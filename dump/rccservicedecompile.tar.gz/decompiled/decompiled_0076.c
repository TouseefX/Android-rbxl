/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 19000 ; VA 0x009ce0b0 ; FUN_009ce0b0 */

int * FUN_009ce0b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
                  undefined4 param_9,int *param_10)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5cb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_0087ddc0(param_1,PTR_s_RaycastResult_01d6d3d4,0x28,DAT_01ede720);
  *puVar3 = param_2;
  puVar3[1] = param_3;
  puVar3[2] = param_4;
  puVar3[3] = param_5;
  *(undefined8 *)(puVar3 + 4) = param_6;
  puVar3[6] = param_7;
  puVar3[7] = param_8;
  puVar3[8] = 0;
  puVar3[9] = 0;
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  puVar3[8] = param_9;
  puVar3[9] = param_10;
  piVar4 = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    piVar1 = param_10 + 1;
    iVar2 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar4 = (int *)(**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar4 = (int *)(**(code **)(*param_10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 19001 ; VA 0x009ce170 ; FUN_009ce170 */

undefined4 * FUN_009ce170(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_0087ddc0(param_1,PTR_s_RBXScriptConnection_01d6d3e4,4,DAT_01ede69c);
  *puVar3 = 0;
  if (param_2 != (int *)0x0) {
    if (*param_2 != 0) {
      *puVar3 = param_2;
      piVar1 = param_2 + 1;
      LOCK();
      puVar3 = (undefined4 *)*piVar1;
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    if (param_2 != (int *)0x0) {
      piVar1 = param_2 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      puVar3 = (undefined4 *)(iVar2 + -1);
      if (puVar3 == (undefined4 *)0x0) {
        puVar3 = (undefined4 *)FUN_01674ea0(param_2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 19002 ; VA 0x009ce200 ; FUN_009ce200 */

int __thiscall FUN_009ce200(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_0055ba30(param_2,param_2);
  *param_1 = 0;
  piVar3 = (int *)param_1[1];
  iVar4 = 0;
  param_1[1] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 19003 ; VA 0x009ce270 ; FUN_009ce270 */

undefined4 *
FUN_009ce270(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6
            )

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar1 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
    if (cVar1 != '\0') {
      puVar2 = (undefined4 *)FUN_00889fa0();
      iVar3 = puVar2[1];
      *param_1 = 0;
      param_1[1] = 0;
      if (iVar3 != 0) {
        LOCK();
        *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
        UNLOCK();
        iVar3 = puVar2[1];
      }
      *param_1 = *puVar2;
      param_1[1] = iVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = (undefined4 *)*param_6;
  if (puVar2 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  iVar3 = puVar2[1];
  *param_1 = 0;
  param_1[1] = 0;
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = puVar2[1];
  }
  *param_1 = *puVar2;
  param_1[1] = iVar3;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19004 ; VA 0x009ce3c0 ; FUN_009ce3c0 */

int FUN_009ce3c0(int *param_1,int *param_2)

{
  undefined uVar1;
  undefined2 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  float *pfVar7;
  double *pdVar8;
  int iVar9;
  int iVar10;
  undefined8 *puVar11;
  int *piVar12;
  undefined *puVar13;
  int *piVar14;
  int *piVar15;
  undefined4 uVar16;
  undefined4 *puVar17;
  bool bVar18;
  double in_XMM0_Qa;
  undefined8 uVar19;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  undefined8 uStack_50;
  int iStack_48;
  int *piStack_44;
  int iStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5d6f;
  pvStack_10 = ExceptionList;
  piVar14 = (int *)*param_1;
  switch(piVar14[7]) {
  default:
    goto switchD_009ce3f1_caseD_0;
  case 1:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088daf0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    FUN_01256800(param_2,*(undefined *)piVar14);
    break;
  case 2:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088c8c0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    in_XMM0_Qa = (double)*piVar14;
    goto LAB_009ce444;
  case 3:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088da50();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    FUN_016f4020();
    goto LAB_009ce444;
  case 4:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088c960();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    pfVar7 = (float *)(param_1 + 2);
    if (param_1[1] == 0) {
      pfVar7 = (float *)0x0;
    }
    in_XMM0_Qa = (double)*pfVar7;
    goto LAB_009ce444;
  case 5:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088ca00();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    pdVar8 = (double *)(param_1 + 2);
    if (param_1[1] == 0) {
      pdVar8 = (double *)0x0;
    }
    in_XMM0_Qa = *pdVar8;
LAB_009ce444:
    FUN_012569a0(param_2,in_XMM0_Qa);
    break;
  case 6:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088cb40();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    goto LAB_009ce4cc;
  case 7:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00886600();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    uVar16 = FUN_00a33fa0();
    FUN_0087de50(param_2,uVar16);
    break;
  case 8:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088cdc0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    FUN_00da3620(param_2,piVar14);
    break;
  case 9:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088cc80();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    FUN_00557fc0();
    uStack_8 = 2;
    if (iStack_48 != 0) {
      param_1 = (int *)FUN_009d5bb0(iStack_48,param_2);
      piStack_34 = piStack_44;
LAB_009ce5eb:
      piVar14 = piStack_34;
      if (piStack_34 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return (int)param_1;
      }
LAB_009ce5f9:
      LOCK();
      iVar9 = piVar14[1] + -1;
      piVar14[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar14)();
        LOCK();
        piVar15 = piVar14 + 2;
        iVar9 = *piVar15;
        *piVar15 = *piVar15 + -1;
        UNLOCK();
        if (iVar9 == 1) {
          (**(code **)(*piVar14 + 4))();
        }
      }
      ExceptionList = pvStack_10;
      return (int)param_1;
    }
    FUN_01255f00(param_2,0,0);
    piVar15 = piStack_44;
    goto LAB_009ce6bb;
  case 10:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d370();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    uVar19 = CONCAT44(DAT_01ede6b8,0x18);
    puVar13 = PTR_DAT_01d6d380;
    goto LAB_009cea3b;
  case 0xb:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d730();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iVar9 = *piVar14;
    piStack_1c = (int *)piVar14[1];
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_Vector2_01d6d384,8,DAT_01ede6c4);
    *piVar14 = iVar9;
    piVar14[1] = (int)piStack_1c;
    break;
  case 0xc:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d870();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    FUN_00d987b0(param_2,piVar14);
    break;
  case 0xd:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d7d0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iVar9 = *piVar14;
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_Vector2int16_01d6d388,4,DAT_01ede6c0);
    *piVar14 = iVar9;
    break;
  case 0xe:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d910();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iVar9 = *piVar14;
    uVar2 = *(undefined2 *)(piVar14 + 1);
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_Vector3int16_01d6d37c,6,DAT_01ede6bc);
    *piVar14 = iVar9;
    *(undefined2 *)(piVar14 + 1) = uVar2;
    break;
  case 0xf:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d410();
    puVar13 = PTR_DAT_01d6d370;
    uVar16 = DAT_01ede6c8;
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    goto LAB_009ce9f7;
  case 0x10:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00b00260();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iStack_30 = *piVar14;
    iStack_2c = piVar14[1];
    iStack_28 = piVar14[2];
    iStack_24 = piVar14[3];
    iVar9 = piVar14[4];
    iStack_64 = piVar14[5];
    iStack_60 = piVar14[6];
    iStack_5c = piVar14[7];
    iStack_58 = piVar14[8];
    iStack_54 = piVar14[9];
    uStack_50._0_4_ = piVar14[10];
    uStack_50._4_4_ = piVar14[0xb];
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_DAT_01d6d364,0x30,DAT_01ede6d4);
    *piVar14 = iStack_30;
    piVar14[1] = iStack_2c;
    piVar14[2] = iStack_28;
    piVar14[3] = iStack_24;
    piVar14[4] = iVar9;
    piVar14[5] = iStack_64;
    piVar14[6] = iStack_60;
    piVar14[7] = iStack_5c;
    piVar14[8] = iStack_58;
    piVar14[9] = iStack_54;
    piVar14[10] = (int)uStack_50;
    piVar14[0xb] = uStack_50._4_4_;
    break;
  case 0x11:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d050();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    uStack_18 = *(undefined8 *)piVar14;
    iVar9 = piVar14[2];
    puVar11 = (undefined8 *)FUN_0087ddc0(param_2,PTR_s_Color3_01d6d38c,0xc,DAT_01ea8be8);
    *puVar11 = uStack_18;
    *(int *)(puVar11 + 1) = iVar9;
    break;
  case 0x13:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d690();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iVar9 = *piVar14;
    iVar3 = piVar14[1];
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_DAT_01d6d390,8,DAT_01ede6e8);
    *piVar14 = iVar9;
    piVar14[1] = iVar3;
    break;
  case 0x14:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d5f0();
    puVar13 = PTR_s_UDim2_01d6d398;
    uVar16 = DAT_01ede6ec;
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
LAB_009ce9f7:
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iStack_30 = *piVar14;
    iStack_2c = piVar14[1];
    iStack_28 = piVar14[2];
    iStack_24 = piVar14[3];
    piVar14 = (int *)FUN_0087ddc0(param_2,puVar13,CONCAT44(uVar16,0x10));
    *piVar14 = iStack_30;
    piVar14[1] = iStack_2c;
    piVar14[2] = iStack_28;
    piVar14[3] = iStack_24;
    break;
  case 0x15:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d230();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iVar9 = *piVar14;
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_Faces_01d6d39c,4,DAT_01ede6d8);
    *piVar14 = iVar9;
    break;
  case 0x16:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088ce60();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iVar9 = *piVar14;
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_DAT_01d6d3a0,4,DAT_01ede6dc);
    *piVar14 = iVar9;
    break;
  case 0x17:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00a73110();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iStack_30 = *piVar14;
    iStack_2c = piVar14[1];
    iStack_28 = piVar14[2];
    iStack_24 = piVar14[3];
    iVar9 = piVar14[0xe];
    iVar3 = piVar14[4];
    iStack_64 = piVar14[5];
    iStack_60 = piVar14[6];
    iStack_5c = piVar14[7];
    iStack_58 = piVar14[8];
    iStack_54 = piVar14[9];
    uStack_50._0_4_ = piVar14[10];
    uStack_50._4_4_ = piVar14[0xb];
    uStack_18 = *(undefined8 *)(piVar14 + 0xc);
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_Region3_01d6d374,0x3c,DAT_01ede6f0);
    *piVar14 = iStack_30;
    piVar14[1] = iStack_2c;
    piVar14[2] = iStack_28;
    piVar14[3] = iStack_24;
    piVar14[4] = iVar3;
    piVar14[5] = iStack_64;
    piVar14[6] = iStack_60;
    piVar14[7] = iStack_5c;
    piVar14[8] = iStack_58;
    piVar14[9] = iStack_54;
    piVar14[10] = (int)uStack_50;
    piVar14[0xb] = uStack_50._4_4_;
    *(undefined8 *)(piVar14 + 0xc) = uStack_18;
    piVar14[0xe] = iVar9;
    break;
  case 0x18:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00b33940();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    uStack_18 = *(undefined8 *)piVar14;
    iVar9 = piVar14[2];
    puVar11 = (undefined8 *)FUN_0087ddc0(param_2,PTR_s_Region3int16_01d6d378,0xc,DAT_01ede6f8);
    *puVar11 = uStack_18;
    *(int *)(puVar11 + 1) = iVar9;
    break;
  case 0x19:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00d896b0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    uVar1 = *(undefined *)piVar14;
    uStack_18 = *(undefined8 *)(piVar14 + 1);
    piVar15 = (int *)piVar14[5];
    piStack_1c = (int *)piVar14[3];
    if (piVar15 != (int *)0x0) {
      LOCK();
      piVar15[1] = piVar15[1] + 1;
      UNLOCK();
      piVar15 = (int *)piVar14[5];
    }
    iVar9 = piVar14[4];
    uStack_8 = 5;
    puVar13 = (undefined *)FUN_0087ddc0(param_2,PTR_s_CellId_01d6d3a8,0x18,DAT_01ede6e0);
    *puVar13 = uVar1;
    *(undefined8 *)(puVar13 + 4) = uStack_18;
    *(int **)(puVar13 + 0xc) = piStack_1c;
    piVar14 = piVar15 + 1;
    *(undefined4 *)(puVar13 + 0x10) = 0;
    *(undefined4 *)(puVar13 + 0x14) = 0;
    if (piVar15 != (int *)0x0) {
      LOCK();
      *piVar14 = *piVar14 + 1;
      UNLOCK();
    }
    *(int *)(puVar13 + 0x10) = iVar9;
    *(int **)(puVar13 + 0x14) = piVar15;
    if (piVar15 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return 1;
    }
    LOCK();
    iVar9 = *piVar14;
    *piVar14 = iVar9 + -1;
    bVar18 = iVar9 + -1 == 0;
    UNLOCK();
    goto LAB_009ce6cd;
  case 0x1b:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d2d0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    uVar19 = CONCAT44(DAT_01ede6cc,0x18);
    puVar13 = PTR_s_PhysicalProperties_01d6d36c;
    goto LAB_009cea3b;
  case 0x1c:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088cfa0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iVar9 = *piVar14;
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_BrickColor_01d6d3a4,4,DAT_01ede6d0);
    *piVar14 = iVar9;
    break;
  case 0x20:
    if (*(char *)((int)piVar14 + 0x22) == '\0') {
      piVar14 = (int *)0x0;
    }
    if (piVar14 != (int *)0x0) {
      ExceptionList = &pvStack_10;
      iVar9 = (**(code **)(*piVar14 + 8))();
      if (iVar9 != 0) {
        FUN_00880a00(param_2,iVar9);
        ExceptionList = pvStack_10;
        return 1;
      }
      uVar16 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Invalid value for enum %s",uVar16);
    }
    goto switchD_009ce3f1_caseD_0;
  case 0x21:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_009ca3d0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    FUN_0087de50(param_2,*(undefined4 *)(*piVar14 + 4));
    break;
  case 0x22:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088cbe0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    FUN_00557fc0();
    uStack_8 = 3;
    if ((int *)uStack_18 == (int *)0x0) {
      if (uStack_18._4_4_ != (int *)0x0) {
        LOCK();
        iVar9 = uStack_18._4_4_[1] + -1;
        uStack_18._4_4_[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*uStack_18._4_4_)();
          LOCK();
          piVar14 = uStack_18._4_4_ + 2;
          iVar9 = *piVar14;
          *piVar14 = *piVar14 + -1;
          UNLOCK();
          if (iVar9 == 1) {
            (**(code **)(*uStack_18._4_4_ + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return 0;
    }
    iVar9 = *(int *)uStack_18;
    iVar3 = ((int *)uStack_18)[1];
    param_1 = (int *)0x0;
    for (; iVar9 != iVar3; iVar9 = iVar9 + 0xd0) {
      piStack_1c = param_2;
      iVar10 = FUN_01255e10(param_2,4);
      if (iVar10 == 0) {
LAB_009cf522:
                    /* WARNING: Subroutine does not return */
        FUN_016757c0();
      }
      iVar10 = FUN_009ce3c0();
      param_1 = (int *)((int)param_1 + iVar10);
    }
    uStack_18._4_4_ = (int *)((ulonglong)uStack_18 >> 0x20);
    piVar14 = uStack_18._4_4_;
    if (uStack_18._4_4_ == (int *)0x0) {
      ExceptionList = pvStack_10;
      return (int)param_1;
    }
    goto LAB_009ce5f9;
  case 0x23:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_008882f0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    FUN_00557fc0();
    uStack_8 = 0;
    if (iStack_38 != 0) {
      param_1 = (int *)FUN_009d5b10(iStack_38,param_2);
      goto LAB_009ce5eb;
    }
    FUN_01255f00(param_2,0,0);
    piVar15 = piStack_34;
    goto LAB_009ce6bb;
  case 0x24:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_008881d0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    FUN_00557fc0();
    uStack_8 = 1;
    if (iStack_40 == 0) {
      FUN_01255f00(param_2,0,0);
      piVar15 = piStack_3c;
    }
    else {
      if (*(int *)(iStack_40 + 8) == 0) {
        puVar17 = (undefined4 *)0x0;
      }
      else {
        puVar17 = *(undefined4 **)(*(int *)(iStack_40 + 0x14) + *(int *)(iStack_40 + 4) * 4);
      }
      FUN_01255f00(param_2,0,*(int *)(iStack_40 + 8));
      piVar15 = piStack_3c;
      for (; puVar17 != (undefined4 *)0x0; puVar17 = (undefined4 *)*puVar17) {
        piStack_3c = piVar15;
        FUN_0087de50(param_2,puVar17 + 2);
        iVar9 = FUN_01255e10(param_2,4);
        if (iVar9 == 0) goto LAB_009cf522;
        iVar9 = FUN_009ce3c0(puVar17 + 8);
        if (iVar9 != 1) {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0();
        }
        FUN_01257230();
        piVar15 = piStack_3c;
      }
    }
    goto LAB_009ce6bb;
  case 0x25:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_008880b0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    if (piVar14[1] != 0) {
      LOCK();
      piVar15 = (int *)(piVar14[1] + 4);
      *piVar15 = *piVar15 + 1;
      UNLOCK();
    }
    iVar9 = FUN_009cfdf0(*piVar14,piVar14[1]);
    ExceptionList = pvStack_10;
    return iVar9;
  case 0x27:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00d883d0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    FUN_00557fc0();
    uStack_8 = 4;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    FUN_00d89200(param_2,uStack_20,piStack_1c);
    piVar15 = piStack_1c;
LAB_009ce6bb:
    if (piVar15 != (int *)0x0) {
      LOCK();
      iVar9 = piVar15[1] + -1;
      piVar15[1] = iVar9;
      bVar18 = iVar9 == 0;
      UNLOCK();
LAB_009ce6cd:
      if (bVar18) {
        (**(code **)*piVar15)();
        LOCK();
        piVar14 = piVar15 + 2;
        iVar9 = *piVar14;
        *piVar14 = *piVar14 + -1;
        UNLOCK();
        if (iVar9 == 1) {
          (**(code **)(*piVar15 + 4))();
        }
      }
    }
    break;
  case 0x28:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00d88470();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    FUN_00d892f0(param_2,piVar14);
    break;
  case 0x29:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00a8dcc0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    FUN_00a8df50();
    uStack_8 = 8;
    FUN_0087ddc0(param_2,PTR_s_ColorSequence_01d6d3b0,0xc,DAT_01ede708);
    FUN_00a8df50();
    FUN_00617bc0();
    break;
  case 0x2a:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00a8dd60();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iStack_30 = *piVar14;
    iStack_2c = piVar14[1];
    iStack_28 = piVar14[2];
    iStack_24 = piVar14[3];
    iVar9 = piVar14[4];
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_ColorSequenceKeypoint_01d6d3b8,0x14,DAT_01ede700);
    *piVar14 = iStack_30;
    piVar14[1] = iStack_2c;
    piVar14[2] = iStack_28;
    piVar14[3] = iStack_24;
    piVar14[4] = iVar9;
    break;
  case 0x2b:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00b33310();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iVar9 = *piVar14;
    piStack_1c = (int *)piVar14[1];
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_NumberRange_01d6d3bc,8,DAT_01ede70c);
    *piVar14 = iVar9;
    piVar14[1] = (int)piStack_1c;
    break;
  case 0x2c:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00a92ae0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    FUN_00a92cb0(piVar14,0xe4078678,0x64078678);
    uStack_8 = 7;
    FUN_0087ddc0(param_2,PTR_s_NumberSequence_01d6d3ac,0xc,DAT_01ede704);
    FUN_00a92cb0(&iStack_64,0xe4078678,0x64078678);
    FUN_00617ad0();
    break;
  case 0x2d:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00a92b80();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    uStack_18 = *(undefined8 *)piVar14;
    iVar9 = piVar14[2];
    puVar11 = (undefined8 *)
              FUN_0087ddc0(param_2,PTR_s_NumberSequenceKeypoint_01d6d3b4,0xc,DAT_01ede6fc);
    *puVar11 = uStack_18;
    *(int *)(puVar11 + 1) = iVar9;
    break;
  case 0x2f:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d9b0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    param_1 = (int *)0x0;
    if (((int *)*piVar14 != (int *)0x0) && (*(int *)*piVar14 != 0)) {
      param_1 = (int *)*piVar14;
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
    }
    uStack_8 = 6;
    puVar17 = (undefined4 *)FUN_0087ddc0(param_2,PTR_s_RBXScriptConnection_01d6d3e4,4,DAT_01ede69c);
    *puVar17 = 0;
    if (param_1 != (int *)0x0) {
      if (*param_1 != 0) {
        *puVar17 = param_1;
        LOCK();
        param_1[1] = param_1[1] + 1;
        UNLOCK();
      }
      if (param_1 != (int *)0x0) {
        param_1 = param_1 + 1;
        LOCK();
        iVar9 = *param_1;
        *param_1 = *param_1 + -1;
        UNLOCK();
        if (iVar9 == 1) {
          FUN_01674ea0();
        }
      }
    }
    break;
  case 0x30:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088d190();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
LAB_009ce4cc:
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    FUN_0087de50(param_2,piVar14);
    break;
  case 0x35:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_0088caa0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    FUN_0088dd80(piVar14);
    FUN_009ce010(param_2);
    break;
  case 0x36:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00da8f20();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iStack_30 = *piVar14;
    iStack_2c = piVar14[1];
    iStack_28 = piVar14[2];
    iStack_24 = piVar14[3];
    iVar9 = piVar14[6];
    uStack_18 = *(undefined8 *)(piVar14 + 4);
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_TweenInfo_01d6d3c0,0x1c,DAT_01ede710);
    *piVar14 = iStack_30;
    piVar14[1] = iStack_2c;
    piVar14[2] = iStack_28;
    piVar14[3] = iStack_24;
    *(undefined8 *)(piVar14 + 4) = uStack_18;
    piVar14[6] = iVar9;
    break;
  case 0x37:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00da9bd0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    uVar19 = CONCAT44(DAT_01ede714,0x18);
    puVar13 = PTR_s_DockWidgetPluginGuiInfo_01d6d3c4;
LAB_009cea3b:
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iStack_30 = *piVar14;
    iStack_2c = piVar14[1];
    iStack_28 = piVar14[2];
    iStack_24 = piVar14[3];
    uStack_18 = *(undefined8 *)(piVar14 + 4);
    piVar14 = (int *)FUN_0087ddc0(param_2,puVar13,uVar19);
    *piVar14 = iStack_30;
    piVar14[1] = iStack_2c;
    piVar14[2] = iStack_28;
    piVar14[3] = iStack_24;
    *(undefined8 *)(piVar14 + 4) = uStack_18;
    break;
  case 0x38:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00da6440();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    piVar15 = (int *)piVar14[1];
    if (piVar15 != (int *)0x0) {
      LOCK();
      piVar15[1] = piVar15[1] + 1;
      UNLOCK();
      piVar15 = (int *)piVar14[1];
    }
    iVar9 = *piVar14;
    uStack_50 = CONCAT44(piVar15,iVar9);
    uStack_8 = 9;
    piVar12 = (int *)FUN_0087ddc0(param_2,PTR_s_PluginDrag_01d6d3c8,8,DAT_01ede718);
    piVar14 = piVar15 + 1;
    *piVar12 = 0;
    piVar12[1] = 0;
    if (piVar15 != (int *)0x0) {
      LOCK();
      *piVar14 = *piVar14 + 1;
      UNLOCK();
    }
    *piVar12 = iVar9;
    piVar12[1] = (int)piVar15;
    if (piVar15 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return 1;
    }
    LOCK();
    iVar9 = *piVar14;
    *piVar14 = iVar9 + -1;
    bVar18 = iVar9 + -1 == 0;
    UNLOCK();
    goto LAB_009ce6cd;
  case 0x3a:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00aa0140();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iStack_30 = *piVar14;
    iStack_2c = piVar14[1];
    iStack_28 = piVar14[2];
    iStack_24 = piVar14[3];
    uStack_50 = *(undefined8 *)(piVar14 + 4);
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_PathWaypoint_01d6d3d0,0x18,DAT_01ede71c);
    *piVar14 = iStack_30;
    piVar14[1] = iStack_2c;
    piVar14[2] = iStack_28;
    piVar14[3] = iStack_24;
    *(undefined8 *)(piVar14 + 4) = uStack_50;
    break;
  case 0x3c:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00b38680();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    iVar9 = piVar14[2];
    iVar3 = *piVar14;
    iVar10 = piVar14[1];
    piStack_1c = (int *)piVar14[3];
    piVar14 = (int *)FUN_0087ddc0(param_2,PTR_s_DateTime_01d6d368,0x10,DAT_01ede6e4);
    piVar14[2] = iVar9;
    *piVar14 = iVar3;
    piVar14[1] = iVar10;
    piVar14[3] = (int)piStack_1c;
    break;
  case 0x3d:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00d89a00();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar14 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar14 = (int *)0x0;
    }
    uVar1 = *(undefined *)piVar14;
    iVar9 = piVar14[3];
    iVar3 = piVar14[1];
    if (iVar9 != 0) {
      LOCK();
      *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
      UNLOCK();
      iVar9 = piVar14[3];
    }
    iVar10 = piVar14[2];
    uStack_8 = 10;
    FUN_0054ef60();
    uStack_8 = 0xb;
    puVar13 = (undefined *)FUN_0087ddc0(param_2,PTR_s_RaycastParams_01d6d394,0x28,DAT_01ede698);
    *puVar13 = uVar1;
    *(int *)(puVar13 + 4) = iVar3;
    *(undefined4 *)(puVar13 + 8) = 0;
    *(undefined4 *)(puVar13 + 0xc) = 0;
    if (iVar9 != 0) {
      LOCK();
      *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
      UNLOCK();
    }
    *(int *)(puVar13 + 8) = iVar10;
    *(int *)(puVar13 + 0xc) = iVar9;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    FUN_0054ef60();
    FUN_0087dcc0();
    break;
  case 0x3e:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00d99d10();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    iVar9 = param_1[1];
    puVar17 = (undefined4 *)(-(uint)(iVar9 != 0) & (uint)(param_1 + 2));
    bVar18 = iVar9 == 0;
    piVar14 = param_1 + 8;
    uVar16 = *puVar17;
    uVar4 = puVar17[1];
    uVar5 = puVar17[2];
    uVar6 = puVar17[3];
    uVar19 = *(undefined8 *)(puVar17 + 4);
    if (bVar18) {
      piVar14 = (int *)&DAT_00000018;
    }
    iVar3 = *piVar14;
    piVar14 = param_1 + 9;
    if (bVar18) {
      piVar14 = (int *)&DAT_0000001c;
    }
    iVar10 = *piVar14;
    piVar14 = param_1 + 10;
    if (bVar18) {
      piVar14 = (int *)&DAT_00000020;
    }
    param_1 = param_1 + 0xb;
    if (iVar9 == 0) {
      param_1 = (int *)0x24;
    }
    if (*param_1 != 0) {
      LOCK();
      piVar15 = (int *)(*param_1 + 4);
      *piVar15 = *piVar15 + 1;
      UNLOCK();
    }
    FUN_009ce0b0(param_2,uVar16,uVar4,uVar5,uVar6,uVar19,iVar3,iVar10,*piVar14,*param_1);
    break;
  case 0x41:
    ExceptionList = &pvStack_10;
    piVar15 = (int *)FUN_00da48e0();
    if (piVar14 != piVar15) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    FUN_009cf8d0();
    uStack_8 = 0xd;
    FUN_0087ddc0(param_2,PTR_s_CatalogSearchParams_01d6d360,0x6c,DAT_01ede6b0);
    FUN_009cf8d0();
    FUN_0087db00();
  }
  ExceptionList = pvStack_10;
  return 1;
switchD_009ce3f1_caseD_0:
  ExceptionList = &pvStack_10;
  FUN_01256980();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 19005 ; VA 0x009cf7b0 ; FUN_009cf7b0 */

undefined4 * __thiscall FUN_009cf7b0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5d96;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_00575b50(0,0);
  param_1[1] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  FUN_009cffc0(param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19006 ; VA 0x009cf840 ; FUN_009cf840 */

undefined4 * __thiscall FUN_009cf840(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5db6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_00575b50(0,0);
  param_1[1] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  FUN_009cffc0(param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19007 ; VA 0x009cf8d0 ; FUN_009cf8d0 */

int __thiscall FUN_009cf8d0(int param_1,int param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5dff;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_2 + 0x18);
  *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(param_2 + 0x1c);
  *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 0x20);
  *(undefined4 *)(param_1 + 0x24) = *(undefined4 *)(param_2 + 0x24);
  *(undefined *)(param_1 + 0x28) = *(undefined *)(param_2 + 0x28);
  *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_2 + 0x2c);
  uStack_8 = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  uVar1 = FUN_00575b50(0,0);
  *(undefined4 *)(param_1 + 0x30) = uVar1;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  uStack_8._0_1_ = 2;
  FUN_009cffc0((undefined4 *)(param_2 + 0x2c));
  uStack_8._0_1_ = 3;
  *(undefined4 *)(param_1 + 0x4c) = *(undefined4 *)(param_2 + 0x4c);
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0;
  uVar1 = FUN_00575b50(0,0);
  *(undefined4 *)(param_1 + 0x50) = uVar1;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_009cffc0((undefined4 *)(param_2 + 0x4c));
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19008 ; VA 0x009cf9e0 ; FUN_009cf9e0 */

undefined * __thiscall FUN_009cf9e0(undefined *param_1,undefined *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5c5b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  *(undefined4 *)(param_1 + 4) = *(undefined4 *)(param_2 + 4);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  if (*(int *)(param_2 + 0xc) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0xc) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_2 + 8);
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0xc);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19009 ; VA 0x009cfa60 ; FUN_009cfa60 */

int __thiscall FUN_009cfa60(int param_1,int param_2)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5e20;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    puStack_18 = (undefined4 *)0x0;
    uStack_14 = 0;
    ExceptionList = &pvStack_10;
    puStack_18 = (undefined4 *)FUN_00575b50(0,0);
    uStack_8 = 0;
    if ((undefined4 **)(param_1 + 4) != &puStack_18) {
      FUN_009cd880(*puStack_18,puStack_18);
    }
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if ((undefined4 *)(param_1 + 0xc) != &uStack_24) {
      FUN_009cd590(0,0,param_2);
    }
    FUN_009cffc0(param_2);
    FUN_0056d320();
    FUN_0056c7e0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19010 ; VA 0x009cfb20 ; FUN_009cfb20 */

int __thiscall FUN_009cfb20(int param_1,int param_2)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5e40;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    puStack_18 = (undefined4 *)0x0;
    uStack_14 = 0;
    ExceptionList = &pvStack_10;
    puStack_18 = (undefined4 *)FUN_00575b50(0,0);
    uStack_8 = 0;
    if ((undefined4 **)(param_1 + 4) != &puStack_18) {
      FUN_009cd880(*puStack_18,puStack_18);
    }
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if ((undefined4 *)(param_1 + 0xc) != &uStack_24) {
      FUN_009cd590(0,0,param_2);
    }
    FUN_009cffc0(param_2);
    FUN_0056d320();
    FUN_0056c7e0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19011 ; VA 0x009cfbe0 ; FUN_009cfbe0 */

undefined4 * __thiscall FUN_009cfbe0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5e70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    puVar1 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar1 = (undefined4 *)*param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0(puVar1,param_2[4]);
  }
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  *(undefined *)(param_1 + 10) = *(undefined *)(param_2 + 10);
  if (param_1 + 0xb != param_2 + 0xb) {
    puStack_18 = (undefined4 *)0x0;
    uStack_14 = 0;
    puStack_18 = (undefined4 *)FUN_00575b50(0,0);
    uStack_8 = 0;
    if ((undefined4 **)(param_1 + 0xc) != &puStack_18) {
      FUN_009cd880(*puStack_18,puStack_18);
    }
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (param_1 + 0xe != &uStack_24) {
      FUN_009cd590(0,0,param_2);
    }
    FUN_009cffc0(param_2 + 0xb);
    FUN_0056d320();
    uStack_8 = 0xffffffff;
    FUN_0056c7e0();
  }
  if (param_1 + 0x13 != param_2 + 0x13) {
    puStack_18 = (undefined4 *)0x0;
    uStack_14 = 0;
    puStack_18 = (undefined4 *)FUN_00575b50(0,0);
    uStack_8 = 2;
    if ((undefined4 **)(param_1 + 0x14) != &puStack_18) {
      FUN_009cd880(*puStack_18,puStack_18);
    }
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (param_1 + 0x16 != &uStack_24) {
      FUN_009cd590(0,0,param_2);
    }
    FUN_009cffc0(param_2 + 0x13);
    FUN_0056d320();
    FUN_0056c7e0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19012 ; VA 0x009cfd70 ; FUN_009cfd70 */

undefined4 * __thiscall FUN_009cfd70(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  
  uVar3 = param_2[1];
  uVar4 = param_2[2];
  uVar5 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar3;
  param_1[2] = uVar4;
  param_1[3] = uVar5;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  iVar6 = param_2[9];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = param_2[9];
  }
  param_1[8] = param_2[8];
  piVar2 = (int *)param_1[9];
  param_1[9] = iVar6;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 19013 ; VA 0x009cfdf0 ; FUN_009cfdf0 */

undefined4 __thiscall FUN_009cfdf0(undefined4 *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5e88;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_2 == (int *)0x0) {
    ExceptionList = &pvStack_10;
    FUN_01255f00(*param_1,0,0);
  }
  else {
    puVar3 = (undefined4 *)*param_2;
    puVar4 = (undefined4 *)*puVar3;
    ExceptionList = &pvStack_10;
    FUN_01255f00(*param_1,0,param_2[1]);
    while (puVar4 != puVar3) {
      FUN_0087de50(*param_1,puVar4 + 4);
      uVar5 = *param_1;
      iVar8 = FUN_01255e10(uVar5,4);
      if (iVar8 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Cannot create enough space in lua stack for bridging value");
      }
      iVar8 = FUN_009ce3c0(puVar4 + 10,uVar5);
      if (iVar8 != 1) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Cannot expand tuple.");
      }
      FUN_01257230(*param_1,0xfffffffd);
      puVar6 = (undefined4 *)puVar4[2];
      if (*(char *)((int)puVar6 + 0xd) == '\0') {
        cVar2 = *(char *)((int)*puVar6 + 0xd);
        puVar4 = puVar6;
        puVar6 = (undefined4 *)*puVar6;
        while (cVar2 == '\0') {
          cVar2 = *(char *)((int)*puVar6 + 0xd);
          puVar4 = puVar6;
          puVar6 = (undefined4 *)*puVar6;
        }
      }
      else {
        cVar2 = *(char *)((int)puVar4[1] + 0xd);
        puVar7 = (undefined4 *)puVar4[1];
        puVar6 = puVar4;
        while ((puVar4 = puVar7, cVar2 == '\0' && (puVar6 == (undefined4 *)puVar4[2]))) {
          cVar2 = *(char *)((int)puVar4[1] + 0xd);
          puVar7 = (undefined4 *)puVar4[1];
          puVar6 = puVar4;
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar8 = param_3[1] + -1;
    param_3[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 19014 ; VA 0x009cff20 ; FUN_009cff20 */

void __fastcall FUN_009cff20(float *param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  undefined auStack_c [8];
  
  fVar2 = param_1[7];
  fVar3 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar2 + (double)(&DAT_018c0d90)[-((int)fVar2 >> 0x1f)]);
  if (*param_1 <= fVar3 && fVar3 != *param_1) {
    if ((uint)fVar2 < 0x200) {
      fVar2 = (float)((int)fVar2 << 3);
    }
    else if ((uint)fVar2 < 0x1fffffff) {
      fVar2 = (float)((int)fVar2 * 2);
    }
    FUN_009d00e0(fVar2);
    pfVar1 = (float *)param_1[1];
    if ((float *)*pfVar1 != pfVar1) {
      fVar2 = pfVar1[1];
      do {
        fVar3 = *(float *)param_1[1];
        FUN_009cd6d0(auStack_c,(int)fVar3 + 8,fVar3);
      } while (fVar3 != fVar2);
    }
  }
  return;
}



/* FUNCTION 19015 ; VA 0x009cffc0 ; FUN_009cffc0 */

void __thiscall FUN_009cffc0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined *puVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined auStack_24 [8];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5ea0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  piVar1 = param_1 + 1;
  ExceptionList = &pvStack_10;
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  piVar2 = (int *)*piVar1;
  piVar6 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*piVar1 + 4) = *piVar1;
  param_1[2] = 0;
  puStack_18 = param_1;
  puVar4 = &stack0xffffffd0;
  if (piVar6 != (int *)*piVar1) {
    do {
      piVar2 = (int *)*piVar6;
      FUN_01674ea0(piVar6,0xc);
      piVar6 = piVar2;
      puVar4 = puStack_14;
    } while (piVar2 != (int *)*piVar1);
  }
  puStack_14 = puVar4;
  *puStack_18 = *puVar3;
  param_2 = (undefined4 *)*piVar1;
  uStack_8 = 0;
  FUN_009d0140((int)(puVar3[4] - puVar3[3]) >> 2,&param_2);
  puVar3 = (undefined4 *)puVar3[1];
  puVar7 = (undefined4 *)*puVar3;
  while( true ) {
    if (puVar7 == puVar3) {
      ExceptionList = pvStack_10;
      return;
    }
    param_2 = *(undefined4 **)*piVar1;
    puStack_1c = *(undefined4 **)((int)param_2 + 4);
    uVar5 = FUN_00602bf0(param_2,puStack_1c,puVar7 + 2);
    if (param_1[2] == 0x15555554) break;
    param_1[2] = param_1[2] + 1;
    *(undefined4 *)((int)param_2 + 4) = uVar5;
    *puStack_1c = uVar5;
    FUN_009cd6d0(auStack_24,*(int *)*piVar1 + 8,*(int *)*piVar1);
    puVar7 = (undefined4 *)*puVar7;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 19016 ; VA 0x009d00c5 ; Catch_All@009d00c5 */

void Catch_All_009d00c5(void)

{
  FUN_009d0220();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19017 ; VA 0x009d00e0 ; FUN_009d00e0 */

void __thiscall FUN_009d00e0(int param_1,int param_2)

{
  uint uVar1;
  int iStack_8;
  
  uVar1 = param_2 * 2;
  if ((uint)(*(int *)(param_1 + 0x14) - *(int *)(param_1 + 0xc) >> 2) < uVar1) {
    iStack_8 = param_1;
    if (0x3fffffff < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_005cb650(uVar1);
  }
  iStack_8 = *(int *)(param_1 + 4);
  FUN_009d0140(uVar1,&iStack_8);
  *(int *)(param_1 + 0x1c) = param_2;
  *(int *)(param_1 + 0x18) = param_2 + -1;
  return;
}



/* FUNCTION 19018 ; VA 0x009d0140 ; FUN_009d0140 */

void __thiscall FUN_009d0140(int *param_1,uint param_2,undefined4 *param_3)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = *param_1;
  uVar4 = param_1[2] - iVar5 >> 2;
  uVar2 = param_1[1] - iVar5 >> 2;
  if (uVar4 < param_2) {
    if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar2 = param_2;
    if ((uVar4 <= 0x3fffffff - (uVar4 >> 1)) && (uVar2 = (uVar4 >> 1) + uVar4, uVar2 < param_2)) {
      uVar2 = param_2;
    }
    if (iVar5 != 0) {
      FUN_0057d270(iVar5,uVar4);
    }
    FUN_005d2220(uVar2);
    puVar3 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar3 = *param_3;
        puVar3 = puVar3 + 1;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
      param_1[1] = (int)puVar3;
      return;
    }
  }
  else {
    if (param_2 <= uVar2) {
      iVar1 = iVar5 + param_2 * 4;
      FUN_005ca6d0(iVar5,iVar1,param_3);
      param_1[1] = iVar1;
      return;
    }
    FUN_005ca6d0(iVar5,param_1[1],param_3);
    puVar3 = (undefined4 *)param_1[1];
    for (iVar5 = param_2 - uVar2; iVar5 != 0; iVar5 = iVar5 + -1) {
      *puVar3 = *param_3;
      puVar3 = puVar3 + 1;
    }
  }
  param_1[1] = (int)puVar3;
  return;
}



/* FUNCTION 19019 ; VA 0x009d0220 ; FUN_009d0220 */

void __fastcall FUN_009d0220(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[1];
  piVar3 = (int *)*piVar2;
  ExceptionList = &pvStack_10;
  *piVar2 = (int)piVar2;
  *(int *)(param_1[1] + 4) = param_1[1];
  param_1[2] = 0;
  piVar2 = (int *)param_1[1];
  piStack_14 = param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_01674ea0(piVar3,0xc);
      piVar2 = (int *)param_1[1];
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  if ((uint)(param_1[5] - param_1[3] >> 2) < 0x10) {
    FUN_005cb650(0x10);
    piVar2 = (int *)param_1[1];
  }
  piStack_14 = piVar2;
  FUN_009d0140(0x10,&piStack_14);
  param_1[6] = 7;
  param_1[7] = 8;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19020 ; VA 0x009d02c0 ; FUN_009d02c0 */

void FUN_009d02c0(undefined4 param_1)

{
  FUN_009cf8d0(param_1);
  return;
}



/* FUNCTION 19021 ; VA 0x009d02d0 ; FUN_009d02d0 */

void FUN_009d02d0(undefined *param_1,undefined *param_2)

{
  int *piVar1;
  
  *param_2 = *param_1;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
  *(undefined4 *)(param_2 + 0xc) = *(undefined4 *)(param_1 + 0xc);
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0;
  if (*(int *)(param_1 + 0x14) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x14) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_2 + 0x10) = *(undefined4 *)(param_1 + 0x10);
  *(undefined4 *)(param_2 + 0x14) = *(undefined4 *)(param_1 + 0x14);
  return;
}



/* FUNCTION 19022 ; VA 0x009d0320 ; FUN_009d0320 */

void FUN_009d0320(undefined *param_1,undefined *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = *param_1;
  *(undefined4 *)(param_2 + 4) = *(undefined4 *)(param_1 + 4);
  *(undefined4 *)(param_2 + 8) = 0;
  *(undefined4 *)(param_2 + 0xc) = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0xc) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_2 + 8) = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_2 + 0xc) = *(undefined4 *)(param_1 + 0xc);
  uStack_8 = 0;
  FUN_0054ef60(param_1 + 0x10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19023 ; VA 0x009d03a0 ; FUN_009d03a0 */

void FUN_009d03a0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar2 = param_1[1];
  uVar3 = param_1[2];
  uVar4 = param_1[3];
  *param_2 = *param_1;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
  param_2[6] = param_1[6];
  param_2[7] = param_1[7];
  param_2[8] = 0;
  param_2[9] = 0;
  if (param_1[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[8] = param_1[8];
  param_2[9] = param_1[9];
  return;
}



/* FUNCTION 19024 ; VA 0x009d03f0 ; FUN_009d03f0 */

void FUN_009d03f0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *param_2 = *param_1;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
  param_2[6] = param_1[6];
  return;
}



/* FUNCTION 19025 ; VA 0x009d0420 ; FUN_009d0420 */

int * FUN_009d0420(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  *param_2 = 0;
  piVar3 = (int *)*param_1;
  if ((piVar3 != (int *)0x0) && (piVar3 = (int *)*piVar3, piVar3 != (int *)0x0)) {
    iVar2 = *param_1;
    *param_2 = iVar2;
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    piVar3 = (int *)*piVar1;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  return piVar3;
}



/* FUNCTION 19026 ; VA 0x009d0450 ; FUN_009d0450 */

undefined4 * FUN_009d0450(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  piVar4 = param_2;
  puStack_c = &LAB_017d5f07;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uStack_8 = 0;
  iVar6 = *param_2;
  iVar5 = FUN_00888530();
  if (iVar6 != iVar5) {
    iVar6 = FUN_01674e20(0xc);
    uStack_8 = 2;
    if (iVar6 == 0) {
      iVar6 = 0;
    }
    else {
      FUN_00569550(1,&uStack_11);
    }
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_009ce200(iVar6);
    piVar2 = *(int **)*param_1;
    piVar1 = piVar2 + 1;
    *piVar2 = *piVar4;
    if (piVar4 + 1 != piVar1) {
      if (*piVar1 != 0) {
        (**(code **)(*piVar1 + 8))(piVar2 + 2);
        *piVar1 = 0;
      }
      puVar3 = (undefined4 *)piVar4[1];
      if (puVar3 != (undefined4 *)0x0) {
        (*(code *)*puVar3)(piVar4 + 2,piVar2 + 2);
        *piVar1 = param_2[1];
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  iVar6 = FUN_01674e20(0xc);
  uStack_8 = 1;
  if (iVar6 == 0) {
    uStack_8 = 0;
    FUN_009ce200(0);
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00569550(0,(int)&param_2 + 3);
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_009ce200(iVar6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19027 ; VA 0x009d05a0 ; FUN_009d05a0 */

void FUN_009d05a0(void)

{
  FUN_0087dcc0();
  return;
}



/* FUNCTION 19028 ; VA 0x009d05b0 ; FUN_009d05b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_009d05b0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  double dVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  float10 fVar5;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_012578b0(param_1,param_2);
    if (iVar3 == 3) {
      fVar5 = (float10)FUN_01257500(param_1,param_2,0);
      dVar1 = (double)fVar5;
      if (dVar1 < _PTR_018c6f48) {
        ExceptionList = pvStack_10;
        return (int)(dVar1 - _PTR_018cf0f8);
      }
      ExceptionList = pvStack_10;
      return (int)(dVar1 + _PTR_018cf0f8);
    }
    if (param_3 <= param_4) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar2 = FUN_009d1bf0(param_1,param_2,&uStack_ec,1);
      if (cVar2 != '\0') {
        piVar4 = (int *)FUN_00889220();
        iVar3 = *piVar4;
        uStack_8 = 1;
        if (iStack_e8 == 0) {
          ExceptionList = pvStack_10;
          return iVar3;
        }
        (**(code **)(iStack_e8 + 8))(auStack_e4);
        ExceptionList = pvStack_10;
        return iVar3;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8 = 0xffffffff;
    }
  }
  if ((int *)*param_5 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return *(int *)*param_5;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 19029 ; VA 0x009d0730 ; FUN_009d0730 */

float10 FUN_009d0730(undefined4 param_1,int param_2,int param_3,int param_4,undefined4 *param_5)

{
  char cVar1;
  int iVar2;
  float *pfVar3;
  float10 fVar4;
  float fVar5;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_012578b0(param_1,param_2);
    if (iVar2 == 3) {
      fVar4 = (float10)FUN_01257500(param_1,param_2,0);
      ExceptionList = pvStack_10;
      return (float10)(float)fVar4;
    }
    if (param_3 <= param_4) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar1 = FUN_009d1bf0(param_1,param_2,&uStack_ec,1);
      if (cVar1 != '\0') {
        pfVar3 = (float *)FUN_008894a0();
        fVar5 = *pfVar3;
        uStack_8 = 1;
        if (iStack_e8 != 0) {
          (**(code **)(iStack_e8 + 8))(auStack_e4);
        }
        goto LAB_009d0845;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8 = 0xffffffff;
    }
  }
  if ((float *)*param_5 == (float *)0x0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  fVar5 = *(float *)*param_5;
LAB_009d0845:
  ExceptionList = pvStack_10;
  return (float10)fVar5;
}



/* FUNCTION 19030 ; VA 0x009d0880 ; FUN_009d0880 */

float10 FUN_009d0880(undefined4 param_1,int param_2,int param_3,int param_4,undefined4 *param_5)

{
  char cVar1;
  int iVar2;
  double *pdVar3;
  float10 fVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [4];
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_012578b0(param_1,param_2);
    if (iVar2 == 3) {
      fVar4 = (float10)FUN_01257500(param_1,param_2,0);
      ExceptionList = pvStack_10;
      return fVar4;
    }
    if (param_3 <= param_4) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar1 = FUN_009d1bf0(param_1,param_2,&uStack_ec,1);
      if (cVar1 != '\0') {
        pdVar3 = (double *)FUN_008896a0();
        dStack_18 = *pdVar3;
        uStack_8 = 1;
        if (iStack_e8 != 0) {
          (**(code **)(iStack_e8 + 8))(auStack_e4);
        }
        goto LAB_009d098f;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8 = 0xffffffff;
    }
  }
  if ((double *)*param_5 == (double *)0x0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  dStack_18 = *(double *)*param_5;
LAB_009d098f:
  ExceptionList = pvStack_10;
  return (float10)dStack_18;
}



/* FUNCTION 19031 ; VA 0x009d09d0 ; FUN_009d09d0 */

undefined *
FUN_009d09d0(undefined *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  param_3 = param_3 + param_4;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_012578b0(param_2,param_3);
    if (iVar2 == 5) {
      uVar3 = FUN_01257440(param_2,param_3,&param_5);
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0xf;
      *param_1 = 0;
      FUN_005542c0(uVar3,param_5);
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (param_4 <= param_5) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar1 = FUN_009d1bf0(param_2,param_3,&uStack_ec,1);
      if (cVar1 != '\0') {
        uVar3 = FUN_008898b0();
        FUN_0054ef60(uVar3);
        uStack_8 = 1;
        if (iStack_e8 == 0) {
          ExceptionList = pvStack_10;
          return param_1;
        }
        (**(code **)(iStack_e8 + 8))(auStack_e4);
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8 = 0xffffffff;
    }
  }
  if (*param_6 == 0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  FUN_0054ef60(*param_6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19032 ; VA 0x009d0b50 ; FUN_009d0b50 */

int * FUN_009d0b50(int *param_1,undefined4 param_2,int param_3,uint param_4,undefined4 *param_5,
                  undefined4 *param_6)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  uint uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  int *piVar10;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [200];
  int *piStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5f4d;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  if ((int)param_5 < (int)param_4) {
    piVar1 = (int *)*param_6;
    if (piVar1 == (int *)0x0) {
      piStack_1c = (int *)0x0;
      puVar6 = &uStack_20;
      bVar3 = false;
      bVar2 = true;
      iVar8 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      piStack_14 = (int *)piVar1[1];
      ExceptionList = &pvStack_10;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        ExceptionList = &pvStack_10;
        piStack_14[1] = piStack_14[1] + 1;
        UNLOCK();
        piStack_14 = (int *)piVar1[1];
      }
      iVar8 = *piVar1;
      bVar3 = true;
      bVar2 = false;
      puVar6 = &uStack_18;
    }
    *puVar6 = 0;
    *param_1 = iVar8;
    param_1[1] = puVar6[1];
    puVar6[1] = 0;
    piVar1 = piStack_1c;
    if ((bVar2) && (piStack_1c != (int *)0x0)) {
      LOCK();
      iVar8 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar10 = piVar1 + 2;
        iVar8 = *piVar10 + -1;
        *piVar10 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piVar1 = piStack_14;
    if ((bVar3) && (piStack_14 != (int *)0x0)) {
      LOCK();
      iVar8 = piStack_14[1] + -1;
      piStack_14[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar10 = piVar1 + 2;
        iVar8 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  iVar8 = (int)param_5 - param_4;
  piStack_14 = (int *)(param_3 + param_4);
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8 = 0;
  piStack_1c = puVar6;
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
    param_5 = (undefined4 *)0x0;
  }
  else {
    puVar6[1] = 1;
    puVar6[2] = 1;
    *puVar6 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    param_5 = puVar6;
    FUN_00569550(iVar8 + 1,(int)&param_4 + 3);
  }
  piVar1 = puVar6 + 3;
  uStack_8._1_3_ = 0;
  iVar8 = puVar6[4] - *piVar1 >> 0x1f;
  param_4 = 0;
  puVar9 = puVar6;
  if ((puVar6[4] - *piVar1) / 0xd0 + iVar8 != iVar8) {
    iVar8 = 0;
    piStack_2c = piVar1;
    puStack_28 = puVar6;
    do {
      uVar4 = param_4;
      uStack_8._0_1_ = 1;
      uStack_fc = FUN_00888530();
      iStack_f8 = 0;
      uStack_8._0_1_ = 2;
      cVar5 = FUN_009d1bf0(param_2,(int)piStack_14 + uVar4,&uStack_fc,1);
      if (cVar5 == '\0') {
        uVar7 = FUN_00888530();
        iStack_1c8 = 0;
        piVar10 = (int *)(iVar8 + 4 + *piVar1);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        *(undefined4 *)(*piVar1 + iVar8) = uVar7;
        if (&iStack_1c8 != piVar10) {
          if (*piVar10 != 0) {
            (**(code **)(*piVar10 + 8))(piVar10 + 1);
            *piVar10 = 0;
          }
          if (iStack_1c8 != 0) {
            (**(code **)(iStack_1c8 + 4))(auStack_1c4,piVar10 + 1);
            *piVar10 = iStack_1c8;
            if (iStack_1c8 != 0) {
              (**(code **)(iStack_1c8 + 8))(auStack_1c4);
              iStack_1c8 = 0;
            }
          }
        }
        FUN_00888530();
        if (iStack_1c8 != 0) {
          (**(code **)(iStack_1c8 + 8))(auStack_1c4);
          iStack_1c8 = 0;
        }
        uStack_8._0_1_ = 4;
        if (iStack_1c8 != 0) {
          (**(code **)(iStack_1c8 + 8))(auStack_1c4);
        }
      }
      else {
        piVar10 = (int *)(iVar8 + 4 + *piVar1);
        *(undefined4 *)(*piVar1 + iVar8) = uStack_fc;
        if (&iStack_f8 != piVar10) {
          if (*piVar10 != 0) {
            (**(code **)(*piVar10 + 8))(piVar10 + 1);
            *piVar10 = 0;
          }
          if (iStack_f8 != 0) {
            (**(code **)(iStack_f8 + 4))(auStack_f4,piVar10 + 1);
            *piVar10 = iStack_f8;
            if (iStack_f8 != 0) {
              (**(code **)(iStack_f8 + 8))(auStack_f4);
              iStack_f8 = 0;
            }
          }
        }
        uStack_fc = FUN_00888530();
        if (iStack_f8 != 0) {
          (**(code **)(iStack_f8 + 8))(auStack_f4);
          iStack_f8 = 0;
        }
      }
      uStack_8._0_1_ = 5;
      if (iStack_f8 != 0) {
        (**(code **)(iStack_f8 + 8))(auStack_f4);
      }
      iVar8 = iVar8 + 0xd0;
      param_4 = param_4 + 1;
      puVar9 = param_5;
    } while (param_4 < (uint)((puVar6[4] - *piVar1) / 0xd0));
  }
  *param_1 = (int)piVar1;
  param_1[1] = (int)puVar9;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19033 ; VA 0x009d0ef0 ; FUN_009d0ef0 */

undefined4 *
FUN_009d0ef0(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6
            )

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar2 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
    if (cVar2 != '\0') {
      puVar3 = (undefined4 *)FUN_00887bf0();
      *param_1 = 0;
      param_1[1] = 0;
      if (puVar3[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar3[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *param_1 = *puVar3;
      param_1[1] = puVar3[1];
      uStack_8 = 1;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)*param_6;
  if (puVar3 != (undefined4 *)0x0) {
    *param_1 = 0;
    param_1[1] = 0;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_1 = *puVar3;
    param_1[1] = puVar3[1];
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 19034 ; VA 0x009d1050 ; FUN_009d1050 */

int * FUN_009d1050(int *param_1,undefined4 param_2,int param_3,int param_4,int param_5,
                  undefined4 param_6)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5f77;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    iVar6 = param_3 + param_4;
    ExceptionList = &pvStack_10;
    iVar4 = FUN_012578b0(param_2,iVar6);
    if (iVar4 == 6) {
      iVar4 = FUN_012566d0(param_2,iVar6);
      piVar5 = (int *)FUN_01674e20(0x18);
      uStack_8 = 0;
      if (piVar5 == (int *)0x0) {
        piVar5 = (int *)0x0;
      }
      else {
        piVar5[1] = 1;
        piVar5[2] = 1;
        *piVar5 = (int)std::
                       _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                       ::vftable;
        FUN_008c25b0(iVar4,&uStack_11);
      }
      uStack_8 = 1;
      iVar7 = 0;
      if (0 < iVar4) {
        do {
          iVar1 = iVar7 + 1;
          FUN_01256cb0(param_2,iVar6,iVar1);
          cVar3 = FUN_00da4680(param_2,0xffffffff,piVar5[3] + iVar7 * 8);
          FUN_01257280(param_2,0xfffffffe);
          if (cVar3 == '\0') {
            FUN_009ce270(param_1,param_2,param_3,param_4,param_5,param_6);
            if (piVar5 != (int *)0x0) {
              LOCK();
              iVar4 = piVar5[1] + -1;
              piVar5[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piVar5)();
                LOCK();
                piVar2 = piVar5 + 2;
                iVar4 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar4 == 1) {
                  (**(code **)(*piVar5 + 4))();
                }
              }
            }
            ExceptionList = pvStack_10;
            return param_1;
          }
          iVar7 = iVar1;
        } while (iVar1 < iVar4);
      }
      param_1[1] = (int)piVar5;
      *param_1 = (int)(piVar5 + 3);
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  FUN_009ce270(param_1,param_2,param_3,param_4,param_5,param_6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19035 ; VA 0x009d11e0 ; FUN_009d11e0 */

undefined4 *
FUN_009d11e0(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6
            )

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar2 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
    if (cVar2 != '\0') {
      puVar3 = (undefined4 *)FUN_00887e80();
      *param_1 = 0;
      param_1[1] = 0;
      if (puVar3[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar3[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *param_1 = *puVar3;
      param_1[1] = puVar3[1];
      uStack_8 = 1;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)*param_6;
  if (puVar3 != (undefined4 *)0x0) {
    *param_1 = 0;
    param_1[1] = 0;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_1 = *puVar3;
    param_1[1] = puVar3[1];
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 19036 ; VA 0x009d1340 ; FUN_009d1340 */

undefined4 *
FUN_009d1340(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6
            )

{
  int *piVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5fa3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    param_3 = param_3 + param_4;
    ExceptionList = &pvStack_10;
    iVar4 = FUN_012578b0(param_2,param_3);
    if (iVar4 == 0) {
      *param_1 = 0;
      param_1[1] = 0;
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (iVar4 == 8) {
      uStack_18 = 0;
      uStack_14 = 0;
      uStack_8 = 0;
      cVar3 = FUN_00da4680(param_2,param_3,&uStack_18);
      uVar2 = uStack_18;
      if (cVar3 != '\0') {
        uStack_18 = 0;
        *param_1 = uVar2;
        param_1[1] = uStack_14;
        uStack_14 = 0;
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 0xffffffff;
      FUN_00550b30();
    }
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 1;
    cVar3 = FUN_009d1bf0(param_2,param_3,&uStack_ec,1);
    if (cVar3 != '\0') {
      puVar5 = (undefined4 *)FUN_0088a3d0();
      *param_1 = 0;
      param_1[1] = 0;
      if (puVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar5[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *param_1 = *puVar5;
      param_1[1] = puVar5[1];
      uStack_8 = 2;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = 3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = (undefined4 *)*param_6;
  if (puVar5 != (undefined4 *)0x0) {
    *param_1 = 0;
    param_1[1] = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_1 = *puVar5;
    param_1[1] = puVar5[1];
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 19037 ; VA 0x009d1540 ; FUN_009d1540 */

undefined4 *
FUN_009d1540(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6
            )

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar1 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
    if (cVar1 != '\0') {
      puVar2 = (undefined4 *)FUN_0054eb90();
      *param_1 = *puVar2;
      param_1[1] = 0;
      puVar3 = (undefined4 *)puVar2[1];
      if (puVar3 != (undefined4 *)0x0) {
        (*(code *)*puVar3)(puVar2 + 2,param_1 + 2);
        puVar3 = (undefined4 *)puVar2[1];
      }
      param_1[1] = puVar3;
      uStack_8 = 1;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)*param_6;
  if (puVar3 != (undefined4 *)0x0) {
    *param_1 = *puVar3;
    param_1[1] = 0;
    puVar2 = (undefined4 *)puVar3[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)(puVar3 + 2,param_1 + 2);
      puVar2 = (undefined4 *)puVar3[1];
    }
    param_1[1] = puVar2;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 19038 ; VA 0x009d16a0 ; FUN_009d16a0 */

undefined8 *
FUN_009d16a0(undefined8 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,
            undefined4 *param_6)

{
  undefined4 uVar1;
  char cVar2;
  undefined8 *puVar3;
  undefined4 uStack_f8;
  int iStack_f4;
  undefined auStack_f0 [200];
  undefined auStack_28 [12];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5fbb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    ExceptionList = &pvStack_10;
    cVar2 = FUN_00d920a0(param_2,param_3 + param_4,&uStack_1c);
    if (cVar2 != '\0') {
      *param_1 = CONCAT44(uStack_18,uStack_1c);
      *(undefined4 *)(param_1 + 1) = uStack_14;
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (param_4 <= param_5) {
      uStack_f8 = FUN_00888530();
      iStack_f4 = 0;
      uStack_8 = 0;
      cVar2 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_f8,1);
      if (cVar2 != '\0') {
        puVar3 = (undefined8 *)FUN_0088b880();
        uVar1 = *(undefined4 *)(puVar3 + 1);
        *param_1 = *puVar3;
        *(undefined4 *)(param_1 + 1) = uVar1;
        uStack_8 = 1;
        if (iStack_f4 == 0) {
          ExceptionList = pvStack_10;
          return param_1;
        }
        (**(code **)(iStack_f4 + 8))(auStack_f0);
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 2;
      if (iStack_f4 != 0) {
        (**(code **)(iStack_f4 + 8))(auStack_f0);
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar3 = (undefined8 *)*param_6;
  if (puVar3 != (undefined8 *)0x0) {
    uVar1 = *(undefined4 *)(puVar3 + 1);
    *param_1 = *puVar3;
    *(undefined4 *)(param_1 + 1) = uVar1;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_28,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_28,&DAT_01c17198);
}



/* FUNCTION 19039 ; VA 0x009d1820 ; FUN_009d1820 */

undefined4
FUN_009d1820(undefined4 param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar1 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
    if (cVar1 != '\0') {
      uVar2 = FUN_00d88220();
      FUN_00d88580(uVar2);
      uStack_8 = 1;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*param_6 != 0) {
    FUN_00d88580(*param_6);
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 19040 ; VA 0x009d1940 ; FUN_009d1940 */

undefined4 FUN_009d1940(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  float10 fVar5;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_012578b0(param_1,param_2);
    if (iVar2 == 3) {
      fVar5 = (float10)FUN_01257500(param_1,param_2,0);
      uVar3 = FUN_0172858a((double)fVar5);
      ExceptionList = pvStack_10;
      return uVar3;
    }
    if (param_3 <= param_4) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar1 = FUN_009d1bf0(param_1,param_2,&uStack_ec,1);
      if (cVar1 != '\0') {
        puVar4 = (undefined4 *)FUN_0088baa0();
        uVar3 = *puVar4;
        uStack_8 = 1;
        if (iStack_e8 == 0) {
          ExceptionList = pvStack_10;
          return uVar3;
        }
        (**(code **)(iStack_e8 + 8))();
        ExceptionList = pvStack_10;
        return uVar3;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))();
      }
      uStack_8 = 0xffffffff;
    }
  }
  if ((undefined4 *)*param_5 != (undefined4 *)0x0) {
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 19041 ; VA 0x009d1aa0 ; FUN_009d1aa0 */

bool FUN_009d1aa0(undefined4 param_1,int param_2,int param_3,int param_4,undefined4 *param_5)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  undefined *puVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_012578b0(param_1,param_2);
    if (iVar3 == 1) {
      iVar3 = FUN_01257360(param_1,param_2);
      ExceptionList = pvStack_10;
      return iVar3 != 0;
    }
    if (param_3 <= param_4) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar2 = FUN_009d1bf0(param_1,param_2,&uStack_ec,1);
      if (cVar2 != '\0') {
        puVar4 = (undefined *)FUN_0088bcc0();
        uVar1 = *puVar4;
        uStack_8 = 1;
        if (iStack_e8 == 0) {
          ExceptionList = pvStack_10;
          return (bool)uVar1;
        }
        (**(code **)(iStack_e8 + 8))(auStack_e4);
        ExceptionList = pvStack_10;
        return (bool)uVar1;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8 = 0xffffffff;
    }
  }
  if ((undefined *)*param_5 != (undefined *)0x0) {
    ExceptionList = pvStack_10;
    return (bool)*(undefined *)*param_5;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 19042 ; VA 0x009d1bf0 ; FUN_009d1bf0 */

undefined FUN_009d1bf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined uVar1;
  uint uVar2;
  int iVar3;
  int aiStack_34 [2];
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_1c;
  undefined uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5fd8;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_0060e8c0(0,&uStack_1c,&uStack_11);
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_8 = 0;
  uVar1 = FUN_009d23a0(param_1,param_2,param_3,param_4,aiStack_34);
  if (aiStack_34[0] != 0) {
    uVar2 = iStack_2c - aiStack_34[0] & 0xfffffff8;
    iVar3 = aiStack_34[0];
    if (0xfff < uVar2) {
      iVar3 = *(int *)(aiStack_34[0] + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (aiStack_34[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19043 ; VA 0x009d1cb0 ; FUN_009d1cb0 */

undefined4 __thiscall FUN_009d1cb0(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  
  param_2 = param_2 + *(int *)(param_1 + 0xd4);
  iVar1 = FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if (param_2 <= iVar1) {
    iVar1 = FUN_012578b0(*(undefined4 *)(param_1 + 0xd8),param_2);
    if (iVar1 == 1) {
      iVar1 = FUN_01257360(*(undefined4 *)(param_1 + 0xd8),param_2);
      *(bool *)param_3 = iVar1 != 0;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 19044 ; VA 0x009d1d10 ; FUN_009d1d10 */

undefined4 __thiscall FUN_009d1d10(int param_1,int param_2,double *param_3)

{
  int iVar1;
  float10 fVar2;
  
  param_2 = param_2 + *(int *)(param_1 + 0xd4);
  iVar1 = FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if (param_2 <= iVar1) {
    iVar1 = FUN_012578b0(*(undefined4 *)(param_1 + 0xd8),param_2);
    if (iVar1 == 3) {
      fVar2 = (float10)FUN_01257500(*(undefined4 *)(param_1 + 0xd8),param_2,0);
      *param_3 = (double)fVar2;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 19045 ; VA 0x009d1d70 ; FUN_009d1d70 */

undefined4 __thiscall FUN_009d1d70(int param_1,int param_2,int param_3,undefined4 *param_4)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  
  param_2 = param_2 + *(int *)(param_1 + 0xd4);
  iVar1 = FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if (param_2 <= iVar1) {
    iVar1 = FUN_012578b0(*(undefined4 *)(param_1 + 0xd8),param_2);
    if (iVar1 == 3) {
      FUN_01257500(*(undefined4 *)(param_1 + 0xd8),param_2,0);
      uVar3 = FUN_016f4180();
      *param_4 = uVar3;
      uVar3 = FUN_009cb5f0(uVar3,param_4);
      return uVar3;
    }
    if (iVar1 == 8) {
      piVar2 = (int *)FUN_01257810(*(undefined4 *)(param_1 + 0xd8),param_2,DAT_01e90cd0);
      if (piVar2 != (int *)0x0) {
        if (*(int *)(*piVar2 + 0x18) == param_3) {
          *param_4 = *(undefined4 *)(*piVar2 + 0x1c);
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 19046 ; VA 0x009d1e20 ; FUN_009d1e20 */

undefined4 FUN_009d1e20(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  float10 fVar4;
  int iStack_8;
  
  iVar2 = FUN_012578b0(param_2,param_3);
  if (iVar2 == 8) {
    piVar3 = (int *)FUN_01257810(param_2,param_3,DAT_01e90cd0);
    if (piVar3 != (int *)0x0) {
      if (*(int **)(*piVar3 + 0x18) == param_1) {
        *param_4 = *(int *)(*piVar3 + 0x1c);
        return 1;
      }
    }
  }
  else if (iVar2 == 3) {
    fVar4 = (float10)FUN_01257500(param_2,param_3,0);
    iStack_8 = (int)fVar4;
    cVar1 = FUN_009cb5f0(iStack_8,&iStack_8);
    if (cVar1 != '\0') {
      *param_4 = iStack_8;
      return 1;
    }
  }
  else if (iVar2 == 5) {
    iVar2 = FUN_01257440(param_2,param_3,0);
    if (iVar2 != 0) {
      iVar2 = (**(code **)(*param_1 + 4))(iVar2);
      if (iVar2 != 0) {
        *param_4 = *(int *)(iVar2 + 0x1c);
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 19047 ; VA 0x009d1ef0 ; FUN_009d1ef0 */

undefined4 __thiscall FUN_009d1ef0(int *param_1,undefined4 param_2,undefined8 *param_3)

{
  char cVar1;
  undefined8 uVar2;
  undefined8 uStack_c;
  
  cVar1 = (**(code **)(*param_1 + 0x14))(param_2,&uStack_c);
  if (cVar1 != '\0') {
    uVar2 = FUN_0172858a(uStack_c);
    *param_3 = uVar2;
    return 1;
  }
  return 0;
}



/* FUNCTION 19048 ; VA 0x009d1f40 ; FUN_009d1f40 */

undefined4 * FUN_009d1f40(undefined4 *param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *****pppppuVar5;
  int *piVar6;
  uint *puVar7;
  undefined4 *puVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  uint uVar11;
  uint in_stack_00000020;
  undefined4 ****ppppuStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  undefined8 uStack_70;
  undefined uStack_68;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 ****ppppuStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  uint uStack_38;
  uint uStack_34;
  undefined4 ****ppppuStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6029;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_8 = 0;
  uStack_40 = 0xf00000000;
  ppppuStack_50 = (undefined4 ****)((uint)ppppuStack_50 & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 1;
  iVar4 = FUN_01256300(param_2);
  if (2 < iVar4) {
    FUN_012561a0(param_2,0xffffd8ee,"tostring");
    FUN_01256aa0(param_2,iVar4 + -1);
    FUN_01255dd0(param_2,1,1);
    iVar4 = FUN_01257440(param_2,0xffffffff,&uStack_14);
    if (iVar4 == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Invalid table key type used");
    }
    FUN_00554150(iVar4,uStack_14);
    FUN_01257280(param_2,0xfffffffe);
    iVar4 = (int)uStack_40;
    uStack_8._0_1_ = 2;
    uStack_58 = 0;
    uStack_54 = 0xf;
    uStack_68 = 0;
    uStack_18 = 2;
    FUN_0058a190((int)uStack_40 + 1);
    FUN_00554150(&DAT_019360f0,1);
    pppppuVar5 = &ppppuStack_50;
    if (0xf < uStack_40._4_4_) {
      pppppuVar5 = (undefined4 *****)ppppuStack_50;
    }
    FUN_00554150(pppppuVar5,iVar4);
    piVar6 = (int *)FUN_00554150(&DAT_018d2114,1);
    ppppuStack_80 = (undefined4 ****)*piVar6;
    iStack_7c = piVar6[1];
    iStack_78 = piVar6[2];
    iStack_74 = piVar6[3];
    uStack_28 = *(undefined8 *)(piVar6 + 2);
    uStack_70 = *(undefined8 *)(piVar6 + 4);
    piVar6[4] = 0;
    piVar6[5] = 0xf;
    *(undefined *)piVar6 = 0;
    ppppuStack_30 = ppppuStack_80;
    uStack_2c = iStack_7c;
    uStack_20 = uStack_70;
    FUN_005507b0();
    uStack_70 = 0xf00000000;
    ppppuStack_50 = ppppuStack_30;
    iStack_4c = uStack_2c;
    uStack_48 = (undefined4)uStack_28;
    uStack_44 = uStack_28._4_4_;
    ppppuStack_80 = (undefined4 ****)((uint)ppppuStack_80 & 0xffffff00);
    uStack_40 = uStack_20;
    FUN_005507b0();
    uStack_8._0_1_ = 1;
    FUN_005507b0();
  }
  FUN_00558df0(&ppppuStack_80,&DAT_018c3500,&param_3);
  uStack_8._0_1_ = 3;
  puVar7 = (uint *)FUN_00554150(&DAT_01934888,2);
  uStack_38 = *puVar7;
  uStack_34 = puVar7[1];
  ppppuStack_30 = (undefined4 ****)puVar7[2];
  uStack_2c = puVar7[3];
  uStack_28 = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  pppppuVar5 = &ppppuStack_50;
  if (0xf < uStack_40._4_4_) {
    pppppuVar5 = (undefined4 *****)ppppuStack_50;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puVar8 = (undefined4 *)FUN_00554150(pppppuVar5,(int)uStack_40);
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = puVar8[1];
  uVar2 = puVar8[2];
  uVar3 = puVar8[3];
  *param_1 = *puVar8;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar8 + 4);
  puVar8[4] = 0;
  puVar8[5] = 0xf;
  *(undefined *)puVar8 = 0;
  if (0xf < uStack_28._4_4_) {
    uVar10 = uStack_28._4_4_ + 1;
    uVar11 = uStack_38;
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(uStack_38 - 4);
      uVar10 = uStack_28._4_4_ + 0x24;
      if (0x1f < (uStack_38 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  uStack_28 = 0xf00000000;
  uStack_38 = uStack_38 & 0xffffff00;
  if (0xf < uStack_70._4_4_) {
    uVar11 = uStack_70._4_4_ + 1;
    ppppuVar9 = ppppuStack_80;
    if (0xfff < uVar11) {
      ppppuVar9 = (undefined4 ****)ppppuStack_80[-1];
      uVar11 = uStack_70._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_80 + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar11);
  }
  uStack_70 = 0xf00000000;
  ppppuStack_80 = (undefined4 ****)((uint)ppppuStack_80 & 0xffffff00);
  if (0xf < uStack_40._4_4_) {
    uVar11 = uStack_40._4_4_ + 1;
    pppppuVar5 = (undefined4 *****)ppppuStack_50;
    if (0xfff < uVar11) {
      pppppuVar5 = (undefined4 *****)ppppuStack_50[-1];
      uVar11 = uStack_40._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_50 + (-4 - (int)pppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar5,uVar11);
  }
  if (0xf < in_stack_00000020) {
    uVar11 = in_stack_00000020 + 1;
    iVar4 = param_3;
    if (0xfff < uVar11) {
      iVar4 = *(int *)(param_3 + -4);
      uVar11 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar11);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19049 ; VA 0x009d2290 ; FUN_009d2290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_009d2290(int *param_1,undefined4 param_2,int *param_3)

{
  char cVar1;
  double dStack_c;
  
  cVar1 = (**(code **)(*param_1 + 0x14))(param_2,&dStack_c);
  if (cVar1 == '\0') {
    return 0;
  }
  if (_PTR_018c6f48 <= dStack_c) {
    *param_3 = (int)(dStack_c + _PTR_018cf0f8);
    return 1;
  }
  *param_3 = (int)(dStack_c - _PTR_018cf0f8);
  return 1;
}



/* FUNCTION 19050 ; VA 0x009d2300 ; FUN_009d2300 */

undefined4 __thiscall FUN_009d2300(int param_1,int param_2,undefined4 *param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  
  param_2 = param_2 + *(int *)(param_1 + 0xd4);
  iVar4 = FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if (param_2 <= iVar4) {
    iVar4 = FUN_012578b0(*(undefined4 *)(param_1 + 0xd8),param_2);
    if (iVar4 == 0) {
      *param_3 = 0;
      piVar2 = (int *)param_3[1];
      param_3[1] = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[1] + -1;
        piVar2[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      return 1;
    }
    if ((iVar4 == 8) &&
       (cVar3 = FUN_00da4680(*(undefined4 *)(param_1 + 0xd8),param_2,param_3), cVar3 != '\0')) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 19051 ; VA 0x009d23a0 ; FUN_009d23a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4
FUN_009d23a0(undefined4 param_1,int param_2,undefined4 *param_3,char param_4,undefined4 param_5)

{
  undefined *puVar1;
  undefined4 uVar2;
  void *pvVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  float10 fVar9;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_108;
  int iStack_104;
  undefined auStack_100 [200];
  undefined auStack_38 [32];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6066;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01256300(param_1);
  if (param_2 <= iVar4) {
    uVar5 = FUN_012578b0(param_1,param_2);
    switch(uVar5) {
    case 0:
      if (param_4 == '\0') {
        uStack_1d8 = FUN_00888530();
        uStack_1d4 = 0;
        uStack_8 = 1;
        FUN_00947a40(&uStack_1d8);
        FUN_0056e5b0();
        ExceptionList = pvStack_10;
        return 1;
      }
      break;
    case 1:
      iVar6 = FUN_01257360(param_1,param_2);
      uVar5 = FUN_0088daf0();
      iVar4 = _tls_index;
      *param_3 = uVar5;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar4 * 4) + 0x34) < DAT_01ea8bf8) &&
         (FUN_016f3809(&DAT_01ea8bf8), DAT_01ea8bf8 == -1)) {
        DAT_01ea8bec = FUN_005c6640;
        DAT_01ea8bf0 = FUN_005c6640;
        DAT_01ea8bf4 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ea8bf8);
      }
      puVar7 = (undefined4 *)param_3[1];
      if ((code **)puVar7 == &DAT_01ea8bec) {
        *(bool *)(param_3 + 2) = iVar6 != 0;
        ExceptionList = pvStack_10;
        return 1;
      }
      if (puVar7 != (undefined4 *)0x0) {
        (*(code *)puVar7[2])(param_3 + 2);
      }
      *(bool *)(param_3 + 2) = iVar6 != 0;
      param_3[1] = &DAT_01ea8bec;
      ExceptionList = pvStack_10;
      return 1;
    default:
      uStack_108 = FUN_00888530();
      iStack_104 = 0;
      uStack_8 = 3;
      FUN_00947a40(&uStack_108);
      uStack_8 = 4;
      if (iStack_104 != 0) {
        (**(code **)(iStack_104 + 8))(auStack_100);
      }
      ExceptionList = pvStack_10;
      return 1;
    case 3:
      fVar9 = (float10)FUN_01257500(param_1,param_2,0);
      uStack_18 = (double)fVar9;
      uVar5 = FUN_0088ca00();
      iVar4 = _tls_index;
      *param_3 = uVar5;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar4 * 4) + 0x34) < DAT_01ead488) &&
         (FUN_016f3809(&DAT_01ead488), DAT_01ead488 == -1)) {
        _DAT_01ead47c = FUN_00619e80;
        _DAT_01ead480 = FUN_00619e80;
        DAT_01ead484 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead488);
      }
      puVar1 = (undefined *)param_3[1];
      if (puVar1 == &DAT_01ead47c) {
        *(double *)(param_3 + 2) = uStack_18;
        ExceptionList = pvStack_10;
        return 1;
      }
      if (puVar1 != (undefined *)0x0) {
        (**(code **)(puVar1 + 8))(param_3 + 2);
      }
      *(double *)(param_3 + 2) = uStack_18;
      param_3[1] = &DAT_01ead47c;
      ExceptionList = pvStack_10;
      return 1;
    case 4:
      uVar5 = FUN_00d91fb0(param_1,param_2,param_3);
      ExceptionList = pvStack_10;
      return uVar5;
    case 5:
      uVar5 = FUN_01257440(param_1,param_2,(int)&uStack_18 + 4);
      puVar7 = (undefined4 *)FUN_00565770(uVar5,uStack_18._4_4_);
      uStack_8 = 0;
      uVar5 = FUN_0088cb40();
      pvVar3 = ThreadLocalStoragePointer;
      iVar4 = _tls_index;
      *param_3 = uVar5;
      if ((*(int *)(*(int *)((int)pvVar3 + iVar4 * 4) + 0x34) < DAT_01ea8c48) &&
         (FUN_016f3809(&DAT_01ea8c48), DAT_01ea8c48 == -1)) {
        _DAT_01ea8c3c = FUN_005c65f0;
        _DAT_01ea8c40 = FUN_005c93a0;
        DAT_01ea8c44 = FUN_005c77b0;
        FUN_016f37bf(&DAT_01ea8c48);
      }
      puVar1 = (undefined *)param_3[1];
      if (puVar1 == &DAT_01ea8c3c) {
        if (param_3 + 2 != puVar7) {
          FUN_005507b0();
          uVar5 = puVar7[1];
          uVar8 = puVar7[2];
          uVar2 = puVar7[3];
          param_3[2] = *puVar7;
          param_3[3] = uVar5;
          param_3[4] = uVar8;
          param_3[5] = uVar2;
          *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar7 + 4);
          puVar7[4] = 0;
          puVar7[5] = 0xf;
          *(undefined *)puVar7 = 0;
          FUN_005507b0();
          ExceptionList = pvStack_10;
          return 1;
        }
      }
      else {
        if (puVar1 != (undefined *)0x0) {
          (**(code **)(puVar1 + 8))(param_3 + 2);
          param_3[1] = 0;
        }
        param_3[6] = 0;
        param_3[7] = 0;
        uVar5 = puVar7[1];
        uVar8 = puVar7[2];
        uVar2 = puVar7[3];
        param_3[2] = *puVar7;
        param_3[3] = uVar5;
        param_3[4] = uVar8;
        param_3[5] = uVar2;
        *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar7 + 4);
        puVar7[4] = 0;
        puVar7[5] = 0xf;
        *(undefined *)puVar7 = 0;
        param_3[1] = &DAT_01ea8c3c;
      }
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return 1;
    case 6:
      FUN_009d2b00(param_1,param_2,param_3,param_5);
      ExceptionList = pvStack_10;
      return 1;
    case 7:
      uVar5 = FUN_00d89340(auStack_38,param_1,param_2);
      uStack_8 = 2;
      uVar8 = FUN_00d88470();
      pvVar3 = ThreadLocalStoragePointer;
      iVar4 = _tls_index;
      *param_3 = uVar8;
      if ((*(int *)(*(int *)((int)pvVar3 + iVar4 * 4) + 0x34) < DAT_01ee047c) &&
         (FUN_016f3809(&DAT_01ee047c), DAT_01ee047c == -1)) {
        _DAT_01ee0470 = FUN_008c9370;
        _DAT_01ee0474 = FUN_008c9370;
        DAT_01ee0478 = FUN_008ca540;
        FUN_016f37bf(&DAT_01ee047c);
      }
      puVar1 = (undefined *)param_3[1];
      if (puVar1 == &DAT_01ee0470) {
        FUN_00d88b50(uVar5);
        FUN_00d88a30();
        ExceptionList = pvStack_10;
        return 1;
      }
      if (puVar1 != (undefined *)0x0) {
        (**(code **)(puVar1 + 8))(param_3 + 2);
        param_3[1] = 0;
      }
      FUN_00d88580(uVar5);
      param_3[1] = &DAT_01ee0470;
      FUN_00d88a30();
      ExceptionList = pvStack_10;
      return 1;
    case 8:
      FUN_009d34f0(param_1,param_2,param_3);
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 19052 ; VA 0x009d2940 ; FUN_009d2940 */

uint __thiscall FUN_009d2940(int param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  param_2 = param_2 + *(int *)(param_1 + 0xd4);
  puVar2 = (undefined4 *)FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if (param_2 <= (int)puVar2) {
    puVar2 = (undefined4 *)FUN_01257810(*(undefined4 *)(param_1 + 0xd8),param_2,DAT_01ede6c8);
    if (puVar2 != (undefined4 *)0x0) {
      *param_3 = *puVar2;
      param_3[1] = puVar2[1];
      param_3[2] = puVar2[2];
      uVar1 = puVar2[3];
      param_3[3] = uVar1;
      return CONCAT31((int3)((uint)uVar1 >> 8),1);
    }
  }
  return (uint)puVar2 & 0xffffff00;
}



/* FUNCTION 19053 ; VA 0x009d29b0 ; FUN_009d29b0 */

uint __thiscall FUN_009d29b0(int param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  param_2 = param_2 + *(int *)(param_1 + 0xd4);
  puVar4 = (undefined4 *)FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if (param_2 <= (int)puVar4) {
    puVar4 = (undefined4 *)FUN_01257810(*(undefined4 *)(param_1 + 0xd8),param_2,DAT_01ede6f0);
    if (puVar4 != (undefined4 *)0x0) {
      uVar1 = puVar4[1];
      uVar2 = puVar4[2];
      uVar3 = puVar4[3];
      *param_3 = *puVar4;
      param_3[1] = uVar1;
      param_3[2] = uVar2;
      param_3[3] = uVar3;
      uVar1 = puVar4[5];
      uVar2 = puVar4[6];
      uVar3 = puVar4[7];
      param_3[4] = puVar4[4];
      param_3[5] = uVar1;
      param_3[6] = uVar2;
      param_3[7] = uVar3;
      uVar1 = puVar4[9];
      uVar2 = puVar4[10];
      uVar3 = puVar4[0xb];
      param_3[8] = puVar4[8];
      param_3[9] = uVar1;
      param_3[10] = uVar2;
      param_3[0xb] = uVar3;
      *(undefined8 *)(param_3 + 0xc) = *(undefined8 *)(puVar4 + 0xc);
      uVar1 = puVar4[0xe];
      param_3[0xe] = uVar1;
      return CONCAT31((int3)((uint)uVar1 >> 8),1);
    }
  }
  return (uint)puVar4 & 0xffffff00;
}



/* FUNCTION 19054 ; VA 0x009d2a30 ; FUN_009d2a30 */

uint __thiscall FUN_009d2a30(int param_1,int param_2,undefined8 *param_3)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  
  param_2 = param_2 + *(int *)(param_1 + 0xd4);
  puVar2 = (undefined8 *)FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if (param_2 <= (int)puVar2) {
    puVar2 = (undefined8 *)FUN_01257810(*(undefined4 *)(param_1 + 0xd8),param_2,DAT_01ede6f8);
    if (puVar2 != (undefined8 *)0x0) {
      *param_3 = *puVar2;
      uVar1 = *(undefined4 *)(puVar2 + 1);
      *(undefined4 *)(param_3 + 1) = uVar1;
      return CONCAT31((int3)((uint)uVar1 >> 8),1);
    }
  }
  return (uint)puVar2 & 0xffffff00;
}



/* FUNCTION 19055 ; VA 0x009d2a90 ; FUN_009d2a90 */

undefined4 __thiscall FUN_009d2a90(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar3 = param_2 + *(int *)(param_1 + 0xd4);
  iVar1 = FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if (iVar3 <= iVar1) {
    iVar1 = FUN_012578b0(*(undefined4 *)(param_1 + 0xd8),iVar3);
    if (iVar1 == 5) {
      uVar2 = FUN_01257440(*(undefined4 *)(param_1 + 0xd8),iVar3,&param_2);
      FUN_005542c0(uVar2,param_2);
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 19056 ; VA 0x009d2b00 ; FUN_009d2b00 */

uint FUN_009d2b00(undefined4 param_1,int param_2,undefined4 *param_3,int *param_4)

{
  uint *puVar1;
  uint *puVar2;
  int *piVar3;
  char cVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  uint *puVar8;
  uint uVar9;
  undefined4 uVar10;
  char *pcVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  char *pcVar15;
  undefined4 in_stack_fffffdc0;
  uint3 uVar16;
  int iStack_220;
  int iStack_21c;
  undefined auStack_218 [200];
  undefined4 uStack_150;
  uint uStack_14c;
  undefined auStack_148 [200];
  uint *puStack_80;
  uint *puStack_7c;
  uint auStack_78 [5];
  uint uStack_64;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  undefined uStack_45;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  int iStack_2c;
  int iStack_28;
  uint *puStack_24;
  uint *puStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d60d8;
  pvStack_10 = ExceptionList;
  iStack_28 = 0;
  ExceptionList = &pvStack_10;
  if ((param_4 != (int *)0x0) &&
     (ExceptionList = &pvStack_10, iStack_28 = FUN_01257580(param_1,param_2), iStack_28 != 0)) {
    if ((uint)((param_4[1] - *param_4 >> 3) * 3) >> 2 <= (uint)param_4[3]) {
      FUN_00958880();
    }
    iVar7 = FUN_00620bc0(&iStack_28);
    if (*(char *)(iVar7 + 4) != '\0') {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("tables cannot be cyclic");
    }
    *(undefined *)(iVar7 + 4) = 1;
  }
  puStack_18 = (uint *)FUN_012566d0(param_1,param_2);
  iVar7 = FUN_01255e10(param_1,3);
  if (iVar7 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to make room on stack to bridge value");
  }
  if (0 < (int)puStack_18) {
    puVar8 = (uint *)FUN_01674e20(0x18);
    uStack_8 = 0;
    if (puVar8 == (uint *)0x0) {
      puVar8 = (uint *)0x0;
    }
    else {
      puVar8[1] = 1;
      puVar8[2] = 1;
      *puVar8 = (uint)std::
                      _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                      ::vftable;
      puStack_20 = puVar8;
      FUN_00569550(puStack_18,&uStack_45);
    }
    puStack_80 = puVar8 + 3;
    uStack_8 = 1;
    iStack_2c = 1;
    puStack_7c = puVar8;
    if (0 < (int)puStack_18) {
      puStack_14 = (uint *)0xd0;
      do {
        puStack_20 = (uint *)((int)puStack_14 + (puVar8[3] - 0xd0));
        FUN_01256cb0(param_1,param_2,iStack_2c);
        iVar7 = FUN_01256300(param_1);
        if (300 < iVar7) goto LAB_009d346b;
        FUN_009d23a0(param_1,0xffffffff,puStack_20,0,param_4);
        FUN_01257280(param_1,0xfffffffe);
        iStack_2c = iStack_2c + 1;
        puStack_14 = puStack_14 + 0x34;
      } while (iStack_2c <= (int)puStack_18);
    }
    puStack_24 = puVar8 + 3;
    if (puVar8 != (uint *)0x0) {
      LOCK();
      puVar8[1] = puVar8[1] + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    puStack_20 = puVar8;
    FUN_005c1810(&puStack_24);
    puVar2 = puStack_20;
    if (puStack_20 != (uint *)0x0) {
      LOCK();
      uVar9 = puStack_20[1] - 1;
      puStack_20[1] = uVar9;
      UNLOCK();
      if (uVar9 == 0) {
        (**(code **)*puStack_20)();
        LOCK();
        puVar1 = puVar2 + 2;
        uVar9 = *puVar1 - 1;
        *puVar1 = uVar9;
        UNLOCK();
        if (uVar9 == 0) {
          (**(code **)(*puVar2 + 4))();
        }
      }
    }
    uVar9 = 0xffffffff;
    uStack_8 = 0xffffffff;
    if (puVar8 != (uint *)0x0) {
      LOCK();
      puVar2 = puVar8 + 1;
      uVar13 = *puVar2;
      uVar9 = *puVar2;
      *puVar2 = uVar13 - 1;
      UNLOCK();
      if (uVar13 - 1 == 0) {
        (**(code **)*puVar8)();
        LOCK();
        puVar2 = puVar8 + 2;
        uVar9 = *puVar2;
        *puVar2 = *puVar2 - 1;
        UNLOCK();
        uVar9 = uVar9 - 1;
        if (uVar9 == 0) {
          uVar9 = (**(code **)(*puVar8 + 4))();
        }
      }
    }
    goto LAB_009d3411;
  }
  puStack_1c = (uint *)0x0;
  puStack_18 = (uint *)0x0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  if (param_2 < 1) {
    iVar7 = FUN_01256300(param_1);
    param_2 = param_2 + 1 + iVar7;
  }
  FUN_01256980(param_1);
  iVar7 = FUN_01256670(param_1,param_2);
  if (iVar7 == 0) {
LAB_009d33a1:
    puStack_20 = (uint *)FUN_01674e20(0x18);
    if (puStack_20 == (uint *)0x0) {
      puStack_20 = (uint *)0x0;
    }
    else {
      puStack_20[1] = 1;
      puStack_20[2] = 1;
      *puStack_20 = (uint)std::
                          _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>
                          ::vftable;
      puStack_20[3] = 0;
      puStack_20[4] = 0;
      puStack_20[5] = 0;
    }
    puStack_24 = puStack_20 + 3;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    FUN_005c1810(&puStack_24);
    FUN_00550b30();
  }
  else {
    do {
      uStack_34 = 0;
      uStack_30 = 0xf;
      uStack_44 = uStack_44 & 0xffffff00;
      uStack_8._0_1_ = 4;
      uVar10 = FUN_012578b0(param_1,0xfffffffe);
      uVar16 = (uint3)((uint)in_stack_fffffdc0 >> 8);
      switch(uVar10) {
      case 3:
        FUN_00565520(2,1);
        uStack_8._0_1_ = 5;
        uVar10 = FUN_012573c0(param_1,0xfffffffe,0);
        FUN_005af260(uVar10);
        puStack_14 = (uint *)FUN_0058c400(auStack_60);
        if (&uStack_44 != puStack_14) {
          FUN_005507b0();
          uStack_44 = *puStack_14;
          uStack_40 = puStack_14[1];
          uStack_3c = puStack_14[2];
          uStack_38 = puStack_14[3];
          uStack_34 = puStack_14[4];
          uStack_30 = puStack_14[5];
          puStack_14[4] = 0;
          puStack_14[5] = 0xf;
          *(undefined *)puStack_14 = 0;
        }
        if (0xf < uStack_4c) {
          uVar13 = uStack_4c + 1;
          uVar9 = auStack_60[0];
          if (0xfff < uVar13) {
            uVar9 = *(uint *)(auStack_60[0] - 4);
            uVar13 = uStack_4c + 0x24;
            if (0x1f < (auStack_60[0] - uVar9) - 4) goto LAB_009d34bf;
          }
          FUN_01674ea0(uVar9,uVar13);
        }
        uStack_8._0_1_ = 4;
        FUN_00570540();
        break;
      case 4:
        iVar7 = (uint)uVar16 << 8;
        FUN_005542c0("Vector3",7);
        puStack_14 = (uint *)FUN_009d1f40(auStack_60,param_1,iVar7);
        if (&uStack_44 != puStack_14) {
          FUN_005507b0();
          uStack_44 = *puStack_14;
          uStack_40 = puStack_14[1];
          uStack_3c = puStack_14[2];
          uStack_38 = puStack_14[3];
          uStack_34 = puStack_14[4];
          uStack_30 = puStack_14[5];
          puStack_14[4] = 0;
          puStack_14[5] = 0xf;
          *(undefined *)puStack_14 = 0;
        }
        uVar9 = auStack_60[0];
        uVar13 = uStack_4c;
        if (uStack_4c < 0x10) break;
        goto LAB_009d308d;
      case 5:
        uVar10 = FUN_01257440(param_1,0xfffffffe,&puStack_20);
        FUN_005542c0(uVar10,puStack_20);
        break;
      case 6:
        uVar10 = 5;
        pcVar15 = "Table";
        goto LAB_009d302b;
      case 7:
        uVar10 = 8;
        pcVar15 = "Function";
LAB_009d302b:
        iVar7 = (uint)uVar16 << 8;
        FUN_005542c0(pcVar15,uVar10);
        puStack_14 = (uint *)FUN_009d1f40(auStack_78,param_1,iVar7);
        if (&uStack_44 != puStack_14) {
          FUN_005507b0();
          uStack_44 = *puStack_14;
          uStack_40 = puStack_14[1];
          uStack_3c = puStack_14[2];
          uStack_38 = puStack_14[3];
          uStack_34 = puStack_14[4];
          uStack_30 = puStack_14[5];
          puStack_14[4] = 0;
          puStack_14[5] = 0xf;
          *(undefined *)puStack_14 = 0;
        }
        uVar9 = auStack_78[0];
        uVar13 = uStack_64;
        if (0xf < uStack_64) {
LAB_009d308d:
          uVar14 = uVar13 + 1;
          uVar12 = uVar9;
          if (0xfff < uVar14) {
            uVar12 = *(uint *)(uVar9 - 4);
            uVar14 = uVar13 + 0x24;
            if (0x1f < (uVar9 - uVar12) - 4) goto LAB_009d34bf;
          }
          FUN_01674ea0(uVar12,uVar14);
        }
        break;
      case 8:
        iStack_220 = FUN_00888530();
        iStack_21c = 0;
        uStack_8._0_1_ = 6;
        FUN_009d34f0(param_1,0xfffffffe,&iStack_220);
        pcVar15 = *(char **)(iStack_220 + 0x18);
        if (0xf < *(uint *)(pcVar15 + 0x14)) {
          pcVar15 = *(char **)pcVar15;
        }
        uStack_50 = 0;
        uStack_4c = 0xf;
        auStack_60[0] = auStack_60[0] & 0xffffff00;
        puStack_14 = (uint *)(pcVar15 + 1);
        pcVar11 = pcVar15;
        do {
          cVar4 = *pcVar11;
          pcVar11 = pcVar11 + 1;
        } while (cVar4 != '\0');
        FUN_005542c0(pcVar15,(int)pcVar11 - (int)puStack_14);
        uStack_8._0_1_ = 7;
        FUN_0054ef60(auStack_60);
        puStack_14 = (uint *)FUN_009d1f40(auStack_78,param_1);
        if (&uStack_44 != puStack_14) {
          FUN_005507b0();
          uStack_44 = *puStack_14;
          uStack_40 = puStack_14[1];
          uStack_3c = puStack_14[2];
          uStack_38 = puStack_14[3];
          uStack_34 = puStack_14[4];
          uStack_30 = puStack_14[5];
          puStack_14[4] = 0;
          puStack_14[5] = 0xf;
          *(undefined *)puStack_14 = 0;
        }
        if (0xf < uStack_64) {
          uVar13 = uStack_64 + 1;
          uVar9 = auStack_78[0];
          if (0xfff < uVar13) {
            uVar9 = *(uint *)(auStack_78[0] - 4);
            uVar13 = uStack_64 + 0x24;
            if (0x1f < (auStack_78[0] - uVar9) - 4) goto LAB_009d34bf;
          }
          FUN_01674ea0(uVar9,uVar13);
        }
        uStack_8._0_1_ = 6;
        if (0xf < uStack_4c) {
          uVar13 = uStack_4c + 1;
          uVar9 = auStack_60[0];
          if (0xfff < uVar13) {
            uVar9 = *(uint *)(auStack_60[0] - 4);
            uVar13 = uStack_4c + 0x24;
            if (0x1f < (auStack_60[0] - uVar9) - 4) goto LAB_009d34bf;
          }
          FUN_01674ea0(uVar9,uVar13);
        }
        uStack_8._0_1_ = 8;
        if (iStack_21c != 0) {
          (**(code **)(iStack_21c + 8))(auStack_218);
        }
        uStack_8._0_1_ = 4;
        break;
      default:
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Invalid table key type used");
      }
      uStack_150 = FUN_00888530();
      uStack_14c = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      iVar7 = FUN_01256300(param_1);
      if (300 < iVar7) {
LAB_009d346b:
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Max lua stack size reached");
      }
      in_stack_fffffdc0 = 0x9d30f5;
      FUN_009d23a0(param_1,0xffffffff,&uStack_150,0,param_4);
      puVar8 = puStack_18;
      if (puStack_1c == (uint *)0x0) {
        puVar8 = (uint *)FUN_01674e20(0x24);
        puStack_14 = puVar8;
        if (puVar8 == (uint *)0x0) {
          puVar8 = (uint *)0x0;
        }
        else {
          puVar8[1] = 1;
          puVar8[2] = 1;
          *puVar8 = (uint)std::
                          _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                          ::vftable;
          *(undefined *)(puVar8 + 3) = 0;
          uVar9 = FUN_00588320(0xb);
          puVar8[4] = uVar9;
          puVar8[5] = 0;
          puVar8[6] = 0x3f800000;
          puVar8[7] = 0;
          puVar8[8] = 0;
        }
        puVar2 = puStack_18;
        puStack_1c = puVar8 + 3;
        if (puStack_18 != (uint *)0x0) {
          LOCK();
          uVar9 = puStack_18[1] - 1;
          puStack_18[1] = uVar9;
          UNLOCK();
          if (uVar9 == 0) {
            puVar5 = (undefined4 *)*puStack_18;
            puStack_18 = puVar8;
            (*(code *)*puVar5)();
            LOCK();
            puVar8 = puVar2 + 2;
            uVar9 = *puVar8 - 1;
            *puVar8 = uVar9;
            UNLOCK();
            puVar8 = puStack_18;
            if (uVar9 == 0) {
              (**(code **)(*puVar2 + 4))();
              puVar8 = puStack_18;
            }
          }
        }
      }
      puStack_18 = puVar8;
      iVar7 = FUN_005c4c00(&uStack_44);
      *(undefined4 *)(iVar7 + 0x18) = uStack_150;
      puStack_14 = (uint *)(iVar7 + 0x1c);
      if (&uStack_14c != puStack_14) {
        iVar7 = iVar7 + 0x20;
        if (*puStack_14 != 0) {
          iStack_2c = iVar7;
          (**(code **)(*puStack_14 + 8))(iVar7);
          *puStack_14 = 0;
          iVar7 = iStack_2c;
        }
        if (uStack_14c != 0) {
          (**(code **)(uStack_14c + 4))(auStack_148,iVar7);
          *puStack_14 = uStack_14c;
          if (uStack_14c != 0) {
            (**(code **)(uStack_14c + 8))(auStack_148);
            uStack_14c = 0;
          }
        }
      }
      uStack_150 = FUN_00888530();
      if (uStack_14c != 0) {
        (**(code **)(uStack_14c + 8))(auStack_148);
        uStack_14c = 0;
      }
      FUN_01257280(param_1,0xfffffffe);
      uStack_8._0_1_ = 10;
      if (uStack_14c != 0) {
        (**(code **)(uStack_14c + 8))(auStack_148);
      }
      uStack_8._0_1_ = 3;
      if (0xf < uStack_30) {
        uVar13 = uStack_30 + 1;
        uVar9 = uStack_44;
        if (0xfff < uVar13) {
          uVar9 = *(uint *)(uStack_44 - 4);
          uVar13 = uStack_30 + 0x24;
          if (0x1f < (uStack_44 - uVar9) - 4) {
LAB_009d34bf:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar13);
      }
      iVar7 = FUN_01256670(param_1,param_2);
      puVar8 = puStack_18;
    } while (iVar7 != 0);
    if (puStack_1c == (uint *)0x0) goto LAB_009d33a1;
    if (puStack_18 != (uint *)0x0) {
      LOCK();
      puStack_18[1] = puStack_18[1] + 1;
      UNLOCK();
    }
    puStack_24 = puStack_1c;
    puStack_20 = puStack_18;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    uVar10 = FUN_008881d0();
    iVar7 = _tls_index;
    *param_3 = uVar10;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar7 * 4) + 0x34) < DAT_01ea8a9c) &&
       (FUN_016f3809(&DAT_01ea8a9c), DAT_01ea8a9c == -1)) {
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8a9c);
    }
    puVar5 = (undefined4 *)param_3[1];
    if ((code **)puVar5 == &DAT_01ea8a90) {
      param_3[2] = puStack_1c;
      piVar6 = (int *)param_3[3];
      puStack_24 = (uint *)0x0;
      puStack_20 = (uint *)0x0;
      param_3[3] = puStack_18;
      if (piVar6 == (int *)0x0) goto LAB_009d3397;
      LOCK();
      iVar7 = piVar6[1] + -1;
      piVar6[1] = iVar7;
      UNLOCK();
      if (iVar7 != 0) goto LAB_009d3397;
      (**(code **)*piVar6)();
      LOCK();
      piVar3 = piVar6 + 2;
      iVar7 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar7 != 1) goto LAB_009d3397;
      (**(code **)(*piVar6 + 4))();
      FUN_00550b30();
    }
    else {
      if (puVar5 != (undefined4 *)0x0) {
        (*(code *)puVar5[2])(param_3 + 2);
      }
      param_3[2] = puStack_1c;
      param_3[3] = puVar8;
      puStack_24 = (uint *)0x0;
      puStack_20 = (uint *)0x0;
      param_3[1] = &DAT_01ea8a90;
LAB_009d3397:
      FUN_00550b30();
    }
  }
  uStack_8 = 0xffffffff;
  uVar9 = FUN_00550b30();
LAB_009d3411:
  if ((param_4 != (int *)0x0) && (iStack_28 != 0)) {
    if ((uint)((param_4[1] - *param_4 >> 3) * 3) >> 2 <= (uint)param_4[3]) {
      FUN_00958880();
    }
    uVar9 = FUN_00620bc0(&iStack_28);
    *(undefined *)(uVar9 + 4) = 0;
  }
  ExceptionList = pvStack_10;
  return uVar9;
}



/* FUNCTION 19057 ; VA 0x009d34f0 ; FUN_009d34f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_009d34f0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined *puVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvVar7;
  char cVar8;
  undefined4 uVar9;
  int iVar10;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined auStack_38 [12];
  undefined auStack_2c [4];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined uStack_1d;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6113;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar8 = FUN_00d87c40(param_1,param_2,param_3);
  if (cVar8 == '\0') {
    iStack_1c = 0;
    piStack_18 = (int *)0x0;
    iStack_8 = 0;
    cVar8 = FUN_00da4680(param_1,param_2,&iStack_1c);
    if (cVar8 == '\0') {
      piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6d4);
      if (piStack_14 == (undefined4 *)0x0) {
        piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6f0);
        if (piStack_14 != (undefined4 *)0x0) {
          uVar9 = FUN_00a73110();
          pvVar7 = ThreadLocalStoragePointer;
          iVar10 = _tls_index;
          *param_3 = uVar9;
          if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead328) {
            FUN_016f3809(&DAT_01ead328);
            if (DAT_01ead328 == -1) {
              _DAT_01ead31c = FUN_00619fd0;
              _DAT_01ead320 = FUN_00619fd0;
              DAT_01ead324 = _guard_check_icall;
              FUN_016f37bf(&DAT_01ead328);
            }
          }
          puVar3 = (undefined *)param_3[1];
          if (puVar3 == &DAT_01ead31c) {
            uVar9 = piStack_14[1];
            uVar5 = piStack_14[2];
            uVar6 = piStack_14[3];
            param_3[2] = *piStack_14;
            param_3[3] = uVar9;
            param_3[4] = uVar5;
            param_3[5] = uVar6;
            uVar9 = piStack_14[5];
            uVar5 = piStack_14[6];
            uVar6 = piStack_14[7];
            param_3[6] = piStack_14[4];
            param_3[7] = uVar9;
            param_3[8] = uVar5;
            param_3[9] = uVar6;
            uVar9 = piStack_14[9];
            uVar5 = piStack_14[10];
            uVar6 = piStack_14[0xb];
            param_3[10] = piStack_14[8];
            param_3[0xb] = uVar9;
            param_3[0xc] = uVar5;
            param_3[0xd] = uVar6;
            *(undefined8 *)(param_3 + 0xe) = *(undefined8 *)(piStack_14 + 0xc);
            param_3[0x10] = piStack_14[0xe];
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          if (puVar3 != (undefined *)0x0) {
            (**(code **)(puVar3 + 8))(param_3 + 2);
            param_3[1] = 0;
          }
          uVar9 = piStack_14[1];
          uVar5 = piStack_14[2];
          uVar6 = piStack_14[3];
          param_3[2] = *piStack_14;
          param_3[3] = uVar9;
          param_3[4] = uVar5;
          param_3[5] = uVar6;
          uVar9 = piStack_14[5];
          uVar5 = piStack_14[6];
          uVar6 = piStack_14[7];
          param_3[6] = piStack_14[4];
          param_3[7] = uVar9;
          param_3[8] = uVar5;
          param_3[9] = uVar6;
          uVar9 = piStack_14[9];
          uVar5 = piStack_14[10];
          uVar6 = piStack_14[0xb];
          param_3[10] = piStack_14[8];
          param_3[0xb] = uVar9;
          param_3[0xc] = uVar5;
          param_3[0xd] = uVar6;
          *(undefined8 *)(param_3 + 0xe) = *(undefined8 *)(piStack_14 + 0xc);
          param_3[0x10] = piStack_14[0xe];
          param_3[1] = &DAT_01ead31c;
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return 1;
        }
        piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6f8);
        if (piStack_14 != (int *)0x0) {
          uVar9 = FUN_00b33940();
          pvVar7 = ThreadLocalStoragePointer;
          iVar10 = _tls_index;
          *param_3 = uVar9;
          if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead318) {
            FUN_016f3809(&DAT_01ead318);
            if (DAT_01ead318 == -1) {
              _DAT_01ead30c = FUN_005c6600;
              _DAT_01ead310 = FUN_005c6600;
              _DAT_01ead314 = _guard_check_icall;
              FUN_016f37bf(&DAT_01ead318);
            }
          }
          puVar3 = (undefined *)param_3[1];
          if (puVar3 == &DAT_01ead30c) {
            *(undefined8 *)(param_3 + 2) = *(undefined8 *)piStack_14;
            param_3[4] = *(undefined4 *)((int)piStack_14 + 8);
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          if (puVar3 != (undefined *)0x0) {
            (**(code **)(puVar3 + 8))(param_3 + 2);
            param_3[1] = 0;
          }
          *(undefined8 *)(param_3 + 2) = *(undefined8 *)piStack_14;
          param_3[4] = *(undefined4 *)((int)piStack_14 + 8);
          param_3[1] = &DAT_01ead30c;
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return 1;
        }
        piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6bc);
        if (piStack_14 != (undefined4 *)0x0) {
          uVar9 = FUN_0088d910();
          pvVar7 = ThreadLocalStoragePointer;
          iVar10 = _tls_index;
          *param_3 = uVar9;
          if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead3e8) {
            FUN_016f3809(&DAT_01ead3e8);
            if (DAT_01ead3e8 == -1) {
              _DAT_01ead3dc = FUN_0061a030;
              _DAT_01ead3e0 = FUN_0061a030;
              DAT_01ead3e4 = _guard_check_icall;
              FUN_016f37bf(&DAT_01ead3e8);
            }
          }
          puVar3 = (undefined *)param_3[1];
          if (puVar3 == &DAT_01ead3dc) {
            param_3[2] = *piStack_14;
            *(undefined2 *)(param_3 + 3) = *(undefined2 *)(piStack_14 + 1);
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          if (puVar3 != (undefined *)0x0) {
            (**(code **)(puVar3 + 8))(param_3 + 2);
            param_3[1] = 0;
          }
          param_3[2] = *piStack_14;
          *(undefined2 *)(param_3 + 3) = *(undefined2 *)(piStack_14 + 1);
          param_3[1] = &DAT_01ead3dc;
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return 1;
        }
        piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6c0);
        if (piStack_14 != (undefined4 *)0x0) {
          uVar9 = FUN_0088d7d0();
          pvVar7 = ThreadLocalStoragePointer;
          iVar10 = _tls_index;
          *param_3 = uVar9;
          if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead3f8) {
            FUN_016f3809(&DAT_01ead3f8);
            if (DAT_01ead3f8 == -1) {
              _DAT_01ead3ec = FUN_005c65e0;
              _DAT_01ead3f0 = FUN_005c65e0;
              _DAT_01ead3f4 = _guard_check_icall;
              FUN_016f37bf(&DAT_01ead3f8);
            }
          }
          puVar3 = (undefined *)param_3[1];
          if (puVar3 == &DAT_01ead3ec) {
            param_3[2] = *piStack_14;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          if (puVar3 != (undefined *)0x0) {
            (**(code **)(puVar3 + 8))(param_3 + 2);
            param_3[1] = 0;
          }
          param_3[2] = *piStack_14;
          param_3[1] = &DAT_01ead3ec;
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return 1;
        }
        cVar8 = FUN_00d91fb0(param_1,param_2,param_3);
        if (cVar8 == '\0') {
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6c8);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_0088d410();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead348) {
              FUN_016f3809(&DAT_01ead348);
              if (DAT_01ead348 == -1) {
                _DAT_01ead33c = FUN_00619fb0;
                _DAT_01ead340 = FUN_00619fb0;
                _DAT_01ead344 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead348);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead33c) {
              param_3[2] = *piStack_14;
              param_3[3] = piStack_14[1];
              param_3[4] = piStack_14[2];
              param_3[5] = piStack_14[3];
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            uVar9 = piStack_14[1];
            uVar5 = piStack_14[2];
            uVar6 = piStack_14[3];
            param_3[2] = *piStack_14;
            param_3[3] = uVar9;
            param_3[4] = uVar5;
            param_3[5] = uVar6;
            param_3[1] = &DAT_01ead33c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6c4);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_0088d730();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead418) {
              FUN_016f3809(&DAT_01ead418);
              if (DAT_01ead418 == -1) {
                DAT_01ead40c = FUN_005c6620;
                _DAT_01ead410 = FUN_005c6620;
                DAT_01ead414 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead418);
              }
            }
            puVar2 = (undefined4 *)param_3[1];
            if ((code **)puVar2 == &DAT_01ead40c) {
              param_3[2] = *piStack_14;
              param_3[3] = piStack_14[1];
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar2 != (undefined4 *)0x0) {
              (*(code *)puVar2[2])(param_3 + 2);
              param_3[1] = 0;
            }
            param_3[2] = *piStack_14;
            param_3[3] = piStack_14[1];
            param_3[1] = &DAT_01ead40c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6b8);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_0088d370();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead458) {
              FUN_016f3809(&DAT_01ead458);
              if (DAT_01ead458 == -1) {
                _DAT_01ead44c = FUN_00619f80;
                _DAT_01ead450 = FUN_00619f80;
                DAT_01ead454 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead458);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead44c) {
              uVar9 = piStack_14[1];
              uVar5 = piStack_14[2];
              uVar6 = piStack_14[3];
              param_3[2] = *piStack_14;
              param_3[3] = uVar9;
              param_3[4] = uVar5;
              param_3[5] = uVar6;
              *(undefined8 *)(param_3 + 6) = *(undefined8 *)(piStack_14 + 4);
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            uVar9 = piStack_14[1];
            uVar5 = piStack_14[2];
            uVar6 = piStack_14[3];
            param_3[2] = *piStack_14;
            param_3[3] = uVar9;
            param_3[4] = uVar5;
            param_3[5] = uVar6;
            *(undefined8 *)(param_3 + 6) = *(undefined8 *)(piStack_14 + 4);
            param_3[1] = &DAT_01ead44c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ea8be8);
          if (piStack_14 != (int *)0x0) {
            uVar9 = FUN_0088d050();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ea8c08) {
              FUN_016f3809(&DAT_01ea8c08);
              if (DAT_01ea8c08 == -1) {
                _DAT_01ea8bfc = FUN_005c6600;
                _DAT_01ea8c00 = FUN_005c6600;
                DAT_01ea8c04 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ea8c08);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ea8bfc) {
              param_3[2] = *piStack_14;
              param_3[3] = *(undefined4 *)((int)piStack_14 + 4);
              param_3[4] = *(undefined4 *)((int)piStack_14 + 8);
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            *(undefined8 *)(param_3 + 2) = *(undefined8 *)piStack_14;
            param_3[4] = *(undefined4 *)((int)piStack_14 + 8);
            param_3[1] = &DAT_01ea8bfc;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6d0);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_0088cfa0();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead2a8) {
              FUN_016f3809(&DAT_01ead2a8);
              if (DAT_01ead2a8 == -1) {
                _DAT_01ead29c = FUN_005c65e0;
                _DAT_01ead2a0 = FUN_005c65e0;
                _DAT_01ead2a4 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead2a8);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead29c) {
              param_3[2] = *piStack_14;
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            param_3[2] = *piStack_14;
            param_3[1] = &DAT_01ead29c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6e8);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_0088d690();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead478) {
              FUN_016f3809(&DAT_01ead478);
              if (DAT_01ead478 == -1) {
                _DAT_01ead46c = FUN_005c6620;
                _DAT_01ead470 = FUN_005c6620;
                _DAT_01ead474 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead478);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead46c) {
              param_3[2] = *piStack_14;
              param_3[3] = piStack_14[1];
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            param_3[2] = *piStack_14;
            param_3[3] = piStack_14[1];
            param_3[1] = &DAT_01ead46c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6ec);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_0088d5f0();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead468) {
              FUN_016f3809(&DAT_01ead468);
              if (DAT_01ead468 == -1) {
                _DAT_01ead45c = FUN_00619fb0;
                _DAT_01ead460 = FUN_00619fb0;
                DAT_01ead464 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead468);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead45c) {
              param_3[2] = *piStack_14;
              param_3[3] = piStack_14[1];
              param_3[4] = piStack_14[2];
              param_3[5] = piStack_14[3];
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            uVar9 = piStack_14[1];
            uVar5 = piStack_14[2];
            uVar6 = piStack_14[3];
            param_3[2] = *piStack_14;
            param_3[3] = uVar9;
            param_3[4] = uVar5;
            param_3[5] = uVar6;
            param_3[1] = &DAT_01ead45c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6d8);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_0088d230();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead448) {
              FUN_016f3809(&DAT_01ead448);
              if (DAT_01ead448 == -1) {
                _DAT_01ead43c = FUN_005c65e0;
                _DAT_01ead440 = FUN_005c65e0;
                _DAT_01ead444 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead448);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead43c) {
              param_3[2] = *piStack_14;
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            param_3[2] = *piStack_14;
            param_3[1] = &DAT_01ead43c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6dc);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_0088ce60();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead438) {
              FUN_016f3809(&DAT_01ead438);
              if (DAT_01ead438 == -1) {
                _DAT_01ead42c = FUN_005c65e0;
                _DAT_01ead430 = FUN_005c65e0;
                _DAT_01ead434 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead438);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead42c) {
              param_3[2] = *piStack_14;
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            param_3[2] = *piStack_14;
            param_3[1] = &DAT_01ead42c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6e0);
          if (piStack_14 != (int *)0x0) {
            uVar9 = FUN_00d896b0();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ee4490) {
              FUN_016f3809(&DAT_01ee4490);
              if (DAT_01ee4490 == -1) {
                _DAT_01ee4484 = FUN_009d02d0;
                _DAT_01ee4488 = FUN_009d55e0;
                _DAT_01ee448c = FUN_0087f020;
                FUN_016f37bf(&DAT_01ee4490);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ee4484) {
              *(undefined *)(param_3 + 2) = *(undefined *)piStack_14;
              *(undefined8 *)(param_3 + 3) = *(undefined8 *)((int)piStack_14 + 4);
              param_3[5] = *(undefined4 *)((int)piStack_14 + 0xc);
              iVar10 = *(int *)((int)piStack_14 + 0x14);
              if (iVar10 != 0) {
                LOCK();
                *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + 1;
                UNLOCK();
                iVar10 = *(int *)((int)piStack_14 + 0x14);
              }
              param_3[6] = *(undefined4 *)((int)piStack_14 + 0x10);
              piVar4 = (int *)param_3[7];
              param_3[7] = iVar10;
              if (piVar4 != (int *)0x0) {
                LOCK();
                iVar10 = piVar4[1] + -1;
                piVar4[1] = iVar10;
                UNLOCK();
                if (iVar10 == 0) {
                  (**(code **)*piVar4)();
                  LOCK();
                  piVar1 = piVar4 + 2;
                  iVar10 = *piVar1;
                  *piVar1 = *piVar1 + -1;
                  UNLOCK();
                  if (iVar10 == 1) {
                    (**(code **)(*piVar4 + 4))();
                    FUN_00550b30();
                    ExceptionList = pvStack_10;
                    return 1;
                  }
                }
              }
            }
            else {
              if (puVar3 != (undefined *)0x0) {
                (**(code **)(puVar3 + 8))(param_3 + 2);
                param_3[1] = 0;
              }
              *(undefined *)(param_3 + 2) = *(undefined *)piStack_14;
              *(undefined8 *)(param_3 + 3) = *(undefined8 *)((int)piStack_14 + 4);
              param_3[5] = *(undefined4 *)((int)piStack_14 + 0xc);
              param_3[6] = 0;
              param_3[7] = 0;
              if (*(int *)((int)piStack_14 + 0x14) != 0) {
                LOCK();
                piVar4 = (int *)(*(int *)((int)piStack_14 + 0x14) + 4);
                *piVar4 = *piVar4 + 1;
                UNLOCK();
              }
              param_3[6] = *(undefined4 *)((int)piStack_14 + 0x10);
              param_3[7] = *(undefined4 *)((int)piStack_14 + 0x14);
              param_3[1] = &DAT_01ee4484;
            }
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piVar4 = (undefined4 *)0x0;
          if (DAT_01d6d350 != '\0') {
            piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6e4);
            piVar4 = piStack_14;
            if (piStack_14 != (undefined4 *)0x0) {
              uVar9 = FUN_00b38680();
              pvVar7 = ThreadLocalStoragePointer;
              iVar10 = _tls_index;
              *param_3 = uVar9;
              if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead2f8) {
                FUN_016f3809(&DAT_01ead2f8);
                if (DAT_01ead2f8 == -1) {
                  _DAT_01ead2ec = FUN_00619f20;
                  _DAT_01ead2f0 = FUN_00619f20;
                  _DAT_01ead2f4 = _guard_check_icall;
                  FUN_016f37bf(&DAT_01ead2f8);
                }
              }
              puVar3 = (undefined *)param_3[1];
              if (puVar3 == &DAT_01ead2ec) {
                param_3[2] = *piStack_14;
                param_3[3] = piStack_14[1];
                param_3[4] = piStack_14[2];
                param_3[5] = piStack_14[3];
                FUN_00550b30();
                ExceptionList = pvStack_10;
                return 1;
              }
              if (puVar3 != (undefined *)0x0) {
                (**(code **)(puVar3 + 8))(param_3 + 2);
                param_3[1] = 0;
              }
              param_3[2] = *piStack_14;
              param_3[3] = piStack_14[1];
              param_3[4] = piStack_14[2];
              param_3[5] = piStack_14[3];
              param_3[1] = &DAT_01ead2ec;
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
          }
          piStack_14 = piVar4;
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6cc);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_0088d2d0();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead338) {
              FUN_016f3809(&DAT_01ead338);
              if (DAT_01ead338 == -1) {
                _DAT_01ead32c = FUN_00619f80;
                _DAT_01ead330 = FUN_00619f80;
                _DAT_01ead334 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead338);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead32c) {
              uVar9 = piStack_14[1];
              uVar5 = piStack_14[2];
              uVar6 = piStack_14[3];
              param_3[2] = *piStack_14;
              param_3[3] = uVar9;
              param_3[4] = uVar5;
              param_3[5] = uVar6;
              *(undefined8 *)(param_3 + 6) = *(undefined8 *)(piStack_14 + 4);
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            uVar9 = piStack_14[1];
            uVar5 = piStack_14[2];
            uVar6 = piStack_14[3];
            param_3[2] = *piStack_14;
            param_3[3] = uVar9;
            param_3[4] = uVar5;
            param_3[5] = uVar6;
            *(undefined8 *)(param_3 + 6) = *(undefined8 *)(piStack_14 + 4);
            param_3[1] = &DAT_01ead32c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede704);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_00a92ae0();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead398) {
              FUN_016f3809(&DAT_01ead398);
              if (DAT_01ead398 == -1) {
                _DAT_01ead38c = FUN_00619f50;
                _DAT_01ead390 = FUN_00619f50;
                _DAT_01ead394 = FUN_0061bd20;
                FUN_016f37bf(&DAT_01ead398);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead38c) {
              if (param_3 + 2 != piStack_14) {
                FUN_00602a00(*piStack_14,piStack_14[1],piStack_14);
                FUN_00550b30();
                ExceptionList = pvStack_10;
                return 1;
              }
            }
            else {
              if (puVar3 != (undefined *)0x0) {
                (**(code **)(puVar3 + 8))(param_3 + 2);
                param_3[1] = 0;
              }
              FUN_00a92cb0(piStack_14,0xe4078678,0x64078678);
              param_3[1] = &DAT_01ead38c;
            }
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede708);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_00a8dcc0();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead378) {
              FUN_016f3809(&DAT_01ead378);
              if (DAT_01ead378 == -1) {
                _DAT_01ead36c = FUN_00619ec0;
                _DAT_01ead370 = FUN_00619ec0;
                _DAT_01ead374 = FUN_0061bd10;
                FUN_016f37bf(&DAT_01ead378);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead36c) {
              if (param_3 + 2 != piStack_14) {
                FUN_00602830(*piStack_14,piStack_14[1],piStack_14);
                FUN_00550b30();
                ExceptionList = pvStack_10;
                return 1;
              }
            }
            else {
              if (puVar3 != (undefined *)0x0) {
                (**(code **)(puVar3 + 8))(param_3 + 2);
                param_3[1] = 0;
              }
              FUN_00a8df50(piStack_14);
              param_3[1] = &DAT_01ead36c;
            }
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede70c);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_00b33310();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead388) {
              FUN_016f3809(&DAT_01ead388);
              if (DAT_01ead388 == -1) {
                _DAT_01ead37c = FUN_005c6620;
                _DAT_01ead380 = FUN_005c6620;
                _DAT_01ead384 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead388);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead37c) {
              param_3[2] = *piStack_14;
              param_3[3] = piStack_14[1];
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            param_3[2] = *piStack_14;
            param_3[3] = piStack_14[1];
            param_3[1] = &DAT_01ead37c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede6fc);
          if (piStack_14 != (int *)0x0) {
            uVar9 = FUN_00a92b80();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead368) {
              FUN_016f3809(&DAT_01ead368);
              if (DAT_01ead368 == -1) {
                _DAT_01ead35c = FUN_005c6600;
                _DAT_01ead360 = FUN_005c6600;
                _DAT_01ead364 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead368);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead35c) {
              *(undefined8 *)(param_3 + 2) = *(undefined8 *)piStack_14;
              param_3[4] = *(undefined4 *)((int)piStack_14 + 8);
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            *(undefined8 *)(param_3 + 2) = *(undefined8 *)piStack_14;
            param_3[4] = *(undefined4 *)((int)piStack_14 + 8);
            param_3[1] = &DAT_01ead35c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede700);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_00a8dd60();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead358) {
              FUN_016f3809(&DAT_01ead358);
              if (DAT_01ead358 == -1) {
                _DAT_01ead34c = FUN_00619ed0;
                _DAT_01ead350 = FUN_00619ed0;
                _DAT_01ead354 = _guard_check_icall;
                FUN_016f37bf(&DAT_01ead358);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ead34c) {
              param_3[2] = *piStack_14;
              param_3[3] = piStack_14[1];
              param_3[4] = piStack_14[2];
              param_3[5] = piStack_14[3];
              param_3[6] = piStack_14[4];
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            uVar9 = piStack_14[1];
            uVar5 = piStack_14[2];
            uVar6 = piStack_14[3];
            param_3[2] = *piStack_14;
            param_3[3] = uVar9;
            param_3[4] = uVar5;
            param_3[5] = uVar6;
            param_3[6] = piStack_14[4];
            param_3[1] = &DAT_01ead34c;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede710);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_00da8f20();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ee4480) {
              FUN_016f3809(&DAT_01ee4480);
              if (DAT_01ee4480 == -1) {
                _DAT_01ee4474 = FUN_009d03f0;
                _DAT_01ee4478 = FUN_009d03f0;
                DAT_01ee447c = _guard_check_icall;
                FUN_016f37bf(&DAT_01ee4480);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ee4474) {
              uVar9 = piStack_14[1];
              uVar5 = piStack_14[2];
              uVar6 = piStack_14[3];
              param_3[2] = *piStack_14;
              param_3[3] = uVar9;
              param_3[4] = uVar5;
              param_3[5] = uVar6;
              *(undefined8 *)(param_3 + 6) = *(undefined8 *)(piStack_14 + 4);
              param_3[8] = piStack_14[6];
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            uVar9 = piStack_14[1];
            uVar5 = piStack_14[2];
            uVar6 = piStack_14[3];
            param_3[2] = *piStack_14;
            param_3[3] = uVar9;
            param_3[4] = uVar5;
            param_3[5] = uVar6;
            *(undefined8 *)(param_3 + 6) = *(undefined8 *)(piStack_14 + 4);
            param_3[8] = piStack_14[6];
            param_3[1] = &DAT_01ee4474;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede714);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_00da9bd0();
            pvVar7 = ThreadLocalStoragePointer;
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ee4470) {
              FUN_016f3809(&DAT_01ee4470);
              if (DAT_01ee4470 == -1) {
                _DAT_01ee4464 = FUN_00619f80;
                _DAT_01ee4468 = FUN_00619f80;
                DAT_01ee446c = _guard_check_icall;
                FUN_016f37bf(&DAT_01ee4470);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ee4464) {
              uVar9 = piStack_14[1];
              uVar5 = piStack_14[2];
              uVar6 = piStack_14[3];
              param_3[2] = *piStack_14;
              param_3[3] = uVar9;
              param_3[4] = uVar5;
              param_3[5] = uVar6;
              *(undefined8 *)(param_3 + 6) = *(undefined8 *)(piStack_14 + 4);
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return 1;
            }
            if (puVar3 != (undefined *)0x0) {
              (**(code **)(puVar3 + 8))(param_3 + 2);
              param_3[1] = 0;
            }
            uVar9 = piStack_14[1];
            uVar5 = piStack_14[2];
            uVar6 = piStack_14[3];
            param_3[2] = *piStack_14;
            param_3[3] = uVar9;
            param_3[4] = uVar5;
            param_3[5] = uVar6;
            *(undefined8 *)(param_3 + 6) = *(undefined8 *)(piStack_14 + 4);
            param_3[1] = &DAT_01ee4464;
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piStack_14 = (int *)FUN_01257810(param_1,param_2,DAT_01ede718);
          if (piStack_14 != (undefined4 *)0x0) {
            uVar9 = FUN_00da6440();
            iVar10 = _tls_index;
            *param_3 = uVar9;
            if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar10 * 4) + 0x34) <
                DAT_01ee4460) {
              FUN_016f3809(&DAT_01ee4460);
              if (DAT_01ee4460 == -1) {
                _DAT_01ee4454 = FUN_0057bbb0;
                _DAT_01ee4458 = FUN_005880a0;
                _DAT_01ee445c = FUN_0057d5e0;
                FUN_016f37bf(&DAT_01ee4460);
              }
            }
            puVar3 = (undefined *)param_3[1];
            if (puVar3 == &DAT_01ee4454) {
              iVar10 = piStack_14[1];
              if (iVar10 != 0) {
                LOCK();
                *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + 1;
                UNLOCK();
                iVar10 = piStack_14[1];
              }
              param_3[2] = *piStack_14;
              piVar4 = (int *)param_3[3];
              param_3[3] = iVar10;
              if (piVar4 != (int *)0x0) {
                LOCK();
                iVar10 = piVar4[1] + -1;
                piVar4[1] = iVar10;
                UNLOCK();
                if (iVar10 == 0) {
                  (**(code **)*piVar4)();
                  LOCK();
                  piVar1 = piVar4 + 2;
                  iVar10 = *piVar1;
                  *piVar1 = *piVar1 + -1;
                  UNLOCK();
                  if (iVar10 == 1) {
                    (**(code **)(*piVar4 + 4))();
                    FUN_00550b30();
                    ExceptionList = pvStack_10;
                    return 1;
                  }
                }
              }
            }
            else {
              if (puVar3 != (undefined *)0x0) {
                (**(code **)(puVar3 + 8))(param_3 + 2);
                param_3[1] = 0;
              }
              param_3[2] = 0;
              param_3[3] = 0;
              if (piStack_14[1] != 0) {
                LOCK();
                piVar4 = (int *)(piStack_14[1] + 4);
                *piVar4 = *piVar4 + 1;
                UNLOCK();
              }
              param_3[2] = *piStack_14;
              param_3[3] = piStack_14[1];
              param_3[1] = &DAT_01ee4454;
            }
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          cVar8 = FUN_009cddd0(param_1,param_2,param_3);
          if (cVar8 == '\0') {
            cVar8 = FUN_009cdcf0(param_1,param_2,param_3);
            if (cVar8 == '\0') {
              cVar8 = FUN_009cdb90(param_1,param_2,param_3);
              if (cVar8 == '\0') {
                cVar8 = FUN_009cdbd0(param_1,param_2,param_3);
                if (cVar8 == '\0') {
                  cVar8 = FUN_009cd9d0(param_1,param_2,param_3);
                  if (cVar8 == '\0') {
                    cVar8 = FUN_009cdeb0(param_1,param_2,param_3);
                    if (cVar8 == '\0') {
                      cVar8 = FUN_009cdab0(param_1,param_2,param_3);
                      if (cVar8 == '\0') {
                        if (DAT_01d653d4 != '\0') {
                          uStack_1d = FUN_01257910(param_1,param_2);
                          if (DAT_01d653dc != '\0') {
                            DAT_01d653dc = '\0';
                            FUN_0151f6f0(0xffffffff,0,0);
                            iStack_8._0_1_ = 1;
                            FUN_0151f9c0(&DAT_0193a4d4,uStack_1d);
                            uVar9 = DAT_01ee43ec;
                            uStack_28 = 0;
                            uStack_24 = 0xf;
                            auStack_38[0] = 0;
                            FUN_005542c0("UnsupportedVariant",0x12);
                            iStack_8._0_1_ = 2;
                            FUN_01520d20(auStack_38,uVar9,0);
                            FUN_005507b0();
                            iStack_8 = (uint)iStack_8._1_3_ << 8;
                            FUN_0151f7f0();
                          }
                        }
                        if (DAT_01d653cc == '\0') {
                          uStack_140 = FUN_00888530();
                          uStack_13c = 0;
                          iStack_8 = CONCAT31(iStack_8._1_3_,3);
                          FUN_00947a40(&uStack_140);
                          FUN_0056e5b0();
                          FUN_00550b30();
                          ExceptionList = pvStack_10;
                          return 0;
                        }
                        FUN_016756b0(auStack_2c,"Unsupported reflection type");
                    /* WARNING: Subroutine does not return */
                        FUN_0170c2a8(auStack_2c,&DAT_01c17198);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      else {
        uVar9 = FUN_00b00260();
        pvVar7 = ThreadLocalStoragePointer;
        iVar10 = _tls_index;
        *param_3 = uVar9;
        if (*(int *)(*(int *)((int)pvVar7 + iVar10 * 4) + 0x34) < DAT_01ead3d8) {
          FUN_016f3809(&DAT_01ead3d8);
          if (DAT_01ead3d8 == -1) {
            _DAT_01ead3cc = FUN_00619ef0;
            _DAT_01ead3d0 = FUN_00619ef0;
            DAT_01ead3d4 = _guard_check_icall;
            FUN_016f37bf(&DAT_01ead3d8);
          }
        }
        puVar3 = (undefined *)param_3[1];
        if (puVar3 == &DAT_01ead3cc) {
          uVar9 = piStack_14[1];
          uVar5 = piStack_14[2];
          uVar6 = piStack_14[3];
          param_3[2] = *piStack_14;
          param_3[3] = uVar9;
          param_3[4] = uVar5;
          param_3[5] = uVar6;
          uVar9 = piStack_14[5];
          uVar5 = piStack_14[6];
          uVar6 = piStack_14[7];
          param_3[6] = piStack_14[4];
          param_3[7] = uVar9;
          param_3[8] = uVar5;
          param_3[9] = uVar6;
          uVar9 = piStack_14[9];
          uVar5 = piStack_14[10];
          uVar6 = piStack_14[0xb];
          param_3[10] = piStack_14[8];
          param_3[0xb] = uVar9;
          param_3[0xc] = uVar5;
          param_3[0xd] = uVar6;
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return 1;
        }
        if (puVar3 != (undefined *)0x0) {
          (**(code **)(puVar3 + 8))(param_3 + 2);
          param_3[1] = 0;
        }
        uVar9 = piStack_14[1];
        uVar5 = piStack_14[2];
        uVar6 = piStack_14[3];
        param_3[2] = *piStack_14;
        param_3[3] = uVar9;
        param_3[4] = uVar5;
        param_3[5] = uVar6;
        uVar9 = piStack_14[5];
        uVar5 = piStack_14[6];
        uVar6 = piStack_14[7];
        param_3[6] = piStack_14[4];
        param_3[7] = uVar9;
        param_3[8] = uVar5;
        param_3[9] = uVar6;
        uVar9 = piStack_14[9];
        uVar5 = piStack_14[10];
        uVar6 = piStack_14[0xb];
        param_3[10] = piStack_14[8];
        param_3[0xb] = uVar9;
        param_3[0xc] = uVar5;
        param_3[0xd] = uVar6;
        param_3[1] = &DAT_01ead3cc;
      }
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return 1;
    }
    uVar9 = FUN_0088cdc0();
    iVar10 = _tls_index;
    *param_3 = uVar9;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar10 * 4) + 0x34) < DAT_01ead288) {
      FUN_016f3809(&DAT_01ead288);
      if (DAT_01ead288 == -1) {
        DAT_01ead27c = FUN_0057bbb0;
        _DAT_01ead280 = FUN_005880a0;
        DAT_01ead284 = FUN_0057d5e0;
        FUN_016f37bf(&DAT_01ead288);
      }
    }
    puVar2 = (undefined4 *)param_3[1];
    if ((code **)puVar2 == &DAT_01ead27c) {
      FUN_0056ecd0(&iStack_1c);
    }
    else {
      if (puVar2 != (undefined4 *)0x0) {
        (*(code *)puVar2[2])(param_3 + 2);
        param_3[1] = 0;
      }
      param_3[2] = 0;
      param_3[3] = 0;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      param_3[2] = iStack_1c;
      param_3[3] = piStack_18;
      param_3[1] = &DAT_01ead27c;
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar10 = piStack_18[1] + -1;
      piStack_18[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        piStack_14 = piStack_18;
        (**(code **)*piStack_18)();
        LOCK();
        piVar4 = piStack_14 + 2;
        iVar10 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar10 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 19058 ; VA 0x009d53a0 ; FUN_009d53a0 */

int * FUN_009d53a0(int *param_1,undefined4 param_2)

{
  int iVar1;
  code *pcVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6148;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8 = 1;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    FUN_00569550(iVar3,&uStack_11);
  }
  *param_1 = (int)(puVar4 + 3);
  param_1[1] = (int)puVar4;
  uVar6 = 0;
  uStack_8 = 0;
  if (0 < iVar3) {
    iVar7 = 0;
    do {
      iVar1 = *(int *)*param_1;
      if ((uint)((((int *)*param_1)[1] - iVar1) / 0xd0) <= uVar6) {
        FUN_00577c40();
        pcVar2 = (code *)swi(3);
        piVar5 = (int *)(*pcVar2)();
        return piVar5;
      }
      uVar6 = uVar6 + 1;
      FUN_009d1bf0(param_2,uVar6,iVar7 + iVar1,0);
      iVar7 = iVar7 + 0xd0;
    } while ((int)uVar6 < iVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19059 ; VA 0x009d54a0 ; FUN_009d54a0 */

void __thiscall FUN_009d54a0(int param_1,int param_2,undefined4 param_3)

{
  FUN_009d1bf0(*(undefined4 *)(param_1 + 0xd8),*(int *)(param_1 + 0xd4) + param_2,param_3,1);
  return;
}



/* FUNCTION 19060 ; VA 0x009d54d0 ; FUN_009d54d0 */

uint __thiscall FUN_009d54d0(int param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  param_2 = param_2 + *(int *)(param_1 + 0xd4);
  puVar2 = (undefined4 *)FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if (param_2 <= (int)puVar2) {
    puVar2 = (undefined4 *)FUN_01257810(*(undefined4 *)(param_1 + 0xd8),param_2,DAT_01ede6c4);
    if (puVar2 != (undefined4 *)0x0) {
      *param_3 = *puVar2;
      uVar1 = puVar2[1];
      param_3[1] = uVar1;
      return CONCAT31((int3)((uint)uVar1 >> 8),1);
    }
  }
  return (uint)puVar2 & 0xffffff00;
}



/* FUNCTION 19061 ; VA 0x009d5530 ; FUN_009d5530 */

uint __thiscall FUN_009d5530(int param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  
  param_2 = param_2 + *(int *)(param_1 + 0xd4);
  uVar1 = FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if ((int)uVar1 < param_2) {
    return uVar1 & 0xffffff00;
  }
  uVar1 = FUN_00d920a0(*(undefined4 *)(param_1 + 0xd8),param_2,param_3);
  return uVar1;
}



/* FUNCTION 19062 ; VA 0x009d5580 ; FUN_009d5580 */

uint __thiscall FUN_009d5580(int param_1,int param_2,undefined4 *param_3)

{
  undefined2 uVar1;
  undefined4 *puVar2;
  
  param_2 = param_2 + *(int *)(param_1 + 0xd4);
  puVar2 = (undefined4 *)FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  if (param_2 <= (int)puVar2) {
    puVar2 = (undefined4 *)FUN_01257810(*(undefined4 *)(param_1 + 0xd8),param_2,DAT_01ede6bc);
    if (puVar2 != (undefined4 *)0x0) {
      *param_3 = *puVar2;
      uVar1 = *(undefined2 *)(puVar2 + 1);
      *(undefined2 *)(param_3 + 1) = uVar1;
      return CONCAT31((int3)(CONCAT22((short)((uint)puVar2 >> 0x10),uVar1) >> 8),1);
    }
  }
  return (uint)puVar2 & 0xffffff00;
}



/* FUNCTION 19063 ; VA 0x009d55e0 ; FUN_009d55e0 */

void FUN_009d55e0(undefined *param_1,undefined *param_2)

{
  *param_2 = *param_1;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
  *(undefined4 *)(param_2 + 0xc) = *(undefined4 *)(param_1 + 0xc);
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0;
  *(undefined4 *)(param_2 + 0x10) = *(undefined4 *)(param_1 + 0x10);
  *(undefined4 *)(param_2 + 0x14) = *(undefined4 *)(param_1 + 0x14);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  return;
}



/* FUNCTION 19064 ; VA 0x009d5630 ; FUN_009d5630 */

void FUN_009d5630(undefined4 *param_1,undefined4 *param_2)

{
  *param_2 = *param_1;
  *param_1 = 0;
  return;
}



/* FUNCTION 19065 ; VA 0x009d5650 ; FUN_009d5650 */

undefined4 FUN_009d5650(undefined4 param_1,int param_2)

{
  FUN_012569a0(param_1,(double)param_2);
  return 1;
}



/* FUNCTION 19066 ; VA 0x009d5680 ; FUN_009d5680 */

undefined4 FUN_009d5680(undefined4 param_1,float param_2)

{
  FUN_012569a0(param_1,(double)param_2);
  return 1;
}



/* FUNCTION 19067 ; VA 0x009d56b0 ; FUN_009d56b0 */

undefined4 FUN_009d56b0(undefined4 param_1,undefined8 param_2)

{
  FUN_012569a0(param_1,param_2);
  return 1;
}



/* FUNCTION 19068 ; VA 0x009d56e0 ; FUN_009d56e0 */

undefined4 FUN_009d56e0(undefined4 param_1,undefined4 param_2)

{
  FUN_0088dd80(param_2);
  FUN_009ce010(param_1);
  return 1;
}



/* FUNCTION 19069 ; VA 0x009d5710 ; FUN_009d5710 */

undefined4 FUN_009d5710(undefined4 param_1,undefined4 param_2)

{
  FUN_0087de50(param_1,param_2);
  return 1;
}



/* FUNCTION 19070 ; VA 0x009d5730 ; FUN_009d5730 */

int * FUN_009d5730(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  piVar1 = (int *)*param_2;
  if (piVar1 == (int *)0x0) {
    return piVar1;
  }
  iVar4 = *piVar1;
  piVar3 = (int *)0x0;
  if (iVar4 != piVar1[1]) {
    do {
      iVar2 = FUN_01255e10(param_1,4);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Cannot create enough space in lua stack for bridging value");
      }
      iVar2 = FUN_009ce3c0(iVar4,param_1);
      piVar3 = (int *)((int)piVar3 + iVar2);
      iVar4 = iVar4 + 0xd0;
    } while (iVar4 != *(int *)(*param_2 + 4));
  }
  return piVar3;
}



/* FUNCTION 19071 ; VA 0x009d5790 ; FUN_009d5790 */

undefined4 FUN_009d5790(undefined4 param_1,int *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  
  if (*param_2 == 0) {
    FUN_01255f00(param_1,0,0);
    return 1;
  }
  FUN_01255f00(param_1,0,*(undefined4 *)(*param_2 + 4));
  puVar2 = *(undefined4 **)*param_2;
  puVar3 = (undefined4 *)*puVar2;
  while( true ) {
    if (puVar3 == puVar2) {
      return 1;
    }
    FUN_0087de50(param_1,puVar3 + 4);
    iVar6 = FUN_01255e10(param_1,4);
    if (iVar6 == 0) break;
    iVar6 = FUN_009ce3c0(puVar3 + 10,param_1);
    if (iVar6 != 1) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Cannot expand tuple.");
    }
    FUN_01257230(param_1,0xfffffffd);
    puVar4 = (undefined4 *)puVar3[2];
    if (*(char *)((int)puVar4 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar4 + 0xd);
      puVar3 = puVar4;
      puVar4 = (undefined4 *)*puVar4;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar4 + 0xd);
        puVar3 = puVar4;
        puVar4 = (undefined4 *)*puVar4;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar3[1] + 0xd);
      puVar5 = (undefined4 *)puVar3[1];
      puVar4 = puVar3;
      while ((puVar3 = puVar5, cVar1 == '\0' && (puVar4 == (undefined4 *)puVar3[2]))) {
        cVar1 = *(char *)((int)puVar3[1] + 0xd);
        puVar5 = (undefined4 *)puVar3[1];
        puVar4 = puVar3;
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Cannot create enough space in lua stack for bridging value");
}



/* FUNCTION 19072 ; VA 0x009d5870 ; FUN_009d5870 */

undefined4 FUN_009d5870(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  if (*param_2 == 0) {
    FUN_01255f00(param_1,0,0);
    return 1;
  }
  FUN_01255f00(param_1,0,*(undefined4 *)(*param_2 + 8));
  iVar1 = *param_2;
  if (*(int *)(iVar1 + 8) == 0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(iVar1 + 0x14) + *(int *)(iVar1 + 4) * 4);
  }
  while( true ) {
    if (puVar2 == (undefined4 *)0x0) {
      return 1;
    }
    FUN_0087de50(param_1,puVar2 + 2);
    iVar1 = FUN_01255e10(param_1,4);
    if (iVar1 == 0) break;
    iVar1 = FUN_009ce3c0(puVar2 + 8,param_1);
    if (iVar1 != 1) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Cannot expand tuple.");
    }
    FUN_01257230(param_1,0xfffffffd);
    puVar2 = (undefined4 *)*puVar2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Cannot create enough space in lua stack for bridging value");
}



/* FUNCTION 19073 ; VA 0x009d5920 ; FUN_009d5920 */

undefined4 FUN_009d5920(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  
  if (*param_2 == 0) {
    FUN_01255f00(param_1,0,0);
    return 1;
  }
  uVar1 = FUN_009d5bb0(*param_2,param_1);
  return uVar1;
}



/* FUNCTION 19074 ; VA 0x009d5950 ; FUN_009d5950 */

undefined4 FUN_009d5950(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  
  if (*param_2 == 0) {
    FUN_01255f00(param_1,0,0);
    return 1;
  }
  uVar1 = FUN_009d5b10(*param_2,param_1);
  return uVar1;
}



/* FUNCTION 19075 ; VA 0x009d5980 ; FUN_009d5980 */

undefined4 FUN_009d5980(undefined4 param_1,undefined4 param_2)

{
  FUN_00da3620(param_1,param_2);
  return 1;
}



/* FUNCTION 19076 ; VA 0x009d59a0 ; FUN_009d59a0 */

undefined4 FUN_009d59a0(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  
  if (param_2[8] != 0) {
    uVar5 = *param_2;
    uVar6 = param_2[1];
    uVar7 = param_2[2];
    uVar8 = param_2[3];
    uVar2 = *(undefined8 *)(param_2 + 4);
    uVar3 = param_2[6];
    uVar4 = param_2[7];
    if (param_2[9] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[9] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_009ce0b0(param_1,uVar5,uVar6,uVar7,uVar8,uVar2,uVar3,uVar4,param_2[8],param_2[9]);
    return 1;
  }
  FUN_01256980(param_1);
  return 1;
}



/* FUNCTION 19077 ; VA 0x009d5a20 ; FUN_009d5a20 */

undefined4 FUN_009d5a20(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar2 = *param_2;
  iVar1 = FUN_00888530();
  if (iVar2 == iVar1) {
    return 0;
  }
  iVar2 = FUN_01255e10(param_1,4);
  if (iVar2 != 0) {
    uVar3 = FUN_009ce3c0(param_2,param_1);
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Cannot create enough space in lua stack for bridging value");
}



/* FUNCTION 19078 ; VA 0x009d5a70 ; FUN_009d5a70 */

undefined4 FUN_009d5a70(undefined4 param_1,undefined4 param_2)

{
  FUN_00d987b0(param_1,param_2);
  return 1;
}



/* FUNCTION 19079 ; VA 0x009d5a90 ; FUN_009d5a90 */

undefined4 FUN_009d5a90(undefined4 param_1)

{
  undefined8 in_XMM0_Qa;
  
  FUN_016f4020();
  FUN_012569a0(param_1,in_XMM0_Qa);
  return 1;
}



/* FUNCTION 19080 ; VA 0x009d5ac0 ; FUN_009d5ac0 */

undefined4 FUN_009d5ac0(undefined4 param_1,undefined param_2)

{
  FUN_01256800(param_1,param_2);
  return 1;
}



/* FUNCTION 19081 ; VA 0x009d5ae0 ; FUN_009d5ae0 */

void FUN_009d5ae0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_01255e10(param_2,4);
  if (iVar1 != 0) {
    FUN_009ce3c0();
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Cannot create enough space in lua stack for bridging value");
}



/* FUNCTION 19082 ; VA 0x009d5b10 ; FUN_009d5b10 */

undefined4 FUN_009d5b10(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  FUN_01255f00(param_2,(param_1[1] - *param_1) / 0xd0,0);
  iVar3 = *param_1;
  iVar1 = param_1[1];
  param_1 = (int *)0x0;
  while( true ) {
    if (iVar3 == iVar1) {
      return 1;
    }
    iVar2 = FUN_01255e10(param_2,4);
    if (iVar2 == 0) break;
    iVar2 = FUN_009ce3c0(iVar3,param_2);
    if (iVar2 != 1) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Cannot expand tuple.");
    }
    param_1 = (int *)((int)param_1 + 1);
    FUN_01256da0(param_2,0xfffffffe,param_1);
    iVar3 = iVar3 + 0xd0;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Cannot create enough space in lua stack for bridging value");
}



/* FUNCTION 19083 ; VA 0x009d5bb0 ; FUN_009d5bb0 */

undefined4 FUN_009d5bb0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  FUN_01255f00(param_2,param_1[1] - *param_1 >> 3,0);
  iVar1 = param_1[1];
  iVar3 = 0;
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 8) {
    FUN_00da3620(param_2,iVar2);
    iVar3 = iVar3 + 1;
    FUN_01256da0(param_2,0xfffffffe,iVar3);
  }
  return 1;
}



/* FUNCTION 19084 ; VA 0x009d5c10 ; FUN_009d5c10 */

undefined4 FUN_009d5c10(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar2 = *param_1;
  iVar1 = FUN_00888530();
  if (iVar2 == iVar1) {
    return 0;
  }
  iVar2 = FUN_01255e10(param_2,4);
  if (iVar2 != 0) {
    uVar3 = FUN_009ce3c0(param_1,param_2);
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Cannot create enough space in lua stack for bridging value");
}



/* FUNCTION 19085 ; VA 0x009d5c60 ; FUN_009d5c60 */

int FUN_009d5c60(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = 0;
  iVar3 = *param_1;
  iVar1 = param_1[1];
  while( true ) {
    if (iVar3 == iVar1) {
      return iVar4;
    }
    iVar2 = FUN_01255e10(param_2,4);
    if (iVar2 == 0) break;
    iVar2 = FUN_009ce3c0(iVar3,param_2);
    iVar3 = iVar3 + 0xd0;
    iVar4 = iVar4 + iVar2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Cannot create enough space in lua stack for bridging value");
}



/* FUNCTION 19086 ; VA 0x009d5cc0 ; FUN_009d5cc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009d5cc0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4470) {
    FUN_016f3809(&DAT_01ee4470);
    if (DAT_01ee4470 == -1) {
      _DAT_01ee4464 = FUN_00619f80;
      _DAT_01ee4468 = FUN_00619f80;
      DAT_01ee446c = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee4470);
    }
  }
  return &DAT_01ee4464;
}



/* FUNCTION 19087 ; VA 0x009d5d30 ; FUN_009d5d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009d5d30(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4460) {
    FUN_016f3809(&DAT_01ee4460);
    if (DAT_01ee4460 == -1) {
      _DAT_01ee4454 = FUN_0057bbb0;
      _DAT_01ee4458 = FUN_005880a0;
      _DAT_01ee445c = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ee4460);
    }
  }
  return &DAT_01ee4454;
}



/* FUNCTION 19088 ; VA 0x009d5da0 ; FUN_009d5da0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009d5da0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4450) {
    FUN_016f3809(&DAT_01ee4450);
    if (DAT_01ee4450 == -1) {
      _DAT_01ee4444 = FUN_005c6620;
      _DAT_01ee4448 = FUN_005c6620;
      _DAT_01ee444c = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee4450);
    }
  }
  return &DAT_01ee4444;
}



/* FUNCTION 19089 ; VA 0x009d5e10 ; FUN_009d5e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009d5e10(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4480) {
    FUN_016f3809(&DAT_01ee4480);
    if (DAT_01ee4480 == -1) {
      _DAT_01ee4474 = FUN_009d03f0;
      _DAT_01ee4478 = FUN_009d03f0;
      DAT_01ee447c = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee4480);
    }
  }
  return &DAT_01ee4474;
}



/* FUNCTION 19090 ; VA 0x009d5e80 ; FUN_009d5e80 */

int * __thiscall
FUN_009d5e80(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_009d5f50();
  FUN_009d6a90(uVar3,param_2,param_3,0,param_7,param_8,param_9,param_10,param_11);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<class_G3D::Color3,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<class_G3D::Color3,1>::BoundPropGetSet<class_RBX::Lighting>
              ::vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = param_5;
    puVar4[5] = param_6;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19091 ; VA 0x009d5f50 ; FUN_009d5f50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009d5f50(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d61a0;
  pvStack_10 = ExceptionList;
  if (DAT_01ee44a8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee46c0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee46c0);
      if (DAT_01ee46c0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Lighting",1,uStack_20,0,0,0xb,0,0);
        _DAT_01ee46b8 = RBX::Creator<class_RBX::Lighting>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee44b0,&DAT_01ee46b8);
        FUN_016f3654(FUN_018877c0);
        FUN_016f37bf(&DAT_01ee46c0);
      }
    }
    DAT_01ee44a8 = &DAT_01ee44b0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee44a8;
}



/* FUNCTION 19092 ; VA 0x009d6050 ; FUN_009d6050 */

void FUN_009d6050(void)

{
  int iVar1;
  
  if (DAT_01ee46c4 == 0) {
    iVar1 = FUN_009d5f50();
    DAT_01ee46c4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19093 ; VA 0x009d6070 ; thunk_FUN_00712f70 */

undefined * thunk_FUN_00712f70(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abd5c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eafa84) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eafa84);
    if (DAT_01eafa84 == -1) {
      uStack_8 = 0;
      FUN_009d69d0();
      FUN_016f3654(&LAB_0187ea60);
      FUN_016f37bf(&DAT_01eafa84);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eafa20;
}



/* FUNCTION 19094 ; VA 0x009d6080 ; FUN_009d6080 */

char * FUN_009d6080(char *param_1)

{
  char cVar1;
  code *pcVar2;
  char cVar3;
  char *pcVar4;
  
  pcVar4 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar4 = *(char **)param_1;
  }
  if (pcVar4 != pcVar4 + *(int *)(param_1 + 0x10)) {
    cVar1 = *pcVar4;
    cVar3 = FUN_009d7350();
    if (cVar1 == '-') {
      param_1 = (char *)(-(int)param_1 & 0xffff);
    }
    if (cVar3 != '\0') {
      return param_1;
    }
  }
  FUN_009d6720();
  pcVar2 = (code *)swi(3);
  pcVar4 = (char *)(*pcVar2)();
  return pcVar4;
}



/* FUNCTION 19095 ; VA 0x009d6100 ; FUN_009d6100 */

undefined4 FUN_009d6100(char *param_1)

{
  char cVar1;
  code *pcVar2;
  bool bVar3;
  char cVar4;
  undefined4 uVar5;
  char *pcVar6;
  
  pcVar6 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar6 = *(char **)param_1;
  }
  if (pcVar6 != pcVar6 + *(int *)(param_1 + 0x10)) {
    cVar1 = *pcVar6;
    cVar4 = FUN_009d7520();
    if (cVar1 == '-') {
      if (cVar4 == '\0') {
        bVar3 = false;
      }
      else {
        bVar3 = true;
      }
    }
    else if (cVar4 == '\0') {
      bVar3 = false;
    }
    else {
      bVar3 = true;
    }
    if (bVar3) {
      return 0;
    }
  }
  FUN_009d6760();
  pcVar2 = (code *)swi(3);
  uVar5 = (*pcVar2)();
  return uVar5;
}



/* FUNCTION 19096 ; VA 0x009d61a0 ; FUN_009d61a0 */

/* WARNING: Removing unreachable block (ram,0x009d6216) */
/* WARNING: Removing unreachable block (ram,0x009d6241) */

undefined8 FUN_009d61a0(char *param_1)

{
  char cVar1;
  code *pcVar2;
  bool bVar3;
  char cVar4;
  char *pcVar5;
  undefined8 uVar6;
  
  pcVar5 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar5 = *(char **)param_1;
  }
  if (pcVar5 != pcVar5 + *(int *)(param_1 + 0x10)) {
    cVar1 = *pcVar5;
    cVar4 = FUN_009d76f0();
    if (cVar1 == '-') {
      if (cVar4 == '\0') {
        bVar3 = false;
      }
      else {
        bVar3 = true;
      }
    }
    else if (cVar4 == '\0') {
      bVar3 = false;
    }
    else {
      bVar3 = true;
    }
    if (bVar3) {
      return 0;
    }
  }
  FUN_009d67a0();
  pcVar2 = (code *)swi(3);
  uVar6 = (*pcVar2)();
  return uVar6;
}



/* FUNCTION 19097 ; VA 0x009d6260 ; FUN_009d6260 */

undefined4 FUN_009d6260(undefined4 param_1,char *param_2)

{
  int *piVar1;
  char cVar2;
  char cVar3;
  uint uVar4;
  char *pcVar5;
  uint uVar6;
  int iVar7;
  char ****ppppcVar8;
  undefined4 uVar9;
  int iVar10;
  bool bVar11;
  undefined8 uVar12;
  undefined auStack_1d8 [44];
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  uint uStack_1a4;
  int *piStack_1a0;
  char ***pppcStack_19c;
  char ***pppcStack_198;
  int iStack_14c;
  int iStack_148;
  char cStack_144;
  char ***pppcStack_140;
  uint uStack_12c;
  int iStack_ec;
  int iStack_e8;
  char cStack_e4;
  char ***apppcStack_e0 [4];
  uint uStack_d0;
  uint uStack_cc;
  undefined auStack_c8 [16];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined auStack_b0 [16];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined auStack_98 [16];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined2 uStack_80;
  undefined4 uStack_7c;
  undefined uStack_78;
  char *pcStack_74;
  char ***pppcStack_70;
  undefined auStack_6c [24];
  undefined auStack_54 [24];
  undefined uStack_3c;
  undefined uStack_3b;
  undefined4 uStack_38;
  undefined uStack_34;
  undefined4 uStack_30;
  uint uStack_2c;
  uint uStack_28;
  char acStack_24 [4];
  undefined *puStack_20;
  undefined8 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017d6207;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)(param_2 + 0x10);
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_30 = 0;
  if (*piVar1 != 0) {
    pcVar5 = param_2;
    if (0xf < *(uint *)(param_2 + 0x14)) {
      pcVar5 = *(char **)param_2;
    }
    cVar2 = *pcVar5;
    iVar10 = 0;
    uStack_1c = 0;
    builtin_strncpy(acStack_24,"-:,.",4);
    puStack_20 = (undefined *)((uint)puStack_20 & 0xffffff00);
    uStack_a0 = 0;
    uStack_9c = 0xf;
    auStack_b0[0] = 0;
    pcVar5 = acStack_24;
    uStack_8 = 0;
    uStack_88 = 0;
    uStack_84 = 0xf;
    auStack_98[0] = 0;
    do {
      cVar3 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar3 != '\0');
    pppcStack_198 = (char ***)((int)pcVar5 - (int)(acStack_24 + 1));
    pppcStack_19c = (char ***)acStack_24;
    piStack_1a0 = (int *)0x9d630b;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_80 = 0;
    uStack_7c = 0;
    uStack_78 = 0;
    uStack_8 = 2;
    pcStack_74 = param_2;
    if (0xf < *(uint *)(param_2 + 0x14)) {
      pcStack_74 = *(char **)param_2;
      param_2 = *(char **)param_2;
    }
    pppcStack_70 = (char ***)(param_2 + *piVar1);
    puStack_14 = auStack_6c;
    pppcStack_198 = (char ***)auStack_b0;
    pppcStack_19c = (char ***)0x9d6350;
    FUN_0054ef60();
    pppcStack_198 = (char ***)auStack_98;
    uStack_8._0_1_ = 3;
    pppcStack_19c = (char ***)0x9d6363;
    FUN_0054ef60();
    uStack_3c = (undefined)uStack_80;
    uStack_3b = uStack_80._1_1_;
    uStack_38 = uStack_7c;
    uStack_34 = uStack_78;
    pppcStack_198 = pppcStack_70;
    uStack_8._0_1_ = 4;
    pppcStack_19c = (char ***)pcStack_74;
    puStack_14 = auStack_1d8;
    FUN_0054ef60(auStack_6c);
    uStack_8._0_1_ = 5;
    FUN_0054ef60(auStack_54);
    uStack_1a8._0_2_ = CONCAT11(uStack_3b,uStack_3c);
    uStack_1a4 = uStack_38;
    piStack_1a0 = (int *)CONCAT31(piStack_1a0._1_3_,uStack_34);
    uStack_8._0_1_ = 4;
    FUN_00590840();
    puStack_14 = (undefined *)uStack_1c._4_4_;
    uStack_8._0_1_ = 6;
    uStack_1c = CONCAT44((undefined4)uStack_1c,(undefined4)uStack_1c);
    while( true ) {
      pppcStack_198 = pppcStack_70;
      pppcStack_19c = pppcStack_70;
      puStack_20 = auStack_1d8;
      FUN_0054ef60(auStack_6c);
      uStack_8._0_1_ = 7;
      FUN_0054ef60(auStack_54);
      uStack_1a8._0_2_ = CONCAT11(uStack_3b,uStack_3c);
      uStack_1a4 = uStack_38;
      piStack_1a0 = (int *)CONCAT31(piStack_1a0._1_3_,uStack_34);
      uStack_8._0_1_ = 6;
      FUN_00590840();
      if ((cStack_144 == '\0') || (cStack_e4 == '\0')) {
        bVar11 = cStack_144 != cStack_e4;
      }
      else if ((iStack_14c == iStack_ec) && (iStack_148 == iStack_e8)) {
        bVar11 = false;
      }
      else {
        bVar11 = true;
      }
      if (0xf < uStack_12c) {
        pppcStack_198 = (char ***)(uStack_12c + 1);
        ppppcVar8 = (char ****)pppcStack_140;
        if (0xfff < pppcStack_198) {
          ppppcVar8 = (char ****)pppcStack_140[-1];
          pppcStack_198 = (char ***)(uStack_12c + 0x24);
          if ((char *)0x1f < (char *)((int)pppcStack_140 + (-4 - (int)ppppcVar8)))
          goto LAB_009d6707;
        }
        piStack_1a0 = (int *)0x9d64a8;
        pppcStack_19c = (char ***)ppppcVar8;
        FUN_01674ea0();
      }
      uStack_12c = 0xf;
      pppcStack_140 = (char ***)((uint)pppcStack_140 & 0xffffff00);
      pppcStack_198 = (char ***)0x9d64d1;
      FUN_005509f0();
      uVar4 = uStack_d0;
      if (!bVar11) break;
      switch(iVar10) {
      case 0:
        pppcStack_198 = (char ***)apppcStack_e0;
        pppcStack_19c = (char ***)0x9d64f5;
        uStack_30 = FUN_009d6100();
        break;
      case 1:
        pppcStack_198 = (char ***)apppcStack_e0;
        pppcStack_19c = (char ***)0x9d650c;
        uStack_2c = FUN_009d6080();
        uStack_2c = uStack_2c & 0xffff;
        break;
      case 2:
        pppcStack_198 = (char ***)apppcStack_e0;
        pppcStack_19c = (char ***)0x9d6526;
        uStack_28 = FUN_009d6080();
        uStack_28 = uStack_28 & 0xffff;
        break;
      case 3:
        pppcStack_198 = (char ***)apppcStack_e0;
        if ((int)uStack_d0 < 6) {
          pppcStack_19c = (char ***)0x9d65b5;
          uVar12 = FUN_009d61a0();
          uVar9 = (undefined4)((ulonglong)uVar12 >> 0x20);
          uStack_1c = CONCAT44((int)uVar12,(undefined4)uStack_1c);
          puStack_14 = (undefined *)uVar9;
        }
        else {
          uStack_b8 = 0;
          uVar6 = 6;
          if (uStack_d0 < 6) {
            uVar6 = uStack_d0;
          }
          uStack_b4 = 0xf;
          pppcStack_19c = pppcStack_198;
          if (0xf < uStack_cc) {
            pppcStack_19c = apppcStack_e0[0];
          }
          auStack_c8[0] = 0;
          piStack_1a0 = (int *)0x9d6583;
          pppcStack_198 = (char ***)uVar6;
          FUN_005542c0();
          pppcStack_198 = (char ***)auStack_c8;
          uStack_8._0_1_ = 8;
          pppcStack_19c = (char ***)0x9d6593;
          uVar12 = FUN_009d61a0();
          uVar9 = (undefined4)((ulonglong)uVar12 >> 0x20);
          uStack_1c = CONCAT44((int)uVar12,(undefined4)uStack_1c);
          uStack_8._0_1_ = 6;
          pppcStack_198 = (char ***)0x9d65ad;
          puStack_14 = (undefined *)uVar9;
          FUN_005507b0();
        }
        if ((int)uVar4 < 6) {
          uStack_1a4 = 1;
          iVar7 = 6 - uVar4;
          if (0 < iVar7) {
            do {
              uStack_1a4 = uStack_1a4 * 10;
              iVar7 = iVar7 + -1;
            } while (iVar7 != 0);
          }
          pppcStack_19c = (char ***)uStack_1c._4_4_;
          piStack_1a0 = (int *)((int)uStack_1a4 >> 0x1f);
          uStack_1a8 = 0x9d65eb;
          pppcStack_198 = (char ***)uVar9;
          uVar12 = FUN_016f39b0();
          puStack_14 = (undefined *)((ulonglong)uVar12 >> 0x20);
          uStack_1c = CONCAT44((int)uVar12,(undefined4)uStack_1c);
        }
      }
      pppcStack_198 = (char ***)apppcStack_e0;
      iVar10 = iVar10 + 1;
      pppcStack_19c = (char ***)iStack_e8;
      piStack_1a0 = &iStack_ec;
      uStack_1a4 = 0x9d6611;
      cStack_e4 = FUN_005904a0();
    }
    if (0xf < uStack_cc) {
      pppcStack_198 = (char ***)(uStack_cc + 1);
      ppppcVar8 = (char ****)apppcStack_e0[0];
      if (0xfff < pppcStack_198) {
        ppppcVar8 = (char ****)apppcStack_e0[0][-1];
        pppcStack_198 = (char ***)(uStack_cc + 0x24);
        if ((char *)0x1f < (char *)((int)apppcStack_e0[0] + (-4 - (int)ppppcVar8)))
        goto LAB_009d6707;
      }
      piStack_1a0 = (int *)0x9d6653;
      pppcStack_19c = (char ***)ppppcVar8;
      FUN_01674ea0();
    }
    uStack_d0 = 0;
    uStack_cc = 0xf;
    apppcStack_e0[0] = (char ***)((uint)apppcStack_e0[0] & 0xffffff00);
    pppcStack_198 = (char ***)0x9d667c;
    FUN_005509f0();
    pppcStack_198 = (char ***)puStack_14;
    pppcStack_19c = (char ***)uStack_1c._4_4_;
    piStack_1a0 = (int *)(uStack_28 & 0xffff);
    uStack_1a4 = uStack_2c & 0xffff;
    uStack_1a8 = uStack_30;
    if (cVar2 == '-') {
      uStack_1ac = 0x9d66a2;
      FUN_005ef640();
      pppcStack_198 = (char ***)param_1;
      pppcStack_19c = (char ***)0x9d66ad;
      FUN_009d70b0();
      pppcStack_198 = (char ***)0x9d66b5;
      FUN_005509f0();
      pppcStack_198 = (char ***)0x9d66c0;
      FUN_005509f0();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_1ac = 0x9d66db;
    FUN_005ef640();
    pppcStack_198 = (char ***)0x9d66e3;
    FUN_005509f0();
    pppcStack_198 = (char ***)0x9d66ee;
    FUN_005509f0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  pppcStack_198 = (char ***)0x9d6707;
  ExceptionList = &pvStack_10;
  FUN_00554050();
LAB_009d6707:
                    /* WARNING: Subroutine does not return */
  pppcStack_198 = (char ***)&switchD_009d64e2::switchdataD_009d670c;
  FUN_017167a3();
}



/* FUNCTION 19098 ; VA 0x009d6720 ; FUN_009d6720 */

void FUN_009d6720(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6228;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00637490(&std::
                        basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                        ::RTTI_Type_Descriptor,&TypeDescriptor_01dc24ec);
  uStack_8 = 0;
  FUN_00636dc0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 19099 ; VA 0x009d6760 ; FUN_009d6760 */

void FUN_009d6760(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6228;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00637490(&std::
                        basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                        ::RTTI_Type_Descriptor,&TypeDescriptor_01d9733c);
  uStack_8 = 0;
  FUN_00636dc0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 19100 ; VA 0x009d67a0 ; FUN_009d67a0 */

void FUN_009d67a0(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6228;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00637490(&std::
                        basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                        ::RTTI_Type_Descriptor,&TypeDescriptor_01d97820);
  uStack_8 = 0;
  FUN_00636dc0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 19101 ; VA 0x009d67e0 ; FUN_009d67e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_009d67e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  undefined *puStack_e4;
  undefined8 auStack_e0 [25];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d628b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_009d5f50();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::BoundFuncDesc<class_RBX::Lighting,void___cdecl(double),1>::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8 = 1;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar1 = (undefined8 *)param_1[0x10];
  if (puVar1 == (undefined8 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088ca00();
    puStack_e4 = (undefined *)0x0;
    auStack_e0[0] = *puVar1;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead488) {
      FUN_016f3809(&DAT_01ead488);
      if (DAT_01ead488 == -1) {
        _DAT_01ead47c = FUN_00619e80;
        _DAT_01ead480 = FUN_00619e80;
        DAT_01ead484 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead488);
      }
    }
    puStack_e4 = &DAT_01ead47c;
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088ca00();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_e4 != (undefined *)0x0) {
      (**(code **)(puStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19102 ; VA 0x009d69d0 ; FUN_009d69d0 */

undefined4 * __fastcall FUN_009d69d0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("Technology");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::LightingTechnology>::vftable;
  FUN_009caf20();
  FUN_009cade0(0,"Legacy",1,0);
  FUN_009cade0(4,"Future",1,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19103 ; VA 0x009d6a90 ; FUN_009d6a90 */

/* WARNING: Removing unreachable block (ram,0x009d6b23) */

int * __thiscall
FUN_009d6a90(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d62bb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088d050();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19104 ; VA 0x009d6b40 ; FUN_009d6b40 */

undefined4 * __fastcall FUN_009d6b40(undefined4 *param_1)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined8 *puVar3;
  int iVar4;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d631a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Lighting,class_RBX::ServiceInstance>::vftable;
  uVar2 = FUN_009d5f50();
  param_1[3] = uVar2;
  uStack_8 = 1;
  *param_1 = RBX::Lighting::vftable;
  FUN_01167070();
  *(undefined *)(param_1 + 0x2a) = 1;
  puVar3 = (undefined8 *)FUN_0115e910();
  uStack_1c = 0;
  *(undefined8 *)(param_1 + 0x2b) = *puVar3;
  param_1[0x2d] = *(undefined4 *)(puVar3 + 1);
  param_1[0x2e] = 0x3f800000;
  param_1[0x2f] = 0x3f333333;
  param_1[0x30] = 0x3f333333;
  param_1[0x31] = 0x3f3851ec;
  param_1[0x32] = 0x3f400000;
  param_1[0x33] = 0x3f400000;
  param_1[0x34] = 0x3f400000;
  param_1[0x35] = 0;
  param_1[0x36] = 0x47c35000;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0();
  uStack_8._0_1_ = 2;
  FUN_009d6260();
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_18) {
    if (0xfff < uStack_18 + 1) {
      if (0x1f < (auStack_2c[0] - *(int *)(auStack_2c[0] - 4)) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0x3f800000;
  param_1[0x41] = 0x3f000000;
  param_1[0x42] = 0x3f000000;
  param_1[0x43] = 0x3f000000;
  param_1[0x44] = 0x3f000000;
  param_1[0x45] = 0x3f000000;
  param_1[0x46] = 0x3f000000;
  *(undefined2 *)(param_1 + 0x47) = 0x100;
  param_1[0x48] = 0x3f000000;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  *(undefined *)(param_1 + 0x4c) = 1;
  param_1[0x4d] = 2;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  param_1[0x19] = 0x3f189899;
  param_1[0x1a] = 0x3f09898a;
  param_1[0x1b] = 0x3ecccccd;
  uStack_8._0_1_ = 5;
  iVar4 = FUN_016f3900(param_1[0x38],param_1[0x39],1000000,0);
  FUN_01167140((double)iVar4,param_1[0x4a]);
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    if (0xfff < uStack_18 + 1) {
      if (0x1f < (auStack_2c[0] - *(int *)(auStack_2c[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19105 ; VA 0x009d6e50 ; FUN_009d6e50 */

void __fastcall FUN_009d6e50(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Lighting>::vftable;
  uVar1 = FUN_009d5f50(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19106 ; VA 0x009d6e90 ; FUN_009d6e90 */

/* WARNING: Removing unreachable block (ram,0x009d6eff) */
/* WARNING: Removing unreachable block (ram,0x009d6f49) */

undefined4 __thiscall FUN_009d6e90(undefined4 *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  char cVar3;
  
  pcVar2 = (char *)*param_1;
  if (pcVar2 == (char *)param_1[1]) {
    return 0;
  }
  cVar1 = *pcVar2;
  if ((cVar1 == '-') || (cVar1 == '+')) {
    *param_1 = pcVar2 + 1;
  }
  cVar3 = FUN_009d76f0();
  if (cVar1 != '-') {
    if (cVar3 == '\0') {
      *param_2 = 0;
      param_2[1] = 0;
      return 0;
    }
    *param_2 = 0;
    param_2[1] = 0;
    return 1;
  }
  if (cVar3 != '\0') {
    *param_2 = 0;
    param_2[1] = 0;
    return 1;
  }
  *param_2 = 0;
  param_2[1] = 0;
  return 0;
}



/* FUNCTION 19107 ; VA 0x009d6f80 ; FUN_009d6f80 */

undefined8 * __thiscall FUN_009d6f80(int *param_1,undefined8 *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  undefined8 uVar3;
  undefined8 uStack_c;
  
  iVar2 = *param_1;
  iVar1 = param_1[1];
  if ((((iVar2 != 0) || (iVar1 != -0x80000000)) && ((iVar2 != -1 || (iVar1 != 0x7fffffff)))) &&
     ((iVar2 != -2 || (iVar1 != 0x7fffffff)))) {
    uVar3 = FUN_016f39b0(param_3,param_3 >> 0x1f,iVar2,iVar1);
    *param_2 = uVar3;
    return param_2;
  }
  if ((iVar2 == -2) && (iVar1 == 0x7fffffff)) {
LAB_009d7071:
    *(undefined4 *)param_2 = 0xfffffffe;
    *(undefined4 *)((int)param_2 + 4) = 0x7fffffff;
    return param_2;
  }
  uStack_c = 0;
  iVar2 = FUN_00874e00(&uStack_c);
  if ((iVar2 != 1) || (param_3 < 1)) {
    uStack_c = 0;
    iVar2 = FUN_00874e00(&uStack_c);
    if ((iVar2 != -1) || (-1 < param_3)) {
      uStack_c = 0;
      iVar2 = FUN_00874e00(&uStack_c);
      if ((iVar2 != 1) || (-1 < param_3)) {
        uStack_c = 0;
        iVar2 = FUN_00874e00(&uStack_c);
        if ((iVar2 != -1) || (param_3 < 1)) goto LAB_009d7071;
      }
      *(undefined4 *)param_2 = 0;
      *(undefined4 *)((int)param_2 + 4) = 0x80000000;
      return param_2;
    }
  }
  *(undefined4 *)param_2 = 0xffffffff;
  *(undefined4 *)((int)param_2 + 4) = 0x7fffffff;
  return param_2;
}



/* FUNCTION 19108 ; VA 0x009d70b0 ; FUN_009d70b0 */

void __thiscall FUN_009d70b0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined8 uStack_c;
  
  iVar2 = *param_1;
  iVar1 = param_1[1];
  if ((((iVar2 != 0) || (iVar1 != -0x80000000)) && ((iVar2 != -1 || (iVar1 != 0x7fffffff)))) &&
     ((iVar2 != -2 || (iVar1 != 0x7fffffff)))) {
    *param_2 = -iVar2;
    param_2[1] = -(iVar1 + (uint)(iVar2 != 0));
    return;
  }
  if ((iVar2 != -2) || (iVar1 != 0x7fffffff)) {
    uStack_c = 0;
    iVar2 = FUN_00874e00(&uStack_c);
    if (iVar2 == -1) {
      *param_2 = -1;
      param_2[1] = 0x7fffffff;
      return;
    }
    uStack_c = 0;
    iVar2 = FUN_00874e00(&uStack_c);
    if (iVar2 == 1) {
      *param_2 = 0;
      param_2[1] = -0x80000000;
      return;
    }
  }
  *param_2 = -2;
  param_2[1] = 0x7fffffff;
  return;
}



/* FUNCTION 19109 ; VA 0x009d7190 ; FUN_009d7190 */

undefined4 * __thiscall FUN_009d7190(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 19110 ; VA 0x009d71c0 ; FUN_009d71c0 */

undefined4 * __thiscall FUN_009d71c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::LightingTechnology>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 19111 ; VA 0x009d71f0 ; FUN_009d71f0 */

undefined4 * __thiscall FUN_009d71f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 19112 ; VA 0x009d7220 ; FUN_009d7220 */

undefined4 * __thiscall FUN_009d7220(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::LightingTechnology>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 19113 ; VA 0x009d7250 ; FUN_009d7250 */

int __thiscall FUN_009d7250(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x148);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x140);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x150);
  }
  return param_1;
}



/* FUNCTION 19114 ; VA 0x009d72e0 ; FUN_009d72e0 */

uint FUN_009d72e0(int param_1)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00d6abe0();
    in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
    if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00e6e130();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))
      goto LAB_009d733a;
    }
    return CONCAT31((int3)(in_EAX >> 8),1);
  }
LAB_009d733a:
  return in_EAX & 0xffffff00;
}



/* FUNCTION 19115 ; VA 0x009d7350 ; FUN_009d7350 */

undefined __fastcall FUN_009d7350(int param_1)

{
  byte bVar1;
  void *pvVar2;
  char cVar3;
  undefined uVar4;
  int *piVar5;
  undefined4 uVar6;
  char ******ppppppcVar7;
  undefined4 *puVar8;
  char *pcVar9;
  char *pcVar10;
  char *****apppppcStack_38 [4];
  int iStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  char cStack_13;
  byte bStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar2 = ExceptionList;
  puStack_c = &LAB_017d64a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + -1;
  **(undefined2 **)(param_1 + 4) = 0;
  if (*(char **)(param_1 + 0xc) < *(char **)(param_1 + 8)) {
    ExceptionList = pvVar2;
    return 0;
  }
  cVar3 = **(char **)(param_1 + 0xc);
  if (cVar3 < '0') {
    ExceptionList = pvVar2;
    return 0;
  }
  if ('9' < cVar3) {
    ExceptionList = pvVar2;
    return 0;
  }
  **(short **)(param_1 + 4) = cVar3 + -0x30;
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + -1;
  uStack_8 = 0;
  piVar5 = (int *)FUN_016de181(1);
  uStack_8 = 1;
  piStack_1c = piVar5;
  uVar6 = FUN_016de368();
  cVar3 = FUN_00637e00(uVar6);
  if (cVar3 != '\0') {
    uVar4 = FUN_009d81f0();
    goto LAB_009d74d5;
  }
  piVar5 = (int *)FUN_00564bf0(auStack_20);
  (**(code **)(*piVar5 + 0x14))(apppppcStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iStack_18 = iStack_28;
  if (iStack_28 == 0) {
LAB_009d74c1:
    uVar4 = FUN_009d81f0();
  }
  else {
    ppppppcVar7 = apppppcStack_38;
    if (0xf < uStack_24) {
      ppppppcVar7 = (char ******)apppppcStack_38[0];
    }
    if (*(char *)ppppppcVar7 < '\x01') goto LAB_009d74c1;
    bStack_12 = 0;
    cStack_13 = (**(code **)(*piVar5 + 0x10))();
    pcVar10 = *(char **)(param_1 + 0xc);
    ppppppcVar7 = apppppcStack_38;
    if (0xf < uStack_24) {
      ppppppcVar7 = (char ******)apppppcStack_38[0];
    }
    pcVar9 = *(char **)(param_1 + 8);
    cStack_11 = *(char *)ppppppcVar7 + -1;
    if (pcVar9 <= pcVar10) {
      do {
        if (cStack_11 == '\0') {
          if (*pcVar10 != cStack_13) goto LAB_009d74c1;
          if (pcVar9 == pcVar10) goto LAB_009d74b9;
          bVar1 = bStack_12 + 1;
          if (iStack_18 - 1U <= (uint)bStack_12) {
            bVar1 = bStack_12;
          }
          ppppppcVar7 = apppppcStack_38;
          if (0xf < uStack_24) {
            ppppppcVar7 = (char ******)apppppcStack_38[0];
          }
          bStack_12 = bVar1;
          cStack_11 = *(char *)((int)ppppppcVar7 + (uint)bVar1);
        }
        else {
          cVar3 = FUN_009d7fe0();
          if (cVar3 == '\0') {
LAB_009d74b9:
            uVar4 = 0;
            goto LAB_009d74ca;
          }
          pcVar10 = *(char **)(param_1 + 0xc);
          cStack_11 = cStack_11 + -1;
        }
        pcVar10 = pcVar10 + -1;
        *(char **)(param_1 + 0xc) = pcVar10;
        pcVar9 = *(char **)(param_1 + 8);
      } while (pcVar9 <= pcVar10);
    }
    uVar4 = 1;
  }
LAB_009d74ca:
  FUN_005507b0();
  piVar5 = piStack_1c;
LAB_009d74d5:
  uStack_8 = 3;
  if ((piVar5 != (int *)0x0) &&
     (puVar8 = (undefined4 *)(**(code **)(*piVar5 + 8))(), puVar8 != (undefined4 *)0x0)) {
    (**(code **)*puVar8)(1);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 19116 ; VA 0x009d7520 ; FUN_009d7520 */

undefined __fastcall FUN_009d7520(int param_1)

{
  byte bVar1;
  void *pvVar2;
  char cVar3;
  undefined uVar4;
  int *piVar5;
  undefined4 uVar6;
  char ******ppppppcVar7;
  undefined4 *puVar8;
  char *pcVar9;
  char *pcVar10;
  char *****apppppcStack_38 [4];
  int iStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  char cStack_13;
  byte bStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar2 = ExceptionList;
  puStack_c = &LAB_017d64a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -1;
  **(undefined4 **)(param_1 + 8) = 0;
  if (*(char **)(param_1 + 0x10) < *(char **)(param_1 + 0xc)) {
    ExceptionList = pvVar2;
    return 0;
  }
  cVar3 = **(char **)(param_1 + 0x10);
  if (cVar3 < '0') {
    ExceptionList = pvVar2;
    return 0;
  }
  if ('9' < cVar3) {
    ExceptionList = pvVar2;
    return 0;
  }
  **(int **)(param_1 + 8) = cVar3 + -0x30;
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -1;
  uStack_8 = 0;
  piVar5 = (int *)FUN_016de181(1);
  uStack_8 = 1;
  piStack_1c = piVar5;
  uVar6 = FUN_016de368();
  cVar3 = FUN_00637e00(uVar6);
  if (cVar3 != '\0') {
    uVar4 = FUN_009d82a0();
    goto LAB_009d76a3;
  }
  piVar5 = (int *)FUN_00564bf0(auStack_20);
  (**(code **)(*piVar5 + 0x14))(apppppcStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iStack_18 = iStack_28;
  if (iStack_28 == 0) {
LAB_009d768f:
    uVar4 = FUN_009d82a0();
  }
  else {
    ppppppcVar7 = apppppcStack_38;
    if (0xf < uStack_24) {
      ppppppcVar7 = (char ******)apppppcStack_38[0];
    }
    if (*(char *)ppppppcVar7 < '\x01') goto LAB_009d768f;
    bStack_12 = 0;
    cStack_13 = (**(code **)(*piVar5 + 0x10))();
    pcVar10 = *(char **)(param_1 + 0x10);
    ppppppcVar7 = apppppcStack_38;
    if (0xf < uStack_24) {
      ppppppcVar7 = (char ******)apppppcStack_38[0];
    }
    pcVar9 = *(char **)(param_1 + 0xc);
    cStack_11 = *(char *)ppppppcVar7 + -1;
    if (pcVar9 <= pcVar10) {
      do {
        if (cStack_11 == '\0') {
          if (*pcVar10 != cStack_13) goto LAB_009d768f;
          if (pcVar9 == pcVar10) goto LAB_009d7687;
          bVar1 = bStack_12 + 1;
          if (iStack_18 - 1U <= (uint)bStack_12) {
            bVar1 = bStack_12;
          }
          ppppppcVar7 = apppppcStack_38;
          if (0xf < uStack_24) {
            ppppppcVar7 = (char ******)apppppcStack_38[0];
          }
          bStack_12 = bVar1;
          cStack_11 = *(char *)((int)ppppppcVar7 + (uint)bVar1);
        }
        else {
          cVar3 = FUN_009d8080();
          if (cVar3 == '\0') {
LAB_009d7687:
            uVar4 = 0;
            goto LAB_009d7698;
          }
          pcVar10 = *(char **)(param_1 + 0x10);
          cStack_11 = cStack_11 + -1;
        }
        pcVar10 = pcVar10 + -1;
        *(char **)(param_1 + 0x10) = pcVar10;
        pcVar9 = *(char **)(param_1 + 0xc);
      } while (pcVar9 <= pcVar10);
    }
    uVar4 = 1;
  }
LAB_009d7698:
  FUN_005507b0();
  piVar5 = piStack_1c;
LAB_009d76a3:
  uStack_8 = 3;
  if ((piVar5 != (int *)0x0) &&
     (puVar8 = (undefined4 *)(**(code **)(*piVar5 + 8))(), puVar8 != (undefined4 *)0x0)) {
    (**(code **)*puVar8)(1);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 19117 ; VA 0x009d76f0 ; FUN_009d76f0 */

undefined __fastcall FUN_009d76f0(int param_1)

{
  byte bVar1;
  void *pvVar2;
  char cVar3;
  undefined uVar4;
  int *piVar5;
  undefined4 uVar6;
  char ******ppppppcVar7;
  undefined4 *puVar8;
  char *pcVar9;
  char *pcVar10;
  char *****apppppcStack_38 [4];
  int iStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  char cStack_13;
  byte bStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar2 = ExceptionList;
  puStack_c = &LAB_017d64a0;
  pvStack_10 = ExceptionList;
  puVar8 = *(undefined4 **)(param_1 + 0x10);
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + -1;
  *puVar8 = 0;
  puVar8[1] = 0;
  if (*(char **)(param_1 + 0x18) < *(char **)(param_1 + 0x14)) {
    ExceptionList = pvVar2;
    return 0;
  }
  cVar3 = **(char **)(param_1 + 0x18);
  if (cVar3 < '0') {
    ExceptionList = pvVar2;
    return 0;
  }
  if ('9' < cVar3) {
    ExceptionList = pvVar2;
    return 0;
  }
  piVar5 = *(int **)(param_1 + 0x10);
  *piVar5 = cVar3 + -0x30;
  piVar5[1] = cVar3 + -0x30 >> 0x1f;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + -1;
  uStack_8 = 0;
  piVar5 = (int *)FUN_016de181(1);
  uStack_8 = 1;
  piStack_1c = piVar5;
  uVar6 = FUN_016de368();
  cVar3 = FUN_00637e00(uVar6);
  if (cVar3 != '\0') {
    uVar4 = FUN_009d8330();
    goto LAB_009d787f;
  }
  piVar5 = (int *)FUN_00564bf0(auStack_20);
  (**(code **)(*piVar5 + 0x14))(apppppcStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iStack_18 = iStack_28;
  if (iStack_28 == 0) {
LAB_009d786b:
    uVar4 = FUN_009d8330();
  }
  else {
    ppppppcVar7 = apppppcStack_38;
    if (0xf < uStack_24) {
      ppppppcVar7 = (char ******)apppppcStack_38[0];
    }
    if (*(char *)ppppppcVar7 < '\x01') goto LAB_009d786b;
    bStack_12 = 0;
    cStack_13 = (**(code **)(*piVar5 + 0x10))();
    pcVar10 = *(char **)(param_1 + 0x18);
    ppppppcVar7 = apppppcStack_38;
    if (0xf < uStack_24) {
      ppppppcVar7 = (char ******)apppppcStack_38[0];
    }
    pcVar9 = *(char **)(param_1 + 0x14);
    cStack_11 = *(char *)ppppppcVar7 + -1;
    if (pcVar9 <= pcVar10) {
      do {
        if (cStack_11 == '\0') {
          if (*pcVar10 != cStack_13) goto LAB_009d786b;
          if (pcVar9 == pcVar10) goto LAB_009d7863;
          bVar1 = bStack_12 + 1;
          if (iStack_18 - 1U <= (uint)bStack_12) {
            bVar1 = bStack_12;
          }
          ppppppcVar7 = apppppcStack_38;
          if (0xf < uStack_24) {
            ppppppcVar7 = (char ******)apppppcStack_38[0];
          }
          bStack_12 = bVar1;
          cStack_11 = *(char *)((int)ppppppcVar7 + (uint)bVar1);
        }
        else {
          cVar3 = FUN_009d8100();
          if (cVar3 == '\0') {
LAB_009d7863:
            uVar4 = 0;
            goto LAB_009d7874;
          }
          pcVar10 = *(char **)(param_1 + 0x18);
          cStack_11 = cStack_11 + -1;
        }
        pcVar10 = pcVar10 + -1;
        *(char **)(param_1 + 0x18) = pcVar10;
        pcVar9 = *(char **)(param_1 + 0x14);
      } while (pcVar9 <= pcVar10);
    }
    uVar4 = 1;
  }
LAB_009d7874:
  FUN_005507b0();
  piVar5 = piStack_1c;
LAB_009d787f:
  uStack_8 = 3;
  if ((piVar5 != (int *)0x0) &&
     (puVar8 = (undefined4 *)(**(code **)(*piVar5 + 8))(), puVar8 != (undefined4 *)0x0)) {
    (**(code **)*puVar8)(1);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 19118 ; VA 0x009d78d0 ; FUN_009d78d0 */

undefined4 * FUN_009d78d0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_005c2ba0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 19119 ; VA 0x009d7940 ; FUN_009d7940 */

undefined __thiscall FUN_009d7940(int param_1,int param_2,int param_3)

{
  float *pfVar1;
  float fVar2;
  int iVar3;
  
  iVar3 = *(int *)(param_1 + 8);
  if ((((NAN(*(float *)(iVar3 + param_2)) || NAN(*(float *)(iVar3 + param_3))) !=
        (*(float *)(iVar3 + param_2) == *(float *)(iVar3 + param_3))) &&
      (fVar2 = *(float *)(iVar3 + 4 + param_2), pfVar1 = (float *)(iVar3 + 4 + param_3),
      (NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1))) &&
     (fVar2 = *(float *)(iVar3 + 8 + param_2), pfVar1 = (float *)(iVar3 + 8 + param_3),
     (NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 19120 ; VA 0x009d7990 ; FUN_009d7990 */

int __fastcall FUN_009d7990(int param_1)

{
  float *pfVar1;
  float fVar2;
  uint3 uVar3;
  float *pfVar4;
  float *pfVar5;
  int iVar6;
  undefined2 uVar7;
  
  pfVar4 = (float *)(**(code **)(param_1 + 8))();
  pfVar5 = (float *)(**(code **)(param_1 + 8))();
  fVar2 = *pfVar4;
  uVar7 = (undefined2)((uint)pfVar5 >> 0x10);
  iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                               fVar2 < *pfVar5) << 8;
  if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
    fVar2 = pfVar4[1];
    pfVar1 = pfVar5 + 1;
    iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                                 fVar2 < *pfVar1) << 8;
    if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
      fVar2 = pfVar4[2];
      pfVar5 = pfVar5 + 2;
      uVar3 = CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                             fVar2 < *pfVar5);
      iVar6 = (uint)uVar3 << 8;
      if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
        return CONCAT31(uVar3,1);
      }
    }
  }
  return iVar6;
}



/* FUNCTION 19121 ; VA 0x009d79f0 ; FUN_009d79f0 */

void __thiscall FUN_009d79f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined auStack_10 [12];
  
  uVar1 = (**(code **)(param_1 + 0x38))(auStack_10);
  FUN_009d5a70(param_3,uVar1);
  return;
}



/* FUNCTION 19122 ; VA 0x009d7a20 ; FUN_009d7a20 */

void __thiscall FUN_009d7a20(int param_1,undefined4 param_2,undefined4 param_3)

{
  float10 fVar1;
  
  fVar1 = (float10)(**(code **)(param_1 + 0x38))();
  FUN_009d5680(param_3,(float)fVar1);
  return;
}



/* FUNCTION 19123 ; VA 0x009d7a60 ; FUN_009d7a60 */

void __thiscall FUN_009d7a60(int param_1,undefined4 param_2,undefined4 param_3)

{
  float10 fVar1;
  
  fVar1 = (float10)(**(code **)(param_1 + 0x38))();
  FUN_009d56b0(param_3,(double)fVar1);
  return;
}



/* FUNCTION 19124 ; VA 0x009d7ab0 ; FUN_009d7ab0 */

void FUN_009d7ab0(void)

{
  FUN_005e6780();
  return;
}



/* FUNCTION 19125 ; VA 0x009d7ac0 ; FUN_009d7ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 __fastcall FUN_009d7ac0(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_016f3900(*(undefined4 *)(param_1 + 0xe0),*(undefined4 *)(param_1 + 0xe4),1000000,0);
  return (float10)((float)iVar1 / _DAT_0193ab38);
}



/* FUNCTION 19126 ; VA 0x009d7b30 ; FUN_009d7b30 */

float10 __fastcall FUN_009d7b30(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_016f3900(*(undefined4 *)(param_1 + 0xe0),*(undefined4 *)(param_1 + 0xe4),1000000,0);
  return (float10)iVar1;
}



/* FUNCTION 19127 ; VA 0x009d7b60 ; FUN_009d7b60 */

float10 __fastcall FUN_009d7b60(int param_1)

{
  return (float10)*(float *)(param_1 + 0x98);
}



/* FUNCTION 19128 ; VA 0x009d7b90 ; FUN_009d7b90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 __fastcall FUN_009d7b90(int param_1)

{
  double in_XMM0_Qa;
  
  FUN_016f3900(*(undefined4 *)(param_1 + 0xe0),*(undefined4 *)(param_1 + 0xe4),1000,0);
  FUN_016f4020();
  return (float10)(in_XMM0_Qa / _DAT_0193ab30);
}



/* FUNCTION 19129 ; VA 0x009d7be0 ; FUN_009d7be0 */

void __thiscall FUN_009d7be0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x94);
  *param_2 = *(undefined8 *)(param_1 + 0x8c);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 19130 ; VA 0x009d7c00 ; FUN_009d7c00 */

int __fastcall FUN_009d7c00(int param_1)

{
  return param_1 + 0xbc;
}



/* FUNCTION 19131 ; VA 0x009d7c10 ; FUN_009d7c10 */

void __thiscall FUN_009d7c10(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x88);
  *param_2 = *(undefined8 *)(param_1 + 0x80);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 19132 ; VA 0x009d7c30 ; FUN_009d7c30 */

int __fastcall FUN_009d7c30(int param_1)

{
  int iVar1;
  
  if (DAT_01d653fc != '\0') {
    return 4;
  }
  if (DAT_01d653f4 != '\0') {
    return 3;
  }
  if (DAT_01d653ec != '\0') {
    return 1;
  }
  iVar1 = *(int *)(param_1 + 0x134);
  if (iVar1 == 0) {
    iVar1 = 2;
  }
  return iVar1;
}



/* FUNCTION 19133 ; VA 0x009d7c70 ; FUN_009d7c70 */

undefined4 __thiscall FUN_009d7c70(int param_1,undefined4 param_2)

{
  FUN_008710d0(param_2,*(undefined4 *)(param_1 + 0xe0),*(undefined4 *)(param_1 + 0xe4),param_1);
  return param_2;
}



/* FUNCTION 19134 ; VA 0x009d7ca0 ; FUN_009d7ca0 */

void __thiscall FUN_009d7ca0(int param_1,undefined8 *param_2,int param_3)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)(*(int *)(param_1 + 8) + param_3);
  uVar1 = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 19135 ; VA 0x009d7cc0 ; FUN_009d7cc0 */

undefined8 * __thiscall FUN_009d7cc0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)(**(code **)(param_1 + 8))();
  uVar1 = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return param_2;
}



/* FUNCTION 19136 ; VA 0x009d7cf0 ; FUN_009d7cf0 */

void __thiscall FUN_009d7cf0(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar3 = (**(code **)(*param_1 + 0x44))(param_2);
  uVar4 = FUN_0088c8c0();
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar4;
  if (*(int *)(iVar1 + 0x34) < DAT_01ea8c18) {
    FUN_016f3809(&DAT_01ea8c18);
    if (DAT_01ea8c18 == -1) {
      DAT_01ea8c0c = FUN_005c65e0;
      DAT_01ea8c10 = FUN_005c65e0;
      DAT_01ea8c14 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c18);
    }
  }
  puVar2 = (undefined4 *)param_3[1];
  if ((code **)puVar2 == &DAT_01ea8c0c) {
    param_3[2] = uVar3;
    return;
  }
  if (puVar2 != (undefined4 *)0x0) {
    (*(code *)puVar2[2])(param_3 + 2);
  }
  param_3[2] = uVar3;
  param_3[1] = &DAT_01ea8c0c;
  return;
}



/* FUNCTION 19137 ; VA 0x009d7da0 ; FUN_009d7da0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_009d7da0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined8 *puVar3;
  undefined4 uVar4;
  undefined auStack_10 [12];
  
  puVar3 = (undefined8 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_10,param_2);
  uVar4 = FUN_0088d050();
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar4;
  if (*(int *)(iVar1 + 0x34) < DAT_01ea8c08) {
    FUN_016f3809(&DAT_01ea8c08);
    if (DAT_01ea8c08 == -1) {
      _DAT_01ea8bfc = FUN_005c6600;
      _DAT_01ea8c00 = FUN_005c6600;
      DAT_01ea8c04 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c08);
    }
  }
  puVar2 = (undefined *)param_3[1];
  if (puVar2 == &DAT_01ea8bfc) {
    param_3[2] = *(undefined4 *)puVar3;
    param_3[3] = *(undefined4 *)((int)puVar3 + 4);
    param_3[4] = *(undefined4 *)(puVar3 + 1);
    return;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  *(undefined8 *)(param_3 + 2) = *puVar3;
  param_3[4] = *(undefined4 *)(puVar3 + 1);
  param_3[1] = &DAT_01ea8bfc;
  return;
}



/* FUNCTION 19138 ; VA 0x009d7e80 ; FUN_009d7e80 */

void __thiscall FUN_009d7e80(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00712f70();
  *param_3 = uVar3;
  iVar4 = FUN_00713000();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 19139 ; VA 0x009d7ee0 ; FUN_009d7ee0 */

bool FUN_009d7ee0(int param_1)

{
  return param_1 == 4;
}



/* FUNCTION 19140 ; VA 0x009d7ef0 ; FUN_009d7ef0 */

undefined4 FUN_009d7ef0(int param_1)

{
  if (((param_1 != 3) && (param_1 != 1)) && (param_1 != 4)) {
    return 0;
  }
  return 1;
}



/* FUNCTION 19141 ; VA 0x009d7f10 ; FUN_009d7f10 */

undefined4 __thiscall FUN_009d7f10(int param_1,undefined *param_2)

{
  int iVar1;
  
  if (((((param_2 != &DAT_02124650) || (DAT_01d653fc != '\0')) || (DAT_01d653f4 != '\0')) ||
      (((DAT_01d653ec == '\0' && (iVar1 = *(int *)(param_1 + 0x134), iVar1 != 0)) &&
       ((iVar1 == 3 || (iVar1 == 4)))))) &&
     ((((param_2 != &DAT_021245a8 && (param_2 != &DAT_021245e0)) && (param_2 != &DAT_02124570)) ||
      ((*(int *)(param_1 + 0x144) == 0 || (*(int *)(param_1 + 0x13c) == 0)))))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 19142 ; VA 0x009d7f80 ; FUN_009d7f80 */

uint FUN_009d7f80(void)

{
  int iVar1;
  
  iVar1 = FUN_009d5f50();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 19143 ; VA 0x009d7fa0 ; FUN_009d7fa0 */

uint FUN_009d7fa0(void)

{
  int iVar1;
  
  iVar1 = FUN_009d5f50();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 19144 ; VA 0x009d7fc0 ; FUN_009d7fc0 */

undefined4 FUN_009d7fc0(int param_1)

{
  if ((param_1 != 3) && (param_1 != 4)) {
    return 0;
  }
  return 1;
}



/* FUNCTION 19145 ; VA 0x009d7fe0 ; FUN_009d7fe0 */

uint __fastcall FUN_009d7fe0(char *param_1)

{
  char cVar1;
  short *psVar2;
  ulonglong uVar3;
  ushort uVar4;
  ushort uVar5;
  ushort *puVar6;
  char cVar7;
  
  if ((*param_1 == '\0') && (*(ushort *)(param_1 + 2) < 0x199a)) {
    cVar7 = '\0';
  }
  else {
    cVar7 = '\x01';
  }
  *param_1 = cVar7;
  uVar4 = *(ushort *)(param_1 + 2) * 10;
  *(ushort *)(param_1 + 2) = uVar4;
  cVar1 = **(char **)(param_1 + 0xc);
  uVar5 = (short)cVar1 - 0x30;
  puVar6 = (ushort *)(uint)uVar5;
  if ((('/' < cVar1) && (cVar1 < ':')) &&
     ((uVar5 == 0 ||
      (((cVar7 == '\0' &&
        (uVar3 = ZEXT48(puVar6), puVar6 = (ushort *)(0xffff / uVar3),
        uVar4 <= (ushort)(0xffff / uVar3))) &&
       (puVar6 = *(ushort **)(param_1 + 4), *puVar6 <= (ushort)~(uVar4 * uVar5))))))) {
    psVar2 = *(short **)(param_1 + 4);
    *psVar2 = *psVar2 + uVar4 * uVar5;
    return CONCAT31((int3)((uint)psVar2 >> 8),1);
  }
  return (uint)puVar6 & 0xffffff00;
}



/* FUNCTION 19146 ; VA 0x009d8080 ; FUN_009d8080 */

uint __fastcall FUN_009d8080(char *param_1)

{
  char cVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  char cVar5;
  uint uVar6;
  
  if ((*param_1 == '\0') && (*(uint *)(param_1 + 4) < 0x1999999a)) {
    cVar5 = '\0';
  }
  else {
    cVar5 = '\x01';
  }
  *param_1 = cVar5;
  uVar3 = *(uint *)(param_1 + 4) * 10;
  *(uint *)(param_1 + 4) = uVar3;
  cVar1 = **(char **)(param_1 + 0x10);
  uVar4 = CONCAT31((int3)((uint)*(char **)(param_1 + 0x10) >> 8),cVar1);
  uVar6 = (int)cVar1 - 0x30;
  if ((('/' < cVar1) && (cVar1 < ':')) &&
     ((uVar6 == 0 ||
      (((cVar5 == '\0' && (uVar4 = (uint)(0xffffffff / (ulonglong)uVar6), uVar3 <= uVar4)) &&
       (uVar4 = ~(uVar3 * uVar6), **(uint **)(param_1 + 8) <= uVar4)))))) {
    piVar2 = *(int **)(param_1 + 8);
    *piVar2 = *piVar2 + uVar3 * uVar6;
    return CONCAT31((int3)((uint)piVar2 >> 8),1);
  }
  return uVar4 & 0xffffff00;
}



/* FUNCTION 19147 ; VA 0x009d8100 ; FUN_009d8100 */

/* WARNING: Removing unreachable block (ram,0x009d81a2) */

uint __fastcall FUN_009d8100(char *param_1)

{
  char cVar1;
  uint *puVar2;
  int iVar3;
  char cVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  undefined8 uVar11;
  ulonglong uVar12;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar6 = *(uint *)(param_1 + 0xc);
  if (((*param_1 == '\0') && (uVar6 < 0x1999999a)) && ((uVar6 < 0x19999999 || (uVar5 < 0x9999999a)))
     ) {
    cVar4 = '\0';
  }
  else {
    cVar4 = '\x01';
  }
  *param_1 = cVar4;
  uVar10 = (uVar6 + (uVar6 << 2 | uVar5 >> 0x1e) + (uint)CARRY4(uVar5,uVar5 * 4)) * 2 |
           uVar5 * 5 >> 0x1f;
  iVar3 = uVar5 * 10;
  *(uint *)(param_1 + 0xc) = uVar10;
  *(int *)(param_1 + 8) = iVar3;
  cVar1 = **(char **)(param_1 + 0x18);
  uVar5 = (int)cVar1 - 0x30;
  uVar8 = (int)uVar5 >> 0x1f;
  uVar11 = FUN_016f39b0(iVar3,uVar10,uVar5,uVar8);
  uVar9 = (uint)((ulonglong)uVar11 >> 0x20);
  uVar6 = (uint)uVar11;
  uVar7 = CONCAT31((int3)((ulonglong)uVar11 >> 8),cVar1);
  if (('/' < cVar1) && (cVar1 < ':')) {
    uVar7 = uVar5 | uVar8;
    if (uVar7 == 0) {
LAB_009d81d1:
      puVar2 = *(uint **)(param_1 + 0x10);
      uVar5 = *puVar2;
      *puVar2 = *puVar2 + uVar6;
      puVar2[1] = puVar2[1] + uVar9 + (uint)CARRY4(uVar5,uVar6);
      return CONCAT31((int3)((uint)puVar2 >> 8),1);
    }
    if (cVar4 == '\0') {
      uVar12 = FUN_016f3c60(0xffffffff,0xffffffff,uVar5,uVar8);
      uVar7 = (uint)uVar12;
      if (CONCAT44(uVar10,iVar3) <= uVar12) {
        uVar7 = ~uVar9;
        uVar5 = (*(uint **)(param_1 + 0x10))[1];
        if ((uVar5 <= uVar7) && ((uVar5 < uVar7 || (**(uint **)(param_1 + 0x10) <= ~uVar6))))
        goto LAB_009d81d1;
      }
    }
  }
  return uVar7 & 0xffffff00;
}



/* FUNCTION 19148 ; VA 0x009d81f0 ; FUN_009d81f0 */

uint __fastcall FUN_009d81f0(char *param_1)

{
  char cVar1;
  ulonglong uVar2;
  ushort uVar3;
  ushort uVar4;
  ushort *puVar5;
  char *pcVar6;
  char cVar7;
  
  pcVar6 = *(char **)(param_1 + 0xc);
  while( true ) {
    if (pcVar6 < *(char **)(param_1 + 8)) {
      return CONCAT31((int3)((uint)pcVar6 >> 8),1);
    }
    if ((*param_1 == '\0') && (*(ushort *)(param_1 + 2) < 0x199a)) {
      cVar7 = '\0';
    }
    else {
      cVar7 = '\x01';
    }
    *param_1 = cVar7;
    uVar3 = *(ushort *)(param_1 + 2) * 10;
    *(ushort *)(param_1 + 2) = uVar3;
    cVar1 = *pcVar6;
    uVar4 = (short)cVar1 - 0x30;
    puVar5 = (ushort *)(uint)uVar4;
    if (((cVar1 < '0') || ('9' < cVar1)) ||
       ((uVar4 != 0 &&
        (((cVar7 != '\0' ||
          (uVar2 = ZEXT48(puVar5), puVar5 = (ushort *)(0xffff / uVar2),
          (ushort)(0xffff / uVar2) < uVar3)) ||
         (puVar5 = *(ushort **)(param_1 + 4), (ushort)~(uVar3 * uVar4) < *puVar5)))))) break;
    **(short **)(param_1 + 4) = **(short **)(param_1 + 4) + uVar3 * uVar4;
    pcVar6 = (char *)(*(int *)(param_1 + 0xc) + -1);
    *(char **)(param_1 + 0xc) = pcVar6;
  }
  return (uint)puVar5 & 0xffffff00;
}



/* FUNCTION 19149 ; VA 0x009d82a0 ; FUN_009d82a0 */

uint __fastcall FUN_009d82a0(char *param_1)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  char *pcVar4;
  char cVar5;
  uint uVar6;
  
  pcVar4 = *(char **)(param_1 + 0x10);
  if (*(char **)(param_1 + 0xc) <= pcVar4) {
    do {
      if ((*param_1 == '\0') && (*(uint *)(param_1 + 4) < 0x1999999a)) {
        cVar5 = '\0';
      }
      else {
        cVar5 = '\x01';
      }
      *param_1 = cVar5;
      uVar2 = *(uint *)(param_1 + 4) * 10;
      *(uint *)(param_1 + 4) = uVar2;
      cVar1 = *pcVar4;
      uVar3 = CONCAT31((int3)((uint)pcVar4 >> 8),cVar1);
      uVar6 = (int)cVar1 - 0x30;
      if (((cVar1 < '0') || ('9' < cVar1)) ||
         ((uVar6 != 0 &&
          (((cVar5 != '\0' || (uVar3 = (uint)(0xffffffff / (ulonglong)uVar6), uVar3 < uVar2)) ||
           (uVar3 = ~(uVar2 * uVar6), uVar3 < **(uint **)(param_1 + 8))))))) {
        return uVar3 & 0xffffff00;
      }
      **(int **)(param_1 + 8) = **(int **)(param_1 + 8) + uVar2 * uVar6;
      pcVar4 = (char *)(*(int *)(param_1 + 0x10) + -1);
      *(char **)(param_1 + 0x10) = pcVar4;
    } while (*(char **)(param_1 + 0xc) <= pcVar4);
  }
  return CONCAT31((int3)((uint)pcVar4 >> 8),1);
}



/* FUNCTION 19150 ; VA 0x009d8330 ; FUN_009d8330 */

/* WARNING: Removing unreachable block (ram,0x009d83db) */

undefined4 __fastcall FUN_009d8330(char *param_1)

{
  char cVar1;
  uint *puVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  char *pcVar8;
  uint uVar9;
  uint uVar10;
  undefined8 uVar11;
  ulonglong uVar12;
  
  pcVar8 = *(char **)(param_1 + 0x18);
  if (*(char **)(param_1 + 0x14) <= pcVar8) {
    do {
      uVar6 = *(uint *)(param_1 + 8);
      uVar9 = *(uint *)(param_1 + 0xc);
      if (((*param_1 == '\0') && (uVar9 < 0x1999999a)) &&
         ((uVar9 < 0x19999999 || (uVar6 < 0x9999999a)))) {
        cVar4 = '\0';
      }
      else {
        cVar4 = '\x01';
      }
      *param_1 = cVar4;
      uVar10 = (uVar9 + (uVar9 << 2 | uVar6 >> 0x1e) + (uint)CARRY4(uVar6,uVar6 * 4)) * 2 |
               uVar6 * 5 >> 0x1f;
      iVar3 = uVar6 * 10;
      *(uint *)(param_1 + 0xc) = uVar10;
      *(int *)(param_1 + 8) = iVar3;
      cVar1 = *pcVar8;
      iVar5 = cVar1 + -0x30;
      uVar11 = FUN_016f39b0(iVar3,uVar10,iVar5,iVar5 >> 0x1f);
      uVar9 = (uint)((ulonglong)uVar11 >> 0x20);
      uVar6 = (uint)uVar11;
      if (cVar1 < '0') {
        return 0;
      }
      if ('9' < cVar1) {
        return 0;
      }
      if (iVar5 != 0) {
        if ((cVar4 != '\0') ||
           (uVar12 = FUN_016f3c60(0xffffffff,0xffffffff,iVar5,iVar5 >> 0x1f),
           uVar12 < CONCAT44(uVar10,iVar3))) {
          return 0;
        }
        uVar7 = ~uVar9;
        uVar10 = (*(uint **)(param_1 + 0x10))[1];
        if (uVar7 < uVar10) {
          return 0;
        }
        if ((uVar7 <= uVar10) && (~uVar6 < **(uint **)(param_1 + 0x10))) {
          return 0;
        }
      }
      puVar2 = *(uint **)(param_1 + 0x10);
      uVar10 = *puVar2;
      *puVar2 = *puVar2 + uVar6;
      puVar2[1] = puVar2[1] + uVar9 + (uint)CARRY4(uVar10,uVar6);
      pcVar8 = (char *)(*(int *)(param_1 + 0x18) - 1);
      *(char **)(param_1 + 0x18) = pcVar8;
    } while (*(char **)(param_1 + 0x14) <= pcVar8);
  }
  return 1;
}



/* FUNCTION 19151 ; VA 0x009d8430 ; FUN_009d8430 */

void __thiscall FUN_009d8430(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_2 == 0) {
    return;
  }
  iVar1 = *(int *)(param_2 + 0xc);
  iVar5 = FUN_00d6abe0();
  if ((uint)*(ushort *)(iVar5 + 0x1da) <
      (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar5 = FUN_00e6e130();
    if ((uint)*(ushort *)(iVar5 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
      return;
    }
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x144) = uVar2;
    piVar4 = *(int **)(param_1 + 0x148);
    *(undefined4 *)(param_1 + 0x148) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar1 = piVar4[1] + -1;
      piVar4[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar1 = piVar4[2] + -1;
        piVar4[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar4 = piStack_8 + 2;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0x13c) == 0) {
      return;
    }
  }
  else {
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x13c) = uVar2;
    piVar4 = *(int **)(param_1 + 0x140);
    *(undefined4 *)(param_1 + 0x140) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar1 = piVar4[1] + -1;
      piVar4[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar1 = piVar4[2] + -1;
        piVar4[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar4 = piStack_8 + 2;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  FUN_005e6780(1);
  return;
}



/* FUNCTION 19152 ; VA 0x009d85c0 ; FUN_009d85c0 */

void __thiscall FUN_009d85c0(int param_1,int param_2,undefined4 param_3)

{
  FUN_008a40d0(param_2,param_3);
  if (*(int *)(param_1 + 0x13c) == param_2) {
    FUN_005e6780(1);
  }
  return;
}



/* FUNCTION 19153 ; VA 0x009d85f0 ; FUN_009d85f0 */

void __thiscall FUN_009d85f0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (*(int *)(param_1 + 0x13c) == param_2) {
    *(undefined4 *)(param_1 + 0x13c) = 0;
    piVar3 = *(int **)(param_1 + 0x140);
    *(undefined4 *)(param_1 + 0x140) = 0;
  }
  else {
    if (*(int *)(param_1 + 0x144) != param_2) {
      return;
    }
    *(undefined4 *)(param_1 + 0x144) = 0;
    piVar3 = *(int **)(param_1 + 0x148);
    *(undefined4 *)(param_1 + 0x148) = 0;
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_005e6780(1);
  return;
}



/* FUNCTION 19154 ; VA 0x009d8690 ; FUN_009d8690 */

void __thiscall FUN_009d8690(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0xb8))) == (param_2 == *(float *)(param_1 + 0xb8)))
  {
    *(float *)(param_1 + 0xb8) = param_2;
    FUN_005e6780();
    return;
  }
  return;
}



/* FUNCTION 19155 ; VA 0x009d86d0 ; FUN_009d86d0 */

void __thiscall FUN_009d86d0(int param_1,float *param_2)

{
  float fVar1;
  
  fVar1 = *param_2;
  if ((((NAN(fVar1) || NAN(*(float *)(param_1 + 0xac))) != (fVar1 == *(float *)(param_1 + 0xac))) &&
      ((NAN(param_2[1]) || NAN(*(float *)(param_1 + 0xb0))) !=
       (param_2[1] == *(float *)(param_1 + 0xb0)))) &&
     ((NAN(param_2[2]) || NAN(*(float *)(param_1 + 0xb4))) !=
      (param_2[2] == *(float *)(param_1 + 0xb4)))) {
    return;
  }
  *(float *)(param_1 + 0xac) = fVar1;
  *(float *)(param_1 + 0xb0) = param_2[1];
  *(float *)(param_1 + 0xb4) = param_2[2];
  FUN_005e6780();
  return;
}



/* FUNCTION 19156 ; VA 0x009d8740 ; FUN_009d8740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_009d8740(float param_1)

{
  longlong lVar1;
  uint uVar2;
  int iVar3;
  float fVar4;
  float fVar5;
  undefined8 uVar6;
  longlong lStack_10;
  
  fVar4 = 0.0;
  if (0.0 <= param_1) {
    fVar4 = param_1;
  }
  fVar5 = DAT_01919034;
  if (fVar4 <= DAT_01919034) {
    fVar5 = fVar4;
  }
  uVar2 = (uint)(fVar5 * _DAT_0193ab38);
  if ((int)uVar2 < 0) {
    lVar1 = (longlong)(int)((uVar2 ^ (int)uVar2 >> 0x1f) - ((int)uVar2 >> 0x1f)) * 1000000;
    iVar3 = (int)lVar1;
    uVar2 = -iVar3;
    uVar6 = FUN_016f39b0(0,1000000,0);
    lStack_10 = CONCAT44((-(int)((ulonglong)uVar6 >> 0x20) -
                         ((int)((ulonglong)lVar1 >> 0x20) + (uint)(iVar3 != 0))) -
                         (uint)(uVar2 < (uint)uVar6),uVar2 - (uint)uVar6);
  }
  else {
    lStack_10 = FUN_016f39b0(0,1000000,0);
    lStack_10 = (longlong)(int)uVar2 * 1000000 + lStack_10;
  }
  FUN_009d8cb0(&lStack_10);
  return;
}



/* FUNCTION 19157 ; VA 0x009d8810 ; FUN_009d8810 */

void __thiscall FUN_009d8810(int param_1,float param_2)

{
  if ((NAN(*(float *)(param_1 + 0x124)) || NAN(param_2)) == (*(float *)(param_1 + 0x124) == param_2)
     ) {
    *(float *)(param_1 + 0x124) = param_2;
    FUN_008a4940(&DAT_021246f8);
    FUN_005e6780(0);
  }
  return;
}



/* FUNCTION 19158 ; VA 0x009d8850 ; FUN_009d8850 */

void __thiscall FUN_009d8850(int param_1,float *param_2)

{
  float fVar1;
  
  fVar1 = *param_2;
  if ((((NAN(fVar1) || NAN(*(float *)(param_1 + 200))) != (fVar1 == *(float *)(param_1 + 200))) &&
      ((NAN(param_2[1]) || NAN(*(float *)(param_1 + 0xcc))) !=
       (param_2[1] == *(float *)(param_1 + 0xcc)))) &&
     ((NAN(param_2[2]) || NAN(*(float *)(param_1 + 0xd0))) !=
      (param_2[2] == *(float *)(param_1 + 0xd0)))) {
    return;
  }
  *(float *)(param_1 + 200) = fVar1;
  *(float *)(param_1 + 0xcc) = param_2[1];
  *(float *)(param_1 + 0xd0) = param_2[2];
  FUN_008a4940();
  return;
}



/* FUNCTION 19159 ; VA 0x009d88c0 ; FUN_009d88c0 */

void __thiscall FUN_009d88c0(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0xd8))) == (param_2 == *(float *)(param_1 + 0xd8)))
  {
    *(float *)(param_1 + 0xd8) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19160 ; VA 0x009d88f0 ; FUN_009d88f0 */

void __thiscall FUN_009d88f0(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0xd4))) == (param_2 == *(float *)(param_1 + 0xd4)))
  {
    *(float *)(param_1 + 0xd4) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19161 ; VA 0x009d8920 ; FUN_009d8920 */

void __thiscall FUN_009d8920(int param_1,float param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0x98))) == (param_2 == *(float *)(param_1 + 0x98)))
  {
    FUN_01167120(param_2);
    uVar2 = *(undefined4 *)(param_1 + 0x128);
    iVar1 = FUN_016f3900(*(undefined4 *)(param_1 + 0xe0),*(undefined4 *)(param_1 + 0xe4),1000000,0);
    FUN_01167140((double)iVar1,uVar2);
    FUN_008a4940(&DAT_02124330);
    FUN_005e6780(0);
  }
  return;
}



/* FUNCTION 19162 ; VA 0x009d89b0 ; FUN_009d89b0 */

void __thiscall FUN_009d89b0(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x11c)) {
    *(char *)(param_1 + 0x11c) = param_2;
    FUN_008a4940(&DAT_02124618);
    FUN_005e6780(0);
  }
  return;
}



/* FUNCTION 19163 ; VA 0x009d89f0 ; FUN_009d89f0 */

void __thiscall FUN_009d89f0(int param_1,float param_2)

{
  float fVar1;
  int iVar2;
  float fVar3;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar3 = DAT_018ce2f8;
  if (fVar1 <= DAT_018ce2f8) {
    fVar3 = fVar1;
  }
  if ((NAN(fVar3) || NAN(*(float *)(param_1 + 0x128))) == (fVar3 == *(float *)(param_1 + 0x128))) {
    *(float *)(param_1 + 0x128) = fVar3;
    iVar2 = FUN_016f3900(*(undefined4 *)(param_1 + 0xe0),*(undefined4 *)(param_1 + 0xe4),1000000,0);
    FUN_01167140((double)iVar2,fVar3);
    FUN_008a4940(&DAT_02124688);
    FUN_005e6780(0);
  }
  return;
}



/* FUNCTION 19164 ; VA 0x009d8a80 ; FUN_009d8a80 */

void __thiscall FUN_009d8a80(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = DAT_018ce2f8;
  if (fVar1 <= DAT_018ce2f8) {
    fVar2 = fVar1;
  }
  if ((NAN(fVar2) || NAN(*(float *)(param_1 + 300))) == (fVar2 == *(float *)(param_1 + 300))) {
    *(float *)(param_1 + 300) = fVar2;
    FUN_008a4940(&DAT_021246c0);
    FUN_005e6780(0);
  }
  return;
}



/* FUNCTION 19165 ; VA 0x009d8ad0 ; FUN_009d8ad0 */

void FUN_009d8ad0(double param_1)

{
  longlong lVar1;
  uint uVar2;
  int iVar3;
  undefined8 uVar4;
  
  uVar2 = (uint)(param_1 * DAT_018cf108);
  param_1._4_4_ = uVar2;
  if ((int)uVar2 < 0) {
    lVar1 = (longlong)(int)((uVar2 ^ (int)uVar2 >> 0x1f) - ((int)uVar2 >> 0x1f)) * 1000000;
    iVar3 = (int)lVar1;
    uVar2 = -iVar3;
    uVar4 = FUN_016f39b0(0,1000000,0);
    param_1 = (double)CONCAT44((-(int)((ulonglong)uVar4 >> 0x20) -
                               ((int)((ulonglong)lVar1 >> 0x20) + (uint)(iVar3 != 0))) -
                               (uint)(uVar2 < (uint)uVar4),uVar2 - (uint)uVar4);
  }
  else {
    lVar1 = FUN_016f39b0(0,1000000,0);
    param_1 = (double)((longlong)(int)param_1._4_4_ * 1000000 + lVar1);
  }
  FUN_009d8cb0(&param_1);
  return;
}



/* FUNCTION 19166 ; VA 0x009d8b90 ; FUN_009d8b90 */

void __thiscall FUN_009d8b90(int param_1,float *param_2)

{
  float fVar1;
  
  fVar1 = *param_2;
  if ((((NAN(fVar1) || NAN(*(float *)(param_1 + 0xbc))) == (fVar1 == *(float *)(param_1 + 0xbc))) ||
      ((NAN(param_2[1]) || NAN(*(float *)(param_1 + 0xc0))) ==
       (param_2[1] == *(float *)(param_1 + 0xc0)))) ||
     ((NAN(param_2[2]) || NAN(*(float *)(param_1 + 0xc4))) ==
      (param_2[2] == *(float *)(param_1 + 0xc4)))) {
    *(float *)(param_1 + 0xbc) = fVar1;
    *(float *)(param_1 + 0xc0) = param_2[1];
    *(float *)(param_1 + 0xc4) = param_2[2];
    FUN_008a4940(&DAT_02124538);
    FUN_005e6780(0);
  }
  return;
}



/* FUNCTION 19167 ; VA 0x009d8c10 ; FUN_009d8c10 */

void __thiscall FUN_009d8c10(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = DAT_018ce2f8;
  if (fVar1 <= DAT_018ce2f8) {
    fVar2 = fVar1;
  }
  if ((NAN(*(float *)(param_1 + 0x120)) || NAN(fVar2)) == (*(float *)(param_1 + 0x120) == fVar2)) {
    *(float *)(param_1 + 0x120) = fVar2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19168 ; VA 0x009d8c60 ; FUN_009d8c60 */

void __thiscall FUN_009d8c60(int param_1,int param_2)

{
  if ((*(int *)(param_1 + 0x134) != param_2) || (*(char *)(param_1 + 0x130) != '\0')) {
    *(int *)(param_1 + 0x134) = param_2;
    FUN_008a4940(&DAT_02124730);
    FUN_005e6780(0);
    *(undefined *)(param_1 + 0x130) = 0;
  }
  return;
}



/* FUNCTION 19169 ; VA 0x009d8cb0 ; FUN_009d8cb0 */

void __thiscall FUN_009d8cb0(int param_1,undefined4 *param_2)

{
  longlong lVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined8 uVar6;
  undefined4 uVar7;
  
  iVar2 = FUN_016f3900(*param_2,param_2[1],1000000,0);
  iVar4 = (int)((ulonglong)((longlong)iVar2 * 0x3dd1baf9) >> 0x20) - iVar2;
  uVar5 = iVar2 + ((iVar4 >> 0x10) - (iVar4 >> 0x1f)) * 0x15180;
  uVar3 = FUN_016f3900(*(undefined4 *)(param_1 + 0xe0),*(undefined4 *)(param_1 + 0xe4),1000000,0);
  if (uVar3 != uVar5) {
    if ((int)uVar5 < 0) {
      lVar1 = (longlong)(int)((uVar5 ^ (int)uVar5 >> 0x1f) - ((int)uVar5 >> 0x1f)) * 1000000;
      iVar2 = (int)lVar1;
      uVar3 = -iVar2;
      uVar6 = FUN_016f39b0(0,0,1000000,0);
      lVar1 = CONCAT44((-(int)((ulonglong)uVar6 >> 0x20) -
                       ((int)((ulonglong)lVar1 >> 0x20) + (uint)(iVar2 != 0))) -
                       (uint)(uVar3 < (uint)uVar6),uVar3 - (uint)uVar6);
    }
    else {
      lVar1 = FUN_016f39b0(0,0,1000000,0);
      lVar1 = (longlong)(int)uVar5 * 1000000 + lVar1;
    }
    uVar7 = *(undefined4 *)(param_1 + 0x128);
    *(longlong *)(param_1 + 0xe0) = lVar1;
    iVar2 = FUN_016f3900((int)lVar1,(int)((ulonglong)lVar1 >> 0x20),1000000,0);
    FUN_01167140((double)iVar2,uVar7);
    FUN_008a4940(&DAT_021242c0);
    FUN_008a4940(&DAT_021242f8);
    FUN_005e6780(0);
  }
  return;
}



/* FUNCTION 19170 ; VA 0x009d8e00 ; FUN_009d8e00 */

void FUN_009d8e00(undefined4 param_1)

{
  undefined auStack_c [8];
  
  FUN_009d6260(auStack_c,param_1);
  FUN_009d8cb0(auStack_c);
  return;
}



/* FUNCTION 19171 ; VA 0x009d8e30 ; FUN_009d8e30 */

void __thiscall FUN_009d8e30(int param_1,int param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  int iVar3;
  
  fVar1 = *param_3;
  iVar3 = *(int *)(param_1 + 8);
  if ((((NAN(*(float *)(iVar3 + param_2)) || NAN(fVar1)) == (*(float *)(iVar3 + param_2) == fVar1))
      || (fVar2 = *(float *)(iVar3 + 4 + param_2),
         (NAN(fVar2) || NAN(param_3[1])) == (fVar2 == param_3[1]))) ||
     (fVar2 = *(float *)(iVar3 + 8 + param_2),
     (NAN(fVar2) || NAN(param_3[2])) == (fVar2 == param_3[2]))) {
    *(float *)(iVar3 + param_2) = fVar1;
    *(float *)(iVar3 + 4 + param_2) = param_3[1];
    *(float *)(iVar3 + 8 + param_2) = param_3[2];
    if (*(code **)(param_1 + 0x10) != (code *)0x0) {
      (**(code **)(param_1 + 0x10))(*(undefined4 *)(param_1 + 4));
    }
    FUN_008a4940(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 19172 ; VA 0x009d8eb0 ; FUN_009d8eb0 */

void __thiscall FUN_009d8eb0(int *param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined auStack_dc [200];
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar4 = *param_3;
  pcStack_14 = *(code **)(*param_1 + 0x48);
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088c8c0();
  if (iVar4 == iVar1) {
    iVar4 = *param_3;
    iVar1 = FUN_0088c8c0();
    if (iVar4 != iVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar2 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar4 = *piVar2;
  }
  else {
    puVar3 = (undefined4 *)param_3[1];
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)*puVar3)(param_3 + 2,auStack_dc);
      puVar3 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    piVar2 = (int *)FUN_00889220();
    iVar4 = *piVar2;
    uStack_8 = 1;
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)puVar3[2])(auStack_dc);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_14)(param_2,iVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19173 ; VA 0x009d8fa0 ; FUN_009d8fa0 */

void __thiscall FUN_009d8fa0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  undefined auStack_e8 [200];
  undefined8 uStack_20;
  int iStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c95ab;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d050();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_0088d050();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    uStack_20 = *(undefined8 *)piVar3;
    iStack_18 = piVar3[2];
  }
  else {
    puVar4 = (undefined4 *)param_3[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_3 + 2,auStack_e8);
      puVar4 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    puVar5 = (undefined8 *)FUN_0088a700();
    uStack_20 = *puVar5;
    iStack_18 = *(int *)(puVar5 + 1);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_e8);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_14)(param_2,&uStack_20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19174 ; VA 0x009d90b0 ; FUN_009d90b0 */

void __thiscall FUN_009d90b0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00712f70();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 19175 ; VA 0x009d9100 ; FUN_009d9100 */

int * __thiscall
FUN_009d9100(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d64cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009d9200();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::BloomEffect,float>::
              GetSetImpl<float_(__thiscall_RBX::BloomEffect::*)(void)const_,void_(__thiscall_RBX::BloomEffect::*)(float)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::BloomEffect,float>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::BloomEffect,float>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19176 ; VA 0x009d9200 ; FUN_009d9200 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009d9200(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6500;
  pvStack_10 = ExceptionList;
  if (DAT_01ee46d0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee48e8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee48e8);
      if (DAT_01ee48e8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00e6f1a0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BloomEffect",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ee48e0 = RBX::Creator<class_RBX::BloomEffect>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee46d8,&DAT_01ee48e0);
        FUN_016f3654(FUN_01887880);
        FUN_016f37bf(&DAT_01ee48e8);
      }
    }
    DAT_01ee46d0 = &DAT_01ee46d8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee46d0;
}



/* FUNCTION 19177 ; VA 0x009d9300 ; FUN_009d9300 */

int __thiscall FUN_009d9300(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6510;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::BloomEffect*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19178 ; VA 0x009d93d2 ; Catch_All@009d93d2 */

void Catch_All_009d93d2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19179 ; VA 0x009d93f0 ; FUN_009d93f0 */

undefined4 * FUN_009d93f0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6558;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009d9200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(100);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00e6f280("Bloom");
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::BloomEffect,class_RBX::PostEffect>::vftable;
    uVar4 = FUN_009d9200();
    puVar3[3] = uVar4;
    *puVar3 = RBX::BloomEffect::vftable;
    puVar3[0x16] = 0x3ecccccd;
    puVar3[0x17] = 0x3f733333;
    puVar3[0x18] = 0x41c00000;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009d9300(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19180 ; VA 0x009d94f0 ; FUN_009d94f0 */

undefined4 * __fastcall FUN_009d94f0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6578;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00e6f280("Bloom");
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::BloomEffect,class_RBX::PostEffect>::vftable;
  uVar1 = FUN_009d9200();
  param_1[3] = uVar1;
  *param_1 = RBX::BloomEffect::vftable;
  param_1[0x16] = 0x3ecccccd;
  param_1[0x17] = 0x3f733333;
  param_1[0x18] = 0x41c00000;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19181 ; VA 0x009d9560 ; FUN_009d9560 */

void __fastcall FUN_009d9560(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::BloomEffect>::vftable;
  uVar1 = FUN_009d9200(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19182 ; VA 0x009d95a0 ; FUN_009d95a0 */

undefined4 __thiscall FUN_009d95a0(undefined4 param_1,byte param_2)

{
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 19183 ; VA 0x009d95d0 ; FUN_009d95d0 */

undefined4 * FUN_009d95d0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_009d93f0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 19184 ; VA 0x009d9640 ; FUN_009d9640 */

void FUN_009d9640(void)

{
  int iVar1;
  
  if (DAT_01ee48ec == 0) {
    iVar1 = FUN_009d9200();
    DAT_01ee48ec = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19185 ; VA 0x009d9660 ; FUN_009d9660 */

uint FUN_009d9660(void)

{
  int iVar1;
  
  iVar1 = FUN_009d9200();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 19186 ; VA 0x009d9680 ; FUN_009d9680 */

uint FUN_009d9680(void)

{
  int iVar1;
  
  iVar1 = FUN_009d9200();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 19187 ; VA 0x009d96a0 ; FUN_009d96a0 */

void __thiscall FUN_009d96a0(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0x58))) == (param_2 == *(float *)(param_1 + 0x58)))
  {
    *(float *)(param_1 + 0x58) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19188 ; VA 0x009d96d0 ; FUN_009d96d0 */

void __thiscall FUN_009d96d0(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0x60))) == (param_2 == *(float *)(param_1 + 0x60)))
  {
    *(float *)(param_1 + 0x60) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19189 ; VA 0x009d9700 ; FUN_009d9700 */

void __thiscall FUN_009d9700(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0x5c))) == (param_2 == *(float *)(param_1 + 0x5c)))
  {
    *(float *)(param_1 + 0x5c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19190 ; VA 0x009d9730 ; FUN_009d9730 */

int * __thiscall
FUN_009d9730(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d64cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009d9830();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ColorCorrectionEffect,float>::
              GetSetImpl<float_(__thiscall_RBX::ColorCorrectionEffect::*)(void)const_,void_(__thiscall_RBX::ColorCorrectionEffect::*)(float)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::ColorCorrectionEffect,float>::vftable
    ;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::ColorCorrectionEffect,float>::vftable
    ;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19191 ; VA 0x009d9830 ; FUN_009d9830 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009d9830(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d65b0;
  pvStack_10 = ExceptionList;
  if (DAT_01ee48f4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4b08) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee4b08);
      if (DAT_01ee4b08 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00e6f1a0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ColorCorrectionEffect",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ee4b00 = RBX::Creator<class_RBX::ColorCorrectionEffect>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee48f8,&DAT_01ee4b00);
        FUN_016f3654(FUN_01887960);
        FUN_016f37bf(&DAT_01ee4b08);
      }
    }
    DAT_01ee48f4 = &DAT_01ee48f8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee48f4;
}



/* FUNCTION 19192 ; VA 0x009d9930 ; FUN_009d9930 */

undefined4 * __fastcall FUN_009d9930(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6578;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00e6f280("ColorCorrection");
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ColorCorrectionEffect,class_RBX::PostEffect>::
             vftable;
  uVar1 = FUN_009d9830();
  param_1[3] = uVar1;
  *param_1 = RBX::ColorCorrectionEffect::vftable;
  param_1[0x19] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0x3f800000;
  param_1[0x1a] = 0x3f800000;
  param_1[0x1b] = 0x3f800000;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19193 ; VA 0x009d99c0 ; FUN_009d99c0 */

void __fastcall FUN_009d99c0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ColorCorrectionEffect>::vftable;
  uVar1 = FUN_009d9830(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19194 ; VA 0x009d9a00 ; FUN_009d9a00 */

undefined4 __thiscall FUN_009d9a00(undefined4 param_1,byte param_2)

{
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x70);
  }
  return param_1;
}



/* FUNCTION 19195 ; VA 0x009d9a30 ; FUN_009d9a30 */

undefined4 * FUN_009d9a30(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_005c25e0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 19196 ; VA 0x009d9aa0 ; FUN_009d9aa0 */

void FUN_009d9aa0(void)

{
  int iVar1;
  
  if (DAT_01ee4b0c == 0) {
    iVar1 = FUN_009d9830();
    DAT_01ee4b0c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19197 ; VA 0x009d9ad0 ; FUN_009d9ad0 */

uint FUN_009d9ad0(void)

{
  int iVar1;
  
  iVar1 = FUN_009d9830();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 19198 ; VA 0x009d9af0 ; FUN_009d9af0 */

uint FUN_009d9af0(void)

{
  int iVar1;
  
  iVar1 = FUN_009d9830();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 19199 ; VA 0x009d9b10 ; FUN_009d9b10 */

void __thiscall FUN_009d9b10(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0x58))) == (param_2 == *(float *)(param_1 + 0x58)))
  {
    *(float *)(param_1 + 0x58) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19200 ; VA 0x009d9b40 ; FUN_009d9b40 */

void __thiscall FUN_009d9b40(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0x5c))) == (param_2 == *(float *)(param_1 + 0x5c)))
  {
    *(float *)(param_1 + 0x5c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19201 ; VA 0x009d9b70 ; FUN_009d9b70 */

void __thiscall FUN_009d9b70(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0x60))) == (param_2 == *(float *)(param_1 + 0x60)))
  {
    *(float *)(param_1 + 0x60) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19202 ; VA 0x009d9ba0 ; FUN_009d9ba0 */

void __thiscall FUN_009d9ba0(int param_1,float *param_2)

{
  float fVar1;
  
  fVar1 = *param_2;
  if ((((NAN(fVar1) || NAN(*(float *)(param_1 + 100))) != (fVar1 == *(float *)(param_1 + 100))) &&
      ((NAN(param_2[1]) || NAN(*(float *)(param_1 + 0x68))) !=
       (param_2[1] == *(float *)(param_1 + 0x68)))) &&
     ((NAN(param_2[2]) || NAN(*(float *)(param_1 + 0x6c))) !=
      (param_2[2] == *(float *)(param_1 + 0x6c)))) {
    return;
  }
  *(float *)(param_1 + 100) = fVar1;
  *(float *)(param_1 + 0x68) = param_2[1];
  *(float *)(param_1 + 0x6c) = param_2[2];
  FUN_008a4940();
  return;
}



/* FUNCTION 19203 ; VA 0x009d9c00 ; FUN_009d9c00 */

undefined * FUN_009d9c00(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d65fc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee4b1c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4d28) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee4d28);
      if (DAT_01ee4d28 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"CacheableContentProvider",1,uStack_20,0,0,0x11,0,0);
        FUN_016f3654(&LAB_018879c0);
        FUN_016f37bf(&DAT_01ee4d28);
      }
    }
    DAT_01ee4b1c = &DAT_01ee4b20;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee4b1c;
}



/* FUNCTION 19204 ; VA 0x009d9ce0 ; FUN_009d9ce0 */

int FUN_009d9ce0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00845db0();
  *(undefined2 *)(iVar4 + 0xc) = 0;
  *(undefined4 *)(iVar4 + 0x10) = *param_1;
  *(undefined4 *)(iVar4 + 0x14) = param_1[1];
  *(undefined4 *)(iVar4 + 0x28) = 0;
  *(undefined4 *)(iVar4 + 0x2c) = 0;
  uVar1 = param_1[3];
  uVar2 = param_1[4];
  uVar3 = param_1[5];
  *(undefined4 *)(iVar4 + 0x18) = param_1[2];
  *(undefined4 *)(iVar4 + 0x1c) = uVar1;
  *(undefined4 *)(iVar4 + 0x20) = uVar2;
  *(undefined4 *)(iVar4 + 0x24) = uVar3;
  *(undefined8 *)(iVar4 + 0x28) = *(undefined8 *)(param_1 + 6);
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  *(undefined4 *)(iVar4 + 0x30) = 0;
  *(undefined4 *)(iVar4 + 0x34) = 0;
  *(undefined4 *)(iVar4 + 0x30) = param_1[8];
  *(undefined4 *)(iVar4 + 0x34) = param_1[9];
  param_1[8] = 0;
  param_1[9] = 0;
  return iVar4;
}



/* FUNCTION 19205 ; VA 0x009d9d60 ; FUN_009d9d60 */

int FUN_009d9d60(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_009a6cf0(param_1,param_2);
  *(undefined4 *)(iVar4 + 0x18) = 0;
  *(undefined4 *)(iVar4 + 0x1c) = 0;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *(undefined4 *)(iVar4 + 8) = *param_3;
  *(undefined4 *)(iVar4 + 0xc) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar2;
  *(undefined4 *)(iVar4 + 0x14) = uVar3;
  *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  *(undefined4 *)(iVar4 + 0x20) = param_3[6];
  *(undefined4 *)(iVar4 + 0x24) = 0;
  *(undefined4 *)(iVar4 + 0x28) = 0;
  *(undefined4 *)(iVar4 + 0x24) = param_3[7];
  *(undefined4 *)(iVar4 + 0x28) = param_3[8];
  param_3[7] = 0;
  param_3[8] = 0;
  return iVar4;
}



/* FUNCTION 19206 ; VA 0x009d9de0 ; FUN_009d9de0 */

void __thiscall
FUN_009d9de0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x4924922 < (uint)param_1[1]) {
    FUN_009dbbf0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_009d9e92:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_009d9e92;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 19207 ; VA 0x009d9f40 ; FUN_009d9f40 */

undefined4 * __thiscall
FUN_009d9f40(int *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6610;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00559fe0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar2 = FUN_00570370(param_4,param_3 + 4);
    if (cVar2 != '\0') {
      FUN_00559fe0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar1 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar2 = FUN_00570370(iVar1 + 0x10,param_4);
    if (cVar2 != '\0') {
      FUN_00559fe0(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_00570370(param_4,param_3 + 4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar2 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar2 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00559fe0(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00559fe0(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar2 = FUN_00570370(param_3 + 4,param_4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      piVar4 = (int *)FUN_00551320();
      piVar3 = piStack_18;
      if ((*piVar4 == *param_1) || (cVar2 = FUN_00570370(param_4,piStack_18 + 4), cVar2 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00559fe0(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00559fe0(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = (undefined4 *)FUN_00714a10(auStack_20,0,param_4,param_5);
  *param_2 = *puVar5;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19208 ; VA 0x009da164 ; Catch_All@009da164 */

void Catch_All_009da164(void)

{
  int unaff_EBP;
  
  FUN_00576370(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19209 ; VA 0x009da180 ; FUN_009da180 */

void __thiscall
FUN_009da180(undefined4 *param_1,undefined4 *param_2,char param_3,float *param_4,undefined4 param_5)

{
  float fVar1;
  float fVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  undefined4 uVar6;
  char cVar7;
  undefined4 *puVar8;
  int *piVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar6 = param_5;
  puStack_c = &LAB_017d6620;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar10 = (int *)*param_1;
  cVar7 = '\x01';
  if (*(char *)(piVar10[1] + 0xd) == '\0') {
    fVar1 = *param_4;
    piVar9 = (int *)piVar10[1];
    do {
      piVar10 = piVar9;
      fVar2 = (float)piVar10[4];
      if (param_3 == '\0') {
        if ((fVar2 <= fVar1) &&
           (((NAN(fVar1) || NAN(fVar2)) == (fVar1 == fVar2) ||
            ((uint)piVar10[5] <= (uint)param_4[1])))) {
          cVar7 = '\0';
          goto LAB_009da21b;
        }
        cVar7 = '\x01';
LAB_009da225:
        piVar9 = (int *)*piVar10;
      }
      else {
        if ((fVar2 < fVar1) ||
           (((NAN(fVar2) || NAN(fVar1)) != (fVar2 == fVar1) && ((uint)piVar10[5] < (uint)param_4[1])
            ))) {
          cVar7 = '\0';
        }
        else {
          cVar7 = '\x01';
        }
        if (cVar7 != '\0') goto LAB_009da225;
LAB_009da21b:
        piVar9 = (int *)piVar10[2];
      }
    } while (*(char *)((int)piVar9 + 0xd) == '\0');
  }
  piVar9 = piVar10;
  if (cVar7 != '\0') {
    if (piVar10 == *(int **)*param_1) {
      cVar7 = '\x01';
      goto LAB_009da249;
    }
    if (*(char *)((int)piVar10 + 0xd) == '\0') {
      piVar9 = (int *)*piVar10;
      if (*(char *)((int)piVar9 + 0xd) == '\0') {
        cVar3 = *(char *)(piVar9[2] + 0xd);
        piVar4 = (int *)piVar9[2];
        while (cVar3 == '\0') {
          cVar3 = *(char *)(piVar4[2] + 0xd);
          piVar9 = piVar4;
          piVar4 = (int *)piVar4[2];
        }
      }
      else {
        cVar3 = *(char *)(piVar10[1] + 0xd);
        piVar4 = (int *)piVar10[1];
        piVar9 = piVar10;
        while ((piVar5 = piVar4, cVar3 == '\0' && (piVar9 == (int *)*piVar5))) {
          cVar3 = *(char *)(piVar5[1] + 0xd);
          piVar4 = (int *)piVar5[1];
          piVar9 = piVar5;
        }
        if (*(char *)((int)piVar9 + 0xd) == '\0') {
          piVar9 = piVar5;
        }
      }
    }
    else {
      piVar9 = (int *)piVar10[2];
    }
  }
  fVar1 = (float)piVar9[4];
  fVar2 = *param_4;
  if ((fVar2 <= fVar1) &&
     (((NAN(fVar1) || NAN(fVar2)) == (fVar1 == fVar2) || ((uint)param_4[1] <= (uint)piVar9[5])))) {
    ExceptionList = &pvStack_10;
    FUN_0056cac0();
    FUN_01674ea0(uVar6,0x38);
    *param_2 = piVar9;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_009da249:
  ExceptionList = &pvStack_10;
  puVar8 = (undefined4 *)FUN_009d9de0(&param_3,cVar7,piVar10,param_4,param_5);
  *param_2 = *puVar8;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19210 ; VA 0x009da32c ; Catch_All@009da32c */

void Catch_All_009da32c(void)

{
  int unaff_EBP;
  
  FUN_009dbbf0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19211 ; VA 0x009da350 ; FUN_009da350 */

void __thiscall FUN_009da350(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6630;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::CacheableContentProvider::CachedItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19212 ; VA 0x009da3be ; Catch_All@009da3be */

void Catch_All_009da3be(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_009db550(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19213 ; VA 0x009da3e0 ; FUN_009da3e0 */

void __thiscall FUN_009da3e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined auStack_30 [24];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d668f;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_80;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_4 + 8) = *(int *)(param_4 + 8) + 1;
    UNLOCK();
  }
  uStack_80 = param_3;
  iStack_7c = param_4;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x00000010);
  uStack_3c = param_2;
  puStack_14 = &uStack_38;
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 8) = *(int *)(iStack_7c + 8) + 1;
    UNLOCK();
  }
  uStack_38 = uStack_80;
  iStack_34 = iStack_7c;
  uStack_8 = 3;
  FUN_0054ef60(auStack_78);
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_3c);
  if (cVar2 == '\0') {
    uStack_60 = uStack_3c;
    puStack_14 = &uStack_5c;
    if (iStack_34 != 0) {
      LOCK();
      *(int *)(iStack_34 + 8) = *(int *)(iStack_34 + 8) + 1;
      UNLOCK();
    }
    uStack_5c = uStack_38;
    iStack_58 = iStack_34;
    uStack_8 = 5;
    FUN_0054ef60(auStack_30);
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_60;
      puStack_18 = puVar3 + 1;
      *puStack_18 = 0;
      puVar3[2] = 0;
      if (iStack_58 != 0) {
        LOCK();
        *(int *)(iStack_58 + 8) = *(int *)(iStack_58 + 8) + 1;
        UNLOCK();
      }
      *puStack_18 = uStack_5c;
      puVar3[2] = iStack_58;
      uStack_8 = 8;
      FUN_0054ef60(auStack_54);
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_0193b180;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19214 ; VA 0x009da5a0 ; FUN_009da5a0 */

undefined4 *
FUN_009da5a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,int param_8)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000034;
  undefined auStack_74 [12];
  undefined4 uStack_68;
  int iStack_64;
  undefined4 *puStack_60;
  undefined4 uStack_54;
  int iStack_50;
  undefined auStack_4c [24];
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d66d0;
  pvStack_10 = ExceptionList;
  puStack_60 = &param_8;
  uStack_8 = 1;
  iStack_64 = 0x9da5d0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_3;
  piStack_18 = param_4;
  puStack_14 = (undefined4 *)auStack_74;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(aiStack_34);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  FUN_009dac10(param_3,param_4,param_5,param_6,param_7);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_60 = (undefined4 *)0x9da643;
      (**(code **)(*param_4 + 4))();
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_20) {
    puStack_60 = (undefined4 *)(uStack_20 + 1);
    iVar2 = aiStack_34[0];
    if (0xfff < puStack_60) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      puStack_60 = (undefined4 *)(uStack_20 + 0x24);
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_60 = (undefined4 *)0x9da71f;
        FUN_017167a3();
      }
    }
    uStack_68 = 0x9da678;
    iStack_64 = iVar2;
    FUN_01674ea0();
  }
  puStack_14 = param_1 + 1;
  *param_1 = param_2;
  *puStack_14 = 0;
  param_1[2] = 0;
  if (iStack_50 != 0) {
    LOCK();
    *(int *)(iStack_50 + 8) = *(int *)(iStack_50 + 8) + 1;
    UNLOCK();
  }
  *puStack_14 = uStack_54;
  param_1[2] = iStack_50;
  puStack_60 = (undefined4 *)auStack_4c;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iStack_64 = 0x9da6bc;
  FUN_0054ef60();
  puStack_60 = (undefined4 *)0x9da6c4;
  FUN_005d11a0();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_60 = (undefined4 *)0x9da6d8;
      (**(code **)(*param_4 + 4))();
    }
  }
  if (0xf < in_stack_00000034) {
    puStack_60 = (undefined4 *)(in_stack_00000034 + 1);
    iVar2 = param_8;
    if (0xfff < puStack_60) {
      iVar2 = *(int *)(param_8 + -4);
      puStack_60 = (undefined4 *)(in_stack_00000034 + 0x24);
      if (0x1f < (param_8 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_60 = (undefined4 *)&UNK_009da724;
        FUN_017167a3();
      }
    }
    uStack_68 = 0x9da705;
    iStack_64 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19215 ; VA 0x009da730 ; FUN_009da730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_009da730(byte *param_1,int *param_2,int param_3,int param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  byte *pbVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d66e8;
  pvStack_10 = ExceptionList;
  pbVar9 = param_1 + *param_1 + 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0055c740(pbVar9,param_3);
  FUN_009da8d0(&param_3,uVar4,iVar6,-(uint)(pbVar9 != (byte *)0x0) & (uint)(pbVar9 + 1));
  if (param_3 == 0) {
    uStack_8 = 0;
    FUN_005d2a40();
    iVar6 = param_4;
    FUN_0054ef60(param_4);
    _DAT_00000020 = *(undefined4 *)(iVar6 + 0x18);
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      uVar7 = uVar1 >> 1;
      if (uVar7 + uVar1 <= uVar5) {
        uVar7 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar7 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar8;
        while (puVar2 != (undefined4 *)0x0) {
          piVar3 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar3 = (int)puVar8;
            puVar8 = puVar2;
          }
          else {
            *puVar8 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar3;
            *(undefined4 **)*piVar3 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar8;
        }
      }
    }
    param_3 = 0;
    uVar5 = uVar4 % *(uint *)(param_1 + 4);
    piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    _DAT_00000004 = uVar4;
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar3 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar8 = piVar3;
      _DAT_00000000 = *piVar3;
      *piVar3 = 0;
    }
    else {
      _DAT_00000000 = *piVar3;
      *(undefined4 *)*puVar8 = 0;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined *)(param_2 + 1) = 1;
  }
  else {
    *(undefined *)(param_2 + 1) = 0;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19216 ; VA 0x009da8d0 ; FUN_009da8d0 */

void __thiscall FUN_009da8d0(int param_1,undefined4 *param_2,uint param_3,byte *param_4)

{
  undefined4 *puVar1;
  uint uVar2;
  byte *pbVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  byte *pbVar7;
  bool bVar8;
  
  uVar6 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5 = (int *)*puVar1;
    }
    if (piVar5 != (int *)0x0) {
      do {
        if (param_3 == piVar5[1]) {
          pbVar3 = (byte *)(piVar5 + 2);
          if (0xf < (uint)piVar5[7]) {
            pbVar3 = *(byte **)pbVar3;
          }
          uVar4 = *(uint *)(param_4 + 0x10);
          pbVar7 = param_4;
          if (0xf < *(uint *)(param_4 + 0x14)) {
            pbVar7 = *(byte **)param_4;
          }
          if (uVar4 == piVar5[6]) {
            while (uVar2 = uVar4 - 4, 3 < uVar4) {
              if (*(int *)pbVar7 != *(int *)pbVar3) goto LAB_009da966;
              pbVar7 = pbVar7 + 4;
              pbVar3 = pbVar3 + 4;
              uVar4 = uVar2;
            }
            if (uVar2 == 0xfffffffc) {
LAB_009da99a:
              uVar4 = 0;
            }
            else {
LAB_009da966:
              bVar8 = *pbVar7 < *pbVar3;
              if ((*pbVar7 == *pbVar3) &&
                 ((uVar2 == 0xfffffffd ||
                  ((bVar8 = pbVar7[1] < pbVar3[1], pbVar7[1] == pbVar3[1] &&
                   ((uVar2 == 0xfffffffe ||
                    ((bVar8 = pbVar7[2] < pbVar3[2], pbVar7[2] == pbVar3[2] &&
                     ((uVar2 == 0xffffffff ||
                      (bVar8 = pbVar7[3] < pbVar3[3], pbVar7[3] == pbVar3[3]))))))))))))
              goto LAB_009da99a;
              uVar4 = -(uint)bVar8 | 1;
            }
            if (uVar4 == 0) break;
          }
        }
        else if ((uint)piVar5[1] % *(uint *)(param_1 + 4) != uVar6) {
          *param_2 = 0;
          return;
        }
        piVar5 = (int *)*piVar5;
        if (piVar5 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar5;
  return;
}



/* FUNCTION 19217 ; VA 0x009da9e0 ; FUN_009da9e0 */

undefined4 * FUN_009da9e0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d673c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = GetProcessHeap(0,0x50);
  puVar4 = (undefined4 *)HeapAlloc(uVar3);
  if (puVar4 == (undefined4 *)0x0) {
    uVar3 = FUN_0054fbc0();
    uStack_8 = 0;
    FUN_005648a0(uVar3);
  }
  else {
    *puVar4 = boost::detail::thread_data_base::vftable;
    puVar4[1] = 0;
    puVar4[2] = 0;
    puVar4[3] = 0;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    puVar4[4] = 0;
    puVar4[5] = 0;
    uVar3 = FUN_00575ab0();
    puVar4[4] = uVar3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    puVar4[8] = 0;
    puVar4[9] = 0;
    puVar4[10] = 0;
    puVar4[0xb] = 0;
    puVar4[0xc] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar5 = CreateEventA(0,1,0,0);
    if (iVar5 != 0) {
      puVar4[0xd] = iVar5;
      *(undefined *)(puVar4 + 0xe) = 1;
      *puVar4 = boost::detail::
                thread_data<class_boost::_bi::bind_t<void,class_boost::_mfi::mf0<void,class_RBX::CacheableContentProvider>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::CacheableContentProvider*>_>_>_>
                ::vftable;
      uVar3 = param_1[1];
      uVar1 = param_1[2];
      uVar2 = param_1[3];
      puVar4[0x10] = *param_1;
      puVar4[0x11] = uVar3;
      puVar4[0x12] = uVar1;
      puVar4[0x13] = uVar2;
      ExceptionList = pvStack_10;
      return puVar4;
    }
  }
  uVar3 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar3);
}



/* FUNCTION 19218 ; VA 0x009daad5 ; Catch_All@009daad5 */

void Catch_All_009daad5(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19219 ; VA 0x009dab20 ; FUN_009dab20 */

undefined4 * __fastcall FUN_009dab20(undefined4 *param_1)

{
  undefined4 uVar1;
  
  *param_1 = RBX::
             LRUCache<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::CacheableContentProvider::CachedItem>,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
             ::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_009a6cf0(0,0);
  param_1[1] = uVar1;
  *(undefined *)(param_1 + 3) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[4] = uVar1;
  param_1[5] = 0;
  param_1[6] = 0x3f800000;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  return param_1;
}



/* FUNCTION 19220 ; VA 0x009dab90 ; FUN_009dab90 */

undefined4 * __thiscall FUN_009dab90(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6758;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19221 ; VA 0x009dac10 ; FUN_009dac10 */

undefined4 * __thiscall FUN_009dac10(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int in_stack_00000018;
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6788;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    piVar1 = param_3 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(&stack0x00000018);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_0000002c) {
    uVar3 = in_stack_0000002c + 1;
    iVar2 = in_stack_00000018;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(in_stack_00000018 + -4);
      uVar3 = in_stack_0000002c + 0x24;
      if (0x1f < (in_stack_00000018 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19222 ; VA 0x009dad40 ; FUN_009dad40 */

undefined4 * __thiscall
FUN_009dad40(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d687c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::CacheableContentProvider,class_RBX::ServiceInstance>::vftable
  ;
  uVar4 = FUN_009d9c00();
  param_1[3] = uVar4;
  uStack_8 = 1;
  FUN_00f45140();
  *param_1 = RBX::CacheableContentProvider::vftable;
  param_1[0x16] = RBX::CacheableContentProvider::vftable;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  *(undefined *)(param_1 + 0x1c) = 0;
  uVar4 = FUN_00588320(0xb);
  param_1[0x1d] = uVar4;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0x3f800000;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  puVar5 = param_1 + 0x2c;
  uStack_8._0_1_ = 7;
  *puVar5 = 0;
  param_1[0x2d] = 0;
  puStack_18 = puVar5;
  uVar4 = FUN_00845d90();
  *puVar5 = uVar4;
  param_1[0x2e] = param_4;
  uStack_8._0_1_ = 8;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  uVar4 = FUN_00575af0();
  param_1[0x2f] = uVar4;
  uStack_8._0_1_ = 9;
  FUN_00610ca0();
  uStack_8._0_1_ = 10;
  *(undefined *)(param_1 + 0x32) = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("CacheableContentProvider",0x18);
  uStack_8._0_1_ = 0xb;
  FUN_008a6520(auStack_30);
  uStack_8._0_1_ = 10;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_1c) {
    uVar9 = uStack_1c + 1;
    uVar8 = auStack_30[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_30[0] - 4);
      uVar9 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
    goto LAB_009db023;
  }
  *puVar5 = param_3;
  puVar5[1] = param_2;
  puVar5[2] = 0;
  puVar5[3] = 0;
  uStack_8._0_1_ = 0xe;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xe;
  puStack_18 = puVar5;
  if (param_2 == 1) {
    puVar6 = (undefined4 *)FUN_01674e20(0x2c);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    if (puVar6 == (undefined4 *)0x0) {
LAB_009dafbd:
      puVar6 = (undefined4 *)0x0;
    }
    else {
      FUN_009dab20();
      *puVar6 = RBX::
                SizeEnforcedLRUCache<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::CacheableContentProvider::CachedItem>,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
                ::vftable;
      puVar6[10] = param_3;
    }
LAB_009dafbf:
    puVar2 = (undefined4 *)puVar5[2];
    puVar5[2] = puVar6;
    uStack_8._0_1_ = 0xe;
    if (puVar2 != (undefined4 *)0x0) {
      (**(code **)*puVar2)(1);
    }
  }
  else {
    uStack_8._0_1_ = uVar3;
    if (param_2 == 0) {
      puVar6 = (undefined4 *)FUN_01674e20(0x2c);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
      if (puVar6 == (undefined4 *)0x0) goto LAB_009dafbd;
      FUN_009dab20();
      *puVar6 = RBX::
                MemEnforcedLRUCache<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::CacheableContentProvider::CachedItem>,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
                ::vftable;
      puVar6[10] = param_3;
      goto LAB_009dafbf;
    }
  }
  iVar7 = FUN_01674e20(0x28);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_009dab20();
  }
  puVar6 = (undefined4 *)puVar5[3];
  puVar5[3] = uVar4;
  if (puVar6 != (undefined4 *)0x0) {
    (**(code **)*puVar6)(1);
  }
  puVar5[4] = 0;
  puVar5[5] = 0;
  puVar5[6] = 300;
  puVar5[7] = 0;
LAB_009db023:
  iVar7 = param_1[0x19];
  param_1[0x19] = puVar5;
  if (iVar7 != 0) {
    LOCK();
    iVar1 = *(int *)(iVar7 + 0x14);
    *(int *)(iVar7 + 0x14) = 0;
    UNLOCK();
    if (iVar1 != 0) {
      CloseHandle(iVar1);
    }
    if (*(undefined4 **)(iVar7 + 0xc) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(iVar7 + 0xc))(1);
    }
    if (*(undefined4 **)(iVar7 + 8) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(iVar7 + 8))(1);
    }
    FUN_01674ea0(iVar7,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19223 ; VA 0x009db080 ; FUN_009db080 */

undefined4 * __thiscall
FUN_009db080(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = param_4;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  param_1[1] = param_2;
  param_1[2] = param_3;
  param_1[3] = 0x7f7fffff;
  param_1[4] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 19224 ; VA 0x009db100 ; FUN_009db100 */

undefined * __fastcall FUN_009db100(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  return param_1;
}



/* FUNCTION 19225 ; VA 0x009db130 ; FUN_009db130 */

void __fastcall FUN_009db130(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  *param_1 = RBX::
             LRUCache<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::CacheableContentProvider::CachedItem>,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
             ::vftable;
  FUN_009dc100();
  if (param_1[5] != 0) {
    FUN_005d31b0(param_1[8] + param_1[4] * 4,0);
    puVar2 = (undefined4 *)param_1[8];
    puVar1 = puVar2 + param_1[4];
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  param_1[9] = 0;
  FUN_0096cd30();
  FUN_009dc100();
  FUN_01674ea0(param_1[1],0x2c);
  return;
}



/* FUNCTION 19226 ; VA 0x009db1b0 ; FUN_009db1b0 */

void __fastcall FUN_009db1b0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009dbc10(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19227 ; VA 0x009db210 ; FUN_009db210 */

void FUN_009db210(void)

{
  FUN_0056cac0();
  return;
}



/* FUNCTION 19228 ; VA 0x009db220 ; FUN_009db220 */

void __fastcall FUN_009db220(int *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_1[8];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[5];
  if (0xf < uVar3) {
    iVar4 = *param_1;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 19229 ; VA 0x009db2a0 ; FUN_009db2a0 */

void __fastcall FUN_009db2a0(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    LOCK();
    iVar1 = *(int *)(iVar2 + 0x14);
    *(int *)(iVar2 + 0x14) = 0;
    UNLOCK();
    if (iVar1 != 0) {
      CloseHandle(iVar1);
    }
    if (*(undefined4 **)(iVar2 + 0xc) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(iVar2 + 0xc))(1);
    }
    if (*(undefined4 **)(iVar2 + 8) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(iVar2 + 8))(1);
    }
    FUN_01674ea0(iVar2,0x20);
  }
  return;
}



/* FUNCTION 19230 ; VA 0x009db2e0 ; FUN_009db2e0 */

void __fastcall FUN_009db2e0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::CacheableContentProvider::vftable;
  param_1[0x16] = RBX::CacheableContentProvider::vftable;
  FUN_009dde60();
  uStack_8 = 0;
  FUN_016899e0();
  puVar3 = (undefined4 *)param_1[0x31];
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    iVar4 = puVar3[1] + -1;
    puVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*puVar3)(0);
      uVar5 = GetProcessHeap(0,puVar3);
      HeapFree(uVar5);
    }
  }
  iVar4 = param_1[0x2f];
  piVar1 = param_1 + 0x2f;
  uStack_8 = 1;
  FUN_00576640(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar1 + 4) = iVar4;
  *(int *)*piVar1 = iVar4;
  *(int *)(*piVar1 + 8) = iVar4;
  param_1[0x30] = 0;
  FUN_01674ea0(*piVar1,0x2c);
  iVar4 = param_1[0x2c];
  piVar1 = param_1 + 0x2c;
  uStack_8 = 2;
  FUN_009dbc10(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar1 + 4) = iVar4;
  *(int *)*piVar1 = iVar4;
  *(int *)(*piVar1 + 8) = iVar4;
  param_1[0x2d] = 0;
  FUN_01674ea0(*piVar1,0x38);
  iVar4 = param_1[0x2b];
  if ((iVar4 != 0) && (iVar4 != -1)) {
    CloseHandle(iVar4);
  }
  FUN_0056d500();
  LOCK();
  iVar4 = param_1[0x25];
  param_1[0x25] = 0;
  UNLOCK();
  if (iVar4 != 0) {
    CloseHandle(iVar4);
  }
  LOCK();
  iVar4 = param_1[0x23];
  param_1[0x23] = 0;
  UNLOCK();
  if (iVar4 != 0) {
    CloseHandle(iVar4);
  }
  FUN_00612580();
  LOCK();
  iVar4 = param_1[0x1b];
  param_1[0x1b] = 0;
  UNLOCK();
  if (iVar4 != 0) {
    CloseHandle(iVar4);
  }
  iVar4 = param_1[0x19];
  if (iVar4 != 0) {
    LOCK();
    iVar2 = *(int *)(iVar4 + 0x14);
    *(int *)(iVar4 + 0x14) = 0;
    UNLOCK();
    if (iVar2 != 0) {
      CloseHandle(iVar2);
    }
    if (*(undefined4 **)(iVar4 + 0xc) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(iVar4 + 0xc))(1);
    }
    if (*(undefined4 **)(iVar4 + 8) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(iVar4 + 8))(1);
    }
    FUN_01674ea0(iVar4,0x20);
  }
  FUN_00f45160();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19231 ; VA 0x009db47e ; FUN_009db47e */

void FUN_009db47e(void)

{
  FUN_009db520();
  return;
}



/* FUNCTION 19232 ; VA 0x009db490 ; FUN_009db490 */

undefined4 __thiscall FUN_009db490(undefined4 param_1,byte param_2)

{
  FUN_009db130();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 19233 ; VA 0x009db4c0 ; FUN_009db4c0 */

undefined4 __thiscall FUN_009db4c0(undefined4 param_1,byte param_2)

{
  FUN_009db130();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 19234 ; VA 0x009db4f0 ; FUN_009db4f0 */

undefined4 * __thiscall FUN_009db4f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::
             SizeEnforcedLRUCache<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::CacheableContentProvider::CachedItem>,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
             ::vftable;
  FUN_009db130();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 19235 ; VA 0x009db520 ; FUN_009db520 */

undefined4 __thiscall FUN_009db520(undefined4 param_1,byte param_2)

{
  FUN_009db2e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xcc);
  }
  return param_1;
}



/* FUNCTION 19236 ; VA 0x009db550 ; FUN_009db550 */

int __thiscall FUN_009db550(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 19237 ; VA 0x009db5a0 ; FUN_009db5a0 */

void FUN_009db5a0(void)

{
  FUN_009dd050();
  return;
}



/* FUNCTION 19238 ; VA 0x009db5b0 ; FUN_009db5b0 */

/* WARNING: Type propagation algorithm not settling */

int FUN_009db5b0(int param_1,int *param_2,int *param_3,int param_4,int *param_5,undefined4 *param_6)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  char cVar4;
  undefined4 uVar5;
  undefined *puVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int iStack_ec;
  undefined **appuStack_e8 [2];
  int aiStack_e0 [2];
  int *piStack_d8;
  int *piStack_d4;
  int aiStack_d0 [2];
  int *piStack_c8;
  uint *puStack_c4;
  int aiStack_c0 [2];
  int *piStack_b8;
  int *piStack_b4;
  int iStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  undefined4 uStack_9c;
  undefined **ppuStack_98;
  undefined4 auStack_50 [4];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_5;
  puStack_c = &LAB_017d690a;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff08;
  piStack_18 = (int *)0x0;
  iStack_30 = 0;
  piStack_2c = (int *)0x0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_009dc320(param_6,&iStack_30,0);
  if (cVar4 == '\0') {
    LOCK();
    UNLOCK();
    uStack_24 = 0x7f7fffff;
    iStack_20 = DAT_01ee4b18;
    DAT_01ee4b18 = DAT_01ee4b18 + 1;
  }
  else {
    uStack_24 = *(undefined4 *)(iStack_30 + 0xc);
    iStack_20 = *(int *)(iStack_30 + 0x10);
  }
  if (param_1 != 1) {
    param_4 = 0;
    param_5 = (int *)0x0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar7 = piVar3[1] + -1;
      piVar3[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar7 = piVar3[2] + -1;
        piVar3[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    goto LAB_009db8f0;
  }
  if ((param_4 != 0) || (param_2 == (int *)0x0)) goto LAB_009db8f0;
  appuStack_e8[0] = &PTR_018be314;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  piStack_18 = (int *)0x1;
  ppuStack_98 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_9c = 0x48;
  FUN_00554f20(appuStack_e8 + 1,0);
  uStack_8 = 6;
  *(undefined ***)((int)appuStack_e8 + (int)appuStack_e8[0][1]) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_ec + (int)appuStack_e8[0][1]) = appuStack_e8[0][1] + -0x50;
  appuStack_e8[1] = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  iStack_b0 = FUN_01674e20(8);
  if (iStack_b0 == 0) {
    iStack_b0 = 0;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    uVar5 = FUN_016de181(1);
    *(undefined4 *)(iStack_b0 + 4) = uVar5;
  }
  piStack_d8 = aiStack_e0;
  piStack_d4 = aiStack_e0 + 1;
  piStack_c8 = aiStack_d0;
  puStack_c4 = (uint *)(aiStack_d0 + 1);
  piStack_b8 = aiStack_c0;
  piStack_b4 = aiStack_c0 + 1;
  aiStack_e0[1] = 0;
  aiStack_d0[1] = 0;
  aiStack_c0[1] = 0;
  aiStack_e0[0] = 0;
  aiStack_d0[0] = 0;
  aiStack_c0[0] = 0;
  appuStack_e8[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_ac = 0;
  uStack_a8 = 4;
  uStack_8._0_1_ = 8;
  FUN_0056f130(*(undefined4 *)(*(int *)(*param_2 + 4) + 0x38 + (int)param_2));
  puVar6 = (undefined *)FUN_01674e20(0x18);
  if (puVar6 == (undefined *)0x0) {
    puVar6 = (undefined *)0x0;
  }
  else {
    *(undefined4 *)(puVar6 + 0x10) = 0;
    *(undefined4 *)(puVar6 + 0x14) = 0xf;
    *puVar6 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    piStack_18 = (int *)0x9;
    if (((uStack_a8 & 2) == 0) && (uVar8 = *puStack_c4, uVar8 != 0)) {
      if (uVar8 < uStack_ac) {
        uVar8 = uStack_ac;
      }
      iVar7 = *piStack_d4;
      iVar9 = uVar8 - iVar7;
LAB_009db840:
      FUN_005542c0(iVar7,iVar9);
    }
    else if (((uStack_a8 & 4) == 0) && (*piStack_c8 != 0)) {
      iVar7 = *piStack_d8;
      iVar9 = (*piStack_c8 - iVar7) + *piStack_b8;
      goto LAB_009db840;
    }
    uStack_8._1_3_ = 0;
  }
  uStack_8._0_1_ = 8;
  iStack_1c = 0;
  piStack_18 = (int *)0x0;
  FUN_005ce7a0(puVar6,param_6);
  param_4 = iStack_1c;
  param_5 = piStack_18;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar7 = piVar3[1] + -1;
    piVar3[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar7 = piVar3[2] + -1;
      piVar3[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00570540();
LAB_009db8f0:
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0]._0_1_ = 0;
  iStack_38 = 0;
  piStack_34 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (auStack_50 != param_6) {
    puVar1 = param_6 + 4;
    if (0xf < (uint)param_6[5]) {
      param_6 = (undefined4 *)*param_6;
    }
    FUN_005542c0(param_6,*puVar1);
  }
  piVar3 = piStack_34;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  iStack_38 = param_4;
  piStack_34 = param_5;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar7 = piVar3[1] + -1;
    piVar3[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar7 = piVar3[2] + -1;
      piVar3[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_009dbc60(auStack_50,&uStack_24,1);
  iVar7 = FUN_0056cac0();
  piVar3 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_2c + 1;
    iVar9 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar9 = *piVar2;
      iVar7 = *piVar2;
      *piVar2 = iVar9 + -1;
      UNLOCK();
      if (iVar9 + -1 == 0) {
        (**(code **)(*piVar3 + 4))();
        iVar7 = FUN_009db9fd();
        return iVar7;
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar9 = *piVar3;
    iVar7 = *piVar3;
    *piVar3 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar9 = *piVar3;
      iVar7 = *piVar3;
      *piVar3 = iVar9 + -1;
      UNLOCK();
      if (iVar9 + -1 == 0) {
        iVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar3 = param_5 + 1;
    iVar9 = *piVar3;
    iVar7 = *piVar3;
    *piVar3 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      iVar7 = (**(code **)*param_5)();
      LOCK();
      piVar3 = param_5 + 2;
      iVar9 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        iVar7 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 19239 ; VA 0x009db9af ; Catch@009db9af */

undefined * Catch_009db9af(void)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  int unaff_EBP;
  
  uVar3 = (**(code **)(**(int **)(unaff_EBP + -0xe8) + 4))();
  piVar1 = *(int **)(unaff_EBP + 0x1c);
  piVar5 = piVar1;
  if (0xf < (uint)piVar1[5]) {
    piVar5 = (int *)*piVar1;
  }
  piVar2 = *(int **)(unaff_EBP + -0x24);
  piVar4 = (int *)piVar2[10];
  if (0xf < (uint)piVar4[5]) {
    piVar4 = (int *)*piVar4;
  }
  FUN_0086f2f0(3,"%s failed to load %s because %s",piVar4,piVar5,uVar3);
  (**(code **)(*piVar2 + 0xa8))(piVar1);
  return &DAT_009db9fa;
}



/* FUNCTION 19240 ; VA 0x009db9fd ; FUN_009db9fd */

void FUN_009db9fd(void)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int unaff_EBP;
  int unaff_ESI;
  
  piVar2 = *(int **)(unaff_EBP + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + unaff_ESI;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + unaff_ESI;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(unaff_EBP + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + unaff_ESI;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + unaff_ESI;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 19241 ; VA 0x009dba60 ; FUN_009dba60 */

int FUN_009dba60(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,int *param_5,
                undefined4 param_6,int *param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6940;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (iStack_1c != 0) {
    if (param_7 != (int *)0x0) {
      LOCK();
      param_7[1] = param_7[1] + 1;
      UNLOCK();
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    iVar3 = FUN_009db5b0(param_3,param_4,param_5,param_6,param_7,param_8);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19242 ; VA 0x009dbba0 ; FUN_009dbba0 */

void __fastcall FUN_009dbba0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0xc);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 8);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x14);
  }
  return;
}



/* FUNCTION 19243 ; VA 0x009dbbf0 ; FUN_009dbbf0 */

void FUN_009dbbf0(undefined4 param_1)

{
  FUN_0056cac0();
  FUN_01674ea0(param_1,0x38);
  return;
}



/* FUNCTION 19244 ; VA 0x009dbc10 ; FUN_009dbc10 */

void FUN_009dbc10(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_009dbc10(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_0056cac0();
    FUN_01674ea0(param_1,0x38);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 19245 ; VA 0x009dbc60 ; FUN_009dbc60 */

void __thiscall FUN_009dbc60(int param_1,float *param_2,float *param_3,int param_4)

{
  int *piVar1;
  float fVar2;
  uint uVar3;
  float fVar4;
  float *pfVar5;
  char cVar6;
  float *pfVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  float *pfVar11;
  float fStack_4c;
  float fStack_48;
  float fStack_2c;
  float fStack_28;
  float afStack_24 [2];
  uint *puStack_1c;
  char cStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6968;
  pvStack_10 = ExceptionList;
  cStack_18 = '\0';
  puStack_1c = (uint *)(param_1 + 0x88);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00587410();
  pfVar5 = param_2;
  piVar1 = (int *)(param_1 + 0xbc);
  uStack_8 = 0;
  FUN_00718820(&param_2,param_2);
  pfVar11 = param_2;
  pfVar7 = (float *)*piVar1;
  if (param_2 == pfVar7) {
LAB_009dbccf:
    pfVar11 = pfVar7;
  }
  else {
    cVar6 = FUN_00570370(pfVar5,param_2 + 4);
    pfVar7 = (float *)*piVar1;
    if (cVar6 != '\0') goto LAB_009dbccf;
  }
  if (pfVar11 != pfVar7) {
    fVar4 = pfVar11[10];
    afStack_24[0] = *(float *)((int)fVar4 + 0x10);
    fVar2 = *param_3;
    if ((fVar2 < afStack_24[0]) ||
       (((NAN(fVar2) || NAN(afStack_24[0])) != (fVar2 == afStack_24[0]) &&
        ((uint)param_3[1] < (uint)*(float *)((int)fVar4 + 0x14))))) {
      param_4 = iStack_14 + 0xb0;
      uVar8 = FUN_00553830(fVar4);
      FUN_0056cac0();
      FUN_01674ea0(uVar8,0x38);
      fStack_4c = *param_3;
      fStack_48 = param_3[1];
      FUN_0054ef60(pfVar5);
      fStack_28 = pfVar5[7];
      if (fStack_28 != 0.0) {
        LOCK();
        *(int *)((int)fStack_28 + 4) = *(int *)((int)fStack_28 + 4) + 1;
        UNLOCK();
        fStack_28 = pfVar5[7];
      }
      fStack_2c = pfVar5[6];
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iVar9 = FUN_009d9ce0(&fStack_4c);
      FUN_009da180(afStack_24,0,iVar9 + 0x10,iVar9);
      pfVar11[10] = afStack_24[0];
      FUN_0056cac0();
    }
    goto LAB_009dbe6a;
  }
  if ((char)param_4 == '\0') goto LAB_009dbe6a;
  fStack_4c = *param_3;
  fStack_48 = param_3[1];
  FUN_0054ef60(pfVar5);
  fStack_28 = pfVar5[7];
  if (fStack_28 != 0.0) {
    LOCK();
    *(int *)((int)fStack_28 + 4) = *(int *)((int)fStack_28 + 4) + 1;
    UNLOCK();
    fStack_28 = pfVar5[7];
  }
  fStack_2c = pfVar5[6];
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar9 = FUN_009d9ce0(&fStack_4c);
  FUN_009da180(afStack_24,0,iVar9 + 0x10,iVar9);
  FUN_00718820(&param_4,pfVar5);
  iVar9 = param_4;
  if (param_4 == *piVar1) {
LAB_009dbe1f:
    param_3 = pfVar5;
    iVar10 = FUN_00714520(&DAT_018bdeda,&param_3,(int)&param_4 + 3);
    FUN_009d9f40(&param_4,iVar9,iVar10 + 0x10,iVar10);
    iVar9 = param_4;
  }
  else {
    cVar6 = FUN_00570370(pfVar5,param_4 + 0x10);
    if (cVar6 != '\0') goto LAB_009dbe1f;
  }
  *(float *)(iVar9 + 0x28) = afStack_24[0];
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_0056cac0();
  FUN_00588350();
LAB_009dbe6a:
  uStack_8 = 3;
  if (cStack_18 != '\0') {
    LOCK();
    uVar3 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar3 & 0x40000000) == 0) && (-0x80000000 < (int)uVar3)) {
      LOCK();
      uVar3 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar3 >> 0x1e & 1) == 0) {
        uVar8 = FUN_00554e40();
        SetEvent(uVar8);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19246 ; VA 0x009dbec0 ; FUN_009dbec0 */

undefined4 * FUN_009dbec0(undefined4 *param_1,int param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int **ppiVar7;
  undefined8 uVar8;
  int **ppiStack_4c;
  undefined4 *puStack_48;
  undefined4 **appuStack_38 [5];
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d69a1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ppiStack_4c = (int **)appuStack_38;
  puStack_48 = (undefined4 *)param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009dc5a0();
  uStack_8 = 1;
  *param_1 = 0;
  param_1[1] = 0;
  uStack_14 = 1;
  param_2 = 0;
  while( true ) {
    puStack_48 = &param_2;
    ppiStack_4c = (int **)0x1;
    puVar5 = (undefined4 *)FUN_009dd5a0(auStack_20,appuStack_38,0,param_3);
    uVar6 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *param_1 = uVar6;
    piVar3 = (int *)param_1[1];
    param_1[1] = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puStack_48 = (undefined4 *)0x9dbf72;
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          puStack_48 = (undefined4 *)0x9dbf82;
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puStack_48 = (undefined4 *)0x9dbf98;
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          puStack_48 = (undefined4 *)0x9dbfa8;
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (param_2 != 0) break;
    if (DAT_01ea94c0 == (code *)0x0) {
      uVar6 = GetModuleHandleA("KERNEL32.DLL","GetTickCount64");
      DAT_01ea94c0 = (code *)GetProcAddress(uVar6);
      if (DAT_01ea94c0 == (code *)0x0) {
        DAT_01ea94c0 = FUN_005efd30;
      }
    }
    uVar8 = (*DAT_01ea94c0)();
    FUN_005f0a90(&ppiStack_4c,FUN_005f1e70,uVar8,0x14,0,1);
    FUN_01689e80(0xffffffff);
  }
  if (param_2 == 2) {
    *param_1 = 0;
    piVar3 = (int *)param_1[1];
    param_1[1] = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puStack_48 = (undefined4 *)0x9dc052;
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          puStack_48 = (undefined4 *)0x9dc061;
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  if (0xf < uStack_24) {
    puStack_48 = (undefined4 *)(uStack_24 + 1);
    ppiVar7 = appuStack_38[0];
    if (0xfff < puStack_48) {
      ppiVar7 = (int **)appuStack_38[0][-1];
      puStack_48 = (undefined4 *)(uStack_24 + 0x24);
      if (0x1f < (uint)((int)appuStack_38[0] + (-4 - (int)ppiVar7))) {
                    /* WARNING: Subroutine does not return */
        puStack_48 = (undefined4 *)&UNK_009dc0ab;
        FUN_017167a3();
      }
    }
    ppiStack_4c = ppiVar7;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19247 ; VA 0x009dc0b0 ; FUN_009dc0b0 */

void __fastcall FUN_009dc0b0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  FUN_009dc100();
  if (*(int *)(param_1 + 0x14) != 0) {
    FUN_005d31b0(*(int *)(param_1 + 0x20) + *(int *)(param_1 + 0x10) * 4,0);
    puVar2 = *(undefined4 **)(param_1 + 0x20);
    puVar1 = puVar2 + *(int *)(param_1 + 0x10);
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  *(undefined4 *)(param_1 + 0x24) = 0;
  return;
}



/* FUNCTION 19248 ; VA 0x009dc100 ; FUN_009dc100 */

void __fastcall FUN_009dc100(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar2 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_009db220();
      FUN_01674ea0(piVar2,0x2c);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 19249 ; VA 0x009dc150 ; FUN_009dc150 */

void __thiscall FUN_009dc150(int param_1,uint param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iStack_8;
  
  uVar1 = *(uint *)(param_1 + 0x24);
  iStack_8 = param_1;
  while (param_2 < uVar1) {
    iVar3 = *(int *)(*(int *)(param_1 + 4) + 4) + 8;
    iVar4 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
    uVar2 = FUN_0055c740(iVar4,iVar3);
    FUN_009da8d0(&iStack_8,uVar2,iVar3,-(uint)(iVar4 != 0) & iVar4 + 1U);
    if (iStack_8 != 0) {
      FUN_009dd490(&iStack_8);
    }
    uVar1 = *(uint *)(param_1 + 0x24);
  }
  return;
}


