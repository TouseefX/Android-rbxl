/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 29250 ; VA 0x00c77eb0 ; FUN_00c77eb0 */

int FUN_00c77eb0(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iStack_c;
  int *piStack_8;
  
  FUN_00587490(&iStack_c);
  if (iStack_c != 0) {
    *(undefined4 *)(iStack_c + 0x360) = 0;
    piVar3 = *(int **)(iStack_c + 0x364);
    *(undefined4 *)(iStack_c + 0x364) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iStack_c = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iStack_c = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_8 + 1;
    iVar2 = *piVar3;
    iStack_c = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_c = (**(code **)*piStack_8)();
      LOCK();
      piVar3 = piStack_8 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_c = (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return iStack_c;
}



/* FUNCTION 29251 ; VA 0x00c77f30 ; FUN_00c77f30 */

void FUN_00c77f30(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  FUN_00d88580(puVar2 + 3);
  if (puVar2[2] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar3)(puVar2[1],puVar2[2]);
  return;
}



/* FUNCTION 29252 ; VA 0x00c77f80 ; FUN_00c77f80 */

undefined4 __fastcall FUN_00c77f80(int *param_1)

{
  char cVar1;
  int iVar2;
  float *pfVar3;
  float *pfVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  float fVar8;
  double dVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  undefined auStack_6c [12];
  undefined auStack_60 [8];
  undefined auStack_58 [4];
  undefined auStack_54 [8];
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  undefined auStack_3c [16];
  undefined auStack_2c [16];
  undefined auStack_1c [24];
  
  cVar1 = (**(code **)(*param_1 + 0xdc))();
  do {
    if (cVar1 == '\0') {
      return 0;
    }
    iVar2 = FUN_00b599b0();
    if ((iVar2 != 0) || ((param_1[0xd] != 0 && (iVar2 = FUN_00c6e770(), iVar2 != 0)))) {
      return 1;
    }
    pfVar3 = (float *)FUN_00d5bef0(auStack_60);
    pfVar4 = (float *)(**(code **)(*param_1 + 0xc0))(auStack_58);
    fVar11 = *pfVar4;
    fVar10 = pfVar4[1];
    fVar13 = *pfVar3 + fVar11;
    fStack_80 = pfVar3[1] + fVar10;
    fStack_7c = fVar13;
    if (fVar13 <= fVar11) {
      fStack_7c = fVar11;
    }
    if (fVar11 <= fVar13) {
      fVar13 = fVar11;
    }
    fStack_78 = fStack_80;
    if (fStack_80 <= fVar10) {
      fStack_78 = fVar10;
    }
    if (fVar10 <= fStack_80) {
      fStack_80 = fVar10;
    }
    dVar9 = (double)((fStack_78 - fStack_80) * (fStack_78 - fStack_80) +
                    (fStack_7c - fVar13) * (fStack_7c - fVar13));
    fStack_4c = fVar13;
    fStack_48 = fStack_80;
    fStack_44 = fStack_7c;
    fStack_40 = fStack_78;
    FUN_017267a0();
    if (0.0 < (float)dVar9) {
      piVar5 = (int *)FUN_00d5be40();
      if (piVar5 != (int *)0x0) {
        uVar6 = (**(code **)(*piVar5 + 0xd4))(auStack_3c);
        pfVar3 = (float *)FUN_00802e80(auStack_2c,uVar6);
        fVar13 = *pfVar3;
        fStack_7c = pfVar3[2];
        fStack_80 = pfVar3[1];
        fStack_78 = pfVar3[3];
        fStack_4c = fVar13;
        if ((NAN(fStack_7c - fVar13) != (fStack_7c - fVar13 == 0.0)) &&
           (NAN(fStack_78 - fStack_80) != (fStack_78 - fStack_80 == 0.0))) {
          return 0;
        }
      }
      iVar2 = FUN_006ebc30(param_1);
      if (iVar2 != 0) {
        FUN_00b98870(auStack_6c);
        if (*(char *)(param_1 + 0x53) == '\0') {
          iVar2 = FUN_00c322c0();
          if (iVar2 == 0) {
            return 0;
          }
          if (*(char *)(iVar2 + 0x15c) == '\0') {
            return 0;
          }
          fVar8 = 0.0;
          fVar11 = 0.0;
          fVar10 = 0.0;
          fVar12 = 0.0;
        }
        else {
          pfVar3 = (float *)FUN_01126580(auStack_54);
          fStack_74 = *pfVar3 + 0.0;
          fStack_70 = pfVar3[1] + 0.0;
          pfVar3 = (float *)FUN_00712c50(auStack_1c,&fStack_74,auStack_6c);
          fVar11 = *pfVar3;
          fVar10 = pfVar3[1];
          fVar12 = pfVar3[2];
          fVar8 = pfVar3[3];
        }
        if (fVar12 <= fVar13) {
          return 0;
        }
        if (fVar8 <= fStack_80) {
          return 0;
        }
        if (fStack_7c <= fVar11) {
          return 0;
        }
        if (fStack_78 <= fVar10) {
          return 0;
        }
      }
    }
    iVar2 = FUN_00c6e680();
    param_1 = (int *)FUN_00b59820(iVar2);
    if (param_1 == (int *)0x0) {
      iVar7 = FUN_00817f60(iVar2);
      if (iVar7 != 0) {
        return 1;
      }
      if (iVar2 != 0) {
        iVar2 = *(int *)(iVar2 + 0xc);
        iVar7 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
            (uint)*(ushort *)(iVar7 + 0x1da)) {
          return 1;
        }
        return 0;
      }
      return 0;
    }
    cVar1 = (**(code **)(*param_1 + 0xdc))();
  } while( true );
}



/* FUNCTION 29253 ; VA 0x00c78230 ; FUN_00c78230 */

uint __thiscall FUN_00c78230(int param_1,float *param_2,float param_3)

{
  float *pfVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined *puVar5;
  code *pcVar6;
  int iVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  undefined auStack_44 [16];
  undefined auStack_34 [16];
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  int *piStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  int *piStack_8;
  
  if (DAT_01d67920 == '\0') {
    pfVar1 = (float *)FUN_00d5c5d0(auStack_44);
    fVar8 = *(float *)(param_1 + 0xa8);
    fStack_24 = *pfVar1;
    fStack_20 = pfVar1[1];
    fStack_1c = pfVar1[2];
    piStack_18 = (int *)pfVar1[3];
    if (NAN(fVar8) == (fVar8 == 0.0)) {
      fVar10 = (float)(*(uint *)(param_1 + 0xac) ^ DAT_018c4ea0);
      if (NAN((float)((uint)fVar8 ^ DAT_018c4ea0)) == ((float)((uint)fVar8 ^ DAT_018c4ea0) == 0.0))
      {
        fVar9 = *param_2 - *(float *)(param_1 + 0xb4);
        iVar7 = *(int *)(param_1 + 0x134);
        fVar8 = param_2[1] - *(float *)(param_1 + 0xb8);
        piStack_8 = (int *)(*(float *)(param_1 + 0xb0) * fVar8 + fVar9 * fVar10 +
                           *(float *)(param_1 + 0xb8));
        fStack_c = (fVar9 * *(float *)(param_1 + 0xb0) - fVar8 * fVar10) +
                   *(float *)(param_1 + 0xb4);
      }
      else {
        fStack_c = *param_2;
        iVar7 = *(int *)(param_1 + 0x134);
        piStack_8 = (int *)param_2[1];
      }
      goto LAB_00c78357;
    }
    uVar4 = *(undefined4 *)(param_1 + 0x134);
    puVar2 = (undefined4 *)FUN_01166750(param_2);
    param_3._3_1_ = FUN_01084370(*puVar2,uVar4);
    piStack_8 = (int *)FUN_00d5be40();
    if (piStack_8 == (int *)0x0) goto LAB_00c78501;
    FUN_00d5c5d0(auStack_44);
    pcVar6 = *(code **)(*piStack_8 + 0xd4);
    puVar5 = auStack_34;
  }
  else {
    pfVar1 = (float *)FUN_00d5c5d0(&fStack_14);
    fVar8 = 0.0;
    if (0.0 <= param_3) {
      fVar8 = param_3;
    }
    if (fVar8 <= param_3) {
      param_3 = fVar8;
    }
    fStack_24 = *pfVar1 - param_3;
    fStack_20 = pfVar1[1] - param_3;
    fStack_1c = pfVar1[2] + param_3;
    piStack_18 = (int *)(pfVar1[3] + param_3);
    fVar8 = *(float *)(param_1 + 0xa8);
    if (NAN(fVar8) == (fVar8 == 0.0)) {
      fVar10 = (float)(*(uint *)(param_1 + 0xac) ^ DAT_018c4ea0);
      if (NAN((float)((uint)fVar8 ^ DAT_018c4ea0)) == ((float)((uint)fVar8 ^ DAT_018c4ea0) == 0.0))
      {
        fVar9 = *param_2 - *(float *)(param_1 + 0xb4);
        fVar8 = param_2[1] - *(float *)(param_1 + 0xb8);
        piStack_8 = (int *)(fVar8 * *(float *)(param_1 + 0xb0) + fVar9 * fVar10 +
                           *(float *)(param_1 + 0xb8));
        fStack_c = (fVar9 * *(float *)(param_1 + 0xb0) - fVar8 * fVar10) +
                   *(float *)(param_1 + 0xb4);
      }
      else {
        fStack_c = *param_2;
        piStack_8 = (int *)param_2[1];
      }
      iVar7 = (int)((float)*(int *)(param_1 + 0x134) + param_3);
LAB_00c78357:
      puVar2 = (undefined4 *)FUN_01166750(&fStack_c);
      uVar3 = FUN_01084370(*puVar2,iVar7);
      return uVar3;
    }
    iVar7 = *(int *)(param_1 + 0x134);
    puVar2 = (undefined4 *)FUN_01166750(param_2);
    param_3._3_1_ = FUN_01084370(*puVar2,(int)((float)iVar7 + param_3));
    piStack_8 = (int *)FUN_00d5be40();
    if (piStack_8 == (int *)0x0) goto LAB_00c78501;
    FUN_00d5c5d0(auStack_34);
    pcVar6 = *(code **)(*piStack_8 + 0xd4);
    puVar5 = auStack_44;
  }
  uVar4 = (*pcVar6)(puVar5);
  FUN_00802e80(&fStack_14,uVar4);
  fStack_24 = fStack_14;
  fStack_20 = fStack_10;
  fStack_1c = fStack_c;
  piStack_18 = piStack_8;
LAB_00c78501:
  puVar2 = (undefined4 *)FUN_01166750(param_2);
  uVar4 = *puVar2;
  uVar3 = (uint)(short)uVar4;
  if ((fStack_24 <= (float)(int)uVar3) && ((float)(int)uVar3 <= fStack_1c)) {
    uVar3 = (uint)(short)((uint)uVar4 >> 0x10);
    if ((fStack_20 <= (float)(int)uVar3) &&
       (((float)(int)uVar3 <= (float)piStack_18 && (param_3._3_1_ != '\0')))) {
      return CONCAT31((int3)(char)((uint)uVar4 >> 0x18),1);
    }
  }
  return uVar3 & 0xffffff00;
}



/* FUNCTION 29254 ; VA 0x00c78560 ; FUN_00c78560 */

bool FUN_00c78560(undefined4 *param_1)

{
  if (param_1 == &DAT_021383a0) {
    return DAT_01d70350 == '\0';
  }
  return false;
}



/* FUNCTION 29255 ; VA 0x00c78580 ; FUN_00c78580 */

uint __fastcall FUN_00c78580(int param_1)

{
  int iVar1;
  uint in_EAX;
  uint uVar2;
  int iVar3;
  
  if (*(char *)(param_1 + 0x340) != '\0') {
    while( true ) {
      uVar2 = FUN_00c6e680();
      in_EAX = uVar2;
      if (uVar2 == 0) break;
      iVar1 = *(int *)(uVar2 + 0xc);
      iVar3 = FUN_00c6de80();
      in_EAX = (uint)*(ushort *)(iVar3 + 0x1da);
      if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
        if (uVar2 != 0) {
          iVar1 = *(int *)(uVar2 + 0xc);
          iVar3 = FUN_00d5e4a0();
          in_EAX = (uint)*(ushort *)(iVar3 + 0x1da);
          if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <= in_EAX) {
            return CONCAT31((uint3)(byte)(*(ushort *)(iVar3 + 0x1da) >> 8),1);
          }
        }
        break;
      }
      if (*(char *)(uVar2 + 0x340) == '\0') break;
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 29256 ; VA 0x00c78600 ; FUN_00c78600 */

bool __fastcall FUN_00c78600(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_006ebc30(param_1);
  if (iVar1 != 0) {
    iVar1 = FUN_00b98e50();
    if (iVar1 != 0) {
      return iVar1 == param_1;
    }
  }
  return false;
}



/* FUNCTION 29257 ; VA 0x00c78630 ; FUN_00c78630 */

undefined4 __thiscall FUN_00c78630(int param_1,float *param_2)

{
  float *pfVar1;
  undefined auStack_14 [16];
  
  if (*(char *)(param_1 + 0xdc) != '\0') {
    pfVar1 = (float *)FUN_00d5c5d0(auStack_14);
    if ((((*param_2 <= pfVar1[2] && pfVar1[2] != *param_2) &&
         (param_2[1] <= pfVar1[3] && pfVar1[3] != param_2[1])) &&
        (*pfVar1 <= param_2[2] && param_2[2] != *pfVar1)) &&
       (pfVar1[1] <= param_2[3] && param_2[3] != pfVar1[1])) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 29258 ; VA 0x00c78690 ; FUN_00c78690 */

void FUN_00c78690(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c7d060();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29259 ; VA 0x00c786d0 ; FUN_00c786d0 */

void FUN_00c786d0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c7d110();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29260 ; VA 0x00c78710 ; FUN_00c78710 */

void FUN_00c78710(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c7d1a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29261 ; VA 0x00c78750 ; FUN_00c78750 */

void FUN_00c78750(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c7d230();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29262 ; VA 0x00c78790 ; FUN_00c78790 */

void FUN_00c78790(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c7d2c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29263 ; VA 0x00c787d0 ; FUN_00c787d0 */

void FUN_00c787d0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c7d370();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29264 ; VA 0x00c78810 ; FUN_00c78810 */

void FUN_00c78810(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c7d400();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29265 ; VA 0x00c78850 ; FUN_00c78850 */

void FUN_00c78850(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1e0b22c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&TypeDescriptor_01e0b228;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 29266 ; VA 0x00c788c0 ; FUN_00c788c0 */

int * FUN_00c788c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c7896b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c788fe. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e0b1f4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_0d9540f29ab1d14c5b56fcbfc6fe96c5>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 29267 ; VA 0x00c78980 ; FUN_00c78980 */

int * FUN_00c78980(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c78a2b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c789be. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e0b184);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_c123a7edf97377abe28a5374b9caf3e1>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 29268 ; VA 0x00c78a40 ; FUN_00c78a40 */

int * FUN_00c78a40(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c78aeb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c78a7e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e0b1bc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_ff99e1b308272e0fb85e0d7169068807>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 29269 ; VA 0x00c78b00 ; FUN_00c78b00 */

void FUN_00c78b00(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796bdf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x2c);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_00c6f3b0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00d88a30();
        piVar1 = *(int **)(iVar3 + 8);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x2c);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1e0b25c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::GuiObject>,class_RBX::Lua::WeakFunctionRef,enum_RBX::TweenInfo::TweenStatus),class_boost::_bi::list3<class_boost::_bi::value<class_std::weak_ptr<class_RBX::GuiObject>_>,class_boost::_bi::value<class_RBX::Lua::WeakFunctionRef>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 29270 ; VA 0x00c78c60 ; FUN_00c78c60 */

void __thiscall FUN_00c78c60(int *param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piStack_28;
  int *piStack_24;
  int iStack_14;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piStack_24 = (int *)param_2;
  piStack_28 = (int *)0xc78c76;
  piStack_c = param_1;
  FUN_00d5cef0();
  piStack_24 = (int *)0xc78c7d;
  iVar2 = FUN_00c6e6c0();
  piStack_24 = &iStack_14;
  *(bool *)(param_1 + 0x53) = iVar2 != 0;
  piStack_8 = (int *)param_1[0xd];
  piStack_28 = (int *)0xc78c9d;
  piVar3 = (int *)FUN_00587490();
  piVar7 = piStack_10;
  piVar3 = (int *)*piVar3;
  if (piStack_10 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_10[1] + -1;
    piStack_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_24 = (int *)0xc78cbb;
      (**(code **)*piStack_10)();
      LOCK();
      piVar9 = piVar7 + 2;
      iVar2 = *piVar9 + -1;
      *piVar9 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_24 = (int *)0xc78ccb;
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  if (piStack_8 == (int *)0x0) {
    piVar7 = param_1;
    piVar9 = (int *)0x0;
  }
  else {
    puVar6 = (undefined4 *)piStack_8[0xb];
    if (puVar6 != (undefined4 *)0x0) {
      piVar5 = (int *)puVar6[1];
      for (piVar8 = (int *)*puVar6; piVar8 != piVar5; piVar8 = piVar8 + 2) {
        piStack_8 = (int *)*piVar8;
        if (piStack_8 != (int *)0x0) {
          iVar2 = piStack_8[3];
          piStack_24 = (int *)0xc78cf3;
          iVar4 = FUN_00ee64a0();
          piVar7 = piStack_c;
          piVar9 = piStack_8;
          if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
              (uint)*(ushort *)(iVar4 + 0x1da)) goto LAB_00c78d2c;
        }
      }
    }
    piVar7 = piStack_c;
    piVar9 = (int *)0x0;
  }
LAB_00c78d2c:
  if (piVar3 != piVar9) {
    piStack_28 = &iStack_14;
    piStack_24 = piVar9;
    piVar5 = (int *)FUN_0060dcd0();
    iVar2 = piVar5[1];
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 8) = *(int *)(iVar2 + 8) + 1;
      UNLOCK();
      iVar2 = piVar5[1];
    }
    piVar7[0x36] = *piVar5;
    piVar5 = (int *)piVar7[0x37];
    piVar7[0x37] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_24 = (int *)0xc78d76;
        (**(code **)(*piVar5 + 4))();
      }
    }
    piVar5 = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[1] + -1;
      piStack_10[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_24 = (int *)0xc78d8d;
        (**(code **)*piStack_10)();
        LOCK();
        piVar8 = piVar5 + 2;
        iVar2 = *piVar8 + -1;
        *piVar8 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_24 = (int *)0xc78d9e;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piVar9 != (int *)0x0) {
      iVar2 = piVar9[3];
      piStack_24 = (int *)0xc78daa;
      iVar4 = FUN_00de9720();
      if (((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
           (uint)*(ushort *)(iVar4 + 0x1da)) && (piVar9[0x1b] == 1)) {
        FUN_0060dcd0(&piStack_28,piVar7);
        FUN_00deb210();
      }
    }
  }
  piStack_24 = (int *)0xc78de8;
  iVar2 = FUN_00c6e680();
  if (iVar2 == 0) {
LAB_00c78e0f:
    piStack_24 = &iStack_14;
    piStack_28 = (int *)0xc78e1e;
    puVar6 = (undefined4 *)FUN_00587490();
    piStack_c = (int *)*puVar6;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[1] + -1;
      piStack_10[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_24 = (int *)0xc78e3c;
        (**(code **)*piStack_10)();
        LOCK();
        piVar9 = piStack_10 + 2;
        iVar2 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          piStack_24 = (int *)0xc78e4b;
          (**(code **)(*piStack_10 + 4))();
        }
      }
    }
    if (piVar3 == piStack_c) goto LAB_00c78e5a;
  }
  else {
    iVar2 = *(int *)(iVar2 + 0xc);
    piStack_24 = (int *)0xc78df4;
    iVar4 = FUN_00d59db0();
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) goto LAB_00c78e0f;
  }
  piStack_24 = (int *)0xc78e5a;
  FUN_00d5c900();
LAB_00c78e5a:
  if (*(char *)(piVar7 + 0xb9) == '\0') {
    piStack_24 = (int *)0x0;
    piStack_28 = piVar7;
    cVar1 = FUN_0098c5a0();
    if (cVar1 != '\0') {
      piStack_24 = (int *)0xc78e7c;
      (**(code **)(*piVar7 + 0x128))();
    }
  }
  return;
}



/* FUNCTION 29271 ; VA 0x00c78e90 ; FUN_00c78e90 */

void FUN_00c78e90(undefined4 param_1)

{
  FUN_00c78ef0(param_1);
  FUN_00c6c430(param_1);
  FUN_00c6c430(param_1);
  FUN_00c6c430(param_1);
  FUN_00c6c430(param_1);
  FUN_00c6c430(param_1);
  FUN_00c6c430(param_1);
  return;
}



/* FUNCTION 29272 ; VA 0x00c78ef0 ; FUN_00c78ef0 */

void FUN_00c78ef0(undefined *param_1)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e688;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00587490(auStack_1c);
  iVar5 = *piVar3;
  uStack_8 = 0;
  if (iVar5 != 0) {
    iVar1 = *(int *)(iVar5 + 0xc);
    iVar4 = FUN_00de9720();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) goto LAB_00c78f52;
  }
  iVar5 = 0;
LAB_00c78f52:
  uStack_8 = 0xffffffff;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_18[1] + -1;
    piStack_18[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar3 = piStack_18 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (((param_1 == &DAT_0211a3a0) && (iVar5 != 0)) && (*(int *)(iVar5 + 0x6c) == 0)) {
    FUN_010113f0();
  }
  FUN_00c6c430(param_1);
  FUN_00c6c430(param_1);
  FUN_00c6c430(param_1);
  FUN_00c6c430(param_1);
  FUN_00c6c430(param_1);
  FUN_00c6c430(param_1);
  cVar2 = FUN_016793f0();
  if ((cVar2 == '\0') && (*(int *)(param_1 + 4) == *(int *)(*(int *)(iStack_14 + 0x2cc) + 4))) {
    iVar5 = (**(code **)(**(int **)(*(int *)(iStack_14 + 0x2cc) + 0x34) + 0xc))
                      (*(undefined4 *)(iStack_14 + 0x2d0));
    if (iVar5 < 1) {
      cVar2 = FUN_016793f0();
      if (cVar2 != '\0') {
        FUN_01679490();
      }
    }
    else {
      cVar2 = FUN_016793f0();
      if (cVar2 == '\0') {
        (*(code *)**(undefined4 **)(iStack_14 + 0x2c8))();
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29273 ; VA 0x00c79070 ; FUN_00c79070 */

void __thiscall FUN_00c79070(int *param_1,undefined4 param_2,int param_3)

{
  FUN_008a4210(param_2,param_3);
  if (param_3 != 0) {
    (**(code **)(*param_1 + 0x124))();
  }
  return;
}



/* FUNCTION 29274 ; VA 0x00c790a0 ; FUN_00c790a0 */

undefined4 * __thiscall FUN_00c790a0(int *param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  char cVar4;
  int iVar5;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e6b0;
  pvStack_10 = ExceptionList;
  iStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_24);
  uStack_8 = 0;
  if (iStack_24 == 0) {
    FUN_00587490(&iStack_1c);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iStack_1c != 0) {
      iVar2 = *(int *)(iStack_1c + 0xc);
      iVar5 = FUN_00ee76e0();
      iStack_14 = 0;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        iStack_14 = iStack_1c;
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar2 = piStack_18[2] + -1;
        piStack_18[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  else {
    iVar2 = *(int *)(iStack_24 + 0xc);
    iVar5 = FUN_00ee76e0();
    iStack_14 = 0;
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      iStack_14 = iStack_24;
    }
  }
  uStack_8 = 0xffffffff;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar2 = piStack_20[2] + -1;
      piStack_20[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (iStack_14 != 0) {
    FUN_00ee96c0(&iStack_38,param_1,param_3);
    if (iStack_38 == 1) {
      param_2[1] = uStack_34;
      param_2[2] = uStack_30;
      *param_2 = 1;
      param_2[3] = uStack_2c;
      param_2[4] = piStack_28;
      ExceptionList = pvStack_10;
      return param_2;
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(*param_3 + 0x54);
  if (uVar3 < 5) {
    (**(code **)(*param_1 + 0x130))(param_2,param_3);
  }
  else if (uVar3 == 8) {
    (**(code **)(*param_1 + 0x13c))(param_2,param_3);
  }
  else if (uVar3 == 7) {
    (**(code **)(*param_1 + 300))(param_2,param_3);
  }
  else {
    cVar4 = FUN_00d81a20();
    if (cVar4 == '\0') {
      FUN_008b6b50(param_2);
    }
    else {
      (**(code **)(*param_1 + 0x140))(param_2,param_3);
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29275 ; VA 0x00c792a0 ; FUN_00c792a0 */

void FUN_00c792a0(undefined4 *param_1,int *param_2)

{
  int iVar1;
  int iStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (*(int *)(*param_2 + 0xa8) == 0x3ea) {
    FUN_00c72530(&iStack_18,param_2);
    if (iStack_18 == 1) {
      param_1[1] = uStack_14;
      param_1[2] = uStack_10;
      *param_1 = 1;
      param_1[3] = uStack_c;
      param_1[4] = piStack_8;
      return;
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[2] + -1;
      piStack_8[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return;
}



/* FUNCTION 29276 ; VA 0x00c79330 ; FUN_00c79330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00c79330(int *param_1,undefined4 *param_2,undefined4 param_3,int *param_4,undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void **ppvVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  int *piVar9;
  undefined auStack_100 [200];
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  code *pcStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e6db;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0xd0) == '\0') {
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = 0;
    return;
  }
  piVar9 = *(int **)*param_4;
  ExceptionList = &pvStack_10;
  ppvVar4 = &pvStack_10;
  if (piVar9 != (int *)((int *)*param_4)[1]) {
    do {
      iVar1 = *piVar9;
      pcStack_1c = *(code **)(*param_1 + 0x10c);
      iVar6 = FUN_0088d730();
      if (iVar1 == iVar6) {
        iVar1 = *piVar9;
        iVar6 = FUN_0088d730();
        if (iVar1 != iVar6) {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Variant cast failed");
        }
        piVar8 = piVar9 + 2;
        if (piVar9[1] == 0) {
          piVar8 = (int *)0x0;
        }
        iStack_18 = *piVar8;
        piStack_14 = (int *)piVar8[1];
      }
      else {
        puVar7 = (undefined4 *)piVar9[1];
        if (puVar7 != (undefined4 *)0x0) {
          (*(code *)*puVar7)(piVar9 + 2,auStack_100);
          puVar7 = (undefined4 *)piVar9[1];
        }
        uStack_8 = 0;
        piVar8 = (int *)FUN_0088b680();
        iStack_18 = *piVar8;
        piStack_14 = (int *)piVar8[1];
        uStack_8 = 1;
        if (puVar7 != (undefined4 *)0x0) {
          (*(code *)puVar7[2])(auStack_100);
        }
        uStack_8 = 0xffffffff;
      }
      cVar5 = (*pcStack_1c)(&iStack_18,0);
      if (cVar5 == '\0') {
        *param_2 = 0;
        param_2[1] = 0;
        param_2[2] = 0;
        param_2[3] = 0;
        param_2[4] = 0;
        ExceptionList = pvStack_10;
        return;
      }
      piVar9 = piVar9 + 0x34;
      ppvVar4 = (void **)ExceptionList;
    } while (piVar9 != *(int **)(*param_4 + 4));
  }
  ExceptionList = ppvVar4;
  if (*(char *)((int)param_1 + 0x341) == '\0') {
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 1;
    FUN_0060e0c0(&uStack_24,0);
    uStack_8 = 2;
    puVar7 = (undefined4 *)FUN_0060e0c0(&iStack_18,param_1);
    uVar2 = *puVar7;
    uVar3 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_20[2] + -1;
      piStack_20[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar9 = piStack_14 + 2;
      iVar1 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    *param_2 = uStack_30;
    param_2[1] = uStack_2c;
    param_2[2] = uStack_28;
    param_2[3] = uVar2;
    param_2[4] = uVar3;
    ExceptionList = pvStack_10;
    return;
  }
  FUN_00c76620(param_3,param_4,param_5);
  uStack_30 = _DAT_0192d580;
  uStack_2c = _UNK_0192d584;
  uStack_28 = _UNK_0192d588;
  uStack_24 = _UNK_0192d58c;
  piStack_20 = (int *)0x0;
  uStack_8 = 3;
  puVar7 = (undefined4 *)FUN_0060e0c0(auStack_38,param_1);
  uVar2 = *puVar7;
  uVar3 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_34[2] + -1;
    piStack_34[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*piStack_34 + 4))();
    }
  }
  *param_2 = 1;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[4] = uVar3;
  param_2[3] = uVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29277 ; VA 0x00c79600 ; FUN_00c79600 */

void FUN_00c79600(undefined4 *param_1,int *param_2)

{
  int iVar1;
  int iStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (*(int *)(*param_2 + 0xa8) == 0xd) {
    FUN_00c72530(&iStack_18,param_2);
    if (iStack_18 == 1) {
      param_1[1] = uStack_14;
      param_1[2] = uStack_10;
      *param_1 = 1;
      param_1[3] = uStack_c;
      param_1[4] = piStack_8;
      return;
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[2] + -1;
      piStack_8[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return;
}



/* FUNCTION 29278 ; VA 0x00c79690 ; FUN_00c79690 */

undefined4 * __thiscall FUN_00c79690(int *param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  bool bVar9;
  undefined4 in_stack_ffffff80;
  undefined4 uVar10;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int iStack_4c;
  int *piStack_48;
  int *piStack_44;
  int iStack_40;
  int *piStack_3c;
  float fStack_38;
  float fStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  char cStack_15;
  char cStack_14;
  char cStack_13;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e731;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  FUN_00d814c0(&fStack_38);
  cStack_13 = (**(code **)(*param_1 + 0x10c))(&fStack_38,0);
  iVar4 = *param_3;
  iVar7 = *(int *)(iVar4 + 0x5c);
  if ((iVar7 == 0) && (*(int *)(iVar4 + 0x54) == 0)) {
    cStack_14 = '\x01';
LAB_00c796fd:
    cStack_12 = '\0';
    if ((iVar7 != 0) || (*(int *)(iVar4 + 0x54) != 1)) goto LAB_00c797e8;
    cStack_15 = '\x01';
LAB_00c79717:
    bVar2 = false;
  }
  else {
    cStack_14 = '\0';
    if ((iVar7 != 2) || (*(int *)(iVar4 + 0x54) != 0)) goto LAB_00c796fd;
    cStack_12 = '\x01';
LAB_00c797e8:
    cStack_15 = '\0';
    if ((iVar7 != 2) || (*(int *)(iVar4 + 0x54) != 1)) goto LAB_00c79717;
    bVar2 = true;
  }
  bVar9 = true;
  iVar7 = param_1[0xba];
  cStack_11 = '\0';
  iStack_20 = iVar7;
  if (*(int *)(iVar4 + 0x58) == 7) {
    iVar4 = FUN_00b599b0();
    if (iVar4 != 0) {
      cVar3 = FUN_01083200();
      bVar9 = cVar3 == '\0';
      iVar7 = iStack_20;
      if ((iStack_20 == 2) && (bVar9)) {
        (*(code *)**(undefined4 **)(iVar4 + 0x358))();
        iVar7 = iStack_20;
      }
    }
    if ((param_1[0xd] != 0) &&
       (((iVar4 = FUN_00c6e770(), iVar4 != 0 || (iVar4 = FUN_00c6e650(), iVar4 != 0)) &&
        (cVar3 = FUN_01083200(), cVar3 != '\0')))) {
      *param_2 = 0;
      param_2[1] = 0;
      param_2[2] = 0;
      param_2[3] = 0;
      param_2[4] = 0;
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  if (((cStack_12 != '\0') && (iVar7 == 2)) &&
     ((bVar9 && (cStack_11 = '\x01', *(int *)(*param_3 + 0x58) == *(int *)(*param_3 + 0x54))))) {
    FUN_006eccd0();
  }
  if (((bVar2) && (iVar7 == 2)) && (bVar9)) {
    cStack_11 = '\x01';
    FUN_006eccd0();
  }
  if (cStack_13 != '\0') {
    if (cStack_14 != '\0') {
      cStack_11 = '\x01';
      in_stack_ffffff80 = 0xc79878;
      FUN_006150c0((int)fStack_38,(int)fStack_34);
    }
    if (cStack_15 != '\0') {
      cStack_11 = '\x01';
      in_stack_ffffff80 = 0xc79899;
      FUN_006150c0((int)fStack_38,(int)fStack_34);
    }
    if (cStack_12 != '\0') {
      cStack_11 = '\x01';
      in_stack_ffffff80 = 0xc798ba;
      FUN_006150c0((int)fStack_38,(int)fStack_34);
    }
    if (bVar2) {
      cStack_11 = '\x01';
      in_stack_ffffff80 = 0xc798d9;
      FUN_006150c0((int)fStack_38,(int)fStack_34);
    }
  }
  piVar5 = (int *)FUN_00587490(&iStack_40);
  piVar6 = piStack_3c;
  if (((*piVar5 != 0) || (*(int *)(*param_3 + 0x5c) != 0)) ||
     (cStack_15 = '\x01', *(int *)(*param_3 + 0x58) != 0)) {
    cStack_15 = '\0';
  }
  if (piStack_3c != (int *)0x0) {
    uStack_1c = 0;
    LOCK();
    iVar4 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_3c)();
      uStack_1c = 0;
      LOCK();
      piVar5 = piVar6 + 2;
      iVar4 = *piVar5 + -1;
      *piVar5 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  uStack_1c = 0;
  if (cStack_15 == '\0') {
    uVar8 = 0xc79ac7;
    FUN_00587490(&iStack_40);
    uStack_8 = 5;
    if (((iStack_40 != 0) && (*(int *)(iStack_40 + 0x5c) == 2)) &&
       ((cStack_13 != '\0' &&
        ((*(char *)((int)param_1 + 0x341) != '\0' && (*(char *)(param_1 + 0x5f) == '\0')))))) {
      FUN_00c44b70();
      uVar10 = *(undefined4 *)(iStack_40 + 0xb0);
      FUN_00557fc0(&iStack_40);
      FUN_0089bf10(in_stack_ffffff80,uVar8,uVar10);
    }
    uStack_8 = 0xffffffff;
    if (piStack_3c == (int *)0x0) goto LAB_00c79b4d;
    LOCK();
    iVar4 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar4;
    UNLOCK();
    if (iVar4 != 0) goto LAB_00c79b4d;
    (**(code **)*piStack_3c)();
  }
  else {
    if (((cStack_13 == '\0') || (*(char *)((int)param_1 + 0x341) == '\0')) ||
       (*(char *)(param_1 + 0x5f) != '\0')) goto LAB_00c79b4d;
    FUN_0088ddf0(param_3);
    FUN_0060e0c0(&iStack_40,param_1);
    if (piStack_3c != (int *)0x0) {
      LOCK();
      piStack_3c[2] = piStack_3c[2] + 1;
      UNLOCK();
    }
    iStack_4c = iStack_40;
    piStack_48 = piStack_3c;
    iStack_20 = *param_3 + 0xd8;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    piStack_44 = param_1;
    piVar6 = (int *)FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 3;
    piStack_2c = piVar6;
    puStack_24 = (undefined4 *)FUN_01674e20(0x24);
    if (puStack_24 == (undefined4 *)0x0) {
      puStack_24 = (undefined4 *)0x0;
    }
    else {
      *puStack_24 = 0;
      puStack_24[1] = 1;
      puStack_24[2] = FUN_00c75c10;
      puStack_24[3] = FUN_005d3660;
      puStack_24[4] = 0;
      puStack_24[5] = iStack_20;
      puStack_24[6] = 0;
      puStack_24[7] = 0;
      if (piStack_3c != (int *)0x0) {
        LOCK();
        piStack_3c[2] = piStack_3c[2] + 1;
        UNLOCK();
      }
      puStack_24[6] = iStack_40;
      puStack_24[7] = piStack_3c;
      puStack_24[8] = param_1;
    }
    FUN_016797d0(puStack_24);
    puStack_28 = puStack_24;
    if (puStack_24 != (undefined4 *)0x0) {
      LOCK();
      puStack_24[1] = puStack_24[1] + 1;
      UNLOCK();
    }
    uStack_1c = 4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_01675290(piVar6);
    puStack_28 = (undefined4 *)param_1[0xdc];
    param_1[0xdc] = (int)puStack_24;
    FUN_0056e750();
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
    uStack_8 = 0xffffffff;
    if (piStack_3c == (int *)0x0) goto LAB_00c79b4d;
  }
  LOCK();
  iVar4 = piStack_3c[2] + -1;
  piStack_3c[2] = iVar4;
  UNLOCK();
  if (iVar4 == 0) {
    (**(code **)(*piStack_3c + 4))();
  }
LAB_00c79b4d:
  (**(code **)(*param_1 + 0x134))(&uStack_60,param_3,1);
  uStack_8 = 6;
  if (cStack_11 != '\0') {
    iVar4 = FUN_00c322c0();
    if (iVar4 == 0) {
      *param_2 = 1;
      param_2[1] = 0;
      param_2[2] = 0;
      param_2[3] = 0;
      param_2[4] = 0;
      if (piStack_50 != (int *)0x0) {
        LOCK();
        piVar6 = piStack_50 + 2;
        iVar4 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_50 + 4))();
        }
      }
      ExceptionList = pvStack_10;
      return param_2;
    }
    if (*(char *)(iVar4 + 0x15c) != '\0') {
      piVar6 = (int *)param_1[0xd];
      if ((piVar6 != (int *)0x0) && (param_1 = piVar6, piVar6[0xd] != 0)) {
        param_1 = (int *)FUN_005c8ac0();
      }
      if ((param_1 != (int *)0x0) &&
         (iVar4 = param_1[3], iVar7 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
         (uint)*(ushort *)(iVar7 + 0x1da))) {
        FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
        uVar8 = FUN_00560d40();
        piVar6 = (int *)FUN_008aa140(uVar8);
        if (*piVar6 == 0) {
          uVar8 = FUN_00995770();
          piVar5 = (int *)FUN_008a9ba0(auStack_30,uVar8);
          iVar4 = *piVar5;
          iVar7 = piVar5[1];
          *piVar5 = 0;
          piVar5[1] = 0;
          *piVar6 = iVar4;
          piVar5 = (int *)piVar6[1];
          piVar6[1] = iVar7;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar4 = piVar5[1] + -1;
            piVar5[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              iVar4 = piVar5[2] + -1;
              piVar5[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          piVar5 = piStack_2c;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar4 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              piVar1 = piVar5 + 2;
              iVar4 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar4 == 1) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
        }
        if ((*piVar6 != 0) && (*(int *)(*piVar6 + 0x68) != 0)) {
          FUN_0090cc40(param_2);
          FUN_008ae7d0();
          ExceptionList = pvStack_10;
          return param_2;
        }
      }
    }
  }
  param_2[1] = uStack_5c;
  param_2[2] = uStack_58;
  *param_2 = uStack_60;
  param_2[3] = uStack_54;
  param_2[4] = piStack_50;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29279 ; VA 0x00c79d40 ; FUN_00c79d40 */

undefined4 __thiscall FUN_00c79d40(int *param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(*param_1 + 0x134))(param_2,param_3,1);
  return param_2;
}



/* FUNCTION 29280 ; VA 0x00c79d60 ; FUN_00c79d60 */

undefined4 * __thiscall FUN_00c79d60(int *param_1,undefined4 *param_2,int *param_3,char param_4)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  char cVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  byte bVar12;
  uint uVar13;
  undefined4 uVar14;
  char cStack0000000f;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  float fStack_20;
  float fStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  int iStack_10;
  int iStack_c;
  char cStack_7;
  byte bStack_6;
  char cStack_5;
  
  uStack_18 = 0;
  pcVar2 = *(code **)(*param_1 + 0x10c);
  uVar7 = FUN_00d814c0(auStack_14);
  bStack_6 = (*pcVar2)(uVar7,0);
  iVar8 = *param_3;
  iVar3 = *(int *)(iVar8 + 0x54);
  if ((*(int *)(iVar8 + 0x5c) == 0) && (iVar3 == 0)) {
    bVar4 = true;
LAB_00c79dbc:
    cStack_5 = '\0';
    if (bVar4) goto LAB_00c79dc4;
  }
  else {
    bVar4 = false;
    if ((*(int *)(iVar8 + 0x5c) != 0) || (iVar3 != 1)) goto LAB_00c79dbc;
LAB_00c79dc4:
    cStack_5 = '\x01';
  }
  if ((iVar3 != 3) || (*(float *)(iVar8 + 0x68) <= 0.0)) {
    cStack_7 = '\0';
    if (iVar3 == 3) goto LAB_00c79de9;
LAB_00c79df3:
    uVar13 = (uint)bStack_6;
  }
  else {
    cStack_7 = '\x01';
LAB_00c79de9:
    if (0.0 < *(float *)(iVar8 + 0x68) || *(float *)(iVar8 + 0x68) == 0.0) goto LAB_00c79df3;
    uVar13 = (uint)CONCAT11(1,bStack_6);
  }
  FUN_00d814c0(&fStack_20);
  iStack_10 = (int)fStack_20;
  iStack_c = (int)fStack_1c;
  if ((param_4 != '\0') && ((char)uVar13 != '\0')) {
    if (iVar3 == 4) {
      FUN_006150c0(iStack_10,iStack_c);
    }
    if (cStack_7 != '\0') {
      FUN_006150c0(iStack_10,iStack_c);
    }
    if ((char)(uVar13 >> 8) != '\0') {
      FUN_006150c0(iStack_10,iStack_c);
    }
  }
  iVar8 = FUN_008acee0(param_1);
  if ((((iVar8 != 0) && (*(char *)((int)param_1 + 0x341) != '\0')) &&
      (*(char *)(param_1 + 0x5f) != '\0')) &&
     ((cVar6 = FUN_00b82b90(), cVar6 != '\0' && (cVar6 = FUN_00b83620(), cVar6 == '\0')))) {
    FUN_00c77a10(param_3);
  }
  cStack0000000f = '\0';
  if ((*(int *)(*param_3 + 0x58) == 7) && (iVar8 = FUN_00b599b0(), iVar8 != 0)) {
    cStack0000000f = FUN_01083200();
  }
  if (*(int *)(*param_3 + 0x58) == *(int *)(*param_3 + 0x54)) {
LAB_00c79f81:
    bVar12 = (byte)uVar13;
    cVar6 = cStack_5;
  }
  else {
    iVar8 = param_1[0xba];
    if ((iVar8 != 0) && (iVar9 = FUN_00817fa0(), iVar9 != 0)) {
      FUN_00d66da0();
    }
    cVar6 = cStack_5;
    bVar12 = bStack_6;
    param_1[0xba] = 0;
    if (iVar8 < 0) {
      uVar13 = (uint)bStack_6;
      goto LAB_00c79f81;
    }
    if (iVar8 < 2) {
      if (bStack_6 != 0) {
        if ((cStack_5 == '\0') || (cStack0000000f != '\0')) {
LAB_00c79f49:
          FUN_00c7bfa0(1);
        }
        else {
          FUN_00c7bfa0(2);
        }
      }
    }
    else if (iVar8 == 2) {
      if (bStack_6 == 0) {
        if ((cStack_5 == '\0') && (iVar3 != 4)) goto LAB_00c79f38;
LAB_00c79f54:
        FUN_00c7bfa0(0);
      }
      else if (((cStack_5 == '\0') && (iVar3 != 4)) || (cStack0000000f != '\0')) {
LAB_00c79f38:
        if (*(int *)(*param_3 + 0x54) != param_1[0x5e]) goto LAB_00c79f54;
        if (bStack_6 != 0) goto LAB_00c79f49;
      }
      else {
        FUN_00c7bfa0(2);
      }
    }
  }
  if (cVar6 == '\0') {
LAB_00c79f9a:
    if ((bVar12 != 0) && (*(char *)((int)param_1 + 0x341) != '\0')) {
      uStack_34 = 0;
      uStack_30 = 0;
      uStack_2c = 1;
      FUN_0060e0c0(&uStack_28,0);
      puVar10 = &uStack_28;
      bVar5 = true;
      bVar4 = false;
      _param_4 = uStack_28;
      uVar7 = uStack_34;
      uVar11 = uStack_30;
      uVar14 = uStack_2c;
      goto LAB_00c7a000;
    }
  }
  else if (bVar12 != 0) {
    param_1[0x5e] = *(int *)(*param_3 + 0x54);
    goto LAB_00c79f9a;
  }
  uVar7 = 0;
  piStack_38 = (int *)0x0;
  _param_4 = 0;
  uVar11 = 0;
  puVar10 = &uStack_3c;
  uStack_3c = 0;
  uVar14 = 0;
  bVar5 = false;
  bVar4 = true;
LAB_00c7a000:
  *puVar10 = 0;
  *param_2 = uVar7;
  param_2[2] = uVar14;
  param_2[1] = uVar11;
  param_2[3] = _param_4;
  param_2[4] = puVar10[1];
  puVar10[1] = 0;
  if ((bVar4) && (piStack_38 != (int *)0x0)) {
    LOCK();
    iVar8 = piStack_38[2] + -1;
    piStack_38[2] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)(*piStack_38 + 4))();
    }
  }
  if ((bVar5) && (piStack_24 != (int *)0x0)) {
    LOCK();
    piVar1 = piStack_24 + 2;
    iVar8 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar8 == 1) {
      (**(code **)(*piStack_24 + 4))();
    }
  }
  return param_2;
}



/* FUNCTION 29281 ; VA 0x00c7a070 ; FUN_00c7a070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c7a070(int *param_1,undefined4 *param_2,int *param_3)

{
  int iVar1;
  code *pcVar2;
  bool bVar3;
  bool bVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  int **ppiVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  int *piStack_50;
  int *piStack_4c;
  int aiStack_48 [3];
  int *piStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  int iStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e779;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  if (*(int *)(*param_3 + 0x54) == 7) {
    pcVar2 = *(code **)(*param_1 + 0x10c);
    ExceptionList = &pvStack_10;
    uVar6 = FUN_00d814c0(&uStack_34);
    cVar5 = (*pcVar2)(uVar6,0);
    if (cVar5 != '\0') {
      if (*(char *)((int)param_1 + 0x341) != '\0') {
        if (((*(char *)(param_1 + 0x5f) == '\0') && (iVar7 = FUN_00b599b0(), iVar7 != 0)) &&
           (cVar5 = FUN_00dd2190(param_3), cVar5 != '\0')) {
          FUN_0090cc40(param_2);
          ExceptionList = pvStack_10;
          return param_2;
        }
        if (((*(char *)((int)param_1 + 0x341) != '\0') && (*(char *)(param_1 + 0x5f) == '\0')) &&
           ((param_1[0xd] != 0 &&
            ((iVar7 = FUN_00c6e770(), iVar7 != 0 || (iVar7 = FUN_00c6e650(), iVar7 != 0)))))) {
          FUN_00ee96c0(aiStack_48,param_1,param_3);
          if (aiStack_48[0] == 1) {
            FUN_008ad9c0(aiStack_48);
            FUN_008ae7d0();
            ExceptionList = pvStack_10;
            return param_2;
          }
          FUN_008ae7d0();
        }
      }
      piVar8 = (int *)FUN_00587490(&uStack_34);
      if ((*piVar8 != 0) || (cStack_11 = '\x01', *(int *)(*param_3 + 0x5c) != 0)) {
        cStack_11 = '\0';
      }
      FUN_00550b30();
      uStack_20 = 0;
      if (cStack_11 == '\0') {
        FUN_00587490(&iStack_2c);
        uStack_8 = 5;
        if ((iStack_2c != 0) && (iStack_2c == *param_3)) {
          if (*(int *)(iStack_2c + 0x5c) == 2) {
            FUN_00c44b70();
            pcVar2 = *(code **)(*param_1 + 0x10c);
            uVar6 = FUN_00d814c0(&uStack_34);
            uVar10 = 0xc7a3d5;
            cVar5 = (*pcVar2)(uVar6,0);
            if (cVar5 != '\0') {
              if ((*(char *)((int)param_1 + 0x341) != '\0') && (*(char *)(param_1 + 0x5f) == '\0'))
              {
                uVar11 = *(undefined4 *)(iStack_2c + 0xb0);
                FUN_00557fc0(&iStack_2c);
                FUN_0089bf10(uVar10,uVar6,uVar11);
              }
              FUN_006eccd0();
              uStack_8 = 0xffffffff;
              FUN_00550b30();
              goto LAB_00c7a309;
            }
          }
          else if (*(int *)(iStack_2c + 0x5c) == 3) {
            FUN_00c44b70();
          }
        }
        uStack_8 = 0xffffffff;
        FUN_00550b30();
      }
      else {
        FUN_0088ddf0(param_3);
        FUN_0060e0c0(&uStack_34,param_1);
        if (piStack_30 != (int *)0x0) {
          LOCK();
          piStack_30[2] = piStack_30[2] + 1;
          UNLOCK();
        }
        aiStack_48[2] = uStack_34;
        piStack_3c = piStack_30;
        iStack_1c = *param_3 + 0xd8;
        uStack_8._0_1_ = 2;
        uStack_8._1_3_ = 0;
        piStack_38 = param_1;
        uVar6 = FUN_01675290(DAT_02110da8);
        uStack_8._0_1_ = 3;
        uStack_24 = uVar6;
        puStack_18 = (undefined4 *)FUN_01674e20(0x24);
        if (puStack_18 == (undefined4 *)0x0) {
          puStack_18 = (undefined4 *)0x0;
        }
        else {
          *puStack_18 = 0;
          puStack_18[1] = 1;
          puStack_18[2] = FUN_00c75d50;
          puStack_18[3] = FUN_005d3660;
          puStack_18[4] = 0;
          puStack_18[5] = iStack_1c;
          puStack_18[6] = 0;
          puStack_18[7] = 0;
          if (piStack_30 != (int *)0x0) {
            LOCK();
            piStack_30[2] = piStack_30[2] + 1;
            UNLOCK();
          }
          puStack_18[6] = uStack_34;
          puStack_18[7] = piStack_30;
          puStack_18[8] = param_1;
        }
        FUN_016797d0(puStack_18);
        puStack_28 = puStack_18;
        if (puStack_18 != (undefined4 *)0x0) {
          LOCK();
          puStack_18[1] = puStack_18[1] + 1;
          UNLOCK();
        }
        uStack_20 = 4;
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        FUN_01675290(uVar6);
        iVar7 = param_1[0xda];
        param_1[0xda] = (int)puStack_18;
        if (iVar7 != 0) {
          piVar8 = (int *)(iVar7 + 4);
          LOCK();
          iVar1 = *piVar8;
          *piVar8 = *piVar8 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            FUN_01674ea0(iVar7);
          }
        }
        if (piStack_30 != (int *)0x0) {
          LOCK();
          iVar7 = piStack_30[2] + -1;
          piStack_30[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piStack_30 + 4))();
          }
        }
        uStack_8 = 0xffffffff;
        if (piStack_30 != (int *)0x0) {
          LOCK();
          iVar7 = piStack_30[2] + -1;
          piStack_30[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piStack_30 + 4))();
          }
        }
      }
    }
  }
LAB_00c7a309:
  if ((*(char *)((int)param_1 + 0x341) != '\0') && (*(char *)(param_1 + 0x5f) != '\0')) {
    FUN_00c77a10(param_3);
  }
  pcVar2 = *(code **)(*param_1 + 0x10c);
  uVar6 = FUN_00d814c0(&iStack_2c);
  cVar5 = (*pcVar2)(uVar6,0);
  if ((cVar5 == '\0') || (*(char *)((int)param_1 + 0x341) == '\0')) {
    piStack_38 = (int *)0x0;
    aiStack_48[0] = 0;
    aiStack_48[1] = 0;
    aiStack_48[2] = 0;
    piStack_3c = (int *)0x0;
    bVar4 = false;
    bVar3 = true;
    ppiVar9 = &piStack_3c;
    uVar6 = 0;
  }
  else {
    ppiVar9 = &piStack_50;
    bVar4 = true;
    bVar3 = false;
    piStack_4c = (int *)0x0;
    piStack_50 = _UNK_0192d58c;
    uVar6 = 1;
  }
  *ppiVar9 = (int *)0x0;
  *param_2 = uVar6;
  piVar8 = ppiVar9[1];
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = piVar8;
  ppiVar9[1] = (int *)0x0;
  if ((bVar3) && (piStack_38 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_38[2] + -1;
    piStack_38[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)(*piStack_38 + 4))();
    }
  }
  if ((bVar4) && (piStack_4c != (int *)0x0)) {
    LOCK();
    piVar8 = piStack_4c + 2;
    iVar7 = *piVar8;
    *piVar8 = *piVar8 + -1;
    UNLOCK();
    if (iVar7 == 1) {
      (**(code **)(*piStack_4c + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29282 ; VA 0x00c7a4f0 ; FUN_00c7a4f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c7a4f0(int *param_1,undefined4 *param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  char cVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  undefined auStack_10 [8];
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*(char *)((int)param_1 + 0x341) != '\0') && (*(char *)(param_1 + 0x5f) != '\0')) {
    FUN_00c77a10(param_3);
  }
  pcVar2 = *(code **)(*param_1 + 0x10c);
  uVar7 = FUN_00d814c0(auStack_10);
  cVar6 = (*pcVar2)(uVar7,0);
  if ((cVar6 == '\0') || (*(char *)((int)param_1 + 0x341) == '\0')) {
    uVar7 = 0;
    piStack_14 = (int *)0x0;
    puVar8 = &uStack_18;
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
    bVar5 = false;
    bVar4 = true;
  }
  else {
    puVar8 = &uStack_2c;
    uVar7 = 1;
    piStack_28 = (int *)0x0;
    uStack_2c = _UNK_0192d58c;
    bVar5 = true;
    bVar4 = false;
  }
  *puVar8 = 0;
  *param_2 = uVar7;
  uVar7 = puVar8[1];
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = uVar7;
  puVar8[1] = 0;
  if (bVar4) {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[2] + -1;
      piStack_14[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if ((bVar5) && (piStack_28 != (int *)0x0)) {
    LOCK();
    piVar1 = piStack_28 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piStack_28 + 4))();
    }
  }
  return param_2;
}



/* FUNCTION 29283 ; VA 0x00c7a5f0 ; FUN_00c7a5f0 */

void __thiscall FUN_00c7a5f0(int param_1,undefined4 param_2)

{
  float fVar1;
  float fVar2;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  float fStack_18;
  undefined4 uStack_14;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  uStack_1c = *(undefined4 *)(param_1 + 0x2dc);
  uStack_10._0_4_ = (undefined4)*(undefined8 *)(param_1 + 0x2d4);
  uStack_24 = (undefined4)uStack_10;
  uStack_10._4_4_ = (undefined4)((ulonglong)*(undefined8 *)(param_1 + 0x2d4) >> 0x20);
  uStack_20 = uStack_10._4_4_;
  fVar1 = DAT_018ce2f8 - *(float *)(param_1 + 0x2f0);
  fVar2 = 0.0;
  if (0.0 <= fVar1) {
    fVar2 = fVar1;
  }
  uStack_14 = 0;
  uStack_10 = 0;
  uStack_8 = 0;
  fStack_18 = DAT_018ce2f8;
  if (fVar2 <= DAT_018ce2f8) {
    fStack_18 = fVar2;
  }
  FUN_00c7b060(param_2,&uStack_24,&uStack_14);
  (**(code **)(*(int *)(param_1 + -0x54) + 0x118))(param_2);
  return;
}



/* FUNCTION 29284 ; VA 0x00c7a680 ; FUN_00c7a680 */

void __thiscall FUN_00c7a680(int *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  float *pfVar4;
  int iVar5;
  float fVar6;
  undefined4 *puVar7;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  undefined8 uStack_24;
  float fStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e882;
  pvStack_10 = ExceptionList;
  iVar5 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeaf0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01efeaf0), DAT_01efeaf0 == -1)) {
    uStack_8 = 0;
    FUN_005542c0("rbxasset://textures/ui/btn_greyTransp.png",0x29);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_009cbbb0(&DAT_01d68928);
    FUN_016f3654(&LAB_018968b0);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeaf0);
  }
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeaf4) && (FUN_016f3809(&DAT_01efeaf4), DAT_01efeaf4 == -1))
  {
    uStack_8 = 2;
    FUN_005542c0("rbxasset://textures/ui/btn_grey.png",0x23);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_009cbbb0(&DAT_01d68940);
    FUN_016f3654(&LAB_01896850);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeaf4);
  }
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeaf8) && (FUN_016f3809(&DAT_01efeaf8), DAT_01efeaf8 == -1))
  {
    uStack_8 = 4;
    FUN_005542c0("rbxasset://textures/ui/btn_white.png",0x24);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_009cbbb0(&DAT_01d68958);
    FUN_016f3654(&LAB_01896c10);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeaf8);
  }
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeafc) && (FUN_016f3809(&DAT_01efeafc), DAT_01efeafc == -1))
  {
    uStack_8 = 6;
    FUN_005542c0("rbxasset://textures/ui/btn_red.png",0x22);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_009cbbb0(&DAT_01d68970);
    FUN_016f3654(&LAB_01896b50);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeafc);
  }
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeb00) && (FUN_016f3809(&DAT_01efeb00), DAT_01efeb00 == -1))
  {
    uStack_8 = 8;
    FUN_005542c0("rbxasset://textures/ui/btn_redGlow.png",0x26);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_009cbbb0(&DAT_01d68988);
    FUN_016f3654(&LAB_01896bb0);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeb00);
  }
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeb04) && (FUN_016f3809(&DAT_01efeb04), DAT_01efeb04 == -1))
  {
    uStack_8 = 10;
    FUN_005542c0("rbxasset://textures/ui/btn_newGrey.png",0x26);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    FUN_009cbbb0(&DAT_01d689a0);
    FUN_016f3654(&LAB_018969d0);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeb04);
  }
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeb08) && (FUN_016f3809(&DAT_01efeb08), DAT_01efeb08 == -1))
  {
    uStack_8 = 0xc;
    FUN_005542c0("rbxasset://textures/ui/btn_newGreyGlow.png",0x2a);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    FUN_009cbbb0(&DAT_01d689b8);
    FUN_016f3654(&LAB_01896a30);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeb08);
  }
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeb0c) && (FUN_016f3809(&DAT_01efeb0c), DAT_01efeb0c == -1))
  {
    uStack_8 = 0xe;
    FUN_005542c0("rbxasset://textures/ui/btn_newBlue.png",0x26);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    FUN_009cbbb0(&DAT_01d689d0);
    FUN_016f3654(&LAB_01896910);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeb0c);
  }
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeb10) && (FUN_016f3809(&DAT_01efeb10), DAT_01efeb10 == -1))
  {
    uStack_8 = 0x10;
    FUN_005542c0("rbxasset://textures/ui/btn_newBlueGlow.png",0x2a);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    FUN_009cbbb0(&DAT_01d689e8);
    FUN_016f3654(&LAB_01896970);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeb10);
  }
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeb14) && (FUN_016f3809(&DAT_01efeb14), DAT_01efeb14 == -1))
  {
    uStack_8 = 0x12;
    FUN_005542c0("rbxasset://textures/ui/btn_newWhite.png",0x27);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
    FUN_009cbbb0(&DAT_01d68a00);
    FUN_016f3654(&LAB_01896a90);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeb14);
  }
  if ((*(int *)(iVar5 + 0x34) < DAT_01efeb18) && (FUN_016f3809(&DAT_01efeb18), DAT_01efeb18 == -1))
  {
    uStack_8 = 0x14;
    FUN_005542c0("rbxasset://textures/ui/btn_newWhiteGlow.png",0x2b);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
    FUN_009cbbb0(&DAT_01d68a18);
    FUN_016f3654(&LAB_01896af0);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01efeb18);
  }
  uVar3 = FUN_00d5be40();
  uVar2 = param_2;
  iVar5 = param_1[0x11c];
  switch(iVar5) {
  case 0:
    uVar1 = *(undefined8 *)(param_1 + 0xca);
    fStack_2c = (float)param_1[0xcc];
    uStack_24._0_4_ = (float)uVar1;
    fStack_34 = (float)uStack_24;
    uStack_24._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
    fStack_30 = uStack_24._4_4_;
    fVar6 = 0.0;
    if (0.0 <= DAT_018ce2f8 - (float)param_1[0xd1]) {
      fVar6 = DAT_018ce2f8 - (float)param_1[0xd1];
    }
    fStack_28 = DAT_018ce2f8;
    if (fVar6 <= DAT_018ce2f8) {
      fStack_28 = fVar6;
    }
    uStack_24 = uVar1;
    fStack_1c = fStack_2c;
    if (*(char *)(param_1 + 0x11b) != '\0') {
      uStack_24 = *(undefined8 *)(param_1 + 0xca);
      if (param_1[0xba] == 1) {
        pfVar4 = (float *)FUN_0115e910();
      }
      else {
        if (param_1[0xba] != 2) goto LAB_00c7a867;
        pfVar4 = (float *)FUN_0115ee70();
      }
      fStack_2c = (pfVar4[2] - fStack_1c) * DAT_018fde64 + fStack_1c;
      fStack_30 = (pfVar4[1] - uStack_24._4_4_) * DAT_018fde64 + uStack_24._4_4_;
      fStack_34 = (*pfVar4 - (float)uStack_24) * DAT_018fde64 + (float)uStack_24;
    }
LAB_00c7a867:
    FUN_00c7b060(uVar2,&fStack_34,param_3);
    ExceptionList = pvStack_10;
    return;
  case 1:
    if (*(char *)(param_1 + 0x11b) == '\0') {
LAB_00c7aa77:
      FUN_00c7bce0(0);
      iVar5 = param_1[0x11d] + 0x44;
      uStack_24 = CONCAT44(0x42100000,(float)uStack_24);
      fStack_1c = 36.0;
      param_2 = 0x80008;
      puVar7 = &DAT_01d68970;
    }
    else if (*(char *)((int)param_1 + 0x341) == '\0') {
LAB_00c7a89f:
      FUN_00c7bce0(0);
      uStack_24 = CONCAT44(0x42100000,(float)uStack_24);
      iVar5 = param_1[0x11d];
      fStack_1c = 36.0;
      param_2 = 0x80008;
      puVar7 = &DAT_01d68928;
    }
    else if (*(char *)((int)param_1 + 0x46d) == '\0') {
      if (param_1[0xba] == 0) goto LAB_00c7aa77;
      FUN_00c7bce0(0);
      iVar5 = param_1[0x11d] + 0x88;
      uStack_24 = CONCAT44(0x42100000,(float)uStack_24);
      fStack_1c = 36.0;
      param_2 = 0x80008;
      puVar7 = &DAT_01d68988;
    }
    else {
      FUN_00c7bce0(0);
      iVar5 = param_1[0x11d] + 0xcc;
      uStack_24 = CONCAT44(0x42100000,(float)uStack_24);
      fStack_1c = 36.0;
      param_2 = 0x80008;
      puVar7 = &DAT_01d68988;
    }
    break;
  case 2:
    if (*(char *)(param_1 + 0x11b) == '\0') {
LAB_00c7a981:
      FUN_00c7bce0(0);
      iVar5 = param_1[0x11d] + 0x44;
      uStack_24 = CONCAT44(0x42100000,(float)uStack_24);
      fStack_1c = 36.0;
      param_2 = 0x80008;
      puVar7 = &DAT_01d68940;
    }
    else {
      if (*(char *)((int)param_1 + 0x341) == '\0') goto LAB_00c7a89f;
      if (*(char *)((int)param_1 + 0x46d) == '\0') {
        if (param_1[0xba] == 0) goto LAB_00c7a981;
        FUN_00c7bce0(0);
        iVar5 = param_1[0x11d] + 0x88;
        uStack_24 = CONCAT44(0x42100000,(float)uStack_24);
        fStack_1c = 36.0;
        param_2 = 0x80008;
        puVar7 = &DAT_01d68958;
      }
      else {
        FUN_00c7bce0(0);
        iVar5 = param_1[0x11d] + 0xcc;
        uStack_24 = CONCAT44(0x42100000,(float)uStack_24);
        fStack_1c = 36.0;
        param_2 = 0x80008;
        puVar7 = &DAT_01d68970;
      }
    }
    break;
  case 3:
  case 4:
  case 5:
    if (iVar5 == 4) {
      puStack_18 = &DAT_01d689d0;
      puStack_14 = &DAT_01d689e8;
    }
    else if (iVar5 == 5) {
      puStack_18 = &DAT_01d68a00;
      puStack_14 = &DAT_01d68a18;
    }
    else {
      puStack_18 = &DAT_01d689a0;
      puStack_14 = &DAT_01d689b8;
    }
    param_2 = 0x60006;
    uStack_24 = CONCAT44(0x41a00000,(float)uStack_24);
    fStack_1c = 20.0;
    if (*(char *)(param_1 + 0x11b) == '\0') {
LAB_00c7ab8e:
      FUN_00c7bce0(0);
      iVar5 = param_1[0x11d] + 0x44;
      puVar7 = puStack_18;
    }
    else if (*(char *)((int)param_1 + 0x341) == '\0') {
      FUN_00c7bce0(0);
      iVar5 = param_1[0x11d];
      puVar7 = &DAT_01d689a0;
    }
    else if (*(char *)((int)param_1 + 0x46d) == '\0') {
      if (param_1[0xba] == 0) goto LAB_00c7ab8e;
      FUN_00c7bce0(0);
      iVar5 = param_1[0x11d] + 0x88;
      puVar7 = puStack_14;
    }
    else {
      FUN_00c7bce0(0);
      iVar5 = param_1[0x11d] + 0xcc;
      puVar7 = puStack_14;
    }
    break;
  default:
    goto switchD_00c7a785_caseD_6;
  }
  FUN_00c7b500(uVar2,puVar7,&param_2,(int)&uStack_24 + 4,iVar5,param_3,uVar3);
switchD_00c7a785_caseD_6:
  (**(code **)(*param_1 + 0x118))(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29285 ; VA 0x00c7b030 ; FUN_00c7b030 */

void FUN_00c7b030(undefined4 param_1,undefined4 param_2)

{
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_14 = 0;
  uStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  FUN_00c7b060(param_1,param_2,&uStack_14);
  return;
}



/* FUNCTION 29286 ; VA 0x00c7b060 ; FUN_00c7b060 */

void __thiscall FUN_00c7b060(int param_1,undefined4 param_2,int param_3,float *param_4)

{
  undefined8 uVar1;
  float fVar2;
  bool bVar3;
  float *pfVar4;
  int *piVar5;
  undefined4 uVar6;
  float10 fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  float fStack_24;
  float fStack_20;
  undefined8 uStack_1c;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  pfVar4 = (float *)FUN_00d5c5d0(&uStack_2c);
  *param_4 = *pfVar4;
  param_4[1] = pfVar4[1];
  param_4[2] = pfVar4[2];
  param_4[3] = pfVar4[3];
  fStack_20 = *(float *)(param_3 + 0xc);
  if (0.0 < fStack_20) {
    uVar1 = *(undefined8 *)(param_1 + 0x334);
    fStack_24 = *(float *)(param_1 + 0x33c);
    uStack_1c._0_4_ = (undefined4)uVar1;
    uStack_2c = (undefined4)uStack_1c;
    uStack_1c._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
    uStack_28 = uStack_1c._4_4_;
    fStack_8 = (float)*(int *)(param_1 + 800);
    uStack_1c = uVar1;
    fStack_14 = fStack_24;
    if (0.0 < fStack_8) {
      fVar7 = (float10)FUN_00832150();
      fStack_8 = (float)(fVar7 * (float10)fStack_8);
    }
    if (*(int *)(param_1 + 0x324) == 2) {
      fVar11 = param_4[3] - fStack_8;
      fVar9 = param_4[1] + fStack_8;
      fVar10 = param_4[2] - fStack_8;
      fVar8 = *param_4 + fStack_8;
      fVar12 = fVar11;
      if (fVar9 < fVar11) {
        fVar12 = fVar9;
      }
      fVar2 = fVar10;
      if (fVar8 < fVar10) {
        fVar2 = fVar8;
      }
      if (fVar9 <= fVar11) {
        fVar9 = fVar11;
      }
      if (fVar8 <= fVar10) {
        fVar8 = fVar10;
      }
      *param_4 = fVar2;
      param_4[1] = fVar12;
      param_4[2] = fVar8;
      param_4[3] = fVar9;
    }
    else if (*(int *)(param_1 + 0x324) == 1) {
      fVar8 = fStack_8 * DAT_018ce2f4;
      fStack_10 = param_4[2] - fVar8;
      fStack_c = param_4[3] - fVar8;
      fStack_14 = param_4[1] + fVar8;
      uStack_1c = CONCAT44(*param_4 + fVar8,(undefined4)uStack_1c);
      pfVar4 = (float *)FUN_006ae8d0(auStack_3c,(int)&uStack_1c + 4,&fStack_10);
      *param_4 = *pfVar4;
      param_4[1] = pfVar4[1];
      param_4[2] = pfVar4[2];
      param_4[3] = pfVar4[3];
    }
    piVar5 = (int *)FUN_00d5be40();
    if ((fStack_8 <= 0.0) || (bVar3 = true, 0 < *(int *)(param_1 + 0x134))) {
      bVar3 = false;
    }
    pfVar4 = (float *)(param_1 + 0xa8);
    if ((piVar5 == (int *)0x0) || (NAN(*pfVar4) == (*pfVar4 == 0.0))) {
      FUN_0114e980(param_4,param_3,pfVar4);
      if (bVar3) {
        FUN_0114e850(param_4,fStack_8,&uStack_2c,pfVar4);
      }
    }
    else {
      uVar6 = (**(code **)(*piVar5 + 0xd4))(auStack_3c);
      FUN_0114e890(param_4,param_3,uVar6);
      if (bVar3) {
        uVar6 = (**(code **)(*piVar5 + 0xd4))(auStack_3c);
        FUN_0114e680(param_4,fStack_8,&uStack_2c,uVar6);
        return;
      }
    }
  }
  return;
}



/* FUNCTION 29287 ; VA 0x00c7b2b0 ; FUN_00c7b2b0 */

void __thiscall
FUN_00c7b2b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5,float param_6,int *param_7,undefined4 param_8,float *param_9,
            float *param_10)

{
  float fVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  float fVar5;
  float *pfVar6;
  float10 fVar7;
  float fVar8;
  undefined auStack_160 [8];
  undefined auStack_158 [136];
  float afStack_d0 [39];
  undefined4 uStack_34;
  int iStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iStack_30 = param_1;
  FUN_00d5c5d0(&fStack_1c);
  if (param_9 != (float *)0x0) {
    fStack_1c = *param_9;
    fStack_18 = param_9[1];
    fStack_14 = param_9[2];
    fStack_10 = param_9[3];
  }
  iVar4 = 9;
  do {
    FUN_0060f2c0();
    iVar4 = iVar4 + -1;
  } while (iVar4 != 0);
  fVar5 = 1.26117e-44;
  do {
    FUN_0060f2c0();
    fVar5 = (float)((int)fVar5 + -1);
  } while (fVar5 != 0.0);
  fStack_c = fVar5;
  fStack_8 = fVar5;
  cVar2 = FUN_00f9c690(param_2,param_3,&fStack_c,param_1,"Texture",1);
  if (cVar2 != '\0') {
    fStack_2c = fStack_c + 0.0;
    fStack_20 = fStack_8 + 0.0;
    afStack_d0[0x24] = (float)*param_5;
    afStack_d0[0x25] = (float)param_5[1];
    afStack_d0[0x26] = (float)param_5[2];
    uStack_34 = param_5[3];
    fStack_24 = fStack_2c;
    if (fStack_2c <= 0.0) {
      fStack_24 = 0.0;
    }
    if (0.0 <= fStack_2c) {
      fStack_2c = 0.0;
    }
    fStack_28 = fStack_20;
    if (0.0 <= fStack_20) {
      fStack_28 = 0.0;
    }
    if (fStack_20 <= 0.0) {
      fStack_20 = 0.0;
    }
    if (param_10 != (float *)0x0) {
      fStack_2c = *param_10;
      fStack_28 = param_10[1];
      fStack_24 = param_10[2];
      fStack_20 = param_10[3];
    }
    fVar7 = (float10)FUN_00832150();
    FUN_00c72880(afStack_d0,auStack_160,&fStack_1c,afStack_d0 + 0x24,&fStack_2c,&fStack_c,
                 (float)(fVar7 * (float10)param_6));
    iVar4 = 0;
    fVar5 = fStack_14 - fStack_1c;
    fVar8 = fStack_10 - fStack_18;
    do {
      pfVar6 = (float *)((int)afStack_d0 + iVar4);
      if ((((0.0 < *(float *)((int)afStack_d0 + iVar4 + 8) - *pfVar6) &&
           (0.0 < *(float *)((int)afStack_d0 + iVar4 + 0xc) -
                  *(float *)((int)afStack_d0 + iVar4 + 4))) && (0.0 < fVar5)) && (0.0 < fVar8)) {
        if ((param_7 == (int *)0x0) ||
           (fVar1 = *(float *)(iStack_30 + 0xa8), NAN(fVar1) == (fVar1 == 0.0))) {
          FUN_00f9c600(param_2,1,pfVar6,auStack_160 + iVar4,auStack_158 + iVar4,param_8,
                       (float *)(iStack_30 + 0xa8),0,0);
        }
        else {
          puVar3 = (undefined4 *)(**(code **)(*param_7 + 0xd4))(&fStack_2c);
          afStack_d0[0x24] = (float)*puVar3;
          afStack_d0[0x25] = (float)puVar3[1];
          afStack_d0[0x26] = (float)puVar3[2];
          uStack_34 = puVar3[3];
          FUN_00f9c440(param_2,1,pfVar6,auStack_160 + iVar4,auStack_158 + iVar4,param_8,
                       afStack_d0 + 0x24,0,0);
        }
      }
      iVar4 = iVar4 + 0x10;
    } while (iVar4 < 0x90);
  }
  return;
}



/* FUNCTION 29288 ; VA 0x00c7b500 ; FUN_00c7b500 */

void FUN_00c7b500(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 *param_6,int *param_7)

{
  char cVar1;
  undefined4 *puVar2;
  float *pfVar3;
  int iVar4;
  uint uVar5;
  float fVar6;
  float afStack_d8 [36];
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  int iStack_8;
  
  puVar2 = (undefined4 *)FUN_00d5c5d0(&uStack_38);
  iVar4 = 9;
  *param_6 = *puVar2;
  param_6[1] = puVar2[1];
  param_6[2] = puVar2[2];
  param_6[3] = puVar2[3];
  do {
    FUN_0060f2c0();
    iVar4 = iVar4 + -1;
  } while (iVar4 != 0);
  FUN_00c73070(afStack_d8,param_6,param_3,param_4);
  iVar4 = iStack_8;
  cVar1 = FUN_00f9c690(param_1,param_2,0,iStack_8,"Texture",1);
  if (cVar1 != '\0') {
    fVar6 = DAT_018ce2f8 - *(float *)(iVar4 + 0x344);
    puVar2 = (undefined4 *)FUN_0115ee70();
    pfVar3 = afStack_d8;
    uStack_28 = *puVar2;
    uStack_24 = puVar2[1];
    uStack_20 = puVar2[2];
    fStack_1c = fVar6;
    uVar5 = 0;
    fStack_c = DAT_0196f834;
    do {
      if ((0.0 < pfVar3[2] - *pfVar3) && (0.0 < pfVar3[3] - pfVar3[1])) {
        fStack_18 = (float)(uVar5 % 3) * fStack_c;
        fStack_14 = (float)(uVar5 / 3) * fStack_c;
        fStack_10 = (float)(uVar5 % 3 + 1) * fStack_c;
        fStack_c = (float)(int)(uVar5 / 3 + 1) * fStack_c;
        if ((param_7 == (int *)0x0) ||
           (fVar6 = *(float *)(iStack_8 + 0xa8), NAN(fVar6) == (fVar6 == 0.0))) {
          FUN_00f9c600(param_1,1,pfVar3,&fStack_18,&fStack_10,&uStack_28,(float *)(iStack_8 + 0xa8),
                       0,0);
          fStack_c = DAT_0196f834;
        }
        else {
          puVar2 = (undefined4 *)(**(code **)(*param_7 + 0xd4))(auStack_48);
          uStack_38 = *puVar2;
          uStack_34 = puVar2[1];
          uStack_30 = puVar2[2];
          uStack_2c = puVar2[3];
          FUN_00f9c440(param_1,1,pfVar3,&fStack_18,&fStack_10,&uStack_28,&uStack_38,0,0);
          fStack_c = DAT_0196f834;
        }
      }
      uVar5 = uVar5 + 1;
      pfVar3 = pfVar3 + 4;
    } while ((int)uVar5 < 9);
  }
  return;
}



/* FUNCTION 29289 ; VA 0x00c7b6f0 ; FUN_00c7b6f0 */

void __thiscall FUN_00c7b6f0(int param_1,undefined4 param_2,int *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  int iVar17;
  char cVar18;
  
  if (*(int **)(param_1 + 0x170) != (int *)0x0) {
    param_3 = *(int **)(param_1 + 0x170);
  }
  if (param_3 != (int *)0x0) {
    cVar18 = (**(code **)(*param_3 + 0xdc))();
    if (cVar18 != '\0') {
      fVar1 = *(float *)(param_1 + 0xa0);
      fVar2 = *(float *)(param_1 + 0xa4);
      fVar3 = *(float *)(param_1 + 0x9c);
      iVar10 = *(int *)(param_1 + 0xa8);
      iVar11 = *(int *)(param_1 + 0xac);
      iVar12 = *(int *)(param_1 + 0xb0);
      iVar13 = *(int *)(param_1 + 0xb4);
      iVar8 = *(int *)(param_1 + 0xb8);
      iVar9 = param_3[0x2e];
      iVar4 = param_3[0x26];
      iVar5 = param_3[0x27];
      iVar6 = param_3[0x28];
      iVar7 = param_3[0x29];
      iVar14 = param_3[0x2a];
      iVar15 = param_3[0x2b];
      iVar16 = param_3[0x2c];
      iVar17 = param_3[0x2d];
      param_3[0x26] =
           (int)(fVar1 * (float)param_3[0xbf] + *(float *)(param_1 + 0x98) + (float)param_3[0xc0]);
      param_3[0x27] = (int)(fVar2 * (float)param_3[0xc1] + fVar3 + (float)param_3[0xc2]);
      param_3[0x28] = (int)(fVar1 * (float)param_3[0xbb] + (float)param_3[0xbc]);
      param_3[0x29] = (int)(fVar2 * (float)param_3[0xbd] + (float)param_3[0xbe]);
      param_3[0x2a] = iVar10;
      param_3[0x2b] = iVar11;
      param_3[0x2c] = iVar12;
      param_3[0x2d] = iVar13;
      param_3[0x2e] = iVar8;
      if (DAT_01d688c8 != '\0') {
        (**(code **)(*param_3 + 0xb8))(param_2);
      }
      (**(code **)(param_3[0x15] + 0x10))(param_2);
      if (DAT_01d688c8 != '\0') {
        (**(code **)(*param_3 + 0xbc))(param_2);
      }
      param_3[0x26] = iVar4;
      param_3[0x27] = iVar5;
      param_3[0x28] = iVar6;
      param_3[0x29] = iVar7;
      param_3[0x2a] = iVar14;
      param_3[0x2b] = iVar15;
      param_3[0x2c] = iVar16;
      param_3[0x2d] = iVar17;
      param_3[0x2e] = iVar9;
    }
  }
  return;
}



/* FUNCTION 29290 ; VA 0x00c7b920 ; FUN_00c7b920 */

void __thiscall FUN_00c7b920(int param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0cf0;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x78) != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((*(uint *)(param_1 + 0x78) & 0xfffffffe) + 4))(param_1 + 0x80,param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29291 ; VA 0x00c7b970 ; FUN_00c7b970 */

void __thiscall FUN_00c7b970(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + -4);
    uStack_8 = 0;
    FUN_016f32d1(iVar2,0x44,*(undefined4 *)(iVar2 + -4),FUN_0091a630);
    FUN_01674ea0(piVar1,(*piVar1 * 0x10 + *piVar1) * 4 + 4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29292 ; VA 0x00c7b9e0 ; FUN_00c7b9e0 */

void __thiscall FUN_00c7b9e0(int *param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  if (iVar1 != 0) {
    uVar2 = *(uint *)(iVar1 + 0x38);
    uStack_8 = 0;
    if (uVar2 != 0) {
      if ((uVar2 & 1) == 0) {
        if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
          (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x40,iVar1 + 0x40,2);
        }
      }
      *(undefined4 *)(iVar1 + 0x38) = 0;
    }
    FUN_01674ea0(iVar1,0x58);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29293 ; VA 0x00c7ba50 ; FUN_00c7ba50 */

void __thiscall FUN_00c7ba50(int param_1,char param_2)

{
  int iVar1;
  
  if (*(char *)(param_1 + 0x341) != param_2) {
    *(char *)(param_1 + 0x341) = param_2;
    FUN_008a4940(&DAT_02138620);
    if (*(char *)(param_1 + 0x341) == '\0') {
      if (*(int *)(param_1 + 0x2e8) != 0) {
        iVar1 = FUN_00817fa0();
        if (iVar1 != 0) {
          FUN_00d66da0();
        }
      }
      *(undefined4 *)(param_1 + 0x2e8) = 0;
    }
  }
  return;
}



/* FUNCTION 29294 ; VA 0x00c7bab0 ; FUN_00c7bab0 */

void __thiscall FUN_00c7bab0(int param_1,float param_2,float param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar2 = 0.0;
  if (0.0 <= param_2) {
    fVar2 = param_2;
  }
  fVar1 = 0.0;
  if (0.0 <= param_3) {
    fVar1 = param_3;
  }
  fVar3 = DAT_018ce2f8;
  if (fVar2 <= DAT_018ce2f8) {
    fVar3 = fVar2;
  }
  fVar2 = DAT_018ce2f8;
  if (fVar1 <= DAT_018ce2f8) {
    fVar2 = fVar1;
  }
  if (((NAN(*(float *)(param_1 + 0x128)) || NAN(fVar3)) == (*(float *)(param_1 + 0x128) == fVar3))
     || ((NAN(*(float *)(param_1 + 300)) || NAN(fVar2)) == (*(float *)(param_1 + 300) == fVar2))) {
    *(float *)(param_1 + 0x128) = fVar3;
    *(float *)(param_1 + 300) = fVar2;
    FUN_00d5d070();
    FUN_008a4940(&DAT_02138330);
  }
  return;
}



/* FUNCTION 29295 ; VA 0x00c7bb30 ; FUN_00c7bb30 */

void __thiscall FUN_00c7bb30(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x46c) != param_2) {
    *(char *)(param_1 + 0x46c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 29296 ; VA 0x00c7bb60 ; FUN_00c7bb60 */

void __thiscall FUN_00c7bb60(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x318) != param_2) {
    *(int *)(param_1 + 0x318) = param_2;
    FUN_00d5cee0();
    FUN_008a4940(&DAT_021383a0);
  }
  return;
}



/* FUNCTION 29297 ; VA 0x00c7bb90 ; FUN_00c7bb90 */

void __thiscall FUN_00c7bb90(int param_1,float param_2,float param_3,float param_4)

{
  if ((((NAN(*(float *)(param_1 + 0x328)) || NAN(param_2)) ==
        (*(float *)(param_1 + 0x328) == param_2)) ||
      ((NAN(*(float *)(param_1 + 0x32c)) || NAN(param_3)) ==
       (*(float *)(param_1 + 0x32c) == param_3))) ||
     ((NAN(*(float *)(param_1 + 0x330)) || NAN(param_4)) == (*(float *)(param_1 + 0x330) == param_4)
     )) {
    *(float *)(param_1 + 0x328) = param_2;
    *(float *)(param_1 + 0x32c) = param_3;
    *(float *)(param_1 + 0x330) = param_4;
    FUN_008a4940(&DAT_021384d0);
    FUN_008a4940(&DAT_02138508);
    if (DAT_01d688d0 != '\0') {
      FUN_006eccd0();
    }
  }
  return;
}



/* FUNCTION 29298 ; VA 0x00c7bc20 ; FUN_00c7bc20 */

void __fastcall FUN_00c7bc20(int param_1)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined auStack_1c [12];
  undefined8 uStack_10;
  float fStack_8;
  
  puVar2 = (undefined8 *)FUN_00c98ad0(auStack_1c);
  uVar1 = *puVar2;
  fStack_8 = *(float *)(puVar2 + 1);
  uStack_10._0_4_ = (float)uVar1;
  uStack_10._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
  if ((((NAN(*(float *)(param_1 + 0x328)) || NAN((float)uStack_10)) ==
        (*(float *)(param_1 + 0x328) == (float)uStack_10)) ||
      ((NAN(*(float *)(param_1 + 0x32c)) || NAN(uStack_10._4_4_)) ==
       (*(float *)(param_1 + 0x32c) == uStack_10._4_4_))) ||
     ((NAN(*(float *)(param_1 + 0x330)) || NAN(fStack_8)) ==
      (*(float *)(param_1 + 0x330) == fStack_8))) {
    *(float *)(param_1 + 0x328) = (float)uStack_10;
    *(float *)(param_1 + 0x32c) = uStack_10._4_4_;
    *(float *)(param_1 + 0x330) = fStack_8;
    uStack_10 = uVar1;
    FUN_008a4940(&DAT_021384d0);
    FUN_008a4940(&DAT_02138508);
    if (DAT_01d688d0 != '\0') {
      FUN_006eccd0();
    }
  }
  return;
}



/* FUNCTION 29299 ; VA 0x00c7bce0 ; FUN_00c7bce0 */

void __thiscall FUN_00c7bce0(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0x344))) == (param_2 == *(float *)(param_1 + 0x344))
     ) {
    *(float *)(param_1 + 0x344) = param_2;
    FUN_008a4940(&DAT_02138540);
    if (DAT_01d688d0 != '\0') {
      FUN_006eccd0();
    }
  }
  return;
}



/* FUNCTION 29300 ; VA 0x00c7bd30 ; FUN_00c7bd30 */

void __thiscall FUN_00c7bd30(int param_1,float param_2,float param_3,float param_4)

{
  if ((((NAN(*(float *)(param_1 + 0x334)) || NAN(param_2)) ==
        (*(float *)(param_1 + 0x334) == param_2)) ||
      ((NAN(*(float *)(param_1 + 0x338)) || NAN(param_3)) ==
       (*(float *)(param_1 + 0x338) == param_3))) ||
     ((NAN(*(float *)(param_1 + 0x33c)) || NAN(param_4)) == (*(float *)(param_1 + 0x33c) == param_4)
     )) {
    *(float *)(param_1 + 0x334) = param_2;
    *(float *)(param_1 + 0x338) = param_3;
    *(float *)(param_1 + 0x33c) = param_4;
    FUN_008a4940(&DAT_02138460);
    FUN_008a4940(&DAT_02138498);
    if (DAT_01d688d0 != '\0') {
      FUN_006eccd0();
    }
  }
  return;
}



/* FUNCTION 29301 ; VA 0x00c7bdc0 ; FUN_00c7bdc0 */

void __fastcall FUN_00c7bdc0(int param_1)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined auStack_1c [12];
  undefined8 uStack_10;
  float fStack_8;
  
  puVar2 = (undefined8 *)FUN_00c98ad0(auStack_1c);
  uVar1 = *puVar2;
  fStack_8 = *(float *)(puVar2 + 1);
  uStack_10._0_4_ = (float)uVar1;
  uStack_10._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
  if ((((NAN(*(float *)(param_1 + 0x334)) || NAN((float)uStack_10)) ==
        (*(float *)(param_1 + 0x334) == (float)uStack_10)) ||
      ((NAN(*(float *)(param_1 + 0x338)) || NAN(uStack_10._4_4_)) ==
       (*(float *)(param_1 + 0x338) == uStack_10._4_4_))) ||
     ((NAN(*(float *)(param_1 + 0x33c)) || NAN(fStack_8)) ==
      (*(float *)(param_1 + 0x33c) == fStack_8))) {
    *(float *)(param_1 + 0x334) = (float)uStack_10;
    *(float *)(param_1 + 0x338) = uStack_10._4_4_;
    *(float *)(param_1 + 0x33c) = fStack_8;
    uStack_10 = uVar1;
    FUN_008a4940(&DAT_02138460);
    FUN_008a4940(&DAT_02138498);
    if (DAT_01d688d0 != '\0') {
      FUN_006eccd0();
    }
  }
  return;
}



/* FUNCTION 29302 ; VA 0x00c7be80 ; FUN_00c7be80 */

void __thiscall FUN_00c7be80(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x324) != param_2) {
    *(int *)(param_1 + 0x324) = param_2;
    FUN_00d5d070();
    FUN_008a4940(&DAT_02138420);
  }
  return;
}



/* FUNCTION 29303 ; VA 0x00c7beb0 ; FUN_00c7beb0 */

void __thiscall FUN_00c7beb0(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = 0;
  if (-1 < param_2) {
    iVar1 = param_2;
  }
  if (100 < iVar1) {
    iVar1 = 100;
  }
  if (*(int *)(param_1 + 800) != iVar1) {
    *(int *)(param_1 + 800) = iVar1;
    if (*(int *)(param_1 + 0x324) != 0) {
      FUN_00d5d070();
    }
    FUN_008a4940(&DAT_02138288);
    if (DAT_01d688d0 != '\0') {
      FUN_006eccd0();
    }
  }
  return;
}



/* FUNCTION 29304 ; VA 0x00c7bf10 ; FUN_00c7bf10 */

void __thiscall FUN_00c7bf10(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x2e5) != param_2) {
    *(char *)(param_1 + 0x2e5) = param_2;
    FUN_00d5cb70();
    FUN_008a4940(&DAT_021385b0);
  }
  return;
}



/* FUNCTION 29305 ; VA 0x00c7bf40 ; FUN_00c7bf40 */

void __thiscall FUN_00c7bf40(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x198) != param_2) {
    *(int *)(param_1 + 0x198) = param_2;
    FUN_010113f0();
  }
  return;
}



/* FUNCTION 29306 ; VA 0x00c7bf70 ; FUN_00c7bf70 */

void __thiscall FUN_00c7bf70(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x17c) != param_2) {
    *(char *)(param_1 + 0x17c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 29307 ; VA 0x00c7bfa0 ; FUN_00c7bfa0 */

void __thiscall FUN_00c7bfa0(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x2e8) != param_2) {
    iVar1 = FUN_00817fa0();
    if (iVar1 != 0) {
      FUN_00d66da0();
    }
  }
  *(int *)(param_1 + 0x2e8) = param_2;
  return;
}



/* FUNCTION 29308 ; VA 0x00c7bfd0 ; FUN_00c7bfd0 */

void __thiscall FUN_00c7bfd0(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e898;
  pvStack_10 = ExceptionList;
  if (param_2 != *(int *)(param_1 + 0x194)) {
    ExceptionList = &pvStack_10;
    *(int *)(param_1 + 0x194) = param_2;
    if (DAT_01d688c0 == '\0') {
      piVar2 = (int *)FUN_00587490(auStack_18);
      iVar4 = *piVar2;
      uStack_8 = 0;
      if ((iVar4 == 0) ||
         (iVar1 = *(int *)(iVar4 + 0xc), iVar3 = FUN_00de9720(),
         (uint)*(ushort *)(iVar3 + 0x1da) <
         (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
        iVar4 = 0;
      }
      uStack_8 = 0xffffffff;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_14[1] + -1;
        piStack_14[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          iVar1 = piStack_14[2] + -1;
          piStack_14[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      if ((iVar4 != 0) && (*(int *)(iVar4 + 0x6c) == 2)) {
        FUN_010113f0();
      }
    }
    else {
      FUN_010113f0();
    }
    FUN_008a4940(&DAT_021382f8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29309 ; VA 0x00c7c0d0 ; FUN_00c7c0d0 */

void __thiscall FUN_00c7c0d0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x46e) != param_2) {
    *(char *)(param_1 + 0x46e) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 29310 ; VA 0x00c7c100 ; FUN_00c7c100 */

void __thiscall FUN_00c7c100(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x15c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x15c) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_00c776a0(*(undefined4 *)(param_1 + 0x158),*(undefined4 *)(param_1 + 0x15c));
  if (param_2 != iVar4) {
    puVar5 = (undefined4 *)FUN_0060e0c0(auStack_c,param_2);
    uVar2 = *puVar5;
    uVar3 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x158) = uVar2;
    piVar1 = *(int **)(param_1 + 0x15c);
    *(undefined4 *)(param_1 + 0x15c) = uVar3;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    FUN_008a4940(&DAT_02138abc);
  }
  return;
}



/* FUNCTION 29311 ; VA 0x00c7c1c0 ; FUN_00c7c1c0 */

void __thiscall FUN_00c7c1c0(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x164) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x164) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_00c776a0(*(undefined4 *)(param_1 + 0x160),*(undefined4 *)(param_1 + 0x164));
  if (param_2 != iVar4) {
    puVar5 = (undefined4 *)FUN_0060e0c0(auStack_c,param_2);
    uVar2 = *puVar5;
    uVar3 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x160) = uVar2;
    piVar1 = *(int **)(param_1 + 0x164);
    *(undefined4 *)(param_1 + 0x164) = uVar3;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    FUN_008a4940(&DAT_02138af8);
  }
  return;
}



/* FUNCTION 29312 ; VA 0x00c7c280 ; FUN_00c7c280 */

void __thiscall FUN_00c7c280(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x16c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x16c) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_00c776a0(*(undefined4 *)(param_1 + 0x168),*(undefined4 *)(param_1 + 0x16c));
  if (param_2 != iVar4) {
    puVar5 = (undefined4 *)FUN_0060e0c0(auStack_c,param_2);
    uVar2 = *puVar5;
    uVar3 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x168) = uVar2;
    piVar1 = *(int **)(param_1 + 0x16c);
    *(undefined4 *)(param_1 + 0x16c) = uVar3;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    FUN_008a4940(&DAT_02138b34);
  }
  return;
}



/* FUNCTION 29313 ; VA 0x00c7c340 ; FUN_00c7c340 */

void __thiscall FUN_00c7c340(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x154) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x154) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_00c776a0(*(undefined4 *)(param_1 + 0x150),*(undefined4 *)(param_1 + 0x154));
  if (param_2 != iVar4) {
    puVar5 = (undefined4 *)FUN_0060e0c0(auStack_c,param_2);
    uVar2 = *puVar5;
    uVar3 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x150) = uVar2;
    piVar1 = *(int **)(param_1 + 0x154);
    *(undefined4 *)(param_1 + 0x154) = uVar3;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    FUN_008a4940(&DAT_02138a80);
  }
  return;
}



/* FUNCTION 29314 ; VA 0x00c7c400 ; FUN_00c7c400 */

void __thiscall FUN_00c7c400(int param_1,float param_2,int param_3,float param_4,int param_5)

{
  if (((((NAN(*(float *)(param_1 + 0x2fc)) || NAN(param_2)) ==
         (*(float *)(param_1 + 0x2fc) == param_2)) || (*(int *)(param_1 + 0x300) != param_3)) ||
      ((NAN(*(float *)(param_1 + 0x304)) || NAN(param_4)) ==
       (*(float *)(param_1 + 0x304) == param_4))) || (*(int *)(param_1 + 0x308) != param_5)) {
    *(int *)(param_1 + 0x300) = param_3;
    *(float *)(param_1 + 0x2fc) = param_2;
    *(float *)(param_1 + 0x304) = param_4;
    *(int *)(param_1 + 0x308) = param_5;
    FUN_00d5d070();
    FUN_008a4940(&DAT_02138250);
  }
  return;
}



/* FUNCTION 29315 ; VA 0x00c7c480 ; FUN_00c7c480 */

void __thiscall FUN_00c7c480(int param_1,float param_2)

{
  double dVar1;
  double dVar2;
  
  if ((NAN(*(float *)(param_1 + 0x30c)) || NAN(param_2)) == (*(float *)(param_1 + 0x30c) == param_2)
     ) {
    dVar1 = (double)(param_2 * DAT_0190119c);
    dVar2 = dVar1;
    FUN_01728390();
    FUN_017279f0();
    *(ulonglong *)(param_1 + 0x30c) = CONCAT44((float)dVar2,param_2);
    *(float *)(param_1 + 0x314) = (float)dVar1;
    FUN_00d5d070();
    FUN_008a4940(&DAT_02138368);
  }
  return;
}



/* FUNCTION 29316 ; VA 0x00c7c510 ; FUN_00c7c510 */

void __thiscall FUN_00c7c510(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x342) != param_2) {
    *(char *)(param_1 + 0x342) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 29317 ; VA 0x00c7c540 ; FUN_00c7c540 */

void __thiscall FUN_00c7c540(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x46d) != param_2) {
    *(char *)(param_1 + 0x46d) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 29318 ; VA 0x00c7c570 ; FUN_00c7c570 */

void __thiscall FUN_00c7c570(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_2 != *(int *)(param_1 + 0x170)) {
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x170) = uVar1;
    piVar3 = *(int **)(param_1 + 0x174);
    *(undefined4 *)(param_1 + 0x174) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    FUN_008a4940(&DAT_02138b70);
  }
  return;
}



/* FUNCTION 29319 ; VA 0x00c7c620 ; FUN_00c7c620 */

void __fastcall FUN_00c7c620(int param_1)

{
  FUN_00c7c6c0();
  FUN_00c6c8e0(*(int *)(param_1 + 0x37c) != 0);
  FUN_00c6c8e0(*(int *)(param_1 + 900) != 0);
  FUN_00c6c8e0(*(int *)(param_1 + 0x38c) != 0);
  FUN_00c6c8e0(*(int *)(param_1 + 0x394) != 0);
  FUN_00c6c8e0(*(int *)(param_1 + 0x39c) != 0);
  FUN_00c6c8e0(*(int *)(param_1 + 0x3a4) != 0);
  return;
}



/* FUNCTION 29320 ; VA 0x00c7c6c0 ; FUN_00c7c6c0 */

void __fastcall FUN_00c7c6c0(int param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d601;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x2e4) = 1;
  iStack_18 = param_1;
  FUN_00c6c8e0(*(int *)(param_1 + 0x1cc) != 0);
  FUN_00c6c8e0(*(int *)(param_1 + 0x1d4) != 0);
  FUN_00c6c8e0(*(int *)(param_1 + 0x1dc) != 0);
  FUN_00c6c8e0(*(int *)(param_1 + 0x1e4) != 0);
  FUN_00c6c8e0(*(int *)(param_1 + 0x1ec) != 0);
  iStack_20 = *(int *)(param_1 + 0x29c);
  cVar2 = FUN_016793f0();
  iVar3 = param_1;
  if (cVar2 == '\0') {
    iStack_14 = *(int *)(param_1 + 0x2d8);
    uStack_8 = 0;
    iVar3 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 1;
    iStack_24 = iVar3;
    puVar4 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = 0;
      puVar4[1] = 1;
      puVar4[2] = FUN_00c6c160;
      puVar4[3] = _guard_check_icall;
      puVar4[4] = 0;
      puVar4[5] = iStack_14;
      puVar4[6] = FUN_00c6c3a0;
      puVar4[7] = param_1 + 0x2c8;
    }
    FUN_016797d0(puVar4);
    if (puVar4 != (undefined4 *)0x0) {
      LOCK();
      puVar4[1] = puVar4[1] + 1;
      UNLOCK();
    }
    uStack_1c = 1;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_01675290(iVar3);
    iVar3 = *(int *)(param_1 + 0x2dc);
    *(undefined4 **)(param_1 + 0x2dc) = puVar4;
    uStack_8 = 0xffffffff;
    if (iVar3 != 0) {
      piVar5 = (int *)(iVar3 + 4);
      LOCK();
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        FUN_01674ea0(iVar3);
      }
    }
    iVar3 = iStack_18;
    if (iStack_20 != 0) {
      iVar3 = *(int *)(param_1 + 0x2cc);
      iStack_14 = 1;
      iStack_24 = (**(code **)(**(int **)(iVar3 + 0x34) + 0xc))(*(undefined4 *)(param_1 + 0x2d0));
      iStack_24 = iStack_24 + 1;
      piVar5 = &iStack_14;
      if (iStack_14 <= iStack_24) {
        piVar5 = &iStack_24;
      }
      (**(code **)(**(int **)(iVar3 + 0x34) + 0x10))(*(undefined4 *)(param_1 + 0x2d0),piVar5);
      iVar3 = iStack_18;
    }
  }
  FUN_00c6c8e0(*(int *)(iVar3 + 0x294) != 0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29321 ; VA 0x00c7c8c0 ; FUN_00c7c8c0 */

void __thiscall FUN_00c7c8c0(int param_1,float param_2,int param_3,float param_4,int param_5)

{
  if (((((NAN(*(float *)(param_1 + 0x2ec)) || NAN(param_2)) ==
         (*(float *)(param_1 + 0x2ec) == param_2)) || (*(int *)(param_1 + 0x2f0) != param_3)) ||
      ((NAN(*(float *)(param_1 + 0x2f4)) || NAN(param_4)) ==
       (*(float *)(param_1 + 0x2f4) == param_4))) || (*(int *)(param_1 + 0x2f8) != param_5)) {
    *(int *)(param_1 + 0x2f0) = param_3;
    *(float *)(param_1 + 0x2ec) = param_2;
    *(float *)(param_1 + 0x2f4) = param_4;
    *(int *)(param_1 + 0x2f8) = param_5;
    FUN_00d5d070();
    FUN_008a4940(&DAT_02138218);
  }
  return;
}



/* FUNCTION 29322 ; VA 0x00c7c940 ; FUN_00c7c940 */

void __thiscall FUN_00c7c940(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x31c) != param_2) {
    *(int *)(param_1 + 0x31c) = param_2;
    FUN_00d5cee0();
    FUN_008a4940(&DAT_021383e0);
  }
  return;
}



/* FUNCTION 29323 ; VA 0x00c7c970 ; FUN_00c7c970 */

void __thiscall FUN_00c7c970(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e8c2;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x470) != param_2) {
    ExceptionList = &pvStack_10;
    *(int *)(param_1 + 0x470) = param_2;
    FUN_00d5cee0();
    FUN_008a4940(&DAT_02139158);
    if (*(int *)(param_1 + 0x470) == 0) {
      iVar2 = *(int *)(param_1 + 0x474);
      *(undefined4 *)(param_1 + 0x474) = 0;
      if (iVar2 != 0) {
        piVar1 = (int *)(iVar2 + -4);
        uStack_8 = 0;
        FUN_016f32d1(iVar2,0x44,*(undefined4 *)(iVar2 + -4),FUN_0091a630);
        FUN_01674ea0(piVar1,(*piVar1 * 0x10 + *piVar1) * 4 + 4);
      }
    }
    else if ((*(int *)(param_1 + 0x470) - 1U < 5) && (*(int *)(param_1 + 0x474) == 0)) {
      puVar3 = (undefined4 *)FUN_01674e20(0x114);
      uStack_8 = 1;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 4;
        FUN_016f4053(puVar3 + 1,0x44,4,FUN_00919430,FUN_0091a630);
        uStack_8 = 0xffffffff;
        FUN_00c7b970(puVar3 + 1);
        ExceptionList = pvStack_10;
        return;
      }
      uStack_8 = 0xffffffff;
      FUN_00c7b970(0);
      ExceptionList = pvStack_10;
      return;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29324 ; VA 0x00c7cac0 ; FUN_00c7cac0 */

void __thiscall FUN_00c7cac0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x10))(*param_3,param_3[1],param_3[2],param_3[3]);
  return;
}



/* FUNCTION 29325 ; VA 0x00c7caf0 ; FUN_00c7caf0 */

void __thiscall FUN_00c7caf0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_f0 [200];
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  code *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e49eb;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 0x34);
  pcStack_18 = *(code **)(*piStack_14 + 0x10);
  iVar1 = *param_3;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d5f0();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_0088d5f0();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iStack_28 = *piVar3;
    iStack_24 = piVar3[1];
    iStack_20 = piVar3[2];
    iStack_1c = piVar3[3];
  }
  else {
    puVar4 = (undefined4 *)param_3[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_3 + 2,auStack_f0);
      puVar4 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_0088b450();
    iStack_28 = *piVar3;
    iStack_24 = piVar3[1];
    iStack_20 = piVar3[2];
    iStack_1c = piVar3[3];
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_f0);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_18)(param_2,&iStack_28);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29326 ; VA 0x00c7cbf0 ; FUN_00c7cbf0 */

void __thiscall FUN_00c7cbf0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c7d2c0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29327 ; VA 0x00c7cc40 ; FUN_00c7cc40 */

void __thiscall FUN_00c7cc40(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c7d060();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29328 ; VA 0x00c7cc90 ; FUN_00c7cc90 */

void __thiscall FUN_00c7cc90(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c7d110();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29329 ; VA 0x00c7cce0 ; FUN_00c7cce0 */

void __thiscall FUN_00c7cce0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c7d230();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29330 ; VA 0x00c7cd30 ; FUN_00c7cd30 */

void __thiscall FUN_00c7cd30(int param_1,char param_2)

{
  int iVar1;
  
  if (*(char *)(param_1 + 0x340) != param_2) {
    *(char *)(param_1 + 0x340) = param_2;
    FUN_00d5d070();
    FUN_0100ef20();
    FUN_008a4940(&DAT_021385e8);
    if (*(char *)(param_1 + 0x340) == '\0') {
      if (*(int *)(param_1 + 0x2e8) != 0) {
        iVar1 = FUN_00817fa0();
        if (iVar1 != 0) {
          FUN_00d66da0();
        }
      }
      *(undefined4 *)(param_1 + 0x2e8) = 0;
    }
  }
  return;
}



/* FUNCTION 29331 ; VA 0x00c7cda0 ; FUN_00c7cda0 */

void __thiscall FUN_00c7cda0(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0xd0) != param_2) {
    *(int *)(param_1 + 0xd0) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 29332 ; VA 0x00c7cdd0 ; FUN_00c7cdd0 */

void __thiscall
FUN_00c7cdd0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  code *pcVar2;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e8f1;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 8);
  uVar1 = *(undefined4 *)(param_1 + 0xc);
  uStack_28 = 0;
  pcVar2 = *(code **)(*piStack_14 + 8);
  uStack_24 = 0;
  uStack_38 = param_2;
  uStack_34 = param_3;
  uStack_30 = param_4;
  uStack_2c = param_5;
  ExceptionList = &pvStack_10;
  uStack_108 = FUN_0088d5f0();
  uStack_104 = 0;
  uStack_100 = uStack_38;
  uStack_fc = uStack_34;
  uStack_f8 = uStack_30;
  uStack_f4 = uStack_2c;
  uStack_104 = FUN_006313f0();
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_108,&uStack_38,param_5);
  uStack_8._0_1_ = 1;
  (*pcVar2)(uVar1,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_108,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29333 ; VA 0x00c7cec0 ; FUN_00c7cec0 */

void __thiscall FUN_00c7cec0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  code *pcVar2;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c917c;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 8);
  uVar1 = *(undefined4 *)(param_1 + 0xc);
  uStack_28 = 0;
  uStack_24 = 0;
  pcVar2 = *(code **)(*piStack_14 + 8);
  ExceptionList = &pvStack_10;
  uStack_1c8 = FUN_0088c8c0();
  uStack_1c4 = 0;
  uStack_1c0 = param_2;
  uStack_1c4 = FUN_005c9cc0();
  uStack_8 = 0;
  uStack_f8 = FUN_0088c8c0();
  uStack_f4 = 0;
  uStack_f0 = param_3;
  uStack_f4 = FUN_005c9cc0();
  uStack_8 = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_1c8,&uStack_28,param_2);
  uStack_8._0_1_ = 2;
  (*pcVar2)(uVar1,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_1c8,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29334 ; VA 0x00c7cfe0 ; FUN_00c7cfe0 */

void __fastcall FUN_00c7cfe0(int param_1)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9648;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 8) + 8))(*(undefined4 *)(param_1 + 0xc),&uStack_24,&uStack_18);
  uStack_8 = 1;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29335 ; VA 0x00c7d060 ; FUN_00c7d060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c7d060(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e916;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff38c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff38c);
    if (DAT_01eff38c == -1) {
      uStack_8 = 0;
      FUN_009ca470("AutomaticSize");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eff328 = RBX::Reflection::EnumDesc<enum_RBX::GuiObject::AutomaticSize>::vftable;
      FUN_009caf20(&DAT_01d688d8,4);
      FUN_016f3654(&LAB_018965e0);
      FUN_016f37bf(&DAT_01eff38c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff328;
}



/* FUNCTION 29336 ; VA 0x00c7d110 ; FUN_00c7d110 */

undefined * FUN_00c7d110(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e92c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff2bc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff2bc);
    if (DAT_01eff2bc == -1) {
      uStack_8 = 0;
      FUN_00ff4e70();
      FUN_016f3654(&LAB_01896600);
      FUN_016f37bf(&DAT_01eff2bc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff258;
}



/* FUNCTION 29337 ; VA 0x00c7d1a0 ; FUN_00c7d1a0 */

undefined * FUN_00c7d1a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e94c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff1ec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff1ec);
    if (DAT_01eff1ec == -1) {
      uStack_8 = 0;
      FUN_00ff4ed0();
      FUN_016f3654(&LAB_01896620);
      FUN_016f37bf(&DAT_01eff1ec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff188;
}



/* FUNCTION 29338 ; VA 0x00c7d230 ; FUN_00c7d230 */

undefined * FUN_00c7d230(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e96c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff324) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff324);
    if (DAT_01eff324 == -1) {
      uStack_8 = 0;
      FUN_00ff4f90();
      FUN_016f3654(&LAB_01896640);
      FUN_016f37bf(&DAT_01eff324);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff2c0;
}



/* FUNCTION 29339 ; VA 0x00c7d2c0 ; FUN_00c7d2c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c7d2c0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e996;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff254) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff254);
    if (DAT_01eff254 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ButtonStyle");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eff1f0 = RBX::Reflection::EnumDesc<enum_RBX::GuiButton::Style>::vftable;
      FUN_009caf20(&DAT_01d688f8,6);
      FUN_016f3654(&LAB_01896660);
      FUN_016f37bf(&DAT_01eff254);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff1f0;
}



/* FUNCTION 29340 ; VA 0x00c7d370 ; FUN_00c7d370 */

undefined * FUN_00c7d370(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e9ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff3f4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff3f4);
    if (DAT_01eff3f4 == -1) {
      uStack_8 = 0;
      FUN_00da8ff0();
      FUN_016f3654(&LAB_01896680);
      FUN_016f37bf(&DAT_01eff3f4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff390;
}



/* FUNCTION 29341 ; VA 0x00c7d400 ; FUN_00c7d400 */

undefined * FUN_00c7d400(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e9cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff45c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff45c);
    if (DAT_01eff45c == -1) {
      uStack_8 = 0;
      FUN_00da9050();
      FUN_016f3654(&LAB_018966a0);
      FUN_016f37bf(&DAT_01eff45c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff3f8;
}



/* FUNCTION 29342 ; VA 0x00c7d490 ; FUN_00c7d490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c7d490(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff48c) {
    FUN_016f3809(&DAT_01eff48c);
    if (DAT_01eff48c == -1) {
      _DAT_01eff480 = FUN_005c65e0;
      _DAT_01eff484 = FUN_005c65e0;
      _DAT_01eff488 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eff48c);
    }
  }
  return &DAT_01eff480;
}



/* FUNCTION 29343 ; VA 0x00c7d500 ; FUN_00c7d500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c7d500(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff4ac) {
    FUN_016f3809(&DAT_01eff4ac);
    if (DAT_01eff4ac == -1) {
      _DAT_01eff4a0 = FUN_005c65e0;
      _DAT_01eff4a4 = FUN_005c65e0;
      _DAT_01eff4a8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eff4ac);
    }
  }
  return &DAT_01eff4a0;
}



/* FUNCTION 29344 ; VA 0x00c7d570 ; FUN_00c7d570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c7d570(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff4cc) {
    FUN_016f3809(&DAT_01eff4cc);
    if (DAT_01eff4cc == -1) {
      _DAT_01eff4c0 = FUN_005c65e0;
      _DAT_01eff4c4 = FUN_005c65e0;
      _DAT_01eff4c8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eff4cc);
    }
  }
  return &DAT_01eff4c0;
}



/* FUNCTION 29345 ; VA 0x00c7d5e0 ; FUN_00c7d5e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c7d5e0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff49c) {
    FUN_016f3809(&DAT_01eff49c);
    if (DAT_01eff49c == -1) {
      _DAT_01eff490 = FUN_005c65e0;
      _DAT_01eff494 = FUN_005c65e0;
      _DAT_01eff498 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eff49c);
    }
  }
  return &DAT_01eff490;
}



/* FUNCTION 29346 ; VA 0x00c7d650 ; FUN_00c7d650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c7d650(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff4bc) {
    FUN_016f3809(&DAT_01eff4bc);
    if (DAT_01eff4bc == -1) {
      _DAT_01eff4b0 = FUN_005c65e0;
      _DAT_01eff4b4 = FUN_005c65e0;
      _DAT_01eff4b8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eff4bc);
    }
  }
  return &DAT_01eff4b0;
}



/* FUNCTION 29347 ; VA 0x00c7d6c0 ; FUN_00c7d6c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c7d6c0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff47c) {
    FUN_016f3809(&DAT_01eff47c);
    if (DAT_01eff47c == -1) {
      _DAT_01eff470 = FUN_005c65e0;
      _DAT_01eff474 = FUN_005c65e0;
      _DAT_01eff478 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eff47c);
    }
  }
  return &DAT_01eff470;
}



/* FUNCTION 29348 ; VA 0x00c7d730 ; FUN_00c7d730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c7d730(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff46c) {
    FUN_016f3809(&DAT_01eff46c);
    if (DAT_01eff46c == -1) {
      _DAT_01eff460 = FUN_005c65e0;
      _DAT_01eff464 = FUN_005c65e0;
      _DAT_01eff468 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eff46c);
    }
  }
  return &DAT_01eff460;
}



/* FUNCTION 29349 ; VA 0x00c7d7a0 ; FUN_00c7d7a0 */

undefined __thiscall
FUN_00c7d7a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 *param_7,undefined4 param_8,undefined4 param_9)

{
  int iVar1;
  uint *puVar2;
  int iVar3;
  undefined4 uStack_c4;
  undefined *puStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  uint uStack_9c;
  undefined4 *puStack_98;
  undefined4 *puStack_94;
  undefined4 uStack_90;
  uint auStack_8c [2];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined8 uStack_74;
  undefined4 uStack_6c;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined *puStack_30;
  undefined *puStack_2c;
  int iStack_28;
  undefined uStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_0180e9fb;
  pvStack_1c = ExceptionList;
  uStack_9c = (uint)DAT_01efeae8;
  uStack_40 = *(undefined4 *)(param_1 + 0x2fc);
  uStack_3c = *(undefined4 *)(param_1 + 0x300);
  uStack_38 = *(undefined4 *)(param_1 + 0x304);
  uStack_34 = *(undefined4 *)(param_1 + 0x308);
  uStack_6c = 0;
  uStack_14 = 0;
  puStack_2c = (undefined *)&uStack_bc;
  puStack_c0 = &stack0x00000024;
  uStack_c4 = 0xc7d808;
  ExceptionList = &pvStack_1c;
  iStack_28 = param_1;
  FUN_00d88580();
  uStack_14._0_1_ = 1;
  FUN_0060e0c0(&uStack_c4,param_1);
  uStack_14._0_1_ = 0;
  FUN_00c6e370(&puStack_98,FUN_00c71320);
  uStack_9c = 0xc7d835;
  FUN_00c6d8f0();
  iVar1 = *(int *)(param_1 + 0x34);
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  iVar3 = iStack_28;
  if ((iVar1 != 0) && (iVar3 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
    uStack_6c = 0xc7d84c;
    iVar3 = FUN_005c8ac0();
  }
  if (iVar3 != 0) {
    iVar1 = *(int *)(iVar3 + 0xc);
    uStack_6c = 0xc7d85f;
    iVar3 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      uStack_6c = 0xc7d881;
      uStack_6c = FUN_008e3430();
      goto LAB_00c7d885;
    }
  }
  uStack_6c = 0;
LAB_00c7d885:
  puStack_30 = (undefined *)auStack_8c;
  auStack_8c[0] = 0;
  puVar2 = auStack_8c;
  if (uStack_60 != 0) {
    auStack_8c[0] = uStack_60;
    if ((uStack_60 & 1) == 0) {
      puStack_94 = &uStack_84;
      uStack_90 = 0;
      puStack_98 = &uStack_58;
      uStack_9c = 0xc7d8c7;
      (**(code **)(uStack_60 & 0xfffffffe))();
      puVar2 = (uint *)puStack_30;
    }
    else {
      uStack_84 = uStack_58;
      uStack_80 = uStack_54;
      uStack_7c = uStack_50;
      uStack_78 = uStack_4c;
      uStack_74 = uStack_48;
      puVar2 = auStack_8c;
    }
  }
  puStack_30 = (undefined *)puVar2;
  uStack_90 = param_9;
  puStack_94 = (undefined4 *)0x0;
  puStack_98 = param_7;
  uStack_9c = param_6;
  uStack_a0 = param_8;
  uStack_b0 = param_2;
  uStack_ac = param_3;
  uStack_a8 = param_4;
  uStack_a4 = param_5;
  puStack_c0 = (undefined *)uStack_40;
  uStack_bc = uStack_3c;
  uStack_b8 = uStack_38;
  uStack_b4 = uStack_34;
  uStack_c4 = 0xc7d906;
  uStack_21 = FUN_00c7d960();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    uStack_6c = 2;
    uStack_74 = CONCAT44(&uStack_58,&uStack_58);
    uStack_78 = 0xc7d92b;
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  uStack_6c = 0xc7d93d;
  FUN_00d88a30();
  ExceptionList = pvStack_1c;
  return uStack_21;
}



/* FUNCTION 29350 ; VA 0x00c7d960 ; FUN_00c7d960 */

undefined4 __thiscall
FUN_00c7d960(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            char param_14,uint param_15)

{
  int *piVar1;
  int iVar2;
  undefined *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 *in_stack_00000058;
  undefined *puStack_30;
  char *pcStack_2c;
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0180ea18;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iStack_14 = param_1;
  if (in_stack_00000058 == (undefined4 *)0x0) {
    pcStack_2c = "Can only tween objects in the workspace";
    puStack_30 = (undefined *)0xc7db55;
    ExceptionList = &pvStack_10;
    FUN_00550130();
    pcStack_2c = "";
    puStack_30 = auStack_20;
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8();
  }
  piVar1 = (int *)(param_1 + 0x148);
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x148) == 0) {
    pcStack_2c = (char *)0x8;
    puStack_30 = (undefined *)0xc7d9aa;
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_01674e20();
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = 0;
      puVar5[1] = 0;
    }
    iVar2 = *piVar1;
    *piVar1 = (int)puVar5;
    if (iVar2 != 0) {
      puStack_30 = (undefined *)0xc7d9d2;
      pcStack_2c = (char *)iVar2;
      FUN_00c33560();
    }
    FUN_0060e0c0(&puStack_30,iStack_14);
    FUN_00e8ec10();
  }
  if (*(int *)(*piVar1 + 4) != 0) {
    if (param_14 == '\0') {
      iStack_8 = 1;
      if (((param_15 != 0) && ((param_15 & 1) == 0)) &&
         (*(code **)(param_15 & 0xfffffffe) != (code *)0x0)) {
        puStack_30 = &stack0x00000040;
        pcStack_2c = (char *)0x2;
        (**(code **)(param_15 & 0xfffffffe))(puStack_30);
      }
      ExceptionList = pvStack_10;
      return 0;
    }
    piVar6 = (int *)(*(int *)(*piVar1 + 4) + 0x38);
    if (*piVar6 != 0) {
      pcStack_2c = (char *)0x0;
      FUN_0054f510(piVar6);
      FUN_00e8ea30();
    }
    pcStack_2c = (char *)0x0;
    puStack_30 = (undefined *)0xc7da5c;
    FUN_00c7b9e0();
  }
  iVar2 = *piVar1;
  pcStack_2c = (char *)0x58;
  puStack_30 = (undefined *)0xc7da68;
  in_stack_00000058 = (undefined4 *)FUN_01674e20();
  if (in_stack_00000058 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *in_stack_00000058 = param_2;
    in_stack_00000058[1] = param_3;
    in_stack_00000058[2] = param_4;
    in_stack_00000058[3] = param_5;
    in_stack_00000058[10] = param_11;
    in_stack_00000058[4] = param_6;
    in_stack_00000058[5] = param_7;
    in_stack_00000058[6] = param_8;
    in_stack_00000058[7] = param_9;
    in_stack_00000058[8] = 0;
    in_stack_00000058[9] = param_10;
    in_stack_00000058[0xb] = param_12;
    in_stack_00000058[0xc] = param_13;
    in_stack_00000058[0xe] = 0;
    puVar5 = in_stack_00000058;
  }
  puVar3 = *(undefined **)(iVar2 + 4);
  *(undefined4 **)(iVar2 + 4) = puVar5;
  if (puVar3 != (undefined *)0x0) {
    uVar4 = *(uint *)(puVar3 + 0x38);
    iStack_8._0_1_ = 2;
    if (uVar4 != 0) {
      if ((uVar4 & 1) == 0) {
        puStack_30 = puVar3 + 0x40;
        if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
          pcStack_2c = (char *)0x2;
          (**(code **)(uVar4 & 0xfffffffe))(puStack_30);
        }
      }
      *(undefined4 *)(puVar3 + 0x38) = 0;
    }
    pcStack_2c = (char *)0x58;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    puStack_30 = puVar3;
    FUN_01674ea0();
  }
  pcStack_2c = (char *)&param_15;
  puStack_30 = (undefined *)0xc7db0d;
  FUN_00c70260();
  iStack_8 = 3;
  if (((param_15 != 0) && ((param_15 & 1) == 0)) &&
     (*(code **)(param_15 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &stack0x00000040;
    pcStack_2c = (char *)0x2;
    (**(code **)(param_15 & 0xfffffffe))(puStack_30);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 29351 ; VA 0x00c7db70 ; FUN_00c7db70 */

undefined __thiscall
FUN_00c7db70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined uVar5;
  undefined4 uStack_c4;
  undefined *puStack_c0;
  undefined4 uStack_a0;
  uint uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_4c;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_18 = &LAB_0180ea43;
  pvStack_1c = ExceptionList;
  uVar1 = *(undefined4 *)(param_1 + 0x2ec);
  uVar2 = *(undefined4 *)(param_1 + 0x2f0);
  uVar3 = *(undefined4 *)(param_1 + 0x2f4);
  uVar4 = *(undefined4 *)(param_1 + 0x2f8);
  uStack_9c = (uint)DAT_01efeae8;
  iStack_14 = 0;
  uStack_6c = 0;
  puStack_c0 = &stack0x00000024;
  uStack_c4 = 0xc7dbdd;
  ExceptionList = &pvStack_1c;
  FUN_00d88580();
  iStack_14._0_1_ = 1;
  FUN_0060e0c0(&uStack_c4,param_1);
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_00c6e370(&uStack_98,FUN_00c71320);
  uStack_9c = 0xc7dc0b;
  FUN_00c6d8f0();
  uStack_6c = param_9;
  uStack_70 = 0;
  uStack_74 = param_7;
  uStack_78 = param_6;
  uStack_7c = param_8;
  uStack_8c = param_2;
  uStack_88 = param_3;
  uStack_84 = param_4;
  uStack_80 = param_5;
  uStack_a0 = 0xc7dc47;
  uStack_9c = uVar1;
  uStack_98 = uVar2;
  uStack_94 = uVar3;
  uStack_90 = uVar4;
  uVar5 = FUN_00c7dd90();
  uStack_4c = 0xc7dc52;
  FUN_00d88a30();
  ExceptionList = pvStack_1c;
  return uVar5;
}



/* FUNCTION 29352 ; VA 0x00c7dc70 ; FUN_00c7dc70 */

undefined __thiscall
FUN_00c7dc70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13)

{
  int *piVar1;
  char cVar2;
  char cVar3;
  undefined4 in_stack_ffffffc4;
  undefined4 in_stack_ffffffc8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180ea58;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if ((((char)param_13 != '\0') || (piVar1 = *(int **)(param_1 + 0x148), piVar1 == (int *)0x0)) ||
     ((ExceptionList = &pvStack_10, piVar1[1] == 0 && (ExceptionList = &pvStack_10, *piVar1 == 0))))
  {
    ExceptionList = &pvStack_10;
    FUN_00d88580(&stack0x00000034);
    cVar2 = FUN_00c7db70(param_2,param_3,param_4,param_5,param_10,param_11,param_12,param_13,
                         in_stack_ffffffc4,in_stack_ffffffc8);
    LOCK();
    DAT_01e90cd8 = DAT_01e90cd8 + 1;
    UNLOCK();
    cVar3 = FUN_00c7d7a0(param_6,param_7,param_8,param_9,param_10,param_11,param_12,param_13,
                         RBX::Lua::WeakFunctionRef::vftable,0);
    if ((cVar3 != '\0') && (param_13._3_1_ = 1, cVar2 != '\0')) goto LAB_00c7dd69;
  }
  param_13._3_1_ = 0;
LAB_00c7dd69:
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return param_13._3_1_;
}



/* FUNCTION 29353 ; VA 0x00c7dd90 ; FUN_00c7dd90 */

undefined4 __thiscall
FUN_00c7dd90(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            char param_14,uint param_15)

{
  int *piVar1;
  int iVar2;
  undefined *puVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined *puStack_34;
  char *pcStack_30;
  undefined auStack_24 [12];
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0180ea18;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = (undefined4 *)param_1;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar2 != 0) && (param_1 = iVar2, ExceptionList = &pvStack_10, *(int *)(iVar2 + 0x34) != 0))
    {
      pcStack_30 = (char *)0xc7ddd4;
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar2 = *(int *)(param_1 + 0xc);
      pcStack_30 = (char *)0xc7dde6;
      iVar5 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        pcStack_30 = (char *)0xc7de0c;
        iStack_14 = FUN_008e3430();
        puVar8 = puStack_18;
        if (iStack_14 != 0) {
          piVar1 = (int *)((int)puStack_18 + 0x148);
          if (*(int *)((int)puStack_18 + 0x148) == 0) {
            pcStack_30 = (char *)0x8;
            puStack_34 = (undefined *)0xc7de30;
            puVar6 = (undefined4 *)FUN_01674e20();
            if (puVar6 == (undefined4 *)0x0) {
              puVar6 = (undefined4 *)0x0;
            }
            else {
              *puVar6 = 0;
              puVar6[1] = 0;
            }
            iVar2 = *piVar1;
            *piVar1 = (int)puVar6;
            if (iVar2 != 0) {
              puStack_34 = (undefined *)0xc7de58;
              pcStack_30 = (char *)iVar2;
              FUN_00c33560();
            }
            FUN_0060e0c0(&puStack_34,puVar8);
            FUN_00e8ec10();
          }
          if (*(int *)*piVar1 != 0) {
            if (param_14 == '\0') {
              iStack_8 = 1;
              if (((param_15 != 0) && ((param_15 & 1) == 0)) &&
                 (*(code **)(param_15 & 0xfffffffe) != (code *)0x0)) {
                puStack_34 = &stack0x00000040;
                pcStack_30 = (char *)0x2;
                (**(code **)(param_15 & 0xfffffffe))(puStack_34);
              }
              ExceptionList = pvStack_10;
              return 0;
            }
            piVar7 = (int *)(*(int *)*piVar1 + 0x38);
            if (*piVar7 != 0) {
              pcStack_30 = (char *)0x0;
              FUN_0054f510(piVar7);
              FUN_00e8ea30();
            }
            pcStack_30 = (char *)0x0;
            puStack_34 = (undefined *)0xc7dee4;
            FUN_00c7b9e0();
          }
          piVar1 = (int *)*piVar1;
          pcStack_30 = (char *)0x58;
          puStack_34 = (undefined *)0xc7def0;
          puStack_18 = (undefined4 *)FUN_01674e20();
          if (puStack_18 == (undefined4 *)0x0) {
            puVar8 = (undefined4 *)0x0;
          }
          else {
            *puStack_18 = param_2;
            puStack_18[1] = param_3;
            puStack_18[2] = param_4;
            puStack_18[3] = param_5;
            puStack_18[10] = param_11;
            puStack_18[4] = param_6;
            puStack_18[5] = param_7;
            puStack_18[6] = param_8;
            puStack_18[7] = param_9;
            puStack_18[8] = 0;
            puStack_18[9] = param_10;
            puStack_18[0xb] = param_12;
            puStack_18[0xc] = param_13;
            puStack_18[0xe] = 0;
            puVar8 = puStack_18;
          }
          puVar3 = (undefined *)*piVar1;
          *piVar1 = (int)puVar8;
          if (puVar3 != (undefined *)0x0) {
            uVar4 = *(uint *)(puVar3 + 0x38);
            iStack_8._0_1_ = 2;
            if (uVar4 != 0) {
              if ((uVar4 & 1) == 0) {
                puStack_34 = puVar3 + 0x40;
                if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
                  pcStack_30 = (char *)0x2;
                  (**(code **)(uVar4 & 0xfffffffe))(puStack_34);
                }
              }
              *(undefined4 *)(puVar3 + 0x38) = 0;
            }
            pcStack_30 = (char *)0x58;
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            puStack_34 = puVar3;
            FUN_01674ea0();
          }
          pcStack_30 = (char *)&param_15;
          puStack_34 = (undefined *)0xc7df92;
          FUN_00c70260();
          iStack_8 = 3;
          if (((param_15 != 0) && ((param_15 & 1) == 0)) &&
             (*(code **)(param_15 & 0xfffffffe) != (code *)0x0)) {
            puStack_34 = &stack0x00000040;
            pcStack_30 = (char *)0x2;
            (**(code **)(param_15 & 0xfffffffe))(puStack_34);
          }
          ExceptionList = pvStack_10;
          return 1;
        }
      }
    }
  }
  pcStack_30 = "Can only tween objects in the workspace";
  puStack_34 = (undefined *)0xc7dfda;
  FUN_00550130();
  pcStack_30 = "";
  puStack_34 = auStack_24;
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8();
}



/* FUNCTION 29354 ; VA 0x00c7dff0 ; FUN_00c7dff0 */

bool __fastcall FUN_00c7dff0(int param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar2 = *(int **)(param_1 + 0x148);
  piVar1 = (int *)(param_1 + 0x148);
  if (piVar2 == (int *)0x0) {
    return true;
  }
  if (piVar2[1] != 0) {
    FUN_00c6cfa0(FUN_00c7c400,0,0);
    FUN_00c72130(piVar2 + 1,param_1);
    piVar2 = (int *)*piVar1;
    if (*(float *)(piVar2[1] + 0x24) <= *(float *)(piVar2[1] + 0x20)) {
      FUN_00c7b9e0(0);
      piVar2 = (int *)*piVar1;
    }
  }
  if (*piVar2 != 0) {
    FUN_00c6cfa0(FUN_00c7c8c0,0,0);
    FUN_00c72130(piVar2,param_1);
    piVar2 = (int *)*piVar1;
    if (*(float *)(*piVar2 + 0x24) <= *(float *)(*piVar2 + 0x20)) {
      FUN_00c7b9e0(0);
      piVar2 = (int *)*piVar1;
    }
    if (*piVar2 != 0) goto LAB_00c7e0d6;
  }
  if (piVar2[1] == 0) {
    *piVar1 = 0;
    FUN_00c33560(piVar2);
    piVar2 = (int *)*piVar1;
  }
LAB_00c7e0d6:
  return piVar2 == (int *)0x0;
}



/* FUNCTION 29355 ; VA 0x00c7e0f0 ; FUN_00c7e0f0 */

int * __thiscall
FUN_00c7e0f0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d293;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c7e1e0();
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar3,uVar4,param_2,param_3,param_5,param_6,param_7,param_8,param_9,param_9,0);
  param_1[0xd] = 0;
  uStack_8 = 3;
  *param_1 = (int)RBX::Reflection::BoundProp<int,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<int,1>::BoundPropGetSet<class_RBX::ArcHandles>::vftable;
    puVar5[1] = param_1;
    puVar5[2] = param_4;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar5;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29356 ; VA 0x00c7e1e0 ; FUN_00c7e1e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c7e1e0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ea90;
  pvStack_10 = ExceptionList;
  if (DAT_01eff4e8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff700) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eff700);
      if (DAT_01eff700 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00ea4740();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ArcHandles",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01eff6f8 = RBX::Creator<class_RBX::ArcHandles>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eff4f0,&DAT_01eff6f8);
        FUN_016f3654(FUN_01896d80);
        FUN_016f37bf(&DAT_01eff700);
      }
    }
    DAT_01eff4e8 = &DAT_01eff4f0;
  }
  ExceptionList = pvStack_10;
  return DAT_01eff4e8;
}



/* FUNCTION 29357 ; VA 0x00c7e2e0 ; FUN_00c7e2e0 */

int __thiscall FUN_00c7e2e0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180eaa0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ArcHandles*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29358 ; VA 0x00c7e3b2 ; Catch_All@00c7e3b2 */

void Catch_All_00c7e3b2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29359 ; VA 0x00c7e3d0 ; FUN_00c7e3d0 */

undefined4 * FUN_00c7e3d0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180eae3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c7e1e0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x168);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c7e5f0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c7e2e0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29360 ; VA 0x00c7e490 ; FUN_00c7e490 */

undefined4 * __thiscall
FUN_00c7e490(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined auStack_110 [216];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180eb11;
  pvStack_1c = ExceptionList;
  uStack_38 = param_6;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00c7e1e0();
  FUN_009cb970(uVar1,param_3,param_5,uStack_38,param_7);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis),class_rbx::remote_signal<void___cdecl(enum_G3D::Vector3::Axis)>,class_rbx::remote_signal<void___cdecl(enum_G3D::Vector3::Axis)>_RBX::ArcHandles::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  thunk_FUN_00896ba0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_110,&uStack_38,puStack_30);
  iStack_14._0_1_ = 2;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 3;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_110,0xd8,1,FUN_00688b10);
  param_1[0xe] = param_9;
  param_1[0xf] = param_8;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis),class_rbx::remote_signal<void___cdecl(enum_G3D::Vector3::Axis)>,class_rbx::remote_signal<void___cdecl(enum_G3D::Vector3::Axis)>_RBX::ArcHandles::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 29361 ; VA 0x00c7e5f0 ; FUN_00c7e5f0 */

undefined4 * __fastcall FUN_00c7e5f0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ebbc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00ea4820("ArcHandles");
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ArcHandles,class_RBX::HandlesBase>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::ArcHandles,class_RBX::HandlesBase>::vftable;
  uVar1 = FUN_00c7e1e0();
  param_1[3] = uVar1;
  *param_1 = RBX::ArcHandles::vftable;
  param_1[0x15] = RBX::ArcHandles::vftable;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x33] = &DAT_021396f0;
  param_1[0x34] = 0;
  param_1[0x35] = &DAT_021395b0;
  param_1[0x36] = param_1 + 0x28;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x32] =
       RBX::EventReplicator<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis)>::vftable;
  param_1[0x39] = 0;
  param_1[0x3b] = &DAT_02139728;
  param_1[0x3c] = 0;
  param_1[0x3d] = &DAT_021395f0;
  param_1[0x3e] = param_1 + 0x2a;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x3a] =
       RBX::EventReplicator<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis)>::vftable;
  param_1[0x41] = 0;
  param_1[0x43] = &DAT_02139760;
  param_1[0x44] = 0;
  param_1[0x45] = &DAT_02139630;
  param_1[0x46] = param_1 + 0x2c;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x42] =
       RBX::EventReplicator<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis,float,float)>
       ::vftable;
  param_1[0x49] = 0;
  param_1[0x4b] = &DAT_02139798;
  param_1[0x4c] = 0;
  param_1[0x4d] = &DAT_02139670;
  param_1[0x4e] = param_1 + 0x2e;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x4a] =
       RBX::EventReplicator<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis)>::vftable;
  param_1[0x51] = 0;
  param_1[0x53] = &DAT_021397d0;
  param_1[0x54] = 0;
  param_1[0x55] = &DAT_021396b0;
  param_1[0x56] = param_1 + 0x30;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x52] =
       RBX::EventReplicator<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis)>::vftable;
  uStack_8 = 0xb;
  FUN_0054d840(7);
  param_1[0x34] = param_1;
  param_1[0x3c] = param_1;
  param_1[0x44] = param_1;
  param_1[0x4c] = param_1;
  param_1[0x54] = param_1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29362 ; VA 0x00c7e890 ; FUN_00c7e890 */

void __fastcall FUN_00c7e890(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ArcHandles>::vftable;
  uVar1 = FUN_00c7e1e0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29363 ; VA 0x00c7e8d0 ; thunk_FUN_00c7e8f0 */

void __fastcall thunk_FUN_00c7e8f0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::EventReplicatorBase<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis)>::
             vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29364 ; VA 0x00c7e8e0 ; thunk_FUN_00c7e990 */

void __fastcall thunk_FUN_00c7e990(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::
             EventReplicatorBase<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis,float,float)>
             ::vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29365 ; VA 0x00c7e8f0 ; FUN_00c7e8f0 */

void __fastcall FUN_00c7e8f0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::EventReplicatorBase<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis)>::
             vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29366 ; VA 0x00c7e990 ; FUN_00c7e990 */

void __fastcall FUN_00c7e990(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::
             EventReplicatorBase<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis,float,float)>
             ::vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29367 ; VA 0x00c7ea30 ; FUN_00c7ea30 */

/* WARNING: Removing unreachable block (ram,0x00c7ea91) */
/* WARNING: Removing unreachable block (ram,0x00c7eaa1) */
/* WARNING: Removing unreachable block (ram,0x00c7eaa7) */

void __fastcall FUN_00c7ea30(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ebe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29368 ; VA 0x00c7eaf8 ; Catch@00c7eaf8 */

undefined * Catch_00c7eaf8(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00c7eb09;
}



/* FUNCTION 29369 ; VA 0x00c7eb20 ; FUN_00c7eb20 */

undefined4 * __thiscall FUN_00c7eb20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Axes>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 29370 ; VA 0x00c7eb50 ; FUN_00c7eb50 */

undefined4 __thiscall FUN_00c7eb50(undefined4 param_1,byte param_2)

{
  FUN_00c7e8f0();
  FUN_00c7e8f0();
  FUN_00c7e990();
  FUN_00c7e8f0();
  FUN_00c7e8f0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00c6b560();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x168);
  }
  return param_1;
}



/* FUNCTION 29371 ; VA 0x00c7ec20 ; FUN_00c7ec20 */

undefined4 * __thiscall FUN_00c7ec20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Axes>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 29372 ; VA 0x00c7ec50 ; FUN_00c7ec50 */

undefined4 * __thiscall
FUN_00c7ec50(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180eca1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c7f260;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29373 ; VA 0x00c7ee00 ; FUN_00c7ee00 */

undefined4 * __thiscall
FUN_00c7ee00(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180ece1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c7f360;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29374 ; VA 0x00c7efb0 ; FUN_00c7efb0 */

void __fastcall FUN_00c7efb0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d561;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 8) == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x34) + *(int *)(param_1 + 8);
  }
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_006d7a70;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = iVar3;
    puVar5[6] = FUN_00c7fd60;
    puVar5[7] = param_1;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar4);
  iVar3 = *(int *)(param_1 + 0x18);
  *(undefined4 **)(param_1 + 0x18) = puVar5;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29375 ; VA 0x00c7f0d0 ; FUN_00c7f0d0 */

void __fastcall FUN_00c7f0d0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d561;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 8) == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x34) + *(int *)(param_1 + 8);
  }
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00c7f4c0;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = iVar3;
    puVar5[6] = FUN_00c7fe50;
    puVar5[7] = param_1;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar4);
  iVar3 = *(int *)(param_1 + 0x18);
  *(undefined4 **)(param_1 + 0x18) = puVar5;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29376 ; VA 0x00c7f1f0 ; FUN_00c7f1f0 */

undefined4 * FUN_00c7f1f0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c7e3d0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29377 ; VA 0x00c7f260 ; FUN_00c7f260 */

void FUN_00c7f260(int param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = thunk_FUN_00896ba0();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_ec = FUN_008971f0();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29378 ; VA 0x00c7f360 ; FUN_00c7f360 */

void FUN_00c7f360(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e104f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_290 = thunk_FUN_00896ba0();
  uStack_28c = 0;
  uStack_288 = param_2;
  uStack_28c = FUN_008971f0();
  iStack_8._0_1_ = 1;
  uStack_1c0 = FUN_0088c960();
  uStack_1bc = 0;
  uStack_1b8 = param_3;
  uStack_1bc = FUN_00630820();
  iStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088c960();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_00630820();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,piVar1);
  iStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 5;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  iStack_8 = 6;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29379 ; VA 0x00c7f4c0 ; FUN_00c7f4c0 */

void FUN_00c7f4c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  (**(code **)(param_1 + 0x18))(param_2,param_3,param_4);
  return;
}



/* FUNCTION 29380 ; VA 0x00c7f4f0 ; FUN_00c7f4f0 */

void FUN_00c7f4f0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = thunk_FUN_00896ba0();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_005e6780(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29381 ; VA 0x00c7f540 ; FUN_00c7f540 */

void FUN_00c7f540(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  
  iVar3 = *param_2;
  iVar6 = *(int *)(iVar3 + 0x1a0);
  iVar4 = FUN_0088c960();
  if (iVar6 == iVar4) {
    puVar5 = (undefined4 *)(iVar3 + 0x1a8);
    iVar6 = *param_2;
    if (*(int *)(iVar3 + 0x1a4) == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    iVar3 = *(int *)(iVar6 + 0xd0);
    uVar1 = *puVar5;
    iVar4 = FUN_0088c960();
    if (iVar3 == iVar4) {
      puVar5 = (undefined4 *)(iVar6 + 0xd8);
      param_2 = (int *)*param_2;
      if (*(int *)(iVar6 + 0xd4) == 0) {
        puVar5 = (undefined4 *)0x0;
      }
      iVar3 = *param_2;
      uVar2 = *puVar5;
      iVar6 = thunk_FUN_00896ba0();
      if (iVar3 == iVar6) {
        piVar7 = param_2 + 2;
        if (param_2[1] == 0) {
          piVar7 = (int *)0x0;
        }
        FUN_00c7ea30(*piVar7,uVar2,uVar1);
        return;
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29382 ; VA 0x00c7f600 ; FUN_00c7f600 */

void __thiscall FUN_00c7f600(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x164);
  return;
}



/* FUNCTION 29383 ; VA 0x00c7f620 ; FUN_00c7f620 */

void FUN_00c7f620(void)

{
  int iVar1;
  
  if (DAT_01eff704 == 0) {
    iVar1 = FUN_00c7e1e0();
    DAT_01eff704 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29384 ; VA 0x00c7f640 ; FUN_00c7f640 */

undefined4 __fastcall FUN_00c7f640(undefined4 param_1)

{
  undefined uVar1;
  
  FUN_0054d840(0);
  uVar1 = FUN_00aa5850(0);
  FUN_00a925f0(0,uVar1);
  uVar1 = FUN_00aa5850(1);
  FUN_00a925f0(1,uVar1);
  uVar1 = FUN_00aa5850(2);
  FUN_00a925f0(2,uVar1);
  uVar1 = FUN_00aa5850(0);
  FUN_00a925f0(3,uVar1);
  uVar1 = FUN_00aa5850(1);
  FUN_00a925f0(4,uVar1);
  uVar1 = FUN_00aa5850(2);
  FUN_00a925f0(5,uVar1);
  return param_1;
}



/* FUNCTION 29385 ; VA 0x00c7f6f0 ; FUN_00c7f6f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c7f6f0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  
  puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_2,param_2);
  uVar5 = FUN_0088ce60();
  puVar3 = param_3;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar5;
  if (*(int *)(iVar1 + 0x34) < DAT_01ead438) {
    FUN_016f3809(&DAT_01ead438);
    if (DAT_01ead438 == -1) {
      _DAT_01ead42c = FUN_005c65e0;
      _DAT_01ead430 = FUN_005c65e0;
      _DAT_01ead434 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead438);
    }
  }
  puVar2 = (undefined *)puVar3[1];
  if (puVar2 == &DAT_01ead42c) {
    puVar3[2] = *puVar4;
    return;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(puVar3 + 2);
    puVar3[1] = 0;
  }
  puVar3[2] = *puVar4;
  puVar3[1] = &DAT_01ead42c;
  return;
}



/* FUNCTION 29386 ; VA 0x00c7f7c0 ; FUN_00c7f7c0 */

uint FUN_00c7f7c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c7e1e0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29387 ; VA 0x00c7f7e0 ; FUN_00c7f7e0 */

uint FUN_00c7f7e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c7e1e0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29388 ; VA 0x00c7f800 ; FUN_00c7f800 */

undefined4 * __thiscall FUN_00c7f800(int param_1,undefined4 *param_2,int *param_3)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 *puVar9;
  int *piVar10;
  undefined auStack_98 [48];
  undefined auStack_68 [4];
  undefined auStack_64 [4];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint uStack_2c;
  uint uStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar10 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ed18;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uVar1 = *(uint *)(*param_3 + 0x54);
  if ((uVar1 < 5) && (*(char *)(param_1 + 0x80) != '\0')) {
    if (uVar1 == 0) {
      iVar2 = *(int *)(*param_3 + 0x5c);
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        if (iVar2 == 2) {
          ExceptionList = &pvStack_10;
          if (((DAT_01d68a34 != '\0') &&
              (ExceptionList = &pvStack_10, *(int *)(param_1 + 0x90) != 0)) &&
             (iVar2 = *(int *)(*(int *)(param_1 + 0x90) + 0x3c), ExceptionList = &pvStack_10,
             iVar2 != 6)) {
            ExceptionList = &pvStack_10;
            uVar6 = FUN_00aa58b0(iVar2);
            FUN_005e6780(uVar6);
          }
          *(undefined4 *)(param_1 + 0x90) = 0;
          piStack_1c = *(int **)(param_1 + 0x94);
          *(undefined4 *)(param_1 + 0x94) = 0;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar2;
            UNLOCK();
            piVar10 = param_3;
            if (iVar2 == 0) {
              (**(code **)*piStack_1c)();
              LOCK();
              piVar10 = piStack_1c + 2;
              iVar2 = *piVar10;
              *piVar10 = *piVar10 + -1;
              UNLOCK();
              piVar10 = param_3;
              if (iVar2 == 1) {
                (**(code **)(*piStack_1c + 4))();
                piVar10 = param_3;
              }
            }
          }
          if (DAT_01d68a34 == '\0') {
            uStack_60 = 0;
            uStack_5c = 0;
            uStack_58 = 0;
            cVar5 = FUN_00ea49f0(piVar10,&uStack_60,&uStack_3c);
            if (cVar5 != '\0') {
              uVar6 = FUN_00aa58b0(uStack_3c);
              FUN_005e6780(uVar6);
            }
          }
        }
LAB_00c7fc07:
        FUN_008b6b50(param_2);
        ExceptionList = pvStack_10;
        return param_2;
      }
      ExceptionList = &pvStack_10;
      uStack_48 = uVar1;
      uStack_44 = uVar1;
      uStack_40 = uVar1;
      cVar5 = FUN_00ea49f0(param_3,&uStack_48,&piStack_18);
      if (cVar5 == '\0') goto LAB_00c7fc07;
      puVar7 = (undefined4 *)FUN_01674e20(0x40);
      puStack_14 = puVar7;
      if (puVar7 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        piStack_1c = piStack_18;
        iVar2 = *(int *)(param_1 + 0x88);
        iStack_24 = 0;
        uStack_20 = 0;
        if (iVar2 != 0) {
          piVar10 = (int *)(iVar2 + 4);
          iVar2 = *(int *)(iVar2 + 4);
          while (iVar2 != 0) {
            LOCK();
            iVar8 = *piVar10;
            if (iVar2 == iVar8) {
              *piVar10 = iVar2 + 1;
              iVar8 = iVar2;
            }
            UNLOCK();
            if (iVar8 == iVar2) {
              iStack_24 = *(int *)(param_1 + 0x84);
              uStack_20 = *(undefined4 *)(param_1 + 0x88);
              break;
            }
            iVar2 = *piVar10;
          }
        }
        uStack_2c = 2;
        uStack_8 = 1;
        puVar9 = (undefined4 *)
                 (*(code *)**(undefined4 **)
                             (iStack_24 + *(int *)(*(int *)(iStack_24 + 0x54) + 4) + 0x54))
                           (auStack_98);
        uVar6 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar7 = *puVar9;
        puVar7[1] = uVar6;
        puVar7[2] = uVar3;
        puVar7[3] = uVar4;
        uVar6 = puVar9[5];
        uVar3 = puVar9[6];
        uVar4 = puVar9[7];
        puVar7[4] = puVar9[4];
        puVar7[5] = uVar6;
        puVar7[6] = uVar3;
        puVar7[7] = uVar4;
        uVar6 = puVar9[9];
        uVar3 = puVar9[10];
        uVar4 = puVar9[0xb];
        puVar7[8] = puVar9[8];
        puVar7[9] = uVar6;
        puVar7[10] = uVar3;
        puVar7[0xb] = uVar4;
        *(ulonglong *)(puVar7 + 0xc) = CONCAT44(uStack_44,uStack_48);
        puVar7[0xe] = uStack_40;
        puVar7[0xf] = piStack_1c;
      }
      uStack_8 = 2;
      uStack_34 = 0;
      uStack_30 = 0;
      FUN_00c6ad40(puVar7,param_2);
      *(undefined4 *)(param_1 + 0x90) = uStack_34;
      param_3 = *(int **)(param_1 + 0x94);
      *(undefined4 *)(param_1 + 0x94) = uStack_30;
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar2 = param_3[1] + -1;
        param_3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*param_3)();
          LOCK();
          piVar10 = param_3 + 2;
          iVar2 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*param_3 + 4))();
          }
        }
      }
      uStack_8 = 0xffffffff;
      if ((uStack_2c & 2) != 0) {
        FUN_00550b30();
      }
      uVar6 = FUN_00aa58b0(piStack_18);
      FUN_005e6780(uVar6);
      *param_2 = 1;
      goto LAB_00c7f94c;
    }
    if (uVar1 == 4) {
      iVar2 = *(int *)(param_1 + 0x90);
      ExceptionList = &pvStack_10;
      if ((iVar2 != 0) &&
         (ExceptionList = &pvStack_10,
         cVar5 = FUN_00ea4b50(param_3,*(undefined4 *)(iVar2 + 0x3c),iVar2 + 0x30,&uStack_28,
                              &piStack_38,auStack_68,auStack_64), cVar5 != '\0')) {
        piStack_18 = piStack_38;
        iVar2 = *(int *)(*(int *)(param_1 + 0x90) + 0x3c);
        if (2 < iVar2) {
          uStack_28 = uStack_28 ^ DAT_018c4ea0;
        }
        puStack_14 = (undefined4 *)uStack_28;
        uVar6 = FUN_00aa58b0(iVar2);
        FUN_00c7ea30(uVar6,puStack_14,piStack_18);
      }
      uStack_54 = 0;
      uStack_50 = 0;
      uStack_4c = 0;
      cVar5 = FUN_00ea49f0(piVar10,&uStack_54,&param_3);
      if (cVar5 == '\0') {
        if (*(int *)(param_1 + 0x8c) != 6) {
          uVar6 = FUN_00aa58b0(param_3);
          FUN_005e6780(uVar6);
          *(undefined4 *)(param_1 + 0x8c) = 6;
        }
      }
      else {
        piVar10 = *(int **)(param_1 + 0x8c);
        if ((piVar10 != (int *)&DAT_00000006) && (piVar10 != param_3)) {
          uVar6 = FUN_00aa58b0(piVar10);
          FUN_005e6780(uVar6);
        }
        *(int **)(param_1 + 0x8c) = param_3;
        uVar6 = FUN_00aa58b0(param_3);
        FUN_005e6780(uVar6);
      }
    }
  }
  *param_2 = 0;
LAB_00c7f94c:
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[4] = 0;
  param_2[3] = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29389 ; VA 0x00c7fc30 ; FUN_00c7fc30 */

void __thiscall FUN_00c7fc30(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x164) != param_2) {
    *(int *)(param_1 + 0x164) = param_2;
    FUN_008a4940(&DAT_02139578);
  }
  return;
}



/* FUNCTION 29390 ; VA 0x00c7fc60 ; FUN_00c7fc60 */

void __thiscall FUN_00c7fc60(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_dc [200];
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088ce60();
  if (iVar1 == iVar3) {
    iVar1 = *piVar2;
    iVar3 = FUN_0088ce60();
    if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
  }
  else {
    puVar4 = (undefined4 *)piVar2[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(piVar2 + 2,auStack_dc);
      puVar4 = (undefined4 *)piVar2[1];
    }
    uStack_8 = 0;
    param_3 = (int *)FUN_0088a510();
    param_3 = (int *)*param_3;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_dc);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_14)(param_2,&param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29391 ; VA 0x00c7fd60 ; FUN_00c7fd60 */

void __thiscall FUN_00c7fd60(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  code *pcVar2;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d53a1;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 8);
  uVar1 = *(undefined4 *)(param_1 + 0xc);
  uStack_28 = 0;
  uStack_24 = 0;
  pcVar2 = *(code **)(*piStack_14 + 8);
  ExceptionList = &pvStack_10;
  uStack_f8 = thunk_FUN_00896ba0();
  uStack_f4 = 0;
  uStack_f0 = param_2;
  uStack_f4 = FUN_008971f0();
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_f8,&uStack_28,param_2);
  uStack_8._0_1_ = 1;
  (*pcVar2)(uVar1,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_f8,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29392 ; VA 0x00c7fe50 ; FUN_00c7fe50 */

void __thiscall FUN_00c7fe50(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  code *pcVar2;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f12e7;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 8);
  uVar1 = *(undefined4 *)(param_1 + 0xc);
  uStack_28 = 0;
  uStack_24 = 0;
  pcVar2 = *(code **)(*piStack_14 + 8);
  ExceptionList = &pvStack_10;
  uStack_298 = thunk_FUN_00896ba0();
  uStack_294 = 0;
  uStack_290 = param_2;
  uStack_294 = FUN_008971f0();
  uStack_8 = 0;
  uStack_1c8 = FUN_0088c960();
  uStack_1c4 = 0;
  uStack_1c0 = param_3;
  uStack_1c4 = FUN_00630820();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_f8 = FUN_0088c960();
  uStack_f4 = 0;
  uStack_f0 = param_4;
  uStack_f4 = FUN_00630820();
  uStack_8 = 2;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_298,&uStack_28,param_2);
  uStack_8._0_1_ = 3;
  (*pcVar2)(uVar1,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_298,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29393 ; VA 0x00c7ffa0 ; FUN_00c7ffa0 */

int * __thiscall
FUN_00c7ffa0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f35eb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c80510();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::BodyGyro,class_G3D::CoordinateFrame>::
              GetSetImpl<class_G3D::CoordinateFrame_(__thiscall_RBX::BodyGyro::*)(void)const_,void_(__thiscall_RBX::BodyGyro::*)(class_G3D::CoordinateFrame)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::BodyGyro,class_G3D::CoordinateFrame>
                    ::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::BodyGyro,class_G3D::CoordinateFrame>
                    ::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29394 ; VA 0x00c800a0 ; FUN_00c800a0 */

int * __thiscall
FUN_00c800a0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c60c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c80510();
  FUN_006846c0(uVar3,param_2,param_3,0,param_7,param_8,param_9,param_10,param_11);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<float,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::BodyGyro>::vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = param_5;
    puVar4[5] = param_6;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29395 ; VA 0x00c80170 ; FUN_00c80170 */

int * __thiscall
FUN_00c80170(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c60c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c806f0();
  FUN_006846c0(uVar3,param_2,param_3,0,param_7,param_8,param_9,param_10,param_11);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<float,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::BodyPosition>::vftable
    ;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = param_5;
    puVar4[5] = param_6;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29396 ; VA 0x00c80240 ; FUN_00c80240 */

int * __thiscall
FUN_00c80240(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c60c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c809f0();
  FUN_006846c0(uVar3,param_2,param_3,0,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<float,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::Rocket>::vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29397 ; VA 0x00c80310 ; FUN_00c80310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c80310(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ed50;
  pvStack_10 = ExceptionList;
  if (DAT_01f00b28 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f00d40) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f00d40);
      if (DAT_01f00d40 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c80610();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BodyAngularVelocity",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f00d38 = RBX::Creator<class_RBX::BodyAngularVelocity>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f00b30,&DAT_01f00d38);
        FUN_016f3654(FUN_01897370);
        FUN_016f37bf(&DAT_01f00d40);
      }
    }
    DAT_01f00b28 = &DAT_01f00b30;
  }
  ExceptionList = pvStack_10;
  return DAT_01f00b28;
}



/* FUNCTION 29398 ; VA 0x00c80410 ; FUN_00c80410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c80410(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ed80;
  pvStack_10 = ExceptionList;
  if (DAT_01f002a8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f004c0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f004c0);
      if (DAT_01f004c0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c80610();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BodyForce",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f004b8 = RBX::Creator<class_RBX::BodyForce>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f002b0,&DAT_01f004b8);
        FUN_016f3654(FUN_018973d0);
        FUN_016f37bf(&DAT_01f004c0);
      }
    }
    DAT_01f002a8 = &DAT_01f002b0;
  }
  ExceptionList = pvStack_10;
  return DAT_01f002a8;
}



/* FUNCTION 29399 ; VA 0x00c80510 ; FUN_00c80510 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c80510(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180edb0;
  pvStack_10 = ExceptionList;
  if (DAT_01f00088 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f002a0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f002a0);
      if (DAT_01f002a0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c80610();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BodyGyro",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f00298 = RBX::Creator<class_RBX::BodyGyro>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f00090,&DAT_01f00298);
        FUN_016f3654(FUN_01897430);
        FUN_016f37bf(&DAT_01f002a0);
      }
    }
    DAT_01f00088 = &DAT_01f00090;
  }
  ExceptionList = pvStack_10;
  return DAT_01f00088;
}



/* FUNCTION 29400 ; VA 0x00c80610 ; FUN_00c80610 */

undefined * FUN_00c80610(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180edcc;
  pvStack_10 = ExceptionList;
  if (DAT_01effe70 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f00080) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f00080);
      if (DAT_01f00080 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BodyMover",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01897490);
        FUN_016f37bf(&DAT_01f00080);
      }
    }
    DAT_01effe70 = &DAT_01effe78;
  }
  ExceptionList = pvStack_10;
  return DAT_01effe70;
}



/* FUNCTION 29401 ; VA 0x00c806f0 ; FUN_00c806f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c806f0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ee00;
  pvStack_10 = ExceptionList;
  if (DAT_01f006e8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f00900) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f00900);
      if (DAT_01f00900 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c80610();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BodyPosition",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f008f8 = RBX::Creator<class_RBX::BodyPosition>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f006f0,&DAT_01f008f8);
        FUN_016f3654(FUN_018974a0);
        FUN_016f37bf(&DAT_01f00900);
      }
    }
    DAT_01f006e8 = &DAT_01f006f0;
  }
  ExceptionList = pvStack_10;
  return DAT_01f006e8;
}



/* FUNCTION 29402 ; VA 0x00c807f0 ; FUN_00c807f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c807f0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ee30;
  pvStack_10 = ExceptionList;
  if (DAT_01f004c8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f006e0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f006e0);
      if (DAT_01f006e0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c80610();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BodyThrust",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f006d8 = RBX::Creator<class_RBX::BodyThrust>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f004d0,&DAT_01f006d8);
        FUN_016f3654(FUN_01897500);
        FUN_016f37bf(&DAT_01f006e0);
      }
    }
    DAT_01f004c8 = &DAT_01f004d0;
  }
  ExceptionList = pvStack_10;
  return DAT_01f004c8;
}



/* FUNCTION 29403 ; VA 0x00c808f0 ; FUN_00c808f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c808f0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ee60;
  pvStack_10 = ExceptionList;
  if (DAT_01f00908 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f00b20) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f00b20);
      if (DAT_01f00b20 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c80610();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BodyVelocity",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f00b18 = RBX::Creator<class_RBX::BodyVelocity>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f00910,&DAT_01f00b18);
        FUN_016f3654(FUN_01897560);
        FUN_016f37bf(&DAT_01f00b20);
      }
    }
    DAT_01f00908 = &DAT_01f00910;
  }
  ExceptionList = pvStack_10;
  return DAT_01f00908;
}



/* FUNCTION 29404 ; VA 0x00c809f0 ; FUN_00c809f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c809f0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ee90;
  pvStack_10 = ExceptionList;
  if (DAT_01f00d48 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f00f60) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f00f60);
      if (DAT_01f00f60 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c80610();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RocketPropulsion",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f00f58 = RBX::Creator<class_RBX::Rocket>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f00d50,&DAT_01f00f58);
        FUN_016f3654(FUN_018975c0);
        FUN_016f37bf(&DAT_01f00f60);
      }
    }
    DAT_01f00d48 = &DAT_01f00d50;
  }
  ExceptionList = pvStack_10;
  return DAT_01f00d48;
}



/* FUNCTION 29405 ; VA 0x00c80af0 ; FUN_00c80af0 */

int __thiscall FUN_00c80af0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180eea0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::BodyAngularVelocity*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29406 ; VA 0x00c80bc2 ; Catch_All@00c80bc2 */

void Catch_All_00c80bc2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29407 ; VA 0x00c80be0 ; FUN_00c80be0 */

int __thiscall FUN_00c80be0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180eeb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::BodyForce*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29408 ; VA 0x00c80cb2 ; Catch_All@00c80cb2 */

void Catch_All_00c80cb2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29409 ; VA 0x00c80cd0 ; FUN_00c80cd0 */

int __thiscall FUN_00c80cd0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180eec0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::BodyGyro*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29410 ; VA 0x00c80da2 ; Catch_All@00c80da2 */

void Catch_All_00c80da2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29411 ; VA 0x00c80dc0 ; FUN_00c80dc0 */

int __thiscall FUN_00c80dc0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180eed0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::BodyPosition*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29412 ; VA 0x00c80e92 ; Catch_All@00c80e92 */

void Catch_All_00c80e92(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29413 ; VA 0x00c80eb0 ; FUN_00c80eb0 */

int __thiscall FUN_00c80eb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180eee0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::BodyThrust*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29414 ; VA 0x00c80f82 ; Catch_All@00c80f82 */

void Catch_All_00c80f82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29415 ; VA 0x00c80fa0 ; FUN_00c80fa0 */

int __thiscall FUN_00c80fa0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180eef0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::BodyVelocity*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29416 ; VA 0x00c81072 ; Catch_All@00c81072 */

void Catch_All_00c81072(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29417 ; VA 0x00c81090 ; FUN_00c81090 */

int __thiscall FUN_00c81090(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180ef00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Rocket*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29418 ; VA 0x00c81162 ; Catch_All@00c81162 */

void Catch_All_00c81162(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29419 ; VA 0x00c81180 ; FUN_00c81180 */

undefined4 * FUN_00c81180(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180ef4b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c80310();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x178);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00c81da0(PTR_s_BodyAngularVelocity_0196fc9c);
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::BodyAngularVelocity,class_RBX::BodyMover>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::BodyAngularVelocity,class_RBX::BodyMover>::
                   vftable;
    puVar3[0x17] = RBX::DescribedCreatable<class_RBX::BodyAngularVelocity,class_RBX::BodyMover>::
                   vftable;
    puVar3[0x3f] = RBX::DescribedCreatable<class_RBX::BodyAngularVelocity,class_RBX::BodyMover>::
                   vftable;
    uVar4 = FUN_00c80310();
    puVar3[3] = uVar4;
    *puVar3 = RBX::BodyAngularVelocity::vftable;
    puVar3[0x15] = RBX::BodyAngularVelocity::vftable;
    puVar3[0x17] = RBX::BodyAngularVelocity::vftable;
    puVar3[0x3f] = RBX::BodyAngularVelocity::vftable;
    puVar3[0x53] = 0x449c4000;
    puVar3[0x54] = 0x457a0000;
    puVar3[0x55] = 0x457a0000;
    puVar3[0x56] = 0x457a0000;
    puVar3[0x57] = 0;
    puVar3[0x58] = 0x40000000;
    puVar3[0x59] = 0;
    puVar3[0x5a] = 0;
    puVar3[0x5b] = 0;
    puVar3[0x5c] = 0;
    puVar3[0x5d] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c80af0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29420 ; VA 0x00c81310 ; FUN_00c81310 */

undefined4 * FUN_00c81310(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180ef9b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c80410();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x158);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00c81da0(PTR_s_BodyForce_0196fca0);
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::BodyForce,class_RBX::BodyMover>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::BodyForce,class_RBX::BodyMover>::vftable;
    puVar3[0x17] = RBX::DescribedCreatable<class_RBX::BodyForce,class_RBX::BodyMover>::vftable;
    puVar3[0x3f] = RBX::DescribedCreatable<class_RBX::BodyForce,class_RBX::BodyMover>::vftable;
    uVar4 = FUN_00c80410();
    puVar3[3] = uVar4;
    *puVar3 = RBX::BodyForce::vftable;
    puVar3[0x15] = RBX::BodyForce::vftable;
    puVar3[0x17] = RBX::BodyForce::vftable;
    puVar3[0x3f] = RBX::BodyForce::vftable;
    puVar3[0x53] = 0;
    puVar3[0x54] = 0x3f800000;
    puVar3[0x55] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c80be0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29421 ; VA 0x00c81440 ; FUN_00c81440 */

undefined4 * FUN_00c81440(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180efeb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c80510();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x1d0);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00c81da0(PTR_s_BodyGyro_0196fc98);
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::BodyGyro,class_RBX::BodyMover>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::BodyGyro,class_RBX::BodyMover>::vftable;
    puVar3[0x17] = RBX::DescribedCreatable<class_RBX::BodyGyro,class_RBX::BodyMover>::vftable;
    puVar3[0x3f] = RBX::DescribedCreatable<class_RBX::BodyGyro,class_RBX::BodyMover>::vftable;
    uVar4 = FUN_00c80510();
    puVar3[3] = uVar4;
    *puVar3 = RBX::BodyGyro::vftable;
    puVar3[0x15] = RBX::BodyGyro::vftable;
    puVar3[0x17] = RBX::BodyGyro::vftable;
    puVar3[0x3f] = RBX::BodyGyro::vftable;
    puVar3[0x53] = 0x453b8000;
    puVar3[0x54] = 0x43fa0000;
    puVar3[0x55] = 0x48c35000;
    puVar3[0x56] = 0;
    puVar3[0x57] = 0x48c35000;
    puVar3[0x58] = 0x3f800000;
    puVar3[0x59] = 0;
    puVar3[0x5a] = 0;
    puVar3[0x5b] = 0;
    puVar3[0x5c] = 0x3f800000;
    puVar3[0x5d] = 0;
    puVar3[0x5e] = 0;
    puVar3[0x5f] = 0;
    puVar3[0x60] = 0x3f800000;
    puVar3[0x61] = 0;
    puVar3[0x62] = 0;
    puVar3[99] = 0;
    puVar3[0x65] = 0;
    puVar3[0x66] = 0;
    puVar3[0x67] = 0;
    puVar3[100] = 0;
    puVar3[0x68] = 0;
    puVar3[0x6a] = 0;
    puVar3[0x6b] = 0;
    puVar3[0x6c] = 0;
    puVar3[0x69] = 0;
    puVar3[0x6d] = 0;
    puVar3[0x6f] = 0;
    puVar3[0x70] = 0;
    puVar3[0x71] = 0;
    puVar3[0x6e] = 0;
    puVar3[0x72] = 0;
    puVar3[0x73] = 0;
    *(undefined *)(puVar3 + 0x1d) = 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c80cd0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29422 ; VA 0x00c816b0 ; FUN_00c816b0 */

undefined4 * FUN_00c816b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180f03b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c806f0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x194);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00c81da0(PTR_s_BodyPosition_0196fc90);
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::BodyPosition,class_RBX::BodyMover>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::BodyPosition,class_RBX::BodyMover>::vftable;
    puVar3[0x17] = RBX::DescribedCreatable<class_RBX::BodyPosition,class_RBX::BodyMover>::vftable;
    puVar3[0x3f] = RBX::DescribedCreatable<class_RBX::BodyPosition,class_RBX::BodyMover>::vftable;
    uVar4 = FUN_00c806f0();
    puVar3[3] = uVar4;
    puVar3[0x53] = RBX::IStepped::vftable;
    puVar3[0x54] = 0;
    puVar3[0x55] = 0;
    *puVar3 = RBX::BodyPosition::vftable;
    puVar3[0x15] = RBX::BodyPosition::vftable;
    puVar3[0x17] = RBX::BodyPosition::vftable;
    puVar3[0x3f] = RBX::BodyPosition::vftable;
    puVar3[0x53] = RBX::BodyPosition::vftable;
    puVar3[0x56] = 0;
    puVar3[0x57] = 0x461c4000;
    puVar3[0x58] = 0x449c4000;
    puVar3[0x59] = 0x457a0000;
    puVar3[0x5a] = 0x457a0000;
    puVar3[0x5b] = 0x457a0000;
    puVar3[0x5c] = 0;
    puVar3[0x5d] = 0x42480000;
    puVar3[0x5e] = 0;
    puVar3[0x5f] = 0;
    puVar3[0x60] = 0;
    puVar3[0x61] = 0;
    *(undefined *)(puVar3 + 0x62) = 0;
    puVar3[99] = 0;
    puVar3[100] = 0;
    *(undefined *)(puVar3 + 0x1d) = 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c80dc0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29423 ; VA 0x00c81890 ; FUN_00c81890 */

undefined4 * FUN_00c81890(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180f08b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c807f0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x164);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00c81da0(PTR_s_BodyThrust_0196fca4);
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::BodyThrust,class_RBX::BodyMover>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::BodyThrust,class_RBX::BodyMover>::vftable;
    puVar3[0x17] = RBX::DescribedCreatable<class_RBX::BodyThrust,class_RBX::BodyMover>::vftable;
    puVar3[0x3f] = RBX::DescribedCreatable<class_RBX::BodyThrust,class_RBX::BodyMover>::vftable;
    uVar4 = FUN_00c807f0();
    puVar3[3] = uVar4;
    *puVar3 = RBX::BodyThrust::vftable;
    puVar3[0x15] = RBX::BodyThrust::vftable;
    puVar3[0x17] = RBX::BodyThrust::vftable;
    puVar3[0x3f] = RBX::BodyThrust::vftable;
    puVar3[0x53] = 0;
    puVar3[0x54] = 0x3f800000;
    puVar3[0x55] = 0;
    puVar3[0x56] = 0;
    puVar3[0x57] = 0;
    puVar3[0x58] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c80eb0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29424 ; VA 0x00c819f0 ; FUN_00c819f0 */

undefined4 * FUN_00c819f0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180f0db;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c808f0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x178);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00c81da0(PTR_s_BodyVelocity_0196fc94);
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::BodyVelocity,class_RBX::BodyMover>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::BodyVelocity,class_RBX::BodyMover>::vftable;
    puVar3[0x17] = RBX::DescribedCreatable<class_RBX::BodyVelocity,class_RBX::BodyMover>::vftable;
    puVar3[0x3f] = RBX::DescribedCreatable<class_RBX::BodyVelocity,class_RBX::BodyMover>::vftable;
    uVar4 = FUN_00c808f0();
    puVar3[3] = uVar4;
    *puVar3 = RBX::BodyVelocity::vftable;
    puVar3[0x15] = RBX::BodyVelocity::vftable;
    puVar3[0x17] = RBX::BodyVelocity::vftable;
    puVar3[0x3f] = RBX::BodyVelocity::vftable;
    puVar3[0x53] = 0x449c4000;
    puVar3[0x54] = 0x457a0000;
    puVar3[0x55] = 0x457a0000;
    puVar3[0x56] = 0x457a0000;
    puVar3[0x57] = 0;
    puVar3[0x58] = 0x40000000;
    puVar3[0x59] = 0;
    puVar3[0x5a] = 0;
    puVar3[0x5b] = 0;
    puVar3[0x5c] = 0;
    puVar3[0x5d] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c80fa0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29425 ; VA 0x00c81b80 ; FUN_00c81b80 */

undefined4 * FUN_00c81b80(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180f15d;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c809f0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x1a8);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00c81da0(PTR_s_RocketPropulsion_0196fca8);
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::Rocket,class_RBX::BodyMover>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::Rocket,class_RBX::BodyMover>::vftable;
    puVar3[0x17] = RBX::DescribedCreatable<class_RBX::Rocket,class_RBX::BodyMover>::vftable;
    puVar3[0x3f] = RBX::DescribedCreatable<class_RBX::Rocket,class_RBX::BodyMover>::vftable;
    uVar4 = FUN_00c809f0();
    puVar3[3] = uVar4;
    puVar3[0x53] = RBX::IStepped::vftable;
    puVar3[0x54] = 0;
    puVar3[0x55] = 0;
    *puVar3 = RBX::Rocket::vftable;
    puVar3[0x15] = RBX::Rocket::vftable;
    puVar3[0x17] = RBX::Rocket::vftable;
    puVar3[0x3f] = RBX::Rocket::vftable;
    puVar3[0x53] = RBX::Rocket::vftable;
    *(undefined *)(puVar3 + 0x56) = 0;
    puVar3[0x57] = 0;
    puVar3[0x58] = 0;
    puVar3[0x59] = 0;
    puVar3[0x5a] = 0;
    puVar3[0x5b] = 0;
    puVar3[0x5c] = 0x40800000;
    *(undefined *)(puVar3 + 0x5d) = 0;
    puVar3[0x5e] = 0x457a0000;
    puVar3[0x5f] = 0x40a00000;
    puVar3[0x60] = 0x3a83126f;
    puVar3[0x61] = 0x41f00000;
    puVar3[0x62] = 0x453b8000;
    puVar3[99] = 0x43fa0000;
    puVar3[100] = 0x48c35000;
    puVar3[0x65] = 0x48c35000;
    puVar3[0x66] = 0;
    puVar3[0x67] = 0x3f333333;
    puVar3[0x68] = 0;
    puVar3[0x69] = 0;
    uStack_8._0_1_ = 7;
    if (DAT_01f754a1 != '\0') {
      FUN_016774b0(DAT_01f754a1,"Rocket created - %p",puVar3);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c81090(puVar3,param_1);
  uStack_8 = 0xb;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29426 ; VA 0x00c81da0 ; FUN_00c81da0 */

undefined4 * __thiscall FUN_00c81da0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f1af;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::BodyMover,class_RBX::Instance>::vftable;
  uVar2 = FUN_00c80610();
  param_1[3] = uVar2;
  puVar1 = param_1 + 0x15;
  uStack_8 = 1;
  puStack_18 = puVar1;
  FUN_00ca27c0();
  param_1[0x3f] = RBX::Connector::vftable;
  param_1[0x40] = 0xffffffff;
  param_1[0x41] = 0xffffffff;
  param_1[0x42] = 0xffffffff;
  param_1[0x43] = 0xffffffff;
  param_1[0x44] = 0xffffffff;
  param_1[0x45] = 0xffffffff;
  *puVar1 = RBX::KernelJoint::vftable;
  param_1[0x17] = RBX::KernelJoint::vftable;
  param_1[0x3f] = RBX::KernelJoint::vftable;
  uStack_8._0_1_ = 2;
  *(undefined *)(param_1 + 0x46) = 0;
  param_1[0x47] = 0;
  FUN_016f4053(param_1 + 0x48,4,2,FUN_00610ca0,FUN_005f60a0);
  *param_1 = RBX::BodyMover::vftable;
  *puVar1 = RBX::BodyMover::vftable;
  param_1[0x17] = RBX::BodyMover::vftable;
  param_1[0x3f] = RBX::BodyMover::vftable;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  uStack_8._0_1_ = 4;
  FUN_0054eff0(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008a6520(aiStack_30);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    iVar3 = aiStack_30[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_30[0] + -4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29427 ; VA 0x00c81f60 ; FUN_00c81f60 */

undefined4 * __thiscall
FUN_00c81f60(undefined4 *param_1,char param_2,undefined4 param_3,undefined4 param_4,byte param_5,
            byte param_6)

{
  uint3 uVar1;
  byte bVar3;
  uint uVar2;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180f1e9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[2] = param_3;
  param_1[3] = param_4;
  param_1[4] = 0;
  param_1[5] = 0;
  iVar4 = 0;
  *(byte *)(param_1 + 8) = *(byte *)(param_1 + 8) & 0xfc;
  uStack_8 = 0;
  *param_1 = RBX::Solver::Constraint::vftable;
  *(byte *)(param_1 + 6) = param_5;
  *(undefined *)((int)param_1 + 0x19) = 0;
  *(byte *)((int)param_1 + 0x1a) = param_6;
  *(char *)(param_1 + 7) = param_2;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  uVar5 = (uint)param_5;
  if (param_5 != 0) {
    uVar1 = 0;
    do {
      bVar3 = (byte)iVar4;
      iVar4 = iVar4 + 1;
      uVar2 = CONCAT31(uVar1,param_6 >> (bVar3 & 0x1f)) & 0xffffff01;
      bVar3 = (char)(uVar2 >> 8) + (char)uVar2;
      uVar1 = (uint3)bVar3;
    } while (iVar4 < (int)uVar5);
    *(byte *)((int)param_1 + 0x19) = bVar3;
  }
  if (param_2 != '\x01') {
    iVar4 = FUN_01674e20(uVar5 * 0x48);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iVar4 == 0) {
      iVar4 = 0;
    }
    else {
      for (; uVar5 != 0; uVar5 = uVar5 - 1) {
        FUN_00c82060();
      }
    }
    param_1[9] = iVar4;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29428 ; VA 0x00c82060 ; FUN_00c82060 */

undefined4 * __fastcall FUN_00c82060(undefined4 *param_1)

{
  param_1[4] = 0x3ff33333;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[5] = 0x3f800000;
  param_1[6] = 0x3ff33333;
  param_1[7] = 0x3f800000;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[8] = 0;
  param_1[0xc] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0xd] = 0;
  param_1[0x11] = 0;
  return param_1;
}



/* FUNCTION 29429 ; VA 0x00c820d0 ; FUN_00c820d0 */

void __fastcall FUN_00c820d0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::BodyAngularVelocity>::vftable;
  uVar1 = FUN_00c80310(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29430 ; VA 0x00c82110 ; FUN_00c82110 */

void __fastcall FUN_00c82110(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::BodyForce>::vftable;
  uVar1 = FUN_00c80410(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29431 ; VA 0x00c82150 ; FUN_00c82150 */

void __fastcall FUN_00c82150(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::BodyGyro>::vftable;
  uVar1 = FUN_00c80510(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29432 ; VA 0x00c82190 ; FUN_00c82190 */

void __fastcall FUN_00c82190(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::BodyPosition>::vftable;
  uVar1 = FUN_00c806f0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29433 ; VA 0x00c821d0 ; FUN_00c821d0 */

void __fastcall FUN_00c821d0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::BodyThrust>::vftable;
  uVar1 = FUN_00c807f0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29434 ; VA 0x00c82210 ; FUN_00c82210 */

void __fastcall FUN_00c82210(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::BodyVelocity>::vftable;
  uVar1 = FUN_00c808f0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29435 ; VA 0x00c82250 ; FUN_00c82250 */

void __fastcall FUN_00c82250(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Rocket>::vftable;
  uVar1 = FUN_00c809f0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29436 ; VA 0x00c82290 ; thunk_FUN_00c822a0 */

void __fastcall thunk_FUN_00c822a0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::BodyMover::vftable;
  param_1[0x15] = RBX::BodyMover::vftable;
  param_1[0x17] = RBX::BodyMover::vftable;
  param_1[0x3f] = RBX::BodyMover::vftable;
  piVar1 = (int *)param_1[0x52];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uStack_8 = 0;
  FUN_016f32d1(param_1 + 0x48,4,2,FUN_005f60a0);
  param_1[0x15] = RBX::KernelJoint::vftable;
  param_1[0x17] = RBX::KernelJoint::vftable;
  param_1[0x3f] = RBX::Connector::vftable;
  FUN_00ca2b60();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29437 ; VA 0x00c822a0 ; FUN_00c822a0 */

void __fastcall FUN_00c822a0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::BodyMover::vftable;
  param_1[0x15] = RBX::BodyMover::vftable;
  param_1[0x17] = RBX::BodyMover::vftable;
  param_1[0x3f] = RBX::BodyMover::vftable;
  piVar1 = (int *)param_1[0x52];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uStack_8 = 0;
  FUN_016f32d1(param_1 + 0x48,4,2,FUN_005f60a0);
  param_1[0x15] = RBX::KernelJoint::vftable;
  param_1[0x17] = RBX::KernelJoint::vftable;
  param_1[0x3f] = RBX::Connector::vftable;
  FUN_00ca2b60();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29438 ; VA 0x00c82350 ; FUN_00c82350 */

void __fastcall FUN_00c82350(undefined4 *param_1)

{
  *param_1 = RBX::Solver::InteractingPair::vftable;
  return;
}



/* FUNCTION 29439 ; VA 0x00c82357 ; FUN_00c82357 */

void FUN_00c82357(void)

{
  FUN_00c82430();
  return;
}



/* FUNCTION 29440 ; VA 0x00c8235f ; FUN_00c8235f */

void FUN_00c8235f(void)

{
  FUN_00c82430();
  return;
}



/* FUNCTION 29441 ; VA 0x00c82367 ; FUN_00c82367 */

void FUN_00c82367(void)

{
  FUN_00c82430();
  return;
}



/* FUNCTION 29442 ; VA 0x00c82372 ; FUN_00c82372 */

void FUN_00c82372(void)

{
  FUN_00c82460();
  return;
}



/* FUNCTION 29443 ; VA 0x00c8237a ; FUN_00c8237a */

void FUN_00c8237a(void)

{
  FUN_00c82460();
  return;
}



/* FUNCTION 29444 ; VA 0x00c82382 ; FUN_00c82382 */

void FUN_00c82382(void)

{
  FUN_00c82460();
  return;
}



/* FUNCTION 29445 ; VA 0x00c8238d ; FUN_00c8238d */

void FUN_00c8238d(void)

{
  FUN_00c82490();
  return;
}



/* FUNCTION 29446 ; VA 0x00c82395 ; FUN_00c82395 */

void FUN_00c82395(void)

{
  FUN_00c82490();
  return;
}



/* FUNCTION 29447 ; VA 0x00c8239d ; FUN_00c8239d */

void FUN_00c8239d(void)

{
  FUN_00c82490();
  return;
}



/* FUNCTION 29448 ; VA 0x00c823a8 ; FUN_00c823a8 */

void FUN_00c823a8(void)

{
  FUN_00c824c0();
  return;
}



/* FUNCTION 29449 ; VA 0x00c823b0 ; FUN_00c823b0 */

void FUN_00c823b0(void)

{
  FUN_00c824c0();
  return;
}



/* FUNCTION 29450 ; VA 0x00c823b8 ; FUN_00c823b8 */

void FUN_00c823b8(void)

{
  FUN_00c824c0();
  return;
}



/* FUNCTION 29451 ; VA 0x00c823c3 ; FUN_00c823c3 */

void FUN_00c823c3(void)

{
  FUN_00c82550();
  return;
}



/* FUNCTION 29452 ; VA 0x00c823ce ; FUN_00c823ce */

void FUN_00c823ce(void)

{
  FUN_00c82550();
  return;
}



/* FUNCTION 29453 ; VA 0x00c823d6 ; FUN_00c823d6 */

void FUN_00c823d6(void)

{
  FUN_00c82550();
  return;
}



/* FUNCTION 29454 ; VA 0x00c823de ; FUN_00c823de */

void FUN_00c823de(void)

{
  FUN_00c82550();
  return;
}



/* FUNCTION 29455 ; VA 0x00c823e9 ; FUN_00c823e9 */

void FUN_00c823e9(void)

{
  FUN_00c82640();
  return;
}



/* FUNCTION 29456 ; VA 0x00c823f1 ; FUN_00c823f1 */

void FUN_00c823f1(void)

{
  FUN_00c82640();
  return;
}



/* FUNCTION 29457 ; VA 0x00c823f9 ; FUN_00c823f9 */

void FUN_00c823f9(void)

{
  FUN_00c82640();
  return;
}



/* FUNCTION 29458 ; VA 0x00c82404 ; FUN_00c82404 */

void FUN_00c82404(void)

{
  FUN_00c82790();
  return;
}



/* FUNCTION 29459 ; VA 0x00c8240f ; FUN_00c8240f */

void FUN_00c8240f(void)

{
  FUN_00c82790();
  return;
}



/* FUNCTION 29460 ; VA 0x00c82417 ; FUN_00c82417 */

void FUN_00c82417(void)

{
  FUN_00c82790();
  return;
}



/* FUNCTION 29461 ; VA 0x00c8241f ; FUN_00c8241f */

void FUN_00c8241f(void)

{
  FUN_00c82790();
  return;
}



/* FUNCTION 29462 ; VA 0x00c82430 ; FUN_00c82430 */

undefined4 __thiscall FUN_00c82430(undefined4 param_1,byte param_2)

{
  FUN_00c822a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14c);
  }
  return param_1;
}



/* FUNCTION 29463 ; VA 0x00c82460 ; FUN_00c82460 */

undefined4 __thiscall FUN_00c82460(undefined4 param_1,byte param_2)

{
  FUN_00c822a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x178);
  }
  return param_1;
}



/* FUNCTION 29464 ; VA 0x00c82490 ; FUN_00c82490 */

undefined4 __thiscall FUN_00c82490(undefined4 param_1,byte param_2)

{
  FUN_00c822a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x158);
  }
  return param_1;
}



/* FUNCTION 29465 ; VA 0x00c824c0 ; FUN_00c824c0 */

undefined4 * __thiscall FUN_00c824c0(undefined4 *param_1,byte param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::BodyGyro::vftable;
  param_1[0x15] = RBX::BodyGyro::vftable;
  param_1[0x17] = RBX::BodyGyro::vftable;
  param_1[0x3f] = RBX::BodyGyro::vftable;
  if (param_1[0x73] != 0) {
    FUN_00ca3cc0();
    if ((undefined4 *)param_1[0x73] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)param_1[0x73])(1);
    }
  }
  FUN_00c822a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1d0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29466 ; VA 0x00c82550 ; FUN_00c82550 */

undefined4 * __thiscall FUN_00c82550(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::BodyPosition::vftable;
  param_1[0x15] = RBX::BodyPosition::vftable;
  param_1[0x17] = RBX::BodyPosition::vftable;
  param_1[0x3f] = RBX::BodyPosition::vftable;
  param_1[0x53] = RBX::BodyPosition::vftable;
  if (param_1[0x56] != 0) {
    FUN_00ca3cc0();
    if ((undefined4 *)param_1[0x56] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)param_1[0x56])(1);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  param_1[0x53] = RBX::IStepped::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01679490();
  iVar3 = param_1[0x55];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_00c822a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x194);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29467 ; VA 0x00c82640 ; FUN_00c82640 */

undefined4 __thiscall FUN_00c82640(undefined4 param_1,byte param_2)

{
  FUN_00c822a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x164);
  }
  return param_1;
}



/* FUNCTION 29468 ; VA 0x00c82670 ; FUN_00c82670 */

undefined4 __thiscall FUN_00c82670(undefined4 param_1,byte param_2)

{
  FUN_01084500();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 29469 ; VA 0x00c826a0 ; FUN_00c826a0 */

undefined4 __thiscall FUN_00c826a0(undefined4 param_1,byte param_2)

{
  FUN_01084500();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  return param_1;
}



/* FUNCTION 29470 ; VA 0x00c826d0 ; FUN_00c826d0 */

undefined4 __thiscall FUN_00c826d0(undefined4 param_1,byte param_2)

{
  FUN_01084500();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 29471 ; VA 0x00c82700 ; FUN_00c82700 */

undefined4 __thiscall FUN_00c82700(undefined4 param_1,byte param_2)

{
  FUN_01084500();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  return param_1;
}



/* FUNCTION 29472 ; VA 0x00c82730 ; FUN_00c82730 */

undefined4 __thiscall FUN_00c82730(undefined4 param_1,byte param_2)

{
  FUN_01084500();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 29473 ; VA 0x00c82760 ; FUN_00c82760 */

undefined4 * __thiscall FUN_00c82760(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Solver::InteractingPair::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 29474 ; VA 0x00c82790 ; FUN_00c82790 */

undefined4 * __thiscall FUN_00c82790(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Rocket::vftable;
  param_1[0x15] = RBX::Rocket::vftable;
  param_1[0x17] = RBX::Rocket::vftable;
  param_1[0x3f] = RBX::Rocket::vftable;
  param_1[0x53] = RBX::Rocket::vftable;
  uStack_8 = 0;
  if (DAT_01f754a1 != '\0') {
    FUN_016774b0(DAT_01f754a1,"Rocket destroyed - %p",param_1);
  }
  FUN_016790b0();
  FUN_016790b0();
  piVar2 = (int *)param_1[0x58];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[0x53] = RBX::IStepped::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01679490();
  iVar3 = param_1[0x55];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_00c822a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1a8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29475 ; VA 0x00c828b0 ; FUN_00c828b0 */

void __fastcall FUN_00c828b0(uint param_1)

{
  undefined4 uStack_8;
  
  uStack_8 = param_1 & 0xffffff;
  (**(code **)(*DAT_02139ac8 + 0x10))(param_1,(int)&uStack_8 + 3);
  return;
}



/* FUNCTION 29476 ; VA 0x00c828d0 ; FUN_00c828d0 */

void __thiscall FUN_00c828d0(int param_1,float *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x20) + 0x2c);
  if (iVar1 != 0) {
    FUN_00f9f070();
    *(float *)(iVar1 + 0x164) = *param_2 + *(float *)(iVar1 + 0x164);
    *(float *)(iVar1 + 0x168) = param_2[1] + *(float *)(iVar1 + 0x168);
    *(float *)(iVar1 + 0x16c) = param_2[2] + *(float *)(iVar1 + 0x16c);
  }
  return;
}



/* FUNCTION 29477 ; VA 0x00c82930 ; FUN_00c82930 */

void __thiscall FUN_00c82930(int param_1,float *param_2)

{
  FUN_00f9f070();
  *(float *)(param_1 + 0x164) = *(float *)(param_1 + 0x164) + *param_2;
  *(float *)(param_1 + 0x168) = param_2[1] + *(float *)(param_1 + 0x168);
  *(float *)(param_1 + 0x16c) = param_2[2] + *(float *)(param_1 + 0x16c);
  return;
}



/* FUNCTION 29478 ; VA 0x00c82990 ; FUN_00c82990 */

bool FUN_00c82990(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00c829c2;
  }
  param_1 = 0;
LAB_00c829c2:
  return param_1 != 0;
}



/* FUNCTION 29479 ; VA 0x00c829d0 ; FUN_00c829d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c829d0(int param_1,float *param_2,int param_3)

{
  undefined8 uVar1;
  float *pfVar2;
  int iVar3;
  float10 fVar4;
  undefined4 uVar5;
  double dVar6;
  double dVar7;
  uint uVar8;
  uint uVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined auStack_3c [12];
  float fStack_30;
  undefined8 uStack_2c;
  undefined8 uStack_24;
  undefined8 uStack_1c;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  dVar6 = (double)*(float *)(param_1 + 0x154);
  if (NAN(dVar6) == (dVar6 == 0.0)) {
    uVar8 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    uStack_2c = (double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & uVar8,
                                 SUB84(dVar6,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    uStack_1c = (double)CONCAT44((uint)((ulonglong)(dVar6 - 0.0) >> 0x20) & uVar8,
                                 SUB84(dVar6 - 0.0,0) & (uint)DAT_018c0da0);
    fVar4 = (float10)FUN_01160810();
    uStack_24 = (double)fVar4;
    dVar6 = DAT_018f76b0;
    if ((NAN(uStack_2c) || NAN(uStack_24)) == (uStack_2c == uStack_24)) {
      dVar6 = uStack_2c * DAT_018f76b0;
    }
    if (dVar6 < uStack_1c) goto LAB_00c82ac9;
  }
  dVar6 = (double)*(float *)(param_1 + 0x15c);
  if (NAN(dVar6) == (dVar6 == 0.0)) {
    uVar8 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    uStack_2c = (double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & uVar8,
                                 SUB84(dVar6,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    uStack_1c = (double)CONCAT44((uint)((ulonglong)(dVar6 - 0.0) >> 0x20) & uVar8,
                                 SUB84(dVar6 - 0.0,0) & (uint)DAT_018c0da0);
    fVar4 = (float10)FUN_01160810();
    uStack_24 = (double)fVar4;
    dVar6 = DAT_018f76b0;
    if ((NAN(uStack_2c) || NAN(uStack_24)) == (uStack_2c == uStack_24)) {
      dVar6 = uStack_2c * DAT_018f76b0;
    }
    if (dVar6 < uStack_1c) {
LAB_00c82ac9:
      FUN_00fa07b0();
      FUN_011612d0(&fStack_30,1);
      fVar11 = *(float *)(param_3 + 0xbc) * fStack_30 + *(float *)(param_3 + 200) * (float)uStack_2c
               + *(float *)(param_3 + 0xd4) * uStack_2c._4_4_;
      fStack_8 = *(float *)(param_3 + 0xb4) * fStack_30 +
                 (float)uStack_2c * *(float *)(param_3 + 0xc0) +
                 *(float *)(param_3 + 0xcc) * uStack_2c._4_4_;
      fStack_c = *(float *)(param_1 + 0x14c);
      fStack_10 = *(float *)(param_1 + 0x150);
      if (DAT_01d67c90 == '\0') {
        uVar5 = 0;
      }
      else {
        uVar5 = *(undefined4 *)(*(int *)(param_1 + 0x140) + 0x610);
      }
      FUN_00c848f0(&fStack_c,&fStack_10,uVar5);
      fVar10 = *(float *)(param_1 + 0x194) + *(float *)(param_1 + 0x198) +
               *(float *)(param_1 + 0x19c);
      dVar6 = (double)fVar10;
      uVar8 = (uint)DAT_018c0da0;
      uVar9 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
      fVar12 = (float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & uVar9,
                                       SUB84(dVar6,0) & uVar8);
      fStack_14 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_8 >> 0x20) & uVar9,
                                          SUB84((double)fStack_8,0) & uVar8);
      if (fVar12 <= fStack_14) {
        fVar12 = fStack_14;
      }
      dVar6 = (double)(fStack_8 - fVar10);
      dVar6 = (double)(float)((uint)((((float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) &
                                                               uVar9,SUB84(dVar6,0) & uVar8) *
                                      *(float *)(param_1 + 400)) / (fVar12 + DAT_018fe498)) *
                                    _DAT_01d68a44) ^ DAT_018c4ea0);
      FUN_01727e40();
      fVar10 = fStack_8 - *(float *)(param_1 + 0x194);
      *(float *)(param_1 + 0x19c) = fVar10 - *(float *)(param_1 + 0x198);
      fVar12 = DAT_018ce2f8;
      *(float *)(param_1 + 0x198) = fVar10;
      *(float *)(param_1 + 0x194) = fStack_8;
      *(float *)(param_1 + 400) =
           (fVar12 - *(float *)(param_1 + 400)) * DAT_018e452c + *(float *)(param_1 + 400);
      uVar1 = DAT_018c0da0;
      *(float *)(param_1 + 0x1a0) = *(float *)(param_1 + 0x1a0) * 0.0 + fStack_14;
      fVar10 = *(float *)(param_1 + 0x1bc) + *(float *)(param_1 + 0x1c0) +
               *(float *)(param_1 + 0x1c4);
      dVar7 = (double)fVar10;
      uVar8 = (uint)uVar1;
      uVar9 = (uint)((ulonglong)uVar1 >> 0x20);
      fVar12 = (float)(double)CONCAT44((uint)((ulonglong)dVar7 >> 0x20) & uVar9,
                                       SUB84(dVar7,0) & uVar8);
      fStack_14 = (float)(double)CONCAT44((uint)((ulonglong)(double)fVar11 >> 0x20) & uVar9,
                                          SUB84((double)fVar11,0) & uVar8);
      if (fVar12 <= fStack_14) {
        fVar12 = fStack_14;
      }
      dVar7 = (double)(fVar11 - fVar10);
      dVar7 = (double)(float)((uint)((((float)(double)CONCAT44((uint)((ulonglong)dVar7 >> 0x20) &
                                                               uVar9,SUB84(dVar7,0) & uVar8) *
                                      *(float *)(param_1 + 0x1b8)) / (fVar12 + DAT_018fe498)) *
                                    _DAT_01d68a44) ^ DAT_018c4ea0);
      uStack_2c._4_4_ = (float)dVar6;
      FUN_01727e40();
      fVar12 = fVar11 - *(float *)(param_1 + 0x1bc);
      *(float *)(param_1 + 0x1c4) = fVar12 - *(float *)(param_1 + 0x1c0);
      *(float *)(param_1 + 0x1c0) = fVar12;
      fVar12 = DAT_018ce2f8 - *(float *)(param_1 + 0x1b8);
      *(float *)(param_1 + 0x1bc) = fVar11;
      *(float *)(param_1 + 0x1b8) = fVar12 * DAT_018e452c + *(float *)(param_1 + 0x1b8);
      *(float *)(param_1 + 0x1c8) = *(float *)(param_1 + 0x1c8) * 0.0 + fStack_14;
      uStack_1c._4_4_ = (float)dVar7;
      FUN_00fa07b0();
      FUN_00fa07b0();
      fStack_14 = *(float *)(param_3 + 0xf4) * *(float *)(param_3 + 0xc0) +
                  *(float *)(param_3 + 0xb4) * *(float *)(param_3 + 0xf0) +
                  *(float *)(param_3 + 0xcc) * *(float *)(param_3 + 0xf8);
      uStack_24._4_4_ =
           *(float *)(param_3 + 0xbc) * *(float *)(param_3 + 0xf0) +
           *(float *)(param_3 + 0xf4) * *(float *)(param_3 + 200) +
           *(float *)(param_3 + 0xd4) * *(float *)(param_3 + 0xf8);
      pfVar2 = (float *)FUN_00c84f30(auStack_3c);
      fVar10 = (fVar11 * fStack_c - fStack_14 * fStack_10) * uStack_1c._4_4_ * *pfVar2;
      iVar3 = FUN_00c84f30(auStack_3c);
      fStack_8 = ((float)((uint)(fStack_8 * fStack_c) ^ DAT_018c4ea0) - uStack_24._4_4_ * fStack_10)
                 * uStack_2c._4_4_ * *(float *)(iVar3 + 8);
      FUN_00fa07b0();
      fVar11 = *(float *)(param_3 + 0xc4);
      *param_2 = fVar10 * *(float *)(param_3 + 0xb4) + *(float *)(param_3 + 0xb8) * 0.0 +
                 *(float *)(param_3 + 0xbc) * fStack_8;
      fVar12 = *(float *)(param_3 + 0xd0);
      param_2[1] = *(float *)(param_3 + 0xc0) * fVar10 + fVar11 * 0.0 +
                   *(float *)(param_3 + 200) * fStack_8;
      param_2[2] = *(float *)(param_3 + 0xcc) * fVar10 + fVar12 * 0.0 +
                   *(float *)(param_3 + 0xd4) * fStack_8;
      return;
    }
  }
  *param_2 = 0.0;
  param_2[1] = 0.0;
  param_2[2] = 0.0;
  return;
}



/* FUNCTION 29480 ; VA 0x00c82f60 ; FUN_00c82f60 */

int __thiscall
FUN_00c82f60(int *param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (((iStack_18 != 0) && (iStack_18 = *(int *)(iStack_18 + 0xa8), iStack_18 != 0)) &&
     (iStack_18 + 0x50 != 0)) {
    uVar3 = *(undefined4 *)(iStack_18 + 0x70);
    *param_3 = uVar3;
    iStack_18 = (**(code **)(*param_1 + 0xa8))(param_2,iStack_18 + 0x50,uVar3,param_4,param_5);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iStack_18 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_18 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_18 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 29481 ; VA 0x00c83010 ; FUN_00c83010 */

void FUN_00c83010(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  int iStack_8;
  
  fStack_14 = 0.0;
  fStack_10 = 0.0;
  fStack_c = 0.0;
  fStack_20 = 0.0;
  fStack_1c = 0.0;
  fStack_18 = 0.0;
  FUN_00c82f60(param_1,&iStack_8,&fStack_14,&fStack_20);
  iVar2 = *(int *)(iStack_8 + 0x20);
  iVar1 = *(int *)(iVar2 + 0x2c);
  if (iVar1 != 0) {
    FUN_00f9f070();
    iVar2 = *(int *)(iStack_8 + 0x20);
    *(float *)(iVar1 + 0x164) = *(float *)(iVar1 + 0x164) + fStack_14;
    *(float *)(iVar1 + 0x168) = fStack_10 + *(float *)(iVar1 + 0x168);
    *(float *)(iVar1 + 0x16c) = fStack_c + *(float *)(iVar1 + 0x16c);
  }
  iVar2 = *(int *)(iVar2 + 0x2c);
  if (iVar2 != 0) {
    FUN_00f9f070();
    *(float *)(iVar2 + 0x170) = *(float *)(iVar2 + 0x170) + fStack_20;
    *(float *)(iVar2 + 0x174) = *(float *)(iVar2 + 0x174) + fStack_1c;
    *(float *)(iVar2 + 0x178) = *(float *)(iVar2 + 0x178) + fStack_18;
  }
  return;
}



/* FUNCTION 29482 ; VA 0x00c83110 ; FUN_00c83110 */

void __fastcall FUN_00c83110(int param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = DAT_018c4ea0;
  iVar2 = *(int *)(param_1 + 0x174);
  *(undefined8 *)(iVar2 + 0x30) = *(undefined8 *)(param_1 + 0x15c);
  *(undefined4 *)(iVar2 + 0x38) = *(undefined4 *)(param_1 + 0x164);
  iVar2 = *(int *)(param_1 + 0x174);
  *(undefined8 *)(iVar2 + 0x3c) = *(undefined8 *)(param_1 + 0x150);
  *(undefined4 *)(iVar2 + 0x44) = *(undefined4 *)(param_1 + 0x158);
  uVar1 = *(uint *)(param_1 + 0x158);
  iVar2 = *(int *)(param_1 + 0x174);
  *(ulonglong *)(iVar2 + 0x48) =
       CONCAT44(*(uint *)(param_1 + 0x154) ^ uVar3,*(uint *)(param_1 + 0x150) ^ uVar3);
  *(uint *)(iVar2 + 0x50) = uVar1 ^ uVar3;
  *(undefined *)(*(int *)(param_1 + 0x174) + 0x54) = 1;
  return;
}



/* FUNCTION 29483 ; VA 0x00c831b0 ; FUN_00c831b0 */

void __thiscall FUN_00c831b0(int param_1)

{
  undefined8 *in_stack_00000010;
  
  *in_stack_00000010 = *(undefined8 *)(param_1 + 0x14c);
  *(undefined4 *)(in_stack_00000010 + 1) = *(undefined4 *)(param_1 + 0x154);
  return;
}



/* FUNCTION 29484 ; VA 0x00c831d0 ; FUN_00c831d0 */

void __thiscall
FUN_00c831d0(int param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5,
            float *param_6)

{
  int iVar1;
  float *pfVar2;
  uint uVar3;
  undefined8 *puVar4;
  float *pfVar5;
  float10 fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  undefined auStack_38 [16];
  ulonglong uStack_28;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  pfVar2 = param_6;
  puVar4 = (undefined8 *)FUN_00c829d0(auStack_38,param_3,param_4);
  *(undefined8 *)param_6 = *puVar4;
  param_6[2] = *(float *)(puVar4 + 1);
  pfVar5 = (float *)FUN_00c84080(auStack_38,param_3,param_4);
  *param_6 = *param_6 + *pfVar5;
  param_6[1] = pfVar5[1] + param_6[1];
  param_6[2] = pfVar5[2] + param_6[2];
  if ((*(int *)(param_1 + 0x140) != 0) && (*(int *)(param_1 + 0x1cc) != 0)) {
    FUN_00fa07b0();
    fVar7 = param_6[1];
    fVar8 = *param_6;
    fVar9 = param_6[2];
    fVar10 = *(float *)(param_3 + 0xb8) * fVar8 + fVar7 * *(float *)(param_3 + 0xc4) +
             fVar9 * *(float *)(param_3 + 0xd0);
    fStack_8 = fVar8 * *(float *)(param_3 + 0xbc) + fVar7 * *(float *)(param_3 + 200) +
               fVar9 * *(float *)(param_3 + 0xd4);
    uStack_28 = (ulonglong)
                (uint)(fVar7 * *(float *)(param_3 + 0xc0) + fVar8 * *(float *)(param_3 + 0xb4) +
                      fVar9 * *(float *)(param_3 + 0xcc));
    FUN_00fa07b0();
    FUN_00fa07b0();
    fVar7 = *(float *)(param_3 + 0xf4);
    fVar8 = *(float *)(param_3 + 0xf0);
    fVar9 = *(float *)(param_3 + 0xf8);
    fStack_1c = *(float *)(param_3 + 0xb8) * fVar8 + *(float *)(param_3 + 0xc4) * fVar7 +
                fVar9 * *(float *)(param_3 + 0xd0);
    fStack_20 = fVar7 * *(float *)(param_3 + 200) + fVar8 * *(float *)(param_3 + 0xbc) +
                fVar9 * *(float *)(param_3 + 0xd4);
    fStack_18 = fVar8 * *(float *)(param_3 + 0xb4) + *(float *)(param_3 + 0xc0) * fVar7 +
                fVar9 * *(float *)(param_3 + 0xcc);
    if (DAT_01d67c90 == '\0') {
      pfVar5 = (float *)FUN_00c84f30(auStack_38);
      fVar7 = *pfVar5;
      fStack_10 = pfVar5[1];
      fStack_14 = pfVar5[2];
      fVar6 = (float10)FUN_00bb5be0();
      fVar8 = (float)fVar6;
      uStack_28 = CONCAT44((int)(uStack_28 >> 0x20),((float)uStack_28 / fVar7) * fVar8);
      param_6 = (float *)((fVar10 / fStack_10) * fVar8);
      fStack_8 = fStack_8 / fStack_14;
      fStack_c = fVar8;
    }
    else {
      pfVar5 = (float *)FUN_00c84f30(auStack_38);
      fVar8 = *(float *)(*(int *)(param_1 + 0x140) + 0x610);
      uStack_28 = CONCAT44((int)(uStack_28 >> 0x20),((float)uStack_28 / *pfVar5) * fVar8);
      param_6 = (float *)((fVar10 / pfVar5[1]) * fVar8);
      fStack_8 = fStack_8 / pfVar5[2];
    }
    fStack_8 = fStack_8 * fVar8;
    pfVar5 = (float *)FUN_00c84f30(auStack_38);
    iVar1 = *(int *)(param_1 + 0x1cc);
    fVar9 = *pfVar5 * *(float *)(param_1 + 0x154);
    fVar8 = *(float *)(param_1 + 0x158) * pfVar5[1];
    fVar7 = *(float *)(param_1 + 0x15c) * pfVar5[2];
    *(ulonglong *)(iVar1 + 0x30) = CONCAT44((float)param_6 + fStack_1c,(float)uStack_28 + fStack_18)
    ;
    *(float *)(iVar1 + 0x38) = fStack_8 + fStack_20;
    iVar1 = *(int *)(param_1 + 0x1cc);
    *(ulonglong *)(iVar1 + 0x3c) = CONCAT44(fVar8,fVar9);
    uVar3 = DAT_018c4ea0;
    *(float *)(iVar1 + 0x44) = fVar7;
    iVar1 = *(int *)(param_1 + 0x1cc);
    *(ulonglong *)(iVar1 + 0x48) = CONCAT44((uint)fVar8 ^ uVar3,(uint)fVar9 ^ uVar3);
    *(uint *)(iVar1 + 0x50) = (uint)fVar7 ^ uVar3;
    pfVar2[0] = 0.0;
    pfVar2[1] = 0.0;
    pfVar2[2] = 0.0;
  }
  return;
}



/* FUNCTION 29485 ; VA 0x00c83530 ; FUN_00c83530 */

void __fastcall FUN_00c83530(int param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fStack_c;
  float fStack_8;
  
  if (*(int *)(param_1 + 0x140) != 0) {
    fStack_8 = *(float *)(param_1 + 0x15c);
    fStack_c = *(float *)(param_1 + 0x160);
    if (DAT_01d67c90 == '\0') {
      uVar8 = 0;
    }
    else {
      uVar8 = *(undefined4 *)(*(int *)(param_1 + 0x140) + 0x610);
    }
    FUN_00c848f0(&fStack_8,&fStack_c,uVar8);
    iVar4 = *(int *)(param_1 + 0x158);
    *(undefined8 *)(iVar4 + 0x48) = *(undefined8 *)(param_1 + 0x164);
    *(undefined4 *)(iVar4 + 0x50) = *(undefined4 *)(param_1 + 0x16c);
    iVar4 = *(int *)(param_1 + 0x158);
    *(float *)(iVar4 + 0x54) = fStack_8;
    *(float *)(iVar4 + 0x58) = fStack_c;
    iVar4 = *(int *)(param_1 + 0x158);
    iVar5 = *(int *)(iVar4 + 8);
    FUN_00fa07b0();
    fVar1 = *(float *)(iVar5 + 200);
    iVar6 = *(int *)(*(int *)(*(int *)(*(int *)(param_1 + 0x158) + 8) + 0x20) + 0x2c);
    fVar11 = *(float *)(iVar6 + 0x3c) - *(float *)(iVar5 + 0xd8);
    fVar9 = *(float *)(iVar6 + 0x40) - *(float *)(iVar5 + 0xdc);
    fVar10 = *(float *)(iVar6 + 0x44) - *(float *)(iVar5 + 0xe0);
    fVar2 = *(float *)(iVar5 + 0xbc);
    fVar3 = *(float *)(iVar5 + 0xd4);
    *(ulonglong *)(iVar4 + 0x30) =
         CONCAT44(*(float *)(iVar5 + 0xc4) * fVar9 + *(float *)(iVar5 + 0xb8) * fVar11 +
                  *(float *)(iVar5 + 0xd0) * fVar10,
                  *(float *)(iVar5 + 0xc0) * fVar9 + *(float *)(iVar5 + 0xb4) * fVar11 +
                  *(float *)(iVar5 + 0xcc) * fVar10);
    *(float *)(iVar4 + 0x38) = fVar1 * fVar9 + fVar2 * fVar11 + fVar3 * fVar10;
    iVar4 = *(int *)(param_1 + 0x158);
    iVar5 = *(int *)(iVar4 + 0xc);
    FUN_00fa07b0();
    fVar1 = *(float *)(param_1 + 0x170);
    iVar6 = *(int *)(*(int *)(param_1 + 0x158) + 8);
    iVar7 = *(int *)(*(int *)(iVar6 + 0x20) + 0x2c);
    fVar2 = *(float *)(iVar7 + 0x3c);
    fVar3 = *(float *)(param_1 + 0x174);
    fStack_8 = *(float *)(iVar7 + 0x40);
    fVar9 = *(float *)(param_1 + 0x178);
    fStack_c = *(float *)(iVar7 + 0x44);
    FUN_00fa07b0();
    fVar10 = ((fStack_8 + fVar3) - *(float *)(iVar6 + 0xdc)) - *(float *)(iVar5 + 0xdc);
    fVar11 = ((fVar2 + fVar1) - *(float *)(iVar6 + 0xd8)) - *(float *)(iVar5 + 0xd8);
    fVar1 = *(float *)(iVar5 + 0xbc);
    fVar9 = ((fVar9 + fStack_c) - *(float *)(iVar6 + 0xe0)) - *(float *)(iVar5 + 0xe0);
    fVar2 = *(float *)(iVar5 + 200);
    fVar3 = *(float *)(iVar5 + 0xd4);
    *(ulonglong *)(iVar4 + 0x3c) =
         CONCAT44(*(float *)(iVar5 + 0xb8) * fVar11 + *(float *)(iVar5 + 0xc4) * fVar10 +
                  *(float *)(iVar5 + 0xd0) * fVar9,
                  *(float *)(iVar5 + 0xc0) * fVar10 + *(float *)(iVar5 + 0xb4) * fVar11 +
                  *(float *)(iVar5 + 0xcc) * fVar9);
    *(float *)(iVar4 + 0x44) = fVar1 * fVar11 + fVar2 * fVar10 + fVar3 * fVar9;
  }
  return;
}



/* FUNCTION 29486 ; VA 0x00c83810 ; FUN_00c83810 */

void __thiscall
FUN_00c83810(int param_1,undefined4 param_2,int param_3,undefined4 param_4,float *param_5,
            undefined8 *param_6)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float *pfVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined auStack_44 [8];
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  FUN_00fa07b0();
  fVar1 = *(float *)(param_1 + 0x150);
  fVar2 = *(float *)(param_1 + 0x14c);
  fVar5 = *(float *)(param_1 + 0x154);
  fVar6 = *(float *)(param_3 + 0xd0);
  fVar7 = *(float *)(param_3 + 0xcc);
  fVar3 = *(float *)(param_3 + 0xd4);
  *(ulonglong *)param_5 =
       CONCAT44(fVar2 * *(float *)(param_3 + 0xc0) + fVar1 * *(float *)(param_3 + 0xc4) +
                fVar5 * *(float *)(param_3 + 200),
                fVar2 * *(float *)(param_3 + 0xb4) + fVar1 * *(float *)(param_3 + 0xb8) +
                *(float *)(param_3 + 0xbc) * fVar5);
  fStack_3c = fVar1 * fVar6 + fVar7 * fVar2 + fVar3 * fVar5;
  param_5[2] = fStack_3c;
  FUN_00fa07b0();
  fVar1 = *(float *)(param_3 + 0xb8);
  fVar2 = *(float *)(param_1 + 0x15c);
  fStack_c = *(float *)(param_3 + 0xb4);
  fStack_8 = *(float *)(param_1 + 0x158);
  fStack_14 = *(float *)(param_3 + 0xbc);
  fStack_10 = *(float *)(param_1 + 0x160);
  fStack_18 = *(float *)(param_3 + 0xd8);
  fStack_20 = *(float *)(param_3 + 0xc4);
  fStack_1c = *(float *)(param_3 + 0xc0);
  fStack_24 = *(float *)(param_3 + 200);
  fStack_28 = *(float *)(param_3 + 0xdc);
  fStack_30 = *(float *)(param_3 + 0xd0);
  fStack_2c = *(float *)(param_3 + 0xcc);
  fStack_34 = *(float *)(param_3 + 0xd4);
  fStack_38 = *(float *)(param_3 + 0xe0);
  pfVar4 = (float *)FUN_00f9fa40(auStack_44);
  fVar6 = (fVar2 * fVar1 + fStack_8 * fStack_c + fStack_10 * fStack_14 + fStack_18) - *pfVar4;
  fVar5 = (fStack_8 * fStack_1c + fVar2 * fStack_20 + fStack_10 * fStack_24 + fStack_28) - pfVar4[1]
  ;
  fVar7 = (fStack_8 * fStack_2c + fVar2 * fStack_30 + fStack_10 * fStack_34 + fStack_38) - pfVar4[2]
  ;
  fVar1 = *param_5;
  fVar2 = param_5[1];
  *param_6 = CONCAT44(fVar7 * *param_5 - fVar6 * param_5[2],fVar5 * param_5[2] - fVar7 * param_5[1])
  ;
  *(float *)(param_6 + 1) = fVar6 * fVar2 - fVar5 * fVar1;
  return;
}



/* FUNCTION 29487 ; VA 0x00c83a80 ; FUN_00c83a80 */

void __fastcall FUN_00c83a80(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x174);
  *(undefined8 *)(iVar1 + 0x3c) = *(undefined8 *)(param_1 + 0x15c);
  *(undefined4 *)(iVar1 + 0x44) = *(undefined4 *)(param_1 + 0x164);
  iVar1 = *(int *)(param_1 + 0x174);
  *(undefined8 *)(iVar1 + 0x30) = *(undefined8 *)(param_1 + 0x150);
  *(undefined4 *)(iVar1 + 0x38) = *(undefined4 *)(param_1 + 0x158);
  return;
}



/* FUNCTION 29488 ; VA 0x00c83ac0 ; FUN_00c83ac0 */

void __thiscall
FUN_00c83ac0(int param_1,undefined4 param_2,int param_3,int param_4,float *param_5,
            undefined8 *param_6)

{
  undefined8 uVar1;
  int iVar2;
  float *pfVar3;
  undefined8 *puVar4;
  float fVar5;
  float fVar6;
  double dVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined8 uStack_20;
  float fStack_18;
  undefined8 uStack_14;
  float fStack_c;
  
  if (*(char *)(param_1 + 0x158) != '\0') {
    if (*(int *)(param_1 + 0x15c) == 0) {
      uStack_14 = *(undefined8 *)(param_1 + 0x164);
      fStack_c = *(float *)(param_1 + 0x16c);
    }
    else {
      pfVar3 = (float *)FUN_00b077e0();
      fVar6 = *(float *)(param_1 + 0x168);
      fVar5 = *(float *)(param_1 + 0x164);
      fVar8 = *(float *)(param_1 + 0x16c);
      uStack_14 = CONCAT44(pfVar3[3] * fVar5 + pfVar3[4] * fVar6 + pfVar3[5] * fVar8 + pfVar3[10],
                           pfVar3[1] * fVar6 + *pfVar3 * fVar5 + pfVar3[2] * fVar8 + pfVar3[9]);
      fStack_c = pfVar3[6] * fVar5 + pfVar3[7] * fVar6 + pfVar3[8] * fVar8 + pfVar3[0xb];
    }
    uStack_20 = uStack_14;
    fStack_18 = fStack_c;
    FUN_00fa07b0();
    fVar5 = uStack_20._4_4_ - *(float *)(param_3 + 0xdc);
    fVar8 = (float)uStack_20 - *(float *)(param_3 + 0xd8);
    fVar10 = fStack_18 - *(float *)(param_3 + 0xe0);
    dVar7 = (double)(fVar5 * fVar5 + fVar8 * fVar8 + fVar10 * fVar10);
    FUN_017267a0();
    fVar6 = DAT_018ce2f8;
    fVar12 = 0.0;
    fVar11 = DAT_018ce2f8 / (float)dVar7;
    iVar2 = *(int *)(*(int *)(param_4 + 0x20) + 0x2c);
    fVar8 = fVar11 * fVar8;
    fVar5 = fVar11 * fVar5;
    fVar11 = fVar11 * fVar10;
    if (iVar2 == 0) {
      uStack_14 = 0;
      fStack_c = 0.0;
    }
    else {
      uStack_14 = *(undefined8 *)(iVar2 + 0x164);
      fStack_c = *(float *)(iVar2 + 0x16c);
    }
    uStack_20 = uStack_14;
    uVar1 = uStack_20;
    uStack_20._0_4_ = (float)uStack_14;
    uStack_20._4_4_ = (float)((ulonglong)uStack_14 >> 0x20);
    *(ulonglong *)param_5 =
         CONCAT44((uint)uStack_20._4_4_ ^ DAT_018c4ea0,(uint)(float)uStack_20 ^ DAT_018c4ea0);
    fStack_18 = fStack_c;
    fStack_c = (float)((uint)fStack_c ^ DAT_018c4ea0);
    param_5[2] = fStack_c;
    fVar10 = *param_5;
    fVar9 = fVar8 * fVar10 + fVar5 * param_5[1] + fVar11 * param_5[2];
    fVar10 = (*(float *)(param_1 + 0x178) * *(float *)(param_1 + 0x178) -
             (fVar10 * fVar10 + param_5[1] * param_5[1] + param_5[2] * param_5[2])) + fVar9 * fVar9;
    uStack_20 = uVar1;
    if (0.0 < fVar10) {
      dVar7 = (double)fVar10;
      FUN_017267a0();
      fVar12 = (float)dVar7 - fVar9;
      fVar6 = DAT_018ce2f8;
    }
    *param_5 = fVar8 * fVar12 + *param_5;
    param_5[1] = fVar5 * fVar12 + param_5[1];
    param_5[2] = fVar11 * fVar12 + param_5[2];
    fVar10 = *(float *)(param_1 + 0x184);
    if ((fVar6 <= fVar10) && (fVar6 = fVar10, DAT_01900c50 <= fVar10)) {
      fVar6 = DAT_01900c50;
    }
    fVar10 = *(float *)(param_1 + 0x178);
    FUN_00fa07b0();
    uVar1 = *(undefined8 *)(param_4 + 0xe4);
    fStack_18 = *(float *)(param_4 + 0xec);
    uStack_20._0_4_ = (float)uVar1;
    uStack_20._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
    dVar7 = (double)((float)uStack_20 * (float)uStack_20 + uStack_20._4_4_ * uStack_20._4_4_ +
                    fStack_18 * fStack_18);
    uStack_20 = uVar1;
    FUN_017267a0();
    fVar6 = (float)dVar7 * (fVar10 / (fVar6 * fVar6));
    fVar9 = *param_5 - (float)uStack_20 * fVar6;
    fVar12 = param_5[1] - uStack_20._4_4_ * fVar6;
    *param_5 = fVar9;
    param_5[1] = fVar12;
    fVar13 = param_5[2] - fStack_18 * fVar6;
    param_5[2] = fVar13;
    fStack_c = *(float *)(param_1 + 0x178);
    fVar6 = (float)((uint)fStack_c ^ DAT_018c4ea0);
    fVar10 = fVar6;
    if (fVar6 <= fVar9) {
      fVar10 = fVar9;
    }
    fVar9 = fStack_c;
    if (fVar10 <= fStack_c) {
      fVar9 = fVar10;
    }
    fVar10 = fVar6;
    if (fVar6 <= fVar12) {
      fVar10 = fVar12;
    }
    if (fVar6 <= fVar13) {
      fVar6 = fVar13;
    }
    fVar12 = fStack_c;
    if (fVar10 <= fStack_c) {
      fVar12 = fVar10;
    }
    if (fVar6 <= fStack_c) {
      fStack_c = fVar6;
    }
    *(ulonglong *)param_5 = CONCAT44(fVar12,fVar9);
    param_5[2] = fStack_c;
    fVar6 = *param_5 * *param_5 + param_5[1] * param_5[1] + param_5[2] * param_5[2];
    if (fVar6 <= DAT_018f76ac) {
      uStack_14._0_4_ = 0.0;
      uStack_14._4_4_ = 0.0;
      fStack_c = 0.0;
    }
    else {
      dVar7 = (double)fVar6;
      FUN_017267a0();
      fStack_c = DAT_018ce2f8 / (float)dVar7;
      uStack_14._0_4_ = fStack_c * *param_5;
      uStack_14._4_4_ = fStack_c * param_5[1];
      fStack_c = fStack_c * param_5[2];
    }
    fVar6 = *(float *)(param_1 + 0x19c);
    fVar10 = DAT_018ce2f8 - fVar6;
    uStack_20._0_4_ = (float)uStack_14;
    uStack_20._4_4_ = uStack_14._4_4_;
    fStack_18 = fStack_c;
    fVar12 = fVar8 * fVar6 + (float)uStack_14 * fVar10;
    fVar5 = uStack_14._4_4_ * fVar10 + fVar5 * fVar6;
    fVar8 = fVar11 * fVar6 + fStack_c * fVar10;
    dVar7 = (double)(fVar5 * fVar5 + fVar12 * fVar12 + fVar8 * fVar8);
    FUN_017267a0();
    fVar6 = DAT_018ce2f8 / (float)dVar7;
    fStack_c = fVar6 * fVar8;
    uStack_14 = CONCAT44(fVar6 * fVar5,fVar6 * fVar12);
    puVar4 = (undefined8 *)FUN_00c84410(&uStack_20,param_3,param_4,&uStack_14);
    *param_6 = *puVar4;
    *(undefined4 *)(param_6 + 1) = *(undefined4 *)(puVar4 + 1);
  }
  return;
}



/* FUNCTION 29489 ; VA 0x00c84080 ; FUN_00c84080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c84080(int param_1,float *param_2,int param_3)

{
  uint *puVar1;
  int iVar2;
  float10 fVar3;
  undefined4 uVar4;
  float fVar5;
  double dVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  undefined auStack_30 [12];
  undefined auStack_24 [4];
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  float fStack_8;
  
  dVar6 = (double)*(float *)(param_1 + 0x158);
  if (NAN(dVar6) == (dVar6 == 0.0)) {
    uStack_20 = (double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & DAT_018c0da0._4_4_,
                                 SUB84(dVar6,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    uStack_10 = (double)CONCAT44((uint)((ulonglong)(dVar6 - 0.0) >> 0x20) & DAT_018c0da0._4_4_,
                                 SUB84(dVar6 - 0.0,0) & (uint)DAT_018c0da0);
    fVar3 = (float10)FUN_01160810();
    uStack_18 = (double)fVar3;
    dVar6 = DAT_018f76b0;
    if ((NAN(uStack_20) || NAN(uStack_18)) == (uStack_20 == uStack_18)) {
      dVar6 = uStack_20 * DAT_018f76b0;
    }
    if (dVar6 < uStack_10) {
      FUN_00fa07b0();
      puVar1 = (uint *)FUN_011612d0(auStack_24,2);
      fVar7 = (float)(puVar1[1] ^ DAT_018c4ea0) * *(float *)(param_3 + 0xc0) +
              (float)(*puVar1 ^ DAT_018c4ea0) * *(float *)(param_3 + 0xb4) +
              (float)(puVar1[2] ^ DAT_018c4ea0) * *(float *)(param_3 + 0xcc);
      fStack_8 = *(float *)(param_1 + 0x150);
      if (DAT_01d67c90 == '\0') {
        uVar4 = 0;
      }
      else {
        uVar4 = *(undefined4 *)(*(int *)(param_1 + 0x140) + 0x610);
      }
      uStack_10._4_4_ = *(float *)(param_1 + 0x14c);
      FUN_00c848f0((int)&uStack_10 + 4,&fStack_8,uVar4);
      fVar8 = *(float *)(param_1 + 0x1a8) + *(float *)(param_1 + 0x1ac) +
              *(float *)(param_1 + 0x1b0);
      dVar6 = (double)fVar8;
      fVar9 = (float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & DAT_018c0da0._4_4_,
                                      SUB84(dVar6,0) & (uint)DAT_018c0da0);
      fVar5 = (float)(double)CONCAT44((uint)((ulonglong)(double)fVar7 >> 0x20) & DAT_018c0da0._4_4_,
                                      SUB84((double)fVar7,0) & (uint)DAT_018c0da0);
      if (fVar9 <= fVar5) {
        fVar9 = fVar5;
      }
      dVar6 = (double)(fVar7 - fVar8);
      dVar6 = (double)(float)((uint)((((float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) &
                                                               DAT_018c0da0._4_4_,
                                                               SUB84(dVar6,0) & (uint)DAT_018c0da0)
                                      * *(float *)(param_1 + 0x1a4)) / (fVar9 + DAT_018fe498)) *
                                    _DAT_01d68a48) ^ DAT_018c4ea0);
      uStack_18._4_4_ = fVar5;
      FUN_01727e40();
      fVar5 = fVar7 - *(float *)(param_1 + 0x1a8);
      *(float *)(param_1 + 0x1b0) = fVar5 - *(float *)(param_1 + 0x1ac);
      fVar9 = DAT_018ce2f8;
      *(float *)(param_1 + 0x1ac) = fVar5;
      *(float *)(param_1 + 0x1a8) = fVar7;
      *(float *)(param_1 + 0x1a4) =
           (fVar9 - *(float *)(param_1 + 0x1a4)) * DAT_018e452c + *(float *)(param_1 + 0x1a4);
      *(float *)(param_1 + 0x1b4) = *(float *)(param_1 + 0x1b4) * 0.0 + uStack_18._4_4_;
      uStack_20._4_4_ = (float)dVar6;
      FUN_00fa07b0();
      FUN_00fa07b0();
      uStack_18._4_4_ =
           *(float *)(param_3 + 0xf4) * *(float *)(param_3 + 0xc4) +
           *(float *)(param_3 + 0xb8) * *(float *)(param_3 + 0xf0) +
           *(float *)(param_3 + 0xf8) * *(float *)(param_3 + 0xd0);
      iVar2 = FUN_00c84f30(auStack_30);
      fVar5 = (float)((uint)(*(float *)(iVar2 + 4) * uStack_20._4_4_ *
                            (uStack_18._4_4_ * fStack_8 + fVar7 * uStack_10._4_4_)) ^ DAT_018c4ea0);
      FUN_00fa07b0();
      fVar7 = *(float *)(param_3 + 0xc0);
      *param_2 = *(float *)(param_3 + 0xb8) * fVar5 + *(float *)(param_3 + 0xb4) * 0.0 +
                 *(float *)(param_3 + 0xbc) * 0.0;
      fVar9 = *(float *)(param_3 + 0xcc);
      param_2[1] = *(float *)(param_3 + 0xc4) * fVar5 + fVar7 * 0.0 +
                   *(float *)(param_3 + 200) * 0.0;
      param_2[2] = *(float *)(param_3 + 0xd0) * fVar5 + fVar9 * 0.0 +
                   *(float *)(param_3 + 0xd4) * 0.0;
      return;
    }
  }
  *param_2 = 0.0;
  param_2[1] = 0.0;
  param_2[2] = 0.0;
  return;
}



/* FUNCTION 29490 ; VA 0x00c84410 ; FUN_00c84410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c84410(float *param_1,float param_2,int param_3,float *param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  int iVar5;
  float *pfVar6;
  int iVar7;
  float fVar8;
  float fVar9;
  double dVar10;
  float fVar11;
  undefined8 uStack_28;
  float fStack_20;
  undefined8 uStack_1c;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar5 = (int)param_2;
  FUN_00fa07b0();
  fVar9 = *(float *)((int)param_2 + 0xb8);
  fVar11 = *param_4;
  fVar1 = param_4[1];
  fVar2 = *(float *)((int)param_2 + 0xc4);
  fVar3 = param_4[2];
  fVar4 = *(float *)((int)param_2 + 0xd0);
  iVar7 = *(int *)(*(int *)(param_3 + 0x20) + 0x2c);
  fStack_c = *(float *)((int)param_2 + 0xc0) * param_4[1] +
             *(float *)((int)param_2 + 0xb4) * *param_4 + fVar3 * *(float *)((int)param_2 + 0xcc);
  if (iVar7 == 0) {
    uStack_28 = 0;
    fStack_20 = 0.0;
  }
  else {
    uStack_28 = *(undefined8 *)(iVar7 + 0x170);
    fStack_20 = *(float *)(iVar7 + 0x178);
  }
  fStack_14 = fStack_20;
  uStack_1c = uStack_28;
  fVar8 = *(float *)((int)fStack_8 + 0x188) * _DAT_0197179c;
  pfVar6 = (float *)FUN_00c84f30(&uStack_28);
  param_4 = (float *)(fVar8 * *pfVar6 * (fVar9 * fVar11 + fVar1 * fVar2 + fVar4 * fVar3));
  iVar7 = FUN_00c84f30(&uStack_28);
  fVar9 = (float)((uint)(*(float *)(iVar7 + 4) * fVar8 * fStack_c) ^ DAT_018c4ea0);
  FUN_00fa07b0();
  fStack_c = uStack_1c._4_4_ * *(float *)((int)param_2 + 0xc4) +
             (float)uStack_1c * *(float *)((int)param_2 + 0xb8) +
             *(float *)((int)param_2 + 0xd0) * fStack_14;
  fStack_10 = *(float *)((int)param_2 + 200) * uStack_1c._4_4_ +
              *(float *)((int)param_2 + 0xbc) * (float)uStack_1c +
              *(float *)((int)param_2 + 0xd4) * fStack_14;
  fVar11 = *(float *)((int)param_2 + 0xc0) * uStack_1c._4_4_ +
           (float)uStack_1c * *(float *)((int)param_2 + 0xb4) +
           fStack_14 * *(float *)((int)param_2 + 0xcc);
  pfVar6 = (float *)FUN_00c84f30(&uStack_28);
  dVar10 = (double)((float)param_4 - fVar11);
  if (*(float *)((int)fStack_8 + 400) * *pfVar6 <=
      (float)(double)CONCAT44((uint)((ulonglong)dVar10 >> 0x20) & DAT_018c0da0._4_4_,
                              SUB84(dVar10,0) & (uint)DAT_018c0da0)) {
    param_4 = (float *)((float)param_4 + fVar11);
  }
  iVar7 = FUN_00c84f30(&uStack_28);
  param_2 = fVar9;
  if (*(float *)((int)fStack_8 + 0x194) * *(float *)(iVar7 + 4) <=
      (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar9 - fStack_c) >> 0x20) &
                              DAT_018c0da0._4_4_,
                              SUB84((double)(fVar9 - fStack_c),0) & (uint)DAT_018c0da0)) {
    param_2 = fVar9 + fStack_c;
  }
  fVar9 = *(float *)((int)fStack_8 + 0x18c) * _DAT_0197179c;
  FUN_00fa07b0();
  FUN_00fa07b0();
  fStack_c = *(float *)(iVar5 + 0xf0) * *(float *)(iVar5 + 0xb4) +
             *(float *)(iVar5 + 0xf4) * *(float *)(iVar5 + 0xc0) +
             *(float *)(iVar5 + 0xf8) * *(float *)(iVar5 + 0xcc);
  fStack_8 = *(float *)(iVar5 + 0xf0) * *(float *)(iVar5 + 0xb8) +
             *(float *)(iVar5 + 0xf4) * *(float *)(iVar5 + 0xc4) +
             *(float *)(iVar5 + 0xf8) * *(float *)(iVar5 + 0xd0);
  pfVar6 = (float *)FUN_00c84f30(&uStack_28);
  fVar8 = (float)param_4 - *pfVar6 * fVar9 * fStack_c;
  iVar7 = FUN_00c84f30(&uStack_28);
  param_2 = param_2 - *(float *)(iVar7 + 4) * fVar9 * fStack_8;
  FUN_00fa07b0();
  fVar9 = *(float *)(iVar5 + 0xc4);
  fVar11 = *(float *)(iVar5 + 0xd0);
  fVar1 = *(float *)(iVar5 + 0xc0);
  fVar2 = *(float *)(iVar5 + 200);
  *param_1 = (*(float *)(iVar5 + 0xb8) * param_2 + fVar8 * *(float *)(iVar5 + 0xb4) +
             *(float *)(iVar5 + 0xbc) * fStack_10) - (float)uStack_1c;
  fVar3 = *(float *)(iVar5 + 0xcc);
  fVar4 = *(float *)(iVar5 + 0xd4);
  param_1[1] = (fVar9 * param_2 + fVar1 * fVar8 + fVar2 * fStack_10) - uStack_1c._4_4_;
  param_1[2] = (fVar11 * param_2 + fVar3 * fVar8 + fVar4 * fStack_10) - fStack_14;
  return;
}



/* FUNCTION 29491 ; VA 0x00c84810 ; FUN_00c84810 */

undefined4 * FUN_00c84810(undefined4 *param_1,int param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_0180f3f0;
  uStack_8 = 0;
  if (param_2 == 0) {
    ExceptionList = &pvStack_10;
    *param_1 = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_18 = param_3;
    piStack_14 = param_4;
    uStack_8 = 1;
    FUN_00915b50(param_1,&uStack_18);
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29492 ; VA 0x00c848f0 ; FUN_00c848f0 */

void FUN_00c848f0(float *param_1,float *param_2,float param_3)

{
  float fVar1;
  float10 fVar2;
  double dVar3;
  float fVar4;
  
  fVar1 = *param_2;
  fVar4 = *param_1 * DAT_018e3f8c - fVar1 * fVar1;
  if (fVar4 < DAT_018ce2f0) {
    fVar4 = fVar1 * DAT_018ce2f4;
    if (DAT_01d67c90 != '\0') {
      if (fVar4 <= DAT_01d68a40 / param_3) {
        return;
      }
      fVar4 = DAT_01d68a40 / (fVar4 * param_3);
      *param_2 = fVar1 * fVar4;
      *param_1 = fVar4 * fVar4 * *param_1;
      return;
    }
    fVar2 = (float10)FUN_00bb5be0();
    if (fVar4 <= (float)((float10)DAT_01d68a40 / fVar2)) {
      return;
    }
    fVar2 = (float10)FUN_00bb5be0();
    fVar2 = (float10)DAT_01d68a40 / (fVar2 * (float10)fVar4);
  }
  else {
    dVar3 = (double)fVar4;
    FUN_017267a0();
    fVar4 = (float)dVar3 * DAT_018ce2f4;
    if (DAT_01d67c90 != '\0') {
      if (fVar4 * param_3 <= DAT_01d68a3c) {
        return;
      }
      fVar4 = DAT_01d68a3c / (fVar4 * param_3);
      *param_2 = fVar1 * fVar4;
      *param_1 = fVar4 * fVar4 * *param_1;
      return;
    }
    fVar2 = (float10)FUN_00bb5be0();
    if ((float)(fVar2 * (float10)fVar4) <= DAT_01d68a3c) {
      return;
    }
    fVar2 = (float10)FUN_00bb5be0();
    fVar2 = (float10)DAT_01d68a3c / (fVar2 * (float10)fVar4);
  }
  fVar1 = (float)fVar2;
  *param_2 = *param_2 * fVar1;
  *param_1 = fVar1 * fVar1 * *param_1;
  return;
}



/* FUNCTION 29493 ; VA 0x00c84a70 ; FUN_00c84a70 */

undefined4 * FUN_00c84a70(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c81180(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29494 ; VA 0x00c84ae0 ; FUN_00c84ae0 */

undefined4 * FUN_00c84ae0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c81310(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29495 ; VA 0x00c84b50 ; FUN_00c84b50 */

undefined4 * FUN_00c84b50(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c81440(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29496 ; VA 0x00c84bc0 ; FUN_00c84bc0 */

undefined4 * FUN_00c84bc0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c816b0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29497 ; VA 0x00c84c30 ; FUN_00c84c30 */

undefined4 * FUN_00c84c30(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c81890(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29498 ; VA 0x00c84ca0 ; FUN_00c84ca0 */

undefined4 * FUN_00c84ca0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c819f0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29499 ; VA 0x00c84d10 ; FUN_00c84d10 */

undefined4 * FUN_00c84d10(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c81b80(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}


