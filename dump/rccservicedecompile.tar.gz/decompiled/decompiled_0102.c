/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 25500 ; VA 0x00b9c950 ; FUN_00b9c950 */

void __thiscall FUN_00b9c950(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((undefined4 **)(param_1 + 0x120) != &param_2) {
    puVar1 = &param_2;
    if (0xf < in_stack_00000018) {
      puVar1 = param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0(puVar1,in_stack_00000014);
  }
  *(undefined4 *)(param_1 + 0x11c) = in_stack_0000001c;
  FUN_0054ef60((undefined4 *)(param_1 + 0x120));
  FUN_006ecaa0();
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    puVar1 = param_2;
    if (0xfff < uVar2) {
      puVar1 = (undefined4 *)param_2[-1];
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25501 ; VA 0x00b9ca00 ; FUN_00b9ca00 */

void __thiscall FUN_00b9ca00(int param_1,char param_2)

{
  int iVar1;
  
  if (param_2 != *(char *)(param_1 + 0x16c)) {
    *(char *)(param_1 + 0x16c) = param_2;
    FUN_008a4940(&DAT_021304e8);
    if (DAT_01d67920 != '\0') {
      iVar1 = FUN_00b7a450(param_1);
      if ((*(char *)(iVar1 + 0x70) != '\0') && (param_2 == '\0')) {
        FUN_00ed4d30();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 25502 ; VA 0x00b9ca60 ; FUN_00b9ca60 */

int __thiscall FUN_00b9ca60(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined uVar4;
  undefined uVar5;
  undefined uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined auStack_20 [8];
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar6 = DAT_01ef22f4;
  uVar5 = DAT_01ef22f3;
  uVar4 = DAT_01ef22f2;
  uVar3 = DAT_01ef22f0;
  puStack_c = &LAB_017fb430;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uVar7 = FUN_00b8db90(auStack_20,FUN_00b93580,param_3,param_4,uVar3,uVar6,uVar5,uVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar8 = FUN_00b8eb10(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x40),
                       *(undefined4 *)(param_1 + 0x44),uVar7);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar8 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 25503 ; VA 0x00b9cb60 ; FUN_00b9cb60 */

void __thiscall FUN_00b9cb60(int param_1,int param_2,int param_3,int param_4,int param_5)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  
  fVar1 = *(float *)(param_1 + 0xf8);
  fVar2 = *(float *)(param_1 + 0xfc);
  fVar3 = *(float *)(param_1 + 0x100);
  fVar4 = *(float *)(param_1 + 0x104);
  *(float *)(param_1 + 0xf8) = (float)param_2;
  *(float *)(param_1 + 0xfc) = (float)param_3;
  *(float *)(param_1 + 0x100) = (float)param_4;
  *(float *)(param_1 + 0x104) = (float)param_5;
  if (((((NAN(fVar1) || NAN(*(float *)(param_1 + 0xf8))) == (fVar1 == *(float *)(param_1 + 0xf8)))
       || ((NAN(fVar2) || NAN(*(float *)(param_1 + 0xfc))) == (fVar2 == *(float *)(param_1 + 0xfc)))
       ) || ((NAN(fVar3) || NAN(*(float *)(param_1 + 0x100))) ==
             (fVar3 == *(float *)(param_1 + 0x100)))) ||
     ((NAN(fVar4) || NAN(*(float *)(param_1 + 0x104))) == (fVar4 == *(float *)(param_1 + 0x104)))) {
    FUN_00b91f60((float)param_2,(float)param_3,(float)param_4,(float)param_5);
  }
  return;
}



/* FUNCTION 25504 ; VA 0x00b9cc10 ; FUN_00b9cc10 */

void __thiscall FUN_00b9cc10(int param_1,char param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  bool bVar8;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined auStack_20 [4];
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_2 == '\0') {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 0x178) != 0) {
      ExceptionList = &pvStack_10;
      uStack_18 = FUN_0055c740((byte *)(param_1 + 0x170) + *(byte *)(param_1 + 0x170) + 1,&param_3);
      uStack_14 = *(uint *)(param_1 + 0x174);
      uVar5 = uStack_18 % uStack_14;
      iStack_1c = uVar5 * 4;
      piVar6 = *(int **)(iStack_1c + *(int *)(param_1 + 0x184));
      if ((piVar6 != (int *)0x0) && (piVar7 = (int *)*piVar6, (int *)*piVar6 != (int *)0x0)) {
        while ((uint)piVar7[1] % uStack_14 == uVar5) {
          if (piVar7[1] == uStack_18) {
            piVar3 = piVar7 + 2;
            if (0xf < (uint)piVar7[7]) {
              piVar3 = (int *)*piVar3;
            }
            puVar2 = &param_3;
            if (0xf < in_stack_0000001c) {
              puVar2 = param_3;
            }
            cVar1 = FUN_0055c360(puVar2,in_stack_00000018,piVar3,piVar7[6]);
            if (cVar1 != '\0') {
              FUN_0061adc0(piVar6,*piVar7);
              if (*piVar6 != 0) {
                uVar4 = *(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 0x174);
                if (uVar5 == uVar4) break;
                *(int **)(*(int *)(param_1 + 0x184) + uVar4 * 4) = piVar6;
              }
              puVar2 = (undefined4 *)(*(int *)(param_1 + 0x184) + iStack_1c);
              if ((int *)*puVar2 == piVar6) {
                *puVar2 = 0;
              }
              break;
            }
          }
          piVar3 = (int *)*piVar7;
          piVar6 = piVar7;
          piVar7 = piVar3;
          if (piVar3 == (int *)0x0) break;
        }
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_00676530(auStack_20,&param_3,&param_3);
  }
  bVar8 = *(int *)(param_1 + 0x178) != 0;
  if (bVar8 != (bool)*(char *)(param_1 + 0x16e)) {
    *(bool *)(param_1 + 0x16e) = bVar8;
    FUN_006eccd0();
    FUN_008a4940(&DAT_021305a0);
  }
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    puVar2 = param_3;
    if (0xfff < uVar5) {
      puVar2 = (undefined4 *)param_3[-1];
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar2,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25505 ; VA 0x00b9cdc0 ; FUN_00b9cdc0 */

void __thiscall FUN_00b9cdc0(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x189)) {
    *(char *)(param_1 + 0x189) = param_2;
    FUN_005e6780();
    return;
  }
  return;
}



/* FUNCTION 25506 ; VA 0x00b9cdf0 ; FUN_00b9cdf0 */

void __thiscall FUN_00b9cdf0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00b9e640(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 25507 ; VA 0x00b9cea0 ; FUN_00b9cea0 */

int __thiscall FUN_00b9cea0(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017fb448;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x150) = param_2;
  piVar2 = *(int **)(param_1 + 0x1bc);
  piVar5 = *(int **)(param_1 + 0x1b8);
  do {
    if (piVar5 == piVar2) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    param_2 = piVar5[1];
    iVar3 = 0;
    piVar4 = (int *)0x0;
    if (param_2 != 0) {
      piVar4 = (int *)(param_2 + 4);
      iVar3 = *(int *)(param_2 + 4);
      while (iVar3 != 0) {
        LOCK();
        param_2 = *piVar4;
        if (iVar3 == param_2) {
          *piVar4 = iVar3 + 1;
          param_2 = iVar3;
        }
        UNLOCK();
        if (param_2 == iVar3) {
          iVar3 = *piVar5;
          piVar4 = (int *)piVar5[1];
          goto LAB_00b9cf0b;
        }
        iVar3 = *piVar4;
      }
      iVar3 = 0;
      piVar4 = (int *)0x0;
    }
LAB_00b9cf0b:
    uStack_8 = 0;
    if (iVar3 != 0) {
      param_2 = FUN_00d66da0();
    }
    uStack_8 = 0xffffffff;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 1;
      iVar3 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1;
        param_2 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar5 = piVar5 + 2;
  } while( true );
}



/* FUNCTION 25508 ; VA 0x00b9cf70 ; FUN_00b9cf70 */

void __thiscall FUN_00b9cf70(int param_1,float param_2,float param_3,float param_4,float param_5)

{
  if (((((NAN(*(float *)(param_1 + 0x108)) || NAN(param_2)) ==
         (*(float *)(param_1 + 0x108) == param_2)) ||
       ((NAN(*(float *)(param_1 + 0x10c)) || NAN(param_3)) ==
        (*(float *)(param_1 + 0x10c) == param_3))) ||
      ((NAN(*(float *)(param_1 + 0x110)) || NAN(param_4)) ==
       (*(float *)(param_1 + 0x110) == param_4))) ||
     ((NAN(*(float *)(param_1 + 0x114)) || NAN(param_5)) == (*(float *)(param_1 + 0x114) == param_5)
     )) {
    *(float *)(param_1 + 0x108) = param_2;
    *(float *)(param_1 + 0x10c) = param_3;
    *(float *)(param_1 + 0x110) = param_4;
    *(float *)(param_1 + 0x114) = param_5;
    FUN_006eccd0();
  }
  return;
}



/* FUNCTION 25509 ; VA 0x00b9d000 ; FUN_00b9d000 */

void FUN_00b9d000(undefined4 param_1)

{
  FUN_00b99c80(param_1,1);
  return;
}



/* FUNCTION 25510 ; VA 0x00b9d020 ; FUN_00b9d020 */

void FUN_00b9d020(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_00b56db0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00b9d055;
  }
  param_2 = 0;
LAB_00b9d055:
  FUN_00b99c80(param_1,param_2 != 0);
  return;
}



/* FUNCTION 25511 ; VA 0x00b9d070 ; FUN_00b9d070 */

void FUN_00b9d070(int param_1)

{
  undefined4 uVar1;
  
  if (param_1 != 0) {
    uVar1 = FUN_01255560();
    if ((*(int *)(*(int *)(param_1 + 0xc) + 0x1d0) != 0) || (*(char *)(param_1 + 0x24) != '\0')) {
      FUN_008a5680(uVar1);
    }
  }
  FUN_00b99c80(param_1,0);
  return;
}



/* FUNCTION 25512 ; VA 0x00b9d0b0 ; FUN_00b9d0b0 */

void __thiscall FUN_00b9d0b0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar5 = in_stack_0000001c;
  piVar6 = param_3;
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  piVar7 = (int *)(param_1 + 0x138);
  uStack_8 = 0;
  piVar3 = piVar7;
  if (0xf < *(uint *)(param_1 + 0x14c)) {
    piVar3 = (int *)*piVar7;
  }
  piVar1 = (int *)&param_3;
  if (0xf < in_stack_0000001c) {
    piVar1 = param_3;
  }
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0055c2d0(piVar1,in_stack_00000018,piVar3,*(undefined4 *)(param_1 + 0x148));
  if (iVar2 != 0) {
    if ((int **)piVar7 != &param_3) {
      piVar3 = (int *)&param_3;
      if (0xf < uVar5) {
        piVar3 = piVar6;
      }
      FUN_005542c0(piVar3,in_stack_00000018);
    }
    FUN_0054ef60(piVar7);
    FUN_006ecd90(param_2);
    uVar5 = in_stack_0000001c;
    piVar6 = param_3;
  }
  if (0xf < uVar5) {
    uVar4 = uVar5 + 1;
    piVar7 = piVar6;
    if (0xfff < uVar4) {
      piVar7 = (int *)piVar6[-1];
      uVar4 = uVar5 + 0x24;
      if (0x1f < (uint)((int)piVar6 + (-4 - (int)piVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar7,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25513 ; VA 0x00b9d190 ; FUN_00b9d190 */

void __thiscall FUN_00b9d190(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0xc1) = param_2;
  return;
}



/* FUNCTION 25514 ; VA 0x00b9d1a0 ; FUN_00b9d1a0 */

void __thiscall FUN_00b9d1a0(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0xc2) = param_2;
  return;
}



/* FUNCTION 25515 ; VA 0x00b9d1b0 ; FUN_00b9d1b0 */

void __thiscall FUN_00b9d1b0(int param_1,undefined4 *param_2)

{
  *(undefined4 *)(param_1 + 0xe8) = *param_2;
  *(undefined4 *)(param_1 + 0xec) = param_2[1];
  *(undefined4 *)(param_1 + 0xf0) = param_2[2];
  *(undefined4 *)(param_1 + 0xf4) = param_2[3];
  return;
}



/* FUNCTION 25516 ; VA 0x00b9d1e0 ; FUN_00b9d1e0 */

void __thiscall
FUN_00b9d1e0(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 *param_4,
            undefined **param_5,undefined *param_6,uint param_7,undefined8 param_8,
            undefined4 *param_9)

{
  int *piVar1;
  int *piVar2;
  undefined ***pppuVar3;
  uint *puVar4;
  uint *puVar5;
  char cVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined **ppuVar9;
  undefined4 in_stack_00000034;
  uint in_stack_00000038;
  int in_stack_0000003c;
  uint in_stack_00000050;
  code *pcVar10;
  undefined4 uVar11;
  undefined4 **ppuStack_1f0;
  undefined4 uStack_1ec;
  uint uStack_1e8;
  undefined4 *puStack_1e4;
  undefined4 *puStack_1e0;
  undefined **ppuStack_1dc;
  undefined *puStack_1d8;
  uint uStack_1d4;
  undefined8 uStack_1d0;
  undefined **ppuStack_1c8;
  undefined *puStack_1c4;
  undefined4 *puStack_1c0;
  undefined8 uStack_1bc;
  undefined4 uStack_1b4;
  int *piStack_1b0;
  undefined *puStack_1ac;
  undefined4 auStack_1a8 [2];
  undefined auStack_1a0 [8];
  undefined4 uStack_198;
  undefined4 *puStack_194;
  undefined4 *puStack_190;
  undefined *puStack_18c;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined auStack_178 [40];
  uint uStack_150;
  undefined4 auStack_148 [6];
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined auStack_128 [40];
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined auStack_f8 [40];
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined auStack_c8 [40];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined auStack_98 [40];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined auStack_68 [40];
  undefined *puStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined *puStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb4f1;
  pvStack_10 = ExceptionList;
  puStack_18c = (undefined *)0x0;
  uStack_8 = 2;
  puStack_20 = &uStack_1d4;
  uStack_1d4 = 0;
  ExceptionList = &pvStack_10;
  puVar4 = &uStack_1d4;
  puStack_18 = param_1;
  if (param_2 != 0) {
    uStack_1d4 = param_2;
    if ((param_2 & 1) == 0) {
      ppuStack_1dc = (undefined **)((int)&uStack_1d0 + 4);
      puStack_1d8 = (undefined *)0x0;
      puStack_1e0 = &param_4;
      puStack_1e4 = (undefined4 *)0xb9d254;
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))();
      puVar4 = puStack_20;
    }
    else {
      uStack_1d0 = CONCAT44(param_4,(undefined4)uStack_1d0);
      ppuStack_1c8 = param_5;
      puStack_1c4 = param_6;
      puStack_1c0 = (undefined4 *)param_7;
      uStack_1bc = param_8;
      ExceptionList = &pvStack_10;
      puVar4 = &uStack_1d4;
    }
  }
  puStack_20 = puVar4;
  ppuStack_1dc = (undefined **)0xb9d25d;
  puStack_1d8 = (undefined *)&uStack_1b4;
  FUN_00b8da80();
  uStack_1bc = CONCAT44(0xb9d26b,(undefined4)uStack_1bc);
  FUN_00b8b320();
  puStack_40 = (undefined *)auStack_1a8;
  puStack_24 = auStack_1a8;
  *(undefined *)(param_1 + 0x7a) = 1;
  puStack_20 = param_1 + 0x2c;
  puStack_1ac = (undefined *)(uint)DAT_01ef22f0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_1bc = CONCAT44(param_1,&uStack_1b4);
  puStack_1c0 = (undefined4 *)0xb9d29e;
  FUN_0060dcd0();
  puStack_1c0 = &uStack_3c;
  uStack_1bc = 0xb99440;
  puStack_1c4 = (undefined *)0xb9d2b1;
  FUN_00b8ddc0();
  piVar2 = piStack_30;
  uStack_28 = uStack_3c;
  puStack_1c = (undefined *)uStack_38;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piStack_30[1] = piStack_30[1] + 1;
    UNLOCK();
  }
  piVar1 = piStack_30 + 1;
  auStack_1a8[0] = 0;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puStack_1ac = auStack_1a0;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  ppuVar9 = &PTR_FUN_0195a334;
  uStack_1b4 = uStack_34;
  piStack_1b0 = piStack_30;
  puStack_1c0 = (undefined4 *)0xb9d31c;
  cVar6 = FUN_00605370();
  if (cVar6 == '\0') {
    ppuVar9 = (undefined **)0x0;
  }
  *puStack_24 = ppuVar9;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar8 = piVar2[1] + -1;
    piVar2[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      puStack_1ac = (undefined *)0xb9d340;
      (**(code **)*piVar2)();
      LOCK();
      iVar8 = piVar2[2] + -1;
      piVar2[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        puStack_1ac = (undefined *)0xb9d350;
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar8 = piVar2[1] + -1;
      piVar2[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        puStack_1ac = (undefined *)0xb9d363;
        (**(code **)*piVar2)();
        LOCK();
        iVar8 = piVar2[2] + -1;
        piVar2[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          puStack_1ac = (undefined *)0xb9d373;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_30[1] + -1;
    piStack_30[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      puStack_1ac = (undefined *)0xb9d389;
      (**(code **)*piStack_30)();
      LOCK();
      piVar2 = piStack_30 + 2;
      iVar8 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        puStack_1ac = (undefined *)0xb9d398;
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  puStack_2c = (undefined *)&ppuStack_1c8;
  uStack_8._0_1_ = 4;
  puStack_24 = &uStack_1e8;
  puStack_1c = (undefined *)&uStack_1e8;
  uStack_1e8 = 0;
  pppuVar3 = &ppuStack_1c8;
  puVar4 = &uStack_1e8;
  puVar5 = &uStack_1e8;
  if (param_2 != 0) {
    uStack_1e8 = param_2;
    if ((param_2 & 1) == 0) {
      ppuStack_1f0 = &puStack_1e0;
      uStack_1ec = 0;
      (**(code **)(param_2 & 0xfffffffe))(&param_4);
      pppuVar3 = (undefined ***)puStack_2c;
      puVar4 = puStack_24;
      puVar5 = (uint *)puStack_1c;
    }
    else {
      puStack_1e0 = param_4;
      ppuStack_1dc = param_5;
      puStack_1d8 = param_6;
      uStack_1d4 = param_7;
      uStack_1d0 = param_8;
      pppuVar3 = &ppuStack_1c8;
      puVar4 = &uStack_1e8;
      puVar5 = &uStack_1e8;
    }
  }
  puStack_1c = (undefined *)puVar5;
  puStack_24 = puVar4;
  puStack_2c = (undefined *)pppuVar3;
  uStack_8._0_1_ = 5;
  FUN_0060dcd0(&ppuStack_1f0,puStack_18);
  uStack_8._0_1_ = 4;
  uVar11 = 0;
  pcVar10 = FUN_00b99490;
  FUN_00b8e350(&uStack_180,FUN_00b99490,0);
  uStack_130 = uStack_180;
  uStack_12c = uStack_17c;
  uStack_8._0_1_ = 6;
  uStack_1d0 = CONCAT44(auStack_178,0xb9d448);
  FUN_00b902d0();
  uStack_100 = uStack_130;
  uStack_fc = uStack_12c;
  uStack_8._0_1_ = 7;
  ppuStack_1c8 = (undefined **)0x0;
  uStack_1d0 = CONCAT44(auStack_128,0xb9d47c);
  FUN_00b902d0();
  uStack_d0 = uStack_100;
  uStack_cc = uStack_fc;
  uStack_8._0_1_ = 8;
  uStack_1d0 = CONCAT44(auStack_f8,0xb9d4aa);
  FUN_00b902d0();
  uStack_70 = uStack_d0;
  uStack_6c = uStack_cc;
  uStack_8._0_1_ = 9;
  uStack_1d0 = CONCAT44(auStack_c8,0xb9d4cf);
  FUN_00b902d0();
  uStack_8._0_1_ = 10;
  uStack_1d0 = CONCAT44(&uStack_70,0xb9d4dc);
  cVar6 = FUN_00585a40();
  if (cVar6 == '\0') {
    uStack_a0 = uStack_70;
    uStack_9c = uStack_6c;
    uStack_1d0 = CONCAT44(auStack_68,0xb9d504);
    FUN_00b902d0();
    uStack_8._0_1_ = 0xb;
    uStack_1d0 = 0x3000b9d50f;
    puVar7 = (undefined4 *)FUN_01674e20();
    uStack_8._0_1_ = 0xc;
    puStack_18 = puVar7;
    if (puVar7 == (undefined4 *)0x0) {
      puStack_1c0 = (undefined4 *)0x0;
    }
    else {
      *puVar7 = uStack_a0;
      puVar7[1] = uStack_9c;
      uStack_1d0 = CONCAT44(auStack_98,0xb9d53f);
      FUN_00b902d0();
      puStack_1c0 = puVar7;
    }
    uStack_1d0 = CONCAT44(0xb9d551,(undefined4)uStack_1d0);
    FUN_00a7c840();
    uStack_1d0 = CONCAT44(0xb9d559,(undefined4)uStack_1d0);
    FUN_00a7c840();
    cStack_11 = '\x01';
  }
  else {
    uStack_1d0 = CONCAT44(0xb9d567,(undefined4)uStack_1d0);
    FUN_00a7c840();
    cStack_11 = '\0';
  }
  uStack_1d0 = CONCAT44(0xb9d576,(undefined4)uStack_1d0);
  FUN_00a7c840();
  ppuStack_1c8 = &PTR_FUN_0195a32c;
  if (cStack_11 == '\0') {
    ppuStack_1c8 = (undefined **)0x0;
  }
  uStack_1d0 = CONCAT44(0xb9d590,(undefined4)uStack_1d0);
  FUN_00a7c840();
  uStack_1d0 = CONCAT44(0xb9d59b,(undefined4)uStack_1d0);
  FUN_00a7c840();
  uStack_1d0 = CONCAT44(0xb9d5a6,(undefined4)uStack_1d0);
  FUN_00a7c840();
  puStack_18 = &puStack_1e0;
  uStack_8._0_1_ = 0xd;
  puStack_1e4 = &stack0x0000003c;
  uStack_1e8 = 0xb9d5bb;
  FUN_0054ef60();
  uStack_8._0_1_ = 0xe;
  FUN_0054ef60(&param_9);
  uStack_8._0_1_ = 3;
  FUN_00b91b20(pcVar10,uVar11);
  uStack_8._0_1_ = 0xf;
  if (uStack_150 != 0) {
    if (((uStack_150 & 1) == 0) && (*(code **)(uStack_150 & 0xfffffffe) != (code *)0x0)) {
      puStack_194 = auStack_148;
      puStack_18c = (undefined *)0x2;
      uStack_198 = 0xb9d600;
      puStack_190 = puStack_194;
      (**(code **)(uStack_150 & 0xfffffffe))();
    }
    uStack_150 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_194 = &param_4;
    puStack_18c = (undefined *)0x2;
    uStack_198 = 0xb9d62e;
    puStack_190 = puStack_194;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  if (0xf < in_stack_00000038) {
    puStack_18c = (undefined *)(in_stack_00000038 + 1);
    puVar7 = param_9;
    if (0xfff < puStack_18c) {
      puVar7 = (undefined4 *)param_9[-1];
      puStack_18c = (undefined *)(in_stack_00000038 + 0x24);
      if (0x1f < (uint)((int)param_9 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        puStack_18c = (undefined *)0xb9d6c1;
        FUN_017167a3();
      }
    }
    puStack_194 = (undefined4 *)0xb9d665;
    puStack_190 = puVar7;
    FUN_01674ea0();
  }
  in_stack_00000034 = 0;
  in_stack_00000038 = 0xf;
  param_9 = (undefined4 *)((uint)param_9 & 0xffffff00);
  if (0xf < in_stack_00000050) {
    puStack_18c = (undefined *)(in_stack_00000050 + 1);
    iVar8 = in_stack_0000003c;
    if (0xfff < puStack_18c) {
      iVar8 = *(int *)(in_stack_0000003c + -4);
      puStack_18c = (undefined *)(in_stack_00000050 + 0x24);
      if (0x1f < (in_stack_0000003c - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_18c = &UNK_00b9d6c6;
        FUN_017167a3();
      }
    }
    puStack_194 = (undefined4 *)0xb9d6a7;
    puStack_190 = (undefined4 *)iVar8;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25517 ; VA 0x00b9d6d0 ; FUN_00b9d6d0 */

undefined __thiscall FUN_00b9d6d0(undefined4 param_1,byte *param_2)

{
  int *piVar1;
  byte bVar2;
  int iVar3;
  undefined4 uVar4;
  byte *pbVar5;
  uint uVar6;
  byte *pbVar7;
  undefined uVar8;
  byte *pbVar9;
  bool bVar10;
  uint in_stack_00000018;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017facb0;
  pvStack_10 = ExceptionList;
  pbVar9 = (byte *)&param_2;
  if (0xf < in_stack_00000018) {
    pbVar9 = param_2;
  }
  uVar8 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_008f7870(param_1);
  FUN_005c4330(&iStack_18,uVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_18 != 0) {
    pbVar7 = &DAT_0195a0c4;
    pbVar5 = pbVar9;
    do {
      bVar2 = *pbVar5;
      bVar10 = bVar2 < *pbVar7;
      if (bVar2 != *pbVar7) {
LAB_00b9d750:
        uVar6 = -(uint)bVar10 | 1;
        goto LAB_00b9d755;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar5[1];
      bVar10 = bVar2 < pbVar7[1];
      if (bVar2 != pbVar7[1]) goto LAB_00b9d750;
      pbVar5 = pbVar5 + 2;
      pbVar7 = pbVar7 + 2;
    } while (bVar2 != 0);
    uVar6 = 0;
LAB_00b9d755:
    if (uVar6 == 0) {
      FUN_00f69120();
    }
    else {
      pbVar7 = &DAT_0195a0d0;
      pbVar5 = pbVar9;
      do {
        bVar2 = *pbVar5;
        bVar10 = bVar2 < *pbVar7;
        if (bVar2 != *pbVar7) {
LAB_00b9d790:
          uVar6 = -(uint)bVar10 | 1;
          goto LAB_00b9d795;
        }
        if (bVar2 == 0) break;
        bVar2 = pbVar5[1];
        bVar10 = bVar2 < pbVar7[1];
        if (bVar2 != pbVar7[1]) goto LAB_00b9d790;
        pbVar5 = pbVar5 + 2;
        pbVar7 = pbVar7 + 2;
      } while (bVar2 != 0);
      uVar6 = 0;
LAB_00b9d795:
      if (uVar6 == 0) {
        FUN_00f69330();
      }
      else {
        pbVar7 = &DAT_0195a0dc;
        pbVar5 = pbVar9;
        do {
          bVar2 = *pbVar5;
          bVar10 = bVar2 < *pbVar7;
          if (bVar2 != *pbVar7) {
LAB_00b9d7d0:
            uVar6 = -(uint)bVar10 | 1;
            goto LAB_00b9d7d5;
          }
          if (bVar2 == 0) break;
          bVar2 = pbVar5[1];
          bVar10 = bVar2 < pbVar7[1];
          if (bVar2 != pbVar7[1]) goto LAB_00b9d7d0;
          pbVar5 = pbVar5 + 2;
          pbVar7 = pbVar7 + 2;
        } while (bVar2 != 0);
        uVar6 = 0;
LAB_00b9d7d5:
        if (uVar6 == 0) {
          FUN_00f691b0();
        }
        else {
          pbVar7 = &DAT_0195a0e8;
          pbVar5 = pbVar9;
          do {
            bVar2 = *pbVar5;
            bVar10 = bVar2 < *pbVar7;
            if (bVar2 != *pbVar7) {
LAB_00b9d810:
              uVar6 = -(uint)bVar10 | 1;
              goto LAB_00b9d815;
            }
            if (bVar2 == 0) break;
            bVar2 = pbVar5[1];
            bVar10 = bVar2 < pbVar7[1];
            if (bVar2 != pbVar7[1]) goto LAB_00b9d810;
            pbVar5 = pbVar5 + 2;
            pbVar7 = pbVar7 + 2;
          } while (bVar2 != 0);
          uVar6 = 0;
LAB_00b9d815:
          if (uVar6 == 0) {
            FUN_00f690c0();
          }
          else {
            pbVar7 = &DAT_0195a0fc;
            pbVar5 = pbVar9;
            do {
              bVar2 = *pbVar5;
              bVar10 = bVar2 < *pbVar7;
              if (bVar2 != *pbVar7) {
LAB_00b9d850:
                uVar6 = -(uint)bVar10 | 1;
                goto LAB_00b9d855;
              }
              if (bVar2 == 0) break;
              bVar2 = pbVar5[1];
              bVar10 = bVar2 < pbVar7[1];
              if (bVar2 != pbVar7[1]) goto LAB_00b9d850;
              pbVar5 = pbVar5 + 2;
              pbVar7 = pbVar7 + 2;
            } while (bVar2 != 0);
            uVar6 = 0;
LAB_00b9d855:
            if (uVar6 == 0) {
              FUN_00f692a0();
            }
            else {
              pbVar5 = &DAT_0195a108;
              do {
                bVar2 = *pbVar9;
                bVar10 = bVar2 < *pbVar5;
                if (bVar2 != *pbVar5) {
LAB_00b9d890:
                  uVar6 = -(uint)bVar10 | 1;
                  goto LAB_00b9d895;
                }
                if (bVar2 == 0) break;
                bVar2 = pbVar9[1];
                bVar10 = bVar2 < pbVar5[1];
                if (bVar2 != pbVar5[1]) goto LAB_00b9d890;
                pbVar9 = pbVar9 + 2;
                pbVar5 = pbVar5 + 2;
              } while (bVar2 != 0);
              uVar6 = 0;
LAB_00b9d895:
              if (uVar6 != 0) goto LAB_00b9d8a6;
              FUN_00f693c0();
            }
          }
        }
      }
    }
    uVar8 = 1;
  }
LAB_00b9d8a6:
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    pbVar9 = param_2;
    if (0xfff < uVar6) {
      pbVar9 = *(byte **)(param_2 + -4);
      uVar6 = in_stack_00000018 + 0x24;
      if ((byte *)0x1f < param_2 + (-4 - (int)pbVar9)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pbVar9,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 25518 ; VA 0x00b9d920 ; FUN_00b9d920 */

undefined4 __fastcall FUN_00b9d920(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  
  iVar3 = FUN_00b91890(&stack0x00000004);
  if (*(int *)(iVar3 + 4) != 0) {
    puVar4 = (undefined4 *)FUN_00b91890(&stack0x00000004);
    uVar1 = *(undefined4 *)(*(int *)*puVar4 + 8);
    puVar4 = (undefined4 *)FUN_00b91890(&stack0x00000004);
    piVar2 = *(int **)*puVar4;
    *(int *)piVar2[1] = *piVar2;
    *(int *)(*piVar2 + 4) = piVar2[1];
    puVar4[1] = puVar4[1] + -1;
    FUN_01674ea0(piVar2,0xc);
    *(undefined4 *)(param_1 + 0x1c4) = uVar1;
    return 1;
  }
  return 0;
}



/* FUNCTION 25519 ; VA 0x00b9d9a0 ; FUN_00b9d9a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b9d9a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb516;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef25fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef25fc);
    if (DAT_01ef25fc == -1) {
      uStack_8 = 0;
      FUN_009ca470("CenterDialogType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef2598 = RBX::Reflection::EnumDesc<enum_RBX::GuiService::CenterDialogType>::vftable;
      FUN_009caf20(&DAT_01d67960,4);
      FUN_016f3654(&LAB_01891200);
      FUN_016f37bf(&DAT_01ef25fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef2598;
}



/* FUNCTION 25520 ; VA 0x00b9da50 ; FUN_00b9da50 */

undefined * FUN_00b9da50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fae5c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef26f4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef26f4);
    if (DAT_01ef26f4 == -1) {
      uStack_8 = 0;
      FUN_00e06fb0();
      FUN_016f3654(&LAB_01891220);
      FUN_016f37bf(&DAT_01ef26f4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef2690;
}



/* FUNCTION 25521 ; VA 0x00b9dae0 ; FUN_00b9dae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b9dae0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb536;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2664) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef2664);
    if (DAT_01ef2664 == -1) {
      uStack_8 = 0;
      FUN_009ca470("SpecialKey");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef2600 = RBX::Reflection::EnumDesc<enum_RBX::GuiService::SpecialKey>::vftable;
      FUN_009caf20(&DAT_01d67930,6);
      FUN_016f3654(&LAB_01891240);
      FUN_016f37bf(&DAT_01ef2664);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef2600;
}



/* FUNCTION 25522 ; VA 0x00b9db90 ; FUN_00b9db90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b9db90(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb556;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2594) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef2594);
    if (DAT_01ef2594 == -1) {
      uStack_8 = 0;
      FUN_009ca470("UiMessageType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef2530 = RBX::Reflection::EnumDesc<enum_RBX::GuiService::UiMessageType>::vftable;
      FUN_009caf20(&DAT_01d67980,2);
      FUN_016f3654(&LAB_01891260);
      FUN_016f37bf(&DAT_01ef2594);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef2530;
}



/* FUNCTION 25523 ; VA 0x00b9dc40 ; FUN_00b9dc40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b9dc40(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2714) {
    FUN_016f3809(&DAT_01ef2714);
    if (DAT_01ef2714 == -1) {
      _DAT_01ef2708 = FUN_005c65e0;
      _DAT_01ef270c = FUN_005c65e0;
      _DAT_01ef2710 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef2714);
    }
  }
  return &DAT_01ef2708;
}



/* FUNCTION 25524 ; VA 0x00b9dcb0 ; FUN_00b9dcb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b9dcb0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2724) {
    FUN_016f3809(&DAT_01ef2724);
    if (DAT_01ef2724 == -1) {
      _DAT_01ef2718 = FUN_005c65e0;
      _DAT_01ef271c = FUN_005c65e0;
      _DAT_01ef2720 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef2724);
    }
  }
  return &DAT_01ef2718;
}



/* FUNCTION 25525 ; VA 0x00b9dd20 ; FUN_00b9dd20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b9dd20(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2704) {
    FUN_016f3809(&DAT_01ef2704);
    if (DAT_01ef2704 == -1) {
      _DAT_01ef26f8 = FUN_005c65e0;
      _DAT_01ef26fc = FUN_005c65e0;
      _DAT_01ef2700 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef2704);
    }
  }
  return &DAT_01ef26f8;
}



/* FUNCTION 25526 ; VA 0x00b9dd90 ; FUN_00b9dd90 */

void __thiscall FUN_00b9dd90(int param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined8 uVar9;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb57c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((DAT_01d6e9b0 == '\0') && (ExceptionList = &pvStack_10, param_1 != 0)) {
    iVar1 = *(int *)(param_1 + 0x34);
    iVar4 = param_1;
    ExceptionList = &pvStack_10;
    if ((iVar1 != 0) && (iVar4 = iVar1, ExceptionList = &pvStack_10, *(int *)(iVar1 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_005c8ac0();
    }
    if ((iVar4 != 0) &&
       (iVar1 = *(int *)(iVar4 + 0xc), iVar4 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      FUN_005789c0(&DAT_01ee0be0,&LAB_008e0ef0);
      FUN_008e4120();
      piVar5 = (int *)FUN_008aa140();
      piStack_14 = piVar5;
      if (*piVar5 == 0) {
        uVar6 = FUN_00e8c140();
        piVar7 = (int *)FUN_008a9ba0(auStack_20,uVar6);
        piVar5 = piStack_14;
        iVar1 = *piVar7;
        iVar4 = piVar7[1];
        *piVar7 = 0;
        piVar7[1] = 0;
        *piStack_14 = iVar1;
        piVar7 = (int *)piStack_14[1];
        piStack_14[1] = iVar4;
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar1 = piVar7[1] + -1;
          piVar7[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            iVar1 = piVar7[2] + -1;
            piVar7[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar1 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            iVar1 = piStack_1c[2] + -1;
            piStack_1c[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
      }
      if (*piVar5 != 0) {
        FUN_00e944a0(*(undefined8 *)(param_2 + 8));
      }
    }
  }
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2300) &&
     (FUN_016f3809(), DAT_01ef2300 == -1)) {
    uStack_8 = 0;
    uVar9 = FUN_0152dab0("Render","UpdateUILayouts",0xffffffff);
    if (DAT_01d7ad40 != '\0') {
      FUN_01532a30(uVar9);
    }
    uStack_8 = 0xffffffff;
    DAT_01ef22f8 = (int)uVar9;
    DAT_01ef22fc = (int *)((ulonglong)uVar9 >> 0x20);
    FUN_016f37bf();
  }
  piVar7 = DAT_01ef22fc;
  uVar6 = DAT_01ef22f8;
  piStack_14 = DAT_01ef22fc;
  uVar9 = FUN_01532c80(DAT_01ef22f8,DAT_01ef22fc);
  puVar8 = *(undefined4 **)(param_1 + 0x1b8);
  puVar2 = *(undefined4 **)(param_1 + 0x1bc);
  uStack_8 = 0;
  piVar5 = piStack_14;
  do {
    if (puVar8 == puVar2) {
      uStack_8 = 3;
      FUN_0152dda0(uVar6,piVar5,uVar9);
      if (DAT_01d7ad40 != '\0') {
        FUN_01532d10(uVar6,piVar5,uVar9);
      }
      ExceptionList = pvStack_10;
      return;
    }
    iVar1 = puVar8[1];
    piStack_18 = (int *)0x0;
    piStack_14 = (int *)0x0;
    if (iVar1 != 0) {
      piVar5 = (int *)(iVar1 + 4);
      iVar1 = *(int *)(iVar1 + 4);
      while (iVar1 != 0) {
        LOCK();
        iVar4 = *piVar5;
        if (iVar1 == iVar4) {
          *piVar5 = iVar1 + 1;
          iVar4 = iVar1;
        }
        UNLOCK();
        if (iVar4 == iVar1) {
          piStack_18 = (int *)*puVar8;
          piStack_14 = (int *)puVar8[1];
          break;
        }
        iVar1 = *piVar5;
      }
    }
    piVar5 = piStack_14;
    uVar3 = (uint)uStack_8 >> 8;
    uStack_8 = CONCAT31((int3)uVar3,2);
    if (piStack_18 != (int *)0x0) {
      (**(code **)(*piStack_18 + 0x118))();
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    puVar8 = puVar8 + 2;
    piVar5 = piVar7;
  } while( true );
}



/* FUNCTION 25527 ; VA 0x00b9e080 ; FUN_00b9e080 */

void __thiscall FUN_00b9e080(int param_1,int param_2)

{
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb598;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    auStack_30[0] = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005880d0(param_1);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_30);
    uStack_8 = 1;
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25528 ; VA 0x00b9e110 ; FUN_00b9e110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00b9e110(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("ToggleFullScreen",0x10);
  uStack_8 = 0;
  iVar2 = FUN_005c3ac0(param_1);
  if ((iVar2 != 0) && (piVar3 = (int *)FUN_009955f0(auStack_30), piVar3 != (int *)0x0)) {
    if (*(char *)(piVar3 + 3) < '\x01') {
      cVar1 = (**(code **)(*piVar3 + 4))();
      if (cVar1 != '\0') {
        iVar2 = FUN_008f7870(param_1);
        if (iVar2 == 0) {
          iVar2 = 0;
        }
        else {
          iVar2 = iVar2 + 4;
        }
        if (*(char *)(piVar3 + 3) < '\x01') {
          (**(code **)(*piVar3 + 0x14))(iVar2);
        }
        else {
          puStack_18 = &DAT_01f026c4;
          uStack_14 = 0x4000000;
          DAT_01f02658 = DAT_01f02658 | 0x4000000;
        }
      }
    }
    else {
      _DAT_01f6ab38 = _DAT_01f6ab38 | 0x4000000;
    }
  }
  FUN_006eccd0();
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    uVar4 = auStack_30[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_30[0] - 4);
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25529 ; VA 0x00b9e230 ; FUN_00b9e230 */

void __thiscall FUN_00b9e230(int param_1,int param_2)

{
  *(bool *)(param_1 + param_2 + 0xe4) = *(char *)(param_1 + param_2 + 0xe4) == '\0';
  return;
}



/* FUNCTION 25530 ; VA 0x00b9e250 ; FUN_00b9e250 */

code * __thiscall FUN_00b9e250(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  code **ppcVar3;
  code **ppcVar4;
  code *pcVar5;
  undefined4 *puStack_c8;
  undefined4 uStack_c4;
  code *apcStack_c0 [2];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  uint uStack_a0;
  undefined auStack_9c [28];
  undefined4 uStack_80;
  undefined *puStack_7c;
  code *pcStack_78;
  int iStack_74;
  undefined auStack_70 [4];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined auStack_64 [12];
  undefined4 uStack_58;
  undefined4 *puStack_54;
  undefined4 *puStack_50;
  int iStack_4c;
  code *pcStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb5c8;
  pvStack_10 = ExceptionList;
  pcVar5 = (code *)ExceptionList;
  if (*(char *)(param_1 + 0x1e8) == '\0') {
    puStack_50 = (undefined4 *)0xb9e282;
    ExceptionList = &pvStack_10;
    iStack_4c = param_1;
    puStack_50 = (undefined4 *)FUN_008f7870();
    puStack_54 = &uStack_20;
    uStack_58 = 0xb9e28c;
    FUN_005c4330();
    iStack_4c = 0;
    uStack_8 = 0;
    uStack_68 = param_2;
    pcStack_78 = (code *)auStack_70;
    puStack_7c = (undefined *)0xb9e2ac;
    iStack_74 = param_1;
    FUN_0060dcd0();
    iStack_74 = 0;
    pcStack_78 = FUN_00b9e3d0;
    uStack_80 = 0xb9e2bc;
    puStack_7c = auStack_64;
    FUN_00b8e520();
    uStack_68 = 0xb9e2c7;
    FUN_00b8b930();
    uStack_a0 = (uint)DAT_01ef22f0;
    uStack_8._0_1_ = 1;
    uStack_6c = 0;
    puStack_14 = (undefined *)apcStack_c0;
    puStack_18 = (undefined *)apcStack_c0;
    apcStack_c0[0] = (code *)0x0;
    ppcVar3 = apcStack_c0;
    ppcVar4 = apcStack_c0;
    if (pcStack_40 != (code *)0x0) {
      apcStack_c0[0] = pcStack_40;
      if (((uint)pcStack_40 & 1) == 0) {
        puStack_c8 = &uStack_b8;
        uStack_c4 = 0;
        (**(code **)((uint)pcStack_40 & 0xfffffffe))(&uStack_38);
        ppcVar3 = (code **)puStack_18;
        ppcVar4 = (code **)puStack_14;
      }
      else {
        uStack_b8 = uStack_38;
        uStack_b4 = uStack_34;
        uStack_b0 = uStack_30;
        uStack_ac = uStack_2c;
        uStack_a8 = uStack_28;
        ppcVar3 = apcStack_c0;
        ppcVar4 = apcStack_c0;
      }
    }
    puStack_14 = (undefined *)ppcVar4;
    puStack_18 = (undefined *)ppcVar3;
    uStack_8._0_1_ = 2;
    FUN_0060dcd0(&puStack_c8,param_1);
    uStack_8._0_1_ = 1;
    FUN_00b8e230(auStack_9c,FUN_00b99640,0);
    uStack_a0 = 0xb9e357;
    FUN_00b8ba30();
    uStack_6c = 0xb9e35f;
    FUN_008ef4a0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    pcVar5 = pcStack_40;
    if (((pcStack_40 != (code *)0x0) && (((uint)pcStack_40 & 1) == 0)) &&
       (pcVar5 = *(code **)((uint)pcStack_40 & 0xfffffffe), pcVar5 != (code *)0x0)) {
      puStack_54 = &uStack_38;
      iStack_4c = 2;
      uStack_58 = 0xb9e380;
      puStack_50 = puStack_54;
      pcVar5 = (code *)(*pcVar5)();
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar2 = *piVar1;
      pcVar5 = (code *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iStack_4c = 0xb9e3a3;
        pcVar5 = (code *)(**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iStack_4c = 0xb9e3b2;
          pcVar5 = (code *)(**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar5;
}



/* FUNCTION 25531 ; VA 0x00b9e3d0 ; FUN_00b9e3d0 */

void __thiscall FUN_00b9e3d0(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  bool bVar6;
  undefined uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9d38;
  pvStack_10 = ExceptionList;
  bVar6 = *(char *)(param_2 + 0xe4 + param_1) == '\0';
  if (!bVar6) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_0090c170();
    if (param_2 == 0) {
      cVar1 = *(char *)(iVar2 + 0xc1);
    }
    else {
      cVar1 = *(char *)(iVar2 + 0xc2);
    }
    if ((cVar1 == '\0') && (*(char *)(param_1 + 0xe4) != '\0')) {
      pcVar5 = "Ctrl-Shift-G again to restore.";
      if (param_2 != 0) {
        pcVar5 = "Ctrl-Shift-C again to restore.";
      }
      pcVar3 = "Hiding Core GUI";
      if (param_2 != 0) {
        pcVar3 = "Hiding Custom GUI";
      }
      pcVar4 = pcVar5;
      do {
        cVar1 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(pcVar5,(int)pcVar4 - (int)(pcVar5 + 1));
      uStack_8 = 0;
      uVar7 = 0;
      pcVar5 = pcVar3;
      do {
        cVar1 = *pcVar5;
        pcVar5 = pcVar5 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(pcVar3,(int)pcVar5 - (int)(pcVar3 + 1));
      uStack_8 = 0xffffffff;
      cVar1 = FUN_00b9c390(param_2,uVar7);
      if (cVar1 != '\0') {
        iVar2 = FUN_0090c170();
        if (param_2 == 0) {
          *(undefined *)(iVar2 + 0xc1) = 1;
        }
        else {
          *(undefined *)(iVar2 + 0xc2) = 1;
        }
      }
    }
    bVar6 = *(char *)(param_2 + 0xe4 + param_1) == '\0';
  }
  *(bool *)(param_2 + 0xe4 + param_1) = bVar6;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25532 ; VA 0x00b9e520 ; FUN_00b9e520 */

void FUN_00b9e520(undefined4 param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  int iStack_10;
  int *piStack_c;
  int iStack_8;
  
  if (param_2 != 0) {
    iVar2 = *(int *)(param_2 + 0xc);
    iVar5 = FUN_00b56db0();
    if ((uint)*(ushort *)(iVar5 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
      FUN_00587490(&iStack_10);
      iVar2 = iStack_10;
      piVar3 = piStack_c;
    }
    else {
      FUN_00587490(&iStack_10);
      iVar2 = iStack_10;
      piVar3 = piStack_c;
    }
    if (iVar2 == 0) {
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    else {
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar5 = piVar3[1] + -1;
        piVar3[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar5 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      if (((iVar2 != 0) &&
          (((param_2 == *(int *)(iVar2 + 0x34) ||
            ((*(int *)(iVar2 + 0x34) != 0 && (cVar4 = FUN_00620ec0(param_2), cVar4 != '\0')))) &&
           (cVar4 = FUN_00c77f80(), cVar4 != '\0')))) && (*(char *)(iVar2 + 0x130) != '\0')) {
        if (*(int *)(param_2 + 0x7c) != 0) {
          FUN_00c7b6f0(param_1,*(int *)(param_2 + 0x7c));
          return;
        }
        FUN_00c7b6f0(param_1,*(undefined4 *)(iStack_8 + 0x19c));
        return;
      }
    }
  }
  return;
}



/* FUNCTION 25533 ; VA 0x00b9e640 ; FUN_00b9e640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b9e640(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb600;
  pvStack_10 = ExceptionList;
  if (DAT_01ef2774 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2988) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef2988);
      if (DAT_01ef2988 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Folder",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ef2980 = RBX::Creator<class_RBX::Folder>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef2778,&DAT_01ef2980);
        FUN_016f3654(FUN_018913c0);
        FUN_016f37bf(&DAT_01ef2988);
      }
    }
    DAT_01ef2774 = &DAT_01ef2778;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef2774;
}



/* FUNCTION 25534 ; VA 0x00b9e740 ; FUN_00b9e740 */

undefined4 * __fastcall FUN_00b9e740(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb628;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Folder,class_RBX::Instance>::vftable;
  uVar1 = FUN_00b9e640();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::Folder::vftable;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("Folder",6);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25535 ; VA 0x00b9e800 ; FUN_00b9e800 */

void __fastcall FUN_00b9e800(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Folder>::vftable;
  uVar1 = FUN_00b9e640(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25536 ; VA 0x00b9e840 ; FUN_00b9e840 */

undefined4 __thiscall FUN_00b9e840(undefined4 param_1,byte param_2)

{
  FUN_0089b310();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x88);
  }
  return param_1;
}



/* FUNCTION 25537 ; VA 0x00b9e870 ; FUN_00b9e870 */

undefined __thiscall FUN_00b9e870(int param_1,undefined4 param_2)

{
  undefined uVar1;
  
  if (*(int *)(param_1 + 0x34) != 0) {
    uVar1 = FUN_0089d560(param_2,0);
    return uVar1;
  }
  return 1;
}



/* FUNCTION 25538 ; VA 0x00b9e890 ; FUN_00b9e890 */

undefined4 * FUN_00b9e890(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00634770(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 25539 ; VA 0x00b9e900 ; FUN_00b9e900 */

void FUN_00b9e900(void)

{
  int iVar1;
  
  if (DAT_01ef298c == 0) {
    iVar1 = FUN_00b9e640();
    DAT_01ef298c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 25540 ; VA 0x00b9e920 ; FUN_00b9e920 */

undefined4 FUN_00b9e920(void)

{
  int iVar1;
  
  iVar1 = FUN_008a40f0();
  if (iVar1 != 0) {
    return *(undefined4 *)(iVar1 + 0x80);
  }
  return 0x7fffffff;
}



/* FUNCTION 25541 ; VA 0x00b9e940 ; FUN_00b9e940 */

undefined4 * FUN_00b9e940(void)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb682;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x88);
  uStack_8 = 0;
  if (puVar1 != (undefined4 *)0x0) {
    FUN_0170d1f0(puVar1,0,0x88);
    FUN_0089a8e0();
    *puVar1 = _anon_B520B974::OnDemandFolderInstance::vftable;
    puVar1[0x20] = 0x7fffffff;
    ExceptionList = pvStack_10;
    return puVar1;
  }
  ExceptionList = pvStack_10;
  return (undefined4 *)0x0;
}



/* FUNCTION 25542 ; VA 0x00b9e9c0 ; FUN_00b9e9c0 */

uint FUN_00b9e9c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b9e640();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 25543 ; VA 0x00b9e9e0 ; FUN_00b9e9e0 */

uint FUN_00b9e9e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b9e640();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 25544 ; VA 0x00b9ea00 ; FUN_00b9ea00 */

void __thiscall FUN_00b9ea00(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uStack_8;
  
  uStack_8 = param_1;
  FUN_008a3ee0(param_2);
  if (DAT_01d70358 != '\0') {
    uStack_8 = 0x7fffffff;
    cVar1 = FUN_010096f0(param_1,param_2,&uStack_8);
    if (cVar1 != '\0') {
      FUN_00b9ea50(uStack_8);
    }
  }
  return;
}



/* FUNCTION 25545 ; VA 0x00b9ea50 ; FUN_00b9ea50 */

void FUN_00b9ea50(int param_1)

{
  int iVar1;
  undefined **ppuStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb698;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008a40f0();
  if (iVar1 == 0) {
    iVar1 = 0x7fffffff;
  }
  else {
    iVar1 = *(int *)(iVar1 + 0x80);
  }
  if (param_1 != iVar1) {
    iVar1 = FUN_008a4100();
    *(int *)(iVar1 + 0x80) = param_1;
    ppuStack_18 = RBX::Instance::PropertyChangedSignalData::vftable;
    puStack_14 = &DAT_01ef2738;
    uStack_8 = 0;
    FUN_006150c0(2,&ppuStack_18);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25546 ; VA 0x00b9ead0 ; FUN_00b9ead0 */

undefined * FUN_00b9ead0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb6bc;
  pvStack_10 = ExceptionList;
  if (DAT_01ef2990 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2ba0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef2ba0);
      if (DAT_01ef2ba0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"CorePackages",1,uStack_20,0,0,1,5,0);
        FUN_016f3654(&LAB_01891420);
        FUN_016f37bf(&DAT_01ef2ba0);
      }
    }
    DAT_01ef2990 = &DAT_01ef2998;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef2990;
}



/* FUNCTION 25547 ; VA 0x00b9ebb0 ; FUN_00b9ebb0 */

void FUN_00b9ebb0(void)

{
  int iVar1;
  
  if (DAT_01ef2ba4 == 0) {
    iVar1 = FUN_00b9ead0();
    DAT_01ef2ba4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 25548 ; VA 0x00b9ebd0 ; FUN_00b9ebd0 */

undefined4 * __fastcall FUN_00b9ebd0(undefined4 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb6e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::CorePackages,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00b9ead0();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::CorePackages::vftable;
  FUN_0054eff0("CorePackages");
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(aiStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25549 ; VA 0x00b9ec80 ; FUN_00b9ec80 */

undefined4 * __fastcall FUN_00b9ec80(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  return param_1;
}



/* FUNCTION 25550 ; VA 0x00b9ecc0 ; FUN_00b9ecc0 */

int __fastcall FUN_00b9ecc0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  uStack_8 = 0;
  iVar4 = FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x10);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    iVar4 = iVar4 + -1;
    if (iVar4 == 0) {
      iVar4 = FUN_01674ea0(iVar3);
    }
  }
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = *(int **)(param_1 + 4);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 25551 ; VA 0x00b9ed80 ; FUN_00b9ed80 */

undefined __thiscall
FUN_00b9ed80(undefined4 param_1,int *param_2,int param_3,int param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined uVar5;
  uint uVar6;
  int iVar7;
  int *piStack_4c;
  int **ppiStack_48;
  int *apiStack_38 [5];
  uint uStack_24;
  int *apiStack_20 [2];
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb710;
  pvStack_10 = ExceptionList;
  if (((param_2 == (int *)0x0) || (param_3 == 0)) || (param_5 == 0)) {
    return 0;
  }
  param_2 = (int *)((int)param_2 + 0xc);
  uVar6 = 0;
  if (param_5 != 0) {
    iStack_14 = 0;
    ExceptionList = &pvStack_10;
    uStack_18 = param_1;
    do {
      ppiStack_48 = (int **)(param_4 + iStack_14);
      piStack_4c = (int *)0xb9ede5;
      FUN_0054ef60();
      ppiStack_48 = apiStack_38;
      uStack_8 = 0;
      piStack_4c = (int *)0xb9edf7;
      iVar2 = FUN_008a1240();
      if (iVar2 == 0) {
LAB_00b9ef1e:
        uVar5 = 0;
        goto LAB_00b9ef20;
      }
      iVar7 = *(int *)(iVar2 + 0xc);
      ppiStack_48 = (int **)0xb9ee0a;
      iVar3 = FUN_00b9e640();
      if ((uint)*(ushort *)(iVar3 + 0x1da) <
          (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) goto LAB_00b9ef1e;
      ppiStack_48 = apiStack_38;
      piStack_4c = (int *)0xb9ee34;
      piVar4 = (int *)FUN_008a1240();
      if (uVar6 == param_5 - 1) {
        if (piVar4 == (int *)0x0) {
          FUN_0060dcd0(&piStack_4c,iVar2);
          FUN_00ba0380();
          piStack_4c = param_2;
          ppiStack_48 = (int **)piVar4;
          FUN_008a65e0();
          uVar5 = 1;
        }
        else {
          piVar1 = *(int **)(iVar2 + 0x2c);
          if (piVar1 != (int *)0x0) {
            iVar2 = piVar1[1];
            for (iVar7 = *piVar1; iVar7 != iVar2; iVar7 = iVar7 + 8) {
              FUN_00557fc0(iVar7);
              FUN_00ba0380();
              ppiStack_48 = (int **)0x0;
              piStack_4c = piVar4;
              FUN_008a65e0();
            }
          }
          uVar5 = 1;
        }
LAB_00b9ef20:
        if (0xf < uStack_24) {
          ppiStack_48 = (int **)(uStack_24 + 1);
          piVar4 = apiStack_38[0];
          if (0xfff < ppiStack_48) {
            piVar4 = (int *)apiStack_38[0][-1];
            ppiStack_48 = (int **)(uStack_24 + 0x24);
            if (0x1f < (uint)((int)apiStack_38[0] + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
              ppiStack_48 = (int **)&UNK_00b9ef7f;
              FUN_017167a3();
            }
          }
          piStack_4c = piVar4;
          FUN_01674ea0();
        }
        ExceptionList = pvStack_10;
        return uVar5;
      }
      if (piVar4 == (int *)0x0) {
        ppiStack_48 = apiStack_20;
        piStack_4c = (int *)0xb9ee4b;
        FUN_00634770();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        ppiStack_48 = *(int ***)(iVar2 + 0x28);
        piStack_4c = (int *)0xb9ee60;
        (**(code **)(*apiStack_20[0] + 0x38))();
        piStack_4c = param_2;
        ppiStack_48 = (int **)piVar4;
        FUN_008a65e0();
        param_2 = apiStack_20[0];
        ppiStack_48 = (int **)0xb9ee7a;
        FUN_00550b30();
        piVar4 = param_2;
      }
      param_2 = piVar4;
      uStack_8 = 0xffffffff;
      ppiStack_48 = (int **)0xb9ee91;
      FUN_005507b0();
      uVar6 = uVar6 + 1;
      iStack_14 = iStack_14 + 0x18;
    } while (uVar6 < param_5);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 25552 ; VA 0x00b9ef80 ; FUN_00b9ef80 */

int * FUN_00b9ef80(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  uint auStack_70 [4];
  int *piStack_60;
  uint uStack_5c;
  int *piStack_58;
  int *piStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  undefined4 *puStack_40;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  uint uStack_2c;
  int *piStack_28;
  uint uStack_24;
  int *piStack_20;
  int *piStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb761;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_2c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_2 + 0x40))(&piStack_48);
  uStack_8._0_1_ = 1;
  piVar9 = (int *)*piStack_48;
  piStack_20 = piVar9;
  if (piVar9 != (int *)piStack_48[1]) {
    do {
      piVar6 = (int *)piVar9[1];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = (int *)piVar9[1];
      }
      piStack_38 = (int *)*piVar9;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      piStack_28 = (int *)0x0;
      piStack_34 = piVar6;
      piStack_20 = piVar9;
      piStack_1c = piVar6;
      piStack_14 = piStack_38;
      uStack_24 = FUN_008a1240(piStack_38[10]);
      piVar5 = piVar6;
      uStack_2c = -(uint)(param_1 != 0) & param_1 + 0xcU;
      if (uStack_24 != 0) {
        do {
          piStack_28 = piStack_14;
          piVar9 = (int *)piStack_14[0xb];
          piVar5 = piVar6;
          uStack_2c = uStack_24;
          if ((piVar9 != (int *)0x0) && (7 < (uint)(piVar9[1] - *piVar9))) {
            puVar4 = (undefined4 *)(**(code **)(*piStack_14 + 0x40))(auStack_50);
            piStack_38 = *(int **)*puVar4;
            piVar5 = (int *)piStack_38[1];
            if (piVar5 != (int *)0x0) {
              LOCK();
              piVar5[1] = piVar5[1] + 1;
              UNLOCK();
              piVar5 = (int *)piStack_38[1];
            }
            piStack_38 = (int *)*piStack_38;
            piStack_34 = piVar5;
            piStack_14 = piStack_38;
            if (piVar6 != (int *)0x0) {
              LOCK();
              iVar2 = piVar6[1] + -1;
              piVar6[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piVar6)();
                LOCK();
                iVar2 = piVar6[2] + -1;
                piVar6[2] = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)(*piVar6 + 4))();
                }
              }
            }
            piVar9 = piStack_4c;
            if (piStack_4c != (int *)0x0) {
              LOCK();
              iVar2 = piStack_4c[1] + -1;
              piStack_4c[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piStack_4c)();
                LOCK();
                piVar6 = piVar9 + 2;
                iVar2 = *piVar6 + -1;
                *piVar6 = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)(*piVar9 + 4))();
                }
              }
            }
          }
          uStack_24 = FUN_008a1240(piStack_14[10]);
          piVar6 = piVar5;
        } while (uStack_24 != 0);
        uStack_24 = 0;
        piVar9 = piStack_20;
        piStack_1c = piVar5;
      }
      if (piStack_28 == (int *)0x0) {
        piStack_60 = piStack_28;
        auStack_70[0] = auStack_70[0] & 0xffffff00;
        uStack_5c = 0xf;
        uStack_2c = uStack_18 | 1;
        uStack_8._0_1_ = 3;
        piStack_28 = (int *)piStack_14[10];
        uStack_18 = uStack_2c;
        FUN_0058a190(((int *)piStack_14[10])[4] + 0xe);
        FUN_00554150("Unknown child ",0xe);
        piVar6 = piStack_28;
        if (0xf < (uint)piStack_28[5]) {
          piVar6 = (int *)*piStack_28;
        }
        FUN_00554150(piVar6,piStack_28[4]);
        FUN_00f929f0(auStack_70);
        uStack_18 = uStack_18 & 0xfffffffe;
        uStack_8._0_1_ = 2;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 2;
        if (0xf < uStack_5c) {
          uVar8 = uStack_5c + 1;
          uVar7 = auStack_70[0];
          if (0xfff < uVar8) {
            uVar7 = *(uint *)(auStack_70[0] - 4);
            uVar8 = uStack_5c + 0x24;
            if (0x1f < (auStack_70[0] - uVar7) - 4) {
              uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar7,uVar8);
        }
        uStack_8._0_1_ = 1;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar2 = piVar5[1] + -1;
          piVar5[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar5)();
LAB_00b9f2c2:
            LOCK();
            iVar2 = piVar5[2] + -1;
            piVar5[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
      }
      else {
        piVar6 = (int *)piStack_28[0xb];
        if ((piVar6 != (int *)0x0) && (piVar6[1] - *piVar6 >> 3 != 0)) {
          (**(code **)(*piStack_28 + 0x40))(&puStack_40);
          puVar4 = (undefined4 *)*puStack_40;
          if (puVar4 != (undefined4 *)puStack_40[1]) {
            do {
              piVar9 = (int *)puVar4[1];
              if (piVar9 != (int *)0x0) {
                LOCK();
                piVar9[1] = piVar9[1] + 1;
                UNLOCK();
                piVar9 = (int *)puVar4[1];
              }
              piStack_58 = (int *)*puVar4;
              uStack_8 = CONCAT31(uStack_8._1_3_,5);
              if (piVar9 != (int *)0x0) {
                LOCK();
                piVar9[1] = piVar9[1] + 1;
                UNLOCK();
              }
              piStack_54 = piVar9;
              piStack_28 = piStack_58;
              FUN_00ba0380(piStack_58,piVar9);
              FUN_008a65e0(uStack_2c,0);
              if (piVar9 != (int *)0x0) {
                LOCK();
                iVar2 = piVar9[1] + -1;
                piVar9[1] = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)*piVar9)();
                  LOCK();
                  iVar2 = piVar9[2] + -1;
                  piVar9[2] = iVar2;
                  UNLOCK();
                  if (iVar2 == 0) {
                    (**(code **)(*piVar9 + 4))();
                  }
                }
              }
              puVar4 = puVar4 + 2;
              piVar5 = piStack_1c;
              piVar9 = piStack_20;
            } while (puVar4 != (undefined4 *)puStack_40[1]);
          }
          piVar6 = piStack_3c;
          if (piStack_3c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_3c[1] + -1;
            piStack_3c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_3c)();
              LOCK();
              piVar1 = piVar6 + 2;
              iVar2 = *piVar1 + -1;
              *piVar1 = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
        }
        uStack_8._0_1_ = 1;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar2 = piVar5[1] + -1;
          piVar5[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar5)();
            goto LAB_00b9f2c2;
          }
        }
      }
      piVar9 = piVar9 + 2;
      piStack_20 = piVar9;
    } while (piVar9 != (int *)piStack_48[1]);
  }
  if (piStack_44 != (int *)0x0) {
    LOCK();
    piVar9 = piStack_44 + 1;
    iVar2 = *piVar9;
    piStack_48 = (int *)*piVar9;
    *piVar9 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      piVar9 = piStack_44 + 2;
      iVar2 = *piVar9;
      piStack_48 = (int *)*piVar9;
      *piVar9 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_48 = (int *)(**(code **)(*piStack_44 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar9 = param_3 + 1;
    iVar2 = *piVar9;
    piStack_48 = (int *)*piVar9;
    *piVar9 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_48 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar9 = param_3 + 2;
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_48 = (int *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_48;
}



/* FUNCTION 25553 ; VA 0x00b9f350 ; FUN_00b9f350 */

int FUN_00b9f350(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_8c [16];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined uStack_74;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined uStack_5c;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined uStack_44;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fb7ed;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  uStack_7c = 0;
  uStack_78 = 0xf;
  auStack_8c[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("CoreGui",7);
  iStack_8._0_1_ = 1;
  uStack_64 = 0;
  uStack_60 = 0xf;
  uStack_74 = 0;
  FUN_005542c0("RobloxGui",9);
  iStack_8._0_1_ = 2;
  uStack_4c = 0;
  uStack_48 = 0xf;
  uStack_5c = 0;
  FUN_005542c0("Modules",7);
  iStack_8._0_1_ = 3;
  uStack_34 = 0;
  uStack_30 = 0xf;
  uStack_44 = 0;
  FUN_005542c0("Server",6);
  iStack_8._0_1_ = 4;
  FUN_00b9ed80(param_1,param_2,auStack_8c,4);
  iStack_8._0_1_ = 0;
  FUN_016f32d1(auStack_8c,0x18,4,FUN_005507b0);
  uStack_7c = 0;
  uStack_78 = 0xf;
  auStack_8c[0] = 0;
  FUN_005542c0("CoreGui",7);
  iStack_8._0_1_ = 5;
  uStack_64 = 0;
  uStack_60 = 0xf;
  uStack_74 = 0;
  FUN_005542c0("RobloxGui",9);
  iStack_8._0_1_ = 6;
  uStack_4c = 0;
  uStack_48 = 0xf;
  uStack_5c = 0;
  FUN_005542c0("Modules",7);
  iStack_8._0_1_ = 7;
  uStack_34 = 0;
  uStack_30 = 0xf;
  uStack_44 = 0;
  FUN_005542c0("Common",6);
  iStack_8._0_1_ = 8;
  FUN_00b9ed80(param_1,param_2,auStack_8c,4);
  iStack_8._0_1_ = 0;
  FUN_016f32d1(auStack_8c,0x18,4,FUN_005507b0);
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = 0;
  FUN_005542c0("CorePackages",0xc);
  iStack_8._0_1_ = 9;
  FUN_00b9ed80(param_1,param_2,auStack_2c,1);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar3 = FUN_016f32d1(auStack_2c,0x18,1,FUN_005507b0);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25554 ; VA 0x00b9f5c0 ; FUN_00b9f5c0 */

undefined * FUN_00b9f5c0(int param_1,undefined *param_2)

{
  undefined *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined *puVar5;
  int *piVar6;
  undefined8 uVar7;
  undefined auStack_20 [8];
  undefined *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb810;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)0x0;
  iVar3 = *(int *)(param_1 + 0x1c);
  piStack_14 = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    piVar6 = (int *)(iVar3 + 4);
    iVar3 = *(int *)(iVar3 + 4);
    ExceptionList = &pvStack_10;
    while (iVar3 != 0) {
      LOCK();
      iVar4 = *piVar6;
      if (iVar3 == iVar4) {
        *piVar6 = iVar3 + 1;
        iVar4 = iVar3;
      }
      UNLOCK();
      if (iVar4 == iVar3) {
        puStack_18 = *(undefined **)(param_1 + 0x18);
        piStack_14 = *(int **)(param_1 + 0x1c);
        break;
      }
      iVar3 = *piVar6;
    }
  }
  piVar6 = piStack_14;
  uStack_8 = 0;
  puVar5 = puStack_18;
  if (puStack_18 != (undefined *)0x0) {
    puVar1 = puStack_18 + 0xc;
    puVar5 = (undefined *)FUN_005cf750();
    if (((puVar5 != (undefined *)0x0) && (puVar5 = param_2, param_2 == PTR_DAT_02120610)) &&
       (puVar5 = (undefined *)FUN_0097bfc0(puVar1), puVar5 != (undefined *)0x0)) {
      FUN_01014cc0(auStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uVar7 = FUN_00928340();
      FUN_01014e00(uVar7);
      puVar5 = (undefined *)FUN_00550b30();
    }
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar2 = piVar6 + 1;
    iVar3 = *piVar2;
    puVar5 = (undefined *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      puVar5 = (undefined *)(**(code **)*piVar6)();
      LOCK();
      piVar2 = piVar6 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puVar5 = (undefined *)(**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 25555 ; VA 0x00b9f6d0 ; FUN_00b9f6d0 */

undefined4 * __thiscall FUN_00b9f6d0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_44 [4];
  int iStack_34;
  uint uStack_30;
  undefined auStack_2c [16];
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb841;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iStack_34 = *param_1;
  if (iStack_34 != 0) {
    ExceptionList = &pvStack_10;
    iStack_1c = FUN_008a1240(param_3);
    if (iStack_1c == 0) {
      auStack_2c[0] = 0;
      uStack_8 = 1;
      uStack_18 = 0xf;
      uStack_14 = 2;
      FUN_0058a190(param_3[4] + 0x1a);
      FUN_00554150("Missing core script child ",0x1a);
      puVar1 = param_3 + 4;
      if (0xf < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      FUN_00554150(param_3,*puVar1);
      FUN_00f921d0(auStack_2c);
      FUN_005507b0();
      *param_2 = 0;
      param_2[1] = 0;
      ExceptionList = pvStack_10;
      return param_2;
    }
    FUN_0060dcd0(param_2,iStack_1c);
    ExceptionList = pvStack_10;
    return param_2;
  }
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  uStack_30 = 0xf;
  ExceptionList = &pvStack_10;
  FUN_005542c0("No core scripts when fetching core script child",0x2f);
  uStack_8 = 0;
  FUN_00f92310(auStack_44);
  if (0xf < uStack_30) {
    uVar3 = uStack_30 + 1;
    uVar2 = auStack_44[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_44[0] - 4);
      uVar3 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *param_2 = 0;
  param_2[1] = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25556 ; VA 0x00b9f840 ; FUN_00b9f840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __thiscall FUN_00b9f840(int *param_1,undefined *param_2,uint *param_3,char param_4)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  byte *pbVar4;
  uint uVar5;
  int iVar6;
  uint *puVar7;
  int iVar8;
  undefined4 uVar9;
  byte *pbVar10;
  byte *pbVar11;
  uint uVar12;
  uint *puVar13;
  bool bVar14;
  uint uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int iStack_54;
  uint uStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  uint uStack_1c;
  undefined auStack_18 [4];
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puVar13 = param_3;
  puStack_c = &LAB_017fb8a1;
  pvStack_10 = ExceptionList;
  uStack_34 = 0;
  uStack_1c = 0;
  uStack_3c = 0xf00000000;
  uStack_4c = uStack_4c & 0xffffff00;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  iVar8 = iStack_54;
  piStack_2c = param_1;
  if (param_4 != '\0') {
    puStack_14 = param_3;
    if (0xf < param_3[5]) {
      puStack_14 = (uint *)*param_3;
    }
    ExceptionList = &pvStack_10;
    if (6 < param_3[4]) {
      piStack_24 = (int *)((param_3[4] - 6) + (int)puStack_14);
      ExceptionList = &pvStack_10;
      pbVar4 = (byte *)FUN_0170db20(puStack_14,99,(int)piStack_24 - (int)puStack_14);
      iVar8 = iStack_54;
      while (pbVar4 != (byte *)0x0) {
        param_3 = (uint *)0x3;
        pbVar11 = &DAT_01941514;
        pbVar10 = pbVar4;
        if (*(int *)pbVar4 == _DAT_01941514) {
          pbVar10 = pbVar4 + 4;
          param_3 = (uint *)0xffffffff;
          pbVar11 = &DAT_01941518;
        }
        bVar14 = *pbVar10 < *pbVar11;
        if ((((*pbVar10 == *pbVar11) && (bVar14 = pbVar10[1] < pbVar11[1], pbVar10[1] == pbVar11[1])
             ) && (bVar14 = pbVar10[2] < pbVar11[2], pbVar10[2] == pbVar11[2])) &&
           ((param_3 == (uint *)0xffffffff ||
            (bVar14 = pbVar10[3] < pbVar11[3], pbVar10[3] == pbVar11[3])))) {
          uVar5 = 0;
        }
        else {
          uVar5 = -(uint)bVar14 | 1;
        }
        if (uVar5 == 0) {
          iStack_54 = (int)pbVar4 - (int)puStack_14;
          if (iStack_54 == 0) {
            uStack_50 = 0xf;
            uStack_64 = uStack_64 & 0xffffff00;
            if (puVar13[4] < 7) {
              FUN_00554050();
              goto LAB_00b9fc38;
            }
            iVar6 = puVar13[4] - 7;
            iVar8 = -1;
            if (iVar6 != -1) {
              iVar8 = iVar6;
            }
            puVar7 = puVar13;
            if (0xf < puVar13[5]) {
              puVar7 = (uint *)*puVar13;
            }
            FUN_005542c0((int)puVar7 + 7,iVar8);
            uStack_1c = 2;
            FUN_005507b0();
            uStack_4c = uStack_64;
            uStack_64 = uStack_64 & 0xffffff00;
            uStack_48 = uStack_60;
            uStack_44 = uStack_5c;
            uStack_40 = uStack_58;
            uStack_3c = CONCAT44(uStack_50,iStack_54);
            iStack_54 = 0;
            uStack_50 = 0xf;
            FUN_005507b0();
            iVar8 = iStack_54;
          }
          break;
        }
        iStack_54 = iVar8;
        pbVar4 = (byte *)FUN_0170db20(pbVar4 + 1,99,(int)piStack_24 - (int)(pbVar4 + 1));
        iVar8 = iStack_54;
      }
    }
  }
  iStack_54 = iVar8;
  puVar7 = &uStack_4c;
  if (param_4 == '\0') {
    puVar7 = puVar13;
  }
  if (*piStack_2c == 0) {
    uStack_64 = uStack_64 & 0xffffff00;
    uStack_50 = 0xf;
    iStack_54 = *piStack_2c;
    FUN_005542c0("No core scripts when fetching core script source",0x30);
    uStack_8 = 1;
    FUN_00f92310(&uStack_64);
    if (0xf < uStack_50) {
      uVar12 = uStack_50 + 1;
      uVar5 = uStack_64;
      if (0xfff < uVar12) {
        uVar5 = *(uint *)(uStack_64 - 4);
        uVar12 = uStack_50 + 0x24;
        if (0x1f < (uStack_64 - uVar5) - 4) {
LAB_00b9fc38:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar12);
    }
    *param_2 = 0;
    if (uStack_3c._4_4_ < 0x10) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    uVar12 = uStack_3c._4_4_ + 1;
    uVar5 = uStack_4c;
    if (0xfff < uVar12) {
      uVar5 = *(uint *)(uStack_4c - 4);
      uVar12 = uStack_3c._4_4_ + 0x24;
      if (0x1f < (uStack_4c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar12);
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar8 = FUN_008a1240(puVar7);
  if (iVar8 != 0) {
    uVar9 = FUN_0060dcd0(auStack_18,iVar8);
    uStack_8 = 2;
    FUN_009431c0(&iStack_28,uVar9);
    puVar7 = puStack_14;
    uStack_8 = 4;
    if (puStack_14 != (uint *)0x0) {
      LOCK();
      uVar5 = puStack_14[1] - 1;
      puStack_14[1] = uVar5;
      UNLOCK();
      if (uVar5 == 0) {
        (**(code **)*puStack_14)();
        LOCK();
        puVar1 = puVar7 + 2;
        uVar5 = *puVar1 - 1;
        *puVar1 = uVar5;
        UNLOCK();
        if (uVar5 == 0) {
          (**(code **)(*puVar7 + 4))();
        }
      }
    }
    if (iStack_28 != 0) {
      FUN_009ed300(auStack_30);
      uStack_8 = 5;
      iVar8 = FUN_00a33fa0();
      if (*(int *)(iVar8 + 0x10) == 0) {
        iVar8 = FUN_00a33fa0();
        if (*(int *)(iVar8 + 0x10) == 0) {
          FUN_0056e380();
          FUN_0056e380();
          goto LAB_00b9fb83;
        }
        uVar9 = FUN_00a33fa0();
        uVar9 = FUN_00886c00(auStack_20,uVar9);
        _uStack_8 = CONCAT31(uStack_7,7);
      }
      else {
        uVar9 = FUN_00a33fa0();
        uVar9 = FUN_008869b0(auStack_20,uVar9);
        _uStack_8 = CONCAT31(uStack_7,6);
      }
      *param_2 = 0;
      FUN_008866a0(uVar9);
      *param_2 = 1;
      FUN_0056e380();
      FUN_0056e380();
      FUN_0056e380();
      FUN_0056e380();
      FUN_00550b30();
      goto LAB_00b9fc17;
    }
LAB_00b9fb83:
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_24[1] + -1;
      piStack_24[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar2 = piVar3 + 2;
        iVar8 = *piVar2 + -1;
        *piVar2 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  uStack_34 = uStack_1c | 4;
  _uStack_8 = CONCAT31(uStack_7,8);
  iStack_54 = 0;
  uStack_50 = 0xf;
  uStack_64 = uStack_64 & 0xffffff00;
  FUN_0058a190(puVar13[4] + 0x14);
  FUN_00554150("Missing core script ",0x14);
  puVar7 = puVar13 + 4;
  if (0xf < puVar13[5]) {
    puVar13 = (uint *)*puVar13;
  }
  FUN_00554150(puVar13,*puVar7);
  FUN_00f921d0(&uStack_64);
  FUN_005507b0();
  *param_2 = 0;
LAB_00b9fc17:
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25557 ; VA 0x00b9fc50 ; FUN_00b9fc50 */

int __thiscall FUN_00b9fc50(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined8 uVar7;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb8e9;
  pvStack_10 = ExceptionList;
  iStack_1c = param_1 + 0x10;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar3 = (int)param_2;
  iVar4 = (int)param_2 + 0xc;
  if (param_2 == (undefined4 *)0x0) {
    iVar4 = 0;
  }
  param_2 = (undefined4 *)FUN_0097bfc0(iVar4);
  if (param_2 != (undefined4 *)0x0) {
    FUN_01014cc0(&uStack_2c);
    uStack_8 = 0;
    uVar7 = FUN_00928340();
    FUN_01014e00(uVar7);
    piVar2 = piStack_28;
    uStack_8 = 0xffffffff;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_28[1] + -1;
      piStack_28[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  iVar4 = FUN_005cf750();
  if (iVar4 != 0) {
    FUN_005e5de0(&uStack_2c,iVar3);
    iStack_14 = iVar4 + 0x4c;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 3;
    uStack_8._1_3_ = 0;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 4;
    uStack_20 = uVar5;
    puStack_24 = (undefined4 *)FUN_01674e20(0x20);
    if (puStack_24 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puStack_24 = 0;
      puStack_24[1] = 1;
      puStack_24[2] = FUN_00b9f5c0;
      puStack_24[3] = FUN_005d3660;
      puStack_24[4] = 0;
      puStack_24[5] = iStack_14;
      puStack_24[6] = 0;
      puStack_24[7] = 0;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[2] = piStack_28[2] + 1;
        UNLOCK();
      }
      puStack_24[6] = uStack_2c;
      puStack_24[7] = piStack_28;
      puVar6 = puStack_24;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    uStack_18 = 1;
    uStack_8._0_1_ = 5;
    param_2 = puVar6;
    FUN_01675290(uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar4 = FUN_01679300(&param_2);
    if ((char)iVar4 != '\0') {
      FUN_01679490();
      iVar4 = FUN_016791c0(&param_2);
    }
    if (param_2 != (undefined4 *)0x0) {
      piVar2 = param_2 + 1;
      LOCK();
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      iVar4 = iVar4 + -1;
      if (iVar4 == 0) {
        iVar4 = FUN_01674ea0(param_2);
      }
    }
    if (piStack_28 != (int *)0x0) {
      piVar2 = piStack_28 + 2;
      LOCK();
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_28 + 4))();
      }
      LOCK();
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 25558 ; VA 0x00b9fe60 ; FUN_00b9fe60 */

int * __thiscall FUN_00b9fe60(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017fb939;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_01014cc0(auStack_20);
  uStack_8 = 1;
  FUN_010149f0(param_1[5] == 1);
  uStack_8 = uStack_8 & 0xffffff00;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar4 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  FUN_01014cc0(auStack_28);
  uStack_8 = 2;
  FUN_01014110(param_2);
  piVar3 = piStack_24;
  uStack_18 = 1;
  uStack_8 = uStack_8 & 0xffffff00;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (*param_2 != 0) {
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0("DataModelInstances",0x12);
    uStack_8 = 3;
    uVar5 = FUN_008a1240(auStack_40);
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_28,uVar5);
    uVar5 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    puStack_14[2] = uVar5;
    piVar3 = (int *)puStack_14[3];
    puStack_14[3] = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar7 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0("CoreScripts",0xb);
    uStack_8 = 4;
    uVar5 = FUN_008a1240(auStack_40);
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_28,uVar5);
    uVar5 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *puStack_14 = uVar5;
    piVar3 = (int *)puStack_14[1];
    puStack_14[1] = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar3 = piStack_24 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar7 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25559 ; VA 0x00ba0110 ; FUN_00ba0110 */

void __thiscall FUN_00ba0110(int *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int aiStack_60 [5];
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb968;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff94;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  uVar3 = FUN_01675640(aiStack_60,"Patching data model with launch intent %u",
                       *(undefined4 *)(param_2 + 0x4a0));
  uStack_8 = 0;
  FUN_00f924f0(uVar3);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_4c) {
    uVar6 = uStack_4c + 1;
    iVar5 = aiStack_60[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_60[0] + -4);
      uVar6 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  piVar2 = param_1 + 2;
  if ((*param_1 == 0) || (*piVar2 == 0)) {
    piStack_18 = piVar2;
    FUN_00b9fe60(auStack_30);
    piStack_20 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
  }
  uStack_8 = 1;
  iVar4 = FUN_008fbd40();
  iVar5 = param_1[3];
  if (iVar4 == 3) {
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
    }
    FUN_00b9f350(param_2,param_1[2],param_1[3]);
  }
  else {
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
    }
    FUN_00b9ef80(param_2,*piVar2,param_1[3]);
  }
  *piVar2 = 0;
  piVar2 = (int *)param_1[3];
  param_1[3] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar2 + 4))();
        FUN_00ba02d2();
        return;
      }
    }
  }
  uStack_8 = 0xffffffff;
  uVar3 = FUN_01675640(auStack_48,"Patching data model with launch intent %u",
                       *(undefined4 *)(param_2 + 0x4a0));
  uStack_8 = 4;
  FUN_00f926d0(uVar3);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar6 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (param_1[5] == 0) {
    FUN_00b9fc50(param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25560 ; VA 0x00ba027b ; Catch@00ba027b */

undefined * Catch_00ba027b(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -0x20) = 0;
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  FUN_005587e0(unaff_EBP + -0x20);
  FUN_00550b30();
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x24) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_00f90c80(unaff_EBP + -0x5c);
  FUN_005507b0();
  return &DAT_00ba02cf;
}



/* FUNCTION 25561 ; VA 0x00ba02d2 ; FUN_00ba02d2 */

void FUN_00ba02d2(void)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  int unaff_EBP;
  int unaff_ESI;
  
  iVar1 = *(int *)(unaff_EBP + 8);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  uVar4 = FUN_01675640(unaff_EBP + -0x44,"Patching data model with launch intent %u",
                       *(undefined4 *)(iVar1 + 0x4a0));
  *(undefined4 *)(unaff_EBP + -4) = 4;
  FUN_00f926d0(uVar4);
  uVar2 = *(uint *)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (0xf < uVar2) {
    iVar3 = *(int *)(unaff_EBP + -0x44);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  iVar3 = *(int *)(unaff_ESI + 0x14);
  *(undefined4 *)(unaff_EBP + -0x34) = 0;
  *(undefined4 *)(unaff_EBP + -0x30) = 0xf;
  *(undefined *)(unaff_EBP + -0x44) = 0;
  if (iVar3 == 0) {
    FUN_00b9fc50(iVar1);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 25562 ; VA 0x00ba0380 ; FUN_00ba0380 */

int * FUN_00ba0380(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb990;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009431c0(&piStack_1c,&param_1);
  piVar2 = piStack_18;
  if (piStack_1c != (int *)0x0) {
    *(undefined *)(piStack_1c + 0x3b) = 1;
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  (**(code **)(*param_1 + 0x40))(&piStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((piStack_1c != (int *)0x0) &&
     (puVar4 = (undefined4 *)*piStack_1c, puVar4 != (undefined4 *)piStack_1c[1])) {
    do {
      if (puVar4[1] != 0) {
        LOCK();
        piVar2 = (int *)(puVar4[1] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      FUN_00ba0380(*puVar4,puVar4[1]);
      puVar4 = puVar4 + 2;
    } while (puVar4 != (undefined4 *)piStack_1c[1]);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_18 + 1;
    iVar3 = *piVar2;
    piStack_1c = (int *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piStack_18 + 2;
      iVar3 = *piVar2;
      piStack_1c = (int *)*piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piStack_1c = (int *)(**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar2 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar3 = *piVar1;
    piStack_1c = (int *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piStack_1c = (int *)(**(code **)*param_2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_1c = (int *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 25563 ; VA 0x00ba04b0 ; FUN_00ba04b0 */

void __thiscall FUN_00ba04b0(int param_1,int param_2)

{
  char *pcVar1;
  undefined uVar2;
  
  *(int *)(param_1 + 0x14) = param_2;
  if (param_2 == 0) {
    pcVar1 = "client";
  }
  else {
    if (param_2 != 1) {
      return;
    }
    pcVar1 = "studio";
  }
  uVar2 = 0;
  FUN_005542c0(pcVar1,6);
  FUN_00f92bd0(uVar2);
  return;
}



/* FUNCTION 25564 ; VA 0x00ba0500 ; FUN_00ba0500 */

int FUN_00ba0500(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb9a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01014cc0(auStack_18);
  uStack_8 = 0;
  iVar3 = FUN_010149e0(param_1);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25565 ; VA 0x00ba0580 ; FUN_00ba0580 */

int * __thiscall
FUN_00ba0580(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ba0840();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::FileSyncItem,bool>::
              GetSetImpl<bool_(__thiscall_RBX::FileSyncItem::*)(void)const_,void_(__thiscall_RBX::FileSyncItem::*)(bool)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::FileSyncItem,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::FileSyncItem,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25566 ; VA 0x00ba0680 ; FUN_00ba0680 */

undefined4 * __thiscall FUN_00ba0680(undefined4 *param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined auStack_1c [4];
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb9c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  puStack_18 = param_1;
  uVar1 = FUN_00601dc0();
  *param_1 = uVar1;
  uStack_8 = 0;
  iStack_14 = param_3;
  if (param_2 != param_3) {
    do {
      uVar1 = *param_1;
      iVar2 = FUN_00773f80(param_2);
      FUN_00ba0da0(auStack_1c,uVar1,iVar2 + 0x10,iVar2);
      param_2 = param_2 + 8;
    } while (param_2 != iStack_14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25567 ; VA 0x00ba0710 ; FUN_00ba0710 */

undefined4 * __thiscall FUN_00ba0710(undefined4 *param_1,uint param_2)

{
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb9f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  FUN_0054f050();
  uStack_8._0_1_ = 2;
  FUN_0054f050(&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00ba13d0();
  if (7 < in_stack_00000018) {
    if (0xfff < in_stack_00000018 * 2 + 2) {
      if (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 7;
  param_2 = param_2 & 0xffff0000;
  if (7 < in_stack_00000038) {
    if (0xfff < in_stack_00000038 * 2 + 2) {
      if (0x1f < (in_stack_00000024 - *(int *)(in_stack_00000024 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25568 ; VA 0x00ba0840 ; FUN_00ba0840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ba0840(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fba30;
  pvStack_10 = ExceptionList;
  if (DAT_01ef2c9c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2eb0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef2eb0);
      puVar1 = PTR_s_InternalSyncItem_01d679bc;
      if (DAT_01ef2eb0 == -1) {
        uStack_8 = 0;
        uVar2 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar2,puVar1,0,uStack_20,0,0,0x19,5,0);
        _DAT_01ef2ea8 = RBX::Creator<class_RBX::FileSyncItem>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef2ca0,&DAT_01ef2ea8);
        FUN_016f3654(FUN_018914b0);
        FUN_016f37bf(&DAT_01ef2eb0);
      }
    }
    DAT_01ef2c9c = &DAT_01ef2ca0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef2c9c;
}



/* FUNCTION 25569 ; VA 0x00ba0940 ; FUN_00ba0940 */

int FUN_00ba0940(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = FUN_009707a0();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = 0;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *param_1;
  *(undefined4 *)(iVar1 + 0x14) = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  *(undefined4 *)(iVar1 + 0x18) = 0;
  *(undefined4 *)(iVar1 + 0x1c) = 0;
  *(undefined4 *)(iVar1 + 0x18) = param_1[2];
  *(undefined4 *)(iVar1 + 0x1c) = param_1[3];
  param_1[2] = 0;
  param_1[3] = 0;
  return iVar1;
}



/* FUNCTION 25570 ; VA 0x00ba09b0 ; FUN_00ba09b0 */

int __thiscall FUN_00ba09b0(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  
  iVar3 = *param_1;
  iVar4 = param_1[1] - iVar3 >> 3;
  if (iVar4 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar7 = param_1[2] - iVar3 >> 3;
  uVar9 = uVar1;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar9 = (uVar7 >> 1) + uVar7, uVar9 < uVar1)) {
    uVar9 = uVar1;
  }
  iVar4 = FUN_00578020(uVar9);
  iVar3 = (param_2 - iVar3 >> 3) * 8;
  *(undefined4 *)(iVar3 + iVar4) = 0;
  *(undefined4 *)(iVar3 + 4 + iVar4) = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar2 = (int *)(param_3[1] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar3 + iVar4) = *param_3;
  *(undefined4 *)(iVar3 + 4 + iVar4) = param_3[1];
  iVar6 = param_1[1];
  iVar8 = *param_1;
  iVar5 = iVar4;
  if (param_2 != iVar6) {
    FUN_005c23f0(iVar8,param_2,iVar4,param_1);
    iVar6 = param_1[1];
    iVar5 = iVar3 + 8 + iVar4;
    iVar8 = param_2;
  }
  FUN_005c23f0(iVar8,iVar6,iVar5,param_1);
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    iVar8 = *param_1;
    uVar7 = param_1[2] - iVar8 & 0xfffffff8;
    iVar6 = iVar8;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar8 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar8 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  *param_1 = iVar4;
  param_1[1] = iVar4 + uVar1 * 8;
  param_1[2] = iVar4 + uVar9 * 8;
  return *param_1 + iVar3;
}



/* FUNCTION 25571 ; VA 0x00ba0ae0 ; FUN_00ba0ae0 */

void __thiscall
FUN_00ba0ae0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x7fffffd < (uint)param_1[1]) {
    FUN_00ba2700(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00ba0b92:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00ba0b92;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 25572 ; VA 0x00ba0c40 ; FUN_00ba0c40 */

void __thiscall
FUN_00ba0c40(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x5555553 < (uint)param_1[1]) {
    FUN_00ba2760(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00ba0cf2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00ba0cf2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 25573 ; VA 0x00ba0da0 ; FUN_00ba0da0 */

undefined4 * __thiscall
FUN_00ba0da0(int *param_1,undefined4 *param_2,int *param_3,int *param_4,undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  bool bVar5;
  undefined4 uVar6;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  byte bStack_16;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fba40;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  piStack_1c = (int *)0x0;
  uStack_8 = 0;
  piStack_20 = param_1;
  if (param_1[1] == 0) {
    param_3 = (int *)*param_1;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
  }
  else {
    piVar3 = (int *)*param_1;
    if (param_3 != (int *)*piVar3) {
      if (param_3 != piVar3) {
        ExceptionList = &pvStack_10;
        cVar1 = FUN_00ba2560(param_4,param_3 + 4);
        if (cVar1 != '\0') {
          piStack_1c = param_3;
          piVar3 = (int *)FUN_0056f560();
          cVar1 = FUN_00ba2560(*piVar3 + 0x10,param_4);
          if (cVar1 != '\0') {
            if (*(char *)(piStack_1c[2] + 0xd) == '\0') {
              uVar6 = 1;
              param_3 = param_3;
            }
            else {
              uVar6 = 0;
              param_3 = piStack_1c;
            }
            goto LAB_00ba0de9;
          }
        }
        cVar1 = FUN_00ba2560(param_3 + 4,param_4);
        if (cVar1 != '\0') {
          piStack_1c = param_3;
          FUN_00551320();
          if ((piStack_1c == (int *)*param_1) ||
             (cVar1 = FUN_00ba2560(param_4,piStack_1c + 4), cVar1 != '\0')) {
            if (*(char *)(param_3[2] + 0xd) == '\0') {
              uVar6 = 1;
              param_3 = piStack_1c;
            }
            else {
              uVar6 = 0;
              param_3 = param_3;
            }
            goto LAB_00ba0de9;
          }
        }
LAB_00ba0f24:
        uStack_8 = 0xffffffff;
        puVar4 = (undefined4 *)FUN_00ba1270(auStack_24,0,param_4,param_5);
        *param_2 = *puVar4;
        ExceptionList = pvStack_10;
        return param_2;
      }
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      cVar1 = FUN_00ba2560(piVar3[2] + 0x10,param_4);
      if (cVar1 == '\0') goto LAB_00ba0f24;
      param_3 = *(int **)(*param_1 + 8);
      uVar6 = 0;
      goto LAB_00ba0de9;
    }
    iVar2 = param_3[4];
    bStack_16 = *(byte *)(*param_4 + 0x18);
    if (bStack_16 == *(byte *)(iVar2 + 0x18)) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      iVar2 = FUN_01686710(iVar2);
      bVar5 = iVar2 < 0;
    }
    else {
      bVar5 = bStack_16 < *(byte *)(iVar2 + 0x18);
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
    }
    if (!bVar5) goto LAB_00ba0f24;
  }
  uVar6 = 1;
LAB_00ba0de9:
  FUN_00913ac0(param_2,uVar6,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25574 ; VA 0x00ba0f56 ; Catch_All@00ba0f56 */

void Catch_All_00ba0f56(void)

{
  int unaff_EBP;
  
  FUN_0091d010(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25575 ; VA 0x00ba0f70 ; FUN_00ba0f70 */

void __thiscall
FUN_00ba0f70(undefined4 *param_1,undefined4 *param_2,char param_3,int param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  bool bVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fba50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar7 = true;
  piVar2 = (int *)*param_1;
  piVar6 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar4 = (int *)piVar2[1];
    do {
      piVar6 = piVar4;
      if (param_3 == '\0') {
        bVar7 = *(uint *)(param_4 + 4) < (uint)piVar6[5];
      }
      else {
        bVar7 = *(uint *)(param_4 + 4) <= (uint)piVar6[5];
      }
      if (bVar7 == false) {
        piVar4 = (int *)piVar6[2];
      }
      else {
        piVar4 = (int *)*piVar6;
      }
    } while (*(char *)((int)piVar4 + 0xd) == '\0');
  }
  piVar4 = piVar6;
  if (bVar7 != false) {
    if (piVar6 == (int *)*piVar2) {
      bVar7 = true;
      goto LAB_00ba1005;
    }
    if (*(char *)((int)piVar6 + 0xd) == '\0') {
      piVar4 = (int *)*piVar6;
      if (*(char *)((int)piVar4 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar4[2] + 0xd);
        piVar2 = (int *)piVar4[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar4 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar6[1] + 0xd);
        piVar2 = (int *)piVar6[1];
        piVar4 = piVar6;
        while ((piVar3 = piVar2, cVar1 == '\0' && (piVar4 == (int *)*piVar3))) {
          cVar1 = *(char *)(piVar3[1] + 0xd);
          piVar2 = (int *)piVar3[1];
          piVar4 = piVar3;
        }
        if (*(char *)((int)piVar4 + 0xd) == '\0') {
          piVar4 = piVar3;
        }
      }
    }
    else {
      piVar4 = (int *)piVar6[2];
    }
  }
  if (*(uint *)(param_4 + 4) <= (uint)piVar4[5]) {
    ExceptionList = &pvStack_10;
    FUN_00ba2700(param_5);
    *param_2 = piVar4;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00ba1005:
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_00ba0ae0(&param_3,bVar7,piVar6,param_4,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25576 ; VA 0x00ba10c6 ; Catch_All@00ba10c6 */

void Catch_All_00ba10c6(void)

{
  int unaff_EBP;
  
  FUN_00ba2700(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25577 ; VA 0x00ba10e0 ; FUN_00ba10e0 */

void __thiscall
FUN_00ba10e0(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,int param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  bool bVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fba60;
  pvStack_10 = ExceptionList;
  cVar1 = (char)param_3;
  bVar9 = true;
  uStack_8 = 0;
  piVar7 = (int *)((int *)*param_1)[1];
  piVar8 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  while (*(char *)((int)piVar7 + 0xd) == '\0') {
    if (cVar1 == '\0') {
      iVar4 = FUN_01686710(piVar7 + 4);
      bVar9 = iVar4 < 0;
    }
    else {
      iVar4 = FUN_01686710(param_4);
      bVar9 = -1 < iVar4;
    }
    piVar8 = piVar7;
    if (bVar9 == false) {
      piVar7 = (int *)piVar7[2];
    }
    else {
      piVar7 = (int *)*piVar7;
    }
  }
  piVar7 = piVar8;
  if (bVar9 != false) {
    if (piVar8 == *(int **)*param_1) {
      bVar9 = true;
      goto LAB_00ba117b;
    }
    if (*(char *)((int)piVar8 + 0xd) == '\0') {
      piVar7 = (int *)*piVar8;
      if (*(char *)((int)piVar7 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar7[2] + 0xd);
        piVar2 = (int *)piVar7[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar7 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar8[1] + 0xd);
        piVar2 = (int *)piVar8[1];
        piVar7 = piVar8;
        while ((piVar3 = piVar2, cVar1 == '\0' && (param_3 = piVar3, piVar7 == (int *)*piVar3))) {
          cVar1 = *(char *)(piVar3[1] + 0xd);
          piVar2 = (int *)piVar3[1];
          piVar7 = piVar3;
        }
        if (*(char *)((int)piVar7 + 0xd) == '\0') {
          piVar7 = piVar3;
        }
      }
    }
    else {
      piVar7 = (int *)piVar8[2];
    }
  }
  iVar6 = FUN_01686710(param_4);
  iVar4 = param_5;
  if (-1 < iVar6) {
    FUN_00ba1950(param_1,param_5 + 0x10);
    FUN_01674ea0(iVar4,0x30);
    *param_2 = piVar7;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00ba117b:
  puVar5 = (undefined4 *)FUN_00ba0c40(&param_3,bVar9,piVar8,param_4,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25578 ; VA 0x00ba1258 ; Catch_All@00ba1258 */

void Catch_All_00ba1258(void)

{
  int unaff_EBP;
  
  FUN_00ba2760(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25579 ; VA 0x00ba1270 ; FUN_00ba1270 */

void __thiscall
FUN_00ba1270(int *param_1,undefined4 *param_2,undefined4 *param_3,int *param_4,undefined4 param_5)

{
  byte bVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  bool bVar5;
  bool bVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fba70;
  pvStack_10 = ExceptionList;
  bVar5 = true;
  uStack_8 = 0;
  puVar3 = (undefined4 *)*param_1;
  puVar4 = (undefined4 *)((undefined4 *)*param_1)[1];
  ExceptionList = &pvStack_10;
  while (*(char *)((int)puVar4 + 0xd) == '\0') {
    if ((char)param_3 == '\0') {
      bVar1 = *(byte *)(puVar4[4] + 0x18);
      bVar5 = *(byte *)(*param_4 + 0x18) < bVar1;
      if (*(byte *)(*param_4 + 0x18) == bVar1) {
        iVar2 = FUN_01686710(puVar4[4]);
        bVar5 = iVar2 < 0;
      }
    }
    else {
      bVar1 = *(byte *)(*param_4 + 0x18);
      bVar5 = bVar1 <= *(byte *)(puVar4[4] + 0x18);
      if (*(byte *)(puVar4[4] + 0x18) == bVar1) {
        iVar2 = FUN_01686710(*param_4);
        bVar5 = -1 < iVar2;
      }
    }
    puVar3 = puVar4;
    if (bVar5 == false) {
      puVar4 = (undefined4 *)puVar4[2];
    }
    else {
      puVar4 = (undefined4 *)*puVar4;
    }
  }
  param_3 = puVar3;
  if (bVar5 != false) {
    if (puVar3 == *(undefined4 **)*param_1) {
      bVar5 = true;
      goto LAB_00ba1325;
    }
    FUN_0056f560();
  }
  puVar4 = param_3;
  bVar1 = *(byte *)(*param_4 + 0x18);
  bVar6 = *(byte *)(param_3[4] + 0x18) < bVar1;
  if (*(byte *)(param_3[4] + 0x18) == bVar1) {
    iVar2 = FUN_01686710(*param_4);
    bVar6 = iVar2 < 0;
  }
  if (!bVar6) {
    FUN_0091d010(param_5);
    *param_2 = puVar4;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00ba1325:
  puVar3 = (undefined4 *)FUN_00913ac0(&param_3,bVar5,puVar3,param_4,param_5);
  *param_2 = *puVar3;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25580 ; VA 0x00ba13af ; Catch_All@00ba13af */

void Catch_All_00ba13af(void)

{
  int unaff_EBP;
  
  FUN_0091d010(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25581 ; VA 0x00ba13d0 ; FUN_00ba13d0 */

void __thiscall FUN_00ba13d0(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  uint in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined4 uStack_b4;
  undefined4 *puStack_b0;
  undefined auStack_ac [16];
  undefined4 uStack_9c;
  uint *puStack_98;
  undefined4 uStack_94;
  undefined4 *puStack_90;
  undefined auStack_8c [16];
  uint uStack_7c;
  undefined4 uStack_78;
  uint uStack_74;
  code *pcStack_70;
  uint auStack_60 [5];
  uint uStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  uint auStack_40 [5];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  uint *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fbab8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff94;
  puStack_1c = auStack_8c;
  puStack_20 = auStack_8c;
  uStack_8 = 1;
  puStack_90 = &stack0x00000024;
  uStack_94 = 0xba1413;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0054f050();
  uStack_74 = in_stack_0000003c;
  pcStack_70 = (code *)in_stack_00000040;
  puStack_20 = auStack_ac;
  uStack_8._0_1_ = 2;
  puStack_b0 = &param_2;
  uStack_b4 = 0xba1436;
  FUN_0054f050();
  uStack_94 = in_stack_0000001c;
  puStack_90 = (undefined4 *)in_stack_00000020;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puStack_b0 = (undefined4 *)0xba144b;
  uVar1 = FUN_00ba19e0();
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (uVar1 != 0) {
    if (0xaaaaaaa < uVar1) {
                    /* WARNING: Subroutine does not return */
      pcStack_70 = (code *)0xba166b;
      FUN_00577c30();
    }
    uVar1 = uVar1 * 0x18;
    if (uVar1 < 0x1000) {
      if (uVar1 == 0) {
        uVar3 = 0;
      }
      else {
        uStack_74 = 0xba14b6;
        pcStack_70 = (code *)uVar1;
        uVar3 = FUN_01674e20();
      }
    }
    else {
      pcStack_70 = (code *)(uVar1 + 0x23);
      if (pcStack_70 <= uVar1) {
        pcStack_70 = (code *)0xffffffff;
      }
      uStack_74 = 0xba1494;
      iVar2 = FUN_01674e20();
      if (iVar2 == 0) goto LAB_00ba166b;
      uVar3 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar3 - 4) = iVar2;
    }
    *param_1 = uVar3;
    param_1[1] = uVar3;
    uStack_8._0_1_ = 3;
    param_1[2] = *param_1 + uVar1;
    pcStack_70 = (code *)&stack0x00000024;
    uVar1 = *param_1;
    uStack_74 = 0xba14db;
    FUN_0054f050();
    uStack_48 = in_stack_0000003c;
    uStack_44 = in_stack_00000040;
    pcStack_70 = (code *)&param_2;
    uStack_8._0_1_ = 4;
    uStack_74 = 0xba14f7;
    FUN_0054f050();
    uStack_28 = in_stack_0000001c;
    uStack_24 = in_stack_00000020;
    puStack_20 = (undefined *)&uStack_94;
    puStack_1c = (undefined *)&uStack_94;
    uStack_8._0_1_ = 6;
    puStack_98 = auStack_60;
    uStack_9c = 0xba151f;
    uStack_74 = uVar1;
    pcStack_70 = (code *)param_1;
    FUN_0054f050();
    uStack_7c = uStack_48;
    uStack_78 = uStack_44;
    puStack_1c = (undefined *)&uStack_b4;
    uStack_8._0_1_ = 7;
    FUN_0054f050(auStack_40);
    uStack_9c = uStack_28;
    puStack_98 = (uint *)uStack_24;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    uVar1 = FUN_00ba16a0();
    if (7 < uStack_2c) {
      pcStack_70 = (code *)(uStack_2c * 2 + 2);
      uVar3 = auStack_40[0];
      if (0xfff < pcStack_70) {
        uVar3 = *(uint *)(auStack_40[0] - 4);
        pcStack_70 = (code *)(uStack_2c * 2 + 0x25);
        if (0x1f < (auStack_40[0] - uVar3) - 4) {
LAB_00ba166b:
                    /* WARNING: Subroutine does not return */
          pcStack_70 = (code *)0xba1670;
          FUN_017167a3();
        }
      }
      uStack_78 = 0xba1593;
      uStack_74 = uVar3;
      FUN_01674ea0();
    }
    if (7 < uStack_4c) {
      pcStack_70 = (code *)(uStack_4c * 2 + 2);
      uVar3 = auStack_60[0];
      if (0xfff < pcStack_70) {
        uVar3 = *(uint *)(auStack_60[0] - 4);
        pcStack_70 = (code *)(uStack_4c * 2 + 0x25);
        if (0x1f < (auStack_60[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          pcStack_70 = (code *)0xba1675;
          FUN_017167a3();
        }
      }
      uStack_78 = 0xba15cd;
      uStack_74 = uVar3;
      FUN_01674ea0();
    }
    param_1[1] = uVar1;
  }
  if (7 < in_stack_00000018) {
    pcStack_70 = (code *)(in_stack_00000018 * 2 + 2);
    uVar1 = param_2;
    if (0xfff < pcStack_70) {
      uVar1 = *(uint *)(param_2 - 4);
      pcStack_70 = (code *)(in_stack_00000018 * 2 + 0x25);
      if (0x1f < (param_2 - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        pcStack_70 = Catch_All_00ba167a;
        FUN_017167a3();
      }
    }
    uStack_78 = 0xba1606;
    uStack_74 = uVar1;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 7;
  param_2 = param_2 & 0xffff0000;
  if (7 < in_stack_00000038) {
    pcStack_70 = (code *)(in_stack_00000038 * 2 + 2);
    iVar2 = in_stack_00000024;
    if (0xfff < pcStack_70) {
      iVar2 = *(int *)(in_stack_00000024 + -4);
      pcStack_70 = (code *)(in_stack_00000038 * 2 + 0x25);
      if (0x1f < (in_stack_00000024 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        pcStack_70 = (code *)0xba1690;
        FUN_017167a3();
      }
    }
    uStack_78 = 0xba1650;
    uStack_74 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25582 ; VA 0x00ba167a ; Catch_All@00ba167a */

void Catch_All_00ba167a(void)

{
  FUN_0058eb40();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25583 ; VA 0x00ba16a0 ; FUN_00ba16a0 */

int FUN_00ba16a0(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int in_stack_0000001c;
  int in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  int in_stack_0000003c;
  int in_stack_00000040;
  int in_stack_00000044;
  undefined4 in_stack_00000048;
  int iStack_a0;
  uint uStack_8c;
  int aiStack_80 [5];
  uint uStack_6c;
  int iStack_68;
  int iStack_64;
  int aiStack_60 [5];
  uint uStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  undefined4 uStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fbb16;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0054f050(&param_1);
  iStack_68 = in_stack_0000001c;
  iStack_64 = in_stack_00000020;
  uStack_8._0_1_ = 2;
  FUN_0054f050(&stack0x00000024);
  iStack_48 = in_stack_0000003c;
  iStack_44 = in_stack_00000040;
  uStack_8._0_1_ = 3;
  FUN_0054f050(aiStack_60);
  iVar2 = iStack_44;
  uStack_8._0_1_ = 4;
  FUN_0054f050(aiStack_80);
  iStack_1c = iStack_68;
  iStack_18 = iStack_64;
  iStack_40 = in_stack_00000044;
  iStack_3c = in_stack_00000044;
  uStack_38 = in_stack_00000048;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar4 = in_stack_00000044;
  while ((in_stack_00000044 = iVar4, iStack_1c != iStack_48 || (iStack_18 != iVar2))) {
    FUN_0054f050(auStack_34);
    iVar4 = iVar4 + 0x18;
    iStack_3c = iVar4;
    FUN_01688400(auStack_34);
  }
  FUN_0058cd80(iVar4,iVar4,in_stack_00000048);
  if (7 < uStack_20) {
    uVar3 = uStack_20 * 2 + 2;
    uVar1 = auStack_34[0];
    if (0xfff < uVar3) {
      uVar1 = *(uint *)(auStack_34[0] - 4);
      uVar3 = uStack_20 * 2 + 0x25;
      if (0x1f < (auStack_34[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar3);
  }
  uStack_24 = 0;
  uStack_20 = 7;
  auStack_34[0] = auStack_34[0] & 0xffff0000;
  if (7 < uStack_8c) {
    uVar3 = uStack_8c * 2 + 2;
    iVar2 = iStack_a0;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iStack_a0 + -4);
      uVar3 = uStack_8c * 2 + 0x25;
      if (0x1f < (iStack_a0 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (7 < uStack_4c) {
    uVar3 = uStack_4c * 2 + 2;
    iVar2 = aiStack_60[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_60[0] + -4);
      uVar3 = uStack_4c * 2 + 0x25;
      if (0x1f < (aiStack_60[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (7 < uStack_6c) {
    uVar3 = uStack_6c * 2 + 2;
    iVar2 = aiStack_80[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_80[0] + -4);
      uVar3 = uStack_6c * 2 + 0x25;
      if (0x1f < (aiStack_80[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (7 < in_stack_00000018) {
    uVar3 = in_stack_00000018 * 2 + 2;
    uVar1 = param_1;
    if (0xfff < uVar3) {
      uVar1 = *(uint *)(param_1 - 4);
      uVar3 = in_stack_00000018 * 2 + 0x25;
      if (0x1f < (param_1 - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar3);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 7;
  param_1 = param_1 & 0xffff0000;
  if (7 < in_stack_00000038) {
    uVar3 = in_stack_00000038 * 2 + 2;
    iVar2 = in_stack_00000024;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(in_stack_00000024 + -4);
      uVar3 = in_stack_00000038 * 2 + 0x25;
      if (0x1f < (in_stack_00000024 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return in_stack_00000044;
}



/* FUNCTION 25584 ; VA 0x00ba1950 ; FUN_00ba1950 */

void FUN_00ba1950(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_2[7];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (7 < (uint)param_2[5]) {
    iVar3 = *param_2;
    iVar4 = param_2[5] * 2;
    uVar6 = iVar4 + 2;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = iVar4 + 0x25;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_2[4] = 0;
  param_2[5] = 7;
  *(undefined2 *)param_2 = 0;
  return;
}



/* FUNCTION 25585 ; VA 0x00ba19e0 ; FUN_00ba19e0 */

int FUN_00ba19e0(uint param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int in_stack_0000001c;
  int in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  int in_stack_0000003c;
  int in_stack_00000040;
  int iStack_54;
  uint uStack_40;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fbb48;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0054f050(&stack0x00000024);
  iVar1 = in_stack_00000040;
  iVar3 = in_stack_0000003c;
  uStack_8._0_1_ = 2;
  FUN_0054f050(&param_1);
  iStack_1c = in_stack_0000001c;
  iStack_18 = in_stack_00000020;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar5 = 0;
  while ((iStack_1c != iVar3 || (iStack_18 != iVar1))) {
    iVar5 = iVar5 + 1;
    FUN_01688400(auStack_34);
  }
  if (7 < uStack_20) {
    uVar4 = uStack_20 * 2 + 2;
    uVar2 = auStack_34[0];
    if (0xfff < uVar4) {
      uVar2 = *(uint *)(auStack_34[0] - 4);
      uVar4 = uStack_20 * 2 + 0x25;
      if (0x1f < (auStack_34[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar4);
  }
  uStack_24 = 0;
  uStack_20 = 7;
  auStack_34[0] = auStack_34[0] & 0xffff0000;
  if (7 < uStack_40) {
    uVar4 = uStack_40 * 2 + 2;
    iVar3 = iStack_54;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iStack_54 + -4);
      uVar4 = uStack_40 * 2 + 0x25;
      if (0x1f < (iStack_54 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  if (7 < in_stack_00000018) {
    uVar4 = in_stack_00000018 * 2 + 2;
    uVar2 = param_1;
    if (0xfff < uVar4) {
      uVar2 = *(uint *)(param_1 - 4);
      uVar4 = in_stack_00000018 * 2 + 0x25;
      if (0x1f < (param_1 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar4);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 7;
  param_1 = param_1 & 0xffff0000;
  if (7 < in_stack_00000038) {
    uVar4 = in_stack_00000038 * 2 + 2;
    iVar3 = in_stack_00000024;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(in_stack_00000024 + -4);
      uVar4 = in_stack_00000038 * 2 + 0x25;
      if (0x1f < (in_stack_00000024 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25586 ; VA 0x00ba1b90 ; FUN_00ba1b90 */

int FUN_00ba1b90(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ead688,&LAB_006340c0);
      uVar3 = FUN_00635250();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00bacc40();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 25587 ; VA 0x00ba1ca0 ; FUN_00ba1ca0 */

void __thiscall FUN_00ba1ca0(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x34,param_1);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<struct_RBX::FileSyncItem::FileMetadata>::vftable;
    puVar1[7] = 0;
    puVar1[8] = 7;
    *(undefined2 *)(puVar1 + 3) = 0;
    *(undefined *)(puVar1 + 9) = 0;
    puVar1[10] = 0;
    puVar1[0xb] = 0;
    puVar1[0xc] = 0;
    *param_2 = (int)(puVar1 + 3);
    param_2[1] = (int)puVar1;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 25588 ; VA 0x00ba1d10 ; FUN_00ba1d10 */

undefined4 * __fastcall FUN_00ba1d10(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fbbf2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::FileSyncItem,class_RBX::Instance>::vftable;
  uVar2 = FUN_00ba0840();
  param_1[3] = uVar2;
  puVar1 = param_1 + 0x15;
  *param_1 = RBX::FileSyncItem::vftable;
  uStack_8 = 1;
  *puVar1 = 0;
  param_1[0x16] = 0;
  puStack_18 = puVar1;
  uVar2 = FUN_00575b10();
  *puVar1 = uVar2;
  puVar1 = param_1 + 0x17;
  uStack_8._0_1_ = 2;
  *puVar1 = 0;
  param_1[0x18] = 0;
  puStack_18 = puVar1;
  uVar2 = FUN_00575ab0();
  *puVar1 = uVar2;
  puVar1 = param_1 + 0x19;
  uStack_8._0_1_ = 3;
  *puVar1 = 0;
  param_1[0x1a] = 0;
  puStack_18 = puVar1;
  uVar2 = FUN_00575b10();
  *puVar1 = uVar2;
  puVar1 = param_1 + 0x1b;
  uStack_8._0_1_ = 4;
  *puVar1 = 0;
  param_1[0x1c] = 0;
  puStack_18 = puVar1;
  uVar2 = FUN_00601dc0();
  *puVar1 = uVar2;
  param_1[0x1d] = 0;
  *(undefined *)(param_1 + 0x1e) = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 7;
  *(undefined2 *)(param_1 + 0x1f) = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  *(undefined2 *)(param_1 + 0x27) = 0x100;
  param_1[0x2c] = 0;
  param_1[0x2d] = 7;
  *(undefined2 *)(param_1 + 0x28) = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  puVar1 = param_1 + 0x32;
  param_1[0x30] = 0;
  *(undefined *)(param_1 + 0x31) = 0;
  uStack_8._0_1_ = 10;
  *puVar1 = 0;
  param_1[0x33] = 0;
  puStack_18 = puVar1;
  uVar2 = FUN_005cb2b0(0,0);
  *puVar1 = uVar2;
  uStack_8._0_1_ = 0xb;
  FUN_00baac60();
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("FileSyncItem",0xc);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar3 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25589 ; VA 0x00ba1ee0 ; FUN_00ba1ee0 */

undefined4 * __thiscall FUN_00ba1ee0(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_2[2] = 0;
  param_2[3] = 0;
  return param_1;
}



/* FUNCTION 25590 ; VA 0x00ba1f20 ; FUN_00ba1f20 */

void __fastcall FUN_00ba1f20(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::FileSyncItem>::vftable;
  uVar1 = FUN_00ba0840(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25591 ; VA 0x00ba1f60 ; FUN_00ba1f60 */

void __fastcall FUN_00ba1f60(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00ba4780(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25592 ; VA 0x00ba1fb0 ; FUN_00ba1fb0 */

void __fastcall FUN_00ba1fb0(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00ba4900(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25593 ; VA 0x00ba2000 ; FUN_00ba2000 */

void __fastcall FUN_00ba2000(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_1[7];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (7 < (uint)param_1[5]) {
    iVar3 = *param_1;
    iVar4 = param_1[5] * 2;
    uVar6 = iVar4 + 2;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = iVar4 + 0x25;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 7;
  *(undefined2 *)param_1 = 0;
  return;
}



/* FUNCTION 25594 ; VA 0x00ba2080 ; FUN_00ba2080 */

void __fastcall FUN_00ba2080(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a950;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::FileSyncItem::vftable;
  puStack_14 = param_1;
  FUN_005cb850();
  FUN_01674ea0(param_1[0x32],0x20);
  piVar1 = (int *)param_1[0x2f];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (7 < (uint)param_1[0x2d]) {
    iVar2 = param_1[0x28];
    iVar3 = param_1[0x2d] * 2;
    uVar5 = iVar3 + 2;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = iVar3 + 0x25;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00ba22a1;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x2c] = 0;
  param_1[0x2d] = 7;
  *(undefined2 *)(param_1 + 0x28) = 0;
  piVar1 = (int *)param_1[0x26];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (7 < (uint)param_1[0x24]) {
    iVar2 = param_1[0x1f];
    iVar3 = param_1[0x24] * 2;
    uVar5 = iVar3 + 2;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = iVar3 + 0x25;
      if (0x1f < (iVar2 - iVar4) - 4U) {
LAB_00ba22a1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x23] = 0;
  param_1[0x24] = 7;
  *(undefined2 *)(param_1 + 0x1f) = 0;
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x1d];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_0094e3b0(&puStack_14,*(undefined4 *)param_1[0x1b],(undefined4 *)param_1[0x1b]);
  FUN_01674ea0(param_1[0x1b],0x18);
  uStack_8 = 2;
  FUN_00ba4900(&puStack_14,*(undefined4 *)param_1[0x19],(undefined4 *)param_1[0x19]);
  FUN_01674ea0(param_1[0x19],0x30);
  uStack_8 = 3;
  FUN_00ba4780(&puStack_14,*(undefined4 *)param_1[0x17],(undefined4 *)param_1[0x17]);
  FUN_01674ea0(param_1[0x17],0x20);
  uStack_8 = 4;
  FUN_00ba4900(&puStack_14,*(undefined4 *)param_1[0x15],(undefined4 *)param_1[0x15]);
  FUN_01674ea0(param_1[0x15],0x30);
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25595 ; VA 0x00ba22b0 ; FUN_00ba22b0 */

undefined4 * __thiscall FUN_00ba22b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  uint uVar9;
  uint uVar10;
  
  if (param_1 != param_2) {
    puVar5 = param_2;
    if (7 < (uint)param_2[5]) {
      puVar5 = (undefined4 *)*param_2;
    }
    FUN_0058ed10(puVar5,param_2[4]);
  }
  piVar1 = param_1 + 7;
  *(undefined *)(param_1 + 6) = *(undefined *)(param_2 + 6);
  if (piVar1 != param_2 + 7) {
    iVar3 = param_2[8];
    iVar4 = param_2[7];
    iVar7 = *piVar1;
    uVar10 = iVar3 - iVar4 >> 3;
    uVar9 = param_1[9] - iVar7 >> 3;
    uVar6 = param_1[8] - iVar7 >> 3;
    if (uVar9 < uVar10) {
      if (0x1fffffff < uVar10) {
LAB_00ba240f:
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      uVar6 = uVar10;
      if ((uVar9 <= 0x1fffffff - (uVar9 >> 1)) && (uVar6 = (uVar9 >> 1) + uVar9, uVar6 < uVar10)) {
        uVar6 = uVar10;
      }
      if (iVar7 != 0) {
        FUN_005596d0(iVar7,param_1[8],piVar1);
        FUN_0057d330(*piVar1,uVar9);
      }
      *piVar1 = 0;
      param_1[8] = 0;
      param_1[9] = 0;
      if (uVar6 != 0) {
        if (0x1fffffff < uVar6) goto LAB_00ba240f;
        iVar7 = FUN_00578020(uVar6);
        *piVar1 = iVar7;
        param_1[8] = iVar7;
        param_1[9] = *piVar1 + uVar6 * 8;
      }
      uVar8 = FUN_0055c480(iVar4,iVar3,*piVar1);
      param_1[8] = uVar8;
      return param_1;
    }
    if (uVar6 < uVar10) {
      iVar2 = iVar4 + uVar6 * 8;
      FUN_00602d30(iVar4,iVar2,iVar7);
      uVar8 = FUN_0055c480(iVar2,iVar3,param_1[8]);
      param_1[8] = uVar8;
      return param_1;
    }
    iVar2 = iVar7 + uVar10 * 8;
    FUN_00602d30(iVar4,iVar3,iVar7);
    FUN_005596d0(iVar2,param_1[8],piVar1);
    param_1[8] = iVar2;
  }
  return param_1;
}



/* FUNCTION 25596 ; VA 0x00ba2420 ; FUN_00ba2420 */

int __thiscall
FUN_00ba2420(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fbc18;
  pvStack_10 = ExceptionList;
  iVar2 = param_1[1];
  iVar4 = 0;
  piVar3 = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    piVar3 = (int *)(iVar2 + 4);
    iVar4 = *(int *)(iVar2 + 4);
    ExceptionList = &pvStack_10;
    while (iVar4 != 0) {
      LOCK();
      iVar2 = *piVar3;
      if (iVar4 == iVar2) {
        *piVar3 = iVar4 + 1;
        iVar2 = iVar4;
      }
      UNLOCK();
      if (iVar2 == iVar4) {
        iVar4 = *param_1;
        piVar3 = (int *)param_1[1];
        goto LAB_00ba247f;
      }
      iVar4 = *piVar3;
    }
    iVar4 = 0;
    piVar3 = (int *)0x0;
  }
LAB_00ba247f:
  uStack_8 = 2;
  if ((iVar4 != 0) && (iVar2 = FUN_008f7870(param_2), iVar2 == 0)) {
    FUN_00ba8ce0(0);
    if (*(char *)(iVar4 + 0x9c) != '\0') {
      *(undefined *)(iVar4 + 0x9c) = 0;
      FUN_008a4940(&DAT_01ef2bb8);
    }
    iVar2 = FUN_01679490();
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar4 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      iVar2 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar4 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar4 = *piVar3;
      iVar2 = *piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar3 = param_5 + 1;
    iVar4 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar2 = (**(code **)*param_5)();
      LOCK();
      piVar3 = param_5 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar2 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 25597 ; VA 0x00ba2560 ; FUN_00ba2560 */

bool FUN_00ba2560(int *param_1,int *param_2)

{
  byte bVar1;
  int iVar2;
  
  bVar1 = *(byte *)(*param_2 + 0x18);
  if (*(byte *)(*param_1 + 0x18) != bVar1) {
    return *(byte *)(*param_1 + 0x18) < bVar1;
  }
  iVar2 = FUN_01686710(*param_2);
  return iVar2 < 0;
}



/* FUNCTION 25598 ; VA 0x00ba25a0 ; FUN_00ba25a0 */

undefined4 __thiscall FUN_00ba25a0(undefined4 param_1,byte param_2)

{
  FUN_00ba2080();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd4);
  }
  return param_1;
}



/* FUNCTION 25599 ; VA 0x00ba25d0 ; FUN_00ba25d0 */

void __thiscall FUN_00ba25d0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_4ae16a20a002de830f3417ef11801457>,bool,class_RBX::Instance*>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 25600 ; VA 0x00ba25f0 ; FUN_00ba25f0 */

void __thiscall FUN_00ba25f0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_e6c2aa09095a06f5f9ae5cfcecbc3ddb>,bool,class_RBX::Instance*>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 25601 ; VA 0x00ba2610 ; FUN_00ba2610 */

void __thiscall FUN_00ba2610(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_ed7d307327e73c8ab3af71a59fd18539>,bool,class_RBX::Instance*>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 25602 ; VA 0x00ba2630 ; FUN_00ba2630 */

void __fastcall FUN_00ba2630(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00577ac0();
  if (7 < *(uint *)(param_1 + 0x20)) {
    iVar2 = *(int *)(param_1 + 0xc);
    iVar1 = *(uint *)(param_1 + 0x20) * 2;
    uVar4 = iVar1 + 2;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = iVar1 + 0x25;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 7;
  *(undefined2 *)(param_1 + 0xc) = 0;
  return;
}



/* FUNCTION 25603 ; VA 0x00ba2690 ; FUN_00ba2690 */

void __fastcall FUN_00ba2690(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar1 = *(int **)(param_1 + 0x28);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  if (7 < *(uint *)(param_1 + 0x20)) {
    iVar2 = *(int *)(param_1 + 0xc);
    iVar3 = *(uint *)(param_1 + 0x20) * 2;
    uVar5 = iVar3 + 2;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = iVar3 + 0x25;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 7;
  *(undefined2 *)(param_1 + 0xc) = 0;
  return;
}



/* FUNCTION 25604 ; VA 0x00ba2700 ; FUN_00ba2700 */

void FUN_00ba2700(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_01674ea0(param_1,0x20);
  return;
}



/* FUNCTION 25605 ; VA 0x00ba2760 ; FUN_00ba2760 */

void __thiscall FUN_00ba2760(undefined4 param_1,int param_2)

{
  FUN_00ba1950(param_1,param_2 + 0x10);
  FUN_01674ea0(param_2,0x30);
  return;
}



/* FUNCTION 25606 ; VA 0x00ba2790 ; FUN_00ba2790 */

bool __thiscall FUN_00ba2790(int param_1,undefined4 *param_2)

{
  char cVar1;
  
  cVar1 = FUN_00bae4c0(*(undefined4 *)(param_1 + 4),*param_2);
  return cVar1 == '\0';
}



/* FUNCTION 25607 ; VA 0x00ba27b0 ; FUN_00ba27b0 */

undefined4 FUN_00ba27b0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fbc98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00ba4f80(&iStack_18,*param_1);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    FUN_00baa4b0(iStack_18,piStack_14);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 25608 ; VA 0x00ba2860 ; FUN_00ba2860 */

bool FUN_00ba2860(undefined4 *param_1)

{
  char cVar1;
  
  cVar1 = FUN_00bae620(*param_1);
  return cVar1 == '\0';
}



/* FUNCTION 25609 ; VA 0x00ba2880 ; FUN_00ba2880 */

undefined4 __thiscall FUN_00ba2880(undefined4 param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  cVar1 = *(char *)((int)param_2 + 0xd);
  while (cVar1 == '\0') {
    FUN_00ba2880(param_2[2]);
    piVar2 = (int *)param_2[7];
    piVar3 = (int *)*param_2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = (int *)param_2[5];
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    FUN_01674ea0(param_2,0x20);
    param_2 = piVar3;
    cVar1 = *(char *)((int)piVar3 + 0xd);
  }
  return param_1;
}



/* FUNCTION 25610 ; VA 0x00ba2910 ; FUN_00ba2910 */

void FUN_00ba2910(int *param_1)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_00ba2910(param_1[2]);
    piVar2 = (int *)param_1[0xb];
    piVar3 = (int *)*param_1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[1] + -1;
      piVar2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar5 = piVar2[2] + -1;
        piVar2[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (7 < (uint)param_1[9]) {
      iVar4 = param_1[4];
      iVar5 = param_1[9] * 2;
      uVar7 = iVar5 + 2;
      iVar6 = iVar4;
      if (0xfff < uVar7) {
        iVar6 = *(int *)(iVar4 + -4);
        uVar7 = iVar5 + 0x25;
        if (0x1f < (iVar4 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar7);
    }
    param_1[8] = 0;
    param_1[9] = 7;
    *(undefined2 *)(param_1 + 4) = 0;
    FUN_01674ea0(param_1,0x30);
    cVar1 = *(char *)((int)piVar3 + 0xd);
    param_1 = piVar3;
  } while( true );
}



/* FUNCTION 25611 ; VA 0x00ba29e0 ; FUN_00ba29e0 */

TypeDescriptor * FUN_00ba29e0(void)

{
  return &<lambda_4ae16a20a002de830f3417ef11801457>::RTTI_Type_Descriptor;
}



/* FUNCTION 25612 ; VA 0x00ba29f0 ; FUN_00ba29f0 */

TypeDescriptor * FUN_00ba29f0(void)

{
  return &<lambda_e6c2aa09095a06f5f9ae5cfcecbc3ddb>::RTTI_Type_Descriptor;
}



/* FUNCTION 25613 ; VA 0x00ba2a00 ; FUN_00ba2a00 */

TypeDescriptor * FUN_00ba2a00(void)

{
  return &<lambda_ed7d307327e73c8ab3af71a59fd18539>::RTTI_Type_Descriptor;
}



/* FUNCTION 25614 ; VA 0x00ba2a10 ; FUN_00ba2a10 */

undefined4 FUN_00ba2a10(undefined4 param_1,int param_2)

{
  undefined uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 ****ppppuVar9;
  undefined *puVar10;
  uint in_stack_0000001c;
  int in_stack_00000020;
  undefined auStack_5c [24];
  undefined4 ***apppuStack_44 [4];
  int iStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fbcf9;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iStack_8 = 0;
  puVar10 = PTR_DAT_01d67998;
  if (((in_stack_00000020 == 3) ||
      (puVar10 = PTR_DAT_01d6799c, ExceptionList = &pvStack_10, in_stack_00000020 == 4)) &&
     (ExceptionList = &pvStack_10, puVar10 != (undefined *)0x0)) {
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_01686c70(auStack_5c);
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    iVar6 = puVar2[4];
    iStack_8._0_1_ = 2;
    uStack_14 = 2;
    if (iVar6 != 0) {
      puVar3 = puVar2;
      if (7 < (uint)puVar2[5]) {
        puVar3 = (undefined4 *)*puVar2;
      }
      if (7 < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      uVar4 = FUN_01686580();
      FUN_01685a20(puVar2,(int)puVar3 + iVar6 * 2,auStack_2c,uVar4);
    }
    FUN_00558ce0(apppuStack_44,auStack_2c,puVar10);
    iStack_8._0_1_ = 4;
    uVar1 = (undefined)iStack_8;
    iStack_8._0_1_ = 4;
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      uVar8 = auStack_2c[0];
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(auStack_2c[0] - 4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar8) - 4) {
          iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_00550800();
    uStack_1c = 0;
    uStack_18 = 7;
    auStack_2c[0] = auStack_2c[0] & 0xffff0000;
    iStack_8._0_1_ = 6;
    if (iStack_34 != 0) {
      ppppuVar5 = apppuStack_44;
      if (0xf < uStack_30) {
        ppppuVar5 = (undefined4 ****)apppuStack_44[0];
      }
      ppppuVar9 = apppuStack_44;
      if (0xf < uStack_30) {
        ppppuVar9 = (undefined4 ****)apppuStack_44[0];
      }
      uVar4 = FUN_01686580();
      FUN_01685950(ppppuVar9,(int)ppppuVar5 + iStack_34,auStack_2c,uVar4);
    }
    iStack_8._0_1_ = 7;
    uVar4 = FUN_016888d0(auStack_2c);
    puVar2 = (undefined4 *)FUN_005514a0(auStack_5c,uVar4);
    iStack_8._0_1_ = 8;
    if (&param_2 != puVar2) {
      puVar3 = puVar2 + 4;
      if (7 < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      FUN_0058ed10(puVar2,*puVar3);
    }
    FUN_00550800();
    FUN_00550800();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_30) {
      uVar8 = uStack_30 + 1;
      ppppuVar5 = (undefined4 ****)apppuStack_44[0];
      if (0xfff < uVar8) {
        ppppuVar5 = (undefined4 ****)apppuStack_44[0][-1];
        uVar8 = uStack_30 + 0x24;
        if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar5,uVar8);
    }
  }
  FUN_0054f050(&param_2);
  if (7 < in_stack_0000001c) {
    uVar8 = in_stack_0000001c * 2 + 2;
    iVar6 = param_2;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(param_2 + -4);
      uVar8 = in_stack_0000001c * 2 + 0x25;
      if (0x1f < (param_2 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25615 ; VA 0x00ba2c50 ; FUN_00ba2c50 */

undefined4 FUN_00ba2c50(undefined4 param_1,int param_2)

{
  undefined uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 ****ppppuVar9;
  uint in_stack_0000001c;
  uint auStack_8c [4];
  undefined4 uStack_7c;
  uint uStack_78;
  uint auStack_74 [4];
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_4c;
  uint uStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fbd5c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01686c70(auStack_74);
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  iVar6 = puVar2[4];
  uStack_8._0_1_ = 2;
  uStack_14 = 2;
  if (iVar6 != 0) {
    puVar3 = puVar2;
    if (7 < (uint)puVar2[5]) {
      puVar3 = (undefined4 *)*puVar2;
    }
    if (7 < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    uVar4 = FUN_01686580();
    FUN_01685a20(puVar2,(int)puVar3 + iVar6 * 2,auStack_44,uVar4);
  }
  FUN_00558ce0(apppuStack_2c,auStack_44,&DAT_018bf1c0);
  uStack_8._0_1_ = 4;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_30) {
    uVar7 = uStack_30 + 1;
    uVar8 = auStack_44[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_44[0] - 4);
      uVar7 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  uStack_8._0_1_ = 5;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (7 < uStack_60) {
    uVar8 = uStack_60 * 2 + 2;
    uVar7 = auStack_74[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_74[0] - 4);
      uVar8 = uStack_60 * 2 + 0x25;
      if (0x1f < (auStack_74[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_64 = 0;
  uStack_60 = 7;
  auStack_74[0] = auStack_74[0] & 0xffff0000;
  uStack_4c = 0;
  uStack_48 = 7;
  uStack_5c = (uint)uStack_5c._2_2_ << 0x10;
  uStack_8._0_1_ = 6;
  if (iStack_1c != 0) {
    ppppuVar5 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar5 = (undefined4 ****)apppuStack_2c[0];
    }
    ppppuVar9 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar9 = (undefined4 ****)apppuStack_2c[0];
    }
    uVar4 = FUN_01686580();
    FUN_01685950(ppppuVar9,(int)ppppuVar5 + iStack_1c,&uStack_5c,uVar4);
  }
  uStack_8._0_1_ = 7;
  uVar4 = FUN_016888d0(&uStack_5c);
  puVar2 = (undefined4 *)FUN_005514a0(auStack_8c,uVar4);
  uStack_8._0_1_ = 8;
  if (&param_2 != puVar2) {
    puVar3 = puVar2 + 4;
    if (7 < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    FUN_0058ed10(puVar2,*puVar3);
  }
  uStack_8._0_1_ = 7;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (7 < uStack_78) {
    uVar8 = uStack_78 * 2 + 2;
    uVar7 = auStack_8c[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_8c[0] - 4);
      uVar8 = uStack_78 * 2 + 0x25;
      if (0x1f < (auStack_8c[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_7c = 0;
  uStack_78 = 7;
  auStack_8c[0] = auStack_8c[0] & 0xffff0000;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (7 < uStack_48) {
    uVar8 = uStack_48 * 2 + 2;
    iVar6 = uStack_5c;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(uStack_5c + -4);
      uVar8 = uStack_48 * 2 + 0x25;
      if (0x1f < (uStack_5c - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  FUN_0054f050(&param_2);
  if (0xf < uStack_18) {
    uVar8 = uStack_18 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar8) {
      ppppuVar5 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar8 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar8);
  }
  iStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  if (7 < in_stack_0000001c) {
    uVar8 = in_stack_0000001c * 2 + 2;
    iVar6 = param_2;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(param_2 + -4);
      uVar8 = in_stack_0000001c * 2 + 0x25;
      if (0x1f < (param_2 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25616 ; VA 0x00ba2f60 ; FUN_00ba2f60 */

undefined __thiscall FUN_00ba2f60(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined uVar4;
  int *piVar5;
  int aiStack_44 [3];
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017fbd88;
  pvStack_10 = ExceptionList;
  piStack_30 = (int *)(param_1 + 0xa0);
  uStack_8 = 0;
  uStack_7 = 0;
  piStack_34 = (int *)0xba2f96;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01686710();
  if (iVar3 != 0) {
    piStack_30 = (int *)param_2;
    piStack_34 = &iStack_20;
    uStack_38 = 0xba2faf;
    FUN_00ba3ff0();
    uStack_8 = 1;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    piStack_34 = (int *)iStack_20;
    piStack_30 = piStack_1c;
    uStack_38 = 0xba2fe2;
    cVar2 = FUN_00ba3190();
    piVar5 = piStack_1c;
    if (cVar2 == '\0') {
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      piStack_34 = (int *)iStack_20;
      piStack_30 = piStack_1c;
      uStack_38 = 0xba3015;
      FUN_00ba8200();
      piVar5 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          piStack_30 = (int *)0xba3036;
          (**(code **)*piStack_1c)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            piStack_30 = (int *)0xba304a;
            (**(code **)(*piVar5 + 4))();
            uVar4 = 0;
            goto LAB_00ba30cc;
          }
        }
      }
LAB_00ba317a:
      uVar4 = 0;
      goto LAB_00ba30cc;
    }
    uStack_8 = 0;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_30 = (int *)0xba3068;
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          piStack_30 = (int *)0xba3078;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  piVar5 = *(int **)(param_2 + 0x1c);
  piStack_14 = *(int **)(param_2 + 0x20);
  if (piVar5 != piStack_14) {
    do {
      if (piVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar5[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      piStack_34 = (int *)*piVar5;
      piStack_30 = (int *)piVar5[1];
      uStack_38 = 0xba30be;
      cVar2 = FUN_00ba2f60();
      if (cVar2 == '\0') {
        piStack_1c = aiStack_44;
        FUN_0054f050(param_2);
        FUN_00ba5030(&iStack_18);
        uStack_8 = 2;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        piStack_34 = (int *)iStack_18;
        piStack_30 = piStack_14;
        uStack_38 = 0xba3154;
        FUN_00ba8200();
        piVar5 = piStack_14;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_14[1] + -1;
          piStack_14[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            piStack_30 = (int *)0xba316a;
            (**(code **)*piStack_14)();
            LOCK();
            piVar1 = piVar5 + 2;
            iVar3 = *piVar1 + -1;
            *piVar1 = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              piStack_30 = (int *)0xba317a;
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        goto LAB_00ba317a;
      }
      piVar5 = piVar5 + 2;
    } while (piVar5 != piStack_14);
  }
  uVar4 = 1;
LAB_00ba30cc:
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      piStack_30 = (int *)0xba30e2;
      (**(code **)*param_3)();
      LOCK();
      piVar5 = param_3 + 2;
      iVar3 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_30 = (int *)0xba30f1;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 25617 ; VA 0x00ba3106 ; FUN_00ba3106 */

uint FUN_00ba3106(void)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int unaff_EBP;
  int unaff_EDI;
  undefined auStack_18 [12];
  undefined4 uStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  *(undefined **)(unaff_EBP + -0x18) = auStack_18;
  FUN_0054f050(*(undefined4 *)(unaff_EBP + 8));
  FUN_00ba5030(unaff_EBP + -0x14);
  *(undefined *)(unaff_EBP + -4) = 2;
  if (*(int *)(unaff_EBP + -0x10) != 0) {
    LOCK();
    piVar3 = (int *)(*(int *)(unaff_EBP + -0x10) + 4);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
  }
  uStack_8 = *(undefined4 *)(unaff_EBP + -0x14);
  uStack_4 = *(undefined4 *)(unaff_EBP + -0x10);
  uStack_c = 0xba3154;
  uVar6 = FUN_00ba8200();
  piVar3 = *(int **)(unaff_EBP + -0x10);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 1);
    uVar5 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar5 + unaff_EDI;
    UNLOCK();
    if (uVar5 + unaff_EDI == 0) {
      uStack_4 = 0xba316a;
      (**(code **)*piVar3)();
      LOCK();
      puVar1 = (uint *)(piVar3 + 2);
      uVar5 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar5 + unaff_EDI;
      UNLOCK();
      if (uVar5 + unaff_EDI == 0) {
        uStack_4 = 0xba317a;
        uVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(unaff_EBP + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 1);
    uVar5 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar5 + unaff_EDI;
    UNLOCK();
    if (uVar5 + unaff_EDI == 0) {
      uStack_4 = 0xba30e2;
      uVar6 = (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + unaff_EDI;
      UNLOCK();
      if (iVar4 == 1) {
        uStack_4 = 0xba30f1;
        uVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return uVar6 & 0xffffff00;
}



/* FUNCTION 25618 ; VA 0x00ba3190 ; FUN_00ba3190 */

undefined FUN_00ba3190(undefined4 ****param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 ****ppppuVar5;
  int *piVar6;
  char *pcStack_124;
  int *piStack_120;
  undefined4 ***pppuStack_11c;
  int *piStack_118;
  undefined4 ***pppuStack_114;
  undefined4 ***pppuStack_110;
  undefined auStack_100 [24];
  undefined auStack_e8 [24];
  undefined auStack_d0 [24];
  undefined auStack_b8 [24];
  int iStack_a0;
  int *piStack_9c;
  int aiStack_98 [6];
  undefined4 ***apppuStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  undefined4 ***apppuStack_68 [4];
  undefined4 ***pppuStack_58;
  uint uStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  undefined4 ***apppuStack_48 [4];
  int *piStack_38;
  uint uStack_34;
  undefined4 ***pppuStack_30;
  int *piStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fbe22;
  pvStack_10 = ExceptionList;
  pppuStack_110 = (undefined4 ***)&puStack_28;
  uStack_8 = 0;
  pppuStack_114 = (undefined4 ***)0xba31cc;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  pppuStack_110 = apppuStack_80;
  uStack_8._0_1_ = 1;
  pppuStack_114 = (undefined4 ***)0xba31dc;
  FUN_01688660();
  piStack_18 = (int *)&pcStack_124;
  uStack_8._0_1_ = 2;
  FUN_0054f050(apppuStack_80);
  FUN_00ba5030(auStack_50);
  pppuStack_110 = &pppuStack_30;
  pppuStack_114 = (undefined4 ***)0xba320b;
  FUN_00587490();
  uStack_8._0_1_ = 4;
  puStack_1c = puStack_28;
  piVar6 = piStack_24;
  if (puStack_28 == (undefined4 *)0x0) {
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    pppuStack_114 = param_1;
    pppuStack_110 = (undefined4 ***)param_2;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[1] = piStack_2c[1] + 1;
      UNLOCK();
    }
    pppuStack_11c = pppuStack_30;
    piStack_118 = piStack_2c;
    piStack_120 = &iStack_a0;
    pcStack_124 = (char *)0xba327b;
    puVar4 = (undefined4 *)FUN_00ba9760();
    puStack_28 = (undefined4 *)*puVar4;
    piVar6 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_18 = piStack_24;
    piVar2 = piVar6;
    puStack_1c = puStack_28;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_24[1] + -1;
      piStack_24[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        puVar4 = (undefined4 *)*piStack_24;
        pppuStack_110 = (undefined4 ***)0xba32ad;
        piStack_24 = piVar6;
        (*(code *)*puVar4)();
        LOCK();
        iVar1 = piStack_18[2] + -1;
        piStack_18[2] = iVar1;
        UNLOCK();
        piVar2 = piStack_24;
        if (iVar1 == 0) {
          pppuStack_110 = (undefined4 ***)0xba32be;
          (**(code **)(*piStack_18 + 4))();
          piVar2 = piStack_24;
        }
      }
    }
    piStack_24 = piVar2;
    piStack_18 = piStack_9c;
    if (piStack_9c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_9c[1] + -1;
      piStack_9c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        pppuStack_110 = (undefined4 ***)0xba32d8;
        (**(code **)*piStack_9c)();
        LOCK();
        iVar1 = piStack_18[2] + -1;
        piStack_18[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          pppuStack_110 = (undefined4 ***)0xba32e9;
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    if (puStack_1c != (undefined4 *)0x0) goto LAB_00ba32f5;
  }
  else {
LAB_00ba32f5:
    if ((undefined4 ****)puStack_1c[0xd] == (undefined4 ****)pppuStack_30) {
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      pppuStack_114 = param_1;
      pppuStack_110 = (undefined4 ***)param_2;
      piStack_118 = (int *)0xba3380;
      cVar3 = FUN_00ba5ba0();
      if (cVar3 != '\0') {
        pppuStack_110 = &param_1;
        pppuStack_114 = (undefined4 ***)aiStack_98;
        piStack_118 = (int *)0xba339b;
        FUN_00ba56f0();
        pppuStack_11c = apppuStack_48;
        piStack_118 = puStack_1c;
        uStack_8._0_1_ = 7;
        piStack_120 = (int *)0xba33ac;
        FUN_00ba5830();
        pppuStack_110 = (undefined4 ***)aiStack_98;
        pppuStack_114 = apppuStack_68;
        uStack_8._0_1_ = 8;
        piStack_118 = (int *)0xba33c6;
        FUN_00ba6150();
        pppuStack_110 = pppuStack_58;
        pppuStack_114 = apppuStack_68;
        if (0xf < uStack_54) {
          pppuStack_114 = apppuStack_68[0];
        }
        pppuStack_11c = apppuStack_48;
        if (0xf < uStack_34) {
          pppuStack_11c = apppuStack_48[0];
        }
        piStack_118 = piStack_38;
        uStack_8._0_1_ = 9;
        piStack_120 = (int *)0xba33ed;
        cVar3 = FUN_0055c360();
        if (cVar3 == '\0') {
          pppuStack_110 = (undefined4 ***)0x64;
          pppuStack_114 = (undefined4 ***)0x0;
          piStack_118 = (int *)auStack_100;
          pppuStack_11c = (undefined4 ***)0xba340b;
          puStack_1c = (undefined4 *)FUN_0058c540();
          uStack_8._0_1_ = 10;
          if (0xf < (uint)puStack_1c[5]) {
            puStack_1c = (undefined4 *)*puStack_1c;
          }
          pppuStack_110 = (undefined4 ***)0x64;
          pppuStack_114 = (undefined4 ***)0x0;
          piStack_118 = (int *)auStack_e8;
          pppuStack_11c = (undefined4 ***)0xba3430;
          piStack_18 = (int *)FUN_0058c540();
          uStack_8._0_1_ = 0xb;
          if (0xf < (uint)piStack_18[5]) {
            piStack_18 = (int *)*piStack_18;
          }
          pppuStack_110 = (undefined4 ***)auStack_d0;
          pppuStack_114 = (undefined4 ***)0xba3454;
          piStack_120 = (int *)FUN_005569d0();
          uStack_8._0_1_ = 0xc;
          if (0xf < (uint)piStack_120[5]) {
            piStack_120 = (int *)*piStack_120;
          }
          pppuStack_110 = (undefined4 ***)puStack_1c;
          pppuStack_114 = (undefined4 ***)piStack_38;
          piStack_118 = piStack_18;
          pppuStack_11c = pppuStack_58;
          pcStack_124 = 
          "Script content are different between file system and datamodel %s.\nFileSystem content: size %d, start with %s ......\nDataModel content: size %d, start with %s ......\n"
          ;
          pppuStack_110 = (undefined4 ***)FUN_01675640(auStack_b8);
          uStack_8._0_1_ = 0xd;
          pppuStack_114 = (undefined4 ****)0xba348e;
          FUN_00ba6cb0();
          pppuStack_110 = (undefined4 ***)0xba3499;
          FUN_005507b0();
          pppuStack_110 = (undefined4 ***)0xba34a4;
          FUN_005507b0();
          pppuStack_110 = (undefined4 ***)0xba34af;
          FUN_005507b0();
          pppuStack_110 = (undefined4 ***)0xba34ba;
          FUN_005507b0();
          pppuStack_110 = (undefined4 ***)0xba34c2;
          FUN_005507b0();
          pppuStack_110 = (undefined4 ***)0xba34ca;
          FUN_005507b0();
          pppuStack_110 = (undefined4 ***)0xba34d5;
          FUN_00550800();
          uStack_11 = 0;
          goto LAB_00ba34fa;
        }
        pppuStack_110 = (undefined4 ***)0xba34e3;
        FUN_005507b0();
        pppuStack_110 = (undefined4 ***)0xba34eb;
        FUN_005507b0();
        pppuStack_110 = (undefined4 ***)0xba34f6;
        FUN_00550800();
      }
      uStack_11 = 1;
      goto LAB_00ba34fa;
    }
    pppuStack_110 = apppuStack_48;
    pppuStack_114 = (undefined4 ***)0xba3309;
    pppuStack_110 = (undefined4 ***)FUN_005569d0();
    uStack_8._0_1_ = 5;
    if (0xf < pppuStack_110[5]) {
      pppuStack_110 = (undefined4 ***)*pppuStack_110;
    }
    piStack_118 = aiStack_98;
    pppuStack_114 = (undefined4 ***)0x195abf8;
    pppuStack_11c = (undefined4 ****)0xba3327;
    pppuStack_110 = (undefined4 ***)FUN_01675640();
    uStack_8._0_1_ = 6;
    pppuStack_114 = (undefined4 ****)0xba3337;
    FUN_00ba6cb0();
    pppuStack_110 = (undefined4 ***)0xba3342;
    FUN_005507b0();
    pppuStack_110 = (undefined4 ***)0xba334a;
    FUN_005507b0();
  }
  uStack_11 = 0;
LAB_00ba34fa:
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar1 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      pppuStack_110 = (undefined4 ***)0xba350d;
      (**(code **)*piStack_2c)();
      LOCK();
      iVar1 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        pppuStack_110 = (undefined4 ***)0xba351d;
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar1 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      pppuStack_110 = (undefined4 ***)0xba3533;
      (**(code **)*piStack_4c)();
      LOCK();
      iVar1 = piStack_4c[2] + -1;
      piStack_4c[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        pppuStack_110 = (undefined4 ***)0xba3543;
        (**(code **)(*piStack_4c + 4))();
      }
    }
  }
  if (7 < uStack_6c) {
    pppuStack_110 = (undefined4 ***)(uStack_6c * 2 + 2);
    ppppuVar5 = (undefined4 ****)apppuStack_80[0];
    if (0xfff < pppuStack_110) {
      ppppuVar5 = (undefined4 ****)apppuStack_80[0][-1];
      pppuStack_110 = (undefined4 ***)(uStack_6c * 2 + 0x25);
      if (0x1f < (uint)((int)apppuStack_80[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_110 = (undefined4 ***)&UNK_00ba35f0;
        FUN_017167a3();
      }
    }
    piStack_118 = (int *)0xba3576;
    pppuStack_114 = ppppuVar5;
    FUN_01674ea0();
  }
  uStack_70 = 0;
  uStack_6c = 7;
  apppuStack_80[0] = (undefined4 ***)((uint)apppuStack_80[0] & 0xffff0000);
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar1 = piVar6[1] + -1;
    piVar6[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      pppuStack_110 = (undefined4 ***)0xba35a0;
      (**(code **)*piVar6)();
      LOCK();
      iVar1 = piVar6[2] + -1;
      piVar6[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        pppuStack_110 = (undefined4 ***)0xba35b0;
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = param_2[1] + -1;
    param_2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      pppuStack_110 = (undefined4 ***)0xba35c6;
      (**(code **)*param_2)();
      LOCK();
      piVar2 = piVar6 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        pppuStack_110 = (undefined4 ***)0xba35d5;
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uStack_11;
}



/* FUNCTION 25619 ; VA 0x00ba3600 ; FUN_00ba3600 */

/* WARNING: Removing unreachable block (ram,0x00ba38da) */
/* WARNING: Removing unreachable block (ram,0x00ba38e8) */
/* WARNING: Removing unreachable block (ram,0x00ba3917) */
/* WARNING: Removing unreachable block (ram,0x00ba38f8) */

undefined4 * __thiscall FUN_00ba3600(int param_1,undefined4 *param_2,int param_3)

{
  int iVar1;
  bool bVar2;
  bool bVar3;
  char cVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piStack_24;
  int *piStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fbe70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)(**(code **)(**(int **)(param_1 + 0xb8) + 0x40))();
  bVar2 = false;
  uStack_8 = 0;
  if (*piVar5 != 0) {
    piVar5 = (int *)(**(code **)(**(int **)(param_1 + 0xb8) + 0x40))();
    bVar2 = true;
    bVar3 = false;
    if (*(int *)*piVar5 != ((int *)*piVar5)[1]) goto LAB_00ba366f;
  }
  bVar3 = true;
LAB_00ba366f:
  if ((bVar2) && (piStack_1c != (int *)0x0)) {
    LOCK();
    iVar1 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar1 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = 0xffffffff;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_24[1] + -1;
    piStack_24[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar1 = piStack_24[2] + -1;
      piStack_24[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if ((*(int *)(param_3 + 4) == 2) || (bVar3)) {
    FUN_00ba5960();
    FUN_00baf040();
    FUN_0054f050(param_1 + 0xa0);
    FUN_00ba71a0();
    FUN_00baf040();
  }
  else {
    FUN_00ba5960();
    FUN_00ba5eb0();
    uStack_8 = 1;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    cVar4 = FUN_00ba2f60();
    if (cVar4 == '\0') {
      FUN_00ba3ae0();
      uStack_8 = 0xffffffff;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar5 = piStack_1c + 2;
          iVar1 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      FUN_005542c0();
      uStack_8 = 2;
      FUN_006373b0();
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    FUN_00ba3920();
    uStack_8 = 0xffffffff;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar5 = piStack_1c + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  FUN_005542c0();
  uStack_8 = 3;
  *param_2 = 0;
  param_2[1] = 0;
  puVar6 = (undefined4 *)FUN_01674e20();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6[1] = 1;
    puVar6[2] = 1;
    *puVar6 = std::
              _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::vftable;
    FUN_0054ef60();
  }
  param_2[2] = puVar6 + 3;
  param_2[3] = puVar6;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25620 ; VA 0x00ba3920 ; FUN_00ba3920 */

int FUN_00ba3920(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_38 [24];
  int iStack_20;
  int *piStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fbe90;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_0054f050(param_1);
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    iStack_20 = param_1;
    piStack_1c = param_2;
    iStack_8._0_1_ = 1;
    iVar3 = FUN_00b75f50(auStack_38);
    FUN_00ba10e0(auStack_18,0,iVar3 + 0x10,iVar3);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    iVar3 = FUN_00ba2000();
    puVar2 = *(undefined4 **)(param_1 + 0x20);
    puVar4 = *(undefined4 **)(param_1 + 0x1c);
    param_1 = iVar3;
    for (; puVar4 != puVar2; puVar4 = puVar4 + 2) {
      if (puVar4[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar4[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      param_1 = FUN_00ba3920(*puVar4,puVar4[1]);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar3 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      param_1 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        param_1 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25621 ; VA 0x00ba3a20 ; FUN_00ba3a20 */

undefined FUN_00ba3a20(int param_1)

{
  int iVar1;
  undefined uVar2;
  int iVar3;
  undefined **appuStack_38 [9];
  undefined ***pppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fbea8;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00b9e640();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      pppuStack_14 = appuStack_38;
      appuStack_38[0] =
           std::
           _Func_impl_no_alloc<class_<lambda_4ae16a20a002de830f3417ef11801457>,bool,class_RBX::Instance*>
           ::vftable;
      uStack_8 = 0;
      uVar2 = FUN_00baa6e0(param_1,pppuStack_14,1,0);
      if (pppuStack_14 != (undefined ***)0x0) {
        (*(code *)(*pppuStack_14)[4])(pppuStack_14 != appuStack_38);
      }
      ExceptionList = pvStack_10;
      return uVar2;
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 25622 ; VA 0x00ba3ae0 ; FUN_00ba3ae0 */

void __fastcall FUN_00ba3ae0(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  void **ppvVar5;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fbec8;
  puVar2 = *(undefined4 **)(param_1 + 0x5c);
  puStack_14 = (undefined4 *)*puVar2;
  ppvVar5 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar5, puStack_14 != puVar2) {
    FUN_00587490(&uStack_1c);
    uStack_8 = 0;
    FUN_00baf060(param_1,uStack_1c);
    piVar4 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    FUN_00551320();
    ppvVar5 = (void **)ExceptionList;
  }
  iVar3 = *(int *)(param_1 + 0x54);
  uStack_8 = 1;
  FUN_00ba2910(*(undefined4 *)(iVar3 + 4));
  *(int *)(*(int *)(param_1 + 0x54) + 4) = iVar3;
  **(int **)(param_1 + 0x54) = iVar3;
  *(int *)(*(int *)(param_1 + 0x54) + 8) = iVar3;
  *(undefined4 *)(param_1 + 0x58) = 0;
  iVar3 = *(int *)(param_1 + 0x5c);
  uStack_8 = 2;
  FUN_00ba2880(*(undefined4 *)(iVar3 + 4));
  *(int *)(*(int *)(param_1 + 0x5c) + 4) = iVar3;
  **(int **)(param_1 + 0x5c) = iVar3;
  *(int *)(*(int *)(param_1 + 0x5c) + 8) = iVar3;
  *(undefined4 *)(param_1 + 0x60) = 0;
  iVar3 = *(int *)(param_1 + 100);
  uStack_8 = 3;
  FUN_00ba2910(*(undefined4 *)(iVar3 + 4));
  *(int *)(*(int *)(param_1 + 100) + 4) = iVar3;
  **(int **)(param_1 + 100) = iVar3;
  *(int *)(*(int *)(param_1 + 100) + 8) = iVar3;
  *(undefined4 *)(param_1 + 0x68) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25623 ; VA 0x00ba3c10 ; FUN_00ba3c10 */

undefined4 * FUN_00ba3c10(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_006346b0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 25624 ; VA 0x00ba3c80 ; FUN_00ba3c80 */

undefined4 * FUN_00ba3c80(undefined4 *param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_2 == 3) {
    puVar4 = (undefined4 *)FUN_00b742d0(auStack_c);
    *param_1 = *puVar4;
    uVar2 = puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    param_1[1] = uVar2;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_8 + 4))();
          return param_1;
        }
      }
    }
  }
  else {
    if (param_2 != 4) {
      if (param_2 == 2) {
        puVar4 = (undefined4 *)FUN_005c30b0(auStack_c);
        *param_1 = *puVar4;
        param_1[1] = puVar4[1];
        *puVar4 = 0;
        puVar4[1] = 0;
        FUN_00550b30();
        return param_1;
      }
      if (param_2 == 1) {
        puVar4 = (undefined4 *)FUN_00634770(auStack_c);
        *param_1 = *puVar4;
        param_1[1] = puVar4[1];
        *puVar4 = 0;
        puVar4[1] = 0;
        FUN_00550b30();
        return param_1;
      }
      *param_1 = 0;
      param_1[1] = 0;
      return param_1;
    }
    puVar4 = (undefined4 *)FUN_00b73ec0(auStack_c);
    *param_1 = *puVar4;
    uVar2 = puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    param_1[1] = uVar2;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return param_1;
}



/* FUNCTION 25625 ; VA 0x00ba3de0 ; FUN_00ba3de0 */

int * FUN_00ba3de0(int *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 uStack_3c;
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined auStack_24 [4];
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fbf2b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x34);
  puStack_1c = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puStack_20 = puVar4 + 3;
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::_Ref_count_obj<struct_RBX::FileSyncItem::InstanceMetadata>::vftable;
    puVar4[7] = 0;
    puVar4[8] = 7;
    *(undefined2 *)puStack_20 = 0;
    puVar4[9] = 0;
    puVar4[10] = 0;
    *(undefined *)(puVar4 + 0xb) = 0;
    uStack_8 = 3;
    puVar5 = (undefined4 *)FUN_0060e0c0(auStack_2c,param_2);
    uVar6 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    puVar4[9] = uVar6;
    piVar3 = (int *)puVar4[10];
    puVar4[10] = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar7 = piVar3[2] + -1;
      piVar3[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_28[2] + -1;
      piStack_28[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    uVar6 = FUN_00ba5240(param_2);
    puVar4[0xc] = uVar6;
  }
  *param_1 = (int)(puVar4 + 3);
  param_1[1] = (int)puVar4;
  uStack_8 = 0;
  uStack_14 = 3;
  if (param_1[1] != 0) {
    LOCK();
    piVar3 = (int *)(param_1[1] + 4);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
  }
  FUN_00ba9d80(*param_1,param_1[1]);
  puVar4 = (undefined4 *)FUN_0060e0c0(auStack_2c,param_2);
  uStack_3c = *puVar4;
  piStack_38 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  piStack_30 = (int *)param_1[1];
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piStack_30[1] = piStack_30[1] + 1;
    UNLOCK();
    piStack_30 = (int *)param_1[1];
  }
  iStack_34 = *param_1;
  uStack_8 = 5;
  iVar7 = FUN_00ba0940(&uStack_3c);
  FUN_00ba0f70(auStack_24,0,iVar7 + 0x10,iVar7);
  piVar3 = piStack_30;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_30[1] + -1;
    piStack_30[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_38[2] + -1;
    piStack_38[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)(*piStack_38 + 4))();
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_28 + 2;
    iVar7 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar7 == 1) {
      (**(code **)(*piStack_28 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25626 ; VA 0x00ba3ff0 ; FUN_00ba3ff0 */

int * FUN_00ba3ff0(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_3c [24];
  int iStack_24;
  int iStack_20;
  undefined auStack_1c [4];
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fbf61;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = (undefined4 *)FUN_01674e20(0x34);
  if (puStack_18 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puStack_18[1] = 1;
    puStack_18[2] = 1;
    *puStack_18 = std::_Ref_count_obj<struct_RBX::FileSyncItem::InstanceMetadata>::vftable;
    puStack_18[7] = 0;
    puStack_18[8] = 7;
    *(undefined2 *)(puStack_18 + 3) = 0;
    puStack_18[9] = 0;
    puStack_18[10] = 0;
    *(undefined *)(puStack_18 + 0xb) = 0;
    puStack_18[0xc] = 0;
    puVar3 = puStack_18;
  }
  *param_1 = (int)(puVar3 + 3);
  param_1[1] = (int)puVar3;
  uStack_8 = 0;
  uStack_14 = 3;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00ba9f10(*param_1,param_1[1],param_2);
  FUN_0054f050(param_2);
  iStack_20 = param_1[1];
  if (iStack_20 != 0) {
    LOCK();
    *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 1;
    UNLOCK();
    iStack_20 = param_1[1];
  }
  iStack_24 = *param_1;
  uStack_14 = 7;
  uStack_8 = 1;
  iVar2 = FUN_00b75f50(auStack_3c);
  FUN_00ba10e0(auStack_1c,0,iVar2 + 0x10,iVar2);
  FUN_00ba2000();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25627 ; VA 0x00ba4120 ; FUN_00ba4120 */

int FUN_00ba4120(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  uint uVar8;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fbf91;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iStack_8 = 0;
  cVar3 = *(char *)(param_1 + 8);
  ExceptionList = &pvStack_10;
  if (DAT_01ef2bac != '\0') {
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    uStack_20 = 0;
    uStack_1c = 0xf;
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    uStack_14 = 1;
    ExceptionList = &pvStack_10;
    if (param_1[4] != 0) {
      puVar4 = param_1;
      if (7 < (uint)param_1[5]) {
        puVar4 = (undefined4 *)*param_1;
      }
      iStack_18 = (int)puVar4 + param_1[4] * 2;
      puVar4 = param_1;
      if (7 < (uint)param_1[5]) {
        puVar4 = (undefined4 *)*param_1;
      }
      ExceptionList = &pvStack_10;
      uVar5 = FUN_01686580();
      FUN_01685a20(puVar4,iStack_18,apppuStack_30,uVar5);
    }
    ppppuVar7 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar7 = (undefined4 ****)apppuStack_30[0];
    }
    FUN_01677520(DAT_01ef2bac,"%s: path: %s, recursive: %d","RBX::FileSyncItem::removePath",
                 ppppuVar7,cVar3);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_1c) {
      uVar8 = uStack_1c + 1;
      ppppuVar7 = (undefined4 ****)apppuStack_30[0];
      if (0xfff < uVar8) {
        ppppuVar7 = (undefined4 ****)apppuStack_30[0][-1];
        uVar8 = uStack_1c + 0x24;
        if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar7,uVar8);
    }
  }
  if (cVar3 == '\0') {
    iVar6 = FUN_0168da40(param_1,&DAT_01ef1210);
  }
  else {
    iVar6 = FUN_0168db50();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 25628 ; VA 0x00ba4270 ; FUN_00ba4270 */

int __thiscall FUN_00ba4270(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  void **ppvVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fbfa8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ppvVar3 = &pvStack_10;
  if (param_2 != 0) {
    puVar8 = *(undefined4 **)(param_2 + 0x20);
    ExceptionList = &pvStack_10;
    for (puVar5 = *(undefined4 **)(param_2 + 0x1c); puVar5 != puVar8; puVar5 = puVar5 + 2) {
      if (puVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar5[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00ba4270(*puVar5,puVar5[1]);
    }
    puVar8 = (undefined4 *)(param_2 + 0x1c);
    FUN_005596d0(*puVar8,*(undefined4 *)(param_2 + 0x20),puVar8);
    *(undefined4 *)(param_2 + 0x20) = *puVar8;
    puVar8 = *(undefined4 **)(param_1 + 100);
    cVar2 = *(char *)((int)puVar8[1] + 0xd);
    puVar5 = puVar8;
    puVar6 = (undefined4 *)puVar8[1];
    iStack_14 = param_2;
    while (puStack_18 = puVar5, cVar2 == '\0') {
      iVar4 = FUN_01686710(iStack_14);
      if (iVar4 < 0) {
        puVar7 = (undefined4 *)puVar6[2];
      }
      else {
        if ((*(char *)((int)puVar8 + 0xd) != '\0') && (iVar4 = FUN_01686710(puVar6 + 4), iVar4 < 0))
        {
          puVar8 = puVar6;
        }
        puVar7 = (undefined4 *)*puVar6;
        puStack_18 = puVar6;
      }
      puVar5 = puStack_18;
      puVar6 = puVar7;
      cVar2 = *(char *)((int)puVar7 + 0xd);
    }
    puVar6 = puVar8;
    if (*(char *)((int)puVar8 + 0xd) != '\0') {
      puVar6 = (undefined4 *)(*(int *)(param_1 + 100) + 4);
    }
    cVar2 = *(char *)((int)*puVar6 + 0xd);
    puVar6 = (undefined4 *)*puVar6;
    while (puVar7 = puVar5, cVar2 == '\0') {
      iVar4 = FUN_01686710(puVar6 + 4);
      if (iVar4 < 0) {
        puVar7 = (undefined4 *)*puVar6;
        puVar8 = puVar6;
      }
      else {
        puVar7 = (undefined4 *)puVar6[2];
      }
      puVar6 = puVar7;
      cVar2 = *(char *)((int)puVar7 + 0xd);
    }
    while (puStack_18 = puVar7, puStack_18 != puVar8) {
      FUN_00551320();
      puVar7 = puStack_18;
    }
    param_2 = FUN_00ba4900(&puStack_18,puVar5,puVar8);
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar4 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25629 ; VA 0x00ba4400 ; FUN_00ba4400 */

int FUN_00ba4400(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  int *piStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fbfe0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00587490(&piStack_24);
  piVar4 = piStack_24;
  uStack_8._0_1_ = 1;
  if (piStack_24 != (int *)0x0) {
    (**(code **)(*piStack_24 + 0x40))(&piStack_34);
    uStack_8._0_1_ = 2;
    if (piStack_34 != (int *)0x0) {
      puVar3 = (undefined4 *)*piStack_34;
      puStack_18 = (undefined4 *)piStack_34[1];
      piVar4 = piStack_24;
      if (puVar3 != puStack_18) {
        do {
          FUN_00ba4f80(&iStack_2c,*puVar3);
          piVar4 = piStack_28;
          uStack_8._0_1_ = 3;
          if (iStack_2c != 0) {
            if (piStack_28 != (int *)0x0) {
              LOCK();
              piStack_28[1] = piStack_28[1] + 1;
              UNLOCK();
            }
            FUN_00ba4400(iStack_2c,piStack_28);
          }
          uStack_8._0_1_ = 2;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar2 = piVar4[1] + -1;
            piVar4[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piVar4)();
              LOCK();
              iVar2 = piVar4[2] + -1;
              piVar4[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          puVar3 = puVar3 + 2;
          piVar4 = piStack_24;
        } while (puVar3 != puStack_18);
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    FUN_00ba8200(param_1,param_2);
    iVar2 = FUN_00ba3a20(piVar4);
    if ((char)iVar2 != '\0') {
      iVar2 = (**(code **)(*piVar4 + 0x2c))();
    }
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_30 + 1;
      iVar1 = *piVar4;
      iVar2 = *piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar4 = piStack_30 + 2;
        iVar1 = *piVar4;
        iVar2 = *piVar4;
        *piVar4 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          iVar2 = (**(code **)(*piStack_30 + 4))();
        }
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_20 + 1;
    iVar1 = *piVar4;
    iVar2 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar4 = piStack_20 + 2;
      iVar1 = *piVar4;
      iVar2 = *piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar2 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar4 = param_2 + 1;
    iVar1 = *piVar4;
    iVar2 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar2 = (**(code **)*param_2)();
      LOCK();
      piVar4 = param_2 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar2 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 25630 ; VA 0x00ba45b0 ; FUN_00ba45b0 */

int FUN_00ba45b0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_3c [12];
  undefined4 uStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc000;
  pvStack_10 = ExceptionList;
  piStack_28 = (int *)param_1;
  uStack_8 = 0;
  iStack_2c = 0xba45de;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00ba5c20();
  if ((char)iVar3 == '\0') {
    puStack_14 = auStack_3c;
    FUN_0054f050(param_1);
    iVar3 = FUN_00ba5030(&iStack_1c);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iStack_1c != 0) {
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      iStack_2c = iStack_1c;
      piStack_28 = piStack_18;
      uStack_30 = 0xba463c;
      iVar3 = FUN_00ba4400();
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_28 = (int *)0xba4652;
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          piStack_28 = (int *)0xba4662;
          iVar3 = (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_28 = (int *)0xba4678;
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_28 = (int *)0xba4687;
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25631 ; VA 0x00ba46a0 ; FUN_00ba46a0 */

int FUN_00ba46a0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4ed0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00ba2420(param_2,param_3,param_4,param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25632 ; VA 0x00ba4780 ; FUN_00ba4780 */

void __thiscall FUN_00ba4780(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  void **ppvVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar3 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar3 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00ba2880(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar3, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    iVar4 = FUN_00553830(param_3);
    piVar1 = *(int **)(iVar4 + 0x1c);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piVar1 = *(int **)(iVar4 + 0x14);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    FUN_01674ea0(iVar4,0x20);
    ppvVar3 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25633 ; VA 0x00ba4880 ; FUN_00ba4880 */

void FUN_00ba4880(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  FUN_00551320();
  iVar4 = FUN_00553830(param_2);
  piVar2 = *(int **)(iVar4 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(iVar4 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_01674ea0(iVar4,0x20);
  *param_1 = param_2;
  return;
}



/* FUNCTION 25634 ; VA 0x00ba4900 ; FUN_00ba4900 */

void __thiscall FUN_00ba4900(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00ba2910(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    iVar3 = FUN_00553830(param_3);
    FUN_00ba1950(param_1,iVar3 + 0x10);
    FUN_01674ea0(iVar3,0x30);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25635 ; VA 0x00ba49d0 ; FUN_00ba49d0 */

void FUN_00ba49d0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  FUN_00551320();
  iVar4 = FUN_00553830(param_2);
  piVar2 = *(int **)(iVar4 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(iVar4,0x18);
  *param_1 = param_2;
  return;
}



/* FUNCTION 25636 ; VA 0x00ba4a40 ; FUN_00ba4a40 */

void __thiscall FUN_00ba4a40(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar1 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    puVar2 = (undefined4 *)puVar1[1];
    puVar4 = puVar1;
    do {
      if ((uint)puVar2[5] < *(uint *)(param_3 + 4)) {
        puVar3 = (undefined4 *)puVar2[2];
      }
      else {
        puVar3 = (undefined4 *)*puVar2;
        puVar4 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
    if ((puVar4 != puVar1) && ((uint)puVar4[5] <= *(uint *)(param_3 + 4))) {
      *param_2 = (int)puVar4;
      return;
    }
  }
  *param_2 = (int)puVar1;
  return;
}



/* FUNCTION 25637 ; VA 0x00ba4a90 ; FUN_00ba4a90 */

void __thiscall FUN_00ba4a90(int *param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar2 = (undefined4 *)*param_1;
  puVar3 = (undefined4 *)puVar2[1];
  puVar4 = puVar2;
  if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
    do {
      iVar1 = FUN_01686710(param_3);
      if (iVar1 < 0) {
        puVar2 = (undefined4 *)puVar3[2];
      }
      else {
        puVar2 = (undefined4 *)*puVar3;
        puVar4 = puVar3;
      }
      puVar3 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
    puVar2 = (undefined4 *)*param_1;
  }
  if ((puVar4 != puVar2) && (iVar1 = FUN_01686710(puVar4 + 4), -1 < iVar1)) {
    *param_2 = (int)puVar4;
    return;
  }
  *param_2 = *param_1;
  return;
}



/* FUNCTION 25638 ; VA 0x00ba4b10 ; FUN_00ba4b10 */

undefined4 __thiscall FUN_00ba4b10(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined auStack_b0 [160];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c07b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0xd0) = 0;
  FUN_00565940(3,1);
  puVar1 = *(undefined4 **)(param_1 + 200);
  uStack_8 = 0;
  for (puVar2 = (undefined4 *)*puVar1; puVar2 != puVar1; puVar2 = (undefined4 *)*puVar2) {
    piVar3 = puVar2 + 2;
    if (0xf < (uint)puVar2[7]) {
      piVar3 = (int *)*piVar3;
    }
    uVar4 = FUN_0055b3b0(auStack_b0,piVar3,puVar2[6]);
    puVar5 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar5 = (undefined4 *)*param_3;
    }
    FUN_0055b3b0(uVar4,puVar5,param_3[4]);
  }
  FUN_0058c4d0(param_2);
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25639 ; VA 0x00ba4bd0 ; FUN_00ba4bd0 */

undefined4 __fastcall FUN_00ba4bd0(int param_1)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  undefined auStack_8c [24];
  undefined auStack_74 [24];
  undefined auStack_5c [16];
  int iStack_4c;
  undefined auStack_44 [16];
  int iStack_34;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc0a0;
  pvStack_10 = ExceptionList;
  uVar5 = 0;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  piVar3 = (int *)FUN_00ba1b90(param_1);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x40))(&piStack_2c);
    uStack_8._0_1_ = 0;
    uStack_8._1_3_ = 0;
    if (piStack_2c != (int *)0x0) {
      piStack_24 = (int *)*piStack_2c;
      piVar3 = (int *)piStack_2c[1];
      piStack_18 = piVar3;
      if (piStack_24 != piVar3) {
        do {
          iVar8 = *piStack_24;
          if ((((iVar8 != 0) &&
               (iVar1 = *(int *)(iVar8 + 0xc), iVar4 = FUN_00ba0840(), iVar7 = iStack_1c,
               piVar3 = piStack_18,
               (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
               (uint)*(ushort *)(iVar4 + 0x1da))) && (iVar8 != iStack_1c)) &&
             (*(char *)(iVar8 + 0x9c) != '\0')) {
            iVar8 = iVar8 + 0x7c;
            FUN_0151a940(auStack_5c,iVar8);
            uVar6 = uVar5 | 5;
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            iVar7 = iVar7 + 0x7c;
            uStack_20 = uVar6;
            if (iStack_4c == 0) {
LAB_00ba4cc9:
              cStack_11 = '\0';
            }
            else {
              FUN_0151a940(auStack_44,iVar7);
              cStack_11 = '\x01';
              uVar6 = uVar5 | 0xf;
              if (iStack_34 == 0) goto LAB_00ba4cc9;
            }
            if ((uVar6 & 2) != 0) {
              uVar6 = uVar6 & 0xfffffffd;
              FUN_005507b0();
            }
            uStack_8._0_1_ = 0;
            uStack_8._1_3_ = 0;
            uStack_20 = uVar6 & 0xfffffffe;
            FUN_005507b0();
            piVar3 = piStack_18;
            uVar5 = uVar6 & 0xfffffffe;
            if (cStack_11 != '\0') {
              FUN_0151a940(auStack_44,iVar7);
              uStack_8._0_1_ = 2;
              FUN_0151a940(auStack_5c,iVar8);
              cVar2 = FUN_00558b30(auStack_5c,auStack_44);
              FUN_005507b0();
              uStack_8._0_1_ = 0;
              FUN_005507b0();
              if (cVar2 != '\0') {
                FUN_0151a940(auStack_8c,iVar8);
                uStack_8 = CONCAT31(uStack_8._1_3_,3);
LAB_00ba4eea:
                FUN_00ba6cb0(auStack_8c);
                FUN_005507b0();
                FUN_00550b30();
                ExceptionList = pvStack_10;
                return 1;
              }
              FUN_0151a940(auStack_8c,iVar7);
              uStack_8._0_1_ = 4;
              FUN_00558140(auStack_8c,0);
              uStack_8._0_1_ = 5;
              FUN_0151a940(auStack_44,iVar8);
              uStack_8._0_1_ = 6;
              FUN_00558140(auStack_44,0);
              uStack_8._0_1_ = 7;
              cVar2 = FUN_00ba6b30(auStack_5c,auStack_74);
              FUN_00550800();
              FUN_005507b0();
              FUN_00550800();
              uStack_8._0_1_ = 0;
              FUN_005507b0();
              if (cVar2 != '\0') {
                FUN_0151a940(auStack_8c,iVar8);
                uStack_8 = CONCAT31(uStack_8._1_3_,8);
                goto LAB_00ba4eea;
              }
              FUN_0151a940(auStack_44,iVar8);
              uStack_8._0_1_ = 9;
              FUN_00558140(auStack_44,0);
              uStack_8._0_1_ = 10;
              FUN_0151a940(auStack_74,iVar7);
              uStack_20 = uStack_20 | 0xdb0;
              uStack_8._0_1_ = 0xb;
              FUN_00558140(auStack_74,0);
              uStack_8._0_1_ = 0xc;
              cVar2 = FUN_00ba6b30(auStack_8c,auStack_5c);
              FUN_00550800();
              FUN_005507b0();
              FUN_00550800();
              uStack_8._0_1_ = 0;
              FUN_005507b0();
              piVar3 = piStack_18;
              uVar5 = uStack_20;
              if (cVar2 != '\0') {
                FUN_0151a940(auStack_8c,iVar8);
                uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
                goto LAB_00ba4eea;
              }
            }
          }
          piStack_24 = piStack_24 + 2;
        } while (piStack_24 != piVar3);
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_28[1] + -1;
      piStack_28[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar3 = piStack_28 + 2;
        iVar8 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 25640 ; VA 0x00ba4f20 ; FUN_00ba4f20 */

undefined __fastcall FUN_00ba4f20(int param_1)

{
  return *(undefined *)(param_1 + 0x9d);
}



/* FUNCTION 25641 ; VA 0x00ba4f30 ; FUN_00ba4f30 */

void FUN_00ba4f30(void)

{
  int iVar1;
  
  if (DAT_01ef2eb4 == 0) {
    iVar1 = FUN_00ba0840();
    DAT_01ef2eb4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 25642 ; VA 0x00ba4f60 ; FUN_00ba4f60 */

undefined4 __thiscall FUN_00ba4f60(int param_1,undefined4 param_2)

{
  FUN_0151a940(param_2,param_1 + 0x7c);
  return param_2;
}



/* FUNCTION 25643 ; VA 0x00ba4f80 ; FUN_00ba4f80 */

undefined4 * __thiscall FUN_00ba4f80(int param_1,undefined4 *param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_3 == 0) {
    *param_2 = 0;
    param_2[1] = 0;
    return param_2;
  }
  FUN_0060e0c0(auStack_c,param_3);
  FUN_00ba4a40(&param_3,auStack_c);
  iVar2 = *(int *)(param_1 + 0x5c);
  *param_2 = 0;
  param_2[1] = 0;
  if (param_3 == iVar2) {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  else {
    iVar2 = *(int *)(param_3 + 0x1c);
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
      UNLOCK();
      iVar2 = *(int *)(param_3 + 0x1c);
    }
    uVar1 = *(undefined4 *)(param_3 + 0x18);
    param_2[1] = iVar2;
    *param_2 = uVar1;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
        return param_2;
      }
    }
  }
  return param_2;
}



/* FUNCTION 25644 ; VA 0x00ba5030 ; FUN_00ba5030 */

undefined4 * __thiscall FUN_00ba5030(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fc0c0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00ba5c20(&stack0x00000008);
  if (cVar2 != '\0') {
    puVar3 = (undefined4 *)FUN_01688660(auStack_2c);
    iStack_8._0_1_ = 1;
    if ((undefined4 *)&stack0x00000008 != puVar3) {
      puVar1 = puVar3 + 4;
      if (7 < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_0058ed10(puVar3,*puVar1);
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_00550800();
  }
  FUN_00ba4a90(&iStack_14,&stack0x00000008);
  iVar4 = *(int *)(param_1 + 0x54);
  *param_2 = 0;
  param_2[1] = 0;
  if (iStack_14 != iVar4) {
    iVar4 = *(int *)(iStack_14 + 0x2c);
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = *(int *)(iStack_14 + 0x2c);
    }
    *param_2 = *(undefined4 *)(iStack_14 + 0x28);
    param_2[1] = iVar4;
  }
  FUN_00550800();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25645 ; VA 0x00ba5100 ; FUN_00ba5100 */

undefined4 FUN_00ba5100(undefined4 param_1,int param_2,int *param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined auStack_70 [24];
  undefined auStack_58 [24];
  undefined auStack_40 [24];
  undefined4 auStack_28 [6];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc100;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int *)(param_2 + 0x24) == 1) {
    ExceptionList = &pvStack_10;
    uVar4 = FUN_01686c70(auStack_58);
    uStack_8._0_1_ = 1;
    FUN_0151a940(param_1,uVar4);
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_01686c70(auStack_70);
    uStack_8._0_1_ = 2;
    FUN_0054d730(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 3;
    uVar4 = FUN_01688950(auStack_40);
    FUN_0054f050(uVar4);
    FUN_00550800();
    uStack_8._0_1_ = 6;
    FUN_00550800();
    if (*(int *)(param_2 + 0x24) != 2) {
      FUN_0054d730(&DAT_018bc9b8,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      puVar5 = (undefined4 *)FUN_01688950(auStack_58);
      if (auStack_28 != puVar5) {
        puVar1 = puVar5 + 4;
        if (7 < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        FUN_0058ed10(puVar5,*puVar1);
      }
      uStack_8._0_1_ = 6;
      FUN_00550800();
    }
    FUN_0151a940(param_1,auStack_28);
  }
  FUN_00550800();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25646 ; VA 0x00ba5240 ; FUN_00ba5240 */

undefined FUN_00ba5240(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    iVar1 = FUN_00b739e0();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      return 4;
    }
    iVar2 = *(int *)(param_1 + 0xc);
    iVar1 = FUN_009ec190();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      return 2;
    }
    iVar2 = *(int *)(param_1 + 0xc);
    iVar1 = FUN_00b73ae0();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      return 3;
    }
  }
  iVar2 = FUN_00b76790(param_1);
  return iVar2 != 0;
}



/* FUNCTION 25647 ; VA 0x00ba52f0 ; FUN_00ba52f0 */

undefined4 FUN_00ba52f0(int param_1)

{
  char ***pppcVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  char ****ppppcVar5;
  int iVar6;
  char *pcVar7;
  uint uVar8;
  int iVar9;
  uint in_stack_00000018;
  undefined auStack_60 [24];
  undefined auStack_48 [24];
  char ***apppcStack_30 [4];
  int iStack_20;
  uint uStack_1c;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc128;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_0168e1c0(auStack_18,&param_1,&DAT_01ef1210);
  iStack_14 = piVar3[1];
  if ((*piVar3 != 0) && (*piVar3 != 1)) {
    piVar3 = (int *)FUN_0168e1c0(auStack_18,&param_1,&DAT_01ef1210);
    if (*piVar3 == 3) {
      uVar4 = 1;
      goto LAB_00ba54c2;
    }
    cVar2 = FUN_00ba5d40(&param_1);
    if (cVar2 != '\0') {
      FUN_0054d730(&DAT_018bc9b8,0);
      uStack_8._0_1_ = 1;
      FUN_01688950(auStack_48);
      uVar4 = FUN_01686b00(auStack_60);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_0151a940(apppcStack_30,uVar4);
      FUN_00550800();
      FUN_00550800();
      ppppcVar5 = apppcStack_30;
      if (0xf < uStack_1c) {
        ppppcVar5 = (char ****)apppcStack_30[0];
      }
      iVar9 = 0;
      iVar6 = ((int)ppppcVar5 + iStack_20) - (int)ppppcVar5;
      if ((char ****)((int)ppppcVar5 + iStack_20) < ppppcVar5) {
        iVar6 = 0;
      }
      if (iVar6 != 0) {
        do {
          cVar2 = FUN_01725677((int)*(char *)ppppcVar5);
          iVar9 = iVar9 + 1;
          *(char *)ppppcVar5 = cVar2;
          ppppcVar5 = (char ****)((int)ppppcVar5 + 1);
        } while (iVar9 != iVar6);
      }
      pppcVar1 = apppcStack_30[0];
      pcVar7 = PTR_DAT_01d67998;
      do {
        cVar2 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar2 != '\0');
      ppppcVar5 = apppcStack_30;
      if (0xf < uStack_1c) {
        ppppcVar5 = (char ****)apppcStack_30[0];
      }
      cVar2 = FUN_0055c360(ppppcVar5,iStack_20,PTR_DAT_01d67998,
                           (int)pcVar7 - (int)(PTR_DAT_01d67998 + 1));
      if (cVar2 == '\0') {
        pcVar7 = PTR_DAT_01d6799c;
        do {
          cVar2 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar2 != '\0');
        ppppcVar5 = apppcStack_30;
        if (0xf < uStack_1c) {
          ppppcVar5 = (char ****)pppcVar1;
        }
        cVar2 = FUN_0055c360(ppppcVar5,iStack_20,PTR_DAT_01d6799c,
                             (int)pcVar7 - (int)(PTR_DAT_01d6799c + 1));
        uVar4 = 4;
        if (cVar2 == '\0') {
          uVar4 = 2;
        }
      }
      else {
        uVar4 = 3;
      }
      if (0xf < uStack_1c) {
        uVar8 = uStack_1c + 1;
        ppppcVar5 = (char ****)pppcVar1;
        if (0xfff < uVar8) {
          ppppcVar5 = (char ****)pppcVar1[-1];
          uVar8 = uStack_1c + 0x24;
          if ((char *)0x1f < (char *)((int)pppcVar1 + (-4 - (int)ppppcVar5))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppcVar5,uVar8);
      }
      iStack_20 = 0;
      uStack_1c = 0xf;
      apppcStack_30[0] = (char ***)((uint)apppcStack_30[0] & 0xffffff00);
      goto LAB_00ba54c2;
    }
  }
  uVar4 = 0;
LAB_00ba54c2:
  if (7 < in_stack_00000018) {
    uVar8 = in_stack_00000018 * 2 + 2;
    iVar6 = param_1;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(param_1 + -4);
      uVar8 = in_stack_00000018 * 2 + 0x25;
      if (0x1f < (param_1 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 25648 ; VA 0x00ba5520 ; FUN_00ba5520 */

int * FUN_00ba5520(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc159;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ba4f80(param_1,param_2);
  uStack_8 = 0;
  uStack_14 = 1;
  if (*param_1 == 0) {
    piVar3 = (int *)FUN_00ba3de0(auStack_1c,param_2);
    iVar1 = *piVar3;
    iVar2 = piVar3[1];
    *piVar3 = 0;
    piVar3[1] = 0;
    *param_1 = iVar1;
    piVar3 = (int *)param_1[1];
    param_1[1] = iVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar1 = piVar3[1] + -1;
      piVar3[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar1 = piVar3[2] + -1;
        piVar3[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_18[1] + -1;
      piStack_18[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar3 = piStack_18 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25649 ; VA 0x00ba5600 ; FUN_00ba5600 */

int * FUN_00ba5600(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int aiStack_40 [3];
  undefined4 uStack_34;
  undefined *puStack_30;
  undefined4 uStack_2c;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc159;
  pvStack_10 = ExceptionList;
  piStack_18 = aiStack_40;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054f050(param_2);
  FUN_00ba5030(param_1);
  uStack_8 = 0;
  uStack_14 = 1;
  if (*param_1 == 0) {
    uStack_2c = param_2;
    puStack_30 = auStack_1c;
    uStack_34 = 0xba5669;
    piVar4 = (int *)FUN_00ba3ff0();
    iVar2 = *piVar4;
    iVar3 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *param_1 = iVar2;
    piVar4 = (int *)param_1[1];
    param_1[1] = iVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar2 = piVar4[1] + -1;
      piVar4[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_2c = 0xba5699;
        (**(code **)*piVar4)();
        LOCK();
        iVar2 = piVar4[2] + -1;
        piVar4[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          uStack_2c = 0xba56a9;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_2c = 0xba56bf;
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          uStack_2c = 0xba56ce;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25650 ; VA 0x00ba56f0 ; FUN_00ba56f0 */

undefined2 * FUN_00ba56f0(undefined2 *param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined auStack_58 [24];
  undefined4 auStack_40 [6];
  undefined2 auStack_28 [8];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc190;
  pvStack_10 = ExceptionList;
  if (*(int *)(*param_2 + 0x10) != 0) {
    ExceptionList = &pvStack_10;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      ExceptionList = &pvStack_10;
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    cVar4 = FUN_00ba5ba0(*param_2,param_2[1]);
    if (cVar4 != '\0') {
      FUN_0054f050(*param_2);
      puVar3 = PTR_s_init_lua_01d679a0;
      iStack_8 = 0;
      if (*(char *)(*param_2 + 0x20) != '\0') {
        uStack_18 = 0;
        uStack_14 = 7;
        auStack_28[0] = 0;
        iStack_8._0_1_ = 1;
        iStack_8._1_3_ = 0;
        uVar5 = FUN_01686580();
        FUN_01685950(puVar3,0,auStack_28,uVar5);
        iStack_8._0_1_ = 2;
        puVar6 = (undefined4 *)FUN_005514a0(auStack_58,auStack_40,auStack_28);
        iStack_8._0_1_ = 3;
        if (auStack_40 != puVar6) {
          puVar2 = puVar6 + 4;
          if (7 < (uint)puVar6[5]) {
            puVar6 = (undefined4 *)*puVar6;
          }
          FUN_0058ed10(puVar6,*puVar2);
        }
        FUN_00550800();
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_00550800();
      }
      FUN_0054f050(auStack_40);
      FUN_00550800();
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 10) = 7;
  *param_1 = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25651 ; VA 0x00ba5830 ; FUN_00ba5830 */

undefined * FUN_00ba5830(undefined *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_009ec190();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      FUN_009ed300(auStack_18);
      uStack_8 = 0;
      uVar3 = FUN_00a33fa0();
      FUN_0054ef60(uVar3);
      FUN_0056e380();
      FUN_0056e380();
      ExceptionList = pvStack_10;
      return param_1;
    }
    iVar1 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_00b73ae0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      FUN_00b74d90();
      uVar3 = FUN_00a33fa0();
      FUN_0054ef60(uVar3);
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25652 ; VA 0x00ba5960 ; FUN_00ba5960 */

int __fastcall FUN_00ba5960(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc1d9;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  piVar2 = (int *)FUN_0168e1c0(&uStack_40,param_1 + 0xa0,&DAT_01ef1210);
  iVar4 = piVar2[1];
  if ((*piVar2 == 3) && (*(int *)(param_1 + 0xb8) != 0)) {
    piStack_3c = (int *)iVar4;
    FUN_00ba5600(&uStack_30,param_1 + 0xa0);
    uVar3 = *(undefined4 *)(param_1 + 0xb8);
    uStack_8 = 0;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[1] = piStack_2c[1] + 1;
      UNLOCK();
    }
    FUN_00baa070(uStack_30,piStack_2c,uVar3);
    FUN_00bae9a0(param_1,*(undefined4 *)(param_1 + 0xb8));
    FUN_0060e0c0(&uStack_38,param_1);
    iStack_18 = *(int *)(param_1 + 0xb8) + 0x48;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[2] = piStack_34[2] + 1;
      UNLOCK();
    }
    uStack_40 = uStack_38;
    piStack_3c = piStack_34;
    uStack_8._0_1_ = 3;
    uVar3 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 4;
    uStack_24 = uVar3;
    puStack_28 = (undefined4 *)FUN_01674e20(0x20);
    if (puStack_28 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puStack_28 = 0;
      puStack_28[1] = 1;
      puStack_28[2] = FUN_00ba46a0;
      puStack_28[3] = FUN_005d3660;
      puStack_28[4] = 0;
      puStack_28[5] = iStack_18;
      puStack_28[6] = 0;
      puStack_28[7] = 0;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        piStack_34[2] = piStack_34[2] + 1;
        UNLOCK();
      }
      puStack_28[6] = uStack_38;
      puStack_28[7] = piStack_34;
      puVar5 = puStack_28;
    }
    FUN_016797d0(puVar5);
    if (puVar5 != (undefined4 *)0x0) {
      LOCK();
      puVar5[1] = puVar5[1] + 1;
      UNLOCK();
    }
    uStack_1c = 2;
    uStack_8._0_1_ = 5;
    puStack_14 = puVar5;
    FUN_01675290(uVar3);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar4 = FUN_01679300(&puStack_14);
    if ((char)iVar4 != '\0') {
      FUN_01679490();
      iVar4 = FUN_016791c0(&puStack_14);
    }
    if (puStack_14 != (undefined4 *)0x0) {
      piVar2 = puStack_14 + 1;
      LOCK();
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      iVar4 = iVar4 + -1;
      if (iVar4 == 0) {
        iVar4 = FUN_01674ea0(puStack_14);
      }
    }
    if (piStack_34 != (int *)0x0) {
      piVar2 = piStack_34 + 2;
      LOCK();
      iVar4 = *piVar2;
      *piVar2 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
      LOCK();
      iVar1 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_34 + 4))();
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piVar2 = piStack_2c + 1;
      iVar1 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar4 = (**(code **)*piStack_2c)();
        LOCK();
        piVar2 = piStack_2c + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          iVar4 = (**(code **)(*piStack_2c + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 25653 ; VA 0x00ba5ba0 ; FUN_00ba5ba0 */

undefined FUN_00ba5ba0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  
  iVar2 = *(int *)(param_1 + 0x24);
  if (((iVar2 == 2) || (iVar2 == 3)) || (iVar2 == 4)) {
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
    return uVar3;
  }
  return uVar3;
}



/* FUNCTION 25654 ; VA 0x00ba5c00 ; FUN_00ba5c00 */

bool FUN_00ba5c00(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00ba5240(param_1);
  return iVar1 != 0;
}



/* FUNCTION 25655 ; VA 0x00ba5c20 ; FUN_00ba5c20 */

bool FUN_00ba5c20(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = PTR_s_init_lua_01d679a0;
  puStack_c = &LAB_017fc208;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 7;
  auStack_28[0] = auStack_28[0] & 0xffff0000;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01686580();
  FUN_01685950(puVar1,0,auStack_28,uVar2);
  uStack_8 = 1;
  FUN_01686c70(auStack_40);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar3 = FUN_01686710(auStack_28);
  if (7 < uStack_2c) {
    uVar5 = uStack_2c * 2 + 2;
    uVar4 = auStack_40[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_40[0] - 4);
      uVar5 = uStack_2c * 2 + 0x25;
      if (0x1f < (auStack_40[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_30 = 0;
  uStack_2c = 7;
  auStack_40[0] = auStack_40[0] & 0xffff0000;
  if (7 < uStack_14) {
    uVar5 = uStack_14 * 2 + 2;
    uVar4 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 * 2 + 0x25;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar3 == 0;
}



/* FUNCTION 25656 ; VA 0x00ba5d40 ; FUN_00ba5d40 */

undefined FUN_00ba5d40(void)

{
  char cVar1;
  undefined4 uVar2;
  char ****ppppcVar3;
  int iVar4;
  uint uVar5;
  char ****ppppcVar6;
  int iVar7;
  int aiStack_48 [5];
  uint uStack_34;
  char ***apppcStack_30 [4];
  int iStack_20;
  uint uStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc228;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01686b00(aiStack_48);
  uStack_8 = 0;
  FUN_0151a940(apppcStack_30,uVar2);
  if (7 < uStack_34) {
    uVar5 = uStack_34 * 2 + 2;
    iVar4 = aiStack_48[0];
    if (0xfff < uVar5) {
      iVar4 = *(int *)(aiStack_48[0] + -4);
      uVar5 = uStack_34 * 2 + 0x25;
      if (0x1f < (aiStack_48[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ppppcVar3 = apppcStack_30;
  if (0xf < uStack_1c) {
    ppppcVar3 = (char ****)apppcStack_30[0];
  }
  ppppcVar6 = apppcStack_30;
  if (0xf < uStack_1c) {
    ppppcVar6 = (char ****)apppcStack_30[0];
  }
  iVar4 = ((int)ppppcVar3 + iStack_20) - (int)ppppcVar6;
  iVar7 = 0;
  if ((char ****)((int)ppppcVar3 + iStack_20) < ppppcVar6) {
    iVar4 = 0;
  }
  if (iVar4 != 0) {
    do {
      cVar1 = FUN_01725677((int)*(char *)ppppcVar6);
      iVar7 = iVar7 + 1;
      *(char *)ppppcVar6 = cVar1;
      ppppcVar6 = (char ****)((int)ppppcVar6 + 1);
    } while (iVar7 != iVar4);
  }
  ppppcVar3 = apppcStack_30;
  if (0xf < uStack_1c) {
    ppppcVar3 = (char ****)apppcStack_30[0];
  }
  uStack_11 = FUN_0055c360(ppppcVar3,iStack_20,&DAT_018bf1c0,4);
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    ppppcVar3 = (char ****)apppcStack_30[0];
    if (0xfff < uVar5) {
      ppppcVar3 = (char ****)((char ****)apppcStack_30[0])[-1];
      uVar5 = uStack_1c + 0x24;
      if ((char *)0x1f < (char *)((int)apppcStack_30[0] + (-4 - (int)ppppcVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppcVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return uStack_11;
}



/* FUNCTION 25657 ; VA 0x00ba5e70 ; FUN_00ba5e70 */

uint FUN_00ba5e70(void)

{
  int iVar1;
  
  iVar1 = FUN_00ba0840();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 25658 ; VA 0x00ba5e90 ; FUN_00ba5e90 */

uint FUN_00ba5e90(void)

{
  int iVar1;
  
  iVar1 = FUN_00ba0840();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 25659 ; VA 0x00ba5eb0 ; FUN_00ba5eb0 */

undefined4 * FUN_00ba5eb0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 uStack_30;
  int iStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc270;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_0168e1c0(&uStack_30,param_2,&DAT_01ef1210);
  iStack_2c = piVar4[1];
  if ((*piVar4 != 0) && (*piVar4 != 1)) {
    piVar4 = (int *)FUN_0168e1c0(&uStack_30,param_2,&DAT_01ef1210);
    iStack_2c = piVar4[1];
    if (*piVar4 == 3) {
      FUN_00ba1ca0(&puStack_28);
      uStack_8 = 0;
      if (puStack_28 != param_2) {
        puVar5 = param_2;
        if (7 < (uint)param_2[5]) {
          puVar5 = (undefined4 *)*param_2;
        }
        FUN_0058ed10(puVar5,param_2[4]);
      }
      *(undefined *)(puStack_28 + 6) = 1;
      uStack_30 = 0;
      iStack_2c = 0;
      uStack_8._0_1_ = 1;
      piStack_14 = (int *)FUN_01674e20(0x2c);
      if (piStack_14 == (int *)0x0) {
        piVar4 = (int *)0x0;
      }
      else {
        piStack_14[4] = 0;
        piStack_14[5] = 7;
        *(undefined2 *)piStack_14 = 0;
        piStack_14[6] = 0;
        piStack_14[7] = 0xffff;
        piStack_14[8] = 0;
        piStack_14[9] = 0xffff;
        piStack_14[10] = 0;
        piVar4 = piStack_14;
      }
      FUN_00632a90(piVar4);
      uStack_8._0_1_ = 2;
      FUN_0168c2c0(&iStack_20,param_2,0);
      uStack_8._0_1_ = 3;
      while (iStack_20 != 0) {
        FUN_00ba5eb0(&iStack_18,iStack_20);
        uStack_8._0_1_ = 4;
        if (iStack_18 != 0) {
          piVar4 = (int *)puStack_28[8];
          if ((int *)puStack_28[9] == piVar4) {
            FUN_00ba09b0(piVar4,&iStack_18);
          }
          else {
            *piVar4 = 0;
            piVar4[1] = 0;
            if (piStack_14 != (int *)0x0) {
              LOCK();
              piStack_14[1] = piStack_14[1] + 1;
              UNLOCK();
            }
            *piVar4 = iStack_18;
            piVar4[1] = (int)piStack_14;
            puStack_28[8] = puStack_28[8] + 8;
          }
        }
        piVar4 = piStack_14;
        uStack_8._0_1_ = 3;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_14[1] + -1;
          piStack_14[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1 + -1;
            *piVar1 = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        FUN_0168c5c0(&iStack_20,0);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar2 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_1c + 4))();
          LOCK();
          piVar4 = piStack_1c + 2;
          iVar2 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_1c + 8))();
          }
        }
      }
      *param_1 = puStack_28;
      param_1[1] = uStack_24;
      ExceptionList = pvStack_10;
      return param_1;
    }
    cVar3 = FUN_00ba5d40(param_2);
    if (((cVar3 != '\0') &&
        (piVar4 = (int *)FUN_0168e1c0(&uStack_30,param_2,&DAT_01ef1210), *piVar4 == 2)) &&
       (cVar3 = FUN_00ba5c20(param_2), cVar3 == '\0')) {
      FUN_00ba1ca0(&iStack_20);
      uStack_8 = 7;
      FUN_0058dd00(param_2);
      FUN_00557f90(&iStack_20);
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  *param_1 = 0;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25660 ; VA 0x00ba6150 ; FUN_00ba6150 */

undefined * FUN_00ba6150(undefined *param_1,undefined4 param_2)

{
  undefined auStack_3c [12];
  undefined4 uStack_30;
  undefined1 *puStack_2c;
  undefined4 uStack_28;
  char acStack_20 [12];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc288;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_3c;
  ExceptionList = &pvStack_10;
  FUN_0054f050(param_2);
  FUN_00a34f50(acStack_20);
  uStack_8 = 0;
  if (acStack_20[0] == '\0') {
    uStack_28 = 0;
    puStack_2c = &DAT_018bc9b8;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    uStack_30 = 0xba61cc;
    FUN_005542c0();
  }
  else {
    uStack_28 = 0xba619d;
    uStack_28 = FUN_00a33fa0();
    puStack_2c = (undefined1 *)0xba61a8;
    FUN_0054ef60();
  }
  if (acStack_20[0] != '\0') {
    uStack_28 = 0xba61da;
    FUN_0056e380();
    uStack_28 = 0xba61e2;
    FUN_0056e380();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25661 ; VA 0x00ba6200 ; FUN_00ba6200 */

int __thiscall FUN_00ba6200(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined auStack_54 [12];
  undefined4 uStack_48;
  undefined *puStack_44;
  int *piStack_40;
  int iStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  undefined *puStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017fc2b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iStack_18 = param_2;
  piStack_40 = (int *)(param_1 + 0xa0);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  puStack_44 = (undefined *)0xba6254;
  iStack_14 = param_1;
  iVar4 = FUN_01686710();
  if (iVar4 == 0) {
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar4 = param_3[1] + -1;
      param_3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        piStack_40 = (int *)0xba6279;
        (**(code **)*param_3)();
        LOCK();
        iVar4 = param_3[2] + -1;
        param_3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          piStack_40 = (int *)0xba628d;
          (**(code **)(*param_3 + 4))();
        }
      }
    }
  }
  else {
    piStack_40 = (int *)iStack_18;
    puStack_44 = (undefined *)0xba629a;
    cVar3 = FUN_00ba5c20();
    if (cVar3 == '\0') {
      puStack_1c = auStack_54;
      FUN_0054f050(iStack_18);
      FUN_00ba5030(&iStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (iStack_28 == 0) {
        piStack_40 = (int *)iStack_18;
        puStack_44 = auStack_20;
        uStack_48 = 0xba630c;
        piStack_40 = (int *)FUN_00ba3ff0();
        puStack_44 = (undefined *)0xba6315;
        FUN_005587e0();
        piStack_40 = (int *)0xba631d;
        FUN_00550b30();
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[1] = piStack_24[1] + 1;
          UNLOCK();
        }
        puStack_44 = (undefined *)iStack_28;
        piStack_40 = piStack_24;
        uStack_48 = 0xba634c;
        FUN_00ba7440();
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_24[1] + -1;
        piStack_24[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          piStack_40 = (int *)0xba6362;
          (**(code **)*piStack_24)();
          LOCK();
          iVar4 = piStack_24[2] + -1;
          piStack_24[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            piStack_40 = (int *)0xba6372;
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar4 = param_3[1] + -1;
        param_3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          piStack_40 = (int *)0xba6389;
          (**(code **)*param_3)();
          LOCK();
          iVar4 = param_3[2] + -1;
          param_3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            piStack_40 = (int *)0xba6399;
            (**(code **)(*param_3 + 4))();
          }
        }
      }
    }
    else {
      uStack_8 = (uint)uStack_8._1_3_ << 8;
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar4 = param_3[1] + -1;
        param_3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          piStack_40 = (int *)0xba62c0;
          (**(code **)*param_3)();
          LOCK();
          iVar4 = param_3[2] + -1;
          param_3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            piStack_40 = (int *)0xba62d4;
            (**(code **)(*param_3 + 4))();
          }
        }
      }
    }
  }
  piVar2 = *(int **)(param_2 + 0x20);
  for (piVar5 = *(int **)(param_2 + 0x1c); piVar5 != piVar2; piVar5 = piVar5 + 2) {
    if (piVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puStack_44 = (undefined *)*piVar5;
    piStack_40 = (int *)piVar5[1];
    uStack_48 = 0xba63de;
    param_2 = FUN_00ba6200();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar4 = *piVar2;
    param_2 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piStack_40 = (int *)0xba63fe;
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piStack_40 = (int *)0xba640d;
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25662 ; VA 0x00ba6420 ; FUN_00ba6420 */

int * FUN_00ba6420(int *param_1,undefined4 param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_3c [4];
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc2e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x40))(&piStack_34);
  uStack_8 = 0;
  if (piStack_34 != (int *)0x0) {
    piVar4 = (int *)*piStack_34;
    piStack_34 = (int *)piStack_34[1];
    piStack_1c = piStack_34;
    if (piVar4 != piStack_34) {
      do {
        FUN_00ba4f80(&piStack_2c,*piVar4);
        piVar2 = piStack_28;
        piStack_34 = piStack_2c;
        if (piStack_2c != (int *)0x0) {
          piStack_24 = (int *)0x0;
          piStack_20 = (int *)0x0;
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          if (piStack_2c[9] == 1) {
            piVar3 = (int *)FUN_00ba3c80(auStack_3c,1);
            param_1 = (int *)*piVar3;
            piVar5 = (int *)piVar3[1];
            *piVar3 = 0;
            piVar3[1] = 0;
            piStack_18 = piStack_38;
            piStack_24 = param_1;
            piStack_20 = piVar5;
            if (piStack_38 != (int *)0x0) {
              LOCK();
              iVar1 = piStack_38[1] + -1;
              piStack_38[1] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)*piStack_38)();
                LOCK();
                iVar1 = piStack_18[2] + -1;
                piStack_18[2] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)(*piStack_18 + 4))();
                }
              }
            }
            (**(code **)(*param_1 + 0x38))(*(undefined4 *)(*piVar4 + 0x28));
            if (piVar2 != (int *)0x0) {
              LOCK();
              piVar2[1] = piVar2[1] + 1;
              UNLOCK();
            }
            FUN_00baa070(piStack_2c,piVar2,param_1);
          }
          else {
            piVar5 = (int *)piVar4[1];
            if (piVar5 != (int *)0x0) {
              LOCK();
              piVar5[1] = piVar5[1] + 1;
              UNLOCK();
              piVar5 = (int *)piVar4[1];
            }
            param_1 = (int *)*piVar4;
            piStack_24 = param_1;
            piStack_20 = piVar5;
          }
          FUN_008a65e0(param_2,0);
          piStack_34 = (int *)FUN_00ba6420(*piVar4,param_1);
          if (piVar5 != (int *)0x0) {
            LOCK();
            piVar3 = piVar5 + 1;
            iVar1 = *piVar3;
            piStack_34 = (int *)*piVar3;
            *piVar3 = iVar1 + -1;
            UNLOCK();
            if (iVar1 + -1 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              piVar3 = piVar5 + 2;
              iVar1 = *piVar3;
              piStack_34 = (int *)*piVar3;
              *piVar3 = iVar1 + -1;
              UNLOCK();
              if (iVar1 + -1 == 0) {
                piStack_34 = (int *)(**(code **)(*piVar5 + 4))();
              }
            }
          }
        }
        uStack_8 = uStack_8 & 0xffffff00;
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar5 = piVar2 + 1;
          iVar1 = *piVar5;
          piStack_34 = (int *)*piVar5;
          *piVar5 = iVar1 + -1;
          UNLOCK();
          if (iVar1 + -1 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            piVar5 = piVar2 + 2;
            iVar1 = *piVar5;
            piStack_34 = (int *)*piVar5;
            *piVar5 = iVar1 + -1;
            UNLOCK();
            if (iVar1 + -1 == 0) {
              piStack_34 = (int *)(**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar4 = piVar4 + 2;
      } while (piVar4 != piStack_1c);
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_30 + 1;
    iVar1 = *piVar4;
    piStack_34 = (int *)*piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      piStack_34 = (int *)(**(code **)*piStack_30)();
      LOCK();
      piVar4 = piStack_30 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        piStack_34 = (int *)(**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_34;
}



/* FUNCTION 25663 ; VA 0x00ba6610 ; FUN_00ba6610 */

int FUN_00ba6610(int param_1,int *param_2)

{
  int iVar1;
  bool bVar2;
  bool bVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc329;
  pvStack_10 = ExceptionList;
  bVar3 = false;
  bVar2 = false;
  piStack_20 = (int *)0x0;
  uStack_8 = 0;
  piStack_18 = *(int **)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  FUN_00ba4f80(&iStack_28,piStack_18);
  uStack_8._0_1_ = 1;
  if (iStack_28 != 0) {
    if (piStack_18 == *(int **)(iStack_1c + 0xb8)) {
LAB_00ba66d3:
      cStack_11 = '\0';
    }
    else {
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
      }
      cVar4 = FUN_00ba5ba0(iStack_28,piStack_24);
      if (cVar4 == '\0') goto LAB_00ba66d3;
      piVar5 = (int *)(**(code **)(*piStack_18 + 0x40))(auStack_38);
      bVar3 = true;
      bVar2 = false;
      uStack_8._0_1_ = 2;
      piStack_20 = (int *)0x1;
      if (*piVar5 == 0) goto LAB_00ba66d3;
      piVar5 = (int *)(**(code **)(*piStack_18 + 0x40))(auStack_30);
      bVar3 = true;
      bVar2 = true;
      cStack_11 = '\x01';
      if (((int *)*piVar5)[1] - *(int *)*piVar5 >> 3 != 1) goto LAB_00ba66d3;
    }
    if (bVar2) {
      piStack_20 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          iVar6 = piStack_20[2] + -1;
          piStack_20[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
    }
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    if ((bVar3) && (piStack_34 != (int *)0x0)) {
      LOCK();
      iVar6 = piStack_34[1] + -1;
      piStack_34[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        iVar6 = piStack_34[2] + -1;
        piStack_34[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
    if (cStack_11 != '\0') {
      iVar6 = FUN_00ba9560(piStack_18);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piVar5 = piStack_24 + 1;
        iVar1 = *piVar5;
        iVar6 = *piVar5;
        *piVar5 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar5 = piStack_24 + 2;
          iVar1 = *piVar5;
          iVar6 = *piVar5;
          *piVar5 = iVar1 + -1;
          UNLOCK();
          if (iVar1 + -1 == 0) {
            iVar6 = (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      goto LAB_00ba67a1;
    }
  }
  uStack_8._0_1_ = 0;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_24[1] + -1;
    piStack_24[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar6 = piStack_24[2] + -1;
      piStack_24[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  iVar6 = FUN_00ba94c0(param_1);
LAB_00ba67a1:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar5 = param_2 + 1;
    iVar1 = *piVar5;
    iVar6 = *piVar5;
    *piVar5 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar6 = (**(code **)*param_2)();
      LOCK();
      piVar5 = param_2 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar6 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 25664 ; VA 0x00ba67e0 ; FUN_00ba67e0 */

void FUN_00ba67e0(undefined4 param_1)

{
  FUN_00ba8a40(param_1,1);
  return;
}



/* FUNCTION 25665 ; VA 0x00ba6800 ; FUN_00ba6800 */

int FUN_00ba6800(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int iVar1;
  bool bVar2;
  bool bVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  undefined auStack_44 [8];
  undefined auStack_3c [8];
  int iStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017fc381;
  pvStack_10 = ExceptionList;
  bVar3 = false;
  bVar2 = false;
  uStack_1c = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ba4f80(&iStack_34,param_1);
  if (iStack_34 != 0) {
    FUN_00587490(&piStack_2c);
    uStack_8 = 3;
    if (piStack_2c != (int *)0x0) {
      FUN_00ba4f80(&iStack_24,piStack_2c);
      uStack_8 = 4;
      if (iStack_24 != 0) {
        if (piStack_2c == *(int **)(iStack_18 + 0xb8)) {
LAB_00ba68dc:
          cStack_11 = '\0';
        }
        else {
          FUN_00557fc0(&iStack_24);
          cVar4 = FUN_00ba5ba0();
          if (cVar4 == '\0') goto LAB_00ba68dc;
          piVar5 = (int *)(**(code **)(*piStack_2c + 0x40))(auStack_44);
          bVar2 = false;
          uStack_8 = 5;
          uStack_1c = 1;
          if (*piVar5 != 0) {
            piVar5 = (int *)(**(code **)(*piStack_2c + 0x40))(auStack_3c);
            bVar3 = true;
            bVar2 = true;
            if (*(int *)*piVar5 != ((int *)*piVar5)[1]) goto LAB_00ba68dc;
          }
          bVar3 = true;
          cStack_11 = '\x01';
        }
        if (bVar2) {
          FUN_00550b30();
        }
        uStack_8 = 4;
        uStack_7 = 0;
        if (bVar3) {
          FUN_00550b30();
        }
        if (cStack_11 != '\0') {
          FUN_00ba9560(piStack_2c);
          FUN_00550b30();
          FUN_00550b30();
          iVar6 = FUN_00550b30();
          goto LAB_00ba69b1;
        }
      }
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_20[1] + -1;
        piStack_20[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar6 = piStack_20[2] + -1;
          piStack_20[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_28[1] + -1;
      piStack_28[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar6 = piStack_28[2] + -1;
        piStack_28[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
  }
  uStack_8 = 1;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_30[1] + -1;
    piStack_30[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar6 = piStack_30[2] + -1;
      piStack_30[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  iVar6 = FUN_00ba80c0(param_1);
LAB_00ba69b1:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar5 = param_2 + 1;
    iVar1 = *piVar5;
    iVar6 = *piVar5;
    *piVar5 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar5 = param_2 + 2;
      iVar1 = *piVar5;
      iVar6 = *piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar6 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar5 = param_4 + 2;
    iVar1 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      iVar6 = (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 25666 ; VA 0x00ba6a00 ; FUN_00ba6a00 */

void * __thiscall FUN_00ba6a00(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  undefined **ppuStack_70;
  int iStack_6c;
  undefined ***pppuStack_4c;
  undefined auStack_48 [24];
  undefined auStack_30 [24];
  void *pvStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc3b0;
  pvStack_10 = ExceptionList;
  pvVar3 = ExceptionList;
  if (param_2 != *(int *)(param_1 + 0xb8)) {
    ExceptionList = &pvStack_10;
    FUN_00ba4f80(&pvStack_18,param_2);
    uStack_8 = 0;
    pvVar3 = pvStack_18;
    if (pvStack_18 != (void *)0x0) {
      FUN_0054f050(pvStack_18);
      uStack_8._0_1_ = 1;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[1] = piStack_14[1] + 1;
        UNLOCK();
      }
      FUN_00ba9d80(pvStack_18,piStack_14);
      FUN_0054f050(pvStack_18);
      uStack_8._0_1_ = 2;
      FUN_00ba8350(auStack_48,auStack_30);
      pppuStack_4c = &ppuStack_70;
      ppuStack_70 = std::
                    _Func_impl_no_alloc<class_<lambda_e6c2aa09095a06f5f9ae5cfcecbc3ddb>,bool,class_RBX::Instance*>
                    ::vftable;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      iStack_6c = param_1;
      FUN_00baa6e0(param_2,pppuStack_4c,1,1);
      if (pppuStack_4c != (undefined ***)0x0) {
        (*(code *)(*pppuStack_4c)[4])(pppuStack_4c != &ppuStack_70);
      }
      FUN_00550800();
      pvVar3 = (void *)FUN_00550800();
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      pvVar3 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar3 = (void *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar3 = (void *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 25667 ; VA 0x00ba6b30 ; FUN_00ba6b30 */

undefined FUN_00ba6b30(undefined *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined uVar3;
  uint uVar4;
  undefined auStack_7c [24];
  undefined4 uStack_64;
  undefined *puStack_60;
  undefined auStack_5c [28];
  undefined4 uStack_40;
  int iStack_3c;
  int iStack_2c;
  int iStack_28;
  int iStack_20;
  int iStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc3e0;
  pvStack_10 = ExceptionList;
  if ((*(int *)((int)param_1 + 0x10) == 0) || (*(int *)(param_2 + 0x10) == 0)) {
    return 0;
  }
  iStack_3c = param_2;
  uStack_40 = 0xba6b70;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01686710();
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return 1;
  }
  iStack_3c = (int)&param_1 + 3;
  param_1 = auStack_5c;
  puStack_60 = auStack_5c;
  uStack_64 = 0xba6b9b;
  FUN_01686ad0();
  uStack_8 = 0;
  FUN_016863f0(auStack_7c);
  uStack_8 = 0xffffffff;
  FUN_00ba0710();
  iStack_3c = (int)&param_1 + 3;
  uStack_8 = 1;
  param_1 = auStack_5c;
  puStack_60 = auStack_5c;
  uStack_64 = 0xba6bd7;
  FUN_01686ad0();
  uStack_8._0_1_ = 2;
  FUN_016863f0(auStack_7c);
  uStack_8._0_1_ = 1;
  FUN_00ba0710();
  iVar1 = iStack_1c - iStack_20 >> 0x1f;
  iVar2 = (iStack_1c - iStack_20) / 0x18 + iVar1;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if ((uint)((iStack_28 - iStack_2c) / 0x18) < (uint)(iVar2 - iVar1)) {
LAB_00ba6c69:
    uVar3 = 0;
  }
  else {
    uVar4 = 0;
    if (iVar2 != iVar1) {
      iVar1 = 0;
      do {
        iStack_3c = iStack_2c + iVar1;
        uStack_40 = 0xba6c40;
        iVar2 = FUN_01686710();
        if (iVar2 != 0) goto LAB_00ba6c69;
        uVar4 = uVar4 + 1;
        iVar1 = iVar1 + 0x18;
      } while (uVar4 < (uint)((iStack_1c - iStack_20) / 0x18));
    }
    uVar3 = 1;
  }
  iStack_3c = 0xba6c73;
  FUN_0058eb40();
  iStack_3c = 0xba6c7b;
  FUN_0058eb40();
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 25668 ; VA 0x00ba6cb0 ; FUN_00ba6cb0 */

void __thiscall FUN_00ba6cb0(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  
  if (*(char *)(param_1 + 0xd0) != '\0') {
    iVar1 = *(int *)(param_1 + 200);
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_0086f8b0(iVar1,puVar2,param_2);
    if (*(int *)(param_1 + 0xcc) == 0x7fffffe) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 0xcc) = *(int *)(param_1 + 0xcc) + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
  }
  return;
}



/* FUNCTION 25669 ; VA 0x00ba6d10 ; FUN_00ba6d10 */

void __thiscall FUN_00ba6d10(int *param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  
  iVar1 = *param_1;
  puVar2 = *(undefined4 **)(iVar1 + 4);
  uVar3 = FUN_0086f8b0(iVar1,puVar2,param_2);
  if (param_1[1] != 0x7fffffe) {
    param_1[1] = param_1[1] + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 25670 ; VA 0x00ba6d60 ; FUN_00ba6d60 */

void * __thiscall FUN_00ba6d60(int param_1,int *param_2,int *param_3,int *param_4,int *param_5)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 *puVar5;
  void *pvVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int *piVar11;
  bool bVar12;
  int iStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  int *piStack_38;
  undefined4 *puStack_30;
  int iStack_28;
  undefined auStack_24 [4];
  undefined auStack_20 [4];
  int iStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc418;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  iStack_1c = param_1;
  if (param_2 == (int *)0x0) {
    pvVar6 = ExceptionList;
    ExceptionList = &pvStack_10;
    if (param_4 != (int *)0x0) {
      ExceptionList = &pvStack_10;
      if (param_5 != (int *)0x0) {
        LOCK();
        ExceptionList = &pvStack_10;
        param_5[1] = param_5[1] + 1;
        UNLOCK();
      }
      piStack_4c = param_4;
      piStack_48 = param_5;
      piStack_50 = (int *)0xba6dc9;
      pvVar6 = (void *)FUN_00ba6200();
    }
  }
  else if (param_4 == (int *)0x0) {
    ExceptionList = &pvStack_10;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piStack_4c = param_2;
    piStack_48 = param_3;
    piStack_50 = (int *)0xba6e04;
    pvVar6 = (void *)FUN_00ba45b0();
  }
  else {
    piStack_48 = (int *)(param_1 + 0xa0);
    piStack_4c = (int *)0xba6e15;
    ExceptionList = &pvStack_10;
    iVar7 = FUN_01686710();
    if (iVar7 != 0) {
      piStack_18 = &iStack_5c;
      FUN_0054f050(param_4);
      FUN_00ba5030(&iStack_28);
      uStack_8._0_1_ = 2;
      if (iStack_28 != 0) {
        piStack_48 = param_4;
        piStack_54 = &iStack_28;
        uStack_58 = 0xba6e4f;
        FUN_00557fc0();
        piStack_54 = (int *)0xba6e56;
        FUN_00ba9f10();
        piStack_50 = &iStack_28;
        piStack_54 = (int *)0xba6e64;
        FUN_00557fc0();
        piStack_50 = (int *)0xba6e6b;
        FUN_00ba7440();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      piStack_48 = (int *)0xba6e77;
      FUN_00550b30();
    }
    piStack_48 = (int *)param_2[8];
    piStack_4c = (int *)param_2[7];
    piStack_50 = (int *)0xba6e88;
    FUN_00ba0680();
    uStack_8._0_1_ = 3;
    piStack_48 = (int *)param_4[8];
    piStack_4c = (int *)param_4[7];
    piStack_50 = (int *)0xba6e9d;
    FUN_00ba0680();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    piStack_18 = (int *)*piStack_38;
    puVar8 = puStack_30;
    if (piStack_18 != piStack_38) {
      puStack_14 = puStack_30;
      do {
        piVar11 = piStack_18;
        puVar9 = (undefined4 *)puVar8[1];
        puVar10 = puStack_14;
        if (*(char *)((int)puVar8[1] + 0xd) == '\0') {
          do {
            bVar12 = *(byte *)(puVar9[4] + 0x18) < *(byte *)(piVar11[4] + 0x18);
            if (*(byte *)(puVar9[4] + 0x18) == *(byte *)(piVar11[4] + 0x18)) {
              piStack_48 = (int *)piVar11[4];
              piStack_4c = (int *)0xba6ee1;
              iVar7 = FUN_01686710();
              bVar12 = iVar7 < 0;
            }
            if (bVar12) {
              puVar10 = (undefined4 *)puVar9[2];
            }
            else {
              puVar10 = (undefined4 *)*puVar9;
              puVar8 = puVar9;
            }
            puVar9 = puVar10;
          } while (*(char *)((int)puVar10 + 0xd) == '\0');
          puStack_14 = puStack_30;
          puVar10 = puStack_30;
          if (puVar8 != puStack_30) {
            bVar12 = *(byte *)(piVar11[4] + 0x18) < *(byte *)(puVar8[4] + 0x18);
            if (*(byte *)(piVar11[4] + 0x18) == *(byte *)(puVar8[4] + 0x18)) {
              piStack_48 = (int *)puVar8[4];
              piStack_4c = (int *)0xba6f22;
              iVar7 = FUN_01686710();
              bVar12 = iVar7 < 0;
            }
            if (!bVar12) {
              puVar10 = puVar8;
            }
          }
        }
        puVar8 = puStack_14;
        if (puVar10 == puStack_14) {
          piStack_48 = (int *)0xba6fc7;
          FUN_00551320();
        }
        else {
          if (puVar10[5] != 0) {
            LOCK();
            piVar1 = (int *)(puVar10[5] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          piStack_4c = (int *)puVar10[4];
          piStack_48 = (int *)puVar10[5];
          if (piVar11[5] != 0) {
            LOCK();
            piVar1 = (int *)(piVar11[5] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          piStack_54 = (int *)piVar11[4];
          piStack_50 = (int *)piVar11[5];
          uStack_58 = 0xba6f98;
          FUN_00ba6d60();
          piStack_4c = (int *)auStack_20;
          piStack_50 = (int *)0xba6fa5;
          piStack_48 = puVar10;
          FUN_00ba49d0();
          piStack_4c = (int *)auStack_24;
          piStack_50 = (int *)0xba6fb2;
          piStack_48 = piVar11;
          puVar8 = (undefined4 *)FUN_00ba49d0();
          puStack_14 = puStack_30;
          piStack_18 = (int *)*puVar8;
          puVar8 = puStack_30;
        }
      } while (piStack_18 != piStack_38);
    }
    piVar11 = (int *)*piStack_38;
    while (piVar11 != piStack_38) {
      if (piVar11[5] != 0) {
        LOCK();
        piVar1 = (int *)(piVar11[5] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      piStack_4c = (int *)piVar11[4];
      piStack_48 = (int *)piVar11[5];
      piStack_50 = (int *)0xba7010;
      FUN_00ba45b0();
      piVar1 = (int *)piVar11[2];
      if (*(char *)((int)piVar1 + 0xd) == '\0') {
        cVar2 = *(char *)(*piVar1 + 0xd);
        piVar11 = piVar1;
        piVar1 = (int *)*piVar1;
        while (puVar8 = puStack_30, cVar2 == '\0') {
          cVar2 = *(char *)(*piVar1 + 0xd);
          piVar11 = piVar1;
          piVar1 = (int *)*piVar1;
        }
      }
      else {
        cVar2 = *(char *)(piVar11[1] + 0xd);
        piVar4 = (int *)piVar11[1];
        piVar1 = piVar11;
        while ((piVar11 = piVar4, puVar8 = puStack_30, cVar2 == '\0' &&
               (piVar1 == (int *)piVar11[2]))) {
          cVar2 = *(char *)(piVar11[1] + 0xd);
          piVar4 = (int *)piVar11[1];
          piVar1 = piVar11;
        }
      }
    }
    puVar9 = (undefined4 *)*puVar8;
    puVar10 = puVar8;
    while (puVar9 != puVar8) {
      if (puVar9[5] != 0) {
        LOCK();
        piVar11 = (int *)(puVar9[5] + 4);
        *piVar11 = *piVar11 + 1;
        UNLOCK();
      }
      piStack_4c = (int *)puVar9[4];
      piStack_48 = (int *)puVar9[5];
      piStack_50 = (int *)0xba7090;
      FUN_00ba6200();
      puVar3 = (undefined4 *)puVar9[2];
      puVar10 = puStack_30;
      if (*(char *)((int)puVar3 + 0xd) == '\0') {
        cVar2 = *(char *)((int)*puVar3 + 0xd);
        puVar9 = puVar3;
        puVar3 = (undefined4 *)*puVar3;
        while (cVar2 == '\0') {
          cVar2 = *(char *)((int)*puVar3 + 0xd);
          puVar9 = puVar3;
          puVar3 = (undefined4 *)*puVar3;
        }
      }
      else {
        cVar2 = *(char *)((int)puVar9[1] + 0xd);
        puVar5 = (undefined4 *)puVar9[1];
        puVar3 = puVar9;
        while ((puVar9 = puVar5, cVar2 == '\0' && (puVar3 == (undefined4 *)puVar9[2]))) {
          cVar2 = *(char *)((int)puVar9[1] + 0xd);
          puVar5 = (undefined4 *)puVar9[1];
          puVar3 = puVar9;
        }
      }
    }
    piStack_48 = (int *)puVar10[1];
    uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
    uStack_8._0_1_ = 5;
    piStack_4c = (int *)0xba70e2;
    FUN_00777e50();
    piStack_48 = (int *)0x18;
    puStack_30[1] = puVar10;
    *puStack_30 = puVar10;
    puStack_30[2] = puVar10;
    piStack_50 = (int *)0xba7104;
    FUN_01674ea0();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    piStack_48 = (int *)piStack_38[1];
    piStack_4c = (int *)0xba7119;
    FUN_00777e50();
    piStack_48 = (int *)0x18;
    piStack_38[1] = (int)piStack_38;
    *piStack_38 = (int)piStack_38;
    piStack_38[2] = (int)piStack_38;
    piStack_4c = piStack_38;
    piStack_50 = (int *)0xba713b;
    pvVar6 = (void *)FUN_01674ea0();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar11 = param_3 + 1;
    iVar7 = *piVar11;
    pvVar6 = (void *)*piVar11;
    *piVar11 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      piStack_48 = (int *)0xba7157;
      (**(code **)*param_3)();
      LOCK();
      piVar11 = param_3 + 2;
      iVar7 = *piVar11;
      pvVar6 = (void *)*piVar11;
      *piVar11 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        piStack_48 = (int *)0xba7167;
        pvVar6 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar11 = param_5 + 1;
    iVar7 = *piVar11;
    pvVar6 = (void *)*piVar11;
    *piVar11 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      piStack_48 = (int *)0xba717d;
      pvVar6 = (void *)(**(code **)*param_5)();
      LOCK();
      piVar11 = param_5 + 2;
      iVar7 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        piStack_48 = (int *)0xba718c;
        pvVar6 = (void *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 25671 ; VA 0x00ba71a0 ; FUN_00ba71a0 */

int __thiscall FUN_00ba71a0(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  undefined4 *puVar9;
  uint in_stack_00000018;
  undefined auStack_40 [24];
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fc450;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  cVar2 = FUN_00ba5c20(&param_2);
  if (cVar2 != '\0') {
    puVar3 = (undefined4 *)FUN_01688660(auStack_40);
    iStack_8._0_1_ = 1;
    if (&param_2 != puVar3) {
      puVar6 = puVar3 + 4;
      if (7 < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_0058ed10(puVar3,*puVar6);
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_00550800();
    iVar4 = FUN_01686710(param_1 + 0xa0);
    if (iVar4 == 0) {
      iVar4 = FUN_00ba9b80();
      goto LAB_00ba73e6;
    }
  }
  FUN_00ba5eb0(&iStack_28,&param_2);
  puVar3 = *(undefined4 **)(param_1 + 100);
  iStack_8 = CONCAT31(iStack_8._1_3_,2);
  puVar6 = (undefined4 *)puVar3[1];
  puVar9 = puVar3;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    do {
      iVar4 = FUN_01686710(&param_2);
      if (iVar4 < 0) {
        puVar3 = (undefined4 *)puVar6[2];
      }
      else {
        puVar3 = (undefined4 *)*puVar6;
        puVar9 = puVar6;
      }
      puVar6 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
    puVar3 = *(undefined4 **)(param_1 + 100);
  }
  if ((puVar9 != puVar3) && (iVar4 = FUN_01686710(puVar9 + 4), puVar3 = puVar9, iVar4 < 0)) {
    puVar3 = *(undefined4 **)(param_1 + 100);
  }
  if (puVar3 == *(undefined4 **)(param_1 + 100)) {
    iVar4 = 0;
    piVar7 = (int *)0x0;
  }
  else {
    piVar7 = (int *)puVar3[0xb];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      piVar7 = (int *)puVar3[0xb];
    }
    iVar4 = puVar3[10];
  }
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piStack_24[1] = piStack_24[1] + 1;
    UNLOCK();
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
  }
  iStack_20 = iVar4;
  piStack_1c = piVar7;
  FUN_00ba6d60(iVar4,piVar7,iStack_28,piStack_24);
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
  }
  FUN_00ba4270(iVar4,piVar7);
  if ((iVar4 == 0) || (iStack_28 == 0)) {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    iStack_20 = iStack_28;
    piStack_1c = piStack_24;
    piVar8 = piStack_24;
    piStack_18 = piVar7;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar4 = piVar7[1] + -1;
      piVar7[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar4 = piStack_18[2] + -1;
        piStack_18[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  else {
    FUN_00ba22b0(iStack_28);
    iStack_28 = iVar4;
    piVar8 = piVar7;
  }
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00ba3920(iStack_28,piVar8);
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar7 = piVar8 + 1;
    iVar1 = *piVar7;
    iVar4 = *piVar7;
    *piVar7 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      piVar7 = piVar8 + 2;
      iVar1 = *piVar7;
      iVar4 = *piVar7;
      *piVar7 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar4 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar7 = piStack_24 + 1;
    iVar1 = *piVar7;
    iVar4 = *piVar7;
    *piVar7 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar4 = (**(code **)*piStack_24)();
      LOCK();
      piVar7 = piStack_24 + 2;
      iVar1 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar4 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
LAB_00ba73e6:
  if (7 < in_stack_00000018) {
    uVar5 = in_stack_00000018 * 2 + 2;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_00000018 * 2 + 0x25;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 25672 ; VA 0x00ba7440 ; FUN_00ba7440 */

int *** FUN_00ba7440(int *******param_1,int ****param_2)

{
  int ****ppppiVar1;
  int *piVar2;
  int ***pppiVar3;
  int ****ppppiVar4;
  int *******pppppppiVar5;
  int *****pppppiVar6;
  int *piVar7;
  char cVar8;
  int ******ppppppiVar9;
  int iVar10;
  int ******ppppppiVar11;
  undefined4 *puVar12;
  int ***pppiVar13;
  int *******pppppppiVar14;
  int ****ppppiStack_e4;
  undefined4 uStack_e0;
  int ******ppppppiStack_dc;
  int ******ppppppiStack_d8;
  int ******ppppppiStack_d4;
  int ******ppppppiStack_d0;
  undefined auStack_c0 [24];
  int ******appppppiStack_a8 [4];
  int ******ppppppiStack_98;
  uint uStack_94;
  int ******appppppiStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  int ******appppppiStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined auStack_60 [4];
  int *piStack_5c;
  int ******ppppppiStack_58;
  int *piStack_54;
  int ******appppppiStack_50 [4];
  int ******ppppppiStack_40;
  uint uStack_3c;
  int *piStack_38;
  int *piStack_34;
  int ******ppppppiStack_30;
  int *piStack_2c;
  int ******ppppppiStack_28;
  int *piStack_24;
  int iStack_20;
  int ******ppppppiStack_1c;
  int *****pppppiStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc4c9;
  pvStack_10 = ExceptionList;
  ppppppiStack_d0 = (int ******)&ppppppiStack_30;
  uStack_8 = 0;
  ppppppiStack_d4 = (int ******)0xba747c;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  ppppppiStack_d0 = (int ******)appppppiStack_90;
  uStack_8._0_1_ = 1;
  ppppppiStack_d4 = (int ******)0xba748f;
  FUN_01688660();
  pppppiStack_18 = &ppppiStack_e4;
  uStack_8._0_1_ = 2;
  FUN_0054f050(appppppiStack_90);
  FUN_00ba5030(auStack_60);
  ppppppiStack_d0 = (int ******)&ppppppiStack_58;
  ppppppiStack_d4 = (int ******)0xba74c1;
  FUN_00587490();
  uStack_8._0_1_ = 4;
  if (param_2 != (int ****)0x0) {
    LOCK();
    param_2[1] = (int ***)((int)param_2[1] + 1);
    UNLOCK();
  }
  ppppppiStack_d4 = (int ******)param_1;
  ppppppiStack_d0 = (int ******)param_2;
  ppppppiStack_d8 = (int ******)appppppiStack_50;
  ppppppiStack_dc = (int ******)0xba74f6;
  FUN_00ba5100();
  pppppppiVar14 = (int *******)ppppppiStack_30;
  pppppppiVar5 = param_1;
  piStack_38 = (int *)0x0;
  piStack_34 = (int *)0x0;
  uStack_8._0_1_ = 6;
  ppppppiStack_1c = ppppppiStack_30;
  if ((int *******)ppppppiStack_30 == (int *******)0x0) {
LAB_00ba7583:
    if (param_1[9] == (int ******)0x1) {
      ppppppiStack_d0 = (int ******)&ppppppiStack_28;
      ppppppiStack_d4 = (int ******)0xba759c;
      (*(code *)(*ppppppiStack_58)[0x10])();
      uStack_8._0_1_ = 7;
      if ((int *******)ppppppiStack_28 != (int *******)0x0) {
        ppppppiVar9 = (int ******)*ppppppiStack_28;
        ppppppiVar11 = (int ******)ppppppiStack_28[1];
        pppppppiVar14 = (int *******)ppppppiStack_1c;
        pppppiStack_18 = (int *****)ppppppiVar11;
        if (ppppppiVar9 != ppppppiVar11) {
          do {
            if (*ppppppiVar9 != (int *****)0x0) {
              ppppiVar4 = (*ppppppiVar9)[3];
              ppppppiStack_d0 = (int ******)0xba75c3;
              iVar10 = FUN_00b9e640();
              ppppppiVar11 = (int ******)pppppiStack_18;
              if ((uint)*(ushort *)(ppppiVar4 + 0x76) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
                  (uint)*(ushort *)(iVar10 + 0x1da)) {
                ppppppiStack_d4 = (int ******)(*ppppppiVar9)[10];
                ppppppiStack_d0 = (int ******)((int ****)ppppppiStack_d4)[4];
                if ((int ***)0xf < ((int ****)ppppppiStack_d4)[5]) {
                  ppppppiStack_d4 = (int ******)*ppppppiStack_d4;
                }
                ppppppiStack_dc = (int ******)appppppiStack_50;
                if (0xf < uStack_3c) {
                  ppppppiStack_dc = appppppiStack_50[0];
                }
                ppppppiStack_d8 = ppppppiStack_40;
                uStack_e0 = 0xba7604;
                cVar8 = FUN_0055c360();
                ppppppiVar11 = (int ******)pppppiStack_18;
                if (cVar8 != '\0') {
                  ppppppiStack_d4 = (int ******)0xba773f;
                  ppppppiStack_d0 = ppppppiVar9;
                  FUN_0056ecd0();
                  pppppppiVar14 = (int *******)ppppppiStack_30;
                  ppppppiStack_d0 = ppppppiStack_30;
                  ppppppiStack_1c = ppppppiStack_30;
                  if (param_2 != (int ****)0x0) {
                    LOCK();
                    param_2[1] = (int ***)((int)param_2[1] + 1);
                    UNLOCK();
                  }
                  ppppppiStack_d8 = (int ******)param_1;
                  ppppppiStack_d4 = (int ******)param_2;
                  ppppppiStack_dc = (int ******)0xba7776;
                  FUN_00baa070();
                  break;
                }
              }
            }
            ppppppiVar9 = ppppppiVar9 + 2;
            pppppppiVar14 = (int *******)ppppppiStack_1c;
          } while (ppppppiVar9 != ppppppiVar11);
        }
      }
      piVar2 = piStack_24;
      uStack_8._0_1_ = 6;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_24[1] + -1;
        piStack_24[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          ppppppiStack_d0 = (int ******)0xba7636;
          (**(code **)*piStack_24)();
          LOCK();
          piVar7 = piVar2 + 2;
          iVar10 = *piVar7 + -1;
          *piVar7 = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            ppppppiStack_d0 = (int ******)0xba7646;
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    if (pppppppiVar14 == (int *******)0x0) {
      ppppppiStack_d0 = param_1[9];
      ppppppiStack_d4 = (int ******)&ppppppiStack_28;
      ppppppiStack_d8 = (int ******)0xba765d;
      puVar12 = (undefined4 *)FUN_00ba3c80();
      piVar2 = piStack_2c;
      pppppppiVar14 = (int *******)*puVar12;
      pppppiStack_18 = (int *****)puVar12[1];
      *puVar12 = 0;
      puVar12[1] = 0;
      ppppppiStack_30 = (int ******)pppppppiVar14;
      piVar7 = (int *)pppppiStack_18;
      ppppppiStack_1c = (int ******)pppppppiVar14;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar10 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          puVar12 = (undefined4 *)*piStack_2c;
          ppppppiStack_d0 = (int ******)0xba7694;
          piStack_2c = (int *)pppppiStack_18;
          (*(code *)*puVar12)();
          LOCK();
          piVar7 = piVar2 + 2;
          iVar10 = *piVar7 + -1;
          *piVar7 = iVar10;
          UNLOCK();
          piVar7 = piStack_2c;
          if (iVar10 == 0) {
            ppppppiStack_d0 = (int ******)0xba76a4;
            (**(code **)(*piVar2 + 4))();
            piVar7 = piStack_2c;
          }
        }
      }
      piStack_2c = piVar7;
      piVar2 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_24[1] + -1;
        piStack_24[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          ppppppiStack_d0 = (int ******)0xba76ba;
          (**(code **)*piStack_24)();
          LOCK();
          piVar7 = piVar2 + 2;
          iVar10 = *piVar7 + -1;
          *piVar7 = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            ppppppiStack_d0 = (int ******)0xba76ca;
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      if (param_2 != (int ****)0x0) {
        LOCK();
        param_2[1] = (int ***)((int)param_2[1] + 1);
        UNLOCK();
      }
      ppppppiStack_d8 = (int ******)param_1;
      ppppppiStack_d4 = (int ******)param_2;
      ppppppiStack_dc = (int ******)0xba76fd;
      ppppppiStack_d0 = (int ******)pppppppiVar14;
      FUN_00baa070();
      if ((*(char *)(iStack_20 + 0xc4) != '\0') && (pppppppiVar14 != (int *******)0x0)) {
        ppppppiVar9 = pppppppiVar14[3];
        ppppppiStack_d0 = (int ******)0xba7712;
        iVar10 = FUN_009ec190();
        if ((uint)*(ushort *)(ppppppiVar9 + 0x76) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
            (uint)*(ushort *)(iVar10 + 0x1da)) {
          *(undefined *)(pppppppiVar14 + 0x3b) = 1;
        }
      }
      goto LAB_00ba7781;
    }
  }
  else {
    ppppppiStack_d0 = ppppppiStack_30;
    ppppppiStack_d4 = (int ******)0xba7521;
    ppppppiVar9 = (int ******)FUN_00ba5240();
    if (ppppppiVar9 != pppppppiVar5[9]) {
      ppppppiStack_d0 = (int ******)&ppppppiStack_30;
      ppppppiStack_d4 = (int ******)0xba7535;
      FUN_0056ecd0();
      ppppppiStack_d0 = (int ******)&ppppppiStack_28;
      ppppppiStack_28 = (int ******)0x0;
      piStack_24 = (int *)0x0;
      ppppppiStack_d4 = (int ******)0xba754f;
      FUN_005587e0();
      piVar2 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_24[1] + -1;
        piStack_24[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          ppppppiStack_d0 = (int ******)0xba7565;
          (**(code **)*piStack_24)();
          LOCK();
          piVar7 = piVar2 + 2;
          iVar10 = *piVar7 + -1;
          *piVar7 = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            ppppppiStack_d0 = (int ******)0xba7575;
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      ppppppiStack_1c = ppppppiStack_30;
      pppppppiVar14 = (int *******)ppppppiStack_30;
    }
    if (pppppppiVar14 == (int *******)0x0) goto LAB_00ba7583;
  }
  pppppiStack_18 = (int *****)piStack_2c;
LAB_00ba7781:
  ppppppiStack_d4 = pppppppiVar14[10];
  ppppppiStack_d0 = ((int *******)ppppppiStack_d4)[4];
  if ((int ******)0xf < ((int *******)ppppppiStack_d4)[5]) {
    ppppppiStack_d4 = (int ******)*ppppppiStack_d4;
  }
  ppppppiStack_dc = (int ******)appppppiStack_50;
  if (0xf < uStack_3c) {
    ppppppiStack_dc = appppppiStack_50[0];
  }
  ppppppiStack_d8 = ppppppiStack_40;
  uStack_e0 = 0xba77a5;
  cVar8 = FUN_0055c360();
  if (cVar8 == '\0') {
    ppppppiStack_d0 = (int ******)appppppiStack_50;
    ppppppiStack_d4 = (int ******)0xba77b7;
    (*(code *)(*pppppppiVar14)[0xe])();
  }
  ppppppiVar9 = ppppppiStack_1c;
  if (pppppppiVar14[0xd] != ppppppiStack_58) {
    if (piStack_54 != (int *)0x0) {
      LOCK();
      piStack_54[1] = piStack_54[1] + 1;
      UNLOCK();
    }
    ppppppiStack_28 = ppppppiStack_58;
    piStack_24 = piStack_54;
    ppppppiStack_d0 = (int ******)0x0;
    ppppppiStack_d4 = ppppppiStack_58;
    uStack_8._0_1_ = 8;
    ppppppiStack_d8 = (int ******)0xba77e1;
    FUN_008a65e0();
    uStack_8._0_1_ = 6;
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar10 = piStack_54[1] + -1;
      piStack_54[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        ppppppiStack_d0 = (int ******)0xba77f8;
        (**(code **)*piStack_54)();
        LOCK();
        iVar10 = piStack_54[2] + -1;
        piStack_54[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          ppppppiStack_d0 = (int ******)0xba7808;
          (**(code **)(*piStack_54 + 4))();
        }
      }
    }
  }
  piVar2 = piStack_38;
  if (piStack_38 != (int *)0x0) {
    ppppppiStack_d0 = ppppppiVar9;
    ppppppiStack_d4 = (int ******)piStack_38;
    ppppppiStack_d8 = (int ******)0xba7820;
    FUN_00ba6420();
    ppppppiStack_d0 = (int ******)piVar2;
    ppppppiStack_d4 = (int ******)0xba7829;
    cVar8 = FUN_00ba3a20();
    if (cVar8 != '\0') {
      ppppppiStack_d0 = (int ******)0xba7834;
      (**(code **)(*piVar2 + 0x2c))();
    }
  }
  ppppiVar4 = param_2;
  if (param_2 != (int ****)0x0) {
    LOCK();
    param_2[1] = (int ***)((int)param_2[1] + 1);
    UNLOCK();
  }
  ppppppiVar9 = param_1[9];
  if (((ppppppiVar9 == (int ******)0x2) || (ppppppiVar9 == (int ******)0x3)) ||
     (cStack_11 = '\0', ppppppiVar9 == (int ******)0x4)) {
    cStack_11 = '\x01';
  }
  if (param_2 != (int ****)0x0) {
    LOCK();
    pppiVar13 = (int ***)((int)param_2[1] + -1);
    param_2[1] = pppiVar13;
    UNLOCK();
    if (pppiVar13 == (int ***)0x0) {
      ppppppiStack_d0 = (int ******)0xba7872;
      (*(code *)**param_2)();
      LOCK();
      ppppiVar1 = ppppiVar4 + 2;
      pppiVar13 = (int ***)((int)*ppppiVar1 + -1);
      *ppppiVar1 = pppiVar13;
      UNLOCK();
      if (pppiVar13 == (int ***)0x0) {
        ppppppiStack_d0 = (int ******)0xba7882;
        (*(code *)(*ppppiVar4)[1])();
      }
    }
  }
  if (cStack_11 != '\0') {
    if (DAT_01d6eebc == '\0') {
      ppppppiStack_d0 = (int ******)&param_1;
      ppppppiStack_d4 = (int ******)auStack_c0;
      ppppppiStack_d8 = (int ******)0xba78da;
      FUN_00ba56f0();
      ppppppiVar9 = ppppppiStack_1c;
      ppppppiStack_dc = (int ******)appppppiStack_a8;
      ppppppiStack_d8 = ppppppiStack_1c;
      uStack_8._0_1_ = 9;
      uStack_e0 = 0xba78ee;
      FUN_00ba5830();
      ppppppiStack_d0 = (int ******)auStack_c0;
      ppppppiStack_d4 = (int ******)appppppiStack_78;
      uStack_8._0_1_ = 10;
      ppppppiStack_d8 = (int ******)0xba7908;
      FUN_00ba6150();
      ppppppiStack_d0 = (int ******)uStack_68;
      ppppppiStack_d4 = (int ******)appppppiStack_78;
      if (0xf < uStack_64) {
        ppppppiStack_d4 = appppppiStack_78[0];
      }
      ppppppiStack_dc = (int ******)appppppiStack_a8;
      if (0xf < uStack_94) {
        ppppppiStack_dc = appppppiStack_a8[0];
      }
      ppppppiStack_d8 = ppppppiStack_98;
      uStack_8._0_1_ = 0xb;
      uStack_e0 = 0xba793b;
      cVar8 = FUN_0055c360();
      if (cVar8 == '\0') {
        ppppppiStack_d0 = (int ******)appppppiStack_78;
        ppppppiStack_d4 = ppppppiVar9;
        ppppppiStack_d8 = (int ******)0xba794c;
        FUN_00ba8be0();
      }
      ppppppiStack_d0 = (int ******)0xba7957;
      FUN_005507b0();
      ppppppiStack_d0 = (int ******)0xba7962;
      FUN_005507b0();
      ppppppiStack_d0 = (int ******)0xba796d;
      FUN_00550800();
    }
    else {
      if (param_2 != (int ****)0x0) {
        LOCK();
        param_2[1] = (int ***)((int)param_2[1] + 1);
        UNLOCK();
      }
      ppppppiStack_d4 = (int ******)param_1;
      ppppppiStack_d0 = (int ******)param_2;
      ppppppiStack_d8 = (int ******)0xba78c5;
      FUN_00ba7cb0();
    }
  }
  piVar2 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar10 = piStack_34[1] + -1;
    piStack_34[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      ppppppiStack_d0 = (int ******)0xba7983;
      (**(code **)*piStack_34)();
      LOCK();
      piVar7 = piVar2 + 2;
      iVar10 = *piVar7 + -1;
      *piVar7 = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        ppppppiStack_d0 = (int ******)0xba7993;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (0xf < uStack_3c) {
    ppppppiStack_d0 = (int ******)(uStack_3c + 1);
    pppppppiVar14 = (int *******)appppppiStack_50[0];
    if (0xfff < ppppppiStack_d0) {
      pppppppiVar14 = (int *******)appppppiStack_50[0][-1];
      ppppppiStack_d0 = (int ******)(uStack_3c + 0x24);
      if (0x1f < (uint)((int)appppppiStack_50[0] + (-4 - (int)pppppppiVar14))) {
                    /* WARNING: Subroutine does not return */
        ppppppiStack_d0 = (int ******)0xba7ad9;
        FUN_017167a3();
      }
    }
    ppppppiStack_d8 = (int ******)0xba79c4;
    ppppppiStack_d4 = (int ******)pppppppiVar14;
    FUN_01674ea0();
  }
  ppppppiStack_40 = (int ******)0x0;
  uStack_3c = 0xf;
  appppppiStack_50[0] = (int ******)((uint)appppppiStack_50[0] & 0xffffff00);
  if (piStack_54 != (int *)0x0) {
    LOCK();
    iVar10 = piStack_54[1] + -1;
    piStack_54[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      ppppppiStack_d0 = (int ******)0xba79ec;
      (**(code **)*piStack_54)();
      LOCK();
      iVar10 = piStack_54[2] + -1;
      piStack_54[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        ppppppiStack_d0 = (int ******)0xba79fc;
        (**(code **)(*piStack_54 + 4))();
      }
    }
  }
  if (piStack_5c != (int *)0x0) {
    LOCK();
    iVar10 = piStack_5c[1] + -1;
    piStack_5c[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      ppppppiStack_d0 = (int ******)0xba7a12;
      (**(code **)*piStack_5c)();
      LOCK();
      iVar10 = piStack_5c[2] + -1;
      piStack_5c[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        ppppppiStack_d0 = (int ******)0xba7a22;
        (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  if (7 < uStack_7c) {
    ppppppiStack_d0 = (int ******)(uStack_7c * 2 + 2);
    pppppppiVar14 = (int *******)appppppiStack_90[0];
    if (0xfff < ppppppiStack_d0) {
      pppppppiVar14 = (int *******)appppppiStack_90[0][-1];
      ppppppiStack_d0 = (int ******)(uStack_7c * 2 + 0x25);
      if (0x1f < (uint)((int)appppppiStack_90[0] + (-4 - (int)pppppppiVar14))) {
                    /* WARNING: Subroutine does not return */
        ppppppiStack_d0 = (int ******)&UNK_00ba7ade;
        FUN_017167a3();
      }
    }
    ppppppiStack_d8 = (int ******)0xba7a5c;
    ppppppiStack_d4 = (int ******)pppppppiVar14;
    FUN_01674ea0();
  }
  pppppiVar6 = pppppiStack_18;
  pppiVar13 = (int ***)0x0;
  uStack_80 = 0;
  uStack_7c = 7;
  appppppiStack_90[0] = (int ******)((uint)appppppiStack_90[0] & 0xffff0000);
  if (pppppiStack_18 != (int *****)0x0) {
    LOCK();
    piVar2 = (int *)(pppppiStack_18 + 1);
    iVar10 = *piVar2;
    pppiVar13 = (int ***)*piVar2;
    *piVar2 = iVar10 + -1;
    UNLOCK();
    if (iVar10 + -1 == 0) {
      ppppppiStack_d0 = (int ******)0xba7a8c;
      (*(code *)**pppppiStack_18)();
      LOCK();
      piVar2 = (int *)(pppppiVar6 + 2);
      iVar10 = *piVar2;
      pppiVar13 = (int ***)*piVar2;
      *piVar2 = iVar10 + -1;
      UNLOCK();
      if (iVar10 + -1 == 0) {
        ppppppiStack_d0 = (int ******)0xba7a9c;
        pppiVar13 = (int ***)(**(code **)((int)*pppppiVar6 + 4))();
      }
    }
  }
  ppppiVar4 = param_2;
  if (param_2 != (int ****)0x0) {
    LOCK();
    ppppiVar1 = param_2 + 1;
    pppiVar3 = *ppppiVar1;
    pppiVar13 = *ppppiVar1;
    *ppppiVar1 = (int ***)((int)pppiVar3 + -1);
    UNLOCK();
    if ((int ***)((int)pppiVar3 + -1) == (int ***)0x0) {
      ppppppiStack_d0 = (int ******)0xba7ab2;
      pppiVar13 = (int ***)(*(code *)**param_2)();
      LOCK();
      ppppiVar1 = ppppiVar4 + 2;
      pppiVar3 = *ppppiVar1;
      *ppppiVar1 = (int ***)((int)*ppppiVar1 + -1);
      UNLOCK();
      if (pppiVar3 == (int ***)0x1) {
        ppppppiStack_d0 = (int ******)0xba7ac1;
        pppiVar13 = (int ***)(*(code *)(*ppppiVar4)[1])();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pppiVar13;
}



/* FUNCTION 25673 ; VA 0x00ba7ae0 ; FUN_00ba7ae0 */

undefined __thiscall FUN_00ba7ae0(undefined4 param_1,undefined4 *param_2,int *param_3)

{
  int iVar1;
  char cVar2;
  undefined uVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 ****ppppuVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 ***apppuStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fc501;
  pvStack_10 = ExceptionList;
  iStack_14 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_1c = param_1;
  if (*(char *)(param_2 + 8) == '\0') {
LAB_00ba7c2c:
    if (param_2[9] != 1) {
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      uVar3 = FUN_00ba7e80(param_2,param_3);
      goto LAB_00ba7c67;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    piVar4 = (int *)FUN_0168e1c0(auStack_18,param_2,&DAT_01ef1210);
    iStack_14 = piVar4[1];
    if (*piVar4 == 3) goto LAB_00ba7c2c;
    if (DAT_01ef2bac != '\0') {
      iVar1 = param_2[4];
      iStack_8._0_1_ = 1;
      uStack_24 = 0;
      uStack_20 = 0xf;
      apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
      iStack_14 = 1;
      if (iVar1 != 0) {
        puVar5 = param_2;
        if (7 < (uint)param_2[5]) {
          puVar5 = (undefined4 *)*param_2;
        }
        puVar9 = param_2;
        if (7 < (uint)param_2[5]) {
          puVar9 = (undefined4 *)*param_2;
        }
        uVar6 = FUN_01686580();
        FUN_01685a20(puVar9,(int)puVar5 + iVar1 * 2,apppuStack_34,uVar6);
      }
      ppppuVar7 = apppuStack_34;
      if (0xf < uStack_20) {
        ppppuVar7 = (undefined4 ****)apppuStack_34[0];
      }
      FUN_01677520(DAT_01ef2bac,"%s: path: %s","RBX::FileSyncItem::makeDir",ppppuVar7);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_20) {
        uVar8 = uStack_20 + 1;
        ppppuVar7 = (undefined4 ****)apppuStack_34[0];
        if (0xfff < uVar8) {
          ppppuVar7 = (undefined4 ****)apppuStack_34[0][-1];
          uVar8 = uStack_20 + 0x24;
          if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar7,uVar8);
      }
      uStack_24 = 0;
      uStack_20 = 0xf;
      apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
    }
    cVar2 = FUN_0168be30(param_2,&DAT_01ef1210);
    if (cVar2 != '\0') goto LAB_00ba7c2c;
  }
  uVar3 = 0;
LAB_00ba7c67:
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar4 = param_3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 25674 ; VA 0x00ba7cb0 ; FUN_00ba7cb0 */

uint FUN_00ba7cb0(undefined4 param_1,int *param_2)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  char cVar4;
  undefined4 ****ppppuVar5;
  undefined4 ****ppppuVar6;
  int iVar7;
  uint uVar8;
  int aiStack_64 [5];
  uint uStack_50;
  undefined4 ***apppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 ***apppuStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc530;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&uStack_1c);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_18[1] + -1;
    piStack_18[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar7 = piStack_18[2] + -1;
      piStack_18[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  FUN_00ba56f0(aiStack_64,&param_1);
  uStack_8._0_1_ = 1;
  FUN_00ba5830(apppuStack_4c,uStack_1c);
  uStack_8._0_1_ = 2;
  FUN_00ba6150(apppuStack_34,aiStack_64);
  ppppuVar6 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar6 = (undefined4 ****)apppuStack_34[0];
  }
  ppppuVar5 = apppuStack_4c;
  if (0xf < uStack_38) {
    ppppuVar5 = (undefined4 ****)apppuStack_4c[0];
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  cVar4 = FUN_0055c360(ppppuVar5,uStack_3c,ppppuVar6,uStack_24);
  if (cVar4 == '\0') {
    FUN_00ba8be0(uStack_1c,apppuStack_34);
  }
  FUN_00ba8a40(uStack_1c,0);
  if (0xf < uStack_20) {
    uVar8 = uStack_20 + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_34[0];
    if (0xfff < uVar8) {
      ppppuVar6 = (undefined4 ****)apppuStack_34[0][-1];
      uVar8 = uStack_20 + 0x24;
      if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar8);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
  if (0xf < uStack_38) {
    uVar8 = uStack_38 + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_4c[0];
    if (0xfff < uVar8) {
      ppppuVar6 = (undefined4 ****)apppuStack_4c[0][-1];
      uVar8 = uStack_38 + 0x24;
      if (0x1f < (uint)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_38 = FUN_01674ea0(ppppuVar6,uVar8);
  }
  if (7 < uStack_50) {
    uVar8 = uStack_50 * 2 + 2;
    iVar7 = aiStack_64[0];
    if (0xfff < uVar8) {
      iVar7 = *(int *)(aiStack_64[0] + -4);
      uVar8 = uStack_50 * 2 + 0x25;
      if (0x1f < (aiStack_64[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_38 = FUN_01674ea0(iVar7,uVar8);
  }
  piVar3 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_2 + 1);
    uVar8 = *puVar1;
    uStack_38 = *puVar1;
    *puVar1 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      uStack_38 = (**(code **)*param_2)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar7 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        uStack_38 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uStack_38;
}



/* FUNCTION 25675 ; VA 0x00ba7e80 ; FUN_00ba7e80 */

undefined FUN_00ba7e80(undefined4 param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  bool bVar3;
  char cVar4;
  undefined uVar5;
  int *piVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  uint uVar11;
  int aiStack_68 [5];
  uint uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 ***apppuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ba56f0(auStack_50,&param_1);
  uStack_8._0_1_ = 1;
  piVar6 = (int *)FUN_0168e1c0(&uStack_20,auStack_50,&DAT_01ef1210);
  piStack_1c = (int *)piVar6[1];
  if ((*piVar6 == 0) || (*piVar6 == 1)) {
    bVar3 = false;
  }
  else {
    bVar3 = true;
  }
  FUN_00587490(&uStack_20);
  uStack_8._0_1_ = 2;
  FUN_00ba5830(apppuStack_38,uStack_20);
  piVar6 = piStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar8 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (bVar3) {
    puVar7 = (undefined4 *)FUN_00ba6150(aiStack_68,auStack_50);
    uStack_14 = 1;
    ppppuVar9 = apppuStack_38;
    if (0xf < uStack_24) {
      ppppuVar9 = (undefined4 ****)apppuStack_38[0];
    }
    puVar2 = puVar7 + 4;
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    cVar4 = FUN_0055c360(puVar7,*puVar2,ppppuVar9,uStack_28);
    if (cVar4 != '\0') {
      bVar3 = false;
      goto LAB_00ba7f84;
    }
  }
  bVar3 = true;
LAB_00ba7f84:
  if (((uStack_14 & 1) != 0) && (0xf < uStack_54)) {
    uVar11 = uStack_54 + 1;
    iVar8 = aiStack_68[0];
    if (0xfff < uVar11) {
      iVar8 = *(int *)(aiStack_68[0] + -4);
      uVar11 = uStack_54 + 0x24;
      if (0x1f < (aiStack_68[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar11);
  }
  if (bVar3) {
    uVar5 = FUN_00baa8a0(auStack_50,apppuStack_38);
  }
  else {
    uVar5 = 1;
  }
  if (0xf < uStack_24) {
    uVar11 = uStack_24 + 1;
    ppppuVar9 = (undefined4 ****)apppuStack_38[0];
    if (0xfff < uVar11) {
      ppppuVar9 = (undefined4 ****)apppuStack_38[0][-1];
      uVar11 = uStack_24 + 0x24;
      if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar11);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
  if (7 < uStack_3c) {
    uVar11 = uStack_3c * 2 + 2;
    uVar10 = auStack_50[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_50[0] - 4);
      uVar11 = uStack_3c * 2 + 0x25;
      if (0x1f < (auStack_50[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  piVar6 = param_2;
  uStack_40 = 0;
  uStack_3c = 7;
  auStack_50[0] = auStack_50[0] & 0xffff0000;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar8 = param_2[1] + -1;
    param_2[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 25676 ; VA 0x00ba80c0 ; FUN_00ba80c0 */

int * FUN_00ba80c0(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc580;
  pvStack_10 = ExceptionList;
  piVar4 = param_1;
  if (param_1 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    piVar4 = (int *)FUN_00ba4f80(&iStack_18,param_1);
    piVar6 = piStack_14;
    iStack_8 = 0;
    if (iStack_18 != 0) {
      (**(code **)(*param_1 + 0x40))(&piStack_20);
      iStack_8._0_1_ = 1;
      if (piStack_20 != (int *)0x0) {
        puVar2 = (undefined4 *)piStack_20[1];
        for (puVar5 = (undefined4 *)*piStack_20; puVar5 != puVar2; puVar5 = puVar5 + 2) {
          FUN_00ba80c0(*puVar5);
          piVar6 = piStack_14;
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar3 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
      }
      FUN_00ba4120(iStack_18,piVar6);
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
      }
      piVar4 = (int *)FUN_00ba9cf0(iStack_18,piVar6);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar3 = *piVar1;
      piVar4 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar4 = (int *)(**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piVar4 = (int *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 25677 ; VA 0x00ba8200 ; FUN_00ba8200 */

undefined4 * __thiscall FUN_00ba8200(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fc5a0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_00587490(auStack_18);
  iStack_8._0_1_ = 1;
  FUN_00baf060(param_1,*puVar3);
  piVar2 = piStack_14;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00ba4a90(&piStack_14,param_2);
  if ((piStack_14 != *(int **)(param_1 + 0x54)) && (piStack_14[10] == param_2)) {
    iVar4 = FUN_00553830(piStack_14);
    FUN_00ba1950((int *)(param_1 + 0x54),iVar4 + 0x10);
    FUN_01674ea0(iVar4,0x30);
  }
  puVar3 = *(undefined4 **)(param_1 + 0x5c);
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    puVar5 = puVar3;
    puVar7 = (undefined4 *)puVar3[1];
    do {
      puVar6 = puVar7;
      if ((uint)puVar6[5] < *(uint *)(param_2 + 0x1c)) {
        puVar7 = (undefined4 *)puVar6[2];
        puVar6 = puVar5;
      }
      else {
        puVar7 = (undefined4 *)*puVar6;
      }
      puVar5 = puVar6;
    } while (*(char *)((int)puVar7 + 0xd) == '\0');
    if ((puVar6 != puVar3) && ((uint)puVar6[5] <= *(uint *)(param_2 + 0x1c))) goto LAB_00ba82f4;
  }
  puVar6 = puVar3;
LAB_00ba82f4:
  if ((puVar6 != puVar3) && (puVar6[6] == param_2)) {
    puVar6 = (undefined4 *)FUN_00ba4880(&piStack_14,puVar6);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar4 = *piVar2;
    puVar6 = (undefined4 *)*piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      puVar6 = (undefined4 *)(**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        puVar6 = (undefined4 *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 25678 ; VA 0x00ba8350 ; FUN_00ba8350 */

void FUN_00ba8350(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  undefined4 ***apppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 ***apppuStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 ***pppuStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc5e2;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01ef2bac != '\0') {
    iStack_8 = 0;
    uStack_3c = 0;
    uStack_38 = 0xf;
    apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffffff00);
    uStack_14 = 1;
    ExceptionList = &pvStack_10;
    if (param_2[4] != 0) {
      puVar2 = param_2;
      if (7 < (uint)param_2[5]) {
        puVar2 = (undefined4 *)*param_2;
      }
      iStack_18 = (int)puVar2 + param_2[4] * 2;
      puVar2 = param_2;
      if (7 < (uint)param_2[5]) {
        puVar2 = (undefined4 *)*param_2;
      }
      ExceptionList = &pvStack_10;
      uVar1 = FUN_01686580();
      FUN_01685a20(puVar2,iStack_18,apppuStack_4c,uVar1);
    }
    pppuStack_1c = apppuStack_4c;
    if (0xf < uStack_38) {
      pppuStack_1c = apppuStack_4c[0];
    }
    iStack_8._0_1_ = 1;
    uStack_24 = 0;
    uStack_20 = 0xf;
    apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
    uStack_14 = 3;
    if (param_1[4] != 0) {
      puVar2 = param_1;
      if (7 < (uint)param_1[5]) {
        puVar2 = (undefined4 *)*param_1;
      }
      iStack_18 = (int)puVar2 + param_1[4] * 2;
      puVar2 = param_1;
      if (7 < (uint)param_1[5]) {
        puVar2 = (undefined4 *)*param_1;
      }
      uVar1 = FUN_01686580();
      FUN_01685a20(puVar2,iStack_18,apppuStack_34,uVar1);
    }
    ppppuVar3 = apppuStack_34;
    if (0xf < uStack_20) {
      ppppuVar3 = (undefined4 ****)apppuStack_34[0];
    }
    FUN_01677520(DAT_01ef2bac,"%s: path: %s, to: %s","RBX::FileSyncItem::rename",ppppuVar3,
                 pppuStack_1c);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_20) {
      uVar4 = uStack_20 + 1;
      ppppuVar3 = (undefined4 ****)apppuStack_34[0];
      if (0xfff < uVar4) {
        ppppuVar3 = (undefined4 ****)apppuStack_34[0][-1];
        uVar4 = uStack_20 + 0x24;
        if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar3,uVar4);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
    iStack_8 = 0xffffffff;
    if (0xf < uStack_38) {
      uVar4 = uStack_38 + 1;
      ppppuVar3 = (undefined4 ****)apppuStack_4c[0];
      if (0xfff < uVar4) {
        ppppuVar3 = (undefined4 ****)apppuStack_4c[0][-1];
        uVar4 = uStack_38 + 0x24;
        if (0x1f < (uint)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar3,uVar4);
    }
  }
  FUN_0168df40(param_1,param_2,&DAT_01ef1210);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25679 ; VA 0x00ba8510 ; FUN_00ba8510 */

undefined4 * __thiscall FUN_00ba8510(int param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined *puVar4;
  char cVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  undefined **ppuStack_4c;
  int iStack_48;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  undefined ***pppuStack_28;
  undefined4 *puStack_24;
  int *piStack_20;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc647;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa8;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  puVar4 = &stack0xffffffa8;
  if (*(int *)(param_3 + 4) == 1) {
    pppuStack_28 = &ppuStack_4c;
    ppuStack_4c = std::
                  _Func_impl_no_alloc<class_<lambda_ed7d307327e73c8ab3af71a59fd18539>,bool,class_RBX::Instance*>
                  ::vftable;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    iStack_48 = param_1;
    cVar5 = FUN_00baa6e0(*(undefined4 *)(param_1 + 0xb8),pppuStack_28,1,1);
    uStack_8 = 0xffffffff;
    if (pppuStack_28 != (undefined ***)0x0) {
      (*(code *)(*pppuStack_28)[4])
                (CONCAT31((int3)((uint)&ppuStack_4c >> 8),pppuStack_28 != &ppuStack_4c));
    }
    if (cVar5 == '\0') {
      uStack_2c = 0;
      pppuStack_28 = (undefined ***)0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      FUN_005542c0("The instance is under target managed by another FSI",0x33);
      uStack_8 = 1;
      FUN_00ba6cb0(auStack_3c);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      uStack_2c = 0;
      pppuStack_28 = (undefined ***)0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8 = 2;
      FUN_006373b0(5,auStack_3c);
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
    uStack_8 = 3;
    (**(code **)(**(int **)(param_1 + 0xb8) + 0x40))(&puStack_24);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (puStack_24 != (undefined4 *)0x0) {
      puVar2 = (undefined4 *)puStack_24[1];
      for (puVar6 = (undefined4 *)*puStack_24; puVar6 != puVar2; puVar6 = puVar6 + 2) {
        (**(code **)(*(int *)*puVar6 + 0x2c))();
      }
    }
    puVar4 = puStack_14;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        puVar4 = puStack_14;
        if (iVar3 == 1) {
          (**(code **)(*piStack_20 + 4))();
          puVar4 = puStack_14;
        }
      }
    }
  }
  puStack_14 = puVar4;
  uStack_8 = 0xffffffff;
  uStack_2c = 0;
  pppuStack_28 = (undefined ***)0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 10;
  *param_2 = 0;
  param_2[1] = 0;
  puVar6 = (undefined4 *)FUN_01674e20(0x24);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6[1] = 1;
    puVar6[2] = 1;
    *puVar6 = std::
              _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::vftable;
    FUN_0054ef60(auStack_3c);
  }
  param_2[2] = puVar6 + 3;
  param_2[3] = puVar6;
  if (0xf < pppuStack_28) {
    uVar8 = (int)pppuStack_28 + 1;
    uVar7 = auStack_3c[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_3c[0] - 4);
      uVar8 = (int)pppuStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25680 ; VA 0x00ba8711 ; Catch@00ba8711 */

undefined4 Catch_00ba8711(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  uVar1 = FUN_01675640(unaff_EBP + -0x38,"Exception thrown when deleting its children :%s ",uVar1);
  *(undefined *)(unaff_EBP + -4) = 6;
  FUN_00ba6cb0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 5;
  FUN_005507b0();
  *(undefined4 *)(unaff_EBP + -0x28) = 0;
  *(undefined4 *)(unaff_EBP + -0x24) = 0xf;
  *(undefined *)(unaff_EBP + -0x38) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  *(undefined *)(unaff_EBP + -4) = 7;
  FUN_006373b0(4,unaff_EBP + -0x38);
  FUN_005507b0();
  return 0xba8618;
}



/* FUNCTION 25681 ; VA 0x00ba8785 ; Catch_All@00ba8785 */

undefined4 Catch_All_00ba8785(void)

{
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -0x28) = 0;
  *(undefined4 *)(unaff_EBP + -0x24) = 0xf;
  *(undefined *)(unaff_EBP + -0x38) = 0;
  FUN_005542c0("Exception thrown when deleting its children, unknown exception",0x3e);
  *(undefined *)(unaff_EBP + -4) = 8;
  FUN_00ba6cb0(unaff_EBP + -0x38);
  *(undefined *)(unaff_EBP + -4) = 5;
  FUN_005507b0();
  *(undefined4 *)(unaff_EBP + -0x28) = 0;
  *(undefined4 *)(unaff_EBP + -0x24) = 0xf;
  *(undefined *)(unaff_EBP + -0x38) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_006373b0(4,unaff_EBP + -0x38);
  FUN_005507b0();
  return 0xba8618;
}



/* FUNCTION 25682 ; VA 0x00ba8860 ; FUN_00ba8860 */

void __thiscall FUN_00ba8860(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x9d) != param_2) {
    *(char *)(param_1 + 0x9d) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25683 ; VA 0x00ba8890 ; FUN_00ba8890 */

void __thiscall FUN_00ba8890(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x9c) != param_2) {
    *(char *)(param_1 + 0x9c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25684 ; VA 0x00ba88c0 ; FUN_00ba88c0 */

undefined4 * __thiscall
FUN_00ba88c0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,uint param_7)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar4 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::
              _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::vftable;
    puVar4[7] = 0;
    puVar4[8] = 0;
    puVar4[3] = param_2;
    puVar4[4] = param_3;
    puVar4[5] = param_4;
    puVar4[6] = param_5;
    *(ulonglong *)(puVar4 + 7) = CONCAT44(param_7,param_6);
    param_7 = 0xf;
    param_2 = param_2 & 0xffffff00;
    puVar7 = puVar4;
  }
  puVar5 = puVar7 + 3;
  *(undefined4 **)(param_1 + 8) = puVar5;
  piVar3 = *(int **)(param_1 + 0xc);
  *(undefined4 **)(param_1 + 0xc) = puVar7;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    puVar5 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar5 = (undefined4 *)(**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar5 = (undefined4 *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < param_7) {
    uVar8 = param_7 + 1;
    uVar6 = param_2;
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(param_2 - 4);
      uVar8 = param_7 + 0x24;
      if (0x1f < (param_2 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3(puVar4);
      }
    }
    puVar5 = (undefined4 *)FUN_01674ea0(uVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 25685 ; VA 0x00ba89c0 ; FUN_00ba89c0 */

void __thiscall FUN_00ba89c0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  
  puVar1 = (undefined4 *)(param_1 + 0x7c);
  puVar3 = puVar1;
  if (7 < *(uint *)(param_1 + 0x90)) {
    puVar3 = (undefined4 *)*puVar1;
  }
  *(undefined4 *)(param_1 + 0x8c) = 0;
  *(undefined2 *)puVar3 = 0;
  iVar2 = param_2[4];
  if (iVar2 != 0) {
    puVar3 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar3 = (undefined4 *)*param_2;
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    uVar4 = FUN_01686580();
    FUN_01685950(param_2,(int)puVar3 + iVar2,puVar1,uVar4);
  }
  FUN_008a4940(&DAT_01ef2c28);
  return;
}



/* FUNCTION 25686 ; VA 0x00ba8a30 ; FUN_00ba8a30 */

void __thiscall FUN_00ba8a30(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0xc4) = param_2;
  return;
}



/* FUNCTION 25687 ; VA 0x00ba8a40 ; FUN_00ba8a40 */

void __thiscall FUN_00ba8a40(int param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc670;
  pvStack_10 = ExceptionList;
  if ((param_2 != 0) &&
     (iVar4 = *(int *)(param_2 + 0xc), ExceptionList = &pvStack_10, iVar2 = FUN_00ae2430(),
     (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    if ((char)param_3 == '\0') {
      piStack_18 = (int *)(param_1 + 0x6c);
      iVar4 = FUN_0060e0c0(auStack_24,param_2);
      puVar8 = *(undefined4 **)(param_1 + 0x6c);
      uStack_8 = 1;
      puVar5 = (undefined4 *)puVar8[1];
      puStack_14 = puVar8;
      if (*(char *)((int)puVar5 + 0xd) == '\0') {
        puVar7 = puVar5;
        do {
          if ((uint)puVar7[5] < *(uint *)(iVar4 + 4)) {
            puVar6 = (undefined4 *)puVar7[2];
          }
          else {
            if ((*(char *)((int)puVar8 + 0xd) != '\0') && (*(uint *)(iVar4 + 4) < (uint)puVar7[5]))
            {
              puVar8 = puVar7;
            }
            puVar6 = (undefined4 *)*puVar7;
            puStack_14 = puVar7;
          }
          puVar7 = puVar6;
        } while (*(char *)((int)puVar6 + 0xd) == '\0');
      }
      if (*(char *)((int)puVar8 + 0xd) == '\0') {
        puVar5 = (undefined4 *)*puVar8;
      }
      puVar7 = puStack_14;
      if (*(char *)((int)puVar5 + 0xd) == '\0') {
        do {
          if (*(uint *)(iVar4 + 4) < (uint)puVar5[5]) {
            puVar6 = (undefined4 *)*puVar5;
            puVar8 = puVar5;
          }
          else {
            puVar6 = (undefined4 *)puVar5[2];
          }
          puVar5 = puVar6;
        } while (*(char *)((int)puVar6 + 0xd) == '\0');
      }
      while (puVar7 != puVar8) {
        puVar5 = (undefined4 *)puVar7[2];
        if (*(char *)((int)puVar5 + 0xd) == '\0') {
          cVar1 = *(char *)((int)*puVar5 + 0xd);
          puVar7 = puVar5;
          puVar5 = (undefined4 *)*puVar5;
          while (cVar1 == '\0') {
            cVar1 = *(char *)((int)*puVar5 + 0xd);
            puVar7 = puVar5;
            puVar5 = (undefined4 *)*puVar5;
          }
        }
        else {
          cVar1 = *(char *)((int)puVar7[1] + 0xd);
          puVar6 = (undefined4 *)puVar7[1];
          puVar5 = puVar7;
          while ((puVar7 = puVar6, cVar1 == '\0' && (puVar5 == (undefined4 *)puVar7[2]))) {
            cVar1 = *(char *)((int)puVar7[1] + 0xd);
            puVar6 = (undefined4 *)puVar7[1];
            puVar5 = puVar7;
          }
        }
      }
      FUN_0094e3b0(&puStack_14,puStack_14,puVar8);
    }
    else {
      uVar3 = FUN_0060e0c0(auStack_1c,param_2);
      uStack_8 = 0;
      FUN_00940eb0(auStack_24,0,uVar3,param_2);
      piStack_20 = piStack_18;
    }
    uStack_8 = 0xffffffff;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_20[2] + -1;
      piStack_20[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
    FUN_00ae6610(param_3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25688 ; VA 0x00ba8be0 ; FUN_00ba8be0 */

undefined4 FUN_00ba8be0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc690;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_009ec190();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      uVar3 = FUN_00886c00(auStack_18,param_2);
      uStack_8 = 0;
      FUN_009ed830(uVar3);
      FUN_0056e380();
      FUN_0056e380();
      ExceptionList = pvStack_10;
      return 1;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b73ae0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      uVar3 = FUN_00886c00(auStack_20,param_2);
      uStack_8 = 1;
      FUN_00b75530(uVar3);
      FUN_0056e380();
      FUN_0056e380();
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 25689 ; VA 0x00ba8ce0 ; FUN_00ba8ce0 */

void __thiscall FUN_00ba8ce0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
  uVar1 = *puVar5;
  uVar2 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x94) = uVar1;
  piVar3 = *(int **)(param_1 + 0x98);
  *(undefined4 *)(param_1 + 0x98) = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_8[1] + -1;
    piStack_8[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar3 = piStack_8 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  FUN_008a4940(&DAT_01ef2c60);
  return;
}



/* FUNCTION 25690 ; VA 0x00ba8d80 ; FUN_00ba8d80 */

undefined4 * __thiscall FUN_00ba8d80(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int iVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  uint uVar10;
  int iVar11;
  undefined4 uStack_7c;
  uint *puStack_78;
  char *pcStack_74;
  undefined4 **ppuStack_70;
  undefined4 **ppuStack_6c;
  uint *puStack_68;
  undefined4 **appuStack_58 [5];
  uint uStack_44;
  uint auStack_40 [2];
  undefined auStack_38 [8];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc747;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ef2bac != 0) {
    puStack_68 = (uint *)(uint)*(byte *)(param_1 + 0x78);
    ppuStack_6c = (undefined4 **)0x195aa68;
    pcStack_74 = (char *)(uint)DAT_01ef2bac;
    ppuStack_70 = (undefined4 **)0x195aa88;
    puStack_78 = (uint *)0xba8dc2;
    ExceptionList = &pvStack_10;
    FUN_01677520();
  }
  ppuStack_6c = (undefined4 **)0xba8dcb;
  puStack_68 = (uint *)param_1;
  FUN_008f7870();
  if (*(char *)(param_1 + 0x78) != '\0') {
    puStack_68 = (uint *)0x0;
    ppuStack_6c = (undefined4 **)&DAT_018bc9b8;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    ppuStack_70 = (undefined4 **)0xba8df9;
    FUN_005542c0();
    puStack_68 = (uint *)0x24;
    uStack_8 = 0;
    *param_2 = 0;
    param_2[1] = 0;
    ppuStack_6c = (undefined4 **)0xba8e1d;
    puVar5 = (undefined4 *)FUN_01674e20();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puStack_68 = auStack_40;
      puVar5[1] = 1;
      puVar5[2] = 1;
      *puVar5 = std::
                _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                ::vftable;
      ppuStack_6c = (undefined4 **)0xba8e4d;
      FUN_0054ef60();
    }
    param_2[2] = puVar5 + 3;
    param_2[3] = puVar5;
    if (0xf < uStack_2c) {
      puStack_68 = (uint *)(uStack_2c + 1);
      uVar10 = auStack_40[0];
      if (0xfff < puStack_68) {
        uVar10 = *(uint *)(auStack_40[0] - 4);
        puStack_68 = (uint *)(uStack_2c + 0x24);
        if (0x1f < (auStack_40[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          puStack_68 = (uint *)0xba9379;
          FUN_017167a3();
        }
      }
      ppuStack_70 = (undefined4 **)0xba8e8a;
      ppuStack_6c = (undefined4 **)uVar10;
      FUN_01674ea0();
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  puStack_68 = (uint *)0xba8ead;
  FUN_005cb850();
  *(undefined *)(param_1 + 0xd0) = 1;
  ppuStack_6c = (undefined4 **)0xba8eba;
  puStack_68 = (uint *)param_1;
  uVar6 = FUN_00ba1b90();
  *(undefined4 *)(param_1 + 0xc0) = uVar6;
  iVar1 = param_1 + 0xa0;
  ppuStack_6c = (undefined4 **)(param_1 + 0x7c);
  if ((undefined4 **)iVar1 != ppuStack_6c) {
    puStack_68 = *(uint **)(param_1 + 0x8c);
    if (7 < *(uint *)(param_1 + 0x90)) {
      ppuStack_6c = (undefined4 **)*ppuStack_6c;
    }
    ppuStack_70 = (undefined4 **)0xba8ee4;
    FUN_0058ed10();
  }
  puStack_68 = (uint *)(param_1 + 0x94);
  ppuStack_6c = (undefined4 **)0xba8ef6;
  FUN_0056ecd0();
  ppuStack_6c = appuStack_58;
  ppuStack_70 = (undefined4 **)0xba8f00;
  puStack_68 = (uint *)iVar1;
  FUN_0151a940();
  uStack_8 = 2;
  ppuStack_70 = appuStack_58;
  if (0xf < uStack_44) {
    ppuStack_70 = appuStack_58[0];
  }
  puStack_78 = auStack_40;
  pcStack_74 = "Unable to enable FileSyncItem %s";
  uStack_7c = 0xba8f21;
  puStack_68 = (uint *)FUN_01675640();
  uStack_8._0_1_ = 3;
  ppuStack_6c = (undefined4 **)0xba8f30;
  FUN_00ba6cb0();
  uStack_8._0_1_ = 2;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_2c) {
    puStack_68 = (uint *)(uStack_2c + 1);
    uVar10 = auStack_40[0];
    if (0xfff < puStack_68) {
      uVar10 = *(uint *)(auStack_40[0] - 4);
      puStack_68 = (uint *)(uStack_2c + 0x24);
      if (0x1f < (auStack_40[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_68 = (uint *)&UNK_00ba937e;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    ppuStack_70 = (undefined4 **)0xba8f65;
    ppuStack_6c = (undefined4 **)uVar10;
    FUN_01674ea0();
  }
  puStack_68 = (uint *)&DAT_01ef1210;
  ppuStack_70 = (undefined4 **)&iStack_18;
  pcStack_74 = (char *)0xba8f77;
  ppuStack_6c = (undefined4 **)iVar1;
  piVar7 = (int *)FUN_0168e1c0();
  piStack_14 = (int *)piVar7[1];
  if ((*piVar7 == 0) || (*piVar7 == 1)) {
    puStack_68 = (uint *)0x15;
    ppuStack_6c = (undefined4 **)0x195aac0;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = (uint)auStack_40[0]._1_3_ << 8;
    ppuStack_70 = (undefined4 **)0xba92e8;
    FUN_005542c0();
    puStack_68 = auStack_40;
    uStack_8._0_1_ = 4;
    ppuStack_6c = (undefined4 **)0xba92f7;
    FUN_00ba6cb0();
    uStack_8._0_1_ = 2;
    puStack_68 = (uint *)0xba9303;
    FUN_005507b0();
    puStack_68 = (uint *)0x2;
    ppuStack_6c = (undefined4 **)&DAT_018cecfc;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    ppuStack_70 = (undefined4 **)0xba9324;
    FUN_005542c0();
    puStack_68 = auStack_40;
    uStack_8._0_1_ = 5;
    ppuStack_6c = (undefined4 **)auStack_28;
    ppuStack_70 = (undefined4 **)0xba9337;
    puStack_68 = (uint *)FUN_00ba4b10();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    ppuStack_6c = (undefined4 **)0x1;
  }
  else {
    iVar1 = *(int *)(param_1 + 0xb8);
    if ((iVar1 == 0) || (*(int *)(iVar1 + 0x34) == 0)) {
      puStack_68 = (uint *)0x3b;
      ppuStack_6c = (undefined4 **)0x195aad8;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = (uint)auStack_40[0]._1_3_ << 8;
      ppuStack_70 = (undefined4 **)0xba926f;
      FUN_005542c0();
      puStack_68 = auStack_40;
      uStack_8._0_1_ = 7;
      ppuStack_6c = (undefined4 **)0xba927e;
      FUN_00ba6cb0();
      uStack_8._0_1_ = 2;
      puStack_68 = (uint *)0xba928a;
      FUN_005507b0();
      puStack_68 = (uint *)0x2;
      ppuStack_6c = (undefined4 **)&DAT_018cecfc;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = auStack_40[0] & 0xffffff00;
      ppuStack_70 = (undefined4 **)0xba92ab;
      FUN_005542c0();
      puStack_68 = auStack_40;
      uStack_8._0_1_ = 8;
      ppuStack_6c = (undefined4 **)auStack_28;
      ppuStack_70 = (undefined4 **)0xba92be;
      puStack_68 = (uint *)FUN_00ba4b10();
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      ppuStack_6c = (undefined4 **)0x2;
    }
    else {
      ppuStack_6c = (undefined4 **)0xba8fb1;
      puStack_68 = (uint *)param_1;
      iVar8 = FUN_008f7870();
      if (iVar8 == 0) {
        iVar11 = 0;
      }
      else {
        iVar11 = iVar8 + 0xc;
      }
      if ((iVar1 == iVar11) || (iVar1 == *(int *)(iVar8 + 0x1b8))) {
        puStack_68 = (uint *)0x28;
        ppuStack_6c = (undefined4 **)0x195ab14;
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        ppuStack_70 = (undefined4 **)0xba91f3;
        FUN_005542c0();
        puStack_68 = auStack_40;
        uStack_8._0_1_ = 10;
        ppuStack_6c = (undefined4 **)0xba9202;
        FUN_00ba6cb0();
        uStack_8._0_1_ = 2;
        puStack_68 = (uint *)0xba920e;
        FUN_005507b0();
        puStack_68 = (uint *)0x2;
        ppuStack_6c = (undefined4 **)&DAT_018cecfc;
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        ppuStack_70 = (undefined4 **)0xba922f;
        FUN_005542c0();
        puStack_68 = auStack_40;
        uStack_8._0_1_ = 0xb;
        ppuStack_6c = (undefined4 **)auStack_28;
        ppuStack_70 = (undefined4 **)0xba9242;
        puStack_68 = (uint *)FUN_00ba4b10();
        uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
        ppuStack_6c = (undefined4 **)0x2;
      }
      else {
        puStack_68 = (uint *)0xba8fda;
        cVar4 = FUN_00ba4bd0();
        if (cVar4 == '\0') {
          ppuStack_6c = (undefined4 **)&iStack_20;
          puStack_68 = (uint *)param_3;
          ppuStack_70 = (undefined4 **)0xba9069;
          FUN_00ba8510();
          uStack_8._0_1_ = 0x10;
          uVar3 = (undefined)uStack_8;
          uStack_8._0_1_ = 0x10;
          if (iStack_20 == 0) {
            puStack_68 = (uint *)param_3;
            ppuStack_6c = (undefined4 **)auStack_38;
            ppuStack_70 = (undefined4 **)0xba90de;
            uStack_8._0_1_ = uVar3;
            piVar9 = (int *)FUN_00ba3600();
            piVar2 = piStack_14;
            iVar1 = *piVar9;
            piVar7 = (int *)piVar9[3];
            iStack_1c = piVar9[1];
            iStack_18 = piVar9[2];
            piVar9[2] = 0;
            piVar9[3] = 0;
            iStack_20 = iVar1;
            if (piStack_14 != (int *)0x0) {
              LOCK();
              iVar8 = piStack_14[1] + -1;
              piStack_14[1] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                puVar5 = (undefined4 *)*piStack_14;
                puStack_68 = (uint *)0xba911f;
                piStack_14 = piVar7;
                (*(code *)*puVar5)();
                LOCK();
                piVar7 = piVar2 + 2;
                iVar8 = *piVar7;
                *piVar7 = *piVar7 + -1;
                UNLOCK();
                piVar7 = piStack_14;
                if (iVar8 == 1) {
                  puStack_68 = (uint *)0xba912e;
                  (**(code **)(*piVar2 + 4))();
                  piVar7 = piStack_14;
                }
              }
            }
            piStack_14 = piVar7;
            puStack_68 = (uint *)0xba9136;
            FUN_0056bac0();
            uStack_30 = 0;
            uStack_2c = 0xf;
            auStack_40[0] = auStack_40[0] & 0xffffff00;
            if (iVar1 == 0) {
              puStack_68 = (uint *)0x0;
              ppuStack_6c = (undefined4 **)&DAT_018bc9b8;
              *(undefined *)(param_1 + 0x78) = 1;
              ppuStack_70 = (undefined4 **)0xba91ab;
              FUN_005542c0();
              puStack_68 = auStack_40;
              ppuStack_6c = (undefined4 **)0x0;
              uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
              ppuStack_70 = (undefined4 **)0xba91bd;
              FUN_006373b0();
              puStack_68 = (uint *)0xba91c5;
              FUN_005507b0();
              puStack_68 = (uint *)0xba91cd;
              FUN_0056bac0();
            }
            else {
              puStack_68 = (uint *)0x2;
              ppuStack_6c = (undefined4 **)&DAT_018cecfc;
              ppuStack_70 = (undefined4 **)0xba915d;
              FUN_005542c0();
              uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
              FUN_00ba4b10(&uStack_7c,auStack_40);
              FUN_00ba88c0();
              puStack_68 = (uint *)0xba9182;
              FUN_005507b0();
              puStack_68 = (uint *)&iStack_20;
              ppuStack_6c = (undefined4 **)0xba918e;
              FUN_00ba1ee0();
              puStack_68 = (uint *)0xba9196;
              FUN_0056bac0();
            }
          }
          else {
            puStack_68 = (uint *)0x2;
            ppuStack_6c = (undefined4 **)&DAT_018cecfc;
            uStack_30 = 0;
            uStack_2c = 0xf;
            auStack_40[0] = auStack_40[0] & 0xffffff00;
            ppuStack_70 = (undefined4 **)0xba9094;
            FUN_005542c0();
            uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
            FUN_00ba4b10(&uStack_7c,auStack_40);
            FUN_00ba88c0();
            puStack_68 = (uint *)0xba90b9;
            FUN_005507b0();
            puStack_68 = (uint *)&iStack_20;
            ppuStack_6c = (undefined4 **)0xba90c5;
            FUN_00ba1ee0();
            puStack_68 = (uint *)0xba90cd;
            FUN_0056bac0();
          }
          goto LAB_00ba9356;
        }
        puStack_68 = (uint *)0xe;
        ppuStack_6c = (undefined4 **)0x195ab40;
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        ppuStack_70 = (undefined4 **)0xba8fff;
        FUN_005542c0();
        puStack_68 = auStack_40;
        uStack_8._0_1_ = 0xd;
        ppuStack_6c = (undefined4 **)0xba900e;
        FUN_00ba6cb0();
        uStack_8._0_1_ = 2;
        puStack_68 = (uint *)0xba901a;
        FUN_005507b0();
        puStack_68 = (uint *)0x2;
        ppuStack_6c = (undefined4 **)&DAT_018cecfc;
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        ppuStack_70 = (undefined4 **)0xba903b;
        FUN_005542c0();
        puStack_68 = auStack_40;
        uStack_8._0_1_ = 0xe;
        ppuStack_6c = (undefined4 **)auStack_28;
        ppuStack_70 = (undefined4 **)0xba904e;
        puStack_68 = (uint *)FUN_00ba4b10();
        uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
        ppuStack_6c = (undefined4 **)0x7;
      }
    }
  }
  ppuStack_70 = (undefined4 **)0xba9346;
  FUN_006373b0();
  puStack_68 = (uint *)0xba934e;
  FUN_005507b0();
  puStack_68 = (uint *)0xba9356;
  FUN_005507b0();
LAB_00ba9356:
  puStack_68 = (uint *)0xba935e;
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25691 ; VA 0x00ba9380 ; FUN_00ba9380 */

undefined __thiscall FUN_00ba9380(undefined4 param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc770;
  pvStack_10 = ExceptionList;
  if (param_2 == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  FUN_00ba4f80(&iStack_20,*(undefined4 *)(param_2 + 0x34));
  uStack_8 = 0;
  if (iStack_20 == 0) {
    uVar3 = 0;
  }
  else {
    FUN_00ba5520(&uStack_18,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    FUN_00ba9d80(uStack_18,piStack_14);
    FUN_00bae9a0(param_1,param_2);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    FUN_00ba7ae0(uStack_18,piStack_14);
    uVar3 = 1;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar2 = piStack_14[2] + -1;
        piStack_14[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 25692 ; VA 0x00ba94c0 ; FUN_00ba94c0 */

void * FUN_00ba94c0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvVar4;
  undefined4 *puVar5;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbe08;
  pvStack_10 = ExceptionList;
  pvVar4 = ExceptionList;
  if (param_1 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    FUN_00ba9380(param_1);
    pvVar4 = (void *)(**(code **)(*param_1 + 0x40))(&puStack_18);
    uStack_8 = 0;
    if (puStack_18 != (undefined4 *)0x0) {
      puVar3 = (undefined4 *)puStack_18[1];
      for (puVar5 = (undefined4 *)*puStack_18; puVar5 != puVar3; puVar5 = puVar5 + 2) {
        pvVar4 = (void *)FUN_00ba94c0(*puVar5);
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 25693 ; VA 0x00ba9560 ; FUN_00ba9560 */

uint FUN_00ba9560(undefined4 param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint *puVar5;
  uint *puVar6;
  uint uStack_24;
  int *piStack_20;
  uint *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc79f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00ba4f80(&uStack_24,param_1);
  uStack_8 = 0;
  uVar4 = uStack_24;
  if (uStack_24 != 0) {
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    uVar4 = FUN_00ba5ba0(uStack_24,piStack_20);
    if ((char)uVar4 != '\0') {
      puVar5 = (uint *)FUN_01674e20(0x34);
      uStack_8._0_1_ = 1;
      puStack_18 = puVar5;
      if (puVar5 == (uint *)0x0) {
        puVar5 = (uint *)0x0;
      }
      else {
        puVar5[1] = 1;
        puVar5[2] = 1;
        *puVar5 = (uint)std::_Ref_count_obj<struct_RBX::FileSyncItem::InstanceMetadata>::vftable;
        FUN_0054f050(uStack_24);
        puVar5[9] = 0;
        puVar5[10] = 0;
        if (*(int *)(uStack_24 + 0x1c) != 0) {
          LOCK();
          piVar1 = (int *)(*(int *)(uStack_24 + 0x1c) + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        puVar5[9] = *(uint *)(uStack_24 + 0x18);
        puVar5[10] = *(uint *)(uStack_24 + 0x1c);
        *(undefined *)(puVar5 + 0xb) = *(undefined *)(uStack_24 + 0x20);
        puVar5[0xc] = *(uint *)(uStack_24 + 0x24);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (piStack_20 != (int *)0x0) {
        LOCK();
        piStack_20[1] = piStack_20[1] + 1;
        UNLOCK();
      }
      FUN_00ba9d80(uStack_24,piStack_20);
      uVar4 = (uint)*(byte *)(puVar5 + 0xb);
      if (*(byte *)(puVar5 + 0xb) == *(byte *)(uStack_24 + 0x20)) {
        puVar6 = puVar5 + 1;
      }
      else {
        puStack_18 = puVar5 + 1;
        if (puVar5 != (uint *)0x0) {
          LOCK();
          *puStack_18 = *puStack_18 + 1;
          UNLOCK();
        }
        FUN_00ba4120(puVar5 + 3,puVar5);
        if (puVar5 != (uint *)0x0) {
          puStack_18 = puVar5 + 1;
          LOCK();
          *puStack_18 = *puStack_18 + 1;
          UNLOCK();
        }
        FUN_00ba9cf0(puVar5 + 3,puVar5);
        uVar4 = FUN_00ba94c0(param_1);
        puVar6 = puStack_18;
      }
      if (puVar5 != (uint *)0x0) {
        LOCK();
        uVar2 = *puVar6;
        uVar4 = *puVar6;
        *puVar6 = uVar2 - 1;
        UNLOCK();
        if (uVar2 - 1 == 0) {
          (**(code **)*puVar5)();
          LOCK();
          puVar6 = puVar5 + 2;
          uVar2 = *puVar6;
          uVar4 = *puVar6;
          *puVar6 = uVar2 - 1;
          UNLOCK();
          if (uVar2 - 1 == 0) {
            uVar4 = (**(code **)(*puVar5 + 4))();
          }
        }
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    puVar5 = (uint *)(piStack_20 + 1);
    uVar2 = *puVar5;
    uVar4 = *puVar5;
    *puVar5 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar4 = (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uVar4 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 25694 ; VA 0x00ba9760 ; FUN_00ba9760 */

int * FUN_00ba9760(int *param_1,int *param_2,int *param_3,undefined4 *param_4,int *param_5)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 ****ppppuVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 ***apppuStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  undefined4 ***apppuStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc809;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_00ba5100(apppuStack_48,param_4,param_5);
  iStack_28 = 0;
  piStack_24 = (int *)0x0;
  uStack_8._0_1_ = 3;
  (**(code **)(*param_2 + 0x40))(&piStack_30);
  uStack_8._0_1_ = 4;
  iVar3 = 0;
  if (piStack_30 != (int *)0x0) {
    piVar11 = (int *)*piStack_30;
    piStack_1c = (int *)piStack_30[1];
    cStack_11 = '\0';
    if (piVar11 != piStack_1c) {
      do {
        iVar3 = *piVar11;
        piVar8 = *(int **)(iVar3 + 0x28);
        piVar1 = piVar8 + 4;
        if (0xf < (uint)piVar8[5]) {
          piVar8 = (int *)*piVar8;
        }
        ppppuVar6 = apppuStack_48;
        if (0xf < uStack_34) {
          ppppuVar6 = (undefined4 ****)apppuStack_48[0];
        }
        cVar2 = FUN_0055c360(ppppuVar6,uStack_38,piVar8,*piVar1);
        if ((cVar2 != '\0') && (iVar3 = FUN_00ba5240(iVar3), iVar3 == param_4[9])) {
          if (cStack_11 != '\0') {
            puVar4 = (undefined4 *)FUN_005569d0(apppuStack_60);
            uStack_8._0_1_ = 5;
            if (0xf < (uint)puVar4[5]) {
              puVar4 = (undefined4 *)*puVar4;
            }
            uVar5 = FUN_01675640(auStack_78,
                                 "Found multiple instances has the same name %s, unable to map",
                                 puVar4);
            uStack_8._0_1_ = 6;
            FUN_00ba6cb0(uVar5);
            FUN_005507b0();
            FUN_005507b0();
            *param_1 = 0;
            param_1[1] = 0;
            if (piStack_2c != (int *)0x0) {
              LOCK();
              iVar3 = piStack_2c[1] + -1;
              piStack_2c[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)*piStack_2c)();
                LOCK();
                iVar3 = piStack_2c[2] + -1;
                piStack_2c[2] = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  (**(code **)(*piStack_2c + 4))();
                }
              }
            }
            piVar11 = piStack_24;
            if (piStack_24 != (int *)0x0) {
              LOCK();
              iVar3 = piStack_24[1] + -1;
              piStack_24[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)*piStack_24)();
                LOCK();
                piVar1 = piVar11 + 2;
                iVar3 = *piVar1 + -1;
                *piVar1 = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  (**(code **)(*piVar11 + 4))();
                }
              }
            }
            FUN_005507b0();
            goto LAB_00ba9b03;
          }
          cStack_11 = '\x01';
          FUN_0056ecd0(piVar11);
        }
        piVar11 = piVar11 + 2;
        iVar3 = iStack_28;
      } while (piVar11 != piStack_1c);
    }
  }
  uStack_8._0_1_ = 3;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar7 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (iVar3 == 0) {
    uStack_50 = 0;
    uStack_4c = 0xf;
    apppuStack_60[0] = (undefined4 ***)((uint)apppuStack_60[0] & 0xffffff00);
    uStack_8._0_1_ = 7;
    uStack_20 = 2;
    if (param_4[4] != 0) {
      puVar4 = param_4;
      if (7 < (uint)param_4[5]) {
        puVar4 = (undefined4 *)*param_4;
      }
      piStack_1c = (int *)((int)puVar4 + param_4[4] * 2);
      if (7 < (uint)param_4[5]) {
        param_4 = (undefined4 *)*param_4;
      }
      uVar5 = FUN_01686580();
      FUN_01685a20(param_4,piStack_1c,apppuStack_60,uVar5);
    }
    ppppuVar6 = apppuStack_60;
    if (0xf < uStack_4c) {
      ppppuVar6 = (undefined4 ****)apppuStack_60[0];
    }
    uVar5 = FUN_01675640(auStack_78,"could not find instance associated with %s, unable to map",
                         ppppuVar6);
    uStack_8._0_1_ = 8;
    if (*(char *)(iStack_18 + 0xd0) != '\0') {
      iVar3 = *(int *)(iStack_18 + 200);
      piStack_1c = *(int **)(iVar3 + 4);
      iVar7 = FUN_0086f8b0(iVar3,piStack_1c,uVar5);
      if (*(int *)(iStack_18 + 0xcc) == 0x7fffffe) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(iStack_18 + 0xcc) = *(int *)(iStack_18 + 0xcc) + 1;
      *(int *)(iVar3 + 4) = iVar7;
      *piStack_1c = iVar7;
    }
    if (0xf < uStack_64) {
      uVar9 = uStack_64 + 1;
      uVar10 = auStack_78[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_78[0] - 4);
        uVar9 = uStack_64 + 0x24;
        if (0x1f < (auStack_78[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_68 = 0;
    uStack_64 = 0xf;
    auStack_78[0] = auStack_78[0] & 0xffffff00;
    if (0xf < uStack_4c) {
      uVar10 = uStack_4c + 1;
      ppppuVar6 = (undefined4 ****)apppuStack_60[0];
      if (0xfff < uVar10) {
        ppppuVar6 = (undefined4 ****)apppuStack_60[0][-1];
        uVar10 = uStack_4c + 0x24;
        if (0x1f < (uint)((int)apppuStack_60[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar6,uVar10);
    }
  }
  else {
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    FUN_00baa070(param_4,param_5,iVar3);
  }
  *param_1 = iStack_28;
  param_1[1] = (int)piStack_24;
  if (0xf < uStack_34) {
    uVar10 = uStack_34 + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_48[0];
    if (0xfff < uVar10) {
      ppppuVar6 = (undefined4 ****)apppuStack_48[0][-1];
      uVar10 = uStack_34 + 0x24;
      if (0x1f < (uint)((int)apppuStack_48[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar10);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffffff00);
LAB_00ba9b03:
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar11 = param_5 + 2;
      iVar3 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25695 ; VA 0x00ba9b80 ; FUN_00ba9b80 */

int __fastcall FUN_00ba9b80(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  bool bVar4;
  int iVar5;
  uint uVar6;
  undefined auStack_5c [12];
  undefined4 uStack_50;
  char *pcStack_4c;
  uint *puStack_48;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc830;
  pvStack_10 = ExceptionList;
  puStack_18 = auStack_5c;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_0054f050(param_1 + 0xa0);
  FUN_00ba5030(&uStack_20);
  piVar2 = piStack_1c;
  uStack_8 = 0;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  iVar5 = *(int *)(uStack_20 + 0x24);
  if (((iVar5 == 2) || (iVar5 == 3)) || (iVar5 == 4)) {
    bVar4 = true;
  }
  else {
    bVar4 = false;
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      puStack_48 = (uint *)0xba9c08;
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puStack_48 = (uint *)0xba9c18;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (bVar4) {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    pcStack_4c = (char *)uStack_20;
    puStack_48 = (uint *)piStack_1c;
    uStack_50 = 0xba9c4c;
    iVar5 = FUN_00ba7cb0();
  }
  else {
    puStack_48 = (uint *)0x33;
    pcStack_4c = "init.lua directly under the root folder is ignored.";
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    uStack_50 = 0xba9c6f;
    FUN_005542c0();
    puStack_48 = auStack_38;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    pcStack_4c = (char *)0xba9c7f;
    iVar5 = FUN_00ba6cb0();
    if (0xf < uStack_24) {
      puStack_48 = (uint *)(uStack_24 + 1);
      uVar6 = auStack_38[0];
      if (0xfff < puStack_48) {
        uVar6 = *(uint *)(auStack_38[0] - 4);
        puStack_48 = (uint *)(uStack_24 + 0x24);
        if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          puStack_48 = (uint *)&UNK_00ba9cea;
          FUN_017167a3();
        }
      }
      uStack_50 = 0xba9cac;
      pcStack_4c = (char *)uVar6;
      iVar5 = FUN_01674ea0();
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_1c + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      puStack_48 = (uint *)0xba9cc5;
      iVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_48 = (uint *)0xba9cd4;
        iVar5 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25696 ; VA 0x00ba9cf0 ; FUN_00ba9cf0 */

int FUN_00ba9cf0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc848;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00ba8200(param_1,param_2);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25697 ; VA 0x00ba9d80 ; FUN_00ba9d80 */

int FUN_00ba9d80(int param_1,int *param_2)

{
  int iVar1;
  bool bVar2;
  bool bVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined uVar7;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc889;
  pvStack_10 = ExceptionList;
  bVar3 = false;
  bVar2 = false;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490(&piStack_20);
  uStack_8._0_1_ = 1;
  if (piStack_20 == (int *)0x0) goto LAB_00ba9eb1;
  uVar5 = FUN_00ba5240(piStack_20);
  *(undefined4 *)(param_1 + 0x24) = uVar5;
  if (*(int *)(param_1 + 0x24) == 1) {
LAB_00ba9e19:
    uVar7 = 1;
  }
  else {
    piVar6 = (int *)(**(code **)(*piStack_20 + 0x40))(auStack_30);
    bVar2 = false;
    uStack_8._0_1_ = 2;
    uStack_14 = 1;
    if (*piVar6 != 0) {
      piVar6 = (int *)(**(code **)(*piStack_20 + 0x40))(auStack_28);
      bVar3 = true;
      bVar2 = true;
      if (*(int *)*piVar6 != ((int *)*piVar6)[1]) goto LAB_00ba9e19;
    }
    bVar3 = true;
    uVar7 = 0;
  }
  *(undefined *)(param_1 + 0x20) = uVar7;
  if (bVar2) {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar4 = piStack_24[2] + -1;
        piStack_24[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if ((bVar3) && (piStack_2c != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar4 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00baa4b0(param_1,param_2);
LAB_00ba9eb1:
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar6 = piStack_1c + 1;
    iVar1 = *piVar6;
    iVar4 = *piVar6;
    *piVar6 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar6 = piStack_1c + 2;
      iVar1 = *piVar6;
      iVar4 = *piVar6;
      *piVar6 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar6 = param_2 + 1;
    iVar1 = *piVar6;
    iVar4 = *piVar6;
    *piVar6 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar6 = param_2 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 25698 ; VA 0x00ba9f10 ; FUN_00ba9f10 */

int FUN_00ba9f10(int param_1,int *param_2,int param_3)

{
  bool bVar1;
  bool bVar2;
  bool bVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  undefined auStack_50 [24];
  undefined2 uStack_38;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [8];
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc8e2;
  pvStack_10 = ExceptionList;
  bVar2 = false;
  bVar1 = false;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_3) {
    ExceptionList = &pvStack_10;
    FUN_0058ed10();
  }
  FUN_0054f050(param_3);
  iStack_18 = FUN_00ba52f0();
  *(bool *)(param_1 + 0x20) = iStack_18 == 1;
  if (iStack_18 == 1) {
    uStack_28 = 0;
    uStack_24 = 7;
    uStack_38 = 0;
    uStack_8._0_1_ = 1;
    FUN_01686580();
    FUN_01685950();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
    uVar4 = FUN_005514a0(auStack_50);
    uStack_8 = 3;
    bVar2 = true;
    bVar1 = true;
    uStack_14 = 3;
    piVar5 = (int *)FUN_0168e1c0(auStack_20,uVar4,&DAT_01ef1210);
    bVar3 = true;
    if (*piVar5 == 2) goto LAB_00ba9ff5;
  }
  bVar3 = false;
LAB_00ba9ff5:
  if (bVar1) {
    FUN_00550800();
  }
  if (bVar2) {
    FUN_00550800();
  }
  iVar6 = iStack_18;
  if (bVar3) {
    iVar6 = 2;
  }
  *(int *)(param_1 + 0x24) = iVar6;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar5 = param_2 + 1;
    iVar6 = *piVar5;
    param_1 = *piVar5;
    *piVar5 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      param_1 = (**(code **)*param_2)();
      LOCK();
      piVar5 = param_2 + 2;
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        param_1 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25699 ; VA 0x00baa070 ; FUN_00baa070 */

int __thiscall FUN_00baa070(int *param_1,int param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  void **ppvVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fc918;
  puVar10 = (undefined4 *)param_1[0x17];
  iStack_8 = 0;
  puVar8 = (undefined4 *)puVar10[1];
  puVar13 = puVar10;
  if (*(char *)((int)puVar8 + 0xd) == '\0') {
    puVar9 = puVar8;
    do {
      if ((uint)puVar9[5] < *(uint *)(param_2 + 0x1c)) {
        puVar12 = (undefined4 *)puVar9[2];
      }
      else {
        if ((*(char *)((int)puVar13 + 0xd) != '\0') && (*(uint *)(param_2 + 0x1c) < (uint)puVar9[5])
           ) {
          puVar13 = puVar9;
        }
        puVar12 = (undefined4 *)*puVar9;
        puVar10 = puVar9;
      }
      puVar9 = puVar12;
    } while (*(char *)((int)puVar12 + 0xd) == '\0');
  }
  if (*(char *)((int)puVar13 + 0xd) == '\0') {
    puVar8 = (undefined4 *)*puVar13;
  }
  puStack_14 = puVar10;
  piStack_18 = param_1;
  pvStack_10 = ExceptionList;
  ppvVar7 = &pvStack_10;
  if (*(char *)((int)puVar8 + 0xd) == '\0') {
    do {
      if (*(uint *)(param_2 + 0x1c) < (uint)puVar8[5]) {
        puVar9 = (undefined4 *)*puVar8;
        puVar13 = puVar8;
      }
      else {
        puVar9 = (undefined4 *)puVar8[2];
      }
      puVar8 = puVar9;
    } while (*(char *)((int)puVar9 + 0xd) == '\0');
  }
  while (ExceptionList = ppvVar7, puStack_14 != puVar13) {
    FUN_00551320();
    ppvVar7 = (void **)ExceptionList;
  }
  FUN_00ba4780(&puStack_14,puVar10,puVar13);
  piVar2 = piStack_18;
  FUN_00587490(&uStack_1c);
  iStack_8 = CONCAT31(iStack_8._1_3_,1);
  FUN_00baf060(piVar2,uStack_1c);
  piVar6 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_18[1] + -1;
    piStack_18[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar11 = *piVar1 + -1;
      *piVar1 = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  FUN_00587490(&uStack_1c);
  iStack_8._0_1_ = 2;
  FUN_00baf060(piVar2,uStack_1c);
  piVar6 = piStack_18;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_18[1] + -1;
    piStack_18[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar11 = *piVar1 + -1;
      *piVar1 = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  puVar10 = (undefined4 *)FUN_0060e0c0(&uStack_1c,param_4);
  uVar4 = *puVar10;
  uVar5 = puVar10[1];
  *puVar10 = 0;
  puVar10[1] = 0;
  *(undefined4 *)(param_2 + 0x18) = uVar4;
  piVar6 = *(int **)(param_2 + 0x1c);
  *(undefined4 *)(param_2 + 0x1c) = uVar5;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar11 = piVar6[2] + -1;
    piVar6[2] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)(*piVar6 + 4))();
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_18[2] + -1;
    piStack_18[2] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)(*piStack_18 + 4))();
    }
  }
  piStack_28 = *(int **)(param_2 + 0x1c);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piStack_28[2] = piStack_28[2] + 1;
    UNLOCK();
    piStack_28 = *(int **)(param_2 + 0x1c);
  }
  uStack_2c = *(undefined4 *)(param_2 + 0x18);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iStack_24 = param_2;
  piStack_20 = param_3;
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  iVar11 = FUN_00ba0940(&uStack_2c);
  FUN_00ba0f70(&uStack_1c,0,iVar11 + 0x10,iVar11);
  piVar6 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_20[1] + -1;
    piStack_20[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar11 = *piVar1 + -1;
      *piVar1 = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_28[2] + -1;
    piStack_28[2] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)(*piStack_28 + 4))();
    }
  }
  FUN_00587490(&uStack_1c);
  iStack_8 = CONCAT31(iStack_8._1_3_,4);
  iVar11 = FUN_00bae9a0(piVar2,uStack_1c);
  piVar2 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar6 = piStack_18 + 1;
    iVar3 = *piVar6;
    iVar11 = *piVar6;
    *piVar6 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar6 = piVar2 + 2;
      iVar3 = *piVar6;
      iVar11 = *piVar6;
      *piVar6 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar11 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    iVar11 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar11 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar11 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar11;
}



/* FUNCTION 25700 ; VA 0x00baa330 ; FUN_00baa330 */

int __thiscall FUN_00baa330(int param_1,undefined4 *param_2,int *param_3,undefined4 *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined auStack_40 [24];
  undefined4 *puStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc940;
  puVar8 = *(undefined4 **)(param_1 + 0x54);
  piStack_1c = (int *)(param_1 + 0x54);
  uStack_8 = 0;
  cVar3 = *(char *)((int)puVar8[1] + 0xd);
  puVar4 = puVar8;
  puVar6 = (undefined4 *)puVar8[1];
  pvStack_10 = ExceptionList;
  puStack_14 = param_2;
  ExceptionList = &pvStack_10;
  while (puStack_18 = puVar4, cVar3 == '\0') {
    iVar5 = FUN_01686710(puStack_14);
    if (iVar5 < 0) {
      puVar7 = (undefined4 *)puVar6[2];
    }
    else {
      if ((*(char *)((int)puVar8 + 0xd) != '\0') && (iVar5 = FUN_01686710(puVar6 + 4), iVar5 < 0)) {
        puVar8 = puVar6;
      }
      puVar7 = (undefined4 *)*puVar6;
      puStack_18 = puVar6;
    }
    puVar4 = puStack_18;
    puVar6 = puVar7;
    cVar3 = *(char *)((int)puVar7 + 0xd);
  }
  puVar6 = puVar8;
  if (*(char *)((int)puVar8 + 0xd) != '\0') {
    puVar6 = (undefined4 *)(*piStack_1c + 4);
  }
  cVar3 = *(char *)((int)*puVar6 + 0xd);
  puVar6 = (undefined4 *)*puVar6;
  while (puVar7 = puVar4, cVar3 == '\0') {
    iVar5 = FUN_01686710(puVar6 + 4);
    if (iVar5 < 0) {
      puVar7 = (undefined4 *)*puVar6;
      puVar8 = puVar6;
    }
    else {
      puVar7 = (undefined4 *)puVar6[2];
    }
    puVar6 = puVar7;
    cVar3 = *(char *)((int)puVar7 + 0xd);
  }
  while (puStack_18 = puVar7, puStack_18 != puVar8) {
    FUN_00551320();
    puVar7 = puStack_18;
  }
  FUN_00ba4900(&puStack_18,puVar4,puVar8);
  if (param_2 != param_4) {
    puVar8 = param_4 + 4;
    if (7 < (uint)param_4[5]) {
      param_4 = (undefined4 *)*param_4;
    }
    FUN_0058ed10(param_4,*puVar8);
  }
  FUN_0054f050(param_2);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  puStack_28 = param_2;
  piStack_24 = param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar5 = FUN_00b75f50(auStack_40);
  FUN_00ba10e0(auStack_20,0,iVar5 + 0x10,iVar5);
  iVar5 = FUN_00ba2000();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25701 ; VA 0x00baa4b0 ; FUN_00baa4b0 */

int FUN_00baa4b0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iVar4;
  int ***pppiVar5;
  int *piStack_98;
  undefined auStack_94 [8];
  undefined4 uStack_8c;
  undefined *puStack_88;
  int **ppiStack_84;
  int *piStack_80;
  undefined2 auStack_70 [12];
  undefined auStack_58 [24];
  undefined2 auStack_40 [8];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int *piStack_24;
  int **ppiStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fc990;
  pvStack_10 = ExceptionList;
  piStack_80 = &iStack_28;
  uStack_8 = 0;
  ppiStack_84 = (int **)0xbaa4e9;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if (iStack_28 != 0) {
    uStack_30 = 0;
    uStack_2c = 7;
    auStack_40[0] = 0;
    piStack_80 = *(int **)(iStack_28 + 0x34);
    uStack_8._0_1_ = 2;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (piStack_80 != (int *)0x0) {
      ppiStack_84 = (int **)&ppiStack_20;
      puStack_88 = (undefined *)0xbaa52a;
      FUN_00ba4f80();
      uStack_8._0_1_ = 3;
      if (((int ***)ppiStack_20 != (int ***)0x0) && ((int **)ppiStack_20[4] != (int **)0x0)) {
        piStack_80 = (int *)0x0;
        ppiStack_84 = *(int ***)(iStack_28 + 0x28);
        puStack_88 = (undefined *)0xbaa550;
        FUN_00558140();
        piStack_80 = (int *)auStack_58;
        uStack_8._0_1_ = 4;
        puStack_88 = (undefined *)auStack_70;
        ppiStack_84 = ppiStack_20;
        uStack_8c = 0xbaa562;
        pppiVar5 = (int ***)FUN_005514a0();
        uStack_8._0_1_ = 5;
        if ((int ***)auStack_40 != pppiVar5) {
          piStack_80 = (int *)pppiVar5[4];
          if ((int **)0x7 < pppiVar5[5]) {
            pppiVar5 = (int ***)*pppiVar5;
          }
          puStack_88 = (undefined *)0xbaa585;
          ppiStack_84 = (int **)pppiVar5;
          FUN_0058ed10();
        }
        piStack_80 = (int *)0xbaa58d;
        FUN_00550800();
        uStack_8._0_1_ = 3;
        piStack_80 = (int *)0xbaa599;
        FUN_00550800();
        if (*(char *)(param_1 + 0x20) == '\0') {
          piStack_80 = *(int **)(param_1 + 0x24);
          puStack_18 = (undefined *)&piStack_98;
          FUN_0054f050(auStack_40);
          piStack_80 = (int *)FUN_00ba2a10(auStack_70);
          uStack_8._0_1_ = 6;
          ppiStack_84 = (int **)0xbaa5cf;
          FUN_0058dd00();
          uStack_8._0_1_ = 3;
          piStack_80 = (int *)0xbaa5db;
          FUN_00550800();
          puStack_18 = auStack_94;
          piStack_98 = (int *)auStack_40;
          FUN_0054f050();
          piStack_98 = (int *)auStack_70;
          piStack_80 = (int *)FUN_00ba2c50();
          uStack_8._0_1_ = 7;
          ppiStack_84 = (int **)0xbaa605;
          FUN_0058dd00();
          piStack_80 = (int *)0xbaa60d;
          FUN_00550800();
        }
      }
      uStack_8._0_1_ = 2;
      uVar3 = (undefined)uStack_8;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          piStack_80 = (int *)0xbaa627;
          (**(code **)*piStack_1c)();
          LOCK();
          iVar4 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar4;
          UNLOCK();
          uVar3 = (undefined)uStack_8;
          if (iVar4 == 0) {
            piStack_80 = (int *)0xbaa637;
            (**(code **)(*piStack_1c + 4))();
            uVar3 = (undefined)uStack_8;
          }
        }
      }
    }
    uStack_8._0_1_ = uVar3;
    piStack_80 = (int *)auStack_40;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    puStack_88 = (undefined *)param_1;
    ppiStack_84 = (int **)param_2;
    uStack_8c = 0xbaa66d;
    FUN_00baa330();
    piStack_80 = (int *)0xbaa675;
    iVar4 = FUN_00550800();
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_80 = (int *)0xbaa68b;
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_80 = (int *)0xbaa69b;
        iVar4 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_80 = (int *)0xbaa6b1;
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_80 = (int *)0xbaa6c0;
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 25702 ; VA 0x00baa6e0 ; FUN_00baa6e0 */

undefined FUN_00baa6e0(int *param_1,int param_2,int *param_3,char param_4)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  int *piVar4;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c59b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (((char)param_3 != '\0') && (ExceptionList = &pvStack_10, param_4 == '\0')) {
    piStack_14 = param_1;
    if (*(int **)(param_2 + 0x24) == (int *)0x0) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_016ddc9c();
    }
    ExceptionList = &pvStack_10;
    cVar2 = (**(code **)(**(int **)(param_2 + 0x24) + 8))(&piStack_14);
    if (cVar2 == '\0') {
      ExceptionList = pvStack_10;
      return 0;
    }
  }
  (**(code **)(*param_1 + 0x40))(&piStack_1c);
  uStack_8 = 0;
  if (piStack_1c != (int *)0x0) {
    piVar4 = (int *)*piStack_1c;
    piStack_14 = (int *)piStack_1c[1];
    if (piVar4 != piStack_14) {
      do {
        piVar3 = (int *)piVar4[1];
        if (piVar3 != (int *)0x0) {
          LOCK();
          piVar3[1] = piVar3[1] + 1;
          UNLOCK();
          piVar3 = (int *)piVar4[1];
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        cVar2 = FUN_00baa6e0(*piVar4,param_2,param_3,0);
        if (cVar2 == '\0') {
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar1 = piVar3[1] + -1;
            piVar3[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              iVar1 = piVar3[2] + -1;
              piVar3[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          if (piStack_18 == (int *)0x0) {
            ExceptionList = pvStack_10;
            return 0;
          }
          LOCK();
          iVar1 = piStack_18[1] + -1;
          piStack_18[1] = iVar1;
          UNLOCK();
          if (iVar1 != 0) {
            ExceptionList = pvStack_10;
            return 0;
          }
          (**(code **)*piStack_18)();
          LOCK();
          piVar4 = piStack_18 + 2;
          iVar1 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar1 != 1) {
            ExceptionList = pvStack_10;
            return 0;
          }
          (**(code **)(*piStack_18 + 4))();
          ExceptionList = pvStack_10;
          return 0;
        }
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar1 = piVar3[1] + -1;
          piVar3[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar1 = piVar3[2] + -1;
            piVar3[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        piVar4 = piVar4 + 2;
      } while (piVar4 != piStack_14);
    }
  }
  uStack_8 = 0xffffffff;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_18[1] + -1;
    piStack_18[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar4 = piStack_18 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (((char)param_3 == '\0') && (param_4 == '\0')) {
    param_3 = param_1;
    if (*(int **)(param_2 + 0x24) == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddc9c();
    }
    cVar2 = (**(code **)(**(int **)(param_2 + 0x24) + 8))(&param_3);
    if (cVar2 == '\0') {
      ExceptionList = pvStack_10;
      return 0;
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 25703 ; VA 0x00baa8a0 ; FUN_00baa8a0 */

undefined FUN_00baa8a0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *****pppppuVar4;
  uint uVar5;
  undefined uVar6;
  undefined4 *puVar7;
  int aiStack_dc [14];
  int aiStack_a4 [6];
  int iStack_8c;
  undefined **appuStack_74 [18];
  undefined4 uStack_2c;
  undefined4 ****appppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc9e5;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01ef2bac != '\0') {
    iVar3 = param_1[4];
    uStack_8 = 0;
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    uStack_2c = 1;
    ExceptionList = &pvStack_10;
    if (iVar3 != 0) {
      puVar2 = param_1;
      if (7 < (uint)param_1[5]) {
        puVar2 = (undefined4 *)*param_1;
      }
      puVar7 = param_1;
      if (7 < (uint)param_1[5]) {
        puVar7 = (undefined4 *)*param_1;
      }
      ExceptionList = &pvStack_10;
      uVar1 = FUN_01686580();
      FUN_01685a20(puVar7,(int)puVar2 + iVar3 * 2,appppuStack_28,uVar1);
    }
    pppppuVar4 = appppuStack_28;
    if (0xf < uStack_14) {
      pppppuVar4 = (undefined4 *****)appppuStack_28[0];
    }
    FUN_01677520(DAT_01ef2bac,"%s: path: %s","RBX::FileSyncItem::writeFile",pppppuVar4);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar5 = uStack_14 + 1;
      pppppuVar4 = (undefined4 *****)appppuStack_28[0];
      if (0xfff < uVar5) {
        pppppuVar4 = (undefined4 *****)appppuStack_28[0][-1];
        uVar5 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)pppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar4,uVar5);
    }
  }
  puVar2 = param_1;
  if (7 < (uint)param_1[5]) {
    puVar2 = (undefined4 *)*param_1;
  }
  FUN_00835210(puVar2,0x22,0x40,1);
  uVar6 = 1;
  uStack_8 = 2;
  if (iStack_8c == 0) {
    uVar6 = 0;
    iVar3 = param_1[4];
    uStack_8._0_1_ = 4;
    uStack_8._1_3_ = 0;
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    uStack_2c = 4;
    if (iVar3 != 0) {
      puVar2 = param_1;
      if (7 < (uint)param_1[5]) {
        puVar2 = (undefined4 *)*param_1;
      }
      if (7 < (uint)param_1[5]) {
        param_1 = (undefined4 *)*param_1;
      }
      uVar1 = FUN_01686580();
      FUN_01685a20(param_1,(int)puVar2 + iVar3 * 2,appppuStack_28,uVar1);
    }
    pppppuVar4 = appppuStack_28;
    if (0xf < uStack_14) {
      pppppuVar4 = (undefined4 *****)appppuStack_28[0];
    }
    FUN_0086f2f0(3,"Can not open file for write: %s",pppppuVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_14) {
      uVar5 = uStack_14 + 1;
      pppppuVar4 = (undefined4 *****)appppuStack_28[0];
      if (0xfff < uVar5) {
        pppppuVar4 = (undefined4 *****)appppuStack_28[0][-1];
        uVar5 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)pppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar4,uVar5);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
  }
  else {
    puVar2 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005af750(param_2,*puVar2,0);
    if ((*(uint *)((int)aiStack_dc + *(int *)(aiStack_dc[0] + 4) + 0xc) >> 2 & 1) != 0) {
      puVar2 = (undefined4 *)FUN_005569d0(appppuStack_28);
      uStack_8._0_1_ = 3;
      if (0xf < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      FUN_0086f2f0(3,"Write file failed: %s",puVar2);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_005507b0();
      uVar6 = 0;
    }
    iVar3 = FUN_005548a0();
    if (iVar3 == 0) {
      FUN_00554460((uint)(*(int *)((int)aiStack_a4 + *(int *)(aiStack_dc[0] + 4)) == 0) * 4 + 2 |
                   *(uint *)((int)aiStack_dc + *(int *)(aiStack_dc[0] + 4) + 0xc),0);
    }
  }
  *(undefined ***)((int)aiStack_dc + *(int *)(aiStack_dc[0] + 4)) =
       std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)((int)aiStack_dc + *(int *)(aiStack_dc[0] + 4) + -4) = *(int *)(aiStack_dc[0] + 4) + -0x68
  ;
  FUN_00550570();
  *(undefined ***)((int)aiStack_dc + *(int *)(aiStack_dc[0] + 4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)((int)aiStack_dc + *(int *)(aiStack_dc[0] + 4) + -4) = *(int *)(aiStack_dc[0] + 4) + -8;
  uStack_8 = 5;
  appuStack_74[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_74);
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 25704 ; VA 0x00baabb0 ; FUN_00baabb0 */

undefined4 * __thiscall FUN_00baabb0(undefined4 *param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined auStack_1c [4];
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fc9f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  puStack_18 = param_1;
  uVar1 = FUN_00575b30();
  *param_1 = uVar1;
  uStack_8 = 0;
  iStack_14 = param_3;
  if (param_2 != param_3) {
    do {
      uVar1 = *param_1;
      iVar2 = FUN_00559300(param_2);
      FUN_0064c760(auStack_1c,uVar1,iVar2 + 0x10,iVar2);
      param_2 = param_2 + 0x18;
    } while (param_2 != iStack_14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25705 ; VA 0x00baac40 ; FUN_00baac40 */

undefined FUN_00baac40(void)

{
  if ((DAT_01ef2ec9 != '\0') && (DAT_01d679d0 != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 25706 ; VA 0x00baac60 ; FUN_00baac60 */

void FUN_00baac60(void)

{
  undefined auStack_10 [12];
  
  if ((DAT_01ef2ec9 != '\0') && (DAT_01d679d0 != '\0')) {
    return;
  }
  FUN_00550130("Internal Permission is required for this feature.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 25707 ; VA 0x00baaca0 ; FUN_00baaca0 */

int FUN_00baaca0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fca48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bab870(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  *(undefined4 *)(iVar1 + 0x20) = *(undefined4 *)(param_3 + 0x18);
  *(undefined4 *)(iVar1 + 0x24) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (*(undefined4 **)(param_3 + 0x1c) != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)(param_3 + 0x1c))(param_3 + 0x20,iVar1 + 0x28);
  }
  *(undefined4 *)(iVar1 + 0x24) = *(undefined4 *)(param_3 + 0x1c);
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 25708 ; VA 0x00baad2e ; Catch_All@00baad2e */

void Catch_All_00baad2e(void)

{
  int unaff_EBP;
  
  FUN_00bac350(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25709 ; VA 0x00baad50 ; FUN_00baad50 */

void FUN_00baad50(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_00bab730();
      param_1 = param_1 + 0x58;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 25710 ; VA 0x00baad80 ; FUN_00baad80 */

void __thiscall FUN_00baad80(float *param_1,float *param_2,undefined4 *param_3,float *param_4)

{
  byte *pbVar1;
  float fVar2;
  float *pfVar3;
  undefined *puVar4;
  char cVar5;
  uint uVar6;
  float fVar7;
  undefined4 *puVar8;
  uint uVar9;
  float fVar10;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fca60;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  puVar8 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar8 = (undefined4 *)*param_3;
  }
  uVar6 = 0;
  uVar9 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar6 + (int)puVar8);
      uVar6 = uVar6 + 1;
      uVar9 = (*pbVar1 ^ uVar9) * 0x1000193;
    } while (uVar6 < (uint)param_3[4]);
  }
  fVar7 = param_1[3];
  uVar9 = (uint)param_1[6] & uVar9;
  fVar10 = param_1[1];
  ExceptionList = &pvStack_10;
  pfStack_18 = param_1;
  puVar4 = &stack0xffffffd0;
  if (fVar10 != *(float *)((int)fVar7 + uVar9 * 8)) {
    fVar10 = **(float **)((int)fVar7 + 4 + uVar9 * 8);
    ExceptionList = &pvStack_10;
    while (puVar4 = puStack_14, fVar10 != *(float *)((int)fVar7 + uVar9 * 8)) {
      fVar10 = *(float *)((int)fVar10 + 4);
      cVar5 = FUN_00570290(param_3,(int)fVar10 + 8);
      fVar7 = param_1[3];
      if (cVar5 != '\0') {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_00baba10(param_4);
        *param_2 = fVar10;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  puStack_14 = puVar4;
  pfStack_1c = param_4;
  fVar7 = *param_4;
  if (fVar10 != fVar7) {
    *(float *)param_4[1] = fVar7;
    **(float **)((int)fVar7 + 4) = fVar10;
    **(undefined4 **)((int)fVar10 + 4) = param_4;
    fVar2 = *(float *)((int)fVar10 + 4);
    *(undefined4 *)((int)fVar10 + 4) = *(undefined4 *)((int)fVar7 + 4);
    *(float *)((int)fVar7 + 4) = param_4[1];
    param_4[1] = fVar2;
  }
  fVar7 = param_1[3];
  fVar2 = *(float *)((int)fVar7 + uVar9 * 8);
  if (fVar2 == param_1[1]) {
    *(float **)((int)fVar7 + uVar9 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar9 * 8) = param_4;
  }
  else if (fVar2 == fVar10) {
    *(float **)((int)fVar7 + uVar9 * 8) = param_4;
  }
  else {
    pfVar3 = (float *)**(undefined4 **)((int)fVar7 + 4 + uVar9 * 8);
    *(float **)((int)fVar7 + 4 + uVar9 * 8) = pfVar3;
    if (pfVar3 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar9 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar9 * 8) + 4);
    }
  }
  fVar7 = param_1[7];
  uStack_8 = 2;
  fVar10 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
           (float)((double)(int)fVar7 + (double)(&DAT_018c0d90)[-((int)fVar7 >> 0x1f)]);
  if (*param_1 <= fVar10 && fVar10 != *param_1) {
    if ((uint)fVar7 < 0x200) {
      fVar7 = (float)((int)fVar7 << 3);
    }
    else if ((uint)fVar7 < 0x1fffffff) {
      fVar7 = (float)((int)fVar7 * 2);
    }
    FUN_00a1aac0(fVar7);
    pfVar3 = (float *)param_1[1];
    if ((float *)*pfVar3 != pfVar3) {
      fVar7 = pfVar3[1];
      do {
        fVar10 = *(float *)param_1[1];
        FUN_00baad80(auStack_24,(int)fVar10 + 8,fVar10);
      } while (fVar10 != fVar7);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25711 ; VA 0x00baaf66 ; Catch_All@00baaf66 */

void Catch_All_00baaf66(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x18));
  FUN_00bab3c0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25712 ; VA 0x00baaf8c ; Catch_All@00baaf8c */

void Catch_All_00baaf8c(void)

{
  int unaff_EBP;
  
  FUN_00bab9e0(*(undefined4 *)(unaff_EBP + 0x10));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25713 ; VA 0x00baafb0 ; FUN_00baafb0 */

void __thiscall FUN_00baafb0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fca70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::SessionizedEventIngest>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25714 ; VA 0x00bab01e ; Catch_All@00bab01e */

void Catch_All_00bab01e(void)

{
  int unaff_EBP;
  
  if (*(int **)(unaff_EBP + 8) != (int *)0x0) {
    (**(code **)(**(int **)(unaff_EBP + 8) + 0x10))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25715 ; VA 0x00bab040 ; FUN_00bab040 */

void __thiscall FUN_00bab040(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fca80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::StandardEventIngest>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25716 ; VA 0x00bab0ae ; Catch_All@00bab0ae */

void Catch_All_00bab0ae(void)

{
  int unaff_EBP;
  
  if (*(int **)(unaff_EBP + 8) != (int *)0x0) {
    (**(code **)(**(int **)(unaff_EBP + 8) + 0x10))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25717 ; VA 0x00bab0d0 ; FUN_00bab0d0 */

void __thiscall
FUN_00bab0d0(int param_1,undefined4 *param_2,byte *param_3,undefined4 param_4,undefined4 param_5)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  byte *pbVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  int iVar10;
  byte *pbVar11;
  undefined4 *puVar12;
  int iVar13;
  bool bVar14;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fcaa0;
  pvStack_10 = ExceptionList;
  uVar7 = *(uint *)(param_3 + 0x14);
  pbVar5 = param_3;
  if (0xf < uVar7) {
    pbVar5 = *(byte **)param_3;
  }
  uVar1 = *(uint *)(param_3 + 0x10);
  pbVar11 = param_3;
  if (0xf < uVar7) {
    pbVar11 = *(byte **)param_3;
  }
  iVar10 = (int)(pbVar5 + uVar1) - (int)pbVar11;
  uStack_14 = 0;
  iVar13 = 0;
  if (pbVar5 + uVar1 < pbVar11) {
    iVar10 = 0;
  }
  if (iVar10 != 0) {
    do {
      iVar13 = iVar13 + 1;
      uStack_14 = uStack_14 ^ (uStack_14 >> 2) + 0x9e3779b9 + uStack_14 * 0x40 + (int)(char)*pbVar11
      ;
      pbVar11 = pbVar11 + 1;
    } while (iVar13 != iVar10);
  }
  uVar9 = uStack_14 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar8 = (int *)0x0;
  }
  else {
    puVar12 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar12 == (undefined4 *)0x0) {
      piVar8 = (int *)0x0;
    }
    else {
      piVar8 = (int *)*puVar12;
    }
    if (piVar8 == (int *)0x0) goto LAB_00bab24a;
    do {
      if (uStack_14 == piVar8[1]) {
        pbVar5 = (byte *)(piVar8 + 2);
        if (0xf < (uint)piVar8[7]) {
          pbVar5 = *(byte **)pbVar5;
        }
        pbVar11 = param_3;
        if (0xf < uVar7) {
          pbVar11 = *(byte **)param_3;
        }
        uVar6 = uVar1;
        if (uVar1 == piVar8[6]) {
          while (uVar4 = uVar6 - 4, 3 < uVar6) {
            if (*(int *)pbVar11 != *(int *)pbVar5) goto LAB_00bab1d7;
            pbVar11 = pbVar11 + 4;
            pbVar5 = pbVar5 + 4;
            uVar6 = uVar4;
          }
          if (uVar4 == 0xfffffffc) {
LAB_00bab20b:
            uVar6 = 0;
          }
          else {
LAB_00bab1d7:
            bVar14 = *pbVar11 < *pbVar5;
            if ((*pbVar11 == *pbVar5) &&
               ((uVar4 == 0xfffffffd ||
                ((bVar14 = pbVar11[1] < pbVar5[1], pbVar11[1] == pbVar5[1] &&
                 ((uVar4 == 0xfffffffe ||
                  ((bVar14 = pbVar11[2] < pbVar5[2], pbVar11[2] == pbVar5[2] &&
                   ((uVar4 == 0xffffffff ||
                    (bVar14 = pbVar11[3] < pbVar5[3], pbVar11[3] == pbVar5[3]))))))))))))
            goto LAB_00bab20b;
            uVar6 = -(uint)bVar14 | 1;
          }
          if (uVar6 == 0) break;
        }
      }
      else if ((uint)piVar8[1] % *(uint *)(param_1 + 4) != uVar9) goto LAB_00bab24a;
      piVar8 = (int *)*piVar8;
    } while (piVar8 != (int *)0x0);
  }
  if (piVar8 != (int *)0x0) {
    *param_2 = piVar8;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_00bab24a:
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar8 = (int *)FUN_01674e20(0x38);
  *piVar8 = 0;
  piVar8[1] = 0;
  FUN_0170d1f0(piVar8 + 2,0,0x30);
  FUN_0054ef60(param_4);
  iStack_8._0_1_ = 1;
  FUN_0054ef60(param_5);
  uVar1 = *(uint *)(param_1 + 8);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005d6bb0(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    uVar9 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar9 = 1;
    }
    iVar10 = FUN_005d6bb0(uVar9 + uVar1);
    if (iVar10 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar10);
      puVar12 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar12;
      while (puVar2 != (undefined4 *)0x0) {
        uVar7 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar3 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar7 * 4) == 0) {
          *piVar3 = (int)puVar12;
          puVar12 = puVar2;
        }
        else {
          *puVar12 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar12;
      }
    }
  }
  piVar8[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  puVar12 = (undefined4 *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar3 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar8;
    }
    *puVar12 = piVar3;
    *piVar8 = *piVar3;
    *piVar3 = (int)piVar8;
  }
  else {
    *piVar8 = *piVar3;
    *(int **)*puVar12 = piVar8;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar8;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25718 ; VA 0x00bab3c0 ; FUN_00bab3c0 */

void __thiscall FUN_00bab3c0(int param_1,int *param_2,int *param_3)

{
  byte *pbVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  
  piVar5 = param_3 + 2;
  if (0xf < (uint)param_3[7]) {
    piVar5 = (int *)*piVar5;
  }
  uVar3 = 0;
  uVar6 = 0x811c9dc5;
  if (param_3[6] != 0) {
    do {
      pbVar1 = (byte *)(uVar3 + (int)piVar5);
      uVar3 = uVar3 + 1;
      uVar6 = (*pbVar1 ^ uVar6) * 0x1000193;
    } while (uVar3 < (uint)param_3[6]);
  }
  iVar2 = (*(uint *)(param_1 + 0x18) & uVar6) * 8;
  piVar5 = *(int **)(*(int *)(param_1 + 0xc) + iVar2);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if ((int *)piVar4[1] == param_3) {
    if (piVar5 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar2 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar5 == param_3) {
    *piVar4 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00baba10(param_3);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 25719 ; VA 0x00bab470 ; FUN_00bab470 */

int __thiscall FUN_00bab470(int param_1,int param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcad9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x18);
  *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_2 + 0x30);
  *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_2 + 0x34);
  *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_2 + 0x38);
  uStack_8._0_1_ = 1;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  uVar1 = FUN_00bab870(0,0);
  *(undefined4 *)(param_1 + 0x3c) = uVar1;
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00bab8a0((undefined4 *)(param_2 + 0x38));
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25720 ; VA 0x00bab520 ; FUN_00bab520 */

undefined4 * __fastcall FUN_00bab520(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcb06;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::SessionizedEventIngest::vftable;
  puStack_14 = param_1;
  FUN_016dee4c(param_1 + 1,2);
  uStack_8 = 0;
  piVar2 = (int *)FUN_01016f90(auStack_1c);
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xd] = -(uint)(*piVar2 != 0) & *piVar2 + 4U;
  param_1[0xe] = piVar2[1];
  *piVar2 = 0;
  piVar2[1] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_18[1] + -1;
    piStack_18[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piStack_18 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  puVar3 = (undefined4 *)FUN_01674e20(4);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::StandardEventIngest::vftable;
  }
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  FUN_00bab040(puVar3,puStack_14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25721 ; VA 0x00bab610 ; FUN_00bab610 */

void __fastcall FUN_00bab610(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00bac280();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0xf0);
  return;
}



/* FUNCTION 25722 ; VA 0x00bab680 ; FUN_00bab680 */

void __fastcall FUN_00bab680(undefined4 *param_1)

{
  FUN_00bac280();
  FUN_01674ea0(*param_1,0xf0);
  return;
}



/* FUNCTION 25723 ; VA 0x00bab6a0 ; FUN_00bab6a0 */

void __fastcall FUN_00bab6a0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00bac280();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0xf0);
  return;
}



/* FUNCTION 25724 ; VA 0x00bab6b0 ; FUN_00bab6b0 */

void __fastcall FUN_00bab6b0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00bab730();
        iVar2 = iVar2 + 0x58;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x58) * 0x58;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 25725 ; VA 0x00bab730 ; FUN_00bab730 */

void __fastcall FUN_00bab730(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00bab610();
  uVar1 = param_1[0xb];
  if (0xf < uVar1) {
    iVar2 = param_1[6];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bab7bf;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00bab7bf:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 25726 ; VA 0x00bab7d0 ; FUN_00bab7d0 */

int __thiscall FUN_00bab7d0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x40);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x38);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016dedfb(param_1 + 4);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x44);
  }
  return param_1;
}



/* FUNCTION 25727 ; VA 0x00bab850 ; FUN_00bab850 */

undefined4 __thiscall FUN_00bab850(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 25728 ; VA 0x00bab870 ; FUN_00bab870 */

void FUN_00bab870(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0xf0);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 25729 ; VA 0x00bab8a0 ; FUN_00bab8a0 */

void __thiscall FUN_00bab8a0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_24 [8];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcb10;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  puVar1 = param_1 + 1;
  ExceptionList = &pvStack_10;
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  puStack_18 = param_1;
  FUN_00bac280();
  *param_1 = *puVar2;
  param_2 = (undefined4 *)*puVar1;
  uStack_8 = 0;
  FUN_00a1ab20((int)(puVar2[4] - puVar2[3]) >> 2,&param_2);
  puVar2 = (undefined4 *)puVar2[1];
  puVar4 = (undefined4 *)*puVar2;
  while( true ) {
    if (puVar4 == puVar2) {
      ExceptionList = pvStack_10;
      return;
    }
    param_2 = *(undefined4 **)*puVar1;
    puStack_1c = *(undefined4 **)((int)param_2 + 4);
    uVar3 = FUN_00baaca0(param_2,puStack_1c,puVar4 + 2);
    if (param_1[2] == 0x1111110) break;
    param_1[2] = param_1[2] + 1;
    *(undefined4 *)((int)param_2 + 4) = uVar3;
    *puStack_1c = uVar3;
    FUN_00baad80(auStack_24,*(int *)*puVar1 + 8,*(int *)*puVar1);
    puVar4 = (undefined4 *)*puVar4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 25730 ; VA 0x00bab984 ; Catch_All@00bab984 */

void Catch_All_00bab984(void)

{
  FUN_00bac200();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25731 ; VA 0x00bab9a0 ; FUN_00bab9a0 */

void __fastcall FUN_00bab9a0(int param_1)

{
  if (*(int **)(param_1 + 0xc) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0xc) + 0x10))(1);
  }
  return;
}



/* FUNCTION 25732 ; VA 0x00bab9b0 ; FUN_00bab9b0 */

void FUN_00bab9b0(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_00bab730();
      param_1 = param_1 + 0x58;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 25733 ; VA 0x00bab9e0 ; FUN_00bab9e0 */

void __thiscall FUN_00bab9e0(int param_1,int *param_2)

{
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00baba10(param_2);
  return;
}



/* FUNCTION 25734 ; VA 0x00baba10 ; FUN_00baba10 */

void FUN_00baba10(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x24) != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*(int *)(param_1 + 0x24) + 8))(param_1 + 0x28);
  }
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  FUN_01674ea0(param_1,0xf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25735 ; VA 0x00babab0 ; FUN_00babab0 */

undefined4 __thiscall FUN_00babab0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined uVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 ****ppppuVar4;
  uint *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined8 uVar11;
  int aiStack_124 [5];
  uint uStack_110;
  undefined auStack_10c [8];
  undefined auStack_104 [8];
  undefined auStack_fc [8];
  uint auStack_f4 [4];
  undefined4 uStack_e4;
  uint uStack_e0;
  undefined4 *puStack_dc;
  int iStack_d8;
  uint uStack_c4;
  uint uStack_c0;
  undefined4 uStack_b0;
  uint uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined auStack_80 [4];
  undefined4 uStack_7c;
  undefined4 *puStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  undefined4 ***pppuStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  undefined8 uStack_58;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  undefined8 uStack_40;
  int iStack_38;
  int iStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fcbff;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined4 *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0060e660(param_3);
  puVar10 = (undefined4 *)0x1;
  uStack_8 = 0;
  puStack_14 = (undefined4 *)0x1;
  (**(code **)(**(int **)(param_1 + 0x34) + 4))(&iStack_74);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  iStack_34 = iStack_74;
  iStack_38 = iStack_70;
  iVar6 = iStack_70;
  if (iStack_74 != iStack_70) {
    puStack_dc = &uStack_a0;
    iVar9 = iStack_74;
    do {
      iStack_34 = iVar9;
      puStack_18 = puVar10;
      FUN_0054ef60(iVar9);
      uStack_8._0_1_ = 2;
      FUN_0054ef60(iVar9 + 0x18);
      uStack_a8 = *(undefined4 *)(iVar9 + 0x30);
      uStack_a4 = *(undefined4 *)(iVar9 + 0x34);
      uStack_a0 = *(undefined4 *)(iVar9 + 0x38);
      uStack_8._0_1_ = 3;
      uStack_9c = 0;
      uStack_98 = 0;
      uStack_9c = FUN_00bab870(0,0);
      uStack_94 = 0;
      uStack_90 = 0;
      uStack_8c = 0;
      uStack_8._0_1_ = 5;
      FUN_00bab8a0((undefined4 *)(iVar9 + 0x38));
      uStack_8._0_1_ = 6;
      FUN_00da5df0(auStack_f4);
      uStack_8._0_1_ = 7;
      piVar2 = (int *)FUN_00585d40(0,&DAT_0195b028,3);
      puStack_14 = (undefined4 *)((uint)puVar10 | 2);
      pppuStack_68 = (undefined4 ***)*piVar2;
      iStack_64 = piVar2[1];
      iStack_60 = piVar2[2];
      iStack_5c = piVar2[3];
      uStack_58 = *(undefined8 *)(piVar2 + 4);
      piVar2[4] = 0;
      piVar2[5] = 0xf;
      *(undefined *)piVar2 = 0;
      uStack_8._0_1_ = 9;
      uVar1 = (undefined)uStack_8;
      uStack_8._0_1_ = 9;
      if (0xf < uStack_e0) {
        uVar7 = uStack_e0 + 1;
        uVar8 = auStack_f4[0];
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(auStack_f4[0] - 4);
          uVar7 = uStack_e0 + 0x24;
          if (0x1f < (auStack_f4[0] - uVar8) - 4) goto LAB_00bac1f3;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      uStack_e4 = 0;
      uStack_e0 = 0xf;
      auStack_f4[0] = auStack_f4[0] & 0xffffff00;
      uVar3 = FUN_01015b70(&uStack_50);
      iVar6 = (int)uStack_58;
      puStack_18 = (undefined4 *)((uint)puStack_18 | 6);
      uStack_8._0_1_ = 0xb;
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = auStack_30[0] & 0xffffff00;
      puStack_14 = puStack_18;
      FUN_0058a190((int)uStack_58 + 3);
      ppppuVar4 = &pppuStack_68;
      if (0xf < uStack_58._4_4_) {
        ppppuVar4 = (undefined4 ****)pppuStack_68;
      }
      FUN_00554150(ppppuVar4,iVar6);
      FUN_00554150(&DAT_0195b02c,3);
      FUN_00bab0d0(auStack_fc,auStack_30,auStack_30,uVar3);
      puVar10 = (undefined4 *)((uint)puStack_18 & 0xfffffffb);
      uStack_8._0_1_ = 10;
      puStack_14 = puVar10;
      if (0xf < uStack_1c) {
        uVar7 = uStack_1c + 1;
        uVar8 = auStack_30[0];
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(auStack_30[0] - 4);
          uVar7 = uStack_1c + 0x24;
          uVar1 = (undefined)uStack_8;
          if (0x1f < (auStack_30[0] - uVar8) - 4) goto LAB_00bac1f3;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = auStack_30[0] & 0xffffff00;
      uStack_8._0_1_ = 9;
      if (0xf < uStack_40._4_4_) {
        uVar7 = uStack_40._4_4_ + 1;
        uVar8 = uStack_50;
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(uStack_50 - 4);
          uVar7 = uStack_40._4_4_ + 0x24;
          uVar1 = (undefined)uStack_8;
          if (0x1f < (uStack_50 - uVar8) - 4) goto LAB_00bac1f3;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      uVar11 = FUN_010159f0();
      uVar3 = FUN_01675640(&uStack_50,&DAT_018bed48,uVar11);
      puStack_18 = (undefined4 *)((uint)puVar10 | 8);
      uStack_8._0_1_ = 0xd;
      iVar6 = (int)uStack_58;
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = auStack_30[0] & 0xffffff00;
      puStack_14 = puStack_18;
      FUN_0058a190((int)uStack_58 + 3);
      ppppuVar4 = &pppuStack_68;
      if (0xf < uStack_58._4_4_) {
        ppppuVar4 = (undefined4 ****)pppuStack_68;
      }
      FUN_00554150(ppppuVar4,iVar6);
      FUN_00554150(&DAT_0195b030,3);
      FUN_00bab0d0(auStack_104,auStack_30,auStack_30,uVar3);
      puVar10 = (undefined4 *)((uint)puStack_18 & 0xfffffff7);
      uStack_8._0_1_ = 0xc;
      puStack_14 = puVar10;
      if (0xf < uStack_1c) {
        uVar7 = uStack_1c + 1;
        uVar8 = auStack_30[0];
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(auStack_30[0] - 4);
          uVar7 = uStack_1c + 0x24;
          uVar1 = (undefined)uStack_8;
          if (0x1f < (auStack_30[0] - uVar8) - 4) goto LAB_00bac1f3;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = auStack_30[0] & 0xffffff00;
      uStack_8._0_1_ = 9;
      if (0xf < uStack_40._4_4_) {
        uVar7 = uStack_40._4_4_ + 1;
        uVar8 = uStack_50;
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(uStack_50 - 4);
          uVar7 = uStack_40._4_4_ + 0x24;
          uVar1 = (undefined)uStack_8;
          if (0x1f < (uStack_50 - uVar8) - 4) goto LAB_00bac1f3;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      FUN_010156b0(&param_3);
      piVar2 = (int *)FUN_010156d0(auStack_80);
      if (param_3 != (undefined4 *)*piVar2) {
        do {
          puStack_78 = puVar10;
          uStack_7c = FUN_00563690(aiStack_124);
          puStack_18 = param_3 + 2;
          iVar6 = (int)uStack_58;
          puStack_14 = (undefined4 *)((uint)puVar10 | 0x20);
          uStack_8._0_1_ = 0xf;
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = auStack_30[0] & 0xffffff00;
          FUN_0058a190((int)uStack_58 + 4);
          ppppuVar4 = &pppuStack_68;
          if (0xf < uStack_58._4_4_) {
            ppppuVar4 = (undefined4 ****)pppuStack_68;
          }
          FUN_00554150(ppppuVar4,iVar6);
          FUN_00554150(&DAT_0195b034,4);
          puVar10 = puStack_18;
          if (0xf < (uint)puStack_18[5]) {
            puVar10 = (undefined4 *)*puStack_18;
          }
          puVar5 = (uint *)FUN_00554150(puVar10,puStack_18[4]);
          puVar10 = (undefined4 *)((uint)puStack_78 | 0x60);
          uStack_50 = *puVar5;
          uStack_4c = puVar5[1];
          uStack_48 = puVar5[2];
          uStack_44 = puVar5[3];
          uStack_40 = *(undefined8 *)(puVar5 + 4);
          puVar5[4] = 0;
          puVar5[5] = 0xf;
          *(undefined *)puVar5 = 0;
          uStack_8._0_1_ = 0x10;
          puStack_14 = puVar10;
          FUN_00bab0d0(auStack_10c,&uStack_50,&uStack_50,uStack_7c);
          uStack_8._0_1_ = 0xf;
          if (0xf < uStack_40._4_4_) {
            uVar7 = uStack_40._4_4_ + 1;
            uVar8 = uStack_50;
            if (0xfff < uVar7) {
              uVar8 = *(uint *)(uStack_50 - 4);
              uVar7 = uStack_40._4_4_ + 0x24;
              uVar1 = (undefined)uStack_8;
              if (0x1f < (uStack_50 - uVar8) - 4) goto LAB_00bac1f3;
            }
            FUN_01674ea0(uVar8,uVar7);
          }
          puVar10 = (undefined4 *)((uint)puVar10 & 0xffffffdf);
          uStack_40 = 0xf00000000;
          uStack_50 = uStack_50 & 0xffffff00;
          uStack_8._0_1_ = 0xe;
          puStack_14 = puVar10;
          if (0xf < uStack_1c) {
            uVar7 = uStack_1c + 1;
            uVar8 = auStack_30[0];
            if (0xfff < uVar7) {
              uVar8 = *(uint *)(auStack_30[0] - 4);
              uVar7 = uStack_1c + 0x24;
              uVar1 = (undefined)uStack_8;
              if (0x1f < (auStack_30[0] - uVar8) - 4) goto LAB_00bac1f3;
            }
            FUN_01674ea0(uVar8,uVar7);
          }
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = auStack_30[0] & 0xffffff00;
          uStack_8._0_1_ = 9;
          if (0xf < uStack_110) {
            uVar8 = uStack_110 + 1;
            iVar6 = aiStack_124[0];
            if (0xfff < uVar8) {
              iVar6 = *(int *)(aiStack_124[0] + -4);
              uVar8 = uStack_110 + 0x24;
              uVar1 = (undefined)uStack_8;
              if (0x1f < (aiStack_124[0] - iVar6) - 4U) goto LAB_00bac1f3;
            }
            FUN_01674ea0(iVar6,uVar8);
          }
          param_3 = (undefined4 *)*param_3;
          piVar2 = (int *)FUN_010156d0(auStack_80);
        } while (param_3 != (undefined4 *)*piVar2);
      }
      uStack_8._0_1_ = 6;
      if (0xf < uStack_58._4_4_) {
        uVar8 = uStack_58._4_4_ + 1;
        ppppuVar4 = (undefined4 ****)pppuStack_68;
        if (0xfff < uVar8) {
          ppppuVar4 = (undefined4 ****)pppuStack_68[-1];
          uVar8 = uStack_58._4_4_ + 0x24;
          uVar1 = (undefined)uStack_8;
          if (0x1f < (uint)((int)pppuStack_68 + (-4 - (int)ppppuVar4))) goto LAB_00bac1f3;
        }
        FUN_01674ea0(ppppuVar4,uVar8);
      }
      uStack_8._0_1_ = 1;
      FUN_00bab610();
      if (0xf < uStack_ac) {
        uVar7 = uStack_ac + 1;
        uVar8 = uStack_c0;
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(uStack_c0 - 4);
          uVar7 = uStack_ac + 0x24;
          uVar1 = (undefined)uStack_8;
          if (0x1f < (uStack_c0 - uVar8) - 4) goto LAB_00bac1f3;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      uStack_b0 = 0;
      uStack_ac = 0xf;
      uStack_c0 = uStack_c0 & 0xffffff00;
      if (0xf < uStack_c4) {
        uVar8 = uStack_c4 + 1;
        iVar6 = iStack_d8;
        if (0xfff < uVar8) {
          iVar6 = *(int *)(iStack_d8 + -4);
          uVar8 = uStack_c4 + 0x24;
          uVar1 = (undefined)uStack_8;
          if (0x1f < (iStack_d8 - iVar6) - 4U) goto LAB_00bac1f3;
        }
        FUN_01674ea0(iVar6,uVar8);
      }
      iVar9 = iStack_34 + 0x58;
      iVar6 = iStack_70;
      iStack_34 = iVar9;
    } while (iVar9 != iStack_38);
  }
  iVar9 = iStack_74;
  if (iStack_74 != 0) {
    for (; iVar9 != iVar6; iVar9 = iVar9 + 0x58) {
      FUN_00bab730();
    }
    uVar8 = ((iStack_6c - iStack_74) / 0x58) * 0x58;
    iVar6 = iStack_74;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iStack_74 + -4);
      uVar8 = uVar8 + 0x23;
      uVar1 = (undefined)uStack_8;
      if (0x1f < (iStack_74 - iVar6) - 4U) {
LAB_00bac1f3:
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25736 ; VA 0x00bac200 ; FUN_00bac200 */

void __fastcall FUN_00bac200(int param_1)

{
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00bac280();
  if ((uint)(*(int *)(param_1 + 0x14) - *(int *)(param_1 + 0xc) >> 2) < 0x10) {
    FUN_005cb650(0x10);
  }
  iStack_14 = *(int *)(param_1 + 4);
  FUN_00a1ab20(0x10,&iStack_14);
  *(undefined4 *)(param_1 + 0x18) = 7;
  *(undefined4 *)(param_1 + 0x1c) = 8;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25737 ; VA 0x00bac280 ; FUN_00bac280 */

void __fastcall FUN_00bac280(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  piVar6 = (int *)*piVar1;
  ExceptionList = &pvStack_10;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar6 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar6;
      uStack_8 = 0;
      if (piVar6[9] != 0) {
        (**(code **)(piVar6[9] + 8))(piVar6 + 10);
      }
      uVar2 = piVar6[7];
      uStack_8 = 0xffffffff;
      if (0xf < uVar2) {
        iVar3 = piVar6[2];
        uVar5 = uVar2 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      piVar6[6] = 0;
      piVar6[7] = 0xf;
      *(undefined *)(piVar6 + 2) = 0;
      FUN_01674ea0(piVar6,0xf0);
      piVar6 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25738 ; VA 0x00bac350 ; FUN_00bac350 */

void FUN_00bac350(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0xf0;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 25739 ; VA 0x00bac390 ; FUN_00bac390 */

void FUN_00bac390(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_c [8];
  
  FUN_00bab0d0(auStack_c,param_2,param_2,param_3);
  return;
}



/* FUNCTION 25740 ; VA 0x00bac3b0 ; FUN_00bac3b0 */

void FUN_00bac3b0(undefined4 *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcc41;
  pvStack_10 = ExceptionList;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2ed4) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ef2ed4), DAT_01ef2ed4 == -1)) {
    uStack_8 = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x44);
    puStack_14 = puVar1;
    if (puVar1 == (undefined4 *)0x0) {
      puVar1 = (undefined4 *)0x0;
    }
    else {
      *puVar1 = RBX::SessionizedEventIngest::vftable;
      FUN_016dee4c(puVar1 + 1,2);
      uStack_8._0_1_ = 2;
      piVar2 = (int *)FUN_01016f90(auStack_1c);
      puVar1[0xd] = 0;
      puVar1[0xe] = 0;
      puVar1[0xd] = -(uint)(*piVar2 != 0) & *piVar2 + 4U;
      puVar1[0xe] = piVar2[1];
      *piVar2 = 0;
      piVar2[1] = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_18[1] + -1;
        piStack_18[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar2 = piStack_18 + 2;
          iVar4 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
      puVar3 = (undefined4 *)FUN_01674e20(4);
      if (puVar3 == (undefined4 *)0x0) {
        puVar3 = (undefined4 *)0x0;
      }
      else {
        *puVar3 = RBX::StandardEventIngest::vftable;
      }
      puVar1[0xf] = 0;
      puVar1[0x10] = 0;
      FUN_00bab040(puVar3,param_1);
    }
    uStack_8 = uStack_8 & 0xffffff00;
    DAT_01ef2ecc = 0;
    DAT_01ef2ed0 = 0;
    FUN_00baafb0(puVar1,param_1);
    FUN_016f3654(&LAB_018915a0);
    FUN_016f37bf(&DAT_01ef2ed4);
  }
  iVar4 = DAT_01ef2ed0;
  *param_1 = 0;
  param_1[1] = 0;
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = DAT_01ef2ed0;
  }
  *param_1 = DAT_01ef2ecc;
  param_1[1] = iVar4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25741 ; VA 0x00bac560 ; FUN_00bac560 */

void __thiscall
FUN_00bac560(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_34 [24];
  int iStack_1c;
  undefined uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcc60;
  pvStack_10 = ExceptionList;
  iVar4 = param_1 + 4;
  ExceptionList = &pvStack_10;
  iStack_1c = iVar4;
  iStack_14 = param_1;
  iVar2 = FUN_016dee6d(iVar4);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_18 = 1;
  uStack_8 = 0;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x3c) + 0xc);
  uVar3 = FUN_00babab0(auStack_34,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (*pcVar1)(param_2,param_3,param_4,uVar3);
  FUN_0056cfd0();
  uStack_8 = 2;
  iVar4 = FUN_016deec8(iVar4);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25742 ; VA 0x00bac610 ; FUN_00bac610 */

void FUN_00bac610(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_008794f0(param_1,param_2,param_3,param_4);
  return;
}



/* FUNCTION 25743 ; VA 0x00bac630 ; FUN_00bac630 */

void __thiscall
FUN_00bac630(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_34 [24];
  int iStack_1c;
  undefined uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcc60;
  pvStack_10 = ExceptionList;
  iVar4 = param_1 + 4;
  ExceptionList = &pvStack_10;
  iStack_1c = iVar4;
  iStack_14 = param_1;
  iVar2 = FUN_016dee6d(iVar4);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_18 = 1;
  uStack_8 = 0;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x3c) + 8);
  uVar3 = FUN_00babab0(auStack_34,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (*pcVar1)(param_2,param_3,param_4,uVar3);
  FUN_0056cfd0();
  uStack_8 = 2;
  iVar4 = FUN_016deec8(iVar4);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25744 ; VA 0x00bac6e0 ; FUN_00bac6e0 */

void FUN_00bac6e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_00879580(param_1,param_2,param_3,param_4);
  return;
}



/* FUNCTION 25745 ; VA 0x00bac700 ; FUN_00bac700 */

void __thiscall
FUN_00bac700(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_34 [24];
  int iStack_1c;
  undefined uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcc60;
  pvStack_10 = ExceptionList;
  iVar4 = param_1 + 4;
  ExceptionList = &pvStack_10;
  iStack_1c = iVar4;
  iStack_14 = param_1;
  iVar2 = FUN_016dee6d(iVar4);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_18 = 1;
  uStack_8 = 0;
  pcVar1 = *(code **)**(undefined4 **)(param_1 + 0x3c);
  uVar3 = FUN_00babab0(auStack_34,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (*pcVar1)(param_2,param_3,param_4,uVar3);
  FUN_0056cfd0();
  uStack_8 = 2;
  iVar4 = FUN_016deec8(iVar4);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25746 ; VA 0x00bac7b0 ; FUN_00bac7b0 */

void FUN_00bac7b0(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_30 [24];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcc88;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  puStack_18 = auStack_30;
  ExceptionList = &pvStack_10;
  FUN_0060e660();
  uStack_8 = 0;
  FUN_0054ef60();
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_1);
  uStack_8 = 0xffffffff;
  FUN_0087a540();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25747 ; VA 0x00bac840 ; FUN_00bac840 */

void __thiscall
FUN_00bac840(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_34 [24];
  int iStack_1c;
  undefined uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcc60;
  pvStack_10 = ExceptionList;
  iVar4 = param_1 + 4;
  ExceptionList = &pvStack_10;
  iStack_1c = iVar4;
  iStack_14 = param_1;
  iVar2 = FUN_016dee6d(iVar4);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_18 = 1;
  uStack_8 = 0;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x3c) + 4);
  uVar3 = FUN_00babab0(auStack_34,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (*pcVar1)(param_2,param_3,param_4,uVar3);
  FUN_0056cfd0();
  uStack_8 = 2;
  iVar4 = FUN_016deec8(iVar4);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25748 ; VA 0x00bac8f0 ; FUN_00bac8f0 */

void FUN_00bac8f0(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_30 [24];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcc88;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  puStack_18 = auStack_30;
  ExceptionList = &pvStack_10;
  FUN_0060e660();
  uStack_8 = 0;
  FUN_0054ef60();
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_1);
  uStack_8 = 0xffffffff;
  FUN_0087ac30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25749 ; VA 0x00bac980 ; FUN_00bac980 */

undefined * FUN_00bac980(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2ee8) {
    FUN_016f3809(&DAT_01ef2ee8);
    if (DAT_01ef2ee8 == -1) {
      FUN_016f3654(&LAB_018915e0);
      FUN_016f37bf(&DAT_01ef2ee8);
    }
  }
  return &DAT_01ef2ee4;
}


