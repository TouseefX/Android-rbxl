/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 21250 ; VA 0x00a6e210 ; FUN_00a6e210 */

void __thiscall FUN_00a6e210(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  
  iVar2 = param_1[1];
  iVar3 = *param_1;
  iVar8 = FUN_00577fb0(param_2);
  puVar9 = (undefined4 *)*param_1;
  puVar4 = (undefined4 *)param_1[1];
  if (puVar9 != puVar4) {
    iVar10 = iVar8 - (int)puVar9;
    do {
      uVar5 = puVar9[1];
      uVar6 = puVar9[2];
      uVar7 = puVar9[3];
      puVar1 = (undefined4 *)(iVar10 + (int)puVar9);
      *puVar1 = *puVar9;
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      *(undefined8 *)(iVar10 + 0x10 + (int)puVar9) = *(undefined8 *)(puVar9 + 4);
      puVar9 = puVar9 + 6;
    } while (puVar9 != puVar4);
  }
  FUN_00616d60(iVar8,(iVar2 - iVar3) / 0x18,param_2);
  return;
}



/* FUNCTION 21251 ; VA 0x00a6e270 ; FUN_00a6e270 */

int __fastcall FUN_00a6e270(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  
  iVar5 = param_1[2] * param_1[1] * *param_1 * 2;
  uVar4 = FUN_01674e20(iVar5);
  FUN_0170d1f0(uVar4,0,iVar5);
  FUN_00a6d6f0(uVar4,&LAB_00a6edc0);
  param_1[4] = 0;
  piVar3 = (int *)param_1[5];
  iVar5 = 0;
  param_1[5] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar5;
}



/* FUNCTION 21252 ; VA 0x00a6e300 ; FUN_00a6e300 */

void __thiscall FUN_00a6e300(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0x20);
  if (*(undefined4 **)(param_1 + 0x24) != puVar1) {
    *puVar1 = param_2;
    *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + 4;
    return;
  }
  FUN_006030d0(puVar1,&param_2);
  return;
}



/* FUNCTION 21253 ; VA 0x00a6e330 ; FUN_00a6e330 */

void __fastcall FUN_00a6e330(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 4) == 0) {
    ExceptionList = &pvStack_10;
    *(undefined2 *)(param_1 + 8) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x5c);
    *(undefined4 **)(param_1 + 4) = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    FUN_0170d1f0(puVar1 + 2,0,0x54);
    *(undefined *)(param_1 + 8) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  if (*(char *)(param_1 + 9) != '\0') {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(*(int *)(param_1 + 4) + 0x14,0x10,4,FUN_00a6de20);
    *(undefined *)(param_1 + 9) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21254 ; VA 0x00a6e3d0 ; FUN_00a6e3d0 */

void FUN_00a6e3d0(int *param_1,int *param_2,int param_3,uint param_4,int *param_5,int param_6)

{
  ushort uVar1;
  ushort uVar2;
  int iVar3;
  undefined2 uVar4;
  char *pcVar5;
  byte bVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  undefined1 *puVar13;
  int iVar14;
  uint uVar15;
  int iVar16;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  uint uStack_44;
  uint uStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined1 *puStack_20;
  int iStack_1c;
  undefined1 *puStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  byte bStack_5;
  
  piStack_24 = (int *)(param_4 * 0x10 + param_3);
  bStack_5 = *(byte *)(param_3 + 0x44);
  FUN_00a71450(&iStack_60,param_2);
  if (((iStack_60 != iStack_54) && (iStack_5c != iStack_50)) && (iStack_58 != iStack_4c)) {
    iVar9 = iStack_54 - iStack_60;
    iStack_10 = iStack_60 - *param_5;
    iVar10 = iStack_5c - param_5[1];
    iStack_28 = iStack_58 - param_5[2];
    iStack_4c = iStack_4c - iStack_58;
    iStack_38 = iStack_60 - *param_2;
    iVar14 = iStack_5c - param_2[1];
    iStack_34 = iStack_58 - param_2[2];
    iStack_c = iStack_50 - iStack_5c;
    iStack_14 = iStack_4c;
    if (((param_4 < 3) && (bStack_5 != 0xff)) && (param_6 != 1)) {
      if (0 < iStack_c) {
        iStack_2c = 4 - param_4;
        iVar14 = iVar14 - iVar10;
        do {
          iStack_30 = 0;
          if (0 < iStack_4c) {
            iStack_1c = 3 - param_4;
            iStack_3c = iVar10 >> ((byte)iStack_1c & 0x1f);
            iStack_48 = iStack_34 - iStack_28;
            param_6 = iStack_28;
            do {
              uVar1 = *(ushort *)
                       (*piStack_24 + (iVar10 * piStack_24[2] + iStack_28 + iStack_30) * 2);
              uStack_44 = (uint)uVar1;
              uVar15 = uStack_44 & 0xfff;
              if ((short)uVar1 < 0) {
                puStack_18 = (undefined1 *)
                             (piStack_24[1] + (uVar15 * piStack_24[2] + iStack_10) * 2);
              }
              else {
                puStack_18 = &DAT_01ee9940 + (uVar15 * 0x20 + iStack_10) * 2;
              }
              bVar6 = (byte)iStack_1c;
              uVar2 = *(ushort *)
                       (*(int *)(param_3 + 0x30) +
                       (iStack_3c * *(int *)(param_3 + 0x38) + (param_6 >> (bVar6 & 0x1f))) * 2);
              uStack_40 = (uint)uVar2;
              uVar7 = uStack_40 & 0xfff;
              if ((short)uVar2 < 0) {
                puStack_20 = (undefined1 *)
                             (*(int *)(param_3 + 0x34) + uVar7 * *(int *)(param_3 + 0x38) * 2);
              }
              else {
                puStack_20 = &DAT_01ee9940 + uVar7 * 0x40;
              }
              if ((short)uVar1 < 0) {
                uVar15 = 0xffffffff;
              }
              if ((short)uVar2 < 0) {
                uVar7 = 0xffffffff;
              }
              if (param_1[4] == 0) {
                if (uVar7 != 0) {
                  if (0 < (int)uVar7) goto LAB_00a6e5f0;
                  iVar11 = iVar9 >> (bVar6 & 0x1f);
                  iVar8 = 0;
                  if (0 < iVar11) {
                    pcVar5 = puStack_20 + (iStack_10 >> (bVar6 & 0x1f)) * 2;
                    do {
                      if (*pcVar5 != '\0') goto LAB_00a6e5f0;
                      iVar8 = iVar8 + 1;
                      pcVar5 = pcVar5 + 2;
                    } while (iVar8 < iVar11);
                  }
                }
                if (uVar15 != 0) {
                  if (0 < (int)uVar15) goto LAB_00a6e5f0;
                  iVar8 = 0;
                  if (0 < iVar9) {
                    do {
                      if (puStack_18[iVar8 * 2] != '\0') goto LAB_00a6e5f0;
                      iVar8 = iVar8 + 1;
                    } while (iVar8 < iVar9);
                  }
                }
              }
              else {
LAB_00a6e5f0:
                iVar8 = param_1[4];
                if (iVar8 == 0) {
                  FUN_00a6e270();
                  iVar8 = param_1[4];
                }
                iVar12 = 0;
                iVar11 = param_1[3];
                iVar3 = *param_1;
                bVar6 = (byte)iStack_2c;
                if (0 < iVar9) {
                  iVar16 = iStack_10;
                  do {
                    if ((bStack_5 &
                        '\x01' << ((byte)(iVar16 >> (bVar6 & 0x1f)) & 1 |
                                  (((byte)(param_6 >> (bVar6 & 0x1f)) & 1) * '\x02' |
                                  (byte)(iVar10 >> (bVar6 & 0x1f)) & 1) * '\x02')) == 0) {
                      uVar4 = *(undefined2 *)(puStack_20 + (iVar16 >> ((byte)iStack_1c & 0x1f)) * 2)
                      ;
                    }
                    else {
                      uVar4 = *(undefined2 *)(puStack_18 + iVar12 * 2);
                    }
                    iVar16 = iVar16 + 1;
                    *(undefined2 *)
                     (iVar8 + ((iStack_48 + param_6) * iVar3 +
                              (iVar10 + iVar14) * iVar11 + iStack_38) * 2 + iVar12 * 2) = uVar4;
                    iVar12 = iVar12 + 1;
                  } while (iVar12 < iVar9);
                }
              }
              param_6 = param_6 + 1;
              iStack_30 = iStack_30 + 1;
              iStack_4c = iStack_14;
            } while (iStack_30 < iStack_14);
          }
          iVar10 = iVar10 + 1;
          iStack_c = iStack_c + -1;
          if (iStack_c == 0) {
            return;
          }
        } while( true );
      }
    }
    else if (0 < iStack_c) {
      iVar10 = iVar10 - iVar14;
      iStack_30 = iVar9;
      do {
        iVar9 = 0;
        if (0 < iStack_4c) {
          do {
            uVar1 = *(ushort *)
                     (*piStack_24 + ((iVar10 + iVar14) * piStack_24[2] + iStack_28 + iVar9) * 2);
            uVar15 = uVar1 & 0xfff;
            if ((short)uVar1 < 0) {
              puVar13 = (undefined1 *)(piStack_24[1] + (uVar15 * piStack_24[2] + iStack_10) * 2);
              uVar15 = 0xffffffff;
            }
            else {
              puVar13 = &DAT_01ee9940 + (uVar15 * 0x20 + iStack_10) * 2;
            }
            iVar8 = param_1[4];
            if (iVar8 == 0) {
              if (uVar15 != 0) {
                if (0 < (int)uVar15) {
LAB_00a6e75d:
                  FUN_00a6e270();
                  iVar8 = param_1[4];
                  goto LAB_00a6e767;
                }
                iVar8 = 0;
                if (0 < iStack_30) {
                  do {
                    if (puVar13[iVar8 * 2] != '\0') goto LAB_00a6e75d;
                    iVar8 = iVar8 + 1;
                  } while (iVar8 < iStack_30);
                }
              }
            }
            else {
LAB_00a6e767:
              FUN_0170c6f0(iVar8 + (param_1[3] * iVar14 + (iStack_34 + iVar9) * *param_1 + iStack_38
                                   ) * 2,puVar13,iStack_30 * 2);
            }
            iVar9 = iVar9 + 1;
            iStack_4c = iStack_14;
          } while (iVar9 < iStack_14);
        }
        iVar14 = iVar14 + 1;
        iStack_c = iStack_c + -1;
      } while (iStack_c != 0);
    }
  }
  return;
}



/* FUNCTION 21255 ; VA 0x00a6e7c0 ; FUN_00a6e7c0 */

undefined4 FUN_00a6e7c0(int *param_1,int *param_2,int *param_3,int *param_4)

{
  ushort *puVar1;
  ushort uVar2;
  byte *pbVar3;
  byte *pbVar4;
  int iVar5;
  byte bVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  byte *pbVar11;
  int iVar12;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  uint uStack_4c;
  int iStack_48;
  uint uStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  byte *pbStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  char cStack_7;
  byte bStack_6;
  byte bStack_5;
  
  FUN_00a71450(&iStack_64,param_2);
  if (((iStack_64 != iStack_58) && (iStack_60 != iStack_54)) && (iStack_5c != iStack_50)) {
    iStack_40 = iStack_64 - *param_4;
    iStack_c = iStack_60 - param_4[1];
    iStack_3c = iStack_5c - param_4[2];
    iStack_10 = iStack_60 - param_2[1];
    iStack_1c = iStack_64 - *param_2;
    iStack_24 = iStack_5c - param_2[2];
    iStack_58 = iStack_58 - iStack_64;
    iStack_38 = iStack_54 - iStack_60;
    iStack_50 = iStack_50 - iStack_5c;
    bVar6 = 0;
    cStack_7 = '\0';
    bStack_5 = 0;
    if (0 < iStack_38) {
      iVar10 = iStack_c - iStack_10;
      iStack_34 = iVar10;
      iStack_2c = iStack_50;
      iStack_28 = iStack_58;
      iStack_20 = iStack_38;
      iStack_14 = iStack_10;
      do {
        iStack_18 = 0;
        if (0 < iStack_50) {
          uStack_44 = iStack_58 * 2;
LAB_00a6e883:
          if (param_3[4] == 0) {
            pbStack_30 = &DAT_01ee9940;
          }
          else {
            pbStack_30 = (byte *)(param_3[4] +
                                 ((iStack_18 + iStack_3c) * *param_3 +
                                 (iStack_10 + iVar10) * param_3[3] + iStack_40) * 2);
          }
          uVar2 = *(ushort *)(*param_1 + (param_1[2] * iStack_10 + iStack_24 + iStack_18) * 2);
          uVar7 = uVar2 & 0xfff;
          pbVar4 = pbStack_30;
          uVar8 = uStack_44;
          if ((short)uVar2 < 0) {
            pbVar3 = (byte *)(param_1[1] + (param_1[2] * uVar7 + iStack_1c) * 2);
            pbVar11 = pbVar3;
          }
          else {
            pbVar3 = &DAT_01ee9940 + (uVar7 * 0x20 + iStack_1c) * 2;
            pbVar11 = pbVar3;
          }
          while (uVar7 = uVar8 - 4, 3 < uVar8) {
            if (*(int *)pbVar3 != *(int *)pbVar4) goto LAB_00a6e91a;
            pbVar3 = pbVar3 + 4;
            pbVar4 = pbVar4 + 4;
            uVar8 = uVar7;
          }
          if (uVar7 != 0xfffffffc) {
LAB_00a6e91a:
            if ((*pbVar3 == *pbVar4) &&
               ((uVar7 == 0xfffffffd ||
                ((pbVar3[1] == pbVar4[1] &&
                 ((uVar7 == 0xfffffffe ||
                  ((pbVar3[2] == pbVar4[2] && ((uVar7 == 0xffffffff || (pbVar3[3] == pbVar4[3]))))))
                 )))))) goto LAB_00a6ea4e;
            bStack_6 = *pbStack_30;
            cStack_7 = '\x01';
            uStack_4c = (uint)bStack_6;
            iVar10 = 0;
            bVar6 = (byte)((int)-uStack_4c >> 0x1f);
            if (0 < iStack_1c) {
              do {
                if ((pbVar11[iVar10 * 2 + iStack_1c * -2] != bStack_6) ||
                   (pbVar11[iVar10 * 2 + iStack_1c * -2 + 1] != bVar6)) goto LAB_00a6ea1e;
                iVar10 = iVar10 + 1;
              } while (iVar10 < iStack_1c);
            }
            iStack_48 = iStack_28 + iStack_1c;
            if (iVar10 < iStack_48) {
              pbVar4 = pbStack_30 + (iVar10 - iStack_1c) * 2;
              do {
                if ((*pbVar4 != bStack_6) || (pbVar4[1] != bVar6)) goto LAB_00a6ea1e;
                iVar10 = iVar10 + 1;
                pbVar4 = pbVar4 + 2;
              } while (iVar10 < iStack_48);
            }
            for (; uVar8 = uStack_4c, iVar10 < param_1[2]; iVar10 = iVar10 + 1) {
              if ((pbVar11[iVar10 * 2 + iStack_1c * -2] != bStack_6) ||
                 (pbVar11[iVar10 * 2 + iStack_1c * -2 + 1] != bVar6)) goto LAB_00a6ea1e;
            }
            goto LAB_00a6e9e7;
          }
          goto LAB_00a6ea4e;
        }
LAB_00a6ea69:
        iStack_10 = iStack_10 + 1;
        iStack_38 = iStack_38 + -1;
      } while (iStack_38 != 0);
      if (bVar6 != 0) {
        FUN_00a71e60();
      }
      if (cStack_7 != '\0') {
        iVar5 = iStack_14 - iStack_c;
        iVar10 = iStack_2c;
        iStack_14 = iVar5;
        do {
          iVar9 = 0;
          iVar12 = iStack_c;
          if (0 < iVar10) {
            do {
              uVar2 = *(ushort *)
                       (*param_1 + ((iVar5 + iVar12) * param_1[2] + iStack_24 + iVar9) * 2);
              if (((short)uVar2 < 0) &&
                 (iVar10 = param_1[1] + ((uVar2 & 0xfff) * param_1[2] + iStack_1c) * 2, iVar10 != 0)
                 ) {
                if (param_3[4] == 0) {
                  FUN_0170d1f0(iVar10,0);
                  iVar12 = iStack_c;
                }
                else {
                  FUN_0170c6f0(iVar10,param_3[4] +
                                      (param_3[3] * iStack_c +
                                      (iStack_3c + iVar9) * *param_3 + iStack_40) * 2,iStack_28 * 2)
                  ;
                  iVar12 = iStack_c;
                }
              }
              iVar9 = iVar9 + 1;
              iVar10 = iStack_2c;
              iVar5 = iStack_14;
            } while (iVar9 < iStack_2c);
          }
          iStack_c = iVar12 + 1;
          iStack_20 = iStack_20 + -1;
        } while (iStack_20 != 0);
        return 1;
      }
    }
  }
  return 0;
LAB_00a6ea1e:
  uVar8 = 0xffffffff;
LAB_00a6e9e7:
  FUN_00a700c0();
  puVar1 = (ushort *)(*param_1 + (param_1[2] * iStack_10 + iStack_18 + iStack_24) * 2);
  if ((int)uVar8 < 0) {
    if (-1 < (short)*puVar1) {
      *puVar1 = *puVar1 | 0x4000;
      bStack_5 = bStack_5 | 1;
    }
  }
  else {
    uVar2 = *puVar1;
    *puVar1 = (ushort)uVar8 & 0xff;
    bStack_5 = bStack_5 | (byte)(uVar2 >> 0xf);
  }
LAB_00a6ea4e:
  iStack_18 = iStack_18 + 1;
  iStack_50 = iStack_2c;
  iStack_58 = iStack_28;
  iVar10 = iStack_34;
  bVar6 = bStack_5;
  if (iStack_2c <= iStack_18) goto LAB_00a6ea69;
  goto LAB_00a6e883;
}



/* FUNCTION 21256 ; VA 0x00a6eb50 ; FUN_00a6eb50 */

int FUN_00a6eb50(int param_1,undefined *param_2)

{
  ushort uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined1 *puVar6;
  int iVar7;
  int iStack_8;
  
  uVar4 = 0;
  *param_2 = 1;
  iStack_8 = 0;
  iVar3 = *(int *)(param_1 + 0x38);
  if (0 < iVar3) {
    do {
      iVar7 = 0;
      do {
        uVar1 = *(ushort *)
                 (*(int *)(param_1 + 0x30) + (*(int *)(param_1 + 0x38) * iStack_8 + iVar7) * 2);
        uVar5 = uVar1 & 0xfff;
        if ((short)uVar1 < 0) {
          puVar6 = (undefined1 *)(*(int *)(param_1 + 0x34) + uVar5 * *(int *)(param_1 + 0x38) * 2);
        }
        else {
          puVar6 = &DAT_01ee9940 + uVar5 * 0x40;
        }
        iVar2 = 0;
        do {
          if ((puVar6[iVar2 * 2] != '\0') &&
             (*param_2 = 0,
             (*(byte *)(param_1 + 0x44) &
             '\x01' << ((byte)(iVar2 >> 1) & 1 | ((byte)iVar7 & 2) * '\x02' | (byte)iStack_8 & 2))
             != 0)) {
            uVar4 = uVar4 + (byte)puVar6[iVar2 * 2 + 1] + 1;
          }
          iVar2 = iVar2 + 1;
        } while (iVar2 < iVar3);
        iVar7 = iVar7 + 1;
      } while (iVar7 < iVar3);
      iStack_8 = iStack_8 + 1;
    } while (iStack_8 < iVar3);
  }
  iVar3 = (uVar4 & 0x7fffff) * 2;
  if (uVar4 == 0) {
    return 0;
  }
  if ((uVar4 & 0x7fffff) == 0) {
    iVar3 = 1;
  }
  return iVar3;
}



/* FUNCTION 21257 ; VA 0x00a6ec40 ; FUN_00a6ec40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00a6ec40(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  float10 fVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e27d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar6 = param_2 + 1;
  if ((uVar6 < 0x40000000) && (uVar6 * 4 < 0x1000)) {
    if (uVar6 * 4 == 0) {
      puVar7 = (undefined4 *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar7 = (undefined4 *)FUN_01674e20();
    }
  }
  else {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_01674e20();
    if (iVar2 == 0) goto LAB_00a6edb7;
    puVar7 = (undefined4 *)(iVar2 + 0x23U & 0xffffffe0);
    puVar7[-1] = iVar2;
  }
  for (puVar3 = puVar7; puVar3 != puVar7 + uVar6; puVar3 = puVar3 + 1) {
    *puVar3 = 0;
  }
  if (*(int *)(param_1 + 0x14) != 0) {
    puVar7[param_2] = *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar1 = *(int *)(param_1 + 0x14);
    iVar4 = iVar1;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar1 - iVar4) - 4U) {
LAB_00a6edb7:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  *(int *)(param_1 + 4) = param_2;
  *(undefined4 **)(param_1 + 0x14) = puVar7;
  if (puVar7 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    fVar8 = (float10)FUN_01725160((double)*(float *)(param_1 + 0xc) *
                                  ((double)param_2 + (double)(&DAT_018c0d90)[-(param_2 >> 0x1f)]));
    if ((double)fVar8 < _DAT_018c4e98) {
      uVar5 = FUN_016f3eb1();
    }
    else {
      uVar5 = 0xffffffff;
    }
  }
  *(undefined4 *)(param_1 + 0x10) = uVar5;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21258 ; VA 0x00a6edd0 ; FUN_00a6edd0 */

/* WARNING: Type propagation algorithm not settling */

uint FUN_00a6edd0(int param_1,uint param_2,uint *param_3,int *param_4,int *param_5)

{
  byte bVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  ushort uVar8;
  char cVar10;
  int iVar9;
  int *piVar11;
  int iVar12;
  int *piVar13;
  undefined auStack_30 [4];
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  uint uStack_1c;
  int *piStack_18;
  int iStack_14;
  int iStack_10;
  uint uStack_c;
  undefined2 uStack_8;
  undefined2 uStack_6;
  
  iStack_14 = param_4[2];
  iVar7 = param_4[1];
  iStack_20 = *param_4;
  iStack_24 = iVar7;
  FUN_00a6d550(iStack_14 * iVar7 * iStack_20,param_5);
  uStack_c = 0;
  iStack_10 = 1;
  if (param_5[1] - *param_5 >> 1 == 0) {
    uVar6 = 0;
    iStack_10 = 1;
  }
  else {
    do {
      uVar6 = *param_3;
      uVar2 = uVar6;
      if (param_2 <= uVar6) {
LAB_00a6f091:
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Error while decoding data: unexpected end at offset %u",uVar2);
      }
      bVar1 = *(byte *)(uVar6 + param_1);
      uVar2 = uVar6 + 1;
      *param_3 = uVar2;
      if ((bVar1 & 0x40) == 0) {
        uVar8 = (ushort)CONCAT31((uint3)bVar1,0xff);
      }
      else {
        if (param_2 <= uVar2) goto LAB_00a6f091;
        uVar8 = CONCAT11(bVar1,*(undefined *)(uVar2 + param_1));
        uVar2 = uVar6 + 2;
        *param_3 = uVar2;
      }
      if ((char)bVar1 < '\0') {
        if (param_2 <= uVar2) goto LAB_00a6f091;
        bVar1 = *(byte *)(uVar2 + param_1);
        *param_3 = uVar2 + 1;
        piVar11 = (int *)(bVar1 + 1);
      }
      else {
        piVar11 = (int *)0x1;
      }
      iVar7 = *param_5;
      uVar8 = uVar8 & 0x3fff;
      cVar10 = (char)(uVar8 >> 8);
      uStack_8 = CONCAT11((byte)((int)-(uint)(uVar8 >> 8) >> 0x1f) & (byte)uVar8,cVar10);
      uStack_1c = uStack_c + (int)piVar11;
      if ((uint)(param_5[1] - iVar7 >> 1) < uStack_1c) {
        FUN_016756b0(auStack_30,"Error while decoding data: chunk overflow at %u cells",uStack_1c);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_30,&DAT_01c17198);
      }
      piVar3 = (int *)0x0;
      if ((piVar11 != (int *)0x0) && (&DAT_00000007 < piVar11)) {
        piStack_18 = (int *)(iVar7 + uStack_c * 2);
        piStack_28 = (int *)(iVar7 + (uStack_1c + -1) * 2);
        if ((param_5 < piStack_18) || (piStack_28 < param_5)) {
          do {
            piVar3 = piVar3 + 2;
          } while (piVar3 < (int *)((uint)piVar11 & 0xfffffff8));
          piVar13 = piStack_18;
          for (uVar6 = (((uint)piVar11 >> 3) << 4) >> 2; uVar6 != 0; uVar6 = uVar6 - 1) {
            *piVar13 = CONCAT22(uStack_8,uStack_8);
            piVar13 = piVar13 + 1;
          }
          for (iVar7 = 0; iVar7 != 0; iVar7 = iVar7 + -1) {
            *(undefined2 *)piVar13 = uStack_8;
            piVar13 = (int *)((int)piVar13 + 2);
          }
          iVar7 = *param_5;
          piStack_28 = piVar3;
        }
      }
      if (piVar3 < piVar11) {
        iVar12 = (int)piVar11 - (int)piVar3;
        iVar7 = (int)((int)piVar3 + uStack_c) * 2;
        do {
          *(undefined2 *)(iVar7 + *param_5) = uStack_8;
          iVar12 = iVar12 + -1;
          iVar7 = iVar7 + 2;
        } while (iVar12 != 0);
        iVar7 = *param_5;
      }
      if ((DAT_01d66378 != '\0') && (cVar10 != '\0')) {
        iStack_10 = 0;
      }
      uVar6 = param_5[1] - iVar7 >> 1;
      iVar7 = iStack_24;
      uStack_c = uStack_1c;
    } while (uStack_1c < uVar6);
  }
  if ((DAT_01d66378 != '\0') && ((char)iStack_10 != '\0')) {
    return uVar6 & 0xffffff00;
  }
  iVar9 = 0;
  iVar4 = 0;
  uStack_1c = 0;
  uStack_c = 0;
  iVar12 = iStack_14;
  if (0 < iVar7) {
    do {
      iStack_10 = 0;
      if (0 < iVar12) {
        do {
          iVar7 = *param_5;
          if (param_4[4] == 0) {
            iVar12 = param_4[1] * param_4[2] * *param_4 * 2;
            uVar5 = FUN_01674e20(iVar12);
            FUN_0170d1f0(uVar5,0,iVar12);
            iStack_2c = 0;
            piStack_28 = (int *)0x0;
            FUN_00a6d6f0(uVar5,&LAB_00a6edc0);
            param_4[4] = iStack_2c;
            piVar11 = (int *)param_4[5];
            param_4[5] = (int)piStack_28;
            if (piVar11 != (int *)0x0) {
              LOCK();
              iVar12 = piVar11[1] + -1;
              piVar11[1] = iVar12;
              UNLOCK();
              if (iVar12 == 0) {
                (**(code **)*piVar11)();
                LOCK();
                iVar12 = piVar11[2] + -1;
                piVar11[2] = iVar12;
                UNLOCK();
                if (iVar12 == 0) {
                  (**(code **)(*piVar11 + 4))();
                }
              }
            }
          }
          FUN_0170c6f0(param_4[4] + (param_4[3] * uStack_c + *param_4 * iStack_10) * 2,
                       iVar7 + iVar9 * 2,iStack_20 * 2);
          iStack_10 = iStack_10 + 1;
          iVar9 = uStack_1c + iStack_20;
          iVar12 = iStack_14;
          iVar7 = iStack_24;
          uStack_1c = iVar9;
        } while (iStack_10 < iStack_14);
      }
      iVar4 = uStack_c + 1;
      uStack_c = iVar4;
    } while (iVar4 < iVar7);
  }
  return CONCAT31((int3)((uint)iVar4 >> 8),1);
}



/* FUNCTION 21259 ; VA 0x00a6f0c0 ; FUN_00a6f0c0 */

int __thiscall FUN_00a6f0c0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  ExceptionList = &pvStack_10;
  do {
    *param_2 = *puVar1;
    uStack_8 = 0;
    FUN_016f32d1(puVar1 + 5,0x10,4,FUN_00a6de20);
    uStack_8 = 0xffffffff;
    FUN_01674ea0(puVar1,0x5c);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 21260 ; VA 0x00a6f140 ; FUN_00a6f140 */

int __thiscall FUN_00a6f140(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e27f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  piVar2 = *(int **)(param_1 + 0x14);
  *(undefined4 *)(param_1 + 0x14) = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = param_3;
  if (param_3 == 0) {
    ExceptionList = pvStack_10;
    return param_3;
  }
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  param_3 = 0;
  if (DAT_01d66378 == '\0') {
    FUN_00a6edd0(param_2,iVar3,&param_3,param_1,&uStack_1c);
  }
  else {
    cVar4 = FUN_00a6edd0(param_2,iVar3,&param_3,param_1,&uStack_1c);
    if (cVar4 == '\0') {
      *(undefined4 *)(param_1 + 0x10) = 0;
      piVar2 = *(int **)(param_1 + 0x14);
      *(undefined4 *)(param_1 + 0x14) = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
  }
  FUN_0072a160();
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 21261 ; VA 0x00a6f260 ; FUN_00a6f260 */

void __thiscall FUN_00a6f260(undefined4 param_1,char *param_2)

{
  int *piVar1;
  byte *pbVar2;
  uint uVar3;
  char *pcVar4;
  int *piVar5;
  void **ppvVar6;
  char cVar7;
  char *pcVar8;
  byte bVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  undefined8 uStack_7c;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_40;
  int iStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar4 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2820;
  pvStack_10 = ExceptionList;
  uVar11 = *(uint *)(param_2 + 0x10);
  if (uVar11 != 0) {
    pcVar8 = param_2;
    if (0xf < *(uint *)(param_2 + 0x14)) {
      pcVar8 = *(char **)param_2;
    }
    uStack_28 = param_1;
    if (uVar11 == 0) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Error while decoding data: unexpected end at offset %u",0);
    }
    if (*pcVar8 != '\x01') {
      ExceptionList = &pvStack_10;
      FUN_016756b0(&iStack_4c,"Error while decoding data: unsupported version");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&iStack_4c,&DAT_01c17198);
    }
    if (0xf < *(uint *)(param_2 + 0x14)) {
      param_2 = *(char **)param_2;
    }
    if (uVar11 < 2) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Error while decoding data: unexpected end at offset %u",1);
    }
    uVar11 = 2;
    uStack_20 = (uint)(byte)param_2[1];
    iStack_64 = 1 << (param_2[1] & 0x1fU);
    iStack_24 = iStack_64;
    if (8 < uStack_20) {
      ExceptionList = &pvStack_10;
      FUN_016756b0(&iStack_4c,"Error while decoding data: malformed chunk size");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&iStack_4c,&DAT_01c17198);
    }
    param_2 = (char *)0x0;
    iStack_14 = 0;
    iStack_18 = 0;
    uStack_34 = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    iStack_58 = iStack_64 * iStack_64;
    uStack_54 = 0;
    piStack_50 = (int *)0x0;
    uVar13 = *(uint *)(pcVar4 + 0x10);
    uStack_8 = 1;
    ExceptionList = &pvStack_10;
    ppvVar6 = &pvStack_10;
    iStack_60 = iStack_64;
    iStack_5c = iStack_64;
    if (2 < uVar13) {
      do {
        ExceptionList = ppvVar6;
        uVar3 = *(uint *)(pcVar4 + 0x14);
        iVar10 = 0x18;
        do {
          pcVar8 = pcVar4;
          if (0xf < uVar3) {
            pcVar8 = *(char **)pcVar4;
          }
          uVar12 = uVar11;
          if (uVar13 <= uVar11) {
LAB_00a6f4ce:
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Error while decoding data: unexpected end at offset %u",uVar12);
          }
          uVar12 = uVar11 + 1;
          bVar9 = (byte)iVar10;
          param_2 = (char *)((int)param_2 + ((uint)(byte)pcVar8[uVar11] << (bVar9 & 0x1f)));
          pcVar8 = pcVar4;
          if (0xf < uVar3) {
            pcVar8 = *(char **)pcVar4;
          }
          if (uVar13 <= uVar12) goto LAB_00a6f4ce;
          pbVar2 = (byte *)(pcVar8 + uVar12);
          uVar12 = uVar11 + 2;
          iStack_14 = iStack_14 + ((uint)*pbVar2 << (bVar9 & 0x1f));
          pcVar8 = pcVar4;
          if (0xf < uVar3) {
            pcVar8 = *(char **)pcVar4;
          }
          if (uVar13 <= uVar12) goto LAB_00a6f4ce;
          uVar11 = uVar11 + 3;
          iStack_18 = iStack_18 + ((uint)(byte)pcVar8[uVar12] << (bVar9 & 0x1f));
          iVar10 = iVar10 + -8;
          uStack_1c = uVar11;
        } while (-1 < iVar10);
        if (DAT_01d66378 == '\0') {
          pcVar8 = pcVar4;
          if (0xf < uVar3) {
            pcVar8 = *(char **)pcVar4;
          }
          FUN_00a6edd0(pcVar8,*(undefined4 *)(pcVar4 + 0x10),&uStack_1c,&iStack_64,&uStack_34);
          bVar9 = (byte)uStack_20;
          iStack_4c = (int)param_2 << (bVar9 & 0x1f);
          iStack_48 = iStack_14 << (bVar9 & 0x1f);
          iStack_74 = iStack_18 << (bVar9 & 0x1f);
          iStack_70 = iStack_4c + iStack_24;
          uStack_7c = CONCAT44(iStack_48,iStack_4c);
          iStack_6c = iStack_48 + iStack_24;
          iStack_68 = iStack_74 + iStack_24;
LAB_00a6f460:
          FUN_00a72960(&uStack_7c,&iStack_64,0);
        }
        else {
          pcVar8 = pcVar4;
          if (0xf < uVar3) {
            pcVar8 = *(char **)pcVar4;
          }
          cVar7 = FUN_00a6edd0(pcVar8,*(undefined4 *)(pcVar4 + 0x10),&uStack_1c,&iStack_64,
                               &uStack_34);
          if (cVar7 != '\0') {
            bVar9 = (byte)uStack_20;
            iStack_40 = (int)param_2 << (bVar9 & 0x1f);
            iStack_3c = iStack_14 << (bVar9 & 0x1f);
            iStack_74 = iStack_18 << (bVar9 & 0x1f);
            iStack_70 = iStack_40 + iStack_24;
            uStack_7c = CONCAT44(iStack_3c,iStack_40);
            iStack_6c = iStack_3c + iStack_24;
            iStack_68 = iStack_74 + iStack_24;
            goto LAB_00a6f460;
          }
        }
        piVar5 = piStack_50;
        uVar13 = *(uint *)(pcVar4 + 0x10);
        uVar11 = uStack_1c;
        ppvVar6 = (void **)ExceptionList;
      } while (uStack_1c < uVar13);
      if (piStack_50 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_50[1] + -1;
        piStack_50[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piStack_50)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar10 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar10 == 1) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    FUN_0072a160();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21262 ; VA 0x00a6f530 ; FUN_00a6f530 */

void __thiscall FUN_00a6f530(int param_1,int param_2)

{
  int *piVar1;
  
  for (piVar1 = *(int **)(param_1 + 0x1c);
      (piVar1 != *(int **)(param_1 + 0x20) && (*piVar1 != param_2)); piVar1 = piVar1 + 1) {
  }
  FUN_0170cc70(piVar1,piVar1 + 1,(int)*(int **)(param_1 + 0x20) - (int)(piVar1 + 1));
  *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + -4;
  return;
}



/* FUNCTION 21263 ; VA 0x00a6f570 ; FUN_00a6f570 */

void __thiscall FUN_00a6f570(uint *param_1,undefined8 *param_2,byte param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  uVar5 = (1 << (param_3 & 0x1f)) - 1;
  uVar1 = param_1[3];
  uVar6 = ~uVar5;
  uVar2 = param_1[4];
  uVar3 = param_1[5];
  uVar4 = param_1[2];
  *param_2 = CONCAT44((int)(param_1[1] & uVar6) >> (param_3 & 0x1f),
                      (int)(uVar6 & *param_1) >> (param_3 & 0x1f));
  *(ulonglong *)((int)param_2 + 0xc) =
       CONCAT44((int)(uVar2 + uVar5 & uVar6) >> (param_3 & 0x1f),
                (int)(uVar1 + uVar5 & uVar6) >> (param_3 & 0x1f));
  *(int *)((int)param_2 + 0x14) = (int)(uVar3 + uVar5 & uVar6) >> (param_3 & 0x1f);
  *(int *)(param_2 + 1) = (int)(uVar4 & uVar6) >> (param_3 & 0x1f);
  return;
}



/* FUNCTION 21264 ; VA 0x00a6f5f0 ; FUN_00a6f5f0 */

byte * FUN_00a6f5f0(byte *param_1,byte *param_2,byte *param_3,byte *param_4,byte *param_5)

{
  byte bVar1;
  byte bVar2;
  uint uVar3;
  uint *puVar4;
  uint uVar5;
  bool bVar6;
  bool bVar7;
  uint uStack_44;
  uint uStack_40;
  byte abStack_3c [4];
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  uint uStack_10;
  byte bStack_a;
  byte bStack_9;
  byte bStack_8;
  byte bStack_7;
  byte bStack_6;
  byte bStack_5;
  
  bStack_a = param_3[2];
  bStack_8 = param_4[2];
  bStack_9 = param_5[2];
  bVar2 = *param_2;
  bStack_7 = param_2[2];
  bVar1 = *param_4;
  bStack_5 = *param_3;
  bStack_6 = *param_5;
  if (bVar2 == bStack_6 &&
      ((bVar2 == bStack_5 &&
       ((bVar2 == bStack_8 && (bVar2 == bStack_a && bVar2 == bStack_7)) && bVar2 == bStack_9)) &&
      bVar2 == bVar1)) {
    bVar1 = param_4[3];
    *param_1 = bVar2;
    param_1[1] = (byte)((uint)param_5[3] + (uint)bVar1 * 2 + (uint)param_5[1] + (uint)param_2[1] +
                        (uint)param_3[1] + (uint)param_2[3] + param_4[1] + 7 >> 3) &
                 (byte)((int)-(uint)bVar2 >> 0x1f);
    return param_1;
  }
  uStack_34 = CONCAT31(uStack_34._1_3_,bVar2);
  uStack_18 = (uint)param_5[3];
  uVar3 = (uint)param_4[3];
  uStack_10 = (uint)param_4[1];
  uStack_20 = (uint)param_5[1];
  uStack_40 = (uint)param_3[3];
  uVar5 = (uint)param_3[1];
  uStack_38 = (uint)param_2[3];
  uStack_30 = (uint)param_2[1];
  param_3._0_1_ =
       (char)((int)((uint)(bVar2 != 0) +
                    (bStack_7 != 0) + uStack_20 +
                    (uint)(bStack_6 != 0) + (bVar1 != 0) + 7 + (uint)(bStack_5 != 0) +
                    (uint)(bStack_9 != 0) + (uint)(bStack_8 != 0) + (uint)(bStack_a != 0) +
                    uStack_18 + uStack_10 + uVar5 + uStack_30 + uStack_38 + uStack_40 + uVar3) >> 3)
       - 1;
  abStack_3c[0] = bStack_7;
  if (bVar2 == bStack_7) {
    uStack_2c = CONCAT31(uStack_2c._1_3_,bVar2);
    uStack_28 = uStack_38 + uStack_30;
  }
  else {
    if (uStack_30 == uStack_38) {
      bVar6 = bVar2 < bStack_7;
      bVar7 = bVar2 == bStack_7;
    }
    else {
      bVar6 = uStack_30 < uStack_38;
      bVar7 = uStack_30 == uStack_38;
    }
    puVar4 = &uStack_34;
    if (bVar6 || bVar7) {
      puVar4 = (uint *)abStack_3c;
    }
    bVar2 = (byte)*puVar4;
    uStack_2c = *puVar4;
    uStack_28 = puVar4[1];
  }
  uStack_44 = CONCAT31(uStack_44._1_3_,bStack_a);
  abStack_3c[0] = bStack_5;
  uStack_38 = uVar5;
  if (bStack_5 == bStack_a) {
    uStack_34 = CONCAT31(uStack_34._1_3_,bStack_5);
    uStack_30 = uStack_40 + uVar5;
  }
  else {
    puVar4 = (uint *)abStack_3c;
    if (uVar5 == uStack_40) {
      if (bStack_5 <= bStack_a) {
        puVar4 = &uStack_44;
      }
    }
    else if (uVar5 <= uStack_40) {
      puVar4 = &uStack_44;
    }
    uStack_30 = puVar4[1];
    uStack_34 = *puVar4;
    bStack_5 = (byte)*puVar4;
  }
  abStack_3c[0] = bStack_8;
  uStack_38 = uVar3;
  uStack_44 = CONCAT31(uStack_44._1_3_,bVar1);
  uStack_40 = uStack_10;
  if (bVar1 == bStack_8) {
    uStack_14 = CONCAT31(uStack_14._1_3_,bVar1);
    uStack_10 = uStack_10 + uVar3;
  }
  else {
    puVar4 = &uStack_44;
    if (uStack_10 == uVar3) {
      if (bVar1 <= bStack_8) {
        puVar4 = (uint *)abStack_3c;
      }
    }
    else if (uStack_10 <= uVar3) {
      puVar4 = (uint *)abStack_3c;
    }
    bVar1 = (byte)*puVar4;
    uStack_10 = puVar4[1];
    uStack_14 = *puVar4;
  }
  abStack_3c[0] = bStack_9;
  uStack_38 = uStack_18;
  uStack_44 = CONCAT31(uStack_44._1_3_,bStack_6);
  uStack_40 = uStack_20;
  if (bStack_6 == bStack_9) {
    uStack_24 = CONCAT31(uStack_24._1_3_,bStack_6);
    uStack_20 = uStack_18 + uStack_20;
  }
  else {
    puVar4 = &uStack_44;
    if (uStack_20 == uStack_18) {
      if (bStack_6 <= bStack_9) {
        puVar4 = (uint *)abStack_3c;
      }
    }
    else if (uStack_20 <= uStack_18) {
      puVar4 = (uint *)abStack_3c;
    }
    uStack_20 = puVar4[1];
    uStack_24 = *puVar4;
    bStack_6 = (byte)*puVar4;
  }
  if (bVar2 == bStack_5) {
    uStack_18 = uStack_30 + uStack_28;
    uStack_1c = CONCAT31(uStack_1c._1_3_,bVar2);
  }
  else {
    bVar6 = uStack_28 < uStack_30;
    if (uStack_28 == uStack_30) {
      bVar6 = bVar2 < bStack_5;
    }
    puVar4 = &uStack_2c;
    if (bVar6 || uStack_28 == uStack_30 && bVar2 == bStack_5) {
      puVar4 = &uStack_34;
    }
    bVar2 = (byte)*puVar4;
    uStack_18 = puVar4[1];
    uStack_1c = *puVar4;
  }
  uVar3 = (uint)CONCAT11(bVar1,bVar2);
  if (bVar1 == bStack_6) {
    uStack_44 = CONCAT31(uStack_44._1_3_,bVar1);
    uStack_20 = uStack_20 + uStack_10;
  }
  else {
    puVar4 = &uStack_14;
    if (uStack_10 == uStack_20) {
      if (bVar1 <= bStack_6) {
        puVar4 = &uStack_24;
      }
    }
    else if (uStack_10 <= uStack_20) {
      puVar4 = &uStack_24;
    }
    uStack_44 = *puVar4;
    uStack_20 = puVar4[1];
  }
  uStack_28 = uStack_20 * 2;
  uStack_2c = uStack_44;
  if (bVar2 != (byte)uStack_44) {
    puVar4 = &uStack_1c;
    if (uStack_18 == uStack_28) {
      if (bVar2 <= (byte)uStack_44) {
        puVar4 = &uStack_2c;
      }
    }
    else if (uStack_18 <= uStack_28) {
      puVar4 = &uStack_2c;
    }
    uVar3 = *puVar4 & 0xff;
  }
  *param_1 = (byte)uVar3;
  param_1[1] = (byte)((int)-(uVar3 & 0xff) >> 0x1f) & (byte)param_3;
  return param_1;
}



/* FUNCTION 21265 ; VA 0x00a6f920 ; FUN_00a6f920 */

void FUN_00a6f920(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  undefined8 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined2 *puVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  int iVar17;
  int iVar18;
  int iVar19;
  int iVar20;
  int iVar21;
  int iVar22;
  int iStack_4c;
  int iStack_48;
  int iStack_30;
  int iStack_14;
  
  iVar3 = *param_2;
  if (iVar3 != param_2[3]) {
    iVar15 = param_2[1];
    if (iVar15 != param_2[4]) {
      iVar4 = param_2[2];
      if ((iVar4 != param_2[5]) && ((param_3[4] != 0 || (param_1[4] != 0)))) {
        iVar12 = param_2[4] - iVar15;
        iVar17 = param_2[3] - iVar3;
        uVar2 = *(undefined8 *)param_2;
        iVar3 = iVar3 * 2;
        iVar1 = param_2[5] - iVar4;
        iVar15 = iVar15 * 2;
        if (0 < iVar12) {
          iStack_48 = (int)((ulonglong)uVar2 >> 0x20);
          do {
            iVar8 = iVar4 * 2;
            iStack_30 = iVar1;
            iStack_14 = iVar4;
            if (0 < iVar1) {
              do {
                iVar16 = param_3[4];
                iStack_4c = (int)uVar2;
                if (iVar16 == 0) {
                  iVar16 = param_1[4];
                  if (iVar16 == 0) {
                    FUN_00a6e270();
                    iVar16 = param_1[4];
                  }
                  FUN_0170d1f0(iVar16 + (param_1[3] * iStack_48 + *param_1 * iStack_14 + iStack_4c)
                                        * 2,0,iVar17 * 2);
                }
                else {
                  iVar13 = param_3[3] * iVar15;
                  iVar18 = iVar8 * *param_3;
                  iVar20 = (iVar8 + 1) * *param_3;
                  iVar9 = param_3[4];
                  iVar11 = (iVar15 + 1) * param_3[3];
                  iVar5 = param_3[4];
                  iVar19 = iVar5 + (iVar3 + iVar18 + iVar11) * 2;
                  iVar21 = param_1[4];
                  if (iVar21 == 0) {
                    FUN_00a6e270();
                    iVar21 = param_1[4];
                  }
                  iVar6 = *param_1;
                  iVar7 = param_1[3];
                  iVar22 = 0;
                  if (0 < iVar17) {
                    iVar14 = (iVar9 + (iVar3 + iVar13 + iVar20) * 2) - iVar19;
                    iVar9 = (iVar5 + (iVar3 + iVar11 + iVar20) * 2) - iVar19;
                    iVar16 = (iVar16 + (iVar3 + iVar18 + iVar13) * 2) - iVar19;
                    do {
                      puVar10 = (undefined2 *)
                                FUN_00a6f5f0((int)&param_2 + 2,iVar16 + iVar19,iVar14 + iVar19,
                                             iVar19,iVar9 + iVar19);
                      iVar19 = iVar19 + 4;
                      *(undefined2 *)
                       (iVar21 + (iVar7 * iStack_48 + iVar6 * iStack_14 + iStack_4c) * 2 +
                       iVar22 * 2) = *puVar10;
                      iVar22 = iVar22 + 1;
                    } while (iVar22 < iVar17);
                  }
                }
                iStack_30 = iStack_30 + -1;
                iVar8 = iVar8 + 2;
                iStack_14 = iStack_14 + 1;
              } while (iStack_30 != 0);
            }
            iStack_48 = iStack_48 + 1;
            iVar15 = iVar15 + 2;
            iVar12 = iVar12 + -1;
          } while (iVar12 != 0);
        }
      }
    }
  }
  return;
}



/* FUNCTION 21266 ; VA 0x00a6fb30 ; FUN_00a6fb30 */

void FUN_00a6fb30(int *param_1,int *param_2,int *param_3)

{
  ushort *puVar1;
  undefined8 uVar2;
  ushort uVar3;
  undefined2 uVar4;
  uint *puVar5;
  undefined1 *puVar6;
  undefined1 *puVar7;
  undefined2 *puVar8;
  byte bVar9;
  uint uVar10;
  ushort uVar11;
  int iVar12;
  uint uVar13;
  undefined1 *puVar14;
  int iVar15;
  undefined1 *puVar16;
  bool bVar17;
  int iStack_88;
  int iStack_84;
  uint uStack_7c;
  byte abStack_74 [4];
  uint uStack_70;
  byte abStack_6c [4];
  uint uStack_68;
  byte abStack_64 [4];
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  byte abStack_54 [4];
  uint uStack_50;
  uint uStack_4c;
  int iStack_44;
  int iStack_40;
  uint uStack_3c;
  int iStack_38;
  int iStack_34;
  uint uStack_30;
  uint uStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  uint uStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_28 = *param_2;
  if (iStack_28 != param_2[3]) {
    iStack_14 = param_2[1];
    if (iStack_14 != param_2[4]) {
      iStack_1c = param_2[2];
      if (iStack_1c != param_2[5]) {
        uVar2 = *(undefined8 *)param_2;
        iStack_18 = param_2[4] - iStack_14;
        iStack_44 = param_2[3] - iStack_28;
        iVar15 = param_2[5] - iStack_1c;
        iStack_14 = iStack_14 * 2;
        iStack_20 = iStack_1c * 2;
        iStack_28 = iStack_28 * 2;
        iStack_34 = iVar15;
        bVar9 = 0;
        param_2 = (int *)((uint)param_2 & 0xffffff);
        iStack_84 = (int)((ulonglong)uVar2 >> 0x20);
        iStack_24 = iStack_14;
        if (0 < iStack_18) {
          iStack_40 = iStack_18;
          iStack_c = iStack_84;
          do {
            iStack_8 = 0;
            if (0 < iVar15) {
              iStack_38 = iStack_14 + 1;
              do {
                iVar15 = *param_3;
                iVar12 = iStack_14 * param_3[2] + iStack_20 + iStack_8 * 2;
                uVar11 = *(ushort *)(iVar15 + iVar12 * 2);
                uVar13 = uVar11 & 0xfff;
                if ((short)uVar11 < 0) {
                  uVar13 = 0xffffffff;
                }
                uVar11 = *(ushort *)(iVar15 + iVar12 * 2 + 2);
                uStack_10 = uVar11 & 0xfff;
                if ((short)uVar11 < 0) {
                  uStack_10 = 0xffffffff;
                }
                puVar1 = (ushort *)
                         (iVar15 + (iStack_38 * param_3[2] + iStack_20 + iStack_8 * 2) * 2);
                uVar11 = *puVar1;
                uVar10 = uVar11 & 0xfff;
                uVar3 = puVar1[1];
                if ((short)uVar11 < 0) {
                  uVar10 = 0xffffffff;
                }
                uStack_3c = uVar3 & 0xfff;
                if ((short)uVar3 < 0) {
                  uStack_3c = 0xffffffff;
                }
                if (uVar13 == 0) {
                  if (((uStack_10 == 0) && (uVar10 == 0)) && (uStack_3c == 0)) {
                    FUN_00a700c0();
                    iVar15 = param_1[2] * iStack_c + iStack_1c + iStack_8;
                    uVar4 = *(undefined2 *)(*param_1 + iVar15 * 2);
                    *(undefined2 *)(*param_1 + iVar15 * 2) = 0;
                    bVar17 = SUB21((ushort)uVar4 >> 0xf,0);
                  }
                  else {
LAB_00a6fdb9:
                    FUN_00a700c0();
                    puVar1 = (ushort *)
                             (*param_1 + (param_1[2] * iStack_c + iStack_1c + iStack_8) * 2);
                    uVar11 = *puVar1;
                    bVar17 = -1 < (short)uVar11;
                    if (bVar17) {
                      *puVar1 = uVar11 | 0x4000;
                    }
                  }
                }
                else {
                  if (((((int)uVar13 < 1) || ((int)uStack_10 < 1)) || ((int)uVar10 < 1)) ||
                     ((int)uStack_3c < 1)) goto LAB_00a6fdb9;
                  abStack_6c[0] = (byte)uStack_10;
                  uStack_68 = (int)-(uStack_10 & 0xff) >> 0x1f & 0xff;
                  uStack_60 = (int)-(uVar13 & 0xff) >> 0x1f & 0xff;
                  abStack_64[0] = (byte)uVar13;
                  if (abStack_64[0] == abStack_6c[0]) {
                    uStack_30 = CONCAT31(uStack_30._1_3_,abStack_64[0]);
                    uStack_2c = uStack_68 + uStack_60;
                  }
                  else {
                    puVar5 = (uint *)abStack_64;
                    if (uStack_60 == uStack_68) {
                      if (abStack_64[0] <= abStack_6c[0]) {
                        puVar5 = (uint *)abStack_6c;
                      }
                    }
                    else if (uStack_60 <= uStack_68) {
                      puVar5 = (uint *)abStack_6c;
                    }
                    uVar13 = *puVar5 & 0xff;
                    uStack_2c = puVar5[1];
                    uStack_30 = *puVar5;
                  }
                  uVar11 = (ushort)uVar13;
                  uStack_70 = (int)-(uStack_3c & 0xff) >> 0x1f & 0xff;
                  abStack_74[0] = (byte)uStack_3c;
                  uStack_50 = (int)-(uVar10 & 0xff) >> 0x1f & 0xff;
                  abStack_54[0] = (byte)uVar10;
                  if (abStack_54[0] == abStack_74[0]) {
                    uStack_7c = CONCAT31(uStack_7c._1_3_,abStack_54[0]);
                    uStack_58 = uStack_50 + uStack_70;
                  }
                  else {
                    puVar5 = (uint *)abStack_54;
                    if (uStack_50 == uStack_70) {
                      if (abStack_54[0] <= abStack_74[0]) {
                        puVar5 = (uint *)abStack_74;
                      }
                    }
                    else if (uStack_50 <= uStack_70) {
                      puVar5 = (uint *)abStack_74;
                    }
                    uStack_7c = *puVar5;
                    uStack_58 = puVar5[1];
                  }
                  uStack_58 = uStack_58 * 2;
                  uStack_5c = uStack_7c;
                  if ((byte)uVar13 != (byte)uStack_7c) {
                    puVar5 = &uStack_30;
                    if (uStack_2c == uStack_58) {
                      if ((byte)uVar13 <= (byte)uStack_7c) {
                        puVar5 = &uStack_5c;
                      }
                    }
                    else if (uStack_2c <= uStack_58) {
                      puVar5 = &uStack_5c;
                    }
                    uStack_4c = *puVar5;
                    uVar11 = (ushort)uStack_4c & 0xff;
                  }
                  FUN_00a700c0();
                  iVar15 = param_1[2] * iStack_c + iStack_1c + iStack_8;
                  uVar4 = *(undefined2 *)(*param_1 + iVar15 * 2);
                  *(ushort *)(*param_1 + iVar15 * 2) = uVar11 & 0xff;
                  bVar17 = SUB21((ushort)uVar4 >> 0xf,0);
                }
                bVar9 = bVar17 | param_2._3_1_;
                iStack_8 = iStack_8 + 1;
                param_2 = (int *)CONCAT13(bVar9,param_2._0_3_);
              } while (iStack_8 < iStack_34);
              param_2 = (int *)CONCAT13(bVar9,param_2._0_3_);
              iVar15 = iStack_34;
            }
            iStack_14 = iStack_14 + 2;
            iStack_c = iStack_c + 1;
            iStack_40 = iStack_40 + -1;
          } while (iStack_40 != 0);
          if (bVar9 != 0) {
            FUN_00a71e60();
          }
        }
        uStack_10 = 0;
        iVar15 = iStack_34;
        if (0 < iStack_18) {
          do {
            iStack_14 = 0;
            uVar13 = uStack_10;
            if (0 < iVar15) {
              do {
                uVar11 = *(ushort *)
                          (*param_1 +
                          ((iStack_84 + uVar13) * param_1[2] + iStack_14 + iStack_1c) * 2);
                if ((short)uVar11 < 0) {
                  iStack_88 = (int)uVar2;
                  iStack_38 = param_1[1] + ((uVar11 & 0xfff) * param_1[2] + iStack_88) * 2;
                  if (iStack_38 != 0) {
                    iVar15 = param_3[2];
                    puVar1 = (ushort *)
                             (*param_3 + (iStack_24 * iVar15 + iStack_20 + iStack_14 * 2) * 2);
                    uVar11 = *puVar1;
                    uVar13 = uVar11 & 0xfff;
                    if ((short)uVar11 < 0) {
                      puVar6 = (undefined1 *)(param_3[1] + (uVar13 * iVar15 + iStack_28) * 2);
                    }
                    else {
                      puVar6 = &DAT_01ee9940 + (uVar13 * 0x20 + iStack_28) * 2;
                    }
                    uVar11 = puVar1[1];
                    uVar13 = uVar11 & 0xfff;
                    if ((short)uVar11 < 0) {
                      puVar7 = (undefined1 *)(param_3[1] + (iVar15 * uVar13 + iStack_28) * 2);
                    }
                    else {
                      puVar7 = &DAT_01ee9940 + (uVar13 * 0x20 + iStack_28) * 2;
                    }
                    puVar1 = (ushort *)
                             (*param_3 + ((iStack_24 + 1) * iVar15 + iStack_20 + iStack_14 * 2) * 2)
                    ;
                    uVar11 = *puVar1;
                    uVar13 = uVar11 & 0xfff;
                    if ((short)uVar11 < 0) {
                      puVar16 = (undefined1 *)(param_3[1] + (iVar15 * uVar13 + iStack_28) * 2);
                    }
                    else {
                      puVar16 = &DAT_01ee9940 + (uVar13 * 0x20 + iStack_28) * 2;
                    }
                    uVar11 = puVar1[1];
                    uVar13 = uVar11 & 0xfff;
                    if ((short)uVar11 < 0) {
                      puVar14 = (undefined1 *)(param_3[1] + (iVar15 * uVar13 + iStack_28) * 2);
                    }
                    else {
                      puVar14 = &DAT_01ee9940 + (uVar13 * 0x20 + iStack_28) * 2;
                    }
                    iVar15 = 0;
                    uVar13 = uStack_10;
                    if (0 < iStack_44) {
                      iVar12 = (int)puVar14 - (int)puVar16;
                      iStack_c = (int)puVar7 - (int)puVar16;
                      iStack_8 = (int)puVar6 - (int)puVar16;
                      do {
                        puVar8 = (undefined2 *)
                                 FUN_00a6f5f0((int)&param_2 + 2,puVar16 + iStack_8,
                                              puVar16 + iStack_c,puVar16,puVar16 + iVar12);
                        puVar16 = puVar16 + 4;
                        *(undefined2 *)(iStack_38 + iVar15 * 2) = *puVar8;
                        iVar15 = iVar15 + 1;
                        uVar13 = uStack_10;
                      } while (iVar15 < iStack_44);
                    }
                  }
                }
                iStack_14 = iStack_14 + 1;
                iVar15 = iStack_34;
              } while (iStack_14 < iStack_34);
            }
            iStack_24 = iStack_24 + 2;
            uStack_10 = uVar13 + 1;
          } while ((int)uStack_10 < iStack_18);
        }
      }
    }
  }
  return;
}



/* FUNCTION 21267 ; VA 0x00a70020 ; FUN_00a70020 */

byte * FUN_00a70020(byte *param_1,byte *param_2,uint param_3)

{
  byte *pbVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  
  bVar2 = *param_2;
  if ((bVar2 == 0) || (param_2[1] == 0xff)) {
    bVar3 = 0;
  }
  else {
    bVar3 = 1;
  }
  if (0x100 < param_3) {
    iVar4 = (param_3 - 0x101 >> 8) + 1;
    do {
      *param_1 = *param_2 | (bVar3 | 0xfe) << 6;
      pbVar1 = param_1 + 1;
      if (bVar3 != 0) {
        *pbVar1 = param_2[1];
        pbVar1 = param_1 + 2;
      }
      *pbVar1 = 0xff;
      param_3 = param_3 - 0x100;
      param_1 = pbVar1 + 1;
      iVar4 = iVar4 + -1;
    } while (iVar4 != 0);
    bVar2 = *param_2;
  }
  *param_1 = (-(1 < param_3) & 2U | bVar3) << 6 | bVar2;
  pbVar1 = param_1 + 1;
  if (bVar3 != 0) {
    *pbVar1 = param_2[1];
    pbVar1 = param_1 + 2;
  }
  if (1 < param_3) {
    *pbVar1 = (char)param_3 - 1;
    pbVar1 = pbVar1 + 1;
  }
  return pbVar1;
}



/* FUNCTION 21268 ; VA 0x00a700c0 ; FUN_00a700c0 */

void __fastcall FUN_00a700c0(int *param_1)

{
  int iVar1;
  
  if ((undefined4 *)*param_1 == &DAT_01ee9130) {
    iVar1 = FUN_01674e20(param_1[2] * param_1[2] * 2);
    *param_1 = iVar1;
    iVar1 = 0;
    if (0 < param_1[2] * param_1[2]) {
      do {
        *(undefined2 *)(*param_1 + iVar1 * 2) = 0;
        iVar1 = iVar1 + 1;
      } while (iVar1 < param_1[2] * param_1[2]);
    }
  }
  return;
}



/* FUNCTION 21269 ; VA 0x00a70110 ; FUN_00a70110 */

void FUN_00a70110(ulonglong *param_1,uint param_2)

{
  byte *pbVar1;
  ulonglong *puVar2;
  char cVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uVar6;
  int iVar7;
  byte bVar8;
  uint uVar9;
  byte *pbVar10;
  char *pcVar11;
  char *pcVar12;
  undefined4 *puVar13;
  undefined8 uVar14;
  undefined auStack_a4 [24];
  undefined auStack_8c [24];
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  uint uStack_30;
  char *pcStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  char *pcStack_1c;
  byte *pbStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2854;
  pvStack_10 = ExceptionList;
  if (param_2 == 0) {
    return;
  }
  if (((*(uint *)(param_1 + 2) | *(uint *)param_1 | *(uint *)((int)param_1 + 0x14) |
        *(uint *)((int)param_1 + 4) | *(uint *)(param_1 + 1) | *(uint *)((int)param_1 + 0xc)) & 0xf)
      != 0) {
    return;
  }
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eea980) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eea980), DAT_01eea980 == -1)) {
    uStack_8 = 0;
    uVar14 = FUN_0152dab0("Voxel","erase",0xffffffff);
    DAT_01eea97c = (undefined4)((ulonglong)uVar14 >> 0x20);
    DAT_01eea978 = (undefined4)uVar14;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eea980);
  }
  uStack_40 = DAT_01eea978;
  uStack_5c = DAT_01eea978;
  uStack_3c = DAT_01eea97c;
  uStack_58 = DAT_01eea97c;
  uStack_54 = FUN_0152d930(DAT_01eea978,DAT_01eea97c);
  uStack_8 = 1;
  uVar4 = FUN_01675290(DAT_01ee9930);
  uVar9 = *(uint *)(param_1 + 1);
  iStack_48 = (int)*(uint *)((int)param_1 + 4) >> 5;
  pcStack_1c = (char *)(*(uint *)param_1 & 0xffffffe0);
  iStack_4c = (int)*(uint *)param_1 >> 5;
  uStack_30 = uVar9 & 0xffffffe0;
  pcStack_14 = (char *)(uVar9 - uStack_30);
  uVar5 = *(uint *)((int)param_1 + 4) & 0xffffffe0;
  iStack_44 = (int)uVar9 >> 5;
  iStack_24 = uStack_30 + 0x20;
  pcStack_2c = pcStack_1c + 0x20;
  uStack_38 = *param_1 & 0xffffffe0ffffffe0;
  iStack_28 = uVar5 + 0x20;
  uStack_8._0_1_ = 2;
  uStack_20 = uVar4;
  if (-1 < (int)((int)pcStack_2c - *(uint *)((int)param_1 + 0xc) |
                 *(uint *)param_1 - (int)pcStack_1c | iStack_28 - *(uint *)(param_1 + 2) |
                 iStack_24 - *(uint *)((int)param_1 + 0x14) | *(uint *)((int)param_1 + 4) - uVar5 |
                (uint)pcStack_14)) {
    pbVar10 = pbStack_18 + *pbStack_18 + 1;
    uVar6 = FUN_00a6ce70(&iStack_4c);
    FUN_006e16e0(&pcStack_1c,uVar6,&iStack_4c,-(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1))
    ;
    pcVar11 = pcStack_1c;
    if (pcStack_1c != (char *)0x0) {
      pcStack_14 = pcStack_1c + 0x14;
      pcStack_1c = pcStack_1c + 0x58;
      if (*pcStack_1c != '\0') {
        FUN_00a71630(0,pcStack_1c,&uStack_38,param_1);
        pcVar12 = pcStack_14;
        if (*pcStack_1c == '\0') {
          param_1 = (ulonglong *)0x0;
          if (param_2 != 0) {
            pcVar11 = pcVar11 + 0x18;
            do {
              if (*(undefined4 **)(pcVar11 + -4) != &DAT_01ee9130) {
                FUN_01674ea0(*(undefined4 **)(pcVar11 + -4));
              }
              FUN_01674ea0(*(undefined4 *)pcVar11);
              bVar8 = (byte)param_1;
              param_1 = (ulonglong *)((int)param_1 + 1);
              *(uint *)(pcVar11 + 4) = 0x20 >> (bVar8 & 0x1f);
              *(undefined4 **)(pcVar11 + -4) = &DAT_01ee9130;
              pcVar11[0] = '\0';
              pcVar11[1] = '\0';
              pcVar11[2] = '\0';
              pcVar11[3] = '\0';
              pcVar11[8] = '\0';
              pcVar11[9] = '\0';
              pcVar11[10] = '\0';
              pcVar11[0xb] = '\0';
              pcVar11 = pcVar11 + 0x10;
            } while (param_1 < param_2);
          }
          *(int *)(pbStack_18 + 0x18) = *(int *)(pbStack_18 + 0x18) - *(int *)(pcStack_14 + 0x40);
          pcStack_14[0x40] = '\0';
          pcStack_14[0x41] = '\0';
          pcStack_14[0x42] = '\0';
          pcStack_14[0x43] = '\0';
          pbVar10 = pbStack_18;
        }
        else {
          iStack_74 = *(uint *)((int)param_1 + 0xc) - *(uint *)param_1;
          iStack_6c = *(uint *)((int)param_1 + 0x14) - *(uint *)(param_1 + 1);
          iStack_70 = *(uint *)(param_1 + 2) - *(uint *)((int)param_1 + 4);
          iStack_68 = iStack_74 * iStack_6c;
          uStack_64 = 0;
          uStack_60 = 0;
          uStack_8 = CONCAT31(uStack_8._1_3_,9);
          cVar3 = FUN_00a6e7c0(pcStack_14,&uStack_38,&iStack_74,param_1);
          pbVar10 = pbStack_18;
          if (cVar3 != '\0') {
            FUN_00a71450(auStack_8c,&uStack_38);
            pcStack_2c = (char *)-(int)uStack_38;
            iStack_28 = -uStack_38._4_4_;
            iStack_24 = -uStack_30;
            FUN_00a716f0(auStack_a4,&pcStack_2c);
            if (1 < param_2) {
              uVar9 = 1;
              pcVar11 = pcVar12;
              do {
                FUN_00a6f570(auStack_8c,uVar9);
                FUN_00a6fb30(pcVar11 + 0x10,auStack_8c,pcVar11);
                uVar9 = uVar9 + 1;
                pcVar12 = pcStack_14;
                uVar4 = uStack_20;
                pcVar11 = pcVar11 + 0x10;
              } while (uVar9 < param_2);
            }
            pbVar10 = pbStack_18;
            iVar7 = FUN_00a6eb50(pcVar12,(int)&param_2 + 3);
            pbVar1 = pbVar10 + 0x18;
            *(int *)pbVar1 = *(int *)pbVar1 + (iVar7 - *(int *)(pcStack_14 + 0x40));
            *(int *)(pcStack_14 + 0x40) = iVar7;
          }
          uStack_8._0_1_ = 2;
          FUN_00612e90();
          if (cVar3 == '\0') goto LAB_00a70468;
        }
        puVar13 = *(undefined4 **)(pbVar10 + 0x1c);
        uVar9 = (uint)((int)*(undefined4 **)(pbStack_18 + 0x20) + (3 - (int)puVar13)) >> 2;
        if (*(undefined4 **)(pbStack_18 + 0x20) < puVar13) {
          uVar9 = 0;
        }
        if (uVar9 != 0) {
          uVar5 = 0;
          do {
            (**(code **)(*(int *)*puVar13 + 4))(puVar2,0,1);
            uVar5 = uVar5 + 1;
            puVar13 = puVar13 + 1;
            uVar4 = uStack_20;
          } while (uVar5 != uVar9);
        }
      }
    }
  }
LAB_00a70468:
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_01675290(uVar4);
  uStack_8 = 0xb;
  FUN_0152dda0(uStack_40,uStack_3c,uStack_54);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21270 ; VA 0x00a70500 ; FUN_00a70500 */

void __thiscall FUN_00a70500(int *param_1,undefined8 *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  
  iVar1 = param_1[3];
  iVar2 = param_1[5];
  iVar3 = param_3[1];
  iVar4 = *param_3;
  iVar5 = param_3[2];
  iVar6 = param_1[4];
  iVar7 = param_1[2];
  *param_2 = CONCAT44(param_1[1] - iVar3,*param_1 - iVar4);
  *(ulonglong *)((int)param_2 + 0xc) = CONCAT44(iVar6 + iVar3,iVar1 + iVar4);
  *(int *)((int)param_2 + 0x14) = iVar2 + iVar5;
  *(int *)(param_2 + 1) = iVar7 - iVar5;
  return;
}



/* FUNCTION 21271 ; VA 0x00a70570 ; FUN_00a70570 */

void __thiscall FUN_00a70570(int *param_1,undefined8 *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = param_1[3];
  iVar2 = param_1[4];
  iVar3 = param_1[5];
  iVar4 = param_1[2];
  *param_2 = CONCAT44(param_1[1] - param_3,*param_1 - param_3);
  *(ulonglong *)((int)param_2 + 0xc) = CONCAT44(iVar2 + param_3,iVar1 + param_3);
  *(int *)((int)param_2 + 0x14) = iVar3 + param_3;
  *(int *)(param_2 + 1) = iVar4 - param_3;
  return;
}



/* FUNCTION 21272 ; VA 0x00a705d0 ; FUN_00a705d0 */

void FUN_00a705d0(undefined8 *param_1,float *param_2,float *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  float10 fVar7;
  float10 fVar8;
  float10 fVar9;
  
  fVar7 = (float10)FUN_01725280((double)(*param_2 * DAT_018e1340));
  iVar1 = (int)fVar7;
  fVar7 = (float10)FUN_01725280((double)(param_2[1] * DAT_018e1340));
  iVar2 = (int)fVar7;
  fVar7 = (float10)FUN_01725280((double)(param_2[2] * DAT_018e1340));
  iVar3 = (int)fVar7;
  fVar7 = (float10)FUN_01725160((double)(*param_3 * DAT_018e1340));
  fVar8 = (float10)FUN_01725160((double)(param_3[1] * DAT_018e1340));
  fVar9 = (float10)FUN_01725160((double)(param_3[2] * DAT_018e1340));
  iVar4 = iVar1;
  if (iVar1 <= (int)fVar7) {
    iVar4 = (int)fVar7;
  }
  iVar5 = iVar2;
  if (iVar2 <= (int)fVar8) {
    iVar5 = (int)fVar8;
  }
  iVar6 = iVar3;
  if (iVar3 <= (int)fVar9) {
    iVar6 = (int)fVar9;
  }
  *param_1 = CONCAT44(iVar2,iVar1);
  *(ulonglong *)((int)param_1 + 0xc) = CONCAT44(iVar5,iVar4);
  *(int *)(param_1 + 1) = iVar3;
  *(int *)((int)param_1 + 0x14) = iVar6;
  return;
}



/* FUNCTION 21273 ; VA 0x00a70760 ; FUN_00a70760 */

void FUN_00a70760(undefined8 *param_1,undefined4 param_2,float param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float *pfVar5;
  undefined auStack_34 [12];
  undefined auStack_28 [24];
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  pfVar5 = (float *)FUN_00a735f0(auStack_28);
  fStack_8 = DAT_018ce2f8 / param_3;
  fVar1 = *pfVar5;
  fStack_c = pfVar5[1];
  fStack_10 = pfVar5[2];
  pfVar5 = (float *)FUN_00a735a0(auStack_34);
  fVar2 = *pfVar5;
  fVar3 = pfVar5[1];
  fVar4 = pfVar5[2];
  *param_1 = CONCAT44((int)(fStack_c * fStack_8),(int)(fVar1 * fStack_8));
  *(ulonglong *)((int)param_1 + 0xc) = CONCAT44((int)(fVar3 * fStack_8),(int)(fStack_8 * fVar2));
  *(int *)(param_1 + 1) = (int)(fStack_10 * fStack_8);
  *(int *)((int)param_1 + 0x14) = (int)(fVar4 * fStack_8);
  return;
}



/* FUNCTION 21274 ; VA 0x00a70830 ; FUN_00a70830 */

undefined1 * __thiscall FUN_00a70830(int *param_1,int param_2,int param_3,int param_4)

{
  ushort uVar1;
  uint uVar2;
  
  uVar1 = *(ushort *)(*param_1 + (param_1[2] * param_3 + param_4) * 2);
  uVar2 = uVar1 & 0xfff;
  if ((short)uVar1 < 0) {
    return (undefined1 *)(param_1[1] + (uVar2 * param_1[2] + param_2) * 2);
  }
  return &DAT_01ee9940 + (uVar2 * 0x20 + param_2) * 2;
}



/* FUNCTION 21275 ; VA 0x00a70880 ; FUN_00a70880 */

undefined4 __thiscall FUN_00a70880(byte *param_1,undefined4 *param_2)

{
  bool bVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  uint uVar4;
  ushort *puVar5;
  char *pcVar6;
  int iVar7;
  byte bVar8;
  int iVar9;
  int iStack_c4;
  int iStack_c0;
  undefined8 uStack_a0;
  int iStack_98;
  undefined8 uStack_94;
  int iStack_8c;
  ushort *puStack_88;
  int iStack_84;
  ushort *puStack_7c;
  int iStack_78;
  uint uStack_6c;
  uint uStack_68;
  byte *pbStack_60;
  uint uStack_5c;
  int iStack_58;
  int iStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  int iStack_38;
  uint uStack_34;
  ushort *puStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined8 uStack_20;
  int iStack_18;
  byte bStack_11;
  uint uStack_10;
  uint uStack_c;
  ushort *puStack_8;
  
  pbStack_60 = param_1;
  FUN_00a70da0(&uStack_a0,5);
  piStack_24 = (int *)&uStack_a0;
  uStack_20 = uStack_a0;
  uVar2 = uStack_20;
  uStack_20._0_4_ = (int)uStack_a0;
  iStack_18 = iStack_98;
  iStack_28 = iStack_8c;
  iVar7 = (int)uStack_20;
  uStack_20 = uVar2;
  while( true ) {
    iStack_c4 = (int)uStack_94;
    if (iVar7 == iStack_c4) {
      iStack_c0 = (int)((ulonglong)uStack_94 >> 0x20);
      if ((uStack_20._4_4_ == iStack_c0) && (iStack_18 == iStack_28)) {
        return 0;
      }
    }
    bVar8 = *param_1;
    uVar3 = FUN_00a6ce70(&uStack_20);
    FUN_006e16e0(&iStack_38,uVar3,&uStack_20,
                 -(uint)(param_1 + bVar8 + 1 != (byte *)0x0) & (uint)(param_1 + bVar8 + 1 + 1));
    if (iStack_38 != 0) break;
LAB_00a70b6a:
    iVar7 = (int)uStack_20 + 1;
    uStack_20 = CONCAT44(uStack_20._4_4_,iVar7);
    if (iVar7 == piStack_24[3]) {
      iVar7 = *piStack_24;
      uStack_20._4_4_ = uStack_20._4_4_ + 1;
      uStack_20 = CONCAT44(uStack_20._4_4_,iVar7);
      if (uStack_20._4_4_ == piStack_24[4]) {
        uStack_20 = CONCAT44(piStack_24[1],iVar7);
        iStack_18 = iStack_18 + 1;
        if (iStack_18 == piStack_24[5]) {
          uStack_20 = *(undefined8 *)(piStack_24 + 3);
          iStack_18 = piStack_24[5];
          iVar7 = (int)uStack_20;
        }
      }
    }
  }
  puVar5 = (ushort *)((int)uStack_20 * 0x20);
  iVar7 = uStack_20._4_4_ * 0x20;
  iVar9 = iStack_18 * 0x20;
  puStack_30 = puVar5 + 0x10;
  uStack_c = param_2[2];
  iStack_2c = uStack_c;
  if ((int)uStack_c <= iVar9) {
    iStack_2c = iVar9;
  }
  puStack_7c = (ushort *)*param_2;
  if ((int)*param_2 <= (int)puVar5) {
    puStack_7c = puVar5;
  }
  iStack_78 = param_2[1];
  if ((int)param_2[1] <= iVar7) {
    iStack_78 = iVar7;
  }
  if ((int)uStack_c <= iVar9) {
    uStack_c = iVar9;
  }
  iVar9 = param_2[4];
  if (iVar7 + 0x20 <= (int)param_2[4]) {
    iVar9 = iVar7 + 0x20;
  }
  puVar5 = (ushort *)param_2[3];
  if ((int)puStack_30 <= (int)param_2[3]) {
    puVar5 = puStack_30;
  }
  puStack_88 = puStack_7c;
  if ((int)puStack_7c <= (int)puVar5) {
    puStack_88 = puVar5;
  }
  iStack_84 = iStack_78;
  if (iStack_78 <= iVar9) {
    iStack_84 = iVar9;
  }
  uStack_10 = iStack_78;
  puStack_8 = puStack_7c;
  FUN_00a70da0(&uStack_50,4);
  uVar4 = uStack_48;
  uStack_6c = uStack_50;
  uStack_68 = uStack_4c;
  do {
    uStack_10 = uStack_6c;
    puStack_8 = (ushort *)uStack_68;
    uStack_c = uVar4;
    do {
      do {
        if (((uStack_10 == uStack_44) && (puStack_8 == (ushort *)uStack_40)) &&
           (param_1 = pbStack_60, uStack_c == uStack_3c)) goto LAB_00a70b6a;
        do {
          iStack_2c = 0;
          uStack_34 = uStack_10 & 1;
          uStack_5c = (uint)puStack_8 & 1;
          bVar8 = 1;
          iStack_58 = (uStack_c & 1) * 2;
          iVar7 = *(int *)(iStack_38 + 0x4c);
          iStack_54 = iVar7 * 2;
          puStack_30 = (ushort *)
                       (*(int *)(iStack_38 + 0x44) + (iVar7 * uStack_5c * 2 + iStack_58) * 2);
          do {
            iVar9 = 0;
            puVar5 = puStack_30;
            do {
              bStack_11 = bVar8;
              uVar4 = *puVar5 & 0xfff;
              if ((short)*puVar5 < 0) {
                pcVar6 = (char *)(*(int *)(iStack_38 + 0x48) +
                                 (uVar4 * *(int *)(iStack_38 + 0x4c) + uStack_34 * 2) * 2);
              }
              else {
                pcVar6 = &DAT_01ee9940 + (uVar4 * 0x20 + uStack_34 * 2) * 2;
              }
              bVar8 = 0;
              if (*pcVar6 == '\0') {
                bVar8 = bStack_11;
              }
              bVar8 = bVar8 & pcVar6[2] == '\0';
              if (bVar8 == 0) {
                bVar1 = false;
                goto LAB_00a70aff;
              }
              iVar9 = iVar9 + 1;
              puVar5 = puVar5 + 1;
            } while (iVar9 < 2);
            iStack_2c = iStack_2c + 1;
            puStack_30 = puStack_30 + iVar7;
          } while (iStack_2c < 2);
          bVar1 = true;
LAB_00a70aff:
          if (((*(byte *)(iStack_38 + 0x58) &
               '\x01' << (((byte)iStack_58 | (byte)uStack_5c) * '\x02' | (byte)uStack_34)) == 0) &&
             (!bVar1)) {
            return 3;
          }
          uStack_10 = uStack_10 + 1;
        } while (uStack_10 != uStack_44);
        uStack_10 = uStack_50;
        puStack_8 = (ushort *)((int)puStack_8 + 1);
      } while (puStack_8 != (ushort *)uStack_40);
      uStack_c = uStack_c + 1;
      puStack_8 = (ushort *)uStack_4c;
      uVar4 = uStack_3c;
      uStack_6c = uStack_44;
      uStack_68 = uStack_40;
    } while (uStack_c != uStack_3c);
  } while( true );
}



/* FUNCTION 21276 ; VA 0x00a70be0 ; FUN_00a70be0 */

void __thiscall
FUN_00a70be0(byte *param_1,undefined2 *param_2,int param_3,uint param_4,uint param_5,int param_6)

{
  byte bVar1;
  ushort uVar2;
  undefined4 uVar3;
  undefined2 *puVar4;
  int iVar5;
  uint uVar6;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  uint uStack_8;
  
  iStack_14 = (int)param_4 >> 5;
  iVar5 = param_3 >> 5;
  iStack_10 = (int)param_5 >> 5;
  uStack_8 = param_5 & 0xffffffe0;
  bVar1 = *param_1;
  iStack_18 = iVar5;
  uVar3 = FUN_00a6ce70(&iStack_18);
  FUN_006e16e0(&iStack_c,uVar3,&iStack_18,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  if (iStack_c == 0) {
    *param_2 = 0;
    return;
  }
  if ((param_6 != 1) &&
     ((*(byte *)(iStack_c + 0x58) &
      '\x01' << ((((byte)((int)param_5 >> 4) & 1) * '\x02' | (byte)((int)param_4 >> 4) & 1) * '\x02'
                | (byte)(param_3 >> 4) & 1)) == 0)) {
    puVar4 = (undefined2 *)
             FUN_00a70830(param_3 + iVar5 * -0x20 >> 3,param_4 >> 3 & 3,
                          (int)(param_5 - uStack_8) >> 3);
    *param_2 = *puVar4;
    return;
  }
  param_3 = param_3 + iVar5 * -0x20;
  uVar2 = *(ushort *)
           (*(int *)(iStack_c + 0x14) +
           (((param_4 & 0x1f) * *(int *)(iStack_c + 0x1c) - uStack_8) + param_5) * 2);
  uVar6 = uVar2 & 0xfff;
  if ((short)uVar2 < 0) {
    *param_2 = *(undefined2 *)
                (*(int *)(iStack_c + 0x18) + (uVar6 * *(int *)(iStack_c + 0x1c) + param_3) * 2);
    return;
  }
  *param_2 = *(undefined2 *)(&DAT_01ee9940 + (uVar6 * 0x20 + param_3) * 2);
  return;
}



/* FUNCTION 21277 ; VA 0x00a70d30 ; FUN_00a70d30 */

undefined4 __fastcall FUN_00a70d30(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined8 uVar6;
  
  iVar1 = *param_1;
  iVar5 = param_1[3];
  if (iVar1 != iVar5) {
    if (param_1[1] != param_1[4]) {
      if (param_1[2] != param_1[5]) {
        iVar4 = param_1[4] - param_1[1];
        iVar2 = param_1[5] - param_1[2];
        uVar6 = FUN_016f39b0(iVar2,iVar2 >> 0x1f,iVar4,iVar4 >> 0x1f);
        iVar5 = iVar5 - iVar1;
        uVar3 = FUN_016f39b0(uVar6,iVar5,iVar5 >> 0x1f);
        return uVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 21278 ; VA 0x00a70da0 ; FUN_00a70da0 */

undefined8 * __thiscall FUN_00a70da0(int *param_1,undefined8 *param_2,byte param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = param_1[3];
  if (*param_1 != iVar1) {
    iVar2 = param_1[4];
    if (param_1[1] != iVar2) {
      iVar3 = param_1[2];
      iVar4 = param_1[5];
      if (iVar3 != iVar4) {
        *param_2 = CONCAT44(param_1[1] >> (param_3 & 0x1f),*param_1 >> (param_3 & 0x1f));
        *(int *)(param_2 + 1) = iVar3 >> (param_3 & 0x1f);
        *(ulonglong *)((int)param_2 + 0xc) =
             CONCAT44((iVar2 + -1 >> (param_3 & 0x1f)) + 1,(iVar1 + -1 >> (param_3 & 0x1f)) + 1);
        *(int *)((int)param_2 + 0x14) = (iVar4 + -1 >> (param_3 & 0x1f)) + 1;
        return param_2;
      }
    }
  }
  *(undefined4 *)param_2 = 0;
  *(undefined4 *)((int)param_2 + 4) = 0;
  *(undefined4 *)(param_2 + 1) = 0;
  *(undefined4 *)((int)param_2 + 0xc) = 0;
  *(undefined4 *)(param_2 + 2) = 0;
  *(undefined4 *)((int)param_2 + 0x14) = 0;
  return param_2;
}



/* FUNCTION 21279 ; VA 0x00a70e60 ; FUN_00a70e60 */

undefined4 * __thiscall FUN_00a70e60(int param_1,undefined4 *param_2)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined8 uStack_38;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2879;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  uVar1 = *(uint *)(param_1 + 8);
  uStack_8 = 0;
  uStack_14 = 1;
  if (uVar1 != 0) {
    if (0xaaaaaaa < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00a6e210(uVar1);
    if (*(int *)(param_1 + 8) != 0) {
      puVar3 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      goto joined_r0x00a70edb;
    }
  }
  puVar3 = (undefined4 *)0x0;
joined_r0x00a70edb:
  for (; puVar3 != (undefined4 *)0x0; puVar3 = (undefined4 *)*puVar3) {
    iStack_20 = puVar3[2] * 0x20;
    iStack_2c = iStack_20 + 0x20;
    iStack_1c = puVar3[3] * 0x20;
    iStack_30 = puVar3[4] * 0x20;
    uStack_38 = CONCAT44(iStack_1c,iStack_20);
    iStack_28 = iStack_1c + 0x20;
    iStack_24 = iStack_30 + 0x20;
    piVar2 = (int *)param_2[1];
    if ((int *)param_2[2] == piVar2) {
      FUN_00603350(piVar2,&uStack_38);
    }
    else {
      *piVar2 = iStack_20;
      piVar2[1] = iStack_1c;
      piVar2[2] = iStack_30;
      piVar2[3] = iStack_2c;
      *(ulonglong *)(piVar2 + 4) = CONCAT44(iStack_24,iStack_28);
      param_2[1] = param_2[1] + 0x18;
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21280 ; VA 0x00a70f70 ; FUN_00a70f70 */

undefined4 * __thiscall FUN_00a70f70(byte *param_1,undefined4 *param_2,uint *param_3)

{
  undefined4 *puVar1;
  uint *puVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  byte *pbVar9;
  int *piVar10;
  uint uVar11;
  undefined8 uVar12;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined8 uStack_88;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  undefined8 uStack_6c;
  uint uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  int iStack_40;
  int iStack_3c;
  uint uStack_38;
  uint uStack_34;
  int *piStack_30;
  undefined8 uStack_2c;
  int iStack_24;
  byte *pbStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e28a9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  uStack_8 = 0;
  uStack_5c = 1;
  uStack_1c = *param_3;
  uStack_34 = param_3[3];
  pbStack_20 = param_1;
  if (uStack_1c != uStack_34) {
    uStack_14 = param_3[1];
    uStack_18 = param_3[4];
    if (uStack_14 != uStack_18) {
      if (param_3[2] != param_3[5]) {
        iVar3 = (((int)(param_3[5] - 1) >> 5) - ((int)param_3[2] >> 5)) + 1;
        iVar4 = (((int)(uStack_18 - 1) >> 5) - ((int)uStack_14 >> 5)) + 1;
        uVar12 = FUN_016f39b0(iVar3,iVar3 >> 0x1f,iVar4,iVar4 >> 0x1f);
        iVar3 = (((int)(uStack_34 - 1) >> 5) - ((int)uStack_1c >> 5)) + 1;
        uVar12 = FUN_016f39b0(uVar12,iVar3,iVar3 >> 0x1f);
        goto LAB_00a71058;
      }
    }
  }
  iStack_3c = 0;
  uStack_38 = 0;
  uVar12 = 0;
LAB_00a71058:
  pbVar8 = pbStack_20;
  uStack_18 = (uint)((ulonglong)uVar12 >> 0x20);
  uStack_1c = *(int *)(pbStack_20 + 8) * 2;
  if ((uStack_18 == 0) && ((uint)uVar12 < uStack_1c)) {
    FUN_00a70da0(&uStack_58,5);
    piStack_30 = (int *)&uStack_58;
    uStack_2c = uStack_58;
    uVar12 = uStack_2c;
    uStack_6c._0_4_ = uStack_4c;
    uStack_6c._4_4_ = uStack_48;
    uStack_2c._0_4_ = (int)uStack_58;
    iStack_24 = uStack_50;
    uStack_14 = uStack_44;
    iVar3 = (int)uStack_2c;
    uStack_2c = uVar12;
    while (((iVar3 != (int)uStack_6c || (uStack_2c._4_4_ != uStack_6c._4_4_)) ||
           (iStack_24 != uStack_14))) {
      pbVar9 = pbVar8 + *pbVar8 + 1;
      uVar5 = FUN_00a6ce70(&uStack_2c);
      pbVar8 = pbStack_20;
      FUN_006e16e0(&uStack_1c,uVar5,&uStack_2c,-(uint)(pbVar9 != (byte *)0x0) & (uint)(pbVar9 + 1));
      if (uStack_1c != 0) {
        iStack_40 = (int)uStack_2c * 0x20;
        iStack_7c = iStack_40 + 0x20;
        iStack_3c = uStack_2c._4_4_ * 0x20;
        iStack_80 = iStack_24 * 0x20;
        uStack_88 = CONCAT44(iStack_3c,iStack_40);
        iStack_78 = iStack_3c + 0x20;
        iStack_74 = iStack_80 + 0x20;
        FUN_00a71450(&uStack_a0,&uStack_88);
        puVar1 = (undefined4 *)param_2[1];
        if ((undefined4 *)param_2[2] == puVar1) {
          FUN_00603350(puVar1,&uStack_a0);
        }
        else {
          *puVar1 = uStack_a0;
          puVar1[1] = uStack_9c;
          puVar1[2] = uStack_98;
          puVar1[3] = uStack_94;
          *(undefined8 *)(puVar1 + 4) = uStack_90;
          param_2[1] = param_2[1] + 0x18;
        }
      }
      iVar3 = (int)uStack_2c + 1;
      uStack_2c = CONCAT44(uStack_2c._4_4_,iVar3);
      if (iVar3 == piStack_30[3]) {
        iVar3 = *piStack_30;
        uStack_2c._4_4_ = uStack_2c._4_4_ + 1;
        uStack_2c = CONCAT44(uStack_2c._4_4_,iVar3);
        if (uStack_2c._4_4_ == piStack_30[4]) {
          uStack_2c = CONCAT44(piStack_30[1],iVar3);
          iStack_24 = iStack_24 + 1;
          if (iStack_24 == piStack_30[5]) {
            uStack_2c = *(undefined8 *)(piStack_30 + 3);
            iStack_24 = piStack_30[5];
            iVar3 = (int)uStack_2c;
          }
        }
      }
    }
  }
  else {
    if (*(int *)(pbStack_20 + 8) == 0) {
      piVar10 = (int *)0x0;
    }
    else {
      piVar10 = *(int **)(*(int *)(pbStack_20 + 0x14) + *(int *)(pbStack_20 + 4) * 4);
    }
    if (piVar10 != (int *)0x0) {
      do {
        uStack_1c = piVar10[2] * 0x20;
        uVar6 = piVar10[4] * 0x20;
        uStack_34 = piVar10[3] * 0x20;
        uStack_60 = param_3[2];
        if ((int)param_3[2] <= (int)uVar6) {
          uStack_60 = uVar6;
        }
        pbStack_20 = (byte *)*param_3;
        if ((int)*param_3 <= (int)uStack_1c) {
          pbStack_20 = (byte *)uStack_1c;
        }
        uStack_14 = param_3[1];
        if ((int)param_3[1] <= (int)uStack_34) {
          uStack_14 = uStack_34;
        }
        uStack_6c = CONCAT44(uStack_14,pbStack_20);
        uStack_58 = uStack_6c;
        uVar11 = param_3[5];
        if ((int)(uVar6 + 0x20) <= (int)param_3[5]) {
          uVar11 = uVar6 + 0x20;
        }
        uVar6 = param_3[4];
        if ((int)(uStack_34 + 0x20) <= (int)param_3[4]) {
          uVar6 = uStack_34 + 0x20;
        }
        uVar7 = param_3[3];
        if ((int)(uStack_1c + 0x20) <= (int)param_3[3]) {
          uVar7 = uStack_1c + 0x20;
        }
        uStack_4c = (uint)pbStack_20;
        if ((int)pbStack_20 <= (int)uVar7) {
          uStack_4c = uVar7;
        }
        uStack_48 = uStack_14;
        if ((int)uStack_14 <= (int)uVar6) {
          uStack_48 = uVar6;
        }
        uStack_2c = CONCAT44(uStack_48,uStack_4c);
        uStack_44 = uStack_60;
        if ((int)uStack_60 <= (int)uVar11) {
          uStack_44 = uVar11;
        }
        if (((pbStack_20 != (byte *)uStack_4c) && (uStack_14 != uStack_48)) &&
           (uStack_60 != uStack_44)) {
          puVar2 = (uint *)param_2[1];
          if ((uint *)param_2[2] == puVar2) {
            uStack_50 = uStack_60;
            uStack_38 = uStack_60;
            uStack_18 = uStack_48;
            FUN_00603350(puVar2,&uStack_58);
          }
          else {
            *puVar2 = (uint)pbStack_20;
            puVar2[1] = uStack_14;
            puVar2[2] = uStack_60;
            puVar2[3] = uStack_4c;
            *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_44,uStack_48);
            param_2[1] = param_2[1] + 0x18;
          }
        }
        piVar10 = (int *)*piVar10;
      } while (piVar10 != (int *)0x0);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21281 ; VA 0x00a71340 ; FUN_00a71340 */

int * __thiscall FUN_00a71340(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e28d9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar4 = param_3[3];
  iVar2 = *param_3;
  iVar1 = param_3[5] - param_3[2];
  iVar3 = param_3[4] - param_3[1];
  ExceptionList = &pvStack_10;
  *param_2 = iVar4 - iVar2;
  param_2[1] = iVar3;
  param_2[2] = iVar1;
  param_2[3] = (iVar4 - iVar2) * iVar1;
  param_2[4] = 0;
  param_2[5] = 0;
  if (param_1[4] != 0) {
    FUN_00a6e270();
    iVar4 = 0;
    if (0 < iVar3) {
      do {
        iVar2 = 0;
        if (0 < iVar1) {
          do {
            FUN_0170c6f0(param_2[4] + (param_2[3] * iVar4 + *param_2 * iVar2) * 2,
                         param_1[4] +
                         ((param_3[1] + iVar4) * param_1[3] + (param_3[2] + iVar2) * *param_1 +
                         *param_3) * 2,*param_2 * 2);
            iVar2 = iVar2 + 1;
          } while (iVar2 < iVar1);
        }
        iVar4 = iVar4 + 1;
      } while (iVar4 < iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21282 ; VA 0x00a71450 ; FUN_00a71450 */

void __thiscall FUN_00a71450(int *param_1,undefined8 *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  
  iVar2 = param_1[2];
  if (param_1[2] <= param_3[2]) {
    iVar2 = param_3[2];
  }
  iVar4 = *param_1;
  if (*param_1 <= *param_3) {
    iVar4 = *param_3;
  }
  iVar6 = param_1[1];
  if (param_1[1] <= param_3[1]) {
    iVar6 = param_3[1];
  }
  iVar7 = param_1[5];
  if (param_3[5] <= param_1[5]) {
    iVar7 = param_3[5];
  }
  iVar3 = param_1[4];
  if (param_3[4] <= param_1[4]) {
    iVar3 = param_3[4];
  }
  iVar1 = param_1[3];
  if (param_3[3] <= param_1[3]) {
    iVar1 = param_3[3];
  }
  iVar5 = iVar4;
  if (iVar4 <= iVar1) {
    iVar5 = iVar1;
  }
  iVar1 = iVar6;
  if (iVar6 <= iVar3) {
    iVar1 = iVar3;
  }
  iVar3 = iVar2;
  if (iVar2 <= iVar7) {
    iVar3 = iVar7;
  }
  *param_2 = CONCAT44(iVar6,iVar4);
  *(ulonglong *)((int)param_2 + 0xc) = CONCAT44(iVar1,iVar5);
  *(int *)(param_2 + 1) = iVar2;
  *(int *)((int)param_2 + 0x14) = iVar3;
  return;
}



/* FUNCTION 21283 ; VA 0x00a714f0 ; FUN_00a714f0 */

uint __thiscall FUN_00a714f0(uint *param_1,int *param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if (((((int)uVar1 <= param_2[3]) && (uVar1 = param_1[3], *param_2 <= (int)uVar1)) &&
      (uVar1 = param_1[1], (int)uVar1 <= param_2[4])) &&
     (((uVar1 = param_1[4], param_2[1] <= (int)uVar1 &&
       (uVar1 = param_1[2], (int)uVar1 <= param_2[5])) &&
      (uVar1 = param_1[5], param_2[2] <= (int)uVar1)))) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 21284 ; VA 0x00a71530 ; FUN_00a71530 */

uint __thiscall FUN_00a71530(byte *param_1,uint *param_2)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  uint *puVar6;
  undefined4 uVar7;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  byte *pbStack_8;
  
  puVar5 = param_2;
  uVar2 = *param_2;
  uVar3 = param_2[1];
  uVar4 = param_2[2];
  puVar6 = (uint *)(param_2[3] | param_2[4] | param_2[5] | uVar2 | uVar3 | uVar4);
  if (((uint)puVar6 & 0xf) == 0) {
    iStack_14 = (int)uVar2 >> 5;
    iStack_10 = (int)uVar3 >> 5;
    iStack_c = (int)uVar4 >> 5;
    puVar6 = (uint *)(param_2[1] - (uVar3 & 0xffffffe0));
    if (-1 < (int)(((uVar2 & 0xffffffe0) - param_2[3]) + 0x20 |
                   ((uVar3 & 0xffffffe0) - param_2[4]) + 0x20 |
                   ((uVar4 & 0xffffffe0) - param_2[5]) + 0x20 | param_2[2] - (uVar4 & 0xffffffe0) |
                   *param_2 - (uVar2 & 0xffffffe0) | (uint)puVar6)) {
      bVar1 = *param_1;
      pbStack_8 = param_1;
      uVar7 = FUN_00a6ce70(&iStack_14);
      FUN_006e16e0(&param_2,uVar7,&iStack_14,
                   -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
      puVar6 = param_2;
      if ((param_2 != (uint *)0x0) && (*(byte *)(param_2 + 0x16) != 0)) {
        return (uint)((*(byte *)(param_2 + 0x16) &
                      '\x01' << (sbyte)((int)((int)((int)*puVar5 >> 1 & 8U | puVar5[1] & 0x10) >> 1
                                             | puVar5[2] & 0x10) >> 2)) != 0);
      }
    }
  }
  return (uint)puVar6 & 0xffffff00;
}



/* FUNCTION 21285 ; VA 0x00a71630 ; FUN_00a71630 */

void FUN_00a71630(char param_1,byte *param_2,undefined4 param_3,undefined4 param_4)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined auStack_1c [24];
  
  uVar3 = 0;
  FUN_00a71450(auStack_1c,param_4);
  FUN_00a70da0(&uStack_34,4);
  uVar2 = uStack_30;
  uVar4 = uStack_34;
  while (((uVar4 != uStack_28 || (uVar2 != uStack_24)) || (uStack_2c != uStack_20))) {
    do {
      uVar1 = uVar4 & 1;
      uVar4 = uVar4 + 1;
      uVar3 = uVar3 & 0xff | 1 << (((uStack_2c & 1) * 2 | uVar2 & 1) * 2 | uVar1);
    } while (uVar4 != uStack_28);
    uVar2 = uVar2 + 1;
    uVar4 = uStack_34;
    if ((uVar2 == uStack_24) &&
       (uStack_2c = uStack_2c + 1, uVar2 = uStack_30, uStack_2c == uStack_20)) {
      uVar2 = uStack_24;
      uStack_2c = uStack_20;
      uVar4 = uStack_28;
    }
  }
  if (param_1 == '\0') {
    *param_2 = ~(byte)uVar3 & *param_2;
    return;
  }
  *param_2 = *param_2 | (byte)uVar3;
  return;
}



/* FUNCTION 21286 ; VA 0x00a716f0 ; FUN_00a716f0 */

void __thiscall FUN_00a716f0(int *param_1,undefined8 *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  
  iVar1 = param_1[3];
  iVar2 = param_1[5];
  iVar3 = param_3[1];
  iVar4 = *param_3;
  iVar5 = param_3[2];
  iVar6 = param_1[4];
  iVar7 = param_1[2];
  *param_2 = CONCAT44(param_1[1] + iVar3,*param_1 + iVar4);
  *(ulonglong *)((int)param_2 + 0xc) = CONCAT44(iVar6 + iVar3,iVar1 + iVar4);
  *(int *)((int)param_2 + 0x14) = iVar2 + iVar5;
  *(int *)(param_2 + 1) = iVar7 + iVar5;
  return;
}



/* FUNCTION 21287 ; VA 0x00a71760 ; FUN_00a71760 */

int * __thiscall
FUN_00a71760(byte *param_1,int *param_2,undefined4 param_3,uint param_4,undefined4 param_5)

{
  int iVar1;
  byte *pbVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uVar5;
  byte bVar6;
  int iVar7;
  undefined8 uVar8;
  undefined8 uStack_c4;
  int iStack_bc;
  ulonglong uStack_b8;
  int iStack_b0;
  int iStack_ac;
  int iStack_a8;
  int iStack_a4;
  int iStack_a0;
  int iStack_9c;
  int iStack_98;
  undefined8 uStack_94;
  int iStack_8c;
  undefined8 uStack_88;
  int iStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined8 uStack_74;
  int iStack_6c;
  int iStack_68;
  byte *pbStack_60;
  int iStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  undefined8 uStack_44;
  int *piStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e291c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_60 = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eea960) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eea960), DAT_01eea960 == -1)) {
    uStack_8 = 0;
    uVar8 = FUN_0152dab0("Voxel",&DAT_019450a4,0xffffffff);
    DAT_01eea95c = (undefined4)((ulonglong)uVar8 >> 0x20);
    DAT_01eea958 = (undefined4)uVar8;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eea960);
  }
  uStack_58 = DAT_01eea958;
  uStack_7c = DAT_01eea958;
  uStack_54 = DAT_01eea95c;
  uStack_78 = DAT_01eea95c;
  uStack_74 = FUN_0152d930(DAT_01eea958,DAT_01eea95c);
  uStack_8 = 1;
  if (param_4 < 4) {
    FUN_00a6f570(&iStack_ac,param_4);
    iStack_38 = iStack_a0 - iStack_ac;
    iStack_30 = iStack_98 - iStack_a4;
    iStack_34 = iStack_9c - iStack_a8;
    iStack_2c = iStack_38 * iStack_30;
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00a70da0(&uStack_c4,5);
    piStack_20 = (int *)&uStack_c4;
    uStack_1c = uStack_c4;
    uVar8 = uStack_1c;
    uStack_1c._0_4_ = (int)uStack_c4;
    iStack_14 = iStack_bc;
    uStack_44 = uStack_b8;
    iVar7 = (int)uStack_1c;
    uStack_1c = uVar8;
LAB_00a71886:
    if (iVar7 == (int)uStack_44) {
      if ((uStack_1c._4_4_ == uStack_44._4_4_) && (iStack_14 == iStack_b0)) goto LAB_00a71996;
    }
    bVar6 = *param_1;
    uVar5 = FUN_00a6ce70(&uStack_1c);
    FUN_006e16e0(&iStack_5c,uVar5,&uStack_1c,
                 -(uint)(param_1 + bVar6 + 1 != (byte *)0x0) & (uint)(param_1 + bVar6 + 1 + 1));
    pbVar2 = pbStack_60;
    if (iStack_5c != 0) {
      bVar6 = 5 - (char)param_4;
      iStack_6c = (int)uStack_1c << (bVar6 & 0x1f);
      iStack_80 = 1 << (bVar6 & 0x1f);
      iStack_68 = uStack_1c._4_4_ << (bVar6 & 0x1f);
      iStack_8c = iStack_14 << (bVar6 & 0x1f);
      uStack_94 = CONCAT44(iStack_68,iStack_6c);
      uStack_88 = CONCAT44(iStack_68 + iStack_80,iStack_6c + iStack_80);
      iStack_80 = iStack_8c + iStack_80;
      FUN_00a6e3d0(&iStack_38,&iStack_ac,iStack_5c + 0x14,param_4,&uStack_94,param_5);
      param_1 = pbVar2;
    }
    iVar7 = (int)uStack_1c + 1;
    uStack_1c = CONCAT44(uStack_1c._4_4_,iVar7);
    if (iVar7 == piStack_20[3]) {
      iVar7 = *piStack_20;
      uStack_1c._4_4_ = uStack_1c._4_4_ + 1;
      uStack_1c = CONCAT44(uStack_1c._4_4_,iVar7);
      if (uStack_1c._4_4_ == piStack_20[4]) {
        uStack_1c = CONCAT44(piStack_20[1],iVar7);
        iStack_14 = iStack_14 + 1;
        if (iStack_14 == piStack_20[5]) {
          uStack_1c = *(undefined8 *)(piStack_20 + 3);
          iStack_14 = piStack_20[5];
          iVar7 = (int)uStack_1c;
        }
      }
    }
    goto LAB_00a71886;
  }
  FUN_00a71760(&iStack_50,param_3,3,param_5);
  if (3 < (int)param_4) {
    iStack_6c = 0;
    iVar7 = param_4 - 3;
    iStack_68 = 0;
    do {
      iStack_28 = 0;
      piStack_24 = (int *)0x0;
      iStack_80 = iStack_48 / 2;
      iStack_34 = iStack_4c / 2;
      iStack_38 = iStack_50 / 2;
      iStack_2c = iStack_80 * iStack_38;
      uStack_94 = CONCAT44(iStack_68,iStack_6c);
      uStack_1c = CONCAT44(iStack_34,iStack_38);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      iStack_8c = 0;
      uStack_88 = uStack_1c;
      iStack_30 = iStack_80;
      FUN_00a6f920(&iStack_38,&uStack_94,&iStack_50);
      piVar4 = piStack_24;
      piVar3 = piStack_3c;
      iStack_50 = iStack_38;
      iStack_4c = iStack_34;
      iStack_48 = iStack_30;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
      }
      uStack_44 = CONCAT44(iStack_28,iStack_2c);
      piStack_3c = piStack_24;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar1 = piVar3[1] + -1;
        piVar3[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar1 = piVar3[2] + -1;
          piVar3[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[1] + -1;
        piVar4[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar1 = piVar4[2] + -1;
          piVar4[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar7 = iVar7 + -1;
    } while (iVar7 != 0);
  }
  *param_2 = iStack_50;
  param_2[1] = iStack_4c;
  param_2[2] = iStack_48;
  param_2[3] = (int)uStack_44;
  param_2[4] = uStack_44._4_4_;
  param_2[5] = (int)piStack_3c;
  uStack_44 = uStack_44 & 0xffffffff;
  piStack_3c = (int *)0x0;
  uStack_8 = 6;
LAB_00a71b35:
  FUN_0152dda0(uStack_58,uStack_54,uStack_74);
  ExceptionList = pvStack_10;
  return param_2;
LAB_00a71996:
  *param_2 = iStack_38;
  param_2[1] = iStack_34;
  param_2[2] = iStack_30;
  param_2[3] = iStack_2c;
  param_2[4] = iStack_28;
  param_2[5] = (int)piStack_24;
  uStack_8 = 3;
  goto LAB_00a71b35;
}



/* FUNCTION 21288 ; VA 0x00a71bc0 ; FUN_00a71bc0 */

bool __thiscall FUN_00a71bc0(byte *param_1,int *param_2)

{
  int *piVar1;
  byte bVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  bool bVar6;
  undefined8 uVar7;
  int iStack_9c;
  int iStack_98;
  undefined8 uStack_90;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  undefined8 uStack_78;
  int iStack_70;
  undefined8 uStack_6c;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e294c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eea950) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eea950), DAT_01eea950 == -1)) {
    uStack_8 = 0;
    uVar7 = FUN_0152dab0("Voxel","readRegionEmptyLod0",0xffffffff);
    DAT_01eea94c = (undefined4)((ulonglong)uVar7 >> 0x20);
    DAT_01eea948 = (undefined4)uVar7;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eea950);
  }
  uStack_2c = DAT_01eea948;
  uStack_3c = DAT_01eea948;
  uStack_28 = DAT_01eea94c;
  uStack_38 = DAT_01eea94c;
  uStack_34 = FUN_0152d930(DAT_01eea948,DAT_01eea94c);
  iStack_44 = 0;
  piStack_40 = (int *)0x0;
  iStack_54 = param_2[3] - *param_2;
  iStack_4c = param_2[5] - param_2[2];
  iStack_50 = param_2[4] - param_2[1];
  iStack_48 = iStack_54 * iStack_4c;
  uStack_8 = 2;
  FUN_00a70da0(&uStack_78,5);
  piStack_20 = (int *)&uStack_78;
  uStack_1c = uStack_78;
  do {
    iVar5 = (int)uStack_1c;
    iStack_14 = iStack_70;
    do {
      do {
        do {
          piVar3 = piStack_40;
          iStack_9c = (int)uStack_6c;
          if (iVar5 == iStack_9c) {
            iStack_98 = (int)((ulonglong)uStack_6c >> 0x20);
            if ((uStack_1c._4_4_ == iStack_98) && (iStack_14 == iStack_64)) {
              bVar6 = iStack_44 == 0;
              if (piStack_40 != (int *)0x0) {
                LOCK();
                iVar5 = piStack_40[1] + -1;
                piStack_40[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piStack_40)();
                  LOCK();
                  piVar1 = piVar3 + 2;
                  iVar5 = *piVar1;
                  *piVar1 = *piVar1 + -1;
                  UNLOCK();
                  if (iVar5 == 1) {
                    (**(code **)(*piVar3 + 4))();
                  }
                }
              }
              uStack_8 = 3;
              FUN_0152dda0(uStack_2c,uStack_28,uStack_34);
              ExceptionList = pvStack_10;
              return bVar6;
            }
          }
          bVar2 = *param_1;
          uVar4 = FUN_00a6ce70(&uStack_1c);
          FUN_006e16e0(&iStack_24,uVar4,&uStack_1c,
                       -(uint)(param_1 + bVar2 + 1 != (byte *)0x0) & (uint)(param_1 + bVar2 + 1 + 1)
                      );
          if ((iStack_24 != 0) && (*(int *)(iStack_24 + 0x54) != 0)) {
            iStack_60 = (int)uStack_1c * 0x20;
            iStack_84 = iStack_60 + 0x20;
            iStack_5c = uStack_1c._4_4_ * 0x20;
            iStack_88 = iStack_14 * 0x20;
            iStack_80 = iStack_5c + 0x20;
            uStack_90 = CONCAT44(iStack_5c,iStack_60);
            iStack_7c = iStack_88 + 0x20;
            FUN_00a6e3d0(&iStack_54,param_2,iStack_24 + 0x14,0,&uStack_90,1);
          }
          iVar5 = (int)uStack_1c + 1;
          uStack_1c = CONCAT44(uStack_1c._4_4_,iVar5);
        } while (iVar5 != piStack_20[3]);
        iVar5 = *piStack_20;
        uStack_1c._4_4_ = uStack_1c._4_4_ + 1;
        uStack_1c = CONCAT44(uStack_1c._4_4_,iVar5);
      } while (uStack_1c._4_4_ != piStack_20[4]);
      uStack_1c = CONCAT44(piStack_20[1],iVar5);
      iStack_14 = iStack_14 + 1;
    } while (iStack_14 != piStack_20[5]);
    uStack_1c = *(undefined8 *)(piStack_20 + 3);
    iStack_70 = piStack_20[5];
  } while( true );
}



/* FUNCTION 21289 ; VA 0x00a71e60 ; FUN_00a71e60 */

void __fastcall FUN_00a71e60(int *param_1)

{
  ushort uVar1;
  undefined1 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  ushort *puVar6;
  int iStack_c;
  int iStack_8;
  
  iStack_c = 0;
  iVar4 = param_1[2];
  iVar3 = iVar4 * iVar4;
  if (0 < iVar3) {
    puVar6 = (ushort *)*param_1;
    iVar5 = 0;
    do {
      uVar1 = *puVar6;
      puVar6 = puVar6 + 1;
      iStack_c = iVar5 + 1;
      if ((uVar1 & 0xc000) == 0) {
        iStack_c = iVar5;
      }
      iVar3 = iVar3 + -1;
      iVar5 = iStack_c;
    } while (iVar3 != 0);
    if (iStack_c != 0) {
      iStack_8 = FUN_01674e20(iVar4 * iStack_c * 2);
      iVar4 = param_1[2];
      goto LAB_00a71ec0;
    }
  }
  iStack_8 = 0;
LAB_00a71ec0:
  iVar3 = 0;
  if (0 < iVar4 * iVar4) {
    iVar5 = 0;
    do {
      puVar6 = (ushort *)(*param_1 + iVar3 * 2);
      uVar1 = *puVar6;
      if ((uVar1 & 0xc000) != 0) {
        if ((short)uVar1 < 0) {
          puVar2 = (undefined1 *)(param_1[1] + (uVar1 & 0xfff) * iVar4 * 2);
        }
        else {
          puVar2 = &DAT_01ee9940 + (uVar1 & 0xfff) * 0x40;
        }
        FUN_0170c6f0(iStack_8 + iVar4 * iVar5 * 2,puVar2,iVar4 * 2);
        uVar1 = (ushort)iVar5;
        iVar5 = iVar5 + 1;
        *puVar6 = uVar1 | 0x8000;
      }
      iVar4 = param_1[2];
      iVar3 = iVar3 + 1;
    } while (iVar3 < iVar4 * iVar4);
  }
  FUN_01674ea0(param_1[1]);
  param_1[3] = iStack_c;
  param_1[1] = iStack_8;
  return;
}



/* FUNCTION 21290 ; VA 0x00a71f60 ; FUN_00a71f60 */

void __thiscall FUN_00a71f60(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar9;
  int iVar10;
  int iVar11;
  int aiStack_40 [4];
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  undefined4 *puVar8;
  
  puStack_c = &LAB_017e2968;
  pvStack_10 = ExceptionList;
  puVar6 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar6 = (undefined4 *)*param_2;
  }
  ExceptionList = &pvStack_10;
  param_2[4] = 0;
  *(undefined *)puVar6 = 0;
  if (param_1[4] != 0) {
    aiStack_40[0] = 0;
    aiStack_40[1] = 0;
    aiStack_40[2] = 0;
    iStack_18 = param_1[2];
    iStack_30 = param_1[1];
    uVar9 = 0;
    iStack_28 = *param_1;
    iVar10 = 0;
    uStack_8 = 0;
    uStack_14 = 0;
    piStack_24 = param_1;
    FUN_00715060(iStack_18 * iStack_30 * iStack_28 * 2,aiStack_40);
    iStack_1c = 0;
    iStack_20 = aiStack_40[0];
    iVar7 = iStack_18;
    iVar4 = aiStack_40[0];
    iVar5 = aiStack_40[0];
    if (0 < iStack_30) {
      do {
        iStack_2c = 0;
        if (0 < iVar7) {
          do {
            iVar11 = 0;
            iVar7 = piStack_24[4] + (piStack_24[3] * iStack_1c + *piStack_24 * iStack_2c) * 2;
            iVar5 = iStack_28;
            aiStack_40[3] = iVar7;
            iVar3 = iStack_20;
            if (0 < iStack_28) {
              do {
                if ((*(char *)(iVar7 + iVar11 * 2) == (char)(uVar9 >> 8)) &&
                   (*(char *)(iVar7 + 1 + iVar11 * 2) == (char)uVar9)) {
                  iVar10 = iVar10 + 1;
                }
                else {
                  if (iVar10 != 0) {
                    iVar4 = FUN_00a70020(iVar4,&uStack_14,iVar10);
                    iVar7 = aiStack_40[3];
                  }
                  uVar2 = *(undefined2 *)(iVar7 + iVar11 * 2);
                  iVar10 = 1;
                  uStack_14._1_1_ = (undefined)((ushort)uVar2 >> 8);
                  uVar9 = (uint)CONCAT11((char)uVar2,uStack_14._1_1_);
                  iVar5 = iStack_28;
                  uStack_14 = uVar2;
                }
                iVar11 = iVar11 + 1;
                iVar3 = iVar4;
              } while (iVar11 < iVar5);
            }
            iStack_20 = iVar3;
            iStack_2c = iStack_2c + 1;
            iVar7 = iStack_18;
          } while (iStack_2c < iStack_18);
        }
        iStack_1c = iStack_1c + 1;
      } while (iStack_1c < iStack_30);
      iVar5 = iStack_20;
      if (iVar10 != 0) {
        iVar5 = FUN_00a70020(iVar4,&uStack_14,iVar10);
      }
    }
    uVar9 = param_2[5];
    puVar6 = param_2;
    if (0xf < uVar9) {
      puVar6 = (undefined4 *)*param_2;
    }
    piVar1 = param_2 + 4;
    puVar8 = param_2;
    if (0xf < uVar9) {
      puVar8 = (undefined4 *)*param_2;
    }
    iVar7 = (int)puVar8 + *piVar1;
    if (0xf < uVar9) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_00591430(iVar7 - (int)param_2,(undefined *)((int)puVar6 + (*piVar1 - iVar7)),aiStack_40[0],
                 iVar5 - aiStack_40[0]);
    FUN_0056d2d0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21291 ; VA 0x00a72130 ; FUN_00a72130 */

void __thiscall FUN_00a72130(byte *param_1,uint *param_2)

{
  undefined8 uVar1;
  undefined2 uVar2;
  ushort uVar3;
  code *pcVar4;
  uint *puVar5;
  undefined4 uVar6;
  int iVar7;
  undefined8 *puVar8;
  uint uVar9;
  uint *puVar10;
  uint *puVar11;
  uint uVar12;
  int iVar13;
  int *piVar14;
  uint uVar15;
  byte *pbVar16;
  int iVar17;
  uint uVar18;
  undefined1 *puVar19;
  int iStack_78;
  int iStack_74;
  undefined8 uStack_6c;
  int iStack_64;
  int iStack_60;
  undefined8 *puStack_5c;
  undefined8 *puStack_58;
  int aiStack_54 [3];
  byte *pbStack_48;
  uint *puStack_44;
  int iStack_40;
  undefined8 *puStack_3c;
  uint uStack_38;
  uint uStack_34;
  int iStack_30;
  uint uStack_2c;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_48 = param_1;
  FUN_00592760(1);
  FUN_00592760(5);
  iStack_18 = 0;
  iStack_60 = 0;
  puStack_5c = (undefined8 *)0x0;
  puStack_3c = (undefined8 *)0x0;
  puStack_58 = (undefined8 *)0x0;
  uStack_8 = 0;
  if (*(int *)(param_1 + 8) == 0) {
    piVar14 = (int *)0x0;
  }
  else {
    piVar14 = *(int **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
  }
  puVar8 = (undefined8 *)0x0;
  if (piVar14 != (int *)0x0) {
    do {
      if (puVar8 == puStack_5c) {
        FUN_00706320(puStack_5c,piVar14 + 2);
        puVar8 = puStack_58;
      }
      else {
        *puStack_5c = *(undefined8 *)(piVar14 + 2);
        *(int *)(puStack_5c + 1) = piVar14[4];
        puStack_5c = (undefined8 *)((int)puStack_5c + 0xc);
      }
      piVar14 = (int *)*piVar14;
    } while (piVar14 != (int *)0x0);
    iStack_18 = iStack_60;
    puStack_3c = puVar8;
  }
  iVar7 = iStack_18;
  uStack_38 = ((int)puStack_5c - iStack_18) / 0xc;
  iStack_60 = iStack_18;
  FUN_00a6d780(iStack_18,puStack_5c,uStack_38,param_2);
  iStack_78 = 0;
  iStack_74 = 0;
  aiStack_54[0] = 0;
  aiStack_54[1] = 0;
  aiStack_54[2] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_34 = 0;
  if (uStack_38 != 0) {
    uStack_20 = 0xffffffff;
    iStack_64 = 0;
    do {
      uVar1 = *(undefined8 *)(iVar7 + uStack_34 * 0xc);
      iVar7 = *(int *)(iVar7 + 8 + uStack_34 * 0xc);
      uStack_6c._0_4_ = (int)uVar1;
      puStack_44 = (uint *)((int)uStack_6c - iStack_78);
      uStack_6c._4_4_ = (int)((ulonglong)uVar1 >> 0x20);
      iStack_30 = uStack_6c._4_4_ - iStack_74;
      iStack_40 = iVar7 - iStack_64;
      iStack_1c = 0x18;
      uStack_6c = uVar1;
      iStack_64 = iVar7;
      do {
        uStack_2c = param_2[5];
        uVar12 = param_2[4];
        iStack_28 = (int)puStack_44 >> ((byte)iStack_1c & 0x1f);
        if (uVar12 < uStack_2c) {
          param_2[4] = uVar12 + 1;
          puVar5 = param_2;
          if (0xf < uStack_2c) {
            puVar5 = (uint *)*param_2;
          }
          *(char *)((int)puVar5 + uVar12) = (char)iStack_28;
          *(undefined *)((int)puVar5 + uVar12 + 1) = 0;
        }
        else {
          if (uVar12 == 0x7fffffff) goto LAB_00a7283c;
          uVar18 = uVar12 + 1 | 0xf;
          if (uVar18 < 0x80000000) {
            if (0x7fffffff - (uStack_2c >> 1) < uStack_2c) {
              uVar18 = 0x7fffffff;
            }
            else {
              uVar15 = uStack_2c + (uStack_2c >> 1);
              if (uVar18 < uVar15) {
                uVar18 = uVar15;
              }
            }
          }
          else {
            uVar18 = 0x7fffffff;
          }
          uVar15 = uVar18 + 1;
          if (uVar15 < 0x1000) {
            if (uVar15 == 0) {
              uVar15 = 0;
            }
            else {
              uVar15 = FUN_01674e20(uVar15);
            }
          }
          else {
            uVar9 = uVar18 + 0x24;
            if (uVar18 + 0x24 <= uVar15) {
              uVar9 = uStack_20;
            }
            iVar7 = FUN_01674e20(uVar9);
            if (iVar7 == 0) goto LAB_00a72832;
            uVar15 = iVar7 + 0x23U & 0xffffffe0;
            *(int *)(uVar15 - 4) = iVar7;
          }
          param_2[4] = uVar12 + 1;
          param_2[5] = uVar18;
          if (uStack_2c < 0x10) {
            FUN_0170c6f0(uVar15,param_2,uVar12);
            *(char *)(uVar15 + uVar12) = (char)iStack_28;
            *(undefined *)(uVar15 + 1 + uVar12) = 0;
          }
          else {
            uVar18 = *param_2;
            FUN_0170c6f0(uVar15,uVar18,uVar12);
            uVar9 = uStack_2c + 1;
            *(char *)(uVar15 + uVar12) = (char)iStack_28;
            *(undefined *)(uVar15 + 1 + uVar12) = 0;
            uVar12 = uVar18;
            if (0xfff < uVar9) {
              uVar12 = *(uint *)(uVar18 - 4);
              uVar9 = uStack_2c + 0x24;
              if (0x1f < (uVar18 - uVar12) - 4) goto LAB_00a72832;
            }
            FUN_01674ea0(uVar12,uVar9);
          }
          *param_2 = uVar15;
        }
        uStack_2c = param_2[5];
        uVar12 = param_2[4];
        iStack_28 = iStack_30 >> ((byte)iStack_1c & 0x1f);
        if (uVar12 < uStack_2c) {
          param_2[4] = uVar12 + 1;
          puVar5 = param_2;
          if (0xf < uStack_2c) {
            puVar5 = (uint *)*param_2;
          }
          *(char *)((int)puVar5 + uVar12) = (char)iStack_28;
          *(undefined *)((int)puVar5 + uVar12 + 1) = 0;
        }
        else {
          if (uVar12 == 0x7fffffff) goto LAB_00a7283c;
          uVar18 = uVar12 + 1 | 0xf;
          if (uVar18 < 0x80000000) {
            if (0x7fffffff - (uStack_2c >> 1) < uStack_2c) {
              uVar18 = 0x7fffffff;
            }
            else {
              uVar15 = uStack_2c + (uStack_2c >> 1);
              if (uVar18 < uVar15) {
                uVar18 = uVar15;
              }
            }
          }
          else {
            uVar18 = 0x7fffffff;
          }
          uVar15 = uVar18 + 1;
          if (uVar15 < 0x1000) {
            if (uVar15 == 0) {
              uVar15 = 0;
            }
            else {
              uVar15 = FUN_01674e20(uVar15);
            }
          }
          else {
            uVar9 = uVar18 + 0x24;
            if (uVar18 + 0x24 <= uVar15) {
              uVar9 = uStack_20;
            }
            iVar7 = FUN_01674e20(uVar9);
            if (iVar7 == 0) goto LAB_00a72832;
            uVar15 = iVar7 + 0x23U & 0xffffffe0;
            *(int *)(uVar15 - 4) = iVar7;
          }
          param_2[4] = uVar12 + 1;
          param_2[5] = uVar18;
          if (uStack_2c < 0x10) {
            FUN_0170c6f0(uVar15,param_2,uVar12);
            *(char *)(uVar15 + uVar12) = (char)iStack_28;
            *(undefined *)(uVar15 + 1 + uVar12) = 0;
          }
          else {
            uVar18 = *param_2;
            FUN_0170c6f0(uVar15,uVar18,uVar12);
            uVar9 = uStack_2c + 1;
            *(char *)(uVar15 + uVar12) = (char)iStack_28;
            *(undefined *)(uVar15 + 1 + uVar12) = 0;
            uVar12 = uVar18;
            if (0xfff < uVar9) {
              uVar12 = *(uint *)(uVar18 - 4);
              uVar9 = uStack_2c + 0x24;
              if (0x1f < (uVar18 - uVar12) - 4) goto LAB_00a72832;
            }
            FUN_01674ea0(uVar12,uVar9);
          }
          *param_2 = uVar15;
        }
        uStack_2c = param_2[5];
        uVar12 = param_2[4];
        iStack_28 = iStack_40 >> ((byte)iStack_1c & 0x1f);
        if (uVar12 < uStack_2c) {
          param_2[4] = uVar12 + 1;
          puVar5 = param_2;
          if (0xf < uStack_2c) {
            puVar5 = (uint *)*param_2;
          }
          *(char *)((int)puVar5 + uVar12) = (char)iStack_28;
          *(undefined *)((int)puVar5 + uVar12 + 1) = 0;
        }
        else {
          if (uVar12 == 0x7fffffff) {
LAB_00a7283c:
            FUN_00554040();
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
          }
          uVar18 = uVar12 + 1 | 0xf;
          if (uVar18 < 0x80000000) {
            if (0x7fffffff - (uStack_2c >> 1) < uStack_2c) {
              uVar18 = 0x7fffffff;
            }
            else {
              uVar15 = uStack_2c + (uStack_2c >> 1);
              if (uVar18 < uVar15) {
                uVar18 = uVar15;
              }
            }
          }
          else {
            uVar18 = 0x7fffffff;
          }
          uVar15 = uVar18 + 1;
          if (uVar15 < 0x1000) {
            if (uVar15 == 0) {
              uVar15 = 0;
            }
            else {
              uVar15 = FUN_01674e20(uVar15);
            }
          }
          else {
            uVar9 = uVar18 + 0x24;
            if (uVar18 + 0x24 <= uVar15) {
              uVar9 = uStack_20;
            }
            iVar7 = FUN_01674e20(uVar9);
            if (iVar7 == 0) goto LAB_00a72832;
            uVar15 = iVar7 + 0x23U & 0xffffffe0;
            *(int *)(uVar15 - 4) = iVar7;
          }
          param_2[4] = uVar12 + 1;
          param_2[5] = uVar18;
          if (uStack_2c < 0x10) {
            FUN_0170c6f0(uVar15,param_2,uVar12);
            *(char *)(uVar15 + uVar12) = (char)iStack_28;
            *(undefined *)(uVar15 + 1 + uVar12) = 0;
          }
          else {
            uVar18 = *param_2;
            FUN_0170c6f0(uVar15,uVar18,uVar12);
            uVar9 = uStack_2c + 1;
            *(char *)(uVar15 + uVar12) = (char)iStack_28;
            *(undefined *)(uVar15 + 1 + uVar12) = 0;
            uVar12 = uVar18;
            if (0xfff < uVar9) {
              uVar12 = *(uint *)(uVar18 - 4);
              uVar9 = uStack_2c + 0x24;
              if (0x1f < (uVar18 - uVar12) - 4) goto LAB_00a72832;
            }
            FUN_01674ea0(uVar12,uVar9);
          }
          *param_2 = uVar15;
        }
        iStack_1c = iStack_1c + -8;
      } while (-1 < iStack_1c);
      pbVar16 = pbStack_48 + *pbStack_48 + 1;
      uVar6 = FUN_00a6ce70(&uStack_6c);
      FUN_006e16e0(&iStack_24,uVar6,&uStack_6c,-(uint)(pbVar16 != (byte *)0x0) & (uint)(pbVar16 + 1)
                  );
      iVar17 = 0;
      uStack_14 = 0;
      iStack_28 = *(int *)(iStack_24 + 0x1c);
      FUN_00715060(iStack_28 * iStack_28 * iStack_28 * 2,aiStack_54);
      iStack_1c = aiStack_54[0];
      uStack_2c = 0;
      iVar7 = aiStack_54[0];
      if (0 < iStack_28) {
        uVar12 = (uint)CONCAT11((undefined)uStack_14,uStack_14._1_1_);
        do {
          iStack_30 = 0;
          do {
            uVar3 = *(ushort *)
                     (*(int *)(iStack_24 + 0x14) +
                     (uStack_2c * *(int *)(iStack_24 + 0x1c) + iStack_30) * 2);
            if ((short)uVar3 < 0) {
              puVar19 = (undefined1 *)
                        (*(int *)(iStack_24 + 0x18) +
                        (uVar3 & 0xfff) * *(int *)(iStack_24 + 0x1c) * 2);
            }
            else {
              puVar19 = &DAT_01ee9940 + (uVar3 & 0xfff) * 0x40;
            }
            iVar13 = 0;
            iVar7 = iStack_28;
            do {
              if ((puVar19[iVar13 * 2] == (char)(uVar12 >> 8)) &&
                 (puVar19[iVar13 * 2 + 1] == (char)uVar12)) {
                iVar17 = iVar17 + 1;
              }
              else {
                if (iVar17 != 0) {
                  iStack_1c = FUN_00a70020(iStack_1c,&uStack_14,iVar17);
                }
                uVar2 = *(undefined2 *)(puVar19 + iVar13 * 2);
                iVar17 = 1;
                uStack_14._1_1_ = (undefined)((ushort)uVar2 >> 8);
                uVar12 = (uint)CONCAT11((char)uVar2,uStack_14._1_1_);
                iVar7 = iStack_28;
                uStack_14 = uVar2;
              }
              iVar13 = iVar13 + 1;
            } while (iVar13 < iVar7);
            iStack_30 = iStack_30 + 1;
          } while (iStack_30 < iVar7);
          uStack_2c = uStack_2c + 1;
        } while ((int)uStack_2c < iVar7);
        iVar7 = iStack_1c;
        if (iVar17 != 0) {
          iVar7 = FUN_00a70020(iStack_1c,&uStack_14,iVar17);
        }
      }
      uVar12 = param_2[5];
      puVar5 = param_2;
      if (0xf < uVar12) {
        puVar5 = (uint *)*param_2;
      }
      puVar10 = param_2;
      if (0xf < uVar12) {
        puVar10 = (uint *)*param_2;
      }
      puVar11 = param_2;
      if (0xf < uVar12) {
        puVar11 = (uint *)*param_2;
      }
      puStack_44 = param_2;
      FUN_00591430(((int)puVar10 + param_2[4]) - (int)puVar11,
                   (int)puVar5 + (param_2[4] - ((int)puVar10 + param_2[4])),aiStack_54[0],
                   iVar7 - aiStack_54[0]);
      uStack_34 = uStack_34 + 1;
      iVar7 = iStack_18;
      if (uStack_38 <= uStack_34) goto LAB_00a72794;
      iStack_74 = (int)((ulonglong)uStack_6c >> 0x20);
      iStack_78 = (int)uStack_6c;
    } while( true );
  }
LAB_00a727dc:
  if (iVar7 != 0) {
    uVar12 = (((int)puStack_3c - iVar7) / 0xc) * 0xc;
    iVar17 = iVar7;
    if (0xfff < uVar12) {
      iVar17 = *(int *)(iVar7 + -4);
      uVar12 = uVar12 + 0x23;
      if (0x1f < (iVar7 - iVar17) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar17,uVar12);
  }
  ExceptionList = pvStack_10;
  return;
LAB_00a72794:
  if (aiStack_54[0] != 0) {
    uVar12 = aiStack_54[2] - aiStack_54[0];
    iVar7 = aiStack_54[0];
    if (0xfff < uVar12) {
      iVar7 = *(int *)(aiStack_54[0] + -4);
      uVar12 = uVar12 + 0x23;
      if (0x1f < (aiStack_54[0] - iVar7) - 4U) {
LAB_00a72832:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar12);
    aiStack_54[0] = 0;
    aiStack_54[1] = 0;
    aiStack_54[2] = 0;
    iVar7 = iStack_18;
  }
  goto LAB_00a727dc;
}



/* FUNCTION 21292 ; VA 0x00a72850 ; FUN_00a72850 */

void __thiscall FUN_00a72850(int *param_1,undefined8 *param_2,undefined8 *param_3)

{
  short sVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  
  fVar2 = DAT_018e3f8c;
  if ((DAT_01d66370 == '\0') && (DAT_01d69070 == '\0')) {
    sVar1 = *(short *)(param_1 + 2);
    *param_2 = CONCAT44((float)((int)*(short *)(param_1 + 1) << 2),
                        (float)((int)*(short *)param_1 << 2));
    *(float *)(param_2 + 1) = (float)((int)sVar1 << 2);
    fVar4 = (float)((int)(short)(*(short *)(param_1 + 3) + 1) << 2);
    fVar3 = (float)((int)(short)(*(short *)(param_1 + 4) + 1) << 2);
    fVar2 = (float)((int)(short)(*(short *)(param_1 + 5) + 1) << 2);
  }
  else {
    fVar3 = (float)param_1[2] * DAT_018e3f8c;
    *param_2 = CONCAT44((float)param_1[1] * DAT_018e3f8c,(float)*param_1 * DAT_018e3f8c);
    *(float *)(param_2 + 1) = fVar3;
    fVar4 = (float)param_1[3] * fVar2;
    fVar3 = (float)param_1[4] * fVar2;
    fVar2 = (float)param_1[5] * fVar2;
  }
  *param_3 = CONCAT44(fVar3,fVar4);
  *(float *)(param_3 + 1) = fVar2;
  return;
}



/* FUNCTION 21293 ; VA 0x00a72960 ; FUN_00a72960 */

void __thiscall FUN_00a72960(byte *param_1,int *param_2,int param_3,int param_4)

{
  byte *pbVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined uVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  byte bVar9;
  int *piVar10;
  int *piVar11;
  uint uVar12;
  uint uVar13;
  byte *pbVar14;
  undefined8 uVar15;
  undefined auStack_140 [28];
  undefined8 uStack_124;
  undefined8 uStack_118;
  uint uStack_110;
  undefined8 uStack_10c;
  uint uStack_104;
  int iStack_100;
  int iStack_fc;
  int iStack_f4;
  int iStack_f0;
  int iStack_e8;
  int iStack_e4;
  int iStack_dc;
  int iStack_d8;
  int *piStack_d0;
  uint uStack_cc;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined8 uStack_b4;
  int iStack_ac;
  undefined8 uStack_a8;
  int iStack_a0;
  int iStack_9c;
  int iStack_98;
  int iStack_94;
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  undefined8 uStack_84;
  int *piStack_7c;
  int *piStack_78;
  uint uStack_74;
  int *piStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  int *piStack_60;
  uint uStack_5c;
  int *piStack_58;
  int *piStack_54;
  int *piStack_50;
  undefined4 *puStack_4c;
  undefined8 *puStack_48;
  undefined8 uStack_44;
  uint uStack_3c;
  int *piStack_38;
  uint uStack_34;
  int *piStack_30;
  uint uStack_2c;
  byte *pbStack_28;
  uint *puStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e29c7;
  pvStack_10 = ExceptionList;
  cStack_11 = '\0';
  ExceptionList = &pvStack_10;
  pbStack_28 = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eea970) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eea970), DAT_01eea970 == -1)) {
    uStack_8 = 0;
    uVar15 = FUN_0152dab0("Voxel","write",0xffffffff);
    DAT_01eea96c = (undefined4)((ulonglong)uVar15 >> 0x20);
    DAT_01eea968 = (undefined4)uVar15;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eea970);
  }
  uStack_6c = DAT_01eea968;
  uStack_c4 = DAT_01eea968;
  uStack_68 = DAT_01eea96c;
  uStack_c0 = DAT_01eea96c;
  uStack_bc = FUN_0152d930(DAT_01eea968,DAT_01eea96c);
  uStack_8 = 1;
  uStack_64 = FUN_01675290(DAT_01ee9930);
  FUN_00a70da0(&uStack_118,5);
  FUN_00a6f570(auStack_140,param_4);
  piStack_58 = (int *)0x0;
  piStack_54 = (int *)0x0;
  piStack_50 = (int *)0x0;
  puStack_48 = &uStack_118;
  uStack_44 = uStack_118;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_124 = uStack_10c;
  uStack_5c = uStack_104;
  uStack_3c = uStack_110;
  do {
    piVar11 = piStack_54;
    if ((int)uStack_44 == (int)uStack_124) {
      if ((uStack_44._4_4_ == uStack_124._4_4_) && (uStack_3c == uStack_5c)) {
        uVar4 = 0xff;
        if (*(int *)(param_3 + 0x10) == 0) {
          uVar4 = 1;
        }
        puStack_4c = *(undefined4 **)(param_1 + 0x20);
        puVar8 = *(undefined4 **)(param_1 + 0x1c);
        puVar2 = puStack_4c;
        piVar10 = piStack_58;
        if (puVar8 != puStack_4c) {
          do {
            for (; piVar10 != piVar11; piVar10 = piVar10 + 6) {
              (**(code **)(*(int *)*puVar8 + 4))(piVar10,param_4,uVar4);
              puVar2 = puStack_4c;
            }
            puVar8 = puVar8 + 1;
            piVar10 = piStack_58;
          } while (puVar8 != puVar2);
        }
        uVar5 = uStack_64;
        FUN_00612d60();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        FUN_01675290(uVar5);
        uStack_8 = 6;
        FUN_0152dda0(uStack_6c,uStack_68,uStack_bc);
        ExceptionList = pvStack_10;
        return;
      }
    }
    bVar9 = *param_1;
    uVar5 = FUN_00a6ce70(&uStack_44);
    FUN_006e16e0(&piStack_60,uVar5,&uStack_44,
                 -(uint)(param_1 + bVar9 + 1 != (byte *)0x0) & (uint)(param_1 + bVar9 + 1 + 1));
    piVar11 = piStack_60;
    if ((*(int *)(param_3 + 0x10) != 0) || (param_1 = pbStack_28, piStack_60 != (int *)0x0)) {
      piStack_7c = (int *)(uStack_3c * 0x20);
      uStack_cc = uStack_44._4_4_ * 0x20;
      piStack_d0 = (int *)((int)uStack_44 * 0x20);
      piStack_38 = piStack_7c + 8;
      piStack_78 = piStack_d0 + 8;
      uStack_74 = uStack_cc + 0x20;
      uStack_84 = CONCAT44(uStack_cc,piStack_d0);
      piStack_70 = piStack_7c + 8;
      uStack_34 = uStack_74;
      piStack_30 = piStack_7c;
      uStack_2c = uStack_cc;
      piStack_1c = piStack_d0;
      if (*(int *)(param_3 + 0x10) == 0) {
        puStack_24 = (uint *)((int)piStack_7c - param_2[2]);
        piStack_20 = (int *)(uStack_cc - param_2[1]);
        piStack_18 = (int *)(param_2[5] - (int)piStack_70);
        if (-1 < (int)(param_2[3] - (int)piStack_78 | (int)piStack_d0 - *param_2 |
                       param_2[4] - uStack_74 | (uint)piStack_18 | (uint)piStack_20 |
                      (uint)puStack_24)) {
          if (piStack_50 == piStack_54) {
            FUN_00603350(piStack_54,&uStack_84);
          }
          else {
            *piStack_54 = (int)piStack_d0;
            piStack_54[1] = uStack_cc;
            piStack_54[2] = (int)piStack_7c;
            piStack_54[3] = (int)piStack_78;
            *(ulonglong *)(piStack_54 + 4) = CONCAT44(piStack_70,uStack_74);
            piStack_54 = piStack_54 + 6;
          }
          puStack_24 = (uint *)(pbStack_28 + 4);
          *(int *)(pbStack_28 + 0x18) = *(int *)(pbStack_28 + 0x18) - piVar11[0x15];
          piStack_20 = (int *)*piVar11;
          piStack_18 = (int *)((uint)piVar11[1] % *puStack_24);
          piVar10 = *(int **)(*(int *)(pbStack_28 + 0x14) + (int)piStack_18 * 4);
          for (piStack_1c = (int *)*piVar10; param_1 = pbStack_28, piStack_1c != piVar11;
              piStack_1c = (int *)*piStack_1c) {
            piVar10 = piStack_1c;
          }
          do {
            *piVar10 = *piStack_1c;
            uStack_8._0_1_ = 4;
            FUN_016f32d1(piStack_1c + 5,0x10,4,FUN_00a6de20);
            uStack_8 = CONCAT31(uStack_8._1_3_,3);
            FUN_01674ea0(piStack_1c,0x5c);
            *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
            piVar11 = piStack_18;
            if (*piVar10 == 0) {
LAB_00a72c20:
              if (*(int **)(*(int *)(param_1 + 0x14) + (int)piStack_18 * 4) == piVar10) {
                *(undefined4 *)(*(int *)(param_1 + 0x14) + (int)piStack_18 * 4) = 0;
              }
            }
            else {
              piVar11 = (int *)(*(uint *)(*piVar10 + 4) % *puStack_24);
              param_1 = pbStack_28;
              if (piStack_18 != piVar11) {
                *(int **)(*(int *)(pbStack_28 + 0x14) + (int)piVar11 * 4) = piVar10;
                goto LAB_00a72c20;
              }
            }
            piStack_1c = (int *)*piVar10;
            piStack_18 = piVar11;
          } while (piStack_1c != piStack_20);
          goto LAB_00a72f68;
        }
      }
      if (piStack_60 == (int *)0x0) {
        iVar7 = FUN_00a6deb0(&uStack_44);
        piVar11 = (int *)(iVar7 + 0xc);
      }
      else {
        piVar11 = piStack_60 + 5;
      }
      bVar9 = (byte)param_4;
      uVar6 = (1 << (bVar9 & 0x1f)) - 1;
      puStack_24 = (uint *)~uVar6;
      piStack_38 = (int *)(uVar6 + (int)piStack_38 & (uint)puStack_24);
      piStack_20 = (int *)((uint)puStack_24 & (uint)piStack_30);
      iStack_d8 = (int)((uint)puStack_24 & uStack_2c) >> (bVar9 & 0x1f);
      iStack_e4 = (int)(uStack_34 + uVar6 & (uint)puStack_24) >> (bVar9 & 0x1f);
      iStack_e8 = (int)((int)piStack_78 + uVar6 & (uint)puStack_24) >> (bVar9 & 0x1f);
      iStack_ac = (int)piStack_20 >> (bVar9 & 0x1f);
      iStack_a0 = (int)piStack_38 >> (bVar9 & 0x1f);
      iStack_dc = (int)((uint)puStack_24 & (uint)piStack_1c) >> (bVar9 & 0x1f);
      uStack_b4 = CONCAT44(iStack_d8,iStack_dc);
      uStack_a8 = CONCAT44(iStack_e4,iStack_e8);
      piStack_18 = piVar11;
      FUN_00a71630(param_4 == 0,piVar11 + 0x11,&uStack_84,param_2);
      cVar3 = FUN_00a6e7c0(piVar11 + param_4 * 4,&uStack_b4,param_3,auStack_140);
      piVar10 = piStack_54;
      if (cVar3 == '\0') {
        iVar7 = piVar11[0x10];
        pbVar14 = pbStack_28;
      }
      else {
        FUN_00a71450(&iStack_9c,&uStack_84);
        if (piStack_50 == piVar10) {
          FUN_00603350(piVar10,&iStack_9c);
        }
        else {
          *piVar10 = iStack_9c;
          piVar10[1] = iStack_98;
          piVar10[2] = iStack_94;
          piVar10[3] = iStack_90;
          *(ulonglong *)(piVar10 + 4) = CONCAT44(iStack_88,iStack_8c);
          piStack_54 = piVar10 + 6;
        }
        piStack_38 = (int *)(iStack_90 + -(int)piStack_1c);
        puStack_24 = (uint *)(iStack_8c + -uStack_2c);
        piStack_20 = (int *)(iStack_88 + -(int)piStack_30);
        uStack_34 = iStack_9c + -(int)piStack_1c;
        uVar6 = param_4 + 1;
        piStack_1c = (int *)(iStack_98 + -uStack_2c);
        puStack_4c = (undefined4 *)(iStack_94 + -(int)piStack_30);
        if (uVar6 < 4) {
          bVar9 = (byte)uVar6 & 0x1f;
          uStack_2c = 1 << bVar9 | 1U >> 0x20 - bVar9;
          piStack_30 = piVar11 + uVar6 * 4;
          do {
            piVar11 = piStack_30;
            uVar12 = uStack_2c - 1;
            uVar13 = ~uVar12;
            bVar9 = (byte)uVar6;
            iStack_100 = (int)((int)piStack_38 + uVar12 & uVar13) >> (bVar9 & 0x1f);
            iStack_fc = (int)((uint)((int)puStack_24 + uVar12) & uVar13) >> (bVar9 & 0x1f);
            iStack_a0 = (int)(uVar12 + (int)piStack_20 & uVar13) >> (bVar9 & 0x1f);
            iStack_f4 = (int)(uStack_34 & uVar13) >> (bVar9 & 0x1f);
            iStack_f0 = (int)((uint)piStack_1c & uVar13) >> (bVar9 & 0x1f);
            uStack_b4 = CONCAT44(iStack_f0,iStack_f4);
            iStack_ac = (int)((uint)puStack_4c & uVar13) >> (bVar9 & 0x1f);
            uStack_a8 = CONCAT44(iStack_fc,iStack_100);
            FUN_00a6fb30(piStack_30,&uStack_b4,piStack_30 + -4);
            uVar6 = uVar6 + 1;
            piStack_30 = piVar11 + 4;
            uStack_2c = uStack_2c << 1 | (uint)((int)uStack_2c < 0);
            piVar11 = piStack_18;
          } while (uVar6 < 4);
        }
        pbVar14 = pbStack_28;
        iVar7 = FUN_00a6eb50(piVar11,&cStack_11);
        pbVar1 = pbVar14 + 0x18;
        *(int *)pbVar1 = *(int *)pbVar1 + (iVar7 - piStack_18[0x10]);
        piStack_18[0x10] = iVar7;
      }
      param_1 = pbStack_28;
      if (((iVar7 == 0) && (cStack_11 != '\0')) && (*(int *)(pbVar14 + 8) != 0)) {
        piStack_38 = (int *)FUN_00a6ce70(&uStack_44);
        puStack_24 = (uint *)(pbVar14 + 4);
        puStack_4c = (undefined4 *)*puStack_24;
        uStack_2c = (uint)piStack_38 % (uint)puStack_4c;
        piStack_20 = (int *)(uStack_2c * 4);
        piStack_30 = *(int **)((int)piStack_20 + *(int *)(pbVar14 + 0x14));
        param_1 = pbStack_28;
        if ((piStack_30 != (int *)0x0) && ((int *)*piStack_30 != (int *)0x0)) {
          uStack_34 = uStack_3c;
          piVar11 = (int *)*piStack_30;
          while (piVar10 = piVar11, piVar11 = piStack_30, param_1 = pbVar14,
                (uint)piVar10[1] % (uint)puStack_4c == uStack_2c) {
            if ((((int *)piVar10[1] == piStack_38) && ((int)uStack_44 == piVar10[2])) &&
               ((uStack_44._4_4_ == piVar10[3] && (uStack_3c == piVar10[4])))) {
              FUN_00a6f0c0(piStack_30,*piVar10);
              param_1 = pbStack_28;
              if (*piVar11 != 0) {
                uVar6 = *(uint *)(*piVar11 + 4) % *puStack_24;
                if (uStack_2c == uVar6) break;
                *(int **)(*(int *)(pbVar14 + 0x14) + uVar6 * 4) = piVar11;
              }
              if (*(int **)(*(int *)(pbVar14 + 0x14) + (int)piStack_20) == piVar11) {
                *(undefined4 *)(*(int *)(pbVar14 + 0x14) + (int)piStack_20) = 0;
                param_1 = pbVar14;
              }
              break;
            }
            piVar11 = (int *)*piVar10;
            piStack_30 = piVar10;
            if ((int *)*piVar10 == (int *)0x0) break;
          }
        }
      }
    }
LAB_00a72f68:
    iVar7 = (int)uStack_44 + 1;
    uStack_44 = CONCAT44(uStack_44._4_4_,iVar7);
    if (iVar7 == *(int *)((int)puStack_48 + 0xc)) {
      uStack_44._4_4_ = uStack_44._4_4_ + 1;
      uStack_44 = CONCAT44(uStack_44._4_4_,*(undefined4 *)puStack_48);
      if (uStack_44._4_4_ == *(int *)(puStack_48 + 2)) {
        uStack_3c = uStack_3c + 1;
        uStack_44 = CONCAT44(*(undefined4 *)((int)puStack_48 + 4),*(undefined4 *)puStack_48);
        if (uStack_3c == *(uint *)((int)puStack_48 + 0x14)) {
          uStack_44 = *(undefined8 *)((int)puStack_48 + 0xc);
          uStack_3c = *(uint *)((int)puStack_48 + 0x14);
        }
      }
    }
  } while( true );
}



/* FUNCTION 21294 ; VA 0x00a73110 ; FUN_00a73110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a73110(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e29ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eea9a8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eea9a8);
    if (DAT_01eea9a8 == -1) {
      uStack_8 = 0;
      FUN_00888860("Region3",0x17,0,0,0);
      _DAT_01eea984 = RBX::Reflection::TType<class_RBX::Region3>::vftable;
      FUN_016f3654(&LAB_0188a870);
      FUN_016f37bf(&DAT_01eea9a8);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eea984;
}



/* FUNCTION 21295 ; VA 0x00a731b0 ; FUN_00a731b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a731b0(undefined4 *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  
  fVar7 = DAT_018ce2f4;
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  uVar11 = _UNK_018e3fbc;
  uVar10 = _UNK_018e3fb8;
  uVar9 = _UNK_018e3fb4;
  uVar8 = _DAT_018e3fb0;
  fVar1 = param_2[5];
  fVar2 = param_2[2];
  fVar3 = *param_2;
  fVar4 = param_2[4];
  fVar5 = param_2[1];
  fVar6 = param_2[3];
  *param_1 = _DAT_018e3fb0;
  param_1[1] = uVar9;
  param_1[2] = uVar10;
  param_1[3] = uVar11;
  param_1[4] = uVar8;
  param_1[5] = uVar9;
  param_1[6] = uVar10;
  param_1[7] = uVar11;
  param_1[8] = 0x3f800000;
  param_1[9] = (fVar3 + fVar6) * fVar7;
  param_1[10] = (fVar4 + fVar5) * fVar7;
  param_1[0xb] = (fVar1 + fVar2) * fVar7;
  fVar1 = param_2[5];
  fVar2 = param_2[2];
  *(ulonglong *)(param_1 + 0xc) = CONCAT44(param_2[4] - param_2[1],param_2[3] - *param_2);
  param_1[0xe] = fVar1 - fVar2;
  return param_1;
}



/* FUNCTION 21296 ; VA 0x00a732d0 ; FUN_00a732d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a732d0(undefined4 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  float fStack_30;
  float fStack_2c;
  float fStack_24;
  float fStack_20;
  
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  fVar3 = DAT_018ce2f4;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  uVar7 = _UNK_018e3fbc;
  uVar6 = _UNK_018e3fb8;
  uVar5 = _UNK_018e3fb4;
  uVar4 = _DAT_018e3fb0;
  fVar1 = *(float *)(param_2 + 1);
  fVar2 = *(float *)(param_3 + 1);
  fStack_24 = (float)*param_3;
  fStack_20 = (float)((ulonglong)*param_3 >> 0x20);
  fStack_2c = (float)((ulonglong)*param_2 >> 0x20);
  fStack_30 = (float)*param_2;
  *param_1 = _DAT_018e3fb0;
  param_1[1] = uVar5;
  param_1[2] = uVar6;
  param_1[3] = uVar7;
  param_1[4] = uVar4;
  param_1[5] = uVar5;
  param_1[6] = uVar6;
  param_1[7] = uVar7;
  param_1[8] = 0x3f800000;
  param_1[9] = (fStack_24 + fStack_30) * fVar3;
  param_1[10] = (fStack_20 + fStack_2c) * fVar3;
  param_1[0xb] = (fVar2 + fVar1) * fVar3;
  *(ulonglong *)(param_1 + 0xc) = CONCAT44(fStack_20 - fStack_2c,fStack_24 - fStack_30);
  param_1[0xe] = fVar2 - fVar1;
  return param_1;
}



/* FUNCTION 21297 ; VA 0x00a73410 ; FUN_00a73410 */

undefined4 * __fastcall FUN_00a73410(undefined4 *param_1)

{
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  return param_1;
}



/* FUNCTION 21298 ; VA 0x00a73480 ; FUN_00a73480 */

undefined4 FUN_00a73480(float *param_1,float *param_2,float *param_3,float param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  fVar2 = *param_2;
  fVar4 = *param_3;
  if ((((NAN(fVar2) || NAN(fVar4)) != (fVar2 == fVar4)) &&
      ((NAN(param_2[1]) || NAN(param_3[1])) != (param_2[1] == param_3[1]))) &&
     ((NAN(param_2[2]) || NAN(param_3[2])) != (param_2[2] == param_3[2]))) {
    return 0;
  }
  fVar2 = *param_1 - fVar2;
  fVar5 = param_1[1] - param_2[1];
  fVar6 = param_1[1] - param_3[1];
  fVar4 = *param_1 - fVar4;
  fVar1 = param_1[2] - param_2[2];
  fVar3 = param_1[2] - param_3[2];
  fVar2 = fVar5 * fVar5 + fVar2 * fVar2 + fVar1 * fVar1;
  fVar4 = fVar6 * fVar6 + fVar4 * fVar4 + fVar3 * fVar3;
  if ((fVar4 < fVar2) &&
     (fVar1 = (param_4 - DAT_018ce2f8) * param_2[3], fVar1 * fVar1 < fVar2 - fVar4)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 21299 ; VA 0x00a73550 ; FUN_00a73550 */

float10 FUN_00a73550(float *param_1,float *param_2)

{
  return (float10)(((param_1[1] - param_2[1]) * (param_1[1] - param_2[1]) +
                    (*param_1 - *param_2) * (*param_1 - *param_2) +
                   (param_1[2] - param_2[2]) * (param_1[2] - param_2[2])) /
                  (param_2[3] * param_2[3]));
}



/* FUNCTION 21300 ; VA 0x00a735a0 ; FUN_00a735a0 */

void __thiscall FUN_00a735a0(int param_1,float *param_2)

{
  float fVar1;
  
  fVar1 = DAT_018ce2f4;
  *param_2 = *(float *)(param_1 + 0x30) * DAT_018ce2f4 + *(float *)(param_1 + 0x24);
  param_2[1] = *(float *)(param_1 + 0x34) * fVar1 + *(float *)(param_1 + 0x28);
  param_2[2] = *(float *)(param_1 + 0x38) * fVar1 + *(float *)(param_1 + 0x2c);
  return;
}



/* FUNCTION 21301 ; VA 0x00a735f0 ; FUN_00a735f0 */

void __thiscall FUN_00a735f0(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar2 = DAT_018ce2f4;
  fVar3 = *(float *)(param_1 + 0x34) * DAT_018ce2f4;
  *param_2 = *(float *)(param_1 + 0x24) - *(float *)(param_1 + 0x30) * DAT_018ce2f4;
  fVar1 = *(float *)(param_1 + 0x38);
  param_2[1] = *(float *)(param_1 + 0x28) - fVar3;
  param_2[2] = *(float *)(param_1 + 0x2c) - fVar1 * fVar2;
  return;
}



/* FUNCTION 21302 ; VA 0x00a73650 ; FUN_00a73650 */

undefined4 * __thiscall
FUN_00a73650(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8,
            undefined4 param_9)

{
  uint *puVar1;
  char cVar2;
  undefined **ppuVar3;
  uint auStack_98 [2];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  uint uStack_64;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined4 uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2a18;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_3c = param_2;
    if ((param_2 & 1) == 0) {
      puStack_74 = &uStack_34;
      puStack_70 = (undefined4 *)0x0;
      puStack_78 = &param_4;
      uStack_80 = CONCAT44(0xa736b3,(undefined4)uStack_80);
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_4;
      uStack_30 = param_5;
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_1c = param_9;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  uStack_64 = 0;
  if (uStack_3c != 0) {
    uStack_64 = uStack_3c;
    if ((uStack_3c & 1) == 0) {
      puStack_74 = &uStack_5c;
      puStack_70 = (undefined4 *)0x0;
      puStack_78 = &uStack_34;
      uStack_80 = CONCAT44(0xa73702,(undefined4)uStack_80);
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    else {
      uStack_5c = uStack_34;
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
    }
  }
  puStack_70 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_98;
  auStack_98[0] = 0;
  uStack_44 = uStack_1c;
  puVar1 = auStack_98;
  if (uStack_64 != 0) {
    auStack_98[0] = uStack_64;
    if ((uStack_64 & 1) == 0) {
      (**(code **)(uStack_64 & 0xfffffffe))(&uStack_5c,&uStack_90,0);
      puVar1 = puStack_14;
    }
    else {
      uStack_90 = uStack_5c;
      uStack_8c = uStack_58;
      uStack_88 = uStack_54;
      uStack_84 = uStack_50;
      uStack_80 = uStack_4c;
      puVar1 = auStack_98;
    }
  }
  puStack_14 = puVar1;
  puStack_78 = (undefined4 *)uStack_44;
  ppuVar3 = &PTR_FUN_01946968;
  cVar2 = FUN_00a75620();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8._0_1_ = 3;
  if (((uStack_64 != 0) && ((uStack_64 & 1) == 0)) &&
     (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_5c;
    puStack_70 = (undefined4 *)0x2;
    uStack_80 = CONCAT44(0xa73797,(undefined4)uStack_80);
    puStack_74 = puStack_78;
    (**(code **)(uStack_64 & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_3c != 0) {
    if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_34;
      puStack_70 = (undefined4 *)0x2;
      uStack_80 = CONCAT44(0xa737c6,(undefined4)uStack_80);
      puStack_74 = puStack_78;
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    uStack_3c = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_4;
    puStack_70 = (undefined4 *)0x2;
    uStack_80 = CONCAT44(0xa737f4,(undefined4)uStack_80);
    puStack_74 = puStack_78;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21303 ; VA 0x00a73810 ; FUN_00a73810 */

undefined4 * __thiscall FUN_00a73810(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_00000034;
  undefined4 auStack_110 [17];
  undefined4 uStack_cc;
  undefined *puStack_c8;
  undefined *puStack_c4;
  undefined4 *puStack_c0;
  undefined auStack_ac [40];
  uint uStack_84;
  undefined auStack_7c [24];
  undefined4 uStack_64;
  undefined auStack_5c [40];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2a4b;
  pvStack_10 = ExceptionList;
  puStack_c0 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_c4 = (undefined *)0xa73854;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a786e0();
  uStack_64 = param_2;
  puStack_c0 = (undefined4 *)auStack_ac;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_c4 = (undefined *)0xa73876;
  FUN_00a786e0();
  puStack_c0 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_110;
  auStack_110[0] = uStack_64;
  FUN_00a786e0(auStack_5c);
  ppuVar2 = &PTR_FUN_01946930;
  cVar1 = FUN_00a757d0();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = auStack_2c;
      puStack_c0 = (undefined4 *)0x2;
      uStack_cc = 0xa738cd;
      puStack_c4 = puStack_c8;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_c0 = (undefined4 *)0xa738df;
  FUN_00a7c840();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_84 != 0) {
    if (((uStack_84 & 1) == 0) && (*(code **)(uStack_84 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = auStack_7c;
      puStack_c0 = (undefined4 *)0x2;
      uStack_cc = 0xa73900;
      puStack_c4 = puStack_c8;
      (**(code **)(uStack_84 & 0xfffffffe))();
    }
    uStack_84 = 0;
  }
  puStack_c0 = (undefined4 *)0xa73915;
  FUN_00a7c840();
  uStack_8 = 5;
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = &stack0x0000003c;
      puStack_c0 = (undefined4 *)0x2;
      uStack_cc = 0xa73939;
      puStack_c4 = puStack_c8;
      (**(code **)(in_stack_00000034 & 0xfffffffe))();
    }
    in_stack_00000034 = 0;
  }
  puStack_c0 = (undefined4 *)0xa7394b;
  FUN_00a7c840();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21304 ; VA 0x00a73960 ; FUN_00a73960 */

undefined4 * __thiscall
FUN_00a73960(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01946978;
  cVar3 = FUN_00605370(param_2,param_3,param_4,param_5,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21305 ; VA 0x00a73a50 ; FUN_00a73a50 */

undefined4 * __thiscall FUN_00a73a50(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_1c4 [80];
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined auStack_16c [80];
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined auStack_114 [80];
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined auStack_bc [80];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined auStack_64 [80];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2aab;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a78dc0(&stack0x0000000c);
  uStack_174 = param_2;
  uStack_170 = param_3;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00a78dc0(auStack_1c4);
  uStack_11c = uStack_174;
  uStack_118 = uStack_170;
  uStack_8._0_1_ = 2;
  FUN_00a78dc0(auStack_16c);
  uStack_6c = uStack_11c;
  uStack_68 = uStack_118;
  uStack_8._0_1_ = 3;
  FUN_00a78dc0(auStack_114);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(&uStack_6c);
  if (cVar2 == '\0') {
    uStack_c4 = uStack_6c;
    uStack_c0 = uStack_68;
    FUN_00a78dc0(auStack_64);
    uStack_8._0_1_ = 5;
    puVar3 = (undefined4 *)FUN_01674e20(0x58);
    uStack_8._0_1_ = 6;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_c4;
      puVar3[1] = uStack_c0;
      FUN_00a78dc0(auStack_bc);
    }
    param_1[2] = puVar3;
    FUN_00a7cc10();
    FUN_00a7cc10();
    bVar1 = true;
  }
  else {
    FUN_00a7cc10();
    bVar1 = false;
  }
  FUN_00a7cc10();
  ppuVar4 = &PTR_FUN_01946948;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a7cc10();
  FUN_00a7cc10();
  FUN_00a7cc10();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21306 ; VA 0x00a73c10 ; FUN_00a73c10 */

undefined4 * __thiscall FUN_00a73c10(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_19c [72];
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined auStack_14c [72];
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined auStack_fc [72];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined auStack_ac [72];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined auStack_5c [72];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2b0b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a78b10(&stack0x0000000c);
  uStack_154 = param_2;
  uStack_150 = param_3;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00a78b10(auStack_19c);
  uStack_104 = uStack_154;
  uStack_100 = uStack_150;
  uStack_8._0_1_ = 2;
  FUN_00a78b10(auStack_14c);
  uStack_64 = uStack_104;
  uStack_60 = uStack_100;
  uStack_8._0_1_ = 3;
  FUN_00a78b10(auStack_fc);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(&uStack_64);
  if (cVar2 == '\0') {
    uStack_b4 = uStack_64;
    uStack_b0 = uStack_60;
    FUN_00a78b10(auStack_5c);
    uStack_8._0_1_ = 5;
    puVar3 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 6;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_b4;
      puVar3[1] = uStack_b0;
      FUN_00a78b10(auStack_ac);
    }
    param_1[2] = puVar3;
    FUN_00a7ca10();
    FUN_00a7ca10();
    bVar1 = true;
  }
  else {
    FUN_00a7ca10();
    bVar1 = false;
  }
  FUN_00a7ca10();
  ppuVar4 = &PTR_FUN_01946960;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a7ca10();
  FUN_00a7ca10();
  FUN_00a7ca10();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21307 ; VA 0x00a73dd0 ; FUN_00a73dd0 */

undefined4 * __thiscall FUN_00a73dd0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000003c;
  undefined auStack_114 [24];
  undefined auStack_fc [24];
  undefined4 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined auStack_d4 [24];
  undefined auStack_bc [24];
  undefined4 uStack_a4;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined auStack_94 [24];
  undefined auStack_7c [24];
  undefined4 uStack_64;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 auStack_54 [6];
  undefined auStack_3c [24];
  undefined4 uStack_24;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2b88;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined4 *)auStack_114;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puStack_18 = param_1;
  FUN_00a7a380(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000024);
  uStack_e4 = in_stack_0000003c;
  uStack_dc = param_2;
  uStack_d8 = param_3;
  puStack_14 = (undefined4 *)auStack_d4;
  FUN_00a7a380(auStack_114);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_fc);
  uStack_a4 = uStack_e4;
  uStack_5c = uStack_dc;
  uStack_58 = uStack_d8;
  puStack_14 = auStack_54;
  FUN_00a7a380(auStack_d4);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_bc);
  uStack_24 = uStack_a4;
  uStack_8._0_1_ = 6;
  cVar2 = FUN_00585a40(&uStack_5c);
  if (cVar2 == '\0') {
    uStack_9c = uStack_5c;
    uStack_98 = uStack_58;
    puStack_14 = (undefined4 *)auStack_94;
    FUN_00a7a380(auStack_54);
    uStack_8._0_1_ = 7;
    FUN_0054ef60(auStack_3c);
    uStack_64 = uStack_24;
    uStack_8._0_1_ = 8;
    puVar3 = (undefined4 *)FUN_01674e20(0x40);
    uStack_8._0_1_ = 9;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      puStack_1c = puVar3 + 2;
      *puVar3 = uStack_9c;
      puVar3[1] = uStack_98;
      FUN_00a7a380(auStack_94);
      uStack_8._0_1_ = 10;
      FUN_0054ef60(auStack_7c);
      puVar3[0xe] = uStack_64;
      param_1 = puStack_18;
    }
    param_1[2] = puVar3;
    FUN_00a7cb00();
    FUN_00a7cb00();
    bVar1 = true;
  }
  else {
    FUN_00a7cb00();
    bVar1 = false;
  }
  FUN_00a7cb00();
  ppuVar4 = &PTR_FUN_01946928;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a7cb00();
  FUN_00a7cb00();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21308 ; VA 0x00a74000 ; FUN_00a74000 */

undefined4 * __thiscall FUN_00a74000(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_00000044;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_ec;
  undefined *puStack_e8;
  undefined *puStack_e4;
  undefined4 *puStack_e0;
  undefined auStack_cc [56];
  uint uStack_94;
  undefined auStack_8c [24];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined auStack_6c [56];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2bbb;
  pvStack_10 = ExceptionList;
  puStack_e0 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_e4 = (undefined *)0xa7404d;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a79230();
  uStack_74 = param_2;
  uStack_70 = param_3;
  puStack_e0 = (undefined4 *)auStack_cc;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_e4 = (undefined *)0xa74078;
  FUN_00a79230();
  puStack_e0 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = &uStack_140;
  uStack_140 = uStack_74;
  uStack_13c = uStack_70;
  FUN_00a79230(auStack_6c);
  ppuVar2 = &PTR_FUN_01946938;
  cVar1 = FUN_00a75960();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_e8 = auStack_2c;
      puStack_e0 = (undefined4 *)0x2;
      uStack_ec = 0xa740d5;
      puStack_e4 = puStack_e8;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_e0 = (undefined4 *)0xa740e7;
  FUN_00a7cb80();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_94 != 0) {
    if (((uStack_94 & 1) == 0) && (*(code **)(uStack_94 & 0xfffffffe) != (code *)0x0)) {
      puStack_e8 = auStack_8c;
      puStack_e0 = (undefined4 *)0x2;
      uStack_ec = 0xa7410e;
      puStack_e4 = puStack_e8;
      (**(code **)(uStack_94 & 0xfffffffe))();
    }
    uStack_94 = 0;
  }
  puStack_e0 = (undefined4 *)0xa74126;
  FUN_00a7cb80();
  uStack_8 = 5;
  if (in_stack_00000044 != 0) {
    if (((in_stack_00000044 & 1) == 0) &&
       (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
      puStack_e8 = &stack0x0000004c;
      puStack_e0 = (undefined4 *)0x2;
      uStack_ec = 0xa7414a;
      puStack_e4 = puStack_e8;
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
    }
    in_stack_00000044 = 0;
  }
  puStack_e0 = (undefined4 *)0xa7415c;
  FUN_00a7cb80();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21309 ; VA 0x00a74170 ; FUN_00a74170 */

undefined4 * __thiscall FUN_00a74170(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000003c;
  undefined auStack_114 [24];
  undefined auStack_fc [24];
  undefined4 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined auStack_d4 [24];
  undefined auStack_bc [24];
  undefined4 uStack_a4;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined auStack_94 [24];
  undefined auStack_7c [24];
  undefined4 uStack_64;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 auStack_54 [6];
  undefined auStack_3c [24];
  undefined4 uStack_24;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2c38;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined4 *)auStack_114;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puStack_18 = param_1;
  FUN_00a7a380(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000024);
  uStack_e4 = in_stack_0000003c;
  uStack_dc = param_2;
  uStack_d8 = param_3;
  puStack_14 = (undefined4 *)auStack_d4;
  FUN_00a7a380(auStack_114);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_fc);
  uStack_a4 = uStack_e4;
  uStack_5c = uStack_dc;
  uStack_58 = uStack_d8;
  puStack_14 = auStack_54;
  FUN_00a7a380(auStack_d4);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_bc);
  uStack_24 = uStack_a4;
  uStack_8._0_1_ = 6;
  cVar2 = FUN_00585a40(&uStack_5c);
  if (cVar2 == '\0') {
    uStack_9c = uStack_5c;
    uStack_98 = uStack_58;
    puStack_14 = (undefined4 *)auStack_94;
    FUN_00a7a380(auStack_54);
    uStack_8._0_1_ = 7;
    FUN_0054ef60(auStack_3c);
    uStack_64 = uStack_24;
    uStack_8._0_1_ = 8;
    puVar3 = (undefined4 *)FUN_01674e20(0x40);
    uStack_8._0_1_ = 9;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      puStack_1c = puVar3 + 2;
      *puVar3 = uStack_9c;
      puVar3[1] = uStack_98;
      FUN_00a7a380(auStack_94);
      uStack_8._0_1_ = 10;
      FUN_0054ef60(auStack_7c);
      puVar3[0xe] = uStack_64;
      param_1 = puStack_18;
    }
    param_1[2] = puVar3;
    FUN_00a7cb00();
    FUN_00a7cb00();
    bVar1 = true;
  }
  else {
    FUN_00a7cb00();
    bVar1 = false;
  }
  FUN_00a7cb00();
  ppuVar4 = &PTR_FUN_01946950;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a7cb00();
  FUN_00a7cb00();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21310 ; VA 0x00a743a0 ; FUN_00a743a0 */

undefined4 __thiscall FUN_00a743a0(undefined4 param_1)

{
  undefined4 in_stack_0000003c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017e2c60;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a7a380(&stack0x0000000c);
  iStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000024);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00a74170();
  FUN_00a7cb00();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21311 ; VA 0x00a74430 ; FUN_00a74430 */

undefined4 * __thiscall FUN_00a74430(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_14c [56];
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined auStack_10c [56];
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined auStack_cc [56];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined auStack_8c [56];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [56];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2cbb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a79530(&stack0x0000000c);
  uStack_114 = param_2;
  uStack_110 = param_3;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00a79530(auStack_14c);
  uStack_d4 = uStack_114;
  uStack_d0 = uStack_110;
  uStack_8._0_1_ = 2;
  FUN_00a79530(auStack_10c);
  uStack_54 = uStack_d4;
  uStack_50 = uStack_d0;
  uStack_8._0_1_ = 3;
  FUN_00a79530(auStack_cc);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(&uStack_54);
  if (cVar2 == '\0') {
    uStack_94 = uStack_54;
    uStack_90 = uStack_50;
    FUN_00a79530(auStack_4c);
    uStack_8._0_1_ = 5;
    puVar3 = (undefined4 *)FUN_01674e20(0x40);
    uStack_8._0_1_ = 6;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_94;
      puVar3[1] = uStack_90;
      FUN_00a79530(auStack_8c);
    }
    param_1[2] = puVar3;
    FUN_00a7cca0();
    FUN_00a7cca0();
    bVar1 = true;
  }
  else {
    FUN_00a7cca0();
    bVar1 = false;
  }
  FUN_00a7cca0();
  ppuVar4 = &PTR_FUN_01946958;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a7cca0();
  FUN_00a7cca0();
  FUN_00a7cca0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21312 ; VA 0x00a745f0 ; FUN_00a745f0 */

int * __thiscall FUN_00a745f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00a8ccb0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 21313 ; VA 0x00a74640 ; FUN_00a74640 */

int * __thiscall FUN_00a74640(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00a8cd20();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 21314 ; VA 0x00a74690 ; FUN_00a74690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a74690(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeade4) {
    FUN_016f3809(&DAT_01eeade4);
    if (DAT_01eeade4 == -1) {
      _DAT_01eeadd8 = FUN_005c65e0;
      _DAT_01eeaddc = FUN_005c65e0;
      _DAT_01eeade0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eeade4);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01eeadd8) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01eeadd8;
  return param_1;
}



/* FUNCTION 21315 ; VA 0x00a74740 ; FUN_00a74740 */

void __thiscall
FUN_00a74740(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 uStack_504;
  undefined4 uStack_500;
  undefined4 uStack_4fc;
  int iStack_4f8;
  undefined4 uStack_434;
  undefined4 uStack_430;
  undefined4 uStack_364;
  undefined4 uStack_360;
  undefined uStack_35c;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2d30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_02110da8);
  iStack_8 = 0;
  pcStack_14 = *(code **)(*(int *)*param_1 + 4);
  uStack_24 = uVar1;
  uStack_504 = FUN_0088cdc0();
  uStack_500 = 0;
  iStack_4f8 = param_2[1];
  if (iStack_4f8 != 0) {
    LOCK();
    *(int *)(iStack_4f8 + 4) = *(int *)(iStack_4f8 + 4) + 1;
    UNLOCK();
    iStack_4f8 = param_2[1];
  }
  uStack_4fc = *param_2;
  uStack_500 = FUN_006309e0();
  iStack_8._0_1_ = 1;
  uStack_434 = FUN_0088cb40();
  uStack_430 = 0;
  FUN_0054ef60(param_3);
  uStack_430 = FUN_005c9d30();
  iStack_8._0_1_ = 2;
  uStack_364 = FUN_0088daf0();
  uStack_360 = 0;
  uStack_35c = *param_4;
  uStack_360 = FUN_005c9ef0();
  iStack_8._0_1_ = 3;
  uStack_294 = FUN_0088cb40();
  uStack_290 = 0;
  FUN_0054ef60(param_5);
  uStack_290 = FUN_005c9d30();
  iStack_8._0_1_ = 4;
  uStack_1c4 = FUN_0088cb40();
  uStack_1c0 = 0;
  FUN_0054ef60(param_6);
  uStack_1c0 = FUN_005c9d30();
  iStack_8._0_1_ = 5;
  uStack_f4 = FUN_0088cb40();
  uStack_f0 = 0;
  FUN_0054ef60(param_7);
  uStack_f0 = FUN_005c9d30();
  iStack_8._0_1_ = 6;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_504,&uStack_24,param_2);
  iStack_8._0_1_ = 7;
  (*pcStack_14)(&uStack_20);
  iStack_8._0_1_ = 8;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_504,0xd0,6,FUN_0056e5b0);
  iStack_8 = 9;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21316 ; VA 0x00a74960 ; FUN_00a74960 */

void __thiscall FUN_00a74960(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  uint auStack_64 [2];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  uint auStack_44 [2];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2d68;
  pvStack_10 = ExceptionList;
  auStack_64[0] = 0;
  uStack_14 = *param_4;
  uVar1 = *(uint *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    auStack_64[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x40,&uStack_5c,0);
    }
    else {
      uStack_5c = *(undefined4 *)(param_1 + 0x40);
      uStack_58 = *(undefined4 *)(param_1 + 0x44);
      uStack_54 = *(undefined4 *)(param_1 + 0x48);
      uStack_50 = *(undefined4 *)(param_1 + 0x4c);
      uStack_4c = *(undefined8 *)(param_1 + 0x50);
      ExceptionList = &pvStack_10;
    }
  }
  uVar1 = *(uint *)(param_1 + 0x18);
  uStack_8 = 0;
  auStack_44[0] = 0;
  if (uVar1 != 0) {
    auStack_44[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x20,&uStack_3c,0);
    }
    else {
      uStack_3c = *(undefined4 *)(param_1 + 0x20);
      uStack_38 = *(undefined4 *)(param_1 + 0x24);
      uStack_34 = *(undefined4 *)(param_1 + 0x28);
      uStack_30 = *(undefined4 *)(param_1 + 0x2c);
      uStack_2c = *(undefined8 *)(param_1 + 0x30);
    }
  }
  piVar4 = *(int **)(param_1 + 0x14);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
    piVar4 = *(int **)(param_1 + 0x14);
  }
  piVar3 = *(int **)(param_1 + 0xc);
  uStack_1c = *(undefined4 *)(param_1 + 0x10);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
    piVar3 = *(int **)(param_1 + 0xc);
  }
  uStack_24 = *(undefined4 *)(param_1 + 8);
  uStack_8 = 4;
  piStack_20 = piVar3;
  piStack_18 = piVar4;
  FUN_00a76ea0(param_1,0,uStack_14,&uStack_24,&uStack_1c,auStack_44,auStack_64);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (auStack_44[0] != 0) {
    if (((auStack_44[0] & 1) == 0) && (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_44[0] & 0xfffffffe))(&uStack_3c,&uStack_3c,2);
    }
    auStack_44[0] = 0;
  }
  uStack_8 = 6;
  if (((auStack_64[0] != 0) && ((auStack_64[0] & 1) == 0)) &&
     (*(code **)(auStack_64[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_64[0] & 0xfffffffe))(&uStack_5c,&uStack_5c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21317 ; VA 0x00a74b20 ; FUN_00a74b20 */

void __thiscall FUN_00a74b20(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  uint auStack_64 [2];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  uint auStack_44 [2];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2d68;
  pvStack_10 = ExceptionList;
  auStack_64[0] = 0;
  uStack_14 = *param_4;
  uVar1 = *(uint *)(param_1 + 0x50);
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    auStack_64[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x58,&uStack_5c,0);
    }
    else {
      uStack_5c = *(undefined4 *)(param_1 + 0x58);
      uStack_58 = *(undefined4 *)(param_1 + 0x5c);
      uStack_54 = *(undefined4 *)(param_1 + 0x60);
      uStack_50 = *(undefined4 *)(param_1 + 100);
      uStack_4c = *(undefined8 *)(param_1 + 0x68);
      ExceptionList = &pvStack_10;
    }
  }
  uVar1 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  auStack_44[0] = 0;
  if (uVar1 != 0) {
    auStack_44[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x38,&uStack_3c,0);
    }
    else {
      uStack_3c = *(undefined4 *)(param_1 + 0x38);
      uStack_38 = *(undefined4 *)(param_1 + 0x3c);
      uStack_34 = *(undefined4 *)(param_1 + 0x40);
      uStack_30 = *(undefined4 *)(param_1 + 0x44);
      uStack_2c = *(undefined8 *)(param_1 + 0x48);
    }
  }
  piVar4 = *(int **)(param_1 + 0x2c);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
    piVar4 = *(int **)(param_1 + 0x2c);
  }
  piVar3 = *(int **)(param_1 + 0x24);
  uStack_1c = *(undefined4 *)(param_1 + 0x28);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
    piVar3 = *(int **)(param_1 + 0x24);
  }
  uStack_24 = *(undefined4 *)(param_1 + 0x20);
  uStack_8 = 4;
  piStack_20 = piVar3;
  piStack_18 = piVar4;
  FUN_00a76d60(param_1,0,uStack_14,param_1 + 8,&uStack_24,&uStack_1c,auStack_44,auStack_64);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (auStack_44[0] != 0) {
    if (((auStack_44[0] & 1) == 0) && (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_44[0] & 0xfffffffe))(&uStack_3c,&uStack_3c,2);
    }
    auStack_44[0] = 0;
  }
  uStack_8 = 6;
  if (((auStack_64[0] != 0) && ((auStack_64[0] & 1) == 0)) &&
     (*(code **)(auStack_64[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_64[0] & 0xfffffffe))(&uStack_5c,&uStack_5c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21318 ; VA 0x00a74ce0 ; FUN_00a74ce0 */

void __thiscall
FUN_00a74ce0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  uint *puVar4;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint auStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2da0;
  pvStack_10 = ExceptionList;
  param_2 = auStack_3c;
  pcVar2 = (code *)*param_1;
  uStack_8 = 2;
  auStack_3c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar4 = auStack_3c;
  if (param_13 != 0) {
    auStack_3c[0] = param_13;
    if ((param_13 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_15;
      uStack_4c = 0xa74d50;
      ExceptionList = &pvStack_10;
      (**(code **)(param_13 & 0xfffffffe))();
      puVar4 = param_2;
    }
    else {
      uStack_34 = param_15;
      uStack_30 = param_16;
      uStack_2c = param_17;
      uStack_28 = param_18;
      uStack_24 = param_19;
      ExceptionList = &pvStack_10;
      puVar4 = auStack_3c;
    }
  }
  param_2 = puVar4;
  uStack_8._0_1_ = 3;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_54,0);
    }
    else {
      uStack_54 = param_8;
      uStack_50 = param_9;
      uStack_4c = param_10;
      puStack_48 = param_11;
      uStack_44 = param_12;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  (*pcVar2)(param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_6 & 0xfffffffe))(&param_8,&param_8,2);
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_13 & 0xfffffffe))(&param_15,&param_15,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21319 ; VA 0x00a74e60 ; FUN_00a74e60 */

code * __thiscall
FUN_00a74e60(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined uVar4;
  undefined4 *puVar5;
  code *pcVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  code *in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  undefined4 in_stack_00000044;
  int *in_stack_00000048;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  int *piStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e2dd8;
  pvStack_10 = ExceptionList;
  param_2 = &uStack_28;
  pcVar6 = (code *)*param_1;
  ExceptionList = &pvStack_10;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000048[1] = in_stack_00000048[1] + 1;
    UNLOCK();
  }
  uStack_28 = in_stack_00000044;
  piStack_24 = in_stack_00000048;
  uStack_8 = 3;
  uStack_7 = 0;
  puVar5 = &uStack_28;
  if (in_stack_00000024 != (code *)0x0) {
    if (((uint)in_stack_00000024 & 1) == 0) {
      (**(code **)((uint)in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&uStack_40,0);
      puVar5 = param_2;
    }
    else {
      uStack_40 = in_stack_0000002c;
      uStack_3c = in_stack_00000030;
      uStack_38 = in_stack_00000034;
      uStack_34 = in_stack_00000038;
      uStack_30 = in_stack_0000003c;
      puVar5 = &uStack_28;
    }
  }
  param_2 = puVar5;
  uStack_8 = 4;
  FUN_0054ef60(&param_4);
  uStack_8 = 2;
  (*pcVar6)(param_3);
  uStack_8 = 1;
  uVar4 = uStack_8;
  uStack_8 = 1;
  if (0xf < in_stack_00000020) {
    uVar8 = in_stack_00000020 + 1;
    uVar7 = param_4;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(param_4 - 4);
      uVar8 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - uVar7) - 4) {
        uStack_8 = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  _uStack_8 = CONCAT31(uStack_7,5);
  pcVar6 = in_stack_00000024;
  if (in_stack_00000024 != (code *)0x0) {
    if ((((uint)in_stack_00000024 & 1) == 0) &&
       (pcVar6 = *(code **)((uint)in_stack_00000024 & 0xfffffffe), pcVar6 != (code *)0x0)) {
      pcVar6 = (code *)(*pcVar6)(&stack0x0000002c,&stack0x0000002c,2);
    }
    in_stack_00000024 = (code *)0x0;
  }
  piVar3 = in_stack_00000048;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000048 + 1;
    iVar2 = *piVar1;
    pcVar6 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pcVar6 = (code *)(**(code **)*in_stack_00000048)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 21320 ; VA 0x00a74fe0 ; FUN_00a74fe0 */

int __thiscall
FUN_00a74fe0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,int *param_7,int param_8)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000030;
  undefined4 in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2e08;
  pvStack_10 = ExceptionList;
  pcVar3 = (code *)*param_1;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_8);
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_3,param_4,param_5,param_6,param_7);
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_7 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000030) {
    uVar5 = in_stack_00000030 + 1;
    iVar4 = param_8;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_8 + -4);
      uVar5 = in_stack_00000030 + 0x24;
      if (0x1f < (param_8 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21321 ; VA 0x00a75110 ; FUN_00a75110 */

void __thiscall
FUN_00a75110(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  uint in_stack_0000002c;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  uint in_stack_00000044;
  undefined4 in_stack_00000054;
  uint in_stack_00000058;
  int in_stack_0000005c;
  uint in_stack_00000070;
  undefined auStack_38 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2e60;
  pvStack_10 = ExceptionList;
  param_2 = auStack_38;
  pcVar2 = (code *)*param_1;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  FUN_0054ef60();
  uStack_8._0_1_ = 6;
  FUN_0054ef60(&stack0x0000002c);
  uStack_8._0_1_ = 7;
  FUN_0054ef60(&param_5);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  (*pcVar2)(param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar4 = in_stack_00000024 + 1;
    uVar5 = param_5;
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(param_5 - 4);
      uVar4 = in_stack_00000024 + 0x24;
      if (0x1f < (param_5 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (0xf < in_stack_00000040) {
    uVar4 = in_stack_00000040 + 1;
    uVar5 = in_stack_0000002c;
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(in_stack_0000002c - 4);
      uVar4 = in_stack_00000040 + 0x24;
      if (0x1f < (in_stack_0000002c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  in_stack_0000003c = 0;
  in_stack_00000040 = 0xf;
  in_stack_0000002c = in_stack_0000002c & 0xffffff00;
  if (0xf < in_stack_00000058) {
    uVar4 = in_stack_00000058 + 1;
    uVar5 = in_stack_00000044;
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(in_stack_00000044 - 4);
      uVar4 = in_stack_00000058 + 0x24;
      if (0x1f < (in_stack_00000044 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  in_stack_00000054 = 0;
  in_stack_00000058 = 0xf;
  in_stack_00000044 = in_stack_00000044 & 0xffffff00;
  if (0xf < in_stack_00000070) {
    uVar5 = in_stack_00000070 + 1;
    iVar3 = in_stack_0000005c;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(in_stack_0000005c + -4);
      uVar5 = in_stack_00000070 + 0x24;
      if (0x1f < (in_stack_0000005c - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21322 ; VA 0x00a75310 ; FUN_00a75310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a75310(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2e90;
  pvStack_10 = ExceptionList;
  if (DAT_01eeaa58 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeac70) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eeac70);
      if (DAT_01eeac70 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_01931fd4,1,uStack_20,0,0,9,0,0);
        _DAT_01eeac68 = RBX::Creator<class_RBX::ChatService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eeaa60,&DAT_01eeac68);
        FUN_016f3654(FUN_0188ac40);
        FUN_016f37bf(&DAT_01eeac70);
      }
    }
    DAT_01eeaa58 = &DAT_01eeaa60;
  }
  ExceptionList = pvStack_10;
  return DAT_01eeaa58;
}



/* FUNCTION 21323 ; VA 0x00a75410 ; FUN_00a75410 */

void FUN_00a75410(void)

{
  int iVar1;
  
  if (DAT_01eeac74 == 0) {
    iVar1 = FUN_00a75310();
    DAT_01eeac74 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 21324 ; VA 0x00a75430 ; FUN_00a75430 */

int FUN_00a75430(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00a7eca0(param_1,param_2);
  *(undefined4 *)(iVar4 + 0x18) = 0;
  *(undefined4 *)(iVar4 + 0x1c) = 0;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *(undefined4 *)(iVar4 + 8) = *param_3;
  *(undefined4 *)(iVar4 + 0xc) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar2;
  *(undefined4 *)(iVar4 + 0x14) = uVar3;
  *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  *(undefined4 *)(iVar4 + 0x20) = param_3[6];
  *(undefined4 *)(iVar4 + 0x24) = param_3[7];
  *(undefined4 *)(iVar4 + 0x28) = param_3[8];
  FUN_00a7bf40(param_3 + 10);
  return iVar4;
}



/* FUNCTION 21325 ; VA 0x00a754a0 ; FUN_00a754a0 */

int __thiscall FUN_00a754a0(int *param_1,int param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint *puVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2ea0;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar4 = param_1[1] - iVar5 >> 5;
  if (iVar4 != 0x7ffffff) {
    uVar1 = iVar4 + 1;
    uVar7 = param_1[2] - iVar5 >> 5;
    uVar8 = uVar1;
    if (uVar7 <= 0x7ffffff - (uVar7 >> 1)) {
      uVar8 = (uVar7 >> 1) + uVar7;
      if (uVar8 < uVar1) {
        uVar8 = uVar1;
      }
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00577f40(uVar8);
    uStack_8 = 0;
    iVar5 = (param_2 - iVar5 >> 5) * 0x20;
    puVar6 = (uint *)(iVar5 + iVar4);
    *puVar6 = 0;
    uVar7 = *param_3;
    if (uVar7 != 0) {
      *puVar6 = uVar7;
      if ((uVar7 & 1) == 0) {
        (**(code **)(uVar7 & 0xfffffffe))(param_3 + 2,puVar6 + 2,0);
      }
      else {
        uVar7 = param_3[3];
        uVar2 = param_3[4];
        uVar3 = param_3[5];
        puVar6[2] = param_3[2];
        puVar6[3] = uVar7;
        puVar6[4] = uVar2;
        puVar6[5] = uVar3;
        *(undefined8 *)(puVar6 + 6) = *(undefined8 *)(param_3 + 6);
      }
    }
    if (param_2 == param_1[1]) {
      FUN_00a7ee30(*param_1,param_1[1],iVar4);
    }
    else {
      FUN_00a7eda0(*param_1,param_2,iVar4);
      FUN_00a7eda0(param_2,param_1[1],puVar6 + 8);
    }
    uStack_8 = 0xffffffff;
    FUN_006d3d20(iVar4,uVar1,uVar8);
    ExceptionList = pvStack_10;
    return *param_1 + iVar5;
  }
  ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 21326 ; VA 0x00a755ea ; Catch_All@00a755ea */

void Catch_All_00a755ea(void)

{
  int unaff_EBP;
  
  FUN_006d3e10(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x24));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x28));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21327 ; VA 0x00a75620 ; FUN_00a75620 */

undefined FUN_00a75620(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,
                      undefined4 param_9,undefined4 *param_10)

{
  char cVar1;
  undefined4 uVar2;
  undefined uVar3;
  uint auStack_64 [2];
  undefined auStack_5c [32];
  uint auStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2ed7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  auStack_3c[0] = 0;
  uStack_14 = param_1;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    auStack_3c[0] = param_1;
    if ((param_1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_1 & 0xfffffffe))(&param_3,&uStack_34,0);
    }
    else {
      uStack_34 = param_3;
      uStack_30 = param_4;
      uStack_2c = param_5;
      uStack_28 = param_6;
      uStack_24 = param_7;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_14 = param_1;
  uStack_1c = param_8;
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_3c);
  if (cVar1 == '\0') {
    FUN_00a78670(auStack_3c);
    uStack_8._0_1_ = 2;
    uStack_14 = FUN_01674e20(0x28);
    uStack_8._0_1_ = 3;
    if (uStack_14 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_00a78670(auStack_64);
    }
    *param_10 = uVar2;
    uStack_8._0_1_ = 4;
    if (auStack_64[0] != 0) {
      if (((auStack_64[0] & 1) == 0) && (*(code **)(auStack_64[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_64[0] & 0xfffffffe))(auStack_5c,auStack_5c,2);
      }
      auStack_64[0] = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (auStack_3c[0] != 0) {
      if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
      }
      auStack_3c[0] = 0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (auStack_3c[0] != 0) {
      if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
        uStack_14 = param_1;
      }
      auStack_3c[0] = 0;
    }
    uVar3 = 0;
    param_1 = uStack_14;
  }
  uStack_8 = 7;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    param_10._3_1_ = uVar3;
    (**(code **)(param_1 & 0xfffffffe))(&param_3,&param_3,2);
    ExceptionList = pvStack_10;
    return param_10._3_1_;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 21328 ; VA 0x00a757d0 ; FUN_00a757d0 */

undefined FUN_00a757d0(undefined4 param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  uint in_stack_00000034;
  int *in_stack_00000054;
  undefined auStack_ac [40];
  uint uStack_84;
  undefined auStack_7c [24];
  undefined4 auStack_64 [2];
  undefined auStack_5c [40];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2f1a;
  pvStack_10 = ExceptionList;
  auStack_64[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a786e0(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(auStack_64);
  uVar1 = auStack_64[0];
  if (cVar2 == '\0') {
    FUN_00a786e0(auStack_5c);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_00a786e0(auStack_ac);
    }
    *in_stack_00000054 = (int)puVar3;
    uStack_8._0_1_ = 4;
    if (uStack_84 != 0) {
      if (((uStack_84 & 1) == 0) && (*(code **)(uStack_84 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_84 & 0xfffffffe))(auStack_7c,auStack_7c,2);
      }
      uStack_84 = 0;
    }
    FUN_00a7c840();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00a7c840();
    uVar4 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00a7c840();
    uVar4 = 0;
  }
  uStack_8 = 7;
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000034 & 0xfffffffe))(&stack0x0000003c,&stack0x0000003c,2);
    }
    in_stack_00000034 = 0;
  }
  FUN_00a7c840();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 21329 ; VA 0x00a75960 ; FUN_00a75960 */

undefined FUN_00a75960(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined uVar5;
  uint in_stack_00000044;
  int *in_stack_00000064;
  undefined auStack_cc [56];
  uint uStack_94;
  undefined auStack_8c [24];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined auStack_6c [56];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2f5a;
  pvStack_10 = ExceptionList;
  uStack_74 = param_1;
  uStack_70 = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a79230(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(&uStack_74);
  uVar2 = uStack_70;
  uVar1 = uStack_74;
  if (cVar3 == '\0') {
    FUN_00a79230(auStack_6c);
    uStack_8._0_1_ = 2;
    puVar4 = (undefined4 *)FUN_01674e20(0x60);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[1] = uVar2;
      FUN_00a79230(auStack_cc);
    }
    *in_stack_00000064 = (int)puVar4;
    uStack_8._0_1_ = 4;
    if (uStack_94 != 0) {
      if (((uStack_94 & 1) == 0) && (*(code **)(uStack_94 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_94 & 0xfffffffe))(auStack_8c,auStack_8c,2);
      }
      uStack_94 = 0;
    }
    FUN_00a7cb80();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00a7cb80();
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00a7cb80();
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (in_stack_00000044 != 0) {
    if (((in_stack_00000044 & 1) == 0) &&
       (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000044 & 0xfffffffe))(&stack0x0000004c,&stack0x0000004c,2);
    }
    in_stack_00000044 = 0;
  }
  FUN_00a7cb80();
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 21330 ; VA 0x00a75b20 ; FUN_00a75b20 */

uint * FUN_00a75b20(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,
                   uint param_6,uint param_7,undefined8 param_8,uint param_9)

{
  uint uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2f80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_2c,0);
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  if (uStack_34 != 0) {
    *param_1 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_2c;
      param_1[3] = uStack_28;
      param_1[4] = uStack_24;
      param_1[5] = uStack_20;
      *(undefined8 *)(param_1 + 6) = uStack_1c;
    }
  }
  param_1[8] = param_9;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
  }
  uStack_8 = 3;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21331 ; VA 0x00a75c40 ; FUN_00a75c40 */

undefined4 *
FUN_00a75c40(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined *param_18,undefined8 param_19)

{
  int iVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint auStack_a8 [2];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 *puStack_94;
  ulonglong uStack_90;
  uint auStack_88 [2];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  undefined8 uStack_70;
  uint uStack_38;
  undefined auStack_30 [24];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2fb8;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_88;
  puStack_18 = (undefined *)auStack_88;
  uStack_8 = 2;
  auStack_88[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_88;
  if (param_13 != 0) {
    auStack_88[0] = param_13;
    if ((param_13 & 1) == 0) {
      uStack_90 = ZEXT48(&uStack_80);
      puStack_94 = &param_15;
      uStack_98 = 0xa75ca8;
      ExceptionList = &pvStack_10;
      (**(code **)(param_13 & 0xfffffffe))();
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_80 = param_15;
      uStack_7c = param_16;
      uStack_78 = param_17;
      puStack_74 = (undefined4 *)param_18;
      uStack_70 = param_19;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_88;
    }
  }
  puStack_14 = (undefined *)puVar2;
  puStack_18 = (undefined *)auStack_a8;
  uStack_8._0_1_ = 3;
  auStack_a8[0] = 0;
  puVar2 = auStack_a8;
  if (param_6 != 0) {
    auStack_a8[0] = param_6;
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_a0,0);
      puVar2 = (uint *)puStack_18;
    }
    else {
      uStack_a0 = param_8;
      uStack_9c = param_9;
      uStack_98 = param_10;
      puStack_94 = param_11;
      uStack_90 = param_12;
      puVar2 = auStack_a8;
    }
  }
  puStack_18 = (undefined *)puVar2;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  uVar3 = FUN_00a78780(param_3,param_4,param_5);
  uStack_8._0_1_ = 4;
  *param_1 = param_2;
  uStack_70 = CONCAT44(uVar3,0xa75d3f);
  FUN_00a786e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    puStack_74 = (undefined4 *)auStack_30;
    uStack_70 = CONCAT44(2,puStack_74);
    uStack_78 = 0xa75d60;
    (**(code **)(uStack_38 & 0xfffffffe))();
  }
  uStack_70 = CONCAT44(0xa75d72,(undefined4)uStack_70);
  FUN_00a7c840();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar1 = param_5[1] + -1;
    param_5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_70 = CONCAT44(0xa75d89,(undefined4)uStack_70);
      (**(code **)*param_5)();
      LOCK();
      iVar1 = param_5[2] + -1;
      param_5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_70 = CONCAT44(0xa75d9a,(undefined4)uStack_70);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_74 = &param_8;
    uStack_70 = CONCAT44(2,puStack_74);
    uStack_78 = 0xa75dbb;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_74 = &param_15;
    uStack_70 = CONCAT44(2,puStack_74);
    uStack_78 = 0xa75de9;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21332 ; VA 0x00a75e00 ; FUN_00a75e00 */

undefined4 *
FUN_00a75e00(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,uint param_7)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  undefined4 in_stack_00000034;
  int *in_stack_00000038;
  undefined4 in_stack_0000003c;
  int *in_stack_00000040;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  uint in_stack_00000064;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 in_stack_00000074;
  undefined4 in_stack_00000078;
  undefined8 in_stack_0000007c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e302b;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000064 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000064 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000064 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 6;
  if ((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) {
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  if (in_stack_00000040 != (int *)0x0) {
    LOCK();
    in_stack_00000040[1] = in_stack_00000040[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    in_stack_00000038[1] = in_stack_00000038[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 9;
  FUN_0054ef60(&param_7);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 5;
  FUN_00a79780(param_4,param_5,param_6);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  *param_1 = param_2;
  param_1[1] = param_3;
  FUN_00a7b940();
  FUN_00a7cd80();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_00000030) {
    if ((0xfff < in_stack_00000030 + 1) && (0x1f < (param_7 - *(int *)(param_7 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000038;
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  param_7 = param_7 & 0xffffff00;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000038[1] + -1;
    in_stack_00000038[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000038)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000040;
  if (in_stack_00000040 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000040[1] + -1;
    in_stack_00000040[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000040)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (in_stack_00000044 != 0) {
    if (((in_stack_00000044 & 1) == 0) &&
       (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
    }
    in_stack_00000044 = 0;
  }
  uStack_8 = 0xc;
  if (((in_stack_00000064 != 0) && ((in_stack_00000064 & 1) == 0)) &&
     (*(code **)(in_stack_00000064 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000064 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21333 ; VA 0x00a760b0 ; FUN_00a760b0 */

undefined4 *
FUN_00a760b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7,int *param_8,undefined4 param_9,
            int *param_10,int param_11)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000040;
  undefined4 in_stack_00000044;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3070;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_11);
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  iVar2 = FUN_00a790b0(param_4,param_5,param_6,param_7,param_8,param_9,param_10);
  *param_1 = param_2;
  param_1[1] = param_3;
  FUN_00a7a380();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0054ef60();
  param_1[0xe] = *(undefined4 *)(iVar2 + 0x30);
  FUN_00a7cb00();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000040) {
    if (0xfff < in_stack_00000040 + 1) {
      if (0x1f < (param_11 - *(int *)(param_11 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21334 ; VA 0x00a76270 ; FUN_00a76270 */

undefined4 *
FUN_00a76270(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7,int *param_8,undefined4 param_9,
            int *param_10,uint param_11,undefined4 param_12,undefined4 param_13,undefined4 param_14,
            undefined4 param_15,undefined4 *param_16,ulonglong param_17,uint param_18,
            undefined4 param_19,undefined4 param_20,undefined4 param_21,undefined4 param_22,
            undefined *param_23,undefined8 param_24)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uVar4;
  uint auStack_b8 [2];
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 *puStack_a4;
  ulonglong uStack_a0;
  uint auStack_98 [2];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 *puStack_84;
  undefined8 uStack_80;
  uint uStack_38;
  undefined auStack_30 [24];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e30b8;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_98;
  puStack_18 = (undefined *)auStack_98;
  uStack_8 = 4;
  auStack_98[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_98;
  if (param_18 != 0) {
    auStack_98[0] = param_18;
    if ((param_18 & 1) == 0) {
      uStack_a0 = ZEXT48(&uStack_90);
      puStack_a4 = &param_20;
      uStack_a8 = 0xa762d8;
      ExceptionList = &pvStack_10;
      (**(code **)(param_18 & 0xfffffffe))();
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_90 = param_20;
      uStack_8c = param_21;
      uStack_88 = param_22;
      puStack_84 = (undefined4 *)param_23;
      uStack_80 = param_24;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_98;
    }
  }
  puStack_14 = (undefined *)puVar3;
  puStack_18 = (undefined *)auStack_b8;
  uStack_8._0_1_ = 5;
  auStack_b8[0] = 0;
  puVar3 = auStack_b8;
  if (param_11 != 0) {
    auStack_b8[0] = param_11;
    if ((param_11 & 1) == 0) {
      (**(code **)(param_11 & 0xfffffffe))(&param_13,&uStack_b0,0);
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_b0 = param_13;
      uStack_ac = param_14;
      uStack_a8 = param_15;
      puStack_a4 = param_16;
      uStack_a0 = param_17;
      puVar3 = auStack_b8;
    }
  }
  puStack_18 = (undefined *)puVar3;
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  uVar4 = FUN_00a79310(param_4,param_5,param_6,param_7,param_8,param_9,param_10);
  uStack_8._0_1_ = 6;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_80 = CONCAT44(uVar4,0xa763c5);
  FUN_00a79230();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    puStack_84 = (undefined4 *)auStack_30;
    uStack_80 = CONCAT44(2,puStack_84);
    uStack_88 = 0xa763e6;
    (**(code **)(uStack_38 & 0xfffffffe))();
  }
  uStack_80 = CONCAT44(0xa763f8,(undefined4)uStack_80);
  FUN_00a7cb80();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_80 = CONCAT44(0xa76411,(undefined4)uStack_80);
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_80 = CONCAT44(0xa76421,(undefined4)uStack_80);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_80 = CONCAT44(0xa76437,(undefined4)uStack_80);
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_80 = CONCAT44(0xa76447,(undefined4)uStack_80);
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_80 = CONCAT44(0xa7645d,(undefined4)uStack_80);
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_80 = CONCAT44(0xa7646c,(undefined4)uStack_80);
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_84 = &param_13;
    uStack_80 = CONCAT44(2,puStack_84);
    uStack_88 = 0xa7648d;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  uStack_8 = 9;
  if (((param_18 != 0) && ((param_18 & 1) == 0)) &&
     (*(code **)(param_18 & 0xfffffffe) != (code *)0x0)) {
    puStack_84 = &param_20;
    uStack_80 = CONCAT44(2,puStack_84);
    uStack_88 = 0xa764bb;
    (**(code **)(param_18 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21335 ; VA 0x00a764e0 ; FUN_00a764e0 */

undefined4 *
FUN_00a764e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7,int *param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 *param_14,ulonglong param_15,uint param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined4 param_20,undefined4 param_21,
            undefined8 param_22)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  ulonglong uStack_98;
  uint uStack_90;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 *puStack_7c;
  undefined8 uStack_78;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3100;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_90 = 0;
  ExceptionList = &pvStack_10;
  if (param_16 != 0) {
    uStack_90 = param_16;
    if ((param_16 & 1) == 0) {
      uStack_98 = ZEXT48(&uStack_88);
      puStack_9c = &param_18;
      uStack_a0 = 0xa76548;
      ExceptionList = &pvStack_10;
      (**(code **)(param_16 & 0xfffffffe))();
    }
    else {
      uStack_88 = param_18;
      uStack_84 = param_19;
      uStack_80 = param_20;
      puStack_7c = (undefined4 *)param_21;
      uStack_78 = param_22;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 4;
  if (param_9 != 0) {
    if ((param_9 & 1) == 0) {
      (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_a8,0);
    }
    else {
      uStack_a8 = param_11;
      uStack_a4 = param_12;
      uStack_a0 = param_13;
      puStack_9c = param_14;
      uStack_98 = param_15;
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  uVar3 = FUN_00a78ee0(param_4,param_5,param_6,param_7,param_8);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_78 = CONCAT44(uVar3,0xa7660d);
  FUN_00a78dc0();
  uStack_78 = CONCAT44(0xa76615,(undefined4)uStack_78);
  FUN_00a7cc10();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_78 = CONCAT44(0xa7662e,(undefined4)uStack_78);
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_78 = CONCAT44(0xa7663e,(undefined4)uStack_78);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_78 = CONCAT44(0xa76654,(undefined4)uStack_78);
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_78 = CONCAT44(0xa76663,(undefined4)uStack_78);
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_7c = &param_11;
    uStack_78 = CONCAT44(2,puStack_7c);
    uStack_80 = 0xa76684;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((param_16 != 0) && ((param_16 & 1) == 0)) &&
     (*(code **)(param_16 & 0xfffffffe) != (code *)0x0)) {
    puStack_7c = &param_18;
    uStack_78 = CONCAT44(2,puStack_7c);
    uStack_80 = 0xa766b2;
    (**(code **)(param_16 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21336 ; VA 0x00a766d0 ; FUN_00a766d0 */

undefined4 *
FUN_00a766d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            )

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_10;
  int *piStack_c;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piVar1 = param_5 + 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0060e560(param_4,param_5,param_6,param_7,param_8,param_9);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (piStack_c != (int *)0x0) {
    LOCK();
    piStack_c[1] = piStack_c[1] + 1;
    UNLOCK();
  }
  param_1[2] = uStack_10;
  param_1[3] = piStack_c;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21337 ; VA 0x00a76820 ; FUN_00a76820 */

undefined4 *
FUN_00a76820(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,uint param_7)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined8 in_stack_0000004c;
  undefined4 in_stack_00000054;
  int *in_stack_00000058;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e3148;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000058 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000058[1] = in_stack_00000058[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  uStack_7 = 0;
  if ((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) {
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  uStack_8 = 5;
  FUN_0054ef60(&param_7);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 3;
  FUN_00a78bf0(param_4,param_5,param_6);
  _uStack_8 = CONCAT31(uStack_7,6);
  *param_1 = param_2;
  param_1[1] = param_3;
  FUN_00a78b10();
  FUN_00a7ca10();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = 1;
  if (0xf < in_stack_00000030) {
    if ((0xfff < in_stack_00000030 + 1) && (0x1f < (param_7 - *(int *)(param_7 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  param_7 = param_7 & 0xffffff00;
  _uStack_8 = CONCAT31(uStack_7,7);
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000034 & 0xfffffffe))();
    }
    in_stack_00000034 = 0;
  }
  piVar3 = in_stack_00000058;
  if (in_stack_00000058 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000058[1] + -1;
    in_stack_00000058[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000058)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21338 ; VA 0x00a76a10 ; FUN_00a76a10 */

undefined4 *
FUN_00a76a10(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined param_6,undefined4 param_7,int *param_8,undefined4 param_9,
            int *param_10,int param_11)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 uStack_80;
  int *piStack_7c;
  undefined4 uStack_78;
  int *piStack_74;
  undefined4 uStack_60;
  int iStack_5c;
  undefined *puStack_58;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3188;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  puStack_58 = (undefined *)in_stack_00000044;
  piStack_74 = &param_11;
  uStack_78 = 0xa76a4d;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  uStack_78 = param_9;
  piStack_74 = param_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  uStack_80 = param_7;
  piStack_7c = param_8;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  puStack_58 = (undefined *)
               FUN_00a79600(param_4,param_5,CONCAT31((int3)((uint)&uStack_80 >> 8),param_6));
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *param_1 = param_2;
  param_1[1] = param_3;
  iStack_5c = 0xa76af0;
  FUN_00a79530();
  puStack_58 = (undefined *)0xa76af8;
  FUN_00a7cca0();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_58 = (undefined *)0xa76b11;
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_58 = (undefined *)0xa76b21;
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_58 = (undefined *)0xa76b37;
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_58 = (undefined *)0xa76b47;
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_58 = (undefined *)0xa76b5d;
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_58 = (undefined *)0xa76b6c;
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000040) {
    puStack_58 = (undefined *)(in_stack_00000040 + 1);
    iVar2 = param_11;
    if (0xfff < puStack_58) {
      iVar2 = *(int *)(param_11 + -4);
      puStack_58 = (undefined *)(in_stack_00000040 + 0x24);
      if (0x1f < (param_11 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = &UNK_00a76bb4;
        FUN_017167a3();
      }
    }
    uStack_60 = 0xa76b99;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21339 ; VA 0x00a76bc0 ; FUN_00a76bc0 */

undefined4 *
FUN_00a76bc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined8 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined8 uStack_100;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined uStack_f0;
  undefined uStack_ef;
  undefined4 uStack_b0;
  undefined4 *puStack_ac;
  undefined4 *puStack_a8;
  undefined4 uStack_a4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e31e1;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_f8 = param_13;
  uStack_f4 = param_14;
  uStack_f0 = (undefined)param_15;
  uStack_ef = (undefined)((uint)param_15 >> 8);
  uStack_100 = CONCAT44(&stack0x00000044,0xa76c1b);
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  uStack_100 = CONCAT44(&stack0x0000005c,0xa76c2b);
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  uStack_100 = CONCAT44(&stack0x00000074,0xa76c3b);
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_110,0);
    }
    else {
      uStack_110 = param_8;
      uStack_10c = param_9;
      uStack_108 = param_10;
      uStack_104 = param_11;
      uStack_100 = param_12;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  uStack_a4 = FUN_00a789a0(param_3,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  *param_1 = param_2;
  puStack_a8 = (undefined4 *)0xa76cd2;
  FUN_00a78900();
  uStack_a4 = 0xa76cda;
  FUN_0096d5e0();
  uStack_a4 = 0xa76ce5;
  FUN_00a7c840();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_a4 = 0xa76cfe;
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_a4 = 0xa76d0d;
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_ac = &param_8;
    uStack_a4 = 2;
    uStack_b0 = 0xa76d31;
    puStack_a8 = puStack_ac;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_a4 = 0xa76d43;
  FUN_0096d5e0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21340 ; VA 0x00a76d60 ; FUN_00a76d60 */

void __thiscall
FUN_00a76d60(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined4 *param_7,uint *param_8,uint *param_9)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b108;
  pvStack_10 = ExceptionList;
  param_2 = (code *)*param_1;
  uStack_40 = 0;
  uVar2 = *param_9;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_40 = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = param_9 + 2;
      uStack_50 = 0xa76dd0;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_9[2];
      uStack_34 = param_9[3];
      uStack_30 = param_9[4];
      uStack_2c = param_9[5];
      uStack_28 = *(undefined8 *)(param_9 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar2 = *param_8;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_8 + 2,&uStack_58,0);
    }
    else {
      uStack_58 = param_8[2];
      uStack_54 = param_8[3];
      uStack_50 = param_8[4];
      puStack_4c = (uint *)param_8[5];
      uStack_48 = *(ulonglong *)(param_8 + 6);
    }
  }
  if (param_7[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_7[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *param_7;
  uVar4 = param_7[1];
  if (param_6[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*param_2)(param_4,param_5,*param_6,param_6[1],uVar3,uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21341 ; VA 0x00a76ea0 ; FUN_00a76ea0 */

void __thiscall
FUN_00a76ea0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5,undefined4 *param_6,uint *param_7,uint *param_8)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b108;
  pvStack_10 = ExceptionList;
  param_2 = (code *)*param_1;
  uStack_40 = 0;
  uVar2 = *param_8;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_40 = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = param_8 + 2;
      uStack_50 = 0xa76f10;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_8[2];
      uStack_34 = param_8[3];
      uStack_30 = param_8[4];
      uStack_2c = param_8[5];
      uStack_28 = *(undefined8 *)(param_8 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar2 = *param_7;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_7 + 2,&uStack_58,0);
    }
    else {
      uStack_58 = param_7[2];
      uStack_54 = param_7[3];
      uStack_50 = param_7[4];
      puStack_4c = (uint *)param_7[5];
      uStack_48 = *(ulonglong *)(param_7 + 6);
    }
  }
  if (param_6[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *param_6;
  uVar4 = param_6[1];
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*param_2)(param_4,*param_5,param_5[1],uVar3,uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21342 ; VA 0x00a76fe0 ; FUN_00a76fe0 */

int * __fastcall FUN_00a76fe0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_00a8cc00();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00a7707b:
    thunk_FUN_00a8cc00();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_00a8cc00();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00a7707b;
    FUN_00a74690(&piStack_8);
    iVar3 = FUN_00a8cc00();
    *param_1 = iVar3;
    iVar2 = FUN_00a8cc00();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21343 ; VA 0x00a770b0 ; FUN_00a770b0 */

void FUN_00a770b0(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a7ed40();
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21344 ; VA 0x00a77130 ; FUN_00a77130 */

void FUN_00a77130(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00a7d100();
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 21345 ; VA 0x00a77190 ; FUN_00a77190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00a77190(byte *param_1,int *param_2,uint *param_3,undefined4 param_4,undefined4 *param_5)

{
  uint *puVar1;
  int *piVar2;
  byte bVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = (int)param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e31f8;
  pvStack_10 = ExceptionList;
  bVar3 = *param_1;
  ExceptionList = &pvStack_10;
  uVar7 = FUN_005702d0(param_3);
  FUN_00562fc0(&param_3,uVar7,iVar6,
               -(uint)(param_1 + bVar3 + 1 != (byte *)0x0) & (uint)(param_1 + bVar3 + 1 + 1));
  if (param_3 == (uint *)0x0) {
    uStack_8 = 0;
    FUN_00a81820();
    FUN_0054ef60(param_4);
    _DAT_00000020 = *param_5;
    uRam00000024 = param_5[1];
    uRam00000028 = param_5[2];
    uRam0000002c = param_5[3];
    uRam00000030 = param_5[4];
    _DAT_00000034 = param_5[5];
    uRam00000038 = param_5[6];
    uRam0000003c = param_5[7];
    uRam00000040 = *(undefined8 *)(param_5 + 8);
    param_5[8] = 0;
    param_5[9] = 0xf;
    *(undefined *)(param_5 + 4) = 0;
    uRam00000048 = param_5[10];
    uRam0000004c = param_5[0xb];
    uRam00000050 = param_5[0xc];
    uRam00000054 = param_5[0xd];
    uRam00000058 = *(undefined8 *)(param_5 + 0xe);
    param_5[0xe] = 0;
    param_5[0xf] = 0xf;
    *(undefined *)(param_5 + 10) = 0;
    uRam00000060 = *(undefined *)(param_5 + 0x10);
    uRam00000061 = *(undefined *)((int)param_5 + 0x41);
    _DAT_00000064 = param_5[0x11];
    uRam00000068 = param_5[0x12];
    _DAT_0000006c = param_5[0x13];
    uRam00000070 = param_5[0x14];
    uRam00000074 = *(undefined8 *)(param_5 + 0x15);
    param_5[0x15] = 0;
    param_5[0x16] = 0xf;
    *(undefined *)(param_5 + 0x11) = 0;
    uRam0000007c = param_5[0x17];
    uRam00000080 = param_5[0x18];
    uRam00000084 = param_5[0x19];
    uRam00000088 = param_5[0x1a];
    uRam0000008c = *(undefined8 *)(param_5 + 0x1b);
    param_5[0x1b] = 0;
    param_5[0x1c] = 0xf;
    *(undefined *)(param_5 + 0x17) = 0;
    uRam00000094 = 0;
    uRam00000098 = param_5[0x1e];
    uRam0000009c = param_5[0x1f];
    _DAT_000000a0 = param_5[0x20];
    uRam000000a4 = param_5[0x21];
    uRam000000a8 = param_5[0x22];
    param_5[0x22] = 0;
    param_5[0x1f] = 0;
    param_5[0x21] = 0;
    uVar4 = *(uint *)(param_1 + 8);
    uVar8 = uVar4 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar8 = FUN_005d6bb0(uVar8);
      if (uVar8 <= *(uint *)(param_1 + 4)) {
        uVar8 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar8);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar8) {
      param_3 = (uint *)0x1;
      uVar9 = uVar4 >> 1;
      if ((uVar4 >> 1) + uVar4 <= uVar8) {
        uVar9 = 1;
      }
      uVar8 = FUN_005d6bb0(uVar9 + uVar4);
      puVar1 = (uint *)(param_1 + 4);
      if (uVar8 != *puVar1) {
        param_3 = puVar1;
        FUN_005d2b00(uVar8);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
        puVar5 = (undefined4 *)*puVar10;
        while (puVar5 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_3) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_3) * 4) == 0) {
            *piVar2 = (int)puVar10;
            puVar10 = puVar5;
          }
          else {
            *puVar10 = *puVar5;
            *puVar5 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar5;
          }
          puVar5 = (undefined4 *)*puVar10;
        }
      }
    }
    uVar8 = *(uint *)(param_1 + 4);
    iVar6 = *(int *)(param_1 + 0x14);
    puVar10 = (undefined4 *)(iVar6 + (uVar7 % uVar8) * 4);
    _DAT_00000004 = uVar7;
    if (*(int *)(iVar6 + (uVar7 % uVar8) * 4) == 0) {
      piVar2 = (int *)(iVar6 + uVar8 * 4);
      if (*piVar2 != 0) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % uVar8) * 4) = 0;
      }
      *puVar10 = piVar2;
      _DAT_00000000 = *piVar2;
      *piVar2 = 0;
    }
    else {
      _DAT_00000000 = *(int *)*puVar10;
      *(undefined4 *)*puVar10 = 0;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = 0;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined *)(param_2 + 1) = 0;
  *param_2 = (int)param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21346 ; VA 0x00a774a0 ; FUN_00a774a0 */

undefined4 * __thiscall FUN_00a774a0(byte *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3218;
  pvStack_10 = ExceptionList;
  uVar7 = param_3[1];
  if (((int)uVar7 < 1) && ((int)uVar7 < 0)) {
    uVar7 = ~uVar7;
  }
  uVar7 = (uVar7 >> 2) + uVar7 * 0x40 + *param_3 ^ uVar7;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_3,uVar7,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 == (int *)0x0) {
    uStack_8 = 0;
    piVar4 = (int *)FUN_01674e20(0x10);
    *piVar4 = 0;
    piVar4[1] = 0;
    piVar4[2] = 0;
    piVar4[3] = 0;
    piVar4[2] = *param_4;
    piVar4[3] = param_4[1];
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005c9310(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_3 = (int *)0x1;
      uVar8 = uVar1 >> 1;
      if ((uVar1 >> 1) + uVar1 <= uVar5) {
        uVar8 = 1;
      }
      iVar6 = FUN_005c9310(uVar8 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar3 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar3 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar3;
            *(undefined4 **)*piVar3 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar4[1] = uVar7;
    uVar7 = uVar7 % *(uint *)(param_1 + 4);
    piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar3 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar9 = piVar3;
      *piVar4 = *piVar3;
      *piVar3 = (int)piVar4;
    }
    else {
      *piVar4 = *piVar3;
      *(int **)*puVar9 = piVar4;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = piVar4;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_2;
  }
  *param_2 = param_3;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21347 ; VA 0x00a77690 ; FUN_00a77690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00a77690(byte *param_1,uint *param_2,uint param_3,int param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3238;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_005702d0(param_3);
  uVar8 = *(uint *)(iVar6 + 0x1c);
  param_3 = iVar4 + 0x9e3779b9;
  if (((int)uVar8 < 1) && ((int)uVar8 < 0)) {
    uVar8 = ~uVar8;
  }
  uVar8 = (uVar8 ^ (uVar8 >> 2) + uVar8 * 0x40 + *(int *)(iVar6 + 0x18)) + param_3 * 0x40 +
          (param_3 >> 2) + 0x9e3779b9 ^ param_3;
  FUN_00a77880(&param_3,uVar8,iVar6,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 == 0) {
    uStack_8 = 0;
    FUN_0094c530();
    iVar6 = param_4;
    FUN_0054ef60(param_4);
    _DAT_00000020 = *(undefined4 *)(iVar6 + 0x18);
    uRam00000024 = *(undefined4 *)(iVar6 + 0x1c);
    uRam00000028 = *(undefined4 *)(iVar6 + 0x20);
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      uVar7 = uVar1 >> 1;
      if (uVar7 + uVar1 <= uVar5) {
        uVar7 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar7 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar3 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar3 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar3;
            *(undefined4 **)*piVar3 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    param_3 = 0;
    uVar5 = uVar8 % *(uint *)(param_1 + 4);
    piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    _DAT_00000004 = uVar8;
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar3 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar9 = piVar3;
      _DAT_00000000 = *piVar3;
      *piVar3 = 0;
    }
    else {
      _DAT_00000000 = *piVar3;
      *(undefined4 *)*puVar9 = 0;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined *)(param_2 + 1) = 1;
  }
  else {
    *(undefined *)(param_2 + 1) = 0;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21348 ; VA 0x00a77880 ; FUN_00a77880 */

void __thiscall FUN_00a77880(int param_1,undefined4 *param_2,uint param_3,undefined4 *param_4)

{
  uint uVar1;
  char cVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  uVar1 = *(uint *)(param_1 + 4);
  uVar5 = param_3 % uVar1;
  if (*(int *)(param_1 + 8) == 0) {
    piVar6 = (int *)0x0;
  }
  else {
    puVar3 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    if (puVar3 == (undefined4 *)0x0) {
      piVar6 = (int *)0x0;
    }
    else {
      piVar6 = (int *)*puVar3;
    }
    if (piVar6 != (int *)0x0) {
      do {
        if (param_3 == piVar6[1]) {
          piVar4 = piVar6 + 2;
          if ((param_4[6] == piVar6[8]) && (param_4[7] == piVar6[9])) {
            if (0xf < (uint)piVar6[7]) {
              piVar4 = (int *)*piVar4;
            }
            puVar3 = param_4;
            if (0xf < (uint)param_4[5]) {
              puVar3 = (undefined4 *)*param_4;
            }
            cVar2 = FUN_0055c360(puVar3,param_4[4],piVar4,piVar6[6]);
            if (cVar2 != '\0') break;
          }
        }
        else if ((uint)piVar6[1] % uVar1 != uVar5) {
          *param_2 = 0;
          return;
        }
        piVar6 = (int *)*piVar6;
        if (piVar6 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar6;
  return;
}



/* FUNCTION 21349 ; VA 0x00a77940 ; thunk_FUN_00a8cc00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a8cc00(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5616;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eead5c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eead5c);
    if (DAT_01eead5c == -1) {
      uStack_8 = 0;
      FUN_009ca470("TextFilterContext");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeacf8 = RBX::Reflection::EnumDesc<enum_RBX::ChatService::TextFilterContext>::vftable;
      FUN_009caf20(&DAT_01d664e8,2);
      FUN_016f3654(&LAB_0188abe0);
      FUN_016f37bf(&DAT_01eead5c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeacf8;
}



/* FUNCTION 21350 ; VA 0x00a77950 ; FUN_00a77950 */

void __thiscall FUN_00a77950(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18,param_1);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple_const_>::vftable;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *param_2 = (int)(puVar1 + 3);
    param_2[1] = (int)puVar1;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 21351 ; VA 0x00a779b0 ; thunk_FUN_00a8caa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a8caa0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e55d6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeacf4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeacf4);
    if (DAT_01eeacf4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ChatCallbackType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeac90 = RBX::Reflection::EnumDesc<enum_RBX::ChatService::ChatCallbackType>::vftable;
      FUN_009caf20(&DAT_019459e0,4);
      FUN_016f3654(&LAB_0188aba0);
      FUN_016f37bf(&DAT_01eeacf4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeac90;
}



/* FUNCTION 21352 ; VA 0x00a779c0 ; thunk_FUN_00a8cb50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a8cb50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e55f6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeadc4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeadc4);
    if (DAT_01eeadc4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ChatColor");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eead60 = RBX::Reflection::EnumDesc<enum_RBX::ChatService::ChatColor>::vftable;
      FUN_009caf20(&DAT_01d664c8,4);
      FUN_016f3654(&LAB_0188abc0);
      FUN_016f37bf(&DAT_01eeadc4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eead60;
}



/* FUNCTION 21353 ; VA 0x00a779d0 ; FUN_00a779d0 */

void FUN_00a779d0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3270;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(*param_2 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088daf0();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar2 = *(int *)(*param_2 + 0x410);
  iVar3 = FUN_0088cb40();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8 = 0;
  iVar2 = *(int *)(*param_2 + 0x340);
  iVar3 = FUN_0088cb40();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8._0_1_ = 1;
  iVar2 = *(int *)(*param_2 + 0x270);
  iVar3 = FUN_0088cb40();
  if (iVar2 == iVar3) {
    FUN_0054ef60();
    iVar2 = *param_2;
    uStack_8._0_1_ = 2;
    iVar3 = *(int *)(iVar2 + 0xd0);
    iVar4 = FUN_0088cb40();
    if (iVar3 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    iVar3 = iVar2 + 0xd8;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      iVar3 = 0;
    }
    FUN_0054ef60(iVar3);
    param_2 = (int *)*param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar2 = *param_2;
    iVar3 = FUN_0088cdc0();
    if (iVar2 == iVar3) {
      piVar5 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar5 = (int *)0x0;
      }
      if (piVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar5[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_8 = 0xffffffff;
      FUN_00a87ed0(param_1,*piVar5,piVar5[1]);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 21354 ; VA 0x00a77bb0 ; FUN_00a77bb0 */

void FUN_00a77bb0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3298;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(*param_2 + 0x270);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8 = 0;
  iVar1 = *(int *)(*param_2 + 0x1a0);
  iVar2 = FUN_0088cb40();
  if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  iVar1 = *param_2;
  uStack_8._0_1_ = 1;
  iVar2 = *(int *)(iVar1 + 0xd0);
  iVar3 = FUN_0088cb40();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar2 = iVar1 + 0xd8;
  if (*(int *)(iVar1 + 0xd4) == 0) {
    iVar2 = 0;
  }
  FUN_0054ef60(iVar2);
  param_2 = (int *)*param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar1 = *param_2;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    piVar4 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar4 = (int *)0x0;
    }
    FUN_0054ef60(piVar4);
    uStack_8 = 0xffffffff;
    FUN_00a87a50(param_1);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21355 ; VA 0x00a77cf0 ; FUN_00a77cf0 */

void FUN_00a77cf0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e32c0;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(*param_2 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088cb40();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  iVar2 = *param_2;
  uStack_8 = 0;
  iVar3 = *(int *)(iVar2 + 0xd0);
  iVar4 = FUN_0088cdc0();
  if (iVar3 == iVar4) {
    iVar3 = iVar2 + 0xd8;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      iVar3 = 0;
    }
    if (*(int *)(iVar3 + 4) != 0) {
      LOCK();
      piVar5 = (int *)(*(int *)(iVar3 + 4) + 4);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    param_2 = (int *)*param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar2 = *param_2;
    iVar3 = FUN_0088cdc0();
    if (iVar2 == iVar3) {
      piVar5 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar5 = (int *)0x0;
      }
      if (piVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar5[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_8 = 0xffffffff;
      FUN_00a87c80(param_1,*piVar5,piVar5[1]);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 21356 ; VA 0x00a77e20 ; FUN_00a77e20 */

undefined4 FUN_00a77e20(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00a77f9d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00a77f9d;
  }
  iVar2 = FUN_00a8caa0();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00a77f48;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00a8caa0();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00a745f0(&param_3);
      iVar4 = FUN_00a8caa0();
      iStack_ec = iVar4;
      iVar5 = FUN_00a8caa0();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00a77f48:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00a8caa0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 21357 ; VA 0x00a78020 ; FUN_00a78020 */

undefined4 FUN_00a78020(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00a7819d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00a7819d;
  }
  iVar2 = FUN_00a8cb50();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00a78148;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00a8cb50();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00a74640(&param_3);
      iVar4 = FUN_00a8cb50();
      iStack_ec = iVar4;
      iVar5 = FUN_00a8cb50();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00a78148:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00a8cb50();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 21358 ; VA 0x00a78220 ; FUN_00a78220 */

undefined4 * __thiscall FUN_00a78220(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e32e3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 4);
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
    }
    else {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
    }
  }
  *(undefined *)(param_1 + 0x14) = *(undefined *)(param_2 + 0x14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21359 ; VA 0x00a78300 ; FUN_00a78300 */

undefined4 * __thiscall
FUN_00a78300(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3319;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a75310();
  FUN_009cb790(uVar1,param_4,param_9,param_10,param_11);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::ChatService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::ChatService::ChatColor),3>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_8;
  }
  param_1[0x12] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00a81d50(param_5,param_6,param_7);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21360 ; VA 0x00a783c0 ; FUN_00a783c0 */

undefined4 * __fastcall FUN_00a783c0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("TextFilterContext");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ChatService::TextFilterContext>::vftable;
  FUN_009caf20(&DAT_01d664e8,2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21361 ; VA 0x00a78420 ; FUN_00a78420 */

undefined4 * __thiscall
FUN_00a78420(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined8 param_11,undefined4 param_12)

{
  undefined4 uVar1;
  undefined auStack_530 [1296];
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3388;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00a75310();
  FUN_009cb970(uVar1,param_3,param_10,param_11,param_12);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ChatService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::ChatService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(param_6);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(param_7);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  FUN_0086e3d0(param_8);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 5;
  FUN_0086e3d0(param_9);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 6;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_530,&puStack_20,param_10);
  iStack_8._0_1_ = 7;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 8;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_530,0xd8,6,FUN_00688b10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21362 ; VA 0x00a78600 ; FUN_00a78600 */

undefined4 * __fastcall FUN_00a78600(undefined4 *param_1)

{
  undefined4 uVar1;
  
  *param_1 = RBX::
             LRUCache<struct_RBX::ChatService::MessageAndSenderId,struct_RBX::TextFilterResult,struct_boost::hash<struct_RBX::ChatService::MessageAndSenderId>_>
             ::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_00a7eca0(0,0);
  param_1[1] = uVar1;
  *(undefined *)(param_1 + 3) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[4] = uVar1;
  param_1[5] = 0;
  param_1[6] = 0x3f800000;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  return param_1;
}



/* FUNCTION 21363 ; VA 0x00a78670 ; FUN_00a78670 */

uint * __thiscall FUN_00a78670(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
      param_1[8] = param_2[8];
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
  }
  param_1[8] = param_2[8];
  return param_1;
}



/* FUNCTION 21364 ; VA 0x00a786e0 ; FUN_00a786e0 */

int __thiscall FUN_00a786e0(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e33a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a79a10(param_2);
  *(undefined4 *)(param_1 + 0x28) = 0;
  uVar1 = *(uint *)(param_2 + 0x28);
  uStack_8 = 0;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x28) = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = *(undefined4 *)(param_2 + 0x34);
      uVar3 = *(undefined4 *)(param_2 + 0x38);
      uVar4 = *(undefined4 *)(param_2 + 0x3c);
      *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_2 + 0x30);
      *(undefined4 *)(param_1 + 0x34) = uVar2;
      *(undefined4 *)(param_1 + 0x38) = uVar3;
      *(undefined4 *)(param_1 + 0x3c) = uVar4;
      *(undefined8 *)(param_1 + 0x40) = *(undefined8 *)(param_2 + 0x40);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x30,param_1 + 0x30,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21365 ; VA 0x00a78780 ; FUN_00a78780 */

undefined4 __thiscall
FUN_00a78780(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18)

{
  int iVar1;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e33e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    uStack_40 = param_12;
    if ((param_12 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_14;
      uStack_50 = 0xa787ed;
      ExceptionList = &pvStack_10;
      (**(code **)(param_12 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_14;
      uStack_34 = param_15;
      uStack_30 = param_16;
      puStack_2c = (undefined4 *)param_17;
      uStack_28 = param_18;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_58,0);
    }
    else {
      uStack_58 = param_7;
      uStack_54 = param_8;
      uStack_50 = param_9;
      puStack_4c = param_10;
      uStack_48 = param_11;
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00a79de0(param_2,param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_28 = CONCAT44(0xa78885,(undefined4)uStack_28);
      (**(code **)*param_4)();
      LOCK();
      iVar1 = param_4[2] + -1;
      param_4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_28 = CONCAT44(0xa78896,(undefined4)uStack_28);
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_7;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xa788b7;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_14;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xa788e5;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21366 ; VA 0x00a78900 ; FUN_00a78900 */

int __thiscall FUN_00a78900(int param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e340e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a79a10(param_2);
  *(undefined4 *)(param_1 + 0x28) = *(undefined4 *)(param_2 + 0x28);
  *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_2 + 0x2c);
  *(undefined *)(param_1 + 0x30) = *(undefined *)(param_2 + 0x30);
  *(undefined *)(param_1 + 0x31) = *(undefined *)(param_2 + 0x31);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x34);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2 + 0x4c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_2 + 100);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21367 ; VA 0x00a789a0 ; FUN_00a789a0 */

undefined4 __thiscall
FUN_00a789a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined uStack_74;
  undefined uStack_73;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3456;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_7c = param_12;
  uStack_78 = param_13;
  uStack_74 = (undefined)param_14;
  uStack_73 = (undefined)((uint)param_14 >> 8);
  uStack_84 = CONCAT44(&stack0x0000003c,0xa789fd);
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  uStack_84 = CONCAT44(&stack0x00000054,0xa78a0d);
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  uStack_84 = CONCAT44(&stack0x0000006c,0xa78a1d);
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_94,0);
    }
    else {
      uStack_94 = param_7;
      uStack_90 = param_8;
      uStack_8c = param_9;
      uStack_88 = param_10;
      uStack_84 = param_11;
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00a79f60(param_2,param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = 0xa78ab4;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = 0xa78ac3;
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_30 = &param_7;
    uStack_28 = 2;
    uStack_34 = 0xa78ae7;
    puStack_2c = puStack_30;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_28 = 0xa78af9;
  FUN_0096d5e0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21368 ; VA 0x00a78b10 ; FUN_00a78b10 */

undefined4 * __thiscall FUN_00a78b10(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3470;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  param_1[8] = 0;
  uVar2 = param_2[8];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[8] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
    }
    else {
      uVar3 = param_2[0xb];
      uVar4 = param_2[0xc];
      uVar5 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar3;
      param_1[0xc] = uVar4;
      param_1[0xd] = uVar5;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
    }
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  if (param_2[0x11] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x11] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21369 ; VA 0x00a78bf0 ; FUN_00a78bf0 */

undefined4 __thiscall
FUN_00a78bf0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  undefined4 in_stack_00000048;
  int *in_stack_0000004c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e34b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_0000004c != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_0000004c[1] = in_stack_0000004c[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  uStack_7 = 0;
  if ((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) {
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  uStack_8 = 5;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_00a7a830(param_2,param_3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = 1;
  if (0xf < in_stack_00000024) {
    if ((0xfff < in_stack_00000024 + 1) && (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  _uStack_8 = CONCAT31(uStack_7,6);
  if (in_stack_00000028 != 0) {
    if (((in_stack_00000028 & 1) == 0) &&
       (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000028 & 0xfffffffe))();
    }
    in_stack_00000028 = 0;
  }
  piVar3 = in_stack_0000004c;
  if (in_stack_0000004c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000004c[1] + -1;
    in_stack_0000004c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000004c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21370 ; VA 0x00a78dc0 ; FUN_00a78dc0 */

undefined4 * __thiscall FUN_00a78dc0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e34d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  uVar2 = param_2[4];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
    }
    else {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
    }
  }
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21371 ; VA 0x00a78ee0 ; FUN_00a78ee0 */

undefined4 __thiscall
FUN_00a78ee0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,int *param_6,uint param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 *param_12,ulonglong param_13,
            uint param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined8 param_20)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3508;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_14 != 0) {
    uStack_40 = param_14;
    if ((param_14 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_16;
      uStack_50 = 0xa78f4d;
      ExceptionList = &pvStack_10;
      (**(code **)(param_14 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_16;
      uStack_34 = param_17;
      uStack_30 = param_18;
      puStack_2c = (undefined4 *)param_19;
      uStack_28 = param_20;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 4;
  if (param_7 != 0) {
    if ((param_7 & 1) == 0) {
      (**(code **)(param_7 & 0xfffffffe))(&param_9,&uStack_58,0);
    }
    else {
      uStack_58 = param_9;
      uStack_54 = param_10;
      uStack_50 = param_11;
      puStack_4c = param_12;
      uStack_48 = param_13;
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00a7aec0(param_2,param_3,param_4,param_5,param_6);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xa7900d,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_28 = CONCAT44(0xa79020,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xa79037,(undefined4)uStack_28);
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0xa79049,(undefined4)uStack_28);
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_9;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xa7906a;
    (**(code **)(param_7 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_14 != 0) && ((param_14 & 1) == 0)) &&
     (*(code **)(param_14 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_16;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xa79098;
    (**(code **)(param_14 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21372 ; VA 0x00a790b0 ; FUN_00a790b0 */

undefined4 __thiscall
FUN_00a790b0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,int param_9)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000034;
  undefined4 in_stack_00000038;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3540;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_9);
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a7b420(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000034) {
    if (0xfff < in_stack_00000034 + 1) {
      if (0x1f < (param_9 - *(int *)(param_9 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21373 ; VA 0x00a79230 ; FUN_00a79230 */

int __thiscall FUN_00a79230(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3560;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a7a380(param_2);
  *(undefined4 *)(param_1 + 0x18) = 0;
  uVar1 = *(uint *)(param_2 + 0x18);
  uStack_8 = 0;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x18) = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x20,param_1 + 0x20,0);
    }
    else {
      uVar2 = *(undefined4 *)(param_2 + 0x24);
      uVar3 = *(undefined4 *)(param_2 + 0x28);
      uVar4 = *(undefined4 *)(param_2 + 0x2c);
      *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 0x20);
      *(undefined4 *)(param_1 + 0x24) = uVar2;
      *(undefined4 *)(param_1 + 0x28) = uVar3;
      *(undefined4 *)(param_1 + 0x2c) = uVar4;
      *(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_2 + 0x30);
    }
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  uVar1 = *(uint *)(param_2 + 0x38);
  uStack_8 = 1;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x38) = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = *(undefined4 *)(param_2 + 0x44);
      uVar3 = *(undefined4 *)(param_2 + 0x48);
      uVar4 = *(undefined4 *)(param_2 + 0x4c);
      *(undefined4 *)(param_1 + 0x40) = *(undefined4 *)(param_2 + 0x40);
      *(undefined4 *)(param_1 + 0x44) = uVar2;
      *(undefined4 *)(param_1 + 0x48) = uVar3;
      *(undefined4 *)(param_1 + 0x4c) = uVar4;
      *(undefined8 *)(param_1 + 0x50) = *(undefined8 *)(param_2 + 0x50);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x40,param_1 + 0x40,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21374 ; VA 0x00a79310 ; FUN_00a79310 */

undefined4 __thiscall
FUN_00a79310(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 *param_14,ulonglong param_15,uint param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined4 param_20,undefined4 param_21,
            undefined8 param_22)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  ulonglong uStack_4c;
  uint uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e35a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  uStack_44 = 0;
  ExceptionList = &pvStack_10;
  if (param_16 != 0) {
    uStack_44 = param_16;
    if ((param_16 & 1) == 0) {
      uStack_4c = ZEXT48(&uStack_3c);
      puStack_50 = &param_18;
      uStack_54 = 0xa7937d;
      ExceptionList = &pvStack_10;
      (**(code **)(param_16 & 0xfffffffe))();
    }
    else {
      uStack_3c = param_18;
      uStack_38 = param_19;
      uStack_34 = param_20;
      puStack_30 = (undefined4 *)param_21;
      uStack_2c = param_22;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 5;
  if (param_9 != 0) {
    if ((param_9 & 1) == 0) {
      (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_5c,0);
    }
    else {
      uStack_5c = param_11;
      uStack_58 = param_12;
      uStack_54 = param_13;
      puStack_50 = param_14;
      uStack_4c = param_15;
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00a7b5a0(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0xa79467,(undefined4)uStack_2c);
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_2c = CONCAT44(0xa79477,(undefined4)uStack_2c);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0xa7948d,(undefined4)uStack_2c);
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_2c = CONCAT44(0xa7949d,(undefined4)uStack_2c);
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0xa794b3,(undefined4)uStack_2c);
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_2c = CONCAT44(0xa794c2,(undefined4)uStack_2c);
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_30 = &param_11;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0xa794e3;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((param_16 != 0) && ((param_16 & 1) == 0)) &&
     (*(code **)(param_16 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &param_18;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0xa79511;
    (**(code **)(param_16 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21375 ; VA 0x00a79530 ; FUN_00a79530 */

undefined4 * __thiscall FUN_00a79530(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e35b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *(undefined *)(param_1 + 2) = *(undefined *)(param_2 + 2);
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = 0;
  param_1[6] = 0;
  if (param_2[6] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[6] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 7);
  param_1[0xd] = param_2[0xd];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21376 ; VA 0x00a79600 ; FUN_00a79600 */

undefined4 __thiscall
FUN_00a79600(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,int param_9)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000034;
  undefined4 in_stack_00000038;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3540;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_9);
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a7b7c0(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000034) {
    if (0xfff < in_stack_00000034 + 1) {
      if (0x1f < (param_9 - *(int *)(param_9 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21377 ; VA 0x00a79780 ; FUN_00a79780 */

undefined4 __thiscall
FUN_00a79780(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  uint in_stack_00000058;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined8 in_stack_00000070;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3620;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000058 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000058 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000058 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 6;
  if ((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) {
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 9;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00a7baa0(param_2,param_3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_00000024) {
    if ((0xfff < in_stack_00000024 + 1) && (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_0000002c;
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (in_stack_00000038 != 0) {
    if (((in_stack_00000038 & 1) == 0) &&
       (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    in_stack_00000038 = 0;
  }
  uStack_8 = 0xb;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000058 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21378 ; VA 0x00a79a10 ; FUN_00a79a10 */

undefined4 * __thiscall FUN_00a79a10(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017e3638;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21379 ; VA 0x00a79ac0 ; FUN_00a79ac0 */

undefined4 * __thiscall
FUN_00a79ac0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3668;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = param_3;
  param_1[1] = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar1 = param_4[2] + -1;
      param_4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  param_1[2] = 0;
  if (param_5 != 0) {
    param_1[2] = param_5;
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,param_1 + 4,0);
    }
    else {
      param_1[4] = param_7;
      param_1[5] = param_8;
      param_1[6] = param_9;
      param_1[7] = param_10;
      *(undefined8 *)(param_1 + 8) = param_11;
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar1 = param_4[2] + -1;
      param_4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = 3;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_5 & 0xfffffffe))(&param_7,&param_7,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21380 ; VA 0x00a79be0 ; FUN_00a79be0 */

undefined4 __thiscall
FUN_00a79be0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000024;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3698;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar3 = in_stack_00000024 + 1;
    iVar2 = param_5;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_5 + -4);
      uVar3 = in_stack_00000024 + 0x24;
      if (0x1f < (param_5 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21381 ; VA 0x00a79cf0 ; FUN_00a79cf0 */

int __thiscall
FUN_00a79cf0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            int *param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 8) = param_5;
  *(int **)(param_1 + 0xc) = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21382 ; VA 0x00a79de0 ; FUN_00a79de0 */

int __thiscall
FUN_00a79de0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18)

{
  int iVar1;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e36d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_38,0);
    }
    else {
      uStack_38 = param_7;
      uStack_34 = param_8;
      uStack_30 = param_9;
      puStack_2c = param_10;
      uStack_28 = param_11;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  FUN_00a79ac0(param_2,param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (param_12 != 0) {
    *(uint *)(param_1 + 0x28) = param_12;
    if ((param_12 & 1) == 0) {
      uStack_28 = (ulonglong)(param_1 + 0x30);
      puStack_2c = &param_14;
      uStack_30 = 0xa79ebd;
      (**(code **)(param_12 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x30) = param_14;
      *(undefined4 *)(param_1 + 0x34) = param_15;
      *(undefined4 *)(param_1 + 0x38) = param_16;
      *(undefined4 *)(param_1 + 0x3c) = param_17;
      *(undefined8 *)(param_1 + 0x40) = param_18;
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_28 = CONCAT44(0xa79eda,(undefined4)uStack_28);
      (**(code **)*param_4)();
      LOCK();
      iVar1 = param_4[2] + -1;
      param_4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_28 = CONCAT44(0xa79eeb,(undefined4)uStack_28);
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_7;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xa79f10;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_14;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xa79f3e;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21383 ; VA 0x00a79f60 ; FUN_00a79f60 */

int __thiscall
FUN_00a79f60(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 *param_10,undefined8 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3716;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_38,0);
    }
    else {
      uStack_38 = param_7;
      uStack_34 = param_8;
      uStack_30 = param_9;
      puStack_2c = param_10;
      uStack_28 = param_11;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  FUN_00a79ac0(param_2,param_3,param_4);
  *(undefined4 *)(param_1 + 0x28) = param_12;
  *(undefined4 *)(param_1 + 0x2c) = param_13;
  *(undefined *)(param_1 + 0x30) = (undefined)param_14;
  *(undefined *)(param_1 + 0x31) = param_14._1_1_;
  uStack_8._0_1_ = 3;
  uStack_28 = CONCAT44(&stack0x0000003c,0xa7a02c);
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  uStack_28 = CONCAT44(&stack0x00000054,0xa7a03c);
  FUN_0054ef60();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uStack_28 = CONCAT44(&stack0x0000006c,0xa7a04c);
  FUN_0054ef60();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xa7a065,(undefined4)uStack_28);
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0xa7a074,(undefined4)uStack_28);
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      puStack_2c = &param_7;
      uStack_28 = CONCAT44(2,puStack_2c);
      uStack_30 = 0xa7a098;
      (**(code **)(param_5 & 0xfffffffe))();
    }
  }
  uStack_28 = CONCAT44(0xa7a0aa,(undefined4)uStack_28);
  FUN_0096d5e0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21384 ; VA 0x00a7a0c0 ; FUN_00a7a0c0 */

int __thiscall
FUN_00a7a0c0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int iVar1;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017e3740;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a79be0(param_2,param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x20) = 0;
  if (in_stack_00000028 != 0) {
    *(uint *)(param_1 + 0x20) = in_stack_00000028;
    if ((in_stack_00000028 & 1) == 0) {
      (**(code **)(in_stack_00000028 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x28) = in_stack_00000030;
      *(undefined4 *)(param_1 + 0x2c) = in_stack_00000034;
      *(undefined4 *)(param_1 + 0x30) = in_stack_00000038;
      *(undefined4 *)(param_1 + 0x34) = in_stack_0000003c;
      *(undefined8 *)(param_1 + 0x38) = in_stack_00000040;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < in_stack_00000024) {
    if ((0xfff < in_stack_00000024 + 1) && (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  uStack_8 = 4;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21385 ; VA 0x00a7a230 ; FUN_00a7a230 */

int __thiscall
FUN_00a7a230(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3768;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a79be0(param_2,param_3,param_4);
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x20) = in_stack_00000028;
  *(int **)(param_1 + 0x24) = in_stack_0000002c;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    if ((0xfff < in_stack_00000024 + 1) && (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_0000002c;
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21386 ; VA 0x00a7a380 ; FUN_00a7a380 */

undefined4 * __thiscall FUN_00a7a380(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_2[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  return param_1;
}



/* FUNCTION 21387 ; VA 0x00a7a400 ; FUN_00a7a400 */

int __thiscall
FUN_00a7a400(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a79cf0(param_2,param_3,param_4,param_5,param_6);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x10) = param_7;
  *(int **)(param_1 + 0x14) = param_8;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21388 ; VA 0x00a7a510 ; FUN_00a7a510 */

int __thiscall
FUN_00a7a510(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            int *param_6,uint param_7,undefined4 param_8,undefined4 param_9,undefined4 param_10,
            undefined4 param_11,undefined4 param_12,undefined8 param_13)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e37a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a79cf0(param_2,param_3,param_4,param_5,param_6);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x10) = 0;
  if (param_7 != 0) {
    *(uint *)(param_1 + 0x10) = param_7;
    if ((param_7 & 1) == 0) {
      (**(code **)(param_7 & 0xfffffffe))(&param_9,param_1 + 0x18,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x18) = param_9;
      *(undefined4 *)(param_1 + 0x1c) = param_10;
      *(undefined4 *)(param_1 + 0x20) = param_11;
      *(undefined4 *)(param_1 + 0x24) = param_12;
      *(undefined8 *)(param_1 + 0x28) = param_13;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar1 = param_6[1] + -1;
    param_6[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar1 = param_6[2] + -1;
      param_6[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  uStack_8 = 4;
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_7 & 0xfffffffe))(&param_9,&param_9,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21389 ; VA 0x00a7a670 ; FUN_00a7a670 */

int __thiscall
FUN_00a7a670(int param_1,undefined4 param_2,int *param_3,undefined param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  piVar1 = param_3 + 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  *(undefined *)(param_1 + 8) = param_4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0xc) = param_5;
  *(int **)(param_1 + 0x10) = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x14) = param_7;
  *(int **)(param_1 + 0x18) = param_8;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21390 ; VA 0x00a7a830 ; FUN_00a7a830 */

int __thiscall
FUN_00a7a830(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  undefined4 in_stack_00000048;
  int *in_stack_0000004c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e37d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000028 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000028 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00a7a0c0(param_2,param_3,param_4);
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  if (in_stack_0000004c != (int *)0x0) {
    LOCK();
    in_stack_0000004c[1] = in_stack_0000004c[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x40) = in_stack_00000048;
  *(int **)(param_1 + 0x44) = in_stack_0000004c;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000024) {
    if ((0xfff < in_stack_00000024 + 1) && (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000028 != 0) {
    if (((in_stack_00000028 & 1) == 0) &&
       (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000028 & 0xfffffffe))();
    }
    in_stack_00000028 = 0;
  }
  piVar3 = in_stack_0000004c;
  if (in_stack_0000004c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000004c[1] + -1;
    in_stack_0000004c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000004c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21391 ; VA 0x00a7a9f0 ; FUN_00a7a9f0 */

int __thiscall
FUN_00a7a9f0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e3818;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  uStack_7 = 0;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_00a7a230(param_2,param_3,param_4);
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x28) = in_stack_00000030;
  *(int **)(param_1 + 0x2c) = in_stack_00000034;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    if (0xfff < in_stack_00000024 + 1) {
      if (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_0000002c;
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21392 ; VA 0x00a7ab90 ; FUN_00a7ab90 */

undefined4 __thiscall
FUN_00a7ab90(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,int param_9)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a7a400(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(&param_9);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000034) {
    uVar3 = in_stack_00000034 + 1;
    iVar2 = param_9;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_9 + -4);
      uVar3 = in_stack_00000034 + 0x24;
      if (0x1f < (param_9 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21393 ; VA 0x00a7ad10 ; FUN_00a7ad10 */

int __thiscall
FUN_00a7ad10(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8,uint param_9,undefined4 param_10,
            undefined4 param_11,undefined4 param_12,undefined4 param_13,undefined4 param_14,
            undefined8 param_15)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3898;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a7a400(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *(undefined4 *)(param_1 + 0x18) = 0;
  if (param_9 != 0) {
    *(uint *)(param_1 + 0x18) = param_9;
    if ((param_9 & 1) == 0) {
      (**(code **)(param_9 & 0xfffffffe))(&param_11,param_1 + 0x20,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x20) = param_11;
      *(undefined4 *)(param_1 + 0x24) = param_12;
      *(undefined4 *)(param_1 + 0x28) = param_13;
      *(undefined4 *)(param_1 + 0x2c) = param_14;
      *(undefined8 *)(param_1 + 0x30) = param_15;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  uStack_8 = 5;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&param_11,&param_11,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21394 ; VA 0x00a7aec0 ; FUN_00a7aec0 */

int __thiscall
FUN_00a7aec0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            int *param_6,uint param_7,undefined4 param_8,undefined4 param_9,undefined4 param_10,
            undefined4 param_11,undefined4 *param_12,ulonglong param_13,uint param_14,
            undefined4 param_15,undefined4 param_16,undefined4 param_17,undefined4 param_18,
            undefined4 param_19,undefined8 param_20)

{
  int iVar1;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e38d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if (param_7 != 0) {
    if ((param_7 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_7 & 0xfffffffe))(&param_9,&uStack_38,0);
    }
    else {
      uStack_38 = param_9;
      uStack_34 = param_10;
      uStack_30 = param_11;
      puStack_2c = param_12;
      uStack_28 = param_13;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a7a510(param_2,param_3,param_4,param_5,param_6);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *(undefined4 *)(param_1 + 0x30) = 0;
  if (param_14 != 0) {
    *(uint *)(param_1 + 0x30) = param_14;
    if ((param_14 & 1) == 0) {
      uStack_28 = (ulonglong)(param_1 + 0x38);
      puStack_2c = &param_16;
      uStack_30 = 0xa7afc5;
      (**(code **)(param_14 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x38) = param_16;
      *(undefined4 *)(param_1 + 0x3c) = param_17;
      *(undefined4 *)(param_1 + 0x40) = param_18;
      *(undefined4 *)(param_1 + 0x44) = param_19;
      *(undefined8 *)(param_1 + 0x48) = param_20;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_28 = CONCAT44(0xa7afe2,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_28 = CONCAT44(0xa7aff3,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar1 = param_6[1] + -1;
    param_6[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_28 = CONCAT44(0xa7b00d,(undefined4)uStack_28);
      (**(code **)*param_6)();
      LOCK();
      iVar1 = param_6[2] + -1;
      param_6[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_28 = CONCAT44(0xa7b01e,(undefined4)uStack_28);
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_9;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xa7b043;
    (**(code **)(param_7 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_14 != 0) && ((param_14 & 1) == 0)) &&
     (*(code **)(param_14 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_16;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xa7b071;
    (**(code **)(param_14 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21395 ; VA 0x00a7b090 ; FUN_00a7b090 */

undefined4 __thiscall
FUN_00a7b090(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,int param_9)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3918;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a7a670(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(&param_9);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000034) {
    uVar3 = in_stack_00000034 + 1;
    iVar2 = param_9;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_9 + -4);
      uVar3 = in_stack_00000034 + 0x24;
      if (0x1f < (param_9 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21396 ; VA 0x00a7b210 ; FUN_00a7b210 */

int __thiscall
FUN_00a7b210(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3970;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 6;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  FUN_00a7a9f0(param_2,param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  *(undefined4 *)(param_1 + 0x30) = 0;
  if (in_stack_00000038 != 0) {
    *(uint *)(param_1 + 0x30) = in_stack_00000038;
    if ((in_stack_00000038 & 1) == 0) {
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x38) = in_stack_00000040;
      *(undefined4 *)(param_1 + 0x3c) = in_stack_00000044;
      *(undefined4 *)(param_1 + 0x40) = in_stack_00000048;
      *(undefined4 *)(param_1 + 0x44) = in_stack_0000004c;
      *(undefined8 *)(param_1 + 0x48) = in_stack_00000050;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000024) {
    if (0xfff < in_stack_00000024 + 1) {
      if (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_0000002c;
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 8;
  if (((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) &&
     (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21397 ; VA 0x00a7b420 ; FUN_00a7b420 */

int __thiscall
FUN_00a7b420(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8,int param_9)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000034;
  undefined4 in_stack_00000038;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3540;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_9);
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a7ab90(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  *(undefined4 *)(param_1 + 0x30) = in_stack_00000038;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000034) {
    if (0xfff < in_stack_00000034 + 1) {
      if (0x1f < (param_9 - *(int *)(param_9 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21398 ; VA 0x00a7b5a0 ; FUN_00a7b5a0 */

int __thiscall
FUN_00a7b5a0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8,uint param_9,undefined4 param_10,
            undefined4 param_11,undefined4 param_12,undefined4 param_13,undefined4 *param_14,
            ulonglong param_15,uint param_16,undefined4 param_17,undefined4 param_18,
            undefined4 param_19,undefined4 param_20,undefined4 param_21,undefined8 param_22)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e39b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  if (param_9 != 0) {
    if ((param_9 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_38,0);
    }
    else {
      uStack_38 = param_11;
      uStack_34 = param_12;
      uStack_30 = param_13;
      puStack_2c = param_14;
      uStack_28 = param_15;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a7ad10(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  *(undefined4 *)(param_1 + 0x38) = 0;
  if (param_16 != 0) {
    *(uint *)(param_1 + 0x38) = param_16;
    if ((param_16 & 1) == 0) {
      uStack_28 = (ulonglong)(param_1 + 0x40);
      puStack_2c = &param_18;
      uStack_30 = 0xa7b6d0;
      (**(code **)(param_16 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x40) = param_18;
      *(undefined4 *)(param_1 + 0x44) = param_19;
      *(undefined4 *)(param_1 + 0x48) = param_20;
      *(undefined4 *)(param_1 + 0x4c) = param_21;
      *(undefined8 *)(param_1 + 0x50) = param_22;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xa7b6ed,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_28 = CONCAT44(0xa7b6fe,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xa7b715,(undefined4)uStack_28);
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_28 = CONCAT44(0xa7b726,(undefined4)uStack_28);
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xa7b73d,(undefined4)uStack_28);
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0xa7b74f,(undefined4)uStack_28);
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_11;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xa7b770;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((param_16 != 0) && ((param_16 & 1) == 0)) &&
     (*(code **)(param_16 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_18;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xa7b79e;
    (**(code **)(param_16 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21399 ; VA 0x00a7b7c0 ; FUN_00a7b7c0 */

int __thiscall
FUN_00a7b7c0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8,int param_9)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000034;
  undefined4 in_stack_00000038;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3540;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_9);
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a7b090(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  *(undefined4 *)(param_1 + 0x34) = in_stack_00000038;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000034) {
    if (0xfff < in_stack_00000034 + 1) {
      if (0x1f < (param_9 - *(int *)(param_9 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21400 ; VA 0x00a7b940 ; FUN_00a7b940 */

undefined4 * __thiscall FUN_00a7b940(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e39d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
    }
    else {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
    }
  }
  param_1[0x14] = 0;
  uVar2 = param_2[0x14];
  uStack_8 = 2;
  if (uVar2 != 0) {
    param_1[0x14] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x17];
      uVar4 = param_2[0x18];
      uVar5 = param_2[0x19];
      param_1[0x16] = param_2[0x16];
      param_1[0x17] = uVar3;
      param_1[0x18] = uVar4;
      param_1[0x19] = uVar5;
      *(undefined8 *)(param_1 + 0x1a) = *(undefined8 *)(param_2 + 0x1a);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x16,param_1 + 0x16,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21401 ; VA 0x00a7baa0 ; FUN_00a7baa0 */

int __thiscall
FUN_00a7baa0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  uint in_stack_00000058;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined8 in_stack_00000070;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3a40;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000038 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000038 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 8;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 5;
  FUN_00a7b210(param_2,param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  *(undefined4 *)(param_1 + 0x50) = 0;
  if (in_stack_00000058 != 0) {
    *(uint *)(param_1 + 0x50) = in_stack_00000058;
    if ((in_stack_00000058 & 1) == 0) {
      (**(code **)(in_stack_00000058 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x58) = in_stack_00000060;
      *(undefined4 *)(param_1 + 0x5c) = in_stack_00000064;
      *(undefined4 *)(param_1 + 0x60) = in_stack_00000068;
      *(undefined4 *)(param_1 + 100) = in_stack_0000006c;
      *(undefined8 *)(param_1 + 0x68) = in_stack_00000070;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_00000024) {
    if ((0xfff < in_stack_00000024 + 1) && (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_0000002c;
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (in_stack_00000038 != 0) {
    if (((in_stack_00000038 & 1) == 0) &&
       (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    in_stack_00000038 = 0;
  }
  uStack_8 = 0xb;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000058 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21402 ; VA 0x00a7bd20 ; FUN_00a7bd20 */

undefined4 * __fastcall FUN_00a7bd20(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3b04;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ChatService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00a75310();
  param_1[3] = uVar1;
  *param_1 = RBX::ChatService::vftable;
  param_1[0x16] = 0;
  uStack_8 = 1;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  *(undefined *)(param_1 + 0x1b) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x1c] = uVar1;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0x3f800000;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 1;
  *(undefined *)(param_1 + 0x27) = 0;
  param_1[0x28] = 0;
  *(undefined *)(param_1 + 0x29) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x2a] = uVar1;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0x3f800000;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  puStack_18 = param_1 + 0x2f;
  uStack_8._0_1_ = 9;
  FUN_00a78600();
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  uStack_8._0_1_ = 10;
  FUN_00a78600();
  param_1[0x45] = 0;
  *(undefined *)(param_1 + 0x46) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x47] = uVar1;
  param_1[0x48] = 0;
  param_1[0x49] = 0x3f800000;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  uStack_8._0_1_ = 0xd;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0(&DAT_01931fd4,4);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    uVar2 = auStack_30[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_30[0] - 4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21403 ; VA 0x00a7bf40 ; FUN_00a7bf40 */

undefined4 * __thiscall FUN_00a7bf40(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *(undefined *)(param_1 + 2) = *(undefined *)(param_2 + 2);
  *(undefined *)((int)param_1 + 9) = *(undefined *)((int)param_2 + 9);
  param_1[7] = 0;
  param_1[8] = 0;
  uVar1 = param_2[4];
  uVar2 = param_2[5];
  uVar3 = param_2[6];
  param_1[3] = param_2[3];
  param_1[4] = uVar1;
  param_1[5] = uVar2;
  param_1[6] = uVar3;
  *(undefined8 *)(param_1 + 7) = *(undefined8 *)(param_2 + 7);
  param_2[7] = 0;
  param_2[8] = 0xf;
  *(undefined *)(param_2 + 3) = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  uVar1 = param_2[10];
  uVar2 = param_2[0xb];
  uVar3 = param_2[0xc];
  param_1[9] = param_2[9];
  param_1[10] = uVar1;
  param_1[0xb] = uVar2;
  param_1[0xc] = uVar3;
  *(undefined8 *)(param_1 + 0xd) = *(undefined8 *)(param_2 + 0xd);
  param_2[0xd] = 0;
  param_2[0xe] = 0xf;
  *(undefined *)(param_2 + 9) = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  uVar1 = param_2[0x10];
  uVar2 = param_2[0x11];
  uVar3 = param_2[0x12];
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = uVar1;
  param_1[0x11] = uVar2;
  param_1[0x12] = uVar3;
  *(undefined8 *)(param_1 + 0x13) = *(undefined8 *)(param_2 + 0x13);
  param_2[0x13] = 0;
  param_2[0x14] = 0xf;
  *(undefined *)(param_2 + 0xf) = 0;
  return param_1;
}



/* FUNCTION 21404 ; VA 0x00a7c000 ; FUN_00a7c000 */

undefined4 * __thiscall FUN_00a7c000(undefined4 *param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3b26;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *(undefined *)(param_1 + 2) = *(undefined *)(param_2 + 2);
  *(undefined *)((int)param_1 + 9) = *(undefined *)((int)param_2 + 9);
  FUN_0054ef60(param_2 + 3);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 9);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2 + 0xf);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21405 ; VA 0x00a7c080 ; FUN_00a7c080 */

undefined4 * __thiscall
FUN_00a7c080(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3b43;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_2;
  param_1[3] = param_3;
  param_1[8] = 0;
  param_1[9] = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  uStack_8 = 1;
  FUN_0054ef60(&param_4);
  *(undefined *)(param_1 + 0x10) = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0xf;
  *(undefined *)(param_1 + 0x11) = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0xf;
  *(undefined *)(param_1 + 0x17) = 0;
  *(undefined *)(param_1 + 0x1d) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x1e] = uVar1;
  param_1[0x1f] = 0;
  param_1[0x20] = 0x3f800000;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_4 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21406 ; VA 0x00a7c180 ; FUN_00a7c180 */

code * __fastcall FUN_00a7c180(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  uVar3 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x10);
    uVar8 = uVar3 + 1;
    iVar7 = iVar4;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar4 + -4);
      uVar8 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pcVar6 = (code *)FUN_01674ea0(iVar7,uVar8);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 21407 ; VA 0x00a7c250 ; FUN_00a7c250 */

void __fastcall FUN_00a7c250(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 21408 ; VA 0x00a7c2b0 ; FUN_00a7c2b0 */

void __fastcall FUN_00a7c2b0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  FUN_005c4ac0();
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 21409 ; VA 0x00a7c320 ; FUN_00a7c320 */

void __fastcall FUN_00a7c320(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0x48);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  FUN_005c4ac0();
  FUN_009cb8d0();
  return;
}



/* FUNCTION 21410 ; VA 0x00a7c3c0 ; FUN_00a7c3c0 */

void __fastcall FUN_00a7c3c0(int param_1)

{
  int iVar1;
  
  LOCK();
  iVar1 = *(int *)(param_1 + 0x2c);
  *(int *)(param_1 + 0x2c) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  FUN_00a7c420();
  return;
}



/* FUNCTION 21411 ; VA 0x00a7c3e0 ; FUN_00a7c3e0 */

void __fastcall FUN_00a7c3e0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ChatService>::vftable;
  uVar1 = FUN_00a75310(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21412 ; VA 0x00a7c420 ; FUN_00a7c420 */

void __fastcall FUN_00a7c420(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  *param_1 = RBX::
             LRUCache<struct_RBX::ChatService::MessageAndSenderId,struct_RBX::TextFilterResult,struct_boost::hash<struct_RBX::ChatService::MessageAndSenderId>_>
             ::vftable;
  FUN_00a80430();
  if (param_1[5] != 0) {
    FUN_00a82b00(param_1[8] + param_1[4] * 4,0);
    puVar2 = (undefined4 *)param_1[8];
    puVar1 = puVar2 + param_1[4];
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  param_1[9] = 0;
  FUN_00a7ce90();
  FUN_00a80430();
  FUN_01674ea0(param_1[1],0x88);
  return;
}



/* FUNCTION 21413 ; VA 0x00a7c4a0 ; FUN_00a7c4a0 */

void __fastcall FUN_00a7c4a0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  FUN_00a7c840();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21414 ; VA 0x00a7c500 ; FUN_00a7c500 */

void FUN_00a7c500(void)

{
  FUN_0096d5e0();
  FUN_00a7c840();
  return;
}



/* FUNCTION 21415 ; VA 0x00a7c520 ; FUN_00a7c520 */

void FUN_00a7c520(void)

{
  FUN_00a7cc10();
  return;
}



/* FUNCTION 21416 ; VA 0x00a7c530 ; FUN_00a7c530 */

void FUN_00a7c530(void)

{
  FUN_00a7ca10();
  return;
}



/* FUNCTION 21417 ; VA 0x00a7c540 ; FUN_00a7c540 */

void FUN_00a7c540(void)

{
  FUN_00a7cb00();
  return;
}



/* FUNCTION 21418 ; VA 0x00a7c550 ; FUN_00a7c550 */

void __fastcall FUN_00a7c550(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x40);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x48,param_1 + 0x48,2);
      }
    }
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  FUN_00a7cb80();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21419 ; VA 0x00a7c5b0 ; FUN_00a7c5b0 */

void FUN_00a7c5b0(void)

{
  FUN_00a7cca0();
  return;
}



/* FUNCTION 21420 ; VA 0x00a7c5c0 ; FUN_00a7c5c0 */

void FUN_00a7c5c0(void)

{
  FUN_00a7cd80();
  return;
}



/* FUNCTION 21421 ; VA 0x00a7c5d0 ; FUN_00a7c5d0 */

void __fastcall FUN_00a7c5d0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  FUN_00a7c840();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21422 ; VA 0x00a7c630 ; FUN_00a7c630 */

void FUN_00a7c630(void)

{
  FUN_0096d5e0();
  FUN_00a7c840();
  return;
}



/* FUNCTION 21423 ; VA 0x00a7c650 ; thunk_FUN_00a7ca10 */

void __fastcall thunk_FUN_00a7ca10(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(param_1 + 0x44);
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x20);
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x28,param_1 + 0x28,2);
      }
    }
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  FUN_006511a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21424 ; VA 0x00a7c660 ; thunk_FUN_00a7cc10 */

void __fastcall thunk_FUN_00a7cc10(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x10);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  FUN_0056b650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21425 ; VA 0x00a7c670 ; thunk_FUN_00a7cb00 */

void __fastcall thunk_FUN_00a7cb00(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x2c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x18);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  piVar4 = *(int **)(param_1 + 0x14);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_0056b650();
  return;
}



/* FUNCTION 21426 ; VA 0x00a7c680 ; FUN_00a7c680 */

void __fastcall FUN_00a7c680(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  FUN_00a7cb80();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21427 ; VA 0x00a7c6e0 ; thunk_FUN_00a7cca0 */

void __fastcall thunk_FUN_00a7cca0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x30);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x1c);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  piVar4 = *(int **)(param_1 + 0x18);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00a7c8d0();
  return;
}



/* FUNCTION 21428 ; VA 0x00a7c6f0 ; thunk_FUN_00a7cd80 */

void __fastcall thunk_FUN_00a7cd80(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x50);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x58,param_1 + 0x58,2);
      }
    }
    *(undefined4 *)(param_1 + 0x50) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x30);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  FUN_00a7caa0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21429 ; VA 0x00a7c700 ; FUN_00a7c700 */

void __fastcall FUN_00a7c700(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00d88a30();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x2c);
  }
  return;
}



/* FUNCTION 21430 ; VA 0x00a7c730 ; FUN_00a7c730 */

void __fastcall FUN_00a7c730(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    if (*(char *)((int)param_1 + 9) != '\0') {
      ExceptionList = &pvStack_10;
      FUN_00a770b0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x38);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21431 ; VA 0x00a7c790 ; FUN_00a7c790 */

void __fastcall FUN_00a7c790(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00a77130(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0xb0);
  }
  return;
}



/* FUNCTION 21432 ; VA 0x00a7c7d0 ; FUN_00a7c7d0 */

void FUN_00a7c7d0(void)

{
  FUN_0096d5e0();
  return;
}



/* FUNCTION 21433 ; VA 0x00a7c7e0 ; FUN_00a7c7e0 */

void __fastcall FUN_00a7c7e0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_0096d5e0();
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 21434 ; VA 0x00a7c840 ; FUN_00a7c840 */

code * __fastcall FUN_00a7c840(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 8);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 21435 ; VA 0x00a7c8d0 ; FUN_00a7c8d0 */

void __fastcall FUN_00a7c8d0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a7c923. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 21436 ; VA 0x00a7c930 ; FUN_00a7c930 */

void __fastcall FUN_00a7c930(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0056b650();
  return;
}



/* FUNCTION 21437 ; VA 0x00a7c970 ; FUN_00a7c970 */

void __fastcall FUN_00a7c970(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  FUN_0056b650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21438 ; VA 0x00a7c9d0 ; FUN_00a7c9d0 */

void __fastcall FUN_00a7c9d0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00a7c8d0();
  return;
}



/* FUNCTION 21439 ; VA 0x00a7ca10 ; FUN_00a7ca10 */

void __fastcall FUN_00a7ca10(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(param_1 + 0x44);
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x20);
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x28,param_1 + 0x28,2);
      }
    }
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  FUN_006511a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21440 ; VA 0x00a7caa0 ; FUN_00a7caa0 */

void __fastcall FUN_00a7caa0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x2c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006511a0();
  return;
}



/* FUNCTION 21441 ; VA 0x00a7cb00 ; FUN_00a7cb00 */

void __fastcall FUN_00a7cb00(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x2c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x18);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  piVar4 = *(int **)(param_1 + 0x14);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_0056b650();
  return;
}



/* FUNCTION 21442 ; VA 0x00a7cb80 ; FUN_00a7cb80 */

void __fastcall FUN_00a7cb80(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x18);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  piVar3 = *(int **)(param_1 + 0x14);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_0056b650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21443 ; VA 0x00a7cc10 ; FUN_00a7cc10 */

void __fastcall FUN_00a7cc10(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x10);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  FUN_0056b650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21444 ; VA 0x00a7cca0 ; FUN_00a7cca0 */

void __fastcall FUN_00a7cca0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x30);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x1c);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  piVar4 = *(int **)(param_1 + 0x18);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00a7c8d0();
  return;
}



/* FUNCTION 21445 ; VA 0x00a7cd20 ; FUN_00a7cd20 */

void __fastcall FUN_00a7cd20(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  FUN_00a7caa0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21446 ; VA 0x00a7cd80 ; FUN_00a7cd80 */

void __fastcall FUN_00a7cd80(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x50);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x58,param_1 + 0x58,2);
      }
    }
    *(undefined4 *)(param_1 + 0x50) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x30);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  FUN_00a7caa0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21447 ; VA 0x00a7ce10 ; FUN_00a7ce10 */

void __fastcall FUN_00a7ce10(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00a82ab0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 21448 ; VA 0x00a7ce90 ; FUN_00a7ce90 */

void __fastcall FUN_00a7ce90(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00a82b00(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 21449 ; VA 0x00a7cf10 ; FUN_00a7cf10 */

void __fastcall FUN_00a7cf10(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar6;
        FUN_00a770b0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21450 ; VA 0x00a7cfe0 ; FUN_00a7cfe0 */

void __fastcall FUN_00a7cfe0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00a77130(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0xb0);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 21451 ; VA 0x00a7d090 ; FUN_00a7d090 */

void __fastcall FUN_00a7d090(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00a82ab0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 21452 ; VA 0x00a7d0a0 ; FUN_00a7d0a0 */

void __fastcall FUN_00a7d0a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar6;
        FUN_00a770b0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21453 ; VA 0x00a7d0b0 ; FUN_00a7d0b0 */

void __fastcall FUN_00a7d0b0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00a77130(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0xb0);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 21454 ; VA 0x00a7d0c0 ; thunk_FUN_0096d5e0 */

void __fastcall thunk_FUN_0096d5e0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x50);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x3c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0096d6af;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0xf;
  *(undefined *)(param_1 + 0x3c) = 0;
  uVar1 = *(uint *)(param_1 + 0x38);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x24);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0096d6af;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0xf;
  *(undefined *)(param_1 + 0x24) = 0;
  uVar1 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xc);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0096d6af:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  return;
}



/* FUNCTION 21455 ; VA 0x00a7d0d0 ; FUN_00a7d0d0 */

void FUN_00a7d0d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a7ed40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21456 ; VA 0x00a7d100 ; FUN_00a7d100 */

void __fastcall FUN_00a7d100(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00612320();
  uVar1 = *(uint *)(param_1 + 0x70);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x5c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a7d21d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0xf;
  *(undefined *)(param_1 + 0x5c) = 0;
  uVar1 = *(uint *)(param_1 + 0x58);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x44);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a7d21d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0xf;
  *(undefined *)(param_1 + 0x44) = 0;
  uVar1 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x28);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a7d21d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  uVar1 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x10);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00a7d21d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  return;
}



/* FUNCTION 21457 ; VA 0x00a7d230 ; FUN_00a7d230 */

undefined4 * __thiscall FUN_00a7d230(undefined4 *param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    ExceptionList = &pvStack_10;
    FUN_00a7ed40();
    *param_1 = *param_2;
    param_1[1] = param_2[1];
    param_1[2] = param_2[2];
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21458 ; VA 0x00a7d290 ; FUN_00a7d290 */

uint * __thiscall FUN_00a7d290(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3b58;
  pvStack_10 = ExceptionList;
  uVar8 = *param_2;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&iStack_14,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_14 == 0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x2c);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[3] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[10] = 0;
    piVar3[2] = uVar8;
    piVar3[4] = 0;
    LOCK();
    DAT_01e90cd8 = DAT_01e90cd8 + 1;
    UNLOCK();
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[3] = (int)RBX::Lua::WeakFunctionRef::vftable;
    piVar3[10] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005d6bb0(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      iStack_14 = 1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005d6bb0(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return (uint *)(piVar3 + 2);
  }
  ExceptionList = pvStack_10;
  return (uint *)(iStack_14 + 8);
}



/* FUNCTION 21459 ; VA 0x00a7d4b0 ; FUN_00a7d4b0 */

int * __thiscall FUN_00a7d4b0(byte *param_1,uint param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  int aiStack_48 [5];
  uint uStack_34;
  int iStack_30;
  int iStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar5 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3b80;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_005702d0(param_2);
  uVar8 = *(uint *)(iVar5 + 0x1c);
  param_2 = iVar3 + 0x9e3779b9;
  if (((int)uVar8 < 1) && ((int)uVar8 < 0)) {
    uVar8 = ~uVar8;
  }
  uStack_14 = (uVar8 ^ (uVar8 >> 2) + uVar8 * 0x40 + *(int *)(iVar5 + 0x18)) + param_2 * 0x40 +
              (param_2 >> 2) + 0x9e3779b9 ^ param_2;
  FUN_00a77880(&param_2,uStack_14,iVar5,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == 0) {
    piStack_24 = (int *)0x0;
    uStack_20 = 0;
    uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
    iStack_8 = 0;
    FUN_0054ef60(iVar5);
    iStack_30 = *(int *)(iVar5 + 0x18);
    iStack_2c = *(int *)(iVar5 + 0x1c);
    iStack_8._0_1_ = 1;
    uStack_20 = 0;
    piVar4 = (int *)FUN_01674e20(0x38);
    piStack_18 = piVar4 + 2;
    *piVar4 = 0;
    piVar4[1] = 0;
    piStack_24 = piVar4;
    FUN_0170d1f0(piStack_18,0,0x30);
    uStack_20 = CONCAT11(uStack_20._1_1_,1);
    FUN_0054ef60(aiStack_48);
    piVar4[8] = iStack_30;
    piVar4[9] = iStack_2c;
    piVar4[10] = 0;
    piVar4[0xb] = 0;
    piVar4[0xc] = 0;
    uStack_20 = CONCAT11(1,(undefined)uStack_20);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_34) {
      uVar8 = uStack_34 + 1;
      iVar5 = aiStack_48[0];
      if (0xfff < uVar8) {
        iVar5 = *(int *)(aiStack_48[0] + -4);
        uVar8 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar8);
    }
    uVar1 = *(uint *)(param_1 + 8);
    uVar8 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar8 = FUN_005d6bb0(uVar8);
      if (uVar8 <= *(uint *)(param_1 + 4)) {
        uVar8 = *(uint *)(param_1 + 4);
      }
      FUN_005c6680(uVar8);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar8) {
      param_2 = 1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar8) {
        uVar6 = 1;
      }
      iVar5 = FUN_005d6bb0(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005c6680(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar4[1] = uStack_14;
    uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar9 = piVar7;
      *piVar4 = *piVar7;
    }
    else {
      *piVar4 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar4;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piStack_18;
  }
  ExceptionList = pvStack_10;
  return (int *)(param_2 + 8);
}



/* FUNCTION 21460 ; VA 0x00a7d740 ; FUN_00a7d740 */

void __thiscall FUN_00a7d740(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined **ppuVar5;
  undefined4 auStack_258 [6];
  undefined4 uStack_240;
  undefined4 uStack_23c;
  undefined auStack_230 [88];
  undefined auStack_1d8 [88];
  undefined auStack_180 [88];
  undefined auStack_128 [88];
  undefined auStack_d0 [88];
  undefined4 uStack_78;
  int iStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined uStack_28;
  undefined4 *puStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e3bf1;
  pvStack_10 = ExceptionList;
  uStack_23c = *param_1;
  uStack_240 = 0xa7d769;
  ExceptionList = &pvStack_10;
  iStack_1c = FUN_008f7870();
  if (iStack_1c != 0) {
    iStack_74 = param_1[1];
    puStack_20 = &uStack_78;
    puStack_18 = auStack_258;
    if (iStack_74 != 0) {
      LOCK();
      *(int *)(iStack_74 + 4) = *(int *)(iStack_74 + 4) + 1;
      UNLOCK();
      iStack_74 = param_1[1];
    }
    uStack_78 = *param_1;
    uStack_70 = param_1[2];
    uStack_6c = param_1[3];
    uStack_8 = 0;
    FUN_0054ef60(param_1 + 4);
    uStack_50 = param_1[10];
    uStack_4c = param_1[0xb];
    uVar1 = param_1[0xc];
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uStack_48 = 0;
    if (uVar1 != 0) {
      uStack_48 = uVar1;
      if ((uVar1 & 1) == 0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0xe,&uStack_40,0);
      }
      else {
        uStack_40 = param_1[0xe];
        uStack_3c = param_1[0xf];
        uStack_38 = param_1[0x10];
        uStack_34 = param_1[0x11];
        uStack_30 = *(undefined8 *)(param_1 + 0x12);
      }
    }
    uStack_28 = *(undefined *)(param_1 + 0x14);
    uStack_8 = 2;
    FUN_00a78220(&uStack_78);
    puVar2 = puStack_18;
    uStack_8._0_1_ = 3;
    *puStack_18 = 0;
    FUN_00a78220(auStack_230);
    uStack_8._0_1_ = 4;
    FUN_00a78220(auStack_1d8);
    uStack_8._0_1_ = 5;
    FUN_00a78220(auStack_180);
    uStack_8._0_1_ = 6;
    cVar3 = FUN_00585a40(auStack_d0);
    if (cVar3 == '\0') {
      FUN_00a78220(auStack_d0);
      uStack_8._0_1_ = 7;
      puStack_20 = (undefined4 *)FUN_01674e20(0x58);
      uStack_8._0_1_ = 8;
      if (puStack_20 == (undefined4 *)0x0) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_00a78220(auStack_128);
      }
      puVar2[2] = uVar4;
      FUN_00a7c180();
      FUN_00a7c180();
      cStack_11 = '\x01';
    }
    else {
      FUN_00a7c180();
      cStack_11 = '\0';
    }
    FUN_00a7c180();
    ppuVar5 = &PTR_FUN_01946980;
    if (cStack_11 == '\0') {
      ppuVar5 = (undefined **)0x0;
    }
    *puVar2 = ppuVar5;
    FUN_00a7c180();
    FUN_00a7c180();
    uStack_8 = 0xffffffff;
    FUN_00a7c180();
    FUN_008ed3f0(iStack_1c,param_2,param_3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21461 ; VA 0x00a7d960 ; FUN_00a7d960 */

int __thiscall
FUN_00a7d960(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_18 = &LAB_017e3c1e;
  pvStack_1c = ExceptionList;
  uVar3 = *(undefined4 *)(param_1 + 8);
  uVar4 = *(undefined4 *)(param_1 + 0xc);
  uStack_14 = 1;
  uVar5 = *(uint *)(param_1 + 0x30);
  ExceptionList = &pvStack_1c;
  if ((uVar5 != 0) && (ExceptionList = &pvStack_1c, (uVar5 & 1) == 0)) {
    ExceptionList = &pvStack_1c;
    (**(code **)(uVar5 & 0xfffffffe))();
  }
  uStack_14._0_1_ = 2;
  FUN_0054ef60(param_1 + 0x10);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  iVar6 = FUN_00a87310(param_2,param_3,param_4,param_5,uVar3,uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iVar6;
}



/* FUNCTION 21462 ; VA 0x00a7dae0 ; FUN_00a7dae0 */

/* WARNING: Removing unreachable block (ram,0x00a7dc4f) */
/* WARNING: Removing unreachable block (ram,0x00a7dc5f) */
/* WARNING: Removing unreachable block (ram,0x00a7dc65) */

void __thiscall FUN_00a7dae0(int *param_1,int param_2)

{
  uint in_stack_00000018;
  int in_stack_0000001c;
  uint in_stack_00000030;
  int in_stack_00000034;
  uint in_stack_00000048;
  int in_stack_0000004c;
  uint in_stack_00000060;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3c78;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 6;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    FUN_01675290();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000030) {
    if ((0xfff < in_stack_00000030 + 1) &&
       (0x1f < (in_stack_0000001c - *(int *)(in_stack_0000001c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000048) {
    if ((0xfff < in_stack_00000048 + 1) &&
       (0x1f < (in_stack_00000034 - *(int *)(in_stack_00000034 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000060) {
    if ((0xfff < in_stack_00000060 + 1) &&
       (0x1f < (in_stack_0000004c - *(int *)(in_stack_0000004c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21463 ; VA 0x00a7dd0b ; Catch@00a7dd0b */

undefined * Catch_00a7dd0b(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x30));
  return &DAT_00a7dd1c;
}



/* FUNCTION 21464 ; VA 0x00a7dd50 ; FUN_00a7dd50 */

/* WARNING: Removing unreachable block (ram,0x00a7de3e) */
/* WARNING: Removing unreachable block (ram,0x00a7de4e) */
/* WARNING: Removing unreachable block (ram,0x00a7de54) */

void * __thiscall
FUN_00a7dd50(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            int param_6)

{
  int *piVar1;
  void *pvVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000028;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3cb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 5;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290(uVar3);
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar4 = param_3[1] + -1;
      param_3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar4 = param_3[2] + -1;
        param_3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar4 = param_5[1] + -1;
      param_5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    pvVar2 = (void *)FUN_005507b0();
    ExceptionList = pvStack_10;
    return pvVar2;
  }
  pvVar2 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar4 = *piVar1;
    pvVar2 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      pvVar2 = (void *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        pvVar2 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar4 = *piVar1;
    pvVar2 = (void *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      pvVar2 = (void *)(**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pvVar2 = (void *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000028) {
    uVar5 = in_stack_00000028 + 1;
    iVar4 = param_6;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_6 + -4);
      uVar5 = in_stack_00000028 + 0x24;
      if (0x1f < (param_6 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pvVar2 = (void *)FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 21465 ; VA 0x00a7df09 ; Catch@00a7df09 */

undefined * Catch_00a7df09(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00a7df1a;
}



/* FUNCTION 21466 ; VA 0x00a7df40 ; FUN_00a7df40 */

/* WARNING: Removing unreachable block (ram,0x00a7e001) */
/* WARNING: Removing unreachable block (ram,0x00a7e011) */
/* WARNING: Removing unreachable block (ram,0x00a7e017) */

void * __thiscall FUN_00a7df40(int *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  void *pvVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3cf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    FUN_01675290(uVar3);
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar4 = param_3[1] + -1;
      param_3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    pvVar2 = (void *)FUN_005507b0();
    ExceptionList = pvStack_10;
    return pvVar2;
  }
  pvVar2 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar4 = *piVar1;
    pvVar2 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      pvVar2 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pvVar2 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    iVar4 = param_4;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_4 + -4);
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pvVar2 = (void *)FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 21467 ; VA 0x00a7e09b ; Catch@00a7e09b */

undefined * Catch_00a7e09b(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00a7e0ac;
}



/* FUNCTION 21468 ; VA 0x00a7e0d0 ; FUN_00a7e0d0 */

/* WARNING: Removing unreachable block (ram,0x00a7e26e) */
/* WARNING: Removing unreachable block (ram,0x00a7e27e) */
/* WARNING: Removing unreachable block (ram,0x00a7e284) */

void __thiscall FUN_00a7e0d0(int *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000020;
  int in_stack_00000028;
  uint in_stack_0000003c;
  int in_stack_00000040;
  uint in_stack_00000054;
  int in_stack_00000058;
  uint in_stack_0000006c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3d50;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 7;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    FUN_01675290();
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    ExceptionList = &pvStack_10;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    if ((0xfff < in_stack_00000020 + 1) && (0x1f < (param_4 - *(int *)(param_4 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (0xf < in_stack_0000003c) {
    if ((0xfff < in_stack_0000003c + 1) &&
       (0x1f < (in_stack_00000028 - *(int *)(in_stack_00000028 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000054) {
    if ((0xfff < in_stack_00000054 + 1) &&
       (0x1f < (in_stack_00000040 - *(int *)(in_stack_00000040 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (0xf < in_stack_0000006c) {
    if ((0xfff < in_stack_0000006c + 1) &&
       (0x1f < (in_stack_00000058 - *(int *)(in_stack_00000058 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21469 ; VA 0x00a7e366 ; Catch@00a7e366 */

undefined * Catch_00a7e366(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x30));
  return &DAT_00a7e377;
}



/* FUNCTION 21470 ; VA 0x00a7e3a0 ; FUN_00a7e3a0 */

/* WARNING: Removing unreachable block (ram,0x00a7e41f) */
/* WARNING: Removing unreachable block (ram,0x00a7e42f) */
/* WARNING: Removing unreachable block (ram,0x00a7e435) */

void __thiscall FUN_00a7e3a0(int *param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e3d78;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 == 0) {
    uStack_8 = 1;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    FUN_01675290(uVar1);
    uStack_8 = 7;
  }
  if (param_3 != 0) {
    (**(code **)(param_3 + 8))(&stack0x0000000c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21471 ; VA 0x00a7e477 ; Catch@00a7e477 */

undefined * Catch_00a7e477(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00a7e488;
}



/* FUNCTION 21472 ; VA 0x00a7e4a0 ; FUN_00a7e4a0 */

undefined4 __thiscall FUN_00a7e4a0(undefined4 param_1,byte param_2)

{
  FUN_00a7c250();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 21473 ; VA 0x00a7e4d0 ; FUN_00a7e4d0 */

undefined4 __thiscall FUN_00a7e4d0(undefined4 param_1,byte param_2)

{
  FUN_00a7c2b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 21474 ; VA 0x00a7e500 ; FUN_00a7e500 */

int __thiscall FUN_00a7e500(int param_1,byte param_2)

{
  if (*(int **)(param_1 + 0x44) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x44) + 4))(1);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 21475 ; VA 0x00a7e550 ; FUN_00a7e550 */

undefined4 __thiscall FUN_00a7e550(undefined4 param_1,byte param_2)

{
  FUN_00a7c320();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 21476 ; VA 0x00a7e580 ; FUN_00a7e580 */

int __thiscall FUN_00a7e580(int param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_005c4ac0();
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 21477 ; VA 0x00a7e5f0 ; FUN_00a7e5f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a7e5f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ChatService::ChatCallbackType>::vftable;
  _DAT_01eeac80 = _DAT_01eeac80 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 21478 ; VA 0x00a7e620 ; FUN_00a7e620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a7e620(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ChatService::ChatColor>::vftable;
  _DAT_01eeac78 = _DAT_01eeac78 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 21479 ; VA 0x00a7e650 ; FUN_00a7e650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a7e650(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ChatService::TextFilterContext>::vftable;
  _DAT_01eeac88 = _DAT_01eeac88 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 21480 ; VA 0x00a7e680 ; FUN_00a7e680 */

undefined4 __thiscall FUN_00a7e680(undefined4 param_1,byte param_2)

{
  FUN_00a7c420();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 21481 ; VA 0x00a7e6b0 ; FUN_00a7e6b0 */

undefined4 * __thiscall FUN_00a7e6b0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::ChatService::vftable;
  FUN_00a7ce10();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x45];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_00a7c420();
  LOCK();
  iVar3 = param_1[0x3a];
  param_1[0x3a] = 0;
  UNLOCK();
  if (iVar3 != 0) {
    CloseHandle(iVar3);
  }
  FUN_00a7c420();
  FUN_00a7cfe0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00a7cf10();
  FUN_016790b0();
  FUN_016790b0();
  iVar3 = param_1[0x18];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x130);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21482 ; VA 0x00a7e820 ; FUN_00a7e820 */

undefined4 FUN_00a7e820(undefined4 param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_e8 [120];
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e414b;
  pvStack_10 = ExceptionList;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 1;
  puVar1 = &DAT_01d66458;
  if (0xf < DAT_01d6646c) {
    puVar1 = DAT_01d66458;
  }
  uVar2 = FUN_0151f070(auStack_70,puVar1);
  uStack_8._0_1_ = 2;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("https",5);
  uStack_8._0_1_ = 3;
  FUN_0151bcc0(auStack_e8,auStack_28,uVar2,&DAT_01d66440,auStack_40,auStack_58);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0151bb70(param_1);
  FUN_0056d9d0();
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21483 ; VA 0x00a7ea40 ; FUN_00a7ea40 */

void FUN_00a7ea40(char param_1,int param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *in_stack_0000006c;
  uint in_stack_00000080;
  uint uStack_30;
  uint uStack_2c;
  char *pcStack_28;
  undefined8 uStack_24;
  undefined4 *puStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4178;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (param_1 == '\0') {
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      puVar3 = &stack0x0000006c;
      if (0xf < in_stack_00000080) {
        puVar3 = in_stack_0000006c;
      }
      if (param_2 == 0) {
        uStack_24 = 0x8000000000000000;
        ExceptionList = &pvStack_10;
      }
      else {
        puStack_1c = (undefined4 *)0xa7eb08;
        ExceptionList = &pvStack_10;
        uStack_24 = FUN_00928340();
      }
      uStack_2c = (uint)DAT_01eea9ad;
      pcStack_28 = "FilterStringAsync:NoChat %lld \"%s\"";
      uStack_30 = 0xa7eb29;
      puStack_1c = puVar3;
      FUN_01677520();
    }
    uStack_24._4_4_ = (undefined *)0x0;
    puStack_1c = (undefined4 *)&DAT_0000000f;
    uStack_30 = uStack_30 & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
  }
  else {
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      puVar3 = &stack0x0000006c;
      if (0xf < in_stack_00000080) {
        puVar3 = in_stack_0000006c;
      }
      if (param_2 == 0) {
        uStack_24 = 0x8000000000000000;
        ExceptionList = &pvStack_10;
      }
      else {
        puStack_1c = (undefined4 *)0xa7ea8a;
        ExceptionList = &pvStack_10;
        uStack_24 = FUN_00928340();
      }
      uStack_2c = (uint)DAT_01eea9ad;
      pcStack_28 = "FilterStringAsync:Success %lld \"%s\"";
      uStack_30 = 0xa7eaab;
      puStack_1c = puVar3;
      FUN_01677520();
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    FUN_00a7ebd0(&uStack_30,&stack0x00000030,param_2,param_3);
  }
  FUN_005e65e0();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_1c = (undefined4 *)0xa7eb6f;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_1c = (undefined4 *)0xa7eb7e;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_24._0_4_ = &stack0x00000018;
    puStack_1c = (undefined4 *)0x2;
    pcStack_28 = (char *)0xa7eb9f;
    uStack_24._4_4_ = (undefined *)uStack_24;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  puStack_1c = (undefined4 *)0xa7ebb1;
  FUN_0096d5e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21484 ; VA 0x00a7ebd0 ; FUN_00a7ebd0 */

undefined4 FUN_00a7ebd0(undefined4 param_1,int param_2,int param_3,int *param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4198;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_00929ba0();
    if (cVar2 != '\0') {
      if (*(char *)(param_2 + 9) == '\0') {
        iVar3 = FUN_00926bd0();
        iVar4 = param_2 + 0x24;
        if (iVar3 != 0) {
          iVar4 = param_2 + 0x3c;
        }
      }
      else {
        iVar4 = param_2 + 0x24;
      }
      FUN_0054ef60(iVar4);
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  FUN_0054ef60(param_2 + 0x24);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar4 = param_4[1] + -1;
    param_4[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21485 ; VA 0x00a7eca0 ; FUN_00a7eca0 */

void FUN_00a7eca0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x88);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 21486 ; VA 0x00a7ecd0 ; FUN_00a7ecd0 */

void FUN_00a7ecd0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_0096d5e0();
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  FUN_01674ea0(param_1,0x88);
  return;
}



/* FUNCTION 21487 ; VA 0x00a7ed40 ; FUN_00a7ed40 */

void __fastcall FUN_00a7ed40(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_006ce110(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 21488 ; VA 0x00a7eda0 ; FUN_00a7eda0 */

undefined4 * __thiscall FUN_00a7eda0(undefined4 param_1,int param_2,int param_3,undefined4 *param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e41b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      *param_4 = 0;
      FUN_005880d0(param_2);
      param_4 = param_4 + 8;
      param_2 = param_2 + 0x20;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar1;
  uStack_8 = 1;
  FUN_006ce110(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 21489 ; VA 0x00a7ee30 ; FUN_00a7ee30 */

void __thiscall FUN_00a7ee30(undefined4 param_1,uint *param_2,uint *param_3,uint *param_4)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void **ppvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e41b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar4 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      *param_4 = 0;
      uVar1 = *param_2;
      if (uVar1 != 0) {
        *param_4 = uVar1;
        if ((uVar1 & 1) == 0) {
          (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_4 + 2,0);
        }
        else {
          uVar1 = param_2[3];
          uVar2 = param_2[4];
          uVar3 = param_2[5];
          param_4[2] = param_2[2];
          param_4[3] = uVar1;
          param_4[4] = uVar2;
          param_4[5] = uVar3;
          uVar1 = param_2[7];
          param_4[6] = param_2[6];
          param_4[7] = uVar1;
        }
      }
      param_4 = param_4 + 8;
      param_2 = param_2 + 8;
      ppvVar4 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar4;
  uStack_8 = 1;
  FUN_006ce110(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21490 ; VA 0x00a7eef0 ; FUN_00a7eef0 */

void __thiscall
FUN_00a7eef0(int param_1,double param_2,int param_3,uint param_4,uint param_5,undefined4 *param_6,
            undefined4 *param_7,undefined4 *param_8)

{
  double *pdVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  double *pdVar5;
  uint auStack_c [2];
  
  pdVar1 = (double *)(param_1 + 8);
  *(byte *)(param_1 + 0x40) = *(byte *)(param_1 + 0x40) | (byte)param_3;
  pdVar5 = &param_2;
  if (param_2 < *pdVar1 || param_2 == *pdVar1) {
    pdVar5 = pdVar1;
  }
  *(undefined4 *)pdVar1 = *(undefined4 *)pdVar5;
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)((int)pdVar5 + 4);
  iVar4 = param_1 + 0x75 + (uint)*(byte *)(param_1 + 0x74);
  if (((int)param_5 < 1) && ((int)param_5 < 0)) {
    auStack_c[0] = ~param_4;
    uVar2 = ~param_5;
  }
  else {
    auStack_c[0] = param_4;
    uVar2 = param_5;
  }
  FUN_00606ff0(&param_3,(uVar2 >> 2) + uVar2 * 0x40 + param_4 ^ uVar2,&param_4,
               -(uint)(iVar4 != 0) & iVar4 + 1U);
  if (param_3 == 0) {
    iVar4 = *(int *)(param_1 + 0x7c);
    uVar2 = FUN_01679ce0();
    if (uVar2 % (iVar4 + 1U) == 0) {
      if ((undefined4 *)(param_1 + 0x10) != param_6) {
        puVar3 = param_6;
        if (0xf < (uint)param_6[5]) {
          puVar3 = (undefined4 *)*param_6;
        }
        FUN_005542c0(puVar3,param_6[4]);
      }
      if ((undefined4 *)(param_1 + 0x44) != param_7) {
        puVar3 = param_7;
        if (0xf < (uint)param_7[5]) {
          puVar3 = (undefined4 *)*param_7;
        }
        FUN_005542c0(puVar3,param_7[4]);
      }
      if ((undefined4 *)(param_1 + 0x5c) != param_8) {
        puVar3 = param_8;
        if (0xf < (uint)param_8[5]) {
          puVar3 = (undefined4 *)*param_8;
        }
        FUN_005542c0(puVar3,param_8[4]);
      }
    }
    FUN_00a774a0(auStack_c,&param_4,&param_4);
  }
  return;
}



/* FUNCTION 21491 ; VA 0x00a7f000 ; FUN_00a7f000 */

void __thiscall
FUN_00a7f000(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,uint param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined4 in_stack_00000028;
  uint in_stack_0000002c;
  int in_stack_00000030;
  uint in_stack_00000044;
  undefined4 in_stack_ffffff14;
  undefined4 uVar7;
  int *piVar8;
  uint *puVar9;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e41f3;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_016830f0(&uStack_18);
  FUN_00fa1110(auStack_3c,param_5);
  uStack_8._0_1_ = 2;
  iVar5 = param_1 + 0xa5 + (uint)*(byte *)(param_1 + 0xa4);
  uVar2 = FUN_005702d0(auStack_3c);
  uVar6 = -(uint)(iVar5 != 0) & iVar5 + 1U;
  puVar9 = auStack_3c;
  piVar8 = &iStack_20;
  uVar7 = 0xa7f07f;
  FUN_00562fc0(piVar8,uVar2,puVar9,uVar6);
  uVar1 = uStack_14;
  uVar3 = uStack_18;
  if (iStack_20 == 0) {
    if (DAT_01d663c0 <= *(uint *)(iStack_1c + 0xac)) goto LAB_00a7f119;
    FUN_0054ef60(param_6);
    uVar3 = FUN_00a7c080(uVar3,uVar1,in_stack_ffffff14,uVar7,piVar8,uVar2,puVar9,uVar6);
    uStack_8._0_1_ = 3;
    FUN_00a77190(auStack_24,auStack_3c,auStack_3c,uVar3);
    uStack_8._0_1_ = 2;
    FUN_00a7d100();
  }
  FUN_00a7eef0(uStack_18,uStack_14,param_2,param_3,param_4,param_5,&param_7,&stack0x00000030);
LAB_00a7f119:
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar6 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar6 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar4);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  if (0xf < in_stack_0000002c) {
    uVar4 = in_stack_0000002c + 1;
    uVar6 = param_7;
    if (0xfff < uVar4) {
      uVar6 = *(uint *)(param_7 - 4);
      uVar4 = in_stack_0000002c + 0x24;
      if (0x1f < (param_7 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar4);
  }
  in_stack_00000028 = 0;
  in_stack_0000002c = 0xf;
  param_7 = param_7 & 0xffffff00;
  if (0xf < in_stack_00000044) {
    uVar6 = in_stack_00000044 + 1;
    iVar5 = in_stack_00000030;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(in_stack_00000030 + -4);
      uVar6 = in_stack_00000044 + 0x24;
      if (0x1f < (in_stack_00000030 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21492 ; VA 0x00a7f200 ; FUN_00a7f200 */

void FUN_00a7f200(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  int *piVar1;
  uint uVar2;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [4];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e4218;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eeaa44);
  uStack_48 = 0;
  uVar2 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_48 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_7 + 2;
      uStack_58 = 0xa7f27a;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_7[2];
      uStack_3c = param_7[3];
      uStack_38 = param_7[4];
      uStack_34 = param_7[5];
      uStack_30 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar2 = *param_6;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_6 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_6[2];
      uStack_ac = param_6[3];
      uStack_a8 = param_6[4];
      uStack_a4 = param_6[5];
      uStack_a0 = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_008e5f10);
  uStack_98 = 0xa7f2f1;
  FUN_008dc050();
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_70 = *param_5;
  uStack_6c = param_5[1];
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_8c = param_4;
  uStack_90 = 0xa7f32f;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_8c = 0xa7f33c;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21493 ; VA 0x00a7f350 ; FUN_00a7f350 */

void FUN_00a7f350(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uStack_b8;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined auStack_9c [24];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_60;
  uint *puStack_5c;
  uint *puStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  undefined8 uStack_38;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0738;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eeaa44);
  uVar1 = *param_5;
  uVar2 = param_5[1];
  uVar3 = *param_4;
  uVar4 = param_4[1];
  uStack_50 = 0;
  uVar5 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    uStack_50 = uVar5;
    if ((uVar5 & 1) == 0) {
      puStack_58 = &uStack_48;
      uStack_54 = 0;
      puStack_5c = param_7 + 2;
      uStack_60 = 0xa7f3e6;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))();
    }
    else {
      uStack_48 = param_7[2];
      uStack_44 = param_7[3];
      uStack_40 = param_7[4];
      uStack_3c = param_7[5];
      uStack_38 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_74 = 0;
  uStack_a0 = param_1;
  uVar5 = *param_6;
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(param_6 + 2,&uStack_b8,0);
    }
    else {
      uStack_b8 = param_6[2];
      uStack_b4 = param_6[3];
      uStack_b0 = param_6[4];
      uStack_ac = param_6[5];
      uStack_a8 = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0(auStack_9c,FUN_008e61f0);
  uStack_a0 = 0xa7f45a;
  FUN_008dc4b0();
  uStack_8 = 0xffffffff;
  uStack_84 = 0xa7f473;
  uStack_80 = uVar3;
  uStack_7c = uVar4;
  uStack_78 = uVar1;
  uStack_74 = uVar2;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21494 ; VA 0x00a7f490 ; FUN_00a7f490 */

void FUN_00a7f490(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,undefined4 *param_6,uint *param_7,uint *param_8)

{
  int *piVar1;
  uint uVar2;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined4 auStack_94 [7];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e4250;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eeaa44);
  uStack_48 = 0;
  uVar2 = *param_8;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_48 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_8 + 2;
      uStack_58 = 0xa7f50a;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_8[2];
      uStack_3c = param_8[3];
      uStack_38 = param_8[4];
      uStack_34 = param_8[5];
      uStack_30 = *(undefined8 *)(param_8 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar2 = *param_7;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_7 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_7[2];
      uStack_ac = param_7[3];
      uStack_a8 = param_7[4];
      uStack_a4 = param_7[5];
      uStack_a0 = *(undefined8 *)(param_7 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_008e5f10);
  uStack_98 = 0xa7f581;
  FUN_008dc050();
  if (param_6[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_70 = *param_6;
  uStack_6c = param_6[1];
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_78 = *param_5;
  uStack_74 = param_5[1];
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  auStack_94[0] = param_4;
  uStack_98 = 0xa7f5ec;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  auStack_94[0] = 0xa7f5f9;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21495 ; VA 0x00a7f610 ; FUN_00a7f610 */

void __thiscall FUN_00a7f610(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  undefined4 *puVar1;
  bool bVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined8 uVar9;
  longlong lVar10;
  uint in_stack_0000002c;
  char *pcVar11;
  undefined4 uVar12;
  undefined uVar13;
  undefined4 in_stack_ffffffa8;
  undefined4 in_stack_ffffffac;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined auStack_38 [24];
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4280;
  pvStack_10 = ExceptionList;
  iVar8 = 0;
  iStack_14 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_01eea9bc);
  uStack_8._0_1_ = 2;
  uVar14 = 0xa7f656;
  uStack_18 = uVar4;
  iVar5 = FUN_008f7870(param_1);
  if (iVar5 == 0) {
    uVar12 = 0xc;
    pcVar11 = "No DataModel";
  }
  else {
    if (iVar5 != -0xc) {
      piVar6 = (int *)FUN_00564080();
      iStack_14 = *piVar6;
      if (iStack_14 != 0) {
        piVar6 = &iStack_20;
        uVar14 = 0xa7f691;
        FUN_0097fc00(piVar6,param_2,param_3);
        uStack_8._0_1_ = 3;
        if ((*(int *)(iVar5 + 0x4a0) == 2) || (*(int *)(iVar5 + 0x4a0) == 3)) {
          if (iStack_20 == 0) {
            uVar12 = 0x30;
            pcVar11 = "The user must be connected to the current server";
            goto LAB_00a7f7ca;
          }
          if (DAT_01d664c0 != '\0') {
            puVar7 = (undefined4 *)FUN_00927520(auStack_38);
            iVar8 = 1;
            puVar1 = puVar7 + 4;
            if (0xf < (uint)puVar7[5]) {
              puVar7 = (undefined4 *)*puVar7;
            }
            cVar3 = FUN_0055c360(puVar7,*puVar1,"Durango",7);
            bVar2 = true;
            if (cVar3 != '\0') goto LAB_00a7f72f;
          }
          bVar2 = false;
LAB_00a7f72f:
          if (iVar8 != 0) {
            FUN_005507b0();
          }
          if (bVar2) {
            FUN_008927d0(0);
          }
          else {
            FUN_008927d0(*(int *)(iStack_20 + 0xec) != 1);
          }
        }
        else {
          if (((iStack_20 != 0) && (*(int *)(iStack_14 + 0xf4) != 0)) &&
             (iStack_20 == *(int *)(iStack_14 + 0xf4))) {
            uVar9 = FUN_00928340();
            iStack_14 = (int)((ulonglong)uVar9 >> 0x20);
            lVar10 = FUN_00928340();
            if (lVar10 == CONCAT44(iStack_14,(int)uVar9)) {
              if (DAT_01d664c0 != '\0') {
                puVar7 = (undefined4 *)FUN_01530500(auStack_38);
                iVar8 = 2;
                puVar1 = puVar7 + 4;
                if (0xf < (uint)puVar7[5]) {
                  puVar7 = (undefined4 *)*puVar7;
                }
                cVar3 = FUN_0055c360(puVar7,*puVar1,"Durango",7);
                bVar2 = true;
                if (cVar3 != '\0') goto LAB_00a7f72f;
              }
              bVar2 = false;
              goto LAB_00a7f72f;
            }
          }
          uVar12 = 0x38;
          pcVar11 = "Must only be called for the local user fom local scripts";
LAB_00a7f7ca:
          uVar15 = 0;
          uVar16 = 0xf;
          uVar13 = 0;
          FUN_005542c0(pcVar11,uVar12);
          FUN_005e65e0(uVar13,in_stack_ffffffa8,uVar14,piVar6,uVar15,uVar16);
        }
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar8 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            piVar6 = piStack_1c + 2;
            iVar8 = *piVar6;
            *piVar6 = *piVar6 + -1;
            UNLOCK();
            if (iVar8 == 1) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
        goto LAB_00a7f84a;
      }
    }
    uVar12 = 0x12;
    pcVar11 = "No Players service";
  }
  uVar15 = 0;
  uVar16 = 0xf;
  uVar13 = 0;
  FUN_005542c0(pcVar11,uVar12);
  FUN_005e65e0(uVar13,in_stack_ffffffa8,in_stack_ffffffac,uVar14,uVar15,uVar16);
LAB_00a7f84a:
  uStack_8._0_1_ = 4;
  FUN_01675290(uVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21496 ; VA 0x00a7f8c0 ; FUN_00a7f8c0 */

void FUN_00a7f8c0(undefined4 param_1,undefined4 param_2,char *param_3,undefined4 param_4,
                 uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined8 param_11,uint param_12)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  uint *puVar6;
  uint auStack_a4 [2];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  char *pcStack_84;
  undefined4 uStack_80;
  undefined uStack_7c;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  int *piStack_70;
  undefined8 uStack_6c;
  undefined auStack_5c [24];
  undefined auStack_44 [24];
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e42d9;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)0x0;
  uStack_6c._4_4_ = (undefined *)DAT_01eea9bc;
  uStack_8 = 1;
  uStack_6c._0_4_ = (char *)0xa7f8f8;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290();
  uStack_8._0_1_ = 2;
  piStack_70 = (int *)0xa7f907;
  uStack_1c = uVar4;
  iVar5 = FUN_008f7870();
  if (iVar5 == 0) {
    uStack_80 = 0xc;
    pcStack_84 = "No DataModel";
LAB_00a7fbb5:
    uStack_6c._0_4_ = (char *)0x0;
    uStack_6c._4_4_ = (undefined *)0xf;
    uStack_7c = 0;
    uStack_8c = CONCAT44(0xa7fbcb,(undefined4)uStack_8c);
    FUN_005542c0();
    uStack_80 = 0xa7fbd3;
    FUN_005e65e0();
  }
  else {
    if (iVar5 == -0xc) {
LAB_00a7fb9b:
      uStack_80 = 0x12;
      pcStack_84 = "No Players service";
      goto LAB_00a7fbb5;
    }
    uStack_6c._4_4_ = (undefined *)0xa7f924;
    puVar6 = (uint *)FUN_00564080();
    uStack_14 = *puVar6;
    if (uStack_14 == 0) goto LAB_00a7fb9b;
    uStack_6c._4_4_ = (undefined *)param_2;
    piStack_70 = &iStack_2c;
    uStack_6c._0_4_ = (char *)param_1;
    puStack_74 = (undefined4 *)0xa7f942;
    FUN_0097fc00();
    uStack_6c._4_4_ = (undefined *)param_4;
    piStack_70 = &iStack_24;
    uStack_6c._0_4_ = param_3;
    uStack_8._0_1_ = 3;
    puStack_74 = (undefined4 *)0xa7f958;
    FUN_0097fc00();
    uStack_8._0_1_ = 4;
    if ((*(int *)(iVar5 + 0x4a0) == 2) || (*(int *)(iVar5 + 0x4a0) == 3)) {
      if ((iStack_2c == 0) || (iStack_24 == 0)) {
        uStack_80 = 0x32;
        pcStack_84 = "Both users must be connected to the current server";
        goto LAB_00a7fb28;
      }
      if (DAT_01d664c0 != '\0') {
        uStack_6c._4_4_ = auStack_5c;
        uStack_6c._0_4_ = (char *)0xa7f9a9;
        puStack_74 = (undefined4 *)FUN_00927520();
        uStack_14 = 1;
        puStack_18 = (undefined *)0x1;
        piStack_70 = (int *)puStack_74[4];
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        if (0xf < (uint)puStack_74[5]) {
          puStack_74 = (undefined4 *)*puStack_74;
        }
        uStack_6c._4_4_ = (undefined *)0x7;
        uStack_6c._0_4_ = "Durango";
        uStack_78 = 0xa7f9d1;
        cVar3 = FUN_0055c360();
        if (cVar3 == '\0') {
          uStack_6c._4_4_ = auStack_44;
          uStack_6c._0_4_ = (char *)0xa7f9e4;
          puStack_74 = (undefined4 *)FUN_00927520();
          uStack_14 = 3;
          piStack_70 = (int *)puStack_74[4];
          if (0xf < (uint)puStack_74[5]) {
            puStack_74 = (undefined4 *)*puStack_74;
          }
          uStack_6c._4_4_ = (undefined *)0x7;
          uStack_6c._0_4_ = "Durango";
          uStack_78 = 0xa7fa04;
          cVar3 = FUN_0055c360();
          bVar2 = false;
          if (cVar3 != '\0') goto LAB_00a7fa0f;
        }
        else {
LAB_00a7fa0f:
          bVar2 = true;
        }
        if ((uStack_14 & 2) != 0) {
          uStack_6c._4_4_ = (undefined *)0xa7fa21;
          FUN_005507b0();
        }
        uStack_8._0_1_ = 4;
        uStack_8._1_3_ = 0;
        uStack_6c._4_4_ = (undefined *)0xa7fa30;
        FUN_005507b0();
        if (!bVar2) goto LAB_00a7fa3c;
LAB_00a7fa4e:
        uStack_6c._4_4_ = (undefined *)0x0;
        uStack_6c._0_4_ = (char *)0xa7fa58;
        FUN_008927d0();
        uStack_6c._4_4_ = (undefined *)0xa7fa60;
        FUN_00550b30();
        uStack_6c._4_4_ = (undefined *)0xa7fa68;
        FUN_00550b30();
        uStack_8._0_1_ = 7;
        goto LAB_00a7fbd7;
      }
LAB_00a7fa3c:
      uStack_6c._4_4_ = (undefined *)0xa7fa41;
      uStack_6c = FUN_00928340();
      piStack_70 = (int *)0xa7fa4a;
      cVar3 = FUN_00928c30();
      if (cVar3 != '\0') goto LAB_00a7fa4e;
      if (*(int *)(iStack_2c + 0xec) == 0) {
        if (*(int *)(iStack_24 + 0xec) == 0) {
          uStack_6c._4_4_ = (undefined *)0x1;
          uStack_6c._0_4_ = (char *)0xa7fa95;
          FUN_008927d0();
        }
        else {
LAB_00a7fa9f:
          if (*(int *)(iStack_24 + 0xec) == 1) goto LAB_00a7fb10;
          uStack_8c = CONCAT44(&param_12,0xa7fab5);
          FUN_0054f510();
          puStack_18 = (undefined *)auStack_a4;
          uStack_8._0_1_ = 8;
          auStack_a4[0] = 0;
          puVar6 = auStack_a4;
          if (param_5 != 0) {
            auStack_a4[0] = param_5;
            if ((param_5 & 1) == 0) {
              (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_9c,0);
              puVar6 = (uint *)puStack_18;
            }
            else {
              uStack_9c = param_7;
              uStack_98 = param_8;
              uStack_94 = param_9;
              uStack_90 = param_10;
              uStack_8c = param_11;
              puVar6 = auStack_a4;
            }
          }
          puStack_18 = (undefined *)puVar6;
          uStack_8._0_1_ = 4;
          FUN_00929bb0(param_1,param_2);
        }
      }
      else {
        if (*(int *)(iStack_2c + 0xec) != 1) goto LAB_00a7fa9f;
LAB_00a7fb10:
        uStack_6c._4_4_ = (undefined *)0x0;
        uStack_6c._0_4_ = (char *)0xa7fb1a;
        FUN_008927d0();
      }
    }
    else {
      uStack_80 = 0x27;
      pcStack_84 = "Must only be called from server scripts";
LAB_00a7fb28:
      uStack_6c._0_4_ = (char *)0x0;
      uStack_6c._4_4_ = (undefined *)0xf;
      uStack_7c = 0;
      uStack_8c = CONCAT44(0xa7fb3e,(undefined4)uStack_8c);
      FUN_005542c0();
      uStack_80 = 0xa7fb46;
      FUN_005e65e0();
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_6c._4_4_ = (undefined *)0xa7fb5d;
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_6c._4_4_ = (undefined *)0xa7fb70;
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_28[1] + -1;
      piStack_28[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_6c._4_4_ = (undefined *)0xa7fb87;
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piStack_28 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          uStack_6c._4_4_ = (undefined *)0xa7fb99;
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
  }
  uStack_8._0_1_ = 9;
LAB_00a7fbd7:
  uStack_6c._0_4_ = (char *)0xa7fbdd;
  uStack_6c._4_4_ = (undefined *)uVar4;
  FUN_01675290();
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    piStack_70 = &param_7;
    uStack_6c._4_4_ = (undefined *)0x2;
    puStack_74 = (undefined4 *)0xa7fc01;
    uStack_6c._0_4_ = (char *)piStack_70;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 0xb;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    piStack_70 = (int *)&stack0x0000003c;
    uStack_6c._4_4_ = (undefined *)0x2;
    puStack_74 = (undefined4 *)0xa7fc2f;
    uStack_6c._0_4_ = (char *)piStack_70;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21497 ; VA 0x00a7fc50 ; FUN_00a7fc50 */

int FUN_00a7fc50(undefined4 param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4300;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00a7fd30(param_1,param_2);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar4 = in_stack_00000020 + 1;
    iVar3 = param_3;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_3 + -4);
      uVar4 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 21498 ; VA 0x00a7fd30 ; FUN_00a7fd30 */

/* WARNING: Removing unreachable block (ram,0x00a7ff8f) */
/* WARNING: Removing unreachable block (ram,0x00a7ff9d) */
/* WARNING: Removing unreachable block (ram,0x00a7fff4) */
/* WARNING: Removing unreachable block (ram,0x00a7ffad) */

void __thiscall FUN_00a7fd30(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  int in_stack_0000001c;
  undefined4 in_stack_00000024;
  char in_stack_00000028;
  undefined4 uVar9;
  undefined *puVar10;
  undefined4 in_stack_ffffff9c;
  undefined4 in_stack_ffffffa0;
  undefined4 in_stack_ffffffa4;
  undefined8 in_stack_ffffffa8;
  int iVar11;
  char *pcVar12;
  undefined4 uVar13;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4330;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  iStack_14 = param_1;
  if (param_2 == 0) {
    pcVar12 = "partOrCharacter must be non-nil";
    ExceptionList = &pvStack_10;
  }
  else {
    iVar11 = 0xa7fd68;
    ExceptionList = &pvStack_10;
    cVar4 = FUN_008b0500(param_2);
    iVar2 = param_2;
    if (cVar4 == '\0') {
      pcVar12 = "partOrCharacter must be in the Workspace";
    }
    else {
      iVar8 = *(int *)(param_2 + 0xc);
      iVar5 = FUN_00b63e30();
      iVar3 = param_2;
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        iVar7 = iVar2;
      }
      if (iVar7 == 0) {
        iVar2 = *(int *)(param_2 + 0xc);
        iVar7 = FUN_00aff8c0();
        iVar8 = 0;
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
            (uint)*(ushort *)(iVar7 + 0x1da)) {
          iVar8 = iVar3;
        }
        if (iVar8 == 0) {
          pcVar12 = "partOrCharacter must be a Part or a Character";
          goto LAB_00a7ffde;
        }
      }
      else {
        if (iStack_14 != 0) {
          iVar2 = *(int *)(iStack_14 + 0x34);
          iVar11 = iStack_14;
          if ((iVar2 != 0) && (iVar11 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
            iVar11 = FUN_005c8ac0();
          }
          if ((iVar11 != 0) &&
             (iVar2 = *(int *)(iVar11 + 0xc), iVar11 = FUN_008a8c30(),
             (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar11 + 0x1d8) <=
             (uint)*(ushort *)(iVar11 + 0x1da))) {
            FUN_0055e560();
          }
        }
        if (param_3 != 0) {
          LOCK();
          *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
          UNLOCK();
        }
        in_stack_ffffffa8 = CONCAT44(&uStack_24,0xa7fe2d);
        iVar11 = param_2;
        piVar6 = (int *)FUN_00988f90();
        iVar2 = *piVar6;
        FUN_00550b30();
        if (iVar2 == 0) {
          pcVar12 = "partOrCharacter is not a legal character";
          goto LAB_00a7ffde;
        }
      }
      if (in_stack_0000001c != 0) {
        puVar10 = &stack0x0000000c;
        if (in_stack_00000028 == '\0') {
          FUN_0054ef60(puVar10);
          FUN_00557fc0(&param_2);
          piVar6 = piStack_18;
          uVar13 = uStack_1c;
          uStack_24 = 0;
          uStack_20 = 0;
          uStack_8 = CONCAT31(uStack_8._1_3_,3);
          uStack_1c = 0;
          piStack_18 = (int *)0x0;
          FUN_00a87900(iStack_14,uVar13,piVar6,uStack_40,uStack_3c,uStack_38,uStack_34,
                       CONCAT44(uStack_2c,uStack_30),in_stack_00000024,&uStack_24);
          piVar6 = piStack_18;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_18[1] + -1;
            piStack_18[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_18)();
              LOCK();
              piVar1 = piVar6 + 2;
              iVar2 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar2 == 1) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
        }
        else {
          uVar9 = 0xa7fea3;
          uVar13 = in_stack_00000024;
          FUN_0054ef60(puVar10);
          FUN_00557fc0(&param_2);
          FUN_00a87dd0(iStack_14,uVar9,puVar10,in_stack_ffffff9c,in_stack_ffffffa0,in_stack_ffffffa4
                       ,in_stack_ffffffa8,iVar11,uVar13);
        }
        FUN_00550b30();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
      pcVar12 = "message must be non-empty";
    }
  }
LAB_00a7ffde:
  FUN_00550130(pcVar12);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_28,&DAT_01c17198);
}



/* FUNCTION 21499 ; VA 0x00a80000 ; FUN_00a80000 */

int FUN_00a80000(undefined4 param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4300;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00a7fd30(param_1,param_2);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar4 = in_stack_00000020 + 1;
    iVar3 = param_3;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_3 + -4);
      uVar4 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}


