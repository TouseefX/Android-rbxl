/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 6250 ; VA 0x00603f40 ; FUN_00603f40 */

void __thiscall
FUN_00603f40(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x108420e < (uint)param_1[1]) {
    FUN_00617080(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00603ff2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00603ff2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 6251 ; VA 0x006040a0 ; FUN_006040a0 */

undefined4 * __thiscall
FUN_006040a0(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cca0;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00603f40(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    piVar3 = param_3 + 4;
    if (0xf < (uint)param_3[9]) {
      piVar3 = (int *)*piVar3;
    }
    puVar4 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar4 = (undefined4 *)*param_4;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    iVar2 = FUN_0055c2d0(puVar4,param_4[4],piVar3,param_3[8]);
    if (iVar2 < 0) {
      FUN_00603f40(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar2 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_00570370(iVar2 + 0x10,param_4);
    if (cVar1 != '\0') {
      FUN_00603f40(param_2,0,iVar2,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00570370(param_4,param_3 + 4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar1 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar1 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00603f40(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00603f40(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar1 = FUN_00570370(param_3 + 4,param_4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      FUN_00551320();
      piVar3 = piStack_18;
      if ((piStack_18 == (int *)*param_1) ||
         (cVar1 = FUN_00570370(param_4,piStack_18 + 4), cVar1 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00603f40(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00603f40(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = (undefined4 *)FUN_00604300(auStack_20,0,param_4,param_5);
  *param_2 = *puVar4;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6252 ; VA 0x006042e6 ; Catch_All@006042e6 */

void Catch_All_006042e6(void)

{
  int unaff_EBP;
  
  FUN_00617080(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6253 ; VA 0x00604300 ; FUN_00604300 */

void __thiscall
FUN_00604300(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  byte bVar4;
  int *piVar5;
  byte extraout_var;
  byte extraout_var_00;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  undefined4 *puVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar6 = param_4;
  puStack_c = &LAB_0179ccb0;
  piVar7 = (int *)*param_1;
  bVar4 = 1;
  uStack_8 = 0;
  cVar1 = *(char *)(piVar7[1] + 0xd);
  piVar5 = piVar7;
  piVar2 = (int *)piVar7[1];
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while (cVar1 == '\0') {
    piVar5 = piVar2 + 4;
    if ((char)param_3 == '\0') {
      if (0xf < (uint)piVar2[9]) {
        piVar5 = (int *)*piVar5;
      }
      puVar9 = puVar6;
      if (0xf < (uint)puVar6[5]) {
        puVar9 = (undefined4 *)*puVar6;
      }
      FUN_0055c2d0(puVar9,puVar6[4],piVar5,piVar2[8]);
      bVar4 = extraout_var_00 >> 7;
    }
    else {
      puVar9 = puVar6;
      if (0xf < (uint)puVar6[5]) {
        puVar9 = (undefined4 *)*puVar6;
      }
      if (0xf < (uint)piVar2[9]) {
        piVar5 = (int *)*piVar5;
      }
      FUN_0055c2d0(piVar5,piVar2[8],puVar9,puVar6[4]);
      bVar4 = extraout_var >> 7 ^ 1;
    }
    if (bVar4 == 0) {
      piVar10 = (int *)piVar2[2];
    }
    else {
      piVar10 = (int *)*piVar2;
    }
    piVar5 = piVar2;
    piVar2 = piVar10;
    cVar1 = *(char *)((int)piVar10 + 0xd);
  }
  param_3 = piVar5;
  if (bVar4 != 0) {
    if (piVar5 == (int *)*piVar7) {
      bVar4 = 1;
      goto LAB_006043cc;
    }
    FUN_0056f560();
  }
  piVar2 = param_3;
  piVar7 = param_3 + 4;
  puVar9 = puVar6;
  if (0xf < (uint)puVar6[5]) {
    puVar9 = (undefined4 *)*puVar6;
  }
  if (0xf < (uint)param_3[9]) {
    piVar7 = (int *)*piVar7;
  }
  iVar8 = FUN_0055c2d0(piVar7,param_3[8],puVar9,puVar6[4]);
  uVar3 = param_5;
  if (-1 < iVar8) {
    FUN_0056cb40();
    FUN_01674ea0(uVar3,0xf8);
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_006043cc:
  puVar6 = (undefined4 *)FUN_00603f40(&param_3,bVar4,piVar5,puVar6,param_5);
  *param_2 = *puVar6;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6254 ; VA 0x0060446d ; Catch_All@0060446d */

void Catch_All_0060446d(void)

{
  int unaff_EBP;
  
  FUN_00617080(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6255 ; VA 0x00604490 ; FUN_00604490 */

void __thiscall FUN_00604490(uint *param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ccc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar3 = (param_3 - param_2) / 0x18;
  param_1[1] = 0;
  param_1[2] = 0;
  if (uVar3 != 0) {
    if (0xaaaaaaa < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar3 = uVar3 * 0x18;
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar3);
      }
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar3;
    uVar3 = *param_1;
    uStack_8 = 1;
    for (; param_2 != param_3; param_2 = param_2 + 0x18) {
      FUN_0054ef60(param_2);
      uVar3 = uVar3 + 0x18;
    }
    FUN_00559570(uVar3,uVar3,param_1);
    param_1[1] = uVar3;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6256 ; VA 0x006045ab ; Catch_All@006045ab */

void Catch_All_006045ab(void)

{
  FUN_00577a40();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6257 ; VA 0x006045c0 ; FUN_006045c0 */

void __thiscall FUN_006045c0(int *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179cce0;
  pvStack_10 = ExceptionList;
  uVar1 = (param_1[1] - *param_1) / 0xd0;
  uVar2 = (param_1[2] - *param_1) / 0xd0;
  if (param_2 <= uVar2) {
    if (param_2 <= uVar1) {
      if (param_2 != uVar1) {
        iVar3 = param_2 * 0xd0 + *param_1;
        ExceptionList = &pvStack_10;
        FUN_00559720(iVar3,param_1[1],param_1);
        param_1[1] = iVar3;
      }
      ExceptionList = pvStack_10;
      return;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00577ba0(param_1[1],param_2 - uVar1);
    param_1[1] = iVar3;
    ExceptionList = pvStack_10;
    return;
  }
  if (0x13b13b1 < param_2) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar4 = param_2;
  if ((uVar2 <= 0x13b13b1 - (uVar2 >> 1)) && (uVar4 = (uVar2 >> 1) + uVar2, uVar4 < param_2)) {
    uVar4 = param_2;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00578090(uVar4);
  uStack_8 = 0;
  FUN_00577ba0(uVar1 * 0xd0 + iVar3,param_2 - uVar1);
  FUN_0055c5a0(*param_1,param_1[1],iVar3,param_1);
  uStack_8 = 0xffffffff;
  FUN_005cb2e0(iVar3,param_2,uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6258 ; VA 0x0060471a ; Catch_All@0060471a */

void Catch_All_0060471a(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  FUN_005762e0(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x14));
  uVar2 = *(undefined4 *)(unaff_EBP + -0x18);
  uVar1 = *(undefined4 *)(unaff_EBP + 8);
  FUN_0054eb90(uVar1,uVar2);
  FUN_0057d370(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6259 ; VA 0x00604750 ; FUN_00604750 */

void __thiscall FUN_00604750(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179ccf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count<class_std::map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_std::less<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6260 ; VA 0x006047be ; Catch_All@006047be */

void Catch_All_006047be(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_006153b0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6261 ; VA 0x006047e0 ; FUN_006047e0 */

void __thiscall FUN_006047e0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cd00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6262 ; VA 0x0060484e ; Catch_All@0060484e */

void Catch_All_0060484e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00573320(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6263 ; VA 0x00604870 ; FUN_00604870 */

int __thiscall FUN_00604870(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cd10;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::DeserializePacketsJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6264 ; VA 0x00604944 ; Catch_All@00604944 */

void Catch_All_00604944(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6265 ; VA 0x00604960 ; FUN_00604960 */

void __thiscall FUN_00604960(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cd20;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedTouchItemS2>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6266 ; VA 0x006049ce ; Catch_All@006049ce */

void Catch_All_006049ce(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6267 ; VA 0x006049f0 ; FUN_006049f0 */

void __thiscall FUN_006049f0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cd30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializePacketsJob::DummyArbiter>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6268 ; VA 0x00604a5e ; Catch_All@00604a5e */

void Catch_All_00604a5e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6269 ; VA 0x00604a80 ; FUN_00604a80 */

void __thiscall FUN_00604a80(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cd40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::NetworkStream>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6270 ; VA 0x00604aee ; Catch_All@00604aee */

void Catch_All_00604aee(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6271 ; VA 0x00604b10 ; FUN_00604b10 */

int __thiscall FUN_00604b10(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cd50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::Replicator::PingJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6272 ; VA 0x00604be4 ; Catch_All@00604be4 */

void Catch_All_00604be4(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6273 ; VA 0x00604c00 ; FUN_00604c00 */

int __thiscall FUN_00604c00(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cd60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::Replicator::ProcessPacketsJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6274 ; VA 0x00604cd4 ; Catch_All@00604cd4 */

void Catch_All_00604cd4(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6275 ; VA 0x00604cf0 ; FUN_00604cf0 */

int __thiscall FUN_00604cf0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cd70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::Replicator::SendDataJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6276 ; VA 0x00604dc4 ; Catch_All@00604dc4 */

void Catch_All_00604dc4(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6277 ; VA 0x00604de0 ; FUN_00604de0 */

int __thiscall FUN_00604de0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cd80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::Marker*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6278 ; VA 0x00604eb2 ; Catch_All@00604eb2 */

void Catch_All_00604eb2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6279 ; VA 0x00604ed0 ; FUN_00604ed0 */

undefined4 *
FUN_00604ed0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar6 = param_3;
  if (param_1 != param_2) {
    puVar4 = param_1 + 1;
    puVar5 = param_3 + 2;
    do {
      uVar3 = puVar4[-1];
      puVar1 = puVar4 + 3;
      *(undefined4 *)((int)param_3 + (-0xc - (int)param_1) + (int)puVar1) = 0;
      *puVar5 = 0;
      *puVar6 = uVar3;
      puVar6 = puVar6 + 3;
      *(undefined4 *)((int)param_3 + (-0xc - (int)param_1) + (int)puVar1) = *puVar4;
      *puVar5 = puVar4[1];
      puVar2 = puVar4 + 2;
      *puVar4 = 0;
      puVar4[1] = 0;
      puVar4 = puVar1;
      puVar5 = puVar5 + 3;
    } while (puVar2 != param_2);
  }
  FUN_00602e00(puVar6,puVar6,param_4);
  return puVar6;
}



/* FUNCTION 6280 ; VA 0x00604f50 ; FUN_00604f50 */

void __thiscall FUN_00604f50(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  uVar3 = FUN_0088c8c0();
  *puVar1 = uVar3;
  iVar4 = FUN_005c9cc0();
  iVar2 = puVar1[1];
  if (iVar2 == iVar4) {
    puVar1[2] = *param_2;
    return;
  }
  if (iVar2 != 0) {
    (**(code **)(iVar2 + 8))(puVar1 + 2);
    puVar1[1] = 0;
  }
  puVar1[2] = *param_2;
  puVar1[1] = iVar4;
  return;
}



/* FUNCTION 6281 ; VA 0x00604fb0 ; FUN_00604fb0 */

void __thiscall FUN_00604fb0(undefined4 *param_1,undefined4 param_2)

{
  if (param_1[1] != 0) {
    (**(code **)(**(int **)(param_1[1] + 0x34) + 0x10))(*param_1,param_2);
  }
  return;
}



/* FUNCTION 6282 ; VA 0x00604fd0 ; FUN_00604fd0 */

void __thiscall FUN_00604fd0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  uVar3 = FUN_0088cb40();
  *puVar1 = uVar3;
  iVar4 = FUN_005c9d30();
  iVar2 = puVar1[1];
  if (iVar2 == iVar4) {
    if (puVar1 + 2 != param_2) {
      puVar1 = param_2 + 4;
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      FUN_005542c0(param_2,*puVar1);
      return;
    }
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(puVar1 + 2);
      puVar1[1] = 0;
    }
    FUN_0054ef60(param_2);
    puVar1[1] = iVar4;
  }
  return;
}



/* FUNCTION 6283 ; VA 0x00605040 ; FUN_00605040 */

void __thiscall FUN_00605040(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  uVar3 = FUN_0088cf00();
  *puVar1 = uVar3;
  iVar4 = FUN_00630ac0();
  iVar2 = puVar1[1];
  if (iVar2 == iVar4) {
    if (puVar1 + 2 != param_2) {
      puVar1 = param_2 + 4;
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      FUN_005542c0(param_2,*puVar1);
      return;
    }
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(puVar1 + 2);
      puVar1[1] = 0;
    }
    FUN_0054ef60(param_2);
    puVar1[1] = iVar4;
  }
  return;
}



/* FUNCTION 6284 ; VA 0x006050b0 ; FUN_006050b0 */

void __thiscall FUN_006050b0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  uVar5 = FUN_00b00260();
  *puVar1 = uVar5;
  iVar6 = FUN_00630d60();
  iVar2 = puVar1[1];
  if (iVar2 == iVar6) {
    uVar5 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    puVar1[2] = *param_2;
    puVar1[3] = uVar5;
    puVar1[4] = uVar3;
    puVar1[5] = uVar4;
    uVar5 = param_2[5];
    uVar3 = param_2[6];
    uVar4 = param_2[7];
    puVar1[6] = param_2[4];
    puVar1[7] = uVar5;
    puVar1[8] = uVar3;
    puVar1[9] = uVar4;
    uVar5 = param_2[9];
    uVar3 = param_2[10];
    uVar4 = param_2[0xb];
    puVar1[10] = param_2[8];
    puVar1[0xb] = uVar5;
    puVar1[0xc] = uVar3;
    puVar1[0xd] = uVar4;
    return;
  }
  if (iVar2 != 0) {
    (**(code **)(iVar2 + 8))(puVar1 + 2);
    puVar1[1] = 0;
  }
  uVar5 = param_2[1];
  uVar3 = param_2[2];
  uVar4 = param_2[3];
  puVar1[2] = *param_2;
  puVar1[3] = uVar5;
  puVar1[4] = uVar3;
  puVar1[5] = uVar4;
  uVar5 = param_2[5];
  uVar3 = param_2[6];
  uVar4 = param_2[7];
  puVar1[6] = param_2[4];
  puVar1[7] = uVar5;
  puVar1[8] = uVar3;
  puVar1[9] = uVar4;
  uVar5 = param_2[9];
  uVar3 = param_2[10];
  uVar4 = param_2[0xb];
  puVar1[10] = param_2[8];
  puVar1[0xb] = uVar5;
  puVar1[0xc] = uVar3;
  puVar1[0xd] = uVar4;
  puVar1[1] = iVar6;
  return;
}



/* FUNCTION 6285 ; VA 0x00605130 ; FUN_00605130 */

void __thiscall FUN_00605130(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  uVar3 = FUN_00886600();
  *puVar1 = uVar3;
  iVar4 = FUN_006310e0();
  iVar2 = puVar1[1];
  if (iVar2 == iVar4) {
    FUN_00886840(param_2);
    return;
  }
  if (iVar2 != 0) {
    (**(code **)(iVar2 + 8))(puVar1 + 2);
    puVar1[1] = 0;
  }
  FUN_008866a0(param_2);
  puVar1[1] = iVar4;
  return;
}



/* FUNCTION 6286 ; VA 0x00605190 ; FUN_00605190 */

void __thiscall FUN_00605190(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  
  puVar2 = *(undefined4 **)(param_1 + 4);
  uVar4 = FUN_0088d4b0();
  *puVar2 = uVar4;
  iVar5 = FUN_00631310();
  iVar3 = puVar2[1];
  if (iVar3 == iVar5) {
    iVar3 = *param_2;
    LOCK();
    piVar1 = (int *)(iVar3 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    puVar2[2] = iVar3;
    FUN_0056cd30();
    return;
  }
  if (iVar3 != 0) {
    (**(code **)(iVar3 + 8))(puVar2 + 2);
    puVar2[1] = 0;
  }
  iVar3 = *param_2;
  puVar2[2] = iVar3;
  LOCK();
  piVar1 = (int *)(iVar3 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  puVar2[1] = iVar5;
  return;
}



/* FUNCTION 6287 ; VA 0x00605200 ; FUN_00605200 */

void __thiscall FUN_00605200(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  uVar3 = FUN_0088da50();
  *puVar1 = uVar3;
  iVar4 = FUN_005c9e80();
  iVar2 = puVar1[1];
  if (iVar2 == iVar4) {
    puVar1[2] = *param_2;
    puVar1[3] = param_2[1];
    return;
  }
  if (iVar2 != 0) {
    (**(code **)(iVar2 + 8))(puVar1 + 2);
    puVar1[1] = 0;
  }
  puVar1[2] = *param_2;
  puVar1[3] = param_2[1];
  puVar1[1] = iVar4;
  return;
}



/* FUNCTION 6288 ; VA 0x00605260 ; FUN_00605260 */

void __thiscall FUN_00605260(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_3;
  uStack_14 = param_2;
  uStack_c = param_4;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    param_1[4] = uStack_c;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_018ce2c4;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 6289 ; VA 0x00605370 ; FUN_00605370 */

undefined FUN_00605370(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 *param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  uStack_14 = param_1;
  uStack_10 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_c = param_3;
  piStack_8 = param_4;
  cVar4 = FUN_00585a40(&uStack_14);
  piVar2 = piStack_8;
  if (cVar4 == '\0') {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[1] = piStack_8[1] + 1;
      UNLOCK();
    }
    *param_5 = uStack_14;
    param_5[1] = uStack_10;
    param_5[2] = 0;
    param_5[3] = 0;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[1] = piStack_8[1] + 1;
      UNLOCK();
    }
    param_5[2] = uStack_c;
    param_5[3] = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 6290 ; VA 0x006054a0 ; FUN_006054a0 */

undefined FUN_006054a0(void)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined uVar6;
  int *in_stack_00000010;
  int *in_stack_00000018;
  undefined4 *in_stack_00000024;
  undefined auStack_50 [12];
  int *piStack_44;
  int *piStack_3c;
  undefined auStack_30 [12];
  int *piStack_24;
  int *piStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cda8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0060e1d0(&stack0x00000004);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_30);
  if (cVar3 == '\0') {
    FUN_0060e1d0(auStack_30);
    uStack_8._0_1_ = 2;
    iVar4 = FUN_01674e20(0x20);
    if (iVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_0060e1d0(auStack_50);
    }
    *in_stack_00000024 = uVar5;
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_44[1] + -1;
      piStack_44[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_44)();
        LOCK();
        iVar4 = piStack_44[2] + -1;
        piStack_44[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_44 + 4))();
        }
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar4 = piStack_24[2] + -1;
        piStack_24[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    uVar6 = 1;
  }
  else {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar4 = piStack_24[2] + -1;
        piStack_24[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    uVar6 = 0;
  }
  if (in_stack_00000018 != (int *)0x0) {
    LOCK();
    iVar4 = in_stack_00000018[2] + -1;
    in_stack_00000018[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*in_stack_00000018 + 4))();
    }
  }
  piVar2 = in_stack_00000010;
  if (in_stack_00000010 != (int *)0x0) {
    LOCK();
    iVar4 = in_stack_00000010[1] + -1;
    in_stack_00000010[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*in_stack_00000010)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 6291 ; VA 0x00605630 ; FUN_00605630 */

undefined4 *
FUN_00605630(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            )

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  piVar1 = param_5 + 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0060e560(param_4,param_5,param_6,param_7,param_8,param_9);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piStack_8[1] = piStack_8[1] + 1;
    UNLOCK();
  }
  param_1[2] = uStack_c;
  param_1[3] = piStack_8;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 6292 ; VA 0x00605730 ; FUN_00605730 */

undefined4 *
FUN_00605730(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int in_stack_0000002c;
  int in_stack_00000034;
  int iStack_34;
  int iStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cdd0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0060e970();
  puVar4 = (undefined4 *)FUN_0060e240(param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = param_2;
  param_1[1] = param_3;
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  param_1[2] = *puVar4;
  param_1[3] = uVar1;
  param_1[4] = uVar2;
  param_1[5] = uVar3;
  *(undefined8 *)(param_1 + 6) = *(undefined8 *)(puVar4 + 4);
  FUN_0060e970();
  param_1[0xb] = puVar4[9];
  param_1[0xc] = puVar4[10];
  *(undefined *)(param_1 + 0xe) = *(undefined *)(puVar4 + 0xc);
  param_1[0xf] = puVar4[0xd];
  if (iStack_34 != 0) {
    if (0xfff < (iStack_2c - iStack_34 & 0xfffffff8U)) {
      if (0x1f < (iStack_34 - *(int *)(iStack_34 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  if (in_stack_0000002c != 0) {
    if (0xfff < (in_stack_00000034 - in_stack_0000002c & 0xfffffff8U)) {
      if (0x1f < (in_stack_0000002c - *(int *)(in_stack_0000002c + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6293 ; VA 0x006058b0 ; FUN_006058b0 */

undefined4 *
FUN_006058b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  piVar1 = param_5 + 1;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 6294 ; VA 0x006059b0 ; FUN_006059b0 */

undefined4 *
FUN_006059b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,int *param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  piVar1 = param_5 + 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0060e460(param_4,param_5,param_6,param_7,param_8);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[2] + -1;
    param_7[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_7 + 4))();
    }
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  param_1[2] = uStack_1c;
  param_1[3] = piStack_18;
  param_1[4] = 0;
  param_1[5] = 0;
  if (piStack_10 != (int *)0x0) {
    LOCK();
    piStack_10[2] = piStack_10[2] + 1;
    UNLOCK();
  }
  param_1[4] = uStack_14;
  param_1[5] = piStack_10;
  param_1[6] = uStack_c;
  if (piStack_10 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_10[2] + -1;
    piStack_10[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_10 + 4))();
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_7 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 6295 ; VA 0x00605b70 ; FUN_00605b70 */

int * __fastcall FUN_00605b70(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088c960();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6296 ; VA 0x00605ba0 ; FUN_00605ba0 */

int * __fastcall FUN_00605ba0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088ca00();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6297 ; VA 0x00605bd0 ; FUN_00605bd0 */

int * __fastcall FUN_00605bd0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088cbe0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6298 ; VA 0x00605c00 ; FUN_00605c00 */

int * __fastcall FUN_00605c00(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088cdc0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6299 ; VA 0x00605c30 ; FUN_00605c30 */

int * __fastcall FUN_00605c30(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088d730();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6300 ; VA 0x00605c60 ; FUN_00605c60 */

int * __fastcall FUN_00605c60(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088daf0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6301 ; VA 0x00605c90 ; FUN_00605c90 */

void __thiscall FUN_00605c90(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  
  *(undefined4 *)(param_1 + 0xc) = param_3;
  iVar2 = FUN_00618490(param_3);
  *(int *)(param_1 + 4) = iVar2;
  *(int *)(param_1 + 8) = iVar2;
  iVar1 = iVar2 + *(int *)(param_1 + 0xc) * 4;
  while (iVar2 != iVar1) {
    **(undefined4 **)(param_1 + 8) = *param_2;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 4;
    iVar2 = *(int *)(param_1 + 8);
  }
  return;
}



/* FUNCTION 6302 ; VA 0x00605ce0 ; FUN_00605ce0 */

void __thiscall FUN_00605ce0(int param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005d2aa0();
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x18);
  *(undefined *)(param_1 + 9) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6303 ; VA 0x00605d50 ; FUN_00605d50 */

undefined4 * FUN_00605d50(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179ce10;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005eded0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x5c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00703570();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00604de0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6304 ; VA 0x00605e10 ; FUN_00605e10 */

void FUN_00605e10(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  iVar1 = param_2[6];
  if (iVar1 != 0) {
    uVar3 = param_2[8] - iVar1 & 0xfffffff0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00605ea2;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_2[6] = 0;
    param_2[7] = 0;
    param_2[8] = 0;
  }
  uVar3 = param_2[5];
  if (0xf < uVar3) {
    iVar1 = *param_2;
    uVar4 = uVar3 + 1;
    iVar2 = iVar1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar4 = uVar3 + 0x24;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00605ea2:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 6305 ; VA 0x00605eb0 ; FUN_00605eb0 */

void FUN_00605eb0(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_0056cd30();
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 6306 ; VA 0x00605f10 ; FUN_00605f10 */

void FUN_00605f10(undefined4 param_1,int param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  puVar2 = *(undefined4 **)(param_2 + 8);
  if (puVar2 != (undefined4 *)0x0) {
    puVar3 = *(undefined4 **)(param_2 + 0xc);
    if (puVar2 != puVar3) {
      do {
        (**(code **)*puVar2)(0);
        puVar2 = puVar2 + 0x16;
      } while (puVar2 != puVar3);
      puVar2 = *(undefined4 **)(param_2 + 8);
    }
    uVar1 = ((*(int *)(param_2 + 0x10) - (int)puVar2) / 0x58) * 0x58;
    puVar3 = puVar2;
    if (0xfff < uVar1) {
      puVar3 = (undefined4 *)puVar2[-1];
      uVar1 = uVar1 + 0x23;
      if (0x1f < (uint)((int)puVar2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar1);
    *(undefined4 *)(param_2 + 8) = 0;
    *(undefined4 *)(param_2 + 0xc) = 0;
    *(undefined4 *)(param_2 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6307 ; VA 0x00605fa0 ; FUN_00605fa0 */

undefined4 FUN_00605fa0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ce2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead490) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead490);
    if (DAT_01ead490 == -1) {
      uStack_8 = 0;
      DAT_01ead48c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead490);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead48c;
}



/* FUNCTION 6308 ; VA 0x00606020 ; FUN_00606020 */

undefined4 FUN_00606020(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ce4c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead498) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead498);
    if (DAT_01ead498 == -1) {
      uStack_8 = 0;
      DAT_01ead494 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead498);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead494;
}



/* FUNCTION 6309 ; VA 0x006060a0 ; FUN_006060a0 */

undefined4 * __thiscall
FUN_006060a0(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 *puStack_8;
  
  puVar2 = *(undefined4 **)(param_1 + 4);
  puStack_8 = param_3;
  if (*(undefined4 **)(param_1 + 8) == puVar2) {
    uVar5 = FUN_006036d0(param_3,param_4);
    *param_2 = uVar5;
    return param_2;
  }
  uStack_14 = *param_4;
  if (param_3 != puVar2) {
    uStack_10 = param_4[1];
    param_4[1] = 0;
    piStack_c = (int *)param_4[2];
    param_4[2] = 0;
    puVar6 = puVar2 + -3;
    puVar2[1] = 0;
    puVar2[2] = 0;
    *puVar2 = *puVar6;
    puVar2[1] = puVar2[-2];
    puVar2[2] = puVar2[-1];
    puVar2[-2] = 0;
    puVar2[-1] = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xc;
    if (puVar6 != param_3) {
      piVar8 = puVar2 + -4;
      piVar7 = puVar2 + 2;
      do {
        piVar1 = piVar7 + -3;
        iVar3 = *piVar8;
        piVar7[-5] = piVar8[-2];
        iVar4 = piVar8[-1];
        piVar8[-1] = 0;
        *piVar8 = 0;
        piVar7[-4] = iVar4;
        piVar7 = (int *)*piVar1;
        *piVar1 = iVar3;
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar3 = piVar7[1] + -1;
          piVar7[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            iVar3 = piVar7[2] + -1;
            piVar7[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        puVar6 = puVar6 + -3;
        piVar8 = piVar8 + -3;
        piVar7 = piVar1;
      } while (puVar6 != puStack_8);
    }
    puVar2 = puStack_8;
    FUN_00613d30(&uStack_14);
    piVar8 = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar7 = piVar8 + 2;
        iVar3 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    *param_2 = puVar2;
    return param_2;
  }
  puVar2[1] = 0;
  puVar2[2] = 0;
  puVar2[1] = param_4[1];
  puVar2[2] = param_4[2];
  *puVar2 = uStack_14;
  param_4[1] = 0;
  param_4[2] = 0;
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xc;
  *param_2 = param_3;
  return param_2;
}



/* FUNCTION 6310 ; VA 0x00606220 ; FUN_00606220 */

void __thiscall FUN_00606220(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 4);
  if (*(int **)(param_1 + 8) != piVar1) {
    iVar2 = *param_2;
    *piVar1 = iVar2;
    LOCK();
    piVar1 = (int *)(iVar2 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
    return;
  }
  FUN_00602fc0(piVar1,param_2);
  return;
}



/* FUNCTION 6311 ; VA 0x00606260 ; FUN_00606260 */

void __thiscall FUN_00606260(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    *puVar1 = *param_2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x10;
    return;
  }
  FUN_006038a0(puVar1,param_2);
  return;
}



/* FUNCTION 6312 ; VA 0x006062a0 ; FUN_006062a0 */

undefined4 * __thiscall
FUN_006062a0(byte *param_1,undefined4 *param_2,uint *param_3,int *param_4,undefined4 param_5)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ce68;
  pvStack_10 = ExceptionList;
  uVar8 = *param_3;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_3,uVar8,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 == (uint *)0x0) {
    uStack_8 = 0;
    piVar4 = (int *)FUN_01674e20(100);
    *piVar4 = 0;
    piVar4[1] = 0;
    FUN_0170d1f0(piVar4 + 2,0,0x5c);
    piVar4[2] = *param_4;
    FUN_0060f060(param_5);
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005c9310(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_3 = (uint *)0x1;
      uVar7 = uVar1 >> 1;
      if ((uVar1 >> 1) + uVar1 <= uVar5) {
        uVar7 = 1;
      }
      iVar6 = FUN_005c9310(uVar7 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar3 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar3 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar3;
            *(undefined4 **)*piVar3 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar4[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar3 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar9 = piVar3;
      *piVar4 = *piVar3;
      *piVar3 = (int)piVar4;
    }
    else {
      *piVar4 = *piVar3;
      *(int **)*puVar9 = piVar4;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = piVar4;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_2;
  }
  *param_2 = param_3;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6313 ; VA 0x00606470 ; FUN_00606470 */

void __thiscall FUN_00606470(int param_1,undefined4 *param_2,undefined4 param_3,int *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  char cVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ce88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_00a33fd0(param_3);
  uVar8 = uVar4 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar9 = (int *)0x0;
  }
  else {
    puVar10 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (puVar10 == (undefined4 *)0x0) {
      piVar9 = (int *)0x0;
    }
    else {
      piVar9 = (int *)*puVar10;
    }
    if (piVar9 == (int *)0x0) goto LAB_00606510;
    do {
      if (uVar4 == piVar9[1]) {
        cVar3 = FUN_00a33d60(piVar9 + 2);
        if (cVar3 != '\0') break;
      }
      else if ((uint)piVar9[1] % *(uint *)(param_1 + 4) != uVar8) goto LAB_00606510;
      piVar9 = (int *)*piVar9;
    } while (piVar9 != (int *)0x0);
  }
  if (piVar9 != (int *)0x0) {
    *param_2 = piVar9;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00606510:
  uStack_8 = 0;
  piVar5 = (int *)FUN_01674e20(0xc);
  *piVar5 = 0;
  piVar5[1] = 0;
  piVar5[2] = 0;
  iVar6 = *param_4;
  piVar5[2] = iVar6;
  LOCK();
  piVar9 = (int *)(iVar6 + 0x28);
  *piVar9 = *piVar9 + 1;
  UNLOCK();
  uVar1 = *(uint *)(param_1 + 8);
  uVar8 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005c9310(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    uVar7 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar8) {
      uVar7 = 1;
    }
    iVar6 = FUN_005c9310(uVar7 + uVar1);
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar6);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar10;
      while (puVar2 != (undefined4 *)0x0) {
        uVar8 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar9 = (int *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar8 * 4) == 0) {
          *piVar9 = (int)puVar10;
          puVar10 = puVar2;
        }
        else {
          *puVar10 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar9;
          *(undefined4 **)*piVar9 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar5[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar9 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *puVar10 = piVar9;
    *piVar5 = *piVar9;
    *piVar9 = (int)piVar5;
  }
  else {
    *piVar5 = *piVar9;
    *(int **)*puVar10 = piVar5;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6314 ; VA 0x00606670 ; FUN_00606670 */

void __thiscall FUN_00606670(int param_1,undefined4 *param_2,int *param_3,undefined8 *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179cea8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_00a6ce70(param_3);
  uVar8 = uVar4 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar6 = (int *)0x0;
  }
  else {
    puVar9 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (puVar9 == (undefined4 *)0x0) {
      piVar6 = (int *)0x0;
    }
    else {
      piVar6 = (int *)*puVar9;
    }
    if (piVar6 == (int *)0x0) goto LAB_00606719;
    do {
      if (uVar4 == piVar6[1]) {
        if (((*param_3 == piVar6[2]) && (param_3[1] == piVar6[3])) && (param_3[2] == piVar6[4]))
        break;
      }
      else if ((uint)piVar6[1] % *(uint *)(param_1 + 4) != uVar8) goto LAB_00606719;
      piVar6 = (int *)*piVar6;
    } while (piVar6 != (int *)0x0);
  }
  if (piVar6 != (int *)0x0) {
    *param_2 = piVar6;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00606719:
  uStack_8 = 0;
  piVar6 = (int *)FUN_01674e20(0x14);
  *piVar6 = 0;
  piVar6[1] = 0;
  piVar6[2] = 0;
  piVar6[3] = 0;
  piVar6[4] = 0;
  *(undefined8 *)(piVar6 + 2) = *param_4;
  piVar6[4] = *(int *)(param_4 + 1);
  uVar1 = *(uint *)(param_1 + 8);
  uVar8 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005c9310(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    uVar7 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar8) {
      uVar7 = 1;
    }
    iVar5 = FUN_005c9310(uVar7 + uVar1);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar9;
      while (puVar2 != (undefined4 *)0x0) {
        uVar8 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar3 = (int *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar8 * 4) == 0) {
          *piVar3 = (int)puVar9;
          puVar9 = puVar2;
        }
        else {
          *puVar9 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar6[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar3 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar6;
    }
    *puVar9 = piVar3;
    *piVar6 = *piVar3;
    *piVar3 = (int)piVar6;
  }
  else {
    *piVar6 = *piVar3;
    *(int **)*puVar9 = piVar6;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar6;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6315 ; VA 0x00606880 ; FUN_00606880 */

undefined4 * __thiscall FUN_00606880(byte *param_1,undefined4 *param_2,uint *param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint *puVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar8 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179cec8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar9 = FUN_008a2fa0(param_3);
  FUN_00606ff0(&param_3,uVar9,puVar8,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 != (uint *)0x0) {
    *param_2 = param_3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  uStack_8 = 0;
  piVar10 = (int *)FUN_00618350(1);
  *piVar10 = 0;
  piVar10[1] = 0;
  piVar10[2] = 0;
  piVar10[3] = 0;
  piVar10[4] = 0;
  piVar10[5] = 0;
  piVar10[6] = 0;
  piVar10[7] = 0;
  piVar10[2] = *param_4;
  piVar10[3] = param_4[1];
  iVar5 = param_4[3];
  iVar6 = param_4[4];
  iVar7 = param_4[5];
  piVar10[4] = param_4[2];
  piVar10[5] = iVar5;
  piVar10[6] = iVar6;
  piVar10[7] = iVar7;
  uVar3 = *(uint *)(param_1 + 8);
  uVar11 = uVar3 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar11 = FUN_005c9310(uVar11);
    if (uVar11 <= *(uint *)(param_1 + 4)) {
      uVar11 = *(uint *)(param_1 + 4);
    }
    FUN_0061a240(uVar11);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar11) {
    param_3 = (uint *)0x1;
    uVar12 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar11) {
      uVar12 = 1;
    }
    uVar11 = FUN_005c9310(uVar12 + *(int *)(param_1 + 8));
    param_3 = (uint *)(param_1 + 4);
    if (uVar11 != *param_3) {
      FUN_0061a240(uVar11);
      puVar13 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_3 * 4);
      puVar4 = (undefined4 *)*puVar13;
      while (puVar4 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_3) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_3) * 4) == 0) {
          *piVar1 = (int)puVar13;
          puVar13 = puVar4;
        }
        else {
          *puVar13 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar13;
      }
    }
  }
  piVar10[1] = uVar9;
  param_4 = *(int **)(param_1 + 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar9 % (uint)param_4) * 4);
  if ((int *)*piVar1 == (int *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + (int)param_4 * 4);
    if (*piVar2 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % (uint)param_4) * 4) = piVar10;
    }
    *piVar1 = (int)piVar2;
    *piVar10 = *piVar2;
    *piVar2 = (int)piVar10;
  }
  else {
    *piVar10 = *(int *)*piVar1;
    *(int **)*piVar1 = piVar10;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar10;
  *(undefined *)(param_2 + 1) = 1;
  FUN_00611bc0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6316 ; VA 0x00606a90 ; FUN_00606a90 */

undefined4 FUN_00606a90(undefined4 param_1,undefined4 param_2)

{
  FUN_0061d300(param_1,param_2);
  return param_1;
}



/* FUNCTION 6317 ; VA 0x00606ab0 ; FUN_00606ab0 */

int FUN_00606ab0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 6318 ; VA 0x00606af0 ; FUN_00606af0 */

int FUN_00606af0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00ae2430();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 6319 ; VA 0x00606b30 ; FUN_00606b30 */

int FUN_00606b30(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_005ee350();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 6320 ; VA 0x00606b70 ; FUN_00606b70 */

void FUN_00606b70(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  int iVar10;
  
  piVar9 = (int *)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
  if (param_1 != (int *)0x0) {
    do {
      iVar10 = *(int *)(param_3 + 4);
      if ((iVar10 == 0) && (puVar5 = *(undefined4 **)(param_3 + 0xc), puVar5 != (undefined4 *)0x0))
      {
        *(undefined4 **)(param_3 + 4) = puVar5;
        *(undefined4 *)(param_3 + 0xc) = *puVar5;
        *puVar5 = 0;
        iVar10 = *(int *)(param_3 + 4);
        *(undefined2 *)(param_3 + 8) = 0x101;
      }
      if (iVar10 == 0) {
        *(undefined2 *)(param_3 + 8) = 0;
        puVar5 = (undefined4 *)FUN_01674e20(0x38);
        *(undefined4 **)(param_3 + 4) = puVar5;
        *puVar5 = 0;
        puVar5[1] = 0;
        FUN_0170d1f0(puVar5 + 2,0,0x30);
        *(undefined *)(param_3 + 8) = 1;
      }
      else if (*(char *)(param_3 + 9) != '\0') {
        uVar8 = *(uint *)(iVar10 + 0x1c);
        if (0xf < uVar8) {
          iVar2 = *(int *)(iVar10 + 8);
          uVar7 = uVar8 + 1;
          iVar6 = iVar2;
          if (0xfff < uVar7) {
            iVar6 = *(int *)(iVar2 + -4);
            uVar7 = uVar8 + 0x24;
            if (0x1f < (iVar2 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar6,uVar7);
        }
        *(undefined4 *)(iVar10 + 0x18) = 0;
        *(undefined4 *)(iVar10 + 0x1c) = 0xf;
        *(undefined *)(iVar10 + 8) = 0;
        *(undefined *)(param_3 + 9) = 0;
      }
      iVar10 = *(int *)(param_3 + 4);
      FUN_0054ef60(param_1 + 2);
      iVar2 = param_1[9];
      iVar6 = param_1[10];
      iVar4 = param_1[0xb];
      *(int *)(iVar10 + 0x20) = param_1[8];
      *(int *)(iVar10 + 0x24) = iVar2;
      *(int *)(iVar10 + 0x28) = iVar6;
      *(int *)(iVar10 + 0x2c) = iVar4;
      *(undefined8 *)(iVar10 + 0x30) = *(undefined8 *)(param_1 + 0xc);
      iVar10 = *(int *)(param_3 + 4);
      *(undefined *)(param_3 + 9) = 1;
      *(undefined4 *)(param_3 + 4) = 0;
      *(int *)(iVar10 + 4) = param_1[1];
      *piVar9 = iVar10;
      *(int *)(param_2 + 8) = *(int *)(param_2 + 8) + 1;
      param_1 = (int *)*param_1;
      piVar3 = (int *)*piVar9;
      uVar8 = (uint)piVar3[1] % *(uint *)(param_2 + 4);
      piVar1 = (int *)(*(int *)(param_2 + 0x14) + uVar8 * 4);
      if (*(int *)(*(int *)(param_2 + 0x14) + uVar8 * 4) == 0) {
        *piVar1 = (int)piVar9;
        piVar9 = piVar3;
      }
      else {
        *piVar9 = *piVar3;
        *piVar3 = *(int *)*piVar1;
        *(int **)*piVar1 = piVar3;
      }
    } while (param_1 != (int *)0x0);
  }
  return;
}



/* FUNCTION 6321 ; VA 0x00606cd0 ; FUN_00606cd0 */

int FUN_00606cd0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
      uVar3 = FUN_00560d40();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00995770();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 6322 ; VA 0x00606de0 ; FUN_00606de0 */

int FUN_00606de0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01ea8dec,&LAB_005cf1b0);
  uVar3 = FUN_005cf480();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_009fb760();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 6323 ; VA 0x00606ea0 ; FUN_00606ea0 */

void __thiscall FUN_00606ea0(int param_1,undefined4 *param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar2 = (int *)0x0;
    }
    else {
      piVar2 = (int *)*puVar1;
    }
    if (piVar2 != (int *)0x0) {
      do {
        if (param_3 == piVar2[1]) {
          if (*param_4 == piVar2[2]) break;
        }
        else if ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar2 = (int *)*piVar2;
        if (piVar2 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar2;
  return;
}



/* FUNCTION 6324 ; VA 0x00606f30 ; FUN_00606f30 */

void __thiscall FUN_00606f30(int param_1,undefined4 *param_2,uint param_3,undefined4 *param_4)

{
  uint uVar1;
  char cVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  uVar1 = *(uint *)(param_1 + 4);
  uVar5 = param_3 % uVar1;
  if (*(int *)(param_1 + 8) == 0) {
    piVar6 = (int *)0x0;
  }
  else {
    puVar3 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    if (puVar3 == (undefined4 *)0x0) {
      piVar6 = (int *)0x0;
    }
    else {
      piVar6 = (int *)*puVar3;
    }
    if (piVar6 != (int *)0x0) {
      do {
        if (param_3 == piVar6[1]) {
          piVar4 = piVar6 + 2;
          if (0xf < (uint)piVar6[7]) {
            piVar4 = (int *)piVar6[2];
          }
          puVar3 = param_4;
          if (0xf < (uint)param_4[5]) {
            puVar3 = (undefined4 *)*param_4;
          }
          cVar2 = FUN_0055c360(puVar3,param_4[4],piVar4,piVar6[6]);
          if ((cVar2 != '\0') && (param_4[6] == piVar6[8])) break;
        }
        else if ((uint)piVar6[1] % uVar1 != uVar5) {
          *param_2 = 0;
          return;
        }
        piVar6 = (int *)*piVar6;
        if (piVar6 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar6;
  return;
}



/* FUNCTION 6325 ; VA 0x00606ff0 ; FUN_00606ff0 */

void __thiscall FUN_00606ff0(int param_1,undefined4 *param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar2 = (int *)0x0;
    }
    else {
      piVar2 = (int *)*puVar1;
    }
    if (piVar2 != (int *)0x0) {
      do {
        if (param_3 == piVar2[1]) {
          if ((*param_4 == piVar2[2]) && (param_4[1] == piVar2[3])) break;
        }
        else if ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar2 = (int *)*piVar2;
        if (piVar2 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar2;
  return;
}



/* FUNCTION 6326 ; VA 0x00607080 ; FUN_00607080 */

void __thiscall FUN_00607080(int param_1,undefined4 *param_2,uint param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar1;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          cVar2 = FUN_009cbaa0(param_4,piVar4 + 2);
          if (cVar2 != '\0') break;
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 6327 ; VA 0x00607110 ; FUN_00607110 */

void __thiscall FUN_00607110(int param_1,undefined4 *param_2,uint param_3)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar1;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          cVar2 = FUN_009c8f50(piVar4 + 2);
          if (cVar2 != '\0') break;
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 6328 ; VA 0x006071a0 ; FUN_006071a0 */

void FUN_006071a0(undefined4 param_1,int *param_2,int *param_3,undefined4 param_4,undefined4 param_5
                 ,undefined4 param_6)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  int *piVar4;
  uint *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  
  uVar9 = 0;
  piVar4 = (int *)*param_2;
  uVar8 = param_2[1] - (int)piVar4 >> 3;
  if (uVar8 != 0) {
    do {
      if (*piVar4 != param_2[4]) break;
      uVar9 = uVar9 + 1;
      piVar4 = piVar4 + 2;
    } while (uVar9 < uVar8);
  }
LAB_006071d0:
  if (uVar9 != uVar8) {
    puVar2 = (uint *)(*param_2 + uVar9 * 8);
    iVar1 = *param_3;
    if ((iVar1 != param_3[1]) && (uVar3 = *puVar2, uVar3 != param_3[4])) {
      uVar3 = (uVar3 >> 3) + uVar3;
      uVar10 = (param_3[1] - iVar1 >> 3) - 1;
      uVar6 = 0;
      do {
        uVar3 = uVar3 & uVar10;
        puVar5 = (uint *)(iVar1 + uVar3 * 8);
        if (*puVar5 == *puVar2) goto LAB_00607236;
        if (*puVar5 == param_3[4]) break;
        uVar3 = uVar3 + 1 + uVar6;
        uVar6 = uVar6 + 1;
      } while (uVar6 <= uVar10);
    }
    puVar5 = (uint *)0x0;
LAB_00607236:
    if (*puVar2 == 0) {
      pcVar7 = "Unknown";
    }
    else {
      pcVar7 = *(char **)(*puVar2 + 4);
      if (0xf < *(uint *)((int)pcVar7 + 0x14)) {
        pcVar7 = *(char **)pcVar7;
      }
    }
    FUN_0060d9a0(param_1,pcVar7,puVar2 + 1,-(uint)(puVar5 != (uint *)0x0) & (uint)(puVar5 + 1),
                 param_4,param_5,param_6);
    piVar4 = (int *)(*param_2 + uVar9 * 8);
    do {
      piVar4 = piVar4 + 2;
      uVar9 = uVar9 + 1;
      if ((uint)(param_2[1] - *param_2 >> 3) <= uVar9) break;
    } while (*piVar4 == param_2[4]);
    goto LAB_006071d0;
  }
  uVar9 = 0;
  piVar4 = (int *)*param_3;
  uVar8 = param_3[1] - (int)piVar4 >> 3;
  if (uVar8 != 0) {
    do {
      if (*piVar4 != param_3[4]) break;
      uVar9 = uVar9 + 1;
      piVar4 = piVar4 + 2;
    } while (uVar9 < uVar8);
  }
  do {
    if (uVar9 == uVar8) {
      return;
    }
    iVar1 = *param_2;
    puVar2 = (uint *)(*param_3 + uVar9 * 8);
    if (iVar1 == param_2[1]) {
      puVar5 = (uint *)0x0;
    }
    else {
      uVar3 = *puVar2;
      if (uVar3 == param_2[4]) {
        puVar5 = (uint *)0x0;
      }
      else {
        uVar3 = (uVar3 >> 3) + uVar3;
        uVar10 = (param_2[1] - iVar1 >> 3) - 1;
        uVar6 = 0;
        do {
          uVar3 = uVar3 & uVar10;
          puVar5 = (uint *)(iVar1 + uVar3 * 8);
          if (*puVar5 == *puVar2) goto LAB_00607349;
          if (*puVar5 == param_2[4]) break;
          uVar3 = uVar3 + 1 + uVar6;
          uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar10);
        puVar5 = (uint *)0x0;
      }
    }
LAB_00607349:
    if (((uint)(puVar5 + 1) & -(uint)(puVar5 != (uint *)0x0)) == 0) {
      if (*puVar2 == 0) {
        pcVar7 = "Unknown";
      }
      else {
        pcVar7 = *(char **)(*puVar2 + 4);
        if (0xf < *(uint *)((int)pcVar7 + 0x14)) {
          pcVar7 = *(char **)pcVar7;
        }
      }
      FUN_0060d9a0(param_1,pcVar7,0,puVar2 + 1,param_4,param_5,param_6);
    }
    piVar4 = (int *)(*param_3 + uVar9 * 8);
    do {
      piVar4 = piVar4 + 2;
      uVar9 = uVar9 + 1;
      if ((uint)(param_3[1] - *param_3 >> 3) <= uVar9) break;
    } while (*piVar4 == param_3[4]);
  } while( true );
}



/* FUNCTION 6329 ; VA 0x006073c0 ; FUN_006073c0 */

void FUN_006073c0(undefined4 param_1,int *param_2,int *param_3,undefined4 param_4,undefined4 param_5
                 ,undefined4 param_6)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  int *piVar4;
  uint *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  
  uVar9 = 0;
  piVar4 = (int *)*param_2;
  uVar8 = param_2[1] - (int)piVar4 >> 3;
  if (uVar8 != 0) {
    do {
      if (*piVar4 != param_2[4]) break;
      uVar9 = uVar9 + 1;
      piVar4 = piVar4 + 2;
    } while (uVar9 < uVar8);
  }
LAB_006073f0:
  if (uVar9 != uVar8) {
    puVar2 = (uint *)(*param_2 + uVar9 * 8);
    iVar1 = *param_3;
    if ((iVar1 != param_3[1]) && (uVar3 = *puVar2, uVar3 != param_3[4])) {
      uVar3 = (uVar3 >> 3) + uVar3;
      uVar10 = (param_3[1] - iVar1 >> 3) - 1;
      uVar6 = 0;
      do {
        uVar3 = uVar3 & uVar10;
        puVar5 = (uint *)(iVar1 + uVar3 * 8);
        if (*puVar5 == *puVar2) goto LAB_00607456;
        if (*puVar5 == param_3[4]) break;
        uVar3 = uVar3 + 1 + uVar6;
        uVar6 = uVar6 + 1;
      } while (uVar6 <= uVar10);
    }
    puVar5 = (uint *)0x0;
LAB_00607456:
    if (*puVar2 == 0) {
      pcVar7 = "Unknown";
    }
    else {
      pcVar7 = *(char **)(*puVar2 + 4);
      if (0xf < *(uint *)((int)pcVar7 + 0x14)) {
        pcVar7 = *(char **)pcVar7;
      }
    }
    FUN_0060db30(param_1,pcVar7,puVar2 + 1,-(uint)(puVar5 != (uint *)0x0) & (uint)(puVar5 + 1),
                 param_4,param_5,param_6);
    piVar4 = (int *)(*param_2 + uVar9 * 8);
    do {
      piVar4 = piVar4 + 2;
      uVar9 = uVar9 + 1;
      if ((uint)(param_2[1] - *param_2 >> 3) <= uVar9) break;
    } while (*piVar4 == param_2[4]);
    goto LAB_006073f0;
  }
  uVar9 = 0;
  piVar4 = (int *)*param_3;
  uVar8 = param_3[1] - (int)piVar4 >> 3;
  if (uVar8 != 0) {
    do {
      if (*piVar4 != param_3[4]) break;
      uVar9 = uVar9 + 1;
      piVar4 = piVar4 + 2;
    } while (uVar9 < uVar8);
  }
  do {
    if (uVar9 == uVar8) {
      return;
    }
    iVar1 = *param_2;
    puVar2 = (uint *)(*param_3 + uVar9 * 8);
    if (iVar1 == param_2[1]) {
      puVar5 = (uint *)0x0;
    }
    else {
      uVar3 = *puVar2;
      if (uVar3 == param_2[4]) {
        puVar5 = (uint *)0x0;
      }
      else {
        uVar3 = (uVar3 >> 3) + uVar3;
        uVar10 = (param_2[1] - iVar1 >> 3) - 1;
        uVar6 = 0;
        do {
          uVar3 = uVar3 & uVar10;
          puVar5 = (uint *)(iVar1 + uVar3 * 8);
          if (*puVar5 == *puVar2) goto LAB_00607569;
          if (*puVar5 == param_2[4]) break;
          uVar3 = uVar3 + 1 + uVar6;
          uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar10);
        puVar5 = (uint *)0x0;
      }
    }
LAB_00607569:
    if (((uint)(puVar5 + 1) & -(uint)(puVar5 != (uint *)0x0)) == 0) {
      if (*puVar2 == 0) {
        pcVar7 = "Unknown";
      }
      else {
        pcVar7 = *(char **)(*puVar2 + 4);
        if (0xf < *(uint *)((int)pcVar7 + 0x14)) {
          pcVar7 = *(char **)pcVar7;
        }
      }
      FUN_0060db30(param_1,pcVar7,0,puVar2 + 1,param_4,param_5,param_6);
    }
    piVar4 = (int *)(*param_3 + uVar9 * 8);
    do {
      piVar4 = piVar4 + 2;
      uVar9 = uVar9 + 1;
      if ((uint)(param_3[1] - *param_3 >> 3) <= uVar9) break;
    } while (*piVar4 == param_3[4]);
  } while( true );
}



/* FUNCTION 6330 ; VA 0x006075e0 ; FUN_006075e0 */

int __fastcall FUN_006075e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_1 = (int *)*param_1;
  iVar1 = *param_1;
  iVar2 = FUN_0088c8c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return *piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6331 ; VA 0x00607610 ; FUN_00607610 */

undefined4 __thiscall FUN_00607610(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_1 = (int *)*param_1;
  iVar1 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6332 ; VA 0x00607650 ; FUN_00607650 */

undefined4 __thiscall FUN_00607650(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_1 = (int *)*param_1;
  iVar1 = *param_1;
  iVar2 = FUN_0088cf00();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6333 ; VA 0x00607690 ; FUN_00607690 */

void FUN_00607690(undefined4 *param_1)

{
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  return;
}



/* FUNCTION 6334 ; VA 0x006076f0 ; FUN_006076f0 */

void __thiscall FUN_006076f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  param_1 = (int *)*param_1;
  iVar1 = *param_1;
  iVar3 = FUN_00b00260();
  if (iVar1 == iVar3) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iVar1 = piVar4[1];
    iVar3 = piVar4[2];
    iVar2 = piVar4[3];
    *param_2 = *piVar4;
    param_2[1] = iVar1;
    param_2[2] = iVar3;
    param_2[3] = iVar2;
    iVar1 = piVar4[5];
    iVar3 = piVar4[6];
    iVar2 = piVar4[7];
    param_2[4] = piVar4[4];
    param_2[5] = iVar1;
    param_2[6] = iVar3;
    param_2[7] = iVar2;
    iVar1 = piVar4[9];
    iVar3 = piVar4[10];
    iVar2 = piVar4[0xb];
    param_2[8] = piVar4[8];
    param_2[9] = iVar1;
    param_2[10] = iVar3;
    param_2[0xb] = iVar2;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6335 ; VA 0x00607740 ; FUN_00607740 */

undefined4 __thiscall FUN_00607740(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_1 = (int *)*param_1;
  iVar1 = *param_1;
  iVar2 = FUN_00886600();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_008866a0(piVar3);
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6336 ; VA 0x00607780 ; FUN_00607780 */

void __thiscall FUN_00607780(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_1 = (int *)*param_1;
  iVar1 = *param_1;
  iVar2 = FUN_0088d4b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iVar1 = *piVar3;
    *param_2 = iVar1;
    LOCK();
    piVar3 = (int *)(iVar1 + 0x28);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6337 ; VA 0x006077c0 ; FUN_006077c0 */

undefined8 __fastcall FUN_006077c0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_1 = (int *)*param_1;
  iVar1 = *param_1;
  iVar2 = FUN_0088da50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return *(undefined8 *)piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6338 ; VA 0x006077f0 ; FUN_006077f0 */

void FUN_006077f0(uint *param_1,undefined4 param_2)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = *param_1;
  iVar2 = FUN_005702d0(param_2);
  *param_1 = iVar2 + uVar1 * 0x40 + -0x61c88647 + (uVar1 >> 2) ^ uVar1;
  return;
}



/* FUNCTION 6339 ; VA 0x00607830 ; FUN_00607830 */

void FUN_00607830(undefined4 *param_1,undefined4 *param_2,undefined8 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  *(undefined8 *)(param_1 + 6) = *param_3;
  return;
}



/* FUNCTION 6340 ; VA 0x00607880 ; FUN_00607880 */

void FUN_00607880(int *param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017939bf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<class_RBX::Network::NetworkStream>::vftable;
    FUN_006ab530();
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6341 ; VA 0x006078f0 ; FUN_006078f0 */

void __thiscall FUN_006078f0(uint *param_1,int param_2,int param_3)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cf09;
  pvStack_10 = ExceptionList;
  uVar3 = *param_1;
  uVar2 = param_1[2] + (param_3 - param_2) / 0x58;
  ExceptionList = &pvStack_10;
  if (uVar3 < uVar2) {
    uStack_8 = 0;
    do {
      uVar3 = uVar3 * 3 >> 1;
    } while (uVar3 < uVar2);
    ExceptionList = &pvStack_10;
    uVar2 = FUN_01674f30(uVar3 * 0x58);
    uStack_18 = 0;
    if (param_1[2] != 0) {
      puVar4 = (undefined4 *)(uVar2 + 0x44);
      do {
        puVar5 = (undefined4 *)(((param_1[1] + uStack_18) % *param_1) * 0x58 + param_1[3]);
        puVar4[-0x11] = RBX::Network::DeserializedItem::vftable;
        puVar4[-0x10] = puVar5[1];
        puVar4[-0xf] = puVar5[2];
        puVar4[-0xe] = puVar5[3];
        puVar4[-0x11] = RBX::Network::DeserializedNewInstanceItem::vftable;
        FUN_0060eaf0(puVar5 + 4);
        puVar4[-10] = puVar5[7];
        puVar4[-9] = puVar5[8];
        puVar4[-8] = puVar5[9];
        puVar4[-7] = puVar5[10];
        puVar4[-6] = puVar5[0xb];
        puVar4[-5] = puVar5[0xc];
        puVar4[-4] = puVar5[0xd];
        puVar4[-3] = 0;
        puVar4[-2] = 0;
        if (puVar5[0xf] != 0) {
          LOCK();
          piVar1 = (int *)(puVar5[0xf] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        puVar4[-3] = puVar5[0xe];
        puVar4[-2] = puVar5[0xf];
        puVar4[-1] = 0;
        *puVar4 = 0;
        if (puVar5[0x11] != 0) {
          LOCK();
          piVar1 = (int *)(puVar5[0x11] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        puVar4[-1] = puVar5[0x10];
        *puVar4 = puVar5[0x11];
        *(undefined *)(puVar4 + 1) = *(undefined *)(puVar5 + 0x12);
        *(undefined *)((int)puVar4 + 5) = *(undefined *)((int)puVar5 + 0x49);
        FUN_0060ea20(puVar5 + 0x13);
        (**(code **)*puVar5)(0);
        puVar4 = puVar4 + 0x16;
        uStack_18 = uStack_18 + 1;
      } while (uStack_18 < param_1[2]);
    }
    FUN_01674ea0(param_1[3]);
    param_1[1] = 0;
    *param_1 = uVar3;
    param_1[3] = uVar2;
  }
  if (param_2 != param_3) {
    uVar3 = param_1[2];
    do {
      puVar4 = (undefined4 *)(((param_1[1] + uVar3) % *param_1) * 0x58 + param_1[3]);
      *puVar4 = RBX::Network::DeserializedItem::vftable;
      puVar4[1] = *(undefined4 *)(param_2 + 4);
      puVar4[2] = *(undefined4 *)(param_2 + 8);
      puVar4[3] = *(undefined4 *)(param_2 + 0xc);
      uStack_8 = 1;
      *puVar4 = RBX::Network::DeserializedNewInstanceItem::vftable;
      FUN_0060eaf0(param_2 + 0x10);
      puVar4[7] = *(undefined4 *)(param_2 + 0x1c);
      puVar4[8] = *(undefined4 *)(param_2 + 0x20);
      puVar4[9] = *(undefined4 *)(param_2 + 0x24);
      puVar4[10] = *(undefined4 *)(param_2 + 0x28);
      puVar4[0xb] = *(undefined4 *)(param_2 + 0x2c);
      puVar4[0xc] = *(undefined4 *)(param_2 + 0x30);
      puVar4[0xd] = *(undefined4 *)(param_2 + 0x34);
      puVar4[0xe] = 0;
      puVar4[0xf] = 0;
      if (*(int *)(param_2 + 0x3c) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(param_2 + 0x3c) + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      puVar4[0xe] = *(undefined4 *)(param_2 + 0x38);
      puVar4[0xf] = *(undefined4 *)(param_2 + 0x3c);
      puVar4[0x10] = 0;
      puVar4[0x11] = 0;
      if (*(int *)(param_2 + 0x44) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(param_2 + 0x44) + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      puVar4[0x10] = *(undefined4 *)(param_2 + 0x40);
      puVar4[0x11] = *(undefined4 *)(param_2 + 0x44);
      *(undefined *)(puVar4 + 0x12) = *(undefined *)(param_2 + 0x48);
      *(undefined *)((int)puVar4 + 0x49) = *(undefined *)(param_2 + 0x49);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_0060ea20(param_2 + 0x4c);
      param_2 = param_2 + 0x58;
      param_1[2] = param_1[2] + 1;
      uVar3 = param_1[2];
    } while (param_2 != param_3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6342 ; VA 0x00607ba0 ; FUN_00607ba0 */

void FUN_00607ba0(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  undefined auStack_4c [36];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_006abe60(param_2,1);
  if (cVar1 != '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0054eff0("readFast past end for uint8_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c27108);
}



/* FUNCTION 6343 ; VA 0x00607c10 ; FUN_00607c10 */

void FUN_00607c10(undefined4 param_1,ushort *param_2)

{
  char cVar1;
  undefined auStack_4c [36];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_006abe60(param_2,2);
  if (cVar1 != '\0') {
    *param_2 = *param_2 << 8 | *param_2 >> 8;
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0054eff0("readFast past end for uint16_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c27108);
}



/* FUNCTION 6344 ; VA 0x00607c90 ; FUN_00607c90 */

void __thiscall
FUN_00607c90(int *param_1,byte *param_2,byte *param_3,undefined4 param_4,int *param_5,byte *param_6,
            byte *param_7,uint *param_8)

{
  char cVar1;
  char cVar2;
  byte bVar3;
  byte *pbVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  int *piVar8;
  undefined4 uVar9;
  int *extraout_ECX;
  int *extraout_ECX_00;
  int *extraout_ECX_01;
  int *extraout_ECX_02;
  int *extraout_ECX_03;
  int *extraout_ECX_04;
  int *extraout_ECX_05;
  int *extraout_ECX_06;
  int *extraout_ECX_07;
  int *extraout_ECX_08;
  int *extraout_ECX_09;
  int *extraout_ECX_10;
  int *extraout_ECX_11;
  int *extraout_ECX_12;
  int *extraout_ECX_13;
  int *extraout_ECX_14;
  int *extraout_ECX_15;
  int *extraout_ECX_16;
  int *extraout_ECX_17;
  int *extraout_ECX_18;
  int *extraout_ECX_19;
  int *extraout_ECX_20;
  int *extraout_ECX_21;
  int *extraout_ECX_22;
  int *extraout_ECX_23;
  int *extraout_ECX_24;
  int *extraout_ECX_25;
  int *extraout_ECX_26;
  int *extraout_ECX_27;
  int *extraout_ECX_28;
  int *extraout_ECX_29;
  int *extraout_ECX_30;
  int *extraout_ECX_31;
  int *extraout_ECX_32;
  int *extraout_ECX_33;
  int *extraout_ECX_34;
  int *extraout_ECX_35;
  int *extraout_ECX_36;
  int *extraout_ECX_37;
  int *extraout_ECX_38;
  int *extraout_ECX_39;
  int *extraout_ECX_40;
  int *extraout_ECX_41;
  int *extraout_ECX_42;
  int *extraout_ECX_43;
  uint *puVar10;
  float10 extraout_ST0;
  float10 extraout_ST0_00;
  undefined auStack_ec [36];
  undefined auStack_c8 [12];
  undefined auStack_bc [24];
  undefined auStack_a4 [12];
  undefined auStack_98 [24];
  undefined4 ***pppuStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  int iStack_74;
  undefined auStack_68 [12];
  undefined4 ***apppuStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  byte *pbStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  byte *pbStack_34;
  undefined4 ***pppuStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int iStack_20;
  byte *pbStack_1c;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar10 = param_8;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d039;
  pvStack_10 = ExceptionList;
  piStack_3c = param_1;
  if (*param_3 == 0) {
    ExceptionList = &pvStack_10;
    FUN_016756b0(&iStack_24,"Cannot read value: value sent via unsupported format");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&iStack_24,&DAT_01c17198);
  }
  pbVar4 = (byte *)(*param_3 - 2);
  ExceptionList = &pvStack_10;
  switch(pbVar4) {
  case (byte *)0x0:
    pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
    uStack_8 = 6;
    ExceptionList = &pvStack_10;
LAB_00607f12:
    pbStack_1c = &DAT_0000000f;
    iStack_20 = 0;
    FUN_006ab8e0(&pppuStack_30,param_2);
    goto LAB_00607f21;
  case (byte *)0x1:
    break;
  default:
    ExceptionList = &pvStack_10;
    FUN_016756b0(&iStack_24,"Cannot read property value: unhandled type");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&iStack_24,&DAT_01c17198);
  case (byte *)0x4:
    ExceptionList = &pvStack_10;
    FUN_00565660(0x10,0);
    uStack_8 = 3;
    FUN_00a33c70();
    uStack_8._0_1_ = 4;
    cVar1 = FUN_00628020(param_2,apppuStack_5c,&param_8);
    if (cVar1 == '\0') {
      FUN_00614120(apppuStack_5c);
      uStack_28 = 0;
      pbStack_1c = &DAT_00000006;
      iStack_24 = param_5[1];
      iStack_20 = *param_5;
      FUN_00606260(&uStack_28);
      FUN_0056cd30();
    }
    else {
      uVar9 = FUN_00886b30(&dStack_18,&param_8);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      FUN_00604fb0(uVar9);
      FUN_0056cd30();
      FUN_0056cd30();
      FUN_0056cd30();
    }
    goto LAB_00607f55;
  case (byte *)0x5:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006abc60(&param_2,param_2);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      pbVar4 = (byte *)(**(code **)(*param_1 + 0x48))(*param_5,param_2);
      param_1 = extraout_ECX;
    }
    break;
  case (byte *)0x6:
    iStack_20 = 0;
    pbStack_1c = &DAT_0000000f;
    pppuStack_30 = (undefined4 ***)((uint)pppuStack_30._1_3_ << 8);
    uStack_8 = 7;
    ExceptionList = &pvStack_10;
    FUN_006ab8e0(&pppuStack_30,param_2);
    if ((DAT_01d5bb88 != '\0') || (DAT_01d5a0c0 != '\0')) {
      *puVar10 = *puVar10 + iStack_20;
    }
    if (*(int *)(param_3 + 8) == 3) {
      uVar9 = FUN_00a33be0(&pppuStack_30);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      FUN_00604fb0(uVar9);
      FUN_0056cd30();
      uStack_8 = 0xffffffff;
      pbVar4 = (byte *)FUN_005507b0();
      param_1 = extraout_ECX_02;
    }
    else {
      if (param_5[1] != 0) {
        (**(code **)(**(int **)(param_5[1] + 0x34) + 0x10))(*param_5,&pppuStack_30);
        puVar10 = param_8;
      }
      uStack_8 = 0xffffffff;
      pbVar4 = (byte *)FUN_005507b0();
      param_1 = extraout_ECX_03;
    }
    break;
  case (byte *)0x7:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006abd90();
    param_2 = (byte *)CONCAT13((char)pbVar4,param_2._0_3_);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,(int)&param_2 + 3);
      param_1 = extraout_ECX_04;
      puVar10 = param_8;
    }
    break;
  case (byte *)0x8:
    ExceptionList = &pvStack_10;
    FUN_006ab8a0(&param_2,param_2);
    if (*(int *)(param_3 + 8) == 1) {
      dStack_18 = (double)(longlong)(int)param_2;
      param_1 = (int *)param_5[1];
      pbVar4 = param_2;
      if (param_1 != (int *)0x0) {
        pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,&dStack_18);
        param_1 = extraout_ECX_05;
        puVar10 = param_8;
      }
    }
    else {
      param_1 = (int *)param_5[1];
      pbVar4 = param_3;
      if (param_1 != (int *)0x0) {
        pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,&param_2);
        param_1 = extraout_ECX_06;
      }
    }
    break;
  case (byte *)0x9:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006ac3c0();
    param_2 = (byte *)(float)extraout_ST0;
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,&param_2);
      param_1 = extraout_ECX_07;
      puVar10 = param_8;
    }
    break;
  case (byte *)0xa:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006ac2c0();
    dStack_18 = (double)extraout_ST0_00;
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,&dStack_18);
      param_1 = extraout_ECX_08;
      puVar10 = param_8;
    }
    break;
  case (byte *)0xb:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006acd90(&iStack_20);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_09;
    }
    break;
  case (byte *)0xc:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006acd20(&uStack_28);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_10;
    }
    break;
  case (byte *)0xd:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006ac930(&pppuStack_80);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_11;
    }
    break;
  case (byte *)0xe:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006abd60(&param_8);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_12;
    }
    break;
  case (byte *)0xf:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006abd60(&param_8);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_13;
    }
    break;
  case (byte *)0x10:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006abdb0(&param_8);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_14;
    }
    break;
  case (byte *)0x11:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006abea0(&iStack_24);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_15;
    }
    break;
  case (byte *)0x12:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006abef0((int)&param_8 + 1);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_16;
    }
    break;
  case (byte *)0x13:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006ac5d0(&iStack_20);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_17;
    }
    break;
  case (byte *)0x14:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006abea0(&iStack_24);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_18;
    }
    break;
  case (byte *)0x16:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006acf50(&param_8);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_19;
    }
    break;
  case (byte *)0x17:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006acf80((int)&uStack_38 + 2);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_20;
    }
    break;
  case (byte *)0x18:
    ExceptionList = &pvStack_10;
    FUN_0060efa0();
    pbVar4 = (byte *)FUN_006ab6e0(auStack_98,param_2);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,auStack_98);
      param_1 = extraout_ECX_21;
      puVar10 = param_8;
    }
    break;
  case (byte *)0x19:
    ExceptionList = &pvStack_10;
    uVar9 = FUN_006ac100(auStack_98);
    pbVar4 = (byte *)FUN_00604fb0(uVar9);
    param_1 = extraout_ECX_22;
    break;
  case (byte *)0x1a:
    uStack_38 = 0xffffffff;
    pbStack_34 = (byte *)0x0;
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_006b8fd0(&iStack_20,param_2);
    dStack_18 = 0.0;
    uStack_38 = *puVar5;
    pbStack_34 = (byte *)puVar5[1];
    uStack_8 = 9;
    cVar1 = FUN_00621ac0(&uStack_38,&dStack_18);
    if (cVar1 == '\0') {
      uStack_44 = 0;
      pbStack_40 = (byte *)0x0;
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      puVar5 = (undefined4 *)FUN_0060dcd0(&iStack_20,*param_5);
      pbStack_40 = (byte *)puVar5[1];
      uStack_44 = *puVar5;
      *puVar5 = 0;
      puVar5[1] = 0;
      param_2 = pbStack_1c;
      if (pbStack_1c != (byte *)0x0) {
        LOCK();
        iVar6 = *(int *)(pbStack_1c + 4) + -1;
        *(int *)(pbStack_1c + 4) = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (*(code *)**(undefined4 **)pbStack_1c)();
          LOCK();
          iVar6 = *(int *)(param_2 + 8) + -1;
          *(int *)(param_2 + 8) = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*(int *)param_2 + 4))();
          }
        }
      }
      FUN_00550b30();
    }
    else if ((int *)param_5[1] != (int *)0x0) {
      (**(code **)(*(int *)param_5[1] + 0x48))(*param_5,dStack_18._0_4_);
      uStack_8 = 0xffffffff;
      pbVar4 = (byte *)FUN_00550b30();
      param_1 = extraout_ECX_23;
      break;
    }
    uStack_8 = 0xffffffff;
    pbVar4 = (byte *)FUN_00550b30();
    param_1 = extraout_ECX_24;
    break;
  case (byte *)0x1b:
    if (param_6 != (byte *)0x0) {
      ExceptionList = &pvStack_10;
      piVar8 = (int *)FUN_00606b30(param_1);
      if (piVar8 != (int *)0x0) {
        (**(code **)(*piVar8 + 0x290))("codeName",0x24,1,"Tuple",0);
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Tuple cannot be received as a member of another container.");
    }
    ExceptionList = &pvStack_10;
    FUN_006abc60(&param_3,param_2);
    FUN_006192f0(param_3,"Tuple (read)");
    param_6 = (byte *)FUN_01674e20(0xc);
    if (param_6 == (byte *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *(undefined4 *)param_6 = 0;
      *(undefined4 *)((int)param_6 + 4) = 0;
      *(undefined4 *)((int)param_6 + 8) = 0;
      puVar5 = (undefined4 *)param_6;
    }
    FUN_00557ff0(puVar5);
    uStack_8 = 0xb;
    FUN_006045c0(param_3,dStack_18._0_4_);
    param_6 = (byte *)0x0;
    if (param_3 != (byte *)0x0) {
      pbStack_40 = (byte *)0x0;
      do {
        FUN_0062ca80(param_2,param_4,pbStack_40 + *(int *)dStack_18._0_4_,0,param_7,puVar10);
        param_6 = param_6 + 1;
        pbStack_40 = pbStack_40 + 0xd0;
      } while (param_6 < param_3);
    }
    FUN_00557fc0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    if (param_5[1] != 0) {
      (**(code **)(**(int **)(param_5[1] + 0x34) + 0x10))(*param_5,&uStack_38);
      puVar10 = param_8;
    }
    FUN_00550b30();
    uStack_8 = 0xffffffff;
    pbVar4 = (byte *)FUN_00550b30();
    param_1 = extraout_ECX_25;
    break;
  case (byte *)0x1c:
    ExceptionList = &pvStack_10;
    FUN_006abc60(&pbStack_40,param_2);
    FUN_006192f0(pbStack_40,"ValueArray (read)");
    pbStack_34 = (byte *)FUN_01674e20(0xc);
    uStack_8 = 0xd;
    if (pbStack_34 == (byte *)0x0) {
      uVar9 = 0;
    }
    else {
      uVar9 = FUN_00569550(pbStack_40,(int)&param_3 + 3);
    }
    uStack_8 = 0xffffffff;
    FUN_006022c0(uVar9);
    uStack_8 = 0xe;
    param_3 = (byte *)0x0;
    if (pbStack_40 != (byte *)0x0) {
      pbStack_34 = (byte *)0x0;
      do {
        FUN_0062ca80(param_2,param_4,pbStack_34 + *(int *)dStack_18._0_4_,param_6,param_7,puVar10);
        param_3 = param_3 + 1;
        pbStack_34 = pbStack_34 + 0xd0;
      } while (param_3 < pbStack_40);
    }
    FUN_00557fc0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    if (param_5[1] != 0) {
      (**(code **)(**(int **)(param_5[1] + 0x34) + 0x10))(*param_5,&uStack_38);
      puVar10 = param_8;
    }
    FUN_00550b30();
    uStack_8 = 0xffffffff;
    pbVar4 = (byte *)FUN_00550b30();
    param_1 = extraout_ECX_26;
    break;
  case (byte *)0x1d:
    ExceptionList = &pvStack_10;
    FUN_006abc60(&pbStack_40,param_2);
    FUN_006192f0(pbStack_40,"ValueTable (read)");
    param_3 = (byte *)FUN_01674e20(0x18);
    if (param_3 == (byte *)0x0) {
      uVar9 = 0;
    }
    else {
      uVar9 = FUN_005693e0(0xb,(int)&param_3 + 3,(int)&param_3 + 3,(int)&param_3 + 3);
    }
    FUN_005e51d0(uVar9);
    uStack_4c = 0;
    uStack_48 = 0xf;
    apppuStack_5c[0] = (undefined4 ***)((uint)apppuStack_5c[0] & 0xffffff00);
    uStack_8._0_1_ = 0x11;
    uStack_8._1_3_ = 0;
    param_3 = (byte *)0x0;
    if (pbStack_40 != (byte *)0x0) {
      do {
        FUN_006ab8e0(apppuStack_5c,param_2);
        iVar6 = FUN_005c4c00(apppuStack_5c);
        FUN_0062ca80(param_2,param_4,iVar6 + 0x18,param_6,param_7,puVar10);
        param_3 = param_3 + 1;
      } while (param_3 < pbStack_40);
    }
    FUN_00557fc0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    if (param_5[1] != 0) {
      (**(code **)(**(int **)(param_5[1] + 0x34) + 0x10))(*param_5,&uStack_38);
      puVar10 = param_8;
    }
    FUN_00550b30();
    FUN_005507b0();
    uStack_8 = 0xffffffff;
    pbVar4 = (byte *)FUN_00550b30();
    param_1 = extraout_ECX_27;
    break;
  case (byte *)0x1e:
    ExceptionList = &pvStack_10;
    FUN_006abc60(&param_3,param_2);
    FUN_006192f0(param_3,"ValueMap (read)");
    pbStack_34 = (byte *)FUN_01674e20(8);
    uStack_8 = 0x13;
    if (pbStack_34 == (byte *)0x0) {
      uVar9 = 0;
    }
    else {
      uVar9 = FUN_0060e3c0();
    }
    uStack_8 = 0xffffffff;
    FUN_00602290(uVar9);
    uStack_4c = 0;
    uStack_48 = 0xf;
    apppuStack_5c[0] = (undefined4 ***)((uint)apppuStack_5c[0] & 0xffffff00);
    uStack_8._0_1_ = 0x15;
    uStack_8._1_3_ = 0;
    pbStack_34 = (byte *)0x0;
    if (param_3 != (byte *)0x0) {
      do {
        FUN_006ab8e0(apppuStack_5c,param_2);
        uVar9 = FUN_00614050(apppuStack_5c);
        FUN_0062ca80(param_2,param_4,uVar9,param_6,param_7,puVar10);
        pbStack_34 = pbStack_34 + 1;
      } while (pbStack_34 < param_3);
    }
    FUN_00557fc0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
    if (param_5[1] != 0) {
      (**(code **)(**(int **)(param_5[1] + 0x34) + 0x10))(*param_5,&uStack_38);
      puVar10 = param_8;
    }
    FUN_00550b30();
    FUN_005507b0();
    uStack_8 = 0xffffffff;
    pbVar4 = (byte *)FUN_00550b30();
    param_1 = extraout_ECX_28;
    break;
  case (byte *)0x1f:
    iStack_20 = 0;
    pbStack_1c = &DAT_0000000f;
    pppuStack_30 = (undefined4 ***)((uint)pppuStack_30._1_3_ << 8);
    uStack_8 = 0x17;
    if ((char)param_4 == '\0') {
      ExceptionList = &pvStack_10;
      FUN_006ab8e0(&pppuStack_30,param_2);
    }
    else {
      ExceptionList = &pvStack_10;
      FUN_00627f10(param_2,&pppuStack_30);
    }
    if ((int *)param_5[1] != (int *)0x0) {
      (**(code **)(*(int *)param_5[1] + 0x34))(*param_5,&pppuStack_30);
      puVar10 = param_8;
    }
    goto LAB_00607f55;
  case (byte *)0x20:
    ExceptionList = &pvStack_10;
    FUN_006abc60(&param_2,param_2);
    param_7 = param_2;
    param_1 = (int *)param_5[1];
    pbVar4 = param_2;
    if (param_1 != (int *)0x0) {
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,&param_7);
      param_1 = extraout_ECX_29;
      puVar10 = param_8;
    }
    break;
  case (byte *)0x21:
    ExceptionList = &pvStack_10;
    param_2 = (byte *)FUN_006ac600(&iStack_24);
    uStack_8 = 0x18;
    if (param_5[1] != 0) {
      (**(code **)(**(int **)(param_5[1] + 0x34) + 0x10))(*param_5,param_2);
    }
    uStack_8 = 0xffffffff;
    pbVar4 = (byte *)FUN_00617ad0();
    param_1 = extraout_ECX_30;
    break;
  case (byte *)0x22:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006abea0(&iStack_24);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_33;
    }
    break;
  case (byte *)0x23:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006ac5d0(&iStack_20);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_31;
    }
    break;
  case (byte *)0x24:
    ExceptionList = &pvStack_10;
    param_2 = (byte *)FUN_006abf40(&iStack_24);
    uStack_8 = 0x19;
    if (param_5[1] != 0) {
      (**(code **)(**(int **)(param_5[1] + 0x34) + 0x10))(*param_5,param_2);
    }
    uStack_8 = 0xffffffff;
    pbVar4 = (byte *)FUN_00617bc0();
    param_1 = extraout_ECX_32;
    break;
  case (byte *)0x25:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006ac070(&uStack_2c);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_34;
    }
    break;
  case (byte *)0x26:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006ac9d0(&uStack_28);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_35;
    }
    break;
  case (byte *)0x27:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006ac760(&pppuStack_80);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_36;
    }
    break;
  case (byte *)0x28:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006aca60(auStack_a4);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_37;
    }
    break;
  case (byte *)0x29:
    ExceptionList = &pvStack_10;
    pbVar4 = (byte *)FUN_006acae0(&iStack_24);
    param_1 = (int *)param_5[1];
    if (param_1 != (int *)0x0) {
      param_2 = pbVar4;
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,pbVar4);
      param_1 = extraout_ECX_38;
    }
    break;
  case (byte *)0x2a:
    ExceptionList = &pvStack_10;
    FUN_006ab860(&dStack_18,param_2);
    param_1 = (int *)param_5[1];
    if (*(int *)(param_3 + 8) == 2) {
      param_2 = dStack_18._0_4_;
      pbVar4 = dStack_18._0_4_;
      if (param_1 != (int *)0x0) {
        pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,&param_2);
        param_1 = extraout_ECX_39;
        puVar10 = param_8;
      }
    }
    else {
      pbVar4 = param_3;
      if (param_1 != (int *)0x0) {
        pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,&dStack_18);
        param_1 = extraout_ECX_40;
      }
    }
    break;
  case (byte *)0x2b:
    ExceptionList = &pvStack_10;
    param_2 = (byte *)FUN_006ac700(&pppuStack_80);
    param_1 = (int *)param_5[1];
    pbVar4 = param_2;
    if (param_1 != (int *)0x0) {
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,param_2);
      param_1 = extraout_ECX_41;
    }
    break;
  case (byte *)0x2c:
    ExceptionList = &pvStack_10;
    FUN_00565660(0x10,0);
    ppppuVar7 = apppuStack_5c;
    if (0xf < uStack_48) {
      ppppuVar7 = (undefined4 ****)apppuStack_5c[0];
    }
    uStack_8 = 0x1a;
    FUN_006abe60(ppppuVar7,0x10);
    FUN_0061de50(&param_2,apppuStack_5c);
    if (param_2 == (byte *)0x0) {
      FUN_00614120(apppuStack_5c);
      uStack_28 = 0;
      pbStack_1c = *(byte **)(param_3 + 8);
      iStack_24 = param_5[1];
      iStack_20 = *param_5;
      FUN_00606260(&uStack_28);
    }
    else if (*(int *)(param_3 + 8) == 4) {
      uVar9 = FUN_00a33fa0();
      FUN_0054ef60(uVar9);
      pppuStack_80 = pppuStack_30;
      pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
      uStack_7c = uStack_2c;
      uStack_78 = uStack_28;
      iStack_74 = iStack_24;
      iStack_20 = 0;
      pbStack_1c = &DAT_0000000f;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1b);
      FUN_00604fb0(&pppuStack_80);
      FUN_005507b0();
    }
    else {
      FUN_00604fb0(param_2 + 0x20);
    }
    goto LAB_00607f55;
  case (byte *)0x2d:
    if (param_1[0x771] == 0) {
      pbVar4 = (byte *)CONCAT31((int3)((uint)pbVar4 >> 8),DAT_01eae4ae);
      ExceptionList = &pvStack_10;
      if (DAT_01eae4ae != '\0') {
        ExceptionList = &pvStack_10;
        pbVar4 = (byte *)FUN_016774b0(DAT_01eae4ae,
                                      "Can\'t recv protected bytecode due to missing SessionCrypto."
                                      ,0);
        param_1 = extraout_ECX_00;
      }
      break;
    }
    ExceptionList = &pvStack_10;
    FUN_00565660(0x10,0);
    uStack_8 = 0;
    FUN_00a33c70();
    uStack_8._0_1_ = 1;
    cVar1 = FUN_00628020(param_2,apppuStack_5c,&param_8);
    if (cVar1 == '\0') {
      FUN_00614120(apppuStack_5c);
      uStack_28 = 0;
      pbStack_1c = &DAT_00000005;
      iStack_24 = param_5[1];
      iStack_20 = *param_5;
      FUN_00606260(&uStack_28);
    }
    else {
      uVar9 = FUN_00886a70(&dStack_18,&param_8);
      uStack_8._0_1_ = 2;
      FUN_00604fb0(uVar9);
      uStack_8._0_1_ = 1;
      FUN_0056cd30();
      FUN_0056cd30();
    }
    cVar1 = FUN_0061f4b0();
    if (cVar1 == '\0') {
      dStack_18 = *(double *)(*param_5 + 0x18);
      FUN_006191b0(param_2,apppuStack_5c,&dStack_18,*(undefined2 *)(param_5 + 2));
      FUN_0056cd30();
    }
    else {
      if ((*(int *)(*param_5 + 0x18) == -1) || (*(short *)(param_5 + 2) == DAT_018db184)) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Invalid Bytecode.");
      }
      FUN_0056cd30();
    }
    goto LAB_00607f55;
  case (byte *)0x2e:
    if (DAT_01d5a0c8 == '\0') {
      ExceptionList = &pvStack_10;
      FUN_016756b0(&iStack_24,"Cannot read DateTime property value: unhandled type");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&iStack_24,&DAT_01c17198);
    }
    ExceptionList = &pvStack_10;
    param_2 = (byte *)FUN_006ac1c0(&uStack_28);
    param_1 = (int *)param_5[1];
    pbVar4 = param_2;
    if (param_1 != (int *)0x0) {
      pbVar4 = (byte *)(**(code **)(*(int *)param_1[0xd] + 0x10))(*param_5,param_2);
      param_1 = extraout_ECX_42;
    }
    break;
  case (byte *)0x2f:
    ExceptionList = &pvStack_10;
    bVar3 = FUN_006abe40();
    if ((char)bVar3 < '\0') {
      param_8 = (uint *)0x0;
      if ((bVar3 & 0x7f) < 0x7f) {
        param_8 = (uint *)(uint)(bVar3 & 0x7f);
      }
      else {
        FUN_006abc60(&param_8,param_2);
        param_8 = (uint *)((int)param_8 + 0x7f);
      }
      param_2 = (byte *)FUN_0061e000(param_8);
      if ((DAT_01d5bb88 != '\0') || (DAT_01d5a0c0 != '\0')) {
        *puVar10 = *puVar10 + *(int *)((int)param_2 + 0x10);
      }
      pbVar4 = (byte *)FUN_00604fb0(param_2);
      param_1 = extraout_ECX_43;
      break;
    }
    iStack_20 = 0;
    pbStack_1c = &DAT_0000000f;
    pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
    uStack_8 = 0x1c;
    if (0x7e < bVar3) goto LAB_00607f12;
    param_8 = (uint *)(uint)bVar3;
    if ((uint *)(*(int *)(param_2 + 0x18) - *(int *)(param_2 + 0x20)) < param_8) {
      uVar9 = FUN_00615980();
      uVar9 = FUN_01675640(&pppuStack_80,
                           "BitStream string read: String too long (%u requested %u available)",
                           param_8,uVar9);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
      FUN_005f8ef0(uVar9);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_c8,&DAT_01c27108);
    }
    FUN_0058a370(param_8,0);
    ppppuVar7 = &pppuStack_30;
    if (&DAT_0000000f < pbStack_1c) {
      ppppuVar7 = (undefined4 ****)pppuStack_30;
    }
    FUN_006abe60(ppppuVar7,param_8);
LAB_00607f21:
    if ((DAT_01d5bb88 != '\0') || (DAT_01d5a0c0 != '\0')) {
      *puVar10 = iStack_20 + *puVar10;
    }
    if (param_5[1] != 0) {
      (**(code **)(**(int **)(param_5[1] + 0x34) + 0x10))(*param_5,&pppuStack_30);
    }
LAB_00607f55:
    uStack_8 = 0xffffffff;
    pbVar4 = (byte *)FUN_005507b0();
    param_1 = extraout_ECX_01;
  }
  if ((DAT_01d5bb88 != '\0') || (DAT_01d5a0c0 != '\0')) {
    param_5 = (int *)((uint)param_1 & 0xffffff00);
    param_2 = (byte *)((uint)pbVar4 & 0xffffff00);
    if (puVar10[2] != 0) {
      param_5 = (int *)(uint)(puVar10[2] < *puVar10);
    }
    cVar1 = (char)param_5;
    if (puVar10[3] != 0) {
      param_2 = (byte *)(uint)(puVar10[3] < puVar10[1]);
    }
    cVar2 = (char)param_2;
    if ((DAT_01d5a0c0 != '\0') && ((cVar1 != '\0' || (cVar2 != '\0')))) {
      uStack_4c = 0;
      uStack_48 = 0xf;
      apppuStack_5c[0] = (undefined4 ***)((uint)apppuStack_5c[0] & 0xffffff00);
      FUN_005542c0("ReplicatorReadVariantLimit",0x1a);
      uStack_8 = 0x1e;
      FUN_006289b0(puVar10,apppuStack_5c);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      cVar2 = (char)param_2;
      cVar1 = (char)param_5;
    }
    if (DAT_01d5bb88 != '\0') {
      if (cVar1 != '\0') {
        uVar9 = FUN_01675640(&pppuStack_80,
                             "Replicator read variant: Total string data size exceed limit! (%u)",
                             *puVar10);
        uStack_8 = 0x1f;
        FUN_005f8ef0(uVar9);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_68,&DAT_01c27108);
      }
      if (cVar2 != '\0') {
        uVar9 = FUN_01675640(auStack_bc,
                             "Replicator read variant: Variant count exceeded limit! (%u)",
                             puVar10[1]);
        uStack_8 = 0x20;
        FUN_005f8ef0(uVar9);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_ec,&DAT_01c27108);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6345 ; VA 0x00609060 ; FUN_00609060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00609060(int *param_1,float param_2,byte *param_3,undefined4 param_4,int *param_5,uint param_6,
            undefined4 *param_7,uint *param_8)

{
  undefined2 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint *puVar4;
  char cVar5;
  undefined uVar6;
  byte bVar7;
  char cVar8;
  int *piVar9;
  int *piVar10;
  undefined2 *puVar11;
  undefined4 *puVar12;
  double *pdVar13;
  int iVar14;
  undefined8 *puVar15;
  undefined4 *puVar16;
  int iVar17;
  undefined4 ****ppppuVar18;
  undefined4 uVar19;
  int *extraout_ECX;
  int *extraout_ECX_00;
  int *extraout_ECX_01;
  int *extraout_ECX_02;
  int *extraout_ECX_03;
  int *extraout_ECX_04;
  int *extraout_ECX_05;
  int *extraout_ECX_06;
  int *extraout_ECX_07;
  int *extraout_ECX_08;
  int *extraout_ECX_09;
  int *extraout_ECX_10;
  int *extraout_ECX_11;
  int *extraout_ECX_12;
  int *extraout_ECX_13;
  int *extraout_ECX_14;
  int *extraout_ECX_15;
  int *extraout_ECX_16;
  int *extraout_ECX_17;
  int *extraout_ECX_18;
  int *extraout_ECX_19;
  int *extraout_ECX_20;
  int *extraout_ECX_21;
  int *extraout_ECX_22;
  int *extraout_ECX_23;
  int *extraout_ECX_24;
  int *extraout_ECX_25;
  int *extraout_ECX_26;
  int *extraout_ECX_27;
  int *extraout_ECX_28;
  int *extraout_ECX_29;
  int *extraout_ECX_30;
  int *extraout_ECX_31;
  int *extraout_ECX_32;
  int *extraout_ECX_33;
  int *extraout_ECX_34;
  uint uVar20;
  byte *pbVar21;
  uint uVar22;
  float10 fVar23;
  undefined auStack_d4 [36];
  undefined auStack_b0 [12];
  undefined4 ***pppuStack_a4;
  undefined4 uStack_a0;
  int iStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined auStack_8c [12];
  undefined auStack_80 [24];
  undefined4 ***apppuStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  int *piStack_48;
  undefined auStack_44 [12];
  undefined4 ***pppuStack_38;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  int iStack_1c;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pbVar21 = param_3;
  uVar20 = (uint)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d17c;
  pvStack_10 = ExceptionList;
  piStack_48 = param_1;
  if (*param_3 == 0) {
    ExceptionList = &pvStack_10;
    FUN_016756b0(&uStack_2c,"Cannot read value: value sent via unsupported format");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_2c,&DAT_01c17198);
  }
  piVar9 = (int *)(*param_3 - 2);
  ExceptionList = &pvStack_10;
  switch(piVar9) {
  case (int *)0x0:
    pppuStack_38 = (undefined4 ***)((uint)pppuStack_38._1_3_ << 8);
    uStack_8 = 6;
    ExceptionList = &pvStack_10;
LAB_0060a75b:
    uStack_28 = 0xf00000000;
    FUN_006ab8e0(&pppuStack_38,uVar20);
    goto LAB_0060a767;
  case (int *)0x1:
    break;
  default:
    ExceptionList = &pvStack_10;
    FUN_016756b0(&uStack_2c,"Cannot read property value: unhandled type");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_2c,&DAT_01c17198);
  case (int *)0x4:
    ExceptionList = &pvStack_10;
    FUN_00565660(0x10,0);
    uStack_8 = 3;
    FUN_00a33c70();
    uStack_8._0_1_ = 4;
    cVar5 = FUN_00628020(param_2,apppuStack_68,&param_4);
    if (cVar5 == '\0') {
      FUN_00614120(apppuStack_68);
      uStack_2c = 0;
      uStack_28 = 0x600000000;
      iStack_30 = param_5[1];
      FUN_00606260(&iStack_30);
      FUN_0056cd30();
    }
    else {
      uVar19 = FUN_00886b30(&dStack_18,&param_4);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      FUN_00605130(uVar19);
      FUN_0056cd30();
      FUN_0056cd30();
      FUN_0056cd30();
    }
    goto LAB_0060a790;
  case (int *)0x5:
    ExceptionList = &pvStack_10;
    FUN_006abc60(&param_2,param_2);
    piVar9 = (int *)*param_5;
    param_1 = (int *)piVar9[1];
    if (param_1 != (int *)0x0) {
      piVar9 = (int *)(**(code **)(*param_1 + 0x10))(param_2,param_5[1]);
      param_1 = extraout_ECX;
    }
    break;
  case (int *)0x6:
    uStack_28 = 0xf00000000;
    pppuStack_38 = (undefined4 ***)((uint)pppuStack_38._1_3_ << 8);
    uStack_8 = 7;
    ExceptionList = &pvStack_10;
    FUN_006ab8e0(&pppuStack_38,param_2);
    if ((DAT_01d5bb88 != '\0') || (DAT_01d5a0c0 != '\0')) {
      *param_8 = *param_8 + (int)uStack_28;
    }
    if (*(int *)(pbVar21 + 8) == 3) {
      uVar19 = FUN_00a33be0(&pppuStack_38);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      FUN_00605190(uVar19);
      FUN_0056cd30();
      uStack_8 = 0xffffffff;
      piVar9 = (int *)FUN_005507b0();
      param_1 = extraout_ECX_01;
    }
    else {
      FUN_00605040(&pppuStack_38);
      uStack_8 = 0xffffffff;
      piVar9 = (int *)FUN_005507b0();
      param_1 = extraout_ECX_02;
    }
    break;
  case (int *)0x7:
    ExceptionList = &pvStack_10;
    uVar6 = FUN_006abd90();
    puVar12 = (undefined4 *)param_5[1];
    param_2._3_1_ = uVar6;
    uVar19 = FUN_0088daf0();
    *puVar12 = uVar19;
    piVar10 = (int *)FUN_005c9ef0();
    param_1 = (int *)puVar12[1];
    if (param_1 == piVar10) {
      piVar9 = (int *)CONCAT31((int3)((uint)piVar10 >> 8),param_2._3_1_);
      *(undefined *)(puVar12 + 2) = param_2._3_1_;
    }
    else {
      piVar9 = piVar10;
      if (param_1 != (int *)0x0) {
        piVar9 = (int *)(*(code *)param_1[2])(puVar12 + 2);
        param_1 = extraout_ECX_03;
      }
      piVar9 = (int *)CONCAT31((int3)((uint)piVar9 >> 8),param_2._3_1_);
      *(undefined *)(puVar12 + 2) = param_2._3_1_;
      puVar12[1] = piVar10;
    }
    break;
  case (int *)0x8:
    ExceptionList = &pvStack_10;
    FUN_006ab8a0(&param_2,param_2);
    if (*(int *)(pbVar21 + 8) != 1) {
LAB_0060a4dd:
      piVar9 = (int *)FUN_00604f50(&param_2);
      param_1 = extraout_ECX_30;
      break;
    }
    dStack_18 = (double)(longlong)(int)param_2;
    goto LAB_006093f6;
  case (int *)0x9:
    ExceptionList = &pvStack_10;
    fVar23 = (float10)FUN_006ac3c0();
    param_2 = (float)fVar23;
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088c960();
    *puVar12 = uVar19;
    piVar10 = (int *)FUN_00630820();
    param_1 = (int *)puVar12[1];
    piVar9 = piVar10;
    if (param_1 == piVar10) {
      puVar12[2] = param_2;
    }
    else {
      if (param_1 != (int *)0x0) {
        piVar9 = (int *)(*(code *)param_1[2])(puVar12 + 2);
        param_1 = extraout_ECX_05;
      }
      puVar12[2] = param_2;
      puVar12[1] = piVar10;
    }
    break;
  case (int *)0xa:
    ExceptionList = &pvStack_10;
    fVar23 = (float10)FUN_006ac2c0();
    dStack_18 = (double)fVar23;
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088ca00();
    *puVar12 = uVar19;
    piVar10 = (int *)FUN_00630890();
    param_1 = (int *)puVar12[1];
    piVar9 = piVar10;
    if (param_1 == piVar10) {
      *(double *)(puVar12 + 2) = dStack_18;
    }
    else {
      if (param_1 != (int *)0x0) {
        piVar9 = (int *)(*(code *)param_1[2])(puVar12 + 2);
        param_1 = extraout_ECX_06;
      }
      *(double *)(puVar12 + 2) = dStack_18;
      puVar12[1] = piVar10;
    }
    break;
  case (int *)0xb:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006acd90(&uStack_28);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d690();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00631460();
    goto LAB_006094d2;
  case (int *)0xc:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006acd20(&iStack_30);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d5f0();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_006313f0();
    goto LAB_00609539;
  case (int *)0xd:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006ac930(apppuStack_68);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d370();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00631150();
    goto LAB_006095a8;
  case (int *)0xe:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006abd60(&param_7);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d230();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00630e40();
    goto LAB_0060961b;
  case (int *)0xf:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006abd60(&param_7);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088ce60();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00630a50();
    goto LAB_0060961b;
  case (int *)0x10:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006abdb0(&param_7);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088cfa0();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00630b30();
    goto LAB_0060961b;
  case (int *)0x11:
    ExceptionList = &pvStack_10;
    puVar15 = (undefined8 *)FUN_006abea0(&uStack_2c);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d050();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_005c9e10();
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      puVar12[2] = *(undefined4 *)puVar15;
      puVar12[3] = *(undefined4 *)((int)puVar15 + 4);
      piVar9 = *(int **)(puVar15 + 1);
      puVar12[4] = piVar9;
      break;
    }
    goto LAB_006096da;
  case (int *)0x12:
    ExceptionList = &pvStack_10;
    puVar11 = (undefined2 *)FUN_006abef0((int)&param_7 + 1);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d0f0();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00630ba0();
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      uVar1 = *puVar11;
      *(undefined2 *)(puVar12 + 2) = uVar1;
      uVar6 = *(undefined *)(puVar11 + 1);
      *(undefined *)((int)puVar12 + 10) = uVar6;
      piVar9 = (int *)CONCAT31((int3)(CONCAT22((short)((uint)param_5 >> 0x10),uVar1) >> 8),uVar6);
    }
    else {
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        puVar12[1] = 0;
        param_1 = extraout_ECX_12;
      }
      *(undefined2 *)(puVar12 + 2) = *puVar11;
      *(undefined *)((int)puVar12 + 10) = *(undefined *)(puVar11 + 1);
      puVar12[1] = param_5;
      piVar9 = param_5;
    }
    break;
  case (int *)0x13:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006ac5d0(&uStack_28);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d730();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_006314d0();
    goto LAB_006094d2;
  case (int *)0x14:
    ExceptionList = &pvStack_10;
    puVar15 = (undefined8 *)FUN_006abea0(&uStack_2c);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d870();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_006315b0();
    goto LAB_006097bb;
  case (int *)0x16:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006acf50(&param_7);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d7d0();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00631540();
LAB_0060961b:
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      piVar9 = (int *)*puVar16;
      puVar12[2] = piVar9;
    }
    else {
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        puVar12[1] = 0;
        param_1 = extraout_ECX_10;
      }
      puVar12[2] = *puVar16;
      puVar12[1] = param_5;
      piVar9 = param_5;
    }
    break;
  case (int *)0x17:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006acf80((int)&uStack_20 + 2);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d910();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00631620();
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      uVar19 = *puVar16;
      puVar12[2] = uVar19;
      uVar1 = *(undefined2 *)(puVar16 + 1);
      *(undefined2 *)(puVar12 + 3) = uVar1;
      piVar9 = (int *)CONCAT22((short)((uint)uVar19 >> 0x10),uVar1);
    }
    else {
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        puVar12[1] = 0;
        param_1 = extraout_ECX_13;
      }
      puVar12[2] = *puVar16;
      *(undefined2 *)(puVar12 + 3) = *(undefined2 *)(puVar16 + 1);
      puVar12[1] = param_5;
      piVar9 = param_5;
    }
    break;
  case (int *)0x18:
    ExceptionList = &pvStack_10;
    FUN_0060efa0();
    FUN_006ab6e0(auStack_80,param_2);
    piVar9 = (int *)FUN_006050b0(auStack_80);
    param_1 = extraout_ECX_14;
    break;
  case (int *)0x19:
    ExceptionList = &pvStack_10;
    uVar19 = FUN_006ac100(auStack_80);
    piVar9 = (int *)FUN_006050b0(uVar19);
    param_1 = extraout_ECX_15;
    break;
  case (int *)0x1a:
    uStack_20 = 0xffffffff;
    iStack_1c = 0;
    ExceptionList = &pvStack_10;
    puVar12 = (undefined4 *)FUN_006b8fd0(&uStack_28,param_2);
    uStack_50 = 0;
    uStack_4c = 0;
    uStack_20 = *puVar12;
    iStack_1c = puVar12[1];
    uStack_8 = 9;
    cVar5 = FUN_00621ac0(&uStack_20,&uStack_50);
    if (cVar5 == '\0') {
      dStack_18 = 0.0;
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      param_7 = (undefined4 *)param_5[2];
      pdVar13 = (double *)FUN_0060dcd0(&uStack_28,param_5[3]);
      param_2 = *(float *)pdVar13;
      dStack_18 = *pdVar13;
      *(undefined4 *)pdVar13 = 0;
      *(undefined4 *)((int)pdVar13 + 4) = 0;
      piVar9 = uStack_28._4_4_;
      if (uStack_28._4_4_ != (int *)0x0) {
        LOCK();
        iVar17 = uStack_28._4_4_[1] + -1;
        uStack_28._4_4_[1] = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)*uStack_28._4_4_)();
          LOCK();
          piVar10 = piVar9 + 2;
          iVar17 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar17 == 1) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      puVar12 = (undefined4 *)param_5[4];
      if ((((param_7 != (undefined4 *)0x0) && (param_2 != 0.0)) && (param_7 != &DAT_0211a3d8)) &&
         (puVar12 != (undefined4 *)0x0)) {
        *puVar12 = uStack_20;
        puVar12[1] = iStack_1c;
      }
      FUN_00550b30();
      uStack_8 = 0xffffffff;
      piVar9 = (int *)FUN_00550b30();
      param_1 = extraout_ECX_18;
    }
    else {
      puVar12 = (undefined4 *)param_5[1];
      uVar19 = FUN_0088cdc0();
      iVar17 = _tls_index;
      *puVar12 = uVar19;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar17 * 4) + 0x34) < DAT_01ead288) &&
         (FUN_016f3809(&DAT_01ead288), DAT_01ead288 == -1)) {
        DAT_01ead27c = FUN_0057bbb0;
        _DAT_01ead280 = FUN_005880a0;
        DAT_01ead284 = FUN_0057d5e0;
        FUN_016f37bf(&DAT_01ead288);
      }
      puVar16 = (undefined4 *)puVar12[1];
      if ((code **)puVar16 == &DAT_01ead27c) {
        FUN_0056ecd0(&uStack_50);
        uStack_8 = 0xffffffff;
        piVar9 = (int *)FUN_00550b30();
        param_1 = extraout_ECX_16;
      }
      else {
        if (puVar16 != (undefined4 *)0x0) {
          (*(code *)puVar16[2])(puVar12 + 2);
          puVar12[1] = 0;
        }
        puVar12[2] = 0;
        puVar12[3] = 0;
        if (uStack_4c != 0) {
          LOCK();
          *(int *)(uStack_4c + 4) = *(int *)(uStack_4c + 4) + 1;
          UNLOCK();
        }
        puVar12[3] = uStack_4c;
        puVar12[2] = uStack_50;
        puVar12[1] = &DAT_01ead27c;
        uStack_8 = 0xffffffff;
        piVar9 = (int *)FUN_00550b30();
        param_1 = extraout_ECX_17;
      }
    }
    break;
  case (int *)0x1b:
    if (param_6 != 0) {
      ExceptionList = &pvStack_10;
      piVar9 = (int *)FUN_00606b30(param_1);
      if (piVar9 != (int *)0x0) {
        (**(code **)(*piVar9 + 0x290))("codeName",0x24,1,"Tuple",0);
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Tuple cannot be received as a member of another container.");
    }
    ExceptionList = &pvStack_10;
    FUN_006abc60(&param_6,param_2);
    FUN_006192f0(param_6,"Tuple (read)");
    param_3 = (byte *)FUN_01674e20(0xc);
    if (param_3 == (byte *)0x0) {
      pbVar21 = (byte *)0x0;
    }
    else {
      param_3[0] = 0;
      param_3[1] = 0;
      param_3[2] = 0;
      param_3[3] = 0;
      param_3[4] = 0;
      param_3[5] = 0;
      param_3[6] = 0;
      param_3[7] = 0;
      param_3[8] = 0;
      param_3[9] = 0;
      param_3[10] = 0;
      param_3[0xb] = 0;
      pbVar21 = param_3;
    }
    FUN_00557ff0(pbVar21);
    uStack_8 = 0xb;
    FUN_006045c0(param_6,dStack_18._0_4_);
    uVar20 = 0;
    if (param_6 != 0) {
      iVar17 = 0;
      do {
        FUN_0062ca80(param_2,param_4,*dStack_18._0_4_ + iVar17,0,param_7,param_8);
        uVar20 = uVar20 + 1;
        iVar17 = iVar17 + 0xd0;
      } while (uVar20 < param_6);
    }
    FUN_00557fc0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088cbe0();
    *puVar12 = uVar19;
    iVar14 = FUN_00630900();
    iVar17 = puVar12[1];
    if (iVar17 == iVar14) {
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
      }
      puVar12[2] = uStack_20;
      piVar9 = (int *)puVar12[3];
      puVar12[3] = iStack_1c;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar17 = piVar9[1] + -1;
        piVar9[1] = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          piVar10 = piVar9 + 2;
          iVar17 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar17 == 1) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    else {
      if (iVar17 != 0) {
        (**(code **)(iVar17 + 8))(puVar12 + 2);
        puVar12[1] = 0;
      }
      puVar12[2] = 0;
      puVar12[3] = 0;
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
      }
      puVar12[2] = uStack_20;
      puVar12[3] = iStack_1c;
      puVar12[1] = iVar14;
    }
    FUN_00550b30();
    uStack_8 = 0xffffffff;
    piVar9 = (int *)FUN_00550b30();
    param_1 = extraout_ECX_19;
    break;
  case (int *)0x1c:
    ExceptionList = &pvStack_10;
    FUN_006abc60(&uStack_4c,param_2);
    FUN_006192f0(uStack_4c,"ValueArray (read)");
    iStack_1c = FUN_01674e20(0xc);
    uStack_8 = 0xd;
    if (iStack_1c == 0) {
      uVar19 = 0;
    }
    else {
      uVar19 = FUN_00569550(uStack_4c,(int)&param_3 + 3);
    }
    uStack_8 = 0xffffffff;
    FUN_006022c0(uVar19);
    uVar20 = 0;
    uStack_8 = 0xe;
    if (uStack_4c != 0) {
      iVar17 = 0;
      do {
        FUN_0062ca80(param_2,param_4,*dStack_18._0_4_ + iVar17,param_6,param_7,param_8);
        uVar20 = uVar20 + 1;
        iVar17 = iVar17 + 0xd0;
      } while (uVar20 < uStack_4c);
    }
    FUN_00557fc0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_008882f0();
    *puVar12 = uVar19;
    iVar14 = FUN_005c9da0();
    iVar17 = puVar12[1];
    if (iVar17 == iVar14) {
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
      }
      puVar12[2] = uStack_20;
      piVar9 = (int *)puVar12[3];
      puVar12[3] = iStack_1c;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar17 = piVar9[1] + -1;
        piVar9[1] = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          piVar10 = piVar9 + 2;
          iVar17 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar17 == 1) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    else {
      if (iVar17 != 0) {
        (**(code **)(iVar17 + 8))(puVar12 + 2);
        puVar12[1] = 0;
      }
      puVar12[2] = 0;
      puVar12[3] = 0;
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
      }
      puVar12[2] = uStack_20;
      puVar12[3] = iStack_1c;
      puVar12[1] = iVar14;
    }
    FUN_00550b30();
    uStack_8 = 0xffffffff;
    piVar9 = (int *)FUN_00550b30();
    param_1 = extraout_ECX_20;
    break;
  case (int *)0x1d:
    ExceptionList = &pvStack_10;
    FUN_006abc60(&param_3,param_2);
    FUN_006192f0(param_3,"ValueTable (read)");
    param_2 = (float)FUN_01674e20(0x18);
    if (param_2 == 0.0) {
      uVar19 = 0;
    }
    else {
      uVar19 = FUN_005693e0(0xb,(int)&param_2 + 3,(int)&param_2 + 3,(int)&param_2 + 3);
    }
    FUN_005e51d0(uVar19);
    uStack_58 = 0;
    uStack_54 = 0xf;
    apppuStack_68[0] = (undefined4 ***)((uint)apppuStack_68[0] & 0xffffff00);
    pbVar21 = (byte *)0x0;
    uStack_8._0_1_ = 0x11;
    uStack_8._1_3_ = 0;
    if (param_3 != (byte *)0x0) {
      do {
        FUN_006ab8e0(apppuStack_68,uVar20);
        iVar17 = FUN_005c4c00(apppuStack_68);
        FUN_0062ca80(uVar20,param_4,iVar17 + 0x18,param_6,param_7,param_8);
        pbVar21 = pbVar21 + 1;
      } while (pbVar21 < param_3);
    }
    FUN_00557fc0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_008881d0();
    *puVar12 = uVar19;
    iVar14 = FUN_0058c000();
    iVar17 = puVar12[1];
    if (iVar17 == iVar14) {
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
      }
      puVar12[2] = uStack_20;
      piVar9 = (int *)puVar12[3];
      puVar12[3] = iStack_1c;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar17 = piVar9[1] + -1;
        piVar9[1] = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          piVar10 = piVar9 + 2;
          iVar17 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar17 == 1) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    else {
      if (iVar17 != 0) {
        (**(code **)(iVar17 + 8))(puVar12 + 2);
        puVar12[1] = 0;
      }
      puVar12[2] = 0;
      puVar12[3] = 0;
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
      }
      puVar12[2] = uStack_20;
      puVar12[3] = iStack_1c;
      puVar12[1] = iVar14;
    }
    FUN_00550b30();
    FUN_005507b0();
    uStack_8 = 0xffffffff;
    piVar9 = (int *)FUN_00550b30();
    param_1 = extraout_ECX_21;
    break;
  case (int *)0x1e:
    ExceptionList = &pvStack_10;
    FUN_006abc60(&param_2,param_2);
    FUN_006192f0(param_2,"ValueMap (read)");
    param_3 = (byte *)FUN_01674e20(8);
    uStack_8 = 0x13;
    if (param_3 == (byte *)0x0) {
      uVar19 = 0;
    }
    else {
      uVar19 = FUN_0060e3c0();
    }
    uStack_8 = 0xffffffff;
    FUN_00602290(uVar19);
    uStack_58 = 0;
    uStack_54 = 0xf;
    apppuStack_68[0] = (undefined4 ***)((uint)apppuStack_68[0] & 0xffffff00);
    uVar22 = 0;
    uStack_8._0_1_ = 0x15;
    uStack_8._1_3_ = 0;
    if (param_2 != 0.0) {
      do {
        FUN_006ab8e0(apppuStack_68,uVar20);
        uVar19 = FUN_00614050(apppuStack_68);
        FUN_0062ca80(uVar20,param_4,uVar19,param_6,param_7,param_8);
        uVar22 = uVar22 + 1;
      } while (uVar22 < (uint)param_2);
    }
    FUN_00557fc0(&dStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_008880b0();
    *puVar12 = uVar19;
    iVar14 = FUN_00630970();
    iVar17 = puVar12[1];
    if (iVar17 == iVar14) {
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
      }
      puVar12[2] = uStack_20;
      piVar9 = (int *)puVar12[3];
      puVar12[3] = iStack_1c;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar17 = piVar9[1] + -1;
        piVar9[1] = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          piVar10 = piVar9 + 2;
          iVar17 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar17 == 1) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    else {
      if (iVar17 != 0) {
        (**(code **)(iVar17 + 8))(puVar12 + 2);
        puVar12[1] = 0;
      }
      puVar12[2] = 0;
      puVar12[3] = 0;
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
      }
      puVar12[2] = uStack_20;
      puVar12[3] = iStack_1c;
      puVar12[1] = iVar14;
    }
    FUN_00550b30();
    FUN_005507b0();
    uStack_8 = 0xffffffff;
    piVar9 = (int *)FUN_00550b30();
    param_1 = extraout_ECX_22;
    break;
  case (int *)0x1f:
    uStack_94 = 0;
    uStack_90 = 0xf;
    pppuStack_a4 = (undefined4 ***)((uint)pppuStack_a4 & 0xffffff00);
    uStack_8 = 0x17;
    if ((char)param_4 == '\0') {
      ExceptionList = &pvStack_10;
      FUN_006ab8e0(&pppuStack_a4,param_2);
    }
    else {
      ExceptionList = &pvStack_10;
      FUN_00627f10(param_2,&pppuStack_a4);
    }
    FUN_0054ef60(&pppuStack_a4);
    uStack_8._0_1_ = 0x18;
    FUN_009cbbb0(&pppuStack_38);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d190();
    *puVar12 = uVar19;
    iVar14 = FUN_00630cf0();
    iVar17 = puVar12[1];
    if (iVar17 == iVar14) {
      if ((undefined4 ****)(puVar12 + 2) == &pppuStack_38) goto LAB_0060a116;
      FUN_005507b0();
      puVar12[2] = pppuStack_38;
      puVar12[3] = uStack_34;
      puVar12[4] = iStack_30;
      puVar12[5] = uStack_2c;
      *(undefined8 *)(puVar12 + 6) = uStack_28;
      uStack_28 = 0xf00000000;
      pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffffff00);
      uStack_28._4_4_ = (int *)0xf;
    }
    else {
      if (iVar17 != 0) {
        (**(code **)(iVar17 + 8))(puVar12 + 2);
        puVar12[1] = 0;
      }
      puVar12[6] = 0;
      puVar12[7] = 0;
      puVar12[2] = pppuStack_38;
      puVar12[3] = uStack_34;
      puVar12[4] = iStack_30;
      puVar12[5] = uStack_2c;
      *(undefined8 *)(puVar12 + 6) = uStack_28;
      uStack_28 = 0xf00000000;
      pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffffff00);
      puVar12[1] = iVar14;
LAB_0060a116:
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
    if (0xf < uStack_28._4_4_) {
      uVar20 = (int)uStack_28._4_4_ + 1;
      ppppuVar18 = (undefined4 ****)pppuStack_38;
      if (0xfff < uVar20) {
        ppppuVar18 = (undefined4 ****)pppuStack_38[-1];
        uVar20 = (int)uStack_28._4_4_ + 0x24;
        if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar18))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar18,uVar20);
    }
    goto LAB_0060a790;
  case (int *)0x20:
    ExceptionList = &pvStack_10;
    FUN_006abc60(&param_2,param_2);
    uVar20 = (uint)param_2;
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d550();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00631380();
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      puVar12[2] = uVar20;
      piVar9 = param_5;
    }
    else {
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        param_1 = extraout_ECX_23;
      }
      puVar12[2] = uVar20;
      puVar12[1] = param_5;
      piVar9 = param_5;
    }
    break;
  case (int *)0x21:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006ac600(&uStack_2c);
    uStack_8 = 0x1a;
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_00a92ae0();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00630f20();
    iVar17 = puVar12[1];
    if ((int *)iVar17 == param_5) {
      if (puVar12 + 2 != puVar16) {
        FUN_00602a00(*puVar16,puVar16[1],param_5);
        uStack_8 = 0xffffffff;
        piVar9 = (int *)FUN_00617ad0();
        param_1 = extraout_ECX_24;
        break;
      }
    }
    else {
      if (iVar17 != 0) {
        (**(code **)(iVar17 + 8))(puVar12 + 2);
        puVar12[1] = 0;
      }
      FUN_00a92cb0(puVar16,0xe4078678,0x64078678);
      puVar12[1] = param_5;
    }
    uStack_8 = 0xffffffff;
    piVar9 = (int *)FUN_00617ad0();
    param_1 = extraout_ECX_25;
    break;
  case (int *)0x22:
    ExceptionList = &pvStack_10;
    puVar15 = (undefined8 *)FUN_006abea0(&uStack_2c);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_00a92b80();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00630f90();
    goto LAB_006097bb;
  case (int *)0x23:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006ac5d0(&uStack_28);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_00b33310();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00630eb0();
LAB_006094d2:
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      puVar12[2] = *puVar16;
      piVar9 = (int *)puVar16[1];
      puVar12[3] = piVar9;
    }
    else {
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        puVar12[1] = 0;
        param_1 = extraout_ECX_07;
      }
      puVar12[2] = *puVar16;
      puVar12[3] = puVar16[1];
      puVar12[1] = param_5;
      piVar9 = param_5;
    }
    break;
  case (int *)0x24:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006abf40(&uStack_2c);
    uStack_8 = 0x1b;
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_00a8dcc0();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00630c10();
    iVar17 = puVar12[1];
    if ((int *)iVar17 == param_5) {
      if (puVar12 + 2 != puVar16) {
        FUN_00602830(*puVar16,puVar16[1],param_5);
        uStack_8 = 0xffffffff;
        piVar9 = (int *)FUN_00617bc0();
        param_1 = extraout_ECX_26;
        break;
      }
    }
    else {
      if (iVar17 != 0) {
        (**(code **)(iVar17 + 8))(puVar12 + 2);
        puVar12[1] = 0;
      }
      FUN_00a8df50(puVar16);
      puVar12[1] = param_5;
    }
    uStack_8 = 0xffffffff;
    piVar9 = (int *)FUN_00617bc0();
    param_1 = extraout_ECX_27;
    break;
  case (int *)0x25:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006ac070(&uStack_34);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_00a8dd60();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00630c80();
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      puVar12[2] = *puVar16;
      puVar12[3] = puVar16[1];
      puVar12[4] = puVar16[2];
      puVar12[5] = puVar16[3];
      piVar9 = (int *)puVar16[4];
      puVar12[6] = piVar9;
    }
    else {
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        puVar12[1] = 0;
        param_1 = extraout_ECX_28;
      }
      uVar19 = puVar16[1];
      uVar2 = puVar16[2];
      uVar3 = puVar16[3];
      puVar12[2] = *puVar16;
      puVar12[3] = uVar19;
      puVar12[4] = uVar2;
      puVar12[5] = uVar3;
      puVar12[6] = puVar16[4];
      puVar12[1] = param_5;
      piVar9 = param_5;
    }
    break;
  case (int *)0x26:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006ac9d0(&iStack_30);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d410();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_006311c0();
LAB_00609539:
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
LAB_00609543:
      puVar12[2] = *puVar16;
      puVar12[3] = puVar16[1];
      puVar12[4] = puVar16[2];
      piVar9 = (int *)puVar16[3];
      puVar12[5] = piVar9;
    }
    else {
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        puVar12[1] = 0;
        param_1 = extraout_ECX_08;
      }
      uVar19 = puVar16[1];
      uVar2 = puVar16[2];
      uVar3 = puVar16[3];
      puVar12[2] = *puVar16;
      puVar12[3] = uVar19;
      puVar12[4] = uVar2;
      puVar12[5] = uVar3;
      puVar12[1] = param_5;
      piVar9 = param_5;
    }
    break;
  case (int *)0x27:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006ac760(apppuStack_68);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_0088d2d0();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00631070();
LAB_006095a8:
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      uVar19 = puVar16[1];
      uVar2 = puVar16[2];
      uVar3 = puVar16[3];
      puVar12[2] = *puVar16;
      puVar12[3] = uVar19;
      puVar12[4] = uVar2;
      puVar12[5] = uVar3;
      *(undefined8 *)(puVar12 + 6) = *(undefined8 *)(puVar16 + 4);
      piVar9 = param_5;
    }
    else {
LAB_006095c8:
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        puVar12[1] = 0;
        param_1 = extraout_ECX_09;
      }
      uVar19 = puVar16[1];
      uVar2 = puVar16[2];
      uVar3 = puVar16[3];
      puVar12[2] = *puVar16;
      puVar12[3] = uVar19;
      puVar12[4] = uVar2;
      puVar12[5] = uVar3;
      *(undefined8 *)(puVar12 + 6) = *(undefined8 *)(puVar16 + 4);
      puVar12[1] = param_5;
      piVar9 = param_5;
    }
    break;
  case (int *)0x28:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006aca60(auStack_8c);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_00a73110();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00631230();
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      uVar19 = puVar16[1];
      uVar2 = puVar16[2];
      uVar3 = puVar16[3];
      puVar12[2] = *puVar16;
      puVar12[3] = uVar19;
      puVar12[4] = uVar2;
      puVar12[5] = uVar3;
      uVar19 = puVar16[5];
      uVar2 = puVar16[6];
      uVar3 = puVar16[7];
      puVar12[6] = puVar16[4];
      puVar12[7] = uVar19;
      puVar12[8] = uVar2;
      puVar12[9] = uVar3;
      uVar19 = puVar16[9];
      uVar2 = puVar16[10];
      uVar3 = puVar16[0xb];
      puVar12[10] = puVar16[8];
      puVar12[0xb] = uVar19;
      puVar12[0xc] = uVar2;
      puVar12[0xd] = uVar3;
      *(undefined8 *)(puVar12 + 0xe) = *(undefined8 *)(puVar16 + 0xc);
      piVar9 = (int *)puVar16[0xe];
      puVar12[0x10] = piVar9;
    }
    else {
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        puVar12[1] = 0;
        param_1 = extraout_ECX_29;
      }
      uVar19 = puVar16[1];
      uVar2 = puVar16[2];
      uVar3 = puVar16[3];
      puVar12[2] = *puVar16;
      puVar12[3] = uVar19;
      puVar12[4] = uVar2;
      puVar12[5] = uVar3;
      uVar19 = puVar16[5];
      uVar2 = puVar16[6];
      uVar3 = puVar16[7];
      puVar12[6] = puVar16[4];
      puVar12[7] = uVar19;
      puVar12[8] = uVar2;
      puVar12[9] = uVar3;
      uVar19 = puVar16[9];
      uVar2 = puVar16[10];
      uVar3 = puVar16[0xb];
      puVar12[10] = puVar16[8];
      puVar12[0xb] = uVar19;
      puVar12[0xc] = uVar2;
      puVar12[0xd] = uVar3;
      *(undefined8 *)(puVar12 + 0xe) = *(undefined8 *)(puVar16 + 0xc);
      puVar12[0x10] = puVar16[0xe];
      puVar12[1] = param_5;
      piVar9 = param_5;
    }
    break;
  case (int *)0x29:
    ExceptionList = &pvStack_10;
    puVar15 = (undefined8 *)FUN_006acae0(&uStack_2c);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_00b33940();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_006312a0();
LAB_006097bb:
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      *(undefined8 *)(puVar12 + 2) = *puVar15;
      piVar9 = *(int **)(puVar15 + 1);
      puVar12[4] = piVar9;
    }
    else {
LAB_006096da:
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        puVar12[1] = 0;
        param_1 = extraout_ECX_11;
      }
      *(undefined8 *)(puVar12 + 2) = *puVar15;
      puVar12[4] = *(undefined4 *)(puVar15 + 1);
      puVar12[1] = param_5;
      piVar9 = param_5;
    }
    break;
  case (int *)0x2a:
    ExceptionList = &pvStack_10;
    FUN_006ab860(&dStack_18,param_2);
    if (*(int *)(pbVar21 + 8) == 2) {
      param_2 = (float)dStack_18._0_4_;
      goto LAB_0060a4dd;
    }
LAB_006093f6:
    piVar9 = (int *)FUN_00605200(&dStack_18);
    param_1 = extraout_ECX_04;
    break;
  case (int *)0x2b:
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006ac700(apppuStack_68);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_00aa0140();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00631000();
    param_1 = (int *)puVar12[1];
    if (param_1 == param_5) {
      piVar9 = (int *)FUN_00aa1570(puVar16);
      param_1 = extraout_ECX_31;
      break;
    }
    goto LAB_006095c8;
  case (int *)0x2c:
    ExceptionList = &pvStack_10;
    FUN_00565660(0x10,0);
    ppppuVar18 = apppuStack_68;
    if (0xf < uStack_54) {
      ppppuVar18 = (undefined4 ****)apppuStack_68[0];
    }
    uStack_8 = 0x1c;
    FUN_006abe60(ppppuVar18,0x10);
    FUN_0061de50(&param_2,apppuStack_68);
    if (param_2 == 0.0) {
      FUN_00614120(apppuStack_68);
      uVar19 = FUN_0061ee90(&iStack_30,*(undefined4 *)(pbVar21 + 8));
      FUN_00606260(uVar19);
    }
    else if (*(int *)(pbVar21 + 8) == 4) {
      uVar19 = FUN_00a33fa0();
      FUN_0054ef60(uVar19);
      pppuStack_38 = pppuStack_a4;
      pppuStack_a4 = (undefined4 ***)((uint)pppuStack_a4 & 0xffffff00);
      uStack_34 = uStack_a0;
      iStack_30 = iStack_9c;
      uStack_2c = uStack_98;
      uStack_28 = CONCAT44(uStack_90,uStack_94);
      uStack_94 = 0;
      uStack_90 = 0xf;
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
      FUN_00605040(&pppuStack_38);
      FUN_005507b0();
    }
    else {
      FUN_00605190((int)param_2 + 0x20);
    }
    goto LAB_0060a790;
  case (int *)0x2d:
    if (param_1[0x771] == 0) {
      piVar9 = (int *)CONCAT31((int3)((uint)piVar9 >> 8),DAT_01eae4ae);
      ExceptionList = &pvStack_10;
      if (DAT_01eae4ae != '\0') {
        ExceptionList = &pvStack_10;
        piVar9 = (int *)FUN_016774b0(DAT_01eae4ae,
                                     "Can\'t recv protected bytecode due to missing SessionCrypto.",
                                     0);
        param_1 = extraout_ECX_00;
      }
      break;
    }
    ExceptionList = &pvStack_10;
    FUN_00565660(0x10,0);
    uStack_8 = 0;
    FUN_00a33c70();
    uStack_8._0_1_ = 1;
    cVar5 = FUN_00628020(param_2,apppuStack_68,&param_4);
    if (cVar5 == '\0') {
      FUN_00614120(apppuStack_68);
      piVar9 = param_5;
      uStack_2c = 0;
      uStack_28 = 0x500000000;
      iStack_30 = param_5[1];
      FUN_00606260(&iStack_30);
    }
    else {
      uVar19 = FUN_00886a70(&dStack_18,&param_4);
      piVar9 = param_5;
      uStack_8._0_1_ = 2;
      FUN_00605130(uVar19);
      uStack_8._0_1_ = 1;
      FUN_0056cd30();
      FUN_0056cd30();
    }
    cVar5 = FUN_0061f4b0();
    if (cVar5 == '\0') {
      uVar1 = *(undefined2 *)(piVar9 + 5);
      uVar19 = FUN_0061e9a0(&uStack_28);
      FUN_006191b0(param_2,apppuStack_68,uVar19,uVar1);
      FUN_0056cd30();
    }
    else {
      piVar10 = (int *)FUN_0061e9a0(&uStack_28);
      if ((*piVar10 == -1) || (*(short *)(piVar9 + 5) == DAT_018db184)) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Invalid Bytecode.");
      }
      FUN_0056cd30();
    }
    goto LAB_0060a790;
  case (int *)0x2e:
    if (DAT_01d5a0c8 == '\0') {
      ExceptionList = &pvStack_10;
      FUN_016756b0(&uStack_2c,"Cannot read DateTime property value: unhandled type");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&uStack_2c,&DAT_01c17198);
    }
    ExceptionList = &pvStack_10;
    puVar16 = (undefined4 *)FUN_006ac1c0(&iStack_30);
    puVar12 = (undefined4 *)param_5[1];
    uVar19 = FUN_00b38680();
    *puVar12 = uVar19;
    param_5 = (int *)FUN_00630dd0();
    param_1 = (int *)puVar12[1];
    if (param_1 != param_5) {
      if (param_1 != (int *)0x0) {
        (*(code *)param_1[2])(puVar12 + 2);
        puVar12[1] = 0;
        param_1 = extraout_ECX_32;
      }
      puVar12[2] = *puVar16;
      puVar12[3] = puVar16[1];
      puVar12[4] = puVar16[2];
      puVar12[5] = puVar16[3];
      puVar12[1] = param_5;
      piVar9 = param_5;
      break;
    }
    goto LAB_00609543;
  case (int *)0x2f:
    ExceptionList = &pvStack_10;
    bVar7 = FUN_006abe40();
    if ((char)bVar7 < '\0') {
      param_2 = 0.0;
      if ((bVar7 & 0x7f) < 0x7f) {
        param_2 = (float)(uint)(bVar7 & 0x7f);
      }
      else {
        FUN_006abc60(&param_2,uVar20);
        param_2 = (float)((int)param_2 + 0x7f);
      }
      iVar17 = FUN_0061e000(param_2);
      if ((DAT_01d5bb88 != '\0') || (DAT_01d5a0c0 != '\0')) {
        *param_8 = *param_8 + *(int *)(iVar17 + 0x10);
      }
      piVar9 = (int *)FUN_00604fd0(iVar17);
      param_1 = extraout_ECX_33;
      break;
    }
    uStack_28 = 0xf00000000;
    pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffffff00);
    uStack_8 = 0x1e;
    if (0x7e < bVar7) goto LAB_0060a75b;
    uVar22 = (uint)bVar7;
    if ((uint)(*(int *)(uVar20 + 0x18) - *(int *)(uVar20 + 0x20)) < uVar22) {
      uVar19 = FUN_00615980();
      uVar19 = FUN_01675640(apppuStack_68,
                            "BitStream string read: String too long (%u requested %u available)",
                            uVar22,uVar19);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1f);
      FUN_005f8ef0(uVar19);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_b0,&DAT_01c27108);
    }
    FUN_0058a370(uVar22,0);
    ppppuVar18 = &pppuStack_38;
    if (0xf < uStack_28._4_4_) {
      ppppuVar18 = (undefined4 ****)pppuStack_38;
    }
    FUN_006abe60(ppppuVar18,uVar22);
LAB_0060a767:
    if ((DAT_01d5bb88 != '\0') || (DAT_01d5a0c0 != '\0')) {
      *param_8 = *param_8 + (int)uStack_28;
    }
    FUN_00604fd0(&pppuStack_38);
LAB_0060a790:
    uStack_8 = 0xffffffff;
    piVar9 = (int *)FUN_005507b0();
    param_1 = extraout_ECX_34;
  }
  puVar4 = param_8;
  if ((DAT_01d5bb88 != '\0') || (DAT_01d5a0c0 != '\0')) {
    param_7 = (undefined4 *)((uint)param_1 & 0xffffff00);
    param_2 = (float)((uint)piVar9 & 0xffffff00);
    param_5 = (int *)0x1;
    if (param_8[2] != 0) {
      param_7 = (undefined4 *)(uint)(param_8[2] < *param_8);
    }
    cVar5 = (char)param_7;
    if (param_8[3] != 0) {
      param_2 = (float)(uint)(param_8[3] < param_8[1]);
    }
    cVar8 = SUB41(param_2,0);
    if ((DAT_01d5a0c0 != '\0') && ((cVar5 != '\0' || (cVar8 != '\0')))) {
      uStack_58 = 0;
      uStack_54 = 0xf;
      apppuStack_68[0] = (undefined4 ***)((uint)apppuStack_68[0] & 0xffffff00);
      FUN_005542c0("ReplicatorReadVariantLimit",0x1a);
      uStack_8 = 0x20;
      FUN_006289b0(puVar4,apppuStack_68);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      cVar8 = SUB41(param_2,0);
      cVar5 = (char)param_7;
    }
    if (DAT_01d5bb88 != '\0') {
      if (cVar5 != '\0') {
        uVar19 = FUN_01675640(apppuStack_68,
                              "Replicator read variant: Total string data size exceed limit! (%u)",
                              *puVar4);
        uStack_8 = 0x21;
        FUN_005f8ef0(uVar19);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_44,&DAT_01c27108);
      }
      if (cVar8 != '\0') {
        uVar19 = FUN_01675640(&pppuStack_a4,
                              "Replicator read variant: Variant count exceeded limit! (%u)",
                              puVar4[1]);
        uStack_8 = 0x22;
        FUN_005f8ef0(uVar19);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_d4,&DAT_01c27108);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6346 ; VA 0x0060aac0 ; FUN_0060aac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_0060aac0(int *param_1,undefined4 param_2,byte *param_3,undefined4 param_4,int *param_5,
            int param_6,uint param_7,uint *param_8)

{
  int *piVar1;
  uint3 uVar2;
  char cVar3;
  char cVar4;
  int *piVar5;
  undefined4 ****ppppuVar6;
  ushort *puVar7;
  undefined4 uVar8;
  int *extraout_ECX;
  int *extraout_ECX_00;
  int *extraout_ECX_01;
  int *extraout_ECX_02;
  int *extraout_ECX_03;
  int *extraout_ECX_04;
  int *extraout_ECX_05;
  int *extraout_ECX_06;
  int *extraout_ECX_07;
  int *extraout_ECX_08;
  int *extraout_ECX_09;
  int *extraout_ECX_10;
  int *extraout_ECX_11;
  int *extraout_ECX_12;
  int *extraout_ECX_13;
  int *extraout_ECX_14;
  int *extraout_ECX_15;
  int *extraout_ECX_16;
  int *extraout_ECX_17;
  int *extraout_ECX_18;
  int *extraout_ECX_19;
  int *extraout_ECX_20;
  int *extraout_ECX_21;
  int *extraout_ECX_22;
  int *extraout_ECX_23;
  int *extraout_ECX_24;
  int *extraout_ECX_25;
  int *extraout_ECX_26;
  int *extraout_ECX_27;
  int *extraout_ECX_28;
  int *extraout_ECX_29;
  int *extraout_ECX_30;
  int *extraout_ECX_31;
  int *extraout_ECX_32;
  int *extraout_ECX_33;
  int *extraout_ECX_34;
  int *extraout_ECX_35;
  int *extraout_ECX_36;
  int *extraout_ECX_37;
  int *extraout_ECX_38;
  int *extraout_ECX_39;
  int *extraout_ECX_40;
  int *extraout_ECX_41;
  uint *puVar9;
  int iVar10;
  undefined auStack_c4 [68];
  undefined auStack_80 [8];
  undefined auStack_78 [2];
  undefined4 uStack_76;
  undefined2 uStack_72;
  undefined auStack_70 [12];
  undefined auStack_64 [24];
  undefined4 ***pppuStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d226;
  pvStack_10 = ExceptionList;
  if (*param_3 == 0) {
    ExceptionList = &pvStack_10;
    FUN_016756b0();
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8();
  }
  piVar5 = (int *)(*param_3 - 2);
  ExceptionList = &pvStack_10;
  switch(piVar5) {
  case (int *)0x0:
    if ((DAT_01d5bb80 != '\0') || (ExceptionList = &pvStack_10, DAT_01d5a0c0 != '\0')) {
      uStack_3c = 0;
      uStack_38 = 0xf;
      pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c._1_3_ << 8);
      ExceptionList = &pvStack_10;
      FUN_005507b0();
    }
    pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c & 0xffffff00);
    uStack_8 = 4;
LAB_0060ac65:
    uStack_38 = 0xf;
    uStack_3c = 0;
    FUN_006ad360();
    goto LAB_0060b4ad;
  case (int *)0x1:
    break;
  default:
    ExceptionList = &pvStack_10;
    FUN_016756b0();
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8();
  case (int *)0x4:
    ExceptionList = &pvStack_10;
    FUN_008866d0();
    uStack_8 = 3;
    FUN_006329a0(param_2,auStack_78,param_7);
    goto LAB_0060abe2;
  case (int *)0x5:
  case (int *)0x20:
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ad4e0();
    param_1 = extraout_ECX;
    break;
  case (int *)0x6:
    if (*(int *)(param_3 + 8) == 3) {
      ExceptionList = &pvStack_10;
      FUN_00a33c70();
      uStack_8 = 5;
      if ((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) {
        iVar10 = FUN_00a33fa0();
        *param_8 = *param_8 + *(int *)(iVar10 + 0x10);
      }
      FUN_00a33fa0(param_2);
      FUN_006ad360();
      uStack_8 = 0xffffffff;
      piVar5 = (int *)FUN_0056cd30();
      param_1 = extraout_ECX_01;
    }
    else {
      uStack_3c = 0;
      uStack_38 = 0xf;
      pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c._1_3_ << 8);
      uStack_8 = 6;
      ExceptionList = &pvStack_10;
      FUN_006ad360();
      uStack_8 = 0xffffffff;
      piVar5 = (int *)FUN_005507b0();
      param_1 = extraout_ECX_02;
    }
    break;
  case (int *)0x7:
    param_7 = param_7 & 0xffffff00;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ad5e0();
    param_1 = extraout_ECX_03;
    break;
  case (int *)0x8:
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ad340();
    param_1 = extraout_ECX_04;
    break;
  case (int *)0x9:
    param_7 = 0;
    ExceptionList = &pvStack_10;
    FUN_006a5c10(&param_7,&param_6,4);
    piVar5 = (int *)FUN_006ad5e0();
    param_1 = extraout_ECX_05;
    break;
  case (int *)0xa:
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    FUN_006a5c10(&uStack_18,auStack_78,8);
    piVar5 = (int *)FUN_006ad5e0();
    param_1 = extraout_ECX_06;
    break;
  case (int *)0xb:
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ae670(&uStack_18);
    param_1 = extraout_ECX_07;
    break;
  case (int *)0xc:
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ae640(&uStack_20);
    param_1 = extraout_ECX_08;
    break;
  case (int *)0xd:
    uStack_3c = 0;
    pppuStack_4c = (undefined4 ****)0x0;
    uStack_48 = 0;
    uStack_44 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ae2d0(&pppuStack_4c);
    param_1 = extraout_ECX_09;
    break;
  case (int *)0xe:
    ExceptionList = &pvStack_10;
    FUN_0054d840(0);
    piVar5 = (int *)FUN_006ad500(&param_7);
    param_1 = extraout_ECX_10;
    break;
  case (int *)0xf:
    ExceptionList = &pvStack_10;
    FUN_0054d840(0);
    piVar5 = (int *)FUN_006ad500(&param_7);
    param_1 = extraout_ECX_11;
    break;
  case (int *)0x10:
    param_7 = 0xc2;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ad570(&param_7);
    param_1 = extraout_ECX_12;
    break;
  case (int *)0x11:
    uStack_1c = 0;
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ad640(&uStack_1c);
    param_1 = extraout_ECX_13;
    break;
  case (int *)0x12:
    uVar2 = (uint3)param_7;
    param_7 = (uint)(uVar2 & 0xff);
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ad780((int)&param_7 + 1);
    param_1 = extraout_ECX_14;
    break;
  case (int *)0x13:
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006addc0(&uStack_18);
    param_1 = extraout_ECX_15;
    break;
  case (int *)0x14:
    uStack_1c = 0;
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ad640(&uStack_1c);
    param_1 = extraout_ECX_16;
    break;
  case (int *)0x16:
    param_7 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ae750(&param_7);
    param_1 = extraout_ECX_17;
    break;
  case (int *)0x17:
    uStack_76 = 0;
    uStack_72 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ae7f0(&uStack_76);
    param_1 = extraout_ECX_18;
    break;
  case (int *)0x18:
    ExceptionList = &pvStack_10;
    FUN_00607690();
    piVar5 = (int *)FUN_006acfc0();
    param_1 = extraout_ECX_19;
    break;
  case (int *)0x19:
    ExceptionList = &pvStack_10;
    uVar8 = FUN_00607690(auStack_64);
    piVar5 = (int *)FUN_006adad0(uVar8);
    param_1 = extraout_ECX_20;
    break;
  case (int *)0x1a:
    uStack_18 = *(undefined8 *)param_5;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006b92d0();
    param_1 = extraout_ECX_21;
    break;
  case (int *)0x1b:
    if (param_6 != 0) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Tuple cannot be sent as a member of another container.");
    }
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    FUN_00550b30();
    FUN_006192f0();
    piVar5 = (int *)FUN_006ad4e0();
    param_1 = extraout_ECX_22;
    break;
  case (int *)0x1c:
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    FUN_00550b30();
    iVar10 = (_DAT_00000004 - (int)_DAT_00000000) / 0xd0;
    FUN_006192f0();
    piVar5 = (int *)FUN_006ad4e0();
    puVar9 = param_8;
    param_1 = extraout_ECX_23;
    if (iVar10 != 0) {
      param_5 = (int *)0x0;
      do {
        piVar5 = (int *)FUN_0062cc40(param_2,param_4,(int)_DAT_00000000 + (int)param_5,param_6,
                                     param_7,puVar9);
        param_1 = param_5 + 0x34;
        iVar10 = iVar10 + -1;
        param_5 = param_1;
      } while (iVar10 != 0);
    }
    goto LAB_0060b4bc;
  case (int *)0x1d:
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    FUN_00550b30();
    FUN_006192f0();
    FUN_006ad4e0();
    piVar5 = (int *)FUN_00618a80(&param_5);
    param_1 = extraout_ECX_24;
    for (piVar1 = param_5; piVar1 != (int *)0x0; piVar1 = (int *)*piVar1) {
      FUN_006ad360();
      piVar5 = (int *)FUN_0062cc40(param_2,param_4,piVar1 + 8,param_6,param_7,param_8);
      param_1 = extraout_ECX_25;
    }
    break;
  case (int *)0x1e:
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    FUN_00550b30();
    FUN_006192f0();
    FUN_006ad4e0();
    piVar5 = (int *)*_DAT_00000000;
    param_1 = extraout_ECX_26;
    while (param_5 = piVar5, piVar5 != _DAT_00000000) {
      FUN_006ad360();
      FUN_0062cc40(param_2,param_4,piVar5 + 10,param_6,param_7,param_8);
      FUN_00551320();
      piVar5 = param_5;
      param_1 = extraout_ECX_27;
    }
    break;
  case (int *)0x1f:
    uStack_3c = 0;
    uStack_38 = 0xf;
    pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c._1_3_ << 8);
    if ((char)param_4 == '\0') {
      uStack_8 = 8;
      ExceptionList = &pvStack_10;
      goto LAB_0060ac65;
    }
    uStack_8 = 7;
    ExceptionList = &pvStack_10;
    FUN_006326e0();
    goto LAB_0060b4ad;
  case (int *)0x21:
    ExceptionList = &pvStack_10;
    FUN_00a92e30(0);
    uStack_8 = 9;
    FUN_006adea0(&uStack_1c);
    uStack_8 = 0xffffffff;
    piVar5 = (int *)FUN_00617ad0();
    param_1 = extraout_ECX_28;
    break;
  case (int *)0x22:
    uStack_1c = 0;
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ad640(&uStack_1c);
    param_1 = extraout_ECX_29;
    break;
  case (int *)0x23:
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006addc0(&uStack_18);
    param_1 = extraout_ECX_30;
    break;
  case (int *)0x24:
    uStack_18 = CONCAT44(0x3f800000,(undefined4)uStack_18);
    ExceptionList = &pvStack_10;
    FUN_00a8e2b0(CONCAT44(DAT_018ce2f8,DAT_018ce2f8),0x3f800000);
    uStack_8 = 10;
    FUN_006ad850(&uStack_1c);
    uStack_8 = 0xffffffff;
    piVar5 = (int *)FUN_00617bc0();
    param_1 = extraout_ECX_31;
    break;
  case (int *)0x25:
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ad9e0(&uStack_24);
    param_1 = extraout_ECX_32;
    break;
  case (int *)0x26:
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ae300(&uStack_20);
    param_1 = extraout_ECX_33;
    break;
  case (int *)0x27:
    pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c._1_3_ << 8);
    uStack_48 = 0;
    uStack_44 = 0;
    uStack_40 = 0;
    uStack_3c = 0;
    uStack_38 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006adfe0(&pppuStack_4c);
    param_1 = extraout_ECX_34;
    break;
  case (int *)0x28:
    ExceptionList = &pvStack_10;
    FUN_00a73410();
    piVar5 = (int *)FUN_006ae340(auStack_70);
    param_1 = extraout_ECX_35;
    break;
  case (int *)0x29:
    uStack_1c = 0;
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ae380(&uStack_1c);
    param_1 = extraout_ECX_36;
    break;
  case (int *)0x2a:
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_006ad310(0,0,param_2);
    param_1 = extraout_ECX_37;
    break;
  case (int *)0x2b:
    ExceptionList = &pvStack_10;
    FUN_00aa1120();
    piVar5 = (int *)FUN_006adf60(&pppuStack_4c);
    param_1 = extraout_ECX_38;
    break;
  case (int *)0x2c:
    ExceptionList = &pvStack_10;
    FUN_00a33c70();
    uStack_8 = 0xb;
    if (*(int *)(param_3 + 8) == 4) {
      uStack_3c = 0;
      uStack_38 = 0xf;
      pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c & 0xffffff00);
      uStack_8._0_1_ = 0xc;
      uStack_8._1_3_ = 0;
      uVar8 = FUN_0054ef60(&pppuStack_4c);
      uStack_8._0_1_ = 0xd;
      uVar8 = FUN_00a33be0(uVar8);
      FUN_00613ff0(uVar8);
      FUN_0056cd30();
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      FUN_005507b0();
    }
    else {
      FUN_00a33c70();
      FUN_00613ff0(&param_4);
      FUN_0056cd30();
    }
    FUN_00a33fb0(&uStack_20);
    FUN_006ad5e0();
    FUN_00606220(&param_6);
    uStack_8 = 0xffffffff;
    piVar5 = (int *)FUN_0056cd30();
    param_1 = extraout_ECX_39;
    break;
  case (int *)0x2d:
    ExceptionList = &pvStack_10;
    FUN_008866d0();
    uStack_8 = 0;
    if (param_1[0x771] == 0) {
      if (DAT_01eae4ae != '\0') {
        FUN_016774b0(DAT_01eae4ae,"Can\'t send protected bytecode due to missing SessionCrypto.",0);
      }
    }
    else {
      (**(code **)(*param_1 + 0x1e8))();
      uStack_8._0_1_ = 1;
      FUN_006329a0(param_2,&param_6,param_7);
      FUN_00565660();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      ppppuVar6 = &pppuStack_4c;
      if (0xf < uStack_38) {
        ppppuVar6 = (undefined4 ****)pppuStack_4c;
      }
      FUN_00a33fb0(ppppuVar6);
      cVar3 = FUN_0061f4b0();
      if (cVar3 == '\0') {
        uStack_18 = 0xffffffff;
        FUN_00632880(param_2,&pppuStack_4c,&uStack_18,DAT_018db184);
      }
      FUN_005507b0();
      FUN_0056cd30();
    }
LAB_0060abe2:
    uStack_8 = 0xffffffff;
    FUN_0056cd30();
    piVar5 = (int *)FUN_0056cd30();
    param_1 = extraout_ECX_00;
    break;
  case (int *)0x2e:
    if (DAT_01d5a0c8 == '\0') {
      ExceptionList = &pvStack_10;
      FUN_016756b0();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8();
    }
    uStack_18 = 0x7ffffffffffffffe;
    ExceptionList = &pvStack_10;
    FUN_0056a9c0(0);
    FUN_005672c0();
    FUN_0061f5c0();
    piVar5 = (int *)FUN_006adcb0(auStack_80);
    param_1 = extraout_ECX_40;
    break;
  case (int *)0x2f:
    uStack_18 = 0xf00000000;
    uStack_28 = uStack_28 & 0xffffff00;
    uStack_8 = 0xe;
    ExceptionList = &pvStack_10;
    puVar7 = (ushort *)FUN_0061dca0(&uStack_28);
    if (puVar7 == (ushort *)0x0) {
      param_7 = (uint)param_7._1_3_ << 8;
      FUN_006ad5e0();
    }
    else {
      if (0x7e < *puVar7) {
        param_7 = CONCAT31(param_7._1_3_,0xff);
        FUN_006ad5e0();
        FUN_006ad4e0();
        goto LAB_0060b4ad;
      }
      param_7 = CONCAT31(param_7._1_3_,(char)*puVar7) | 0x80;
    }
    FUN_006ad5e0();
LAB_0060b4ad:
    uStack_8 = 0xffffffff;
    piVar5 = (int *)FUN_005507b0();
    param_1 = extraout_ECX_41;
  }
  puVar9 = param_8;
LAB_0060b4bc:
  if ((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) {
    param_7 = (uint)param_1 & 0xffffff00;
    param_8 = (uint *)((uint)piVar5 & 0xffffff00);
    if (puVar9[2] != 0) {
      param_7 = (uint)(puVar9[2] < *puVar9);
    }
    cVar3 = (char)param_7;
    if (puVar9[3] != 0) {
      param_8 = (uint *)(uint)(puVar9[3] < puVar9[1]);
    }
    cVar4 = (char)param_8;
    if ((DAT_01d5a0c0 != '\0') && ((cVar3 != '\0' || (cVar4 != '\0')))) {
      uStack_3c = 0;
      uStack_38 = 0xf;
      pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c & 0xffffff00);
      FUN_005542c0();
      uStack_8 = 0xf;
      FUN_006289b0();
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      cVar4 = (char)param_8;
      cVar3 = (char)param_7;
    }
    if (DAT_01d5bb80 != '\0') {
      if (cVar3 != '\0') {
        uVar8 = FUN_01675640(&pppuStack_4c,
                             "Replicator send variant: Total string data size exceed limit! (%u)",
                             *puVar9);
        uStack_8 = 0x10;
        FUN_005f8ef0(uVar8);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8();
      }
      if (cVar4 != '\0') {
        uVar8 = FUN_01675640(auStack_c4,
                             "Replicator send variant: Variant count exceeded limit! (%u)",puVar9[1]
                            );
        uStack_8 = 0x11;
        FUN_005f8ef0(uVar8);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6347 ; VA 0x0060b720 ; FUN_0060b720 */

void __thiscall
FUN_0060b720(int *param_1,undefined4 param_2,byte *param_3,ushort *param_4,code *param_5,
            int *param_6,uint param_7,uint *param_8)

{
  int *piVar1;
  undefined4 *puVar2;
  uint *puVar3;
  char cVar4;
  undefined uVar5;
  char cVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 ****ppppuVar9;
  undefined4 uVar10;
  int *extraout_ECX;
  int *extraout_ECX_00;
  int *extraout_ECX_01;
  int *extraout_ECX_02;
  int *extraout_ECX_03;
  int *extraout_ECX_04;
  int *extraout_ECX_05;
  int *extraout_ECX_06;
  int *extraout_ECX_07;
  int *extraout_ECX_08;
  int *extraout_ECX_09;
  int *extraout_ECX_10;
  int *extraout_ECX_11;
  int *extraout_ECX_12;
  int *extraout_ECX_13;
  int *extraout_ECX_14;
  int *extraout_ECX_15;
  int *extraout_ECX_16;
  int *extraout_ECX_17;
  int *extraout_ECX_18;
  int *extraout_ECX_19;
  int *extraout_ECX_20;
  int *extraout_ECX_21;
  int *extraout_ECX_22;
  int *extraout_ECX_23;
  int *extraout_ECX_24;
  int *extraout_ECX_25;
  int *extraout_ECX_26;
  int *extraout_ECX_27;
  int *extraout_ECX_28;
  int *extraout_ECX_29;
  int *extraout_ECX_30;
  int *extraout_ECX_31;
  int *extraout_ECX_32;
  int *extraout_ECX_33;
  int *extraout_ECX_34;
  int *extraout_ECX_35;
  int *extraout_ECX_36;
  int *extraout_ECX_37;
  int *extraout_ECX_38;
  int *extraout_ECX_39;
  int *extraout_ECX_40;
  int *extraout_ECX_41;
  int *extraout_ECX_42;
  int *extraout_ECX_43;
  int *extraout_ECX_44;
  int *extraout_ECX_45;
  int *extraout_ECX_46;
  int *extraout_ECX_47;
  int *extraout_ECX_48;
  int *extraout_ECX_49;
  int *extraout_ECX_50;
  int *extraout_ECX_51;
  int *extraout_ECX_52;
  float10 fVar11;
  undefined8 uVar12;
  undefined auStack_cc [24];
  undefined auStack_b4 [36];
  undefined auStack_90 [12];
  undefined auStack_84 [24];
  undefined auStack_6c [24];
  undefined auStack_54 [12];
  undefined4 ***apppuStack_48 [4];
  int iStack_38;
  uint uStack_34;
  undefined4 ***pppuStack_30;
  undefined auStack_2c [4];
  undefined auStack_28 [4];
  undefined auStack_24 [4];
  undefined8 uStack_20;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar3 = param_8;
  piVar1 = (int *)param_5;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d2c3;
  pvStack_10 = ExceptionList;
  piStack_14 = param_1;
  if (*param_3 == 0) {
    ExceptionList = &pvStack_10;
    FUN_016756b0(auStack_24,"Invalid schema type for writing value");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  puVar7 = (undefined4 *)(*param_3 - 2);
  ExceptionList = &pvStack_10;
  switch(puVar7) {
  case (undefined4 *)0x0:
    if ((DAT_01d5bb80 != '\0') || (ExceptionList = &pvStack_10, DAT_01d5a0c0 != '\0')) {
      ExceptionList = &pvStack_10;
      (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))
                (apppuStack_48,*(int *)param_5);
      *puVar3 = *puVar3 + iStack_38;
      FUN_005507b0();
    }
    (**(code **)(**(int **)(piVar1[1] + 0x34) + 0xc))(apppuStack_48,*piVar1);
    uStack_8 = 4;
    goto LAB_0060b8f4;
  case (undefined4 *)0x1:
    break;
  default:
    ExceptionList = &pvStack_10;
    FUN_016756b0(auStack_24,"Attempted to send value with unknown network format");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  case (undefined4 *)0x4:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&uStack_18,*(int *)param_5);
    uStack_8 = 3;
    FUN_006329a0(param_2,&uStack_18,param_7);
    goto LAB_0060b85e;
  case (undefined4 *)0x5:
    ExceptionList = &pvStack_10;
    uVar10 = (**(code **)(**(int **)((int)param_5 + 4) + 0x44))(*(int *)param_5,param_2);
    puVar7 = (undefined4 *)FUN_006ad4e0(uVar10);
    param_1 = extraout_ECX;
    break;
  case (undefined4 *)0x6:
    if (*(int *)(param_3 + 8) == 3) {
      ExceptionList = &pvStack_10;
      (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&param_5);
      uStack_8 = 5;
      if ((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) {
        iVar8 = FUN_00a33fa0();
        *puVar3 = *puVar3 + *(int *)(iVar8 + 0x10);
      }
      uVar10 = FUN_00a33fa0(param_2);
      FUN_006ad360(uVar10);
      uStack_8 = 0xffffffff;
      puVar7 = (undefined4 *)FUN_0056cd30();
      param_1 = extraout_ECX_02;
    }
    else {
      ExceptionList = &pvStack_10;
      (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))
                (apppuStack_48,*(int *)param_5);
      uStack_8 = 6;
      if ((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) {
        *puVar3 = *puVar3 + iStack_38;
      }
      FUN_006ad360(apppuStack_48,param_2);
      uStack_8 = 0xffffffff;
      puVar7 = (undefined4 *)FUN_005507b0();
      param_1 = extraout_ECX_03;
    }
    break;
  case (undefined4 *)0x7:
    ExceptionList = &pvStack_10;
    uVar5 = (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(*(int *)param_5);
    param_5 = (code *)CONCAT31(param_5._1_3_,uVar5);
    puVar7 = (undefined4 *)FUN_006ad5e0(&param_5,1);
    param_1 = extraout_ECX_04;
    break;
  case (undefined4 *)0x8:
    if (*(int *)(param_3 + 8) == 1) {
      ExceptionList = &pvStack_10;
      uVar10 = (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))();
      puVar7 = (undefined4 *)FUN_006ad340(uVar10,param_2);
      param_1 = extraout_ECX_05;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar10 = (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(*(int *)param_5);
      puVar7 = (undefined4 *)FUN_006ad340(uVar10,param_2);
      param_1 = extraout_ECX_06;
    }
    break;
  case (undefined4 *)0x9:
    iVar8 = *(int *)param_5;
    param_5 = *(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc);
    ExceptionList = &pvStack_10;
    fVar11 = (float10)(*param_5)(iVar8);
    param_5 = (code *)(float)fVar11;
    FUN_006a5c10(&param_5,&param_7,4);
    puVar7 = (undefined4 *)FUN_006ad5e0(&param_7,4);
    param_1 = extraout_ECX_07;
    break;
  case (undefined4 *)0xa:
    iVar8 = *(int *)param_5;
    param_5 = *(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc);
    ExceptionList = &pvStack_10;
    fVar11 = (float10)(*param_5)(iVar8);
    uStack_20 = (double)fVar11;
    FUN_006a5c10(&uStack_20,&uStack_18,8);
    puVar7 = (undefined4 *)FUN_006ad5e0(&uStack_18,8);
    param_1 = extraout_ECX_08;
    break;
  case (undefined4 *)0xb:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&uStack_20,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ae670(&uStack_20);
    param_1 = extraout_ECX_09;
    break;
  case (undefined4 *)0xc:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_28,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ae640(auStack_28);
    param_1 = extraout_ECX_10;
    break;
  case (undefined4 *)0xd:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))
              (apppuStack_48,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ae2d0(apppuStack_48);
    param_1 = extraout_ECX_11;
    break;
  case (undefined4 *)0xe:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&param_5,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ad500(&param_5);
    param_1 = extraout_ECX_12;
    break;
  case (undefined4 *)0xf:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&param_5,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ad500(&param_5);
    param_1 = extraout_ECX_13;
    break;
  case (undefined4 *)0x10:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&param_5,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ad570(&param_5);
    param_1 = extraout_ECX_14;
    break;
  case (undefined4 *)0x11:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_24,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ad640(auStack_24);
    param_1 = extraout_ECX_15;
    break;
  case (undefined4 *)0x12:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))
              ((int)&param_5 + 1,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ad780((int)&param_5 + 1);
    param_1 = extraout_ECX_16;
    break;
  case (undefined4 *)0x13:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&uStack_20,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006addc0(&uStack_20);
    param_1 = extraout_ECX_17;
    break;
  case (undefined4 *)0x14:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_24,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ad640(auStack_24);
    param_1 = extraout_ECX_18;
    break;
  case (undefined4 *)0x16:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&param_5,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ae750(&param_5);
    param_1 = extraout_ECX_19;
    break;
  case (undefined4 *)0x17:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))
              ((int)&uStack_18 + 2,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ae7f0((int)&uStack_18 + 2);
    param_1 = extraout_ECX_20;
    break;
  case (undefined4 *)0x18:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_84,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006acfc0(auStack_84,param_2);
    param_1 = extraout_ECX_21;
    break;
  case (undefined4 *)0x19:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_84,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006adad0(auStack_84);
    param_1 = extraout_ECX_22;
    break;
  case (undefined4 *)0x1a:
    ExceptionList = &pvStack_10;
    iVar8 = (**(code **)(**(int **)((int)param_5 + 4) + 0x44))(*(int *)param_5);
    if (iVar8 == 0) {
      uStack_18 = 0xffffffff;
      piStack_14 = (int *)0x0;
      puVar7 = (undefined4 *)FUN_006b92d0(param_2,&uStack_18);
      param_1 = extraout_ECX_24;
    }
    else {
      uStack_18 = *(undefined4 *)(iVar8 + 0x18);
      piStack_14 = *(int **)(iVar8 + 0x1c);
      puVar7 = (undefined4 *)FUN_006b92d0(param_2,&uStack_18);
      param_1 = extraout_ECX_23;
    }
    break;
  case (undefined4 *)0x1b:
    if (param_6 != (int *)0x0) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Tuple cannot be sent as a member of another container.");
    }
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&uStack_20,*(int *)param_5);
    piVar1 = (int *)uStack_20;
    param_6 = (int *)uStack_20;
    FUN_00550b30();
    if (piVar1 == (int *)0x0) {
      iVar8 = 0;
    }
    else {
      iVar8 = (piVar1[1] - *piVar1) / 0xd0;
    }
    FUN_006192f0(iVar8,"Tuple (write)");
    puVar7 = (undefined4 *)FUN_006ad4e0(iVar8,param_2);
    param_1 = extraout_ECX_25;
    if (iVar8 != 0) {
      param_5 = (code *)0x0;
      do {
        puVar7 = (undefined4 *)
                 FUN_0062cc40(param_2,param_4,*param_6 + (int)param_5,0,param_7,puVar3);
        param_1 = (int *)((int)param_5 + 0xd0);
        iVar8 = iVar8 + -1;
        param_5 = (code *)param_1;
      } while (iVar8 != 0);
    }
    break;
  case (undefined4 *)0x1c:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&uStack_20,*(int *)param_5);
    piVar1 = (int *)uStack_20;
    FUN_00550b30();
    iVar8 = (piVar1[1] - *piVar1) / 0xd0;
    param_5 = (code *)iVar8;
    FUN_006192f0(iVar8,"ValueArray (write)");
    puVar7 = (undefined4 *)FUN_006ad4e0(iVar8,param_2);
    param_1 = extraout_ECX_26;
    if (iVar8 != 0) {
      iVar8 = 0;
      do {
        puVar7 = (undefined4 *)FUN_0062cc40(param_2,param_4,*piVar1 + iVar8,param_6,param_7,puVar3);
        iVar8 = iVar8 + 0xd0;
        param_5 = (code *)((int)param_5 + -1);
        param_1 = extraout_ECX_27;
      } while (param_5 != (code *)0x0);
    }
    break;
  case (undefined4 *)0x1d:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&uStack_20,*(int *)param_5);
    iVar8 = (int)(int *)uStack_20;
    FUN_00550b30();
    uVar10 = *(undefined4 *)(iVar8 + 8);
    FUN_006192f0(uVar10,"ValueTable (write)");
    FUN_006ad4e0(uVar10,param_2);
    puVar7 = (undefined4 *)FUN_00618a80(&param_5);
    param_1 = extraout_ECX_28;
    for (piVar1 = (int *)param_5; piVar1 != (int *)0x0; piVar1 = (int *)*piVar1) {
      FUN_006ad360(piVar1 + 2,param_2);
      puVar7 = (undefined4 *)FUN_0062cc40(param_2,param_4,piVar1 + 8,param_6,param_7,puVar3);
      param_1 = extraout_ECX_29;
    }
    break;
  case (undefined4 *)0x1e:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&uStack_20,*(int *)param_5);
    piVar1 = (int *)uStack_20;
    FUN_00550b30();
    iVar8 = piVar1[1];
    FUN_006192f0(iVar8,"ValueMap (write)");
    FUN_006ad4e0(iVar8,param_2);
    puVar2 = (undefined4 *)*piVar1;
    puVar7 = (undefined4 *)*puVar2;
    param_1 = extraout_ECX_30;
    while (puVar7 != puVar2) {
      param_5 = (code *)puVar7;
      FUN_006ad360(puVar7 + 4,param_2);
      FUN_0062cc40(param_2,param_4,puVar7 + 10,param_6,param_7,puVar3);
      FUN_00551320();
      puVar7 = (undefined4 *)param_5;
      param_1 = extraout_ECX_31;
    }
    break;
  case (undefined4 *)0x1f:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)((int)param_5 + 4) + 0x30))(apppuStack_48,*(int *)param_5);
    if ((char)param_4 != '\0') {
      uStack_8 = 7;
      FUN_006326e0(param_2,apppuStack_48);
      uStack_8 = 0xffffffff;
      puVar7 = (undefined4 *)FUN_005507b0();
      param_1 = extraout_ECX_32;
      break;
    }
    uStack_8 = 8;
LAB_0060b8f4:
    FUN_006ad360(apppuStack_48,param_2);
    uStack_8 = 0xffffffff;
    puVar7 = (undefined4 *)FUN_005507b0();
    param_1 = extraout_ECX_01;
    break;
  case (undefined4 *)0x20:
    ExceptionList = &pvStack_10;
    cVar4 = (**(code **)(*param_1 + 0x1f8))(*(int *)param_5,*(int *)((int)param_5 + 4));
    if (cVar4 == '\0') {
      (**(code **)(**(int **)(piVar1[1] + 0x34) + 0xc))(&param_5,*piVar1);
      puVar7 = (undefined4 *)FUN_006ad4e0(param_5,param_2);
      param_1 = extraout_ECX_34;
    }
    else {
      puVar7 = (undefined4 *)FUN_006ad4e0(3,param_2);
      param_1 = extraout_ECX_33;
    }
    break;
  case (undefined4 *)0x21:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_24,*(int *)param_5);
    uStack_8 = 9;
    FUN_006adea0(auStack_24);
    uStack_8 = 0xffffffff;
    puVar7 = (undefined4 *)FUN_00617ad0();
    param_1 = extraout_ECX_35;
    break;
  case (undefined4 *)0x22:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_24,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ad640(auStack_24);
    param_1 = extraout_ECX_36;
    break;
  case (undefined4 *)0x23:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&uStack_20,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006addc0(&uStack_20);
    param_1 = extraout_ECX_37;
    break;
  case (undefined4 *)0x24:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_24,*(int *)param_5);
    uStack_8 = 10;
    FUN_006ad850(auStack_24);
    uStack_8 = 0xffffffff;
    puVar7 = (undefined4 *)FUN_00617bc0();
    param_1 = extraout_ECX_38;
    break;
  case (undefined4 *)0x25:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_2c,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ad9e0(auStack_2c);
    param_1 = extraout_ECX_39;
    break;
  case (undefined4 *)0x26:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_28,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ae300(auStack_28);
    param_1 = extraout_ECX_40;
    break;
  case (undefined4 *)0x27:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))
              (apppuStack_48,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006adfe0(apppuStack_48);
    param_1 = extraout_ECX_41;
    break;
  case (undefined4 *)0x28:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_90,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ae340(auStack_90);
    param_1 = extraout_ECX_42;
    break;
  case (undefined4 *)0x29:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_24,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006ae380(auStack_24);
    param_1 = extraout_ECX_43;
    break;
  case (undefined4 *)0x2a:
    if (*(int *)(param_3 + 8) == 2) {
      ExceptionList = &pvStack_10;
      iVar8 = (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))();
      puVar7 = (undefined4 *)FUN_006ad310(iVar8,iVar8 >> 0x1f,param_2);
      param_1 = extraout_ECX_44;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar12 = (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(*(int *)param_5);
      puVar7 = (undefined4 *)FUN_006ad310(uVar12,param_2);
      param_1 = extraout_ECX_45;
    }
    break;
  case (undefined4 *)0x2b:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))
              (apppuStack_48,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006adf60(apppuStack_48);
    param_1 = extraout_ECX_46;
    break;
  case (undefined4 *)0x2c:
    ExceptionList = &pvStack_10;
    FUN_00a33c70();
    uStack_8 = 0xb;
    if (*(int *)(param_3 + 8) == 4) {
      (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(apppuStack_48);
      uStack_8._0_1_ = 0xc;
      uVar10 = FUN_0054ef60(apppuStack_48);
      uStack_8._0_1_ = 0xd;
      uVar10 = FUN_00a33be0(uVar10);
      FUN_00613ff0(uVar10);
      FUN_0056cd30();
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      FUN_005507b0();
    }
    else {
      (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&param_5,*(int *)param_5);
      FUN_00613ff0(&param_5);
      FUN_0056cd30();
    }
    FUN_00a33fb0(auStack_28);
    FUN_006ad5e0(auStack_28,0x10);
    FUN_00606220(&param_4);
    uStack_8 = 0xffffffff;
    puVar7 = (undefined4 *)FUN_0056cd30();
    param_1 = extraout_ECX_47;
    break;
  case (undefined4 *)0x2d:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(&uStack_18,*(int *)param_5);
    uStack_8 = 0;
    if (param_1[0x771] == 0) {
      if (DAT_01eae4ae != '\0') {
        FUN_016774b0(DAT_01eae4ae,"Can\'t send protected bytecode due to missing SessionCrypto.",0);
      }
    }
    else {
      (**(code **)(*param_1 + 0x1e8))(&param_5,&uStack_18);
      uStack_8._0_1_ = 1;
      FUN_006329a0(param_2,&param_5,param_7);
      FUN_00565660(0x10,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      ppppuVar9 = apppuStack_48;
      if (0xf < uStack_34) {
        ppppuVar9 = (undefined4 ****)apppuStack_48[0];
      }
      FUN_00a33fb0(ppppuVar9);
      cVar4 = FUN_0061f4b0();
      if (cVar4 == '\0') {
        uStack_20 = *(double *)(*piVar1 + 0x18);
        FUN_00632880(param_2,apppuStack_48,&uStack_20,*(undefined2 *)(piVar1 + 2));
      }
      FUN_005507b0();
      FUN_0056cd30();
    }
LAB_0060b85e:
    uStack_8 = 0xffffffff;
    FUN_0056cd30();
    puVar7 = (undefined4 *)FUN_0056cd30();
    param_1 = extraout_ECX_00;
    break;
  case (undefined4 *)0x2e:
    if (DAT_01d5a0c8 == '\0') {
      ExceptionList = &pvStack_10;
      FUN_016756b0(auStack_24,"Attempted to send DateTime value with unknown network format");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_24,&DAT_01c17198);
    }
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))(auStack_28,*(int *)param_5);
    puVar7 = (undefined4 *)FUN_006adcb0(auStack_28);
    param_1 = extraout_ECX_48;
    break;
  case (undefined4 *)0x2f:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(*(int *)((int)param_5 + 4) + 0x34) + 0xc))
              (&pppuStack_30,*(int *)param_5);
    uStack_8 = 0xe;
    param_7 = (uint)(int *)uStack_20;
    if ((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) {
      *puVar3 = *puVar3 + (int)(int *)uStack_20;
    }
    param_4 = (ushort *)FUN_0061dca0(&pppuStack_30);
    if (param_4 == (ushort *)0x0) {
      if (param_7 < 0x7f) {
        param_5 = (code *)CONCAT31(param_5._1_3_,(char)param_7);
        FUN_006ad5e0(&param_5,1);
        ppppuVar9 = &pppuStack_30;
        if (0xf < uStack_20._4_4_) {
          ppppuVar9 = (undefined4 ****)pppuStack_30;
        }
        FUN_006ad5e0(ppppuVar9,param_7);
        uStack_8 = 0xffffffff;
        puVar7 = (undefined4 *)FUN_005507b0();
        param_1 = extraout_ECX_51;
      }
      else {
        param_5 = (code *)CONCAT31(param_5._1_3_,0x7f);
        FUN_006ad5e0(&param_5,1);
        FUN_006ad360(&pppuStack_30,param_2);
        uStack_8 = 0xffffffff;
        puVar7 = (undefined4 *)FUN_005507b0();
        param_1 = extraout_ECX_52;
      }
    }
    else if (*param_4 < 0x7f) {
      param_5 = (code *)(CONCAT31(param_5._1_3_,(char)*param_4) | 0x80);
      FUN_006ad5e0(&param_5,1);
      uStack_8 = 0xffffffff;
      puVar7 = (undefined4 *)FUN_005507b0();
      param_1 = extraout_ECX_49;
    }
    else {
      param_5 = (code *)CONCAT31(param_5._1_3_,0xff);
      FUN_006ad5e0(&param_5,1);
      FUN_006ad4e0(*param_4 - 0x7f,param_2);
      uStack_8 = 0xffffffff;
      puVar7 = (undefined4 *)FUN_005507b0();
      param_1 = extraout_ECX_50;
    }
  }
  if ((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) {
    param_7 = (uint)param_1 & 0xffffff00;
    param_5 = (code *)((uint)puVar7 & 0xffffff00);
    if (puVar3[2] != 0) {
      param_7 = (uint)(puVar3[2] < *puVar3);
    }
    cVar4 = (char)param_7;
    if (puVar3[3] != 0) {
      param_5 = (code *)(uint)(puVar3[3] < puVar3[1]);
    }
    cVar6 = (char)param_5;
    if ((DAT_01d5a0c0 != '\0') && ((cVar4 != '\0' || (cVar6 != '\0')))) {
      iStack_38 = 0;
      uStack_34 = 0xf;
      apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffffff00);
      FUN_005542c0("ReplicatorWriteVariantLimit",0x1b);
      uStack_8 = 0xf;
      FUN_006289b0(puVar3,apppuStack_48);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      cVar6 = (char)param_5;
      cVar4 = (char)param_7;
    }
    if (DAT_01d5bb80 != '\0') {
      if (cVar4 != '\0') {
        uVar10 = FUN_01675640(auStack_6c,
                              "Replicator send variant: Total string data size exceed limit! (%u)",
                              *puVar3);
        uStack_8 = 0x10;
        FUN_005f8ef0(uVar10);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_54,&DAT_01c27108);
      }
      if (cVar6 != '\0') {
        uVar10 = FUN_01675640(auStack_cc,
                              "Replicator send variant: Variant count exceeded limit! (%u)",
                              puVar3[1]);
        uStack_8 = 0x11;
        FUN_005f8ef0(uVar10);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_b4,&DAT_01c27108);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6348 ; VA 0x0060c670 ; FUN_0060c670 */

void __thiscall
FUN_0060c670(int *param_1,undefined4 param_2,byte *param_3,undefined4 param_4,int *param_5,
            int param_6,ushort *param_7,uint *param_8)

{
  bool bVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 ****ppppuVar6;
  undefined4 uVar7;
  int *piVar8;
  uint *puVar9;
  undefined8 uVar10;
  undefined auStack_d0 [24];
  undefined auStack_b8 [36];
  int iStack_94;
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  undefined8 uStack_64;
  int iStack_5c;
  undefined auStack_58 [12];
  undefined4 ***pppuStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  undefined4 ***pppuStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  uint uStack_20;
  undefined2 uStack_1c;
  undefined2 uStack_1a;
  undefined2 uStack_18;
  undefined2 uStack_16;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d353;
  pvStack_10 = ExceptionList;
  piStack_14 = param_1;
  if (*param_3 == 0) {
    ExceptionList = &pvStack_10;
    FUN_016756b0(&iStack_28,"Invalid schema type for writing value");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&iStack_28,&DAT_01c17198);
  }
  piVar3 = (int *)(*param_3 - 2);
  ExceptionList = &pvStack_10;
  switch(piVar3) {
  case (int *)0x0:
    if ((DAT_01d5bb80 != '\0') || (ExceptionList = &pvStack_10, DAT_01d5a0c0 != '\0')) {
      ExceptionList = &pvStack_10;
      FUN_00607610(&pppuStack_4c);
      *param_8 = (int)uStack_3c + *param_8;
      FUN_005507b0();
    }
    uVar7 = FUN_00607610(&pppuStack_4c);
    uStack_8 = 4;
    FUN_006ad360(uVar7,param_2);
    uStack_8 = 0xffffffff;
    piVar3 = (int *)FUN_005507b0();
    break;
  case (int *)0x1:
    break;
  default:
    ExceptionList = &pvStack_10;
    FUN_016756b0(&iStack_28,"Attempted to send value with unknown network format");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&iStack_28,&DAT_01c17198);
  case (int *)0x4:
    ExceptionList = &pvStack_10;
    FUN_00607740(&uStack_1c);
    uStack_8 = 3;
    FUN_006329a0(param_2,&uStack_1c,param_7);
    goto LAB_0060c873;
  case (int *)0x5:
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)*param_5 + 0xc))((undefined4 *)*param_5,&param_5);
    piVar3 = param_5;
    goto LAB_0060c6cf;
  case (int *)0x6:
    if (*(int *)(param_3 + 8) == 3) {
      ExceptionList = &pvStack_10;
      FUN_00607780(&param_7);
      uStack_8 = 5;
      if ((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) {
        iVar4 = FUN_00a33fa0();
        *param_8 = *param_8 + *(int *)(iVar4 + 0x10);
      }
      uVar7 = FUN_00a33fa0(param_2);
      FUN_006ad360(uVar7);
      uStack_8 = 0xffffffff;
      piVar3 = (int *)FUN_0056cd30();
    }
    else {
      ExceptionList = &pvStack_10;
      FUN_00607650(&pppuStack_4c);
      uStack_8 = 6;
      if ((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) {
        *param_8 = *param_8 + (int)uStack_3c;
      }
      FUN_006ad360(&pppuStack_4c,param_2);
      uStack_8 = 0xffffffff;
      piVar3 = (int *)FUN_005507b0();
    }
    break;
  case (int *)0x7:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088daf0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    param_5 = (int *)CONCAT31(param_5._1_3_,*(undefined *)piVar8);
    piVar3 = (int *)FUN_006ad5e0(&param_5,1);
    break;
  case (int *)0x8:
    if (*(int *)(param_3 + 8) == 1) {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_006077c0();
      piVar3 = (int *)FUN_006ad340(uVar7,param_2);
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_006075e0();
      piVar3 = (int *)FUN_006ad340(uVar7,param_2);
    }
    break;
  case (int *)0x9:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088c960();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    param_5 = piVar3 + 2;
    if (piVar3[1] == 0) {
      param_5 = (int *)0x0;
    }
    param_5 = (int *)*param_5;
    FUN_006a5c10(&param_5,&param_7,4);
    piVar3 = (int *)FUN_006ad5e0(&param_7,4);
    break;
  case (int *)0xa:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088ca00();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    piStack_24 = (int *)*(undefined8 *)piVar8;
    uStack_20 = (uint)((ulonglong)*(undefined8 *)piVar8 >> 0x20);
    FUN_006a5c10(&piStack_24,&uStack_1c,8);
    piVar3 = (int *)FUN_006ad5e0(&uStack_1c,8);
    break;
  case (int *)0xb:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d690();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    piStack_24 = (int *)*piVar8;
    uStack_20 = piVar8[1];
    piVar3 = (int *)FUN_006ae670(&piStack_24);
    break;
  case (int *)0xc:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d5f0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    iStack_2c = *piVar8;
    iStack_28 = piVar8[1];
    piStack_24 = (int *)piVar8[2];
    uStack_20 = piVar8[3];
    piVar3 = (int *)FUN_006ae640(&iStack_2c);
    break;
  case (int *)0xd:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d370();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    pppuStack_4c = (undefined4 ***)*piVar8;
    iStack_48 = piVar8[1];
    iStack_44 = piVar8[2];
    iStack_40 = piVar8[3];
    uStack_3c = *(undefined8 *)(piVar8 + 4);
    piVar3 = (int *)FUN_006ae2d0(&pppuStack_4c);
    break;
  case (int *)0xe:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d230();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    param_5 = piVar3 + 2;
    if (piVar3[1] == 0) {
      param_5 = (int *)0x0;
    }
    param_5 = (int *)*param_5;
    piVar3 = (int *)FUN_006ad500(&param_5);
    break;
  case (int *)0xf:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088ce60();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    param_5 = piVar3 + 2;
    if (piVar3[1] == 0) {
      param_5 = (int *)0x0;
    }
    param_5 = (int *)*param_5;
    piVar3 = (int *)FUN_006ad500(&param_5);
    break;
  case (int *)0x10:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088cfa0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    param_5 = piVar3 + 2;
    if (piVar3[1] == 0) {
      param_5 = (int *)0x0;
    }
    param_5 = (int *)*param_5;
    piVar3 = (int *)FUN_006ad570(&param_5);
    break;
  case (int *)0x11:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d050();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    iStack_28 = (int)*(undefined8 *)piVar8;
    piStack_24 = (int *)((ulonglong)*(undefined8 *)piVar8 >> 0x20);
    uStack_20 = piVar8[2];
    piVar3 = (int *)FUN_006ad640(&iStack_28);
    break;
  case (int *)0x12:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d0f0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    param_5 = (int *)CONCAT13(*(undefined *)((int)piVar8 + 2),
                              CONCAT21(*(undefined2 *)piVar8,param_5._0_1_));
    piVar3 = (int *)FUN_006ad780((int)&param_5 + 1);
    break;
  case (int *)0x13:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d730();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    piStack_24 = (int *)*piVar8;
    uStack_20 = piVar8[1];
    piVar3 = (int *)FUN_006addc0(&piStack_24);
    break;
  case (int *)0x14:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d870();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    iStack_28 = (int)*(undefined8 *)piVar8;
    piStack_24 = (int *)((ulonglong)*(undefined8 *)piVar8 >> 0x20);
    uStack_20 = piVar8[2];
    piVar3 = (int *)FUN_006ad640(&iStack_28);
    break;
  case (int *)0x16:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d7d0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    param_5 = piVar3 + 2;
    if (piVar3[1] == 0) {
      param_5 = (int *)0x0;
    }
    param_5 = (int *)*param_5;
    piVar3 = (int *)FUN_006ae750(&param_5);
    break;
  case (int *)0x17:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d910();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    uStack_1a = (undefined2)*piVar8;
    uStack_18 = (undefined2)((uint)*piVar8 >> 0x10);
    uStack_16 = *(undefined2 *)(piVar8 + 1);
    piVar3 = (int *)FUN_006ae7f0(&uStack_1a);
    break;
  case (int *)0x18:
    ExceptionList = &pvStack_10;
    uVar7 = FUN_006076f0(&iStack_88);
    piVar3 = (int *)FUN_006acfc0(uVar7,param_2);
    break;
  case (int *)0x19:
    ExceptionList = &pvStack_10;
    uVar7 = FUN_006076f0(&iStack_88);
    piVar3 = (int *)FUN_006adad0(uVar7);
    break;
  case (int *)0x1a:
    param_5 = (int *)*param_5;
    iVar4 = *param_5;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088cdc0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_5 + 2;
    if (param_5[1] == 0) {
      piVar3 = (int *)0x0;
    }
    piVar8 = (int *)piVar3[1];
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = (int *)piVar3[1];
    }
    iVar4 = *piVar3;
    if (iVar4 == 0) {
      uStack_1c = 0xffff;
      uStack_1a = 0xffff;
      uStack_18 = 0;
      uStack_16 = 0;
    }
    else {
      uStack_1c = (undefined2)*(undefined4 *)(iVar4 + 0x18);
      uStack_1a = (undefined2)((uint)*(undefined4 *)(iVar4 + 0x18) >> 0x10);
      uStack_18 = (undefined2)*(undefined4 *)(iVar4 + 0x1c);
      uStack_16 = (undefined2)((uint)*(undefined4 *)(iVar4 + 0x1c) >> 0x10);
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar4 = piVar8[1] + -1;
      piVar8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        piVar3 = piVar8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    piVar3 = (int *)FUN_006b92d0(param_2,&uStack_1c);
    break;
  case (int *)0x1b:
    if (param_6 != 0) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Tuple cannot be sent as a member of another container.");
    }
    param_5 = (int *)*param_5;
    iVar4 = *param_5;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088cbe0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_5 + 2;
    if (param_5[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iVar4 = piVar3[1];
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    piVar3 = (int *)*piVar3;
    uStack_1c = SUB42(piVar3,0);
    uStack_1a = (undefined2)((uint)piVar3 >> 0x10);
    uStack_18 = (undefined2)iVar4;
    uStack_16 = (undefined2)((uint)iVar4 >> 0x10);
    FUN_00550b30();
    if (piVar3 == (int *)0x0) {
      piVar8 = (int *)0x0;
    }
    else {
      piVar8 = (int *)((piVar3[1] - *piVar3) / 0xd0);
    }
    param_5 = piVar8;
    FUN_006192f0(piVar8,"Tuple (write)");
    piVar3 = (int *)FUN_006ad4e0(piVar8,param_2);
    puVar9 = param_8;
    if (piVar8 != (int *)0x0) {
      param_6 = 0;
      do {
        piVar3 = (int *)FUN_0062cc40(param_2,param_4,*(int *)CONCAT22(uStack_1a,uStack_1c) + param_6
                                     ,0,param_7,puVar9);
        param_6 = param_6 + 0xd0;
        param_5 = (int *)((int)param_5 + -1);
      } while (param_5 != (int *)0x0);
      param_5 = (int *)0x0;
    }
    goto LAB_0060c6da;
  case (int *)0x1c:
    param_5 = (int *)*param_5;
    iVar4 = *param_5;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_008882f0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_5 + 2;
    if (param_5[1] == 0) {
      piVar3 = (int *)0x0;
    }
    uStack_20 = piVar3[1];
    if (uStack_20 != 0) {
      LOCK();
      *(int *)(uStack_20 + 4) = *(int *)(uStack_20 + 4) + 1;
      UNLOCK();
      uStack_20 = piVar3[1];
    }
    piVar3 = (int *)*piVar3;
    uStack_18 = SUB42(piVar3,0);
    uStack_16 = (undefined2)((uint)piVar3 >> 0x10);
    piStack_24 = piVar3;
    FUN_00550b30();
    param_3 = (byte *)((piVar3[1] - *piVar3) / 0xd0);
    FUN_006192f0(param_3,"ValueArray (write)");
    piVar3 = (int *)FUN_006ad4e0(param_3,param_2);
    puVar9 = param_8;
    if (param_3 != (byte *)0x0) {
      param_5 = (int *)0x0;
      do {
        piVar3 = (int *)FUN_0062cc40(param_2,param_4,
                                     (undefined *)
                                     (*(int *)CONCAT22(uStack_16,uStack_18) + (int)param_5),param_6,
                                     param_7,puVar9);
        param_5 = param_5 + 0x34;
        param_3 = (byte *)((int)param_3 + -1);
      } while (param_3 != (byte *)0x0);
    }
    goto LAB_0060c6da;
  case (int *)0x1d:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    param_5 = piVar3;
    iVar5 = FUN_008881d0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = piVar3 + 2;
    if (param_5[1] == 0) {
      piVar3 = (int *)0x0;
    }
    uStack_20 = piVar3[1];
    if (uStack_20 != 0) {
      LOCK();
      *(int *)(uStack_20 + 4) = *(int *)(uStack_20 + 4) + 1;
      UNLOCK();
      uStack_20 = piVar3[1];
    }
    piVar3 = (int *)*piVar3;
    piStack_24 = piVar3;
    FUN_00550b30();
    iVar4 = piVar3[2];
    FUN_006192f0(iVar4,"ValueTable (write)");
    FUN_006ad4e0(iVar4,param_2);
    piVar3 = (int *)FUN_00618a80(&param_5);
    for (piVar8 = param_5; piVar8 != (int *)0x0; piVar8 = (int *)*piVar8) {
      FUN_006ad360(piVar8 + 2,param_2);
      piVar3 = (int *)FUN_0062cc40(param_2,param_4,piVar8 + 8,param_6,param_7,param_8);
    }
    break;
  case (int *)0x1e:
    piVar8 = (int *)*param_5;
    iVar4 = *piVar8;
    ExceptionList = &pvStack_10;
    param_5 = piVar8;
    iVar5 = FUN_008880b0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar8 + 2;
    if (param_5[1] == 0) {
      piVar8 = (int *)0x0;
    }
    uStack_20 = piVar8[1];
    if (uStack_20 != 0) {
      LOCK();
      *(int *)(uStack_20 + 4) = *(int *)(uStack_20 + 4) + 1;
      UNLOCK();
      uStack_20 = piVar8[1];
    }
    piVar8 = (int *)*piVar8;
    piStack_24 = piVar8;
    FUN_00550b30();
    iVar4 = piVar8[1];
    FUN_006192f0(iVar4,"ValueMap (write)");
    FUN_006ad4e0(iVar4,param_2);
    piVar8 = (int *)*piVar8;
    piVar3 = (int *)*piVar8;
    while (param_5 = piVar3, piVar3 != piVar8) {
      FUN_006ad360(piVar3 + 4,param_2);
      FUN_0062cc40(param_2,param_4,piVar3 + 10,param_6,param_7,param_8);
      FUN_00551320();
      piVar3 = param_5;
    }
    break;
  case (int *)0x1f:
    if ((char)param_4 == '\0') {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_0061ec50(param_2);
      piVar3 = (int *)FUN_006ad360(uVar7);
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_0061ec50();
      piVar3 = (int *)FUN_006326e0(param_2,uVar7);
    }
    break;
  case (int *)0x20:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d550();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    piVar3 = (int *)*piVar8;
LAB_0060c6cf:
    piVar3 = (int *)FUN_006ad4e0(piVar3,param_2);
    break;
  case (int *)0x21:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00a92ae0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    FUN_00a92cb0(piVar8,0xe4078678,0x64078678);
    uStack_8 = 7;
    FUN_006adea0(&iStack_28);
    uStack_8 = 0xffffffff;
    piVar3 = (int *)FUN_00617ad0();
    break;
  case (int *)0x22:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00a92b80();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    iStack_28 = (int)*(undefined8 *)piVar8;
    piStack_24 = (int *)((ulonglong)*(undefined8 *)piVar8 >> 0x20);
    uStack_20 = piVar8[2];
    piVar3 = (int *)FUN_006ad640(&iStack_28);
    break;
  case (int *)0x23:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00b33310();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    piStack_24 = (int *)*piVar8;
    uStack_20 = piVar8[1];
    piVar3 = (int *)FUN_006addc0(&piStack_24);
    break;
  case (int *)0x24:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00a8dcc0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    FUN_00a8df50(piVar8);
    uStack_8 = 8;
    FUN_006ad850(&iStack_28);
    uStack_8 = 0xffffffff;
    piVar3 = (int *)FUN_00617bc0();
    break;
  case (int *)0x25:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00a8dd60();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    iStack_30 = *piVar8;
    iStack_2c = piVar8[1];
    iStack_28 = piVar8[2];
    piStack_24 = (int *)piVar8[3];
    uStack_20 = piVar8[4];
    piVar3 = (int *)FUN_006ad9e0(&iStack_30);
    break;
  case (int *)0x26:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d410();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    iStack_2c = *piVar8;
    iStack_28 = piVar8[1];
    piStack_24 = (int *)piVar8[2];
    uStack_20 = piVar8[3];
    piVar3 = (int *)FUN_006ae300(&iStack_2c);
    break;
  case (int *)0x27:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088d2d0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    pppuStack_4c = (undefined4 ***)*piVar8;
    iStack_48 = piVar8[1];
    iStack_44 = piVar8[2];
    iStack_40 = piVar8[3];
    uStack_3c = *(undefined8 *)(piVar8 + 4);
    piVar3 = (int *)FUN_006adfe0(&pppuStack_4c);
    break;
  case (int *)0x28:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00a73110();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    iStack_94 = *piVar8;
    iStack_90 = piVar8[1];
    iStack_8c = piVar8[2];
    iStack_88 = piVar8[3];
    iStack_84 = piVar8[4];
    iStack_80 = piVar8[5];
    iStack_7c = piVar8[6];
    iStack_78 = piVar8[7];
    iStack_74 = piVar8[8];
    iStack_70 = piVar8[9];
    iStack_6c = piVar8[10];
    iStack_68 = piVar8[0xb];
    uStack_64 = *(undefined8 *)(piVar8 + 0xc);
    iStack_5c = piVar8[0xe];
    piVar3 = (int *)FUN_006ae340(&iStack_94);
    break;
  case (int *)0x29:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00b33940();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    iStack_28 = (int)*(undefined8 *)piVar8;
    piStack_24 = (int *)((ulonglong)*(undefined8 *)piVar8 >> 0x20);
    uStack_20 = piVar8[2];
    piVar3 = (int *)FUN_006ae380(&iStack_28);
    break;
  case (int *)0x2a:
    if (*(int *)(param_3 + 8) == 2) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_006075e0();
      piVar3 = (int *)FUN_006ad310(iVar4,iVar4 >> 0x1f,param_2);
    }
    else {
      ExceptionList = &pvStack_10;
      uVar10 = FUN_006077c0();
      piVar3 = (int *)FUN_006ad310(uVar10,param_2);
    }
    break;
  case (int *)0x2b:
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00aa0140();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    pppuStack_4c = (undefined4 ***)*piVar8;
    iStack_48 = piVar8[1];
    iStack_44 = piVar8[2];
    iStack_40 = piVar8[3];
    uStack_3c = *(undefined8 *)(piVar8 + 4);
    piVar3 = (int *)FUN_006adf60(&pppuStack_4c);
    break;
  case (int *)0x2c:
    ExceptionList = &pvStack_10;
    FUN_00a33c70();
    uStack_8 = 9;
    if (*(int *)(param_3 + 8) == 4) {
      FUN_00607650(&pppuStack_4c);
      uStack_8._0_1_ = 10;
      uVar7 = FUN_0054ef60(&pppuStack_4c);
      uStack_8._0_1_ = 0xb;
      uVar7 = FUN_00a33be0(uVar7);
      FUN_00613ff0(uVar7);
      FUN_0056cd30();
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      FUN_005507b0();
    }
    else {
      uVar7 = FUN_00607780(&param_6);
      FUN_00613ff0(uVar7);
      FUN_0056cd30();
    }
    FUN_00a33fb0(&iStack_2c);
    FUN_006ad5e0(&iStack_2c,0x10);
    FUN_00606220(&param_4);
    uStack_8 = 0xffffffff;
    piVar3 = (int *)FUN_0056cd30();
    break;
  case (int *)0x2d:
    ExceptionList = &pvStack_10;
    FUN_00607740(&uStack_1c);
    uStack_8 = 0;
    if (param_1[0x771] == 0) {
      if (DAT_01eae4ae != '\0') {
        FUN_016774b0(DAT_01eae4ae,"Can\'t send protected bytecode due to missing SessionCrypto.",0);
      }
    }
    else {
      (**(code **)(*param_1 + 0x1e8))(&param_5,&uStack_1c);
      uStack_8._0_1_ = 1;
      FUN_006329a0(param_2,&param_5,param_7);
      FUN_00565660(0x10,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      ppppuVar6 = &pppuStack_4c;
      if (0xf < uStack_3c._4_4_) {
        ppppuVar6 = (undefined4 ****)pppuStack_4c;
      }
      FUN_00a33fb0(ppppuVar6);
      cVar2 = FUN_0061f4b0();
      if (cVar2 == '\0') {
        piStack_24 = (int *)0xffffffff;
        uStack_20 = 0;
        FUN_00632880(param_2,&pppuStack_4c,&piStack_24,DAT_018db184);
      }
      FUN_005507b0();
      FUN_0056cd30();
    }
LAB_0060c873:
    uStack_8 = 0xffffffff;
    FUN_0056cd30();
    piVar3 = (int *)FUN_0056cd30();
    break;
  case (int *)0x2e:
    if (DAT_01d5a0c8 == '\0') {
      ExceptionList = &pvStack_10;
      FUN_016756b0(&iStack_28,"Attempted to send DateTime value with unknown network format");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&iStack_28,&DAT_01c17198);
    }
    piVar3 = (int *)*param_5;
    iVar4 = *piVar3;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00b38680();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar8 = (int *)0x0;
    }
    iStack_2c = *piVar8;
    iStack_28 = piVar8[1];
    piStack_24 = (int *)piVar8[2];
    uStack_20 = piVar8[3];
    piVar3 = (int *)FUN_006adcb0(&iStack_2c);
    break;
  case (int *)0x2f:
    ExceptionList = &pvStack_10;
    FUN_00607610(&pppuStack_34);
    puVar9 = param_8;
    uStack_8 = 0xc;
    param_5 = piStack_24;
    if ((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) {
      *param_8 = *param_8 + (int)piStack_24;
    }
    param_7 = (ushort *)FUN_0061dca0(&pppuStack_34);
    if (param_7 == (ushort *)0x0) {
      if (param_5 < &DAT_0000007f) {
        param_8 = (uint *)CONCAT31(param_8._1_3_,(char)param_5);
        FUN_006ad5e0(&param_8,1);
        ppppuVar6 = &pppuStack_34;
        if (0xf < uStack_20) {
          ppppuVar6 = (undefined4 ****)pppuStack_34;
        }
        FUN_006ad5e0(ppppuVar6,param_5);
        uStack_8 = 0xffffffff;
        piVar3 = (int *)FUN_005507b0();
        goto LAB_0060c6da;
      }
      param_8 = (uint *)CONCAT31(param_8._1_3_,0x7f);
      FUN_006ad5e0(&param_8,1);
      FUN_006ad360(&pppuStack_34,param_2);
    }
    else {
      if (*param_7 < 0x7f) {
        param_8 = (uint *)(CONCAT31(param_8._1_3_,(char)*param_7) | 0x80);
        FUN_006ad5e0(&param_8,1);
        uStack_8 = 0xffffffff;
        piVar3 = (int *)FUN_005507b0();
        goto LAB_0060c6da;
      }
      param_8 = (uint *)CONCAT31(param_8._1_3_,0xff);
      FUN_006ad5e0(&param_8,1);
      FUN_006ad4e0(*param_7 - 0x7f,param_2);
    }
    uStack_8 = 0xffffffff;
    piVar3 = (int *)FUN_005507b0();
    goto LAB_0060c6da;
  }
  puVar9 = param_8;
LAB_0060c6da:
  if ((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) {
    bVar1 = false;
    param_8 = (uint *)((uint)piVar3 & 0xffffff00);
    if (puVar9[2] != 0) {
      bVar1 = puVar9[2] < *puVar9;
    }
    if (puVar9[3] != 0) {
      param_8 = (uint *)(uint)(puVar9[3] < puVar9[1]);
    }
    cVar2 = (char)param_8;
    if ((DAT_01d5a0c0 != '\0') && ((bVar1 || (cVar2 != '\0')))) {
      uStack_3c = 0xf00000000;
      pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c & 0xffffff00);
      FUN_005542c0("ReplicatorWriteVariantLimit",0x1b);
      uStack_8 = 0xd;
      FUN_006289b0(puVar9,&pppuStack_4c);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      cVar2 = (char)param_8;
    }
    if (DAT_01d5bb80 != '\0') {
      if (bVar1) {
        uVar7 = FUN_01675640(&iStack_70,
                             "Replicator send variant: Total string data size exceed limit! (%u)",
                             *puVar9);
        uStack_8 = 0xe;
        FUN_005f8ef0(uVar7);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_58,&DAT_01c27108);
      }
      if (cVar2 != '\0') {
        uVar7 = FUN_01675640(auStack_d0,
                             "Replicator send variant: Variant count exceeded limit! (%u)",puVar9[1]
                            );
        uStack_8 = 0xf;
        FUN_005f8ef0(uVar7);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_b8,&DAT_01c27108);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6349 ; VA 0x0060d9a0 ; FUN_0060d9a0 */

void FUN_0060d9a0(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4,
                 undefined4 param_5,undefined4 param_6,int param_7)

{
  undefined4 uVar1;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  FUN_0151f950(&DAT_018cdcc0,param_7);
  FUN_0151f850(&DAT_018bf030,param_1);
  FUN_0151f850("Subtype",param_2);
  if (param_3 == (undefined4 *)0x0) {
    uVar1 = 0;
  }
  else {
    uVar1 = *param_3;
  }
  FUN_0151f9c0("SubtypeInbound",uVar1);
  if (param_4 == (undefined4 *)0x0) {
    uVar1 = 0;
  }
  else {
    uVar1 = *param_4;
  }
  FUN_0151f9c0("SubtypeOutbound",uVar1);
  FUN_0151fa60("TypeInboundSubtotal",param_5);
  FUN_0151fa60("TypeOutboundSubtotal",param_6);
  FUN_0151fa60("InboundTotal",*(undefined4 *)(param_7 + 0x1c));
  FUN_0151fa60("OutboundTotal",*(undefined4 *)(param_7 + 0x20));
  FUN_0151fb00("ElapsedSeconds",(double)*(float *)(param_7 + 0x18));
  FUN_0151fcf0("IncludesJoin",*(undefined *)(param_7 + 0x24));
  uVar1 = DAT_01eace78;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("DetailedBandwidth",0x11);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01520d20(auStack_28,uVar1,0);
  if (0xf < uStack_14) {
    if (0xfff < uStack_14 + 1) {
      if (0x1f < (auStack_28[0] - *(int *)(auStack_28[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6350 ; VA 0x0060db30 ; FUN_0060db30 */

void FUN_0060db30(undefined4 param_1,undefined4 param_2,float *param_3,float *param_4,
                 undefined4 param_5,undefined4 param_6,int param_7)

{
  undefined4 uVar1;
  int iVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  FUN_0151f950(&DAT_018cdcc0,param_7);
  FUN_0151f850(&DAT_018bf030,param_1);
  FUN_0151f850("Subtype",param_2);
  if (param_3 == (float *)0x0) {
    iVar2 = 0;
  }
  else {
    iVar2 = (int)*param_3;
  }
  FUN_0151f9c0("SubtypeInbound",iVar2);
  if (param_4 == (float *)0x0) {
    iVar2 = 0;
  }
  else {
    iVar2 = (int)*param_4;
  }
  FUN_0151f9c0("SubtypeOutbound",iVar2);
  FUN_0151fa60("TypeInboundSubtotal",param_5);
  FUN_0151fa60("TypeOutboundSubtotal",param_6);
  FUN_0151fa60("InboundTotal",*(undefined4 *)(param_7 + 0x1c));
  FUN_0151fa60("OutboundTotal",*(undefined4 *)(param_7 + 0x20));
  FUN_0151fb00("ElapsedSeconds",(double)*(float *)(param_7 + 0x18));
  FUN_0151fcf0("IncludesJoin",*(undefined *)(param_7 + 0x24));
  uVar1 = DAT_01eace78;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("DetailedBandwidth",0x11);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01520d20(auStack_28,uVar1,0);
  if (0xf < uStack_14) {
    if (0xfff < uStack_14 + 1) {
      if (0x1f < (auStack_28[0] - *(int *)(auStack_28[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6351 ; VA 0x0060dcd0 ; FUN_0060dcd0 */

undefined4 * FUN_0060dcd0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  bool bVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (param_2 == 0) {
    piStack_c = (int *)0x0;
    puVar7 = &uStack_10;
    bVar6 = false;
    bVar5 = false;
    bVar4 = true;
    uVar8 = 0;
  }
  else {
    puVar7 = (undefined4 *)FUN_005c9c10(auStack_20);
    piStack_14 = (int *)puVar7[1];
    uVar8 = *puVar7;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)puVar7[1];
    }
    bVar6 = true;
    bVar5 = true;
    bVar4 = false;
    puVar7 = &uStack_18;
  }
  uVar2 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *param_1 = uVar8;
  param_1[1] = uVar2;
  if (bVar4) {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar3 = piStack_c[2] + -1;
        piStack_c[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
  }
  if (bVar5) {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar3 = piStack_14[2] + -1;
        piStack_14[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  if ((bVar6) && (piStack_1c != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 6352 ; VA 0x0060ddd0 ; FUN_0060ddd0 */

undefined4 * FUN_0060ddd0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  bool bVar5;
  bool bVar6;
  bool bVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (param_2 == 0) {
    piStack_c = (int *)0x0;
    puVar8 = &uStack_10;
    bVar7 = false;
    bVar6 = false;
    bVar5 = true;
    uVar9 = 0;
  }
  else {
    puVar8 = (undefined4 *)FUN_005c9c10(auStack_20);
    piStack_14 = (int *)puVar8[1];
    uVar9 = *puVar8;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)puVar8[1];
    }
    bVar7 = true;
    bVar6 = true;
    bVar5 = false;
    puVar8 = &uStack_18;
  }
  uVar3 = puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  piVar2 = piStack_c;
  param_1[1] = uVar3;
  *param_1 = uVar9;
  if ((bVar5) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_c[1] + -1;
    piStack_c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_14;
  if ((bVar6) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((bVar7) && (piStack_1c != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 6353 ; VA 0x0060ded0 ; thunk_FUN_0088c960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088c960(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba52c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede954) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede954);
    if (DAT_01ede954 == -1) {
      uStack_8 = 0;
      FUN_00888860("float",4,1,1,0);
      _DAT_01ede930 = RBX::Reflection::TType<float>::vftable;
      FUN_016f3654(&LAB_01880930);
      FUN_016f37bf(&DAT_01ede954);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede930;
}



/* FUNCTION 6354 ; VA 0x0060dee0 ; thunk_FUN_0088ca00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088ca00(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba54c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede97c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede97c);
    if (DAT_01ede97c == -1) {
      uStack_8 = 0;
      FUN_00888860("double",5,1,1,0);
      _DAT_01ede958 = RBX::Reflection::TType<double>::vftable;
      FUN_016f3654(&LAB_01880940);
      FUN_016f37bf(&DAT_01ede97c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede958;
}



/* FUNCTION 6355 ; VA 0x0060df00 ; thunk_FUN_0088ce60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088ce60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba62c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edebd4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edebd4);
    if (DAT_01edebd4 == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cf58,0x16,0,0,0);
      _DAT_01edebb0 = RBX::Reflection::TType<class_RBX::Axes>::vftable;
      FUN_016f3654(&LAB_018809b0);
      FUN_016f37bf(&DAT_01edebd4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edebb0;
}



/* FUNCTION 6356 ; VA 0x0060df10 ; thunk_FUN_0088cf00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088cf00(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba64c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edecc4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edecc4);
    if (DAT_01edecc4 == -1) {
      uStack_8 = 0;
      FUN_00888860("BinaryString",0x1e,0,0,0);
      _DAT_01edeca0 = RBX::Reflection::TType<class_RBX::BinaryString>::vftable;
      FUN_016f3654(&LAB_018809c0);
      FUN_016f37bf(&DAT_01edecc4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeca0;
}



/* FUNCTION 6357 ; VA 0x0060df20 ; thunk_FUN_0088cfa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088cfa0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba66c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edec74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edec74);
    if (DAT_01edec74 == -1) {
      uStack_8 = 0;
      FUN_008887b0("BrickColor",&DAT_0191cd9c,0x1c,0,0,0);
      _DAT_01edec50 = RBX::Reflection::TType<class_RBX::BrickColor>::vftable;
      FUN_016f3654(&LAB_018809d0);
      FUN_016f37bf(&DAT_01edec74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edec50;
}



/* FUNCTION 6358 ; VA 0x0060df30 ; thunk_FUN_0088d0f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d0f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba6ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edec24) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edec24);
    if (DAT_01edec24 == -1) {
      uStack_8 = 0;
      FUN_00888860("Color3uint8",0x12,0,0,0);
      _DAT_01edec00 = RBX::Reflection::TType<class_G3D::Color3uint8>::vftable;
      FUN_016f3654(&LAB_018809f0);
      FUN_016f37bf(&DAT_01edec24);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edec00;
}



/* FUNCTION 6359 ; VA 0x0060df40 ; thunk_FUN_00a8dcc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a8dcc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e570c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeae20) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeae20);
    if (DAT_01eeae20 == -1) {
      uStack_8 = 0;
      FUN_00888860("ColorSequence",0x29,0,0,0);
      _DAT_01eeadfc = RBX::Reflection::TType<class_RBX::ColorSequence>::vftable;
      FUN_016f3654(&LAB_0188aca0);
      FUN_016f37bf(&DAT_01eeae20);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeadfc;
}



/* FUNCTION 6360 ; VA 0x0060df50 ; thunk_FUN_00a8dd60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a8dd60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e572c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeae48) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeae48);
    if (DAT_01eeae48 == -1) {
      uStack_8 = 0;
      FUN_00888860("ColorSequenceKeypoint",0x2a,0,0,0);
      _DAT_01eeae24 = RBX::Reflection::TType<class_RBX::ColorSequenceKeypoint>::vftable;
      FUN_016f3654(&LAB_0188acb0);
      FUN_016f37bf(&DAT_01eeae48);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeae24;
}



/* FUNCTION 6361 ; VA 0x0060df60 ; thunk_FUN_0088d190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d190(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba6cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede9a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede9a4);
    if (DAT_01ede9a4 == -1) {
      uStack_8 = 0;
      FUN_00888860("Content",0x30,0,0,0);
      _DAT_01ede980 = RBX::Reflection::TType<class_RBX::ContentId>::vftable;
      FUN_016f3654(&LAB_01880a00);
      FUN_016f37bf(&DAT_01ede9a4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede980;
}



/* FUNCTION 6362 ; VA 0x0060df70 ; thunk_FUN_00b00260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b00260(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecfec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eedcc0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eedcc0);
    if (DAT_01eedcc0 == -1) {
      uStack_8 = 0;
      FUN_00888860("CoordinateFrame",0x10,0,0,0);
      _DAT_01eedc9c = RBX::Reflection::TType<class_G3D::CoordinateFrame>::vftable;
      FUN_016f3654(&LAB_0188d2f0);
      FUN_016f37bf(&DAT_01eedcc0);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eedc9c;
}



/* FUNCTION 6363 ; VA 0x0060df80 ; thunk_FUN_00b38680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b38680(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1ccc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee664) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee664);
    if (DAT_01eee664 == -1) {
      uStack_8 = 0;
      FUN_00888860("DateTime",0x3c,0,0,0);
      _DAT_01eee640 = RBX::Reflection::TType<class_RBX::DateTime>::vftable;
      FUN_016f3654(&LAB_0188db50);
      FUN_016f37bf(&DAT_01eee664);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee640;
}



/* FUNCTION 6364 ; VA 0x0060df90 ; thunk_FUN_0088d230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d230(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba6ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edebac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edebac);
    if (DAT_01edebac == -1) {
      uStack_8 = 0;
      FUN_00888860("Faces",0x15,0,0,0);
      _DAT_01edeb88 = RBX::Reflection::TType<class_RBX::Faces>::vftable;
      FUN_016f3654(&LAB_01880a10);
      FUN_016f37bf(&DAT_01edebac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeb88;
}



/* FUNCTION 6365 ; VA 0x0060dfa0 ; thunk_FUN_00b33310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b33310(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f161c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee5fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee5fc);
    if (DAT_01eee5fc == -1) {
      uStack_8 = 0;
      FUN_00888860("NumberRange",0x2b,0,0,0);
      _DAT_01eee5d8 = RBX::Reflection::TType<class_RBX::NumberRange>::vftable;
      FUN_016f3654(&LAB_0188dab0);
      FUN_016f37bf(&DAT_01eee5fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee5d8;
}



/* FUNCTION 6366 ; VA 0x0060dfb0 ; thunk_FUN_00a92ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a92ae0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e59fc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeae7c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeae7c);
    if (DAT_01eeae7c == -1) {
      uStack_8 = 0;
      FUN_00888860("NumberSequence",0x2c,0,0,0);
      _DAT_01eeae58 = RBX::Reflection::TType<class_RBX::NumberSequence>::vftable;
      FUN_016f3654(&LAB_0188acc0);
      FUN_016f37bf(&DAT_01eeae7c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeae58;
}



/* FUNCTION 6367 ; VA 0x0060dfc0 ; thunk_FUN_00a92b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a92b80(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5a1c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeaea4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeaea4);
    if (DAT_01eeaea4 == -1) {
      uStack_8 = 0;
      FUN_00888860("NumberSequenceKeypoint",0x2d,0,0,0);
      _DAT_01eeae80 = RBX::Reflection::TType<class_RBX::NumberSequenceKeypoint>::vftable;
      FUN_016f3654(&LAB_0188acd0);
      FUN_016f37bf(&DAT_01eeaea4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeae80;
}



/* FUNCTION 6368 ; VA 0x0060dfd0 ; thunk_FUN_00aa0140 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00aa0140(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6edc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb224) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb224);
    if (DAT_01eeb224 == -1) {
      uStack_8 = 0;
      FUN_00888860("PathWaypoint",0x3a,0,0,0);
      _DAT_01eeb200 = RBX::Reflection::TType<class_RBX::PathWaypoint>::vftable;
      FUN_016f3654(&LAB_0188aeb0);
      FUN_016f37bf(&DAT_01eeb224);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb200;
}



/* FUNCTION 6369 ; VA 0x0060dfe0 ; thunk_FUN_0088d2d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d2d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba70c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeb0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeb0c);
    if (DAT_01edeb0c == -1) {
      uStack_8 = 0;
      FUN_00888860("PhysicalProperties",0x1b,0,0,0);
      _DAT_01edeae8 = RBX::Reflection::TType<class_RBX::PhysicalProperties>::vftable;
      FUN_016f3654(&LAB_01880a20);
      FUN_016f37bf(&DAT_01edeb0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeae8;
}



/* FUNCTION 6370 ; VA 0x0060dff0 ; thunk_FUN_00886600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00886600(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba01c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede75c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede75c);
    if (DAT_01ede75c == -1) {
      uStack_8 = 0;
      FUN_00888860("ProtectedString",7,0,0,0);
      _DAT_01ede738 = RBX::Reflection::TType<class_RBX::ProtectedString>::vftable;
      FUN_016f3654(&LAB_01880840);
      FUN_016f37bf(&DAT_01ede75c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede738;
}



/* FUNCTION 6371 ; VA 0x0060e000 ; thunk_FUN_0088d370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d370(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba72c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edec4c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edec4c);
    if (DAT_01edec4c == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cf8c,10,0,0,0);
      _DAT_01edec28 = RBX::Reflection::TType<class_RBX::RbxRay>::vftable;
      FUN_016f3654(&LAB_01880a30);
      FUN_016f37bf(&DAT_01edec4c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edec28;
}



/* FUNCTION 6372 ; VA 0x0060e010 ; thunk_FUN_0088d410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d410(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba74c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeb34) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeb34);
    if (DAT_01edeb34 == -1) {
      uStack_8 = 0;
      FUN_00888860("Rect2D",0xf,0,0,0);
      _DAT_01edeb10 = RBX::Reflection::TType<class_G3D::Rect2D>::vftable;
      FUN_016f3654(&LAB_01880a40);
      FUN_016f37bf(&DAT_01edeb34);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeb10;
}



/* FUNCTION 6373 ; VA 0x0060e020 ; thunk_FUN_00a73110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a73110(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e29ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eea9a8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eea9a8);
    if (DAT_01eea9a8 == -1) {
      uStack_8 = 0;
      FUN_00888860("Region3",0x17,0,0,0);
      _DAT_01eea984 = RBX::Reflection::TType<class_RBX::Region3>::vftable;
      FUN_016f3654(&LAB_0188a870);
      FUN_016f37bf(&DAT_01eea9a8);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eea984;
}



/* FUNCTION 6374 ; VA 0x0060e030 ; thunk_FUN_00b33940 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b33940(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f16ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee624) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee624);
    if (DAT_01eee624 == -1) {
      uStack_8 = 0;
      FUN_00888860("Region3int16",0x18,0,0,0);
      _DAT_01eee600 = RBX::Reflection::TType<class_RBX::Region3int16>::vftable;
      FUN_016f3654(&LAB_0188dac0);
      FUN_016f37bf(&DAT_01eee624);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee600;
}



/* FUNCTION 6375 ; VA 0x0060e040 ; thunk_FUN_0088d4b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d4b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba76c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edecec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edecec);
    if (DAT_01edecec == -1) {
      uStack_8 = 0;
      FUN_00888860("SharedString",0x3b,0,0,0);
      _DAT_01edecc8 = RBX::Reflection::TType<class_RBX::SharedString>::vftable;
      FUN_016f3654(&LAB_01880a50);
      FUN_016f37bf(&DAT_01edecec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edecc8;
}



/* FUNCTION 6376 ; VA 0x0060e050 ; thunk_FUN_0088d550 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d550(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba78c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edec9c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edec9c);
    if (DAT_01edec9c == -1) {
      uStack_8 = 0;
      FUN_00888860("SystemAddress",0x1d,0,0,0);
      _DAT_01edec78 = RBX::Reflection::TType<class_RBX::SystemAddress>::vftable;
      FUN_016f3654(&LAB_01880a60);
      FUN_016f37bf(&DAT_01edec9c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edec78;
}



/* FUNCTION 6377 ; VA 0x0060e060 ; thunk_FUN_0088d5f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d5f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba7ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeb84) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeb84);
    if (DAT_01edeb84 == -1) {
      uStack_8 = 0;
      FUN_00888860("UDim2",0x14,0,0,0);
      _DAT_01edeb60 = RBX::Reflection::TType<class_RBX::UDim2>::vftable;
      FUN_016f3654(&LAB_01880a70);
      FUN_016f37bf(&DAT_01edeb84);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeb60;
}



/* FUNCTION 6378 ; VA 0x0060e070 ; thunk_FUN_0088d690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d690(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba7cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeb5c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeb5c);
    if (DAT_01edeb5c == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cf28,0x13,0,0,0);
      _DAT_01edeb38 = RBX::Reflection::TType<class_RBX::UDim>::vftable;
      FUN_016f3654(&LAB_01880a80);
      FUN_016f37bf(&DAT_01edeb5c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeb38;
}



/* FUNCTION 6379 ; VA 0x0060e080 ; thunk_FUN_0088d730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d730(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba7ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edea1c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edea1c);
    if (DAT_01edea1c == -1) {
      uStack_8 = 0;
      FUN_00888860("Vector2",0xb,0,0,0);
      _DAT_01ede9f8 = RBX::Reflection::TType<class_G3D::Vector2>::vftable;
      FUN_016f3654(&LAB_01880a90);
      FUN_016f37bf(&DAT_01edea1c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede9f8;
}



/* FUNCTION 6380 ; VA 0x0060e090 ; thunk_FUN_0088d7d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d7d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba80c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edea94) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edea94);
    if (DAT_01edea94 == -1) {
      uStack_8 = 0;
      FUN_00888860("Vector2int16",0xd,0,0,0);
      _DAT_01edea70 = RBX::Reflection::TType<class_G3D::Vector2int16>::vftable;
      FUN_016f3654(&LAB_01880aa0);
      FUN_016f37bf(&DAT_01edea94);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edea70;
}



/* FUNCTION 6381 ; VA 0x0060e0a0 ; thunk_FUN_0088d870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d870(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba82c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede9f4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede9f4);
    if (DAT_01ede9f4 == -1) {
      uStack_8 = 0;
      FUN_00888860("Vector3",0xc,0,0,0);
      _DAT_01ede9d0 = RBX::Reflection::TType<class_G3D::Vector3>::vftable;
      FUN_016f3654(&LAB_01880ab0);
      FUN_016f37bf(&DAT_01ede9f4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede9d0;
}



/* FUNCTION 6382 ; VA 0x0060e0b0 ; thunk_FUN_0088d910 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d910(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba84c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeabc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeabc);
    if (DAT_01edeabc == -1) {
      uStack_8 = 0;
      FUN_00888860("Vector3int16",0xe,0,0,0);
      _DAT_01edea98 = RBX::Reflection::TType<class_G3D::Vector3int16>::vftable;
      FUN_016f3654(&LAB_01880ac0);
      FUN_016f37bf(&DAT_01edeabc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edea98;
}



/* FUNCTION 6383 ; VA 0x0060e0c0 ; FUN_0060e0c0 */

undefined4 * FUN_0060e0c0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  undefined4 *puVar6;
  undefined auStack_18 [4];
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (param_2 == 0) {
    uStack_10 = 0;
    piStack_c = (int *)0x0;
    bVar5 = false;
    bVar4 = false;
    bVar3 = true;
  }
  else {
    puVar6 = (undefined4 *)FUN_005c9c10(auStack_18);
    piStack_c = (int *)puVar6[1];
    uStack_10 = *puVar6;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[1] = piStack_c[1] + 1;
      UNLOCK();
      piStack_c = (int *)puVar6[1];
    }
    bVar5 = true;
    bVar4 = true;
    bVar3 = false;
  }
  piVar1 = piStack_c;
  *param_1 = 0;
  param_1[1] = 0;
  if (piStack_c != (int *)0x0) {
    LOCK();
    piStack_c[2] = piStack_c[2] + 1;
    UNLOCK();
  }
  *param_1 = uStack_10;
  param_1[1] = piStack_c;
  if ((bVar3) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if ((bVar4) && (piVar1 != (int *)0x0)) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if ((bVar5) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 6384 ; VA 0x0060e1d0 ; FUN_0060e1d0 */

undefined4 * __thiscall FUN_0060e1d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_2[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[5] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  return param_1;
}



/* FUNCTION 6385 ; VA 0x0060e240 ; FUN_0060e240 */

undefined4 * __thiscall
FUN_0060e240(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined param_6,undefined param_7,undefined param_8,int param_9,
            undefined4 param_10,int param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined param_15,undefined4 param_16)

{
  undefined uVar1;
  uint uVar2;
  int iVar3;
  int aiStack_48 [2];
  int iStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int aiStack_30 [2];
  int iStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_15;
  puStack_c = &LAB_0179d378;
  pvStack_10 = ExceptionList;
  uStack_14 = param_16;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0060e970(&param_9);
  uStack_3c = param_12;
  uStack_38 = param_13;
  uStack_8._0_1_ = 1;
  FUN_0060e970(aiStack_48);
  uStack_24 = uStack_3c;
  uStack_20 = uStack_38;
  *param_1 = param_2;
  param_1[1] = param_4;
  param_1[2] = param_5;
  *(undefined *)(param_1 + 3) = param_6;
  *(undefined *)(param_1 + 4) = param_7;
  *(undefined *)(param_1 + 5) = param_8;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0060e970(aiStack_30);
  param_1[9] = uStack_24;
  param_1[10] = uStack_20;
  if (aiStack_30[0] != 0) {
    uVar2 = iStack_28 - aiStack_30[0] & 0xfffffff8;
    iVar3 = aiStack_30[0];
    if (0xfff < uVar2) {
      iVar3 = *(int *)(aiStack_30[0] + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (aiStack_30[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *(undefined *)(param_1 + 0xc) = uVar1;
  param_1[0xd] = uStack_14;
  if (aiStack_48[0] != 0) {
    uVar2 = iStack_40 - aiStack_48[0] & 0xfffffff8;
    iVar3 = aiStack_48[0];
    if (0xfff < uVar2) {
      iVar3 = *(int *)(aiStack_48[0] + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (aiStack_48[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  if (param_9 != 0) {
    uVar2 = param_11 - param_9 & 0xfffffff8;
    iVar3 = param_9;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(param_9 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (param_9 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6386 ; VA 0x0060e3c0 ; FUN_0060e3c0 */

undefined4 * __fastcall FUN_0060e3c0(undefined4 *param_1)

{
  undefined4 uVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  uVar1 = FUN_00616cf0();
  *param_1 = uVar1;
  return param_1;
}



/* FUNCTION 6387 ; VA 0x0060e3f0 ; FUN_0060e3f0 */

undefined4 * __thiscall FUN_0060e3f0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 6388 ; VA 0x0060e460 ; FUN_0060e460 */

int __thiscall
FUN_0060e460(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 8) = param_4;
  *(int **)(param_1 + 0xc) = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  *(undefined4 *)(param_1 + 0x10) = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_5 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 6389 ; VA 0x0060e560 ; FUN_0060e560 */

undefined4 __thiscall FUN_0060e560(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    piVar1 = param_3 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piVar1 = param_3 + 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar2 = param_3[2] + -1;
        param_3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 6390 ; VA 0x0060e660 ; FUN_0060e660 */

undefined * __thiscall FUN_0060e660(undefined *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d3a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar2 = FUN_005d6bb0(*(undefined4 *)((int)param_2 + 8));
  *(undefined4 *)(param_1 + 4) = uVar2;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)((int)param_2 + 0xc);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  uStack_8 = 0;
  if (*(int *)((int)param_2 + 8) != 0) {
    FUN_005d2b00(uVar2);
    if (*(int *)((int)param_2 + 8) == 0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = *(int **)(*(int *)((int)param_2 + 0x14) + *(int *)((int)param_2 + 4) * 4);
    }
    param_2 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    if (piVar4 != (int *)0x0) {
      do {
        uStack_8._0_1_ = 1;
        puVar3 = (undefined4 *)FUN_01674e20(0x38);
        *puVar3 = 0;
        puVar3[1] = 0;
        FUN_0170d1f0(puVar3 + 2,0,0x30);
        FUN_0054ef60(piVar4 + 2);
        uStack_8._0_1_ = 2;
        FUN_0054ef60(piVar4 + 8);
        puVar3[1] = piVar4[1];
        *param_2 = puVar3;
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
        puVar1 = (undefined4 *)*param_2;
        piVar4 = (int *)*piVar4;
        puVar3 = (undefined4 *)
                 (*(int *)(param_1 + 0x14) + ((uint)puVar1[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar1[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *puVar3 = param_2;
          param_2 = puVar1;
        }
        else {
          *param_2 = *puVar1;
          *puVar1 = *(undefined4 *)*puVar3;
          *(undefined4 **)*puVar3 = puVar1;
        }
      } while (piVar4 != (int *)0x0);
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6391 ; VA 0x0060e7f0 ; FUN_0060e7f0 */

undefined4 __thiscall FUN_0060e7f0(undefined4 param_1,undefined4 param_2)

{
  FUN_0060e660(param_2);
  return param_1;
}



/* FUNCTION 6392 ; VA 0x0060e810 ; FUN_0060e810 */

uint * __thiscall FUN_0060e810(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar1 = param_2 * 4;
    if (uVar1 < 0x1000) {
      if (uVar1 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar1);
      }
    }
    else {
      uVar2 = uVar1 + 0x23;
      if (uVar2 <= uVar1) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar1;
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar4 = *param_3;
        puVar4 = puVar4 + 1;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar4;
  }
  return param_1;
}



/* FUNCTION 6393 ; VA 0x0060e8c0 ; FUN_0060e8c0 */

uint * __thiscall FUN_0060e8c0(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar1 = param_2 * 8;
    if (uVar1 < 0x1000) {
      if (uVar1 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar1);
      }
    }
    else {
      uVar2 = uVar1 + 0x23;
      if (uVar2 <= uVar1) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar1;
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar4 = *param_3;
        puVar4[1] = param_3[1];
        puVar4 = puVar4 + 2;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar4;
  }
  return param_1;
}



/* FUNCTION 6394 ; VA 0x0060e970 ; FUN_0060e970 */

undefined4 * __thiscall FUN_0060e970(undefined4 *param_1,int *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar2 = FUN_00575930(param_2[1] - *param_2 >> 3);
  if (cVar2 != '\0') {
    puVar1 = (undefined4 *)param_2[1];
    puVar4 = (undefined4 *)*param_1;
    for (puVar3 = (undefined4 *)*param_2; puVar3 != puVar1; puVar3 = puVar3 + 2) {
      *puVar4 = *puVar3;
      puVar4[1] = puVar3[1];
      puVar4 = puVar4 + 2;
    }
    param_1[1] = puVar4;
  }
  return param_1;
}



/* FUNCTION 6395 ; VA 0x0060e9d0 ; FUN_0060e9d0 */

undefined4 * __thiscall FUN_0060e9d0(undefined4 *param_1,int param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 *puVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar1 = FUN_00575930(param_2);
  if (cVar1 != '\0') {
    puVar2 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar2 = *param_3;
        puVar2[1] = param_3[1];
        puVar2 = puVar2 + 2;
        param_2 = param_2 + -1;
      } while (param_2 != 0);
    }
    param_1[1] = puVar2;
  }
  return param_1;
}



/* FUNCTION 6396 ; VA 0x0060ea20 ; FUN_0060ea20 */

uint * __thiscall FUN_0060ea20(uint *param_1,int *param_2)

{
  undefined8 *puVar1;
  uint uVar2;
  int iVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  uint uVar6;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar6 = (param_2[1] - *param_2) / 0xc;
  if (uVar6 != 0) {
    if (0x15555555 < uVar6) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar6 = uVar6 * 0xc;
    if (uVar6 < 0x1000) {
      if (uVar6 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar6);
      }
    }
    else {
      uVar2 = uVar6 + 0x23;
      if (uVar2 <= uVar6) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar6;
    puVar1 = (undefined8 *)param_2[1];
    puVar5 = (undefined8 *)*param_1;
    for (puVar4 = (undefined8 *)*param_2; puVar4 != puVar1;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc)) {
      *puVar5 = *puVar4;
      *(undefined4 *)(puVar5 + 1) = *(undefined4 *)(puVar4 + 1);
      puVar5 = (undefined8 *)((int)puVar5 + 0xc);
    }
    param_1[1] = (uint)puVar5;
  }
  return param_1;
}



/* FUNCTION 6397 ; VA 0x0060eaf0 ; FUN_0060eaf0 */

uint * __thiscall FUN_0060eaf0(uint *param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d3c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  puVar2 = (undefined *)((param_2[1] - *param_2) / 0xd8);
  if (puVar2 != (undefined *)0x0) {
    if (&DAT_012f684b < puVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar6 = (int)puVar2 * 0xd8;
    if (uVar6 < 0x1000) {
      if (uVar6 == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = FUN_01674e20(uVar6);
      }
    }
    else {
      uVar3 = uVar6 + 0x23;
      if (uVar3 <= uVar6) {
        uVar3 = 0xffffffff;
      }
      iVar4 = FUN_01674e20(uVar3);
      if (iVar4 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar3 = iVar4 + 0x23U & 0xffffffe0;
      *(int *)(uVar3 - 4) = iVar4;
    }
    *param_1 = uVar3;
    param_1[1] = uVar3;
    param_1[2] = *param_1 + uVar6;
    puVar8 = (undefined4 *)*param_1;
    puVar1 = (undefined4 *)param_2[1];
    puVar7 = (undefined4 *)*param_2;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    for (; puVar7 != puVar1; puVar7 = puVar7 + 0x36) {
      *puVar8 = *puVar7;
      puVar8[1] = puVar7[1];
      puVar8[2] = 0;
      puVar5 = (undefined4 *)puVar7[2];
      if (puVar5 != (undefined4 *)0x0) {
        (*(code *)*puVar5)(puVar7 + 3,puVar8 + 3);
        puVar5 = (undefined4 *)puVar7[2];
      }
      puVar8[2] = puVar5;
      *(undefined *)(puVar8 + 0x35) = *(undefined *)(puVar7 + 0x35);
      puVar8 = puVar8 + 0x36;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00602ed0(puVar8,puVar8,param_1);
    param_1[1] = (uint)puVar8;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6398 ; VA 0x0060ec52 ; Catch_All@0060ec52 */

void Catch_All_0060ec52(void)

{
  FUN_00617b40();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6399 ; VA 0x0060ec70 ; FUN_0060ec70 */

undefined4 * __thiscall FUN_0060ec70(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  FUN_00604490(param_2,param_3,param_3);
  return param_1;
}



/* FUNCTION 6400 ; VA 0x0060eca0 ; FUN_0060eca0 */

int * __thiscall FUN_0060eca0(int *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar2 = param_2[1] - *param_2 >> 3;
  if (uVar2 != 0) {
    if (0x1fffffff < uVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar1 = FUN_00578020(uVar2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = *param_1 + uVar2 * 8;
    iVar1 = FUN_0055c480(*param_2,param_2[1],*param_1);
    param_1[1] = iVar1;
  }
  return param_1;
}



/* FUNCTION 6401 ; VA 0x0060ed10 ; FUN_0060ed10 */

undefined4 * __thiscall FUN_0060ed10(undefined4 *param_1,undefined4 param_2)

{
  FUN_005f70a0();
  FUN_005f7140();
  *param_1 = DAT_01d59f90;
  param_1[1] = DAT_01d59f94;
  *(undefined2 *)(param_1 + 2) = DAT_01d59f98;
  FUN_005f7170(param_2);
  return param_1;
}



/* FUNCTION 6402 ; VA 0x0060ed50 ; FUN_0060ed50 */

int * __thiscall FUN_0060ed50(int *param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179d3e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_8 = 0;
  puVar2 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[3] = param_2 + 4;
    puVar2[4] = 0x20;
    puVar2[5] = 0x20;
    puVar2[6] = 0;
  }
  iVar1 = *param_1;
  *param_1 = (int)puVar2;
  if (iVar1 != 0) {
    FUN_00615040(iVar1);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6403 ; VA 0x0060edf0 ; FUN_0060edf0 */

undefined4 * __thiscall FUN_0060edf0(undefined4 *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179d40b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  param_1[3] = param_2;
  FUN_006ab530();
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6404 ; VA 0x0060ee60 ; FUN_0060ee60 */

undefined4 * __fastcall FUN_0060ee60(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined **ppuVar2;
  undefined **ppuVar3;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179d43e;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 8;
  param_1[1] = 0;
  param_1[2] = 0;
  puStack_14 = param_1;
  uVar1 = FUN_01674f30(0x60);
  param_1[3] = uVar1;
  uStack_8 = 1;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  uVar1 = FUN_005cb2b0(0,0);
  param_1[5] = uVar1;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  param_1[4] = 0x3f800000;
  FUN_005cb500(8);
  *(undefined *)(param_1 + 0xc) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  param_1[0xd] = *ppuVar3;
  param_1[0xe] = 0;
  param_1[0xf] = 0x3f800000;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6405 ; VA 0x0060ef70 ; FUN_0060ef70 */

undefined4 * __fastcall FUN_0060ef70(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return param_1;
}



/* FUNCTION 6406 ; VA 0x0060efa0 ; FUN_0060efa0 */

undefined4 * __fastcall FUN_0060efa0(undefined4 *param_1)

{
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  return param_1;
}



/* FUNCTION 6407 ; VA 0x0060f000 ; FUN_0060f000 */

undefined4 __fastcall FUN_0060f000(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uStack_10 = 0xfffffffe;
  uStack_c = 0x7fffffff;
  uVar1 = FUN_0056a9c0(0);
  FUN_005672c0(uVar1,&uStack_10);
  uStack_10 = 0xfffffffe;
  uStack_c = 0x7fffffff;
  uVar1 = FUN_0056a9c0(0);
  FUN_005672c0(uVar1,&uStack_10);
  return param_1;
}



/* FUNCTION 6408 ; VA 0x0060f060 ; FUN_0060f060 */

undefined4 * __thiscall FUN_0060f060(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179d479;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::DeserializedItem::vftable;
  param_1[1] = *(undefined4 *)(param_2 + 4);
  param_1[2] = *(undefined4 *)(param_2 + 8);
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  uStack_8 = 0;
  *param_1 = RBX::Network::DeserializedNewInstanceItem::vftable;
  FUN_0060eaf0(param_2 + 0x10);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  param_1[10] = *(undefined4 *)(param_2 + 0x28);
  param_1[0xb] = *(undefined4 *)(param_2 + 0x2c);
  param_1[0xc] = *(undefined4 *)(param_2 + 0x30);
  param_1[0xd] = *(undefined4 *)(param_2 + 0x34);
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  if (*(int *)(param_2 + 0x3c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x3c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xe] = *(undefined4 *)(param_2 + 0x38);
  param_1[0xf] = *(undefined4 *)(param_2 + 0x3c);
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  if (*(int *)(param_2 + 0x44) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x44) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x10] = *(undefined4 *)(param_2 + 0x40);
  param_1[0x11] = *(undefined4 *)(param_2 + 0x44);
  *(undefined *)(param_1 + 0x12) = *(undefined *)(param_2 + 0x48);
  *(undefined *)((int)param_1 + 0x49) = *(undefined *)(param_2 + 0x49);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0060ea20(param_2 + 0x4c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6409 ; VA 0x0060f160 ; FUN_0060f160 */

int __fastcall FUN_0060f160(int param_1)

{
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d4ae;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_0060e8c0(0,&uStack_20,&uStack_11);
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  FUN_0060e8c0(0,&uStack_20,&uStack_11);
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  uStack_8._0_1_ = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  FUN_0060e8c0(0,&uStack_20,&uStack_11);
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  FUN_016830f0(param_1 + 0x60);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6410 ; VA 0x0060f260 ; FUN_0060f260 */

undefined * __fastcall FUN_0060f260(undefined *param_1)

{
  *param_1 = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  return param_1;
}



/* FUNCTION 6411 ; VA 0x0060f290 ; FUN_0060f290 */

undefined4 * __fastcall FUN_0060f290(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  return param_1;
}



/* FUNCTION 6412 ; VA 0x0060f2c0 ; FUN_0060f2c0 */

undefined4 * __fastcall FUN_0060f2c0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  return param_1;
}



/* FUNCTION 6413 ; VA 0x0060f2e0 ; FUN_0060f2e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_0060f2e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,int param_11,int *param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined param_17,
            undefined4 param_18)

{
  int iVar1;
  code *pcVar2;
  undefined4 *puVar3;
  uint uVar4;
  char cVar5;
  undefined4 uVar6;
  undefined **ppuVar7;
  undefined **ppuVar8;
  undefined **ppuVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  int *piVar13;
  int iVar14;
  uint uVar15;
  float10 fVar16;
  double dVar17;
  undefined *puVar18;
  code *pcVar19;
  undefined4 *puVar20;
  undefined *puVar21;
  undefined auStack_70 [8];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 *puStack_40;
  undefined4 *puStack_3c;
  code *pcStack_38;
  undefined **ppuStack_34;
  undefined4 *puStack_30;
  undefined *puStack_2c;
  undefined uStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_0179d92e;
  pvStack_1c = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_1c;
  puStack_3c = param_1;
  FUN_006b8f80();
  uStack_14._0_1_ = 1;
  *param_1 = RBX::Described<class_RBX::Network::Replicator,class_RBX::Network::IdSerializer>::
             vftable;
  uVar6 = FUN_005ee170();
  param_1[3] = uVar6;
  uStack_14._0_1_ = 2;
  FUN_006bcd20();
  param_1[0x19] = RBX::IMetric::vftable;
  param_1[0x1a] = RBX::Voxel2::GridListener::vftable;
  *param_1 = RBX::Network::Replicator::vftable;
  param_1[0x17] = RBX::Network::Replicator::vftable;
  param_1[0x19] = RBX::Network::Replicator::vftable;
  param_1[0x1a] = RBX::Network::Replicator::vftable;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  if (param_12 != (int *)0x0) {
    LOCK();
    param_12[1] = param_12[1] + 1;
    UNLOCK();
  }
  param_1[0x1b] = param_11;
  param_1[0x1c] = param_12;
  uStack_14._0_1_ = 6;
  uStack_48 = (double)CONCAT44(param_1 + 0x1d,(undefined4)uStack_48);
  param_1[0x1d] = param_3;
  param_1[0x1e] = param_4;
  param_1[0x1f] = param_5;
  param_1[0x20] = param_6;
  param_1[0x21] = param_7;
  param_1[0x22] = param_8;
  param_1[0x23] = param_9;
  param_1[0x24] = param_10;
  param_1[0x25] = param_2;
  param_1[0x26] = 0;
  FUN_006b79c0();
  FUN_006af1a0();
  FUN_006af1a0();
  FUN_006af1a0();
  FUN_006af1a0();
  puStack_40 = param_1 + 0x5fa;
  *puStack_40 = 0;
  param_1[0x5fb] = 0;
  param_1[0x5fc] = 0;
  uStack_14._0_1_ = 7;
  puStack_30 = (undefined4 *)0x0;
  puStack_2c = (undefined *)0x0;
  FUN_0060e8c0(0,&puStack_30,&uStack_21);
  puVar3 = puStack_3c;
  param_1[0x600] = 0;
  param_1[0x601] = 0;
  param_1[0x603] = 0;
  param_1[0x604] = 0;
  uStack_14._0_1_ = 8;
  FUN_0060f160();
  uStack_14._0_1_ = 9;
  FUN_0060f160();
  puVar3[0x63a] = 0xffffffff;
  *(undefined2 *)(puVar3 + 0x63b) = 0;
  *(undefined *)((int)puVar3 + 0x18ee) = 0;
  puVar3[0x63c] = 0;
  puVar3[0x63d] = 0;
  puVar3[0x63e] = 0;
  *(undefined *)(puVar3 + 0x63f) = 1;
  puVar3[0x641] = 0;
  puVar3[0x642] = 0;
  uStack_14._0_1_ = 0xc;
  puVar3[0x643] = (DAT_01d59f18 * 0x400) / 0x3c;
  FUN_01682800(puVar3 + 0x644);
  puVar3[0x646] = DAT_01d59f18;
  puVar3[0x647] = 0;
  puVar3[0x648] = 0;
  puVar3[0x649] = 0;
  puVar3[0x64a] = 0;
  puVar3[0x64b] = 0;
  puVar3[0x64c] = 0;
  puVar3[0x64d] = 0;
  puVar3[0x64e] = 0;
  puVar3[0x64f] = 0;
  puVar3[0x652] = 0;
  puVar3[0x653] = 0;
  puVar3[0x654] = 0;
  puVar3[0x655] = 0;
  puVar3[0x656] = 0;
  puVar3[0x657] = 0;
  puVar3[0x658] = 0;
  puVar3[0x659] = 0;
  puVar3[0x65a] = 0;
  puVar3[0x65b] = 0;
  puStack_2c = (undefined *)(float)DAT_01d59e84;
  uStack_14._0_1_ = 0x1b;
  puStack_40 = (undefined4 *)((float)DAT_01d59ea4 / DAT_018ce324);
  FUN_016830f0(puVar3 + 0x65c);
  puVar3[0x65f] = puStack_2c;
  puVar3[0x660] = puStack_40;
  puVar3[0x65e] = 0;
  puStack_40 = (undefined4 *)(float)DAT_01d59e78;
  puStack_2c = (undefined *)((float)DAT_01d59e94 / DAT_018ce324);
  FUN_016830f0(puVar3 + 0x662);
  puVar3[0x665] = puStack_40;
  puVar3[0x666] = puStack_2c;
  puVar3[0x664] = 0;
  puStack_40 = (undefined4 *)(float)DAT_01eace5c;
  puStack_2c = (undefined *)((float)DAT_01d59e9c / DAT_018ce324);
  FUN_016830f0(puVar3 + 0x668);
  puVar3[0x66b] = puStack_40;
  puVar3[0x66a] = 0;
  puVar3[0x66c] = puStack_2c;
  puStack_40 = (undefined4 *)(float)DAT_01d59e8c;
  puStack_2c = (undefined *)((float)DAT_01d59eac / DAT_018ce324);
  FUN_016830f0(puVar3 + 0x66e);
  puVar3[0x671] = puStack_40;
  puVar3[0x672] = puStack_2c;
  puVar3[0x670] = 0;
  puStack_40 = (undefined4 *)(float)DAT_01d59eb4;
  puStack_2c = (undefined *)((float)DAT_01d59ebc / DAT_018ce324);
  FUN_016830f0(puVar3 + 0x674);
  puVar3[0x677] = puStack_40;
  puVar3[0x676] = 0;
  puVar3[0x678] = puStack_2c;
  puVar3[0x67a] = 0;
  puVar3[0x67b] = 0;
  puVar3[0x67c] = DAT_01eace64;
  uVar6 = FUN_006d9070();
  puVar3[0x67d] = uVar6;
  *(undefined *)(puVar3 + 0x67e) = 0;
  *(undefined *)(puVar3 + 0x67f) = 0;
  puStack_40 = (undefined4 *)0xb;
  ppuVar7 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  if (ppuVar7 == &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = (undefined **)&DAT_018be194;
  }
  puVar3[0x680] = *ppuVar7;
  puVar3[0x681] = 0;
  puVar3[0x682] = 0x3f800000;
  puVar3[0x683] = 0;
  puVar3[0x684] = 0;
  puVar3[0x685] = 0;
  uStack_14._0_1_ = 0x1d;
  puVar3[0x686] = 0;
  FUN_0060ee60();
  uStack_14._0_1_ = 0x1e;
  FUN_006ba480(puVar3);
  *(undefined *)(puVar3 + 0x76c) = param_17;
  *(undefined *)((int)puVar3 + 0x1db1) = 0;
  puVar3[0x76d] = param_18;
  *(undefined2 *)(puVar3 + 0x76e) = 0;
  puVar3[0x76f] = 0;
  puVar3[0x770] = 0;
  puVar3[0x771] = 0;
  puVar3[0x772] = 0;
  puVar3[0x773] = 0;
  puVar3[0x774] = 0;
  puVar3[0x775] = 0;
  puVar3[0x776] = 0;
  puVar3[0x777] = 0;
  puVar3[0x778] = 0;
  puVar3[0x779] = 0;
  puVar3[0x77a] = 0;
  uStack_14._0_1_ = 0x24;
  FUN_006b1ac0();
  uStack_14._0_1_ = 0x25;
  FUN_006b1ac0();
  puVar3[0x787] = 0;
  uStack_14._0_1_ = 0x26;
  if (DAT_01ead1f1 == '\0') {
    DAT_01ead1f1 = '\x01';
    DAT_01ead1cc = 0;
    uRam01ead1d0 = 0;
    DAT_01ead1d4 = 0;
    DAT_01ead1d8 = 0;
    _DAT_01ead1ec = 0;
    DAT_01ead1dc = _DAT_018ce350;
    _DAT_01ead1e0 = _UNK_018ce354;
    _DAT_01ead1e4 = _UNK_018ce358;
    _DAT_01ead1e8 = _UNK_018ce35c;
  }
  FUN_005874f0();
  iVar1 = DAT_01ead1dc;
  for (iVar14 = DAT_01ead1d8; iVar14 != 0; iVar14 = *(int *)(iVar14 + -8)) {
    iVar14 = iVar1 + iVar14;
    iVar1 = *(int *)(iVar14 + -4);
  }
  uStack_14._0_1_ = 0x27;
  LOCK();
  uVar15 = DAT_01ead1cc + 0x80000000;
  UNLOCK();
  uVar4 = uVar15;
  if (((DAT_01ead1cc & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1cc)) {
    LOCK();
    DAT_01ead1cc = uVar15 | 0x40000000;
    UNLOCK();
    uVar4 = DAT_01ead1cc;
    if ((uVar15 >> 0x1e & 1) == 0) {
      uVar6 = FUN_00554e40();
      SetEvent(uVar6);
      uVar4 = DAT_01ead1cc;
    }
  }
  DAT_01ead1cc = uVar4;
  uStack_14._0_1_ = 0x26;
  if (DAT_01ead269 == '\0') {
    DAT_01ead269 = '\x01';
    DAT_01ead21c = 0;
    uRam01ead220 = 0;
    DAT_01ead224 = 0;
    DAT_01ead228 = 0;
    _DAT_01ead23c = 0;
    DAT_01ead22c = _DAT_018ce370;
    _DAT_01ead230 = _UNK_018ce374;
    _DAT_01ead234 = _UNK_018ce378;
    _DAT_01ead238 = _UNK_018ce37c;
  }
  FUN_005874f0();
  iVar1 = DAT_01ead22c;
  for (iVar14 = DAT_01ead228; iVar14 != 0; iVar14 = *(int *)(iVar14 + -8)) {
    iVar14 = iVar1 + iVar14;
    iVar1 = *(int *)(iVar14 + -4);
  }
  uStack_14._0_1_ = 0x28;
  LOCK();
  uVar15 = DAT_01ead21c + 0x80000000;
  UNLOCK();
  uVar4 = uVar15;
  if (((DAT_01ead21c & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead21c)) {
    LOCK();
    DAT_01ead21c = uVar15 | 0x40000000;
    UNLOCK();
    uVar4 = DAT_01ead21c;
    if ((uVar15 >> 0x1e & 1) == 0) {
      uVar6 = FUN_00554e40();
      SetEvent(uVar6);
      uVar4 = DAT_01ead21c;
    }
  }
  DAT_01ead21c = uVar4;
  uStack_14._0_1_ = 0x26;
  *(undefined *)(puVar3 + 0x788) = 0;
  FUN_00621160(0);
  puStack_40 = (undefined4 *)0xb;
  ppuVar8 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar8 + -1;
  if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar8;
  }
  puVar3[0x789] = *ppuVar7;
  puVar3[0x78a] = 0;
  puVar3[0x78b] = 0x3f800000;
  puVar3[0x78c] = 0;
  puVar3[0x78d] = 0;
  uStack_14._0_1_ = 0x29;
  if (DAT_01ead1f2 == '\0') {
    DAT_01ead1f2 = '\x01';
    DAT_01ead1a4 = 0;
    uRam01ead1a8 = 0;
    uRam01ead1ac = 0;
    DAT_01ead1b0 = 0;
    _DAT_01ead1c4 = 0;
    DAT_01ead1b4 = _DAT_018ce360;
    uRam01ead1b8 = _UNK_018ce364;
    uRam01ead1bc = _UNK_018ce368;
    uRam01ead1c0 = _UNK_018ce36c;
  }
  FUN_005874f0();
  iVar1 = DAT_01ead1b4;
  for (iVar14 = DAT_01ead1b0; iVar14 != 0; iVar14 = *(int *)(iVar14 + -8)) {
    iVar14 = iVar1 + iVar14;
    iVar1 = *(int *)(iVar14 + -4);
  }
  uStack_14._0_1_ = 0x2a;
  LOCK();
  uVar15 = DAT_01ead1a4 + 0x80000000;
  UNLOCK();
  uVar4 = uVar15;
  if (((DAT_01ead1a4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1a4)) {
    LOCK();
    DAT_01ead1a4 = uVar15 | 0x40000000;
    UNLOCK();
    uVar4 = DAT_01ead1a4;
    if ((uVar15 >> 0x1e & 1) == 0) {
      uVar6 = FUN_00554e40();
      SetEvent(uVar6);
      uVar4 = DAT_01ead1a4;
    }
  }
  DAT_01ead1a4 = uVar4;
  uStack_14._0_1_ = 0x29;
  if (DAT_01ead26a == '\0') {
    DAT_01ead26a = '\x01';
    DAT_01ead1f4 = 0;
    uRam01ead1f8 = 0;
    DAT_01ead1fc = 0;
    DAT_01ead200 = 0;
    _DAT_01ead214 = 0;
    DAT_01ead204 = _DAT_018ce380;
    _DAT_01ead208 = _UNK_018ce384;
    _DAT_01ead20c = _UNK_018ce388;
    _DAT_01ead210 = _UNK_018ce38c;
  }
  FUN_005874f0();
  iVar1 = DAT_01ead204;
  for (iVar14 = DAT_01ead200; iVar14 != 0; iVar14 = *(int *)(iVar14 + -8)) {
    iVar14 = iVar1 + iVar14;
    iVar1 = *(int *)(iVar14 + -4);
  }
  uStack_14._0_1_ = 0x2b;
  LOCK();
  uVar15 = DAT_01ead1f4 + 0x80000000;
  UNLOCK();
  uVar4 = uVar15;
  if (((DAT_01ead1f4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1f4)) {
    LOCK();
    DAT_01ead1f4 = uVar15 | 0x40000000;
    UNLOCK();
    uVar4 = DAT_01ead1f4;
    if ((uVar15 >> 0x1e & 1) == 0) {
      uVar6 = FUN_00554e40();
      SetEvent(uVar6);
      uVar4 = DAT_01ead1f4;
    }
  }
  DAT_01ead1f4 = uVar4;
  uStack_14._0_1_ = 0x29;
  *(undefined *)(puVar3 + 0x78e) = 0;
  FUN_00621160(0);
  puStack_40 = (undefined4 *)0xb;
  ppuVar8 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar8 + -1;
  if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar8;
  }
  puVar3[0x78f] = *ppuVar7;
  puVar3[0x790] = 0;
  puVar3[0x791] = 0x3f800000;
  puVar3[0x792] = 0;
  puVar3[0x793] = 0;
  FUN_016dee4c(puVar3 + 0x794,2);
  *(undefined *)(puVar3 + 0x7a0) = 0;
  puStack_40 = (undefined4 *)0xb;
  ppuVar8 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar8 + -1;
  if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar8;
  }
  puVar3[0x7a1] = *ppuVar7;
  puVar3[0x7a2] = 0;
  puVar3[0x7a3] = 0x3f800000;
  puVar3[0x7a4] = 0;
  puVar3[0x7a5] = 0;
  *(undefined *)(puVar3 + 0x7a6) = 0;
  puStack_40 = (undefined4 *)0xb;
  ppuVar8 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar8 + -1;
  if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar8;
  }
  puVar3[0x7a7] = *ppuVar7;
  puVar3[0x7a8] = 0;
  puVar3[0x7a9] = 0x3f800000;
  puVar3[0x7aa] = 0;
  puVar3[0x7ab] = 0;
  *(undefined *)(puVar3 + 0x7ac) = 0;
  puStack_40 = (undefined4 *)0xb;
  ppuVar8 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar8 + -1;
  if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar8;
  }
  puVar3[0x7ad] = *ppuVar7;
  puVar3[0x7ae] = 0;
  puVar3[0x7af] = 0x3f800000;
  puVar3[0x7b0] = 0;
  puVar3[0x7b1] = 0;
  *(undefined *)(puVar3 + 0x7b2) = 0;
  *(undefined *)(puVar3 + 0x7b3) = 0;
  puStack_40 = (undefined4 *)0xb;
  ppuVar8 = &boost::lock_error::vftable_meta_ptr;
  pcVar19 = (code *)&DAT_018be100;
  uVar6 = 0x60fd2a;
  ppuVar9 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar9 + -1;
  if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar9;
  }
  puVar3[0x7b4] = *ppuVar7;
  puVar3[0x7b5] = 0;
  puVar3[0x7b6] = 0x3f800000;
  puVar3[0x7b7] = 0;
  puVar3[0x7b8] = 0;
  puVar3[0x7b9] = 0;
  puVar3[0x7ba] = 0;
  *(undefined *)(puVar3 + 0x7bb) = 0;
  puStack_40 = (undefined4 *)0xb;
  ppuVar9 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar9 + -1;
  if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar9;
  }
  puVar3[0x7bc] = *ppuVar7;
  puVar3[0x7bd] = 0;
  puVar3[0x7be] = 0x3f800000;
  puVar3[0x7bf] = 0;
  puVar3[0x7c0] = 0;
  puVar3[0x7c1] = 0;
  puVar3[0x7c2] = 0;
  puVar20 = puVar3 + 0x7c4;
  uStack_14._0_1_ = 0x33;
  *puVar20 = 0;
  puVar3[0x7c5] = 0;
  puVar3[0x7c6] = 0;
  puVar3[0x7c7] = 0;
  puVar3[0x7c8] = 0;
  puStack_40 = puVar20;
  puVar10 = (undefined4 *)FUN_01674e20(8);
  *puVar20 = puVar10;
  *puVar10 = 0;
  puVar10[1] = 0;
  *(undefined4 **)*puVar20 = puVar20;
  puVar3[0x7c9] = 0;
  uStack_14._0_1_ = 0x34;
  puVar3[0x7cc] = 0;
  puVar3[0x7cd] = 0;
  puVar3[0x7ce] = 0;
  FUN_016827a0(puVar3 + 2000);
  *(undefined8 *)(puVar3 + 0x7d2) = DAT_018c0d60;
  puVar3[0x7d4] = 0;
  puVar3[0x7d5] = 0;
  puVar20 = puVar3 + 0x7d7;
  *(undefined *)(puVar3 + 0x7d6) = 0;
  *puVar20 = 0;
  puVar3[0x7d8] = 0;
  puVar3[0x7d9] = 0;
  puVar3[0x7da] = 0;
  puVar3[0x7db] = 0;
  puStack_40 = puVar20;
  puVar10 = (undefined4 *)FUN_01674e20(8);
  *puVar20 = puVar10;
  *puVar10 = 0;
  puVar10[1] = 0;
  *(undefined4 **)*puVar20 = puVar20;
  puVar20 = puVar3 + 0x7dd;
  puVar3[0x7dc] = param_16;
  uStack_14._0_1_ = 0x35;
  *puVar20 = 0;
  puVar3[0x7de] = 0;
  puStack_40 = puVar20;
  uVar11 = FUN_00575af0();
  *puVar20 = uVar11;
  uStack_14._0_1_ = 0x36;
  FUN_016f4053(puVar3 + 0x7df,0x18,0x80,FUN_0054f030,FUN_005507b0);
  puVar3[0xadf] = 1;
  uStack_14._0_1_ = 0x37;
  FUN_016f4053(puVar3 + 0xae0,0x18,0x80,FUN_0054f030,FUN_005507b0);
  *(undefined *)(puVar3 + 0xde0) = 0;
  puStack_40 = (undefined4 *)0xb;
  ppuVar9 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar9 + -1;
  if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar9;
  }
  puVar3[0xde1] = *ppuVar7;
  puVar3[0xde2] = 0;
  puVar3[0xde3] = 0x3f800000;
  puVar3[0xde4] = 0;
  puVar3[0xde5] = 0;
  *(undefined *)(puVar3 + 0xde6) = 0;
  puStack_40 = (undefined4 *)0xb;
  ppuVar9 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar9 + -1;
  if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar9;
  }
  puVar3[0xde7] = *ppuVar7;
  puVar3[0xde8] = 0;
  puVar3[0xde9] = 0x3f800000;
  puVar3[0xdea] = 0;
  puVar3[0xdeb] = 0;
  *(undefined *)(puVar3 + 0xdec) = 0;
  puStack_40 = (undefined4 *)0xb;
  ppuVar9 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar9 + -1;
  if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar9;
  }
  puVar3[0xded] = *ppuVar7;
  puVar3[0xdee] = 0;
  puVar3[0xdef] = 0x3f800000;
  puVar3[0xdf0] = 0;
  puVar3[0xdf1] = 0;
  *(undefined *)(puVar3 + 0xdf2) = 0;
  puStack_40 = (undefined4 *)0xb;
  ppuVar9 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar9 + -1;
  if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar9;
  }
  puVar3[0xdf3] = *ppuVar7;
  puVar3[0xdf4] = 0;
  puVar3[0xdf5] = 0x3f800000;
  puVar3[0xdf6] = 0;
  puVar3[0xdf7] = 0;
  *(undefined *)(puVar3 + 0xdf8) = 0;
  puVar21 = &DAT_018be100;
  puStack_40 = (undefined4 *)0xb;
  puVar20 = (undefined4 *)0x6100da;
  ppuVar9 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_40);
  ppuVar7 = ppuVar9 + -1;
  if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar9;
  }
  puVar3[0xdf9] = *ppuVar7;
  puVar3[0xdfa] = 0;
  puVar3[0xdfb] = 0x3f800000;
  puVar3[0xdfc] = 0;
  puVar3[0xdfd] = 0;
  puVar3[0xe02] = param_14;
  *(undefined *)(puVar3 + 0xdfe) = 0;
  *(undefined4 *)((int)puVar3 + 0x37fd) = 0x10101;
  *(undefined2 *)((int)puVar3 + 0x3801) = 0;
  puVar3[0xe03] = param_15;
  puVar3[0xe04] = 0;
  puVar3[0xe05] = 0;
  puVar3[0xe06] = 0;
  puVar3[0xe07] = 0;
  puVar3[0xe08] = 0;
  puVar3[0xe09] = 0;
  puVar3[0xe0a] = 0;
  puVar3[0xe0b] = 0;
  puVar3[0xe0c] = 0;
  puVar3[0xe0d] = 0;
  puVar3[0xe0e] = 0;
  puVar3[0xe0f] = 0;
  puVar3[0xe10] = 0xffffffff;
  *(undefined *)(puVar3 + 0xe11) = 0;
  puVar3[0xe12] = 0;
  puVar3[0xe13] = 0;
  puVar3[0xe14] = 0;
  puVar3[0xe15] = 0;
  puVar3[0xe16] = 0;
  puVar3[0xe17] = 0;
  uStack_14._0_1_ = 0x40;
  *(undefined *)(puVar3 + 0xe18) = 0;
  puStack_40 = (undefined4 *)0x0;
  *(undefined8 *)(puVar3 + 0xe1a) = 0;
  FUN_005d0b80(0x1b,&puStack_40,&uStack_21);
  uStack_14._0_1_ = 0x41;
  puStack_40 = (undefined4 *)0x0;
  FUN_005d0b80(0x1b,&puStack_40,&uStack_21);
  uStack_14._0_1_ = 0x42;
  puStack_40 = (undefined4 *)0x0;
  FUN_005d0b80(0x1e,&puStack_40,&uStack_21);
  *(undefined *)(puVar3 + 0xe25) = 0;
  puVar3[0xe26] = 0;
  puVar3[0xe27] = 0;
  puVar3[0xe2a] = 0;
  uStack_14._0_1_ = 0x45;
  FUN_0151f360(0);
  puVar3[0xe2c] = 0;
  puVar3[0xe2d] = 0;
  puVar10 = puVar3 + 0xe2f;
  *(undefined *)(puVar3 + 0xe2e) = 0;
  uStack_14._0_1_ = 0x47;
  *puVar10 = 0;
  puVar3[0xe30] = 0;
  puStack_40 = puVar10;
  uVar11 = FUN_00575b50(0,0);
  *puVar10 = uVar11;
  puVar10 = puVar3 + 0xe31;
  uStack_14._0_1_ = 0x48;
  *puVar10 = 0;
  puVar3[0xe32] = 0;
  puStack_40 = puVar10;
  uVar11 = FUN_00575b50(0,0);
  *puVar10 = uVar11;
  puVar10 = puVar3 + 0xe34;
  uStack_14._0_1_ = 0x49;
  *puVar10 = 0;
  puVar3[0xe35] = 0;
  puVar3[0xe36] = 0;
  puVar3[0xe37] = 0;
  puVar3[0xe38] = 0;
  puStack_40 = puVar10;
  puVar12 = (undefined4 *)FUN_00578020(1);
  *puVar10 = puVar12;
  *puVar12 = 0;
  puVar12[1] = 0;
  *(undefined4 **)*puVar10 = puVar10;
  puVar3[0xe39] = 0;
  puVar3[0xe3c] = 0;
  puVar3[0xe3d] = 0;
  puVar3[0xe3e] = 0;
  uStack_14._0_1_ = 0x4c;
  FUN_01682800(puVar3 + 0xe40);
  dVar17 = DAT_018ce300;
  puVar3[0xe44] = 0;
  puVar3[0xe45] = 0;
  puVar3[0xe46] = 0;
  puVar3[0xe47] = 0;
  puVar3[0xe49] = 0;
  puVar3[0xe4a] = 0;
  puVar3[0xe4b] = 0;
  *(double *)(puVar3 + 0xe4c) = dVar17;
  puVar3[0xe4e] = 0;
  puVar3[0xe50] = 0;
  puVar3[0xe51] = 0;
  puVar3[0xe52] = 0;
  puVar3[0xe53] = 0;
  *(undefined *)(puVar3 + 0xe54) = 1;
  *(double *)(puVar3 + 0xe56) = dVar17;
  puVar3[0xe58] = 0;
  puVar3[0xe5a] = 0;
  puVar3[0xe5b] = 0;
  puVar3[0xe5c] = 0;
  puVar3[0xe5d] = 0;
  *(undefined *)(puVar3 + 0xe5e) = 1;
  *(double *)(puVar3 + 0xe60) = dVar17;
  puVar3[0xe62] = 0;
  puVar3[0xe64] = 0;
  puVar3[0xe65] = 0;
  puVar3[0xe66] = 0;
  puVar3[0xe67] = 0;
  *(undefined *)(puVar3 + 0xe68) = 1;
  *(double *)(puVar3 + 0xe6a) = dVar17;
  puVar3[0xe6c] = 0;
  puVar3[0xe6d] = 0;
  puVar3[0xe6e] = 0;
  puVar3[0xe6f] = 0;
  *(undefined *)(puVar3 + 0xe72) = 1;
  *(undefined8 *)(puVar3 + 0xe70) = 0;
  *(double *)(puVar3 + 0xe76) = dVar17;
  puVar3[0xe78] = 0;
  puVar3[0xe7a] = 0;
  puVar3[0xe7b] = 0;
  puVar3[0xe7c] = 0;
  puVar3[0xe7d] = 0;
  *(undefined *)(puVar3 + 0xe7e) = 1;
  *(double *)(puVar3 + 0xe84) = dVar17;
  puVar3[0xe86] = 0;
  puVar3[0xe88] = 0;
  puVar3[0xe89] = 0;
  puVar3[0xe8a] = 0;
  puVar3[0xe8b] = 0;
  *(undefined *)(puVar3 + 0xe8c) = 1;
  *(double *)(puVar3 + 0xe8e) = dVar17;
  puVar3[0xe90] = 0;
  puVar3[0xe92] = 0;
  puVar3[0xe93] = 0;
  puVar3[0xe94] = 0;
  puVar3[0xe95] = 0;
  *(undefined *)(puVar3 + 0xe96) = 1;
  *(double *)(puVar3 + 0xe98) = dVar17;
  puVar3[0xe9a] = 0;
  puVar3[0xe9c] = 0;
  puVar3[0xe9d] = 0;
  puVar3[0xe9e] = 0;
  puVar3[0xe9f] = 0;
  *(undefined *)(puVar3 + 0xea0) = 1;
  *(double *)(puVar3 + 0xea2) = dVar17;
  puVar3[0xea4] = 0;
  puVar3[0xea6] = 0;
  puVar3[0xea7] = 0;
  puVar3[0xea8] = 0;
  puVar3[0xea9] = 0;
  *(undefined *)(puVar3 + 0xeaa) = 1;
  puVar3[0xeba] = 0;
  puVar3[0xebb] = 0;
  puVar3[0xebc] = 0;
  puVar3[0xebd] = 0;
  puVar3[0xebe] = 0;
  uStack_14 = CONCAT31(uStack_14._1_3_,0x4d);
  piVar13 = (int *)FUN_0054db20();
  pcVar2 = *(code **)(*piVar13 + 0x9c);
  FUN_0060ed10(uStack_48._4_4_);
  uVar11 = (*pcVar2)();
  puVar3 = puStack_3c;
  puStack_3c[0xe42] = uVar11;
  puStack_3c[0xe43] = 0xffffffff;
  uVar11 = 0x610585;
  puVar10 = puStack_3c;
  FUN_006ddbd0(puStack_3c);
  if ((puVar3[0xe02] & 0x2000000) == 0) {
    puVar3[0x640] = 2;
  }
  uStack_48 = (double)CONCAT44(param_11,(undefined4)uStack_48);
  if (param_11 != 0) {
    uStack_58 = puVar3[0x1d];
    uStack_54 = puVar3[0x1e];
    uStack_50 = puVar3[0x1f];
    uStack_4c = puVar3[0x20];
    uStack_68 = puVar3[0x21];
    uStack_64 = puVar3[0x22];
    uStack_60 = puVar3[0x23];
    uStack_5c = puVar3[0x24];
    pcStack_38 = FUN_00623970;
    ppuStack_34 = (undefined **)0x0;
    puStack_30 = puVar3;
    cVar5 = FUN_00585a40();
    if (cVar5 == '\0') {
      puVar18 = &DAT_018ce295;
      pcVar19 = pcStack_38;
      ppuVar8 = ppuStack_34;
      puVar20 = puStack_30;
      puVar21 = puStack_2c;
    }
    else {
      puVar18 = (undefined *)0x0;
    }
    dVar17 = (double)CONCAT44(uStack_64,uStack_68);
    FUN_006afed0(uStack_58,uStack_54,uStack_50,uStack_4c,dVar17,CONCAT44(uStack_5c,uStack_60),
                 puVar18,uVar6,pcVar19,ppuVar8,puVar20,puVar21,uVar11,puVar10);
    piVar13 = (int *)FUN_0054db20();
    (**(code **)(*piVar13 + 0xfc))(puVar3 + 0x17);
  }
  FUN_006a6900();
  FUN_016f3fe0();
  uStack_48 = dVar17 / DAT_018c0d70;
  fVar16 = (float10)FUN_01683110();
  *(double *)(puVar3 + 0xe28) = (double)((float10)uStack_48 - fVar16);
  if (DAT_01ee420a != '\0') {
    puVar20 = (undefined4 *)FUN_006b1620(auStack_70,puVar3 + 0x1d,1,0x7c);
    uStack_14._0_1_ = 0x4e;
    if (0xf < (uint)puVar20[5]) {
      puVar20 = (undefined4 *)*puVar20;
    }
    FUN_01677650(DAT_01ee420a,"Replicator created for player %s",puVar20);
    uStack_14 = CONCAT31(uStack_14._1_3_,0x4d);
    FUN_005507b0();
    if (DAT_01ee420a != '\0') {
      FUN_016774b0(DAT_01ee420a,"Replicator created: %p",puVar3);
    }
  }
  iVar14 = FUN_01674e20(4);
  uStack_48 = (double)CONCAT44(iVar14,(undefined4)uStack_48);
  uStack_14._0_1_ = 0x4f;
  if (iVar14 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_0060ed50(0x50);
  }
  piVar13 = (int *)puVar3[0x652];
  uStack_14._0_1_ = 0x4d;
  puVar3[0x652] = uVar6;
  if (piVar13 != (int *)0x0) {
    if (*piVar13 != 0) {
      FUN_00615040(*piVar13);
    }
    FUN_01674ea0(piVar13,4);
  }
  iVar14 = FUN_01674e20(4);
  uStack_48 = (double)CONCAT44(iVar14,(undefined4)uStack_48);
  uStack_14._0_1_ = 0x50;
  if (iVar14 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_0060ed50(0x40);
  }
  piVar13 = (int *)puVar3[0x653];
  uStack_14._0_1_ = 0x4d;
  puVar3[0x653] = uVar6;
  if (piVar13 != (int *)0x0) {
    if (*piVar13 != 0) {
      FUN_00615040(*piVar13);
    }
    FUN_01674ea0(piVar13,4);
  }
  iVar14 = FUN_01674e20(4);
  uStack_48 = (double)CONCAT44(iVar14,(undefined4)uStack_48);
  uStack_14._0_1_ = 0x51;
  if (iVar14 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_0060ed50(0x40);
  }
  piVar13 = (int *)puVar3[0x654];
  uStack_14._0_1_ = 0x4d;
  puVar3[0x654] = uVar6;
  if (piVar13 != (int *)0x0) {
    if (*piVar13 != 0) {
      FUN_00615040(*piVar13);
    }
    FUN_01674ea0(piVar13,4);
  }
  iVar14 = FUN_01674e20(4);
  uStack_48 = (double)CONCAT44(iVar14,(undefined4)uStack_48);
  uStack_14._0_1_ = 0x52;
  if (iVar14 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_0060ed50(0x40);
  }
  piVar13 = (int *)puVar3[0x655];
  uStack_14._0_1_ = 0x4d;
  puVar3[0x655] = uVar6;
  if (piVar13 != (int *)0x0) {
    if (*piVar13 != 0) {
      FUN_00615040(*piVar13);
    }
    FUN_01674ea0(piVar13,4);
  }
  iVar14 = FUN_01674e20(4);
  uStack_48 = (double)CONCAT44(iVar14,(undefined4)uStack_48);
  uStack_14._0_1_ = 0x53;
  if (iVar14 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_0060ed50(0x50);
  }
  piVar13 = (int *)puVar3[0x656];
  uStack_14._0_1_ = 0x4d;
  puVar3[0x656] = uVar6;
  if (piVar13 != (int *)0x0) {
    if (*piVar13 != 0) {
      FUN_00615040(*piVar13);
    }
    FUN_01674ea0(piVar13,4);
  }
  iVar14 = FUN_01674e20(4);
  uStack_48 = (double)CONCAT44(iVar14,(undefined4)uStack_48);
  uStack_14._0_1_ = 0x54;
  if (iVar14 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_0060ed50(0x48);
  }
  piVar13 = (int *)puVar3[0x657];
  uStack_14._0_1_ = 0x4d;
  puVar3[0x657] = uVar6;
  if (piVar13 != (int *)0x0) {
    if (*piVar13 != 0) {
      FUN_00615040(*piVar13);
    }
    FUN_01674ea0(piVar13,4);
  }
  iVar14 = FUN_01674e20(4);
  uStack_48 = (double)CONCAT44(iVar14,(undefined4)uStack_48);
  uStack_14._0_1_ = 0x55;
  if (iVar14 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_0060ed50(0x48);
  }
  piVar13 = (int *)puVar3[0x658];
  uStack_14._0_1_ = 0x4d;
  puVar3[0x658] = uVar6;
  if (piVar13 != (int *)0x0) {
    if (*piVar13 != 0) {
      FUN_00615040(*piVar13);
    }
    FUN_01674ea0(piVar13,4);
  }
  iVar14 = FUN_01674e20(4);
  uStack_48 = (double)CONCAT44(iVar14,(undefined4)uStack_48);
  uStack_14._0_1_ = 0x56;
  if (iVar14 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_0060ed50(0x40);
  }
  piVar13 = (int *)puVar3[0x659];
  uStack_14._0_1_ = 0x4d;
  puVar3[0x659] = uVar6;
  if (piVar13 != (int *)0x0) {
    if (*piVar13 != 0) {
      FUN_00615040(*piVar13);
    }
    FUN_01674ea0(piVar13,4);
  }
  iVar14 = FUN_01674e20(4);
  uStack_48 = (double)CONCAT44(iVar14,(undefined4)uStack_48);
  uStack_14._0_1_ = 0x57;
  if (iVar14 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_0060ed50(0x48);
  }
  piVar13 = (int *)puVar3[0x65a];
  uStack_14._0_1_ = 0x4d;
  puVar3[0x65a] = uVar6;
  if (piVar13 != (int *)0x0) {
    if (*piVar13 != 0) {
      FUN_00615040(*piVar13);
    }
    FUN_01674ea0(piVar13,4);
  }
  FUN_0062b770();
  FUN_01682800(&uStack_48);
  puVar3[0x644] = (undefined4)uStack_48;
  puVar3[0x645] = uStack_48._4_4_;
  puStack_2c = (undefined *)DAT_01d59dc8;
  puVar21 = (undefined *)DAT_01d59dc8;
  if (DAT_01d59fe8 != 0) {
    uStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = 0;
    FUN_005542c0(&DAT_018bf378,1);
    uStack_14._0_1_ = 0x58;
    iVar14 = FUN_006b16c0(&DAT_01d7a8b8,&DAT_01d59fd8,auStack_70);
    uStack_14._0_1_ = 0x4d;
    FUN_005507b0();
    puVar21 = puStack_2c;
    if (iVar14 != -1) {
      puVar21 = (undefined *)iVar14;
    }
  }
  puStack_2c = puVar21;
  uVar15 = FUN_01679ce0();
  puVar3[0xe74] = 0;
  uStack_48 = (double)((ulonglong)uStack_48 & 0xffffffff);
  *(bool *)(puVar3 + 0xe48) = (int)(uVar15 % 100) < (int)puVar21;
  puVar3[0xe78] = 0;
  puVar3[0xe7a] = 0;
  puVar3[0xe7b] = 0;
  puVar3[0xe7c] = 0;
  puVar3[0xe7d] = 0;
  *(undefined *)(puVar3 + 0xe7e) = 1;
  puVar3[0xeb8] = 0;
  puVar3[0xeb7] = 0;
  puVar20 = (undefined4 *)FUN_005d0b80(0x1b,(int)&uStack_48 + 4,&uStack_21);
  if (puVar3 + 0xe1c != puVar20) {
    FUN_0056d320();
    puVar3[0xe1c] = *puVar20;
    puVar3[0xe1d] = puVar20[1];
    puVar3[0xe1e] = puVar20[2];
    *puVar20 = 0;
    puVar20[1] = 0;
    puVar20[2] = 0;
  }
  FUN_0056d320();
  if (param_12 != (int *)0x0) {
    LOCK();
    iVar14 = param_12[1] + -1;
    param_12[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*param_12)();
      LOCK();
      iVar14 = param_12[2] + -1;
      param_12[2] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)(*param_12 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return puVar3;
}



/* FUNCTION 6414 ; VA 0x00610b20 ; FUN_00610b20 */

undefined4 * __thiscall
FUN_00610b20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d948;
  pvStack_10 = ExceptionList;
  uStack_20 = param_5;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008f7870(param_3);
  FUN_005c4330(&uStack_28,uVar1);
  FUN_00a360a0(param_2,param_4,1);
  uStack_20 = param_3;
  puStack_24 = param_1 + 0x4a;
  uStack_8 = 0;
  *param_1 = RBX::Network::ReplicatorJob::vftable;
  uStack_28 = 0x610b85;
  FUN_0060dcd0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6415 ; VA 0x00610ba0 ; FUN_00610ba0 */

undefined4 * __fastcall FUN_00610ba0(undefined4 *param_1)

{
  *param_1 = 0;
  *(undefined2 *)(param_1 + 1) = 0;
  return param_1;
}



/* FUNCTION 6416 ; VA 0x00610bb0 ; FUN_00610bb0 */

undefined4 * __thiscall FUN_00610bb0(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c9c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  uStack_8 = 0;
  *param_1 = RBX::physics_receiver_exception::vftable;
  FUN_0054ef60(param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6417 ; VA 0x00610c20 ; FUN_00610c20 */

undefined4 * __thiscall FUN_00610c20(undefined4 *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c9c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined8 *)(param_1 + 1) = 0;
  uStack_8 = 0;
  *param_1 = RBX::physics_receiver_exception::vftable;
  FUN_0054ef60(param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6418 ; VA 0x00610c80 ; FUN_00610c80 */

undefined4 __thiscall FUN_00610c80(undefined4 param_1,undefined4 param_2)

{
  FUN_0061f5c0(param_1,param_2);
  return param_1;
}



/* FUNCTION 6419 ; VA 0x00610ca0 ; FUN_00610ca0 */

undefined4 * __fastcall FUN_00610ca0(undefined4 *param_1)

{
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 6420 ; VA 0x00610cc0 ; FUN_00610cc0 */

undefined4 * __thiscall FUN_00610cc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  FUN_0054f9c0(param_2,param_3,auStack_2c);
  if (0xf < uStack_18) {
    uVar2 = uStack_18 + 1;
    uVar1 = auStack_2c[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_2c[0] - 4);
      uVar2 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  *param_1 = std::system_error::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6421 ; VA 0x00610d70 ; FUN_00610d70 */

void __fastcall FUN_00610d70(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01674ea0(*param_1);
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6422 ; VA 0x00610dc0 ; FUN_00610dc0 */

void FUN_00610dc0(void)

{
  FUN_00611620();
  FUN_0089b230();
  return;
}



/* FUNCTION 6423 ; VA 0x00610de0 ; FUN_00610de0 */

void __fastcall FUN_00610de0(int *param_1)

{
  if ((int *)*param_1 != (int *)0x0) {
    *(int *)*param_1 = param_1[1];
  }
  return;
}



/* FUNCTION 6424 ; VA 0x00610df0 ; FUN_00610df0 */

void __fastcall FUN_00610df0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179d960;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1 + 0x303,0x18,0x80,FUN_005507b0);
  uStack_8 = 1;
  FUN_016f32d1(param_1 + 2,0x18,0x80,FUN_005507b0);
  iVar1 = *param_1;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00576640(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x2c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6425 ; VA 0x00610e90 ; FUN_00610e90 */

void __fastcall FUN_00610e90(uint *param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piStack_2c;
  int *piStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  uVar1 = param_1[2];
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while (uVar1 != 0) {
    uStack_8 = 0xffffffff;
    puVar3 = (undefined4 *)((param_1[1] % *param_1) * 0x58 + param_1[3]);
    param_1[1] = (param_1[1] + 1) % *param_1;
    FUN_0060f060(puVar3);
    (**(code **)*puVar3)(0);
    param_1[2] = param_1[2] - 1;
    FUN_00617ad0();
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar2 = piStack_24[2] + -1;
        piStack_24[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar2 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    uStack_8 = 0;
    FUN_00617b40();
    uVar1 = param_1[2];
  }
  uStack_8 = 0xffffffff;
  FUN_01674ea0(param_1[3]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6426 ; VA 0x00610f90 ; FUN_00610f90 */

void __fastcall FUN_00610f90(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  uVar2 = param_1[2];
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uVar1 = param_1[1];
    do {
      uVar1 = (uVar1 + 1) % *param_1;
      uVar2 = uVar2 - 1;
    } while (uVar2 != 0);
    ExceptionList = &pvStack_10;
    param_1[2] = 0;
    param_1[1] = uVar1;
  }
  FUN_01674ea0(param_1[3]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6427 ; VA 0x00610ff0 ; FUN_00610ff0 */

void __fastcall FUN_00610ff0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00619470();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x20);
  return;
}



/* FUNCTION 6428 ; VA 0x00611060 ; FUN_00611060 */

void __fastcall FUN_00611060(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00602ed0(*param_1,param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6429 ; VA 0x006110a0 ; FUN_006110a0 */

void __fastcall FUN_006110a0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)param_1[1];
  for (param_1 = (undefined4 *)*param_1; param_1 != puVar1; param_1 = param_1 + 0x16) {
    (**(code **)*param_1)(0);
  }
  return;
}



/* FUNCTION 6430 ; VA 0x006110d0 ; FUN_006110d0 */

void __fastcall FUN_006110d0(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 4) {
    FUN_0056cd30();
  }
  return;
}



/* FUNCTION 6431 ; VA 0x00611100 ; FUN_00611100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00611100(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 4);
  uVar4 = DAT_01ead244;
  if (piVar1 != (int *)0x0) {
    iVar2 = *(int *)(param_1 + 0xc);
    if (iVar2 == 1) {
      if (DAT_01ead26b == '\0') {
        DAT_01ead26b = '\x01';
        DAT_01ead244 = 0;
        uRam01ead248 = 0;
        DAT_01ead24c = (int *)0x0;
        DAT_01ead250 = 0;
        _DAT_01ead264 = 0;
        DAT_01ead254 = _DAT_018ce340;
        uRam01ead258 = _UNK_018ce344;
        uRam01ead25c = _UNK_018ce348;
        uRam01ead260 = _UNK_018ce34c;
      }
      ExceptionList = &pvStack_10;
      FUN_005874f0();
      *piVar1 = (int)DAT_01ead24c;
      uStack_8 = 0;
      DAT_01ead24c = piVar1;
    }
    else {
      if (DAT_01ead26b == '\0') {
        DAT_01ead26b = '\x01';
        DAT_01ead244 = 0;
        uRam01ead248 = 0;
        DAT_01ead24c = (int *)0x0;
        DAT_01ead250 = 0;
        _DAT_01ead264 = 0;
        DAT_01ead254 = _DAT_018ce340;
        uRam01ead258 = _UNK_018ce344;
        uRam01ead25c = _UNK_018ce348;
        uRam01ead260 = _UNK_018ce34c;
      }
      ExceptionList = &pvStack_10;
      FUN_005874f0();
      FUN_0061e1a0(piVar1,iVar2);
      uStack_8 = 1;
    }
    LOCK();
    uVar3 = DAT_01ead244 + 0x80000000;
    UNLOCK();
    uVar4 = uVar3;
    if (((DAT_01ead244 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead244)) {
      LOCK();
      DAT_01ead244 = uVar3 | 0x40000000;
      UNLOCK();
      uVar4 = DAT_01ead244;
      if ((uVar3 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
        uVar4 = DAT_01ead244;
      }
    }
  }
  DAT_01ead244 = uVar4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6432 ; VA 0x00611210 ; thunk_FUN_00611c70 */

void __fastcall thunk_FUN_00611c70(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  puVar1 = (undefined4 *)param_1[3];
  do {
    if (puVar1 == (undefined4 *)0x0) {
      iVar4 = param_1[1];
      if (iVar4 != 0) {
        if (*(char *)((int)param_1 + 9) != '\0') {
          FUN_005cf430(*param_1,iVar4 + 8);
          iVar4 = param_1[1];
        }
        FUN_01674ea0(iVar4,0x38);
      }
      return;
    }
    param_1[3] = *puVar1;
    uVar2 = puVar1[7];
    if (0xf < uVar2) {
      iVar4 = puVar1[2];
      uVar5 = uVar2 + 1;
      iVar3 = iVar4;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(iVar4 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    puVar1[6] = 0;
    puVar1[7] = 0xf;
    *(undefined *)(puVar1 + 2) = 0;
    FUN_01674ea0(puVar1,0x38);
    puVar1 = (undefined4 *)param_1[3];
  } while( true );
}



/* FUNCTION 6433 ; VA 0x00611220 ; FUN_00611220 */

void __fastcall FUN_00611220(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00611260. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 6434 ; VA 0x00611270 ; FUN_00611270 */

void __fastcall FUN_00611270(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x20);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x28) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x20) = 0;
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  return;
}



/* FUNCTION 6435 ; VA 0x006112d0 ; FUN_006112d0 */

void __fastcall FUN_006112d0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_005cf430(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x38);
  }
  return;
}



/* FUNCTION 6436 ; VA 0x00611300 ; FUN_00611300 */

void __fastcall FUN_00611300(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[4];
  if (iVar1 != 0) {
    do {
      iVar1 = iVar1 + -1;
      param_1[4] = iVar1;
    } while (iVar1 != 0);
    param_1[3] = 0;
  }
  iVar1 = param_1[2];
  while (iVar1 != 0) {
    iVar1 = iVar1 + -1;
    iVar2 = *(int *)(param_1[1] + iVar1 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x10);
    }
  }
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 6437 ; VA 0x006113b0 ; FUN_006113b0 */

void __fastcall FUN_006113b0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    FUN_00577ac0();
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x18);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 6438 ; VA 0x00611470 ; FUN_00611470 */

void __fastcall FUN_00611470(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    uVar3 = param_1[3] + -1 + iVar4;
    piVar1 = *(int **)(*(int *)(param_1[1] + (uVar3 >> 1 & param_1[2] - 1) * 4) + 4 +
                      (uVar3 & 1) * 8);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[1] + -1;
      piVar1[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar4 = piVar1[2] + -1;
        piVar1[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x10);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 6439 ; VA 0x00611560 ; FUN_00611560 */

void __fastcall FUN_00611560(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    (**(code **)**(undefined4 **)(param_1[1] + (iVar4 + param_1[3] + -1 & param_1[2] - 1) * 4))(0);
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x58);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 6440 ; VA 0x00611620 ; FUN_00611620 */

void __fastcall FUN_00611620(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar2 = (int *)*param_1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if ((iVar3 == 1) && (piVar2 != (int *)0x0)) {
      FUN_016dedfb(piVar2 + 7);
      iVar3 = piVar2[6];
      if (iVar3 != 0) {
        if (piVar2[3] != 0) {
          FUN_0061ad00(iVar3 + piVar2[2] * 4,0);
          iVar3 = piVar2[6];
        }
        if (iVar3 != iVar3 + (piVar2[2] + 1) * 4) {
          iVar3 = piVar2[6];
        }
        iVar1 = piVar2[2] * 4;
        uVar5 = iVar1 + 4;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = iVar1 + 0x27;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
        piVar2[6] = 0;
        piVar2[5] = 0;
      }
      FUN_01674ea0(piVar2,0x4c);
    }
  }
  return;
}



/* FUNCTION 6441 ; VA 0x006116d0 ; FUN_006116d0 */

void __fastcall FUN_006116d0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x18);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x20) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  return;
}



/* FUNCTION 6442 ; VA 0x00611730 ; FUN_00611730 */

void __fastcall FUN_00611730(undefined4 *param_1)

{
  FUN_00619470();
  FUN_01674ea0(*param_1,0x20);
  return;
}



/* FUNCTION 6443 ; VA 0x00611750 ; FUN_00611750 */

void __fastcall FUN_00611750(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  piVar3 = (int *)*param_1;
  piVar4 = (int *)*piVar3;
  *piVar3 = (int)piVar3;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar3 = (int *)*param_1;
  if (piVar4 != piVar3) {
    do {
      piVar3 = (int *)piVar4[8];
      piVar1 = (int *)*piVar4;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar3 = (int *)piVar4[3];
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x24);
      piVar3 = (int *)*param_1;
      piVar4 = piVar1;
    } while (piVar1 != piVar3);
  }
  FUN_01674ea0(piVar3,0x24);
  return;
}



/* FUNCTION 6444 ; VA 0x006117f0 ; FUN_006117f0 */

void __fastcall FUN_006117f0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00576640(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x2c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6445 ; VA 0x00611850 ; FUN_00611850 */

void __fastcall FUN_00611850(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00617290(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0xf8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6446 ; VA 0x006118c0 ; FUN_006118c0 */

void __fastcall FUN_006118c0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00613010();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,100);
  }
  return;
}



/* FUNCTION 6447 ; VA 0x006118f0 ; FUN_006118f0 */

void __fastcall FUN_006118f0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00605e10(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x2c);
  }
  return;
}



/* FUNCTION 6448 ; VA 0x00611920 ; FUN_00611920 */

void __fastcall FUN_00611920(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00605eb0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x24);
  }
  return;
}



/* FUNCTION 6449 ; VA 0x00611950 ; FUN_00611950 */

void __fastcall FUN_00611950(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00611ed0();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x30);
  }
  return;
}



/* FUNCTION 6450 ; VA 0x00611980 ; FUN_00611980 */

void __fastcall FUN_00611980(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00605f10(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x1c);
  }
  return;
}



/* FUNCTION 6451 ; VA 0x006119b0 ; FUN_006119b0 */

void __fastcall FUN_006119b0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 4) != 0) {
    if ((*(char *)(param_1 + 9) != '\0') &&
       (piVar1 = *(int **)(*(int *)(param_1 + 4) + 0x14), piVar1 != (int *)0x0)) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x18);
  }
  return;
}



/* FUNCTION 6452 ; VA 0x006119f0 ; FUN_006119f0 */

void __fastcall FUN_006119f0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00612010();
      piVar3 = *(int **)(iVar2 + 0x10);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x2c);
  }
  return;
}



/* FUNCTION 6453 ; VA 0x00611a50 ; FUN_00611a50 */

void __fastcall FUN_00611a50(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 4) != 0) {
    if ((*(char *)(param_1 + 9) != '\0') &&
       (piVar2 = *(int **)(*(int *)(param_1 + 4) + 0x10), piVar2 != (int *)0x0)) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x14);
  }
  return;
}



/* FUNCTION 6454 ; VA 0x00611aa0 ; FUN_00611aa0 */

void __fastcall FUN_00611aa0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_0056cd30();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0xc);
  }
  return;
}



/* FUNCTION 6455 ; VA 0x00611ad0 ; FUN_00611ad0 */

void __fastcall FUN_00611ad0(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0x14);
  }
  return;
}



/* FUNCTION 6456 ; VA 0x00611af0 ; FUN_00611af0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00611af0(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)param_1[1];
  uVar2 = DAT_01ead1f4;
  if (piVar4 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    if (*(char *)((int)param_1 + 9) != '\0') {
      ExceptionList = &pvStack_10;
      FUN_005cf430(*param_1,piVar4 + 2);
      piVar4 = (int *)param_1[1];
    }
    if (DAT_01ead26a == '\0') {
      DAT_01ead26a = '\x01';
      DAT_01ead1f4 = 0;
      uRam01ead1f8 = 0;
      DAT_01ead1fc = (int *)0x0;
      DAT_01ead200 = 0;
      _DAT_01ead214 = 0;
      DAT_01ead204 = _DAT_018ce380;
      _DAT_01ead208 = _UNK_018ce384;
      _DAT_01ead20c = _UNK_018ce388;
      _DAT_01ead210 = _UNK_018ce38c;
    }
    FUN_005874f0();
    *piVar4 = (int)DAT_01ead1fc;
    uStack_8 = 0;
    LOCK();
    uVar1 = DAT_01ead1f4 + 0x80000000;
    UNLOCK();
    uVar2 = uVar1;
    DAT_01ead1fc = piVar4;
    if (((DAT_01ead1f4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1f4)) {
      LOCK();
      DAT_01ead1f4 = uVar1 | 0x40000000;
      UNLOCK();
      uVar2 = DAT_01ead1f4;
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        SetEvent(uVar3);
        uVar2 = DAT_01ead1f4;
      }
    }
  }
  DAT_01ead1f4 = uVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6457 ; VA 0x00611bc0 ; FUN_00611bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00611bc0(int param_1)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 4);
  uVar3 = DAT_01ead21c;
  if (piVar1 != (int *)0x0) {
    if (DAT_01ead269 == '\0') {
      DAT_01ead269 = '\x01';
      DAT_01ead21c = 0;
      uRam01ead220 = 0;
      DAT_01ead224 = (int *)0x0;
      DAT_01ead228 = 0;
      _DAT_01ead23c = 0;
      DAT_01ead22c = _DAT_018ce370;
      _DAT_01ead230 = _UNK_018ce374;
      _DAT_01ead234 = _UNK_018ce378;
      _DAT_01ead238 = _UNK_018ce37c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    *piVar1 = (int)DAT_01ead224;
    uStack_8 = 0;
    LOCK();
    uVar2 = DAT_01ead21c + 0x80000000;
    UNLOCK();
    uVar3 = uVar2;
    DAT_01ead224 = piVar1;
    if (((DAT_01ead21c & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead21c)) {
      LOCK();
      DAT_01ead21c = uVar2 | 0x40000000;
      UNLOCK();
      uVar3 = DAT_01ead21c;
      if ((uVar2 >> 0x1e & 1) == 0) {
        uVar4 = FUN_00554e40();
        SetEvent(uVar4);
        uVar3 = DAT_01ead21c;
      }
    }
  }
  DAT_01ead21c = uVar3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6458 ; VA 0x00611c70 ; FUN_00611c70 */

void __fastcall FUN_00611c70(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  puVar1 = (undefined4 *)param_1[3];
  do {
    if (puVar1 == (undefined4 *)0x0) {
      iVar4 = param_1[1];
      if (iVar4 != 0) {
        if (*(char *)((int)param_1 + 9) != '\0') {
          FUN_005cf430(*param_1,iVar4 + 8);
          iVar4 = param_1[1];
        }
        FUN_01674ea0(iVar4,0x38);
      }
      return;
    }
    param_1[3] = *puVar1;
    uVar2 = puVar1[7];
    if (0xf < uVar2) {
      iVar4 = puVar1[2];
      uVar5 = uVar2 + 1;
      iVar3 = iVar4;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(iVar4 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    puVar1[6] = 0;
    puVar1[7] = 0xf;
    *(undefined *)(puVar1 + 2) = 0;
    FUN_01674ea0(puVar1,0x38);
    puVar1 = (undefined4 *)param_1[3];
  } while( true );
}



/* FUNCTION 6459 ; VA 0x00611d10 ; FUN_00611d10 */

void __fastcall FUN_00611d10(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_0056cd30();
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 6460 ; VA 0x00611d70 ; FUN_00611d70 */

void FUN_00611d70(void)

{
  FUN_00611ed0();
  return;
}



/* FUNCTION 6461 ; VA 0x00611d80 ; FUN_00611d80 */

void __fastcall FUN_00611d80(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = *(int *)(param_1 + 0x10);
  if (iVar5 != 0) {
    iVar6 = *(int *)(param_1 + 0x14);
    if (iVar5 != iVar6) {
      do {
        piVar2 = *(int **)(iVar5 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[1] + -1;
          piVar2[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar3 = piVar2[2] + -1;
            piVar2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        iVar5 = iVar5 + 8;
      } while (iVar5 != iVar6);
      iVar5 = *(int *)(param_1 + 0x10);
    }
    uVar4 = *(int *)(param_1 + 0x18) - iVar5 & 0xfffffff8;
    iVar6 = iVar5;
    if (0xfff < uVar4) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar4);
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  return;
}



/* FUNCTION 6462 ; VA 0x00611e50 ; FUN_00611e50 */

int __fastcall FUN_00611e50(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00612010();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00611e83. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 6463 ; VA 0x00611e90 ; FUN_00611e90 */

void __fastcall FUN_00611e90(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    uVar3 = param_1[3] + -1 + iVar4;
    piVar1 = *(int **)(*(int *)(param_1[1] + (uVar3 >> 1 & param_1[2] - 1) * 4) + 4 +
                      (uVar3 & 1) * 8);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[1] + -1;
      piVar1[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar4 = piVar1[2] + -1;
        piVar1[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x10);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 6464 ; VA 0x00611ea0 ; FUN_00611ea0 */

void __fastcall FUN_00611ea0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    (**(code **)**(undefined4 **)(param_1[1] + (iVar4 + param_1[3] + -1 & param_1[2] - 1) * 4))(0);
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x58);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 6465 ; VA 0x00611eb0 ; FUN_00611eb0 */

void __fastcall FUN_00611eb0(undefined4 *param_1)

{
  FUN_01674ea0(*param_1);
  return;
}



/* FUNCTION 6466 ; VA 0x00611ec0 ; thunk_FUN_016790b0 */

void __fastcall thunk_FUN_016790b0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016795b0();
  piVar3 = (int *)*param_1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iStack_8 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    iStack_8 = iStack_8 + -1;
    if (iStack_8 == 0) {
      if ((code *)piVar3[3] != (code *)0x0) {
        (*(code *)piVar3[3])(piVar3);
      }
      FUN_0056c630();
      piVar1 = piVar3 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(piVar3);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6467 ; VA 0x00611ed0 ; FUN_00611ed0 */

void __fastcall FUN_00611ed0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00613010();
        FUN_01674ea0(puVar6,100);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6468 ; VA 0x00611f60 ; FUN_00611f60 */

void __fastcall FUN_00611f60(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00605eb0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6469 ; VA 0x00612010 ; FUN_00612010 */

void __fastcall FUN_00612010(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_006120cd;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_006120cd:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6470 ; VA 0x006120e0 ; FUN_006120e0 */

void __fastcall FUN_006120e0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00611ed0();
        FUN_01674ea0(puVar6,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6471 ; VA 0x00612170 ; FUN_00612170 */

void __fastcall FUN_00612170(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00605f10(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x1c);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6472 ; VA 0x00612220 ; FUN_00612220 */

void __fastcall FUN_00612220(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_0061ad00(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6473 ; VA 0x006122a0 ; FUN_006122a0 */

void __fastcall FUN_006122a0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_0061ad50(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6474 ; VA 0x00612320 ; FUN_00612320 */

void __fastcall FUN_00612320(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x10);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6475 ; VA 0x006123a0 ; FUN_006123a0 */

void __fastcall FUN_006123a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[4];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar7,0x14);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6476 ; VA 0x00612460 ; FUN_00612460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00612460(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x14);
  if (iVar2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar2 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar2 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        uStack_8 = 0xffffffff;
        *puVar1 = *puVar6;
        if (DAT_01ead269 == '\0') {
          DAT_01ead269 = '\x01';
          DAT_01ead21c = 0;
          uRam01ead220 = 0;
          DAT_01ead224 = (undefined4 *)0x0;
          DAT_01ead228 = 0;
          DAT_01ead22c = 0;
          _DAT_01ead230 = 0x20;
          _DAT_01ead234 = 0x20;
          _DAT_01ead238 = 0x20;
          _DAT_01ead23c = 0;
        }
        FUN_005874f0();
        *puVar6 = DAT_01ead224;
        uStack_8 = 0;
        LOCK();
        uVar3 = DAT_01ead21c + 0x80000000;
        UNLOCK();
        uVar4 = uVar3;
        DAT_01ead224 = puVar6;
        if (((DAT_01ead21c & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead21c)) {
          LOCK();
          DAT_01ead21c = uVar3 | 0x40000000;
          UNLOCK();
          uVar4 = DAT_01ead21c;
          if ((uVar3 >> 0x1e & 1) == 0) {
            uVar5 = FUN_00554e40();
            SetEvent(uVar5);
            uVar4 = DAT_01ead21c;
          }
        }
        DAT_01ead21c = uVar4;
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
    }
    uStack_8 = 0xffffffff;
    FUN_0061bc00();
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6477 ; VA 0x00612580 ; FUN_00612580 */

void __fastcall FUN_00612580(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0061263d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x20);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_0061263d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6478 ; VA 0x00612650 ; FUN_00612650 */

void __fastcall FUN_00612650(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_0056cd30();
        FUN_01674ea0(puVar6,0xc);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6479 ; VA 0x006126e0 ; thunk_FUN_0061ac80 */

void __fastcall thunk_FUN_0061ac80(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x14);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6480 ; VA 0x006126f0 ; FUN_006126f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_006126f0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x14);
  if (iVar2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(iVar2 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar2 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        uStack_8 = 0xffffffff;
        *puVar1 = *puVar7;
        uVar3 = puVar7[7];
        if (0xf < uVar3) {
          iVar2 = puVar7[2];
          uVar6 = uVar3 + 1;
          iVar4 = iVar2;
          if (0xfff < uVar6) {
            iVar4 = *(int *)(iVar2 + -4);
            uVar6 = uVar3 + 0x24;
            if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar4,uVar6);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        if (DAT_01ead26a == '\0') {
          DAT_01ead26a = '\x01';
          DAT_01ead1f4 = 0;
          uRam01ead1f8 = 0;
          DAT_01ead1fc = (undefined4 *)0x0;
          DAT_01ead200 = 0;
          DAT_01ead204 = 0;
          _DAT_01ead208 = 0x24;
          _DAT_01ead20c = 0x20;
          _DAT_01ead210 = 0x20;
          _DAT_01ead214 = 0;
        }
        FUN_005874f0();
        *puVar7 = DAT_01ead1fc;
        uStack_8 = 0;
        LOCK();
        uVar3 = DAT_01ead1f4 + 0x80000000;
        UNLOCK();
        uVar6 = uVar3;
        DAT_01ead1fc = puVar7;
        if (((DAT_01ead1f4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1f4)) {
          LOCK();
          DAT_01ead1f4 = uVar3 | 0x40000000;
          UNLOCK();
          uVar6 = DAT_01ead1f4;
          if ((uVar3 >> 0x1e & 1) == 0) {
            uVar5 = FUN_00554e40();
            SetEvent(uVar5);
            uVar6 = DAT_01ead1f4;
          }
        }
        DAT_01ead1f4 = uVar6;
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    uStack_8 = 0xffffffff;
    FUN_0061bc00();
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6481 ; VA 0x00612860 ; thunk_FUN_00611300 */

void __fastcall thunk_FUN_00611300(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[4];
  if (iVar1 != 0) {
    do {
      iVar1 = iVar1 + -1;
      param_1[4] = iVar1;
    } while (iVar1 != 0);
    param_1[3] = 0;
  }
  iVar1 = param_1[2];
  while (iVar1 != 0) {
    iVar1 = iVar1 + -1;
    iVar2 = *(int *)(param_1[1] + iVar1 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x10);
    }
  }
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 6482 ; VA 0x00612870 ; FUN_00612870 */

void __fastcall FUN_00612870(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    FUN_00577ac0();
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x18);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 6483 ; VA 0x00612880 ; FUN_00612880 */

void FUN_00612880(void)

{
  FUN_00577ac0();
  return;
}



/* FUNCTION 6484 ; VA 0x00612890 ; FUN_00612890 */

void __fastcall FUN_00612890(int *param_1)

{
  if (*param_1 != 0) {
    FUN_00615040(*param_1);
  }
  return;
}



/* FUNCTION 6485 ; VA 0x006128a0 ; FUN_006128a0 */

void __fastcall FUN_006128a0(int *param_1)

{
  param_1 = (int *)*param_1;
  if (param_1 != (int *)0x0) {
    if (*param_1 != 0) {
      FUN_00615040(*param_1);
    }
    FUN_01674ea0(param_1,4);
  }
  return;
}



/* FUNCTION 6486 ; VA 0x006128d0 ; FUN_006128d0 */

void __fastcall FUN_006128d0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_006157e0(1);
  }
  return;
}



/* FUNCTION 6487 ; VA 0x006128e0 ; thunk_FUN_0061a9e0 */

void __fastcall thunk_FUN_0061a9e0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  
  iVar6 = *(int *)(param_1 + 0x14);
  if (iVar6 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar5 = *(undefined4 **)(iVar6 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar6 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar5;
        iVar6 = puVar5[6];
        if (iVar6 != 0) {
          iVar7 = puVar5[7];
          if (iVar6 != iVar7) {
            do {
              piVar2 = *(int **)(iVar6 + 4);
              if (piVar2 != (int *)0x0) {
                LOCK();
                iVar4 = piVar2[1] + -1;
                piVar2[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)*piVar2)();
                  LOCK();
                  iVar4 = piVar2[2] + -1;
                  piVar2[2] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar2 + 4))();
                  }
                }
              }
              iVar6 = iVar6 + 8;
            } while (iVar6 != iVar7);
            iVar6 = puVar5[6];
          }
          uVar3 = puVar5[8] - iVar6 & 0xfffffff8;
          iVar7 = iVar6;
          if (0xfff < uVar3) {
            iVar7 = *(int *)(iVar6 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar6 - iVar7) - 4U) goto LAB_0061ab35;
          }
          FUN_01674ea0(iVar7,uVar3);
          puVar5[6] = 0;
          puVar5[7] = 0;
          puVar5[8] = 0;
        }
        piVar2 = (int *)puVar5[5];
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar6 = piVar2[1] + -1;
          piVar2[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar6 = piVar2[2] + -1;
            piVar2[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar5,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar5 = (undefined4 *)*puVar1;
      } while (puVar5 != (undefined4 *)0x0);
    }
    iVar6 = *(int *)(param_1 + 4) * 4;
    uVar3 = iVar6 + 4;
    iVar7 = *(int *)(param_1 + 0x14);
    iVar4 = iVar7;
    if (0xfff < uVar3) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar3 = iVar6 + 0x27;
      if (0x1f < (iVar7 - iVar4) - 4U) {
LAB_0061ab35:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar3);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6488 ; VA 0x006128f0 ; FUN_006128f0 */

void __fastcall FUN_006128f0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_0061ad50(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6489 ; VA 0x00612900 ; thunk_FUN_0061ab40 */

void __fastcall thunk_FUN_0061ab40(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  
  iVar6 = *(int *)(param_1 + 0x14);
  if (iVar6 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar9 = *(undefined4 **)(iVar6 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar6 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar9;
        iVar6 = puVar9[10];
        if (iVar6 != 0) {
          if (puVar9[7] != 0) {
            puVar2 = (undefined4 *)(iVar6 + puVar9[6] * 4);
            puVar5 = (undefined4 *)*puVar2;
            do {
              *puVar2 = *puVar5;
              FUN_01674ea0(puVar5,0x10);
              puVar9[7] = puVar9[7] + -1;
              puVar5 = (undefined4 *)*puVar2;
            } while (puVar5 != (undefined4 *)0x0);
            iVar6 = puVar9[10];
          }
          uVar8 = puVar9[6] * 4 + 4;
          iVar7 = iVar6;
          if (0xfff < uVar8) {
            iVar7 = *(int *)(iVar6 + -4);
            uVar8 = puVar9[6] * 4 + 0x27;
            if (0x1f < (iVar6 - iVar7) - 4U) goto LAB_0061ac74;
          }
          FUN_01674ea0(iVar7,uVar8);
          puVar9[10] = 0;
          puVar9[9] = 0;
        }
        piVar3 = (int *)puVar9[4];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar6 = piVar3[1] + -1;
          piVar3[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar6 = piVar3[2] + -1;
            piVar3[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar9,0x2c);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar9 = (undefined4 *)*puVar1;
      } while (puVar9 != (undefined4 *)0x0);
    }
    iVar6 = *(int *)(param_1 + 4) * 4;
    uVar8 = iVar6 + 4;
    iVar7 = *(int *)(param_1 + 0x14);
    iVar4 = iVar7;
    if (0xfff < uVar8) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar8 = iVar6 + 0x27;
      if (0x1f < (iVar7 - iVar4) - 4U) {
LAB_0061ac74:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar8);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6490 ; VA 0x00612910 ; thunk_FUN_00612320 */

void __fastcall thunk_FUN_00612320(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x10);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6491 ; VA 0x00612920 ; FUN_00612920 */

void __fastcall FUN_00612920(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[4];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar7,0x14);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6492 ; VA 0x00612930 ; FUN_00612930 */

void __fastcall FUN_00612930(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00605eb0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6493 ; VA 0x00612940 ; FUN_00612940 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00612940(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x14);
  if (iVar2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar2 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar2 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        uStack_8 = 0xffffffff;
        *puVar1 = *puVar6;
        if (DAT_01ead269 == '\0') {
          DAT_01ead269 = '\x01';
          DAT_01ead21c = 0;
          uRam01ead220 = 0;
          DAT_01ead224 = (undefined4 *)0x0;
          DAT_01ead228 = 0;
          DAT_01ead22c = 0;
          _DAT_01ead230 = 0x20;
          _DAT_01ead234 = 0x20;
          _DAT_01ead238 = 0x20;
          _DAT_01ead23c = 0;
        }
        FUN_005874f0();
        *puVar6 = DAT_01ead224;
        uStack_8 = 0;
        LOCK();
        uVar3 = DAT_01ead21c + 0x80000000;
        UNLOCK();
        uVar4 = uVar3;
        DAT_01ead224 = puVar6;
        if (((DAT_01ead21c & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead21c)) {
          LOCK();
          DAT_01ead21c = uVar3 | 0x40000000;
          UNLOCK();
          uVar4 = DAT_01ead21c;
          if ((uVar3 >> 0x1e & 1) == 0) {
            uVar5 = FUN_00554e40();
            SetEvent(uVar5);
            uVar4 = DAT_01ead21c;
          }
        }
        DAT_01ead21c = uVar4;
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
    }
    uStack_8 = 0xffffffff;
    FUN_0061bc00();
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6494 ; VA 0x00612950 ; thunk_FUN_00612010 */

void __fastcall thunk_FUN_00612010(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_006120cd;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_006120cd:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6495 ; VA 0x00612960 ; FUN_00612960 */

void __fastcall FUN_00612960(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00611ed0();
        FUN_01674ea0(puVar6,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6496 ; VA 0x00612970 ; FUN_00612970 */

void __fastcall FUN_00612970(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00605f10(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x1c);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6497 ; VA 0x00612980 ; FUN_00612980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00612980(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x14);
  if (iVar2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(iVar2 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar2 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        uStack_8 = 0xffffffff;
        *puVar1 = *puVar7;
        uVar3 = puVar7[7];
        if (0xf < uVar3) {
          iVar2 = puVar7[2];
          uVar6 = uVar3 + 1;
          iVar4 = iVar2;
          if (0xfff < uVar6) {
            iVar4 = *(int *)(iVar2 + -4);
            uVar6 = uVar3 + 0x24;
            if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar4,uVar6);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        if (DAT_01ead26a == '\0') {
          DAT_01ead26a = '\x01';
          DAT_01ead1f4 = 0;
          uRam01ead1f8 = 0;
          DAT_01ead1fc = (undefined4 *)0x0;
          DAT_01ead200 = 0;
          DAT_01ead204 = 0;
          _DAT_01ead208 = 0x24;
          _DAT_01ead20c = 0x20;
          _DAT_01ead210 = 0x20;
          _DAT_01ead214 = 0;
        }
        FUN_005874f0();
        *puVar7 = DAT_01ead1fc;
        uStack_8 = 0;
        LOCK();
        uVar3 = DAT_01ead1f4 + 0x80000000;
        UNLOCK();
        uVar6 = uVar3;
        DAT_01ead1fc = puVar7;
        if (((DAT_01ead1f4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1f4)) {
          LOCK();
          DAT_01ead1f4 = uVar3 | 0x40000000;
          UNLOCK();
          uVar6 = DAT_01ead1f4;
          if ((uVar3 >> 0x1e & 1) == 0) {
            uVar5 = FUN_00554e40();
            SetEvent(uVar5);
            uVar6 = DAT_01ead1f4;
          }
        }
        DAT_01ead1f4 = uVar6;
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    uStack_8 = 0xffffffff;
    FUN_0061bc00();
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6498 ; VA 0x00612990 ; FUN_00612990 */

void __fastcall FUN_00612990(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0061263d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x20);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_0061263d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6499 ; VA 0x006129a0 ; FUN_006129a0 */

void __fastcall FUN_006129a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_0056cd30();
        FUN_01674ea0(puVar6,0xc);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}


