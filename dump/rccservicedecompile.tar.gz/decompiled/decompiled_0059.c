/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 14750 ; VA 0x008b6a00 ; FUN_008b6a00 */

void FUN_008b6a00(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da5d5c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<float,class_boost::_mfi::cmf0<float,class_RBX::World>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::World_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14751 ; VA 0x008b6a70 ; FUN_008b6a70 */

void FUN_008b6a70(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da5dd4);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<double,class_boost::_mfi::cmf0<double,class_RBX::RunService>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::RunService_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14752 ; VA 0x008b6ae0 ; FUN_008b6ae0 */

void FUN_008b6ae0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da5a44);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<double,class_boost::_mfi::cmf0<double,class_RBX::Workspace>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::Workspace_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14753 ; VA 0x008b6b50 ; FUN_008b6b50 */

void FUN_008b6b50(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return;
}



/* FUNCTION 14754 ; VA 0x008b6b80 ; FUN_008b6b80 */

void __thiscall FUN_008b6b80(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  FUN_00b66360(param_2);
  iVar1 = FUN_0170d75d(param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::IAdornable::RTTI_Type_Descriptor,0);
  if (iVar1 != 0) {
    FUN_0115aba0(iVar1);
  }
  if ((DAT_01d62d64 != '\0') && (param_2 != 0)) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_00c391f0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      piVar3 = (int *)(*(code *)**(undefined4 **)(param_2 + 0x70))();
      iVar1 = (**(code **)(*piVar3 + 0x10))();
      if (iVar1 - 1U < 4) {
        *(int *)(param_1 + 0x278) = *(int *)(param_1 + 0x278) + 1;
      }
    }
  }
  return;
}



/* FUNCTION 14755 ; VA 0x008b6c10 ; FUN_008b6c10 */

void __thiscall FUN_008b6c10(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  if (DAT_01d62d64 != '\0') {
    iVar4 = *param_2;
    if (iVar4 != 0) {
      iVar1 = *(int *)(iVar4 + 0xc);
      iVar2 = FUN_00c391f0();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        piVar3 = (int *)(*(code *)**(undefined4 **)(iVar4 + 0x70))();
        iVar4 = (**(code **)(*piVar3 + 0x10))();
        if (iVar4 - 1U < 4) {
          *(int *)(param_1 + 0x278) = *(int *)(param_1 + 0x278) + -1;
        }
      }
    }
  }
  iVar4 = FUN_0170d75d(*param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::IAdornable::RTTI_Type_Descriptor,0);
  if (iVar4 != 0) {
    FUN_0115abe0(iVar4);
  }
  FUN_00b66390(param_2);
  return;
}



/* FUNCTION 14756 ; VA 0x008b6cb0 ; FUN_008b6cb0 */

void __fastcall FUN_008b6cb0(int *param_1)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  uint3 uVar8;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [8];
  int iStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd860;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  uVar3 = FUN_01675290(DAT_01edfb30);
  iStack_8 = 0;
  uStack_24 = uVar3;
  FUN_00c3e740();
  FUN_008b95a0();
  if ((param_1[0x72] != 0) && (*(int **)(param_1[0x72] + 0x34) != param_1)) {
    FUN_008a5700(param_1);
  }
  iVar4 = FUN_008f7870(param_1);
  uVar8 = (uint3)((uint)param_1[0x6d] >> 8);
  if ((*(int *)(iVar4 + 0x4a0) == 2) || (*(int *)(iVar4 + 0x4a0) == 3)) {
    iVar4 = CONCAT31(uVar8,1);
  }
  else {
    iVar4 = (uint)uVar8 << 8;
  }
  FUN_00cdd100(iVar4);
  if (DAT_01d62d7c != '\0') {
    piStack_14 = (int *)param_1[0xd];
    piVar5 = param_1;
    if ((piStack_14 != (int *)0x0) && (piVar5 = piStack_14, piStack_14[0xd] != 0)) {
      piVar5 = (int *)FUN_005c8ac0();
    }
    piStack_14 = piVar5;
    if ((piStack_14 != (int *)0x0) &&
       (iVar4 = piStack_14[3], iVar6 = FUN_008a8c30(), param_1 = piStack_18,
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
       (uint)*(ushort *)(iVar6 + 0x1da))) {
      FUN_005789c0();
      uVar7 = FUN_00635450();
      piStack_14 = (int *)FUN_008aa140(uVar7);
      if (*piStack_14 == 0) {
        FUN_00b7a190();
        piVar5 = (int *)FUN_008a9ba0();
        iVar4 = *piVar5;
        iVar6 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piStack_14 = iVar4;
        piVar5 = (int *)piStack_14[1];
        piStack_14[1] = iVar6;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar4 = piVar5[1] + -1;
          piVar5[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar4 = piVar5[2] + -1;
            piVar5[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        piVar5 = piStack_30;
        if (piStack_30 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_30[1] + -1;
          piStack_30[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_30)();
            LOCK();
            piVar1 = piVar5 + 2;
            iVar4 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
      }
      param_1 = piStack_18;
      if (*piStack_14 != 0) {
        uVar7 = FUN_00b82b00();
        iVar4 = FUN_00ed3bf0(uVar7);
        param_1 = piStack_18;
        if ((iVar4 != -1) && (iVar4 = FUN_008acdd0(piStack_18), iVar4 != 0)) {
          piStack_30 = *(int **)(iVar4 + 0x6c);
          if (piStack_30 != (int *)0x0) {
            LOCK();
            piStack_30[1] = piStack_30[1] + 1;
            UNLOCK();
            piStack_30 = *(int **)(iVar4 + 0x6c);
          }
          iStack_34 = *(int *)(iVar4 + 0x68);
          iStack_8._0_1_ = 1;
          if (iStack_34 != 0) {
            FUN_00d814c0(&uStack_2c);
            if (param_1[0x98] != 0) {
              uStack_4c = 0;
              FUN_00d81ed0(CONCAT44(uStack_28,uStack_2c),0);
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_00550b30();
              goto LAB_008b6f81;
            }
            piStack_14 = (int *)FUN_008f7870(param_1);
            uStack_54 = uStack_2c;
            uStack_48 = 0;
            uStack_44 = 0;
            uStack_40 = 0;
            uStack_50 = uStack_28;
            uStack_4c = 0;
            uStack_1c = 1;
            uStack_20 = 5;
            uVar7 = FUN_008ac260(auStack_3c,&uStack_20,&uStack_1c,&uStack_54,&uStack_48,&piStack_14)
            ;
            FUN_005587e0(uVar7);
            FUN_00550b30();
          }
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_00550b30();
        }
      }
    }
  }
LAB_008b6f81:
  if ((int *)param_1[0x94] != (int *)0x0) {
    if ((param_1[0x98] != 0) && (*(int *)(param_1[0x98] + 0x54) == 5)) {
      (**(code **)(*(int *)param_1[0x94] + 0x2c))(param_1 + 0x98);
      cVar2 = FUN_0097c970();
      if ((cVar2 != '\0') && (iVar4 = FUN_0097bfc0(param_1), iVar4 != 0)) {
        FUN_008b3a10(&iStack_34);
        iStack_8._0_1_ = 2;
        if (iStack_34 != 0) {
          FUN_006eccd0();
        }
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_00550b30();
      }
      FUN_00eb65e0(auStack_3c);
      iStack_8._0_1_ = 3;
      uVar7 = FUN_008f7870();
      iVar4 = FUN_00eb6280(uVar7);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_00550b30();
      if ((iVar4 != 0) && (*(int *)(iVar4 + 0x70) != 0)) {
        FUN_006eccd0();
      }
    }
  }
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14757 ; VA 0x008b7060 ; FUN_008b7060 */

undefined4 __thiscall FUN_008b7060(undefined4 param_1,undefined4 param_2)

{
  FUN_008ad1c0(param_2,param_1);
  return param_2;
}



/* FUNCTION 14758 ; VA 0x008b7080 ; FUN_008b7080 */

void __thiscall FUN_008b7080(int *param_1,undefined4 *param_2)

{
  (**(code **)(*param_1 + 0x60))();
  *param_2 = 0;
  param_2[1] = 0;
  return;
}



/* FUNCTION 14759 ; VA 0x008b70a0 ; FUN_008b70a0 */

void FUN_008b70a0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  return;
}



/* FUNCTION 14760 ; VA 0x008b70c0 ; FUN_008b70c0 */

void __thiscall FUN_008b70c0(int param_1,int *param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uStack_40;
  undefined4 uStack_30;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd899;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    FUN_01679490();
    if (*(int *)(param_1 + 0x240) != 0) {
      FUN_008a65e0(0,0);
      *(undefined4 *)(param_1 + 0x240) = 0;
      piStack_18 = *(int **)(param_1 + 0x244);
      *(undefined4 *)(param_1 + 0x244) = 0;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_18[1] + -1;
        piStack_18[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          iVar6 = piStack_18[2] + -1;
          piStack_18[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    iVar6 = *(int *)(param_1 + 800);
    if (iVar6 != 0) {
      piVar4 = *(int **)(param_1 + 0x324);
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
        iVar6 = *(int *)(param_1 + 800);
        piVar4 = *(int **)(param_1 + 0x324);
      }
      uStack_8 = 0;
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
      }
      iStack_28 = iVar6;
      piStack_24 = piVar4;
      FUN_0151dac0(iVar6,piVar4,0,0);
      uStack_8 = 0xffffffff;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar6 = piVar4[1] + -1;
        piVar4[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar6 = piVar4[2] + -1;
          piVar4[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      *(undefined4 *)(param_1 + 800) = 0;
      piVar4 = *(int **)(param_1 + 0x324);
      *(undefined4 *)(param_1 + 0x324) = 0;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar6 = piVar4[1] + -1;
        piVar4[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar6 = piVar4[2] + -1;
          piVar4[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
    }
  }
  iVar6 = param_3;
  FUN_008a4210(param_2,param_3);
  if (iVar6 != 0) {
    iStack_20 = FUN_005f5170();
    iStack_14 = iStack_20 + 0xd4;
    iStack_28 = 0;
    uStack_8 = 1;
    piVar4 = (int *)FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 2;
    piStack_24 = piVar4;
    piStack_18 = (int *)FUN_01674e20(0x30);
    if (piStack_18 == (undefined4 *)0x0) {
      piStack_18 = (undefined4 *)0x0;
    }
    else {
      *piStack_18 = 0;
      piStack_18[1] = 1;
      piStack_18[2] = (int)FUN_008b2320;
      piStack_18[3] = (int)_guard_check_icall;
      piStack_18[4] = 0;
      piStack_18[6] = (int)FUN_008b6cb0;
      piStack_18[7] = 0;
      piStack_18[8] = 0;
      piStack_18[9] = uStack_30;
      piStack_18[5] = iStack_14;
      *(ulonglong *)(piStack_18 + 10) = CONCAT44(uStack_40,param_1);
    }
    FUN_016797d0(piStack_18);
    param_2 = piStack_18;
    if (piStack_18 != (undefined4 *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    uStack_1c = 1;
    uStack_8._0_1_ = 3;
    FUN_01675290(piVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    cVar3 = FUN_01679300(&param_2);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_2);
    }
    uStack_8 = 0xffffffff;
    if (param_2 != (undefined4 *)0x0) {
      piVar4 = param_2 + 1;
      LOCK();
      iVar6 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        FUN_01674ea0(param_2);
      }
    }
    param_3 = FUN_006fb410();
    if (param_3 != 0) {
      puVar5 = (undefined4 *)
               FUN_008b0870(&iStack_28,param_1,*(undefined4 *)(param_1 + 0x1b4),iStack_20);
      uVar1 = *puVar5;
      uVar2 = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      *(undefined4 *)(param_1 + 0x240) = uVar1;
      param_2 = *(int **)(param_1 + 0x244);
      *(undefined4 *)(param_1 + 0x244) = uVar2;
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar6 = param_2[1] + -1;
        param_2[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*param_2)();
          LOCK();
          iVar6 = param_2[2] + -1;
          param_2[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      param_2 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_24[1] + -1;
        piStack_24[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar4 = param_2 + 2;
          iVar6 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      FUN_008a65e0(param_3,0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14761 ; VA 0x008b7430 ; FUN_008b7430 */

float10 __fastcall FUN_008b7430(int param_1)

{
  undefined4 *puVar1;
  float *pfVar2;
  float fVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  uint uVar9;
  int iVar10;
  float10 fVar11;
  undefined8 uVar12;
  int *piStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  int iStack_34;
  undefined auStack_30 [4];
  int iStack_2c;
  float fStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd8d0;
  pvStack_10 = ExceptionList;
  fStack_28 = (float)(**(int **)(param_1 + 0x334) - (int)*(int **)(param_1 + 0x334));
  pfVar2 = (float *)(*(int *)(param_1 + 0x1b4) + 0xc4);
  ExceptionList = &pvStack_10;
  iStack_34 = param_1;
  if ((NAN(fStack_28) || NAN(*pfVar2)) == (fStack_28 == *pfVar2)) {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_008f7870();
    piStack_14 = (int *)0x80;
    uStack_3c = CONCAT44(iVar4 + 0x1e0,(undefined4)uStack_3c);
    iVar4 = FUN_016dee6d(iVar4 + 0x1e0);
    if (iVar4 != 0) {
      FUN_016df3c9();
    }
    uStack_8 = 0;
    FUN_00687eb0(auStack_30,&piStack_14,&piStack_14);
    DAT_01ee04b4 = DAT_01ee04b4 | (uint)piStack_14;
    uStack_8 = 1;
    iVar4 = FUN_016deec8();
    if (iVar4 != 0) {
      FUN_016df3c9();
    }
  }
  uStack_8 = 0xffffffff;
  FUN_008bc530();
  FUN_008f7870();
  FUN_00cdd100();
  if (DAT_01d69150 != '\0') {
    FUN_008f7870();
    iVar4 = FUN_0097bfc0();
    uStack_3c = 0;
    if (iVar4 == 0) {
      uVar12 = 0;
    }
    else {
      uVar12 = FUN_00928340();
    }
    FUN_00bc0d40(uVar12);
  }
  fVar11 = (float10)FUN_00bc0df0(1,*(undefined8 *)(param_1 + 0x2e0));
  uVar9 = 0;
  iVar4 = *(int *)(param_1 + 0x20c) * 4;
  uStack_3c = CONCAT44((float)fVar11,(undefined4)uStack_3c);
  fStack_28 = (float)(iVar4 + 3U >> 2);
  if (iVar4 + *(uint *)(param_1 + 0x208) < *(uint *)(param_1 + 0x208)) {
    fStack_28 = 0.0;
  }
  if (fStack_28 != 0.0) {
    do {
      FUN_00ea90a0(*(undefined8 *)(param_1 + 0x2e0));
      uVar9 = uVar9 + 1;
    } while ((float)uVar9 != fStack_28);
  }
  if ((DAT_01d67cb0 == '\0') && (FUN_00bbe770(), DAT_01d69070 != '\0')) {
    FUN_00f27860();
    FUN_00ce86a0();
  }
  piStack_48 = (int *)0x0;
  uStack_44 = 0;
  iStack_40 = 0;
  iStack_2c = *(int *)(param_1 + 0x1b4);
  uStack_8 = 2;
  iVar4 = *(int *)(iStack_2c + 0x30);
  iStack_1c = iVar4;
  FUN_008aad40(iVar4,&piStack_48);
  if (0 < iVar4) {
    iVar10 = 0;
    piStack_20 = (int *)0x0;
    fStack_28 = (float)iVar4;
    do {
      piVar8 = piStack_20;
      iVar4 = *(int *)(iStack_2c + 0x2c);
      piStack_14 = piStack_48;
      iVar6 = *(int *)((int)piStack_20 + iVar4 + 0xc);
      if (iVar6 != 0) {
        LOCK();
        *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
        UNLOCK();
        iVar6 = *(int *)((int)piStack_20 + iVar4 + 0xc);
      }
      *(undefined4 *)((int)piStack_48 + iVar10) = *(undefined4 *)((int)piStack_20 + iVar4 + 8);
      piVar7 = *(int **)((int)piStack_48 + iVar10 + 4);
      *(int *)((int)piStack_48 + iVar10 + 4) = iVar6;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar6 = piVar7[1] + -1;
        piVar7[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar6 = piVar7[2] + -1;
          piVar7[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      iVar6 = *(int *)((int)piVar8 + iVar4 + 0x14);
      if (iVar6 != 0) {
        LOCK();
        *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
        UNLOCK();
        iVar6 = *(int *)((int)piVar8 + iVar4 + 0x14);
      }
      *(undefined4 *)((int)piStack_14 + iVar10 + 8) = *(undefined4 *)((int)piVar8 + iVar4 + 0x10);
      piVar7 = *(int **)((int)piStack_14 + iVar10 + 0xc);
      *(int *)((int)piStack_14 + iVar10 + 0xc) = iVar6;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar6 = piVar7[1] + -1;
        piVar7[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar6 = piVar7[2] + -1;
          piVar7[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      *(uint *)((int)piStack_14 + iVar10 + 0x10) = (uint)(*(int *)((int)piVar8 + iVar4 + 0x18) != 0)
      ;
      iVar10 = iVar10 + 0x18;
      piStack_20 = piStack_20 + 7;
      fStack_28 = (float)((int)fStack_28 + -1);
    } while (fStack_28 != 0.0);
    fStack_28 = 0.0;
    param_1 = iStack_34;
    iVar4 = iStack_1c;
  }
  FUN_008b9880(0,0);
  FUN_008b45f0();
  if (0 < iVar4) {
    iStack_34 = param_1 + 0x338;
    fStack_28 = 0.0;
    do {
      fVar3 = fStack_28;
      piVar8 = piStack_48;
      puVar1 = (undefined4 *)((int)piStack_48 + (int)fStack_28 + 8U);
      if (*(int *)((int)piStack_48 + (int)fStack_28 + 0x10U) == 0) {
        FUN_00b0c3d0();
        iVar4 = FUN_008a40f0();
        if (iVar4 != 0) {
          FUN_008a4100();
          piVar7 = *(int **)((int)piVar8 + (int)fVar3 + 0xcU);
          if (piVar7 != (int *)0x0) {
            LOCK();
            piVar7[1] = piVar7[1] + 1;
            UNLOCK();
            piVar7 = *(int **)((int)piVar8 + (int)fVar3 + 0xcU);
          }
          uVar5 = *puVar1;
          uStack_8._0_1_ = 3;
          uStack_24 = uVar5;
          piStack_20 = piVar7;
LAB_008b77c8:
          piVar8 = piVar7 + 1;
          if (piVar7 != (int *)0x0) {
            LOCK();
            *piVar8 = *piVar8 + 1;
            UNLOCK();
          }
          FUN_0089be10(uVar5,piVar7);
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar4 = *piVar8;
            *piVar8 = iVar4 + -1;
            UNLOCK();
            if (iVar4 + -1 == 0) {
              (**(code **)*piVar7)();
              LOCK();
              iVar4 = piVar7[2] + -1;
              piVar7[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
        }
      }
      else {
        FUN_00b0c4d0();
        iVar4 = FUN_008a40f0();
        if (iVar4 != 0) {
          FUN_008a4100();
          piVar7 = *(int **)((int)piVar8 + (int)fVar3 + 0xcU);
          if (piVar7 != (int *)0x0) {
            LOCK();
            piVar7[1] = piVar7[1] + 1;
            UNLOCK();
            piVar7 = *(int **)((int)piVar8 + (int)fVar3 + 0xcU);
          }
          uVar5 = *puVar1;
          uStack_8._0_1_ = 4;
          uStack_18 = uVar5;
          piStack_14 = piVar7;
          goto LAB_008b77c8;
        }
      }
      FUN_005e6780();
      fStack_28 = (float)((int)fStack_28 + 0x18);
      iStack_1c = iStack_1c + -1;
    } while (iStack_1c != 0);
  }
  if (piStack_48 != (int *)0x0) {
    FUN_00602f40(piStack_48,uStack_44,&piStack_48);
    uVar9 = ((iStack_40 - (int)piStack_48) / 0x18) * 0x18;
    piVar8 = piStack_48;
    if (0xfff < uVar9) {
      piVar8 = (int *)piStack_48[-1];
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uint)((int)piStack_48 + (-4 - (int)piVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar8,uVar9);
  }
  ExceptionList = pvStack_10;
  return (float10)uStack_3c._4_4_;
}



/* FUNCTION 14762 ; VA 0x008b78b0 ; FUN_008b78b0 */

undefined4 * __thiscall FUN_008b78b0(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  undefined3 uVar3;
  int iVar4;
  int iVar5;
  code *pcVar6;
  uint uStack_84;
  int *piStack_80;
  int **ppiStack_7c;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  uint uStack_64;
  int *piStack_60;
  int iStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  int iStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int iStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd920;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (DAT_01ee4205 != 0) {
    ppiStack_7c = *(int ***)(*param_3 + 0x54);
    uStack_84 = (uint)DAT_01ee4205;
    piStack_80 = (int *)0x191fc10;
    ExceptionList = &pvStack_10;
    FUN_016774b0();
  }
  if (param_1 == 0) {
LAB_008b7939:
    param_1 = 0;
  }
  else {
    iVar5 = *(int *)(param_1 + 0x34);
    if ((iVar5 != 0) && (param_1 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      ppiStack_7c = (int **)0x8b790c;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 == 0) goto LAB_008b7939;
    iVar5 = *(int *)(param_1 + 0xc);
    ppiStack_7c = (int **)0x8b791e;
    iVar4 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) goto LAB_008b7939;
  }
  ppiStack_7c = &piStack_3c;
  piStack_80 = (int *)0x8b7944;
  FUN_00eb65e0();
  uStack_8 = 0;
  ppiStack_7c = (int **)(-(uint)(param_1 != 0) & param_1 - 0xcU);
  piStack_80 = (int *)0x8b795f;
  piStack_18 = (int *)FUN_00eb6280();
  piVar2 = piStack_38;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_38[1] + -1;
    piStack_38[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      ppiStack_7c = (int **)0x8b797b;
      (**(code **)*piStack_38)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_7c = (int **)0x8b798b;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iStack_34 = 0;
  uStack_30 = 0;
  piStack_2c = (int *)0x0;
  piStack_28 = (int *)0x0;
  uStack_8._1_3_ = 0;
  uVar3 = uStack_8._1_3_;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  if (piStack_18 != (int *)0x0) {
    uStack_84 = *(uint *)((int)piStack_18 + 0x70);
    if (param_3[1] != 0) {
      LOCK();
      piVar2 = (int *)(param_3[1] + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    piStack_80 = (int *)*param_3;
    ppiStack_7c = (int **)param_3[1];
    FUN_008ab6d0(&uStack_70,&LAB_008af4eb,0);
    uStack_8._0_1_ = 3;
    piStack_3c = (int *)0x0;
    uStack_84 = uStack_64;
    piStack_80 = piStack_60;
    piStack_38 = (int *)0x0;
    uStack_64 = 0;
    piStack_60 = (int *)0x0;
    FUN_008ab5e0(0,uStack_70,uStack_6c,uStack_68);
    piVar2 = piStack_60;
    uStack_8._0_1_ = 2;
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_60[1] + -1;
      piStack_60[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_7c = (int **)0x8b7a6a;
        (**(code **)*piStack_60)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_7c = (int **)0x8b7a7a;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piStack_2c = piStack_3c;
    piStack_28 = piStack_38;
    uVar3 = uStack_8._1_3_;
  }
  uStack_8._1_3_ = uVar3;
  piVar2 = piStack_28;
  ppiStack_7c = (int **)param_3;
  piStack_80 = &iStack_58;
  uStack_84 = 0x8b7a95;
  FUN_008b4e80();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (iStack_58 == 1) {
    param_2[1] = uStack_54;
    param_2[2] = uStack_50;
    *param_2 = 1;
    param_2[3] = uStack_4c;
    param_2[4] = piStack_48;
    uStack_4c = 0;
    piStack_48 = (int *)0x0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[1] + -1;
      piVar2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_7c = (int **)0x8b7ae1;
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          ppiStack_7c = (int **)0x8b7af0;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  piStack_38 = *(int **)(iStack_14 + 0x254);
  if (piStack_38 != (int *)0x0) {
    LOCK();
    piStack_38[1] = piStack_38[1] + 1;
    UNLOCK();
    piStack_38 = *(int **)(iStack_14 + 0x254);
  }
  piVar2 = *(int **)(iStack_14 + 0x250);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  ppiStack_7c = (int **)*param_3;
  piStack_3c = piVar2;
  piStack_18 = piStack_38;
  if (*(uint *)((int)ppiStack_7c + 0x54) < 5) {
    piStack_80 = &iStack_44;
    uStack_84 = 0x8b7b49;
    ppiStack_7c = (int **)FUN_008ac190();
    iStack_20 = iStack_14 + 0x260;
    piStack_80 = (int *)0x8b7b5e;
    FUN_005587e0();
    piStack_1c = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_40[1] + -1;
      piStack_40[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_7c = (int **)0x8b7b75;
        (**(code **)*piStack_40)();
        LOCK();
        iVar5 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_7c = (int **)0x8b7b86;
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    ppiStack_7c = (int **)0x5;
    piStack_80 = (int *)0x8b7b92;
    FUN_00d81e80();
    ppiStack_7c = (int **)*param_3;
  }
  switch(*(undefined4 *)((int)ppiStack_7c + 0x54)) {
  case 0:
    if (*(int *)((int)ppiStack_7c + 0x5c) == 0) {
      *(undefined *)(iStack_14 + 0x272) = 1;
      if (*(char *)(piVar2 + 9) == '\0') {
        if (DAT_01ee4205 != 0) {
          uStack_84 = (uint)DAT_01ee4205;
          piStack_80 = (int *)0x191fcc0;
          ppiStack_7c = (int **)piVar2;
          FUN_016774b0();
        }
        ppiStack_7c = (int **)param_3;
        piStack_80 = &iStack_24;
        uStack_84 = 0x8b7dd9;
        (**(code **)(*piVar2 + 0x24))();
        uStack_8._0_1_ = 6;
        if ((iStack_24 != 0) && (*(int *)(*param_3 + 0x58) == 7)) {
          ppiStack_7c = (int **)&iStack_44;
          piStack_80 = (int *)0x8b7dfc;
          ppiStack_7c = (int **)FUN_00f2afe0();
          piStack_80 = (int *)0x8b7e05;
          FUN_005587e0();
          ppiStack_7c = (int **)0x8b7e0d;
          FUN_00550b30();
        }
LAB_008b7e6a:
        ppiStack_7c = (int **)0x0;
        FUN_00557fc0(&iStack_24);
        FUN_008bac40();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        ppiStack_7c = (int **)0x8b7e8e;
        FUN_00550b30();
      }
    }
    else if (*(int *)((int)ppiStack_7c + 0x5c) == 2) {
      if (DAT_01ee41ed != 0) {
        uStack_84 = (uint)DAT_01ee41ed;
        piStack_80 = (int *)0x191fce0;
        ppiStack_7c = (int **)piVar2;
        FUN_016774b0();
      }
      *(undefined *)(iStack_14 + 0x272) = 0;
      if (DAT_01ee4205 != 0) {
        uStack_84 = (uint)DAT_01ee4205;
        piStack_80 = (int *)0x191fd0c;
        ppiStack_7c = (int **)piVar2;
        FUN_016774b0();
      }
      ppiStack_7c = (int **)param_3;
      piStack_80 = &iStack_24;
      uStack_84 = 0x8b7e66;
      (**(code **)(*piVar2 + 0x4c))();
      uStack_8._0_1_ = 7;
      goto LAB_008b7e6a;
    }
    break;
  case 1:
    if (*(int *)((int)ppiStack_7c + 0x5c) == 0) {
      ppiStack_7c = (int **)0x8b7ccb;
      iVar5 = (**(code **)(*(int *)(iStack_14 + 0x144) + 8))();
      if (*(int *)(iVar5 + 0x1ac) != 6) {
        ppiStack_7c = (int **)iStack_14;
        *(undefined *)(iStack_14 + 0x271) = 1;
        piStack_80 = (int *)0x8b7ce4;
        iVar5 = FUN_008acdd0();
        if (iVar5 != 0) {
          *(undefined4 *)(iVar5 + 0x5c) = 1;
        }
      }
      if (*(char *)(piVar2 + 9) == '\0') {
        pcVar6 = *(code **)(*piVar2 + 0x28);
        goto LAB_008b7c0c;
      }
    }
    else if (*(int *)((int)ppiStack_7c + 0x5c) == 2) {
      if (DAT_01ee41ed != 0) {
        ppiStack_7c = (int **)0x0;
        uStack_84 = (uint)DAT_01ee41ed;
        piStack_80 = (int *)0x191fc60;
        FUN_016774b0();
      }
      ppiStack_7c = (int **)0x8b7d34;
      FUN_008b0040();
      ppiStack_7c = (int **)0x8b7d44;
      iStack_20 = (**(code **)(*(int *)(iStack_14 + 0x144) + 4))();
      if (iStack_20 != 0) {
        if (DAT_01ee41ed != 0) {
          ppiStack_7c = (int **)0x0;
          uStack_84 = (uint)DAT_01ee41ed;
          piStack_80 = (int *)0x191fc7c;
          FUN_016774b0();
        }
        ppiStack_7c = (int **)0x8b7d72;
        FUN_00d24300();
      }
      if (DAT_01ee41ed != 0) {
        uStack_84 = (uint)DAT_01ee41ed;
        piStack_80 = (int *)0x191fc94;
        ppiStack_7c = (int **)piVar2;
        FUN_016774b0();
      }
      pcVar6 = *(code **)(*piVar2 + 0x50);
      goto LAB_008b7c0c;
    }
    break;
  default:
    if (DAT_01ee4205 != 0) {
      ppiStack_7c = (int **)0x0;
      uStack_84 = (uint)DAT_01ee4205;
      piStack_80 = (int *)0x191fc34;
      FUN_016774b0();
    }
    piVar2 = piStack_18;
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_18[1] + -1;
      piStack_18[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_7c = (int **)0x8b804a;
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_7c = (int **)0x8b805a;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_48[2] + -1;
      piStack_48[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_7c = (int **)0x8b806f;
        (**(code **)(*piStack_48 + 4))();
      }
    }
    piVar2 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_28[1] + -1;
      piStack_28[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_7c = (int **)0x8b8085;
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          ppiStack_7c = (int **)0x8b8094;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  case 3:
    if (*(float *)((int)ppiStack_7c + 0x68) <= 0.0) {
      if (*(float *)((int)ppiStack_7c + 0x68) < 0.0) {
        ppiStack_7c = (int **)param_3;
        piStack_80 = &iStack_44;
        uStack_84 = 0x8b7eca;
        (**(code **)(*piVar2 + 0x58))();
        ppiStack_7c = (int **)0x8b7ed2;
        FUN_00550b30();
      }
    }
    else {
      ppiStack_7c = (int **)param_3;
      piStack_80 = &iStack_44;
      uStack_84 = 0x8b7eaf;
      (**(code **)(*piVar2 + 0x54))();
      ppiStack_7c = (int **)0x8b7eb7;
      FUN_00550b30();
    }
    break;
  case 4:
    if (*(char *)(piVar2 + 9) == '\0') {
      if (DAT_01ee41ed != 0) {
        uStack_84 = (uint)DAT_01ee41ed;
        piStack_80 = (int *)0x191fd58;
        ppiStack_7c = (int **)piVar2;
        FUN_016774b0();
      }
      ppiStack_7c = (int **)param_3;
      piStack_80 = (int *)0x8b7f21;
      (**(code **)(*piVar2 + 0x30))();
    }
    else {
      if (DAT_01ee41ed != 0) {
        uStack_84 = (uint)DAT_01ee41ed;
        piStack_80 = (int *)0x191fd28;
        ppiStack_7c = (int **)piVar2;
        FUN_016774b0();
      }
      ppiStack_7c = (int **)param_3;
      piStack_80 = (int *)0x8b7eff;
      (**(code **)(*piVar2 + 0x44))();
    }
    break;
  case 6:
    if (*(char *)(piVar2 + 9) != '\0') {
      ppiStack_7c = (int **)param_3;
      piStack_80 = (int *)0x8b7f34;
      (**(code **)(*piVar2 + 0x48))();
    }
    break;
  case 8:
    if (*(int *)((int)ppiStack_7c + 0x5c) == 2) {
      if (DAT_01ee4205 != 0) {
        ppiStack_7c = (int **)0x0;
        uStack_84 = (uint)DAT_01ee4205;
        piStack_80 = (int *)0x191fc50;
        FUN_016774b0();
      }
      ppiStack_7c = (int **)param_3;
      piStack_80 = &iStack_44;
      uStack_84 = 0x8b7c9b;
      (**(code **)(*piVar2 + 0x40))();
      ppiStack_7c = (int **)0x8b7ca3;
      FUN_00550b30();
      if (*(char *)(piVar2 + 9) == '\0') {
LAB_008b7c28:
        ppiStack_7c = (int **)param_2;
        piStack_80 = (undefined4 *)0x8b7c31;
        FUN_008b6b50();
        ppiStack_7c = (int **)0x8b7c3c;
        FUN_00550b30();
        ppiStack_7c = (int **)0x8b7c44;
        FUN_008ae7d0();
        goto LAB_008b7c44;
      }
      pcVar6 = *(code **)(*piVar2 + 0x38);
    }
    else {
      if (*(int *)((int)ppiStack_7c + 0x5c) == 4) break;
      if (DAT_01ee4205 != 0) {
        ppiStack_7c = (int **)0x0;
        uStack_84 = (uint)DAT_01ee4205;
        piStack_80 = (int *)0x191fc50;
        FUN_016774b0();
      }
      ppiStack_7c = (int **)param_3;
      piStack_80 = &iStack_44;
      uStack_84 = 0x8b7bf9;
      (**(code **)(*piVar2 + 0x3c))();
      ppiStack_7c = (int **)0x8b7c01;
      FUN_00550b30();
      if (*(char *)(piVar2 + 9) == '\0') goto LAB_008b7c28;
      pcVar6 = *(code **)(*piVar2 + 0x34);
    }
LAB_008b7c0c:
    ppiStack_7c = (int **)0x0;
    (*pcVar6)(&uStack_84,param_3);
    FUN_008bac40();
    break;
  case 9:
    ppiStack_7c = (int **)0x8b7bb5;
    FUN_008b0040();
  }
  if (DAT_01ee41ed != 0) {
    ppiStack_7c = (int **)0x0;
    uStack_84 = (uint)DAT_01ee41ed;
    piStack_80 = (int *)0x191fd88;
    FUN_016774b0();
  }
  if (DAT_01ee4205 != 0) {
    ppiStack_7c = (int **)(uint)*(byte *)(piVar2 + 9);
    uStack_84 = (uint)DAT_01ee4205;
    piStack_80 = (int *)0x191fda4;
    FUN_016774b0();
  }
  if (*(char *)(piVar2 + 9) == '\0') {
    if (iStack_34 != 0) {
      ppiStack_7c = (int **)iStack_34;
      piStack_80 = param_2;
      uStack_84 = 0x8b7fbc;
      FUN_008bc460();
      ppiStack_7c = (int **)0x8b7fc7;
      FUN_00550b30();
      if (piStack_48 != (int *)0x0) {
        LOCK();
        piVar2 = piStack_48 + 2;
        iVar5 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          ppiStack_7c = (int **)0x8b7fe3;
          (**(code **)(*piStack_48 + 4))();
        }
      }
      goto LAB_008b7c44;
    }
    ppiStack_7c = (int **)param_2;
    piStack_80 = (undefined4 *)0x8b7fee;
    FUN_008b6b50();
  }
  else {
    ppiStack_7c = (int **)iStack_14;
    piStack_80 = param_2;
    uStack_84 = 0x8b7f82;
    FUN_008bc460();
  }
  ppiStack_7c = (int **)0x8b7f8d;
  FUN_00550b30();
  if (piStack_48 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_48 + 2;
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      ppiStack_7c = (int **)0x8b7fa9;
      (**(code **)(*piStack_48 + 4))();
    }
  }
LAB_008b7c44:
  ppiStack_7c = (int **)0x8b7c4c;
  FUN_00550b30();
  ppiStack_7c = (int **)0x8b7c54;
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14763 ; VA 0x008b80e0 ; FUN_008b80e0 */

int FUN_008b80e0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bd938;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008ac890(auStack_18,&param_1,&param_1);
  piVar3 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 14764 ; VA 0x008b8160 ; FUN_008b8160 */

void FUN_008b8160(void)

{
  FUN_008a4940(&DAT_0211b270);
  return;
}



/* FUNCTION 14765 ; VA 0x008b8170 ; FUN_008b8170 */

void __thiscall FUN_008b8170(int *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 ****ppppuVar3;
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_0087d4d0();
  if ((cVar2 == '\0') &&
     (((cVar2 = FUN_0087ce60(&param_3), uVar1 = param_2, cVar2 == '\0' ||
       (cVar2 = (**(code **)(*param_1 + 0x48))(param_2,param_3), cVar2 == '\0')) &&
      (cVar2 = FUN_0087ca30(), cVar2 != '\0')))) {
    iStack_1c = 0;
    uStack_18 = 0xf;
    apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
    uStack_8 = 0;
    cVar2 = FUN_0087d060(apppuStack_2c);
    if (cVar2 != '\0') {
      ppppuVar3 = apppuStack_2c;
      if (0xf < uStack_18) {
        ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
      }
      cVar2 = FUN_009cb180(ppppuVar3,&param_2);
      if (cVar2 == '\0') {
        if (iStack_1c == 0) {
          (**(code **)(*param_1 + 0x48))(uVar1,0);
        }
      }
      else {
        uStack_14 = param_2;
        (**(code **)(*(int *)param_1[0xe] + 0x10))(uVar1,&uStack_14);
      }
    }
    FUN_005507b0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14766 ; VA 0x008b8260 ; FUN_008b8260 */

void __thiscall FUN_008b8260(uint *param_1,uint param_2)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  int iVar9;
  
  uVar2 = *param_1;
  piVar5 = (int *)FUN_01674f30(param_1[2] * 0x1c);
  *param_1 = (uint)piVar5;
  uVar7 = param_2;
  if ((int)param_1[2] < (int)param_2) {
    uVar7 = param_1[2];
  }
  piVar3 = piVar5 + uVar7 * 7;
  if (piVar5 < piVar3) {
    piVar8 = (int *)(uVar2 + 0xc);
    piVar6 = piVar5 + 5;
    do {
      *piVar5 = piVar8[-3];
      piVar6[-4] = piVar8[-2];
      piVar6[-3] = 0;
      piVar6[-2] = 0;
      if (*piVar8 != 0) {
        LOCK();
        piVar1 = (int *)(*piVar8 + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      piVar6[-3] = piVar8[-1];
      piVar6[-2] = *piVar8;
      piVar6[-1] = 0;
      *piVar6 = 0;
      if (piVar8[2] != 0) {
        LOCK();
        piVar1 = (int *)(piVar8[2] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      piVar5 = piVar5 + 7;
      piVar6[-1] = piVar8[1];
      *piVar6 = piVar8[2];
      piVar1 = piVar8 + 3;
      piVar8 = piVar8 + 7;
      piVar6[1] = *piVar1;
      piVar6 = piVar6 + 7;
    } while (piVar5 < piVar3);
  }
  if (uVar2 < param_2 * 0x1c + uVar2) {
    piVar5 = (int *)(uVar2 + 0xc);
    iVar9 = (param_2 * 0x1c - 1) / 0x1c + 1;
    do {
      piVar3 = (int *)piVar5[2];
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar3 = (int *)*piVar5;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar5 = piVar5 + 7;
      iVar9 = iVar9 + -1;
    } while (iVar9 != 0);
  }
  FUN_01674ea0(uVar2);
  return;
}



/* FUNCTION 14767 ; VA 0x008b83b0 ; FUN_008b83b0 */

void __fastcall FUN_008b83b0(int param_1)

{
  *(undefined *)(param_1 + 0x24) = 0;
  return;
}



/* FUNCTION 14768 ; VA 0x008b83c0 ; FUN_008b83c0 */

void __fastcall FUN_008b83c0(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  
  piVar2 = (int *)FUN_008b3820();
  iVar1 = *piVar2;
  *(undefined4 *)(*(int *)(param_1 + 0x208) + iVar1 * 4) =
       *(undefined4 *)(*(int *)(param_1 + 0x208) + -4 + *(int *)(param_1 + 0x20c) * 4);
  piVar2 = (int *)FUN_008b3820();
  *piVar2 = iVar1;
  FUN_0078c900(*(int *)(param_1 + 0x20c) + -1,0);
  puVar3 = (undefined4 *)FUN_008b3820();
  *puVar3 = 0xffffffff;
  return;
}



/* FUNCTION 14769 ; VA 0x008b8430 ; FUN_008b8430 */

void __thiscall FUN_008b8430(int param_1,undefined4 param_2)

{
  (**(code **)(**(int **)(param_1 + 0x1f8) + 0x10))(param_2);
  FUN_0115afb0(param_2);
  return;
}



/* FUNCTION 14770 ; VA 0x008b8460 ; FUN_008b8460 */

void __thiscall FUN_008b8460(int *param_1,undefined4 param_2)

{
  (**(code **)(*param_1 + 0x10))(param_2);
  return;
}



/* FUNCTION 14771 ; VA 0x008b8470 ; FUN_008b8470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008b8470(int param_1,int *param_2)

{
  code *pcVar1;
  undefined uVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined **ppuVar6;
  int *piVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined **ppuVar10;
  int *piVar11;
  float *pfVar12;
  int iVar13;
  int *piVar14;
  undefined8 *puVar15;
  uint uVar16;
  float10 fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  undefined8 uVar21;
  undefined auStack_1dc [104];
  undefined auStack_174 [12];
  int aiStack_168 [5];
  uint uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  float fStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined8 uStack_104;
  undefined *puStack_fc;
  ulonglong uStack_f8;
  int *piStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  float fStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  float fStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  float fStack_b4;
  undefined8 uStack_ac;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  int iStack_94;
  undefined8 *puStack_8c;
  float *pfStack_88;
  int *piStack_84;
  undefined8 uStack_80;
  float fStack_78;
  int *piStack_74;
  float *pfStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  undefined8 uStack_60;
  float *pfStack_58;
  undefined4 uStack_54;
  undefined uStack_4d;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  int *piStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  float *pfStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  char cStack_19;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd9af;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_38 = param_1;
  puVar4 = (undefined4 *)(**(code **)(*param_2 + 0x30))(&piStack_74);
  *(undefined4 *)(param_1 + 0x14c) = *puVar4;
  *(undefined4 *)(param_1 + 0x150) = puVar4[1];
  *(undefined4 *)(param_1 + 0x154) = puVar4[2];
  *(undefined4 *)(param_1 + 0x158) = puVar4[3];
  iStack_94 = param_1 + -0x58;
  if (DAT_01d62dc4 == '\0') {
LAB_008b84f3:
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edfbf8)
       && (FUN_016f3809(), DAT_01edfbf8 == -1)) {
      uStack_8 = 0;
      uVar21 = FUN_0152dab0("Render","StandardAdorns",0xffffffff);
      DAT_01edfbf4 = (int *)((ulonglong)uVar21 >> 0x20);
      DAT_01edfbf0 = (float *)uVar21;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edfbf8);
    }
    pfStack_30 = DAT_01edfbf0;
    pfStack_88 = DAT_01edfbf0;
    piStack_18 = DAT_01edfbf4;
    piStack_84 = DAT_01edfbf4;
    uStack_80 = FUN_0152d930(DAT_01edfbf0,DAT_01edfbf4);
    uStack_8 = 1;
    iVar5 = FUN_008f7870(param_1 + -0x58);
    if ((iVar5 != 0) && (piVar14 = (int *)(param_1 + 0x15c), param_1 = iStack_38, *piVar14 != 0)) {
      uVar8 = *(undefined4 *)(*piVar14 + 0x6ac);
      fVar17 = (float10)FUN_008f7ed0();
      uStack_60 = (double)fVar17;
      FUN_00bbfa50(uStack_60,uVar8,param_2,0x40);
      param_1 = iStack_38;
    }
    FUN_0115b000();
    uStack_8 = 2;
    FUN_0152dda0(pfStack_30,piStack_18,uStack_80);
    uStack_8 = 0xffffffff;
  }
  else {
    iVar5 = FUN_006ebc30();
    if (*(char *)(iVar5 + 0xe7) != '\0') goto LAB_008b84f3;
  }
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edfc08) {
    FUN_016f3809();
    if (DAT_01edfc08 == -1) {
      uStack_8 = 3;
      uVar21 = FUN_0152dab0("Render","DebugAndEditAdorns",0xffffffff);
      DAT_01edfc04 = (undefined4)((ulonglong)uVar21 >> 0x20);
      DAT_01edfc00 = (undefined4)uVar21;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edfc08);
    }
  }
  uStack_ec = DAT_01edfc00;
  uStack_13c = DAT_01edfc00;
  uStack_e8 = DAT_01edfc04;
  uStack_138 = DAT_01edfc04;
  uStack_134 = FUN_0152d930(DAT_01edfc00,DAT_01edfc04);
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  if ((DAT_01d69070 != '\0') && (DAT_01d62db4 != '\0')) {
    piStack_28 = (int *)0x0;
    piStack_24 = (int *)0x0;
    piStack_20 = (int *)0x0;
    uStack_8 = 5;
    FUN_00f27860();
    FUN_00ce0200();
    FUN_01679a70(0x2a,0);
    piStack_34 = piStack_24;
    if (piStack_28 != piStack_24) {
      piStack_3c = piStack_28 + 0xc;
      do {
        fVar17 = (float10)FUN_01679fb0();
        fStack_78 = (float)fVar17;
        fVar17 = (float10)FUN_01679fb0();
        pfStack_30 = (float *)(float)fVar17;
        fVar17 = (float10)FUN_01679fb0();
        piStack_18 = (int *)(float)fVar17;
        uStack_54 = (int *)piStack_3c[1];
        piStack_40 = (int *)*piStack_3c;
        if (piStack_40 != uStack_54) {
          pfVar12 = (float *)(piStack_40 + 5);
          do {
            uStack_11c = _DAT_018e3fb0;
            uStack_118 = _UNK_018e3fb4;
            uStack_114 = _UNK_018e3fb8;
            fStack_110 = _UNK_018e3fbc;
            puStack_fc = &DAT_3f800000;
            fVar19 = (pfVar12[-1] + pfVar12[-4]) * DAT_018ce2f4;
            fVar20 = (pfVar12[-3] + *pfVar12) * DAT_018ce2f4;
            piStack_f0 = (int *)((pfVar12[1] + pfVar12[-2]) * DAT_018ce2f4);
            uStack_10c = _DAT_018e3fb0;
            uStack_108 = _UNK_018e3fb4;
            uStack_104 = CONCAT44(_UNK_018e3fbc,_UNK_018e3fb8);
            uStack_f8 = CONCAT44(fVar20,fVar19);
            pfStack_58 = DAT_018fde58;
            fStack_68 = DAT_018ce2f4;
            if (*(char *)piStack_40 != '\0') {
              pfStack_58 = DAT_018e452c;
              fStack_68 = DAT_018ce2f8;
            }
            fStack_4c = pfVar12[-1] - pfVar12[-4];
            piStack_74 = piStack_18;
            pfStack_70 = pfStack_30;
            fStack_6c = fStack_78;
            fStack_48 = *pfVar12 - pfVar12[-3];
            fStack_44 = pfVar12[1] - pfVar12[-2];
            uStack_ac = CONCAT44((float)piStack_3c[-6] * fVar19 + (float)piStack_3c[-5] * fVar20 +
                                 (float)piStack_3c[-4] * (float)piStack_f0 + (float)piStack_3c[-1],
                                 (undefined4)uStack_ac);
            piStack_2c = (int *)((float)piStack_3c[-9] * fVar19 + (float)piStack_3c[-8] * fVar20 +
                                 (float)piStack_3c[-7] * (float)piStack_f0 + (float)piStack_3c[-2]);
            uStack_60 = (double)(ulonglong)
                                (uint)((float)piStack_3c[-0xb] * fVar20 +
                                       fVar19 * (float)piStack_3c[-0xc] +
                                       (float)piStack_3c[-10] * (float)piStack_f0 +
                                      (float)piStack_3c[-3]);
            uStack_80._4_4_ = piStack_f0;
            puVar4 = (undefined4 *)FUN_01160c20(auStack_174,&uStack_11c);
            uStack_e0 = *puVar4;
            uStack_dc = puVar4[1];
            uStack_d8 = puVar4[2];
            fStack_d4 = (float)puVar4[3];
            uStack_d0 = puVar4[4];
            uStack_cc = puVar4[5];
            uStack_c8 = puVar4[6];
            fStack_c4 = (float)puVar4[7];
            uStack_c0 = puVar4[8];
            uStack_bc = CONCAT44(piStack_2c,SUB84(uStack_60,0));
            fStack_b4 = uStack_ac._4_4_;
            FUN_0114dc00(&uStack_e0,&fStack_4c,param_2);
            piStack_40 = piStack_40 + 7;
            pfVar12 = pfVar12 + 7;
          } while (piStack_40 != uStack_54);
        }
        piVar11 = piStack_3c + 0xf;
        piVar14 = piStack_3c + 3;
        piStack_3c = piVar11;
      } while (piVar14 != piStack_34);
    }
    uStack_8._0_1_ = 4;
    param_1 = iStack_38;
    piStack_34 = piStack_24;
    if (piStack_28 != (int *)0x0) {
      if (piStack_28 != piStack_24) {
        piVar14 = piStack_24;
        piStack_2c = piStack_28 + 0xe;
        do {
          iVar5 = piStack_2c[-2];
          if (iVar5 != 0) {
            uVar9 = ((*piStack_2c - iVar5) / 0x1c) * 0x1c;
            iVar13 = iVar5;
            if (0xfff < uVar9) {
              iVar13 = *(int *)(iVar5 + -4);
              uVar9 = uVar9 + 0x23;
              uVar2 = (undefined)uStack_8;
              if (0x1f < (iVar5 - iVar13) - 4U) goto LAB_008b9593;
            }
            FUN_01674ea0(iVar13,uVar9);
            piStack_2c[-2] = 0;
            piStack_2c[-1] = 0;
            *piStack_2c = 0;
            piVar14 = piStack_34;
          }
          piVar11 = piStack_2c + 0xf;
          piVar7 = piStack_2c + 1;
          piStack_2c = piVar11;
        } while (piVar7 != piVar14);
      }
      uVar9 = (((int)piStack_20 - (int)piStack_28) / 0x3c) * 0x3c;
      piVar14 = piStack_28;
      if (0xfff < uVar9) {
        piVar14 = (int *)piStack_28[-1];
        uVar9 = uVar9 + 0x23;
        uVar2 = (undefined)uStack_8;
        if ((char *)0x1f < (char *)((int)piStack_28 + (-4 - (int)piVar14))) {
LAB_008b9593:
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(piVar14,uVar9);
      param_1 = iStack_38;
    }
  }
  if ((DAT_01d68e50 != '\0') && (*(int *)(param_1 + 0x1bc) != 0)) {
    FUN_00b4eac0();
  }
  if (DAT_01edfb03 != '\0') {
    iVar5 = *(int *)(*(int *)(param_1 + 0x15c) + 0x6ac);
    piStack_18 = *(int **)(iVar5 + 0x7c);
    piVar14 = *(int **)(iVar5 + 0x78);
    if (piVar14 != piStack_18) {
      do {
        fStack_4c = 0.0;
        fStack_48 = 0.0;
        fStack_44 = 0.0;
        piStack_28 = (int *)0x0;
        piStack_24 = (int *)0x0;
        piStack_20 = (int *)0x0;
        FUN_00a72850(&fStack_4c,&piStack_28);
        fStack_b4 = ((float)piStack_20 + fStack_44) * DAT_018ce2f4;
        uStack_c0 = 0x3f800000;
        uStack_e0 = _DAT_018e3fb0;
        uStack_dc = _UNK_018e3fb4;
        uStack_d8 = _UNK_018e3fb8;
        fStack_d4 = _UNK_018e3fbc;
        uStack_d0 = _DAT_018e3fb0;
        uStack_cc = _UNK_018e3fb4;
        uStack_c8 = _UNK_018e3fb8;
        fStack_c4 = _UNK_018e3fbc;
        uStack_bc = CONCAT44(((float)piStack_24 + fStack_48) * DAT_018ce2f4,
                             ((float)piStack_28 + fStack_4c) * DAT_018ce2f4);
        uStack_80._4_4_ = (int *)fStack_b4;
        puVar4 = (undefined4 *)FUN_0115eb90();
        fStack_64 = (float)piStack_28 - fStack_4c;
        piStack_74 = (int *)*puVar4;
        pfStack_70 = (float *)puVar4[1];
        fStack_6c = (float)puVar4[2];
        fStack_68 = 1.0;
        uStack_60 = (double)CONCAT44((float)piStack_20 - fStack_44,(float)piStack_24 - fStack_48);
        FUN_0114dc00(&uStack_e0,&fStack_64,param_2);
        piVar14 = piVar14 + 6;
      } while (piVar14 != piStack_18);
    }
    iVar5 = *(int *)(*(int *)(iStack_38 + 0x15c) + 0x6ac);
    piStack_18 = *(int **)(iVar5 + 0x70);
    piVar14 = *(int **)(iVar5 + 0x6c);
    if (piVar14 != piStack_18) {
      do {
        fStack_4c = 0.0;
        fStack_48 = 0.0;
        fStack_44 = 0.0;
        piStack_28 = (int *)0x0;
        piStack_24 = (int *)0x0;
        piStack_20 = (int *)0x0;
        FUN_00a72850(&fStack_4c,&piStack_28);
        fStack_b4 = ((float)piStack_20 + fStack_44) * DAT_018ce2f4;
        uStack_c0 = 0x3f800000;
        uStack_e0 = _DAT_018e3fb0;
        uStack_dc = _UNK_018e3fb4;
        uStack_d8 = _UNK_018e3fb8;
        fStack_d4 = _UNK_018e3fbc;
        uStack_d0 = _DAT_018e3fb0;
        uStack_cc = _UNK_018e3fb4;
        uStack_c8 = _UNK_018e3fb8;
        fStack_c4 = _UNK_018e3fbc;
        uStack_bc = CONCAT44(((float)piStack_24 + fStack_48) * DAT_018ce2f4,
                             ((float)piStack_28 + fStack_4c) * DAT_018ce2f4);
        uStack_80._4_4_ = (int *)fStack_b4;
        puVar4 = (undefined4 *)FUN_0115eb50();
        fStack_64 = (float)piStack_28 - fStack_4c;
        piStack_74 = (int *)*puVar4;
        pfStack_70 = (float *)puVar4[1];
        fStack_6c = (float)puVar4[2];
        fStack_68 = 1.0;
        uStack_60 = (double)CONCAT44((float)piStack_20 - fStack_44,(float)piStack_24 - fStack_48);
        FUN_0114dc00(&uStack_e0,&fStack_64,param_2);
        piVar14 = piVar14 + 6;
      } while (piVar14 != piStack_18);
    }
  }
  if (((DAT_01edfafc != '\0') && (iVar5 = *(int *)(iStack_38 + 0x15c), iVar5 != 0)) &&
     (*(int *)(iVar5 + 0x6d0) != 0)) {
    iVar5 = *(int *)(iVar5 + 0x6ac);
    puStack_8c = &uStack_104;
    uStack_104 = uStack_104 & 0xffffffffffffff00;
    uStack_60 = ((double)*(int *)(iVar5 + 0x22c) +
                (double)(&DAT_018c0d90)[-(*(int *)(iVar5 + 0x22c) >> 0x1f)]) /
                (double)*(float *)(iVar5 + 0x230);
    fVar17 = (float10)FUN_01725280(uStack_60);
    uStack_60 = (double)fVar17;
    if (uStack_60 + DAT_018c0d60 < _DAT_018c4e98) {
      piStack_18 = (int *)FUN_016f3eb1();
    }
    else {
      piStack_18 = (int *)0xffffffff;
    }
    ppuVar6 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_18);
    ppuVar10 = ppuVar6 + -1;
    if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar10 = ppuVar6;
    }
    uStack_104 = CONCAT44(*ppuVar10,(undefined4)uStack_104);
    puStack_fc = (undefined *)0x0;
    uStack_f8 = (ulonglong)*(uint *)(iVar5 + 0x230);
    piStack_f0 = (int *)0x0;
    uStack_8._0_1_ = 6;
    FUN_008b5570();
    uStack_8._0_1_ = 7;
    puVar15 = (undefined8 *)0x539;
    cStack_19 = '\0';
    if (puStack_fc == (undefined *)0x0) {
      piVar14 = (int *)0x0;
    }
    else {
      piVar14 = (int *)piStack_f0[uStack_104._4_4_];
    }
    for (; piStack_3c = piVar14, piVar14 != (int *)0x0; piVar14 = (int *)*piVar14) {
      piStack_34 = (int *)piVar14[2];
      if (piStack_34[3] != 0) {
        if (cStack_19 == '\0') {
          uVar16 = 0;
          iVar5 = *piStack_34;
          uVar9 = piStack_34[1] - iVar5 >> 3;
          if (uVar9 != 0) {
            do {
              if (*(int *)(iVar5 + uVar16 * 8) != piStack_34[4]) break;
              uVar16 = uVar16 + 1;
            } while (uVar16 < uVar9);
          }
          puVar15 = *(undefined8 **)(iVar5 + uVar16 * 8);
          cStack_19 = '\x01';
        }
        uVar9 = (int)puVar15 * 0x343fd + 0x269ec3;
        uVar16 = uVar9 * 0x343fd + 0x269ec3;
        uStack_4d = (undefined)((ulonglong)(uVar9 >> 0x10 & 0x7fff) % 0xff);
        cStack_11 = (char)((ulonglong)(uVar16 >> 0x10 & 0x7fff) % 0xff);
        puVar15 = (undefined8 *)(uVar16 * 0x343fd + 0x269ec3);
        uStack_54 = (int *)CONCAT13(0xff,CONCAT12(uStack_4d,(short)CONCAT21(0xff00,cStack_11) << 8))
        ;
        uStack_54 = (int *)CONCAT31(uStack_54._1_3_,
                                    (char)((ulonglong)((uint)puVar15 >> 0x10 & 0x7fff) % 0xff));
        puStack_8c = puVar15;
        FUN_011667e0();
        pfVar12 = (float *)0x0;
        pfStack_58 = (float *)0x0;
        piVar11 = (int *)*piStack_34;
        pfStack_30 = (float *)(piStack_34[1] - (int)piVar11 >> 3);
        if (pfStack_30 != (float *)0x0) {
          piStack_18 = (int *)piStack_34[4];
          piVar7 = piVar11;
          do {
            piVar14 = piStack_3c;
            pfStack_58 = pfVar12;
            if ((int *)*piVar7 != piStack_18) break;
            pfVar12 = (float *)((int)pfVar12 + 1);
            piVar7 = piVar7 + 2;
            pfStack_58 = pfVar12;
          } while (pfVar12 < pfStack_30);
        }
LAB_008b8ed8:
        if (pfStack_58 != (float *)(piStack_34[1] - (int)piVar11 >> 3)) {
          uStack_e4 = *(undefined4 *)(*piStack_34 + 4 + (int)pfStack_58 * 8);
          piStack_18 = (int *)FUN_00ca1550();
          fStack_78 = 0.0;
          piStack_28 = (int *)0x0;
          piStack_24 = (int *)0x0;
          piStack_20 = (int *)0x0;
          uStack_8._0_1_ = 8;
          FUN_0063d9b0(0,&piStack_18);
          cStack_11 = '\0';
          piStack_40 = piStack_20;
          piStack_18 = piStack_28;
          do {
            piStack_2c = (int *)piStack_18[(int)fStack_78];
            FUN_00b06640();
            piVar11 = param_2;
            uVar8 = FUN_00b08170(auStack_1dc);
            FUN_0114df50(uVar8,piVar11);
            if (cStack_11 == '\0') {
              cStack_11 = '\x01';
              pfStack_30 = (float *)(**(code **)*param_2)();
              iVar5 = FUN_00c157b0();
              FUN_00d23e50(&piStack_84,iVar5 + 0x24);
              (**(code **)*param_2)();
              iVar5 = FUN_00712f10();
              pfStack_30 = (float *)(iVar5 + 0x24);
              iVar5 = FUN_00c157b0();
              fVar18 = pfStack_30[1] - *(float *)(iVar5 + 0x28);
              fVar20 = *pfStack_30 - *(float *)(iVar5 + 0x24);
              fVar19 = pfStack_30[2] - *(float *)(iVar5 + 0x2c);
              if (fVar18 * fVar18 + fVar20 * fVar20 + fVar19 * fVar19 < DAT_019203fc) {
                uStack_150 = _DAT_018e3fc0;
                uStack_14c = _UNK_018e3fc4;
                uStack_148 = _UNK_018e3fc8;
                uStack_144 = _UNK_018e3fcc;
                uStack_140 = 0;
                piStack_74 = _DAT_018e3fd0;
                pfStack_70 = _UNK_018e3fd4;
                fStack_6c = _UNK_018e3fd8;
                fStack_68 = _UNK_018e3fdc;
                uStack_ac = 0;
                puVar4 = (undefined4 *)FUN_0115e910();
                uStack_a4 = *puVar4;
                uStack_a0 = puVar4[1];
                uStack_9c = puVar4[2];
                uStack_98 = 0x3f800000;
                uStack_60 = (double)CONCAT44((undefined4)uStack_80,piStack_84);
                uVar8 = FUN_01675640(aiStack_168,&DAT_018bed68);
                uStack_8._0_1_ = 9;
                FUN_0114e430(&fStack_48,uVar8,&uStack_60,0x41800000,0,&uStack_12c,&uStack_a4,0,1,0,
                             &uStack_ac,&piStack_74,&uStack_150,1);
                uStack_8._0_1_ = 8;
                uVar2 = (undefined)uStack_8;
                uStack_8._0_1_ = 8;
                if (0xf < uStack_154) {
                  if ((0xfff < uStack_154 + 1) &&
                     (0x1f < (aiStack_168[0] - *(int *)(aiStack_168[0] + -4)) - 4U))
                  goto LAB_008b9593;
                  FUN_01674ea0();
                }
              }
            }
            piVar11 = piStack_2c;
            pfStack_30 = (float *)0x0;
            if (0 < piStack_2c[5]) {
              do {
                iVar5 = *(int *)(piVar11[4] + (int)pfStack_30 * 4);
                if (iVar5 == 0) {
                  piStack_2c = (int *)0x0;
                }
                else {
                  piStack_2c = (int *)(iVar5 + -8);
                }
                if (piStack_40 == piStack_24) {
                  FUN_0063d9b0(piStack_24,&piStack_2c);
                  piStack_40 = piStack_20;
                }
                else {
                  *piStack_24 = (int)piStack_2c;
                  piStack_24 = piStack_24 + 1;
                }
                pfStack_30 = (float *)((int)pfStack_30 + 1);
              } while ((int)pfStack_30 < piVar11[5]);
              piStack_18 = piStack_28;
              piVar14 = piStack_3c;
              puVar15 = puStack_8c;
            }
            fStack_78 = (float)((int)fStack_78 + 1);
          } while ((uint)fStack_78 < (uint)((int)piStack_24 - (int)piStack_18 >> 2));
          uStack_8._0_1_ = 7;
          if (piStack_18 != (int *)0x0) {
            if ((0xfff < ((int)piStack_40 - (int)piStack_18 & 0xfffffffcU)) &&
               (uVar2 = (undefined)uStack_8,
               (char *)0x1f < (char *)((int)piStack_18 + (-4 - piStack_18[-1])))) goto LAB_008b9593;
            FUN_01674ea0();
            piStack_28 = (int *)0x0;
            piStack_24 = (int *)0x0;
            piStack_20 = (int *)0x0;
          }
          piVar11 = (int *)*piStack_34;
          do {
            pfStack_58 = (float *)((int)pfStack_58 + 1);
            piStack_40 = piVar11;
            if ((float *)(piStack_34[1] - (int)piVar11 >> 3) <= pfStack_58) break;
            piVar14 = piStack_3c;
          } while (piVar11[(int)pfStack_58 * 2] == piStack_34[4]);
          goto LAB_008b8ed8;
        }
      }
    }
    uStack_8._0_1_ = 4;
    FUN_006e27a0();
  }
  if (DAT_01edfafd != '\0') {
    uStack_e0 = _DAT_018e3fb0;
    uStack_dc = _UNK_018e3fb4;
    uStack_d8 = _UNK_018e3fb8;
    fStack_d4 = _UNK_018e3fbc;
    uStack_d0 = _DAT_018e3fb0;
    uStack_cc = _UNK_018e3fb4;
    uStack_c8 = _UNK_018e3fb8;
    fStack_c4 = _UNK_018e3fbc;
    uStack_c0 = _DAT_018e3fb0;
    uStack_bc = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
    fStack_b4 = _UNK_018e3fbc;
    (**(code **)(*param_2 + 0x54))();
    pcVar1 = *(code **)(*param_2 + 0x84);
    puVar4 = (undefined4 *)FUN_0115e920();
    uStack_a4 = *puVar4;
    uStack_a0 = puVar4[1];
    uStack_9c = puVar4[2];
    uStack_98 = 0x3f800000;
    puVar4 = (undefined4 *)FUN_0115eb50();
    piStack_74 = (int *)*puVar4;
    pfStack_70 = (float *)puVar4[1];
    fStack_6c = (float)puVar4[2];
    fStack_68 = 1.0;
    puVar4 = (undefined4 *)FUN_0115eb90();
    pfStack_88 = (float *)*puVar4;
    piStack_84 = (int *)puVar4[1];
    uStack_80._0_4_ = puVar4[2];
    uStack_80._4_4_ = (int *)&DAT_3f800000;
    (*pcVar1)(&pfStack_88,&piStack_74,&uStack_a4,0x42480000);
  }
  if (DAT_01edfafe != '\0') {
    uStack_60 = (double)(ulonglong)DAT_019203f8;
    uStack_ac = (ulonglong)DAT_01900a14;
    uStack_e0 = _DAT_018e3fb0;
    uStack_dc = _UNK_018e3fb4;
    uStack_d8 = _UNK_018e3fb8;
    fStack_d4 = _UNK_018e3fbc;
    uStack_d0 = _DAT_018e3fb0;
    uStack_cc = _UNK_018e3fb4;
    uStack_c8 = _UNK_018e3fb8;
    fStack_c4 = _UNK_018e3fbc;
    uStack_80._4_4_ = (int *)0x41400000;
    piStack_20 = (int *)0x41800000;
    uStack_c0 = _DAT_018e3fb0;
    uStack_bc = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
    fStack_b4 = _UNK_018e3fbc;
    (**(code **)(*param_2 + 0x54))();
    uStack_12c = _DAT_01920410;
    uStack_128 = _UNK_01920414;
    uStack_124 = _UNK_01920418;
    uStack_120 = _UNK_0192041c;
    puStack_fc = (undefined *)uStack_80._4_4_;
    uStack_104 = CONCAT44(DAT_018e3f8c,SUB84(uStack_60,0));
    piStack_f0 = piStack_20;
    uStack_f8 = CONCAT44(DAT_018f997c,(int)uStack_ac);
    (**(code **)(*param_2 + 0x5c))(&uStack_104,&uStack_12c);
  }
  iVar5 = FUN_0097bfc0();
  if (*(char *)(iStack_38 + 0x21b) != '\0') {
    if (iVar5 != 0) {
      cVar3 = FUN_00983210();
      if (cVar3 == '\0') goto LAB_008b949f;
    }
    iVar5 = (int)_DAT_01d62c3c;
    uStack_12c = _DAT_01920430;
    uStack_128 = _UNK_01920434;
    uStack_124 = _UNK_01920438;
    uStack_120 = _UNK_0192043c;
    uStack_a4 = _DAT_01920420;
    uStack_a0 = _UNK_01920424;
    uStack_9c = _UNK_01920428;
    uStack_98 = _UNK_0192042c;
    uVar8 = (**(code **)(*(int *)(iStack_38 + 0xec) + 4))();
    FUN_0114cd30(param_2,uVar8,iVar5,0,&uStack_a4,&uStack_12c);
  }
LAB_008b949f:
  FUN_00f30b80();
  uStack_8 = 10;
  FUN_0152dda0(uStack_ec,uStack_e8,uStack_134);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14772 ; VA 0x008b95a0 ; FUN_008b95a0 */

int __fastcall FUN_008b95a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_28 [4];
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd9c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((*(int *)(param_1 + 0x284) == 0) ||
     ((iVar2 = *(int *)(*(int *)(param_1 + 0x284) + 0x34), iVar2 != param_1 &&
      (ExceptionList = &pvStack_10, iVar2 = FUN_008a3680(iVar2), (char)iVar2 == '\0')))) {
    puVar1 = *(undefined4 **)(param_1 + 0x2c);
    if (puVar1 != (undefined4 *)0x0) {
      piVar6 = (int *)puVar1[1];
      for (piVar5 = (int *)*puVar1; piVar5 != piVar6; piVar5 = piVar5 + 2) {
        piStack_18 = (int *)*piVar5;
        if ((piStack_18 != (int *)0x0) &&
           (iVar2 = piStack_18[3], iVar3 = FUN_00d1e830(), piVar4 = piStack_18,
           (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
           (uint)*(ushort *)(iVar3 + 0x1da))) goto LAB_008b962f;
      }
    }
    piVar4 = (int *)0x0;
LAB_008b962f:
    FUN_0060dcd0(&iStack_20,piVar4);
    iVar2 = iStack_14;
    uStack_8 = 0;
    iVar3 = iStack_20;
    piVar6 = piStack_1c;
    if (iStack_20 == 0) {
      piVar5 = (int *)FUN_0089d950(auStack_28,3);
      piVar6 = (int *)piVar5[1];
      iStack_20 = *piVar5;
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = (int *)piVar5[1];
      }
      piStack_18 = piStack_1c;
      piVar5 = piVar6;
      iStack_14 = iStack_20;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          puVar1 = (undefined4 *)*piStack_1c;
          piStack_1c = piVar6;
          (*(code *)*puVar1)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          piVar5 = piStack_1c;
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
            piVar5 = piStack_1c;
          }
        }
      }
      piStack_1c = piVar5;
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
      FUN_008a64c0(0);
      iVar3 = *(int *)(iVar2 + 0x284);
      if (iVar3 != 0) {
        FUN_00d25e10(*(undefined4 *)(iVar3 + 0x1cc));
      }
      FUN_008a65e0(iVar2,0);
      iVar3 = iStack_14;
    }
    iVar2 = FUN_008ba0d0(iVar3);
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar5 = piVar6 + 1;
      iVar3 = *piVar5;
      iVar2 = *piVar5;
      *piVar5 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar2 = (**(code **)*piVar6)();
        LOCK();
        piVar5 = piVar6 + 2;
        iVar3 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          iVar2 = (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 14773 ; VA 0x008b9750 ; FUN_008b9750 */

void __thiscall FUN_008b9750(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  undefined auStack_24 [32];
  
  if ((((DAT_01d62d34 != '\0') && (*(int *)(param_1 + 0x1b4) != 0)) && (-1 < param_3)) &&
     ((0 < param_3 || (param_2 != 0)))) {
    FUN_005bde90(auStack_24,&DAT_018bed48,param_2,param_3);
    iVar2 = *(int *)(param_1 + 0x1b4);
    iVar1 = *(int *)(iVar2 + 0x6fc);
    if (0 < iVar1) {
      FUN_0087c450(&DAT_018c5f98,"AutoJoinExplicitApi",auStack_24,iVar1,iVar1 >> 0x1f,0);
      iVar2 = *(int *)(param_1 + 0x1b4);
    }
    iVar1 = *(int *)(iVar2 + 0x700);
    if (0 < iVar1) {
      FUN_0087c450(&DAT_018c5f98,"AutoJoinPropertyChanged",auStack_24,iVar1,iVar1 >> 0x1f,0);
      iVar2 = *(int *)(param_1 + 0x1b4);
    }
    iVar1 = *(int *)(iVar2 + 0x704);
    if (0 < iVar1) {
      FUN_0087c450(&DAT_018c5f98,"AutoJoinDragger",auStack_24,iVar1,iVar1 >> 0x1f,0);
      iVar2 = *(int *)(param_1 + 0x1b4);
    }
    iVar1 = *(int *)(iVar2 + 0x708);
    if (0 < iVar1) {
      FUN_0087c450(&DAT_018c5f98,"AutoJoinInsert",auStack_24,iVar1,iVar1 >> 0x1f,0);
    }
  }
  return;
}



/* FUNCTION 14774 ; VA 0x008b9860 ; FUN_008b9860 */

void __fastcall FUN_008b9860(int param_1)

{
  FUN_008bc1f0();
  *(undefined4 *)(*(int *)(param_1 + 0x1b4) + 0x50) = 0;
  return;
}



/* FUNCTION 14775 ; VA 0x008b9880 ; FUN_008b9880 */

void __thiscall FUN_008b9880(int *param_1,int param_2,char param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  float fVar7;
  
  iVar6 = param_1[1];
  if (iVar6 == param_2) {
    return;
  }
  param_1[1] = param_2;
  iVar4 = param_2;
  if (param_2 < iVar6) {
    iVar4 = param_2 * 0x1c;
    iVar5 = iVar6 - param_2;
    do {
      iVar1 = *param_1;
      piVar2 = *(int **)(iVar1 + iVar4 + 0x14);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = *(int **)(iVar1 + iVar4 + 0xc);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = piVar2[1] + -1;
        piVar2[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar1 = piVar2[2] + -1;
          piVar2[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      iVar4 = iVar4 + 0x1c;
      iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
    iVar4 = param_1[1];
  }
  iVar5 = param_1[2];
  if (iVar5 < iVar4) {
    if (iVar5 == 0) {
      param_1[2] = param_2;
      iVar4 = iVar6;
    }
    else {
      if (9 < iVar4) {
        fVar7 = DAT_018df57c;
        if ((iVar5 * 0x1c < 0x61a81) && (fVar7 = DAT_018df580, 64000 < iVar5 * 0x1c)) {
          fVar7 = DAT_018daf58;
        }
        iVar5 = ((int)((float)iVar5 * fVar7) - iVar5) + iVar4;
        param_1[2] = iVar5;
        iVar4 = iVar6;
        if (9 < iVar5) goto LAB_008b99cf;
      }
      param_1[2] = 10;
      iVar4 = iVar6;
    }
  }
  else {
    if (((iVar5 / 3 < iVar4) || (param_3 == '\0')) || (iVar4 < 0xb)) goto LAB_008b99d6;
    if (iVar6 <= iVar4) {
      iVar4 = iVar6;
    }
  }
LAB_008b99cf:
  FUN_008b8260(iVar4);
LAB_008b99d6:
  if (iVar6 < param_1[1]) {
    iVar4 = iVar6 * 0x1c;
    do {
      iVar6 = iVar6 + 1;
      iVar5 = *param_1 + iVar4;
      iVar4 = iVar4 + 0x1c;
      *(undefined4 *)(iVar5 + 8) = 0;
      *(undefined4 *)(iVar5 + 0xc) = 0;
      *(undefined4 *)(iVar5 + 0x10) = 0;
      *(undefined4 *)(iVar5 + 0x14) = 0;
    } while (iVar6 < param_1[1]);
  }
  return;
}



/* FUNCTION 14776 ; VA 0x008b9a20 ; FUN_008b9a20 */

void FUN_008b9a20(void)

{
  code *pcVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bd9e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008afdb0();
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 14777 ; VA 0x008b9a50 ; FUN_008b9a50 */

undefined4 __thiscall FUN_008b9a50(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  
  iVar3 = *(int *)(param_2 + 0xc);
  iVar2 = FUN_00b739e0();
  iVar5 = 0;
  if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar5 = param_2;
  }
  if (iVar5 == 0) {
    uVar4 = FUN_00971ce0(param_1 + -0x1e8,1);
    return uVar4;
  }
  iVar3 = FUN_0097bf90(param_1 + -0x1e8);
  if (iVar3 != 0) {
    if (iVar3 == *(int *)(param_2 + 0x34)) {
      return 1;
    }
    if ((*(int *)(param_2 + 0x34) != 0) && (cVar1 = FUN_00620ec0(iVar3), cVar1 != '\0')) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 14778 ; VA 0x008b9b00 ; FUN_008b9b00 */

void FUN_008b9b00(undefined4 param_1)

{
  FUN_0098c5a0(param_1,0);
  return;
}



/* FUNCTION 14779 ; VA 0x008b9b20 ; FUN_008b9b20 */

void __thiscall FUN_008b9b20(int param_1,char param_2)

{
  char cVar1;
  
  cVar1 = *(char *)(param_1 + 0x328);
  *(char *)(param_1 + 0x328) = param_2;
  if (cVar1 != param_2) {
    cVar1 = FUN_00983210(param_1);
    if (cVar1 != '\0') {
      FUN_008a4940(&DAT_0211b200);
    }
  }
  return;
}



/* FUNCTION 14780 ; VA 0x008b9b60 ; FUN_008b9b60 */

undefined4 * __thiscall FUN_008b9b60(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (DAT_01ee41fa != '\0') {
    FUN_016774b0(DAT_01ee41fa,"Setting clouds on workspace, %p",param_2);
  }
  puVar6 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 *)(param_1 + 0x1d0) = uVar3;
  piVar5 = *(int **)(param_1 + 0x1d4);
  *(undefined4 *)(param_1 + 0x1d4) = uVar4;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar2 = *piVar1;
    puVar6 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      puVar6 = (undefined4 *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_8 + 1;
    iVar2 = *piVar5;
    puVar6 = (undefined4 *)*piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar6 = (undefined4 *)(**(code **)*piStack_8)();
      LOCK();
      piVar5 = piStack_8 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar6 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return puVar6;
}



/* FUNCTION 14781 ; VA 0x008b9c10 ; FUN_008b9c10 */

void FUN_008b9c10(int param_1)

{
  byte bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *****pppppuVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint in_stack_00000018;
  undefined auStack_14c [180];
  undefined4 ****ppppuStack_98;
  uint uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  uint uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  uint uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ****appppuStack_28 [4];
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bda36;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00729510(&param_1,3,1);
  uStack_34 = 0xffffffff;
  uStack_30 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
  uStack_84 = 0xf00000000;
  uStack_94 = uStack_94 & 0xffffff00;
  uStack_6c = 0xf00000000;
  uStack_7c = uStack_7c & 0xffffff00;
  uStack_54 = 0xf00000000;
  uStack_64 = uStack_64 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00bbc010();
  piVar2 = (int *)FUN_00591ab0(auStack_14c,appppuStack_28,0x5c);
  bVar1 = *(byte *)(*(int *)(*piVar2 + 4) + 0xc + (int)piVar2);
  do {
    if ((bVar1 & 6) != 0) {
      FUN_008a4940(&DAT_0211b270);
      if (0xf < uStack_54._4_4_) {
        uVar6 = uStack_54._4_4_ + 1;
        uVar7 = uStack_64;
        if (0xfff < uVar6) {
          uVar7 = *(uint *)(uStack_64 - 4);
          uVar6 = uStack_54._4_4_ + 0x24;
          if (0x1f < (uStack_64 - uVar7) - 4) {
LAB_008ba0ad:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar6);
      }
      uStack_54 = 0xf00000000;
      uStack_64 = uStack_64 & 0xffffff00;
      if (0xf < uStack_6c._4_4_) {
        uVar6 = uStack_6c._4_4_ + 1;
        uVar7 = uStack_7c;
        if (0xfff < uVar6) {
          uVar7 = *(uint *)(uStack_7c - 4);
          uVar6 = uStack_6c._4_4_ + 0x24;
          if (0x1f < (uStack_7c - uVar7) - 4) {
LAB_008ba0b7:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar6);
      }
      uStack_6c = 0xf00000000;
      uStack_7c = uStack_7c & 0xffffff00;
      if (0xf < uStack_84._4_4_) {
        uVar6 = uStack_84._4_4_ + 1;
        uVar7 = uStack_94;
        if (0xfff < uVar6) {
          uVar7 = *(uint *)(uStack_94 - 4);
          uVar6 = uStack_84._4_4_ + 0x24;
          if (0x1f < (uStack_94 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar6);
      }
      uStack_84 = 0xf00000000;
      uStack_94 = uStack_94 & 0xffffff00;
      if (0xf < uStack_14) {
        uVar7 = uStack_14 + 1;
        pppppuVar4 = (undefined4 *****)appppuStack_28[0];
        if (0xfff < uVar7) {
          pppppuVar4 = (undefined4 *****)appppuStack_28[0][-1];
          uVar7 = uStack_14 + 0x24;
          if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)pppppuVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppuVar4,uVar7);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
      FUN_005705c0();
      if (0xf < in_stack_00000018) {
        uVar7 = in_stack_00000018 + 1;
        iVar3 = param_1;
        if (0xfff < uVar7) {
          iVar3 = *(int *)(param_1 + -4);
          uVar7 = in_stack_00000018 + 0x24;
          if (0x1f < (param_1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar7);
      }
      ExceptionList = pvStack_10;
      return;
    }
    pppppuVar4 = appppuStack_28;
    if (0xf < uStack_14) {
      pppppuVar4 = (undefined4 *****)appppuStack_28[0];
    }
    if ((uStack_18 == 0) || (iVar3 = FUN_0170db20(pppppuVar4,0x5e,uStack_18), iVar3 == 0)) {
      uVar7 = 0xffffffff;
    }
    else {
      uVar7 = iVar3 - (int)pppppuVar4;
    }
    uStack_3c = 0;
    uVar6 = uVar7;
    if (uStack_18 < uVar7) {
      uVar6 = uStack_18;
    }
    pppppuVar4 = appppuStack_28;
    if (0xf < uStack_14) {
      pppppuVar4 = (undefined4 *****)appppuStack_28[0];
    }
    uStack_38 = 0xf;
    uStack_4c = uStack_4c & 0xffffff00;
    FUN_005542c0(pppppuVar4,uVar6);
    if (0xf < uStack_84._4_4_) {
      uVar5 = uStack_84._4_4_ + 1;
      uVar6 = uStack_94;
      if (0xfff < uVar5) {
        uVar6 = *(uint *)(uStack_94 - 4);
        uVar5 = uStack_84._4_4_ + 0x24;
        if (0x1f < (uStack_94 - uVar6) - 4) goto LAB_008ba0ad;
      }
      FUN_01674ea0(uVar6,uVar5);
    }
    uVar6 = uVar7 + 1;
    ppppuStack_98 = appppuStack_28;
    if (0xf < uStack_14) {
      ppppuStack_98 = appppuStack_28[0];
    }
    uStack_2c = uStack_18;
    uStack_94 = uStack_4c;
    uStack_90 = uStack_48;
    uStack_8c = uStack_44;
    uStack_88 = uStack_40;
    uStack_84 = CONCAT44(uStack_38,uStack_3c);
    if ((uVar6 < uStack_18) &&
       (iVar3 = FUN_0170db20((int)ppppuStack_98 + uVar6,0x5e,uStack_18 - uVar6), iVar3 != 0)) {
      iVar3 = iVar3 - (int)ppppuStack_98;
    }
    else {
      iVar3 = -1;
    }
    uVar6 = uVar7 + 1;
    uStack_3c = 0;
    uStack_38 = 0xf;
    uStack_4c = uStack_4c & 0xffffff00;
    if (uStack_2c < uVar6) {
LAB_008ba0b2:
      uStack_38 = 0xf;
      uStack_3c = 0;
      FUN_00554050();
      goto LAB_008ba0b7;
    }
    uVar7 = (iVar3 - uVar7) - 1;
    if (uStack_2c - uVar6 < uVar7) {
      uVar7 = uStack_2c - uVar6;
    }
    pppppuVar4 = appppuStack_28;
    if (0xf < uStack_14) {
      pppppuVar4 = (undefined4 *****)appppuStack_28[0];
    }
    FUN_005542c0((int)pppppuVar4 + uVar6,uVar7);
    if (0xf < uStack_6c._4_4_) {
      uVar6 = uStack_6c._4_4_ + 1;
      uVar7 = uStack_7c;
      if (0xfff < uVar6) {
        uVar7 = *(uint *)(uStack_7c - 4);
        uVar6 = uStack_6c._4_4_ + 0x24;
        if (0x1f < (uStack_7c - uVar7) - 4) goto LAB_008ba0ad;
      }
      FUN_01674ea0(uVar7,uVar6);
    }
    uStack_7c = uStack_4c;
    uStack_78 = uStack_48;
    uStack_74 = uStack_44;
    uStack_70 = uStack_40;
    uStack_6c = CONCAT44(uStack_38,uStack_3c);
    FUN_009ee5c0(&uStack_7c,&uStack_34);
    uVar7 = iVar3 + 1;
    uStack_3c = 0;
    uStack_38 = 0xf;
    uStack_4c = uStack_4c & 0xffffff00;
    if (uStack_18 < uVar7) goto LAB_008ba0b2;
    iVar3 = -1;
    if (uStack_18 - uVar7 != -1) {
      iVar3 = uStack_18 - uVar7;
    }
    pppppuVar4 = appppuStack_28;
    if (0xf < uStack_14) {
      pppppuVar4 = (undefined4 *****)appppuStack_28[0];
    }
    FUN_005542c0((int)pppppuVar4 + uVar7,iVar3);
    if (0xf < uStack_54._4_4_) {
      uVar6 = uStack_54._4_4_ + 1;
      uVar7 = uStack_64;
      if (0xfff < uVar6) {
        uVar7 = *(uint *)(uStack_64 - 4);
        uVar6 = uStack_54._4_4_ + 0x24;
        if (0x1f < (uStack_64 - uVar7) - 4) goto LAB_008ba0ad;
      }
      FUN_01674ea0(uVar7,uVar6);
    }
    uStack_64 = uStack_4c;
    uStack_60 = uStack_48;
    uStack_5c = uStack_44;
    uStack_58 = uStack_40;
    uStack_54 = CONCAT44(uStack_38,uStack_3c);
    FUN_009ee5c0(&uStack_64,&uStack_30);
    FUN_00bbc9d0(&uStack_94,uStack_34,uStack_30);
    piVar2 = (int *)FUN_00591ab0(auStack_14c,appppuStack_28,0x5c);
    bVar1 = *(byte *)(*(int *)(*piVar2 + 4) + 0xc + (int)piVar2);
  } while( true );
}



/* FUNCTION 14782 ; VA 0x008ba0d0 ; FUN_008ba0d0 */

void __thiscall FUN_008ba0d0(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bda48;
  pvStack_10 = ExceptionList;
  if (param_2 != *(int *)(param_1 + 0x284)) {
    ExceptionList = &pvStack_10;
    iStack_14 = param_1;
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_1c,param_2);
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x284) = uVar2;
    piVar7 = *(int **)(param_1 + 0x288);
    *(undefined4 *)(param_1 + 0x288) = uVar3;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar5 = piVar7[1] + -1;
      piVar7[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar5 = piVar7[2] + -1;
        piVar7[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    piVar7 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_18[1] + -1;
      piStack_18[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    FUN_008a4940(&DAT_0211b524);
    if ((param_2 != 0) && (puVar6 = *(undefined4 **)(param_1 + 0x2c), puVar6 != (undefined4 *)0x0))
    {
      piVar7 = *(int **)(param_1 + 0x30);
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        piVar7 = *(int **)(param_1 + 0x30);
        puVar6 = *(undefined4 **)(param_1 + 0x2c);
      }
      puVar4 = (undefined4 *)puVar6[1];
      puVar6 = (undefined4 *)*puVar6;
      uStack_8 = 0;
      param_1 = iStack_14;
      for (; piStack_18 = piVar7, iStack_14 = param_1, puVar6 != puVar4; puVar6 = puVar6 + 2) {
        if (puVar6[1] != 0) {
          LOCK();
          piVar7 = (int *)(puVar6[1] + 4);
          *piVar7 = *piVar7 + 1;
          UNLOCK();
        }
        FUN_008b21f0(*puVar6,puVar6[1],param_2);
        piVar7 = piStack_18;
        param_1 = iStack_14;
      }
      uStack_8 = 0xffffffff;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[1] + -1;
        piVar7[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          param_1 = iStack_14;
          if (iVar5 == 1) {
            (**(code **)(*piVar7 + 4))();
            param_1 = iStack_14;
          }
        }
      }
    }
    if (*(int *)(param_1 + 0x288) != 0) {
      LOCK();
      piVar7 = (int *)(*(int *)(param_1 + 0x288) + 4);
      *piVar7 = *piVar7 + 1;
      UNLOCK();
    }
    FUN_008af3d0(*(undefined4 *)(param_1 + 0x284),*(undefined4 *)(param_1 + 0x288));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14783 ; VA 0x008ba290 ; FUN_008ba290 */

void FUN_008ba290(int param_1)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000018;
  
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 14784 ; VA 0x008ba2d0 ; FUN_008ba2d0 */

void __thiscall FUN_008ba2d0(undefined4 param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_008f7870(param_1);
  if ((iVar1 != 0) && (*(int *)(iVar1 + 0x450) != param_2)) {
    FUN_008a4940(&DAT_0211b238);
    FUN_0090b1c0(param_2);
  }
  return;
}



/* FUNCTION 14785 ; VA 0x008ba310 ; FUN_008ba310 */

void __fastcall FUN_008ba310(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *(undefined4 *)(param_1 + 600) = 0;
  piVar2 = *(int **)(param_1 + 0x25c);
  *(undefined4 *)(param_1 + 0x25c) = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_008bac40(0,0,0);
  return;
}



/* FUNCTION 14786 ; VA 0x008ba380 ; FUN_008ba380 */

void __thiscall FUN_008ba380(int param_1,double param_2)

{
  if ((NAN(param_2) || NAN(*(double *)(param_1 + 0x2e0))) ==
      (param_2 == *(double *)(param_1 + 0x2e0))) {
    *(double *)(param_1 + 0x2e0) = param_2;
    FUN_008a4940(&DAT_0211af08);
  }
  return;
}



/* FUNCTION 14787 ; VA 0x008ba3b0 ; FUN_008ba3b0 */

undefined4 __thiscall FUN_008ba3b0(int param_1,undefined4 param_2,int param_3)

{
  if (*(int *)(param_3 + 0x18) != *(int *)(param_1 + 0x34)) {
    return 0;
  }
  param_3 = *(undefined4 *)(param_3 + 0x1c);
  (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
  return 1;
}



/* FUNCTION 14788 ; VA 0x008ba3f0 ; FUN_008ba3f0 */

void __thiscall FUN_008ba3f0(int param_1,char param_2)

{
  if (param_2 != *(char *)(*(int *)(param_1 + 0x1b4) + 0xe8)) {
    *(char *)(*(int *)(param_1 + 0x1b4) + 0xe8) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 14789 ; VA 0x008ba420 ; FUN_008ba420 */

void __thiscall FUN_008ba420(int param_1,float param_2)

{
  int *piVar1;
  float fVar2;
  float fVar3;
  
  fVar2 = DAT_01920404;
  if (DAT_01920404 <= param_2) {
    fVar2 = param_2;
  }
  piVar1 = *(int **)(*(int *)(param_1 + 0x1b4) + 0xc0);
  fVar3 = DAT_01920400;
  if (fVar2 <= DAT_01920400) {
    fVar3 = fVar2;
  }
  if ((NAN((float)(*piVar1 - (int)piVar1)) || NAN(fVar3)) ==
      ((float)(*piVar1 - (int)piVar1) == fVar3)) {
    *piVar1 = (int)fVar3 + (int)piVar1;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 14790 ; VA 0x008ba480 ; FUN_008ba480 */

void __thiscall FUN_008ba480(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = DAT_018ce324;
  if (fVar1 <= DAT_018ce324) {
    fVar2 = fVar1;
  }
  if ((((uint)fVar2 & 0x7f800000) != 0x7f800000) &&
     (fVar1 = *(float *)(*(int *)(param_1 + 0x1b4) + 0xc4),
     (NAN(fVar1) || NAN(fVar2)) == (fVar1 == fVar2))) {
    FUN_00bc0c90(fVar2);
    **(int **)(param_1 + 0x334) =
         *(int *)(*(int *)(param_1 + 0x1b4) + 0xc4) + (int)*(int **)(param_1 + 0x334);
    FUN_008a4940(&DAT_0211b1c8);
  }
  return;
}



/* FUNCTION 14791 ; VA 0x008ba510 ; FUN_008ba510 */

uint __thiscall FUN_008ba510(int param_1,char param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined auStack_a4 [48];
  undefined auStack_74 [24];
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined auStack_44 [16];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bda80;
  pvStack_10 = ExceptionList;
  if (param_2 != '\0') {
    return (uint)ExceptionList & 0xffffff00;
  }
  piVar1 = *(int **)(param_1 + 0x2c);
  ExceptionList = &pvStack_10;
  if (((piVar1 != (int *)0x0) && (ExceptionList = &pvStack_10, piVar1[1] - *piVar1 >> 3 != 0)) &&
     (ExceptionList = &pvStack_10, *(int *)*piVar1 != 0)) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("ThumbnailCamera",0xf);
    uStack_8 = 0;
    iVar2 = FUN_008a1240(auStack_2c);
    if ((iVar2 == 0) ||
       (iVar5 = *(int *)(iVar2 + 0xc), iVar3 = FUN_00d1e830(),
       (uint)*(ushort *)(iVar3 + 0x1da) <
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
      iVar2 = 0;
    }
    uStack_8 = 0xffffffff;
    FUN_005507b0();
    if (iVar2 != 0) {
      uVar4 = FUN_008ba0d0(iVar2);
      ExceptionList = pvStack_10;
      return uVar4 & 0xffffff00;
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = 0;
    FUN_005542c0("ThumbnailConfiguration",0x16);
    uStack_8 = 1;
    iVar2 = FUN_008a1240(auStack_2c);
    if ((iVar2 == 0) ||
       (iVar5 = *(int *)(iVar2 + 0xc), iVar3 = FUN_00ea83f0(),
       (uint)*(ushort *)(iVar3 + 0x1da) <
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
      iVar2 = 0;
    }
    uStack_8 = 0xffffffff;
    FUN_005507b0();
    if (iVar2 != 0) {
      uStack_4c = 0;
      uStack_48 = 0xf;
      auStack_5c[0] = 0;
      FUN_005542c0("ThumbnailCameraTarget",0x15);
      uStack_8 = 2;
      _param_2 = FUN_008a1240(auStack_5c);
      if ((_param_2 == 0) ||
         (iVar2 = *(int *)(_param_2 + 0xc), iVar5 = FUN_00dafee0(),
         (uint)*(ushort *)(iVar5 + 0x1da) <
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
        _param_2 = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = 0;
      FUN_005542c0("ThumbnailCameraValue",0x14);
      uStack_8 = 3;
      iVar2 = FUN_008a1240(auStack_44);
      if ((iVar2 == 0) ||
         (iVar5 = *(int *)(iVar2 + 0xc), iVar3 = FUN_00dafae0(),
         (uint)*(ushort *)(iVar3 + 0x1da) <
         (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
        iVar2 = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      if ((_param_2 != 0) && (iVar2 != 0)) {
        uVar6 = FUN_00db4dc0();
        iVar5 = FUN_006e16a0(uVar6);
        if (iVar5 != 0) {
          FUN_008b95a0();
          (**(code **)(*(int *)(param_1 + 0x144) + 4))();
          FUN_00b077e0();
          uVar6 = FUN_0071f260(auStack_74,iVar2 + 0x54);
          uVar4 = FUN_00d24840(uVar6);
          ExceptionList = pvStack_10;
          return uVar4 & 0xffffff00;
        }
      }
    }
  }
  FUN_008b95a0();
  iVar2 = 0;
  uVar4 = 0;
  iVar5 = FUN_005d6c30();
  if (iVar5 != 0) {
    do {
      iStack_14 = FUN_0170d75d(*(undefined4 *)(**(int **)(param_1 + 0x2c) + uVar4 * 8),0,
                               &RBX::Instance::RTTI_Type_Descriptor,
                               &RBX::HopperBin::RTTI_Type_Descriptor,0);
      puVar7 = (undefined4 *)
               FUN_0170d75d(*(undefined4 *)(**(int **)(param_1 + 0x2c) + uVar4 * 8),0,
                            &RBX::Instance::RTTI_Type_Descriptor,
                            &RBX::IHasLocation::RTTI_Type_Descriptor,0);
      iVar5 = FUN_0170d75d(*(undefined4 *)(**(int **)(param_1 + 0x2c) + uVar4 * 8),0,
                           &RBX::Instance::RTTI_Type_Descriptor,
                           &RBX::IAdornable::RTTI_Type_Descriptor,0);
      if ((puVar7 != (undefined4 *)0x0) && (iVar5 != 0)) {
        (**(code **)*puVar7)(auStack_a4);
        (**(code **)(*(int *)(param_1 + 0x144) + 4))();
        FUN_00d25610(auStack_a4,param_3);
      }
      if (iStack_14 != 0) {
        iVar2 = iStack_14;
      }
      uVar4 = uVar4 + 1;
      uVar8 = FUN_005d6c30();
    } while (uVar4 < uVar8);
    if (iVar2 != 0) {
      iVar2 = *(int *)(param_1 + 0x34);
      iVar5 = param_1;
      if ((iVar2 != 0) && (iVar5 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
        iVar5 = FUN_005c8ac0();
      }
      if ((iVar5 == 0) ||
         (iVar2 = *(int *)(iVar5 + 0xc), iVar5 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar5 + 0x1da) <
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
        uVar6 = 0;
      }
      else {
        uVar6 = FUN_00674620();
      }
      FUN_008a65e0(uVar6,0);
    }
  }
  *(uint *)(param_1 + 0x348) = (uint)(*(int *)(param_1 + 0x348) < 1);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 14792 ; VA 0x008ba920 ; FUN_008ba920 */

undefined __thiscall FUN_008ba920(int param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iStack_8;
  
  iStack_8 = param_1;
  cVar1 = FUN_009cb5f0(param_3,&iStack_8);
  if (cVar1 == '\0') {
    return 0;
  }
  param_3 = iStack_8;
  (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
  return 1;
}



/* FUNCTION 14793 ; VA 0x008ba960 ; FUN_008ba960 */

void __thiscall FUN_008ba960(int param_1,uint param_2)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  undefined *puVar4;
  bool bVar5;
  undefined *puStack_38;
  undefined *puStack_34;
  undefined *puStack_30;
  int iStack_2c;
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdaa8;
  pvStack_10 = ExceptionList;
  if ((DAT_01d6f4e8 == '\0') && (DAT_01d6f4f0 == '\0')) {
    return;
  }
  if (param_2 == *(uint *)(param_1 + 0x314)) {
    return;
  }
  ExceptionList = &pvStack_10;
  *(uint *)(param_1 + 0x314) = param_2;
  if (DAT_01d62d9c == '\0') {
    bVar5 = param_2 == 2;
  }
  else {
    bVar5 = param_2 != 1;
  }
  *(bool *)(*(int *)(*(int *)(param_1 + 0x1b4) + 0x6d0) + 0xca) = bVar5;
  FUN_008a4940(&DAT_0211b028);
  if (DAT_01d62d94 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  iVar3 = *(int *)(param_1 + 0x314);
  uStack_18 = 0;
  if (iVar3 == 0) {
    uStack_11 = 0;
    uStack_8 = 0;
    FUN_016dfd92(auStack_20);
    puStack_38 = auStack_20;
    uStack_8 = 1;
    puStack_34 = &uStack_11;
    iVar3 = FUN_016de3db(&uStack_18,FUN_008aa970,&puStack_38);
    if (iVar3 != 0) {
      uStack_8 = 2;
      goto LAB_008baac2;
    }
    uStack_8._0_1_ = 3;
    cVar2 = FUN_016dfded(auStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
LAB_008baaf3:
    if (cVar2 != '\0') goto LAB_008bab70;
  }
  else {
    if (iVar3 == 1) {
      uStack_11 = 0;
      uStack_8 = 5;
      FUN_016dfd92(auStack_20);
      puStack_38 = auStack_20;
      uStack_8 = 6;
      puStack_34 = &uStack_11;
      iVar3 = FUN_016de3db(&uStack_18,FUN_008aaa20,&puStack_38);
      if (iVar3 == 0) {
        uStack_8._0_1_ = 8;
        cVar2 = FUN_016dfded(auStack_20);
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        goto LAB_008baaf3;
      }
      uStack_8 = 7;
LAB_008baac2:
      puVar4 = auStack_20;
LAB_008baac5:
      FUN_016dfdcc(puVar4);
      ExceptionList = pvStack_10;
      return;
    }
    if (iVar3 != 2) {
      ExceptionList = pvStack_10;
      return;
    }
    param_2 = param_2 & 0xffffff;
    uStack_8 = 10;
    FUN_016dfd92(auStack_28);
    puStack_30 = auStack_28;
    uStack_8 = 0xb;
    iStack_2c = (int)&param_2 + 3;
    iVar3 = FUN_016de3db(&uStack_18,FUN_008aaad0,&puStack_30);
    if (iVar3 != 0) {
      uStack_8 = 0xc;
      puVar4 = auStack_28;
      goto LAB_008baac5;
    }
    uStack_8._0_1_ = 0xd;
    cVar2 = FUN_016dfded(auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    if (cVar2 != '\0') {
      FUN_005dbd40(auStack_28);
      FUN_008b9a20();
    }
  }
  FUN_016de3f3();
LAB_008bab70:
  FUN_005dbd40(auStack_20);
  FUN_008b9a20();
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 14794 ; VA 0x008bab90 ; FUN_008bab90 */

void __thiscall FUN_008bab90(int param_1,int param_2)

{
  if ((DAT_01d62dac != '\0') && (param_2 != *(int *)(param_1 + 0x31c))) {
    *(int *)(param_1 + 0x31c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 14795 ; VA 0x008babc0 ; FUN_008babc0 */

int __thiscall FUN_008babc0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(int *)(param_1 + 800) = param_2;
  piVar3 = *(int **)(param_1 + 0x324);
  *(int **)(param_1 + 0x324) = param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar2 = *piVar3;
    param_2 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 14796 ; VA 0x008bac40 ; FUN_008bac40 */

uint __thiscall FUN_008bac40(int param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  uint uVar9;
  char *pcVar10;
  int iVar11;
  undefined auStack_30 [4];
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017bdb30;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  piStack_24 = (int *)0x0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01ee4205 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01677490(DAT_01ee4205,"Set mouse command: %p, old command: %p",param_2,
                 *(undefined4 *)(param_1 + 0x250),0);
  }
  if (param_1 == 0) {
LAB_008bacd4:
    iVar5 = 0;
  }
  else {
    iVar11 = *(int *)(param_1 + 0x34);
    iVar5 = param_1;
    if ((iVar11 != 0) && (iVar5 = iVar11, *(int *)(iVar11 + 0x34) != 0)) {
      iVar5 = FUN_005c8ac0();
    }
    if ((iVar5 == 0) ||
       (iVar11 = *(int *)(iVar5 + 0xc), iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) goto LAB_008bacd4;
  }
  uVar9 = -(uint)(iVar5 != 0) & iVar5 - 0xcU;
  FUN_00eb65e0(auStack_30);
  iStack_8._0_1_ = 1;
  iStack_14 = FUN_00eb6280(uVar9);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  piStack_1c = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar11 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar11 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if ((((param_2 == (int *)0x0) || ((char)param_4 != '\0')) && (iStack_14 != 0)) &&
     (*(char *)(iStack_14 + 0x75) != '\0')) {
    uVar9 = (uint)DAT_01ee4205;
    if (DAT_01ee4205 == 0) goto LAB_008bb0f7;
    pcVar10 = "Rejecting because of plugin override, plugin: %p";
    iVar11 = iStack_14;
  }
  else {
    if (param_2 == (int *)0x0) {
      if (*(int **)(param_1 + 600) != (int *)0x0) {
        uVar7 = (**(code **)(**(int **)(param_1 + 600) + 0x70))(&uStack_20);
        FUN_005587e0(uVar7);
        param_4 = piStack_1c;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar11 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            iVar11 = param_4[2] + -1;
            param_4[2] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)(*param_4 + 4))();
            }
          }
        }
        if (DAT_01ee4205 != 0) {
          FUN_01677490(DAT_01ee4205,"Have sticky command %p, generating new mouse command: %p",
                       *(undefined4 *)(param_1 + 600),param_2,0);
        }
        if (param_2 != (int *)0x0) goto LAB_008baf72;
      }
      if (DAT_01d62d3c == '\0') {
        iVar11 = FUN_0097bfc0(param_1);
        if ((iVar11 != 0) && (cVar4 = FUN_00983210(param_1), cVar4 == '\0')) {
          iStack_8 = CONCAT31(iStack_8._1_3_,7);
          param_4 = (int *)FUN_01674e20(0x74);
          iStack_8 = 8;
          if (param_4 == (int *)0x0) {
            uVar7 = 0;
          }
          else {
            uVar7 = FUN_00f31120(param_1);
          }
          iStack_8 = CONCAT31(iStack_8._1_3_,7);
          uStack_20 = 0;
          piStack_1c = (int *)0x0;
          FUN_008ab400(uVar7,param_4);
          iStack_8 = 0;
          uStack_18 = 8;
          FUN_005587e0(&uStack_20);
          FUN_00550b30();
          goto LAB_008bae6f;
        }
        param_4 = (int *)param_1;
        uVar7 = FUN_008ac040(&iStack_28,&param_4);
        FUN_005587e0(uVar7);
        param_4 = piStack_24;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar11 = piStack_24[1] + -1;
          piStack_24[1] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar11 = param_4[2] + -1;
            param_4[2] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)(*param_4 + 4))();
            }
          }
        }
        if (DAT_01ee4205 == 0) goto LAB_008baf72;
        pcVar10 = "Generating new arrow tool: %p";
      }
      else {
        iStack_8 = CONCAT31(iStack_8._1_3_,2);
        param_4 = (int *)FUN_01674e20(0x74);
        iStack_8 = 3;
        if (param_4 == (int *)0x0) {
          uVar7 = 0;
        }
        else {
          uVar7 = FUN_00f31120(param_1);
        }
        iStack_8 = CONCAT31(iStack_8._1_3_,2);
        uStack_20 = 0;
        piStack_1c = (int *)0x0;
        FUN_008ab400(uVar7,param_4);
        iStack_8 = 0;
        uStack_18 = 2;
        FUN_005587e0(&uStack_20);
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar11 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            iVar11 = piStack_1c[2] + -1;
            piStack_1c[2] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
LAB_008bae6f:
        if (DAT_01ee4205 == 0) goto LAB_008baf72;
        pcVar10 = "Setting as null tool: %p";
      }
      FUN_016774b0(DAT_01ee4205,pcVar10,param_2);
    }
LAB_008baf72:
    piVar8 = *(int **)(param_1 + 0x250);
    if (param_2 != piVar8) {
      if (piVar8 != (int *)0x0) {
        (**(code **)(*piVar8 + 100))();
      }
      if ((iStack_14 != 0) && (*(char *)(iStack_14 + 0x75) != '\0')) {
        FUN_00eb65e0(auStack_30);
        iStack_8._0_1_ = 0xc;
        FUN_00eb6610(uVar9);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_00550b30();
      }
      if (DAT_01ee4205 != 0) {
        FUN_01677490(DAT_01ee4205,"Current command update, new: %p, old: %p",param_2,
                     *(undefined4 *)(param_1 + 0x250),0);
      }
      uVar9 = uStack_18;
      if (*(int **)(param_1 + 0x250) == (int *)0x0) {
LAB_008bb00e:
        param_4 = (int *)((uint)param_4 & 0xffffff);
      }
      else {
        piVar8 = (int *)(**(code **)(**(int **)(param_1 + 0x250) + 0x70))(auStack_30);
        uVar9 = uStack_18 | 1;
        if (*piVar8 == 0) goto LAB_008bb00e;
        param_4 = (int *)CONCAT13(1,param_4._0_3_);
      }
      if (((uVar9 & 1) != 0) && (piStack_2c != (int *)0x0)) {
        LOCK();
        iVar11 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          iVar11 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piStack_2c + 4))();
          }
        }
      }
      FUN_0056ecd0(&param_2);
      (**(code **)(*param_2 + 0x70))(&iStack_28);
      iStack_8._0_1_ = 0xd;
      if (iStack_28 != 0) {
        if (DAT_01ee4205 != 0) {
          FUN_01677490(DAT_01ee4205,"Sticky command replaced too: %p, old: %p",iStack_28,
                       *(undefined4 *)(param_1 + 600),0);
        }
        FUN_0056ecd0(&iStack_28);
        if ((iStack_28 != 0) && (param_4._3_1_ != '\0')) {
          FUN_006eccd0();
        }
      }
      FUN_008bc5f0();
      piVar8 = piStack_24;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar11 = piStack_24[1] + -1;
        piStack_24[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piVar8 + 2;
          iVar11 = *piVar1 + -1;
          *piVar1 = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
    }
    uVar9 = (uint)DAT_01ee4205;
    if (DAT_01ee4205 == 0) goto LAB_008bb0f7;
    iVar11 = 0;
    pcVar10 = "Set mouse command: Done";
  }
  uVar9 = FUN_016774b0(uVar9,pcVar10,iVar11);
LAB_008bb0f7:
  piVar8 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(param_3 + 1);
    uVar3 = *puVar2;
    uVar9 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar9 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar11 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar11 == 1) {
        uVar9 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar9;
}



/* FUNCTION 14797 ; VA 0x008bb130 ; FUN_008bb130 */

void __thiscall FUN_008bb130(int param_1,char param_2)

{
  char cVar1;
  
  if (param_2 != '\0') {
    cVar1 = FUN_0098c5a0(param_1,0);
    if (cVar1 != '\0') {
      FUN_005789c0(&DAT_01edfba4,&LAB_008b9ae0);
    }
  }
  cVar1 = *(char *)(param_1 + 0x31b);
  *(char *)(param_1 + 0x31b) = param_2;
  if (cVar1 != param_2) {
    cVar1 = FUN_00983210(param_1);
    if (cVar1 != '\0') {
      FUN_008a4940(&DAT_0211b158);
    }
  }
  return;
}



/* FUNCTION 14798 ; VA 0x008bb190 ; FUN_008bb190 */

void __thiscall FUN_008bb190(int param_1,char param_2)

{
  char cVar1;
  int iVar2;
  
  cVar1 = *(char *)(param_1 + 0x300);
  *(char *)(param_1 + 0x300) = param_2;
  iVar2 = FUN_008f7870(param_1);
  if (param_2 == cVar1) {
    return;
  }
  cVar1 = FUN_00983210(param_1);
  if (cVar1 == '\0') {
    if (iVar2 == 0) {
      return;
    }
    cVar1 = FUN_008ff0a0();
    if (cVar1 == '\0') {
      return;
    }
  }
  FUN_008a4940(&DAT_0211af40);
  return;
}



/* FUNCTION 14799 ; VA 0x008bb1f0 ; FUN_008bb1f0 */

void __fastcall FUN_008bb1f0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdb68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 600) = 0;
  piVar2 = *(int **)(param_1 + 0x25c);
  *(undefined4 *)(param_1 + 0x25c) = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0;
  iVar3 = FUN_01674e20(0x74);
  uStack_8 = 1;
  if (iVar3 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00f31120(param_1);
  }
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_008ab400(uVar4,0);
  *(undefined4 *)(param_1 + 0x250) = 0;
  piVar2 = *(int **)(param_1 + 0x254);
  uStack_8 = 0xffffffff;
  *(undefined4 *)(param_1 + 0x254) = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_008bc5f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14800 ; VA 0x008bb300 ; FUN_008bb300 */

void FUN_008bb300(undefined4 param_1)

{
  undefined auStack_10 [12];
  
  if (DAT_01d67c88 != '\0') {
    FUN_008bb340(param_1);
    return;
  }
  FUN_00550130("PhysicsSimulationRate is not a valid member of Workspace");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 14801 ; VA 0x008bb340 ; FUN_008bb340 */

void __thiscall FUN_008bb340(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (DAT_01d67c88 != '\0') {
    if (DAT_01ef36fc == 1) {
      iVar1 = 2;
    }
    else if (DAT_01ef36fc == 2) {
      iVar1 = 1;
    }
    else {
      iVar1 = DAT_01ef36fc + -4;
      if (DAT_01ef36fc + -4 != 0) {
        iVar1 = param_2;
      }
    }
    if (iVar1 != *(int *)(param_1 + 0x310)) {
      *(int *)(param_1 + 0x310) = iVar1;
      uVar2 = FUN_00bb9a60(iVar1);
      FUN_00bbb280(uVar2);
      FUN_008a4940(&DAT_0211b0a8);
    }
  }
  return;
}



/* FUNCTION 14802 ; VA 0x008bb3c0 ; FUN_008bb3c0 */

void __thiscall FUN_008bb3c0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00d1e830(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 14803 ; VA 0x008bb470 ; FUN_008bb470 */

void __thiscall FUN_008bb470(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = thunk_FUN_00897b90(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 14804 ; VA 0x008bb520 ; FUN_008bb520 */

void __thiscall FUN_008bb520(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = 1;
  if (DAT_01d62d8c != '\0') {
    iVar1 = 0x40;
  }
  if ((iVar1 < param_2) && (iVar1 = param_2, 0x1fffbf < param_2)) {
    iVar1 = 0x1fffc0;
  }
  if (iVar1 != *(int *)(param_1 + 0x308)) {
    *(int *)(param_1 + 0x308) = iVar1;
    FUN_008a4940(&DAT_0211afb0);
    if ((DAT_01d62d8c != '\0') && (*(int *)(param_1 + 0x304) < *(int *)(param_1 + 0x308))) {
      *(int *)(param_1 + 0x304) = *(int *)(param_1 + 0x308);
      FUN_008a4940(&DAT_0211af78);
    }
  }
  return;
}



/* FUNCTION 14805 ; VA 0x008bb5a0 ; FUN_008bb5a0 */

void __thiscall FUN_008bb5a0(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x30c)) {
    *(int *)(param_1 + 0x30c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 14806 ; VA 0x008bb5d0 ; FUN_008bb5d0 */

void __thiscall FUN_008bb5d0(int param_1,int param_2)

{
  int iVar1;
  
  if (DAT_01d62d8c == '\0') {
    iVar1 = 1;
  }
  else {
    iVar1 = *(int *)(param_1 + 0x308);
  }
  if ((iVar1 < param_2) && (iVar1 = param_2, 0x1fffbf < param_2)) {
    iVar1 = 0x1fffc0;
  }
  if (iVar1 == *(int *)(param_1 + 0x304)) {
    return;
  }
  *(int *)(param_1 + 0x304) = iVar1;
  FUN_008a4940();
  return;
}



/* FUNCTION 14807 ; VA 0x008bb620 ; FUN_008bb620 */

undefined4 __thiscall FUN_008bb620(undefined4 *param_1,undefined4 param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puStack_8;
  
  puVar2 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar2 = (undefined4 *)*param_3;
  }
  puStack_8 = param_1;
  cVar1 = FUN_009cb180(puVar2,&param_3);
  if (cVar1 != '\0') {
    puStack_8 = param_3;
    (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&puStack_8);
    return 1;
  }
  return 0;
}



/* FUNCTION 14808 ; VA 0x008bb670 ; FUN_008bb670 */

undefined4 * __thiscall FUN_008bb670(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar6 = (undefined4 *)FUN_0060e0c0(auStack_c,param_2);
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 *)(param_1 + 0xc) = uVar3;
  piVar5 = *(int **)(param_1 + 0x10);
  *(undefined4 *)(param_1 + 0x10) = uVar4;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 2;
    iVar2 = *piVar1;
    puVar6 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar6 = (undefined4 *)(**(code **)(*piVar5 + 4))();
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_8 + 2;
    iVar2 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puVar6 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
    }
  }
  return puVar6;
}



/* FUNCTION 14809 ; VA 0x008bb6e0 ; FUN_008bb6e0 */

void __thiscall FUN_008bb6e0(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (DAT_01d6517b != '\0') {
    FUN_016774b0(DAT_01d6517b,"Setting terrain on workspace, %p",param_2);
  }
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
  uVar1 = *puVar5;
  uVar2 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x1c8) = uVar1;
  piVar3 = *(int **)(param_1 + 0x1cc);
  *(undefined4 *)(param_1 + 0x1cc) = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_8[1] + -1;
    piStack_8[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar3 = piStack_8 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  FUN_008a4940(&DAT_0211b4e8);
  if (param_2 != 0) {
    *(undefined *)(*(int *)(param_1 + 0x1c8) + 0x22) = 1;
    FUN_008a65e0(param_1,1);
  }
  return;
}



/* FUNCTION 14810 ; VA 0x008bb7c0 ; FUN_008bb7c0 */

void __thiscall FUN_008bb7c0(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x1b8)) {
    *(char *)(param_1 + 0x1b8) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 14811 ; VA 0x008bb7f0 ; FUN_008bb7f0 */

void __thiscall FUN_008bb7f0(int param_1,char param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  if ((DAT_01d62cfc != '\0') &&
     (iVar1 = *(int *)(param_1 + 0x1b4), *(char *)(iVar1 + 0x41) != param_2)) {
    iVar3 = FUN_008f7870(param_1);
    if ((iVar3 != 0) && (cVar2 = FUN_008ff0a0(), cVar2 == '\0')) {
      FUN_0086f2f0(2,"Cannot change this property during runtime.");
      return;
    }
    *(char *)(iVar1 + 0x41) = param_2;
    FUN_008a4940(&DAT_0211b2a8);
  }
  return;
}



/* FUNCTION 14812 ; VA 0x008bb860 ; FUN_008bb860 */

void __thiscall FUN_008bb860(int param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  
  pcVar1 = *(code **)(param_1 + 0x18);
  FUN_0054ef60(param_3);
  (*pcVar1)();
  return;
}



/* FUNCTION 14813 ; VA 0x008bb8a0 ; FUN_008bb8a0 */

void __thiscall FUN_008bb8a0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 14814 ; VA 0x008bb8d0 ; FUN_008bb8d0 */

void __thiscall FUN_008bb8d0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 14815 ; VA 0x008bb910 ; FUN_008bb910 */

void __thiscall FUN_008bb910(int param_1,undefined4 param_2,undefined8 *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 14816 ; VA 0x008bb950 ; FUN_008bb950 */

void __thiscall FUN_008bb950(int param_1,undefined4 param_2,undefined *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 14817 ; VA 0x008bb980 ; FUN_008bb980 */

void __thiscall FUN_008bb980(int *param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  
  pcVar1 = *(code **)(*param_1 + 0x48);
  uVar2 = FUN_00563070();
  (*pcVar1)(param_2,uVar2);
  return;
}



/* FUNCTION 14818 ; VA 0x008bb9b0 ; FUN_008bb9b0 */

void __thiscall FUN_008bb9b0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_008bbb80();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14819 ; VA 0x008bba00 ; FUN_008bba00 */

void __thiscall FUN_008bba00(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_008bbc30();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14820 ; VA 0x008bba50 ; FUN_008bba50 */

void __thiscall FUN_008bba50(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_008bbce0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14821 ; VA 0x008bbaa0 ; FUN_008bbaa0 */

void __thiscall FUN_008bbaa0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_008bbd90();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14822 ; VA 0x008bbaf0 ; FUN_008bbaf0 */

undefined * FUN_008bbaf0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdb8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee005c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee005c);
    if (DAT_01ee005c == -1) {
      uStack_8 = 0;
      FUN_00f35810();
      FUN_016f3654(&LAB_01881740);
      FUN_016f37bf(&DAT_01ee005c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edfff8;
}



/* FUNCTION 14823 ; VA 0x008bbb80 ; FUN_008bbb80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008bbb80(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdbb6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edff8c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edff8c);
    if (DAT_01edff8c == -1) {
      uStack_8 = 0;
      FUN_009ca470("InterpolationThrottlingMode");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01edff28 =
           RBX::Reflection::EnumDesc<enum_RBX::Workspace::InterpolationThrottlingMode>::vftable;
      FUN_009caf20(&DAT_01d62e24,3);
      FUN_016f3654(&LAB_01881760);
      FUN_016f37bf(&DAT_01edff8c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edff28;
}



/* FUNCTION 14824 ; VA 0x008bbc30 ; FUN_008bbc30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008bbc30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdbd6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edfebc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edfebc);
    if (DAT_01edfebc == -1) {
      uStack_8 = 0;
      FUN_009ca470("MeshPartHeads");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01edfe58 = RBX::Reflection::EnumDesc<enum_RBX::Workspace::MeshPartHeads>::vftable;
      FUN_009caf20(&DAT_01d62df4,3);
      FUN_016f3654(&LAB_01881780);
      FUN_016f37bf(&DAT_01edfebc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edfe58;
}



/* FUNCTION 14825 ; VA 0x008bbce0 ; FUN_008bbce0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008bbce0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdbf6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edff24) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edff24);
    if (DAT_01edff24 == -1) {
      uStack_8 = 0;
      FUN_009ca470("PhysicsSimulationRate");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01edfec0 = RBX::Reflection::EnumDesc<enum_RBX::PhysicsSimulationRate>::vftable;
      FUN_009caf20(&DAT_01d62e0c,3);
      FUN_016f3654(&LAB_018817a0);
      FUN_016f37bf(&DAT_01edff24);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edfec0;
}



/* FUNCTION 14826 ; VA 0x008bbd90 ; FUN_008bbd90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008bbd90(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdc16;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edfff4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edfff4);
    if (DAT_01edfff4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("StreamingPauseMode");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01edff90 = RBX::Reflection::EnumDesc<enum_RBX::Workspace::StreamingPauseMode>::vftable;
      FUN_009caf20(&DAT_01d62ddc,3);
      FUN_016f3654(&LAB_018817c0);
      FUN_016f37bf(&DAT_01edfff4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edff90;
}



/* FUNCTION 14827 ; VA 0x008bbe40 ; FUN_008bbe40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008bbe40(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0094) {
    FUN_016f3809(&DAT_01ee0094);
    if (DAT_01ee0094 == -1) {
      _DAT_01ee0088 = FUN_005c65e0;
      _DAT_01ee008c = FUN_005c65e0;
      _DAT_01ee0090 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee0094);
    }
  }
  return &DAT_01ee0088;
}



/* FUNCTION 14828 ; VA 0x008bbeb0 ; FUN_008bbeb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008bbeb0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee00a4) {
    FUN_016f3809(&DAT_01ee00a4);
    if (DAT_01ee00a4 == -1) {
      _DAT_01ee0098 = FUN_005c65e0;
      _DAT_01ee009c = FUN_005c65e0;
      _DAT_01ee00a0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee00a4);
    }
  }
  return &DAT_01ee0098;
}



/* FUNCTION 14829 ; VA 0x008bbf20 ; FUN_008bbf20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008bbf20(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee00c4) {
    FUN_016f3809(&DAT_01ee00c4);
    if (DAT_01ee00c4 == -1) {
      _DAT_01ee00b8 = FUN_005c65e0;
      _DAT_01ee00bc = FUN_005c65e0;
      _DAT_01ee00c0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee00c4);
    }
  }
  return &DAT_01ee00b8;
}



/* FUNCTION 14830 ; VA 0x008bbf90 ; FUN_008bbf90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008bbf90(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee00b4) {
    FUN_016f3809(&DAT_01ee00b4);
    if (DAT_01ee00b4 == -1) {
      _DAT_01ee00a8 = FUN_005c65e0;
      _DAT_01ee00ac = FUN_005c65e0;
      _DAT_01ee00b0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee00b4);
    }
  }
  return &DAT_01ee00a8;
}



/* FUNCTION 14831 ; VA 0x008bc000 ; FUN_008bc000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008bc000(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee00d4) {
    FUN_016f3809(&DAT_01ee00d4);
    if (DAT_01ee00d4 == -1) {
      _DAT_01ee00c8 = FUN_005c65e0;
      _DAT_01ee00cc = FUN_005c65e0;
      _DAT_01ee00d0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee00d4);
    }
  }
  return &DAT_01ee00c8;
}



/* FUNCTION 14832 ; VA 0x008bc070 ; FUN_008bc070 */

int * __fastcall FUN_008bc070(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdc38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00f30d70(0);
  FUN_00bbbe60();
  uVar3 = FUN_008accc0(param_1);
  piVar4 = (int *)FUN_0060dcd0(&iStack_18,uVar3);
  uStack_8 = 0;
  if (iStack_18 == 0) goto LAB_008bc1af;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("Frame",5);
  uStack_8._0_1_ = 1;
  piVar4 = (int *)FUN_0063a700(auStack_20,auStack_38,1);
  iVar8 = *piVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iVar8 == 0) {
LAB_008bc133:
    iVar8 = 0;
  }
  else {
    iVar2 = *(int *)(iVar8 + 0xc);
    iVar5 = FUN_00ea2500();
    piVar4 = (int *)(uint)*(ushort *)(iVar5 + 0x1da);
    if (piVar4 < (int *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)))
    goto LAB_008bc133;
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      piVar4 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar4 = (int *)(**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    piVar4 = (int *)FUN_01674ea0(uVar6,uVar7);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  if (iVar8 != 0) {
    piVar4 = (int *)FUN_00c7cda0(1);
  }
LAB_008bc1af:
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar8 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      piVar4 = (int *)(**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        piVar4 = (int *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 14833 ; VA 0x008bc1f0 ; FUN_008bc1f0 */

int __fastcall FUN_008bc1f0(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdc68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  uVar2 = FUN_008accc0(param_1);
  FUN_0060dcd0(&iStack_1c,uVar2);
  uStack_8 = 0;
  if (iStack_1c != 0) {
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    FUN_005542c0("Frame",5);
    uStack_8._0_1_ = 1;
    piVar3 = (int *)FUN_0063a700(auStack_24,auStack_3c,1);
    iVar7 = *piVar3;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if ((iVar7 == 0) ||
       (iVar1 = *(int *)(iVar7 + 0xc), iVar4 = FUN_00ea2500(),
       (uint)*(ushort *)(iVar4 + 0x1da) <
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
      iVar7 = 0;
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_20[1] + -1;
      piStack_20[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar1 = piStack_20[2] + -1;
        piStack_20[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (0xf < uStack_28) {
      uVar6 = uStack_28 + 1;
      uVar5 = auStack_3c[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_3c[0] - 4);
        uVar6 = uStack_28 + 0x24;
        if (0x1f < (auStack_3c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    if (iVar7 != 0) {
      FUN_00c7cda0(10);
    }
  }
  iVar7 = FUN_008bc530();
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_18 + 1;
    iVar1 = *piVar3;
    iVar7 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar7 = (**(code **)*piStack_18)();
      LOCK();
      piVar3 = piStack_18 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar7 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 14834 ; VA 0x008bc360 ; FUN_008bc360 */

void * __fastcall FUN_008bc360(int param_1)

{
  int *piVar1;
  void *pvVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac578;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 800);
  pvVar2 = ExceptionList;
  if (iVar3 != 0) {
    piVar4 = *(int **)(param_1 + 0x324);
    ExceptionList = &pvStack_10;
    if (piVar4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      iVar3 = *(int *)(param_1 + 800);
      piVar4 = *(int **)(param_1 + 0x324);
    }
    uStack_8 = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
    }
    pvVar2 = (void *)FUN_0151dac0(iVar3,piVar4,0,0);
    if (piVar4 != (int *)0x0) {
      piVar1 = piVar4 + 1;
      LOCK();
      iVar3 = *piVar1;
      pvVar2 = (void *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1;
        pvVar2 = (void *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          pvVar2 = (void *)(**(code **)(*piVar4 + 4))();
        }
      }
    }
    *(undefined4 *)(param_1 + 800) = 0;
    piVar4 = *(int **)(param_1 + 0x324);
    *(undefined4 *)(param_1 + 0x324) = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 1;
      iVar3 = *piVar1;
      pvVar2 = (void *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pvVar2 = (void *)(**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pvVar2 = (void *)(**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 14835 ; VA 0x008bc460 ; FUN_008bc460 */

undefined4 * FUN_008bc460(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = 1;
  param_1[1] = 0;
  param_1[2] = 0;
  FUN_0060e0c0(param_1 + 3,param_2);
  return param_1;
}



/* FUNCTION 14836 ; VA 0x008bc490 ; FUN_008bc490 */

int FUN_008bc490(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bd830;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00f284a0(param_1,&uStack_1c);
  FUN_00f29930(&uStack_1c);
  iVar3 = FUN_00777020();
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14837 ; VA 0x008bc530 ; FUN_008bc530 */

void __fastcall FUN_008bc530(int param_1)

{
  double dVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    if ((iVar4 != 0) && (iVar3 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
      iVar3 = FUN_005c8ac0();
    }
    if ((iVar3 != 0) &&
       (iVar4 = *(int *)(iVar3 + 0xc), iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      iVar4 = FUN_005f5170();
      goto LAB_008bc586;
    }
  }
  iVar4 = 0;
LAB_008bc586:
  cVar2 = FUN_0098c5a0(param_1,0);
  dVar1 = *(double *)(iVar4 + 0x70);
  if (cVar2 == '\0') {
    *(double *)(param_1 + 0x2e0) = dVar1;
  }
  else if ((NAN(dVar1) || NAN(*(double *)(param_1 + 0x2e0))) ==
           (dVar1 == *(double *)(param_1 + 0x2e0))) {
    *(double *)(param_1 + 0x2e0) = dVar1;
    FUN_008a4940(&DAT_0211af08);
    return;
  }
  return;
}



/* FUNCTION 14838 ; VA 0x008bc5d0 ; FUN_008bc5d0 */

void FUN_008bc5d0(undefined4 param_1)

{
  FUN_00bc2910(param_1);
  return;
}



/* FUNCTION 14839 ; VA 0x008bc5f0 ; FUN_008bc5f0 */

int __fastcall FUN_008bc5f0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdc88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0097bfc0(param_1);
  if (iVar3 != 0) {
    piVar4 = *(int **)(iVar3 + 0x498);
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = *(int **)(iVar3 + 0x498);
    }
    uStack_8 = 0;
    if (*(int *)(iVar3 + 0x494) != 0) {
      iVar3 = FUN_00e8a020(param_1);
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14840 ; VA 0x008bc690 ; FUN_008bc690 */

uint FUN_008bc690(undefined4 param_1)

{
  uint uVar1;
  
  uVar1 = FUN_008f78c0(param_1);
  if ((uVar1 != 0) && (uVar1 != 0xfffffff4)) {
    uVar1 = FUN_00562f00();
    if ((uVar1 != 0) &&
       ((uVar1 = *(uint *)(uVar1 + 0x31c), uVar1 == 2 || ((DAT_01d62dbc != '\0' && (uVar1 == 0))))))
    {
      return CONCAT31((int3)(uVar1 >> 8),1);
    }
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 14841 ; VA 0x008bc6e0 ; FUN_008bc6e0 */

void __thiscall FUN_008bc6e0(int param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  FUN_0087ccc0();
  *(undefined4 *)(param_3 + 0x18) = uVar1;
  *(undefined4 *)(param_3 + 0x14) = 5;
  return;
}



/* FUNCTION 14842 ; VA 0x008bc710 ; FUN_008bc710 */

void __thiscall FUN_008bc710(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  FUN_00d85940(uVar1);
  FUN_008a71e0();
  return;
}



/* FUNCTION 14843 ; VA 0x008bc760 ; FUN_008bc760 */

undefined4 * __thiscall FUN_008bc760(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0088d190();
  *param_1 = uVar1;
  param_1[1] = 0;
  FUN_0054ef60(param_2);
  uVar1 = FUN_00630cf0();
  param_1[1] = uVar1;
  return param_1;
}



/* FUNCTION 14844 ; VA 0x008bc7a0 ; FUN_008bc7a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008bc7a0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_00d88470();
  *param_1 = uVar1;
  param_1[1] = 0;
  FUN_00d88580(param_2);
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee047c) {
    FUN_016f3809(&DAT_01ee047c);
    if (DAT_01ee047c == -1) {
      _DAT_01ee0470 = FUN_008c9370;
      _DAT_01ee0474 = FUN_008c9370;
      DAT_01ee0478 = FUN_008ca540;
      FUN_016f37bf(&DAT_01ee047c);
    }
  }
  param_1[1] = &DAT_01ee0470;
  return param_1;
}



/* FUNCTION 14845 ; VA 0x008bc840 ; FUN_008bc840 */

undefined4 * __thiscall FUN_008bc840(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  int *in_stack_00000054;
  uint in_stack_0000005c;
  undefined auStack_114 [80];
  int *piStack_c4;
  uint uStack_bc;
  undefined auStack_b4 [32];
  undefined auStack_94 [80];
  int *piStack_44;
  uint uStack_3c;
  undefined auStack_34 [32];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bdcbe;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008c0e00(&stack0x00000004);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_008c0e00(auStack_114);
  uStack_8._0_1_ = 2;
  FUN_008c0e00(auStack_94);
  ppuVar4 = &PTR_FUN_01929934;
  cVar3 = FUN_008bef20();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_3c != 0) {
    if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_3c & 0xfffffffe))(auStack_34,auStack_34,2);
    }
    uStack_3c = 0;
  }
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_44[2] + -1;
    piStack_44[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_44 + 4))();
    }
  }
  FUN_00637950();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_bc != 0) {
    if (((uStack_bc & 1) == 0) && (*(code **)(uStack_bc & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_bc & 0xfffffffe))(auStack_b4,auStack_b4,2);
    }
    uStack_bc = 0;
  }
  if (piStack_c4 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c4[2] + -1;
    piStack_c4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c4 + 4))();
    }
  }
  FUN_00637950();
  uStack_8 = 5;
  if (in_stack_0000005c != 0) {
    if (((in_stack_0000005c & 1) == 0) &&
       (*(code **)(in_stack_0000005c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000005c & 0xfffffffe))(&stack0x00000064,&stack0x00000064,2);
    }
    in_stack_0000005c = 0;
  }
  if (in_stack_00000054 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000054 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000054 + 4))();
    }
  }
  FUN_00637950();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14846 ; VA 0x008bc9d0 ; FUN_008bc9d0 */

undefined4 * __thiscall FUN_008bc9d0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_94;
  int iStack_90;
  undefined auStack_8c [24];
  undefined4 uStack_74;
  int iStack_70;
  undefined auStack_6c [24];
  undefined4 uStack_54;
  int iStack_50;
  undefined auStack_4c [24];
  undefined4 uStack_34;
  int iStack_30;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bdd32;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_94;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
    UNLOCK();
  }
  uStack_94 = param_2;
  iStack_90 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x0000000c);
  puStack_14 = &uStack_74;
  if (iStack_90 != 0) {
    LOCK();
    *(int *)(iStack_90 + 8) = *(int *)(iStack_90 + 8) + 1;
    UNLOCK();
  }
  uStack_74 = uStack_94;
  iStack_70 = iStack_90;
  uStack_8 = 3;
  FUN_0054ef60(auStack_8c);
  puStack_14 = &uStack_34;
  if (iStack_70 != 0) {
    LOCK();
    *(int *)(iStack_70 + 8) = *(int *)(iStack_70 + 8) + 1;
    UNLOCK();
  }
  uStack_34 = uStack_74;
  iStack_30 = iStack_70;
  uStack_8 = 5;
  FUN_0054ef60(auStack_6c);
  uStack_8 = 6;
  cVar2 = FUN_00585a40(&uStack_34);
  if (cVar2 == '\0') {
    puStack_14 = &uStack_54;
    if (iStack_30 != 0) {
      LOCK();
      *(int *)(iStack_30 + 8) = *(int *)(iStack_30 + 8) + 1;
      UNLOCK();
    }
    uStack_54 = uStack_34;
    iStack_50 = iStack_30;
    uStack_8 = 7;
    FUN_0054ef60(auStack_2c);
    uStack_8 = 8;
    puVar3 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8 = 9;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_50 != 0) {
        LOCK();
        *(int *)(iStack_50 + 8) = *(int *)(iStack_50 + 8) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_54;
      puVar3[1] = iStack_50;
      uStack_8 = 10;
      FUN_0054ef60(auStack_4c);
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_019298a4;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14847 ; VA 0x008bcbe0 ; FUN_008bcbe0 */

undefined4 * __thiscall FUN_008bcbe0(undefined4 *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000018;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  int iStack_54;
  int *piStack_50;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bdd58;
  pvStack_10 = ExceptionList;
  piStack_50 = &param_2;
  uStack_8 = 0;
  iStack_54 = 0x8bcc15;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  piStack_50 = aiStack_44;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_54 = 0x8bcc2b;
  FUN_0054ef60();
  piStack_50 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_68;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_019298ac;
  cVar1 = FUN_008bf090();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_50 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_50 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0x8bcd02;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x8bcc86;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_30) {
    piStack_50 = (int *)(uStack_30 + 1);
    iVar2 = aiStack_44[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      piStack_50 = (int *)(uStack_30 + 0x24);
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0x8bcd07;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x8bccb6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000018) {
    piStack_50 = (int *)(in_stack_00000018 + 1);
    iVar2 = param_2;
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(param_2 + -4);
      piStack_50 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)&UNK_008bcd0c;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x8bcce6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14848 ; VA 0x008bcd10 ; FUN_008bcd10 */

undefined4 * __thiscall FUN_008bcd10(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01929964;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 14849 ; VA 0x008bce40 ; FUN_008bce40 */

undefined4 * __thiscall FUN_008bce40(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  int *in_stack_00000050;
  uint in_stack_00000054;
  undefined auStack_104 [76];
  int *piStack_b8;
  uint uStack_b4;
  undefined auStack_ac [32];
  undefined auStack_8c [76];
  int *piStack_40;
  uint uStack_3c;
  undefined auStack_34 [32];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bdd8e;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008c1700(&stack0x00000004);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_008c1700(auStack_104);
  uStack_8._0_1_ = 2;
  FUN_008c1700(auStack_8c);
  ppuVar4 = &PTR_FUN_0192993c;
  cVar3 = FUN_008bf200();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_3c != 0) {
    if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_3c & 0xfffffffe))(auStack_34,auStack_34,2);
    }
    uStack_3c = 0;
  }
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_40[2] + -1;
    piStack_40[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_40 + 4))();
    }
  }
  FUN_00637950();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_b4 != 0) {
    if (((uStack_b4 & 1) == 0) && (*(code **)(uStack_b4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_b4 & 0xfffffffe))(auStack_ac,auStack_ac,2);
    }
    uStack_b4 = 0;
  }
  if (piStack_b8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_b8[2] + -1;
    piStack_b8[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_b8 + 4))();
    }
  }
  FUN_00637950();
  uStack_8 = 5;
  if (in_stack_00000054 != 0) {
    if (((in_stack_00000054 & 1) == 0) &&
       (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000054 & 0xfffffffe))(&stack0x0000005c,&stack0x0000005c,2);
    }
    in_stack_00000054 = 0;
  }
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000050 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000050 + 4))();
    }
  }
  FUN_00637950();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14850 ; VA 0x008bcfd0 ; FUN_008bcfd0 */

undefined4 * __thiscall FUN_008bcfd0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_94;
  int iStack_90;
  undefined auStack_8c [24];
  undefined4 uStack_74;
  int iStack_70;
  undefined auStack_6c [24];
  undefined4 uStack_54;
  int iStack_50;
  undefined auStack_4c [24];
  undefined4 uStack_34;
  int iStack_30;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bde02;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_94;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
    UNLOCK();
  }
  uStack_94 = param_2;
  iStack_90 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x0000000c);
  puStack_14 = &uStack_74;
  if (iStack_90 != 0) {
    LOCK();
    *(int *)(iStack_90 + 8) = *(int *)(iStack_90 + 8) + 1;
    UNLOCK();
  }
  uStack_74 = uStack_94;
  iStack_70 = iStack_90;
  uStack_8 = 3;
  FUN_0054ef60(auStack_8c);
  puStack_14 = &uStack_34;
  if (iStack_70 != 0) {
    LOCK();
    *(int *)(iStack_70 + 8) = *(int *)(iStack_70 + 8) + 1;
    UNLOCK();
  }
  uStack_34 = uStack_74;
  iStack_30 = iStack_70;
  uStack_8 = 5;
  FUN_0054ef60(auStack_6c);
  uStack_8 = 6;
  cVar2 = FUN_00585a40(&uStack_34);
  if (cVar2 == '\0') {
    puStack_14 = &uStack_54;
    if (iStack_30 != 0) {
      LOCK();
      *(int *)(iStack_30 + 8) = *(int *)(iStack_30 + 8) + 1;
      UNLOCK();
    }
    uStack_54 = uStack_34;
    iStack_50 = iStack_30;
    uStack_8 = 7;
    FUN_0054ef60(auStack_2c);
    uStack_8 = 8;
    puVar3 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8 = 9;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_50 != 0) {
        LOCK();
        *(int *)(iStack_50 + 8) = *(int *)(iStack_50 + 8) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_54;
      puVar3[1] = iStack_50;
      uStack_8 = 10;
      FUN_0054ef60(auStack_4c);
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_01929924;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14851 ; VA 0x008bd1e0 ; FUN_008bd1e0 */

undefined4 * __thiscall FUN_008bd1e0(undefined4 *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000018;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  int iStack_54;
  int *piStack_50;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bde28;
  pvStack_10 = ExceptionList;
  piStack_50 = &param_2;
  uStack_8 = 0;
  iStack_54 = 0x8bd215;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  piStack_50 = aiStack_44;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_54 = 0x8bd22b;
  FUN_0054ef60();
  piStack_50 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_68;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_0192991c;
  cVar1 = FUN_008bf360();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_50 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_50 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0x8bd302;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x8bd286;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_30) {
    piStack_50 = (int *)(uStack_30 + 1);
    iVar2 = aiStack_44[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      piStack_50 = (int *)(uStack_30 + 0x24);
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0x8bd307;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x8bd2b6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000018) {
    piStack_50 = (int *)(in_stack_00000018 + 1);
    iVar2 = param_2;
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(param_2 + -4);
      piStack_50 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)&UNK_008bd30c;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x8bd2e6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14852 ; VA 0x008bd310 ; FUN_008bd310 */

undefined4 * __thiscall FUN_008bd310(undefined4 *param_1,uint param_2)

{
  char cVar1;
  undefined **ppuVar2;
  int in_stack_00000028;
  uint auStack_1f4 [2];
  undefined auStack_1ec [28];
  int iStack_1d0;
  undefined auStack_1cc [200];
  uint auStack_104 [2];
  undefined auStack_fc [28];
  int iStack_e0;
  undefined auStack_dc [200];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bde5e;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008c1ae0(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_008c1ae0(auStack_1f4);
  uStack_8._0_1_ = 2;
  FUN_008c1ae0(auStack_104);
  ppuVar2 = &PTR_FUN_0192995c;
  cVar1 = FUN_008bf4d0();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (iStack_e0 != 0) {
    (**(code **)(iStack_e0 + 8))(auStack_dc);
  }
  uStack_8._0_1_ = 4;
  if (auStack_104[0] != 0) {
    if (((auStack_104[0] & 1) == 0) && (*(code **)(auStack_104[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_104[0] & 0xfffffffe))(auStack_fc,auStack_fc,2);
    }
    auStack_104[0] = 0;
  }
  uStack_8._0_1_ = 5;
  if (iStack_1d0 != 0) {
    (**(code **)(iStack_1d0 + 8))(auStack_1cc);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (auStack_1f4[0] != 0) {
    if (((auStack_1f4[0] & 1) == 0) && (*(code **)(auStack_1f4[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_1f4[0] & 0xfffffffe))(auStack_1ec,auStack_1ec,2);
    }
    auStack_1f4[0] = 0;
  }
  uStack_8 = 7;
  if (in_stack_00000028 != 0) {
    (**(code **)(in_stack_00000028 + 8))(&stack0x0000002c);
  }
  uStack_8 = 8;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14853 ; VA 0x008bd490 ; FUN_008bd490 */

undefined4 * __thiscall
FUN_008bd490(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bde88;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x8bd4fd);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x8bd549);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01929954;
  cStack_11 = FUN_008bf6c0();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x8bd5d3);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x8bd60e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x8bd63c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14854 ; VA 0x008bd660 ; FUN_008bd660 */

undefined4 __thiscall FUN_008bd660(undefined4 param_1,undefined4 param_2)

{
  bool bVar1;
  char cVar2;
  undefined auStack_1dc [64];
  undefined4 uStack_19c;
  undefined auStack_194 [64];
  undefined4 uStack_154;
  undefined auStack_14c [64];
  undefined4 uStack_10c;
  undefined auStack_104 [64];
  undefined4 uStack_c4;
  undefined auStack_bc [64];
  undefined4 auStack_7c [2];
  undefined auStack_74 [64];
  undefined **ppuStack_34;
  undefined4 *apuStack_2c [6];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bdefe;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008c1da0(&stack0x0000000c);
  uStack_19c = param_2;
  uStack_8._0_1_ = 1;
  FUN_008c1da0(auStack_1dc);
  uStack_154 = uStack_19c;
  uStack_8._0_1_ = 2;
  ppuStack_34 = (undefined **)0x0;
  FUN_008c1da0(auStack_194);
  uStack_10c = uStack_154;
  uStack_8._0_1_ = 3;
  FUN_008c1da0(auStack_14c);
  auStack_7c[0] = uStack_10c;
  uStack_8._0_1_ = 4;
  FUN_008c1da0(auStack_104);
  uStack_8._0_1_ = 5;
  cVar2 = FUN_00585a40(auStack_7c);
  if (cVar2 == '\0') {
    uStack_c4 = auStack_7c[0];
    FUN_008c1da0(auStack_74);
    uStack_8._0_1_ = 6;
    apuStack_2c[0] = (undefined4 *)FUN_01674e20(0x48);
    uStack_8._0_1_ = 7;
    puStack_14 = apuStack_2c[0];
    if (apuStack_2c[0] == (undefined4 *)0x0) {
      apuStack_2c[0] = (undefined4 *)0x0;
    }
    else {
      *apuStack_2c[0] = uStack_c4;
      FUN_008c1da0(auStack_bc);
    }
    FUN_008c3d70();
    FUN_008c3d70();
    bVar1 = true;
  }
  else {
    FUN_008c3d70();
    bVar1 = false;
  }
  FUN_008c3d70();
  ppuStack_34 = &PTR_FUN_0192996c;
  if (!bVar1) {
    ppuStack_34 = (undefined **)0x0;
  }
  FUN_008c3d70();
  FUN_008c3d70();
  FUN_008c3d70();
  uStack_8._0_1_ = 8;
  FUN_008da7c0(param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (((ppuStack_34 != (undefined **)0x0) && (((uint)ppuStack_34 & 1) == 0)) &&
     (*(code **)((uint)ppuStack_34 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)((uint)ppuStack_34 & 0xfffffffe))(apuStack_2c,apuStack_2c,2);
  }
  FUN_008c3d70();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14855 ; VA 0x008bd840 ; FUN_008bd840 */

undefined * FUN_008bd840(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdf1c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee01e8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee03f8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee03f8);
      if (DAT_01ee03f8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ContentProvider",1,uStack_20,0,0,0x11,0,0);
        FUN_016f3654(&LAB_01882620);
        FUN_016f37bf(&DAT_01ee03f8);
      }
    }
    DAT_01ee01e8 = &DAT_01ee01f0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee01e8;
}



/* FUNCTION 14856 ; VA 0x008bd920 ; FUN_008bd920 */

void FUN_008bd920(void)

{
  int iVar1;
  
  if (DAT_01ee03fc == 0) {
    iVar1 = FUN_008bd840();
    DAT_01ee03fc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 14857 ; VA 0x008bd940 ; FUN_008bd940 */

int FUN_008bd940(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdf30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008c74c0(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  uVar1 = param_4[1];
  uVar2 = param_4[2];
  uVar3 = param_4[3];
  *(undefined4 *)(iVar4 + 0x20) = *param_4;
  *(undefined4 *)(iVar4 + 0x24) = uVar1;
  *(undefined4 *)(iVar4 + 0x28) = uVar2;
  *(undefined4 *)(iVar4 + 0x2c) = uVar3;
  uVar1 = param_4[5];
  uVar2 = param_4[6];
  uVar3 = param_4[7];
  *(undefined4 *)(iVar4 + 0x30) = param_4[4];
  *(undefined4 *)(iVar4 + 0x34) = uVar1;
  *(undefined4 *)(iVar4 + 0x38) = uVar2;
  *(undefined4 *)(iVar4 + 0x3c) = uVar3;
  uVar1 = param_4[9];
  uVar2 = param_4[10];
  uVar3 = param_4[0xb];
  *(undefined4 *)(iVar4 + 0x40) = param_4[8];
  *(undefined4 *)(iVar4 + 0x44) = uVar1;
  *(undefined4 *)(iVar4 + 0x48) = uVar2;
  *(undefined4 *)(iVar4 + 0x4c) = uVar3;
  *(undefined8 *)(iVar4 + 0x50) = *(undefined8 *)(param_4 + 0xc);
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 14858 ; VA 0x008bd9bf ; Catch_All@008bd9bf */

void Catch_All_008bd9bf(void)

{
  int unaff_EBP;
  
  FUN_0061a4a0(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14859 ; VA 0x008bd9e0 ; FUN_008bd9e0 */

void FUN_008bd9e0(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  
  if (param_1 != param_2) {
    puVar6 = param_1 + 0xb;
    do {
      uVar2 = *puVar6;
      if (0xf < uVar2) {
        uVar3 = puVar6[-5];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) goto LAB_008bda8a;
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-1] = 0;
      *puVar6 = 0xf;
      *(undefined *)(puVar6 + -5) = 0;
      uVar2 = puVar6[-6];
      if (0xf < uVar2) {
        uVar3 = puVar6[-0xb];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) {
LAB_008bda8a:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-7] = 0;
      puVar6[-6] = 0xf;
      *(undefined *)(puVar6 + -0xb) = 0;
      puVar1 = puVar6 + 1;
      puVar6 = puVar6 + 0xc;
    } while (puVar1 != param_2);
  }
  return;
}



/* FUNCTION 14860 ; VA 0x008bda90 ; FUN_008bda90 */

int __thiscall FUN_008bda90(int *param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdf40;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar2 = (param_1[1] - *param_1) / 0x1c;
  if (iVar2 == 0x9249249) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - *param_1) / 0x1c;
  uVar7 = uVar1;
  if ((uVar3 <= 0x9249249 - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0072e960(uVar7);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0x1c) * 0x1c;
  iVar6 = iVar5 + iVar4;
  FUN_0054ef60(param_3);
  *(undefined4 *)(iVar6 + 0x18) = *(undefined4 *)(param_3 + 0x18);
  if (param_2 == param_1[1]) {
    FUN_008bed40(*param_1,param_1[1],iVar4,param_1);
  }
  else {
    FUN_008bed40(*param_1,param_2,iVar4,param_1);
    FUN_008bed40(param_2,param_1[1],iVar6 + 0x1c,param_1);
  }
  FUN_008c74f0(iVar4,iVar2 + 1,uVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 14861 ; VA 0x008bdbd3 ; Catch_All@008bdbd3 */

void Catch_All_008bdbd3(void)

{
  int unaff_EBP;
  
  FUN_008c7730(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x14));
  FUN_007c60b0(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x18));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14862 ; VA 0x008bdc00 ; FUN_008bdc00 */

int __thiscall FUN_008bdc00(uint *param_1,uint param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdf5b;
  pvStack_10 = ExceptionList;
  uVar8 = *param_1;
  iVar2 = (int)(param_1[1] - *param_1) / 0x60;
  if (iVar2 == 0x2aaaaaa) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar2 + 1;
  uVar3 = (int)(param_1[2] - *param_1) / 0x60;
  uVar7 = uVar5;
  if ((uVar3 <= 0x2aaaaaa - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar5)) {
    uVar7 = uVar5;
  }
  uVar5 = uVar7 * 0x60;
  if (uVar7 < 0x2aaaaab) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_008bdcb7;
    if (uVar5 == 0) {
      uVar7 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_008bdcb7:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_008bde5d;
    uVar7 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar4;
  }
  iVar4 = ((int)(param_2 - uVar8) / 0x60) * 0x60;
  puVar1 = (undefined4 *)(iVar4 + uVar7);
  uStack_8 = 0;
  *puVar1 = *param_3;
  puVar1[1] = param_3[1];
  FUN_0054ef60(param_3 + 2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_3 + 8);
  puVar1[0xe] = param_3[0xe];
  *(undefined8 *)(puVar1 + 0x10) = *(undefined8 *)(param_3 + 0x10);
  *(undefined8 *)(puVar1 + 0x12) = *(undefined8 *)(param_3 + 0x12);
  *(undefined8 *)(puVar1 + 0x14) = *(undefined8 *)(param_3 + 0x14);
  puVar1[0x16] = param_3[0x16];
  if (param_2 == param_1[1]) {
    FUN_008bedc0(*param_1,param_1[1],uVar7,param_1);
  }
  else {
    FUN_008bedc0(*param_1,param_2,uVar7,param_1);
    FUN_008bedc0(param_2,param_1[1],puVar1 + 0x18,param_1);
  }
  uVar8 = *param_1;
  if (uVar8 != 0) {
    uVar3 = param_1[1];
    if (uVar8 != uVar3) {
      do {
        FUN_00651cc0();
        uVar8 = uVar8 + 0x60;
      } while (uVar8 != uVar3);
      uVar8 = *param_1;
    }
    uVar6 = ((int)(param_1[2] - uVar8) / 0x60) * 0x60;
    uVar3 = uVar8;
    if (0xfff < uVar6) {
      uVar3 = *(uint *)(uVar8 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar8 - uVar3) - 4) {
LAB_008bde5d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = (iVar2 * 3 + 3) * 0x20 + uVar7;
  param_1[2] = uVar5 + uVar7;
  ExceptionList = pvStack_10;
  return *param_1 + iVar4;
}



/* FUNCTION 14863 ; VA 0x008bde34 ; Catch_All@008bde34 */

void Catch_All_008bde34(void)

{
  int unaff_EBP;
  
  FUN_008c7750(*(undefined4 *)(unaff_EBP + -0x28),*(undefined4 *)(unaff_EBP + -0x28));
  FUN_006c96a0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x18));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14864 ; VA 0x008bde70 ; FUN_008bde70 */

int __thiscall FUN_008bde70(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdf78;
  pvStack_10 = ExceptionList;
  uVar7 = *param_1;
  iVar4 = (int)(param_1[1] - uVar7) / 0x58;
  if (iVar4 == 0x2e8ba2e) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar5 = (int)(param_1[2] - uVar7) / 0x58;
  uVar2 = uVar1;
  if ((uVar5 <= 0x2e8ba2e - (uVar5 >> 1)) && (uVar2 = (uVar5 >> 1) + uVar5, uVar2 < uVar1)) {
    uVar2 = uVar1;
  }
  uVar5 = uVar2 * 0x58;
  if (uVar2 < 0x2e8ba2f) {
    if (0xfff < uVar5) goto LAB_008bdf29;
    if (uVar5 == 0) {
      uVar5 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_008bdf29:
    uVar3 = uVar5 + 0x23;
    if (uVar3 <= uVar5) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_008be0a4;
    uVar5 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar4;
  }
  iVar4 = ((int)(param_2 - uVar7) / 0x58) * 0x58;
  uStack_8 = 0;
  FUN_008c2f20(param_3);
  uVar7 = param_1[1];
  if (param_2 == uVar7) {
    uVar3 = *param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    for (; uVar3 != uVar7; uVar3 = uVar3 + 0x58) {
      FUN_008c2f20(uVar3);
    }
  }
  else {
    FUN_008c7cf0(*param_1,param_2,uVar5);
    FUN_008c7cf0(param_2,param_1[1],iVar4 + uVar5 + 0x58);
  }
  uVar7 = *param_1;
  if (uVar7 != 0) {
    uVar3 = param_1[1];
    if (uVar7 != uVar3) {
      do {
        FUN_008c4380();
        uVar7 = uVar7 + 0x58;
      } while (uVar7 != uVar3);
      uVar7 = *param_1;
    }
    uVar6 = ((int)(param_1[2] - uVar7) / 0x58) * 0x58;
    uVar3 = uVar7;
    if (0xfff < uVar6) {
      uVar3 = *(uint *)(uVar7 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar7 - uVar3) - 4) {
LAB_008be0a4:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar6);
  }
  *param_1 = uVar5;
  param_1[1] = uVar1 * 0x58 + uVar5;
  param_1[2] = uVar2 * 0x58 + uVar5;
  ExceptionList = pvStack_10;
  return *param_1 + iVar4;
}



/* FUNCTION 14865 ; VA 0x008be07a ; Catch_All@008be07a */

void Catch_All_008be07a(void)

{
  int unaff_EBP;
  
  FUN_008c7780(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x20));
  FUN_0061a4a0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14866 ; VA 0x008be0b0 ; FUN_008be0b0 */

int __thiscall FUN_008be0b0(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdf90;
  pvStack_10 = ExceptionList;
  uVar1 = *param_1;
  iVar3 = (int)(param_1[1] - uVar1) / 0x18;
  if (iVar3 == 0xaaaaaaa) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar3 + 1;
  uVar4 = (int)(param_1[2] - uVar1) / 0x18;
  uVar7 = uVar6;
  if ((uVar4 <= 0xaaaaaaa - (uVar4 >> 1)) && (uVar7 = (uVar4 >> 1) + uVar4, uVar7 < uVar6)) {
    uVar7 = uVar6;
  }
  uVar4 = uVar7 * 0x18;
  if (uVar7 < 0xaaaaaab) {
    uVar7 = uVar4;
    if (0xfff < uVar4) goto LAB_008be16b;
    if (uVar4 == 0) {
      uVar7 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_008be16b:
    uVar2 = uVar7 + 0x23;
    if (uVar2 <= uVar7) {
      uVar2 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_008be2ae;
    uVar7 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar3;
  }
  uStack_8 = 0;
  iVar3 = ((int)(param_2 - uVar1) / 0x18) * 0x18;
  FUN_0054ef60(param_3);
  if (param_2 == param_1[1]) {
    FUN_0055c6d0(*param_1,param_1[1],uVar7,param_1);
  }
  else {
    FUN_0055c6d0(*param_1,param_2,uVar7,param_1);
    FUN_0055c6d0(param_2,param_1[1],iVar3 + uVar7 + 0x18,param_1);
  }
  if (*param_1 != 0) {
    FUN_00559570(*param_1,param_1[1],param_1);
    uVar1 = *param_1;
    uVar5 = ((int)(param_1[2] - uVar1) / 0x18) * 0x18;
    uVar2 = uVar1;
    if (0xfff < uVar5) {
      uVar2 = *(uint *)(uVar1 - 4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uVar1 - uVar2) - 4) {
LAB_008be2ae:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar5);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + uVar6 * 0x18;
  param_1[2] = uVar4 + uVar7;
  ExceptionList = pvStack_10;
  return *param_1 + iVar3;
}



/* FUNCTION 14867 ; VA 0x008be285 ; Catch_All@008be285 */

void Catch_All_008be285(void)

{
  int unaff_EBP;
  
  FUN_005762c0(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_0057d2f0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14868 ; VA 0x008be2c0 ; FUN_008be2c0 */

int __thiscall FUN_008be2c0(uint *param_1,uint param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  
  uVar8 = *param_1;
  iVar6 = (int)(param_1[1] - *param_1) / 0x1c;
  if (iVar6 == 0x9249249) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar10 = iVar6 + 1;
  uVar7 = (int)(param_1[2] - *param_1) / 0x1c;
  uVar11 = uVar10;
  if ((uVar7 <= 0x9249249 - (uVar7 >> 1)) && (uVar11 = (uVar7 >> 1) + uVar7, uVar11 < uVar10)) {
    uVar11 = uVar10;
  }
  uVar7 = uVar11 * 0x1c;
  if (uVar11 < 0x924924a) {
    uVar11 = uVar7;
    if (0xfff < uVar7) goto LAB_008be364;
    if (uVar7 == 0) {
      uVar11 = 0;
    }
    else {
      uVar11 = FUN_01674e20(uVar7);
    }
  }
  else {
    uVar11 = 0xffffffff;
LAB_008be364:
    uVar5 = uVar11 + 0x23;
    if (uVar5 <= uVar11) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_008be4ab;
    uVar11 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar11 - 4) = iVar6;
  }
  iVar6 = ((int)(param_2 - uVar8) / 0x1c) * 0x1c;
  *(undefined4 *)(iVar6 + uVar11) = *param_3;
  *(undefined4 *)(iVar6 + 0x14 + uVar11) = 0;
  *(undefined4 *)(iVar6 + 0x18 + uVar11) = 0;
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  uVar4 = param_3[4];
  puVar1 = (undefined4 *)(iVar6 + 4 + uVar11);
  *puVar1 = param_3[1];
  puVar1[1] = uVar2;
  puVar1[2] = uVar3;
  puVar1[3] = uVar4;
  *(undefined8 *)(iVar6 + 0x14 + uVar11) = *(undefined8 *)(param_3 + 5);
  param_3[5] = 0;
  param_3[6] = 0xf;
  *(undefined *)(param_3 + 1) = 0;
  uVar5 = param_1[1];
  uVar8 = *param_1;
  uVar9 = uVar11;
  if (param_2 != uVar5) {
    FUN_008beea0(uVar8,param_2,uVar11,param_1);
    uVar5 = param_1[1];
    uVar9 = iVar6 + 0x1c + uVar11;
    uVar8 = param_2;
  }
  FUN_008beea0(uVar8,uVar5,uVar9,param_1);
  if (*param_1 != 0) {
    FUN_007be6b0(*param_1,param_1[1],param_1);
    uVar8 = *param_1;
    uVar9 = ((int)(param_1[2] - uVar8) / 0x1c) * 0x1c;
    uVar5 = uVar8;
    if (0xfff < uVar9) {
      uVar5 = *(uint *)(uVar8 - 4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uVar8 - uVar5) - 4) {
LAB_008be4ab:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar9);
  }
  *param_1 = uVar11;
  param_1[1] = uVar11 + uVar10 * 0x1c;
  param_1[2] = uVar7 + uVar11;
  return *param_1 + iVar6;
}



/* FUNCTION 14869 ; VA 0x008be4c0 ; FUN_008be4c0 */

int __thiscall FUN_008be4c0(int *param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdfa0;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  iVar2 = param_1[1] - iVar3 >> 6;
  if (iVar2 == 0x3ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar4 = param_1[2] - iVar3 >> 6;
  uVar5 = uVar1;
  if ((uVar4 <= 0x3ffffff - (uVar4 >> 1)) && (uVar5 = (uVar4 >> 1) + uVar4, uVar5 < uVar1)) {
    uVar5 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008c8200(uVar5);
  uVar4 = param_2 - iVar3 & 0xffffffc0;
  iVar3 = iVar2 + uVar4;
  uStack_8 = 0;
  FUN_008bfd20(param_1,iVar3,param_3);
  if (param_2 == param_1[1]) {
    FUN_008c7ee0(*param_1,param_1[1],iVar2);
  }
  else {
    FUN_008c7e20(*param_1,param_2,iVar2);
    FUN_008c7e20(param_2,param_1[1],iVar3 + 0x40);
  }
  FUN_008c7590(iVar2,uVar1,uVar5);
  ExceptionList = pvStack_10;
  return *param_1 + uVar4;
}



/* FUNCTION 14870 ; VA 0x008be5c2 ; Catch_All@008be5c2 */

void Catch_All_008be5c2(void)

{
  int unaff_EBP;
  
  FUN_008c77b0(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0089eda0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14871 ; VA 0x008be5f0 ; FUN_008be5f0 */

void __thiscall FUN_008be5f0(float *param_1,float *param_2,undefined4 param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  char cVar3;
  uint uVar4;
  float fVar5;
  float fVar6;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bdfb0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pfStack_18 = param_1;
  uVar4 = FUN_009cc8a0(param_3);
  fVar5 = param_1[1];
  uVar4 = (uint)param_1[6] & uVar4;
  if (*(float *)((int)param_1[3] + uVar4 * 8) != fVar5) {
    fVar5 = **(float **)((int)param_1[3] + 4 + uVar4 * 8);
  }
  do {
    fVar6 = param_1[3];
    if (fVar5 == *(float *)((int)fVar6 + uVar4 * 8)) {
      pfStack_1c = param_4;
      fVar1 = *param_4;
      if (fVar5 != fVar1) {
        *(float *)param_4[1] = fVar1;
        **(float **)((int)fVar1 + 4) = fVar5;
        **(undefined4 **)((int)fVar5 + 4) = param_4;
        fVar6 = *(float *)((int)fVar5 + 4);
        *(undefined4 *)((int)fVar5 + 4) = *(undefined4 *)((int)fVar1 + 4);
        *(float *)((int)fVar1 + 4) = param_4[1];
        param_4[1] = fVar6;
        fVar6 = param_1[3];
      }
      fVar1 = *(float *)((int)fVar6 + uVar4 * 8);
      if (fVar1 == param_1[1]) {
        *(float **)((int)fVar6 + uVar4 * 8) = param_4;
        *(float **)((int)param_1[3] + 4 + uVar4 * 8) = param_4;
      }
      else if (fVar1 == fVar5) {
        *(float **)((int)fVar6 + uVar4 * 8) = param_4;
      }
      else {
        pfVar2 = (float *)**(undefined4 **)((int)fVar6 + 4 + uVar4 * 8);
        *(float **)((int)fVar6 + 4 + uVar4 * 8) = pfVar2;
        if (pfVar2 != param_4) {
          *(undefined4 *)((int)param_1[3] + 4 + uVar4 * 8) =
               *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar4 * 8) + 4);
        }
      }
      fVar5 = param_1[7];
      uStack_8 = 2;
      fVar6 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)])
              / (float)((double)(int)fVar5 + (double)(&DAT_018c0d90)[-((int)fVar5 >> 0x1f)]);
      if (*param_1 <= fVar6 && fVar6 != *param_1) {
        if ((uint)fVar5 < 0x200) {
          fVar5 = (float)((int)fVar5 << 3);
        }
        else if ((uint)fVar5 < 0x1fffffff) {
          fVar5 = (float)((int)fVar5 * 2);
        }
        FUN_005cb500(fVar5);
        pfVar2 = (float *)param_1[1];
        if ((float *)*pfVar2 != pfVar2) {
          fVar5 = pfVar2[1];
          do {
            fVar6 = *(float *)param_1[1];
            FUN_008be5f0(auStack_24,(int)fVar6 + 8,fVar6);
          } while (fVar6 != fVar5);
        }
      }
      *param_2 = (float)param_4;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    fVar5 = *(float *)((int)fVar5 + 4);
    cVar3 = FUN_009cbaa0(param_3,(int)fVar5 + 8);
  } while (cVar3 == '\0');
  *(float *)param_4[1] = *param_4;
  *(float *)((int)*param_4 + 4) = param_4[1];
  param_1[2] = (float)((int)param_1[2] + -1);
  FUN_008c78a0(param_4);
  *param_2 = fVar5;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14872 ; VA 0x008be7b6 ; Catch_All@008be7b6 */

void Catch_All_008be7b6(void)

{
  int unaff_EBP;
  
  FUN_008c77e0(*(undefined4 *)(unaff_EBP + 0x10));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14873 ; VA 0x008be7ca ; Catch_All@008be7ca */

void Catch_All_008be7ca(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x18));
  FUN_008c03a0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14874 ; VA 0x008be800 ; FUN_008be800 */

/* WARNING: Removing unreachable block (ram,0x008be8b5) */
/* WARNING: Removing unreachable block (ram,0x008be8b9) */
/* WARNING: Removing unreachable block (ram,0x008be8c2) */
/* WARNING: Removing unreachable block (ram,0x008be94b) */
/* WARNING: Removing unreachable block (ram,0x008be94f) */
/* WARNING: Removing unreachable block (ram,0x008be958) */

int * FUN_008be800(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdfd0;
  pvStack_10 = ExceptionList;
  if (param_1 == param_2) {
    return param_3;
  }
  piVar5 = param_3 + 0x15;
  piVar4 = param_1 + 0x15;
  ExceptionList = &pvStack_10;
  do {
    iVar1 = piVar4[-0x15];
    iVar2 = piVar4[-0x14];
    piVar4[-0x15] = 0;
    piVar4[-0x14] = 0;
    *param_3 = iVar1;
    piVar3 = (int *)piVar5[-0x14];
    piVar5[-0x14] = iVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar1 = piVar3[1] + -1;
      piVar3[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar1 = piVar3[2] + -1;
        piVar3[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_005880d0(piVar4 + -0x13);
    uStack_8 = 0;
    FUN_005e2c00(piVar5 + -0x13);
    iVar1 = piVar4[-0xb];
    iVar2 = piVar4[-10];
    piVar4[-0xb] = 0;
    piVar4[-10] = 0;
    piVar5[-0xb] = iVar1;
    piVar3 = (int *)piVar5[-10];
    uStack_8 = 0xffffffff;
    piVar5[-10] = iVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar1 = piVar3[1] + -1;
      piVar3[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar1 = piVar3[2] + -1;
        piVar3[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_005880d0(piVar4 + -9);
    uStack_8 = 2;
    FUN_008da730(piVar5 + -9);
    iVar1 = piVar4[-1];
    iVar2 = *piVar4;
    piVar4[-1] = 0;
    *piVar4 = 0;
    piVar5[-1] = iVar1;
    piVar3 = (int *)*piVar5;
    uStack_8 = 0xffffffff;
    *piVar5 = iVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar1 = piVar3[1] + -1;
      piVar3[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar1 = piVar3[2] + -1;
        piVar3[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    param_3 = param_3 + 0x16;
    piVar5 = piVar5 + 0x16;
    piVar3 = piVar4 + 1;
    piVar4 = piVar4 + 0x16;
  } while (piVar3 != param_2);
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 14875 ; VA 0x008be9f0 ; FUN_008be9f0 */

int __thiscall FUN_008be9f0(int *param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdfe8;
  pvStack_10 = ExceptionList;
  iVar2 = (param_3 - param_2) * 0x2aaaaaab;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = (param_3 - param_2) / 0x18;
  param_1[1] = 0;
  param_1[2] = 0;
  if (uVar1 != 0) {
    if (0x13b13b1 < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_00578090(uVar1);
    *param_1 = iVar2;
    param_1[1] = iVar2;
    param_1[2] = uVar1 * 0xd0 + *param_1;
    puVar4 = (undefined4 *)*param_1;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    for (; param_2 != param_3; param_2 = param_2 + 0x18) {
      uVar3 = FUN_0088d190();
      *puVar4 = uVar3;
      puVar4[1] = 0;
      FUN_0054ef60(param_2);
      uVar3 = FUN_00630cf0();
      puVar4[1] = uVar3;
      puVar4 = puVar4 + 0x34;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar2 = FUN_00559720(puVar4,puVar4,param_1);
    param_1[1] = (int)puVar4;
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 14876 ; VA 0x008beadc ; Catch_All@008beadc */

void Catch_All_008beadc(void)

{
  FUN_00577b20();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14877 ; VA 0x008beaf0 ; FUN_008beaf0 */

void __thiscall FUN_008beaf0(int *param_1,uint param_2)

{
  void **ppvVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be000;
  pvStack_10 = ExceptionList;
  iVar3 = param_1[1];
  iVar7 = *param_1;
  uVar2 = iVar3 - iVar7 >> 6;
  uVar4 = param_1[2] - iVar7 >> 6;
  if (param_2 <= uVar4) {
    if (uVar2 < param_2) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_008c5f40(iVar3,param_2 - uVar2);
      param_1[1] = iVar3;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_2 != uVar2) {
      iVar7 = param_2 * 0x40 + iVar7;
      ppvVar1 = &pvStack_10;
      for (iVar6 = iVar7; ExceptionList = ppvVar1, iVar6 != iVar3; iVar6 = iVar6 + 0x40) {
        FUN_008c3d70();
        ppvVar1 = (void **)ExceptionList;
      }
      param_1[1] = iVar7;
    }
    ExceptionList = pvStack_10;
    return;
  }
  if (param_2 < 0x4000000) {
    uVar5 = param_2;
    if ((uVar4 <= 0x3ffffff - (uVar4 >> 1)) && (uVar5 = (uVar4 >> 1) + uVar4, uVar5 < param_2)) {
      uVar5 = param_2;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_008c8200(uVar5);
    uStack_8 = 0;
    FUN_008c5f40(uVar2 * 0x40 + iVar3,param_2 - uVar2);
    FUN_008c7ee0(*param_1,param_1[1],iVar3);
    FUN_008c7590(iVar3,param_2,uVar5);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 14878 ; VA 0x008bec22 ; Catch_All@008bec22 */

void Catch_All_008bec22(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  FUN_008c77b0(*(undefined4 *)(unaff_EBP + -0x20),*(undefined4 *)(unaff_EBP + -0x1c));
  uVar2 = *(undefined4 *)(unaff_EBP + -0x14);
  uVar1 = *(undefined4 *)(unaff_EBP + 8);
  FUN_0054eb90(uVar1,uVar2);
  FUN_0089eda0(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14879 ; VA 0x008bec50 ; FUN_008bec50 */

int __thiscall FUN_008bec50(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::KeyframeSequenceProvider*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14880 ; VA 0x008bed22 ; Catch_All@008bed22 */

void Catch_All_008bed22(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14881 ; VA 0x008bed40 ; FUN_008bed40 */

undefined4 *
FUN_008bed40(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar6 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 5;
    do {
      puVar6[4] = 0;
      *(undefined4 *)((int)param_3 + (-0x1c - (int)param_1) + (int)(puVar5 + 7)) = 0;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      *puVar6 = puVar5[-5];
      puVar6[1] = uVar2;
      puVar6[2] = uVar3;
      puVar6[3] = uVar4;
      *(undefined8 *)(puVar6 + 4) = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      puVar6[6] = puVar5[1];
      puVar1 = puVar5 + 2;
      puVar6 = puVar6 + 7;
      puVar5 = puVar5 + 7;
    } while (puVar1 != param_2);
  }
  FUN_006b2190(puVar6,puVar6,param_4);
  return puVar6;
}



/* FUNCTION 14882 ; VA 0x008bedc0 ; FUN_008bedc0 */

undefined4 * FUN_008bedc0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined8 *puVar6;
  undefined4 *puVar7;
  
  puVar7 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 7;
    puVar6 = (undefined8 *)(param_3 + 0xc);
    do {
      *puVar7 = puVar5[-7];
      puVar7 = puVar7 + 0x18;
      *(undefined4 *)((int)puVar6 + -0x2c) = puVar5[-6];
      *(undefined4 *)(puVar6 + -3) = 0;
      *(undefined4 *)((int)param_3 + (-0x60 - (int)param_1) + (int)(puVar5 + 0x18)) = 0;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      *(undefined4 *)(puVar6 + -5) = puVar5[-5];
      *(undefined4 *)((int)puVar6 + -0x24) = uVar2;
      *(undefined4 *)(puVar6 + -4) = uVar3;
      *(undefined4 *)((int)puVar6 + -0x1c) = uVar4;
      puVar6[-3] = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      *(undefined4 *)puVar6 = 0;
      *(undefined4 *)((int)puVar6 + 4) = 0;
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      uVar4 = puVar5[4];
      *(undefined4 *)(puVar6 + -2) = puVar5[1];
      *(undefined4 *)((int)puVar6 + -0xc) = uVar2;
      *(undefined4 *)(puVar6 + -1) = uVar3;
      *(undefined4 *)((int)puVar6 + -4) = uVar4;
      *puVar6 = *(undefined8 *)(puVar5 + 5);
      puVar5[5] = 0;
      puVar5[6] = 0xf;
      *(undefined *)(puVar5 + 1) = 0;
      *(undefined4 *)(puVar6 + 1) = puVar5[7];
      puVar6[2] = *(undefined8 *)(puVar5 + 9);
      puVar6[3] = *(undefined8 *)(puVar5 + 0xb);
      puVar6[4] = *(undefined8 *)(puVar5 + 0xd);
      *(undefined4 *)(puVar6 + 5) = puVar5[0xf];
      puVar1 = puVar5 + 0x11;
      puVar5 = puVar5 + 0x18;
      puVar6 = puVar6 + 0xc;
    } while (puVar1 != param_2);
  }
  return puVar7;
}



/* FUNCTION 14883 ; VA 0x008beea0 ; FUN_008beea0 */

undefined4 *
FUN_008beea0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  puVar7 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 6;
    puVar6 = param_3 + 1;
    do {
      *puVar7 = puVar5[-6];
      puVar6[4] = 0;
      puVar1 = puVar5 + 1;
      *(undefined4 *)((int)param_3 + (-0x1c - (int)param_1) + (int)(puVar5 + 7)) = 0;
      puVar7 = puVar7 + 7;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      *puVar6 = puVar5[-5];
      puVar6[1] = uVar2;
      puVar6[2] = uVar3;
      puVar6[3] = uVar4;
      *(undefined8 *)(puVar6 + 4) = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      puVar5 = puVar5 + 7;
      puVar6 = puVar6 + 7;
    } while (puVar1 != param_2);
  }
  FUN_007be6b0(puVar7,puVar7,param_4);
  return puVar7;
}



/* FUNCTION 14884 ; VA 0x008bef20 ; FUN_008bef20 */

undefined FUN_008bef20(void)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  int *in_stack_00000054;
  uint in_stack_0000005c;
  undefined4 *in_stack_00000084;
  undefined auStack_114 [128];
  undefined auStack_94 [80];
  int *piStack_44;
  uint uStack_3c;
  undefined auStack_34 [32];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be050;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008c0e00(&stack0x00000004);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_114);
  if (cVar3 == '\0') {
    FUN_008c0e00(auStack_114);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x80);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_008c0e00(auStack_94);
    }
    *in_stack_00000084 = uVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_3c != 0) {
      if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_3c & 0xfffffffe))(auStack_34,auStack_34,2);
      }
      uStack_3c = 0;
    }
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_44[2] + -1;
      piStack_44[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_44 + 4))();
      }
    }
    FUN_00637950();
    FUN_008c3050();
    uVar5 = 1;
  }
  else {
    FUN_008c3050();
    uVar5 = 0;
  }
  uStack_8 = 5;
  if (in_stack_0000005c != 0) {
    if (((in_stack_0000005c & 1) == 0) &&
       (*(code **)(in_stack_0000005c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000005c & 0xfffffffe))(&stack0x00000064,&stack0x00000064,2);
    }
    in_stack_0000005c = 0;
  }
  if (in_stack_00000054 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000054 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000054 + 4))();
    }
  }
  FUN_00637950();
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 14885 ; VA 0x008bf090 ; FUN_008bf090 */

undefined FUN_008bf090(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined uVar5;
  uint in_stack_00000018;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be078;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_2c);
  if (cVar1 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(aiStack_44);
    if (0xf < uStack_30) {
      uVar3 = uStack_30 + 1;
      iVar2 = aiStack_44[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_44[0] + -4);
        uVar3 = uStack_30 + 0x24;
        if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 14886 ; VA 0x008bf200 ; FUN_008bf200 */

undefined FUN_008bf200(void)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  int *in_stack_00000050;
  uint in_stack_00000054;
  undefined4 *in_stack_0000007c;
  undefined auStack_104 [120];
  undefined auStack_8c [76];
  int *piStack_40;
  uint uStack_3c;
  undefined auStack_34 [32];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be0bd;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008c1700(&stack0x00000004);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_104);
  if (cVar3 == '\0') {
    FUN_008c1700(auStack_104);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x78);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_008c1700(auStack_8c);
    }
    *in_stack_0000007c = uVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_3c != 0) {
      if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_3c & 0xfffffffe))(auStack_34,auStack_34,2);
      }
      uStack_3c = 0;
    }
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_40[2] + -1;
      piStack_40[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
    FUN_00637950();
    FUN_008c38d0();
    uVar5 = 1;
  }
  else {
    FUN_008c38d0();
    uVar5 = 0;
  }
  uStack_8 = 5;
  if (in_stack_00000054 != 0) {
    if (((in_stack_00000054 & 1) == 0) &&
       (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000054 & 0xfffffffe))(&stack0x0000005c,&stack0x0000005c,2);
    }
    in_stack_00000054 = 0;
  }
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000050 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000050 + 4))();
    }
  }
  FUN_00637950();
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 14887 ; VA 0x008bf360 ; FUN_008bf360 */

undefined FUN_008bf360(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined uVar5;
  uint in_stack_00000018;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be0e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_2c);
  if (cVar1 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(aiStack_44);
    if (0xf < uStack_30) {
      uVar3 = uStack_30 + 1;
      iVar2 = aiStack_44[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_44[0] + -4);
        uVar3 = uStack_30 + 0x24;
        if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 14888 ; VA 0x008bf4d0 ; FUN_008bf4d0 */

undefined FUN_008bf4d0(uint param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined uVar3;
  int in_stack_00000028;
  undefined4 *in_stack_000000f4;
  uint auStack_1f4 [2];
  undefined auStack_1ec [28];
  int iStack_1d0;
  undefined auStack_1cc [200];
  uint auStack_104 [2];
  undefined auStack_fc [28];
  int iStack_e0;
  undefined auStack_dc [200];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be130;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008c1ae0(&param_1);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_104);
  if (cVar1 == '\0') {
    FUN_008c1ae0(auStack_104);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0xf0);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_008c1ae0(auStack_1f4);
    }
    *in_stack_000000f4 = uVar2;
    uStack_8._0_1_ = 4;
    if (iStack_1d0 != 0) {
      (**(code **)(iStack_1d0 + 8))(auStack_1cc);
    }
    uStack_8._0_1_ = 5;
    if (auStack_1f4[0] != 0) {
      if (((auStack_1f4[0] & 1) == 0) && (*(code **)(auStack_1f4[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_1f4[0] & 0xfffffffe))(auStack_1ec,auStack_1ec,2);
      }
      auStack_1f4[0] = 0;
    }
    uStack_8._0_1_ = 6;
    if (iStack_e0 != 0) {
      (**(code **)(iStack_e0 + 8))(auStack_dc);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (auStack_104[0] != 0) {
      if (((auStack_104[0] & 1) == 0) && (*(code **)(auStack_104[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_104[0] & 0xfffffffe))(auStack_fc,auStack_fc,2);
      }
      auStack_104[0] = 0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8._0_1_ = 8;
    if (iStack_e0 != 0) {
      (**(code **)(iStack_e0 + 8))(auStack_dc);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if (auStack_104[0] != 0) {
      if (((auStack_104[0] & 1) == 0) && (*(code **)(auStack_104[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_104[0] & 0xfffffffe))(auStack_fc,auStack_fc,2);
      }
      auStack_104[0] = 0;
    }
    uVar3 = 0;
  }
  uStack_8 = 10;
  if (in_stack_00000028 != 0) {
    (**(code **)(in_stack_00000028 + 8))(&stack0x0000002c);
  }
  uStack_8 = 0xb;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 14889 ; VA 0x008bf6c0 ; FUN_008bf6c0 */

undefined FUN_008bf6c0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be15f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 14890 ; VA 0x008bf820 ; FUN_008bf820 */

uint * FUN_008bf820(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,
                   uint param_6,uint param_7,undefined8 param_8,uint param_9,undefined4 *param_10)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined auStack_29c [200];
  uint uStack_1d4;
  undefined4 *puStack_1d0;
  undefined auStack_1cc [200];
  uint uStack_104;
  undefined4 *puStack_100;
  undefined auStack_fc [200];
  uint uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be1b1;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_104 = param_9;
  puStack_100 = (undefined4 *)0x0;
  ExceptionList = &pvStack_10;
  if (param_10 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    (*(code *)*param_10)(&stack0x00000030,auStack_fc);
  }
  uVar1 = uStack_104;
  puStack_100 = param_10;
  uStack_8._0_1_ = 2;
  if (param_10 != (undefined4 *)0x0) {
    (*(code *)*param_10)(auStack_fc,auStack_29c);
  }
  puVar2 = puStack_100;
  uStack_8._0_1_ = 3;
  puStack_1d0 = (undefined4 *)0x0;
  uStack_1d4 = uVar1;
  if (puStack_100 != (undefined4 *)0x0) {
    (*(code *)*puStack_100)(auStack_29c,auStack_1cc);
  }
  uStack_8._0_1_ = 4;
  puStack_1d0 = puVar2;
  if (puVar2 != (undefined4 *)0x0) {
    (*(code *)puVar2[2])(auStack_29c);
  }
  uStack_8._0_1_ = 5;
  if (puStack_100 != (undefined4 *)0x0) {
    (*(code *)puStack_100[2])(auStack_fc);
  }
  uStack_8._0_1_ = 6;
  uStack_34 = 0;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_2c,0);
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
    }
  }
  uStack_8._0_1_ = 7;
  *param_1 = 0;
  if (uStack_34 != 0) {
    *param_1 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_2c;
      param_1[3] = uStack_28;
      param_1[4] = uStack_24;
      param_1[5] = uStack_20;
      *(undefined8 *)(param_1 + 6) = uStack_1c;
    }
  }
  param_1[8] = uStack_1d4;
  uStack_8._0_1_ = 8;
  param_1[9] = 0;
  if (puStack_1d0 != (undefined4 *)0x0) {
    (*(code *)*puStack_1d0)(auStack_1cc,param_1 + 10);
  }
  param_1[9] = (uint)puStack_1d0;
  uStack_8._0_1_ = 9;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 10;
  if (puStack_1d0 != (undefined4 *)0x0) {
    (*(code *)puStack_1d0[2])(auStack_1cc);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  uStack_8 = 0xc;
  if (param_10 != (undefined4 *)0x0) {
    (*(code *)param_10[2])(&stack0x00000030);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14891 ; VA 0x008bfab0 ; FUN_008bfab0 */

undefined4 * FUN_008bfab0(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  uint extraout_ECX;
  uint uVar1;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined uStack00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined auStack_a8 [12];
  undefined4 uStack_9c;
  undefined4 *puStack_98;
  undefined4 *puStack_94;
  undefined4 uStack_90;
  uint uStack_8c;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined8 uStack_74;
  undefined4 uStack_6c;
  undefined4 *puStack_68;
  undefined4 *puStack_64;
  undefined *puStack_60;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017be1e0;
  pvStack_10 = ExceptionList;
  puStack_60 = (undefined *)in_stack_00000054;
  iStack_8 = 1;
  puStack_64 = (undefined4 *)in_stack_00000050;
  puStack_68 = (undefined4 *)in_stack_0000004c;
  uStack_6c = in_stack_00000048;
  uStack_8c = 0;
  uVar1 = in_stack_00000028;
  ExceptionList = &pvStack_10;
  if (in_stack_00000028 != 0) {
    uStack_8c = in_stack_00000028;
    if ((in_stack_00000028 & 1) == 0) {
      puStack_94 = &uStack_84;
      uStack_90 = 0;
      puStack_98 = &stack0x00000030;
      uStack_9c = 0x8bfb23;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000028 & 0xfffffffe))();
      uVar1 = extraout_ECX;
    }
    else {
      uStack_84 = in_stack_00000030;
      uStack_80 = in_stack_00000034;
      uStack_7c = in_stack_00000038;
      uStack_78 = in_stack_0000003c;
      uStack_74 = in_stack_00000040;
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 2;
  uStack_90 = CONCAT31((int3)(uVar1 >> 8),uStack00000024);
  _uStack00000024 = auStack_a8;
  FUN_0054ef60(&param_3);
  iStack_8._0_1_ = 1;
  puStack_60 = (undefined *)FUN_008c1e40();
  iStack_8._0_1_ = 3;
  *param_1 = param_2;
  puStack_64 = (undefined4 *)0x8bfb64;
  FUN_008c1da0();
  puStack_60 = (undefined *)0x8bfb6c;
  FUN_008c3d70();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < in_stack_00000020) {
    puStack_60 = (undefined *)(in_stack_00000020 + 1);
    uVar1 = param_3;
    if (0xfff < puStack_60) {
      uVar1 = *(uint *)(param_3 - 4);
      puStack_60 = (undefined *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_3 - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_60 = &UNK_008bfbef;
        FUN_017167a3();
      }
    }
    puStack_68 = (undefined4 *)0x8bfb9d;
    puStack_64 = (undefined4 *)uVar1;
    FUN_01674ea0();
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  iStack_8 = 4;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    puStack_68 = &stack0x00000030;
    puStack_60 = (undefined *)0x2;
    uStack_6c = 0x8bfbd6;
    puStack_64 = puStack_68;
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14892 ; VA 0x008bfbf0 ; FUN_008bfbf0 */

undefined4 *
FUN_008bfbf0(undefined4 *param_1,undefined4 param_2,uint param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined8 param_9,undefined4 param_10)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  uint auStack_5c [2];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be200;
  pvStack_10 = ExceptionList;
  uStack_3c = param_10;
  uStack_8 = 0;
  puStack_14 = (undefined *)auStack_5c;
  auStack_5c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar4 = auStack_5c;
  if (param_3 != 0) {
    auStack_5c[0] = param_3;
    if ((param_3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_54,0);
      puVar4 = (uint *)puStack_14;
    }
    else {
      uStack_54 = param_5;
      uStack_50 = param_6;
      uStack_4c = param_7;
      uStack_48 = param_8;
      uStack_44 = param_9;
      ExceptionList = &pvStack_10;
      puVar4 = auStack_5c;
    }
  }
  puStack_14 = (undefined *)puVar4;
  puVar4 = (uint *)FUN_008c1c00();
  uStack_8._0_1_ = 1;
  *param_1 = param_2;
  param_1[2] = 0;
  uVar1 = *puVar4;
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      uStack_3c = 0;
      uStack_44 = CONCAT44(param_1 + 4,puVar4 + 2);
      uStack_48 = 0x8bfcaa;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      uVar1 = puVar4[3];
      uVar2 = puVar4[4];
      uVar3 = puVar4[5];
      param_1[4] = puVar4[2];
      param_1[5] = uVar1;
      param_1[6] = uVar2;
      param_1[7] = uVar3;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(puVar4 + 6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    uStack_3c = 2;
    uStack_44 = CONCAT44(auStack_2c,auStack_2c);
    uStack_48 = 0x8bfcce;
    (**(code **)(uStack_34 & 0xfffffffe))();
  }
  uStack_8 = 3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    uStack_3c = 2;
    uStack_44 = CONCAT44(&param_5,&param_5);
    uStack_48 = 0x8bfcfc;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14893 ; VA 0x008bfd20 ; FUN_008bfd20 */

void FUN_008bfd20(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be218;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_2[4] = 0;
  param_2[5] = 0;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *param_2 = *param_3;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  param_2[6] = param_3[6];
  uStack_8 = 0;
  param_2[8] = 0;
  FUN_005880d0(param_3 + 8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14894 ; VA 0x008bfda0 ; FUN_008bfda0 */

undefined4 * FUN_008bfda0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be263;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e5ae20();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xc4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e5d420();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008bec50(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14895 ; VA 0x008bfe60 ; FUN_008bfe60 */

int FUN_008bfe60(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be278;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0490,&LAB_008bfd10);
  uVar2 = FUN_008c00b0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00e5af00();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008bfda0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0490,&LAB_008bfd10);
      uVar2 = FUN_008c00b0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 14896 ; VA 0x008bfff0 ; FUN_008bfff0 */

undefined4 FUN_008bfff0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_008bfe60();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 14897 ; VA 0x008c0050 ; FUN_008c0050 */

undefined4 FUN_008c0050(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_0055ea10();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 14898 ; VA 0x008c00b0 ; FUN_008c00b0 */

undefined4 FUN_008c00b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be29c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee049c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee049c);
    if (DAT_01ee049c == -1) {
      uStack_8 = 0;
      DAT_01ee0498 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee049c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0498;
}



/* FUNCTION 14899 ; VA 0x008c0130 ; FUN_008c0130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008c0130(int param_1,undefined4 *param_2,int param_3,undefined4 *param_4)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  char cVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be2b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_009cc8a0(param_3);
  uVar7 = iVar6 + 0x9e3779b9;
  uVar7 = (uVar7 >> 2) +
          uVar7 * 0x40 + *(uint *)(param_3 + 0x18) + (*(uint *)(param_3 + 0x18) >> 3) + 0x9e3779b9 ^
          uVar7;
  puVar1 = (uint *)(param_1 + 4);
  uVar8 = *puVar1;
  if (*(int *)(param_1 + 8) == 0) {
    piVar10 = (int *)0x0;
  }
  else {
    puVar11 = *(undefined4 **)(*(int *)(param_1 + 0x14) + (uVar7 % uVar8) * 4);
    if (puVar11 == (undefined4 *)0x0) {
      piVar10 = (int *)0x0;
    }
    else {
      piVar10 = (int *)*puVar11;
    }
    if (piVar10 == (int *)0x0) goto LAB_008c0211;
    do {
      if (uVar7 == piVar10[1]) {
        cVar5 = FUN_009cbaa0(param_3,piVar10 + 2);
        if ((cVar5 != '\0') && (*(int *)(param_3 + 0x18) == piVar10[8])) break;
      }
      else if ((uint)piVar10[1] % *puVar1 != uVar7 % uVar8) goto LAB_008c0211;
      piVar10 = (int *)*piVar10;
    } while (piVar10 != (int *)0x0);
  }
  if (piVar10 != (int *)0x0) {
    *param_2 = piVar10;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_008c0211:
  uStack_8 = 0;
  FUN_005d2a40();
  _DAT_00000008 = *param_4;
  _DAT_0000000c = param_4[1];
  _DAT_00000010 = param_4[2];
  _DAT_00000014 = param_4[3];
  _DAT_00000018 = *(undefined8 *)(param_4 + 4);
  param_4[4] = 0;
  param_4[5] = 0xf;
  *(undefined *)param_4 = 0;
  _DAT_00000020 = param_4[6];
  uVar3 = *(uint *)(param_1 + 8);
  uVar8 = uVar3 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005c9310(uVar8);
    if (uVar8 <= *puVar1) {
      uVar8 = *puVar1;
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    uVar9 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar8) {
      uVar9 = 1;
    }
    uVar8 = FUN_005c9310(uVar9 + *(int *)(param_1 + 8));
    if (uVar8 != *puVar1) {
      FUN_005d2b00(uVar8);
      puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
      puVar4 = (undefined4 *)*puVar11;
      while (puVar4 != (undefined4 *)0x0) {
        piVar10 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *puVar1) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *puVar1) * 4) == 0) {
          *piVar10 = (int)puVar11;
          puVar11 = puVar4;
        }
        else {
          *puVar11 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar10;
          *(undefined4 **)*piVar10 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar11;
      }
    }
  }
  uVar8 = *puVar1;
  piVar10 = (int *)(*(int *)(param_1 + 0x14) + (uVar7 % uVar8) * 4);
  _DAT_00000004 = uVar7;
  if ((int *)*piVar10 == (int *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (*piVar2 != 0) {
      *(undefined4 *)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % uVar8) * 4) = 0;
    }
    *piVar10 = (int)piVar2;
    _DAT_00000000 = *piVar2;
    *piVar2 = 0;
  }
  else {
    _DAT_00000000 = *(int *)*piVar10;
    *(undefined4 *)*piVar10 = 0;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = 0;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14900 ; VA 0x008c03a0 ; FUN_008c03a0 */

undefined4 FUN_008c03a0(undefined4 param_1,undefined4 param_2)

{
  FUN_008ca7f0(param_1,param_2);
  return param_1;
}



/* FUNCTION 14901 ; VA 0x008c03c0 ; FUN_008c03c0 */

int * __thiscall FUN_008c03c0(int *param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cdc0();
  if (iVar4 != iVar1) {
    puVar2 = (undefined4 *)param_1[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)(param_1 + 2,auStack_d8);
      puVar2 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_0088a3d0();
    iVar4 = piVar3[1];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    *param_2 = *piVar3;
    param_2[1] = iVar4;
    uStack_8 = 1;
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)puVar2[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar4 = *param_1;
  iVar1 = FUN_0088cdc0();
  if (iVar4 == iVar1) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iVar4 = piVar3[1];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    *param_2 = *piVar3;
    param_2[1] = iVar4;
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14902 ; VA 0x008c04f0 ; FUN_008c04f0 */

undefined4 __thiscall FUN_008c04f0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d190();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    uVar5 = FUN_0088a920();
    FUN_0054ef60(uVar5);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088d190();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14903 ; VA 0x008c05f0 ; FUN_008c05f0 */

void __thiscall FUN_008c05f0(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18,param_1);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *param_2 = (int)(puVar1 + 3);
    param_2[1] = (int)puVar1;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 14904 ; VA 0x008c0650 ; FUN_008c0650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_008c0650(int *param_1)

{
  int *piVar1;
  undefined8 uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be30b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_01674e20(0x98);
  uStack_8 = 0;
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3[1] = 1;
    piVar3[2] = 1;
    *piVar3 = (int)std::_Ref_count_obj<class_RBX::AsyncBackoffDelayMap<class_RBX::ContentId>_>::
                   vftable;
    piVar3[4] = 0;
    piVar3[5] = 0;
    FUN_016dee4c(piVar3 + 6,2);
    uStack_8._0_1_ = 2;
    piVar3[0x12] = 0;
    piVar3[0x13] = 0;
    piVar3[0x14] = 0;
    iVar4 = FUN_008c74c0(0,0);
    piVar3[0x13] = iVar4;
    piVar3[0x15] = 0;
    piVar3[0x16] = 0;
    piVar3[0x17] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    piVar3[0x12] = 0x3f800000;
    FUN_005cb500(8);
    uVar2 = _PTR_018dad08;
    *(undefined *)(piVar3 + 0x1a) = 0;
    piVar3[0x1c] = DAT_01d62ed4;
    *(undefined8 *)(piVar3 + 0x1e) = uVar2;
    piVar3[0x20] = DAT_01d62ed8;
    piVar3[0x21] = DAT_01d62edc;
    piVar3[0x22] = 2;
    piVar3[0x23] = 2000;
    piVar3[0x24] = 0;
    piVar3[0x25] = -1;
  }
  piVar1 = piVar3 + 4;
  *param_1 = (int)piVar1;
  param_1[1] = (int)piVar3;
  if ((piVar1 != (int *)0x0) && ((piVar3[5] == 0 || (*(int *)(piVar3[5] + 4) == 0)))) {
    piVar5 = piVar3;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar5 = (int *)param_1[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
    }
    *piVar1 = (int)piVar1;
    piVar1 = (int *)piVar3[5];
    piVar3[5] = (int)piVar5;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = piVar5[1] + -1;
      piVar5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar3 = piVar5 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14905 ; VA 0x008c07f0 ; FUN_008c07f0 */

void FUN_008c07f0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be332;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(200);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<class_std::basic_ifstream<char,struct_std::char_traits<char>_>_>::
              vftable;
    FUN_0054ebd0(*param_2,*param_3,0x40,1);
  }
  *param_1 = (int)(puVar1 + 4);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14906 ; VA 0x008c0870 ; FUN_008c0870 */

void FUN_008c0870(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be352;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0xb8);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::vftable;
    FUN_00565000(param_2,1,1);
  }
  *param_1 = (int)(puVar1 + 4);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14907 ; VA 0x008c08f0 ; FUN_008c08f0 */

void FUN_008c08f0(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be36f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x24);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::vftable;
    FUN_0054ef60(param_2);
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14908 ; VA 0x008c0970 ; FUN_008c0970 */

void __thiscall FUN_008c0970(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_01674e20(0x24,param_1);
  if (puVar4 != (undefined4 *)0x0) {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::
              _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::vftable;
    puVar4[7] = 0;
    puVar4[8] = 0;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar4[3] = *param_3;
    puVar4[4] = uVar1;
    puVar4[5] = uVar2;
    puVar4[6] = uVar3;
    *(undefined8 *)(puVar4 + 7) = *(undefined8 *)(param_3 + 4);
    param_3[4] = 0;
    param_3[5] = 0xf;
    *(undefined *)param_3 = 0;
    *param_2 = (int)(puVar4 + 3);
    param_2[1] = (int)puVar4;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 14909 ; VA 0x008c09f0 ; FUN_008c09f0 */

int * FUN_008c09f0(int *param_1,int *param_2,undefined4 *param_3,undefined4 *param_4)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  uint auStack_3c [2];
  int aiStack_34 [6];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be39a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_01674e20(0x130);
  uStack_8 = 0;
  piStack_1c = piVar3;
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3[1] = 1;
    piVar3[2] = 1;
    *piVar3 = (int)std::_Ref_count_obj<class_RBX::AsyncHttpQueue>::vftable;
    uStack_14 = *param_4;
    auStack_3c[0] = 0;
    uStack_18 = *param_3;
    iVar1 = *param_2;
    FUN_008d2550(aiStack_34,aiStack_34,2);
    if (iVar1 == 0) {
      auStack_3c[0] = 0;
    }
    else {
      auStack_3c[0] = 0x1929975;
      aiStack_34[0] = iVar1;
    }
    uStack_8._0_1_ = 1;
    FUN_00d19bf0(auStack_3c,uStack_18,uStack_14);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (((auStack_3c[0] != 0) && ((auStack_3c[0] & 1) == 0)) &&
       (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_3c[0] & 0xfffffffe))(aiStack_34,aiStack_34,2);
    }
  }
  piVar2 = piVar3 + 4;
  *param_1 = (int)piVar2;
  param_1[1] = (int)piVar3;
  if ((piVar2 != (int *)0x0) && ((piVar3[7] == 0 || (*(int *)(piVar3[7] + 4) == 0)))) {
    piVar4 = piVar3;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    piVar3[6] = (int)piVar2;
    piVar2 = (int *)piVar3[7];
    piVar3[7] = (int)piVar4;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[2] + -1;
      piVar2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar1 = piVar4[1] + -1;
      piVar4[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14910 ; VA 0x008c0b50 ; FUN_008c0b50 */

void FUN_008c0b50(int *param_1,int param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<class_std::runtime_error>::vftable;
    puVar1[3] = std::exception::vftable;
    *(undefined8 *)(puVar1 + 4) = 0;
    FUN_0170c226(param_2 + 4,puVar1 + 4);
    puVar1[3] = std::runtime_error::vftable;
    param_1[1] = (int)puVar1;
    *param_1 = (int)(puVar1 + 3);
    return;
  }
  param_1[1] = 0;
  *param_1 = 0xc;
  return;
}



/* FUNCTION 14911 ; VA 0x008c0bd0 ; FUN_008c0bd0 */

void FUN_008c0bd0(uint param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 in_stack_00000024;
  undefined4 uStack_1b8;
  undefined4 *puStack_1b4;
  undefined auStack_1b0 [184];
  undefined4 uStack_f8;
  undefined *puStack_f4;
  undefined *puStack_f0;
  undefined4 *puStack_ec;
  undefined4 auStack_dc [50];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be3c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puStack_ec = (undefined4 *)0x8c0bfb;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088c8c0();
  auStack_dc[0] = in_stack_00000024;
  puStack_ec = (undefined4 *)0x8c0c19;
  puVar3 = (undefined4 *)FUN_005c9cc0();
  puStack_14 = (undefined *)&uStack_1b8;
  uStack_8._0_1_ = 1;
  puStack_1b4 = (undefined4 *)0x0;
  uStack_1b8 = uVar2;
  puVar1 = &uStack_1b8;
  if (puVar3 != (undefined4 *)0x0) {
    (*(code *)*puVar3)(auStack_dc,auStack_1b0);
    puVar1 = (undefined4 *)puStack_14;
  }
  puStack_14 = (undefined *)puVar1;
  puStack_1b4 = puVar3;
  FUN_008c6ce0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 != (undefined4 *)0x0) {
    puStack_ec = auStack_dc;
    puStack_f0 = (undefined *)0x8c0c84;
    (*(code *)puVar3[2])();
  }
  uStack_8 = 3;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_f4 = &stack0x0000000c;
    puStack_ec = (undefined4 *)0x2;
    uStack_f8 = 0x8c0cab;
    puStack_f0 = puStack_f4;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14912 ; VA 0x008c0cc0 ; FUN_008c0cc0 */

undefined4 * FUN_008c0cc0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  int *piVar6;
  char cVar7;
  undefined4 *puVar8;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  uStack_10 = 0;
  if (param_2 == 0) {
    puVar8 = &uStack_10;
    piStack_c = (int *)0x0;
    bVar5 = false;
    bVar4 = false;
    bVar3 = true;
  }
  else {
    piStack_c = (int *)0x0;
    cVar7 = FUN_00602ce0(param_2);
    if (cVar7 == '\0') {
      FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c21d80);
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[1] = piStack_c[1] + 1;
      UNLOCK();
    }
    bVar5 = true;
    bVar4 = true;
    bVar3 = false;
    uStack_18 = uStack_10;
    puVar8 = &uStack_18;
    piStack_14 = piStack_c;
  }
  piVar6 = piStack_c;
  piVar1 = piStack_14;
  iVar2 = puVar8[1];
  *param_1 = 0;
  param_1[1] = 0;
  if (iVar2 != 0) {
    LOCK();
    *(int *)(puVar8[1] + 8) = *(int *)(puVar8[1] + 8) + 1;
    UNLOCK();
  }
  *param_1 = *puVar8;
  param_1[1] = iVar2;
  if ((bVar3) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if ((bVar4) && (piVar1 != (int *)0x0)) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if ((bVar5) && (piVar6 != (int *)0x0)) {
    LOCK();
    iVar2 = piVar6[1] + -1;
    piVar6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 14913 ; VA 0x008c0e00 ; FUN_008c0e00 */

int __thiscall FUN_008c0e00(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be3f6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2 + 0x30);
  *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(param_2 + 0x48);
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  if (*(int *)(param_2 + 0x50) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x50) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x4c) = *(undefined4 *)(param_2 + 0x4c);
  *(undefined4 *)(param_1 + 0x50) = *(undefined4 *)(param_2 + 0x50);
  *(undefined4 *)(param_1 + 0x58) = 0;
  uVar2 = *(uint *)(param_2 + 0x58);
  uStack_8 = 3;
  if (uVar2 != 0) {
    *(uint *)(param_1 + 0x58) = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x60,param_1 + 0x60,0);
    }
    else {
      uVar3 = *(undefined4 *)(param_2 + 100);
      uVar4 = *(undefined4 *)(param_2 + 0x68);
      uVar5 = *(undefined4 *)(param_2 + 0x6c);
      *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(param_2 + 0x60);
      *(undefined4 *)(param_1 + 100) = uVar3;
      *(undefined4 *)(param_1 + 0x68) = uVar4;
      *(undefined4 *)(param_1 + 0x6c) = uVar5;
      *(undefined8 *)(param_1 + 0x70) = *(undefined8 *)(param_2 + 0x70);
    }
  }
  *(undefined4 *)(param_1 + 0x78) = *(undefined4 *)(param_2 + 0x78);
  *(undefined *)(param_1 + 0x7c) = *(undefined *)(param_2 + 0x7c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14914 ; VA 0x008c0ef0 ; FUN_008c0ef0 */

undefined4 * __thiscall FUN_008c0ef0(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be40b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  uVar1 = param_2[2];
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar2 = param_2[5];
      uVar3 = param_2[6];
      uVar4 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar2;
      param_1[6] = uVar3;
      param_1[7] = uVar4;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = param_2[10];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0xb);
  *(undefined *)(param_1 + 0x11) = *(undefined *)(param_2 + 0x11);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14915 ; VA 0x008c0f90 ; FUN_008c0f90 */

int __thiscall FUN_008c0f90(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be428;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = 0;
  uVar1 = *(uint *)(param_2 + 0x18);
  uStack_8 = 0;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x18) = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = *(undefined4 *)(param_2 + 0x24);
      uVar3 = *(undefined4 *)(param_2 + 0x28);
      uVar4 = *(undefined4 *)(param_2 + 0x2c);
      *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 0x20);
      *(undefined4 *)(param_1 + 0x24) = uVar2;
      *(undefined4 *)(param_1 + 0x28) = uVar3;
      *(undefined4 *)(param_1 + 0x2c) = uVar4;
      *(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_2 + 0x30);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x20,param_1 + 0x20,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14916 ; VA 0x008c1030 ; FUN_008c1030 */

undefined4 * __thiscall FUN_008c1030(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be46c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  uVar2 = param_2[2];
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
    }
    else {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
    }
  }
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  if (param_2[0x15] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x15] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x14] = param_2[0x14];
  param_1[0x15] = param_2[0x15];
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_2 + 0x16);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14917 ; VA 0x008c1150 ; FUN_008c1150 */

uint * __thiscall FUN_008c1150(uint *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  *param_1 = 0;
  uVar2 = *param_2;
  if (uVar2 != 0) {
    *param_1 = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar2 = param_2[3];
      uVar3 = param_2[4];
      uVar4 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar2;
      param_1[4] = uVar3;
      param_1[5] = uVar4;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = param_2[8];
  param_1[9] = 0;
  param_1[10] = 0;
  if (param_2[10] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[10] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  if (param_2[0xc] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xc] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  if (param_2[0xe] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xe] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xd] = param_2[0xd];
  param_1[0xe] = param_2[0xe];
  return param_1;
}



/* FUNCTION 14918 ; VA 0x008c1220 ; FUN_008c1220 */

undefined4 * __thiscall FUN_008c1220(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be49e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2 + 10);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_2 + 0x10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14919 ; VA 0x008c12e0 ; FUN_008c12e0 */

uint * __thiscall FUN_008c12e0(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be4b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uVar1 = param_2[8];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[8] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_2[0xb];
      uVar2 = param_2[0xc];
      uVar3 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar1;
      param_1[0xc] = uVar2;
      param_1[0xd] = uVar3;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14920 ; VA 0x008c13b0 ; FUN_008c13b0 */

undefined4 * __thiscall FUN_008c13b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be4e6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 3);
  param_1[9] = param_2[9];
  *(undefined *)(param_1 + 10) = *(undefined *)(param_2 + 10);
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14921 ; VA 0x008c1490 ; FUN_008c1490 */

uint * __thiscall FUN_008c1490(uint *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  *param_1 = 0;
  uVar2 = *param_2;
  if (uVar2 != 0) {
    *param_1 = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar2 = param_2[3];
      uVar3 = param_2[4];
      uVar4 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar2;
      param_1[4] = uVar3;
      param_1[5] = uVar4;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  return param_1;
}



/* FUNCTION 14922 ; VA 0x008c1510 ; FUN_008c1510 */

undefined4 * __thiscall FUN_008c1510(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be40b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  uVar2 = param_2[2];
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = param_2[10];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0xb);
  *(undefined *)(param_1 + 0x11) = *(undefined *)(param_2 + 0x11);
  param_1[0x12] = param_2[0x12];
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  if (param_2[0x14] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x14] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x13] = param_2[0x13];
  param_1[0x14] = param_2[0x14];
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  if (param_2[0x16] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x16] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x15] = param_2[0x15];
  param_1[0x16] = param_2[0x16];
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  if (param_2[0x18] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x18] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x17] = param_2[0x17];
  param_1[0x18] = param_2[0x18];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14923 ; VA 0x008c1620 ; FUN_008c1620 */

undefined4 * __thiscall FUN_008c1620(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017be503;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[6] = 0;
  uVar2 = param_2[6];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[6] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[9];
      uVar4 = param_2[10];
      uVar5 = param_2[0xb];
      param_1[8] = param_2[8];
      param_1[9] = uVar3;
      param_1[10] = uVar4;
      param_1[0xb] = uVar5;
      *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(param_2 + 0xc);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 8,param_1 + 8,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14924 ; VA 0x008c1700 ; FUN_008c1700 */

int __thiscall FUN_008c1700(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be536;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2 + 0x30);
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  if (*(int *)(param_2 + 0x4c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x4c) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(param_2 + 0x48);
  *(undefined4 *)(param_1 + 0x4c) = *(undefined4 *)(param_2 + 0x4c);
  *(undefined4 *)(param_1 + 0x50) = 0;
  uVar2 = *(uint *)(param_2 + 0x50);
  uStack_8 = 3;
  if (uVar2 != 0) {
    *(uint *)(param_1 + 0x50) = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x58,param_1 + 0x58,0);
    }
    else {
      uVar3 = *(undefined4 *)(param_2 + 0x5c);
      uVar4 = *(undefined4 *)(param_2 + 0x60);
      uVar5 = *(undefined4 *)(param_2 + 100);
      *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_2 + 0x58);
      *(undefined4 *)(param_1 + 0x5c) = uVar3;
      *(undefined4 *)(param_1 + 0x60) = uVar4;
      *(undefined4 *)(param_1 + 100) = uVar5;
      *(undefined8 *)(param_1 + 0x68) = *(undefined8 *)(param_2 + 0x68);
    }
  }
  *(undefined4 *)(param_1 + 0x70) = *(undefined4 *)(param_2 + 0x70);
  *(undefined *)(param_1 + 0x74) = *(undefined *)(param_2 + 0x74);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14925 ; VA 0x008c17e0 ; FUN_008c17e0 */

undefined4 * __thiscall
FUN_008c17e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be58b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_008bd840();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::ContentProvider,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14926 ; VA 0x008c1960 ; FUN_008c1960 */

undefined4 * __thiscall
FUN_008c1960(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be5eb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_008bd840();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::ContentProvider,void___cdecl(class_RBX::ContentId),1>::vftable
  ;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088d190();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_00630cf0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088d190();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14927 ; VA 0x008c1ae0 ; FUN_008c1ae0 */

uint * __thiscall FUN_008c1ae0(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be608;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = param_2[8];
  param_1[9] = 0;
  uStack_8 = 0;
  if ((undefined4 *)param_2[9] != (undefined4 *)0x0) {
    (**(code **)param_2[9])(param_2 + 10,param_1 + 10);
    param_1[9] = param_2[9];
    ExceptionList = pvStack_10;
    return param_1;
  }
  param_1[9] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14928 ; VA 0x008c1ba0 ; FUN_008c1ba0 */

undefined4 * __thiscall FUN_008c1ba0(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_1 = *param_2;
  param_1[2] = 0;
  uVar1 = param_2[2];
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[5];
      uVar3 = param_2[6];
      uVar4 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar2;
      param_1[6] = uVar3;
      param_1[7] = uVar4;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
  }
  return param_1;
}



/* FUNCTION 14929 ; VA 0x008c1c00 ; FUN_008c1c00 */

uint * __thiscall
FUN_008c1c00(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,uint param_6,
            uint param_7,undefined8 param_8)

{
  uint uStack_54;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be638;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_2c,0);
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_4c,0);
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  uStack_8._0_1_ = 2;
  *param_1 = 0;
  if (uStack_54 != 0) {
    *param_1 = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_4c;
      param_1[3] = uStack_48;
      param_1[4] = uStack_44;
      param_1[5] = uStack_40;
      *(undefined8 *)(param_1 + 6) = uStack_3c;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14930 ; VA 0x008c1da0 ; FUN_008c1da0 */

int __thiscall FUN_008c1da0(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be658;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  *(undefined *)(param_1 + 0x18) = *(undefined *)(param_2 + 0x18);
  *(undefined4 *)(param_1 + 0x20) = 0;
  uVar1 = *(uint *)(param_2 + 0x20);
  uStack_8 = 0;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x20) = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = *(undefined4 *)(param_2 + 0x2c);
      uVar3 = *(undefined4 *)(param_2 + 0x30);
      uVar4 = *(undefined4 *)(param_2 + 0x34);
      *(undefined4 *)(param_1 + 0x28) = *(undefined4 *)(param_2 + 0x28);
      *(undefined4 *)(param_1 + 0x2c) = uVar2;
      *(undefined4 *)(param_1 + 0x30) = uVar3;
      *(undefined4 *)(param_1 + 0x34) = uVar4;
      *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x28,param_1 + 0x28,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14931 ; VA 0x008c1e40 ; FUN_008c1e40 */

undefined4 __thiscall FUN_008c1e40(undefined4 param_1,uint param_2)

{
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined8 in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017be688;
  pvStack_10 = ExceptionList;
  iStack_8 = 1;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000020 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000020 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000020 & 0xfffffffe))();
  }
  iStack_8._0_1_ = 2;
  FUN_0054ef60(&param_2);
  iStack_8._0_1_ = 1;
  FUN_008c22f0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  iStack_8 = 3;
  if (((in_stack_00000020 != 0) && ((in_stack_00000020 & 1) == 0)) &&
     (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000020 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14932 ; VA 0x008c1f70 ; FUN_008c1f70 */

int __thiscall FUN_008c1f70(int param_1,uint param_2)

{
  undefined uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined8 in_stack_00000038;
  int aiStack_48 [5];
  uint uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017be6c8;
  pvStack_10 = ExceptionList;
  iStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_0054ef60(&param_2);
  iStack_8._0_1_ = 2;
  FUN_0054ef60(aiStack_48);
  iStack_8._0_1_ = 3;
  FUN_0054ef60(aiStack_30);
  iStack_8._0_1_ = 2;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 2;
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    iVar2 = aiStack_30[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *(undefined *)(param_1 + 0x18) = in_stack_0000001c;
  iStack_8._0_1_ = 1;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 1;
  if (0xf < uStack_34) {
    uVar3 = uStack_34 + 1;
    iVar2 = aiStack_48[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_48[0] + -4);
      uVar3 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar2) - 4U) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  iStack_8._0_1_ = 4;
  *(undefined4 *)(param_1 + 0x20) = 0;
  if (in_stack_00000020 != 0) {
    *(uint *)(param_1 + 0x20) = in_stack_00000020;
    if ((in_stack_00000020 & 1) == 0) {
      (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028,param_1 + 0x28,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x28) = in_stack_00000028;
      *(undefined4 *)(param_1 + 0x2c) = in_stack_0000002c;
      *(undefined4 *)(param_1 + 0x30) = in_stack_00000030;
      *(undefined4 *)(param_1 + 0x34) = in_stack_00000034;
      *(undefined8 *)(param_1 + 0x38) = in_stack_00000038;
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    uVar3 = param_2;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(param_2 - 4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  iStack_8 = 5;
  if (((in_stack_00000020 != 0) && ((in_stack_00000020 & 1) == 0)) &&
     (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028,&stack0x00000028,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14933 ; VA 0x008c2110 ; FUN_008c2110 */

undefined4 __thiscall FUN_008c2110(undefined4 param_1,uint param_2)

{
  undefined uVar1;
  uint *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 *in_stack_00000034;
  undefined8 in_stack_00000038;
  undefined auStack_90 [12];
  undefined4 uStack_84;
  undefined4 *puStack_80;
  undefined4 *puStack_7c;
  undefined4 uStack_78;
  uint auStack_74 [2];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  undefined8 uStack_5c;
  uint uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  undefined8 uStack_38;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017be710;
  pvStack_10 = ExceptionList;
  iStack_8 = 1;
  uStack_50 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined *)param_1;
  if (in_stack_00000020 != 0) {
    uStack_50 = in_stack_00000020;
    if ((in_stack_00000020 & 1) == 0) {
      uStack_5c = ZEXT48(&uStack_48);
      puStack_60 = &stack0x00000028;
      uStack_64 = 0x8c2172;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000020 & 0xfffffffe))();
    }
    else {
      uStack_48 = in_stack_00000028;
      uStack_44 = in_stack_0000002c;
      uStack_40 = in_stack_00000030;
      puStack_3c = in_stack_00000034;
      uStack_38 = in_stack_00000038;
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 2;
  uStack_5c = CONCAT44(&param_2,0x8c2185);
  FUN_0054ef60();
  puStack_14 = (undefined *)auStack_74;
  puStack_18 = (undefined *)auStack_74;
  iStack_8._0_1_ = 4;
  auStack_74[0] = 0;
  puVar2 = auStack_74;
  if (uStack_50 != 0) {
    auStack_74[0] = uStack_50;
    if ((uStack_50 & 1) == 0) {
      puStack_7c = &uStack_6c;
      uStack_78 = 0;
      puStack_80 = &uStack_48;
      uStack_84 = 0x8c21cd;
      (**(code **)(uStack_50 & 0xfffffffe))();
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_6c = uStack_48;
      uStack_68 = uStack_44;
      uStack_64 = uStack_40;
      puStack_60 = puStack_3c;
      uStack_5c = uStack_38;
      puVar2 = auStack_74;
    }
  }
  puStack_14 = (undefined *)puVar2;
  uStack_78 = in_stack_0000001c;
  iStack_8._0_1_ = 5;
  puStack_18 = auStack_90;
  FUN_0054ef60(aiStack_30);
  iStack_8._0_1_ = 4;
  FUN_008c1f70();
  iStack_8._0_1_ = 3;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 3;
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    iVar3 = aiStack_30[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_30[0] + -4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar3) - 4U) {
        uStack_5c = CONCAT44(0x8c22df,(undefined4)uStack_5c);
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_5c = CONCAT44(uVar4,iVar3);
    puStack_60 = (undefined4 *)0x8c2228;
    FUN_01674ea0();
  }
  iStack_8._0_1_ = 6;
  if (uStack_50 != 0) {
    if (((uStack_50 & 1) == 0) && (*(code **)(uStack_50 & 0xfffffffe) != (code *)0x0)) {
      puStack_60 = &uStack_48;
      uStack_5c = CONCAT44(2,puStack_60);
      uStack_64 = 0x8c2250;
      (**(code **)(uStack_50 & 0xfffffffe))();
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    uVar4 = param_2;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_2 - 4);
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar4) - 4) {
        uStack_5c = CONCAT44(&UNK_008c22e4,(undefined4)uStack_5c);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_5c = CONCAT44(uVar5,uVar4);
    puStack_60 = (undefined4 *)0x8c228b;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  iStack_8 = 7;
  if (((in_stack_00000020 != 0) && ((in_stack_00000020 & 1) == 0)) &&
     (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
    puStack_60 = &stack0x00000028;
    uStack_5c = CONCAT44(2,puStack_60);
    uStack_64 = 0x8c22c4;
    (**(code **)(in_stack_00000020 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14934 ; VA 0x008c22f0 ; FUN_008c22f0 */

undefined4 __thiscall FUN_008c22f0(undefined4 param_1,uint param_2)

{
  undefined uVar1;
  uint *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined8 in_stack_00000038;
  undefined4 *in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined auStack_98 [12];
  undefined4 uStack_8c;
  undefined4 *puStack_88;
  undefined4 *puStack_84;
  undefined4 uStack_80;
  uint auStack_7c [2];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined4 *puStack_5c;
  undefined4 *puStack_58;
  uint uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 *apuStack_30 [5];
  uint uStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017be710;
  pvStack_10 = ExceptionList;
  iStack_8 = 1;
  uStack_50 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined *)param_1;
  if (in_stack_00000020 != 0) {
    uStack_50 = in_stack_00000020;
    if ((in_stack_00000020 & 1) == 0) {
      puStack_5c = &uStack_48;
      puStack_58 = (undefined4 *)0x0;
      uStack_64 = CONCAT44(&stack0x00000028,0x8c2352);
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000020 & 0xfffffffe))();
    }
    else {
      uStack_48 = in_stack_00000028;
      uStack_44 = in_stack_0000002c;
      uStack_40 = in_stack_00000030;
      uStack_3c = in_stack_00000034;
      uStack_38 = in_stack_00000038;
      ExceptionList = &pvStack_10;
    }
  }
  puStack_58 = &param_2;
  iStack_8._0_1_ = 2;
  puStack_5c = (undefined4 *)0x8c2365;
  FUN_0054ef60();
  puStack_58 = (undefined4 *)in_stack_00000044;
  iStack_8._0_1_ = 4;
  puStack_5c = in_stack_00000040;
  puStack_14 = (undefined *)auStack_7c;
  puStack_18 = (undefined *)auStack_7c;
  auStack_7c[0] = 0;
  puVar2 = auStack_7c;
  if (uStack_50 != 0) {
    auStack_7c[0] = uStack_50;
    if ((uStack_50 & 1) == 0) {
      puStack_84 = &uStack_74;
      uStack_80 = 0;
      puStack_88 = &uStack_48;
      uStack_8c = 0x8c23b3;
      (**(code **)(uStack_50 & 0xfffffffe))();
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_74 = uStack_48;
      uStack_70 = uStack_44;
      uStack_6c = uStack_40;
      uStack_68 = uStack_3c;
      uStack_64 = uStack_38;
      puVar2 = auStack_7c;
    }
  }
  puStack_14 = (undefined *)puVar2;
  uStack_80 = in_stack_0000001c;
  iStack_8._0_1_ = 5;
  puStack_18 = auStack_98;
  FUN_0054ef60(apuStack_30);
  iStack_8._0_1_ = 4;
  FUN_008c2110();
  iStack_8._0_1_ = 3;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 3;
  if (0xf < uStack_1c) {
    puStack_58 = (undefined4 *)(uStack_1c + 1);
    puVar3 = apuStack_30[0];
    if (0xfff < puStack_58) {
      puVar3 = (undefined4 *)apuStack_30[0][-1];
      puStack_58 = (undefined4 *)(uStack_1c + 0x24);
      if (0x1f < (uint)((int)apuStack_30[0] + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (undefined4 *)0x8c24c5;
        iStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    uStack_64 = CONCAT44(0x8c240e,(undefined4)uStack_64);
    puStack_5c = puVar3;
    FUN_01674ea0();
  }
  iStack_8._0_1_ = 6;
  if (((uStack_50 != 0) && ((uStack_50 & 1) == 0)) &&
     (*(code **)(uStack_50 & 0xfffffffe) != (code *)0x0)) {
    puStack_5c = &uStack_48;
    puStack_58 = (undefined4 *)0x2;
    uStack_64 = CONCAT44(puStack_5c,0x8c2436);
    (**(code **)(uStack_50 & 0xfffffffe))();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < in_stack_00000018) {
    puStack_58 = (undefined4 *)(in_stack_00000018 + 1);
    uVar4 = param_2;
    if (0xfff < puStack_58) {
      uVar4 = *(uint *)(param_2 - 4);
      puStack_58 = (undefined4 *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (undefined4 *)&UNK_008c24ca;
        FUN_017167a3();
      }
    }
    uStack_64 = CONCAT44(0x8c2471,(undefined4)uStack_64);
    puStack_5c = (undefined4 *)uVar4;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  iStack_8 = 7;
  if (((in_stack_00000020 != 0) && ((in_stack_00000020 & 1) == 0)) &&
     (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
    puStack_5c = &stack0x00000028;
    puStack_58 = (undefined4 *)0x2;
    uStack_64 = CONCAT44(puStack_5c,0x8c24aa);
    (**(code **)(in_stack_00000020 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14935 ; VA 0x008c24d0 ; FUN_008c24d0 */

uint * __thiscall FUN_008c24d0(uint *param_1,int *param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined auStack_10 [4];
  uint *puStack_c;
  undefined uStack_5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = param_2[1] - *param_2 >> 2;
  if (uVar1 != 0) {
    puStack_c = param_1;
    if (0x3fffffff < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar1 = uVar1 * 4;
    if (uVar1 < 0x1000) {
      if (uVar1 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar1);
      }
    }
    else {
      uVar2 = uVar1 + 0x23;
      if (uVar2 <= uVar1) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar1;
    iVar3 = *param_2;
    uVar1 = *param_1;
    FUN_0055b6b0(&uStack_5,auStack_10,auStack_10);
    iVar4 = param_2[1] - iVar3;
    FUN_0170cc70(uVar1,iVar3,iVar4);
    puStack_c[1] = uVar1 + iVar4;
    param_1 = puStack_c;
  }
  return param_1;
}



/* FUNCTION 14936 ; VA 0x008c25b0 ; FUN_008c25b0 */

uint * __thiscall FUN_008c25b0(uint *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar1 = param_2 * 8;
    if (uVar1 < 0x1000) {
      if (uVar1 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar1);
      }
    }
    else {
      uVar2 = uVar1 + 0x23;
      if (uVar2 <= uVar1) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar1;
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar4 = 0;
        puVar4[1] = 0;
        puVar4 = puVar4 + 2;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    FUN_005596d0(puVar4,puVar4,param_1);
    param_1[1] = (uint)puVar4;
  }
  return param_1;
}



/* FUNCTION 14937 ; VA 0x008c2680 ; FUN_008c2680 */

undefined4 * __thiscall
FUN_008c2680(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 14938 ; VA 0x008c2740 ; FUN_008c2740 */

undefined4 * __thiscall FUN_008c2740(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  param_1[2] = param_2;
  param_1[3] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 14939 ; VA 0x008c27c0 ; FUN_008c27c0 */

undefined4 * __fastcall FUN_008c27c0(undefined4 *param_1)

{
  code *pcVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  char cVar5;
  undefined4 uVar6;
  undefined **ppuVar7;
  code *pcVar8;
  undefined4 *puVar9;
  int *piVar10;
  undefined4 *****pppppuVar11;
  undefined **ppuVar12;
  undefined4 ****ppppuVar13;
  char *pcVar14;
  uint uVar15;
  char *pcVar16;
  bool bVar17;
  undefined auStack_60 [24];
  undefined4 ****appppuStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 *puStack_28;
  code *pcStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  code *pcStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be845;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff94;
  pcStack_18 = (code *)0x0;
  pcStack_24 = (code *)0x0;
  ExceptionList = &pvStack_10;
  puStack_28 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::ContentProvider,class_RBX::ServiceInstance>::vftable;
  uVar6 = FUN_008bd840();
  param_1[3] = uVar6;
  uStack_8 = 1;
  FUN_00f45140();
  *param_1 = RBX::ContentProvider::vftable;
  param_1[0x16] = RBX::ContentProvider::vftable;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  *(undefined *)(param_1 + 0x26) = 0;
  pcStack_24 = (code *)0xb;
  ppuVar7 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&pcStack_24);
  ppuVar12 = ppuVar7 + -1;
  if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar12 = ppuVar7;
  }
  param_1[0x27] = *ppuVar12;
  param_1[0x28] = 0;
  param_1[0x29] = 0x3f800000;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  *(undefined *)(param_1 + 0x2c) = 0;
  param_1[0x2d] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0xf;
  *(undefined *)(param_1 + 0x2e) = 0;
  bVar17 = DAT_01d62f70 == '\0';
  pcVar16 = "";
  param_1[0x38] = 0;
  param_1[0x39] = 0xf;
  if (bVar17) {
    pcVar16 = "https://www.roblox.com/";
  }
  uStack_8._0_1_ = 9;
  *(undefined *)(param_1 + 0x34) = 0;
  pcVar14 = pcVar16;
  do {
    cVar5 = *pcVar14;
    pcVar14 = pcVar14 + 1;
  } while (cVar5 != '\0');
  FUN_005542c0(pcVar16,(int)pcVar14 - (int)(pcVar16 + 1));
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  *(undefined *)(param_1 + 0x41) = 0;
  pcStack_24 = (code *)&DAT_0000000b;
  ppuVar7 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&pcStack_24);
  ppuVar12 = ppuVar7 + -1;
  if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar12 = ppuVar7;
  }
  param_1[0x42] = *ppuVar12;
  param_1[0x43] = 0;
  param_1[0x44] = 0x3f800000;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  *(undefined *)(param_1 + 0x4b) = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0xf;
  uStack_8._0_1_ = 0xf;
  *(undefined *)(param_1 + 0x4c) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x52] = 0;
  uStack_8._0_1_ = 0x10;
  if (DAT_01d62f40 != '\0') {
    pcVar8 = (code *)FUN_01674e20(0x14);
    uStack_8._0_1_ = 0x11;
    pcStack_24 = pcVar8;
    if (pcVar8 == (code *)0x0) {
      pcVar8 = (code *)0x0;
    }
    else {
      *(undefined4 *)(pcVar8 + 4) = 1;
      *(undefined4 *)(pcVar8 + 8) = 1;
      *(undefined ***)pcVar8 = std::_Ref_count_obj<class_RBX::BatchAssetApi>::vftable;
      FUN_00f4bad0();
    }
    uStack_8._0_1_ = 0x10;
    pcStack_18 = (code *)0x1;
    param_1[0x3d] = pcVar8 + 0xc;
    piVar10 = (int *)param_1[0x3e];
    param_1[0x3e] = pcVar8;
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar4 = piVar10[1] + -1;
      piVar10[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar10)();
        LOCK();
        iVar4 = piVar10[2] + -1;
        piVar10[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
      goto LAB_008c2ae1;
    }
  }
  uStack_8._0_1_ = 0x10;
LAB_008c2ae1:
  pcVar8 = (code *)FUN_01674e20(0x80);
  uStack_8._0_1_ = 0x12;
  if (pcVar8 == (code *)0x0) {
    pcVar8 = (code *)0x0;
  }
  else {
    *(int *)(pcVar8 + 4) = 1;
    *(int *)(pcVar8 + 8) = 1;
    *(undefined ***)pcVar8 = std::_Ref_count_obj<class_RBX::BatchThumbnailFetcher>::vftable;
    pcStack_24 = pcVar8;
    FUN_00f46cf0();
  }
  pcStack_24 = (code *)((uint)pcStack_18 | 2);
  uStack_8._0_1_ = 0x10;
  pcVar1 = pcVar8 + 0xc;
  pcStack_18 = pcStack_24;
  if ((pcVar1 != (code *)0x0) &&
     ((*(int *)(pcVar8 + 0x10) == 0 || (*(int *)(*(int *)(pcVar8 + 0x10) + 4) == 0)))) {
    if (pcVar8 != (code *)0x0) {
      LOCK();
      *(int *)(pcVar8 + 4) = *(int *)(pcVar8 + 4) + 1;
      UNLOCK();
      LOCK();
      *(int *)(pcVar8 + 8) = *(int *)(pcVar8 + 8) + 1;
      UNLOCK();
    }
    *(code **)pcVar1 = pcVar1;
    piVar10 = *(int **)(pcVar8 + 0x10);
    *(code **)(pcVar8 + 0x10) = pcVar8;
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar4 = piVar10[2] + -1;
      piVar10[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
    if (pcVar8 != (code *)0x0) {
      LOCK();
      iVar4 = *(int *)(pcVar8 + 4) + -1;
      *(int *)(pcVar8 + 4) = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (*(code *)**(undefined4 **)pcVar8)();
        LOCK();
        iVar4 = *(int *)(pcVar8 + 8) + -1;
        *(int *)(pcVar8 + 8) = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*(int *)pcVar8 + 4))();
        }
      }
    }
  }
  param_1[0x3f] = pcVar8 + 0xc;
  piVar10 = (int *)param_1[0x40];
  param_1[0x40] = pcVar8;
  if (piVar10 != (int *)0x0) {
    LOCK();
    iVar4 = piVar10[1] + -1;
    piVar10[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar10)();
      LOCK();
      iVar4 = piVar10[2] + -1;
      piVar10[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  if (DAT_01d63008 != '\0') {
    puVar9 = (undefined4 *)FUN_008c0650(auStack_30);
    uVar6 = *puVar9;
    uVar3 = puVar9[1];
    *puVar9 = 0;
    puVar9[1] = 0;
    param_1[0x1e] = uVar6;
    piVar10 = (int *)param_1[0x1f];
    param_1[0x1f] = uVar3;
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar4 = piVar10[1] + -1;
      piVar10[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar10)();
        LOCK();
        iVar4 = piVar10[2] + -1;
        piVar10[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
    piVar10 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar2 = piVar10 + 2;
        iVar4 = *piVar2 + -1;
        *piVar2 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
  }
  if (DAT_01d62f90 != '\0') {
    uStack_8._0_1_ = 0x13;
    piVar10 = (int *)FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 0x14;
    piStack_2c = piVar10;
    puStack_20 = (undefined4 *)FUN_01674e20(0x1c);
    if (puStack_20 == (undefined4 *)0x0) {
      puStack_20 = (undefined4 *)0x0;
    }
    else {
      *puStack_20 = 0;
      puStack_20[1] = 1;
      puStack_20[2] = FUN_008ca690;
      puStack_20[3] = _guard_check_icall;
      puStack_20[4] = 0;
      puStack_20[5] = &DAT_01ee0198;
      puStack_20[6] = param_1;
    }
    FUN_016797d0(puStack_20);
    puStack_1c = puStack_20;
    if (puStack_20 != (undefined4 *)0x0) {
      LOCK();
      puStack_20[1] = puStack_20[1] + 1;
      UNLOCK();
    }
    pcStack_24 = (code *)((uint)pcStack_18 | 4);
    uStack_8._0_1_ = 0x15;
    FUN_01675290(piVar10);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
    cVar5 = FUN_01679300(&puStack_1c);
    if (cVar5 != '\0') {
      FUN_01679490();
      FUN_016791c0(&puStack_1c);
    }
    uStack_8._0_1_ = 0x10;
    if (puStack_1c != (undefined4 *)0x0) {
      piVar10 = puStack_1c + 1;
      LOCK();
      iVar4 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        FUN_01674ea0(puStack_1c);
      }
    }
  }
  if (DAT_01d62f38 != '\0') {
    LOCK();
    DAT_01ee0184 = DAT_01ee0184 + 1;
    UNLOCK();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
    if (DAT_01d62f38 == '\0') {
      uStack_38 = 0;
      uStack_34 = 0xf;
      appppuStack_48[0] = (undefined4 ****)((uint)appppuStack_48[0] & 0xffffff00);
      FUN_005542c0("ContentProvider",0xf);
    }
    else {
      uVar6 = GetCurrentProcessId();
      FUN_01675640(appppuStack_48,"ContentProvider_%d",uVar6);
    }
    uStack_8._0_1_ = 0x17;
    pppppuVar11 = appppuStack_48;
    if (0xf < uStack_34) {
      pppppuVar11 = (undefined4 *****)appppuStack_48[0];
    }
    FUN_0153e080(auStack_60,1,pppppuVar11);
    FUN_00550800();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
    if (0xf < uStack_34) {
      uVar15 = uStack_34 + 1;
      pppppuVar11 = (undefined4 *****)appppuStack_48[0];
      if (0xfff < uVar15) {
        pppppuVar11 = (undefined4 *****)appppuStack_48[0][-1];
        uVar15 = uStack_34 + 0x24;
        if (0x1f < (uint)((int)appppuStack_48[0] + (-4 - (int)pppppuVar11))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar11,uVar15);
      puVar9 = (undefined4 *)FUN_008c2df7();
      return puVar9;
    }
    uStack_8._0_1_ = 0x10;
    uStack_8._1_3_ = 0;
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  appppuStack_48[0] = (undefined4 ****)((uint)appppuStack_48[0] & 0xffffff00);
  FUN_005542c0("ContentProvider",0xf);
  uStack_8._0_1_ = 0x19;
  FUN_008a6520(appppuStack_48);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  if (0xf < uStack_34) {
    uVar15 = uStack_34 + 1;
    ppppuVar13 = appppuStack_48[0];
    if (0xfff < uVar15) {
      ppppuVar13 = (undefined4 ****)appppuStack_48[0][-1];
      uVar15 = uStack_34 + 0x24;
      if (0x1f < (uint)((int)appppuStack_48[0] + (-4 - (int)ppppuVar13))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar13,uVar15);
  }
  pcStack_24 = FUN_008cbdd0;
  puVar9 = (undefined4 *)FUN_008c09f0(auStack_30,&pcStack_24,&DAT_01d62e50,&DAT_01f6dd5c);
  uVar6 = *puVar9;
  uVar3 = puVar9[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  param_1[0x19] = uVar6;
  piVar10 = (int *)param_1[0x1a];
  param_1[0x1a] = uVar3;
  if (piVar10 != (int *)0x0) {
    LOCK();
    iVar4 = piVar10[1] + -1;
    piVar10[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar10)();
      LOCK();
      iVar4 = piVar10[2] + -1;
      piVar10[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  piVar10 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar2 = piVar10 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1[0x19] + 0xf8) = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14940 ; VA 0x008c2deb ; Catch_All@008c2deb */

undefined * Catch_All_008c2deb(void)

{
  return &DAT_008c2df1;
}



/* FUNCTION 14941 ; VA 0x008c2df7 ; FUN_008c2df7 */

void FUN_008c2df7(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  int unaff_EBX;
  int unaff_EBP;
  int unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 0x10;
  *(undefined4 *)(unaff_EBP + -0x34) = 0;
  *(undefined4 *)(unaff_EBP + -0x30) = 0xf;
  *(undefined *)(unaff_EBP + -0x44) = 0;
  FUN_005542c0("ContentProvider",0xf);
  *(undefined *)(unaff_EBP + -4) = 0x19;
  FUN_008a6520(unaff_EBP + -0x44);
  uVar2 = *(uint *)(unaff_EBP + -0x30);
  *(undefined *)(unaff_EBP + -4) = 0x10;
  if (0xf < uVar2) {
    iVar3 = *(int *)(unaff_EBP + -0x44);
    uVar9 = uVar2 + 1;
    iVar8 = iVar3;
    if (0xfff < uVar9) {
      iVar8 = *(int *)(iVar3 + -4);
      uVar9 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar9);
  }
  *(code **)(unaff_EBP + -0x20) = FUN_008cbdd0;
  puVar7 = (undefined4 *)
           FUN_008c09f0(unaff_EBP + -0x2c,unaff_EBP + -0x20,&DAT_01d62e50,&DAT_01f6dd5c);
  uVar4 = *puVar7;
  uVar5 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *(undefined4 *)(unaff_EDI + 100) = uVar4;
  piVar6 = *(int **)(unaff_EDI + 0x68);
  *(undefined4 *)(unaff_EDI + 0x68) = uVar5;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar3 = piVar6[1] + unaff_EBX;
    piVar6[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar3 = piVar6[2] + unaff_EBX;
      piVar6[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = *(int **)(unaff_EBP + -0x28);
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar3 = piVar6[1] + unaff_EBX;
    piVar6[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + unaff_EBX;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  *(undefined4 *)(*(int *)(unaff_EDI + 100) + 0xf8) = 1;
  return;
}



/* FUNCTION 14942 ; VA 0x008c2f20 ; FUN_008c2f20 */

undefined4 * __thiscall FUN_008c2f20(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be86e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
    }
    else {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
    }
  }
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  if (param_2[0x15] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x15] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x14] = param_2[0x14];
  param_1[0x15] = param_2[0x15];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14943 ; VA 0x008c3050 ; FUN_008c3050 */

void __fastcall FUN_008c3050(int param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x58);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x60,param_1 + 0x60,2);
      }
    }
    *(undefined4 *)(param_1 + 0x58) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x50);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_00637950();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14944 ; VA 0x008c30d0 ; FUN_008c30d0 */

void __fastcall FUN_008c30d0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x40);
  ExceptionList = &pvStack_10;
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x2c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0xf;
  *(undefined *)(param_1 + 0x2c) = 0;
  uVar1 = *(uint *)(param_1 + 8);
  uStack_8 = 0;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14945 ; VA 0x008c3170 ; FUN_008c3170 */

void __fastcall FUN_008c3170(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[6];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 8,param_1 + 8,2);
      }
    }
    param_1[6] = 0;
  }
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14946 ; VA 0x008c3210 ; FUN_008c3210 */

void __fastcall FUN_008c3210(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x6c);
  ExceptionList = &pvStack_10;
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x58);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0xf;
  *(undefined *)(param_1 + 0x58) = 0;
  piVar4 = *(int **)(param_1 + 0x54);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uVar2 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  piVar4 = *(int **)(param_1 + 0x2c);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uVar2 = *(uint *)(param_1 + 8);
  uStack_8 = 1;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14947 ; VA 0x008c3340 ; FUN_008c3340 */

void __fastcall FUN_008c3340(uint *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[0xe];
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xc];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[10];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *param_1;
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14948 ; VA 0x008c3410 ; FUN_008c3410 */

code * __fastcall FUN_008c3410(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  code *pcVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x54);
  ExceptionList = &pvStack_10;
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x40);
    uVar7 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar7 = uVar2 + 0x24;
      ExceptionList = &pvStack_10;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_008c3506;
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar5,uVar7);
  }
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0xf;
  *(undefined *)(param_1 + 0x40) = 0;
  uVar2 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x28);
    uVar7 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar7 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_008c3506:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  pcVar6 = *(code **)(param_1 + 8);
  uStack_8 = 0;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 2);
    uVar2 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 14949 ; VA 0x008c3510 ; FUN_008c3510 */

void __fastcall FUN_008c3510(uint *param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[8];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 10,param_1 + 10,2);
      }
    }
    param_1[8] = 0;
  }
  uVar1 = *param_1;
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14950 ; VA 0x008c35a0 ; FUN_008c35a0 */

code * __fastcall FUN_008c35a0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  uVar3 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0xc);
    uVar8 = uVar3 + 1;
    iVar7 = iVar4;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar4 + -4);
      uVar8 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pcVar6 = (code *)FUN_01674ea0(iVar7,uVar8);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar5 = *(int **)(param_1 + 8);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 14951 ; VA 0x008c3670 ; FUN_008c3670 */

void __fastcall FUN_008c3670(uint *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[9];
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *param_1;
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14952 ; VA 0x008c3700 ; FUN_008c3700 */

void __fastcall FUN_008c3700(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(param_1 + 0x60);
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x58);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x50);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x40);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x2c);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0xf;
  *(undefined *)(param_1 + 0x2c) = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14953 ; VA 0x008c3820 ; FUN_008c3820 */

code * __fastcall FUN_008c3820(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x18);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  piVar5 = *(int **)(param_1 + 0xc);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 14954 ; VA 0x008c38d0 ; FUN_008c38d0 */

void __fastcall FUN_008c38d0(int param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x50);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x58,param_1 + 0x58,2);
      }
    }
    *(undefined4 *)(param_1 + 0x50) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x4c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_00637950();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14955 ; VA 0x008c3950 ; FUN_008c3950 */

void __fastcall FUN_008c3950(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int **)(param_1 + 0x44) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x44) + 4))(1);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8d0();
  return;
}



/* FUNCTION 14956 ; VA 0x008c39b0 ; thunk_FUN_009cb8d0 */

void __fastcall thunk_FUN_009cb8d0(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::YieldFunctionDescriptor::vftable;
  FUN_00888910();
  FUN_008925b0();
  return;
}



/* FUNCTION 14957 ; VA 0x008c39c0 ; FUN_008c39c0 */

void __fastcall FUN_008c39c0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_008c3be0();
  return;
}



/* FUNCTION 14958 ; VA 0x008c3a20 ; FUN_008c3a20 */

void __fastcall FUN_008c3a20(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x58) {
    FUN_008c4380();
  }
  return;
}



/* FUNCTION 14959 ; VA 0x008c3a50 ; FUN_008c3a50 */

void __fastcall FUN_008c3a50(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x40) {
    FUN_008c3d70();
  }
  return;
}



/* FUNCTION 14960 ; VA 0x008c3a80 ; FUN_008c3a80 */

void __fastcall FUN_008c3a80(uint *param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1[9] != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(param_1[9] + 8))(param_1 + 10);
  }
  uVar1 = *param_1;
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14961 ; VA 0x008c3af0 ; FUN_008c3af0 */

void FUN_008c3af0(void)

{
  FUN_008c3d70();
  return;
}



/* FUNCTION 14962 ; VA 0x008c3b00 ; FUN_008c3b00 */

void __fastcall FUN_008c3b00(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 8);
  uStack_8 = 0;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14963 ; VA 0x008c3b60 ; FUN_008c3b60 */

void * __fastcall FUN_008c3b60(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    piVar1 = puVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      if ((undefined4 *)puVar3[0x20] != (undefined4 *)0x0) {
        pvVar4 = (void *)(*(code *)**(undefined4 **)puVar3[0x20])(puVar3);
        ExceptionList = pvStack_10;
        return pvVar4;
      }
      pvVar4 = (void *)(**(code **)*puVar3)(1);
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 14964 ; VA 0x008c3bd0 ; thunk_FUN_008c3d70 */

void __fastcall thunk_FUN_008c3d70(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[8];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 10,param_1 + 10,2);
      }
    }
    param_1[8] = 0;
  }
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14965 ; VA 0x008c3be0 ; FUN_008c3be0 */

void __fastcall FUN_008c3be0(int *param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  
  piVar5 = (int *)*param_1;
  piVar7 = (int *)*piVar5;
  *piVar5 = (int)piVar5;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar5 = (int *)*param_1;
  if (piVar7 != piVar5) {
    do {
      uVar1 = piVar7[7];
      piVar2 = (int *)*piVar7;
      if (0xf < uVar1) {
        iVar3 = piVar7[2];
        uVar6 = uVar1 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar6) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar6 = uVar1 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar6);
      }
      piVar7[6] = 0;
      piVar7[7] = 0xf;
      *(undefined *)(piVar7 + 2) = 0;
      FUN_01674ea0(piVar7,0x58);
      piVar5 = (int *)*param_1;
      piVar7 = piVar2;
    } while (piVar2 != piVar5);
  }
  FUN_01674ea0(piVar5,0x58);
  return;
}



/* FUNCTION 14966 ; VA 0x008c3c70 ; FUN_008c3c70 */

void * __fastcall FUN_008c3c70(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  void **ppvVar4;
  int iVar5;
  void *pvVar6;
  undefined *puStack_3c;
  code *pcStack_38;
  undefined4 *puStack_34;
  undefined **ppuStack_28;
  undefined auStack_24 [20];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  puStack_34 = (undefined4 *)*param_1;
  pvVar6 = ExceptionList;
  ppvVar4 = &pvStack_10;
  if (((puStack_34 != (undefined4 *)0x0) &&
      (((*(char *)(param_1 + 1) == '\0' ||
        (ppvVar4 = &pvStack_10, *(char *)(puStack_34 + 0x1d) == '\0')) &&
       (ppvVar4 = &pvStack_10, puStack_34[0x1e] == 0)))) &&
     (ppvVar4 = &pvStack_10, *(char *)(puStack_34 + 0x1f) == '\0')) {
    puStack_34 = (undefined4 *)&DAT_01ea8f84;
    pcStack_38 = FUN_005dbc60;
    puStack_3c = &DAT_01ea8f80;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_016de3db();
    if (iVar5 == 0) {
      puStack_34 = (undefined4 *)0x8c3d6a;
      FUN_0171d16a();
      pcVar3 = (code *)swi(3);
      pvVar6 = (void *)(*pcVar3)();
      return pvVar6;
    }
    puStack_34 = (undefined4 *)&DAT_01ea8f84;
    pcStack_38 = (code *)0x1;
    puStack_3c = (undefined *)0x8c3cdf;
    FUN_005dbdd0();
    puStack_34 = (undefined4 *)0x0;
    FUN_005dbd80(&ppuStack_28);
    FUN_005dbc80(&puStack_3c);
    FUN_008c7b20();
    puStack_34 = (undefined4 *)auStack_24;
    ppuStack_28 = std::exception::vftable;
    pcStack_38 = (code *)0x8c3d14;
    pvVar6 = (void *)FUN_0170c289();
    puStack_34 = (undefined4 *)*param_1;
    ppvVar4 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar4;
  uStack_8 = 0;
  if (puStack_34 != (undefined4 *)0x0) {
    LOCK();
    piVar1 = puStack_34 + 1;
    iVar5 = *piVar1;
    pvVar6 = (void *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      if ((undefined4 *)puStack_34[0x20] != (undefined4 *)0x0) {
        pcStack_38 = (code *)0x8c3d3f;
        pvVar6 = (void *)(*(code *)**(undefined4 **)puStack_34[0x20])();
        ExceptionList = pvStack_10;
        return pvVar6;
      }
      puVar2 = (undefined4 *)*puStack_34;
      puStack_34 = (undefined4 *)0x1;
      pcStack_38 = (code *)0x8c3d55;
      pvVar6 = (void *)(*(code *)*puVar2)();
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 14967 ; VA 0x008c3d70 ; FUN_008c3d70 */

void __fastcall FUN_008c3d70(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[8];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 10,param_1 + 10,2);
      }
    }
    param_1[8] = 0;
  }
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14968 ; VA 0x008c3e10 ; FUN_008c3e10 */

void __fastcall FUN_008c3e10(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_008ca4e0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 14969 ; VA 0x008c3e90 ; thunk_FUN_00d88a30 */

void __fastcall thunk_FUN_00d88a30(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  bool bVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Lua::WeakFunctionRef::vftable;
  if (param_1[7] != 0) {
    iVar1 = param_1[5];
    if (iVar1 == 0) {
      bVar3 = true;
    }
    else {
      bVar3 = *(int *)(iVar1 + 8) == 0;
    }
    if (!bVar3) {
      if (iVar1 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = *(undefined4 *)(iVar1 + 8);
      }
      FUN_00958600(uVar2,param_1[7]);
    }
  }
  FUN_00d88aa0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14970 ; VA 0x008c3ea0 ; FUN_008c3ea0 */

void __fastcall FUN_008c3ea0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_008ca4e0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 14971 ; VA 0x008c3eb0 ; thunk_FUN_008c7c70 */

void __fastcall thunk_FUN_008c7c70(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_008bd9e0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x30) * 0x30;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 14972 ; VA 0x008c3ec0 ; FUN_008c3ec0 */

void __fastcall FUN_008c3ec0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_008c4380();
        iVar2 = iVar2 + 0x58;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x58) * 0x58;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 14973 ; VA 0x008c3f40 ; FUN_008c3f40 */

void __fastcall FUN_008c3f40(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_008c3d70();
        iVar2 = iVar2 + 0x40;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xffffffc0;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 14974 ; VA 0x008c3fb0 ; FUN_008c3fb0 */

void __fastcall FUN_008c3fb0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined auStack_40 [24];
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::ContentProvider::vftable;
  param_1[0x16] = RBX::ContentProvider::vftable;
  if (DAT_01d62f38 == '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
    FUN_005542c0("ContentProvider",0xf);
    ppppuVar5 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar5 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0153da10(ppppuVar5,0);
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      ppppuVar5 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar8) {
        ppppuVar5 = (undefined4 ****)apppuStack_28[0][-1];
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar5))) goto LAB_008c4316;
      }
      FUN_01674ea0(ppppuVar5,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  }
  else {
    LOCK();
    DAT_01ee0184 = DAT_01ee0184 + -1;
    UNLOCK();
    if (DAT_01ee0184 == 0) {
      puVar4 = (undefined4 *)FUN_008cdc30(auStack_40);
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_0153da10(puVar4,1);
      FUN_005507b0();
    }
  }
  uVar8 = param_1[0x51];
  if (0xf < uVar8) {
    iVar3 = param_1[0x4c];
    uVar7 = uVar8 + 1;
    iVar6 = iVar3;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar7 = uVar8 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_008c4316;
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  param_1[0x50] = 0;
  param_1[0x51] = 0xf;
  *(undefined *)(param_1 + 0x4c) = 0;
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x4a];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar6 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_008c3e10();
  piVar1 = (int *)param_1[0x40];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x3e];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_008c3ec0();
  uVar8 = param_1[0x39];
  if (0xf < uVar8) {
    iVar3 = param_1[0x34];
    uVar7 = uVar8 + 1;
    iVar6 = iVar3;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar7 = uVar8 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_008c4316;
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  param_1[0x38] = 0;
  param_1[0x39] = 0xf;
  *(undefined *)(param_1 + 0x34) = 0;
  uVar8 = param_1[0x33];
  if (0xf < uVar8) {
    iVar3 = param_1[0x2e];
    uVar7 = uVar8 + 1;
    iVar6 = iVar3;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar7 = uVar8 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_008c4316;
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  param_1[0x32] = 0;
  param_1[0x33] = 0xf;
  *(undefined *)(param_1 + 0x2e) = 0;
  FUN_008c3e10();
  uVar8 = param_1[0x25];
  if (0xf < uVar8) {
    iVar3 = param_1[0x20];
    uVar7 = uVar8 + 1;
    iVar6 = iVar3;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar7 = uVar8 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) {
LAB_008c4316:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  param_1[0x24] = 0;
  param_1[0x25] = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  piVar1 = (int *)param_1[0x1f];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_008c3f40();
  piVar1 = (int *)param_1[0x1a];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_016790b0();
  FUN_00f45160();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14975 ; VA 0x008c4320 ; FUN_008c4320 */

void __fastcall FUN_008c4320(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 100);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x50);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 100) = 0xf;
  *(undefined *)(param_1 + 0x50) = 0;
  FUN_00637950();
  return;
}



/* FUNCTION 14976 ; VA 0x008c4380 ; FUN_008c4380 */

code * __fastcall FUN_008c4380(int param_1)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar3 = *(int **)(param_1 + 0x54);
  ExceptionList = &pvStack_10;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    ExceptionList = &pvStack_10;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uVar4 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  piVar3 = *(int **)(param_1 + 0x2c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  pcVar6 = *(code **)(param_1 + 8);
  uStack_8 = 1;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 14977 ; VA 0x008c4480 ; FUN_008c4480 */

undefined4 __thiscall FUN_008c4480(undefined4 param_1,uint *param_2)

{
  uint uVar1;
  uint uStack_30;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be888;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  uVar1 = *param_2;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_30 = uVar1;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,&uStack_28,0);
    }
    else {
      uStack_28 = param_2[2];
      uStack_24 = param_2[3];
      uStack_20 = param_2[4];
      uStack_1c = param_2[5];
      uStack_18 = *(undefined8 *)(param_2 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  FUN_008da730(param_1);
  uStack_8 = 1;
  if (((uStack_30 != 0) && ((uStack_30 & 1) == 0)) &&
     (*(code **)(uStack_30 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_30 & 0xfffffffe))(&uStack_28,&uStack_28,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14978 ; VA 0x008c4530 ; FUN_008c4530 */

/* WARNING: Removing unreachable block (ram,0x008c457e) */
/* WARNING: Removing unreachable block (ram,0x008c4582) */
/* WARNING: Removing unreachable block (ram,0x008c458b) */

undefined4 __thiscall FUN_008c4530(undefined4 param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be8a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005880d0(param_2);
  uStack_8 = 0;
  FUN_008da7c0(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14979 ; VA 0x008c45b0 ; FUN_008c45b0 */

undefined4 * __thiscall FUN_008c45b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  
  uVar2 = *param_2;
  uVar3 = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  *param_1 = uVar2;
  piVar4 = (int *)param_1[1];
  param_1[1] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  param_2[2] = 0;
  param_2[3] = 0;
  param_1[2] = uVar2;
  piVar4 = (int *)param_1[3];
  param_1[3] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 14980 ; VA 0x008c4650 ; FUN_008c4650 */

int * __thiscall FUN_008c4650(byte *param_1,int param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017be8d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_009cc8a0(param_2);
  FUN_00607080(&param_2,uStack_14,iVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return (int *)(param_2 + 8);
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  piVar3 = (int *)FUN_01674e20(0x38);
  piStack_18 = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  piStack_20 = piVar3;
  FUN_0170d1f0(piStack_18,0,0x30);
  uStack_1c = CONCAT11(uStack_1c._1_1_,1);
  FUN_0054ef60(aiStack_3c);
  piVar3[0xc] = 0;
  piVar3[0xd] = 0xf;
  *(undefined *)(piVar3 + 8) = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar7 = uStack_28 + 1;
    iVar4 = aiStack_3c[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_3c[0] + -4);
      uVar7 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005c9310(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = 1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    iVar4 = FUN_005c9310(uVar5 + uVar1);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar8;
      while (puVar2 != (undefined4 *)0x0) {
        piVar6 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar6 = (int)puVar8;
          puVar8 = puVar2;
        }
        else {
          *puVar8 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar6;
          *(undefined4 **)*piVar6 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar3[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar3;
    }
    *puVar8 = piVar6;
    *piVar3 = *piVar6;
  }
  else {
    *piVar3 = *piVar6;
    piVar6 = (int *)*puVar8;
  }
  *piVar6 = (int)piVar3;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 14981 ; VA 0x008c4880 ; FUN_008c4880 */

int __thiscall FUN_008c4880(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 in_stack_ffffffb0;
  undefined4 in_stack_ffffffb4;
  undefined4 in_stack_ffffffb8;
  undefined4 in_stack_ffffffbc;
  undefined4 uVar6;
  int *piVar7;
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017be8f8;
  pvStack_10 = ExceptionList;
  piVar7 = &iStack_18;
  uVar6 = 0x8c48ac;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(piVar7);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    if (param_3 == 0) {
      iVar3 = FUN_00d1b340(param_1,param_2,*(undefined4 *)(param_1 + 0x48),param_1 + 0x58,
                           *(undefined4 *)(param_1 + 0x78),4,0,*(undefined *)(param_1 + 0x7c),1,0);
    }
    else {
      if (DAT_01d6cae8 == '\0') {
        FUN_00d1af10(param_1,400);
      }
      else {
        FUN_0054ef60(param_3);
        FUN_00d1b0e0(param_1,400,in_stack_ffffffb0,in_stack_ffffffb4,in_stack_ffffffb8,
                     in_stack_ffffffbc,uVar6,piVar7);
      }
      iVar3 = param_1 + 0x58;
      if (*(int *)(param_1 + 0x58) != 0) {
        uVar6 = *(undefined4 *)(param_1 + 0x78);
        uVar4 = FUN_005500e0(param_3);
        uStack_8._0_1_ = 1;
        puVar5 = (undefined4 *)FUN_008c0b50(auStack_20,uVar4);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        uVar4 = *puVar5;
        uVar2 = puVar5[1];
        *puVar5 = 0;
        puVar5[1] = 0;
        FUN_00d1bdb0(iVar3,iStack_18,2,0,0,uVar6,uVar4,uVar2);
        FUN_00550b30();
        iVar3 = FUN_0170c289(auStack_28);
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar7 = piStack_14 + 1;
    iVar1 = *piVar7;
    iVar3 = *piVar7;
    *piVar7 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar7 = piStack_14 + 2;
      iVar1 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14982 ; VA 0x008c4a00 ; FUN_008c4a00 */

code * __thiscall
FUN_008c4a00(undefined4 *param_1,undefined4 param_2,int param_3,int *param_4,undefined4 param_5,
            int *param_6,int *param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  uint uVar7;
  int iStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  int *piStack_50;
  int *piStack_4c;
  code *apcStack_3c [2];
  int aiStack_34 [6];
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be948;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((param_3 == 0) || (ExceptionList = &pvStack_10, param_7 != (int *)0x0)) {
LAB_008c4b7c:
    if (param_8 != (int *)0x0) {
      LOCK();
      param_8[1] = param_8[1] + 1;
      UNLOCK();
    }
    piStack_50 = param_7;
    piStack_4c = param_8;
    if (param_6 != (int *)0x0) {
      LOCK();
      param_6[1] = param_6[1] + 1;
      UNLOCK();
    }
    uStack_58 = param_5;
    piStack_54 = param_6;
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    iStack_60 = param_3;
    piStack_5c = param_4;
    apcStack_3c[0] = (code *)FUN_008c6d70(param_2);
  }
  else {
    cVar3 = *(char *)(param_1 + 0x11);
    ExceptionList = &pvStack_10;
    if (DAT_01d62fc0 == '\0') {
LAB_008c4a55:
      if (((param_1[0xf] == 0) || (cVar3 != '\0')) ||
         ((DAT_01d62fa8 == '\0' && (DAT_01d62fb0 == '\0')))) goto LAB_008c4b7c;
    }
    else {
      piStack_4c = (int *)param_3;
      piStack_50 = (int *)0x8c4a4e;
      ExceptionList = &pvStack_10;
      cVar6 = FUN_008da580();
      if (cVar6 == '\0') goto LAB_008c4a55;
    }
    uVar7 = (uint)*(byte *)(param_1 + 0x11);
    puStack_14 = (undefined *)&piStack_50;
    uVar4 = param_1[10];
    uVar5 = *param_1;
    if (param_8 != (int *)0x0) {
      LOCK();
      param_8[1] = param_8[1] + 1;
      UNLOCK();
    }
    piStack_50 = param_7;
    piStack_4c = param_8;
    puStack_18 = (undefined *)&uStack_58;
    if (param_6 != (int *)0x0) {
      LOCK();
      param_6[1] = param_6[1] + 1;
      UNLOCK();
    }
    uStack_58 = param_5;
    piStack_54 = param_6;
    puStack_1c = (undefined *)&iStack_60;
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    iStack_60 = param_3;
    piStack_5c = param_4;
    uStack_8._0_1_ = 5;
    FUN_0054ef60(param_1 + 0xb);
    uStack_8._0_1_ = 2;
    FUN_008ccdd0(apcStack_3c,uVar5,param_1 + 2,uVar4);
    uStack_8._0_1_ = 6;
    FUN_0054f510(apcStack_3c);
    FUN_0151ddd0(uVar7,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (((apcStack_3c[0] != (code *)0x0) && (((uint)apcStack_3c[0] & 1) == 0)) &&
       (apcStack_3c[0] = *(code **)((uint)apcStack_3c[0] & 0xfffffffe),
       apcStack_3c[0] != (code *)0x0)) {
      piStack_54 = aiStack_34;
      piStack_4c = (int *)0x2;
      uStack_58 = 0x8c4b74;
      piStack_50 = piStack_54;
      apcStack_3c[0] = (code *)(*apcStack_3c[0])();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    apcStack_3c[0] = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_4c = (int *)0x8c4c18;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      apcStack_3c[0] = (code *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_4c = (int *)0x8c4c28;
        apcStack_3c[0] = (code *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    apcStack_3c[0] = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_4c = (int *)0x8c4c3e;
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      apcStack_3c[0] = (code *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_4c = (int *)0x8c4c4e;
        apcStack_3c[0] = (code *)(**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    apcStack_3c[0] = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_4c = (int *)0x8c4c64;
      apcStack_3c[0] = (code *)(**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_4c = (int *)0x8c4c73;
        apcStack_3c[0] = (code *)(**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return apcStack_3c[0];
}



/* FUNCTION 14983 ; VA 0x008c4c90 ; FUN_008c4c90 */

/* WARNING: Removing unreachable block (ram,0x008c4d61) */
/* WARNING: Removing unreachable block (ram,0x008c4d74) */
/* WARNING: Removing unreachable block (ram,0x008c4d7b) */
/* WARNING: Removing unreachable block (ram,0x008c4d82) */

int __thiscall
FUN_008c4c90(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be978;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  *(undefined4 *)*param_1 = param_2;
  puVar2 = (undefined4 *)param_1[1];
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  *puVar2 = param_5;
  piVar3 = (int *)puVar2[1];
  puVar2[1] = param_6;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  puVar2 = (undefined4 *)param_1[2];
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  *puVar2 = param_7;
  piVar3 = (int *)puVar2[1];
  puVar2[1] = param_8;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00587410();
  *(undefined *)param_1[4] = 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar4 = FUN_00588350();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar3 = param_4 + 1;
    iVar1 = *piVar3;
    iVar4 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar3 = param_4 + 2;
      iVar1 = *piVar3;
      iVar4 = *piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar3 = param_6 + 1;
    iVar1 = *piVar3;
    iVar4 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar3 = param_6 + 2;
      iVar1 = *piVar3;
      iVar4 = *piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar3 = param_8 + 1;
    iVar1 = *piVar3;
    iVar4 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar4 = (**(code **)*param_8)();
      LOCK();
      piVar3 = param_8 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar4 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 14984 ; VA 0x008c4e20 ; FUN_008c4e20 */

int __thiscall
FUN_008c4e20(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017be9b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  uStack_2c = param_7;
  piStack_28 = param_8;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  uStack_34 = param_5;
  piStack_30 = param_6;
  uStack_8 = 4;
  uStack_7 = 0;
  uVar3 = *(uint *)(param_1 + 0x18);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x20,&uStack_4c,0);
    }
    else {
      uStack_4c = *(undefined4 *)(param_1 + 0x20);
      uStack_48 = *(undefined4 *)(param_1 + 0x24);
      uStack_44 = *(undefined4 *)(param_1 + 0x28);
      uStack_40 = *(undefined4 *)(param_1 + 0x2c);
      uStack_3c = *(undefined8 *)(param_1 + 0x30);
    }
  }
  _uStack_8 = CONCAT31(uStack_7,2);
  iVar4 = FUN_008d5210(param_1,param_2,param_3);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_28 = (int *)0x8c4f11;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_28 = (int *)0x8c4f21;
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_28 = (int *)0x8c4f37;
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_28 = (int *)0x8c4f47;
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_28 = (int *)0x8c4f5d;
      iVar4 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_28 = (int *)0x8c4f6c;
        iVar4 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 14985 ; VA 0x008c4f80 ; FUN_008c4f80 */

int __thiscall FUN_008c4f80(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined4 *puStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017be9f0;
  pvStack_10 = ExceptionList;
  iStack_2c = param_1 + 0x58;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x54) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x54) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_34 = *(undefined4 *)(param_1 + 0x50);
  uStack_30 = *(undefined4 *)(param_1 + 0x54);
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  uStack_54 = 0;
  uVar3 = *(uint *)(param_1 + 0x30);
  if (uVar3 != 0) {
    uStack_54 = uVar3;
    if ((uVar3 & 1) == 0) {
      puStack_5c = &uStack_4c;
      uStack_58 = 0;
      uStack_64 = CONCAT44(param_1 + 0x38,0x8c501f);
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_4c = *(undefined4 *)(param_1 + 0x38);
      uStack_48 = *(undefined4 *)(param_1 + 0x3c);
      uStack_44 = *(undefined4 *)(param_1 + 0x40);
      uStack_40 = *(undefined4 *)(param_1 + 0x44);
      uStack_3c = *(undefined8 *)(param_1 + 0x48);
    }
  }
  if (*(int *)(param_1 + 0x2c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x2c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puStack_5c = *(undefined4 **)(param_1 + 0x28);
  uStack_58 = *(undefined4 *)(param_1 + 0x2c);
  iStack_8._0_1_ = 3;
  uVar3 = *(uint *)(param_1 + 8);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x10,&uStack_74,0);
    }
    else {
      uStack_74 = *(undefined4 *)(param_1 + 0x10);
      uStack_70 = *(undefined4 *)(param_1 + 0x14);
      uStack_6c = *(undefined4 *)(param_1 + 0x18);
      uStack_68 = *(undefined4 *)(param_1 + 0x1c);
      uStack_64 = *(undefined8 *)(param_1 + 0x20);
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar4 = FUN_008d7140(1);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_2c = 0x8c50bb;
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_2c = 0x8c50ca;
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 14986 ; VA 0x008c50e0 ; FUN_008c50e0 */

int __thiscall
FUN_008c50e0(int param_1,int param_2,undefined4 param_3,int *param_4,int param_5,int *param_6,
            undefined4 param_7,int *param_8)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined auStack_38 [12];
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bea52;
  pvStack_10 = ExceptionList;
  uStack_18 = (double)CONCAT44(param_1,(undefined4)uStack_18);
  uStack_8 = 2;
  uStack_7 = 0;
  if ((param_2 == 2) && (param_5 != 0)) {
    puVar3 = (undefined4 *)(param_1 + 0x40);
    puVar8 = &DAT_01d63080;
    if (0xf < DAT_01d63094) {
      puVar8 = DAT_01d63080;
    }
    if (0xf < *(uint *)(param_1 + 0x54)) {
      puVar3 = (undefined4 *)*puVar3;
    }
    ExceptionList = &pvStack_10;
    cVar2 = FUN_0055c360(puVar3,*(undefined4 *)(param_1 + 0x50),puVar8,DAT_01d63090);
    if (cVar2 != '\0') {
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      iStack_20 = param_5;
      piStack_1c = param_6;
      _uStack_8 = CONCAT31(uStack_7,3);
      FUN_008d4e30(&piStack_2c,param_5);
      if (piStack_2c != piStack_28) {
        piVar5 = piStack_2c + 1;
        do {
          if (piVar5[-1] == 0x193) {
            piVar4 = piVar5;
            if (0xf < (uint)piVar5[5]) {
              piVar4 = (int *)*piVar5;
            }
            cVar2 = FUN_0055c360(piVar4,piVar5[4],"Asset has not been reviewed",0x1b);
            if (cVar2 != '\0') {
              FUN_007c4590();
              if (param_6 != (int *)0x0) {
                LOCK();
                iVar7 = param_6[1] + -1;
                param_6[1] = iVar7;
                UNLOCK();
                if (iVar7 == 0) {
                  (**(code **)*param_6)();
                  LOCK();
                  iVar7 = param_6[2] + -1;
                  param_6[2] = iVar7;
                  UNLOCK();
                  if (iVar7 == 0) {
                    (**(code **)(*param_6 + 4))();
                  }
                }
              }
              iVar7 = uStack_18._4_4_;
              FUN_00587490(&iStack_20);
              uStack_8 = 4;
              if (iStack_20 != 0) {
                iVar6 = FUN_008cd0c0(iVar7 + 0x28);
                uStack_18 = ((double)iVar6 + (double)(&DAT_018c0d90)[-(iVar6 >> 0x1f)]) /
                            DAT_018c0d70;
                if (DAT_01d63010 != '\0') {
                  puVar3 = (undefined4 *)FUN_009cc5b0(auStack_38);
                  uStack_8 = 5;
                  if (0xf < (uint)puVar3[5]) {
                    puVar3 = (undefined4 *)*puVar3;
                  }
                  FUN_0086f2f0(2,
                               "Mesh %s failed to load because it has not been moderated yet. Retrying soon..."
                               ,puVar3);
                  uStack_8 = 4;
                  FUN_005507b0();
                }
                FUN_005587b0(iVar7);
                FUN_008d98b0();
              }
              uStack_8 = 2;
              FUN_00550b30();
              goto LAB_008c51fc;
            }
          }
          piVar4 = piVar5 + 6;
          piVar5 = piVar5 + 7;
        } while (piVar4 != piStack_28);
      }
      FUN_007c4590();
      uStack_8 = 2;
      if (param_6 != (int *)0x0) {
        LOCK();
        iVar7 = param_6[1] + -1;
        param_6[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*param_6)();
          LOCK();
          iVar7 = param_6[2] + -1;
          param_6[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*param_6 + 4))();
          }
        }
      }
    }
LAB_008c51fc:
    FUN_00563ec0(&iStack_20);
    uStack_8 = 6;
    piVar5 = (int *)FUN_01674e20(0xb8);
    uStack_8 = 7;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5[1] = 1;
      piVar5[2] = 1;
      *piVar5 = (int)std::
                     _Ref_count_obj<class_std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                     ::vftable;
      FUN_00565000(iStack_20,1,1);
    }
    piVar4 = piStack_1c;
    piStack_28 = piVar5 + 4;
    uStack_8 = 8;
    if (param_8 != (int *)0x0) {
      LOCK();
      param_8[1] = param_8[1] + 1;
      UNLOCK();
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    piStack_24 = piVar5;
    iVar7 = FUN_008c6d70(2,piStack_28,piVar5,iStack_20,piStack_1c,param_7,param_8);
    if (piVar5 != (int *)0x0) {
      piVar1 = piVar5 + 1;
      LOCK();
      iVar6 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1;
        iVar7 = *piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          iVar7 = (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar5 = piVar4 + 1;
      iVar6 = *piVar5;
      iVar7 = *piVar5;
      *piVar5 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar5 = piVar4 + 2;
        iVar6 = *piVar5;
        iVar7 = *piVar5;
        *piVar5 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          iVar7 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_8 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_8[1] = param_8[1] + 1;
      UNLOCK();
    }
    if (param_6 != (int *)0x0) {
      LOCK();
      param_6[1] = param_6[1] + 1;
      UNLOCK();
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    iVar7 = FUN_008c6d70(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar5 = param_4 + 1;
    iVar6 = *piVar5;
    iVar7 = *piVar5;
    *piVar5 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar5 = param_4 + 2;
      iVar6 = *piVar5;
      iVar7 = *piVar5;
      *piVar5 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar7 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar5 = param_6 + 1;
    iVar6 = *piVar5;
    iVar7 = *piVar5;
    *piVar5 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar5 = param_6 + 2;
      iVar6 = *piVar5;
      iVar7 = *piVar5;
      *piVar5 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar7 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar5 = param_8 + 1;
    iVar6 = *piVar5;
    iVar7 = *piVar5;
    *piVar5 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar7 = (**(code **)*param_8)();
      LOCK();
      piVar5 = param_8 + 2;
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar7 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 14987 ; VA 0x008c5520 ; FUN_008c5520 */

void __thiscall FUN_008c5520(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint in_stack_00000018;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined4 *puStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  int iStack_30;
  undefined *puStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017bea80;
  pvStack_10 = ExceptionList;
  puStack_2c = (undefined *)(param_1 + 0x58);
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x54) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x54) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_34 = *(undefined4 *)(param_1 + 0x50);
  iStack_30 = *(undefined4 *)(param_1 + 0x54);
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  uStack_54 = 0;
  uVar2 = *(uint *)(param_1 + 0x30);
  if (uVar2 != 0) {
    uStack_54 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_5c = &uStack_4c;
      uStack_58 = 0;
      uStack_64 = CONCAT44(param_1 + 0x38,0x8c55bf);
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_4c = *(undefined4 *)(param_1 + 0x38);
      uStack_48 = *(undefined4 *)(param_1 + 0x3c);
      uStack_44 = *(undefined4 *)(param_1 + 0x40);
      uStack_40 = *(undefined4 *)(param_1 + 0x44);
      uStack_3c = *(undefined8 *)(param_1 + 0x48);
    }
  }
  if (*(int *)(param_1 + 0x2c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x2c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puStack_5c = *(undefined4 **)(param_1 + 0x28);
  uStack_58 = *(undefined4 *)(param_1 + 0x2c);
  iStack_8._0_1_ = 3;
  uVar2 = *(uint *)(param_1 + 8);
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x10,&uStack_74,0);
    }
    else {
      uStack_74 = *(undefined4 *)(param_1 + 0x10);
      uStack_70 = *(undefined4 *)(param_1 + 0x14);
      uStack_6c = *(undefined4 *)(param_1 + 0x18);
      uStack_68 = *(undefined4 *)(param_1 + 0x1c);
      uStack_64 = *(undefined8 *)(param_1 + 0x20);
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_008d7140(2);
  if (0xf < in_stack_00000018) {
    puStack_2c = (undefined *)(in_stack_00000018 + 1);
    iVar3 = param_2;
    if (0xfff < puStack_2c) {
      iVar3 = *(int *)(param_2 + -4);
      puStack_2c = (undefined *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_2c = &UNK_008c5689;
        FUN_017167a3();
      }
    }
    uStack_34 = 0x8c566f;
    iStack_30 = iVar3;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14988 ; VA 0x008c5690 ; FUN_008c5690 */

int __thiscall
FUN_008c5690(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017be9b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  uStack_2c = param_7;
  piStack_28 = param_8;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  uStack_34 = param_5;
  piStack_30 = param_6;
  uStack_8 = 4;
  uStack_7 = 0;
  uVar3 = *(uint *)(param_1 + 0x18);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x20,&uStack_4c,0);
    }
    else {
      uStack_4c = *(undefined4 *)(param_1 + 0x20);
      uStack_48 = *(undefined4 *)(param_1 + 0x24);
      uStack_44 = *(undefined4 *)(param_1 + 0x28);
      uStack_40 = *(undefined4 *)(param_1 + 0x2c);
      uStack_3c = *(undefined8 *)(param_1 + 0x30);
    }
  }
  _uStack_8 = CONCAT31(uStack_7,2);
  iVar4 = FUN_008d5420(param_1,param_2,param_3);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_28 = (int *)0x8c5781;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_28 = (int *)0x8c5791;
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_28 = (int *)0x8c57a7;
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_28 = (int *)0x8c57b7;
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_28 = (int *)0x8c57cd;
      iVar4 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_28 = (int *)0x8c57dc;
        iVar4 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 14989 ; VA 0x008c57f0 ; FUN_008c57f0 */

int __thiscall
FUN_008c57f0(int *param_1,undefined **param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6,int param_7,int *param_8)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined *puStack_40;
  undefined *puStack_3c;
  undefined ***pppuStack_38;
  undefined **ppuStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017beab8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_7 == 0) {
    uStack_8 = 0xc;
    ppuStack_2c = param_2;
    ExceptionList = &pvStack_10;
    if (param_6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_6[1] = param_6[1] + 1;
      UNLOCK();
    }
    pppuStack_38 = &ppuStack_2c;
    uStack_28 = param_5;
    piStack_24 = param_6;
    puStack_3c = (undefined *)0x8c5916;
    iVar4 = FUN_008da320();
    piVar2 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_24 + 1;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pppuStack_38 = (undefined ***)0x8c592c;
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          pppuStack_38 = (undefined ***)0x8c593c;
          iVar4 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  else {
    param_1 = (int *)*param_1;
    pppuStack_38 = (undefined ***)&uStack_28;
    puStack_3c = (undefined *)(param_7 + 4);
    ppuStack_2c = std::exception::vftable;
    uStack_28 = 0;
    piStack_24 = (int *)0x0;
    puStack_40 = (undefined *)0x8c5842;
    ExceptionList = &pvStack_10;
    FUN_0170c226();
    puStack_40 = auStack_18;
    uStack_8._0_1_ = 4;
    FUN_016dfd92();
    uStack_8._0_1_ = 3;
    FUN_016dfd64(auStack_18,&ppuStack_2c,&DAT_01c243ac);
    uStack_8._0_1_ = 7;
    FUN_016dfd4d(auStack_20,auStack_18);
    uStack_8._0_1_ = 8;
    FUN_016dfdcc(auStack_18);
    ppuStack_2c = std::exception::vftable;
    FUN_0170c289(&uStack_28);
    iVar4 = *param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if ((iVar4 == 0) || ((*(char *)(param_1 + 1) != '\0' && (*(char *)(iVar4 + 0x74) != '\0')))) {
      puStack_3c = auStack_18;
      pppuStack_38 = (undefined ***)0x4;
      puStack_40 = (undefined *)0x8c59ca;
      pppuStack_38 = (undefined ***)FUN_005deb10();
                    /* WARNING: Subroutine does not return */
      puStack_3c = &UNK_008c59d3;
      FUN_016dfe59();
    }
    pppuStack_38 = (undefined ***)0x0;
    uStack_8._0_1_ = 10;
    FUN_016dfd4d(&puStack_40,auStack_20);
    uStack_8._0_1_ = 9;
    FUN_008c7b20();
    pppuStack_38 = (undefined ***)auStack_20;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    puStack_3c = (undefined *)0x8c58e5;
    iVar4 = FUN_016dfdcc();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar2 = param_4 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      pppuStack_38 = (undefined ***)0x8c5952;
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pppuStack_38 = (undefined ***)0x8c5962;
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar2 = param_6 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      pppuStack_38 = (undefined ***)0x8c5978;
      (**(code **)*param_6)();
      LOCK();
      piVar2 = param_6 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pppuStack_38 = (undefined ***)0x8c5988;
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar2 = param_8 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      pppuStack_38 = (undefined ***)0x8c599e;
      iVar4 = (**(code **)*param_8)();
      LOCK();
      piVar2 = param_8 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pppuStack_38 = (undefined ***)0x8c59ad;
        iVar4 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 14990 ; VA 0x008c59e0 ; FUN_008c59e0 */

void __thiscall FUN_008c59e0(int param_1,undefined4 param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined4 *puStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017beae8;
  pvStack_10 = ExceptionList;
  iStack_2c = param_1 + 0x58;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x54) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x54) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_34 = *(undefined4 *)(param_1 + 0x50);
  uStack_30 = *(undefined4 *)(param_1 + 0x54);
  uStack_8 = 0;
  uStack_54 = 0;
  uVar2 = *(uint *)(param_1 + 0x30);
  if (uVar2 != 0) {
    uStack_54 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_5c = &uStack_4c;
      uStack_58 = 0;
      uStack_64 = CONCAT44(param_1 + 0x38,0x8c5a7b);
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_4c = *(undefined4 *)(param_1 + 0x38);
      uStack_48 = *(undefined4 *)(param_1 + 0x3c);
      uStack_44 = *(undefined4 *)(param_1 + 0x40);
      uStack_40 = *(undefined4 *)(param_1 + 0x44);
      uStack_3c = *(undefined8 *)(param_1 + 0x48);
    }
  }
  if (*(int *)(param_1 + 0x2c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x2c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puStack_5c = *(undefined4 **)(param_1 + 0x28);
  uStack_58 = *(undefined4 *)(param_1 + 0x2c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar2 = *(uint *)(param_1 + 8);
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x10,&uStack_74,0);
    }
    else {
      uStack_74 = *(undefined4 *)(param_1 + 0x10);
      uStack_70 = *(undefined4 *)(param_1 + 0x14);
      uStack_6c = *(undefined4 *)(param_1 + 0x18);
      uStack_68 = *(undefined4 *)(param_1 + 0x1c);
      uStack_64 = *(undefined8 *)(param_1 + 0x20);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_008d7140(param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14991 ; VA 0x008c5b20 ; FUN_008c5b20 */

/* WARNING: Type propagation algorithm not settling */

int __thiscall
FUN_008c5b20(uint *param_1,int param_2,int *param_3,int *param_4,undefined4 param_5,int *param_6,
            undefined4 param_7,int *param_8)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined uVar8;
  undefined **appuStack_d0 [15];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_84;
  undefined **ppuStack_80;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint *puStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017beb5f;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff24;
  piStack_18 = (int *)0x0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  puStack_20 = param_1;
  if (param_2 == 1) {
    appuStack_d0[0] = &PTR_018be314;
    uStack_8 = 3;
    piStack_18 = (int *)0x1;
    ppuStack_80 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_84 = 0x48;
    ExceptionList = &pvStack_10;
    FUN_00554f20(appuStack_d0 + 1,0);
    uStack_8 = 5;
    *(undefined ***)(appuStack_d0[0][1] + (int)appuStack_d0) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)(appuStack_d0[0][1] + (int)&stack0xffffff2c) = appuStack_d0[0][1] + -0x50;
    FUN_0054ee60();
    appuStack_d0[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_94 = 0;
    uStack_90 = 4;
    uStack_8._0_1_ = 6;
    FUN_0056f130(*(undefined4 *)(*(int *)(*param_3 + 4) + 0x38 + (int)param_3));
    uStack_8._0_1_ = 7;
    uVar5 = FUN_0058c400(auStack_38);
    uStack_8._0_1_ = 8;
    FUN_0114fa10(&iStack_1c,uVar5);
    uStack_8._0_1_ = 10;
    if (0xf < uStack_24) {
      uVar7 = uStack_24 + 1;
      uVar6 = auStack_38[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_38[0] - 4);
        uVar7 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    if (*param_1 == 0) {
      uVar5 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar5);
    }
    (**(code **)((*param_1 & 0xfffffffe) + 4))
              (param_1 + 2,*(undefined4 *)(*(int *)(iStack_1c + 100) + 4));
    piVar2 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
          iVar4 = FUN_008c5d27();
          return iVar4;
        }
      }
    }
    iVar4 = FUN_00570540();
  }
  else {
    uVar8 = 0;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffff24;
    FUN_005542c0("Request failed",0xe);
    iVar4 = FUN_005e65e0(uVar8);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar2 = param_4 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar2 = param_6 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar2 = param_6 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar2 = param_8 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*param_8)();
      LOCK();
      piVar2 = param_8 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 14992 ; VA 0x008c5cf1 ; Catch@008c5cf1 */

undefined * Catch_008c5cf1(void)

{
  undefined uVar1;
  
  uVar1 = 0;
  FUN_005542c0("Failed to read mesh",0x13);
  FUN_005e65e0(uVar1);
  return &DAT_008c5d24;
}



/* FUNCTION 14993 ; VA 0x008c5d27 ; FUN_008c5d27 */

int FUN_008c5d27(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int unaff_EBP;
  int unaff_ESI;
  
  iVar4 = FUN_00570540();
  piVar3 = *(int **)(unaff_EBP + 0x10);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + unaff_ESI;
    UNLOCK();
    if (iVar2 + unaff_ESI == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + unaff_ESI;
      UNLOCK();
      if (iVar2 + unaff_ESI == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(unaff_EBP + 0x18);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + unaff_ESI;
    UNLOCK();
    if (iVar2 + unaff_ESI == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + unaff_ESI;
      UNLOCK();
      if (iVar2 + unaff_ESI == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(unaff_EBP + 0x20);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + unaff_ESI;
    UNLOCK();
    if (iVar2 + unaff_ESI == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + unaff_ESI;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return iVar4;
}



/* FUNCTION 14994 ; VA 0x008c5dd0 ; FUN_008c5dd0 */

int __fastcall FUN_008c5dd0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017beb9a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  puVar5 = (undefined4 *)FUN_0151a8d0(aiStack_40,*(undefined4 *)(param_1 + 0x20));
  uStack_8 = 0;
  if (7 < (uint)puVar5[5]) {
    puVar5 = (undefined4 *)*puVar5;
  }
  piVar6 = (int *)FUN_01674e20(200);
  uStack_8._0_1_ = 1;
  piStack_18 = piVar6;
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)0x0;
  }
  else {
    piVar6[1] = 1;
    piVar6[2] = 1;
    *piVar6 = (int)std::
                   _Ref_count_obj<class_std::basic_ifstream<char,struct_std::char_traits<char>_>_>::
                   vftable;
    FUN_0054ebd0(puVar5,0x21,0x40,1);
  }
  piVar1 = piVar6 + 4;
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  piStack_20 = piVar1;
  piStack_1c = piVar6;
  if (7 < uStack_2c) {
    uVar8 = uStack_2c * 2 + 2;
    iVar7 = aiStack_40[0];
    if (0xfff < uVar8) {
      iVar7 = *(int *)(aiStack_40[0] + -4);
      uVar8 = uStack_2c * 2 + 0x25;
      if (0x1f < (aiStack_40[0] - iVar7) - 4U) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar8);
  }
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  piVar2 = piVar6 + 1;
  if (piVar6 != (int *)0x0) {
    LOCK();
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  iVar7 = FUN_008c6d70(1,piVar1,piVar6,0,0,0,0);
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar7 = (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar7 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 14995 ; VA 0x008c5f40 ; FUN_008c5f40 */

void FUN_008c5f40(undefined *param_1,int param_2)

{
  if (param_2 != 0) {
    do {
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0xf;
      *param_1 = 0;
      *(undefined4 *)(param_1 + 0x20) = 0;
      param_1 = param_1 + 0x40;
      param_2 = param_2 + -1;
    } while (param_2 != 0);
  }
  return;
}



/* FUNCTION 14996 ; VA 0x008c5f80 ; FUN_008c5f80 */

/* WARNING: Type propagation algorithm not settling */

void __fastcall FUN_008c5f80(undefined4 *param_1)

{
  uint uVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  undefined **ppuVar8;
  undefined4 auStack_294 [5];
  undefined4 uStack_280;
  undefined ***pppuStack_27c;
  int *piStack_278;
  undefined ***pppuStack_274;
  undefined ***pppuStack_270;
  undefined auStack_264 [64];
  undefined auStack_224 [64];
  undefined auStack_1e4 [64];
  undefined auStack_1a4 [64];
  undefined auStack_164 [60];
  int iStack_128;
  undefined **appuStack_124 [14];
  int aiStack_ec [5];
  undefined4 uStack_d8;
  undefined **appuStack_d4 [18];
  int aiStack_8c [5];
  uint uStack_78;
  uint auStack_74 [2];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  int iStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bec6c;
  pvStack_10 = ExceptionList;
  appuStack_124[0] = &PTR_018be314;
  pppuStack_270 = (undefined ***)0x0;
  pppuStack_274 = appuStack_124 + 1;
  uStack_8 = 0;
  piStack_1c = (int *)0x1;
  appuStack_d4[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_d8 = 0x48;
  piStack_278 = (int *)0x8c5fec;
  ExceptionList = &pvStack_10;
  puStack_28 = param_1;
  FUN_00554f20();
  uStack_8 = 2;
  *(undefined ***)(appuStack_124[0][1] + (int)appuStack_124) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_128 + (int)appuStack_124[0][1]) = appuStack_124[0][1] + -0x50;
  pppuStack_270 = (undefined ***)0x8c6025;
  uVar4 = FUN_0054ee60();
  appuStack_124[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  aiStack_ec[1] = 0;
  aiStack_ec[2] = 4;
  pppuStack_270 = (undefined ***)CONCAT31((int3)((uint)uVar4 >> 8),*(undefined *)(param_1 + 0x11));
  pppuStack_274 = (undefined ***)(param_1 + 0xb);
  uStack_8 = 3;
  piStack_278 = (int *)param_1[0x13];
  pppuStack_27c = appuStack_124;
  uStack_280 = 0x8c6061;
  iVar5 = FUN_008c9de0();
  piStack_30 = (int *)0x0;
  piStack_2c = (int *)0x0;
  piStack_24 = (int *)0x0;
  piStack_20 = (int *)0x0;
  uStack_8._0_1_ = 5;
  if (DAT_01d62fc8 != '\0') {
    if (iVar5 == 1) {
      piVar6 = (int *)param_1[0x14];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = (int *)param_1[0x14];
      }
      piStack_30 = (int *)param_1[0x13];
      pppuStack_270 = (undefined ***)(param_1 + 0x15);
      pppuStack_274 = (undefined ***)0x8c60b8;
      piStack_2c = piVar6;
      piStack_1c = piStack_30;
      FUN_0056ecd0();
      piVar7 = piStack_20;
      goto LAB_008c61d8;
    }
    if (iVar5 == -1) {
      pppuStack_270 = (undefined ***)0x0;
      pppuStack_274 = (undefined ***)0x4;
      if (*(int *)((int)aiStack_ec + (int)appuStack_124[0][1]) != 0) {
        pppuStack_274 = (undefined ***)0x0;
      }
      piStack_278 = (int *)0x8c60eb;
      FUN_00554460();
    }
  }
  pppuStack_270 = (undefined ***)aiStack_8c;
  pppuStack_274 = (undefined ***)0x8c60fd;
  FUN_0058c400();
  pppuStack_270 = (undefined ***)0xb8;
  uStack_8._0_1_ = 6;
  pppuStack_274 = (undefined ***)0x8c610b;
  piVar6 = (int *)FUN_01674e20();
  uStack_8._0_1_ = 7;
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)0x0;
  }
  else {
    pppuStack_270 = (undefined ***)0x1;
    pppuStack_274 = (undefined ***)0x1;
    piStack_278 = aiStack_8c;
    piVar6[1] = 1;
    piVar6[2] = 1;
    *piVar6 = (int)std::
                   _Ref_count_obj<class_std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                   ::vftable;
    pppuStack_27c = (undefined ***)0x8c6142;
    piStack_1c = piVar6;
    FUN_00565000();
  }
  piStack_30 = piVar6 + 4;
  uStack_8._0_1_ = 6;
  pppuStack_270 = (undefined ***)0x24;
  pppuStack_274 = (undefined ***)0x8c615d;
  piStack_2c = piVar6;
  piStack_1c = piStack_30;
  piVar7 = (int *)FUN_01674e20();
  uStack_8._0_1_ = 8;
  piStack_18 = piVar7;
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)0x0;
  }
  else {
    pppuStack_270 = (undefined ***)aiStack_8c;
    piVar7[1] = 1;
    piVar7[2] = 1;
    *piVar7 = (int)std::
                   _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                   ::vftable;
    pppuStack_274 = (undefined ***)0x8c6190;
    FUN_0054ef60();
  }
  piStack_24 = piVar7 + 3;
  uStack_8._0_1_ = 5;
  piStack_20 = piVar7;
  if (0xf < uStack_78) {
    pppuStack_270 = (undefined ***)(uStack_78 + 1);
    iVar5 = aiStack_8c[0];
    if (0xfff < pppuStack_270) {
      iVar5 = *(int *)(aiStack_8c[0] + -4);
      pppuStack_270 = (undefined ***)(uStack_78 + 0x24);
      if (0x1f < (aiStack_8c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        pppuStack_270 = (undefined ***)&UNK_008c6495;
        FUN_017167a3();
      }
    }
    piStack_278 = (int *)0x8c61d5;
    pppuStack_274 = (undefined ***)iVar5;
    FUN_01674ea0();
  }
LAB_008c61d8:
  auStack_74[0] = 0;
  pppuStack_270 = (undefined ***)puStack_28[10];
  uVar1 = puStack_28[2];
  pppuStack_274 = (undefined ***)*puStack_28;
  piStack_18 = auStack_294;
  piVar2 = auStack_294;
  if (uVar1 != 0) {
    auStack_74[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(puStack_28 + 4,&uStack_6c,0);
      piVar2 = piStack_18;
    }
    else {
      uStack_6c = puStack_28[4];
      uStack_68 = puStack_28[5];
      uStack_64 = puStack_28[6];
      uStack_60 = puStack_28[7];
      uStack_5c = *(undefined8 *)(puStack_28 + 8);
      piVar2 = auStack_294;
    }
  }
  piStack_18 = piVar2;
  uStack_54 = puStack_28[0x12];
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
  }
  piStack_50 = piStack_1c;
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
  }
  iStack_3c = puStack_28[0x18];
  piStack_48 = piStack_24;
  if (iStack_3c != 0) {
    LOCK();
    *(int *)(iStack_3c + 4) = *(int *)(iStack_3c + 4) + 1;
    UNLOCK();
    iStack_3c = puStack_28[0x18];
  }
  uStack_40 = puStack_28[0x17];
  uStack_8._0_1_ = 9;
  piStack_4c = piVar6;
  piStack_44 = piVar7;
  FUN_008c1150(auStack_74);
  uStack_8._0_1_ = 10;
  *piStack_18 = 0;
  FUN_008c1150(auStack_264);
  uStack_8._0_1_ = 0xb;
  FUN_008c1150(auStack_224);
  uStack_8._0_1_ = 0xc;
  FUN_008c1150(auStack_1e4);
  uStack_8._0_1_ = 0xd;
  cVar3 = FUN_00585a40(auStack_164);
  if (cVar3 == '\0') {
    FUN_008c1150(auStack_164);
    uStack_8._0_1_ = 0xe;
    iStack_34 = FUN_01674e20(0x40);
    uStack_8._0_1_ = 0xf;
    if (iStack_34 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_008c1150(auStack_1a4);
    }
    piStack_18[2] = uVar4;
    FUN_008c3340();
    FUN_008c3340();
    cStack_11 = '\x01';
  }
  else {
    FUN_008c3340();
    cStack_11 = '\0';
  }
  FUN_008c3340();
  ppuVar8 = &PTR_FUN_01929914;
  if (cStack_11 == '\0') {
    ppuVar8 = (undefined **)0x0;
  }
  *piStack_18 = (int)ppuVar8;
  FUN_008c3340();
  FUN_008c3340();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008c3340();
  FUN_00d1bff0();
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar5 = piVar7[1] + -1;
    piVar7[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      pppuStack_270 = (undefined ***)0x8c63ce;
      (**(code **)*piVar7)();
      LOCK();
      iVar5 = piVar7[2] + -1;
      piVar7[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        pppuStack_270 = (undefined ***)0x8c63e1;
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar5 = piVar6[1] + -1;
    piVar6[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      pppuStack_270 = (undefined ***)0x8c63f5;
      (**(code **)*piVar6)();
      LOCK();
      piVar7 = piVar6 + 2;
      iVar5 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        pppuStack_270 = (undefined ***)0x8c6407;
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  *(undefined ***)(appuStack_124[0][1] + (int)appuStack_124) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_128 + (int)appuStack_124[0][1]) = appuStack_124[0][1] + -0x50;
  pppuStack_270 = (undefined ***)0x8c6439;
  FUN_0056b950();
  *(undefined ***)(appuStack_124[0][1] + (int)appuStack_124) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&iStack_128 + (int)appuStack_124[0][1]) = appuStack_124[0][1] + -8;
  pppuStack_270 = appuStack_d4;
  uStack_8 = 0x10;
  appuStack_d4[0] = std::ios_base::vftable;
  pppuStack_274 = (undefined ***)0x8c647d;
  FUN_016de551();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14997 ; VA 0x008c64a0 ; FUN_008c64a0 */

int * __thiscall
FUN_008c64a0(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  code *pcVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bec90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  *(int *)*param_1 = *(int *)*param_1 + -1;
  iVar3 = *(int *)param_1[2];
  if ((uint)param_1[4] < (uint)(((int *)param_1[2])[1] - iVar3 >> 3)) {
    puVar2 = (undefined4 *)(iVar3 + param_1[4] * 8);
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    *puVar2 = param_3;
    piVar5 = (int *)puVar2[1];
    puVar2[1] = param_4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar3 = piVar5[1] + -1;
      piVar5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar3 = piVar5[2] + -1;
        piVar5[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    piVar5 = (int *)*param_1;
    if (*piVar5 == 0) {
      if (param_1[3] != 0) {
        LOCK();
        piVar5 = (int *)(param_1[3] + 4);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
      piVar5 = (int *)FUN_008c6c20(param_1[2],param_1[3]);
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      piVar1 = param_4 + 1;
      iVar3 = *piVar1;
      piVar5 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*param_4)();
        LOCK();
        piVar1 = param_4 + 2;
        iVar3 = *piVar1;
        piVar5 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar5 = (int *)(**(code **)(*param_4 + 4))();
        }
      }
    }
    if (param_6 != (int *)0x0) {
      LOCK();
      piVar1 = param_6 + 1;
      iVar3 = *piVar1;
      piVar5 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar5 = (int *)(**(code **)*param_6)();
        LOCK();
        piVar1 = param_6 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piVar5 = (int *)(**(code **)(*param_6 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return piVar5;
  }
  FUN_00577c40();
  pcVar4 = (code *)swi(3);
  piVar5 = (int *)(*pcVar4)();
  return piVar5;
}



/* FUNCTION 14998 ; VA 0x008c65c0 ; FUN_008c65c0 */

int __fastcall FUN_008c65c0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  double *pdVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  undefined auStack_2c [8];
  int iStack_24;
  undefined uStack_20;
  int iStack_1c;
  int *piStack_18;
  double *pdStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017becb0;
  pvStack_10 = ExceptionList;
  iStack_1c = 0;
  piStack_18 = (int *)0x0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00602ce0(param_1);
  iVar2 = iStack_1c;
  uStack_8 = 0;
  if (iStack_1c != 0) {
    pdStack_14 = (double *)FUN_016830f0(auStack_2c);
    iStack_24 = iVar2 + 8;
    iVar3 = FUN_016dee6d(iStack_24);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    uStack_20 = 1;
    piVar1 = (int *)(iVar2 + 0x3c);
    uStack_8._0_1_ = 1;
    piVar6 = (int *)**(int **)(iVar2 + 0x3c);
    pdVar5 = pdStack_14;
    iVar8 = iVar2;
    if (piVar6 != *(int **)(iVar2 + 0x3c)) {
      do {
        if (*pdVar5 <=
            *(double *)(iVar8 + 0x68) * *(double *)(piVar6 + 0x12) + *(double *)(piVar6 + 0x14)) {
          piVar7 = (int *)*piVar6;
        }
        else {
          uVar4 = FUN_009cc8a0(piVar6 + 2);
          iVar3 = *(int *)(iVar8 + 0x44);
          uVar4 = *(uint *)(iVar8 + 0x50) & uVar4;
          if (*(int **)(iVar3 + 4 + uVar4 * 8) == piVar6) {
            if (*(int **)(iVar3 + uVar4 * 8) == piVar6) {
              *(int *)(iVar3 + uVar4 * 8) = *piVar1;
              *(int *)(*(int *)(iVar8 + 0x44) + 4 + uVar4 * 8) = *piVar1;
            }
            else {
              *(int *)(iVar3 + 4 + uVar4 * 8) = piVar6[1];
            }
          }
          else if (*(int **)(iVar3 + uVar4 * 8) == piVar6) {
            *(int *)(iVar3 + uVar4 * 8) = *piVar6;
          }
          piVar7 = (int *)*piVar6;
          *(int **)piVar6[1] = piVar7;
          *(int *)(*piVar6 + 4) = piVar6[1];
          *(int *)(iVar2 + 0x40) = *(int *)(iVar2 + 0x40) + -1;
          FUN_008c78a0(piVar6);
          pdVar5 = pdStack_14;
          iVar8 = iStack_1c;
        }
        piVar6 = piVar7;
      } while (piVar7 != (int *)*piVar1);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar3 = FUN_016deec8(iVar8 + 8);
    if (iVar3 != 0) {
      iVar3 = FUN_016df3c9(iVar3);
    }
    *(undefined *)(iVar8 + 0x58) = 0;
  }
  piVar1 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar6 = piStack_18 + 1;
    iVar2 = *piVar6;
    iVar3 = *piVar6;
    *piVar6 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_18)();
      LOCK();
      piVar6 = piVar1 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14999 ; VA 0x008c6740 ; FUN_008c6740 */

int __thiscall
FUN_008c6740(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined4 *puStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017becf0;
  pvStack_10 = ExceptionList;
  iStack_2c = param_1 + 0x58;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x54) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x54) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_34 = *(undefined4 *)(param_1 + 0x50);
  uStack_30 = *(undefined4 *)(param_1 + 0x54);
  uStack_8 = 3;
  uStack_7 = 0;
  uStack_54 = 0;
  uVar3 = *(uint *)(param_1 + 0x30);
  if (uVar3 != 0) {
    uStack_54 = uVar3;
    if ((uVar3 & 1) == 0) {
      puStack_5c = &uStack_4c;
      uStack_58 = 0;
      uStack_64 = CONCAT44(param_1 + 0x38,0x8c67df);
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_4c = *(undefined4 *)(param_1 + 0x38);
      uStack_48 = *(undefined4 *)(param_1 + 0x3c);
      uStack_44 = *(undefined4 *)(param_1 + 0x40);
      uStack_40 = *(undefined4 *)(param_1 + 0x44);
      uStack_3c = *(undefined8 *)(param_1 + 0x48);
    }
  }
  if (*(int *)(param_1 + 0x2c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x2c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puStack_5c = *(undefined4 **)(param_1 + 0x28);
  uStack_58 = *(undefined4 *)(param_1 + 0x2c);
  uStack_8 = 5;
  uVar3 = *(uint *)(param_1 + 8);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x10,&uStack_74,0);
    }
    else {
      uStack_74 = *(undefined4 *)(param_1 + 0x10);
      uStack_70 = *(undefined4 *)(param_1 + 0x14);
      uStack_6c = *(undefined4 *)(param_1 + 0x18);
      uStack_68 = *(undefined4 *)(param_1 + 0x1c);
      uStack_64 = *(undefined8 *)(param_1 + 0x20);
    }
  }
  _uStack_8 = CONCAT31(uStack_7,2);
  iVar4 = FUN_008d7140(param_2);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_2c = 0x8c687c;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iStack_2c = 0x8c688c;
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_2c = 0x8c68a2;
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iStack_2c = 0x8c68b2;
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_2c = 0x8c68c8;
      iVar4 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_2c = 0x8c68d7;
        iVar4 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}


