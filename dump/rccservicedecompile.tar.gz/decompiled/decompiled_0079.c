/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 19750 ; VA 0x00a006f0 ; FUN_00a006f0 */

float10 __fastcall FUN_00a006f0(undefined4 param_1)

{
  double in_XMM0_Qa;
  
  FUN_01522960(param_1);
  FUN_016f3fe0();
  return (float10)((float)in_XMM0_Qa * DAT_018d6c1c * DAT_018d6c1c);
}



/* FUNCTION 19751 ; VA 0x00a00730 ; FUN_00a00730 */

uint __fastcall FUN_00a00730(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0xd0);
  if ((uVar1 == *(uint *)(param_1 + 0xd4)) &&
     (uVar1 = *(uint *)(param_1 + 0xf8), uVar1 == *(uint *)(param_1 + 0xfc))) {
    return uVar1 & 0xffffff00;
  }
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 19752 ; VA 0x00a00760 ; FUN_00a00760 */

uint __fastcall FUN_00a00760(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x80);
  if ((uVar1 == *(uint *)(param_1 + 0x84)) &&
     (uVar1 = *(uint *)(param_1 + 0xa8), uVar1 == *(uint *)(param_1 + 0xac))) {
    return uVar1 & 0xffffff00;
  }
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 19753 ; VA 0x00a00790 ; FUN_00a00790 */

void FUN_00a00790(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a011b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 19754 ; VA 0x00a007d0 ; FUN_00a007d0 */

int __thiscall FUN_00a007d0(int param_1,int param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = (int)param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9d3a;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  iVar4 = FUN_008a4210(param_2,param_3);
  if (param_2 != 0) {
    iVar4 = FUN_01679490();
  }
  if (iVar2 != 0) {
    uStack_8 = 0;
    puVar5 = (undefined4 *)FUN_009fd340(&uStack_28);
    uStack_14 = 1;
    FUN_00ca83c0();
    uVar6 = *puVar5;
    uVar7 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x58) = uVar6;
    piVar3 = *(int **)(param_1 + 0x5c);
    *(undefined4 *)(param_1 + 0x5c) = uVar7;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_24;
    uStack_14 = 0;
    uStack_8 = 0xffffffff;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    iVar4 = FUN_008a65e0(param_1,0);
    if (DAT_01d6575c != '\0') {
      FUN_0060e0c0(&uStack_28,param_1);
      uStack_8 = 1;
      uVar6 = FUN_0153c830();
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[2] = piStack_24[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 3;
      uVar7 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 4;
      uStack_1c = uVar7;
      puStack_20 = (undefined4 *)FUN_01674e20(0x20);
      if (puStack_20 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puStack_20 = 0;
        puStack_20[1] = 1;
        puStack_20[2] = FUN_009ff440;
        puStack_20[3] = FUN_005d3660;
        puStack_20[4] = 0;
        puStack_20[5] = uVar6;
        puStack_20[6] = 0;
        puStack_20[7] = 0;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[2] = piStack_24[2] + 1;
          UNLOCK();
        }
        puStack_20[6] = uStack_28;
        puStack_20[7] = piStack_24;
        puVar5 = puStack_20;
      }
      FUN_016797d0(puVar5);
      if (puVar5 != (undefined4 *)0x0) {
        LOCK();
        puVar5[1] = puVar5[1] + 1;
        UNLOCK();
      }
      uStack_14 = 2;
      uStack_8._0_1_ = 5;
      param_3 = puVar5;
      FUN_01675290(uVar7);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      iVar4 = FUN_01679300(&param_3);
      if ((char)iVar4 != '\0') {
        FUN_01679490();
        iVar4 = FUN_016791c0(&param_3);
      }
      if (param_3 != (undefined4 *)0x0) {
        piVar3 = param_3 + 1;
        LOCK();
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        iVar4 = iVar4 + -1;
        if (iVar4 == 0) {
          iVar4 = FUN_01674ea0(param_3);
        }
      }
      if (piStack_24 != (int *)0x0) {
        piVar3 = piStack_24 + 2;
        LOCK();
        iVar2 = *piVar3;
        iVar4 = *piVar3;
        *piVar3 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar4 = (**(code **)(*piStack_24 + 4))();
        }
        LOCK();
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 19755 ; VA 0x00a00a30 ; FUN_00a00a30 */

void FUN_00a00a30(undefined4 param_1)

{
  FUN_00a01ab0(param_1);
  FUN_00a00ab0();
  FUN_00a01ab0(param_1);
  FUN_00a00ab0();
  return;
}



/* FUNCTION 19756 ; VA 0x00a00a70 ; FUN_00a00a70 */

void FUN_00a00a70(undefined4 param_1)

{
  FUN_00a01ab0(param_1);
  FUN_00a00ab0();
  FUN_00a01ab0(param_1);
  FUN_00a00ab0();
  return;
}



/* FUNCTION 19757 ; VA 0x00a00ab0 ; FUN_00a00ab0 */

void __fastcall FUN_00a00ab0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0x1c);
  iVar2 = *(int *)(param_1 + 0x18);
  if (iVar2 != iVar1) {
    do {
      FUN_00a00b00(iVar2);
      iVar2 = iVar2 + 0x48;
    } while (iVar2 != iVar1);
    iVar1 = *(int *)(param_1 + 0x1c);
  }
  iVar2 = *(int *)(param_1 + 0x18);
  if (iVar2 != iVar1) {
    do {
      FUN_0096ca80();
      iVar2 = iVar2 + 0x48;
    } while (iVar2 != iVar1);
    *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(param_1 + 0x18);
    return;
  }
  *(int *)(param_1 + 0x1c) = iVar2;
  return;
}



/* FUNCTION 19758 ; VA 0x00a00b00 ; FUN_00a00b00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_00a00b00(int param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined *puVar2;
  void *pvVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  undefined4 uVar9;
  uint uVar10;
  int *piVar11;
  uint uVar12;
  int iVar13;
  undefined4 *puVar14;
  undefined4 uStack_140;
  int iStack_13c;
  int *piStack_138;
  int *piStack_134;
  int *piStack_70;
  int *piStack_6c;
  uint auStack_68 [4];
  int *piStack_58;
  int *piStack_54;
  int iStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  int *piStack_44;
  int iStack_40;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9db3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00888650(&uStack_4c);
  uStack_8 = 0;
  iVar13 = *(int *)(param_1 + 0xc) - *(int *)(param_1 + 8) >> 5;
  piStack_58 = (int *)0x0;
  piStack_54 = (int *)&DAT_0000000f;
  auStack_68[0] = auStack_68[0] & 0xffffff00;
  FUN_005542c0("TotalCount",10);
  uStack_8._0_1_ = 1;
  iVar4 = FUN_005c4c00(auStack_68);
  uVar5 = FUN_0088c8c0();
  *(undefined4 *)(iVar4 + 0x18) = uVar5;
  iVar6 = FUN_005c9cc0();
  iVar7 = *(int *)(iVar4 + 0x1c);
  if (iVar7 == iVar6) {
    *(int *)(iVar4 + 0x20) = iVar13;
  }
  else {
    if (iVar7 != 0) {
      (**(code **)(iVar7 + 8))(iVar4 + 0x20);
    }
    *(int *)(iVar4 + 0x20) = iVar13;
    *(int *)(iVar4 + 0x1c) = iVar6;
  }
  uStack_8._0_1_ = 0;
  if (&DAT_0000000f < piStack_54) {
    piVar11 = (int *)((int)piStack_54 + 1);
    uVar10 = auStack_68[0];
    if ((int *)0xfff < piVar11) {
      uVar10 = *(uint *)(auStack_68[0] - 4);
      piVar11 = piStack_54 + 9;
      if (0x1f < (auStack_68[0] - uVar10) - 4) {
LAB_00a010f0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,piVar11);
  }
  piStack_44 = (int *)FUN_01674e20(0x18);
  if (piStack_44 == (int *)0x0) {
    piStack_44 = (int *)0x0;
  }
  else {
    piStack_44[1] = 1;
    piStack_44[2] = 1;
    *piStack_44 = (int)std::
                       _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                       ::vftable;
    piStack_44[3] = 0;
    piStack_44[4] = 0;
    piStack_44[5] = 0;
  }
  piStack_70 = piStack_44 + 3;
  uStack_8._0_1_ = 2;
  iStack_50 = (*param_2 + 1) * param_2[1];
  piVar11 = piStack_44 + 3;
  iVar7 = *(int *)(iStack_14 + 0xc) - *(int *)(iStack_14 + 8) >> 5;
  if (iVar7 <= iStack_50) {
    iStack_50 = iVar7;
  }
  iStack_40 = param_2[1] * *param_2;
  piStack_6c = piStack_44;
  if (iStack_40 < iStack_50) {
    iStack_18 = iStack_40 * 0x20;
    do {
      piVar8 = (int *)FUN_01674e20(0x24);
      piStack_1c = piVar8;
      if (piVar8 == (int *)0x0) {
        piVar8 = (int *)0x0;
      }
      else {
        piVar8[1] = 1;
        piVar8[2] = 1;
        *piVar8 = (int)std::
                       _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                       ::vftable;
        *(undefined *)(piVar8 + 3) = 0;
        iVar7 = FUN_00588320(0xb);
        piVar8[4] = iVar7;
        piVar8[5] = 0;
        piVar8[6] = 0x3f800000;
        piVar8[7] = 0;
        piVar8[8] = 0;
      }
      piStack_58 = piVar8 + 3;
      uStack_8._0_1_ = 3;
      puVar14 = (undefined4 *)(*(int *)(iStack_14 + 8) + iStack_18);
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      piStack_54 = piVar8;
      FUN_005542c0("TextureId",9);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      iVar4 = FUN_005c4c00(auStack_3c);
      piStack_1c = (undefined4 *)(iVar4 + 0x18);
      uVar5 = FUN_0088cb40();
      piVar11 = piStack_1c;
      iVar7 = _tls_index;
      *(undefined4 *)(iVar4 + 0x18) = uVar5;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar7 * 4) + 0x34) < DAT_01ea8c48) &&
         (FUN_016f3809(&DAT_01ea8c48), DAT_01ea8c48 == -1)) {
        _DAT_01ea8c3c = FUN_005c65f0;
        _DAT_01ea8c40 = FUN_005c93a0;
        DAT_01ea8c44 = FUN_005c77b0;
        FUN_016f37bf(&DAT_01ea8c48);
      }
      puVar2 = (undefined *)piVar11[1];
      if (puVar2 == &DAT_01ea8c3c) {
        if (piVar11 + 2 != puVar14) {
          puVar1 = puVar14 + 4;
          if (0xf < (uint)puVar14[5]) {
            puVar14 = (undefined4 *)*puVar14;
          }
          FUN_005542c0(puVar14,*puVar1);
        }
      }
      else {
        if (puVar2 != (undefined *)0x0) {
          (**(code **)(puVar2 + 8))(piVar11 + 2);
          piVar11[1] = 0;
        }
        FUN_0054ef60(puVar14);
        piVar11[1] = (int)&DAT_01ea8c3c;
      }
      uStack_8._0_1_ = 3;
      if (0xf < uStack_28) {
        uVar12 = uStack_28 + 1;
        uVar10 = auStack_3c[0];
        if (0xfff < uVar12) {
          uVar10 = *(uint *)(auStack_3c[0] - 4);
          uVar12 = uStack_28 + 0x24;
          if (0x1f < (auStack_3c[0] - uVar10) - 4) goto LAB_00a010f0;
        }
        FUN_01674ea0(uVar10,uVar12);
      }
      uVar5 = *(undefined4 *)(iStack_18 + 0x18 + *(int *)(iStack_14 + 8));
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      FUN_005542c0("MemoryInBytes",0xd);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      iVar7 = FUN_005c4c00(auStack_3c);
      uVar9 = FUN_0088c8c0();
      *(undefined4 *)(iVar7 + 0x18) = uVar9;
      piStack_1c = (int *)FUN_005c9cc0();
      puVar14 = *(undefined4 **)(iVar7 + 0x1c);
      if (puVar14 == piStack_1c) {
        *(undefined4 *)(iVar7 + 0x20) = uVar5;
      }
      else {
        if (puVar14 != (undefined4 *)0x0) {
          (*(code *)puVar14[2])(iVar7 + 0x20);
        }
        *(undefined4 *)(iVar7 + 0x20) = uVar5;
        *(int **)(iVar7 + 0x1c) = piStack_1c;
      }
      uStack_8._0_1_ = 3;
      if (0xf < uStack_28) {
        uVar12 = uStack_28 + 1;
        uVar10 = auStack_3c[0];
        if (0xfff < uVar12) {
          uVar10 = *(uint *)(auStack_3c[0] - 4);
          uVar12 = uStack_28 + 0x24;
          if (0x1f < (auStack_3c[0] - uVar10) - 4) goto LAB_00a010f0;
        }
        FUN_01674ea0(uVar10,uVar12);
      }
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 6;
      piStack_24 = piVar8 + 3;
      piStack_20 = piVar8;
      uStack_140 = FUN_008881d0();
      iStack_13c = 0;
      piStack_24 = (int *)0x0;
      piStack_20 = (int *)0x0;
      piStack_138 = piVar8 + 3;
      piStack_134 = piVar8;
      iStack_13c = FUN_0058c000();
      piVar11 = piStack_70;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      if (piStack_70[2] == piStack_70[1]) {
        FUN_005ca4f0(piStack_70[1],&uStack_140);
      }
      else {
        FUN_005caf00(&uStack_140);
        piVar11[1] = piVar11[1] + 0xd0;
      }
      uStack_8._0_1_ = 8;
      if (iStack_13c != 0) {
        (**(code **)(iStack_13c + 8))(&piStack_138);
      }
      uStack_8._0_1_ = 2;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar7 = piVar8[1] + -1;
        piVar8[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar7 = piVar8[2] + -1;
          piVar8[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      iStack_18 = iStack_18 + 0x20;
      iStack_40 = iStack_40 + 1;
    } while (iStack_40 < iStack_50);
  }
  piVar8 = piStack_44;
  if (piStack_44 != (int *)0x0) {
    LOCK();
    piStack_44[1] = piStack_44[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 9;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  piStack_58 = piVar11;
  piStack_54 = piStack_44;
  FUN_005542c0("Results",7);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  iVar7 = FUN_005c4c00(auStack_3c);
  uVar5 = FUN_008882f0();
  pvVar3 = ThreadLocalStoragePointer;
  *(undefined4 *)(iVar7 + 0x18) = uVar5;
  if ((*(int *)(*(int *)((int)pvVar3 + _tls_index * 4) + 0x34) < DAT_01ea8c38) &&
     (FUN_016f3809(&DAT_01ea8c38), DAT_01ea8c38 == -1)) {
    DAT_01ea8c2c = FUN_0057bbb0;
    DAT_01ea8c30 = FUN_005880a0;
    DAT_01ea8c34 = FUN_0057d5e0;
    FUN_016f37bf(&DAT_01ea8c38);
  }
  puVar14 = *(undefined4 **)(iVar7 + 0x1c);
  if ((code **)puVar14 == &DAT_01ea8c2c) {
    *(int **)(iVar7 + 0x20) = piVar11;
    piVar11 = *(int **)(iVar7 + 0x24);
    *(int **)(iVar7 + 0x24) = piVar8;
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar7 = piVar11[1] + -1;
      piVar11[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar11)();
        LOCK();
        iVar7 = piVar11[2] + -1;
        piVar11[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
  }
  else {
    if (puVar14 != (undefined4 *)0x0) {
      (*(code *)puVar14[2])(iVar7 + 0x20);
    }
    *(int **)(iVar7 + 0x20) = piVar11;
    *(int **)(iVar7 + 0x24) = piVar8;
    *(code ***)(iVar7 + 0x1c) = &DAT_01ea8c2c;
  }
  uStack_8._0_1_ = 9;
  if (0xf < uStack_28) {
    uVar12 = uStack_28 + 1;
    uVar10 = auStack_3c[0];
    if (0xfff < uVar12) {
      uVar10 = *(uint *)(auStack_3c[0] - 4);
      uVar12 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar12);
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    piStack_48[1] = piStack_48[1] + 1;
    UNLOCK();
  }
  piStack_24 = (int *)uStack_4c;
  piStack_20 = piStack_48;
  uStack_8._0_1_ = 0xb;
  if (param_2[2] == 0) {
    uVar5 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar5);
  }
  piStack_24 = (int *)0x0;
  piStack_20 = (int *)0x0;
  iVar7 = (**(code **)((param_2[2] & 0xfffffffeU) + 4))(param_2 + 4,uStack_4c,piStack_48);
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar11 = piVar8 + 1;
    iVar4 = *piVar11;
    iVar7 = *piVar11;
    *piVar11 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      piVar11 = piVar8 + 2;
      iVar4 = *piVar11;
      iVar7 = *piVar11;
      *piVar11 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar7 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    piVar11 = piStack_48 + 1;
    iVar4 = *piVar11;
    iVar7 = *piVar11;
    *piVar11 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar7 = (**(code **)*piStack_48)();
      LOCK();
      piVar11 = piStack_48 + 2;
      iVar4 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar7 = (**(code **)(*piStack_48 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 19759 ; VA 0x00a011b0 ; FUN_00a011b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a011b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9dd6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee6bb4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee6bb4);
    if (DAT_01ee6bb4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("TextureQueryType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee6b50 = RBX::Reflection::EnumDesc<enum_RBX::Stats::TextureQueryType>::vftable;
      FUN_009caf20(&DAT_01d658a8,4);
      FUN_016f3654(&LAB_01888800);
      FUN_016f37bf(&DAT_01ee6bb4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee6b50;
}



/* FUNCTION 19760 ; VA 0x00a01260 ; FUN_00a01260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a01260(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee6bc4) {
    FUN_016f3809(&DAT_01ee6bc4);
    if (DAT_01ee6bc4 == -1) {
      _DAT_01ee6bb8 = FUN_005c65e0;
      _DAT_01ee6bbc = FUN_005c65e0;
      _DAT_01ee6bc0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee6bc4);
    }
  }
  return &DAT_01ee6bb8;
}



/* FUNCTION 19761 ; VA 0x00a012d0 ; FUN_00a012d0 */

void __thiscall FUN_00a012d0(int param_1,undefined4 param_2,char param_3)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  float10 fVar10;
  float fVar11;
  float fVar12;
  undefined8 uVar13;
  undefined uVar14;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9dfc;
  pvStack_10 = ExceptionList;
  if ((param_3 != '\0') && (DAT_01d6575c != '\0')) {
    ExceptionList = &pvStack_10;
    iStack_18 = param_1;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee5eb8)
       && (ExceptionList = &pvStack_10, FUN_016f3809(), cVar2 = DAT_01d80f3c, DAT_01ee5eb8 == -1)) {
      uStack_8 = 0;
      uVar13 = FUN_0152dab0("telem","stats",0xffffffff);
      if ((cVar2 != '\0') && (DAT_01d7ad40 != '\0')) {
        FUN_01532a30(uVar13);
      }
      uStack_8 = 0xffffffff;
      DAT_01ee5eb0 = (int)uVar13;
      DAT_01ee5eb4 = (int)((ulonglong)uVar13 >> 0x20);
      FUN_016f37bf();
    }
    cVar2 = DAT_01d80f3c;
    uStack_20 = DAT_01ee5eb0;
    uStack_1c = DAT_01ee5eb4;
    uVar13 = FUN_01532c80(DAT_01ee5eb0,DAT_01ee5eb4);
    uStack_8 = 1;
    FUN_0151f9c0("stats/instances",DAT_01ea851c);
    iVar4 = FUN_008f7870();
    if (iVar4 != 0) {
      iVar4 = *(int *)(iVar4 + 0x22c);
    }
    FUN_0151f9c0("stats/primitives",iVar4);
    iVar5 = FUN_005c3ac0();
    iVar4 = 0;
    if (iVar5 != 0) {
      iVar4 = *(int *)(iVar5 + 0x1b4);
      FUN_0151f9c0("stats/movingprimitives",*(undefined4 *)(iVar5 + 0x160));
    }
    uVar14 = 0;
    FUN_005542c0("Sent Data Packets",0x11);
    fVar10 = (float10)FUN_009fe870(param_1,uVar14);
    FUN_0151fb00("net/datasendkbs",(double)(float)fVar10);
    uVar14 = 0;
    FUN_005542c0("Received Data Packets",0x15);
    fVar10 = (float10)FUN_009fe870(param_1,uVar14);
    FUN_0151fb00("net/datareceivekbs",(double)(float)fVar10);
    if (iVar4 != 0) {
      uVar6 = FUN_00bbdd30();
      FUN_0151f9c0("physics/contacts",uVar6);
      iStack_14 = *(int *)(iVar4 + 0x63c);
      iVar4 = iStack_14;
      param_1 = param_1;
      if (param_1 != 0) {
        iVar4 = *(int *)(param_1 + 0x34);
        iVar5 = param_1;
        if ((iVar4 != 0) && (iVar5 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
          iVar5 = FUN_005c8ac0();
        }
        iVar4 = iStack_14;
        param_1 = param_1;
        if ((iVar5 != 0) &&
           (iVar5 = *(int *)(iVar5 + 0xc), iVar7 = FUN_008a8c30(), iVar4 = iStack_14,
           param_1 = iStack_18,
           (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
           (uint)*(ushort *)(iVar7 + 0x1da))) {
          FUN_005789c0(&DAT_01eadd54,&LAB_00670c30);
          FUN_00675a30();
          piVar8 = (int *)FUN_008aa140();
          if (*piVar8 == 0) {
            uVar6 = FUN_00be8560();
            piVar9 = (int *)FUN_008a9ba0(&piStack_28,uVar6);
            iVar4 = *piVar9;
            iVar5 = piVar9[1];
            *piVar9 = 0;
            piVar9[1] = 0;
            *piVar8 = iVar4;
            piVar9 = (int *)piVar8[1];
            piVar8[1] = iVar5;
            if (piVar9 != (int *)0x0) {
              LOCK();
              iVar4 = piVar9[1] + -1;
              piVar9[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piVar9)();
                LOCK();
                iVar4 = piVar9[2] + -1;
                piVar9[2] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)(*piVar9 + 4))();
                }
              }
            }
            piVar9 = piStack_24;
            if (piStack_24 != (int *)0x0) {
              LOCK();
              iVar4 = piStack_24[1] + -1;
              piStack_24[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piStack_24)();
                LOCK();
                piVar1 = piVar9 + 2;
                iVar4 = *piVar1 + -1;
                *piVar1 = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)(*piVar9 + 4))();
                }
              }
            }
          }
          iVar4 = iStack_14;
          param_1 = iStack_18;
          if ((*piVar8 != 0) && (piVar8 = *(int **)(*piVar8 + 0x2c), piVar8 != (int *)0x0)) {
            iVar4 = iStack_14 + (piVar8[1] - *piVar8 >> 3);
          }
        }
      }
      FUN_0151f9c0("physics/joints",iVar4);
      FUN_0151f9c0("physics/bodies",0);
    }
    if (param_1 != 0) {
      iVar4 = *(int *)(param_1 + 0x34);
      if ((iVar4 != 0) && (param_1 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
        param_1 = FUN_005c8ac0();
      }
      if (((param_1 != 0) &&
          (iVar4 = *(int *)(param_1 + 0xc), iVar5 = FUN_008a8c30(),
          (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da))) && (iVar4 = FUN_0055e560(), iVar4 != 0)) {
        FUN_0151f9c0("stats/numplayers",(*(int **)(iVar4 + 0xb8))[1] - **(int **)(iVar4 + 0xb8) >> 3
                    );
        piVar8 = *(int **)(iVar4 + 0xbc);
        fVar12 = 0.0;
        fVar11 = 0.0;
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar8[1] = piVar8[1] + 1;
          UNLOCK();
          piVar8 = *(int **)(iVar4 + 0xbc);
        }
        piStack_28 = *(int **)(iVar4 + 0xb8);
        piVar9 = (int *)*piStack_28;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        for (; piVar9 != (int *)piStack_28[1]; piVar9 = piVar9 + 2) {
          fVar11 = fVar11 + *(float *)(*piVar9 + 0x188);
          fVar12 = fVar12 + *(float *)(*piVar9 + 0x18c);
        }
        piStack_24 = piVar8;
        FUN_0151fb00("stats/currentradius",(double)fVar11);
        FUN_0151fb00("stats/maxradius",(double)fVar12);
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar4 = piVar8[1] + -1;
          piVar8[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            piVar9 = piVar8 + 2;
            iVar4 = *piVar9;
            *piVar9 = *piVar9 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
      }
    }
    uVar3 = uStack_1c;
    uVar6 = uStack_20;
    uStack_8 = 3;
    FUN_0152dda0(uStack_20,uStack_1c,uVar13);
    if ((cVar2 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532d10(uVar6,uVar3,uVar13);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19762 ; VA 0x00a017c0 ; FUN_00a017c0 */

void __fastcall FUN_00a017c0(int param_1)

{
  double dVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  double dVar8;
  int aiStack_58 [5];
  uint uStack_44;
  
  iVar6 = *(int *)(param_1 + 0x78);
  dVar1 = *(double *)(iVar6 + 0x10);
  if ((NAN(*(double *)(param_1 + 0x58)) || NAN(dVar1)) == (*(double *)(param_1 + 0x58) == dVar1)) {
    *(double *)(param_1 + 0x58) = dVar1;
    dVar8 = *(double *)(iVar6 + 0x18);
    FUN_017267a0();
    puVar5 = (undefined4 *)
             FUN_01675640(aiStack_58,"%g (%.0f%%CV)",dVar1,
                          (dVar8 / *(double *)(iVar6 + 0x10)) * DAT_018ce318);
    if ((undefined4 *)(param_1 + 0x60) != puVar5) {
      FUN_005507b0();
      uVar2 = puVar5[1];
      uVar3 = puVar5[2];
      uVar4 = puVar5[3];
      *(undefined4 *)(param_1 + 0x60) = *puVar5;
      *(undefined4 *)(param_1 + 100) = uVar2;
      *(undefined4 *)(param_1 + 0x68) = uVar3;
      *(undefined4 *)(param_1 + 0x6c) = uVar4;
      *(undefined8 *)(param_1 + 0x70) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    if (0xf < uStack_44) {
      uVar7 = uStack_44 + 1;
      iVar6 = aiStack_58[0];
      if (0xfff < uVar7) {
        iVar6 = *(int *)(aiStack_58[0] + -4);
        uVar7 = uStack_44 + 0x24;
        if (0x1f < (aiStack_58[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar7);
    }
  }
  return;
}



/* FUNCTION 19763 ; VA 0x00a018a0 ; FUN_00a018a0 */

void __fastcall FUN_00a018a0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = *(int **)(param_1 + 0x34);
  if (piVar1 != (int *)0x0) {
    iVar2 = piVar1[3];
    iVar3 = FUN_009fb200();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
                    /* WARNING: Could not recover jumptable at 0x00a018d2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 0xa4))();
      return;
    }
  }
  return;
}



/* FUNCTION 19764 ; VA 0x00a018e0 ; FUN_00a018e0 */

void __fastcall FUN_00a018e0(int param_1)

{
  double *pdVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  double *pdVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  double dVar9;
  int aiStack_24 [5];
  uint uStack_10;
  undefined auStack_c [8];
  
  pdVar1 = *(double **)(param_1 + 0x78);
  pdVar5 = (double *)FUN_016827a0(auStack_c);
  if (pdVar1[1] < *pdVar5 - *pdVar1) {
    iVar7 = 0;
  }
  else {
    iVar7 = *(int *)(pdVar1 + 2);
  }
  dVar9 = (double)iVar7;
  if ((NAN(*(double *)(param_1 + 0x58)) || NAN(dVar9)) == (*(double *)(param_1 + 0x58) == dVar9)) {
    *(double *)(param_1 + 0x58) = dVar9;
    puVar6 = (undefined4 *)FUN_01675640(aiStack_24,&DAT_018bed68,iVar7);
    if ((undefined4 *)(param_1 + 0x60) != puVar6) {
      FUN_005507b0();
      uVar2 = puVar6[1];
      uVar3 = puVar6[2];
      uVar4 = puVar6[3];
      *(undefined4 *)(param_1 + 0x60) = *puVar6;
      *(undefined4 *)(param_1 + 100) = uVar2;
      *(undefined4 *)(param_1 + 0x68) = uVar3;
      *(undefined4 *)(param_1 + 0x6c) = uVar4;
      *(undefined8 *)(param_1 + 0x70) = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
    }
    if (0xf < uStack_10) {
      uVar8 = uStack_10 + 1;
      iVar7 = aiStack_24[0];
      if (0xfff < uVar8) {
        iVar7 = *(int *)(aiStack_24[0] + -4);
        uVar8 = uStack_10 + 0x24;
        if (0x1f < (aiStack_24[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar8);
    }
  }
  return;
}



/* FUNCTION 19765 ; VA 0x00a019b0 ; FUN_00a019b0 */

void __fastcall FUN_00a019b0(int param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792078;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x78) != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = (**(code **)((*(uint *)(param_1 + 0x78) & 0xfffffffe) + 4))(param_1 + 0x80);
    FUN_009ff7e0(uVar1);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 19766 ; VA 0x00a01a20 ; FUN_00a01a20 */

void __fastcall FUN_00a01a20(int param_1)

{
  float10 fVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab168;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x78) != 0) {
    ExceptionList = &pvStack_10;
    fVar1 = (float10)(**(code **)((*(uint *)(param_1 + 0x78) & 0xfffffffe) + 4))();
    FUN_009ffd50(param_1,(double)fVar1,"%.1f%%",(double)fVar1 * DAT_018ce318);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0();
}



/* FUNCTION 19767 ; VA 0x00a01ab0 ; FUN_00a01ab0 */

void __thiscall FUN_00a01ab0(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_10 [8];
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  puVar4 = (undefined4 *)FUN_016830f0(auStack_10);
  piVar1 = param_1 + 2;
  *param_1 = *puVar4;
  param_1[1] = puVar4[1];
  FUN_00559500(*piVar1,param_1[3],piVar1);
  param_1[3] = *piVar1;
  iVar2 = param_2[1];
  puVar4 = param_1;
  for (iVar5 = *param_2; iVar5 != iVar2; iVar5 = iVar5 + 0x20) {
    if (*(char *)(iVar5 + 0x1c) == *(char *)(puVar4 + 9)) {
      iVar3 = param_1[3];
      if (param_1[4] == iVar3) {
        FUN_009fb9d0(iVar3,iVar5);
        puVar4 = puStack_8;
      }
      else {
        FUN_0054ef60(iVar5);
        *(undefined4 *)(iVar3 + 0x18) = *(undefined4 *)(iVar5 + 0x18);
        *(undefined *)(iVar3 + 0x1c) = *(undefined *)(iVar5 + 0x1c);
        param_1[3] = param_1[3] + 0x20;
        puVar4 = puStack_8;
      }
    }
  }
  FUN_009fcfc0(*piVar1,puVar4[3],puVar4[3] - *piVar1 >> 5,iVar2);
  return;
}



/* FUNCTION 19768 ; VA 0x00a01b60 ; FUN_00a01b60 */

undefined4 * __thiscall FUN_00a01b60(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f51c;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19769 ; VA 0x00a01c90 ; FUN_00a01c90 */

undefined4 * __thiscall FUN_00a01c90(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f55c;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19770 ; VA 0x00a01dc0 ; FUN_00a01dc0 */

undefined4 * __thiscall FUN_00a01dc0(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  undefined *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000001c;
  undefined auStack_118 [24];
  undefined4 uStack_100;
  undefined auStack_fc [24];
  undefined auStack_e4 [24];
  undefined4 uStack_cc;
  undefined auStack_c8 [24];
  undefined auStack_b0 [24];
  undefined4 uStack_98;
  undefined auStack_94 [24];
  undefined auStack_7c [24];
  undefined4 uStack_64;
  undefined auStack_60 [24];
  undefined auStack_48 [24];
  undefined4 uStack_30;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9e88;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_118;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&stack0x00000004);
  uStack_100 = in_stack_0000001c;
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000020);
  puStack_14 = auStack_e4;
  uStack_8._0_1_ = 2;
  *param_1 = 0;
  FUN_0054ef60(auStack_118);
  uStack_cc = uStack_100;
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_fc);
  puStack_14 = auStack_b0;
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_e4);
  uStack_98 = uStack_cc;
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_c8);
  puStack_14 = auStack_48;
  uStack_8._0_1_ = 6;
  FUN_0054ef60(auStack_b0);
  uStack_30 = uStack_98;
  uStack_8._0_1_ = 7;
  FUN_0054ef60(auStack_94);
  uStack_8._0_1_ = 8;
  cVar2 = FUN_00585a40(auStack_48);
  if (cVar2 == '\0') {
    puStack_14 = auStack_7c;
    FUN_0054ef60(auStack_48);
    uStack_64 = uStack_30;
    uStack_8._0_1_ = 9;
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 10;
    puVar3 = (undefined *)FUN_01674e20(0x34);
    uStack_8._0_1_ = 0xb;
    puStack_14 = puVar3;
    if (puVar3 == (undefined *)0x0) {
      puVar3 = (undefined *)0x0;
    }
    else {
      FUN_0054ef60(auStack_7c);
      *(undefined4 *)(puVar3 + 0x18) = uStack_64;
      uStack_8._0_1_ = 0xc;
      FUN_0054ef60(auStack_60);
    }
    param_1[2] = puVar3;
    FUN_00a04640();
    FUN_00a04640();
    bVar1 = true;
  }
  else {
    FUN_00a04640();
    bVar1 = false;
  }
  FUN_00a04640();
  ppuVar4 = &PTR_FUN_0193f4e4;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a04640();
  FUN_00a04640();
  FUN_00a04640();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19771 ; VA 0x00a01fd0 ; FUN_00a01fd0 */

undefined4 * __thiscall FUN_00a01fd0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f54c;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19772 ; VA 0x00a02100 ; FUN_00a02100 */

undefined4 * __thiscall FUN_00a02100(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f52c;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19773 ; VA 0x00a02230 ; FUN_00a02230 */

undefined4 * __thiscall FUN_00a02230(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f4fc;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19774 ; VA 0x00a02360 ; FUN_00a02360 */

undefined4 * __fastcall FUN_00a02360(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  undefined *puVar3;
  undefined **ppuVar4;
  undefined auStack_104 [24];
  undefined auStack_ec [24];
  undefined auStack_d4 [24];
  undefined auStack_bc [24];
  undefined auStack_a4 [24];
  undefined auStack_8c [24];
  undefined auStack_74 [24];
  undefined auStack_5c [24];
  undefined auStack_44 [24];
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9f18;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_104;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&stack0x00000004);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x0000001c);
  puStack_14 = auStack_d4;
  uStack_8._0_1_ = 2;
  *param_1 = 0;
  FUN_0054ef60(auStack_104);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_ec);
  puStack_14 = auStack_a4;
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_d4);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_bc);
  puStack_14 = auStack_44;
  uStack_8._0_1_ = 6;
  FUN_0054ef60(auStack_a4);
  uStack_8._0_1_ = 7;
  FUN_0054ef60(auStack_8c);
  uStack_8._0_1_ = 8;
  cVar2 = FUN_00585a40(auStack_44);
  if (cVar2 == '\0') {
    puStack_14 = auStack_74;
    FUN_0054ef60(auStack_44);
    uStack_8._0_1_ = 9;
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 10;
    puVar3 = (undefined *)FUN_01674e20(0x30);
    uStack_8._0_1_ = 0xb;
    puStack_14 = puVar3;
    if (puVar3 == (undefined *)0x0) {
      puVar3 = (undefined *)0x0;
    }
    else {
      FUN_0054ef60(auStack_74);
      uStack_8._0_1_ = 0xc;
      FUN_0054ef60(auStack_5c);
    }
    param_1[2] = puVar3;
    FUN_005509f0();
    FUN_005509f0();
    bVar1 = true;
  }
  else {
    FUN_005509f0();
    bVar1 = false;
  }
  FUN_005509f0();
  ppuVar4 = &PTR_FUN_0193f50c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005509f0();
  FUN_005509f0();
  FUN_005509f0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19775 ; VA 0x00a02540 ; FUN_00a02540 */

undefined4 * __thiscall FUN_00a02540(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f544;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19776 ; VA 0x00a02670 ; FUN_00a02670 */

undefined4 * __thiscall FUN_00a02670(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f514;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19777 ; VA 0x00a027a0 ; FUN_00a027a0 */

undefined4 * __thiscall FUN_00a027a0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f524;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19778 ; VA 0x00a028d0 ; FUN_00a028d0 */

undefined4 * __thiscall FUN_00a028d0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f554;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19779 ; VA 0x00a02a00 ; FUN_00a02a00 */

undefined4 * __thiscall FUN_00a02a00(undefined4 *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000018;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  int iStack_54;
  int *piStack_50;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9f48;
  pvStack_10 = ExceptionList;
  piStack_50 = &param_2;
  uStack_8 = 0;
  iStack_54 = 0xa02a35;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  piStack_50 = aiStack_44;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_54 = 0xa02a4b;
  FUN_0054ef60();
  piStack_50 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_68;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_0193f504;
  cVar1 = FUN_00a03ba0();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_50 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_50 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xa02b22;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa02aa6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_30) {
    piStack_50 = (int *)(uStack_30 + 1);
    iVar2 = aiStack_44[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      piStack_50 = (int *)(uStack_30 + 0x24);
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xa02b27;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa02ad6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000018) {
    piStack_50 = (int *)(in_stack_00000018 + 1);
    iVar2 = param_2;
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(param_2 + -4);
      piStack_50 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)&UNK_00a02b2c;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa02b06;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19780 ; VA 0x00a02b30 ; FUN_00a02b30 */

undefined4 * __thiscall FUN_00a02b30(undefined4 *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000018;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  int iStack_54;
  int *piStack_50;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9f78;
  pvStack_10 = ExceptionList;
  piStack_50 = &param_2;
  uStack_8 = 0;
  iStack_54 = 0xa02b65;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  piStack_50 = aiStack_44;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_54 = 0xa02b7b;
  FUN_0054ef60();
  piStack_50 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_68;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_0193f534;
  cVar1 = FUN_00a03d10();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_50 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_50 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xa02c52;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa02bd6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_30) {
    piStack_50 = (int *)(uStack_30 + 1);
    iVar2 = aiStack_44[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      piStack_50 = (int *)(uStack_30 + 0x24);
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xa02c57;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa02c06;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000018) {
    piStack_50 = (int *)(in_stack_00000018 + 1);
    iVar2 = param_2;
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(param_2 + -4);
      piStack_50 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)&UNK_00a02c5c;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa02c36;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19781 ; VA 0x00a02c60 ; FUN_00a02c60 */

undefined4 * __thiscall FUN_00a02c60(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f56c;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19782 ; VA 0x00a02d90 ; FUN_00a02d90 */

undefined4 * __thiscall FUN_00a02d90(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  undefined *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined auStack_f4 [24];
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined auStack_d4 [24];
  undefined auStack_bc [24];
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined auStack_9c [24];
  undefined auStack_84 [24];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined auStack_64 [24];
  undefined auStack_4c [24];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9ff5;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_f4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  FUN_0054ef60(&stack0x00000004);
  uStack_dc = in_stack_0000001c;
  uStack_d8 = in_stack_00000020;
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000024);
  puStack_14 = auStack_bc;
  uStack_8._0_1_ = 2;
  FUN_0054ef60(auStack_f4);
  uStack_a4 = uStack_dc;
  uStack_a0 = uStack_d8;
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_d4);
  puStack_14 = auStack_4c;
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_bc);
  uStack_34 = uStack_a4;
  uStack_30 = uStack_a0;
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_9c);
  uStack_8._0_1_ = 6;
  cVar2 = FUN_00585a40(auStack_4c);
  if (cVar2 == '\0') {
    puStack_14 = auStack_84;
    FUN_0054ef60(auStack_4c);
    uStack_6c = uStack_34;
    uStack_68 = uStack_30;
    uStack_8._0_1_ = 7;
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 8;
    puVar3 = (undefined *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 9;
    puStack_14 = puVar3;
    if (puVar3 == (undefined *)0x0) {
      puVar3 = (undefined *)0x0;
    }
    else {
      FUN_0054ef60(auStack_84);
      *(undefined4 *)(puVar3 + 0x18) = uStack_6c;
      *(undefined4 *)(puVar3 + 0x1c) = uStack_68;
      uStack_8._0_1_ = 10;
      FUN_0054ef60(auStack_64);
    }
    param_1[2] = puVar3;
    FUN_00a047b0();
    FUN_00a047b0();
    bVar1 = true;
  }
  else {
    FUN_00a047b0();
    bVar1 = false;
  }
  FUN_00a047b0();
  ppuVar4 = &PTR_FUN_0193f4d4;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a047b0();
  FUN_00a047b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19783 ; VA 0x00a02f80 ; FUN_00a02f80 */

undefined4 * __thiscall FUN_00a02f80(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f564;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19784 ; VA 0x00a030b0 ; FUN_00a030b0 */

undefined4 * __thiscall FUN_00a030b0(undefined4 *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000018;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  int iStack_54;
  int *piStack_50;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da018;
  pvStack_10 = ExceptionList;
  piStack_50 = &param_2;
  uStack_8 = 0;
  iStack_54 = 0xa030e5;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  piStack_50 = aiStack_44;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_54 = 0xa030fb;
  FUN_0054ef60();
  piStack_50 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_68;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_0193f4f4;
  cVar1 = FUN_00a03e80();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_50 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_50 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xa031d2;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa03156;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_30) {
    piStack_50 = (int *)(uStack_30 + 1);
    iVar2 = aiStack_44[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      piStack_50 = (int *)(uStack_30 + 0x24);
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xa031d7;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa03186;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000018) {
    piStack_50 = (int *)(in_stack_00000018 + 1);
    iVar2 = param_2;
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(param_2 + -4);
      piStack_50 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)&UNK_00a031dc;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa031b6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19785 ; VA 0x00a031e0 ; FUN_00a031e0 */

undefined4 * __thiscall FUN_00a031e0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f4ec;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19786 ; VA 0x00a03310 ; FUN_00a03310 */

undefined4 * __thiscall FUN_00a03310(undefined4 *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000018;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  int iStack_54;
  int *piStack_50;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da048;
  pvStack_10 = ExceptionList;
  piStack_50 = &param_2;
  uStack_8 = 0;
  iStack_54 = 0xa03345;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  piStack_50 = aiStack_44;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_54 = 0xa0335b;
  FUN_0054ef60();
  piStack_50 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_68;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_0193f53c;
  cVar1 = FUN_00a03ff0();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_50 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_50 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xa03432;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa033b6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_30) {
    piStack_50 = (int *)(uStack_30 + 1);
    iVar2 = aiStack_44[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      piStack_50 = (int *)(uStack_30 + 0x24);
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xa03437;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa033e6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000018) {
    piStack_50 = (int *)(in_stack_00000018 + 1);
    iVar2 = param_2;
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(param_2 + -4);
      piStack_50 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)&UNK_00a0343c;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xa03416;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19787 ; VA 0x00a03440 ; FUN_00a03440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a03440(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined *puVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  
  uVar4 = FUN_008882f0();
  iVar5 = _tls_index;
  *param_1 = uVar4;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar5 * 4) + 0x34) < DAT_01ea8cd0) {
    FUN_016f3809(&DAT_01ea8cd0);
    if (DAT_01ea8cd0 == -1) {
      _DAT_01ea8cc4 = FUN_0057bbb0;
      _DAT_01ea8cc8 = FUN_005880a0;
      DAT_01ea8ccc = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8cd0);
    }
  }
  puVar2 = (undefined *)param_1[1];
  if (puVar2 == &DAT_01ea8cc4) {
    iVar5 = param_2[1];
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = param_2[1];
    }
    param_1[2] = *param_2;
    piVar3 = (int *)param_1[3];
    param_1[3] = iVar5;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar5 = piVar3[1] + -1;
      piVar3[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
      return param_1;
    }
    return param_1;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar3 = (int *)(param_2[1] + 4);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
  }
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  param_1[1] = &DAT_01ea8cc4;
  return param_1;
}



/* FUNCTION 19788 ; VA 0x00a03570 ; FUN_00a03570 */

int FUN_00a03570(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00a08ae0(param_1,param_2);
  *(undefined4 *)(iVar4 + 0x18) = 0;
  *(undefined4 *)(iVar4 + 0x1c) = 0;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *(undefined4 *)(iVar4 + 8) = *param_3;
  *(undefined4 *)(iVar4 + 0xc) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar2;
  *(undefined4 *)(iVar4 + 0x14) = uVar3;
  *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  *(undefined4 *)(iVar4 + 0x20) = 0;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  *(undefined4 *)(iVar4 + 0x20) = param_3[6];
  *(undefined4 *)(iVar4 + 0x24) = param_3[7];
  param_3[6] = 0;
  param_3[7] = 0;
  *(undefined4 *)(iVar4 + 0x38) = 0;
  *(undefined4 *)(iVar4 + 0x3c) = 0;
  uVar1 = param_3[9];
  uVar2 = param_3[10];
  uVar3 = param_3[0xb];
  *(undefined4 *)(iVar4 + 0x28) = param_3[8];
  *(undefined4 *)(iVar4 + 0x2c) = uVar1;
  *(undefined4 *)(iVar4 + 0x30) = uVar2;
  *(undefined4 *)(iVar4 + 0x34) = uVar3;
  *(undefined8 *)(iVar4 + 0x38) = *(undefined8 *)(param_3 + 0xc);
  param_3[0xc] = 0;
  param_3[0xd] = 0xf;
  *(undefined *)(param_3 + 8) = 0;
  *(undefined4 *)(iVar4 + 0x50) = 0;
  *(undefined4 *)(iVar4 + 0x54) = 0;
  uVar1 = param_3[0xf];
  uVar2 = param_3[0x10];
  uVar3 = param_3[0x11];
  *(undefined4 *)(iVar4 + 0x40) = param_3[0xe];
  *(undefined4 *)(iVar4 + 0x44) = uVar1;
  *(undefined4 *)(iVar4 + 0x48) = uVar2;
  *(undefined4 *)(iVar4 + 0x4c) = uVar3;
  *(undefined8 *)(iVar4 + 0x50) = *(undefined8 *)(param_3 + 0x12);
  param_3[0x12] = 0;
  param_3[0x13] = 0xf;
  *(undefined *)(param_3 + 0xe) = 0;
  *(undefined4 *)(iVar4 + 0x58) = param_3[0x14];
  *(undefined4 *)(iVar4 + 0x5c) = param_3[0x15];
  *(undefined4 *)(iVar4 + 0x60) = param_3[0x16];
  *(undefined4 *)(iVar4 + 0x74) = 0;
  *(undefined4 *)(iVar4 + 0x78) = 0;
  uVar1 = param_3[0x18];
  uVar2 = param_3[0x19];
  uVar3 = param_3[0x1a];
  *(undefined4 *)(iVar4 + 100) = param_3[0x17];
  *(undefined4 *)(iVar4 + 0x68) = uVar1;
  *(undefined4 *)(iVar4 + 0x6c) = uVar2;
  *(undefined4 *)(iVar4 + 0x70) = uVar3;
  *(undefined8 *)(iVar4 + 0x74) = *(undefined8 *)(param_3 + 0x1b);
  param_3[0x1b] = 0;
  param_3[0x1c] = 0xf;
  *(undefined *)(param_3 + 0x17) = 0;
  return iVar4;
}



/* FUNCTION 19789 ; VA 0x00a03690 ; FUN_00a03690 */

void __thiscall FUN_00a03690(float *param_1,float *param_2,undefined4 *param_3,float *param_4)

{
  byte *pbVar1;
  float fVar2;
  float *pfVar3;
  undefined *puVar4;
  char cVar5;
  uint uVar6;
  float fVar7;
  undefined4 *puVar8;
  uint uVar9;
  float fVar10;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da060;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  puVar8 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar8 = (undefined4 *)*param_3;
  }
  uVar6 = 0;
  uVar9 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar6 + (int)puVar8);
      uVar6 = uVar6 + 1;
      uVar9 = (*pbVar1 ^ uVar9) * 0x1000193;
    } while (uVar6 < (uint)param_3[4]);
  }
  fVar7 = param_1[3];
  uVar9 = (uint)param_1[6] & uVar9;
  fVar10 = param_1[1];
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  puVar4 = &stack0xffffffd0;
  if (fVar10 != *(float *)((int)fVar7 + uVar9 * 8)) {
    fVar10 = **(float **)((int)fVar7 + 4 + uVar9 * 8);
    ExceptionList = &pvStack_10;
    while (puVar4 = puStack_14, fVar10 != *(float *)((int)fVar7 + uVar9 * 8)) {
      fVar10 = *(float *)((int)fVar10 + 4);
      cVar5 = FUN_00570290(param_3,(int)fVar10 + 8);
      fVar7 = param_1[3];
      if (cVar5 != '\0') {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_009f3420(param_4);
        *param_2 = fVar10;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  puStack_14 = puVar4;
  pfStack_18 = param_4;
  fVar7 = *param_4;
  if (fVar10 != fVar7) {
    *(float *)param_4[1] = fVar7;
    **(float **)((int)fVar7 + 4) = fVar10;
    **(undefined4 **)((int)fVar10 + 4) = param_4;
    fVar2 = *(float *)((int)fVar10 + 4);
    *(undefined4 *)((int)fVar10 + 4) = *(undefined4 *)((int)fVar7 + 4);
    *(float *)((int)fVar7 + 4) = param_4[1];
    param_4[1] = fVar2;
  }
  fVar7 = param_1[3];
  fVar2 = *(float *)((int)fVar7 + uVar9 * 8);
  if (fVar2 == param_1[1]) {
    *(float **)((int)fVar7 + uVar9 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar9 * 8) = param_4;
  }
  else if (fVar2 == fVar10) {
    *(float **)((int)fVar7 + uVar9 * 8) = param_4;
  }
  else {
    pfVar3 = (float *)**(undefined4 **)((int)fVar7 + 4 + uVar9 * 8);
    *(float **)((int)fVar7 + 4 + uVar9 * 8) = pfVar3;
    if (pfVar3 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar9 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar9 * 8) + 4);
    }
  }
  fVar7 = param_1[7];
  uStack_8 = 2;
  fVar10 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
           (float)((double)(int)fVar7 + (double)(&DAT_018c0d90)[-((int)fVar7 >> 0x1f)]);
  if (*param_1 <= fVar10 && fVar10 != *param_1) {
    if ((uint)fVar7 < 0x200) {
      fVar7 = (float)((int)fVar7 << 3);
    }
    else if ((uint)fVar7 < 0x1fffffff) {
      fVar7 = (float)((int)fVar7 * 2);
    }
    FUN_005cb500(fVar7);
    pfVar3 = (float *)param_1[1];
    if ((float *)*pfVar3 != pfVar3) {
      fVar7 = pfVar3[1];
      do {
        fVar10 = *(float *)param_1[1];
        FUN_00a03690(auStack_24,(int)fVar10 + 8,fVar10);
      } while (fVar10 != fVar7);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19790 ; VA 0x00a03876 ; Catch_All@00a03876 */

void Catch_All_00a03876(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00a04160(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19791 ; VA 0x00a038a0 ; FUN_00a038a0 */

void __thiscall FUN_00a038a0(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  undefined *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined auStack_104 [24];
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined auStack_e4 [24];
  undefined auStack_cc [24];
  undefined auStack_b4 [24];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined auStack_94 [24];
  undefined auStack_7c [24];
  undefined auStack_64 [24];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined auStack_44 [24];
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da0f1;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_104;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&stack0x00000004);
  uStack_ec = in_stack_0000001c;
  uStack_e8 = in_stack_00000020;
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000024);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(&stack0x0000003c);
  puStack_14 = auStack_64;
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_104);
  uStack_4c = uStack_ec;
  uStack_48 = uStack_e8;
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_e4);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_cc);
  uStack_8._0_1_ = 6;
  cVar2 = FUN_00585a40(auStack_64);
  if (cVar2 == '\0') {
    puStack_14 = auStack_b4;
    FUN_0054ef60(auStack_64);
    uStack_9c = uStack_4c;
    uStack_98 = uStack_48;
    uStack_8._0_1_ = 7;
    FUN_0054ef60(auStack_44);
    uStack_8._0_1_ = 8;
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 9;
    puVar3 = (undefined *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 10;
    puStack_14 = puVar3;
    if (puVar3 == (undefined *)0x0) {
      puVar3 = (undefined *)0x0;
    }
    else {
      FUN_0054ef60(auStack_b4);
      *(undefined4 *)(puVar3 + 0x18) = uStack_9c;
      *(undefined4 *)(puVar3 + 0x1c) = uStack_98;
      uStack_8._0_1_ = 0xb;
      FUN_0054ef60(auStack_94);
      uStack_8._0_1_ = 0xc;
      FUN_0054ef60(auStack_7c);
    }
    param_1[2] = puVar3;
    FUN_00a046d0();
    FUN_00a046d0();
    bVar1 = true;
  }
  else {
    FUN_00a046d0();
    bVar1 = false;
  }
  FUN_00a046d0();
  ppuVar4 = &PTR_FUN_0193f4dc;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a046d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19792 ; VA 0x00a03a90 ; FUN_00a03a90 */

void __thiscall FUN_00a03a90(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_3;
  uStack_14 = param_2;
  uStack_c = param_4;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    param_1[4] = uStack_c;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193f4cc;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 19793 ; VA 0x00a03ba0 ; FUN_00a03ba0 */

undefined FUN_00a03ba0(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined uVar5;
  uint in_stack_00000018;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da118;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_2c);
  if (cVar1 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(aiStack_44);
    if (0xf < uStack_30) {
      uVar3 = uStack_30 + 1;
      iVar2 = aiStack_44[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_44[0] + -4);
        uVar3 = uStack_30 + 0x24;
        if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 19794 ; VA 0x00a03d10 ; FUN_00a03d10 */

undefined FUN_00a03d10(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined uVar5;
  uint in_stack_00000018;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da148;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_2c);
  if (cVar1 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(aiStack_44);
    if (0xf < uStack_30) {
      uVar3 = uStack_30 + 1;
      iVar2 = aiStack_44[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_44[0] + -4);
        uVar3 = uStack_30 + 0x24;
        if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 19795 ; VA 0x00a03e80 ; FUN_00a03e80 */

undefined FUN_00a03e80(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined uVar5;
  uint in_stack_00000018;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da178;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_2c);
  if (cVar1 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(aiStack_44);
    if (0xf < uStack_30) {
      uVar3 = uStack_30 + 1;
      iVar2 = aiStack_44[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_44[0] + -4);
        uVar3 = uStack_30 + 0x24;
        if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 19796 ; VA 0x00a03ff0 ; FUN_00a03ff0 */

undefined FUN_00a03ff0(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined uVar5;
  uint in_stack_00000018;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da1a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_2c);
  if (cVar1 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(aiStack_44);
    if (0xf < uStack_30) {
      uVar3 = uStack_30 + 1;
      iVar2 = aiStack_44[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_44[0] + -4);
        uVar3 = uStack_30 + 0x24;
        if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 19797 ; VA 0x00a04160 ; FUN_00a04160 */

void __thiscall FUN_00a04160(int param_1,int *param_2,int *param_3)

{
  byte *pbVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  
  piVar5 = param_3 + 2;
  if (0xf < (uint)param_3[7]) {
    piVar5 = (int *)*piVar5;
  }
  uVar3 = 0;
  uVar6 = 0x811c9dc5;
  if (param_3[6] != 0) {
    do {
      pbVar1 = (byte *)(uVar3 + (int)piVar5);
      uVar3 = uVar3 + 1;
      uVar6 = (*pbVar1 ^ uVar6) * 0x1000193;
    } while (uVar3 < (uint)param_3[6]);
  }
  iVar2 = (*(uint *)(param_1 + 0x18) & uVar6) * 8;
  piVar5 = *(int **)(*(int *)(param_1 + 0xc) + iVar2);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if ((int *)piVar4[1] == param_3) {
    if (piVar5 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar2 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar5 == param_3) {
    *piVar4 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_009f3420(param_3);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 19798 ; VA 0x00a04210 ; FUN_00a04210 */

undefined4 * __fastcall FUN_00a04210(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da1d6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_00a08ae0(0,0);
  param_1[1] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  *param_1 = 0x3f800000;
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19799 ; VA 0x00a042a0 ; FUN_00a042a0 */

undefined4 * __thiscall FUN_00a042a0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da1fe;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2 + 8);
  param_1[0xe] = param_2[0xe];
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = param_2[0x10];
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_2 + 0x11);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19800 ; VA 0x00a04340 ; FUN_00a04340 */

undefined4 * __thiscall
FUN_00a04340(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017da283;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  param_1[7] = param_2;
  param_1[8] = param_3;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xc] = param_6;
  uStack_8 = 8;
  uStack_7 = 0;
  param_1[0xd] = param_7;
  FUN_00a04210();
  param_1[0x1a] = 0;
  param_1[0x1b] = 0xf;
  *(undefined *)(param_1 + 0x16) = 0;
  _uStack_8 = CONCAT31(uStack_7,10);
  FUN_0054ef60(param_4);
  param_1[0x22] = param_5;
  *(undefined2 *)(param_1 + 0x23) = 0x100;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  FUN_016dee4c(param_1 + 0x32,2);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19801 ; VA 0x00a044a0 ; FUN_00a044a0 */

undefined4 * __thiscall
FUN_00a044a0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017da324;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  param_1[7] = param_2;
  param_1[8] = param_3;
  param_1[9] = 0;
  param_1[10] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  param_1[9] = param_4;
  param_1[10] = param_5;
  uStack_8 = 9;
  uStack_7 = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  FUN_00a04210();
  uStack_8 = 10;
  FUN_0054ef60(param_8);
  param_1[0x20] = 0;
  param_1[0x21] = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  param_1[0x22] = 0;
  *(undefined2 *)(param_1 + 0x23) = 0x100;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  FUN_016dee4c(param_1 + 0x32,2);
  _uStack_8 = CONCAT31(uStack_7,0xd);
  FUN_00a11770(param_6,param_7);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19802 ; VA 0x00a04640 ; FUN_00a04640 */

void __fastcall FUN_00a04640(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0xc];
  if (0xf < uVar1) {
    iVar2 = param_1[7];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a046c7;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0xb] = 0;
  param_1[0xc] = 0xf;
  *(undefined *)(param_1 + 7) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00a046c7:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 19803 ; VA 0x00a046d0 ; FUN_00a046d0 */

void __fastcall FUN_00a046d0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0x13];
  if (0xf < uVar1) {
    iVar2 = param_1[0xe];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a0479d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x12] = 0;
  param_1[0x13] = 0xf;
  *(undefined *)(param_1 + 0xe) = 0;
  uVar1 = param_1[0xd];
  if (0xf < uVar1) {
    iVar2 = param_1[8];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a0479d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00a0479d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 19804 ; VA 0x00a047b0 ; FUN_00a047b0 */

void __fastcall FUN_00a047b0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0xd];
  if (0xf < uVar1) {
    iVar2 = param_1[8];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a04837;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00a04837:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 19805 ; VA 0x00a04840 ; FUN_00a04840 */

void __fastcall FUN_00a04840(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_009f1010();
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 19806 ; VA 0x00a048a0 ; FUN_00a048a0 */

int __thiscall FUN_00a048a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  undefined *puVar5;
  int iVar6;
  double *pdVar7;
  int *piVar8;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  double dStack_20;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puVar5 = PTR_s_Place_Changes_01d65cb8;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017da348;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1[1] != 0) {
    LOCK();
    piVar8 = (int *)(param_1[1] + 8);
    ExceptionList = &pvStack_10;
    *piVar8 = *piVar8 + 1;
    UNLOCK();
  }
  iVar6 = FUN_00a0b130(&iStack_18,*param_1,param_1[1],puVar5);
  iStack_8 = 0;
  if (iStack_18 != 0) {
    iVar6 = FUN_00a0d4b0(param_2,param_3,PTR_s_Place_Changes_01d65cb8,1);
    iVar2 = iStack_18;
    if ((char)iVar6 != '\0') {
      pdVar7 = (double *)FUN_016830f0(&dStack_20);
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      *(int *)(iStack_18 + 0xc0) = (int)((*pdVar7 - *(double *)(iVar2 + 0xa0)) * DAT_018c0d70);
      dStack_20 = (double)*(int *)(iStack_18 + 0xc0);
      if (DAT_01d65a40 == '\0') {
        FUN_005542c0();
        iStack_8._0_1_ = 2;
        FUN_00878cf0(auStack_38,dStack_20,0);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
      }
      else {
        uVar3 = *(undefined *)(iStack_18 + 0x8d);
        FUN_005542c0();
        iStack_8._0_1_ = 1;
        FUN_00a11480(auStack_38,dStack_20,CONCAT31(0xffffff,uVar3));
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
      }
      piVar8 = (int *)param_1[1];
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[2] = piVar8[2] + 1;
        UNLOCK();
        piVar8 = (int *)param_1[1];
      }
      uVar4 = *param_1;
      piVar1 = piVar8 + 2;
      if (piVar8 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00a027a0(uVar4,piVar8,0);
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar6 = *piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
      iVar6 = FUN_0090ca30();
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar8 = piStack_14 + 1;
    iVar2 = *piVar8;
    iVar6 = *piVar8;
    *piVar8 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piStack_14)();
      LOCK();
      piVar8 = piStack_14 + 2;
      iVar2 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 19807 ; VA 0x00a04ab0 ; FUN_00a04ab0 */

int __thiscall FUN_00a04ab0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  undefined *puVar5;
  char cVar6;
  int iVar7;
  double *pdVar8;
  int *piVar9;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  double dStack_20;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puVar5 = PTR_s_Place_Changes_01d65cb8;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017da348;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1[1] != 0) {
    LOCK();
    piVar9 = (int *)(param_1[1] + 8);
    ExceptionList = &pvStack_10;
    *piVar9 = *piVar9 + 1;
    UNLOCK();
  }
  iVar7 = FUN_00a0b130(&iStack_18,*param_1,param_1[1],puVar5);
  iStack_8 = 0;
  if (iStack_18 != 0) {
    cVar6 = FUN_00a0d4b0(param_2,param_3,PTR_s_Place_Changes_01d65cb8,0);
    iVar7 = iStack_18;
    if (cVar6 == '\0') {
      if ((((param_2 == 0) && (iVar7 = *(int *)(param_3 + 0xc), iVar7 < 500)) && (iVar7 != 0x198))
         && (iVar7 != 0x1ad)) {
        if (DAT_01d84e8e != '\0') {
          FUN_016774b0(DAT_01d84e8e,"Commit Failure: %s - fatal error",PTR_s_Place_Changes_01d65cb8)
          ;
        }
        piVar9 = (int *)param_1[1];
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[2] = piVar9[2] + 1;
          UNLOCK();
          piVar9 = (int *)param_1[1];
        }
        uVar4 = *param_1;
        piVar1 = piVar9 + 2;
        if (piVar9 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_00a01c90(uVar4,piVar9,0);
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar7 = *piVar1;
          *piVar1 = iVar7 + -1;
          UNLOCK();
          if (iVar7 + -1 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      else {
        piVar9 = (int *)param_1[1];
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[2] = piVar9[2] + 1;
          UNLOCK();
          piVar9 = (int *)param_1[1];
        }
        uVar4 = *param_1;
        piVar1 = piVar9 + 2;
        if (piVar9 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_00a02f80(uVar4,piVar9,0);
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar7 = *piVar1;
          *piVar1 = iVar7 + -1;
          UNLOCK();
          if (iVar7 + -1 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    else {
      pdVar8 = (double *)FUN_016830f0(&dStack_20);
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      *(int *)(iStack_18 + 0xc0) = (int)((*pdVar8 - *(double *)(iVar7 + 0xa0)) * DAT_018c0d70);
      dStack_20 = (double)*(int *)(iStack_18 + 0xc0);
      if (DAT_01d65a40 == '\0') {
        FUN_005542c0();
        iStack_8._0_1_ = 2;
        FUN_00878cf0(auStack_38,dStack_20,0);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
      }
      else {
        uVar3 = *(undefined *)(iStack_18 + 0x8d);
        FUN_005542c0();
        iStack_8._0_1_ = 1;
        FUN_00a11480(auStack_38,dStack_20,CONCAT31(0xffffff,uVar3));
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
      }
      piVar9 = (int *)param_1[1];
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[2] = piVar9[2] + 1;
        UNLOCK();
        piVar9 = (int *)param_1[1];
      }
      uVar4 = *param_1;
      piVar1 = piVar9 + 2;
      if (piVar9 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00a02c60(uVar4,piVar9,0);
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar7 = *piVar1;
        *piVar1 = iVar7 + -1;
        UNLOCK();
        if (iVar7 + -1 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    iVar7 = FUN_0090ca30();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar9 = piStack_14 + 1;
    iVar2 = *piVar9;
    iVar7 = *piVar9;
    *piVar9 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*piStack_14)();
      LOCK();
      piVar9 = piStack_14 + 2;
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 19808 ; VA 0x00a04dd0 ; FUN_00a04dd0 */

char * __thiscall FUN_00a04dd0(undefined8 *param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  double *pdVar8;
  int iVar9;
  undefined8 uVar10;
  undefined8 auStack_ac [4];
  undefined4 uStack_88;
  undefined4 uStack_84;
  int *piStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_6c;
  int iStack_68;
  int *piStack_64;
  undefined8 uStack_60;
  double *pdStack_58;
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  double dStack_30;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined8 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da398;
  pvStack_10 = ExceptionList;
  pdStack_58 = (double *)PTR_s_Publish_Assets_01d65cac;
  ExceptionList = &pvStack_10;
  if (*(int *)((int)param_1 + 4) != 0) {
    LOCK();
    piVar7 = (int *)(*(int *)((int)param_1 + 4) + 8);
    ExceptionList = &pvStack_10;
    *piVar7 = *piVar7 + 1;
    UNLOCK();
  }
  uStack_60 = (double)*param_1;
  piStack_64 = &iStack_20;
  iStack_68 = 0xa04e29;
  puStack_14 = param_1;
  pdStack_58 = (double *)FUN_00a0b130();
  uStack_8 = 0;
  if (iStack_20 != 0) {
    uStack_28 = 0;
    piStack_24 = (int *)0x0;
    pdStack_58 = (double *)&uStack_28;
    uStack_8 = 1;
    uStack_60 = (double)CONCAT44(1,PTR_s_Publish_Assets_01d65cac);
    piStack_64 = param_3;
    iStack_68 = param_2;
    uStack_6c = 0xa04e6a;
    pdStack_58 = (double *)FUN_00a0d930();
    if ((char)pdStack_58 != '\0') {
      iVar9 = iStack_20 + 200;
      uStack_60 = (double)CONCAT44(0xa04e84,(undefined4)uStack_60);
      pdStack_58 = (double *)iVar9;
      iStack_18 = iVar9;
      pdStack_58 = (double *)FUN_016dee6d();
      if (pdStack_58 != (double *)0x0) {
        uStack_60 = (double)CONCAT44(0xa04e91,(undefined4)uStack_60);
        FUN_016df3c9();
      }
      iVar4 = iStack_20;
      param_3 = (int *)(param_1 + 1);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      uStack_60 = (double)CONCAT44(&param_2,0xa04eae);
      pdStack_58 = (double *)param_3;
      FUN_00a0a300();
      iVar2 = param_2;
      if (param_2 == *(int *)(iVar4 + 0x3c)) {
        if (DAT_01d84e8e != 0) {
          pdStack_58 = (double *)param_3;
          if (0xf < (uint)param_3[5]) {
            pdStack_58 = (double *)*param_3;
          }
          piStack_64 = (int *)(uint)DAT_01d84e8e;
          uStack_60 = (double)CONCAT44(PTR_s_Publish_Assets_01d65cac,
                                       "Commit Failure: %s - unexpected scriptGuid: %s");
          iStack_68 = 0xa04ee6;
          FUN_01677520();
        }
        if (DAT_01ee5c38 != 0) {
          if (*(int *)(iStack_20 + 0x24) == 0) {
            pdStack_58 = (double *)&DAT_0193ebc8;
          }
          else {
            pdStack_58 = *(double **)(*(int *)(iStack_20 + 0x24) + 0x28);
            if (0xf < *(uint *)((int)pdStack_58 + 0x14)) {
              pdStack_58 = *(double **)pdStack_58;
            }
          }
          uStack_60 = (double)CONCAT44(0xa04f17,(undefined4)uStack_60);
          FUN_0054eff0();
          pdStack_58 = (double *)0x1;
          uStack_8._0_1_ = 3;
          param_2 = *(int *)(iStack_20 + 0x1c);
          uStack_7c = 0;
          puStack_14 = auStack_ac;
          FUN_0054ef60(auStack_48);
          uStack_8._0_1_ = 4;
          FUN_0054ef60(param_3);
          uStack_8._0_1_ = 3;
          FUN_00a02360();
          uStack_7c = 0xa04f62;
          FUN_0090ca30();
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          pdStack_58 = (double *)0xa04f6e;
          FUN_005507b0();
        }
        pdStack_58 = (double *)0x0;
        uStack_60 = (double)CONCAT44(0xa04f78,(undefined4)uStack_60);
        FUN_00a11160();
      }
      else {
        pdStack_58 = (double *)&DAT_01d65be8;
        uStack_60 = (double)CONCAT44(0xa04f8a,(undefined4)uStack_60);
        param_3 = (int *)FUN_0091d440();
        iVar4 = *param_3;
        pdStack_58 = (double *)0xa04f94;
        iVar6 = FUN_0088cb40();
        if (iVar4 != iVar6) {
          pdStack_58 = (double *)0x18c072c;
          uStack_60 = (double)CONCAT44(0xa051fb,(undefined4)uStack_60);
                    /* WARNING: Subroutine does not return */
          FUN_016757c0();
        }
        piVar7 = param_3 + 2;
        if (param_3[1] == 0) {
          piVar7 = (int *)0x0;
        }
        if ((int *)(iVar2 + 100) != piVar7) {
          pdStack_58 = (double *)piVar7[4];
          if (0xf < (uint)piVar7[5]) {
            piVar7 = (int *)*piVar7;
          }
          uStack_60 = (double)CONCAT44(piVar7,0xa04fc3);
          FUN_005542c0();
        }
        pdStack_58 = (double *)&DAT_01d65c00;
        uStack_60 = (double)CONCAT44(0xa04fd0,(undefined4)uStack_60);
        param_3 = (int *)FUN_0091d440();
        iVar4 = *param_3;
        pdStack_58 = (double *)0xa04fda;
        iVar6 = FUN_0088c8c0();
        uVar5 = uStack_28;
        if (iVar4 != iVar6) {
          pdStack_58 = (double *)0x18c072c;
          uStack_60 = (double)CONCAT44(&UNK_00a05205,(undefined4)uStack_60);
                    /* WARNING: Subroutine does not return */
          FUN_016757c0();
        }
        pdStack_58 = (double *)&DAT_01d65ab0;
        piVar7 = param_3 + 2;
        if (param_3[1] == 0) {
          piVar7 = (int *)0x0;
        }
        *(int *)(iVar2 + 0x60) = *piVar7;
        uStack_60 = (double)CONCAT44(&param_3,0xa05008);
        piVar7 = (int *)FUN_00580040();
        if (*piVar7 != 0) {
          pdStack_58 = (double *)&DAT_01d65ab0;
          uStack_60 = (double)CONCAT44(0xa05019,(undefined4)uStack_60);
          pdStack_58 = (double *)FUN_0091d440();
          uStack_60 = (double)CONCAT44(0xa0501f,(undefined4)uStack_60);
          uVar10 = FUN_00a0a3b0();
          *(undefined8 *)(iVar2 + 0x58) = uVar10;
        }
        iVar2 = iStack_20;
        *(int *)(iStack_20 + 0x90) = *(int *)(iStack_20 + 0x90) + 1;
        if (*(int *)(iStack_20 + 0x90) == *(int *)(iStack_20 + 0x40)) {
          pdStack_58 = &dStack_30;
          uStack_60 = (double)CONCAT44(0xa0504c,(undefined4)uStack_60);
          pdVar8 = (double *)FUN_016830f0();
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          *(int *)(iStack_20 + 0xb0) = (int)((*pdVar8 - *(double *)(iVar2 + 0xa0)) * DAT_018c0d70);
          dStack_30 = (double)*(int *)(iStack_20 + 0xb0);
          if (DAT_01d65a40 == '\0') {
            pdStack_58 = (double *)0x3b;
            uStack_60 = 4.6509668716603396e-301;
            FUN_005542c0();
            piStack_64 = (int *)auStack_48;
            pdStack_58 = (double *)0x0;
            uStack_8 = CONCAT31(uStack_8._1_3_,6);
            uStack_60 = dStack_30;
            iStack_68 = 0xa050fe;
            FUN_00878cf0();
          }
          else {
            uVar3 = *(undefined *)(iStack_20 + 0x8d);
            pdStack_58 = (double *)0x14;
            uStack_60 = 4.650881428824135e-301;
            FUN_005542c0();
            piStack_64 = (int *)auStack_48;
            uStack_8 = CONCAT31(uStack_8._1_3_,5);
            uStack_60 = dStack_30;
            iStack_68 = 0xa050cf;
            pdStack_58 = (double *)CONCAT31((int3)((uint)uVar5 >> 8),uVar3);
            FUN_00a11480();
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          pdStack_58 = (double *)0xa0510d;
          FUN_005507b0();
          pdStack_58 = (double *)0x1;
          param_3 = *(int **)(iStack_20 + 0x1c);
          piVar7 = *(int **)((int)puStack_14 + 4);
          if (piVar7 != (int *)0x0) {
            LOCK();
            piVar7[2] = piVar7[2] + 1;
            UNLOCK();
            piVar7 = *(int **)((int)puStack_14 + 4);
          }
          uStack_84 = *(undefined4 *)puStack_14;
          piVar1 = piVar7 + 2;
          uStack_7c = 0;
          if (piVar7 != (int *)0x0) {
            LOCK();
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          uStack_88 = 0xa0515a;
          piStack_80 = piVar7;
          FUN_00a02670();
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar2 = *piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              uStack_7c = 0xa0516e;
              (**(code **)(*piVar7 + 4))();
            }
          }
          uStack_7c = 0xa05176;
          FUN_0090ca30();
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      uStack_60 = (double)CONCAT44(0xa05180,(undefined4)uStack_60);
      pdStack_58 = (double *)iVar9;
      pdStack_58 = (double *)FUN_016deec8();
      if (pdStack_58 != (double *)0x0) {
        uStack_60 = (double)CONCAT44(0xa0518d,(undefined4)uStack_60);
        pdStack_58 = (double *)FUN_016df3c9();
      }
    }
    piVar7 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_24 + 1;
      iVar9 = *piVar1;
      pdStack_58 = (double *)*piVar1;
      *piVar1 = iVar9 + -1;
      UNLOCK();
      if (iVar9 + -1 == 0) {
        pdStack_58 = (double *)0xa051a9;
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar9 = *piVar1;
        pdStack_58 = (double *)*piVar1;
        *piVar1 = iVar9 + -1;
        UNLOCK();
        if (iVar9 + -1 == 0) {
          pdStack_58 = (double *)0xa051b9;
          pdStack_58 = (double *)(**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar7 = piStack_1c + 1;
    iVar9 = *piVar7;
    pdStack_58 = (double *)*piVar7;
    *piVar7 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      pdStack_58 = (double *)0xa051cf;
      pdStack_58 = (double *)(**(code **)*piStack_1c)();
      LOCK();
      piVar7 = piStack_1c + 2;
      iVar9 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        pdStack_58 = (double *)0xa051de;
        pdStack_58 = (double *)(**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return (char *)pdStack_58;
}



/* FUNCTION 19809 ; VA 0x00a05210 ; FUN_00a05210 */

int __thiscall FUN_00a05210(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  undefined *puVar5;
  char cVar6;
  int iVar7;
  double *pdVar8;
  int *piVar9;
  char acStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  double dStack_20;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puVar5 = PTR_s_Place_Changes_01d65cb8;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da3d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1[1] != 0) {
    LOCK();
    piVar9 = (int *)(param_1[1] + 8);
    ExceptionList = &pvStack_10;
    *piVar9 = *piVar9 + 1;
    UNLOCK();
  }
  iVar7 = FUN_00a0b130(&iStack_18,*param_1,param_1[1],puVar5);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    cVar6 = FUN_00a0d4b0(param_2,param_3,PTR_s_Place_Changes_01d65cb8,0);
    if (cVar6 == '\0') {
      uStack_28 = 0;
      uStack_24 = 0xf;
      acStack_38[0] = cVar6;
      if (DAT_01d65a40 == '\0') {
        FUN_005542c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_008783f0(acStack_38,1,0);
      }
      else {
        FUN_005542c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_00a11370();
      }
      uStack_8 = uStack_8 & 0xffffff00;
      FUN_005507b0();
      FUN_0087c450("Studio","CollabEditVersionHistory","PlaceChangesFailed",1,0,0);
      if ((DAT_01d65a40 == '\0') || (*(char *)(iStack_18 + 0x8d) != '\0')) {
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        iVar7 = FUN_00a06980();
        goto LAB_00a0549c;
      }
    }
    iVar7 = iStack_18;
    pdVar8 = (double *)FUN_016830f0(&dStack_20);
    uStack_28 = 0;
    uStack_24 = 0xf;
    acStack_38[0] = '\0';
    *(int *)(iStack_18 + 0xbc) = (int)((*pdVar8 - *(double *)(iVar7 + 0xa0)) * DAT_018c0d70);
    dStack_20 = (double)*(int *)(iStack_18 + 0xbc);
    if (DAT_01d65a40 == '\0') {
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_00878cf0(acStack_38,dStack_20,0);
    }
    else {
      uVar3 = *(undefined *)(iStack_18 + 0x8d);
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_00a11480(acStack_38,dStack_20,uVar3);
    }
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_005507b0();
    piVar9 = (int *)param_1[1];
    if (piVar9 != (int *)0x0) {
      LOCK();
      piVar9[2] = piVar9[2] + 1;
      UNLOCK();
      piVar9 = (int *)param_1[1];
    }
    uVar4 = *param_1;
    piVar1 = piVar9 + 2;
    if (piVar9 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00a02100(uVar4,piVar9,0);
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
    iVar7 = FUN_0090ca30();
  }
LAB_00a0549c:
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar9 = piStack_14 + 1;
    iVar2 = *piVar9;
    iVar7 = *piVar9;
    *piVar9 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*piStack_14)();
      LOCK();
      piVar9 = piStack_14 + 2;
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 19810 ; VA 0x00a054e0 ; FUN_00a054e0 */

int __thiscall FUN_00a054e0(double *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  double *pdVar7;
  byte *pbVar8;
  int aiStack_8c [3];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  int *piStack_78;
  undefined4 uStack_74;
  undefined4 uStack_64;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined8 uStack_58;
  byte **ppbStack_50;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  double dStack_28;
  byte *pbStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da418;
  pvStack_10 = ExceptionList;
  ppbStack_50 = (byte **)PTR_s_Create_Commit_01d65934;
  ExceptionList = &pvStack_10;
  if (*(int *)((int)param_1 + 4) != 0) {
    LOCK();
    piVar6 = (int *)(*(int *)((int)param_1 + 4) + 8);
    ExceptionList = &pvStack_10;
    *piVar6 = *piVar6 + 1;
    UNLOCK();
  }
  uStack_58 = *param_1;
  piStack_5c = &iStack_18;
  uStack_60 = 0xa05536;
  iVar3 = FUN_00a0b130();
  uStack_8 = 0;
  if (iStack_18 != 0) {
    pbStack_20 = (byte *)0x0;
    piStack_1c = (int *)0x0;
    ppbStack_50 = &pbStack_20;
    uStack_8 = 1;
    uStack_58 = (double)CONCAT44(1,PTR_s_Create_Commit_01d65934);
    piStack_5c = param_3;
    uStack_60 = param_2;
    uStack_64 = 0xa05577;
    iVar3 = FUN_00a0d930();
    if ((char)iVar3 != '\0') {
      ppbStack_50 = (byte **)&DAT_01d65af8;
      pbVar8 = pbStack_20 + *pbStack_20 + 1;
      uStack_58 = (double)CONCAT44(pbVar8,0xa05595);
      uVar4 = FUN_0055c740();
      ppbStack_50 = (byte **)(-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
      uStack_58 = (double)CONCAT44(&DAT_01d65af8,uVar4);
      piStack_5c = (int *)&param_3;
      uStack_60 = 0xa055b6;
      FUN_00562fc0();
      if (param_3 == (int *)0x0) {
        if (DAT_01d84e8e != 0) {
          ppbStack_50 = (byte **)PTR_s_Create_Commit_01d65934;
          uStack_58 = (double)CONCAT44("Commit Failure: %s - no commit guid provided",
                                       (uint)DAT_01d84e8e);
          piStack_5c = (int *)0xa0576e;
          FUN_016774b0();
        }
        if (DAT_01ee5c38 != 0) {
          if (*(int *)(iStack_18 + 0x24) == 0) {
            ppbStack_50 = (byte **)&DAT_0193ebc8;
          }
          else {
            ppbStack_50 = *(byte ***)(*(int *)(iStack_18 + 0x24) + 0x28);
            if (0xf < ppbStack_50[5]) {
              ppbStack_50 = (byte **)*ppbStack_50;
            }
          }
          uStack_58 = (double)CONCAT44(0xa0579f,(undefined4)uStack_58);
          FUN_0054eff0();
          ppbStack_50 = (byte **)0x1;
          uStack_8._0_1_ = 4;
          uStack_74 = 0;
          param_3 = aiStack_8c;
          FUN_0054ef60(auStack_40);
          FUN_00a030b0();
          uStack_74 = 0xa057d1;
          FUN_0090ca30();
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          ppbStack_50 = (byte **)0xa057dd;
          FUN_005507b0();
        }
        ppbStack_50 = (byte **)0x0;
        uStack_58 = (double)CONCAT44(0xa057e7,(undefined4)uStack_58);
        iVar3 = FUN_00a11160();
      }
      else {
        ppbStack_50 = (byte **)&DAT_01d65af8;
        uStack_58 = (double)CONCAT44(0xa055cc,(undefined4)uStack_58);
        param_3 = (int *)FUN_0091d440();
        iVar3 = *param_3;
        ppbStack_50 = (byte **)0xa055d6;
        iVar5 = FUN_0088cb40();
        if (iVar3 != iVar5) {
          ppbStack_50 = (byte **)0x18c072c;
          uStack_58 = (double)CONCAT44(&UNK_00a0584f,(undefined4)uStack_58);
                    /* WARNING: Subroutine does not return */
          FUN_016757c0();
        }
        piVar6 = param_3 + 2;
        if (param_3[1] == 0) {
          piVar6 = (int *)0x0;
        }
        if ((int *)(iStack_18 + 0x70) != piVar6) {
          ppbStack_50 = (byte **)piVar6[4];
          if (0xf < (uint)piVar6[5]) {
            piVar6 = (int *)*piVar6;
          }
          uStack_58 = (double)CONCAT44(piVar6,0xa05608);
          FUN_005542c0();
        }
        iVar3 = iStack_18;
        ppbStack_50 = (byte **)&dStack_28;
        uStack_58 = (double)CONCAT44(0xa05614,(undefined4)uStack_58);
        pdVar7 = (double *)FUN_016830f0();
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = 0;
        *(int *)(iStack_18 + 0xa8) = (int)((*pdVar7 - *(double *)(iVar3 + 0xa0)) * DAT_018c0d70);
        dStack_28 = (double)*(int *)(iStack_18 + 0xa8);
        if (DAT_01d65a40 == '\0') {
          ppbStack_50 = (byte **)0x33;
          uStack_58 = 4.648916243593581e-301;
          FUN_005542c0();
          piStack_5c = (int *)auStack_40;
          ppbStack_50 = (byte **)0x0;
          uStack_8._0_1_ = 3;
          uStack_58 = dStack_28;
          uStack_60 = 0xa056d8;
          FUN_00878cf0();
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          ppbStack_50 = (byte **)0xa056e7;
          FUN_005507b0();
        }
        else {
          uVar2 = *(undefined *)(iStack_18 + 0x8d);
          ppbStack_50 = (byte **)0xc;
          uStack_58 = 4.64885928170275e-301;
          FUN_005542c0();
          piStack_5c = (int *)auStack_40;
          uStack_8._0_1_ = 2;
          uStack_58 = dStack_28;
          uStack_60 = 0xa05697;
          ppbStack_50 = (byte **)CONCAT31(0xffffff,uVar2);
          FUN_00a11480();
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          ppbStack_50 = (byte **)0xa056a6;
          FUN_005507b0();
        }
        piVar6 = *(int **)((int)param_1 + 4);
        ppbStack_50 = (byte **)0x1;
        param_3 = *(int **)(iStack_18 + 0x1c);
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[2] = piVar6[2] + 1;
          UNLOCK();
          piVar6 = *(int **)((int)param_1 + 4);
        }
        uStack_7c = *(undefined4 *)param_1;
        piVar1 = piVar6 + 2;
        uStack_74 = 0;
        if (piVar6 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        uStack_80 = 0xa05731;
        piStack_78 = piVar6;
        FUN_00a031e0();
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar3 = *piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            uStack_74 = 0xa05744;
            (**(code **)(*piVar6 + 4))();
          }
        }
        uStack_74 = 0xa0574c;
        iVar3 = FUN_0090ca30();
      }
    }
    piVar6 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar5 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        ppbStack_50 = (byte **)0xa057fd;
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar5 + -1;
        UNLOCK();
        if (iVar5 + -1 == 0) {
          ppbStack_50 = (byte **)0xa0580d;
          iVar3 = (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar6 = piStack_14 + 1;
    iVar5 = *piVar6;
    iVar3 = *piVar6;
    *piVar6 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      ppbStack_50 = (byte **)0xa05823;
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar6 = piStack_14 + 2;
      iVar5 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        ppbStack_50 = (byte **)0xa05832;
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19811 ; VA 0x00a05850 ; FUN_00a05850 */

int __thiscall FUN_00a05850(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  undefined *puVar5;
  char cVar6;
  int iVar7;
  double *pdVar8;
  int *piVar9;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  double dStack_20;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puVar5 = PTR_s_Place_Changes_01d65cb8;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017da348;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1[1] != 0) {
    LOCK();
    piVar9 = (int *)(param_1[1] + 8);
    ExceptionList = &pvStack_10;
    *piVar9 = *piVar9 + 1;
    UNLOCK();
  }
  iVar7 = FUN_00a0b130(&iStack_18,*param_1,param_1[1],puVar5);
  iStack_8 = 0;
  if (iStack_18 != 0) {
    cVar6 = FUN_00a0d4b0(param_2,param_3,PTR_s_Place_Changes_01d65cb8,0);
    iVar7 = iStack_18;
    if (cVar6 == '\0') {
      if ((((param_2 == 0) && (iVar7 = *(int *)(param_3 + 0xc), iVar7 < 500)) && (iVar7 != 0x198))
         && (iVar7 != 0x1ad)) {
        if (DAT_01d84e8e != '\0') {
          FUN_016774b0(DAT_01d84e8e,"Commit Failure: %s - fatal error",PTR_s_Place_Changes_01d65cb8)
          ;
        }
        piVar9 = (int *)param_1[1];
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[2] = piVar9[2] + 1;
          UNLOCK();
          piVar9 = (int *)param_1[1];
        }
        uVar4 = *param_1;
        piVar1 = piVar9 + 2;
        if (piVar9 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_00a02540(uVar4,piVar9,0);
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar7 = *piVar1;
          *piVar1 = iVar7 + -1;
          UNLOCK();
          if (iVar7 + -1 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      else {
        piVar9 = (int *)param_1[1];
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[2] = piVar9[2] + 1;
          UNLOCK();
          piVar9 = (int *)param_1[1];
        }
        uVar4 = *param_1;
        piVar1 = piVar9 + 2;
        if (piVar9 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_00a01fd0(uVar4,piVar9,0);
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar7 = *piVar1;
          *piVar1 = iVar7 + -1;
          UNLOCK();
          if (iVar7 + -1 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    else {
      pdVar8 = (double *)FUN_016830f0(&dStack_20);
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      *(int *)(iStack_18 + 0xbc) = (int)((*pdVar8 - *(double *)(iVar7 + 0xa0)) * DAT_018c0d70);
      dStack_20 = (double)*(int *)(iStack_18 + 0xbc);
      if (DAT_01d65a40 == '\0') {
        FUN_005542c0();
        iStack_8._0_1_ = 2;
        FUN_00878cf0(auStack_38,dStack_20,0);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
      }
      else {
        uVar3 = *(undefined *)(iStack_18 + 0x8d);
        FUN_005542c0();
        iStack_8._0_1_ = 1;
        FUN_00a11480(auStack_38,dStack_20,CONCAT31(0xffffff,uVar3));
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
      }
      piVar9 = (int *)param_1[1];
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[2] = piVar9[2] + 1;
        UNLOCK();
        piVar9 = (int *)param_1[1];
      }
      uVar4 = *param_1;
      piVar1 = piVar9 + 2;
      if (piVar9 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00a028d0(uVar4,piVar9,0);
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar7 = *piVar1;
        *piVar1 = iVar7 + -1;
        UNLOCK();
        if (iVar7 + -1 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    iVar7 = FUN_0090ca30();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar9 = piStack_14 + 1;
    iVar2 = *piVar9;
    iVar7 = *piVar9;
    *piVar9 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*piStack_14)();
      LOCK();
      piVar9 = piStack_14 + 2;
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 19812 ; VA 0x00a05b70 ; FUN_00a05b70 */

int __thiscall FUN_00a05b70(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined *puVar4;
  int iVar5;
  double *pdVar6;
  int iVar7;
  int *piVar8;
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  double dStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar4 = PTR_s_Instance_Changes_01d65cb0;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da450;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1[1] != 0) {
    LOCK();
    piVar8 = (int *)(param_1[1] + 8);
    ExceptionList = &pvStack_10;
    *piVar8 = *piVar8 + 1;
    UNLOCK();
  }
  puStack_14 = param_1;
  iVar5 = FUN_00a0b130(&iStack_24,*param_1,param_1[1],puVar4);
  uStack_8 = 0;
  if (iStack_24 != 0) {
    iVar5 = FUN_00a0d4b0(param_2,param_3,PTR_s_Instance_Changes_01d65cb0,1);
    if ((char)iVar5 != '\0') {
      iVar7 = iStack_24 + 200;
      iVar5 = FUN_016dee6d(iVar7);
      if (iVar5 != 0) {
        FUN_016df3c9(iVar5);
      }
      iVar5 = iStack_24;
      uStack_8._0_1_ = 1;
      *(int *)(iStack_24 + 0x94) = *(int *)(iStack_24 + 0x94) + 1;
      if (*(int *)(iStack_24 + 0x94) == param_1[2]) {
        pdVar6 = (double *)FUN_016830f0(&dStack_1c);
        uStack_2c = 0;
        uStack_28 = 0xf;
        auStack_3c[0] = 0;
        *(int *)(iStack_24 + 0xb4) = (int)((*pdVar6 - *(double *)(iVar5 + 0xa0)) * DAT_018c0d70);
        dStack_1c = (double)*(int *)(iStack_24 + 0xb4);
        if (DAT_01d65a40 == '\0') {
          FUN_005542c0();
          uStack_8._0_1_ = 3;
          FUN_00878cf0(auStack_3c,dStack_1c,0);
          uStack_8._0_1_ = 1;
          FUN_005507b0();
        }
        else {
          uVar2 = *(undefined *)(iStack_24 + 0x8d);
          FUN_005542c0();
          uStack_8._0_1_ = 2;
          FUN_00a11480(auStack_3c,dStack_1c,uVar2);
          uStack_8._0_1_ = 1;
          FUN_005507b0();
          param_1 = puStack_14;
        }
        piVar8 = (int *)param_1[1];
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar8[2] = piVar8[2] + 1;
          UNLOCK();
          piVar8 = (int *)param_1[1];
        }
        uVar3 = *param_1;
        piVar1 = piVar8 + 2;
        if (piVar8 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_00a01b60(uVar3,piVar8,0);
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar5 = *piVar1;
          *piVar1 = iVar5 + -1;
          UNLOCK();
          if (iVar5 + -1 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
        FUN_0090ca30();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      iVar5 = FUN_016deec8(iVar7);
      if (iVar5 != 0) {
        iVar5 = FUN_016df3c9(iVar5);
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar8 = piStack_20 + 1;
    iVar7 = *piVar8;
    iVar5 = *piVar8;
    *piVar8 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      iVar5 = (**(code **)*piStack_20)();
      LOCK();
      piVar8 = piStack_20 + 2;
      iVar7 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        iVar5 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 19813 ; VA 0x00a05de0 ; FUN_00a05de0 */

int __fastcall FUN_00a05de0(undefined4 param_1)

{
  undefined uVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  double *pdVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  undefined auStack_44 [16];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [16];
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017da4a8;
  pvStack_10 = ExceptionList;
  iStack_1c = 0;
  piStack_18 = (int *)0x0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00602ce0(param_1);
  iVar3 = iStack_1c;
  iStack_8 = 0;
  if (iStack_1c != 0) {
    if (*(char *)(iStack_1c + 0x8d) != '\0') {
      piVar7 = *(int **)(iStack_1c + 0x3c);
      piVar6 = (int *)*piVar7;
      if (piVar6 != piVar7) {
        do {
          iVar2 = FUN_008f7870(piVar6[8]);
          if (iVar2 == 0) {
            FUN_00a11160(1);
            goto LAB_00a05f43;
          }
          piVar6 = (int *)*piVar6;
        } while (piVar6 != piVar7);
        piVar7 = *(int **)(iVar3 + 0x3c);
      }
      for (piVar6 = (int *)*piVar7; piVar6 != piVar7; piVar6 = (int *)*piVar6) {
        iStack_14 = piVar6[8];
        if ((iStack_14 == 0) ||
           (iVar2 = *(int *)(iStack_14 + 0xc), iVar3 = FUN_00b73ae0(),
           (uint)*(ushort *)(iVar3 + 0x1da) <
           (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
          iStack_14 = piVar6[8];
          if ((iStack_14 != 0) &&
             (iVar2 = *(int *)(iStack_14 + 0xc), iVar3 = FUN_009ec190(),
             (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
             (uint)*(ushort *)(iVar3 + 0x1da))) {
            uVar4 = FUN_00886c00();
            iStack_8._0_1_ = 2;
            FUN_009ed830(uVar4);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_0056e380();
            goto LAB_00a05f21;
          }
        }
        else {
          uVar4 = FUN_00886c00();
          iStack_8._0_1_ = 1;
          FUN_00b75530(uVar4);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_0056e380();
LAB_00a05f21:
          FUN_0056e380();
        }
        iVar3 = iStack_1c;
      }
      FUN_006eccd0();
    }
    FUN_006eccd0();
LAB_00a05f43:
    pdVar5 = (double *)FUN_016830f0(auStack_2c);
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = 0;
    iVar8 = (int)((*pdVar5 - *(double *)(iVar3 + 0x98)) * DAT_018c0d70);
    iVar2 = ((((iVar8 - *(int *)(iVar3 + 0xc0)) - *(int *)(iVar3 + 0xb4)) - *(int *)(iVar3 + 0xb0))
            - *(int *)(iVar3 + 0xac)) - *(int *)(iVar3 + 0xa8);
    if (DAT_01d65a40 == '\0') {
      FUN_005542c0();
      iStack_8._0_1_ = 5;
      FUN_00878cf0(auStack_44,(double)iVar8,0);
      iStack_8._0_1_ = 0;
      FUN_005507b0();
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = 0;
      FUN_005542c0();
      iStack_8._0_1_ = 6;
      FUN_00878cf0(auStack_44,(double)iVar2,0);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
    }
    else {
      uVar1 = *(undefined *)(iVar3 + 0x8d);
      FUN_005542c0();
      iStack_8._0_1_ = 3;
      FUN_00a11480(auStack_44,(double)iVar8,uVar1);
      iStack_8._0_1_ = 0;
      FUN_005507b0();
      uStack_34 = 0;
      uVar1 = *(undefined *)(iStack_1c + 0x8d);
      uStack_30 = 0xf;
      auStack_44[0] = 0;
      FUN_005542c0();
      iStack_8._0_1_ = 4;
      FUN_00a11480(auStack_44,(double)iVar2,uVar1);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = 0;
    if (DAT_01d65a40 == '\0') {
      FUN_005542c0();
      iStack_8._0_1_ = 8;
      FUN_008783f0(auStack_44,1,0);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
      iVar2 = FUN_0087c450("Studio","CollabEditVersionHistory","CommitFinalized",1,0,0);
    }
    else {
      FUN_005542c0();
      iStack_8 = CONCAT31(iStack_8._1_3_,7);
      FUN_00a11370();
      iVar2 = FUN_005507b0();
    }
  }
  piVar7 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar6 = piStack_18 + 1;
    iVar3 = *piVar6;
    iVar2 = *piVar6;
    *piVar6 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar2 = (**(code **)*piStack_18)();
      LOCK();
      piVar6 = piVar7 + 2;
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar2 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 19814 ; VA 0x00a061a0 ; FUN_00a061a0 */

int __fastcall FUN_00a061a0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int *piVar4;
  int iVar5;
  double *pdVar6;
  undefined3 uVar7;
  int iVar8;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da4f8;
  pvStack_10 = ExceptionList;
  iStack_20 = 0;
  piStack_1c = (int *)0x0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00602ce0(param_1);
  iVar2 = iStack_20;
  uStack_8 = 0;
  if (iStack_20 != 0) {
    FUN_00a07f70();
    FUN_006eccd0();
    pdVar6 = (double *)FUN_016830f0(auStack_18);
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = 0;
    iVar5 = (int)((*pdVar6 - *(double *)(iVar2 + 0x98)) * DAT_018c0d70);
    iVar8 = ((((((iVar5 - *(int *)(iVar2 + 0xc0)) - *(int *)(iVar2 + 0xbc)) - *(int *)(iVar2 + 0xb8)
               ) - *(int *)(iVar2 + 0xb4)) - *(int *)(iVar2 + 0xb0)) - *(int *)(iVar2 + 0xac)) -
            *(int *)(iVar2 + 0xa8);
    iStack_14 = iVar5;
    if (DAT_01d65a40 == '\0') {
      FUN_005542c0();
      uStack_8._0_1_ = 3;
      FUN_00878cf0(auStack_38,(double)iVar5,0);
      uStack_8._0_1_ = 0;
      FUN_005507b0();
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_00878cf0(auStack_38,(double)iVar8,0);
    }
    else {
      uVar3 = *(undefined *)(iVar2 + 0x8d);
      uVar7 = (undefined3)((uint)iVar5 >> 8);
      FUN_005542c0();
      uStack_8._0_1_ = 1;
      FUN_00a11480(auStack_38,(double)iStack_14,CONCAT31(uVar7,uVar3));
      uStack_8._0_1_ = 0;
      FUN_005507b0();
      uVar3 = *(undefined *)(iVar2 + 0x8d);
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00a11480(auStack_38,(double)iVar8,CONCAT31(uVar7,uVar3));
    }
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_005507b0();
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = 0;
    if (DAT_01d65a40 == '\0') {
      FUN_005542c0();
      uStack_8._0_1_ = 6;
      FUN_008783f0(auStack_38,1,0);
      uStack_8 = (uint)uStack_8._1_3_ << 8;
      FUN_005507b0();
      iVar5 = FUN_0087c450("Studio","CollabEditVersionHistory","CommitFinalized",1,0,0);
    }
    else {
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      FUN_00a11370();
      iVar5 = FUN_005507b0();
    }
  }
  piVar4 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 19815 ; VA 0x00a06450 ; FUN_00a06450 */

int __thiscall FUN_00a06450(double *param_1,int param_2,byte *param_3)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  double *pdVar6;
  uint uVar7;
  byte *pbVar8;
  byte *pbVar9;
  int *piVar10;
  byte *pbVar11;
  undefined8 uVar12;
  byte abStack_b0 [12];
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_88;
  int iStack_84;
  byte *pbStack_80;
  undefined8 uStack_7c;
  byte **ppbStack_74;
  byte abStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined8 uStack_34;
  byte *pbStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  double *pdStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da558;
  pvStack_10 = ExceptionList;
  ppbStack_74 = (byte **)PTR_s_Asset_Mappings_01d65ca8;
  ExceptionList = &pvStack_10;
  if (*(int *)((int)param_1 + 4) != 0) {
    LOCK();
    piVar10 = (int *)(*(int *)((int)param_1 + 4) + 8);
    ExceptionList = &pvStack_10;
    *piVar10 = *piVar10 + 1;
    UNLOCK();
  }
  uStack_7c = *param_1;
  pbStack_80 = (byte *)&iStack_24;
  iStack_84 = 0xa064a7;
  pdStack_1c = param_1;
  iVar3 = FUN_00a0b130();
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (iStack_24 != 0) {
    pbStack_2c = (byte *)0x0;
    piStack_28 = (int *)0x0;
    ppbStack_74 = &pbStack_2c;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    uStack_7c = (double)CONCAT44(1,PTR_s_Asset_Mappings_01d65ca8);
    pbStack_80 = param_3;
    iStack_84 = param_2;
    uStack_88 = 0xa064e8;
    iVar3 = FUN_00a0d930();
    if ((char)iVar3 != '\0') {
      ppbStack_74 = (byte **)&DAT_01d65c90;
      if (DAT_01d65a60 == '\0') {
        ppbStack_74 = (byte **)&DAT_01d65ba0;
      }
      uStack_7c = (double)CONCAT44(0xa0650d,(undefined4)uStack_7c);
      FUN_0054ef60();
      pbVar8 = pbStack_2c;
      uStack_8._0_1_ = 2;
      pbVar9 = pbStack_2c + *pbStack_2c + 1;
      ppbStack_74 = (byte **)auStack_4c;
      uStack_7c = (double)CONCAT44(pbVar9,0xa06526);
      uVar4 = FUN_0055c740();
      ppbStack_74 = (byte **)(-(uint)(pbVar9 != (byte *)0x0) & (uint)(pbVar9 + 1));
      uStack_7c = (double)CONCAT44(auStack_4c,uVar4);
      pbStack_80 = (byte *)&param_3;
      iStack_84 = 0xa06543;
      FUN_00562fc0();
      if (param_3 == (byte *)0x0) {
        if (DAT_01d84e8e != 0) {
          ppbStack_74 = (byte **)PTR_s_Asset_Mappings_01d65ca8;
          uStack_7c = (double)CONCAT44("Commit Failure: %s - no asset mapings available",
                                       (uint)DAT_01d84e8e);
          pbStack_80 = (byte *)0xa06852;
          FUN_016774b0();
        }
        if (DAT_01ee5c38 != 0) {
          if (*(int *)(iStack_24 + 0x24) == 0) {
            ppbStack_74 = (byte **)&DAT_0193ebc8;
          }
          else {
            ppbStack_74 = *(byte ***)(*(int *)(iStack_24 + 0x24) + 0x28);
            if (0xf < ppbStack_74[5]) {
              ppbStack_74 = (byte **)*ppbStack_74;
            }
          }
          uStack_7c = (double)CONCAT44(0xa06883,(undefined4)uStack_7c);
          FUN_0054eff0();
          ppbStack_74 = (byte **)0x1;
          uStack_8._0_1_ = 8;
          uStack_98 = 0;
          param_3 = abStack_b0;
          FUN_0054ef60(abStack_64);
          FUN_00a02a00();
          uStack_98 = 0xa068b5;
          FUN_0090ca30();
          uStack_8._0_1_ = 2;
          ppbStack_74 = (byte **)0xa068c1;
          FUN_005507b0();
        }
        ppbStack_74 = (byte **)0x0;
        uStack_7c = (double)CONCAT44(0xa068ce,(undefined4)uStack_7c);
        iVar3 = FUN_00a11160();
      }
      else {
        if (DAT_01d65a60 == '\0') {
          ppbStack_74 = (byte **)&DAT_01d65ba0;
          uStack_7c = (double)CONCAT44(0xa06650,(undefined4)uStack_7c);
          FUN_0091d440();
          ppbStack_74 = (byte **)0xa06657;
          ppbStack_74 = (byte **)FUN_0055d640();
          uStack_7c = (double)CONCAT44(0xa06660,(undefined4)uStack_7c);
          FUN_00557fc0();
          ppbStack_74 = &param_3;
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          uStack_7c = (double)CONCAT44(0xa06670,(undefined4)uStack_7c);
          FUN_00618a80();
          for (pbVar9 = param_3; pbVar9 != (byte *)0x0; pbVar9 = *(byte **)pbVar9) {
            ppbStack_74 = (byte **)(pbVar9 + 8);
            uStack_7c = (double)CONCAT44(0xa06683,(undefined4)uStack_7c);
            FUN_0054ef60();
            ppbStack_74 = (byte **)(pbVar9 + 0x20);
            uStack_8._0_1_ = 5;
            uStack_7c = (double)CONCAT44(0xa06690,(undefined4)uStack_7c);
            uVar12 = FUN_00a0a3b0();
            iVar3 = iStack_24;
            param_2 = (int)((ulonglong)uVar12 >> 0x20);
            pbVar8 = (byte *)uVar12;
            ppbStack_74 = (byte **)abStack_64;
            uStack_7c = (double)CONCAT44(&param_3,0xa066ab);
            FUN_00a0a300();
            if (param_3 != *(byte **)(iVar3 + 0x3c)) {
              *(byte **)(param_3 + 0x58) = pbVar8;
              *(int *)(param_3 + 0x5c) = param_2;
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,4);
            ppbStack_74 = (byte **)0xa066c8;
            FUN_005507b0();
          }
        }
        else {
          ppbStack_74 = (byte **)&DAT_01d65c90;
          uStack_7c = (double)CONCAT44(0xa06566,(undefined4)uStack_7c);
          FUN_0091d440();
          ppbStack_74 = (byte **)0xa0656d;
          ppbStack_74 = (byte **)FUN_0055d640();
          uStack_7c = (double)CONCAT44(0xa06576,(undefined4)uStack_7c);
          FUN_00557fc0();
          ppbStack_74 = &param_3;
          uStack_8 = CONCAT31(uStack_8._1_3_,3);
          uStack_7c = (double)CONCAT44(0xa06586,(undefined4)uStack_7c);
          FUN_00618a80();
          for (pbVar9 = param_3; pbVar9 != (byte *)0x0; pbVar9 = *(byte **)pbVar9) {
            iVar3 = *(int *)(pbVar9 + 0x20);
            pbVar8 = pbVar9 + 8;
            ppbStack_74 = (byte **)0xa0659c;
            iVar5 = FUN_008881d0();
            if (((iVar3 == iVar5) && (*(int *)(pbVar9 + 0x24) != 0)) &&
               (pbVar9 + 0x28 != (byte *)0x0)) {
              param_3 = *(byte **)(pbVar9 + 0x28);
              ppbStack_74 = (byte **)&DAT_01d65ab0;
              pbVar11 = param_3 + *param_3 + 1;
              uStack_7c = (double)CONCAT44(pbVar11,0xa065d1);
              uVar4 = FUN_0055c740();
              ppbStack_74 = (byte **)(-(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1));
              uStack_7c = (double)CONCAT44(&DAT_01d65ab0,uVar4);
              pbStack_80 = (byte *)&param_2;
              iStack_84 = 0xa065f2;
              FUN_00562fc0();
              if (param_2 != 0) {
                ppbStack_74 = (byte **)&DAT_01d65ab0;
                uStack_7c = (double)CONCAT44(0xa06604,(undefined4)uStack_7c);
                ppbStack_74 = (byte **)FUN_0091d440();
                uStack_7c = (double)CONCAT44(0xa0660a,(undefined4)uStack_7c);
                uVar12 = FUN_00a0a3b0();
                iVar3 = iStack_24;
                uStack_18 = (undefined4)((ulonglong)uVar12 >> 0x20);
                param_3 = (byte *)uVar12;
                uStack_7c = (double)CONCAT44(&iStack_14,0xa06623);
                ppbStack_74 = (byte **)pbVar8;
                FUN_00a0a300();
                if (iStack_14 != *(int *)(iVar3 + 0x3c)) {
                  *(byte **)(iStack_14 + 0x58) = param_3;
                  *(undefined4 *)(iStack_14 + 0x5c) = uStack_18;
                }
              }
            }
          }
        }
        uStack_8._0_1_ = 2;
        if (uStack_34._4_4_ != (int *)0x0) {
          LOCK();
          iVar3 = uStack_34._4_4_[1] + -1;
          uStack_34._4_4_[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppbStack_74 = (byte **)0xa066eb;
            (**(code **)*uStack_34._4_4_)();
            LOCK();
            iVar3 = uStack_34._4_4_[2] + -1;
            uStack_34._4_4_[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              ppbStack_74 = (byte **)0xa066fb;
              (**(code **)(*uStack_34._4_4_ + 4))();
            }
          }
        }
        iVar3 = iStack_24;
        ppbStack_74 = (byte **)&uStack_34;
        uStack_7c = (double)CONCAT44(0xa06707,(undefined4)uStack_7c);
        pdVar6 = (double *)FUN_016830f0();
        uStack_54 = 0;
        uStack_50 = 0xf;
        abStack_64[0] = 0;
        *(int *)(iStack_24 + 0xac) = (int)((*pdVar6 - *(double *)(iVar3 + 0xa0)) * DAT_018c0d70);
        uStack_34 = (double)*(int *)(iStack_24 + 0xac);
        if (DAT_01d65a40 == '\0') {
          ppbStack_74 = (byte **)0x33;
          uStack_7c = 4.649913076685774e-301;
          FUN_005542c0();
          pbStack_80 = abStack_64;
          ppbStack_74 = (byte **)0x0;
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          uStack_7c = uStack_34;
          iStack_84 = 0xa067b9;
          FUN_00878cf0();
        }
        else {
          uVar2 = *(undefined *)(iStack_24 + 0x8d);
          ppbStack_74 = (byte **)0xc;
          uStack_7c = 4.649856114794958e-301;
          FUN_005542c0();
          pbStack_80 = abStack_64;
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          uStack_7c = uStack_34;
          iStack_84 = 0xa0678a;
          ppbStack_74 = (byte **)CONCAT31((int3)((uint)pbVar8 >> 8),uVar2);
          FUN_00a11480();
        }
        uStack_8._0_1_ = 2;
        ppbStack_74 = (byte **)0xa067c8;
        FUN_005507b0();
        ppbStack_74 = (byte **)0x1;
        param_3 = *(byte **)(iStack_24 + 0x1c);
        piVar10 = *(int **)((int)pdStack_1c + 4);
        if (piVar10 != (int *)0x0) {
          LOCK();
          piVar10[2] = piVar10[2] + 1;
          UNLOCK();
          piVar10 = *(int **)((int)pdStack_1c + 4);
        }
        uStack_a0 = *(undefined4 *)pdStack_1c;
        piVar1 = piVar10 + 2;
        uStack_98 = 0;
        if (piVar10 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        uStack_a4 = 0xa06815;
        piStack_9c = piVar10;
        FUN_00a02230();
        if (piVar10 != (int *)0x0) {
          LOCK();
          iVar3 = *piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            uStack_98 = 0xa06828;
            (**(code **)(*piVar10 + 4))();
          }
        }
        uStack_98 = 0xa06830;
        iVar3 = FUN_0090ca30();
      }
      if (0xf < uStack_38) {
        ppbStack_74 = (byte **)(uStack_38 + 1);
        uVar7 = auStack_4c[0];
        if (0xfff < ppbStack_74) {
          uVar7 = *(uint *)(auStack_4c[0] - 4);
          ppbStack_74 = (byte **)(uStack_38 + 0x24);
          if (0x1f < (auStack_4c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
            ppbStack_74 = (byte **)&UNK_00a06973;
            FUN_017167a3();
          }
        }
        uStack_7c = (double)CONCAT44(uVar7,0xa068fb);
        iVar3 = FUN_01674ea0();
      }
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    }
    piVar10 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_28 + 1;
      iVar5 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        ppbStack_74 = (byte **)0xa06926;
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar10 + 2;
        iVar5 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar5 + -1;
        UNLOCK();
        if (iVar5 + -1 == 0) {
          ppbStack_74 = (byte **)0xa06936;
          iVar3 = (**(code **)(*piVar10 + 4))();
        }
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar10 = piStack_20 + 1;
    iVar5 = *piVar10;
    iVar3 = *piVar10;
    *piVar10 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      ppbStack_74 = (byte **)0xa0694c;
      iVar3 = (**(code **)*piStack_20)();
      LOCK();
      piVar10 = piStack_20 + 2;
      iVar5 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        ppbStack_74 = (byte **)0xa0695b;
        iVar3 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19816 ; VA 0x00a06980 ; FUN_00a06980 */

/* WARNING: Removing unreachable block (ram,0x00a069d2) */
/* WARNING: Removing unreachable block (ram,0x00a069e2) */
/* WARNING: Removing unreachable block (ram,0x00a069e8) */

void * __thiscall FUN_00a06980(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da588;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 19817 ; VA 0x00a06a53 ; Catch@00a06a53 */

undefined * Catch_00a06a53(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00a06a64;
}



/* FUNCTION 19818 ; VA 0x00a06a80 ; FUN_00a06a80 */

void __fastcall FUN_00a06a80(int param_1)

{
  undefined uVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da5b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_016830f0(auStack_18);
  *(undefined4 *)(param_1 + 0x98) = *puVar2;
  *(undefined4 *)(param_1 + 0x9c) = puVar2[1];
  if (DAT_01d65a40 == '\0') {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("Studio.TeamCreate.CollabEditVersionHistory.CommitRecoveryAttempt",0x40);
    uStack_8 = 1;
    FUN_008783f0(auStack_30,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_1c) {
      uVar4 = uStack_1c + 1;
      uVar3 = auStack_30[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_30[0] - 4);
        uVar4 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
  }
  else {
    uVar1 = *(undefined *)(param_1 + 0x8d);
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    FUN_005542c0("CommitRecoveryAttempt",0x15);
    uStack_8 = 0;
    FUN_00a11370(auStack_48,uVar1);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_34) {
      uVar4 = uStack_34 + 1;
      uVar3 = auStack_48[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_48[0] - 4);
        uVar4 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
  }
  FUN_0087c450("Studio","CollabEditVersionHistory","CommitRecoveryAttempt",1,0,0);
  FUN_00a07430();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19819 ; VA 0x00a06c10 ; FUN_00a06c10 */

int __fastcall FUN_00a06c10(int param_1)

{
  undefined4 *****pppppuVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined uVar8;
  undefined3 uVar9;
  undefined4 *puVar10;
  undefined4 *****pppppuVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  int iVar14;
  undefined4 ****ppppuVar15;
  uint uVar16;
  uint uVar17;
  undefined8 uVar18;
  undefined auStack_158 [120];
  uint auStack_e0 [4];
  undefined4 uStack_d0;
  uint uStack_cc;
  uint auStack_c8 [4];
  undefined4 uStack_b8;
  uint uStack_b4;
  uint auStack_b0 [4];
  undefined4 uStack_a0;
  uint uStack_9c;
  undefined **ppuStack_98;
  undefined4 uStack_94;
  int *piStack_90;
  uint auStack_88 [4];
  undefined4 uStack_78;
  undefined ***pppuStack_74;
  undefined4 uStack_70;
  int *piStack_6c;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 ****ppppuStack_50;
  undefined4 ***pppuStack_4c;
  undefined4 ***pppuStack_48;
  undefined4 ***pppuStack_44;
  undefined8 uStack_40;
  undefined4 ****appppuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da645;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  if (DAT_01ee6bcc != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee6bcc,"Commit: Finalize",0);
  }
  puVar10 = (undefined4 *)FUN_016830f0(&uStack_70);
  *(undefined4 *)(param_1 + 0xa0) = *puVar10;
  *(undefined4 *)(param_1 + 0xa4) = puVar10[1];
  FUN_008c0cc0(&uStack_70,param_1);
  uStack_40 = 0xf00000000;
  ppppuStack_50 = (undefined4 ****)((uint)ppppuStack_50 & 0xffffff00);
  uStack_8._1_3_ = 0;
  uVar9 = uStack_8._1_3_;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if ((DAT_01d658cc < 1) || (DAT_01d65908 < DAT_01d658cc)) {
    uStack_8._1_3_ = uVar9;
    FUN_0054ef60(param_1 + 0x70);
    pppppuVar11 = (undefined4 *****)FUN_00fb8d10(auStack_88);
    uStack_8._0_1_ = 8;
    if (&ppppuStack_50 != pppppuVar11) {
      pppppuVar1 = pppppuVar11 + 4;
      if ((undefined4 ****)0xf < pppppuVar11[5]) {
        pppppuVar11 = (undefined4 *****)*pppppuVar11;
      }
      FUN_005542c0(pppppuVar11,*pppppuVar1);
    }
    uStack_8._0_1_ = 1;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < pppuStack_74) {
      uVar16 = (int)pppuStack_74 + 1;
      uVar17 = auStack_88[0];
      if (0xfff < uVar16) {
        uVar17 = *(uint *)(auStack_88[0] - 4);
        uVar16 = (int)pppuStack_74 + 0x24;
        if (0x1f < (auStack_88[0] - uVar17) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      goto LAB_00a07054;
    }
  }
  else {
    uStack_58 = 0;
    uStack_54 = 0xf;
    auStack_68[0] = auStack_68[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 2;
    uStack_28 = 0;
    uStack_24 = 0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 3;
    uStack_d0 = 0;
    uStack_cc = 0xf;
    auStack_e0[0] = auStack_e0[0] & 0xffffff00;
    FUN_005542c0("universe-history-mock/commits/200/commit",0x28);
    uStack_8._0_1_ = 4;
    uStack_b8 = 0;
    uStack_b4 = 0xf;
    auStack_c8[0] = auStack_c8[0] & 0xffffff00;
    FUN_005542c0("apis.simulpong.com",0x12);
    uStack_8._0_1_ = 5;
    uStack_a0 = 0;
    uStack_9c = 0xf;
    auStack_b0[0] = auStack_b0[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c71bc,4);
    uStack_8._0_1_ = 6;
    FUN_0151bcc0(auStack_158,auStack_b0,auStack_c8,auStack_e0,appppuStack_38,auStack_68);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    pppppuVar11 = (undefined4 *****)FUN_0151bb70(auStack_88);
    if (&ppppuStack_50 != pppppuVar11) {
      FUN_005507b0();
      ppppuStack_50 = *pppppuVar11;
      pppuStack_4c = pppppuVar11[1];
      pppuStack_48 = pppppuVar11[2];
      pppuStack_44 = pppppuVar11[3];
      uStack_40 = *(undefined8 *)(pppppuVar11 + 4);
      pppppuVar11[4] = (undefined4 ****)0x0;
      pppppuVar11[5] = (undefined4 ****)0xf;
      *(undefined *)pppppuVar11 = 0;
    }
    if (0xf < pppuStack_74) {
      uVar16 = (int)pppuStack_74 + 1;
      uVar17 = auStack_88[0];
      if (0xfff < uVar16) {
        uVar17 = *(uint *)(auStack_88[0] - 4);
        uVar16 = (int)pppuStack_74 + 0x24;
        if (0x1f < (auStack_88[0] - uVar17) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar16);
    }
    uStack_78 = 0;
    pppuStack_74 = (undefined ***)0xf;
    auStack_88[0] = auStack_88[0] & 0xffffff00;
    FUN_0056d9d0();
    uStack_8._0_1_ = 5;
    if (0xf < uStack_9c) {
      uVar16 = uStack_9c + 1;
      uVar17 = auStack_b0[0];
      if (0xfff < uVar16) {
        uVar17 = *(uint *)(auStack_b0[0] - 4);
        uVar16 = uStack_9c + 0x24;
        if (0x1f < (auStack_b0[0] - uVar17) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar16);
    }
    uStack_a0 = 0;
    uStack_9c = 0xf;
    auStack_b0[0] = auStack_b0[0] & 0xffffff00;
    uStack_8._0_1_ = 4;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_b4) {
      uVar16 = uStack_b4 + 1;
      uVar17 = auStack_c8[0];
      if (0xfff < uVar16) {
        uVar17 = *(uint *)(auStack_c8[0] - 4);
        uVar16 = uStack_b4 + 0x24;
        if (0x1f < (auStack_c8[0] - uVar17) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar16);
    }
    uStack_b8 = 0;
    uStack_b4 = 0xf;
    auStack_c8[0] = auStack_c8[0] & 0xffffff00;
    uStack_8._0_1_ = 3;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_cc) {
      uVar16 = uStack_cc + 1;
      uVar17 = auStack_e0[0];
      if (0xfff < uVar16) {
        uVar17 = *(uint *)(auStack_e0[0] - 4);
        uVar16 = uStack_cc + 0x24;
        if (0x1f < (auStack_e0[0] - uVar17) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar16);
    }
    uStack_d0 = 0;
    uStack_cc = 0xf;
    auStack_e0[0] = auStack_e0[0] & 0xffffff00;
    uStack_8._0_1_ = 2;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_24) {
      uVar17 = uStack_24 + 1;
      ppppuVar15 = appppuStack_38[0];
      if (0xfff < uVar17) {
        ppppuVar15 = (undefined4 ****)appppuStack_38[0][-1];
        uVar17 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)ppppuVar15))) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar15,uVar17);
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    uStack_8._0_1_ = 1;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_54) {
      uVar16 = uStack_54 + 1;
      uVar17 = auStack_68[0];
      if (0xfff < uVar16) {
        uVar17 = *(uint *)(auStack_68[0] - 4);
        uVar16 = uStack_54 + 0x24;
        if (0x1f < (auStack_68[0] - uVar17) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
LAB_00a07054:
      uStack_8._0_1_ = 1;
      FUN_01674ea0(uVar17,uVar16);
    }
  }
  FUN_014c9d60(&iStack_1c,0);
  uStack_8._0_1_ = 9;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (DAT_01d65a40 == '\0') {
    uStack_8._0_1_ = uVar8;
    FUN_014cba60();
    pppppuVar11 = &ppppuStack_50;
    if (0xf < uStack_40._4_4_) {
      pppppuVar11 = (undefined4 *****)ppppuStack_50;
    }
    FUN_014cbbc0(pppppuVar11,(undefined4)uStack_40);
    *(undefined4 *)(iStack_1c + 0xb0) = 0;
    puVar10 = &DAT_01d79f98;
    if (0xf < DAT_01d79fac) {
      puVar10 = DAT_01d79f98;
    }
    puVar12 = &DAT_01d79d70;
    if (0xf < DAT_01d79d84) {
      puVar12 = DAT_01d79d70;
    }
    FUN_014cb8a0(puVar12,DAT_01d79d80,puVar10,DAT_01d79fa8);
    if (*(int *)(iStack_20 + 0x24) == 0) {
      uVar18 = *(undefined8 *)(iStack_20 + 0x30);
    }
    else {
      uVar18 = FUN_00928340();
    }
    puVar12 = (undefined4 *)FUN_01675640(auStack_88,&DAT_018bed48,uVar18);
    puVar10 = puVar12 + 4;
    uStack_8._0_1_ = 0xb;
    if (0xf < (uint)puVar12[5]) {
      puVar12 = (undefined4 *)*puVar12;
    }
    puVar13 = &DAT_01d79ef0;
    if (0xf < DAT_01d79f04) {
      puVar13 = DAT_01d79ef0;
    }
    FUN_014cb8a0(puVar13,DAT_01d79f00,puVar12,*puVar10);
    uStack_8._0_1_ = 9;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 9;
    if (pppuStack_74 < 0x10) goto LAB_00a07289;
    uVar16 = (int)pppuStack_74 + 1;
    uVar17 = auStack_88[0];
    if (0xfff < uVar16) {
      uVar17 = *(uint *)(auStack_88[0] - 4);
      uVar16 = (int)pppuStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar17) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    uVar4 = *(undefined4 *)(param_1 + 0x30);
    uVar5 = *(undefined4 *)(param_1 + 0x34);
    uStack_14 = CONCAT31((int3)((uint)iStack_20 >> 8),*(undefined *)(iStack_20 + 0x8d));
    uStack_58 = 0;
    uStack_54 = 0xf;
    auStack_68[0] = auStack_68[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c3c98,4);
    uStack_8._0_1_ = 10;
    if (*(int *)(iStack_20 + 0x28) != 0) {
      LOCK();
      piVar2 = (int *)(*(int *)(iStack_20 + 0x28) + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    uVar6 = *(undefined4 *)(iStack_20 + 0x24);
    uVar7 = *(undefined4 *)(iStack_20 + 0x28);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    FUN_00a115a0(iStack_1c,piStack_18,auStack_68,&ppppuStack_50,uVar6,uVar7,uStack_14,uVar4,uVar5);
    uStack_8._0_1_ = 9;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 9;
    if (uStack_54 < 0x10) goto LAB_00a07289;
    uVar16 = uStack_54 + 1;
    uVar17 = auStack_68[0];
    if (0xfff < uVar16) {
      uVar17 = *(uint *)(auStack_68[0] - 4);
      uVar16 = uStack_54 + 0x24;
      if (0x1f < (auStack_68[0] - uVar17) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  uStack_8._0_1_ = 9;
  FUN_01674ea0(uVar17,uVar16);
LAB_00a07289:
  uStack_28 = 0;
  uStack_24 = 0xf;
  appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
  FUN_005542c0(&DAT_018bf820,2);
  uStack_8._0_1_ = 0xc;
  pppppuVar11 = appppuStack_38;
  if (0xf < uStack_24) {
    pppppuVar11 = (undefined4 *****)appppuStack_38[0];
  }
  FUN_014cb7a0(pppppuVar11,uStack_28);
  uStack_8._0_1_ = 9;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_24) {
    uVar17 = uStack_24 + 1;
    pppppuVar11 = (undefined4 *****)appppuStack_38[0];
    if (0xfff < uVar17) {
      pppppuVar11 = (undefined4 *****)appppuStack_38[0][-1];
      uVar17 = uStack_24 + 0x24;
      if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)pppppuVar11))) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar11,uVar17);
  }
  if (piStack_6c != (int *)0x0) {
    LOCK();
    piStack_6c[2] = piStack_6c[2] + 1;
    UNLOCK();
  }
  uStack_94 = uStack_70;
  pppuStack_74 = &ppuStack_98;
  ppuStack_98 = std::
                _Func_impl_no_alloc<class_<lambda_2ab7fb679342095f6e35d4e8067a7366>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                ::vftable;
  piStack_90 = piStack_6c;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  iVar14 = FUN_014cb530(pppuStack_74);
  if (pppuStack_74 != (undefined ***)0x0) {
    iVar14 = (*(code *)(*pppuStack_74)[4])(pppuStack_74 != &ppuStack_98);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_18 + 1;
    iVar3 = *piVar2;
    iVar14 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piStack_18 + 2;
      iVar3 = *piVar2;
      iVar14 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar14 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < uStack_40._4_4_) {
    uVar17 = uStack_40._4_4_ + 1;
    pppppuVar11 = (undefined4 *****)ppppuStack_50;
    if (0xfff < uVar17) {
      pppppuVar11 = (undefined4 *****)ppppuStack_50[-1];
      uVar17 = uStack_40._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_50 + (-4 - (int)pppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar14 = FUN_01674ea0(pppppuVar11,uVar17);
  }
  uStack_40 = 0xf00000000;
  ppppuStack_50 = (undefined4 ****)((uint)ppppuStack_50 & 0xffffff00);
  if (piStack_6c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_6c + 2;
    iVar3 = *piVar2;
    iVar14 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar14 = (**(code **)(*piStack_6c + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar14;
}



/* FUNCTION 19820 ; VA 0x00a07430 ; FUN_00a07430 */

int __fastcall FUN_00a07430(uint param_1)

{
  undefined4 ****ppppuVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined uVar7;
  undefined3 uVar8;
  undefined4 *puVar9;
  undefined4 ****ppppuVar10;
  undefined *puVar11;
  undefined **ppuVar12;
  undefined4 uVar13;
  undefined4 *puVar14;
  undefined4 *puVar15;
  int iVar16;
  undefined **ppuVar17;
  uint uVar18;
  uint uVar19;
  undefined8 uVar20;
  int *piVar21;
  undefined auStack_1e8 [4];
  int iStack_1e4;
  undefined auStack_1e0 [80];
  undefined auStack_190 [120];
  uint auStack_118 [4];
  undefined4 uStack_108;
  uint uStack_104;
  uint auStack_100 [4];
  undefined4 uStack_f0;
  uint uStack_ec;
  uint auStack_e8 [4];
  undefined4 uStack_d8;
  uint uStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  uint auStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  undefined **ppuStack_a0;
  undefined4 uStack_9c;
  int *piStack_98;
  uint auStack_90 [4];
  undefined4 uStack_80;
  undefined ***pppuStack_7c;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  undefined4 ***pppuStack_50;
  undefined4 **ppuStack_4c;
  undefined4 **ppuStack_48;
  undefined4 **ppuStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da709;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_20 = param_1;
  if (DAT_01ee6bcc != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee6bcc,"Commit: %s",PTR_s_Place_Changes_01d65cb8);
  }
  puVar9 = (undefined4 *)FUN_016830f0(&uStack_60);
  *(undefined4 *)(param_1 + 0xa0) = *puVar9;
  *(undefined4 *)(param_1 + 0xa4) = puVar9[1];
  FUN_008c0cc0(&uStack_60,param_1);
  uStack_40 = 0xf00000000;
  pppuStack_50 = (undefined4 ***)((uint)pppuStack_50 & 0xffffff00);
  uStack_8._1_3_ = 0;
  uVar8 = uStack_8._1_3_;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if ((DAT_01d658cc < 1) || (DAT_01d65900 < DAT_01d658cc)) {
    cStack_11 = '\0';
    uStack_8._1_3_ = uVar8;
    FUN_0054ef60(param_1 + 0x70);
    ppppuVar10 = (undefined4 ****)FUN_00fb8290(auStack_90);
    uStack_8._0_1_ = 8;
    if (&pppuStack_50 != ppppuVar10) {
      ppppuVar1 = ppppuVar10 + 4;
      if ((undefined4 ***)0xf < ppppuVar10[5]) {
        ppppuVar10 = (undefined4 ****)*ppppuVar10;
      }
      FUN_005542c0(ppppuVar10,*ppppuVar1);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < pppuStack_7c) {
      uVar18 = (int)pppuStack_7c + 1;
      uVar19 = auStack_90[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_90[0] - 4);
        uVar18 = (int)pppuStack_7c + 0x24;
        if (0x1f < (auStack_90[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      goto LAB_00a0789e;
    }
  }
  else {
    cStack_11 = '\x01';
    uStack_68 = 0;
    uStack_64 = 0xf;
    auStack_78[0] = auStack_78[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 2;
    uStack_f0 = 0;
    uStack_ec = 0xf;
    auStack_100[0] = auStack_100[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 3;
    uStack_d8 = 0;
    uStack_d4 = 0xf;
    auStack_e8[0] = auStack_e8[0] & 0xffffff00;
    FUN_005542c0("universe-history-mock/commits/200/place-commits",0x2f);
    uStack_8._0_1_ = 4;
    uStack_c0 = 0;
    uStack_bc = 0xf;
    auStack_d0[0] = auStack_d0[0] & 0xffffff00;
    FUN_005542c0("apis.simulpong.com",0x12);
    uStack_8._0_1_ = 5;
    uStack_a8 = 0;
    uStack_a4 = 0xf;
    auStack_b8[0] = auStack_b8[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c71bc,4);
    uStack_8._0_1_ = 6;
    FUN_0151bcc0(auStack_190,auStack_b8,auStack_d0,auStack_e8,auStack_100,auStack_78);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    ppppuVar10 = (undefined4 ****)FUN_0151bb70(auStack_90);
    if (&pppuStack_50 != ppppuVar10) {
      FUN_005507b0();
      pppuStack_50 = *ppppuVar10;
      ppuStack_4c = ppppuVar10[1];
      ppuStack_48 = ppppuVar10[2];
      ppuStack_44 = ppppuVar10[3];
      uStack_40 = *(undefined8 *)(ppppuVar10 + 4);
      ppppuVar10[4] = (undefined4 ***)0x0;
      ppppuVar10[5] = (undefined4 ***)0xf;
      *(undefined *)ppppuVar10 = 0;
    }
    if (0xf < pppuStack_7c) {
      uVar18 = (int)pppuStack_7c + 1;
      uVar19 = auStack_90[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_90[0] - 4);
        uVar18 = (int)pppuStack_7c + 0x24;
        if (0x1f < (auStack_90[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
    uStack_80 = 0;
    pppuStack_7c = (undefined ***)0xf;
    auStack_90[0] = auStack_90[0] & 0xffffff00;
    FUN_0056d9d0();
    uStack_8._0_1_ = 5;
    if (0xf < uStack_a4) {
      uVar18 = uStack_a4 + 1;
      uVar19 = auStack_b8[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_b8[0] - 4);
        uVar18 = uStack_a4 + 0x24;
        if (0x1f < (auStack_b8[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
    uStack_a8 = 0;
    uStack_a4 = 0xf;
    auStack_b8[0] = auStack_b8[0] & 0xffffff00;
    uStack_8._0_1_ = 4;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_bc) {
      uVar18 = uStack_bc + 1;
      uVar19 = auStack_d0[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_d0[0] - 4);
        uVar18 = uStack_bc + 0x24;
        if (0x1f < (auStack_d0[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
    uStack_c0 = 0;
    uStack_bc = 0xf;
    auStack_d0[0] = auStack_d0[0] & 0xffffff00;
    uStack_8._0_1_ = 3;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_d4) {
      uVar18 = uStack_d4 + 1;
      uVar19 = auStack_e8[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_e8[0] - 4);
        uVar18 = uStack_d4 + 0x24;
        if (0x1f < (auStack_e8[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
    uStack_d8 = 0;
    uStack_d4 = 0xf;
    auStack_e8[0] = auStack_e8[0] & 0xffffff00;
    uStack_8._0_1_ = 2;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_ec) {
      uVar18 = uStack_ec + 1;
      uVar19 = auStack_100[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_100[0] - 4);
        uVar18 = uStack_ec + 0x24;
        if (0x1f < (auStack_100[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
    uStack_f0 = 0;
    uStack_ec = 0xf;
    auStack_100[0] = auStack_100[0] & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_64) {
      uVar18 = uStack_64 + 1;
      uVar19 = auStack_78[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_78[0] - 4);
        uVar18 = uStack_64 + 0x24;
        if (0x1f < (auStack_78[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
LAB_00a0789e:
      FUN_01674ea0(uVar19,uVar18);
    }
  }
  puVar11 = (undefined *)FUN_01674e20(0x18);
  if (puVar11 == (undefined *)0x0) {
    puVar11 = (undefined *)0x0;
    iStack_18 = 0;
  }
  else {
    *puVar11 = 0;
    iStack_18 = 0xb;
    ppuVar12 = (undefined **)
               FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_18);
    ppuVar17 = ppuVar12 + -1;
    if (ppuVar12 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar17 = ppuVar12;
    }
    *(undefined **)(puVar11 + 4) = *ppuVar17;
    *(undefined4 *)(puVar11 + 8) = 0;
    *(undefined4 *)(puVar11 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar11 + 0x10) = 0;
    *(undefined4 *)(puVar11 + 0x14) = 0;
  }
  uStack_38 = 0;
  piStack_34 = (int *)0x0;
  FUN_005c1af0(puVar11,iStack_18);
  uStack_8._0_1_ = 9;
  puVar9 = (undefined4 *)FUN_01674e20(0xc);
  if (puVar9 == (undefined4 *)0x0) {
    puVar9 = (undefined4 *)0x0;
  }
  else {
    *puVar9 = 0;
    puVar9[1] = 0;
    puVar9[2] = 0;
  }
  iStack_30 = 0;
  piStack_2c = (int *)0x0;
  FUN_006047e0(puVar9,iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  puVar11 = (undefined *)FUN_01674e20(0x18);
  if (puVar11 == (undefined *)0x0) {
    puVar11 = (undefined *)0x0;
    iStack_18 = 0;
  }
  else {
    *puVar11 = 0;
    iStack_18 = 0xb;
    ppuVar12 = (undefined **)
               FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_18);
    ppuVar17 = ppuVar12 + -1;
    if (ppuVar12 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar17 = ppuVar12;
    }
    *(undefined **)(puVar11 + 4) = *ppuVar17;
    *(undefined4 *)(puVar11 + 8) = 0;
    *(undefined4 *)(puVar11 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar11 + 0x10) = 0;
    *(undefined4 *)(puVar11 + 0x14) = 0;
  }
  uStack_58 = 0;
  piStack_54 = (int *)0x0;
  FUN_005c1af0(puVar11,iStack_18);
  uStack_8._0_1_ = 0xb;
  if (cStack_11 == '\0') {
    piVar21 = *(int **)(*(int *)(param_1 + 0x1c) + 0x43c);
    iStack_1c = *piVar21 - (int)piVar21;
    iStack_18 = piVar21[1] - (int)piVar21;
  }
  else {
    iStack_1c = 200;
    iStack_18 = 0;
  }
  piVar21 = &iStack_1c;
  FUN_005c4c00(&DAT_01d65a98);
  FUN_00632bc0(piVar21);
  iVar16 = param_1 + 0x88;
  FUN_005c4c00(&DAT_01d65c60);
  FUN_005ed510(iVar16);
  FUN_005e4d60(&uStack_58);
  iVar16 = iStack_30;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (*(int *)(iStack_30 + 8) == *(int *)(iStack_30 + 4)) {
    FUN_005ca4f0(*(int *)(iStack_30 + 4),auStack_1e8);
  }
  else {
    FUN_005caaf0(iStack_30);
    *(int *)(iVar16 + 4) = *(int *)(iVar16 + 4) + 0xd0;
  }
  uStack_8._0_1_ = 0xd;
  if (iStack_1e4 != 0) {
    (**(code **)(iStack_1e4 + 8))(auStack_1e0);
  }
  piVar21 = &iStack_30;
  uStack_8._0_1_ = 0xb;
  if (DAT_01d65a48 == '\0') {
    puVar11 = &DAT_01d65b58;
  }
  else {
    puVar11 = &DAT_01d65b70;
  }
  FUN_005c4c00(puVar11);
  FUN_00a03440(piVar21);
  uStack_108 = 0;
  uStack_104 = 0xf;
  auStack_118[0] = auStack_118[0] & 0xffffff00;
  uStack_8._0_1_ = 0xe;
  FUN_005e4d60(&uStack_38);
  uStack_8._0_1_ = 0xf;
  FUN_0098fc00(auStack_1e8,auStack_118,1);
  uStack_8._0_1_ = 0x10;
  if (iStack_1e4 != 0) {
    (**(code **)(iStack_1e4 + 8))(auStack_1e0);
  }
  uStack_8._0_1_ = 0xe;
  uVar13 = FUN_014c9d60(&iStack_28,0);
  uStack_8._0_1_ = 0x11;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x11;
  if (DAT_01d65a40 == '\0') {
    uStack_8._0_1_ = uVar7;
    FUN_014cba60();
    ppppuVar10 = &pppuStack_50;
    if (0xf < uStack_40._4_4_) {
      ppppuVar10 = (undefined4 ****)pppuStack_50;
    }
    FUN_014cbbc0(ppppuVar10,(undefined4)uStack_40);
    *(undefined4 *)(iStack_28 + 0xb0) = 0;
    puVar9 = &DAT_01d79f98;
    if (0xf < DAT_01d79fac) {
      puVar9 = DAT_01d79f98;
    }
    puVar14 = &DAT_01d79d70;
    if (0xf < DAT_01d79d84) {
      puVar14 = DAT_01d79d70;
    }
    FUN_014cb8a0(puVar14,DAT_01d79d80,puVar9,DAT_01d79fa8);
    uVar20 = FUN_00928340();
    puVar14 = (undefined4 *)FUN_01675640(auStack_90,&DAT_018bed48,uVar20);
    puVar9 = puVar14 + 4;
    uStack_8._0_1_ = 0x13;
    if (0xf < (uint)puVar14[5]) {
      puVar14 = (undefined4 *)*puVar14;
    }
    puVar15 = &DAT_01d79ef0;
    if (0xf < DAT_01d79f04) {
      puVar15 = DAT_01d79ef0;
    }
    FUN_014cb8a0(puVar15,DAT_01d79f00,puVar14,*puVar9);
    uStack_8._0_1_ = 0x11;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x11;
    if (0xf < pppuStack_7c) {
      uVar18 = (int)pppuStack_7c + 1;
      uVar19 = auStack_90[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_90[0] - 4);
        uVar18 = (int)pppuStack_7c + 0x24;
        if (0x1f < (auStack_90[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      goto LAB_00a07d58;
    }
  }
  else {
    uVar4 = *(undefined4 *)(param_1 + 0x30);
    iStack_18 = CONCAT31((int3)((uint)uVar13 >> 8),*(undefined *)(uStack_20 + 0x8d));
    uVar13 = *(undefined4 *)(uStack_20 + 0x34);
    uStack_68 = 0;
    uStack_64 = 0xf;
    auStack_78[0] = auStack_78[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c3c98,4);
    uStack_8._0_1_ = 0x12;
    if (*(int *)(uStack_20 + 0x28) != 0) {
      LOCK();
      piVar21 = (int *)(*(int *)(uStack_20 + 0x28) + 4);
      *piVar21 = *piVar21 + 1;
      UNLOCK();
    }
    uVar5 = *(undefined4 *)(uStack_20 + 0x24);
    uVar6 = *(undefined4 *)(uStack_20 + 0x28);
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    FUN_00a115a0(iStack_28,piStack_24,auStack_78,&pppuStack_50,uVar5,uVar6,iStack_18,uVar4,uVar13);
    uStack_8._0_1_ = 0x11;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x11;
    if (0xf < uStack_64) {
      uVar18 = uStack_64 + 1;
      uVar19 = auStack_78[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_78[0] - 4);
        uVar18 = uStack_64 + 0x24;
        if (0x1f < (auStack_78[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
LAB_00a07d58:
      uStack_8._0_1_ = 0x11;
      FUN_01674ea0(uVar19,uVar18);
    }
  }
  if (cStack_11 == '\0') {
    uStack_20 = CONCAT31(uStack_20._1_3_,1);
    if (DAT_01d65a38 != '\0') goto LAB_00a07d79;
  }
  uStack_20 = uStack_20 & 0xffffff00;
LAB_00a07d79:
  FUN_014cb780(auStack_118,uStack_20);
  if (piStack_5c != (int *)0x0) {
    LOCK();
    piStack_5c[2] = piStack_5c[2] + 1;
    UNLOCK();
  }
  uStack_9c = uStack_60;
  pppuStack_7c = &ppuStack_a0;
  ppuStack_a0 = std::
                _Func_impl_no_alloc<class_<lambda_688a2941277874b65c1a87ae0b80497f>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                ::vftable;
  piStack_98 = piStack_5c;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  iVar16 = FUN_014cb530(pppuStack_7c);
  if (pppuStack_7c != (undefined ***)0x0) {
    iVar16 = (*(code *)(*pppuStack_7c)[4])(pppuStack_7c != &ppuStack_a0);
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar21 = piStack_24 + 1;
    iVar3 = *piVar21;
    iVar16 = *piVar21;
    *piVar21 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar21 = piStack_24 + 2;
      iVar3 = *piVar21;
      iVar16 = *piVar21;
      *piVar21 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar16 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (0xf < uStack_104) {
    uVar18 = uStack_104 + 1;
    uVar19 = auStack_118[0];
    if (0xfff < uVar18) {
      uVar19 = *(uint *)(auStack_118[0] - 4);
      uVar18 = uStack_104 + 0x24;
      if (0x1f < (auStack_118[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar16 = FUN_01674ea0(uVar19,uVar18);
  }
  piVar21 = piStack_54;
  uStack_108 = 0;
  uStack_104 = 0xf;
  auStack_118[0] = auStack_118[0] & 0xffffff00;
  if (piStack_54 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_54 + 1;
    iVar3 = *piVar2;
    iVar16 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_54)();
      LOCK();
      piVar2 = piVar21 + 2;
      iVar3 = *piVar2;
      iVar16 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar16 = (**(code **)(*piVar21 + 4))();
      }
    }
  }
  piVar21 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_2c + 1;
    iVar3 = *piVar2;
    iVar16 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar2 = piVar21 + 2;
      iVar3 = *piVar2;
      iVar16 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar16 = (**(code **)(*piVar21 + 4))();
      }
    }
  }
  piVar21 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_34 + 1;
    iVar3 = *piVar2;
    iVar16 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar2 = piVar21 + 2;
      iVar3 = *piVar2;
      iVar16 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar16 = (**(code **)(*piVar21 + 4))();
      }
    }
  }
  if (0xf < uStack_40._4_4_) {
    uVar19 = uStack_40._4_4_ + 1;
    ppppuVar10 = (undefined4 ****)pppuStack_50;
    if (0xfff < uVar19) {
      ppppuVar10 = (undefined4 ****)pppuStack_50[-1];
      uVar19 = uStack_40._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_50 + (-4 - (int)ppppuVar10))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar16 = FUN_01674ea0(ppppuVar10,uVar19);
  }
  uStack_40 = 0xf00000000;
  pppuStack_50 = (undefined4 ***)((uint)pppuStack_50 & 0xffffff00);
  if (piStack_5c != (int *)0x0) {
    LOCK();
    piVar21 = piStack_5c + 2;
    iVar3 = *piVar21;
    *piVar21 = *piVar21 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      iVar16 = (**(code **)(*piStack_5c + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar16;
}



/* FUNCTION 19821 ; VA 0x00a07f70 ; FUN_00a07f70 */

void __fastcall FUN_00a07f70(int param_1)

{
  int iVar1;
  undefined uVar2;
  
  iVar1 = FUN_009effc0(-(uint)(*(int *)(param_1 + 0x1c) != 0) & *(int *)(param_1 + 0x1c) + 0xcU);
  if (iVar1 != 0) {
    FUN_00c2d990(0,0);
    uVar2 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    FUN_00c2d9d0(uVar2);
    FUN_00c2da90(0);
  }
  return;
}



/* FUNCTION 19822 ; VA 0x00a07ff0 ; FUN_00a07ff0 */

void __fastcall FUN_00a07ff0(int param_1)

{
  int *piVar1;
  undefined uVar2;
  undefined4 *puVar3;
  int *piVar4;
  char cVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  double *pdVar10;
  char *pcVar11;
  char *pcVar12;
  uint uVar13;
  uint uVar14;
  undefined8 uVar15;
  longlong lVar16;
  int aiStack_f4 [6];
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined1 *puStack_d4;
  int iStack_d0;
  undefined uStack_cc;
  undefined4 uStack_c8;
  uint *puStack_c4;
  undefined8 uStack_c0;
  int **ppiStack_b8;
  char acStack_a0 [4];
  undefined4 uStack_9c;
  uint auStack_98 [4];
  undefined4 uStack_88;
  uint uStack_84;
  uint auStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  int *piStack_68;
  int *piStack_64;
  undefined auStack_60 [8];
  undefined4 uStack_58;
  int *piStack_54;
  undefined auStack_50 [8];
  int iStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da79f;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if (DAT_01ee6bcc != 0) {
    ppiStack_b8 = (int **)PTR_s_Save_Place_01d65cb4;
    uStack_c0 = (double)CONCAT44("Commit: %s",(uint)DAT_01ee6bcc);
    puStack_c4 = (uint *)0xa08038;
    ExceptionList = &pvStack_10;
    FUN_016774b0();
  }
  if ((DAT_01d65a40 != '\0') && (*(char *)(param_1 + 0x8d) == '\0')) {
    ppiStack_b8 = (int **)0xa08052;
    FUN_00a07430();
    ExceptionList = pvStack_10;
    return;
  }
  ppiStack_b8 = &piStack_68;
  uStack_c0 = (double)CONCAT44(0xa0806c,(undefined4)uStack_c0);
  puVar6 = (undefined4 *)FUN_016830f0();
  *(undefined4 *)(param_1 + 0xa0) = *puVar6;
  *(undefined4 *)(param_1 + 0xa4) = puVar6[1];
  puVar6 = *(undefined4 **)(param_1 + 0x3c);
  iVar7 = iStack_1c;
  for (puVar3 = (undefined4 *)*puVar6; iStack_1c = iVar7, puVar3 != puVar6;
      puVar3 = (undefined4 *)*puVar3) {
    ppiStack_b8 = (int **)puVar3[8];
    uStack_c0 = (double)CONCAT44(0xa08098,(undefined4)uStack_c0);
    iVar7 = FUN_008f7870();
    if (iVar7 == 0) {
      ppiStack_b8 = (int **)0x1;
      goto LAB_00a08aaa;
    }
    iVar7 = iStack_1c;
  }
  ppiStack_b8 = (int **)(-(uint)(*(int *)(iVar7 + 0x1c) != 0) & *(int *)(iVar7 + 0x1c) + 0xcU);
  uStack_c0 = (double)CONCAT44(0xa080ba,(undefined4)uStack_c0);
  iStack_48 = FUN_009effc0();
  if (iStack_48 == 0) {
    if (DAT_01d84e8e != 0) {
      ppiStack_b8 = (int **)PTR_s_Save_Place_01d65cb4;
      uStack_c0 = (double)CONCAT44("Commit Failure: %s - no StudioData available",(uint)DAT_01d84e8e
                                  );
      puStack_c4 = (uint *)0xa080e5;
      FUN_016774b0();
    }
    if (DAT_01ee5c38 != 0) {
      if (*(int *)(iVar7 + 0x24) == 0) {
        pcVar12 = "someone";
      }
      else {
        pcVar12 = *(char **)(*(int *)(iVar7 + 0x24) + 0x28);
        if (0xf < *(uint *)(pcVar12 + 0x14)) {
          pcVar12 = *(char **)pcVar12;
        }
      }
      uStack_70 = 0;
      uStack_6c = 0xf;
      auStack_80[0] = auStack_80[0] & 0xffffff00;
      pcVar11 = pcVar12;
      do {
        cVar5 = *pcVar11;
        pcVar11 = pcVar11 + 1;
      } while (cVar5 != '\0');
      ppiStack_b8 = (int **)((int)pcVar11 - (int)(pcVar12 + 1));
      uStack_c0 = (double)CONCAT44(pcVar12,0xa08143);
      FUN_005542c0();
      ppiStack_b8 = (int **)0x1;
      uStack_8 = 0;
      uStack_dc = 0;
      piStack_24 = aiStack_f4;
      FUN_0054ef60(auStack_80);
      FUN_00a02b30();
      uStack_dc = 0xa08175;
      FUN_0090ca30();
      uStack_8 = 0xffffffff;
      if (0xf < uStack_6c) {
        ppiStack_b8 = (int **)(uStack_6c + 1);
        uVar13 = auStack_80[0];
        if (0xfff < ppiStack_b8) {
          uVar13 = *(uint *)(auStack_80[0] - 4);
          ppiStack_b8 = (int **)(uStack_6c + 0x24);
          if (0x1f < (auStack_80[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
            ppiStack_b8 = (int **)0xa08ac5;
            FUN_017167a3();
          }
        }
        uStack_c0 = (double)CONCAT44(uVar13,0xa081ad);
        FUN_01674ea0();
      }
    }
  }
  else {
    puVar6 = *(undefined4 **)(iVar7 + 0x3c);
    uVar14 = 0;
    iVar7 = iStack_1c;
    uVar13 = uStack_14;
    for (puVar3 = (undefined4 *)*puVar6; uStack_14 = uVar14, iStack_1c = iVar7, puVar3 != puVar6;
        puVar3 = (undefined4 *)*puVar3) {
      if (puVar3[8] == 0) {
LAB_00a08216:
        uVar13 = uStack_14 | 2;
        piStack_24 = (int *)0x0;
        puVar9 = &uStack_28;
        piStack_18 = (int *)0x0;
      }
      else {
        iVar7 = *(int *)(puVar3[8] + 0xc);
        ppiStack_b8 = (int **)0xa081d6;
        uStack_14 = uVar13;
        iVar8 = FUN_00b73ae0();
        if ((uint)*(ushort *)(iVar8 + 0x1da) <
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) goto LAB_00a08216;
        piStack_30 = (int *)puVar3[9];
        piStack_18 = (int *)puVar3[8];
        if (piStack_30 != (int *)0x0) {
          LOCK();
          piStack_30[1] = piStack_30[1] + 1;
          UNLOCK();
          piStack_30 = (int *)puVar3[9];
        }
        uVar13 = uStack_14 | 1;
        puVar9 = &uStack_34;
      }
      uVar14 = uVar13 | 4;
      piStack_20 = (int *)puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      uStack_14 = uVar14;
      if (((uVar13 & 2) != 0) &&
         (uVar14 = uVar13 & 0xfffffffd | 4, uStack_14 = uVar14, piStack_24 != (int *)0x0)) {
        LOCK();
        iVar7 = piStack_24[1] + -1;
        piStack_24[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppiStack_b8 = (int **)0xa0826d;
          (**(code **)*piStack_24)();
          LOCK();
          iVar7 = piStack_24[2] + -1;
          piStack_24[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa0827f;
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      if (((uVar14 & 1) != 0) &&
         (uVar14 = uVar14 & 0xfffffffe, uStack_14 = uVar14, piStack_30 != (int *)0x0)) {
        LOCK();
        iVar7 = piStack_30[1] + -1;
        piStack_30[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppiStack_b8 = (int **)0xa0829f;
          (**(code **)*piStack_30)();
          LOCK();
          iVar7 = piStack_30[2] + -1;
          piStack_30[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa082b1;
            (**(code **)(*piStack_30 + 4))();
          }
        }
      }
      uStack_8 = 1;
      if (piStack_18 == (int *)0x0) {
        if (puVar3[8] == 0) {
LAB_00a08369:
          uStack_14 = uVar14;
          piStack_38 = (int *)0x0;
          puVar9 = &uStack_3c;
          piStack_18 = (int *)0x0;
          uVar14 = 0x30;
        }
        else {
          iVar7 = *(int *)(puVar3[8] + 0xc);
          ppiStack_b8 = (int **)0xa08327;
          iVar8 = FUN_009ec190();
          uVar14 = uStack_14;
          if ((uint)*(ushort *)(iVar8 + 0x1da) <
              (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8))
          goto LAB_00a08369;
          piStack_40 = (int *)puVar3[9];
          piStack_18 = (int *)puVar3[8];
          if (piStack_40 != (int *)0x0) {
            LOCK();
            piStack_40[1] = piStack_40[1] + 1;
            UNLOCK();
            piStack_40 = (int *)puVar3[9];
          }
          uVar14 = 0x28;
          puVar9 = &uStack_44;
        }
        uVar14 = uStack_14 | uVar14;
        piStack_64 = (int *)puVar9[1];
        piStack_2c = piStack_64;
        *puVar9 = 0;
        puVar9[1] = 0;
        piStack_68 = piStack_18;
        uStack_14 = uVar14;
        if (((uVar14 & 0x10) != 0) &&
           (uVar14 = uVar14 & 0xffffffef, uStack_14 = uVar14, piStack_38 != (int *)0x0)) {
          LOCK();
          iVar7 = piStack_38[1] + -1;
          piStack_38[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa083bb;
            (**(code **)*piStack_38)();
            LOCK();
            iVar7 = piStack_38[2] + -1;
            piStack_38[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppiStack_b8 = (int **)0xa083cd;
              (**(code **)(*piStack_38 + 4))();
            }
          }
        }
        if (((uVar14 & 8) != 0) &&
           (uVar14 = uVar14 & 0xfffffff7, uStack_14 = uVar14, piStack_40 != (int *)0x0)) {
          LOCK();
          iVar7 = piStack_40[1] + -1;
          piStack_40[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa083ed;
            (**(code **)*piStack_40)();
            LOCK();
            iVar7 = piStack_40[2] + -1;
            piStack_40[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppiStack_b8 = (int **)0xa083ff;
              (**(code **)(*piStack_40 + 4))();
            }
          }
        }
        uStack_8._0_1_ = 3;
        if (piStack_18 != (int *)0x0) {
          ppiStack_b8 = (int **)&uStack_58;
          uStack_c0 = (double)CONCAT44(0xa08415,(undefined4)uStack_c0);
          FUN_009ed300();
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          ppiStack_b8 = (int **)0xa08420;
          puVar9 = (undefined4 *)FUN_00a33fa0();
          if (puVar3 + 10 != puVar9) {
            ppiStack_b8 = (int **)puVar9[4];
            if (0xf < (uint)puVar9[5]) {
              puVar9 = (undefined4 *)*puVar9;
            }
            uStack_c0 = (double)CONCAT44(puVar9,0xa08439);
            FUN_005542c0();
          }
          uStack_8._0_1_ = 3;
          ppiStack_b8 = (int **)0xa08445;
          FUN_0056e380();
          ppiStack_b8 = (int **)0xa0844d;
          FUN_0056e380();
          ppiStack_b8 = (int **)(puVar3 + 0x10);
          uStack_c0 = (double)CONCAT44(auStack_60,0xa0845a);
          ppiStack_b8 = (int **)FUN_00886c00();
          uStack_8._0_1_ = 5;
          uStack_c0 = (double)CONCAT44(0xa0846a,(undefined4)uStack_c0);
          FUN_009ed830();
          ppiStack_b8 = (int **)0xa08472;
          FUN_0056e380();
          ppiStack_b8 = (int **)0xa0847a;
          FUN_0056e380();
        }
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar7 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa0848f;
            (**(code **)*piStack_2c)();
            LOCK();
            iVar7 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppiStack_b8 = (int **)0xa084a1;
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
      }
      else {
        ppiStack_b8 = (int **)0xa082c6;
        FUN_00b74d90();
        ppiStack_b8 = (int **)0xa082cd;
        puVar9 = (undefined4 *)FUN_00a33fa0();
        if (puVar3 + 10 != puVar9) {
          ppiStack_b8 = (int **)puVar9[4];
          if (0xf < (uint)puVar9[5]) {
            puVar9 = (undefined4 *)*puVar9;
          }
          uStack_c0 = (double)CONCAT44(puVar9,0xa082e6);
          FUN_005542c0();
        }
        ppiStack_b8 = (int **)(puVar3 + 0x10);
        uStack_c0 = (double)CONCAT44(auStack_50,0xa082f3);
        ppiStack_b8 = (int **)FUN_00886c00();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        uStack_c0 = (double)CONCAT44(0xa08303,(undefined4)uStack_c0);
        FUN_00b75530();
        ppiStack_b8 = (int **)0xa0830b;
        FUN_0056e380();
        ppiStack_b8 = (int **)0xa08313;
        FUN_0056e380();
      }
      uStack_8 = 0xffffffff;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar7 = piStack_20[1] + -1;
        piStack_20[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppiStack_b8 = (int **)0xa084bd;
          (**(code **)*piStack_20)();
          LOCK();
          iVar7 = piStack_20[2] + -1;
          piStack_20[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa084cf;
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
      iVar7 = iStack_1c;
      uVar13 = uStack_14;
    }
    ppiStack_b8 = (int **)0xa084e4;
    uStack_14 = uVar13;
    uVar15 = FUN_00928340();
    ppiStack_b8 = (int **)((ulonglong)uVar15 >> 0x20);
    uStack_c0 = (double)CONCAT44((int)uVar15,0xa084f0);
    FUN_00c2d990();
    iStack_d0 = iVar7 + 0x70;
    puStack_d4 = (undefined1 *)0xa084fe;
    FUN_0054ef60();
    iStack_d0 = 0xa08505;
    FUN_00c2d9d0();
    acStack_a0[0] = '\0';
    uStack_8 = 6;
    ppiStack_b8 = (int **)0xa0851e;
    lVar16 = FUN_00928340();
    ppiStack_b8 = (int **)((ulonglong)lVar16 >> 0x20);
    uStack_c0 = (double)(lVar16 << 0x20);
    puStack_c4 = (uint *)acStack_a0;
    uStack_c8 = 0xa08530;
    cVar5 = FUN_005e8250();
    if ((cVar5 != '\0') && (acStack_a0[0] != '\0')) {
      ppiStack_b8 = (int **)uStack_9c;
      *(undefined4 *)(iVar7 + 0x88) = uStack_9c;
      uStack_c0 = (double)CONCAT44(0xa08559,(undefined4)uStack_c0);
      FUN_00c2da90();
      ppiStack_b8 = (int **)0xa08561;
      FUN_006eccd0();
      ppiStack_b8 = &piStack_68;
      uStack_c0 = (double)CONCAT44(0xa0856a,(undefined4)uStack_c0);
      pdVar10 = (double *)FUN_016830f0();
      iVar8 = (int)((*pdVar10 - *(double *)(iVar7 + 0xa0)) * DAT_018c0d70);
      *(int *)(iVar7 + 0xb8) = iVar8;
      if (DAT_01d65a40 == '\0') {
        ppiStack_b8 = (int **)0x37;
        uStack_88 = 0;
        uStack_84 = 0xf;
        auStack_98[0] = auStack_98[0] & 0xffffff00;
        uStack_c0 = 4.65465515409955e-301;
        FUN_005542c0();
        puStack_c4 = auStack_98;
        uStack_c0 = (double)iVar8;
        ppiStack_b8 = (int **)0x0;
        uStack_8._0_1_ = 0xd;
        uStack_c8 = 0xa0867f;
        FUN_00878cf0();
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        if (0xf < uStack_84) {
          ppiStack_b8 = (int **)(uStack_84 + 1);
          uVar13 = auStack_98[0];
          if (0xfff < ppiStack_b8) {
            uVar13 = *(uint *)(auStack_98[0] - 4);
            ppiStack_b8 = (int **)(uStack_84 + 0x24);
            if (0x1f < (auStack_98[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
              ppiStack_b8 = (int **)0xa08acf;
              FUN_017167a3();
            }
          }
          uStack_c0 = (double)CONCAT44(uVar13,0xa086ba);
          FUN_01674ea0();
        }
      }
      else {
        uVar2 = *(undefined *)(iVar7 + 0x8d);
        ppiStack_b8 = (int **)0x10;
        uStack_70 = 0;
        uStack_6c = 0xf;
        auStack_80[0] = auStack_80[0] & 0xffffff00;
        uStack_c0 = 4.6545839517359464e-301;
        FUN_005542c0();
        puStack_c4 = auStack_80;
        uStack_c0 = (double)iVar8;
        uStack_8._0_1_ = 0xc;
        uStack_c8 = 0xa085dd;
        ppiStack_b8 = (int **)CONCAT31((int3)((uint)iVar7 >> 8),uVar2);
        FUN_00a11480();
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        if (0xf < uStack_6c) {
          ppiStack_b8 = (int **)(uStack_6c + 1);
          uVar13 = auStack_80[0];
          if (0xfff < ppiStack_b8) {
            uVar13 = *(uint *)(auStack_80[0] - 4);
            ppiStack_b8 = (int **)(uStack_6c + 0x24);
            if (0x1f < (auStack_80[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
              ppiStack_b8 = (int **)0xa08aca;
              FUN_017167a3();
            }
          }
          uStack_c0 = (double)CONCAT44(uVar13,0xa08615);
          FUN_01674ea0();
        }
      }
      ppiStack_b8 = (int **)0xa08622;
      FUN_00a07430();
      ExceptionList = pvStack_10;
      return;
    }
    puVar6 = *(undefined4 **)(iVar7 + 0x3c);
    for (puVar3 = (undefined4 *)*puVar6; puVar3 != puVar6; puVar3 = (undefined4 *)*puVar3) {
      if (puVar3[8] == 0) {
LAB_00a0871d:
        piStack_40 = (int *)0x0;
        puVar9 = &uStack_44;
        piStack_20 = (int *)&DAT_00000180;
        piStack_18 = (int *)0x0;
      }
      else {
        iVar7 = *(int *)(puVar3[8] + 0xc);
        ppiStack_b8 = (int **)0xa086df;
        iVar8 = FUN_00b73ae0();
        if ((uint)*(ushort *)(iVar8 + 0x1da) <
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) goto LAB_00a0871d;
        piStack_38 = (int *)puVar3[9];
        piStack_18 = (int *)puVar3[8];
        if (piStack_38 != (int *)0x0) {
          LOCK();
          piStack_38[1] = piStack_38[1] + 1;
          UNLOCK();
          piStack_38 = (int *)puVar3[9];
        }
        puVar9 = &uStack_3c;
        piStack_20 = (int *)0x140;
      }
      uVar13 = uStack_14 | (uint)piStack_20;
      piStack_64 = (int *)puVar9[1];
      piStack_24 = piStack_64;
      *puVar9 = 0;
      puVar9[1] = 0;
      piStack_68 = piStack_18;
      uStack_14 = uVar13;
      if (((char)uVar13 < '\0') &&
         (uVar13 = uVar13 & 0xffffff7f, uStack_14 = uVar13, piStack_40 != (int *)0x0)) {
        LOCK();
        iVar7 = piStack_40[1] + -1;
        piStack_40[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppiStack_b8 = (int **)0xa08777;
          (**(code **)*piStack_40)();
          LOCK();
          iVar7 = piStack_40[2] + -1;
          piStack_40[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa08789;
            (**(code **)(*piStack_40 + 4))();
          }
        }
      }
      if (((uVar13 & 0x40) != 0) &&
         (uVar13 = uVar13 & 0xffffffbf, uStack_14 = uVar13, piStack_38 != (int *)0x0)) {
        LOCK();
        iVar7 = piStack_38[1] + -1;
        piStack_38[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppiStack_b8 = (int **)0xa087a9;
          (**(code **)*piStack_38)();
          LOCK();
          iVar7 = piStack_38[2] + -1;
          piStack_38[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa087bb;
            (**(code **)(*piStack_38 + 4))();
          }
        }
      }
      uStack_8._0_1_ = 7;
      if (piStack_18 == (int *)0x0) {
        if (puVar3[8] == 0) {
LAB_00a0884a:
          uStack_14 = uVar13;
          piStack_30 = (int *)0x0;
          puVar9 = &uStack_34;
          piStack_20 = (int *)0xc00;
          piStack_2c = (int *)0x0;
        }
        else {
          iVar7 = *(int *)(puVar3[8] + 0xc);
          ppiStack_b8 = (int **)0xa08806;
          iVar8 = FUN_009ec190();
          uVar13 = uStack_14;
          if ((uint)*(ushort *)(iVar8 + 0x1da) <
              (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8))
          goto LAB_00a0884a;
          piStack_54 = (int *)puVar3[9];
          piStack_2c = (int *)puVar3[8];
          if (piStack_54 != (int *)0x0) {
            LOCK();
            piStack_54[1] = piStack_54[1] + 1;
            UNLOCK();
            piStack_54 = (int *)puVar3[9];
          }
          puVar9 = &uStack_58;
          piStack_20 = (int *)0xa00;
        }
        uVar13 = uStack_14 | (uint)piStack_20;
        piStack_18 = (int *)puVar9[1];
        *puVar9 = 0;
        puVar9[1] = 0;
        uStack_14 = uVar13;
        if (((uVar13 & 0x400) != 0) &&
           (uVar13 = uVar13 & 0xfffffbff, uStack_14 = uVar13, piStack_30 != (int *)0x0)) {
          LOCK();
          iVar7 = piStack_30[1] + -1;
          piStack_30[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa088ab;
            (**(code **)*piStack_30)();
            LOCK();
            iVar7 = piStack_30[2] + -1;
            piStack_30[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppiStack_b8 = (int **)0xa088bd;
              (**(code **)(*piStack_30 + 4))();
            }
          }
        }
        piVar4 = piStack_54;
        if (((uVar13 & 0x200) != 0) && (uStack_14 = uVar13 & 0xfffffdff, piStack_54 != (int *)0x0))
        {
          LOCK();
          iVar7 = piStack_54[1] + -1;
          piStack_54[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa088e5;
            (**(code **)*piStack_54)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar7 = *piVar1 + -1;
            *piVar1 = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppiStack_b8 = (int **)0xa088f6;
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        uStack_8._0_1_ = 9;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 9;
        if (piStack_2c != (int *)0x0) {
          ppiStack_b8 = (int **)(puVar3 + 10);
          uStack_c0 = (double)CONCAT44(auStack_50,0xa0890e);
          ppiStack_b8 = (int **)FUN_00886c00();
          uStack_8._0_1_ = 10;
          uStack_c0 = (double)CONCAT44(0xa0891d,(undefined4)uStack_c0);
          FUN_009ed830();
          ppiStack_b8 = (int **)0xa08925;
          FUN_0056e380();
          ppiStack_b8 = (int **)0xa0892d;
          FUN_0056e380();
          uVar2 = (undefined)uStack_8;
        }
        uStack_8._0_1_ = uVar2;
        piVar4 = piStack_18;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar7 = piStack_18[1] + -1;
          piStack_18[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa08944;
            (**(code **)*piStack_18)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar7 = *piVar1 + -1;
            *piVar1 = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppiStack_b8 = (int **)0xa08955;
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
      }
      else {
        ppiStack_b8 = (int **)(puVar3 + 10);
        uStack_c0 = (double)CONCAT44(auStack_60,0xa087d2);
        ppiStack_b8 = (int **)FUN_00886c00();
        uStack_8._0_1_ = 8;
        uStack_c0 = (double)CONCAT44(0xa087e2,(undefined4)uStack_c0);
        FUN_00b75530();
        ppiStack_b8 = (int **)0xa087ea;
        FUN_0056e380();
        ppiStack_b8 = (int **)0xa087f2;
        FUN_0056e380();
      }
      piVar4 = piStack_24;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar7 = piStack_24[1] + -1;
        piStack_24[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppiStack_b8 = (int **)0xa08970;
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar7 = *piVar1 + -1;
          *piVar1 = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_b8 = (int **)0xa08981;
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar7 = iStack_1c;
    }
    ppiStack_b8 = (int **)0x0;
    uStack_c0 = 5.19805774297671e-317;
    FUN_00c2d990();
    iStack_d0 = 0;
    uStack_c0 = (double)((ulonglong)uStack_c0 & 0xffffffff);
    ppiStack_b8 = (int **)0xf;
    puStack_d4 = &DAT_018bc9b8;
    uStack_cc = 0;
    uStack_d8 = 0xa089bc;
    FUN_005542c0();
    iStack_d0 = 0xa089c4;
    FUN_00c2d9d0();
    if (DAT_01d84e8e != 0) {
      ppiStack_b8 = (int **)PTR_s_Save_Place_01d65cb4;
      uStack_c0 = (double)CONCAT44("Commit Failure: %s - cannot save new place version",
                                   (uint)DAT_01d84e8e);
      puStack_c4 = (uint *)0xa089e1;
      FUN_016774b0();
    }
    if (DAT_01ee5c38 != 0) {
      if (*(int *)(iVar7 + 0x24) == 0) {
        pcVar12 = "someone";
      }
      else {
        pcVar12 = *(char **)(*(int *)(iVar7 + 0x24) + 0x28);
        if (0xf < *(uint *)(pcVar12 + 0x14)) {
          pcVar12 = *(char **)pcVar12;
        }
      }
      uStack_88 = 0;
      uStack_84 = 0xf;
      auStack_98[0] = auStack_98[0] & 0xffffff00;
      pcVar11 = pcVar12;
      do {
        cVar5 = *pcVar11;
        pcVar11 = pcVar11 + 1;
      } while (cVar5 != '\0');
      ppiStack_b8 = (int **)((int)pcVar11 - (int)(pcVar12 + 1));
      uStack_c0 = (double)CONCAT44(pcVar12,0xa08a3d);
      FUN_005542c0();
      ppiStack_b8 = (int **)0x1;
      uStack_8._0_1_ = 0xb;
      uStack_dc = 0;
      piStack_24 = aiStack_f4;
      FUN_0054ef60(auStack_98);
      FUN_00a03310();
      uStack_dc = 0xa08a6f;
      FUN_0090ca30();
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      if (0xf < uStack_84) {
        ppiStack_b8 = (int **)(uStack_84 + 1);
        uVar13 = auStack_98[0];
        if (0xfff < ppiStack_b8) {
          uVar13 = *(uint *)(auStack_98[0] - 4);
          ppiStack_b8 = (int **)(uStack_84 + 0x24);
          if (0x1f < (auStack_98[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
            ppiStack_b8 = (int **)&UNK_00a08ad4;
            FUN_017167a3();
          }
        }
        uStack_c0 = (double)CONCAT44(uVar13,0xa08aa3);
        FUN_01674ea0();
      }
    }
  }
  ppiStack_b8 = (int **)0x0;
LAB_00a08aaa:
  uStack_c0 = (double)CONCAT44(0xa08aaf,(undefined4)uStack_c0);
  FUN_00a11160();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19823 ; VA 0x00a08ae0 ; FUN_00a08ae0 */

void FUN_00a08ae0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x80);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 19824 ; VA 0x00a08b10 ; FUN_00a08b10 */

void __thiscall FUN_00a08b10(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_242501298d2d251cf827e607c47ce812>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 19825 ; VA 0x00a08b50 ; FUN_00a08b50 */

void __thiscall FUN_00a08b50(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_2ab7fb679342095f6e35d4e8067a7366>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 19826 ; VA 0x00a08b90 ; FUN_00a08b90 */

undefined4 * __thiscall FUN_00a08b90(int param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017da7b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_2e98fbd261150ecdb69f7dc9441cf65c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  uStack_8 = 0;
  FUN_0054ef60(param_1 + 0xc);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19827 ; VA 0x00a08c10 ; FUN_00a08c10 */

void __thiscall FUN_00a08c10(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_3582bc2984258734a0a9ce9de1a9d633>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 19828 ; VA 0x00a08c50 ; FUN_00a08c50 */

void __thiscall FUN_00a08c50(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_677418c1100a047d77fc4bbf0eb151ef>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 19829 ; VA 0x00a08c90 ; FUN_00a08c90 */

void __thiscall FUN_00a08c90(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_688a2941277874b65c1a87ae0b80497f>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 19830 ; VA 0x00a08cd0 ; FUN_00a08cd0 */

void __thiscall FUN_00a08cd0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_8504b1d6e35ce6755247acb07cd8948c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  return;
}



/* FUNCTION 19831 ; VA 0x00a08d10 ; FUN_00a08d10 */

void __thiscall FUN_00a08d10(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_d8d005b61aca10da22230ba33a64c55c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 19832 ; VA 0x00a08d50 ; FUN_00a08d50 */

void __thiscall FUN_00a08d50(undefined4 param_1,char param_2)

{
  FUN_005d11a0();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x24);
  }
  return;
}



/* FUNCTION 19833 ; VA 0x00a08d80 ; FUN_00a08d80 */

void __thiscall FUN_00a08d80(int param_1,char param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 8);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x10);
  }
  return;
}



/* FUNCTION 19834 ; VA 0x00a08dc0 ; FUN_00a08dc0 */

void FUN_00a08dc0(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a048a0(*param_1,param_2);
  return;
}



/* FUNCTION 19835 ; VA 0x00a08de0 ; FUN_00a08de0 */

void FUN_00a08de0(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a04ab0(*param_1,param_2);
  return;
}



/* FUNCTION 19836 ; VA 0x00a08e00 ; FUN_00a08e00 */

void FUN_00a08e00(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a04dd0(*param_1,param_2);
  return;
}



/* FUNCTION 19837 ; VA 0x00a08e20 ; FUN_00a08e20 */

void FUN_00a08e20(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a05210(*param_1,param_2);
  return;
}



/* FUNCTION 19838 ; VA 0x00a08e40 ; FUN_00a08e40 */

void FUN_00a08e40(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a054e0(*param_1,param_2);
  return;
}



/* FUNCTION 19839 ; VA 0x00a08e60 ; FUN_00a08e60 */

void FUN_00a08e60(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a05850(*param_1,param_2);
  return;
}



/* FUNCTION 19840 ; VA 0x00a08e80 ; FUN_00a08e80 */

void FUN_00a08e80(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a05b70(*param_1,param_2);
  return;
}



/* FUNCTION 19841 ; VA 0x00a08ea0 ; FUN_00a08ea0 */

void FUN_00a08ea0(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a06450(*param_1,param_2);
  return;
}



/* FUNCTION 19842 ; VA 0x00a08ec0 ; FUN_00a08ec0 */

void __thiscall FUN_00a08ec0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_242501298d2d251cf827e607c47ce812>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 19843 ; VA 0x00a08f00 ; FUN_00a08f00 */

void __thiscall FUN_00a08f00(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_2ab7fb679342095f6e35d4e8067a7366>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 19844 ; VA 0x00a08f40 ; FUN_00a08f40 */

undefined4 * __thiscall FUN_00a08f40(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_2e98fbd261150ecdb69f7dc9441cf65c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  param_2[7] = 0;
  param_2[8] = 0;
  uVar1 = *(undefined4 *)(param_1 + 0x10);
  uVar2 = *(undefined4 *)(param_1 + 0x14);
  uVar3 = *(undefined4 *)(param_1 + 0x18);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = uVar1;
  param_2[5] = uVar2;
  param_2[6] = uVar3;
  *(undefined8 *)(param_2 + 7) = *(undefined8 *)(param_1 + 0x1c);
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  return param_2;
}



/* FUNCTION 19845 ; VA 0x00a08fb0 ; FUN_00a08fb0 */

void __thiscall FUN_00a08fb0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_3582bc2984258734a0a9ce9de1a9d633>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 19846 ; VA 0x00a08ff0 ; FUN_00a08ff0 */

void __thiscall FUN_00a08ff0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_677418c1100a047d77fc4bbf0eb151ef>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 19847 ; VA 0x00a09030 ; FUN_00a09030 */

void __thiscall FUN_00a09030(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_688a2941277874b65c1a87ae0b80497f>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 19848 ; VA 0x00a09070 ; FUN_00a09070 */

void __thiscall FUN_00a09070(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_8504b1d6e35ce6755247acb07cd8948c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  return;
}



/* FUNCTION 19849 ; VA 0x00a090c0 ; FUN_00a090c0 */

void __thiscall FUN_00a090c0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_d8d005b61aca10da22230ba33a64c55c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 19850 ; VA 0x00a09100 ; FUN_00a09100 */

TypeDescriptor * FUN_00a09100(void)

{
  return &<lambda_242501298d2d251cf827e607c47ce812>::RTTI_Type_Descriptor;
}



/* FUNCTION 19851 ; VA 0x00a09110 ; FUN_00a09110 */

TypeDescriptor * FUN_00a09110(void)

{
  return &<lambda_2ab7fb679342095f6e35d4e8067a7366>::RTTI_Type_Descriptor;
}



/* FUNCTION 19852 ; VA 0x00a09120 ; FUN_00a09120 */

TypeDescriptor * FUN_00a09120(void)

{
  return &<lambda_2e98fbd261150ecdb69f7dc9441cf65c>::RTTI_Type_Descriptor;
}



/* FUNCTION 19853 ; VA 0x00a09130 ; FUN_00a09130 */

TypeDescriptor * FUN_00a09130(void)

{
  return &<lambda_3582bc2984258734a0a9ce9de1a9d633>::RTTI_Type_Descriptor;
}



/* FUNCTION 19854 ; VA 0x00a09140 ; FUN_00a09140 */

TypeDescriptor * FUN_00a09140(void)

{
  return &<lambda_677418c1100a047d77fc4bbf0eb151ef>::RTTI_Type_Descriptor;
}



/* FUNCTION 19855 ; VA 0x00a09150 ; FUN_00a09150 */

TypeDescriptor * FUN_00a09150(void)

{
  return &<lambda_688a2941277874b65c1a87ae0b80497f>::RTTI_Type_Descriptor;
}



/* FUNCTION 19856 ; VA 0x00a09160 ; FUN_00a09160 */

TypeDescriptor * FUN_00a09160(void)

{
  return &<lambda_8504b1d6e35ce6755247acb07cd8948c>::RTTI_Type_Descriptor;
}



/* FUNCTION 19857 ; VA 0x00a09170 ; FUN_00a09170 */

TypeDescriptor * FUN_00a09170(void)

{
  return &<lambda_d8d005b61aca10da22230ba33a64c55c>::RTTI_Type_Descriptor;
}



/* FUNCTION 19858 ; VA 0x00a09180 ; FUN_00a09180 */

int __fastcall FUN_00a09180(int param_1)

{
  undefined4 ****ppppuVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined uVar8;
  undefined3 uVar9;
  undefined4 *puVar10;
  undefined4 ****ppppuVar11;
  undefined *puVar12;
  undefined **ppuVar13;
  int iVar14;
  undefined4 uVar15;
  undefined4 *puVar16;
  undefined4 *puVar17;
  undefined **ppuVar18;
  uint uVar19;
  uint uVar20;
  undefined8 uVar21;
  undefined auStack_1d8 [4];
  int iStack_1d4;
  undefined auStack_1d0 [80];
  undefined auStack_180 [120];
  uint auStack_108 [4];
  undefined4 uStack_f8;
  uint uStack_f4;
  uint auStack_f0 [4];
  undefined4 uStack_e0;
  uint uStack_dc;
  uint auStack_d8 [4];
  undefined4 uStack_c8;
  uint uStack_c4;
  uint auStack_c0 [4];
  undefined4 uStack_b0;
  uint uStack_ac;
  uint auStack_a8 [4];
  undefined4 uStack_98;
  uint uStack_94;
  undefined **ppuStack_90;
  undefined4 uStack_8c;
  int *piStack_88;
  uint auStack_80 [4];
  undefined4 uStack_70;
  undefined ***pppuStack_6c;
  undefined4 uStack_68;
  int *piStack_64;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 ***pppuStack_38;
  undefined4 **ppuStack_34;
  undefined4 **ppuStack_30;
  undefined4 **ppuStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da868;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  if (DAT_01ee6bcc != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee6bcc,"Commit: %s",PTR_s_Create_Commit_01d65934);
  }
  puVar10 = (undefined4 *)FUN_016830f0(&uStack_68);
  *(undefined4 *)(param_1 + 0xa0) = *puVar10;
  *(undefined4 *)(param_1 + 0xa4) = puVar10[1];
  FUN_008c0cc0(&uStack_68,param_1);
  uStack_28 = 0xf00000000;
  pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffffff00);
  uStack_8._1_3_ = 0;
  uVar9 = uStack_8._1_3_;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if ((DAT_01d658cc < 1) || (DAT_01d658d8 < DAT_01d658cc)) {
    uStack_48 = *(undefined4 *)(*(int *)(param_1 + 0x1c) + 0x440);
    uStack_44 = *(undefined4 *)(*(int *)(param_1 + 0x1c) + 0x444);
    uStack_8._1_3_ = uVar9;
    ppppuVar11 = (undefined4 ****)FUN_00fb87d0(auStack_80,*(undefined *)(param_1 + 0x8d));
    uStack_8._0_1_ = 8;
    if (&pppuStack_38 != ppppuVar11) {
      ppppuVar1 = ppppuVar11 + 4;
      if ((undefined4 ***)0xf < ppppuVar11[5]) {
        ppppuVar11 = (undefined4 ****)*ppppuVar11;
      }
      FUN_005542c0(ppppuVar11,*ppppuVar1);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < pppuStack_6c) {
      uVar19 = (int)pppuStack_6c + 1;
      uVar20 = auStack_80[0];
      if (0xfff < uVar19) {
        uVar20 = *(uint *)(auStack_80[0] - 4);
        uVar19 = (int)pppuStack_6c + 0x24;
        if (0x1f < (auStack_80[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      goto LAB_00a095ed;
    }
  }
  else {
    uStack_48 = 200;
    uStack_44 = 0;
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 2;
    uStack_e0 = 0;
    uStack_dc = 0xf;
    auStack_f0[0] = auStack_f0[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 3;
    uStack_c8 = 0;
    uStack_c4 = 0xf;
    auStack_d8[0] = auStack_d8[0] & 0xffffff00;
    FUN_005542c0("universe-history-mock/commits",0x1d);
    uStack_8._0_1_ = 4;
    uStack_b0 = 0;
    uStack_ac = 0xf;
    auStack_c0[0] = auStack_c0[0] & 0xffffff00;
    FUN_005542c0("apis.simulpong.com",0x12);
    uStack_8._0_1_ = 5;
    uStack_98 = 0;
    uStack_94 = 0xf;
    auStack_a8[0] = auStack_a8[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c71bc,4);
    uStack_8._0_1_ = 6;
    FUN_0151bcc0(auStack_180,auStack_a8,auStack_c0,auStack_d8,auStack_f0,auStack_60);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    ppppuVar11 = (undefined4 ****)FUN_0151bb70(auStack_80);
    if (&pppuStack_38 != ppppuVar11) {
      FUN_005507b0();
      pppuStack_38 = *ppppuVar11;
      ppuStack_34 = ppppuVar11[1];
      ppuStack_30 = ppppuVar11[2];
      ppuStack_2c = ppppuVar11[3];
      uStack_28 = *(undefined8 *)(ppppuVar11 + 4);
      ppppuVar11[4] = (undefined4 ***)0x0;
      ppppuVar11[5] = (undefined4 ***)0xf;
      *(undefined *)ppppuVar11 = 0;
    }
    if (0xf < pppuStack_6c) {
      uVar19 = (int)pppuStack_6c + 1;
      uVar20 = auStack_80[0];
      if (0xfff < uVar19) {
        uVar20 = *(uint *)(auStack_80[0] - 4);
        uVar19 = (int)pppuStack_6c + 0x24;
        if (0x1f < (auStack_80[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar19);
    }
    uStack_70 = 0;
    pppuStack_6c = (undefined ***)0xf;
    auStack_80[0] = auStack_80[0] & 0xffffff00;
    FUN_0056d9d0();
    uStack_8._0_1_ = 5;
    if (0xf < uStack_94) {
      uVar19 = uStack_94 + 1;
      uVar20 = auStack_a8[0];
      if (0xfff < uVar19) {
        uVar20 = *(uint *)(auStack_a8[0] - 4);
        uVar19 = uStack_94 + 0x24;
        if (0x1f < (auStack_a8[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar19);
    }
    uStack_98 = 0;
    uStack_94 = 0xf;
    auStack_a8[0] = auStack_a8[0] & 0xffffff00;
    uStack_8._0_1_ = 4;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_ac) {
      uVar19 = uStack_ac + 1;
      uVar20 = auStack_c0[0];
      if (0xfff < uVar19) {
        uVar20 = *(uint *)(auStack_c0[0] - 4);
        uVar19 = uStack_ac + 0x24;
        if (0x1f < (auStack_c0[0] - uVar20) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar19);
    }
    uStack_b0 = 0;
    uStack_ac = 0xf;
    auStack_c0[0] = auStack_c0[0] & 0xffffff00;
    uStack_8._0_1_ = 3;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_c4) {
      uVar19 = uStack_c4 + 1;
      uVar20 = auStack_d8[0];
      if (0xfff < uVar19) {
        uVar20 = *(uint *)(auStack_d8[0] - 4);
        uVar19 = uStack_c4 + 0x24;
        if (0x1f < (auStack_d8[0] - uVar20) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar19);
    }
    uStack_c8 = 0;
    uStack_c4 = 0xf;
    auStack_d8[0] = auStack_d8[0] & 0xffffff00;
    uStack_8._0_1_ = 2;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_dc) {
      uVar19 = uStack_dc + 1;
      uVar20 = auStack_f0[0];
      if (0xfff < uVar19) {
        uVar20 = *(uint *)(auStack_f0[0] - 4);
        uVar19 = uStack_dc + 0x24;
        if (0x1f < (auStack_f0[0] - uVar20) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar19);
    }
    uStack_e0 = 0;
    uStack_dc = 0xf;
    auStack_f0[0] = auStack_f0[0] & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_4c) {
      uVar19 = uStack_4c + 1;
      uVar20 = auStack_60[0];
      if (0xfff < uVar19) {
        uVar20 = *(uint *)(auStack_60[0] - 4);
        uVar19 = uStack_4c + 0x24;
        if (0x1f < (auStack_60[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
LAB_00a095ed:
      FUN_01674ea0(uVar20,uVar19);
    }
  }
  puVar12 = (undefined *)FUN_01674e20(0x18);
  if (puVar12 == (undefined *)0x0) {
    puVar12 = (undefined *)0x0;
    uStack_14 = 0;
  }
  else {
    *puVar12 = 0;
    uStack_14 = 0xb;
    ppuVar13 = (undefined **)
               FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
    ppuVar18 = ppuVar13 + -1;
    if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar18 = ppuVar13;
    }
    *(undefined **)(puVar12 + 4) = *ppuVar18;
    *(undefined4 *)(puVar12 + 8) = 0;
    *(undefined4 *)(puVar12 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar12 + 0x10) = 0;
    *(undefined4 *)(puVar12 + 0x14) = 0;
  }
  uStack_40 = 0;
  piStack_3c = (int *)0x0;
  FUN_005c1af0(puVar12,uStack_14);
  puVar10 = &uStack_48;
  uStack_8._0_1_ = 9;
  FUN_005c4c00(&DAT_01d65a80);
  FUN_00632bc0(puVar10);
  iVar14 = FUN_005c4c00(&DAT_01d65ae0);
  uVar15 = FUN_0088cb40();
  *(undefined4 *)(iVar14 + 0x18) = uVar15;
  FUN_005c17a0(param_1 + 0x58);
  uStack_f8 = 0;
  uStack_f4 = 0xf;
  auStack_108[0] = auStack_108[0] & 0xffffff00;
  uStack_8._0_1_ = 10;
  FUN_005e4d60(&uStack_40);
  uStack_8._0_1_ = 0xb;
  FUN_0098fc00(auStack_1d8,auStack_108,1);
  uStack_8._0_1_ = 0xc;
  if (iStack_1d4 != 0) {
    (**(code **)(iStack_1d4 + 8))(auStack_1d0);
  }
  uStack_8._0_1_ = 10;
  uVar15 = FUN_014c9d60(&iStack_1c,0);
  uStack_8._0_1_ = 0xd;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xd;
  if (DAT_01d65a40 == '\0') {
    uStack_8._0_1_ = uVar8;
    FUN_014cba60();
    ppppuVar11 = &pppuStack_38;
    if (0xf < uStack_28._4_4_) {
      ppppuVar11 = (undefined4 ****)pppuStack_38;
    }
    FUN_014cbbc0(ppppuVar11,(undefined4)uStack_28);
    *(undefined4 *)(iStack_1c + 0xb0) = 0;
    puVar10 = &DAT_01d79f98;
    if (0xf < DAT_01d79fac) {
      puVar10 = DAT_01d79f98;
    }
    puVar16 = &DAT_01d79d70;
    if (0xf < DAT_01d79d84) {
      puVar16 = DAT_01d79d70;
    }
    FUN_014cb8a0(puVar16,DAT_01d79d80,puVar10,DAT_01d79fa8);
    uVar21 = FUN_00928340();
    puVar16 = (undefined4 *)FUN_01675640(auStack_80,&DAT_018bed48,uVar21);
    puVar10 = puVar16 + 4;
    uStack_8._0_1_ = 0xf;
    if (0xf < (uint)puVar16[5]) {
      puVar16 = (undefined4 *)*puVar16;
    }
    puVar17 = &DAT_01d79ef0;
    if (0xf < DAT_01d79f04) {
      puVar17 = DAT_01d79ef0;
    }
    FUN_014cb8a0(puVar17,DAT_01d79f00,puVar16,*puVar10);
    uStack_8._0_1_ = 0xd;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xd;
    if (pppuStack_6c < 0x10) goto LAB_00a09936;
    uVar19 = (int)pppuStack_6c + 1;
    uVar20 = auStack_80[0];
    if (0xfff < uVar19) {
      uVar20 = *(uint *)(auStack_80[0] - 4);
      uVar19 = (int)pppuStack_6c + 0x24;
      if (0x1f < (auStack_80[0] - uVar20) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    uVar5 = *(undefined4 *)(param_1 + 0x30);
    uStack_14 = CONCAT31((int3)((uint)uVar15 >> 8),*(undefined *)(iStack_20 + 0x8d));
    uVar15 = *(undefined4 *)(iStack_20 + 0x34);
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c3c98,4);
    uStack_8._0_1_ = 0xe;
    if (*(int *)(iStack_20 + 0x28) != 0) {
      LOCK();
      piVar2 = (int *)(*(int *)(iStack_20 + 0x28) + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    uVar6 = *(undefined4 *)(iStack_20 + 0x24);
    uVar7 = *(undefined4 *)(iStack_20 + 0x28);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    FUN_00a115a0(iStack_1c,piStack_18,auStack_60,&pppuStack_38,uVar6,uVar7,uStack_14,uVar5,uVar15);
    uStack_8._0_1_ = 0xd;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xd;
    if (uStack_4c < 0x10) goto LAB_00a09936;
    uVar19 = uStack_4c + 1;
    uVar20 = auStack_60[0];
    if (0xfff < uVar19) {
      uVar20 = *(uint *)(auStack_60[0] - 4);
      uVar19 = uStack_4c + 0x24;
      if (0x1f < (auStack_60[0] - uVar20) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  uStack_8._0_1_ = 0xd;
  FUN_01674ea0(uVar20,uVar19);
LAB_00a09936:
  FUN_014cb780(auStack_108,DAT_01d65a38);
  if (piStack_64 != (int *)0x0) {
    LOCK();
    piStack_64[2] = piStack_64[2] + 1;
    UNLOCK();
  }
  uStack_8c = uStack_68;
  pppuStack_6c = &ppuStack_90;
  ppuStack_90 = std::
                _Func_impl_no_alloc<class_<lambda_677418c1100a047d77fc4bbf0eb151ef>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                ::vftable;
  piStack_88 = piStack_64;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  iVar14 = FUN_014cb530(pppuStack_6c);
  if (pppuStack_6c != (undefined ***)0x0) {
    iVar14 = (*(code *)(*pppuStack_6c)[4])(pppuStack_6c != &ppuStack_90);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_18 + 1;
    iVar4 = *piVar2;
    iVar14 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piStack_18 + 2;
      iVar4 = *piVar2;
      iVar14 = *piVar2;
      *piVar2 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar14 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < uStack_f4) {
    uVar19 = uStack_f4 + 1;
    uVar20 = auStack_108[0];
    if (0xfff < uVar19) {
      uVar20 = *(uint *)(auStack_108[0] - 4);
      uVar19 = uStack_f4 + 0x24;
      if (0x1f < (auStack_108[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar14 = FUN_01674ea0(uVar20,uVar19);
  }
  piVar2 = piStack_3c;
  uStack_f8 = 0;
  uStack_f4 = 0xf;
  auStack_108[0] = auStack_108[0] & 0xffffff00;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    piVar3 = piStack_3c + 1;
    iVar4 = *piVar3;
    iVar14 = *piVar3;
    *piVar3 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar3 = piVar2 + 2;
      iVar4 = *piVar3;
      iVar14 = *piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar14 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (0xf < uStack_28._4_4_) {
    uVar20 = uStack_28._4_4_ + 1;
    ppppuVar11 = (undefined4 ****)pppuStack_38;
    if (0xfff < uVar20) {
      ppppuVar11 = (undefined4 ****)pppuStack_38[-1];
      uVar20 = uStack_28._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar14 = FUN_01674ea0(ppppuVar11,uVar20);
  }
  uStack_28 = 0xf00000000;
  pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffffff00);
  if (piStack_64 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_64 + 2;
    iVar4 = *piVar2;
    iVar14 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar14 = (**(code **)(*piStack_64 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar14;
}



/* FUNCTION 19859 ; VA 0x00a09af0 ; FUN_00a09af0 */

void __fastcall FUN_00a09af0(int param_1)

{
  undefined4 *****pppppuVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined uVar8;
  undefined4 *puVar9;
  undefined4 *****pppppuVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 ****ppppuVar13;
  uint uVar14;
  uint uVar15;
  undefined8 uVar16;
  undefined auStack_158 [120];
  uint auStack_e0 [4];
  undefined4 uStack_d0;
  uint uStack_cc;
  uint auStack_c8 [4];
  undefined4 uStack_b8;
  uint uStack_b4;
  uint auStack_b0 [4];
  undefined4 uStack_a0;
  uint uStack_9c;
  undefined **ppuStack_98;
  undefined4 uStack_94;
  int *piStack_90;
  uint auStack_88 [4];
  undefined4 uStack_78;
  undefined ***pppuStack_74;
  undefined4 uStack_70;
  int *piStack_6c;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 ****ppppuStack_50;
  undefined4 ***pppuStack_4c;
  undefined4 ***pppuStack_48;
  undefined4 ***pppuStack_44;
  undefined8 uStack_40;
  undefined4 ****appppuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da905;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  if (DAT_01ee6bcc != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee6bcc,"Commit: Finalize",0);
  }
  puVar9 = (undefined4 *)FUN_016830f0(&uStack_70);
  *(undefined4 *)(param_1 + 0xa0) = *puVar9;
  *(undefined4 *)(param_1 + 0xa4) = puVar9[1];
  uStack_40 = 0xf00000000;
  ppppuStack_50 = (undefined4 ****)((uint)ppppuStack_50 & 0xffffff00);
  uStack_8 = 0;
  if ((DAT_01d658cc < 1) || (DAT_01d658f8 < DAT_01d658cc)) {
    FUN_0054ef60(param_1 + 0x70);
    pppppuVar10 = (undefined4 *****)FUN_00fb8d10(auStack_88);
    uStack_8._0_1_ = 7;
    if (&ppppuStack_50 != pppppuVar10) {
      pppppuVar1 = pppppuVar10 + 4;
      if ((undefined4 ****)0xf < pppppuVar10[5]) {
        pppppuVar10 = (undefined4 *****)*pppppuVar10;
      }
      FUN_005542c0(pppppuVar10,*pppppuVar1);
    }
    uStack_8._0_1_ = 0;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < pppuStack_74) {
      uVar14 = (int)pppuStack_74 + 1;
      uVar15 = auStack_88[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_88[0] - 4);
        uVar14 = (int)pppuStack_74 + 0x24;
        if (0x1f < (auStack_88[0] - uVar15) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      goto LAB_00a09f26;
    }
  }
  else {
    uStack_58 = 0;
    uStack_54 = 0xf;
    auStack_68[0] = auStack_68[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 1;
    uStack_28 = 0;
    uStack_24 = 0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 2;
    uStack_d0 = 0;
    uStack_cc = 0xf;
    auStack_e0[0] = auStack_e0[0] & 0xffffff00;
    FUN_005542c0("universe-history-mock/commits/200/commit",0x28);
    uStack_8._0_1_ = 3;
    uStack_b8 = 0;
    uStack_b4 = 0xf;
    auStack_c8[0] = auStack_c8[0] & 0xffffff00;
    FUN_005542c0("apis.simulpong.com",0x12);
    uStack_8._0_1_ = 4;
    uStack_a0 = 0;
    uStack_9c = 0xf;
    auStack_b0[0] = auStack_b0[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c71bc,4);
    uStack_8._0_1_ = 5;
    FUN_0151bcc0(auStack_158,auStack_b0,auStack_c8,auStack_e0,appppuStack_38,auStack_68);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    pppppuVar10 = (undefined4 *****)FUN_0151bb70(auStack_88);
    if (&ppppuStack_50 != pppppuVar10) {
      FUN_005507b0();
      ppppuStack_50 = *pppppuVar10;
      pppuStack_4c = pppppuVar10[1];
      pppuStack_48 = pppppuVar10[2];
      pppuStack_44 = pppppuVar10[3];
      uStack_40 = *(undefined8 *)(pppppuVar10 + 4);
      pppppuVar10[4] = (undefined4 ****)0x0;
      pppppuVar10[5] = (undefined4 ****)0xf;
      *(undefined *)pppppuVar10 = 0;
    }
    if (0xf < pppuStack_74) {
      uVar14 = (int)pppuStack_74 + 1;
      uVar15 = auStack_88[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_88[0] - 4);
        uVar14 = (int)pppuStack_74 + 0x24;
        if (0x1f < (auStack_88[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar14);
    }
    uStack_78 = 0;
    pppuStack_74 = (undefined ***)0xf;
    auStack_88[0] = auStack_88[0] & 0xffffff00;
    FUN_0056d9d0();
    uStack_8._0_1_ = 4;
    if (0xf < uStack_9c) {
      uVar14 = uStack_9c + 1;
      uVar15 = auStack_b0[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_b0[0] - 4);
        uVar14 = uStack_9c + 0x24;
        if (0x1f < (auStack_b0[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar14);
    }
    uStack_a0 = 0;
    uStack_9c = 0xf;
    auStack_b0[0] = auStack_b0[0] & 0xffffff00;
    uStack_8._0_1_ = 3;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_b4) {
      uVar14 = uStack_b4 + 1;
      uVar15 = auStack_c8[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_c8[0] - 4);
        uVar14 = uStack_b4 + 0x24;
        if (0x1f < (auStack_c8[0] - uVar15) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar14);
    }
    uStack_b8 = 0;
    uStack_b4 = 0xf;
    auStack_c8[0] = auStack_c8[0] & 0xffffff00;
    uStack_8._0_1_ = 2;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_cc) {
      uVar14 = uStack_cc + 1;
      uVar15 = auStack_e0[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_e0[0] - 4);
        uVar14 = uStack_cc + 0x24;
        if (0x1f < (auStack_e0[0] - uVar15) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar14);
    }
    uStack_d0 = 0;
    uStack_cc = 0xf;
    auStack_e0[0] = auStack_e0[0] & 0xffffff00;
    uStack_8._0_1_ = 1;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_24) {
      uVar15 = uStack_24 + 1;
      ppppuVar13 = appppuStack_38[0];
      if (0xfff < uVar15) {
        ppppuVar13 = (undefined4 ****)appppuStack_38[0][-1];
        uVar15 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)ppppuVar13))) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar13,uVar15);
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    uStack_8._0_1_ = 0;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_54) {
      uVar14 = uStack_54 + 1;
      uVar15 = auStack_68[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_68[0] - 4);
        uVar14 = uStack_54 + 0x24;
        if (0x1f < (auStack_68[0] - uVar15) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
LAB_00a09f26:
      uStack_8._0_1_ = 0;
      FUN_01674ea0(uVar15,uVar14);
    }
  }
  FUN_008c0cc0(&uStack_70,param_1);
  uStack_8._0_1_ = 8;
  FUN_014c9d60(&iStack_1c,0);
  uStack_8._0_1_ = 9;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (DAT_01d65a40 == '\0') {
    uStack_8._0_1_ = uVar8;
    FUN_014cba60();
    pppppuVar10 = &ppppuStack_50;
    if (0xf < uStack_40._4_4_) {
      pppppuVar10 = (undefined4 *****)ppppuStack_50;
    }
    FUN_014cbbc0(pppppuVar10,(undefined4)uStack_40);
    *(undefined4 *)(iStack_1c + 0xb0) = 0;
    puVar9 = &DAT_01d79f98;
    if (0xf < DAT_01d79fac) {
      puVar9 = DAT_01d79f98;
    }
    puVar11 = &DAT_01d79d70;
    if (0xf < DAT_01d79d84) {
      puVar11 = DAT_01d79d70;
    }
    FUN_014cb8a0(puVar11,DAT_01d79d80,puVar9,DAT_01d79fa8);
    if (*(int *)(iStack_20 + 0x24) == 0) {
      uVar16 = *(undefined8 *)(iStack_20 + 0x30);
    }
    else {
      uVar16 = FUN_00928340();
    }
    puVar11 = (undefined4 *)FUN_01675640(auStack_88,&DAT_018bed48,uVar16);
    puVar9 = puVar11 + 4;
    uStack_8._0_1_ = 0xb;
    if (0xf < (uint)puVar11[5]) {
      puVar11 = (undefined4 *)*puVar11;
    }
    puVar12 = &DAT_01d79ef0;
    if (0xf < DAT_01d79f04) {
      puVar12 = DAT_01d79ef0;
    }
    FUN_014cb8a0(puVar12,DAT_01d79f00,puVar11,*puVar9);
    uStack_8._0_1_ = 9;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 9;
    if (pppuStack_74 < 0x10) goto LAB_00a0a169;
    uVar14 = (int)pppuStack_74 + 1;
    uVar15 = auStack_88[0];
    if (0xfff < uVar14) {
      uVar15 = *(uint *)(auStack_88[0] - 4);
      uVar14 = (int)pppuStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    uVar3 = *(undefined4 *)(param_1 + 0x30);
    uVar4 = *(undefined4 *)(param_1 + 0x34);
    uStack_14 = CONCAT31((int3)((uint)iStack_20 >> 8),*(undefined *)(iStack_20 + 0x8d));
    uStack_58 = 0;
    uStack_54 = 0xf;
    auStack_68[0] = auStack_68[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c3c98,4);
    uStack_8._0_1_ = 10;
    if (*(int *)(iStack_20 + 0x28) != 0) {
      LOCK();
      piVar2 = (int *)(*(int *)(iStack_20 + 0x28) + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    uVar5 = *(undefined4 *)(iStack_20 + 0x24);
    uVar6 = *(undefined4 *)(iStack_20 + 0x28);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    FUN_00a115a0(iStack_1c,piStack_18,auStack_68,&ppppuStack_50,uVar5,uVar6,uStack_14,uVar3,uVar4);
    uStack_8._0_1_ = 9;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 9;
    if (uStack_54 < 0x10) goto LAB_00a0a169;
    uVar14 = uStack_54 + 1;
    uVar15 = auStack_68[0];
    if (0xfff < uVar14) {
      uVar15 = *(uint *)(auStack_68[0] - 4);
      uVar14 = uStack_54 + 0x24;
      if (0x1f < (auStack_68[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  uStack_8._0_1_ = 9;
  FUN_01674ea0(uVar15,uVar14);
LAB_00a0a169:
  uStack_28 = 0;
  uStack_24 = 0xf;
  appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
  FUN_005542c0(&DAT_018bf820,2);
  uStack_8._0_1_ = 0xc;
  pppppuVar10 = appppuStack_38;
  if (0xf < uStack_24) {
    pppppuVar10 = (undefined4 *****)appppuStack_38[0];
  }
  FUN_014cb7a0(pppppuVar10,uStack_28);
  uStack_8._0_1_ = 9;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_24) {
    uVar15 = uStack_24 + 1;
    pppppuVar10 = (undefined4 *****)appppuStack_38[0];
    if (0xfff < uVar15) {
      pppppuVar10 = (undefined4 *****)appppuStack_38[0][-1];
      uVar15 = uStack_24 + 0x24;
      if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)pppppuVar10))) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar10,uVar15);
  }
  if (piStack_6c != (int *)0x0) {
    LOCK();
    piStack_6c[2] = piStack_6c[2] + 1;
    UNLOCK();
  }
  uStack_94 = uStack_70;
  pppuStack_74 = &ppuStack_98;
  ppuStack_98 = std::
                _Func_impl_no_alloc<class_<lambda_242501298d2d251cf827e607c47ce812>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                ::vftable;
  piStack_90 = piStack_6c;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  FUN_014cb530(pppuStack_74);
  if (pppuStack_74 != (undefined ***)0x0) {
    (*(code *)(*pppuStack_74)[4])(pppuStack_74 != &ppuStack_98);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_18[1] + -1;
    piStack_18[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar7 = piStack_18[2] + -1;
      piStack_18[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (piStack_6c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_6c + 2;
    iVar7 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar7 == 1) {
      (**(code **)(*piStack_6c + 4))();
    }
  }
  if (0xf < uStack_40._4_4_) {
    uVar15 = uStack_40._4_4_ + 1;
    pppppuVar10 = (undefined4 *****)ppppuStack_50;
    if (0xfff < uVar15) {
      pppppuVar10 = (undefined4 *****)ppppuStack_50[-1];
      uVar15 = uStack_40._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_50 + (-4 - (int)pppppuVar10))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar10,uVar15);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19860 ; VA 0x00a0a300 ; FUN_00a0a300 */

void __thiscall FUN_00a0a300(int param_1,int *param_2,undefined4 *param_3)

{
  byte *pbVar1;
  int iVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  
  puVar8 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar8 = (undefined4 *)*param_3;
  }
  uVar6 = 0;
  uVar7 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar6 + (int)puVar8);
      uVar6 = uVar6 + 1;
      uVar7 = (*pbVar1 ^ uVar7) * 0x1000193;
    } while (uVar6 < (uint)param_3[4]);
  }
  uVar7 = *(uint *)(param_1 + 0x18) & uVar7;
  iVar2 = *(int *)(param_1 + 0xc);
  puVar8 = *(undefined4 **)(param_1 + 4);
  puVar3 = *(undefined4 **)(iVar2 + uVar7 * 8);
  puVar9 = puVar3;
  while( true ) {
    puVar5 = puVar8;
    if (puVar3 != puVar8) {
      puVar5 = (undefined4 *)**(undefined4 **)(uVar7 * 8 + 4 + iVar2);
    }
    if (puVar9 == puVar5) goto LAB_00a0a3a1;
    cVar4 = FUN_00570290(puVar9 + 2,param_3);
    if (cVar4 != '\0') break;
    puVar9 = (undefined4 *)*puVar9;
  }
  cVar4 = FUN_00570290(param_3,puVar9 + 2);
  if (cVar4 != '\0') {
    puVar8 = puVar9;
  }
LAB_00a0a3a1:
  *param_2 = (int)puVar8;
  return;
}



/* FUNCTION 19861 ; VA 0x00a0a3b0 ; FUN_00a0a3b0 */

longlong FUN_00a0a3b0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  longlong *plVar5;
  
  iVar2 = *param_1;
  iVar1 = FUN_0088c8c0();
  iVar4 = *param_1;
  if (iVar2 == iVar1) {
    iVar2 = FUN_0088c8c0();
    if (iVar4 == iVar2) {
      piVar3 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar3 = (int *)0x0;
      }
      return (longlong)*piVar3;
    }
  }
  else {
    iVar2 = FUN_0088da50();
    if (iVar4 != iVar2) {
      if (DAT_01d84e8e != '\0') {
        FUN_016774b0(DAT_01d84e8e,"int64_t conversion failure: not a valid number",0);
      }
      return 0;
    }
    iVar2 = *param_1;
    iVar4 = FUN_0088da50();
    if (iVar2 == iVar4) {
      plVar5 = (longlong *)(param_1 + 2);
      if (param_1[1] == 0) {
        plVar5 = (longlong *)0x0;
      }
      return *plVar5;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 19862 ; VA 0x00a0a460 ; FUN_00a0a460 */

int * __thiscall FUN_00a0a460(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017da934;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puVar3[1] = 1;
    puVar3[2] = 1;
    *puVar3 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
  }
  *param_2 = (int)(puVar3 + 3);
  param_2[1] = (int)puVar3;
  piVar1 = *(int **)(param_1 + 0x3c);
  uStack_8 = 0;
  uStack_18 = 3;
  piVar4 = (int *)*piVar1;
  if (piVar4 == piVar1) {
    ExceptionList = pvStack_10;
    return param_2;
  }
  do {
    iStack_14 = *param_2;
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(piVar4 + 2);
    iStack_e4 = FUN_005c9d30();
    iVar2 = iStack_14;
    uStack_8 = 1;
    if (*(int *)(iStack_14 + 8) == *(int *)(iStack_14 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_14 + 4),&uStack_e8);
    }
    else {
      FUN_005caaf0(iStack_14);
      *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 0xd0;
    }
    uStack_8 = 2;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
    piVar4 = (int *)*piVar4;
    uStack_8 = uStack_8 & 0xffffff00;
  } while (piVar4 != piVar1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19863 ; VA 0x00a0a5c0 ; FUN_00a0a5c0 */

int __fastcall FUN_00a0a5c0(uint param_1)

{
  undefined4 ****ppppuVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined uVar7;
  undefined3 uVar8;
  undefined4 *puVar9;
  undefined4 ****ppppuVar10;
  undefined *puVar11;
  undefined **ppuVar12;
  undefined4 uVar13;
  undefined4 *puVar14;
  undefined4 *puVar15;
  int iVar16;
  undefined **ppuVar17;
  uint uVar18;
  uint uVar19;
  undefined8 uVar20;
  int *piVar21;
  undefined4 uStack_1dc;
  int iStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined8 uStack_1c4;
  undefined auStack_184 [120];
  uint auStack_10c [4];
  undefined4 uStack_fc;
  uint uStack_f8;
  uint auStack_f4 [4];
  undefined4 uStack_e4;
  uint uStack_e0;
  uint auStack_dc [4];
  undefined4 uStack_cc;
  uint uStack_c8;
  uint auStack_c4 [4];
  undefined4 uStack_b4;
  uint uStack_b0;
  uint auStack_ac [4];
  undefined4 uStack_9c;
  uint uStack_98;
  undefined **ppuStack_94;
  undefined4 uStack_90;
  int *piStack_8c;
  uint auStack_84 [4];
  undefined4 uStack_74;
  undefined ***pppuStack_70;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  undefined4 ***pppuStack_44;
  undefined4 **ppuStack_40;
  undefined4 **ppuStack_3c;
  undefined4 **ppuStack_38;
  undefined8 uStack_34;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da9fe;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_1c = param_1;
  if (DAT_01ee6bcc != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee6bcc,"Commit: %s",PTR_s_Asset_Mappings_01d65ca8);
  }
  puVar9 = (undefined4 *)FUN_016830f0(&uStack_54);
  *(undefined4 *)(param_1 + 0xa0) = *puVar9;
  *(undefined4 *)(param_1 + 0xa4) = puVar9[1];
  FUN_008c0cc0(&uStack_54,param_1);
  uStack_34 = 0xf00000000;
  pppuStack_44 = (undefined4 ***)((uint)pppuStack_44 & 0xffffff00);
  uStack_8._1_3_ = 0;
  uVar8 = uStack_8._1_3_;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if ((DAT_01d658cc < 1) || (DAT_01d658e0 < DAT_01d658cc)) {
    uStack_18 = CONCAT31((int3)((uint)DAT_01d658cc >> 8),*(undefined *)(param_1 + 0x8d));
    cStack_11 = '\0';
    piVar21 = *(int **)(*(int *)(param_1 + 0x1c) + 0x43c);
    uStack_8._1_3_ = uVar8;
    ppppuVar10 = (undefined4 ****)
                 FUN_00fb7830(auStack_84,*piVar21 - (int)piVar21,piVar21[1] - (int)piVar21,uStack_18
                             );
    uStack_8._0_1_ = 8;
    if (&pppuStack_44 != ppppuVar10) {
      ppppuVar1 = ppppuVar10 + 4;
      if ((undefined4 ***)0xf < ppppuVar10[5]) {
        ppppuVar10 = (undefined4 ****)*ppppuVar10;
      }
      FUN_005542c0(ppppuVar10,*ppppuVar1);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < pppuStack_70) {
      uVar18 = (int)pppuStack_70 + 1;
      uVar19 = auStack_84[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_84[0] - 4);
        uVar18 = (int)pppuStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      goto LAB_00a0aa2a;
    }
  }
  else {
    cStack_11 = '\x01';
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 2;
    uStack_e4 = 0;
    uStack_e0 = 0xf;
    auStack_f4[0] = auStack_f4[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 3;
    uStack_cc = 0;
    uStack_c8 = 0xf;
    auStack_dc[0] = auStack_dc[0] & 0xffffff00;
    FUN_005542c0("universe-history-mock/places/200/asset-mappings",0x2f);
    uStack_8._0_1_ = 4;
    uStack_b4 = 0;
    uStack_b0 = 0xf;
    auStack_c4[0] = auStack_c4[0] & 0xffffff00;
    FUN_005542c0("apis.simulpong.com",0x12);
    uStack_8._0_1_ = 5;
    uStack_9c = 0;
    uStack_98 = 0xf;
    auStack_ac[0] = auStack_ac[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c71bc,4);
    uStack_8._0_1_ = 6;
    FUN_0151bcc0(auStack_184,auStack_ac,auStack_c4,auStack_dc,auStack_f4,auStack_6c);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    ppppuVar10 = (undefined4 ****)FUN_0151bb70(auStack_84);
    if (&pppuStack_44 != ppppuVar10) {
      FUN_005507b0();
      pppuStack_44 = *ppppuVar10;
      ppuStack_40 = ppppuVar10[1];
      ppuStack_3c = ppppuVar10[2];
      ppuStack_38 = ppppuVar10[3];
      uStack_34 = *(undefined8 *)(ppppuVar10 + 4);
      ppppuVar10[4] = (undefined4 ***)0x0;
      ppppuVar10[5] = (undefined4 ***)0xf;
      *(undefined *)ppppuVar10 = 0;
    }
    if (0xf < pppuStack_70) {
      uVar18 = (int)pppuStack_70 + 1;
      uVar19 = auStack_84[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_84[0] - 4);
        uVar18 = (int)pppuStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
    uStack_74 = 0;
    pppuStack_70 = (undefined ***)0xf;
    auStack_84[0] = auStack_84[0] & 0xffffff00;
    FUN_0056d9d0();
    uStack_8._0_1_ = 5;
    if (0xf < uStack_98) {
      uVar18 = uStack_98 + 1;
      uVar19 = auStack_ac[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_ac[0] - 4);
        uVar18 = uStack_98 + 0x24;
        if (0x1f < (auStack_ac[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
    uStack_9c = 0;
    uStack_98 = 0xf;
    auStack_ac[0] = auStack_ac[0] & 0xffffff00;
    uStack_8._0_1_ = 4;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_b0) {
      uVar18 = uStack_b0 + 1;
      uVar19 = auStack_c4[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_c4[0] - 4);
        uVar18 = uStack_b0 + 0x24;
        if (0x1f < (auStack_c4[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
    uStack_b4 = 0;
    uStack_b0 = 0xf;
    auStack_c4[0] = auStack_c4[0] & 0xffffff00;
    uStack_8._0_1_ = 3;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_c8) {
      uVar18 = uStack_c8 + 1;
      uVar19 = auStack_dc[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_dc[0] - 4);
        uVar18 = uStack_c8 + 0x24;
        if (0x1f < (auStack_dc[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
    uStack_cc = 0;
    uStack_c8 = 0xf;
    auStack_dc[0] = auStack_dc[0] & 0xffffff00;
    uStack_8._0_1_ = 2;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_e0) {
      uVar18 = uStack_e0 + 1;
      uVar19 = auStack_f4[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_f4[0] - 4);
        uVar18 = uStack_e0 + 0x24;
        if (0x1f < (auStack_f4[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
    uStack_e4 = 0;
    uStack_e0 = 0xf;
    auStack_f4[0] = auStack_f4[0] & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_58) {
      uVar18 = uStack_58 + 1;
      uVar19 = auStack_6c[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_6c[0] - 4);
        uVar18 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
LAB_00a0aa2a:
      FUN_01674ea0(uVar19,uVar18);
    }
  }
  puVar11 = (undefined *)FUN_01674e20(0x18);
  if (puVar11 == (undefined *)0x0) {
    puVar11 = (undefined *)0x0;
    uStack_18 = 0;
  }
  else {
    *puVar11 = 0;
    uStack_18 = 0xb;
    ppuVar12 = (undefined **)
               FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_18);
    ppuVar17 = ppuVar12 + -1;
    if (ppuVar12 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar17 = ppuVar12;
    }
    *(undefined **)(puVar11 + 4) = *ppuVar17;
    *(undefined4 *)(puVar11 + 8) = 0;
    *(undefined4 *)(puVar11 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar11 + 0x10) = 0;
    *(undefined4 *)(puVar11 + 0x14) = 0;
  }
  uStack_4c = 0;
  piStack_48 = (int *)0x0;
  FUN_005c1af0(puVar11,uStack_18);
  uStack_8._0_1_ = 9;
  puVar9 = (undefined4 *)FUN_01674e20(0xc);
  if (puVar9 == (undefined4 *)0x0) {
    puVar9 = (undefined4 *)0x0;
  }
  else {
    *puVar9 = 0;
    puVar9[1] = 0;
    puVar9[2] = 0;
  }
  iStack_2c = 0;
  piStack_28 = (int *)0x0;
  FUN_006047e0(puVar9,uStack_18);
  uStack_8._0_1_ = 10;
  if (cStack_11 == '\0') {
    puVar9 = *(undefined4 **)(param_1 + 0x3c);
    param_1 = uStack_1c;
    for (puVar14 = (undefined4 *)*puVar9; uStack_1c = param_1, puVar14 != puVar9;
        puVar14 = (undefined4 *)*puVar14) {
      uStack_8._0_1_ = 10;
      uStack_1dc = FUN_0088cb40();
      iStack_1d8 = 0;
      FUN_0054ef60(puVar14 + 2);
      iStack_1d8 = FUN_005c9d30();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      if (*(int *)(iStack_2c + 8) == *(int *)(iStack_2c + 4)) {
        FUN_005ca4f0(*(int *)(iStack_2c + 4),&uStack_1dc);
      }
      else {
        FUN_005caaf0(iStack_2c);
        *(int *)(iStack_2c + 4) = *(int *)(iStack_2c + 4) + 0xd0;
      }
      uStack_8._0_1_ = 0xf;
      if (iStack_1d8 != 0) {
        (**(code **)(iStack_1d8 + 8))(&uStack_1d4);
      }
      param_1 = uStack_1c;
    }
    uStack_8._0_1_ = 10;
  }
  else {
    puVar9 = (undefined4 *)FUN_0054ef60(&DAT_01d65a68);
    uStack_8._0_1_ = 0xb;
    uStack_1dc = FUN_0088cb40();
    iStack_1d8 = 0;
    uStack_1d4 = *puVar9;
    uStack_1d0 = puVar9[1];
    uStack_1cc = puVar9[2];
    uStack_1c8 = puVar9[3];
    uStack_1c4 = *(undefined8 *)(puVar9 + 4);
    puVar9[4] = 0;
    puVar9[5] = 0xf;
    *(undefined *)puVar9 = 0;
    iStack_1d8 = FUN_005c9d30();
    iVar16 = iStack_2c;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    if (*(int *)(iStack_2c + 8) == *(int *)(iStack_2c + 4)) {
      FUN_005ca4f0(*(int *)(iStack_2c + 4),&uStack_1dc);
    }
    else {
      FUN_005caaf0(iStack_2c);
      *(int *)(iVar16 + 4) = *(int *)(iVar16 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 0xd;
    if (iStack_1d8 != 0) {
      (**(code **)(iStack_1d8 + 8))(&uStack_1d4);
    }
    uStack_8._0_1_ = 10;
    if (0xf < pppuStack_70) {
      uVar18 = (int)pppuStack_70 + 1;
      uVar19 = auStack_84[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_84[0] - 4);
        uVar18 = (int)pppuStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar18);
    }
  }
  piVar21 = &iStack_2c;
  FUN_005c4c00(&DAT_01d65b10);
  FUN_00a03440(piVar21);
  uStack_fc = 0;
  uStack_f8 = 0xf;
  auStack_10c[0] = auStack_10c[0] & 0xffffff00;
  uStack_8._0_1_ = 0x10;
  FUN_005e4d60(&uStack_4c);
  uStack_8._0_1_ = 0x11;
  FUN_0098fc00(&uStack_1dc,auStack_10c,1);
  uStack_8._0_1_ = 0x12;
  if (iStack_1d8 != 0) {
    (**(code **)(iStack_1d8 + 8))(&uStack_1d4);
  }
  uStack_8._0_1_ = 0x10;
  uVar13 = FUN_014c9d60(&iStack_24,0);
  uStack_8._0_1_ = 0x13;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x13;
  if (DAT_01d65a40 == '\0') {
    uStack_8._0_1_ = uVar7;
    FUN_014cba60();
    ppppuVar10 = &pppuStack_44;
    if (0xf < uStack_34._4_4_) {
      ppppuVar10 = (undefined4 ****)pppuStack_44;
    }
    FUN_014cbbc0(ppppuVar10,(undefined4)uStack_34);
    *(undefined4 *)(iStack_24 + 0xb0) = 0;
    puVar9 = &DAT_01d79f98;
    if (0xf < DAT_01d79fac) {
      puVar9 = DAT_01d79f98;
    }
    puVar14 = &DAT_01d79d70;
    if (0xf < DAT_01d79d84) {
      puVar14 = DAT_01d79d70;
    }
    FUN_014cb8a0(puVar14,DAT_01d79d80,puVar9,DAT_01d79fa8);
    uVar20 = FUN_00928340();
    puVar14 = (undefined4 *)FUN_01675640(auStack_84,&DAT_018bed48,uVar20);
    puVar9 = puVar14 + 4;
    uStack_8._0_1_ = 0x15;
    if (0xf < (uint)puVar14[5]) {
      puVar14 = (undefined4 *)*puVar14;
    }
    puVar15 = &DAT_01d79ef0;
    if (0xf < DAT_01d79f04) {
      puVar15 = DAT_01d79ef0;
    }
    FUN_014cb8a0(puVar15,DAT_01d79f00,puVar14,*puVar9);
    uStack_8._0_1_ = 0x13;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x13;
    if (0xf < pppuStack_70) {
      uVar18 = (int)pppuStack_70 + 1;
      uVar19 = auStack_84[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_84[0] - 4);
        uVar18 = (int)pppuStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      goto LAB_00a0af31;
    }
  }
  else {
    uVar4 = *(undefined4 *)(param_1 + 0x30);
    uStack_18 = CONCAT31((int3)((uint)uVar13 >> 8),*(undefined *)(uStack_1c + 0x8d));
    uVar13 = *(undefined4 *)(uStack_1c + 0x34);
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c3c98,4);
    uStack_8._0_1_ = 0x14;
    if (*(int *)(uStack_1c + 0x28) != 0) {
      LOCK();
      piVar21 = (int *)(*(int *)(uStack_1c + 0x28) + 4);
      *piVar21 = *piVar21 + 1;
      UNLOCK();
    }
    uVar5 = *(undefined4 *)(uStack_1c + 0x24);
    uVar6 = *(undefined4 *)(uStack_1c + 0x28);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    FUN_00a115a0(iStack_24,piStack_20,auStack_6c,&pppuStack_44,uVar5,uVar6,uStack_18,uVar4,uVar13);
    uStack_8._0_1_ = 0x13;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x13;
    if (0xf < uStack_58) {
      uVar18 = uStack_58 + 1;
      uVar19 = auStack_6c[0];
      if (0xfff < uVar18) {
        uVar19 = *(uint *)(auStack_6c[0] - 4);
        uVar18 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
LAB_00a0af31:
      uStack_8._0_1_ = 0x13;
      FUN_01674ea0(uVar19,uVar18);
    }
  }
  if (cStack_11 == '\0') {
    uStack_1c = CONCAT31(uStack_1c._1_3_,1);
    if (DAT_01d65a38 != '\0') goto LAB_00a0af52;
  }
  uStack_1c = uStack_1c & 0xffffff00;
LAB_00a0af52:
  FUN_014cb780(auStack_10c,uStack_1c);
  if (piStack_50 != (int *)0x0) {
    LOCK();
    piStack_50[2] = piStack_50[2] + 1;
    UNLOCK();
  }
  uStack_90 = uStack_54;
  pppuStack_70 = &ppuStack_94;
  ppuStack_94 = std::
                _Func_impl_no_alloc<class_<lambda_d8d005b61aca10da22230ba33a64c55c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                ::vftable;
  piStack_8c = piStack_50;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
  iVar16 = FUN_014cb530(pppuStack_70);
  if (pppuStack_70 != (undefined ***)0x0) {
    iVar16 = (*(code *)(*pppuStack_70)[4])(pppuStack_70 != &ppuStack_94);
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar21 = piStack_20 + 1;
    iVar3 = *piVar21;
    iVar16 = *piVar21;
    *piVar21 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar21 = piStack_20 + 2;
      iVar3 = *piVar21;
      iVar16 = *piVar21;
      *piVar21 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar16 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (0xf < uStack_f8) {
    uVar18 = uStack_f8 + 1;
    uVar19 = auStack_10c[0];
    if (0xfff < uVar18) {
      uVar19 = *(uint *)(auStack_10c[0] - 4);
      uVar18 = uStack_f8 + 0x24;
      if (0x1f < (auStack_10c[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar16 = FUN_01674ea0(uVar19,uVar18);
  }
  piVar21 = piStack_28;
  uStack_fc = 0;
  uStack_f8 = 0xf;
  auStack_10c[0] = auStack_10c[0] & 0xffffff00;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_28 + 1;
    iVar3 = *piVar2;
    iVar16 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar2 = piVar21 + 2;
      iVar3 = *piVar2;
      iVar16 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar16 = (**(code **)(*piVar21 + 4))();
      }
    }
  }
  piVar21 = piStack_48;
  if (piStack_48 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_48 + 1;
    iVar3 = *piVar2;
    iVar16 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      piVar2 = piVar21 + 2;
      iVar3 = *piVar2;
      iVar16 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar16 = (**(code **)(*piVar21 + 4))();
      }
    }
  }
  if (0xf < uStack_34._4_4_) {
    uVar19 = uStack_34._4_4_ + 1;
    ppppuVar10 = (undefined4 ****)pppuStack_44;
    if (0xfff < uVar19) {
      ppppuVar10 = (undefined4 ****)pppuStack_44[-1];
      uVar19 = uStack_34._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_44 + (-4 - (int)ppppuVar10))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar16 = FUN_01674ea0(ppppuVar10,uVar19);
  }
  uStack_34 = 0xf00000000;
  pppuStack_44 = (undefined4 ***)((uint)pppuStack_44 & 0xffffff00);
  if (piStack_50 != (int *)0x0) {
    LOCK();
    piVar21 = piStack_50 + 2;
    iVar3 = *piVar21;
    *piVar21 = *piVar21 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      iVar16 = (**(code **)(*piStack_50 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar16;
}



/* FUNCTION 19864 ; VA 0x00a0b130 ; FUN_00a0b130 */

/* WARNING: Removing unreachable block (ram,0x00a0b1b9) */
/* WARNING: Removing unreachable block (ram,0x00a0b1c2) */
/* WARNING: Removing unreachable block (ram,0x00a0b1d1) */
/* WARNING: Removing unreachable block (ram,0x00a0b174) */
/* WARNING: Removing unreachable block (ram,0x00a0b18a) */
/* WARNING: Removing unreachable block (ram,0x00a0b198) */

undefined4 * FUN_00a0b130(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017daa18;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00602ce0(&param_2);
  if (DAT_01d84e8e != '\0') {
    FUN_01677520(DAT_01d84e8e,"Commit Failure: %s - VersionHistoryCommitCoordinator destroyed",
                 param_4);
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19865 ; VA 0x00a0b230 ; FUN_00a0b230 */

uint * FUN_00a0b230(uint *param_1,undefined4 *param_2)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  int in_stack_00000018;
  uint in_stack_0000001c;
  int iStack_dc;
  int *piStack_c8;
  int *piStack_c4;
  int *piStack_b8;
  uint *puStack_b4;
  int *piStack_a8;
  uint auStack_a4 [26];
  uint uStack_3c;
  undefined auStack_34 [4];
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = in_stack_00000018;
  puStack_c = &LAB_017daa75;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  puVar3 = &param_2;
  if (0xf < in_stack_0000001c) {
    puVar3 = param_2;
  }
  uStack_18 = 1;
  FUN_00565940(3,1);
  uStack_3c = uStack_3c & 0xffffff00;
  uStack_8._0_1_ = 2;
  FUN_005c3e00(puVar3,iVar1 + (int)puVar3,uStack_3c,
               *(undefined4 *)((int)auStack_a4 + *(int *)(iStack_dc + 4)),auStack_34,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_20 = 0;
  uStack_1c = 0xf;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_18 = 5;
  if (((auStack_a4[3] & 2) == 0) && (uVar5 = *puStack_b4, uVar5 != 0)) {
    if (uVar5 < auStack_a4[2]) {
      uVar5 = auStack_a4[2];
    }
    iVar1 = *piStack_c4;
    iVar4 = uVar5 - iVar1;
  }
  else {
    if (((auStack_a4[3] & 4) != 0) || (*piStack_b8 == 0)) goto LAB_00a0b347;
    iVar1 = *piStack_c8;
    iVar4 = (*piStack_b8 - iVar1) + *piStack_a8;
  }
  FUN_005542c0(iVar1,iVar4);
LAB_00a0b347:
  if (param_1 == &uStack_30) {
    if (0xf < uStack_1c) {
      uVar5 = uStack_1c + 1;
      uVar2 = uStack_30;
      if (0xfff < uVar5) {
        uVar2 = *(uint *)(uStack_30 - 4);
        uVar5 = uStack_1c + 0x24;
        if (0x1f < (uStack_30 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar5);
    }
  }
  else {
    FUN_005507b0();
    *param_1 = uStack_30;
    param_1[1] = uStack_2c;
    param_1[2] = uStack_28;
    param_1[3] = uStack_24;
    *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_1c,uStack_20);
  }
  FUN_005705c0();
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    puVar3 = param_2;
    if (0xfff < uVar5) {
      puVar3 = (undefined4 *)param_2[-1];
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19866 ; VA 0x00a0b400 ; FUN_00a0b400 */

void __fastcall FUN_00a0b400(int param_1)

{
  undefined uVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017da5b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_016830f0(auStack_18);
  *(undefined4 *)(param_1 + 0x98) = *puVar2;
  *(undefined4 *)(param_1 + 0x9c) = puVar2[1];
  if (DAT_01d65a40 == '\0') {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("Studio.TeamCreate.CollabEditVersionHistory.CommitAttempt",0x38);
    uStack_8 = 1;
    FUN_008783f0(auStack_30,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_1c) {
      uVar4 = uStack_1c + 1;
      uVar3 = auStack_30[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_30[0] - 4);
        uVar4 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
  }
  else {
    uVar1 = *(undefined *)(param_1 + 0x8d);
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    FUN_005542c0("CommitAttempt",0xd);
    uStack_8 = 0;
    FUN_00a11370(auStack_48,uVar1);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_34) {
      uVar4 = uStack_34 + 1;
      uVar3 = auStack_48[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_48[0] - 4);
        uVar4 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
  }
  FUN_0087c450("Studio","CollabEditVersionHistory","CommitAttempt",1,0,0);
  FUN_00a09180();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19867 ; VA 0x00a0b590 ; FUN_00a0b590 */

/* WARNING: Removing unreachable block (ram,0x00a0b5d2) */
/* WARNING: Removing unreachable block (ram,0x00a0b5fb) */
/* WARNING: Removing unreachable block (ram,0x00a0b5db) */
/* WARNING: Removing unreachable block (ram,0x00a0b5e4) */
/* WARNING: Removing unreachable block (ram,0x00a0b5f4) */
/* WARNING: Removing unreachable block (ram,0x00a0b5ed) */
/* WARNING: Removing unreachable block (ram,0x00a0b608) */
/* WARNING: Removing unreachable block (ram,0x00a0b615) */
/* WARNING: Removing unreachable block (ram,0x00a0b623) */
/* WARNING: Removing unreachable block (ram,0x00a0b62a) */

undefined4 FUN_00a0b590(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017daa88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00602ce0(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19868 ; VA 0x00a0b640 ; FUN_00a0b640 */

int FUN_00a0b640(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017daab8;
  pvStack_10 = ExceptionList;
  iStack_18 = 0;
  piStack_14 = (int *)0x0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00602ce0(param_1);
  iVar2 = iStack_18;
  uStack_8 = 0;
  if (iStack_18 != 0) {
    FUN_00a07f70();
    FUN_006eccd0();
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    if (DAT_01d65a40 == '\0') {
      FUN_005542c0("Studio.TeamCreate.CollabEditVersionHistory.CommitFinalizeFailed",0x3f);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_008783f0(auStack_30,1,0);
    }
    else {
      uVar3 = *(undefined *)(iVar2 + 0x8d);
      FUN_005542c0("CommitFinalizeFailed",0x14);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00a11370(auStack_30,uVar3);
    }
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_005507b0();
    iVar5 = FUN_0087c450("Studio","CollabEditVersionHistory","CommitFinalizeFailed",1,0,0);
  }
  piVar4 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 19869 ; VA 0x00a0b760 ; FUN_00a0b760 */

void FUN_00a0b760(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  piVar6 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_005e5c70(-(uint)(param_2 != 0) & param_2 + 0xcU);
  if (iVar2 != 0) {
    piVar4 = piVar6 + 7;
    if (0xf < (uint)piVar6[0xc]) {
      piVar4 = (int *)*piVar4;
    }
    piVar1 = piVar6 + 6;
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    uVar3 = FUN_01675640(aiStack_28,
                         "%s\'s commit failed with internal error: %s - can\'t parse JSON: `%s`",
                         piVar6,*piVar1,piVar4);
    uStack_8 = 0;
    FUN_0098c2c0(1,uVar3);
    if (0xf < uStack_14) {
      uVar5 = uStack_14 + 1;
      iVar2 = aiStack_28[0];
      if (0xfff < uVar5) {
        iVar2 = *(int *)(aiStack_28[0] + -4);
        uVar5 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar5);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19870 ; VA 0x00a0b820 ; FUN_00a0b820 */

/* WARNING: Removing unreachable block (ram,0x00a0b862) */
/* WARNING: Removing unreachable block (ram,0x00a0b86f) */
/* WARNING: Removing unreachable block (ram,0x00a0b87c) */
/* WARNING: Removing unreachable block (ram,0x00a0b88a) */
/* WARNING: Removing unreachable block (ram,0x00a0b891) */

undefined4 FUN_00a0b820(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017daa88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00602ce0(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19871 ; VA 0x00a0b8b0 ; FUN_00a0b8b0 */

/* WARNING: Removing unreachable block (ram,0x00a0b92b) */
/* WARNING: Removing unreachable block (ram,0x00a0b8f7) */
/* WARNING: Removing unreachable block (ram,0x00a0b900) */
/* WARNING: Removing unreachable block (ram,0x00a0b912) */
/* WARNING: Removing unreachable block (ram,0x00a0b92f) */
/* WARNING: Removing unreachable block (ram,0x00a0b909) */
/* WARNING: Removing unreachable block (ram,0x00a0b93d) */
/* WARNING: Removing unreachable block (ram,0x00a0b949) */
/* WARNING: Removing unreachable block (ram,0x00a0b957) */

undefined4 FUN_00a0b8b0(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017daa88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00602ce0(param_1);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 19872 ; VA 0x00a0b970 ; FUN_00a0b970 */

/* WARNING: Removing unreachable block (ram,0x00a0b9b2) */
/* WARNING: Removing unreachable block (ram,0x00a0b9bf) */
/* WARNING: Removing unreachable block (ram,0x00a0b9cc) */
/* WARNING: Removing unreachable block (ram,0x00a0b9da) */
/* WARNING: Removing unreachable block (ram,0x00a0b9e1) */

undefined4 FUN_00a0b970(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017daa88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00602ce0(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19873 ; VA 0x00a0ba00 ; FUN_00a0ba00 */

void FUN_00a0ba00(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  piVar8 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_005e5c70(-(uint)(param_2 != 0) & param_2 + 0xcU);
  if (iVar3 != 0) {
    piVar6 = piVar8 + 0xe;
    if (0xf < (uint)piVar8[0x13]) {
      piVar6 = (int *)*piVar6;
    }
    piVar4 = piVar8 + 8;
    if (0xf < (uint)piVar8[0xd]) {
      piVar4 = (int *)*piVar4;
    }
    piVar1 = piVar8 + 7;
    piVar2 = piVar8 + 6;
    if (0xf < (uint)piVar8[5]) {
      piVar8 = (int *)*piVar8;
    }
    uVar5 = FUN_01675640(aiStack_28,
                         "%s\'s commit failed with internal error: %s - Http status error (%d) %s, response body \'%s\'"
                         ,piVar8,*piVar2,*piVar1,piVar4,piVar6);
    uStack_8 = 0;
    FUN_0098c2c0(1,uVar5);
    if (0xf < uStack_14) {
      uVar7 = uStack_14 + 1;
      iVar3 = aiStack_28[0];
      if (0xfff < uVar7) {
        iVar3 = *(int *)(aiStack_28[0] + -4);
        uVar7 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar7);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19874 ; VA 0x00a0bad0 ; FUN_00a0bad0 */

void FUN_00a0bad0(undefined4 *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  piVar5 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005e5c70(-(uint)(param_2 != 0) & param_2 + 0xcU);
  if (iVar1 != 0) {
    piVar3 = piVar5 + 6;
    if (0xf < (uint)piVar5[0xb]) {
      piVar3 = (int *)*piVar3;
    }
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    uVar2 = FUN_01675640(aiStack_28,
                         "%s\'s commit failed with internal error: %s - unexpected scriptGuid: %s",
                         piVar5,PTR_s_Publish_Assets_01d65cac,piVar3);
    uStack_8 = 0;
    FUN_0098c2c0(1,uVar2);
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      iVar1 = aiStack_28[0];
      if (0xfff < uVar4) {
        iVar1 = *(int *)(aiStack_28[0] + -4);
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar1,uVar4);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19875 ; VA 0x00a0bb90 ; FUN_00a0bb90 */

/* WARNING: Removing unreachable block (ram,0x00a0bbd2) */
/* WARNING: Removing unreachable block (ram,0x00a0bbdf) */
/* WARNING: Removing unreachable block (ram,0x00a0bbec) */
/* WARNING: Removing unreachable block (ram,0x00a0bbfa) */
/* WARNING: Removing unreachable block (ram,0x00a0bc01) */

undefined4 FUN_00a0bb90(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017daa88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00602ce0(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19876 ; VA 0x00a0bc20 ; FUN_00a0bc20 */

void FUN_00a0bc20(undefined4 param_1,undefined4 param_2)

{
  FUN_00a05de0(param_2);
  return;
}



/* FUNCTION 19877 ; VA 0x00a0bc30 ; FUN_00a0bc30 */

/* WARNING: Removing unreachable block (ram,0x00a0bc72) */
/* WARNING: Removing unreachable block (ram,0x00a0bc7f) */
/* WARNING: Removing unreachable block (ram,0x00a0bc8c) */
/* WARNING: Removing unreachable block (ram,0x00a0bc9a) */
/* WARNING: Removing unreachable block (ram,0x00a0bca1) */

undefined4 FUN_00a0bc30(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017daa88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00602ce0(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19878 ; VA 0x00a0bcc0 ; FUN_00a0bcc0 */

int FUN_00a0bcc0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017daab8;
  pvStack_10 = ExceptionList;
  iStack_18 = 0;
  piStack_14 = (int *)0x0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00602ce0(param_1);
  iVar2 = iStack_18;
  uStack_8 = 0;
  if (iStack_18 != 0) {
    FUN_005e6780(*(undefined4 *)(param_1 + 8));
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    if (DAT_01d65a40 == '\0') {
      FUN_005542c0("Studio.TeamCreate.CollabEditVersionHistory.CommitRejected",0x39);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_008783f0(auStack_30,1,0);
    }
    else {
      uVar3 = *(undefined *)(iVar2 + 0x8d);
      FUN_005542c0("CommitRejected",0xe);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00a11370(auStack_30,uVar3);
    }
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_005507b0();
    iVar5 = FUN_0087c450("Studio","CollabEditVersionHistory","CommitRejected",1,0,0);
  }
  piVar4 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 19879 ; VA 0x00a0bde0 ; FUN_00a0bde0 */

void FUN_00a0bde0(undefined4 *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005e5c70(-(uint)(param_2 != 0) & param_2 + 0xcU);
  if (iVar1 != 0) {
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    uVar2 = FUN_01675640(aiStack_28,
                         "%s\'s commit failed with internal error: %s - no asset mapings available",
                         param_1,PTR_s_Asset_Mappings_01d65ca8);
    uStack_8 = 0;
    FUN_0098c2c0(1,uVar2);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      iVar1 = aiStack_28[0];
      if (0xfff < uVar3) {
        iVar1 = *(int *)(aiStack_28[0] + -4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar1,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19880 ; VA 0x00a0be90 ; FUN_00a0be90 */

void FUN_00a0be90(undefined4 *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005e5c70(-(uint)(param_2 != 0) & param_2 + 0xcU);
  if (iVar1 != 0) {
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    uVar2 = FUN_01675640(aiStack_28,
                         "%s\'s commit failed with internal error: %s - no StudioData available",
                         param_1,PTR_s_Save_Place_01d65cb4);
    uStack_8 = 0;
    FUN_0098c2c0(1,uVar2);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      iVar1 = aiStack_28[0];
      if (0xfff < uVar3) {
        iVar1 = *(int *)(aiStack_28[0] + -4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar1,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19881 ; VA 0x00a0bf40 ; FUN_00a0bf40 */

void FUN_00a0bf40(undefined4 param_1,undefined4 param_2)

{
  FUN_00a061a0(param_2);
  return;
}



/* FUNCTION 19882 ; VA 0x00a0bf50 ; FUN_00a0bf50 */

void FUN_00a0bf50(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  piVar7 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_005e5c70(-(uint)(param_2 != 0) & param_2 + 0xcU);
  if (iVar3 != 0) {
    piVar5 = piVar7 + 8;
    if (0xf < (uint)piVar7[0xd]) {
      piVar5 = (int *)*piVar5;
    }
    piVar1 = piVar7 + 7;
    piVar2 = piVar7 + 6;
    if (0xf < (uint)piVar7[5]) {
      piVar7 = (int *)*piVar7;
    }
    uVar4 = FUN_01675640(aiStack_28,
                         "%s\'s commit failed with internal error: %s - Http transport error (%d) %s"
                         ,piVar7,*piVar2,*piVar1,piVar5);
    uStack_8 = 0;
    FUN_0098c2c0(1,uVar4);
    if (0xf < uStack_14) {
      uVar6 = uStack_14 + 1;
      iVar3 = aiStack_28[0];
      if (0xfff < uVar6) {
        iVar3 = *(int *)(aiStack_28[0] + -4);
        uVar6 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar6);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19883 ; VA 0x00a0c020 ; FUN_00a0c020 */

void FUN_00a0c020(undefined4 *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005e5c70(-(uint)(param_2 != 0) & param_2 + 0xcU);
  if (iVar1 != 0) {
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    uVar2 = FUN_01675640(aiStack_28,
                         "%s\'s commit failed with internal error: %s - no commit guid provided",
                         param_1,PTR_s_Create_Commit_01d65934);
    uStack_8 = 0;
    FUN_0098c2c0(1,uVar2);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      iVar1 = aiStack_28[0];
      if (0xfff < uVar3) {
        iVar1 = *(int *)(aiStack_28[0] + -4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar1,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19884 ; VA 0x00a0c0d0 ; FUN_00a0c0d0 */

/* WARNING: Removing unreachable block (ram,0x00a0c112) */
/* WARNING: Removing unreachable block (ram,0x00a0c11f) */
/* WARNING: Removing unreachable block (ram,0x00a0c12c) */
/* WARNING: Removing unreachable block (ram,0x00a0c13a) */
/* WARNING: Removing unreachable block (ram,0x00a0c141) */

undefined4 FUN_00a0c0d0(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017daa88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00602ce0(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19885 ; VA 0x00a0c160 ; FUN_00a0c160 */

void FUN_00a0c160(undefined4 *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005e5c70(-(uint)(param_2 != 0) & param_2 + 0xcU);
  if (iVar1 != 0) {
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    uVar2 = FUN_01675640(aiStack_28,
                         "%s\'s commit failed with internal error: %s - cannot save new place version"
                         ,param_1,PTR_s_Save_Place_01d65cb4);
    uStack_8 = 0;
    FUN_0098c2c0(1,uVar2);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      iVar1 = aiStack_28[0];
      if (0xfff < uVar3) {
        iVar1 = *(int *)(aiStack_28[0] + -4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar1,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19886 ; VA 0x00a0c210 ; FUN_00a0c210 */

int * FUN_00a0c210(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0c2bb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0c24e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc7fe4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_03b17a397f7c0ac66631f5c5a475beb8>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19887 ; VA 0x00a0c2d0 ; FUN_00a0c2d0 */

int * FUN_00a0c2d0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0c37b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0c30e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc7e24);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_20f7cd9061f709306faa55839e5a76fe>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19888 ; VA 0x00a0c390 ; FUN_00a0c390 */

void FUN_00a0c390(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017daae7;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x34);
      uStack_8 = 0;
      if (iVar1 != 0) {
        FUN_0054ef60(iVar2);
        *(undefined4 *)(iVar1 + 0x18) = *(undefined4 *)(iVar2 + 0x18);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_0054ef60(iVar2 + 0x1c);
        *param_2 = iVar1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a04640();
        FUN_01674ea0(iVar2,0x34);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc816c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_35ca7f056213aeda51345091ef72e52f>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 19889 ; VA 0x00a0c4f0 ; FUN_00a0c4f0 */

int * FUN_00a0c4f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0c59b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0c52e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc7e94);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_41b294c8a4fd754e6b3bf3d4fe1e8fc8>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19890 ; VA 0x00a0c5b0 ; FUN_00a0c5b0 */

int * FUN_00a0c5b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0c65b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0c5ee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc7f74);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_4538535c519316b2c940911240373024>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19891 ; VA 0x00a0c670 ; FUN_00a0c670 */

int * FUN_00a0c670(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0c71b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0c6ae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc80c4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_478697d0188ca1383637f45aa0b6b90e>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19892 ; VA 0x00a0c730 ; FUN_00a0c730 */

void FUN_00a0c730(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dab22;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x50);
      uStack_8 = 0;
      if (iVar1 != 0) {
        FUN_0054ef60(iVar2);
        *(undefined4 *)(iVar1 + 0x18) = *(undefined4 *)(iVar2 + 0x18);
        *(undefined4 *)(iVar1 + 0x1c) = *(undefined4 *)(iVar2 + 0x1c);
        uStack_8._0_1_ = 1;
        FUN_0054ef60(iVar2 + 0x20);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_0054ef60(iVar2 + 0x38);
        *param_2 = iVar1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a046d0();
        FUN_01674ea0(iVar2,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc81a4);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_491df0a9dc411bf1cd8fbe106010d84d>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 19893 ; VA 0x00a0c8a0 ; FUN_00a0c8a0 */

void FUN_00a0c8a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dab47;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x30);
      uStack_8 = 0;
      if (iVar1 != 0) {
        FUN_0054ef60(iVar2);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_0054ef60(iVar2 + 0x18);
        *param_2 = iVar1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005509f0();
        FUN_01674ea0(iVar2,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc8054);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_6523394dbbda1b59e27ddc84487658d4>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 19894 ; VA 0x00a0ca00 ; FUN_00a0ca00 */

int * FUN_00a0ca00(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0caab. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0ca3e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc7ecc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_76e687cad09f283a067b9069bf351199>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19895 ; VA 0x00a0cac0 ; FUN_00a0cac0 */

int * FUN_00a0cac0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0cb6b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0cafe. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc801c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_86b695ef62433bb7a2698cb6d885a1a4>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19896 ; VA 0x00a0cb80 ; FUN_00a0cb80 */

int * FUN_00a0cb80(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0cc2b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0cbbe. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc7fac);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_959c1c01c6a7159c870c597fd62378cd>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19897 ; VA 0x00a0cc40 ; FUN_00a0cc40 */

int * FUN_00a0cc40(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0cceb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0cc7e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc7e5c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_a1f599733b2ab5f33435084adc4f928d>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19898 ; VA 0x00a0cd00 ; FUN_00a0cd00 */

int * FUN_00a0cd00(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0cdb1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0cd3e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc8214);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_a722f0e53b31ed2064079ff534ff66c3>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19899 ; VA 0x00a0cdd0 ; FUN_00a0cdd0 */

void FUN_00a0cdd0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_0054ef60(param_1);
      if (param_3 == 1) {
        uVar1 = param_1[5];
        if (0xf < uVar1) {
          iVar2 = *param_1;
          uVar5 = uVar1 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar1 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        param_1[4] = 0;
        param_1[5] = 0xf;
        *(undefined *)param_1 = 0;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_00571be0(0);
      return;
    }
    if (param_3 == 3) {
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc808c);
      piVar4 = (int *)0x0;
      if (iVar2 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_b0e32033ed1abc73c94e48b27768ec0f>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 19900 ; VA 0x00a0cea0 ; FUN_00a0cea0 */

void FUN_00a0cea0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_0054ef60(param_1);
      if (param_3 == 1) {
        uVar1 = param_1[5];
        if (0xf < uVar1) {
          iVar2 = *param_1;
          uVar5 = uVar1 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar1 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        param_1[4] = 0;
        param_1[5] = 0xf;
        *(undefined *)param_1 = 0;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_00571be0(0);
      return;
    }
    if (param_3 == 3) {
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc7f3c);
      piVar4 = (int *)0x0;
      if (iVar2 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_c0a6e3a64db89e4e4785a53443cc5108>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 19901 ; VA 0x00a0cf70 ; FUN_00a0cf70 */

int * FUN_00a0cf70(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0d01b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0cfae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc7db4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_c0b6a28e38daa3b2c4c4b9bb1e99ec65>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19902 ; VA 0x00a0d030 ; FUN_00a0d030 */

void FUN_00a0d030(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dab77;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        FUN_0054ef60(iVar2);
        *(undefined4 *)(iVar1 + 0x18) = *(undefined4 *)(iVar2 + 0x18);
        *(undefined4 *)(iVar1 + 0x1c) = *(undefined4 *)(iVar2 + 0x1c);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_0054ef60(iVar2 + 0x20);
        *param_2 = iVar1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a047b0();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc81dc);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_c34333f0e2de97391d0b35740c2f5af8>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 19903 ; VA 0x00a0d190 ; FUN_00a0d190 */

int * FUN_00a0d190(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0d23b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0d1ce. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc7dec);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_cccba1f7d816c9159ac90d35f496c0e3>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19904 ; VA 0x00a0d250 ; FUN_00a0d250 */

void FUN_00a0d250(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_0054ef60(param_1);
      if (param_3 == 1) {
        uVar1 = param_1[5];
        if (0xf < uVar1) {
          iVar2 = *param_1;
          uVar5 = uVar1 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar1 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        param_1[4] = 0;
        param_1[5] = 0xf;
        *(undefined *)param_1 = 0;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_00571be0(0);
      return;
    }
    if (param_3 == 3) {
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc80fc);
      piVar4 = (int *)0x0;
      if (iVar2 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_d0bed8cc2bed2d8e2a2395023c9749ee>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 19905 ; VA 0x00a0d320 ; FUN_00a0d320 */

int * FUN_00a0d320(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0d3cb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a0d35e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc8134);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_e717d8c9f560c242d5d6ae220b19ee69>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19906 ; VA 0x00a0d3e0 ; FUN_00a0d3e0 */

void FUN_00a0d3e0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_0054ef60(param_1);
      if (param_3 == 1) {
        uVar1 = param_1[5];
        if (0xf < uVar1) {
          iVar2 = *param_1;
          uVar5 = uVar1 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar1 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        param_1[4] = 0;
        param_1[5] = 0xf;
        *(undefined *)param_1 = 0;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_00571be0(0);
      return;
    }
    if (param_3 == 3) {
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc7f04);
      piVar4 = (int *)0x0;
      if (iVar2 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_fab5433f5b1c23cbdd55ddf98aee83c5>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 19907 ; VA 0x00a0d4b0 ; FUN_00a0d4b0 */

uint __thiscall FUN_00a0d4b0(int param_1,int param_2,int param_3,undefined4 param_4,char param_5)

{
  char cVar1;
  uint uVar2;
  char *pcVar3;
  undefined auStack_94 [24];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined auStack_74 [16];
  undefined4 uStack_64;
  int iStack_60;
  undefined auStack_5c [24];
  undefined uStack_44;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined uStack_2c;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dac22;
  pvStack_10 = ExceptionList;
  iStack_14 = param_1;
  if (param_2 == 0) {
    uVar2 = *(int *)(param_3 + 0xc) - 200;
    if ((uVar2 < 100) && (*(int *)(param_3 + 0xc) != 0xca)) {
      return CONCAT31((int3)(uVar2 >> 8),1);
    }
    ExceptionList = &pvStack_10;
    if (DAT_01d84e8e != '\0') {
      ExceptionList = &pvStack_10;
      FUN_01677520();
    }
    uVar2 = FUN_00a11240();
    if (DAT_01ee5c38 == 0) goto LAB_00a0d900;
    if (*(int *)(param_1 + 0x24) == 0) {
      pcVar3 = "someone";
    }
    else {
      pcVar3 = *(char **)(*(int *)(param_1 + 0x24) + 0x28);
      if (0xf < *(uint *)(pcVar3 + 0x14)) {
        pcVar3 = *(char **)pcVar3;
      }
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = 0;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0();
    uStack_78 = *(undefined4 *)(param_3 + 0xc);
    uStack_8 = 5;
    if (*(int *)(param_3 + 0x84) == 0) {
      pcVar3 = "";
    }
    else {
      pcVar3 = (char *)(param_3 + 0x74);
      if (0xf < *(uint *)(param_3 + 0x88)) {
        pcVar3 = *(char **)pcVar3;
      }
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    uStack_44 = 0;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0();
    uStack_8._0_1_ = 6;
    FUN_0054ef60();
    uStack_8._0_1_ = 7;
    FUN_0054ef60();
    uStack_8._0_1_ = 8;
    FUN_0054ef60();
    uStack_8._0_1_ = 9;
    FUN_0054ef60();
    uStack_8._0_1_ = 10;
    FUN_0054ef60();
    uStack_7c = param_4;
    uStack_8._0_1_ = 0xb;
    FUN_0054ef60();
    uStack_8._0_1_ = 0xc;
    FUN_0054ef60();
    uStack_8._0_1_ = 0xd;
    FUN_0054ef60(auStack_94);
    uStack_8._0_1_ = 0xe;
    FUN_0054ef60(auStack_74);
    uStack_8._0_1_ = 0xf;
    FUN_0054ef60(auStack_5c);
    uStack_8._0_1_ = 0xd;
    FUN_00a038a0();
    FUN_00a046d0();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00a046d0();
    FUN_0090ca30();
    FUN_005507b0();
    FUN_005507b0();
  }
  else {
    ExceptionList = &pvStack_10;
    if (DAT_01d84e8e != '\0') {
      ExceptionList = &pvStack_10;
      FUN_01677520();
    }
    uVar2 = FUN_00a11240();
    if (DAT_01ee5c38 == 0) goto LAB_00a0d900;
    if (*(int *)(param_1 + 0x24) == 0) {
      pcVar3 = "someone";
    }
    else {
      pcVar3 = *(char **)(*(int *)(param_1 + 0x24) + 0x28);
      if (0xf < *(uint *)(pcVar3 + 0x14)) {
        pcVar3 = *(char **)pcVar3;
      }
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    uStack_44 = 0;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0();
    uStack_8 = 0;
    if (*(int *)(param_3 + 0x84) == 0) {
      pcVar3 = "";
    }
    else {
      pcVar3 = (char *)(param_3 + 0x74);
      if (0xf < *(uint *)(param_3 + 0x88)) {
        pcVar3 = *(char **)pcVar3;
      }
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = 0;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0();
    uStack_8._0_1_ = 1;
    FUN_0054ef60();
    uStack_64 = param_4;
    iStack_60 = param_2;
    uStack_8._0_1_ = 2;
    FUN_0054ef60();
    uStack_8._0_1_ = 3;
    FUN_0054ef60();
    uStack_8._0_1_ = 4;
    FUN_0054ef60();
    uStack_8._0_1_ = 3;
    FUN_00a02d90();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00a047b0();
    FUN_0090ca30();
    FUN_005507b0();
  }
  uStack_8 = 0xffffffff;
  uVar2 = FUN_005507b0();
LAB_00a0d900:
  if (param_5 != '\0') {
    uVar2 = FUN_00a11160();
  }
  ExceptionList = pvStack_10;
  return uVar2 & 0xffffff00;
}



/* FUNCTION 19908 ; VA 0x00a0d930 ; FUN_00a0d930 */

undefined4 __thiscall FUN_00a0d930(int param_1)

{
  char cVar1;
  char *pcVar2;
  char in_stack_00000010;
  undefined auStack_44 [24];
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dac58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  cVar1 = FUN_00a0d4b0();
  if (cVar1 != '\0') {
    cVar1 = FUN_0098f070();
    if (cVar1 != '\0') {
      ExceptionList = pvStack_10;
      return 1;
    }
    if (DAT_01d84e8e != '\0') {
      FUN_01677520();
    }
    if (0 < DAT_01ee6bc8) {
      FUN_0151f6f0();
      uStack_8 = 0;
      FUN_0151f850();
      uStack_1c = 0;
      uStack_18 = 0xf;
      auStack_2c[0] = 0;
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_01520d20();
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      FUN_0151f7f0();
    }
    if (DAT_01ee5c38 != 0) {
      if (*(int *)(param_1 + 0x24) == 0) {
        pcVar2 = "someone";
      }
      else {
        pcVar2 = *(char **)(*(int *)(param_1 + 0x24) + 0x28);
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar2 = *(char **)pcVar2;
        }
      }
      uStack_1c = 0;
      uStack_18 = 0xf;
      auStack_2c[0] = 0;
      do {
        cVar1 = *pcVar2;
        pcVar2 = pcVar2 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0();
      uStack_8 = 2;
      FUN_0054ef60();
      uStack_8._0_1_ = 3;
      FUN_0054ef60(auStack_2c);
      uStack_8._0_1_ = 4;
      FUN_0054ef60(auStack_44);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_00a01dc0();
      FUN_0090ca30();
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    if (in_stack_00000010 != '\0') {
      FUN_00a11160();
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 19909 ; VA 0x00a0db30 ; FUN_00a0db30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00a0db30(int param_1)

{
  undefined4 ****ppppuVar1;
  int *piVar2;
  undefined8 uVar3;
  int *piVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined auVar8 [16];
  undefined auVar9 [16];
  void *pvVar10;
  undefined (*pauVar11) [16];
  undefined uVar12;
  undefined3 uVar13;
  undefined uVar14;
  undefined4 *puVar15;
  undefined4 ****ppppuVar16;
  undefined **ppuVar17;
  int iVar18;
  uint uVar19;
  undefined4 uVar20;
  undefined4 *puVar21;
  undefined4 *puVar22;
  undefined **ppuVar23;
  undefined *puVar24;
  undefined ***pppuVar25;
  uint uVar26;
  uint *puVar27;
  int *piVar28;
  float10 fVar29;
  undefined4 uStack_284;
  undefined *puStack_280;
  undefined4 uStack_27c;
  int *piStack_278;
  undefined auStack_1b4 [24];
  int iStack_19c;
  int iStack_198;
  undefined4 ***apppuStack_17c [5];
  uint uStack_168;
  int iStack_164;
  int iStack_160;
  uint uStack_15c;
  double dStack_13c;
  uint auStack_134 [4];
  undefined4 uStack_124;
  uint uStack_120;
  uint auStack_11c [4];
  undefined4 uStack_10c;
  uint uStack_108;
  undefined4 uStack_104;
  int *piStack_100;
  undefined *puStack_fc;
  undefined *puStack_f8;
  undefined4 ***pppuStack_f4;
  undefined4 **ppuStack_f0;
  undefined4 **ppuStack_ec;
  undefined4 **ppuStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined **ppuStack_d4;
  undefined4 uStack_d0;
  int *piStack_cc;
  int iStack_c8;
  uint auStack_c4 [4];
  undefined4 uStack_b4;
  undefined ***pppuStack_b0;
  uint auStack_ac [4];
  undefined4 uStack_9c;
  uint uStack_98;
  uint uStack_94;
  int iStack_90;
  uint auStack_8c [4];
  undefined4 uStack_7c;
  uint uStack_78;
  undefined auStack_74 [16];
  uint *puStack_64;
  uint *puStack_60;
  undefined8 uStack_5c;
  int iStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  int iStack_48;
  int iStack_44;
  uint *puStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  uint uStack_34;
  int *piStack_30;
  int iStack_2c;
  uint uStack_28;
  uint *puStack_24;
  char cStack_1d;
  uint *puStack_1c;
  uint *puStack_18;
  undefined (*pauStack_14) [16];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dada9;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  iStack_2c = param_1;
  if (DAT_01ee6bcc != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee6bcc,"Commit: %s",PTR_s_Instance_Changes_01d65cb0);
  }
  puVar15 = (undefined4 *)FUN_016830f0();
  *(undefined4 *)(param_1 + 0xa0) = *puVar15;
  *(undefined4 *)(param_1 + 0xa4) = puVar15[1];
  FUN_008c0cc0(&uStack_104,param_1);
  uStack_e4 = 0xf00000000;
  pppuStack_f4 = (undefined4 ***)((uint)pppuStack_f4 & 0xffffff00);
  uStack_8._1_3_ = 0;
  uVar13 = uStack_8._1_3_;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if ((DAT_01d658cc < 1) || (DAT_01d658f0 < DAT_01d658cc)) {
    cStack_1d = '\0';
    uStack_8._1_3_ = uVar13;
    FUN_0054ef60(param_1 + 0x70);
    ppppuVar16 = (undefined4 ****)FUN_00fb7d50(auStack_c4);
    uStack_8._0_1_ = 8;
    if (&pppuStack_f4 != ppppuVar16) {
      ppppuVar1 = ppppuVar16 + 4;
      if ((undefined4 ***)0xf < ppppuVar16[5]) {
        ppppuVar16 = (undefined4 ****)*ppppuVar16;
      }
      FUN_005542c0(ppppuVar16,*ppppuVar1);
    }
    uStack_8._0_1_ = 1;
    uVar14 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (&DAT_0000000f < pppuStack_b0) {
      pppuVar25 = (undefined ***)((int)pppuStack_b0 + 1);
      uVar19 = auStack_c4[0];
      if ((undefined ***)0xfff < pppuVar25) {
        uVar19 = *(uint *)(auStack_c4[0] - 4);
        pppuVar25 = pppuStack_b0 + 9;
        if (0x1f < (auStack_c4[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar14;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,pppuVar25);
      uVar14 = (undefined)uStack_8;
    }
  }
  else {
    cStack_1d = '\x01';
    uStack_7c = 0;
    uStack_78 = 0xf;
    auStack_8c[0] = auStack_8c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 2;
    puStack_64 = (uint *)0x0;
    puStack_60 = (uint *)&DAT_0000000f;
    auVar8[0xf] = 0;
    auVar8._0_15_ = auStack_74._1_15_;
    auStack_74 = auVar8 << 8;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 3;
    uStack_9c = 0;
    uStack_98 = 0xf;
    auStack_ac[0] = auStack_ac[0] & 0xffffff00;
    FUN_005542c0("universe-history-mock/commits/200/instance-changes",0x32);
    uStack_8._0_1_ = 4;
    uStack_124 = 0;
    uStack_120 = 0xf;
    auStack_134[0] = auStack_134[0] & 0xffffff00;
    FUN_005542c0("apis.simulpong.com",0x12);
    uStack_8._0_1_ = 5;
    uStack_10c = 0;
    uStack_108 = 0xf;
    auStack_11c[0] = auStack_11c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c71bc,4);
    uStack_8._0_1_ = 6;
    FUN_0151bcc0(auStack_1b4,auStack_11c,auStack_134,auStack_ac,auStack_74,auStack_8c);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    ppppuVar16 = (undefined4 ****)FUN_0151bb70();
    if (&pppuStack_f4 != ppppuVar16) {
      FUN_005507b0();
      pppuStack_f4 = *ppppuVar16;
      ppuStack_f0 = ppppuVar16[1];
      ppuStack_ec = ppppuVar16[2];
      ppuStack_e8 = ppppuVar16[3];
      uStack_e4 = *(undefined8 *)(ppppuVar16 + 4);
      ppppuVar16[4] = (undefined4 ***)0x0;
      ppppuVar16[5] = (undefined4 ***)0xf;
      *(undefined *)ppppuVar16 = 0;
    }
    if (&DAT_0000000f < pppuStack_b0) {
      pppuVar25 = (undefined ***)((int)pppuStack_b0 + 1);
      uVar19 = auStack_c4[0];
      if ((undefined ***)0xfff < pppuVar25) {
        uVar19 = *(uint *)(auStack_c4[0] - 4);
        pppuVar25 = pppuStack_b0 + 9;
        if (0x1f < (auStack_c4[0] - uVar19) - 4) {
LAB_00a0f010:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,pppuVar25);
    }
    uStack_b4 = 0;
    pppuStack_b0 = (undefined ***)&DAT_0000000f;
    auStack_c4[0] = auStack_c4[0] & 0xffffff00;
    FUN_0056d9d0();
    uStack_8._0_1_ = 5;
    if (0xf < uStack_108) {
      uVar26 = uStack_108 + 1;
      uVar19 = auStack_11c[0];
      if (0xfff < uVar26) {
        uVar19 = *(uint *)(auStack_11c[0] - 4);
        uVar26 = uStack_108 + 0x24;
        if (0x1f < (auStack_11c[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar26);
    }
    uStack_10c = 0;
    uStack_108 = 0xf;
    auStack_11c[0] = auStack_11c[0] & 0xffffff00;
    uStack_8._0_1_ = 4;
    uVar14 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_120) {
      uVar26 = uStack_120 + 1;
      uVar19 = auStack_134[0];
      if (0xfff < uVar26) {
        uVar19 = *(uint *)(auStack_134[0] - 4);
        uVar26 = uStack_120 + 0x24;
        if (0x1f < (auStack_134[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar14;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar26);
    }
    uStack_124 = 0;
    uStack_120 = 0xf;
    auStack_134[0] = auStack_134[0] & 0xffffff00;
    uStack_8._0_1_ = 3;
    uVar14 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_98) {
      uVar26 = uStack_98 + 1;
      uVar19 = auStack_ac[0];
      if (0xfff < uVar26) {
        uVar19 = *(uint *)(auStack_ac[0] - 4);
        uVar26 = uStack_98 + 0x24;
        if (0x1f < (auStack_ac[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar14;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar26);
    }
    uStack_9c = 0;
    uStack_98 = 0xf;
    auStack_ac[0] = auStack_ac[0] & 0xffffff00;
    uStack_8._0_1_ = 2;
    uVar14 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (&DAT_0000000f < puStack_60) {
      puVar27 = (uint *)((int)puStack_60 + 1);
      iVar18 = auStack_74._0_4_;
      if ((uint *)0xfff < puVar27) {
        iVar18 = *(int *)(auStack_74._0_4_ + -4);
        puVar27 = puStack_60 + 9;
        if (0x1f < (auStack_74._0_4_ - iVar18) - 4U) {
          uStack_8._0_1_ = uVar14;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar18,puVar27);
    }
    puStack_64 = (uint *)0x0;
    puStack_60 = (uint *)&DAT_0000000f;
    auVar9[0xf] = 0;
    auVar9._0_15_ = auStack_74._1_15_;
    auStack_74 = auVar9 << 8;
    uStack_8._0_1_ = 1;
    uVar12 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    param_1 = iStack_2c;
    uVar14 = (undefined)uStack_8;
    if (0xf < uStack_78) {
      uVar26 = uStack_78 + 1;
      uVar19 = auStack_8c[0];
      if (0xfff < uVar26) {
        uVar19 = *(uint *)(auStack_8c[0] - 4);
        uVar26 = uStack_78 + 0x24;
        if (0x1f < (auStack_8c[0] - uVar19) - 4) {
          uStack_8._0_1_ = uVar12;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar26);
      param_1 = iStack_2c;
      uVar14 = (undefined)uStack_8;
    }
  }
  uStack_8._0_1_ = uVar14;
  if (DAT_01d65910 < 2) {
    iStack_54 = 1;
  }
  else {
    iStack_54 = DAT_01d65910;
    if (0x19 < DAT_01d65910) {
      iStack_54 = 0x19;
    }
  }
  uStack_5c = ((double)*(int *)(param_1 + 0x40) +
              (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 0x40) >> 0x1f)]) / (double)iStack_54;
  fVar29 = (float10)FUN_01725160(uStack_5c);
  dStack_13c = (double)fVar29;
  iStack_90 = 0;
  iStack_48 = 0;
  uStack_50 = 0;
  piStack_4c = (int *)0x0;
  uStack_34 = 0;
  piStack_30 = (int *)0x0;
  piVar4 = *(int **)(param_1 + 0x3c);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  piVar28 = (int *)*piVar4;
  if (piVar28 != piVar4) {
    do {
      pauStack_14 = (undefined (*) [16])(piVar28 + 2);
      puStack_1c = (uint *)piVar28[6];
      puStack_64 = (uint *)0x0;
      puStack_60 = (uint *)0x0;
      if (0xf < (uint)piVar28[7]) {
        pauStack_14 = *(undefined (**) [16])*pauStack_14;
      }
      if (&DAT_0000000f < puStack_1c) {
        puStack_24 = (uint *)((uint)puStack_1c | 0xf);
        if ((uint *)0x7fffffff < puStack_24) {
          puStack_24 = (uint *)0x7fffffff;
        }
        if ((undefined *)((int)puStack_24 + 1) < &DAT_00001000) {
          if (puStack_24 == (uint *)0xffffffff) {
            uVar19 = 0;
          }
          else {
            uVar19 = FUN_01674e20();
          }
        }
        else {
          iVar18 = FUN_01674e20();
          if (iVar18 == 0) goto LAB_00a0f010;
          uVar19 = iVar18 + 0x23U & 0xffffffe0;
          *(int *)(uVar19 - 4) = iVar18;
        }
        auStack_74._0_4_ = uVar19;
        FUN_0170c6f0(uVar19,pauStack_14,(undefined *)((int)puStack_1c + 1));
        puStack_60 = puStack_24;
      }
      else {
        auStack_74 = *pauStack_14;
        puStack_60 = (uint *)&DAT_0000000f;
      }
      iStack_198 = piVar28[9];
      if (iStack_198 != 0) {
        LOCK();
        *(int *)(iStack_198 + 4) = *(int *)(iStack_198 + 4) + 1;
        UNLOCK();
        iStack_198 = piVar28[9];
      }
      iStack_19c = piVar28[8];
      uStack_8._0_1_ = 0xc;
      puStack_64 = puStack_1c;
      FUN_0054ef60();
      uStack_8._0_1_ = 0xd;
      FUN_0054ef60();
      iStack_164 = piVar28[0x16];
      iStack_160 = piVar28[0x17];
      uStack_15c = piVar28[0x18];
      uStack_8._0_1_ = 0xe;
      FUN_0054ef60();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
      puStack_f8 = (undefined *)FUN_01674e20();
      if (puStack_f8 == (undefined *)0x0) {
        puVar24 = (undefined *)0x0;
      }
      else {
        *puStack_f8 = 0;
        pauStack_14 = (undefined (*) [16])&DAT_0000000b;
        ppuVar17 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr);
        ppuVar23 = (undefined **)&DAT_018be194;
        if (ppuVar17 != &boost::lock_error::vftable_meta_ptr) {
          ppuVar23 = ppuVar17;
        }
        *(undefined **)(puStack_f8 + 4) = *ppuVar23;
        *(undefined4 *)(puStack_f8 + 8) = 0;
        *(undefined4 *)(puStack_f8 + 0xc) = 0x3f800000;
        *(undefined4 *)(puStack_f8 + 0x10) = 0;
        *(undefined4 *)(puStack_f8 + 0x14) = 0;
        puVar24 = puStack_f8;
      }
      uStack_3c = 0;
      piStack_38 = (int *)0x0;
      FUN_005c1af0(puVar24,puStack_18);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
      if (iStack_48 == 0) {
        puStack_fc = (undefined *)FUN_01674e20();
        if (puStack_fc == (undefined *)0x0) {
          puVar24 = (undefined *)0x0;
        }
        else {
          *puStack_fc = 0;
          pauStack_14 = (undefined (*) [16])&DAT_0000000b;
          ppuVar17 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr);
          ppuVar23 = (undefined **)&DAT_018be194;
          if (ppuVar17 != &boost::lock_error::vftable_meta_ptr) {
            ppuVar23 = ppuVar17;
          }
          *(undefined **)(puStack_fc + 4) = *ppuVar23;
          *(undefined4 *)(puStack_fc + 8) = 0;
          *(undefined4 *)(puStack_fc + 0xc) = 0x3f800000;
          *(undefined4 *)(puStack_fc + 0x10) = 0;
          *(undefined4 *)(puStack_fc + 0x14) = 0;
          puVar24 = puStack_fc;
        }
        uStack_dc = 0;
        piStack_d8 = (int *)0x0;
        FUN_005c1af0(puVar24,puStack_18);
        piVar2 = piStack_4c;
        uStack_50 = uStack_dc;
        pauStack_14 = (undefined (*) [16])piStack_4c;
        piStack_4c = piStack_d8;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar18 = piVar2[1] + -1;
          piVar2[1] = iVar18;
          UNLOCK();
          if (iVar18 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar18 = *(int *)((int)pauStack_14 + 8) + -1;
            *(int *)((int)pauStack_14 + 8) = iVar18;
            UNLOCK();
            if (iVar18 == 0) {
              (**(code **)(*(int *)pauStack_14 + 4))();
            }
          }
        }
        puVar15 = (undefined4 *)FUN_01674e20();
        if (puVar15 == (undefined4 *)0x0) {
          puVar15 = (undefined4 *)0x0;
        }
        else {
          *puVar15 = 0;
          puVar15[1] = 0;
          puVar15[2] = 0;
        }
        uStack_5c = 0.0;
        FUN_006047e0(puVar15,puStack_18);
        piVar2 = piStack_30;
        uStack_34 = (uint)uStack_5c;
        pauStack_14 = (undefined (*) [16])piStack_30;
        piStack_30 = uStack_5c._4_4_;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar18 = piVar2[1] + -1;
          piVar2[1] = iVar18;
          UNLOCK();
          if (iVar18 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar18 = *(int *)((int)pauStack_14 + 8) + -1;
            *(int *)((int)pauStack_14 + 8) = iVar18;
            UNLOCK();
            if (iVar18 == 0) {
              (**(code **)(*(int *)pauStack_14 + 4))();
            }
          }
        }
        if (DAT_01d65a48 == '\0') {
          iVar18 = FUN_005c4c00();
          puStack_1c = (uint *)(iVar18 + 0x18);
          uVar19 = FUN_008882f0();
          iVar18 = _tls_index;
          *puStack_1c = uVar19;
          if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar18 * 4) + 0x34) < DAT_01ea8cd0
              ) && (FUN_016f3809(), DAT_01ea8cd0 == -1)) {
            _DAT_01ea8cc4 = FUN_0057bbb0;
            _DAT_01ea8cc8 = FUN_005880a0;
            DAT_01ea8ccc = FUN_0057d5e0;
            FUN_016f37bf();
          }
          puVar24 = (undefined *)puStack_1c[1];
          if (puVar24 != &DAT_01ea8cc4) goto LAB_00a0e4b9;
          if (piStack_30 != (int *)0x0) {
            LOCK();
            piStack_30[1] = piStack_30[1] + 1;
            UNLOCK();
          }
          puStack_1c[2] = uStack_34;
          pauStack_14 = (undefined (*) [16])puStack_1c[3];
          puStack_1c[3] = (uint)piStack_30;
          if (pauStack_14 != (undefined (*) [16])0x0) {
            LOCK();
            iVar18 = *(int *)((int)pauStack_14 + 4) + -1;
            *(int *)((int)pauStack_14 + 4) = iVar18;
            UNLOCK();
            if (iVar18 == 0) {
              (*(code *)**(undefined4 **)pauStack_14)();
              goto LAB_00a0e4a8;
            }
          }
        }
        else {
          iVar18 = FUN_005c4c00();
          puStack_1c = (uint *)(iVar18 + 0x18);
          uVar19 = FUN_008882f0();
          iVar18 = _tls_index;
          *puStack_1c = uVar19;
          if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar18 * 4) + 0x34) < DAT_01ea8cd0
              ) && (FUN_016f3809(), DAT_01ea8cd0 == -1)) {
            _DAT_01ea8cc4 = FUN_0057bbb0;
            _DAT_01ea8cc8 = FUN_005880a0;
            DAT_01ea8ccc = FUN_0057d5e0;
            FUN_016f37bf();
          }
          puVar24 = (undefined *)puStack_1c[1];
          if (puVar24 == &DAT_01ea8cc4) {
            if (piStack_30 != (int *)0x0) {
              LOCK();
              piStack_30[1] = piStack_30[1] + 1;
              UNLOCK();
            }
            puStack_1c[2] = uStack_34;
            pauStack_14 = (undefined (*) [16])puStack_1c[3];
            puStack_1c[3] = (uint)piStack_30;
            if (pauStack_14 != (undefined (*) [16])0x0) {
              LOCK();
              iVar18 = *(int *)((int)pauStack_14 + 4) + -1;
              *(int *)((int)pauStack_14 + 4) = iVar18;
              UNLOCK();
              if (iVar18 == 0) {
                (*(code *)**(undefined4 **)pauStack_14)();
LAB_00a0e4a8:
                LOCK();
                iVar18 = *(int *)((int)pauStack_14 + 8) + -1;
                *(int *)((int)pauStack_14 + 8) = iVar18;
                UNLOCK();
                if (iVar18 == 0) {
                  (**(code **)(*(int *)pauStack_14 + 4))();
                }
              }
            }
          }
          else {
LAB_00a0e4b9:
            if (puVar24 != (undefined *)0x0) {
              (**(code **)(puVar24 + 8))();
              puStack_1c[1] = 0;
            }
            puStack_1c[3] = 0;
            puStack_1c[2] = 0;
            if (piStack_30 != (int *)0x0) {
              LOCK();
              piStack_30[1] = piStack_30[1] + 1;
              UNLOCK();
            }
            puStack_1c[2] = uStack_34;
            puStack_1c[3] = (uint)piStack_30;
            puStack_1c[1] = (uint)&DAT_01ea8cc4;
          }
        }
      }
      if (cStack_1d == '\0') {
        piVar2 = *(int **)(*(int *)(iStack_2c + 0x1c) + 0x43c);
        puStack_24 = (uint *)(*piVar2 - (int)piVar2);
        pauStack_14 = (undefined (*) [16])(piVar2[1] - (int)piVar2);
      }
      else {
        puStack_24 = (uint *)0xc8;
        pauStack_14 = (undefined (*) [16])0x0;
      }
      iVar18 = FUN_005c4c00();
      puStack_1c = (uint *)(iVar18 + 0x18);
      uVar19 = FUN_0088da50();
      *puStack_1c = uVar19;
      puStack_18 = (uint *)FUN_005c9e80();
      uVar19 = puStack_1c[1];
      if ((uint *)uVar19 == puStack_18) {
        puStack_1c[2] = (uint)puStack_24;
        puStack_1c[3] = (uint)pauStack_14;
      }
      else {
        if (uVar19 != 0) {
          (**(code **)(uVar19 + 8))();
        }
        puStack_1c[2] = (uint)puStack_24;
        puStack_1c[3] = (uint)pauStack_14;
        puStack_1c[1] = (uint)puStack_18;
      }
      iVar18 = FUN_005c4c00();
      puStack_18 = (uint *)(iVar18 + 0x18);
      uVar20 = FUN_0088cb40();
      *puStack_18 = uVar20;
      FUN_005c17a0();
      if (cStack_1d == '\0') {
        uStack_7c = 0;
        uStack_78 = 0xf;
        auStack_8c[0] = auStack_8c[0] & 0xffffff00;
        FUN_005542c0("Update",6);
        uStack_28 = uStack_28 | 2;
        puStack_24 = auStack_8c;
        uStack_8 = 0x12;
      }
      else {
        uStack_9c = 0;
        uStack_98 = 0xf;
        auStack_ac[0] = auStack_ac[0] & 0xffffff00;
        FUN_005542c0(&DAT_0193f01c,3);
        uStack_28 = uStack_28 | 1;
        puStack_24 = auStack_ac;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
      }
      iVar18 = FUN_005c4c00();
      pauStack_14 = (undefined (*) [16])(iVar18 + 0x18);
      uVar20 = FUN_0088cb40();
      *(undefined4 *)*pauStack_14 = uVar20;
      puStack_18 = (uint *)FUN_005c9d30();
      puVar27 = *(uint **)(*pauStack_14 + 4);
      if (puVar27 == puStack_18) {
        puStack_18 = (uint *)(*pauStack_14 + 8);
        if (puStack_18 != puStack_24) {
          if (0xf < *(uint *)(pauStack_14[1] + 0xc)) {
            uVar19 = *puStack_18;
            uVar26 = uVar19;
            if ((0xfff < *(uint *)(pauStack_14[1] + 0xc) + 1) &&
               (uVar26 = *(uint *)(uVar19 - 4), 0x1f < (uVar19 - uVar26) - 4)) goto LAB_00a0f010;
            FUN_01674ea0(uVar26);
          }
          uVar19 = *puStack_24;
          uVar26 = puStack_24[1];
          uVar6 = puStack_24[2];
          uVar7 = puStack_24[3];
          puStack_18[4] = 0;
          puStack_18[5] = 0xf;
          *puStack_18 = uVar19;
          puStack_18[1] = uVar26;
          puStack_18[2] = uVar6;
          puStack_18[3] = uVar7;
          uVar3 = *(undefined8 *)(puStack_24 + 4);
          puStack_24[4] = 0;
          puStack_24[5] = 0xf;
          *(undefined8 *)(puStack_18 + 4) = uVar3;
          *(undefined *)puStack_24 = 0;
        }
      }
      else {
        if (puVar27 != (uint *)0x0) {
          (*(code *)puVar27[2])();
        }
        pauVar11 = pauStack_14;
        puVar27 = puStack_24;
        *(undefined4 *)(pauStack_14[1] + 8) = 0;
        *(undefined4 *)(pauStack_14[1] + 0xc) = 0;
        uVar19 = puStack_24[1];
        uVar26 = puStack_24[2];
        uVar6 = puStack_24[3];
        *(uint *)(*pauStack_14 + 8) = *puStack_24;
        *(uint *)(*pauStack_14 + 0xc) = uVar19;
        *(uint *)pauStack_14[1] = uVar26;
        *(uint *)(pauStack_14[1] + 4) = uVar6;
        uVar3 = *(undefined8 *)(puStack_24 + 4);
        puStack_24[4] = 0;
        puVar27[5] = 0xf;
        *(undefined *)puVar27 = 0;
        *(undefined8 *)(pauVar11[1] + 8) = uVar3;
        *(uint **)(*pauVar11 + 4) = puStack_18;
      }
      uStack_8 = 0x11;
      if (((uStack_28 & 2) != 0) && (uStack_28 = uStack_28 & 0xfffffffd, 0xf < uStack_78)) {
        uVar19 = auStack_8c[0];
        if ((0xfff < uStack_78 + 1) &&
           (uVar19 = *(uint *)(auStack_8c[0] - 4), 0x1f < (auStack_8c[0] - uVar19) - 4))
        goto LAB_00a0f010;
        FUN_01674ea0(uVar19);
      }
      uStack_8 = 0x10;
      if (((uStack_28 & 1) != 0) && (uStack_28 = uStack_28 & 0xfffffffe, 0xf < uStack_98)) {
        uVar19 = auStack_ac[0];
        if ((0xfff < uStack_98 + 1) &&
           (uVar19 = *(uint *)(auStack_ac[0] - 4), 0x1f < (auStack_ac[0] - uVar19) - 4))
        goto LAB_00a0f010;
        FUN_01674ea0(uVar19);
      }
      if (DAT_01d65a48 == '\0') {
        iVar18 = FUN_005c4c00();
        pauStack_14 = (undefined (*) [16])(iVar18 + 0x18);
        uVar20 = FUN_0088da50();
        *(undefined4 *)*pauStack_14 = uVar20;
        puStack_18 = (uint *)FUN_005c9e80();
        puVar27 = *(uint **)(*pauStack_14 + 4);
        if (puVar27 == puStack_18) {
          *(int *)(*pauStack_14 + 8) = iStack_164;
          *(int *)(*pauStack_14 + 0xc) = iStack_160;
        }
        else {
          if (puVar27 != (uint *)0x0) {
            (*(code *)puVar27[2])();
            *(undefined4 *)(*pauStack_14 + 4) = 0;
          }
          *(int *)(*pauStack_14 + 8) = iStack_164;
          *(int *)(*pauStack_14 + 0xc) = iStack_160;
          *(uint **)(*pauStack_14 + 4) = puStack_18;
        }
        iVar18 = FUN_005c4c00();
        puStack_1c = (uint *)(iVar18 + 0x18);
        uVar19 = FUN_0088c8c0();
        pvVar10 = ThreadLocalStoragePointer;
        *puStack_1c = uVar19;
        puStack_24 = *(uint **)((int)pvVar10 + _tls_index * 4);
        if (((int)puStack_24[0xd] < DAT_01ea8c18) && (FUN_016f3809(), DAT_01ea8c18 == -1)) {
          DAT_01ea8c0c = FUN_005c65e0;
          DAT_01ea8c10 = FUN_005c65e0;
          DAT_01ea8c14 = _guard_check_icall;
          FUN_016f37bf();
        }
        puVar15 = (undefined4 *)puStack_1c[1];
        if ((code **)puVar15 != &DAT_01ea8c0c) {
          if (puVar15 != (undefined4 *)0x0) {
            (*(code *)puVar15[2])();
            puStack_1c[1] = 0;
          }
          puStack_1c[2] = uStack_15c;
          goto LAB_00a0e9c9;
        }
        puStack_1c[2] = uStack_15c;
      }
      else {
        iVar18 = FUN_005c4c00();
        pauStack_14 = (undefined (*) [16])(iVar18 + 0x18);
        uVar20 = FUN_0088da50();
        *(undefined4 *)*pauStack_14 = uVar20;
        puStack_18 = (uint *)FUN_005c9e80();
        puVar27 = *(uint **)(*pauStack_14 + 4);
        if (puVar27 == puStack_18) {
          *(int *)(*pauStack_14 + 8) = iStack_164;
          *(int *)(*pauStack_14 + 0xc) = iStack_160;
        }
        else {
          if (puVar27 != (uint *)0x0) {
            (*(code *)puVar27[2])();
            *(undefined4 *)(*pauStack_14 + 4) = 0;
          }
          *(int *)(*pauStack_14 + 8) = iStack_164;
          *(int *)(*pauStack_14 + 0xc) = iStack_160;
          *(uint **)(*pauStack_14 + 4) = puStack_18;
        }
        iVar18 = FUN_005c4c00();
        puStack_1c = (uint *)(iVar18 + 0x18);
        uVar19 = FUN_0088c8c0();
        pvVar10 = ThreadLocalStoragePointer;
        *puStack_1c = uVar19;
        puStack_24 = *(uint **)((int)pvVar10 + _tls_index * 4);
        if (((int)puStack_24[0xd] < DAT_01ea8c18) && (FUN_016f3809(), DAT_01ea8c18 == -1)) {
          DAT_01ea8c0c = FUN_005c65e0;
          DAT_01ea8c10 = FUN_005c65e0;
          DAT_01ea8c14 = _guard_check_icall;
          FUN_016f37bf();
        }
        puVar15 = (undefined4 *)puStack_1c[1];
        if ((code **)puVar15 == &DAT_01ea8c0c) {
          puStack_1c[2] = uStack_15c;
        }
        else {
          if (puVar15 != (undefined4 *)0x0) {
            (*(code *)puVar15[2])();
            puStack_1c[1] = 0;
          }
          puStack_1c[2] = uStack_15c;
LAB_00a0e9c9:
          puStack_1c[1] = (uint)&DAT_01ea8c0c;
        }
      }
      if (DAT_01d65a58 != '\0') {
        ppppuVar16 = apppuStack_17c;
        if (0xf < uStack_168) {
          ppppuVar16 = (undefined4 ****)apppuStack_17c[0];
        }
        puStack_1c = (uint *)FUN_01531190(auStack_c4,ppppuVar16);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
        iVar18 = FUN_005c4c00();
        pauStack_14 = (undefined (*) [16])(iVar18 + 0x18);
        uVar20 = FUN_0088cb40();
        *(undefined4 *)*pauStack_14 = uVar20;
        puStack_18 = (uint *)FUN_005c9d30();
        puVar27 = *(uint **)(*pauStack_14 + 4);
        if (puVar27 == puStack_18) {
          puStack_18 = (uint *)(*pauStack_14 + 8);
          if (puStack_18 != puStack_1c) {
            FUN_005507b0();
            uVar19 = puStack_1c[1];
            uVar26 = puStack_1c[2];
            uVar6 = puStack_1c[3];
            *puStack_18 = *puStack_1c;
            puStack_18[1] = uVar19;
            puStack_18[2] = uVar26;
            puStack_18[3] = uVar6;
            *(undefined8 *)(puStack_18 + 4) = *(undefined8 *)(puStack_1c + 4);
            puStack_1c[4] = 0;
            puStack_1c[5] = 0xf;
            *(undefined *)puStack_1c = 0;
          }
        }
        else {
          if (puVar27 != (uint *)0x0) {
            (*(code *)puVar27[2])();
            *(undefined4 *)(*pauStack_14 + 4) = 0;
          }
          *(undefined4 *)(pauStack_14[1] + 8) = 0;
          *(undefined4 *)(pauStack_14[1] + 0xc) = 0;
          uVar19 = puStack_1c[1];
          uVar26 = puStack_1c[2];
          uVar6 = puStack_1c[3];
          *(uint *)(*pauStack_14 + 8) = *puStack_1c;
          *(uint *)(*pauStack_14 + 0xc) = uVar19;
          *(uint *)pauStack_14[1] = uVar26;
          *(uint *)(pauStack_14[1] + 4) = uVar6;
          *(undefined8 *)(pauStack_14[1] + 8) = *(undefined8 *)(puStack_1c + 4);
          puStack_1c[4] = 0;
          puStack_1c[5] = 0xf;
          *(undefined *)puStack_1c = 0;
          *(uint **)(*pauStack_14 + 4) = puStack_18;
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
        FUN_005507b0();
      }
      uStack_284 = FUN_008881d0();
      puStack_280 = (undefined *)0x0;
      if (piStack_38 != (int *)0x0) {
        LOCK();
        piStack_38[1] = piStack_38[1] + 1;
        UNLOCK();
      }
      piStack_278 = piStack_38;
      uStack_27c = uStack_3c;
      if (((int)puStack_24[0xd] < DAT_01ea93d0) && (FUN_016f3809(), DAT_01ea93d0 == -1)) {
        _DAT_01ea93c4 = FUN_0057bbb0;
        _DAT_01ea93c8 = FUN_005880a0;
        DAT_01ea93cc = FUN_0057d5e0;
        FUN_016f37bf();
      }
      puStack_280 = &DAT_01ea93c4;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
      if (*(int *)(uStack_34 + 8) == *(int *)(uStack_34 + 4)) {
        FUN_005ca4f0(*(int *)(uStack_34 + 4),&uStack_284);
      }
      else {
        FUN_005caaf0(uStack_34);
        *(int *)(uStack_34 + 4) = *(int *)(uStack_34 + 4) + 0xd0;
      }
      uStack_8._0_1_ = 0x15;
      if (puStack_280 != (undefined *)0x0) {
        (**(code **)(puStack_280 + 8))();
      }
      iStack_48 = iStack_48 + 1;
      iStack_90 = iStack_90 + 1;
      if ((iStack_48 == iStack_54) || (iStack_90 == *(int *)(iStack_2c + 0x40))) {
        iStack_48 = 0;
        uStack_7c = 0;
        uStack_78 = 0xf;
        auStack_8c[0] = auStack_8c[0] & 0xffffff00;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
        uStack_284 = FUN_008881d0();
        puStack_280 = (undefined *)0x0;
        if (piStack_4c != (int *)0x0) {
          LOCK();
          piStack_4c[1] = piStack_4c[1] + 1;
          UNLOCK();
        }
        uStack_27c = uStack_50;
        piStack_278 = piStack_4c;
        if (((int)puStack_24[0xd] < DAT_01ea93d0) && (FUN_016f3809(), DAT_01ea93d0 == -1)) {
          _DAT_01ea93c4 = FUN_0057bbb0;
          _DAT_01ea93c8 = FUN_005880a0;
          DAT_01ea93cc = FUN_0057d5e0;
          FUN_016f37bf();
        }
        puStack_280 = &DAT_01ea93c4;
        uStack_8._0_1_ = 0x17;
        FUN_0098fc00(&uStack_284,auStack_8c);
        uStack_8._0_1_ = 0x18;
        if (puStack_280 != (undefined *)0x0) {
          (**(code **)(puStack_280 + 8))();
        }
        uStack_8._0_1_ = 0x16;
        FUN_014c9d60(&iStack_44);
        uStack_8._0_1_ = 0x19;
        uVar14 = (undefined)uStack_8;
        uStack_8._0_1_ = 0x19;
        if (DAT_01d65a40 == '\0') {
          uStack_8._0_1_ = uVar14;
          FUN_014cba60();
          puStack_18 = (uint *)iStack_44;
          ppppuVar16 = &pppuStack_f4;
          if (0xf < uStack_e4._4_4_) {
            ppppuVar16 = (undefined4 ****)pppuStack_f4;
          }
          FUN_014cbbc0(ppppuVar16,(undefined4)uStack_e4);
          *(undefined4 *)(iStack_44 + 0xb0) = 0;
          puStack_18 = (uint *)iStack_44;
          puVar15 = &DAT_01d79f98;
          if (0xf < DAT_01d79fac) {
            puVar15 = DAT_01d79f98;
          }
          puVar21 = &DAT_01d79d70;
          if (0xf < DAT_01d79d84) {
            puVar21 = DAT_01d79d70;
          }
          FUN_014cb8a0(puVar21,DAT_01d79d80,puVar15,DAT_01d79fa8);
          puStack_18 = (uint *)iStack_44;
          uVar20 = FUN_00928340();
          puVar21 = (undefined4 *)FUN_01675640(auStack_c4,&DAT_018bed48,uVar20);
          puVar15 = puVar21 + 4;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x1b);
          if (0xf < (uint)puVar21[5]) {
            puVar21 = (undefined4 *)*puVar21;
          }
          puVar22 = &DAT_01d79ef0;
          if (0xf < DAT_01d79f04) {
            puVar22 = DAT_01d79ef0;
          }
          FUN_014cb8a0(puVar22,DAT_01d79f00,puVar21,*puVar15);
        }
        else {
          uStack_b4 = 0;
          pauStack_14 = *(undefined (**) [16])(iStack_2c + 0x30);
          puStack_18 = *(uint **)(iStack_2c + 0x34);
          puStack_1c = (uint *)CONCAT31((int3)((uint)puStack_18 >> 8),
                                        *(undefined *)(iStack_2c + 0x8d));
          pppuStack_b0 = (undefined ***)&DAT_0000000f;
          auStack_c4[0] = auStack_c4[0] & 0xffffff00;
          FUN_005542c0(&DAT_018c3c98,4);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
          if (*(int *)(iStack_2c + 0x28) != 0) {
            LOCK();
            piVar2 = (int *)(*(int *)(iStack_2c + 0x28) + 4);
            *piVar2 = *piVar2 + 1;
            UNLOCK();
          }
          uVar20 = *(undefined4 *)(iStack_2c + 0x24);
          uVar5 = *(undefined4 *)(iStack_2c + 0x28);
          if (puStack_40 != (uint *)0x0) {
            LOCK();
            puStack_40[1] = puStack_40[1] + 1;
            UNLOCK();
          }
          FUN_00a115a0(iStack_44,puStack_40,auStack_c4,&pppuStack_f4,uVar20,uVar5,puStack_1c,
                       CONCAT44(puStack_18,pauStack_14));
        }
        uStack_8._0_1_ = 0x19;
        FUN_005507b0();
        if (cStack_1d == '\0') {
          uStack_94 = CONCAT31(uStack_94._1_3_,1);
          if (DAT_01d65a38 == '\0') goto LAB_00a0ee80;
        }
        else {
LAB_00a0ee80:
          uStack_94 = uStack_94 & 0xffffff00;
        }
        FUN_014cb780(auStack_8c,uStack_94);
        if (piStack_100 != (int *)0x0) {
          LOCK();
          piStack_100[2] = piStack_100[2] + 1;
          UNLOCK();
        }
        piStack_cc = piStack_100;
        iStack_c8 = (int)dStack_13c;
        ppuStack_d4 = std::
                      _Func_impl_no_alloc<class_<lambda_8504b1d6e35ce6755247acb07cd8948c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                      ::vftable;
        uStack_d0 = uStack_104;
        pppuStack_b0 = &ppuStack_d4;
        uStack_8._0_1_ = 0x1c;
        FUN_014cb530();
        if (pppuStack_b0 != (undefined ***)0x0) {
          (*(code *)(*pppuStack_b0)[4])();
        }
        puStack_18 = puStack_40;
        if (puStack_40 != (uint *)0x0) {
          LOCK();
          uVar19 = puStack_40[1] - 1;
          puStack_40[1] = uVar19;
          UNLOCK();
          if (uVar19 == 0) {
            (**(code **)*puStack_40)();
            LOCK();
            uVar19 = puStack_18[2] - 1;
            puStack_18[2] = uVar19;
            UNLOCK();
            if (uVar19 == 0) {
              (**(code **)(*puStack_18 + 4))();
            }
          }
        }
        FUN_005507b0();
      }
      if (piStack_38 != (int *)0x0) {
        LOCK();
        iVar18 = piStack_38[1] + -1;
        piStack_38[1] = iVar18;
        UNLOCK();
        if (iVar18 == 0) {
          (**(code **)*piStack_38)();
          LOCK();
          iVar18 = piStack_38[2] + -1;
          piStack_38[2] = iVar18;
          UNLOCK();
          if (iVar18 == 0) {
            (**(code **)(*piStack_38 + 4))();
          }
        }
      }
      FUN_009f1010();
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      FUN_005507b0();
      piVar2 = piStack_30;
      piVar28 = (int *)*piVar28;
    } while (piVar28 != piVar4);
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar18 = piStack_30[1] + -1;
      piStack_30[1] = iVar18;
      UNLOCK();
      if (iVar18 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar4 = piVar2 + 2;
        iVar18 = *piVar4 + -1;
        *piVar4 = iVar18;
        UNLOCK();
        if (iVar18 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar4 = piStack_4c;
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar18 = piStack_4c[1] + -1;
      piStack_4c[1] = iVar18;
      UNLOCK();
      if (iVar18 == 0) {
        (**(code **)*piStack_4c)();
        LOCK();
        piVar28 = piVar4 + 2;
        iVar18 = *piVar28 + -1;
        *piVar28 = iVar18;
        UNLOCK();
        if (iVar18 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  FUN_005507b0();
  if (piStack_100 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_100 + 2;
    iVar18 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar18 == 1) {
      (**(code **)(*piStack_100 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19910 ; VA 0x00a0f1f0 ; FUN_00a0f1f0 */

int __fastcall FUN_00a0f1f0(uint param_1)

{
  undefined4 ****ppppuVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined uVar8;
  undefined3 uVar9;
  undefined4 *puVar10;
  undefined4 ****ppppuVar11;
  undefined *puVar12;
  undefined **ppuVar13;
  int iVar14;
  undefined4 *puVar15;
  undefined4 *puVar16;
  undefined **ppuVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  undefined8 uVar21;
  int *piVar22;
  undefined auStack_1e8 [4];
  int iStack_1e4;
  undefined auStack_1e0 [80];
  undefined auStack_190 [120];
  uint auStack_118 [4];
  undefined4 uStack_108;
  uint uStack_104;
  uint auStack_100 [4];
  undefined4 uStack_f0;
  uint uStack_ec;
  uint auStack_e8 [4];
  undefined4 uStack_d8;
  uint uStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  uint auStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  undefined **ppuStack_a0;
  undefined4 uStack_9c;
  int *piStack_98;
  uint auStack_90 [4];
  undefined4 uStack_80;
  undefined ***pppuStack_7c;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  undefined4 ***pppuStack_50;
  undefined4 **ppuStack_4c;
  undefined4 **ppuStack_48;
  undefined4 **ppuStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dae79;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_20 = param_1;
  if (DAT_01ee6bcc != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee6bcc,"Commit: %s",PTR_s_Place_Changes_01d65cb8);
  }
  puVar10 = (undefined4 *)FUN_016830f0(&uStack_60);
  *(undefined4 *)(param_1 + 0xa0) = *puVar10;
  *(undefined4 *)(param_1 + 0xa4) = puVar10[1];
  FUN_008c0cc0(&uStack_60,param_1);
  uStack_40 = 0xf00000000;
  pppuStack_50 = (undefined4 ***)((uint)pppuStack_50 & 0xffffff00);
  uStack_8._1_3_ = 0;
  uVar9 = uStack_8._1_3_;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if ((DAT_01d658cc < 1) || (DAT_01d65900 < DAT_01d658cc)) {
    cStack_11 = '\0';
    uStack_8._1_3_ = uVar9;
    FUN_0054ef60(param_1 + 0x70);
    ppppuVar11 = (undefined4 ****)FUN_00fb8290(auStack_90);
    uStack_8._0_1_ = 8;
    if (&pppuStack_50 != ppppuVar11) {
      ppppuVar1 = ppppuVar11 + 4;
      if ((undefined4 ***)0xf < ppppuVar11[5]) {
        ppppuVar11 = (undefined4 ****)*ppppuVar11;
      }
      FUN_005542c0(ppppuVar11,*ppppuVar1);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < pppuStack_7c) {
      uVar18 = (int)pppuStack_7c + 1;
      uVar20 = auStack_90[0];
      if (0xfff < uVar18) {
        uVar20 = *(uint *)(auStack_90[0] - 4);
        uVar18 = (int)pppuStack_7c + 0x24;
        if (0x1f < (auStack_90[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      goto LAB_00a0f65e;
    }
  }
  else {
    cStack_11 = '\x01';
    uStack_68 = 0;
    uStack_64 = 0xf;
    auStack_78[0] = auStack_78[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 2;
    uStack_f0 = 0;
    uStack_ec = 0xf;
    auStack_100[0] = auStack_100[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 3;
    uStack_d8 = 0;
    uStack_d4 = 0xf;
    auStack_e8[0] = auStack_e8[0] & 0xffffff00;
    FUN_005542c0("universe-history-mock/commits/200/place-commits",0x2f);
    uStack_8._0_1_ = 4;
    uStack_c0 = 0;
    uStack_bc = 0xf;
    auStack_d0[0] = auStack_d0[0] & 0xffffff00;
    FUN_005542c0("apis.simulpong.com",0x12);
    uStack_8._0_1_ = 5;
    uStack_a8 = 0;
    uStack_a4 = 0xf;
    auStack_b8[0] = auStack_b8[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c71bc,4);
    uStack_8._0_1_ = 6;
    FUN_0151bcc0(auStack_190,auStack_b8,auStack_d0,auStack_e8,auStack_100,auStack_78);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    ppppuVar11 = (undefined4 ****)FUN_0151bb70(auStack_90);
    if (&pppuStack_50 != ppppuVar11) {
      FUN_005507b0();
      pppuStack_50 = *ppppuVar11;
      ppuStack_4c = ppppuVar11[1];
      ppuStack_48 = ppppuVar11[2];
      ppuStack_44 = ppppuVar11[3];
      uStack_40 = *(undefined8 *)(ppppuVar11 + 4);
      ppppuVar11[4] = (undefined4 ***)0x0;
      ppppuVar11[5] = (undefined4 ***)0xf;
      *(undefined *)ppppuVar11 = 0;
    }
    if (0xf < pppuStack_7c) {
      uVar18 = (int)pppuStack_7c + 1;
      uVar20 = auStack_90[0];
      if (0xfff < uVar18) {
        uVar20 = *(uint *)(auStack_90[0] - 4);
        uVar18 = (int)pppuStack_7c + 0x24;
        if (0x1f < (auStack_90[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar18);
    }
    uStack_80 = 0;
    pppuStack_7c = (undefined ***)0xf;
    auStack_90[0] = auStack_90[0] & 0xffffff00;
    FUN_0056d9d0();
    uStack_8._0_1_ = 5;
    if (0xf < uStack_a4) {
      uVar18 = uStack_a4 + 1;
      uVar20 = auStack_b8[0];
      if (0xfff < uVar18) {
        uVar20 = *(uint *)(auStack_b8[0] - 4);
        uVar18 = uStack_a4 + 0x24;
        if (0x1f < (auStack_b8[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar18);
    }
    uStack_a8 = 0;
    uStack_a4 = 0xf;
    auStack_b8[0] = auStack_b8[0] & 0xffffff00;
    uStack_8._0_1_ = 4;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_bc) {
      uVar18 = uStack_bc + 1;
      uVar20 = auStack_d0[0];
      if (0xfff < uVar18) {
        uVar20 = *(uint *)(auStack_d0[0] - 4);
        uVar18 = uStack_bc + 0x24;
        if (0x1f < (auStack_d0[0] - uVar20) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar18);
    }
    uStack_c0 = 0;
    uStack_bc = 0xf;
    auStack_d0[0] = auStack_d0[0] & 0xffffff00;
    uStack_8._0_1_ = 3;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_d4) {
      uVar18 = uStack_d4 + 1;
      uVar20 = auStack_e8[0];
      if (0xfff < uVar18) {
        uVar20 = *(uint *)(auStack_e8[0] - 4);
        uVar18 = uStack_d4 + 0x24;
        if (0x1f < (auStack_e8[0] - uVar20) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar18);
    }
    uStack_d8 = 0;
    uStack_d4 = 0xf;
    auStack_e8[0] = auStack_e8[0] & 0xffffff00;
    uStack_8._0_1_ = 2;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_ec) {
      uVar18 = uStack_ec + 1;
      uVar20 = auStack_100[0];
      if (0xfff < uVar18) {
        uVar20 = *(uint *)(auStack_100[0] - 4);
        uVar18 = uStack_ec + 0x24;
        if (0x1f < (auStack_100[0] - uVar20) - 4) {
          uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar18);
    }
    uStack_f0 = 0;
    uStack_ec = 0xf;
    auStack_100[0] = auStack_100[0] & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_64) {
      uVar18 = uStack_64 + 1;
      uVar20 = auStack_78[0];
      if (0xfff < uVar18) {
        uVar20 = *(uint *)(auStack_78[0] - 4);
        uVar18 = uStack_64 + 0x24;
        if (0x1f < (auStack_78[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
LAB_00a0f65e:
      FUN_01674ea0(uVar20,uVar18);
    }
  }
  puVar12 = (undefined *)FUN_01674e20(0x18);
  if (puVar12 == (undefined *)0x0) {
    puVar12 = (undefined *)0x0;
    iStack_18 = 0;
  }
  else {
    *puVar12 = 0;
    iStack_18 = 0xb;
    ppuVar13 = (undefined **)
               FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_18);
    ppuVar17 = ppuVar13 + -1;
    if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar17 = ppuVar13;
    }
    *(undefined **)(puVar12 + 4) = *ppuVar17;
    *(undefined4 *)(puVar12 + 8) = 0;
    *(undefined4 *)(puVar12 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar12 + 0x10) = 0;
    *(undefined4 *)(puVar12 + 0x14) = 0;
  }
  uStack_38 = 0;
  piStack_34 = (int *)0x0;
  FUN_005c1af0(puVar12,iStack_18);
  uStack_8._0_1_ = 9;
  puVar10 = (undefined4 *)FUN_01674e20(0xc);
  if (puVar10 == (undefined4 *)0x0) {
    puVar10 = (undefined4 *)0x0;
  }
  else {
    *puVar10 = 0;
    puVar10[1] = 0;
    puVar10[2] = 0;
  }
  iStack_30 = 0;
  piStack_2c = (int *)0x0;
  FUN_006047e0(puVar10,iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  puVar12 = (undefined *)FUN_01674e20(0x18);
  if (puVar12 == (undefined *)0x0) {
    puVar12 = (undefined *)0x0;
    iStack_18 = 0;
  }
  else {
    *puVar12 = 0;
    iStack_18 = 0xb;
    ppuVar13 = (undefined **)
               FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_18);
    ppuVar17 = ppuVar13 + -1;
    if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar17 = ppuVar13;
    }
    *(undefined **)(puVar12 + 4) = *ppuVar17;
    *(undefined4 *)(puVar12 + 8) = 0;
    *(undefined4 *)(puVar12 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar12 + 0x10) = 0;
    *(undefined4 *)(puVar12 + 0x14) = 0;
  }
  uStack_58 = 0;
  piStack_54 = (int *)0x0;
  FUN_005c1af0(puVar12,iStack_18);
  uStack_8._0_1_ = 0xb;
  if (cStack_11 == '\0') {
    piVar22 = *(int **)(*(int *)(param_1 + 0x1c) + 0x43c);
    iStack_1c = *piVar22 - (int)piVar22;
    iStack_18 = piVar22[1] - (int)piVar22;
  }
  else {
    iStack_1c = 200;
    iStack_18 = 0;
  }
  piVar22 = &iStack_1c;
  FUN_005c4c00(&DAT_01d65a98);
  FUN_00632bc0(piVar22);
  iVar14 = param_1 + 0x88;
  FUN_005c4c00(&DAT_01d65c60);
  FUN_005ed510(iVar14);
  FUN_005e4d60(&uStack_58);
  iVar14 = iStack_30;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (*(int *)(iStack_30 + 8) == *(int *)(iStack_30 + 4)) {
    FUN_005ca4f0(*(int *)(iStack_30 + 4),auStack_1e8);
  }
  else {
    FUN_005caaf0(iStack_30);
    *(int *)(iVar14 + 4) = *(int *)(iVar14 + 4) + 0xd0;
  }
  uStack_8._0_1_ = 0xd;
  if (iStack_1e4 != 0) {
    (**(code **)(iStack_1e4 + 8))(auStack_1e0);
  }
  piVar22 = &iStack_30;
  uStack_8._0_1_ = 0xb;
  if (DAT_01d65a48 == '\0') {
    puVar12 = &DAT_01d65b58;
  }
  else {
    puVar12 = &DAT_01d65b70;
  }
  FUN_005c4c00(puVar12);
  FUN_00a03440(piVar22);
  uStack_108 = 0;
  uStack_104 = 0xf;
  auStack_118[0] = auStack_118[0] & 0xffffff00;
  uStack_8._0_1_ = 0xe;
  FUN_005e4d60(&uStack_38);
  uStack_8._0_1_ = 0xf;
  FUN_0098fc00(auStack_1e8,auStack_118,1);
  uStack_8._0_1_ = 0x10;
  if (iStack_1e4 != 0) {
    (**(code **)(iStack_1e4 + 8))(auStack_1e0);
  }
  uStack_8._0_1_ = 0xe;
  FUN_014c9d60(&iStack_28,0);
  uStack_8._0_1_ = 0x11;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x11;
  if (DAT_01d65a40 == '\0') {
    uStack_8._0_1_ = uVar8;
    FUN_014cba60();
    ppppuVar11 = &pppuStack_50;
    if (0xf < uStack_40._4_4_) {
      ppppuVar11 = (undefined4 ****)pppuStack_50;
    }
    FUN_014cbbc0(ppppuVar11,(undefined4)uStack_40);
    *(undefined4 *)(iStack_28 + 0xb0) = 0;
    puVar10 = &DAT_01d79f98;
    if (0xf < DAT_01d79fac) {
      puVar10 = DAT_01d79f98;
    }
    puVar15 = &DAT_01d79d70;
    if (0xf < DAT_01d79d84) {
      puVar15 = DAT_01d79d70;
    }
    FUN_014cb8a0(puVar15,DAT_01d79d80,puVar10,DAT_01d79fa8);
    uVar20 = uStack_20;
    iStack_18 = iStack_28;
    uVar21 = FUN_00928340();
    puVar15 = (undefined4 *)FUN_01675640(auStack_90,&DAT_018bed48,uVar21);
    puVar10 = puVar15 + 4;
    uStack_8._0_1_ = 0x13;
    if (0xf < (uint)puVar15[5]) {
      puVar15 = (undefined4 *)*puVar15;
    }
    puVar16 = &DAT_01d79ef0;
    if (0xf < DAT_01d79f04) {
      puVar16 = DAT_01d79ef0;
    }
    FUN_014cb8a0(puVar16,DAT_01d79f00,puVar15,*puVar10);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    if (0xf < pppuStack_7c) {
      uVar19 = (int)pppuStack_7c + 1;
      uVar18 = auStack_90[0];
      if (0xfff < uVar19) {
        uVar18 = *(uint *)(auStack_90[0] - 4);
        uVar19 = (int)pppuStack_7c + 0x24;
        if (0x1f < (auStack_90[0] - uVar18) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar18,uVar19);
    }
  }
  else {
    uVar4 = *(undefined4 *)(param_1 + 0x30);
    uVar5 = *(undefined4 *)(uStack_20 + 0x34);
    iStack_18 = CONCAT31((int3)(uStack_20 >> 8),*(undefined *)(uStack_20 + 0x8d));
    uStack_68 = 0;
    uStack_64 = 0xf;
    auStack_78[0] = auStack_78[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c3c98,4);
    uStack_8._0_1_ = 0x12;
    if (*(int *)(uStack_20 + 0x28) != 0) {
      LOCK();
      piVar22 = (int *)(*(int *)(uStack_20 + 0x28) + 4);
      *piVar22 = *piVar22 + 1;
      UNLOCK();
    }
    uVar6 = *(undefined4 *)(uStack_20 + 0x24);
    uVar7 = *(undefined4 *)(uStack_20 + 0x28);
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    FUN_00a115a0(iStack_28,piStack_24,auStack_78,&pppuStack_50,uVar6,uVar7,iStack_18,uVar4,uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    uVar20 = uStack_20;
    if (0xf < uStack_64) {
      uVar18 = uStack_64 + 1;
      uVar20 = auStack_78[0];
      if (0xfff < uVar18) {
        uVar20 = *(uint *)(auStack_78[0] - 4);
        uVar18 = uStack_64 + 0x24;
        if (0x1f < (auStack_78[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar20,uVar18);
      uVar20 = uStack_20;
    }
  }
  if (*(char *)(uVar20 + 0x8c) != '\0') {
    puVar10 = &DAT_01d79f38;
    if (0xf < DAT_01d79f4c) {
      puVar10 = DAT_01d79f38;
    }
    FUN_014cb8a0(puVar10,DAT_01d79f48,&DAT_018bdf50,4);
  }
  if (cStack_11 == '\0') {
    uStack_20 = CONCAT31(uStack_20._1_3_,1);
    if (DAT_01d65a38 != '\0') goto LAB_00a0fa5b;
  }
  uStack_20 = uStack_20 & 0xffffff00;
LAB_00a0fa5b:
  FUN_014cb780(auStack_118,uStack_20);
  if (piStack_5c != (int *)0x0) {
    LOCK();
    piStack_5c[2] = piStack_5c[2] + 1;
    UNLOCK();
  }
  uStack_9c = uStack_60;
  pppuStack_7c = &ppuStack_a0;
  ppuStack_a0 = std::
                _Func_impl_no_alloc<class_<lambda_3582bc2984258734a0a9ce9de1a9d633>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                ::vftable;
  piStack_98 = piStack_5c;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  iVar14 = FUN_014cb530(pppuStack_7c);
  if (pppuStack_7c != (undefined ***)0x0) {
    iVar14 = (*(code *)(*pppuStack_7c)[4])(pppuStack_7c != &ppuStack_a0);
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar22 = piStack_24 + 1;
    iVar3 = *piVar22;
    iVar14 = *piVar22;
    *piVar22 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar22 = piStack_24 + 2;
      iVar3 = *piVar22;
      iVar14 = *piVar22;
      *piVar22 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar14 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (0xf < uStack_104) {
    uVar18 = uStack_104 + 1;
    uVar20 = auStack_118[0];
    if (0xfff < uVar18) {
      uVar20 = *(uint *)(auStack_118[0] - 4);
      uVar18 = uStack_104 + 0x24;
      if (0x1f < (auStack_118[0] - uVar20) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar14 = FUN_01674ea0(uVar20,uVar18);
  }
  piVar22 = piStack_54;
  uStack_108 = 0;
  uStack_104 = 0xf;
  auStack_118[0] = auStack_118[0] & 0xffffff00;
  if (piStack_54 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_54 + 1;
    iVar3 = *piVar2;
    iVar14 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_54)();
      LOCK();
      piVar2 = piVar22 + 2;
      iVar3 = *piVar2;
      iVar14 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar14 = (**(code **)(*piVar22 + 4))();
      }
    }
  }
  piVar22 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_2c + 1;
    iVar3 = *piVar2;
    iVar14 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar2 = piVar22 + 2;
      iVar3 = *piVar2;
      iVar14 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar14 = (**(code **)(*piVar22 + 4))();
      }
    }
  }
  piVar22 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_34 + 1;
    iVar3 = *piVar2;
    iVar14 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar2 = piVar22 + 2;
      iVar3 = *piVar2;
      iVar14 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar14 = (**(code **)(*piVar22 + 4))();
      }
    }
  }
  if (0xf < uStack_40._4_4_) {
    uVar20 = uStack_40._4_4_ + 1;
    ppppuVar11 = (undefined4 ****)pppuStack_50;
    if (0xfff < uVar20) {
      ppppuVar11 = (undefined4 ****)pppuStack_50[-1];
      uVar20 = uStack_40._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_50 + (-4 - (int)ppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar14 = FUN_01674ea0(ppppuVar11,uVar20);
  }
  uStack_40 = 0xf00000000;
  pppuStack_50 = (undefined4 ***)((uint)pppuStack_50 & 0xffffff00);
  if (piStack_5c != (int *)0x0) {
    LOCK();
    piVar22 = piStack_5c + 2;
    iVar3 = *piVar22;
    *piVar22 = *piVar22 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      iVar14 = (**(code **)(*piStack_5c + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar14;
}



/* FUNCTION 19911 ; VA 0x00a0fd90 ; FUN_00a0fd90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00a0fd90(int *****param_1)

{
  int *piVar1;
  char cVar2;
  int ****ppppiVar3;
  int ****ppppiVar4;
  int ***pppiVar5;
  int ***pppiVar6;
  int ****ppppiVar7;
  int *****pppppiVar8;
  int *****pppppiVar9;
  undefined uVar10;
  undefined4 *puVar11;
  int ******ppppppiVar12;
  int *******pppppppiVar13;
  undefined **ppuVar14;
  int iVar15;
  undefined4 uVar16;
  int *****pppppiVar17;
  undefined **ppuVar18;
  int ******ppppppiStack_28c;
  int ******ppppppiStack_288;
  int ******ppppppiStack_284;
  int ******ppppppiStack_280;
  undefined8 uStack_27c;
  int ******appppppiStack_24c [4];
  int ****ppppiStack_23c;
  uint uStack_238;
  int ******ppppppiStack_234;
  int ******ppppppiStack_230;
  int **ppiStack_22c;
  undefined auStack_20c [16];
  undefined4 uStack_1fc;
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  undefined *puStack_1f0;
  undefined4 uStack_1ec;
  int *piStack_1e8;
  int ******appppppiStack_19c [4];
  undefined4 uStack_18c;
  uint uStack_188;
  int ******ppppppiStack_184;
  undefined4 uStack_174;
  uint uStack_170;
  int ******ppppppiStack_16c;
  undefined4 uStack_15c;
  uint uStack_158;
  int ******ppppppiStack_154;
  undefined4 uStack_144;
  uint uStack_140;
  int ******ppppppiStack_13c;
  undefined4 uStack_12c;
  uint uStack_128;
  int ******ppppppiStack_124;
  int *****pppppiStack_120;
  int *****pppppiStack_11c;
  int *****pppppiStack_118;
  int ****ppppiStack_114;
  int ****ppppiStack_110;
  int ****ppppiStack_10c;
  undefined **ppuStack_108;
  int *****pppppiStack_104;
  int *piStack_100;
  int ******ppppppiStack_fc;
  int *****pppppiStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  ulonglong uStack_ec;
  undefined ***pppuStack_e4;
  int *****pppppiStack_e0;
  int *piStack_dc;
  int ******appppppiStack_d8 [4];
  undefined4 uStack_c8;
  uint uStack_c4;
  int ******appppppiStack_c0 [4];
  undefined4 uStack_b0;
  uint uStack_ac;
  int ******appppppiStack_a8 [4];
  undefined4 uStack_98;
  uint uStack_94;
  int ******appppppiStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint uStack_78;
  int ******ppppppiStack_74;
  int *****pppppiStack_70;
  int *****pppppiStack_6c;
  int *****pppppiStack_68;
  undefined8 uStack_64;
  int *****pppppiStack_5c;
  int *piStack_58;
  int ******ppppppiStack_54;
  int *****pppppiStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  int ******ppppppiStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int *****pppppiStack_30;
  int ****ppppiStack_2c;
  int ****ppppiStack_28;
  int ****ppppiStack_24;
  int *****pppppiStack_20;
  char cStack_19;
  int ******ppppppiStack_18;
  int ******ppppppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dafb7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  ppppiStack_28 = (int ****)param_1;
  if (DAT_01ee6bcc != 0) {
    uStack_27c._4_4_ = (int *******)PTR_s_Publish_Assets_01d65cac;
    ppppppiStack_280 = (int ******)(uint)DAT_01ee6bcc;
    uStack_27c._0_4_ = (undefined **)0x193ed4c;
    ppppppiStack_284 = (int ******)0xa0fdd2;
    ExceptionList = &pvStack_10;
    FUN_016774b0();
  }
  uStack_27c._4_4_ = (int *******)&pppppiStack_e0;
  uStack_27c._0_4_ = (undefined **)0xa0fde1;
  puVar11 = (undefined4 *)FUN_016830f0();
  param_1[0x28] = (int ****)*puVar11;
  param_1[0x29] = (int ****)puVar11[1];
  ppppppiStack_280 = &pppppiStack_e0;
  ppppppiStack_284 = (int ******)0xa0fdff;
  uStack_27c._0_4_ = (undefined **)param_1;
  FUN_008c0cc0();
  ppppiVar3 = param_1[0xf];
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  ppppiVar4 = (int ****)*ppppiVar3;
  do {
    if (ppppiVar4 == ppppiVar3) {
      if (piStack_dc != (int *)0x0) {
        LOCK();
        piVar1 = piStack_dc + 2;
        iVar15 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar15 == 1) {
          uStack_27c._4_4_ = (int *******)0xa110f8;
          (**(code **)(*piStack_dc + 4))();
        }
      }
      ExceptionList = pvStack_10;
      return;
    }
    ppppppiStack_14 = (int ******)(ppppiVar4 + 2);
    pppppiStack_20 = (int *****)ppppiVar4[6];
    ppppiStack_114 = (int ****)0x0;
    ppppiStack_110 = (int ****)0x0;
    if ((int ***)0xf < ppppiVar4[7]) {
      ppppppiStack_14 = (int ******)*ppppppiStack_14;
    }
    if (pppppiStack_20 < (int *****)0x10) {
      ppppppiStack_124 = (int ******)*ppppppiStack_14;
      pppppiStack_120 = (int *****)((int *******)ppppppiStack_14)[1];
      pppppiStack_11c = (int *****)((int *******)ppppppiStack_14)[2];
      pppppiStack_118 = (int *****)((int *******)ppppppiStack_14)[3];
      ppppiStack_110 = (int ****)0xf;
    }
    else {
      ppppiStack_24 = (int ****)((uint)pppppiStack_20 | 0xf);
      if ((int *****)0x7fffffff < ppppiStack_24) {
        ppppiStack_24 = (int ****)0x7fffffff;
      }
      uStack_27c._4_4_ = (int *******)((int)ppppiStack_24 + 1);
      if (uStack_27c._4_4_ < (int *****)0x1000) {
        if (uStack_27c._4_4_ == (int *******)0x0) {
          ppppppiStack_280 = (int ******)0x0;
        }
        else {
          uStack_27c._0_4_ = (undefined **)0xa0fec2;
          ppppppiStack_280 = (int ******)FUN_01674e20();
        }
      }
      else {
        pppppiVar17 = (int *****)ppppiStack_24 + 9;
        if (pppppiVar17 <= uStack_27c._4_4_) {
          pppppiVar17 = (int *****)0xffffffff;
        }
        uStack_27c._0_4_ = (undefined **)0xa0fea2;
        uStack_27c._4_4_ = (int *******)pppppiVar17;
        ppppppiVar12 = (int ******)FUN_01674e20();
        if (ppppppiVar12 == (int ******)0x0) goto LAB_00a11108;
        ppppppiStack_280 = (int ******)((int)ppppppiVar12 + 0x23U & 0xffffffe0);
        ((int *******)ppppppiStack_280)[-1] = ppppppiVar12;
      }
      uStack_27c._4_4_ = (int *******)((int)pppppiStack_20 + 1);
      uStack_27c._0_4_ = (undefined **)ppppppiStack_14;
      ppppppiStack_284 = (int ******)0xa0fedf;
      ppppppiStack_124 = ppppppiStack_280;
      FUN_0170c6f0();
      ppppiStack_110 = ppppiStack_24;
    }
    if (ppppiVar4[9] != (int ***)0x0) {
      LOCK();
      pppiVar5 = ppppiVar4[9] + 1;
      *pppiVar5 = (int **)((int)*pppiVar5 + 1);
      UNLOCK();
    }
    pppiVar5 = ppppiVar4[8];
    uStack_27c._4_4_ = (int *******)(ppppiVar4 + 10);
    uStack_8._0_1_ = 2;
    uStack_27c._0_4_ = (undefined **)0xa0ff27;
    ppppiStack_114 = (int ****)pppppiStack_20;
    FUN_0054ef60();
    uStack_27c._4_4_ = (int *******)(ppppiVar4 + 0x10);
    uStack_8._0_1_ = 3;
    uStack_27c._0_4_ = (undefined **)0xa0ff3a;
    FUN_0054ef60();
    ppppppiStack_234 = (int ******)ppppiVar4[0x16];
    ppppppiStack_230 = (int ******)ppppiVar4[0x17];
    ppiStack_22c = (int **)ppppiVar4[0x18];
    uStack_27c._4_4_ = (int *******)(ppppiVar4 + 0x19);
    uStack_8._0_1_ = 4;
    uStack_27c._0_4_ = (undefined **)0xa0ff68;
    FUN_0054ef60();
    uStack_64 = 0xf00000000;
    ppppppiStack_74 = (int ******)((uint)ppppppiStack_74 & 0xffffff00);
    uStack_8._0_1_ = 6;
    uVar10 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if ((DAT_01d658cc < 1) || (DAT_01d658e8 < DAT_01d658cc)) {
      cStack_19 = '\0';
      uStack_27c._4_4_ = (int *******)(uint)*(byte *)((int)ppppiStack_28 + 0x8d);
      uStack_27c._0_4_ = (undefined **)ppppppiStack_230;
      ppppppiStack_280 = ppppppiStack_234;
      ppppppiStack_3c = ppppppiStack_234;
      ppppppiStack_284 = (int ******)&ppppppiStack_54;
      ppppppiStack_288 = (int ******)0xa108d7;
      uStack_8._0_1_ = uVar10;
      pppppppiVar13 = (int *******)FUN_00a27790();
      uStack_8._0_1_ = 0x13;
      if (&ppppppiStack_74 != pppppppiVar13) {
        uStack_27c._4_4_ = (int *******)pppppppiVar13[4];
        if ((int ******)0xf < pppppppiVar13[5]) {
          pppppppiVar13 = (int *******)*pppppppiVar13;
        }
        ppppppiStack_280 = (int ******)0xa108fa;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_005542c0();
      }
LAB_00a108fd:
      uStack_8._0_1_ = 6;
      uStack_27c._4_4_ = (int *******)0xa10906;
      FUN_005507b0();
    }
    else {
      ppppppiStack_3c = ppppppiStack_234;
      uStack_27c._4_4_ = (int *******)0x0;
      cStack_19 = '\x01';
      uStack_27c._0_4_ = (undefined **)&DAT_018bc9b8;
      if ((int *******)ppppppiStack_234 == (int *******)0x0 &&
          (int *******)ppppppiStack_230 == (int *******)0x0) {
        uStack_80 = 0;
        uStack_7c = 0xf;
        appppppiStack_90[0] = (int ******)((uint)appppppiStack_90[0] & 0xffffff00);
        ppppppiStack_280 = (int ******)0xa1050a;
        uStack_8._0_1_ = uVar10;
        FUN_005542c0();
        uStack_27c._4_4_ = (int *******)0x0;
        uStack_27c._0_4_ = (undefined **)&DAT_018bc9b8;
        uStack_8._0_1_ = 0xd;
        uStack_98 = 0;
        uStack_94 = 0xf;
        appppppiStack_a8[0] = (int ******)((uint)appppppiStack_a8[0] & 0xffffff00);
        ppppppiStack_280 = (int ******)0xa1053b;
        FUN_005542c0();
        uStack_27c._4_4_ = (int *******)0x17;
        uStack_27c._0_4_ = (undefined **)0x193ef80;
        uStack_8._0_1_ = 0xe;
        uStack_b0 = 0;
        uStack_ac = 0xf;
        appppppiStack_c0[0] = (int ******)((uint)appppppiStack_c0[0] & 0xffffff00);
        ppppppiStack_280 = (int ******)0xa1056c;
        FUN_005542c0();
        uStack_27c._4_4_ = (int *******)0x12;
        uStack_27c._0_4_ = (undefined **)0x18c888c;
        uStack_8._0_1_ = 0xf;
        uStack_c8 = 0;
        uStack_c4 = 0xf;
        appppppiStack_d8[0] = (int ******)((uint)appppppiStack_d8[0] & 0xffffff00);
        ppppppiStack_280 = (int ******)0xa1059d;
        FUN_005542c0();
        uStack_27c._4_4_ = (int *******)0x4;
        uStack_27c._0_4_ = (undefined **)&DAT_018c71bc;
        uStack_8._0_1_ = 0x10;
        uStack_ec = uStack_ec & 0xffffffff;
        pppuStack_e4 = (undefined ***)&DAT_0000000f;
        pppppiStack_f8 = (int *****)((uint)pppppiStack_f8 & 0xffffff00);
        ppppppiStack_280 = (int ******)0xa105ce;
        FUN_005542c0();
        uStack_27c._4_4_ = appppppiStack_90;
        uStack_8._0_1_ = 0x11;
        uStack_27c._0_4_ = (undefined **)appppppiStack_a8;
        ppppppiStack_280 = (int ******)appppppiStack_c0;
        ppppppiStack_284 = (int ******)appppppiStack_d8;
        ppppppiStack_288 = &pppppiStack_f8;
        ppppppiStack_28c = (int ******)appppppiStack_19c;
        FUN_0151bcc0();
        uStack_27c._4_4_ = &ppppppiStack_54;
        uStack_8._0_1_ = 0x12;
        uStack_27c._0_4_ = (undefined **)0xa10613;
        ppppppiStack_14 = (int ******)FUN_0151bb70();
        if (&ppppppiStack_74 != (int *******)ppppppiStack_14) {
          if (0xf < uStack_64._4_4_) {
            uStack_27c._4_4_ = (int *******)(uStack_64._4_4_ + 1);
            pppppppiVar13 = (int *******)ppppppiStack_74;
            if (0xfff < uStack_27c._4_4_) {
              pppppppiVar13 = (int *******)ppppppiStack_74[-1];
              uStack_27c._4_4_ = (int *******)(uStack_64._4_4_ + 0x24);
              if (0x1f < (uint)((int)ppppppiStack_74 + (-4 - (int)pppppppiVar13)))
              goto LAB_00a11108;
            }
            ppppppiStack_280 = (int ******)0xa1064e;
            uStack_27c._0_4_ = (undefined **)pppppppiVar13;
            FUN_01674ea0();
          }
          ppppppiStack_74 = (int ******)*ppppppiStack_14;
          pppppiStack_70 = ppppppiStack_14[1];
          pppppiStack_6c = ppppppiStack_14[2];
          pppppiStack_68 = ppppppiStack_14[3];
          uStack_64 = *(undefined8 *)(ppppppiStack_14 + 4);
          ppppppiStack_14[4] = (int *****)0x0;
          ppppppiStack_14[5] = (int *****)0xf;
          *(undefined *)ppppppiStack_14 = 0;
        }
        if (0xf < uStack_40) {
          uStack_27c._4_4_ = (int *******)(uStack_40 + 1);
          pppppppiVar13 = (int *******)ppppppiStack_54;
          if (0xfff < uStack_27c._4_4_) {
            pppppppiVar13 = (int *******)ppppppiStack_54[-1];
            uStack_27c._4_4_ = (int *******)(uStack_40 + 0x24);
            if (0x1f < (uint)((int)ppppppiStack_54 + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
          }
          ppppppiStack_280 = (int ******)0xa106b9;
          uStack_27c._0_4_ = (undefined **)pppppppiVar13;
          FUN_01674ea0();
        }
        uStack_44 = 0;
        uStack_40 = 0xf;
        ppppppiStack_54 = (int ******)((uint)ppppppiStack_54 & 0xffffff00);
        uStack_8._0_1_ = 0x11;
        if (0xf < uStack_128) {
          uStack_27c._4_4_ = (int *******)(uStack_128 + 1);
          pppppppiVar13 = (int *******)ppppppiStack_13c;
          if (0xfff < uStack_27c._4_4_) {
            pppppppiVar13 = (int *******)ppppppiStack_13c[-1];
            uStack_27c._4_4_ = (int *******)(uStack_128 + 0x24);
            if (0x1f < (uint)((int)ppppppiStack_13c + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
          }
          ppppppiStack_280 = (int ******)0xa10709;
          uStack_27c._0_4_ = (undefined **)pppppppiVar13;
          FUN_01674ea0();
        }
        uStack_12c = 0;
        uStack_128 = 0xf;
        ppppppiStack_13c = (int ******)((uint)ppppppiStack_13c & 0xffffff00);
        if (0xf < uStack_140) {
          uStack_27c._4_4_ = (int *******)(uStack_140 + 1);
          pppppppiVar13 = (int *******)ppppppiStack_154;
          if (0xfff < uStack_27c._4_4_) {
            pppppppiVar13 = (int *******)ppppppiStack_154[-1];
            uStack_27c._4_4_ = (int *******)(uStack_140 + 0x24);
            if (0x1f < (uint)((int)ppppppiStack_154 + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
          }
          ppppppiStack_280 = (int ******)0xa1075e;
          uStack_27c._0_4_ = (undefined **)pppppppiVar13;
          FUN_01674ea0();
        }
        uStack_144 = 0;
        uStack_140 = 0xf;
        ppppppiStack_154 = (int ******)((uint)ppppppiStack_154 & 0xffffff00);
        if (0xf < uStack_158) {
          uStack_27c._4_4_ = (int *******)(uStack_158 + 1);
          pppppppiVar13 = (int *******)ppppppiStack_16c;
          if (0xfff < uStack_27c._4_4_) {
            pppppppiVar13 = (int *******)ppppppiStack_16c[-1];
            uStack_27c._4_4_ = (int *******)(uStack_158 + 0x24);
            if (0x1f < (uint)((int)ppppppiStack_16c + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
          }
          ppppppiStack_280 = (int ******)0xa107b3;
          uStack_27c._0_4_ = (undefined **)pppppppiVar13;
          FUN_01674ea0();
        }
        uStack_15c = 0;
        uStack_158 = 0xf;
        ppppppiStack_16c = (int ******)((uint)ppppppiStack_16c & 0xffffff00);
        if (0xf < uStack_170) {
          uStack_27c._4_4_ = (int *******)(uStack_170 + 1);
          pppppppiVar13 = (int *******)ppppppiStack_184;
          if (0xfff < uStack_27c._4_4_) {
            pppppppiVar13 = (int *******)ppppppiStack_184[-1];
            uStack_27c._4_4_ = (int *******)(uStack_170 + 0x24);
            if (0x1f < (uint)((int)ppppppiStack_184 + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
          }
          ppppppiStack_280 = (int ******)0xa10808;
          uStack_27c._0_4_ = (undefined **)pppppppiVar13;
          FUN_01674ea0();
        }
        uStack_174 = 0;
        uStack_170 = 0xf;
        ppppppiStack_184 = (int ******)((uint)ppppppiStack_184 & 0xffffff00);
        if (0xf < uStack_188) {
          uStack_27c._4_4_ = (int *******)(uStack_188 + 1);
          pppppppiVar13 = (int *******)appppppiStack_19c[0];
          if (0xfff < uStack_27c._4_4_) {
            pppppppiVar13 = (int *******)appppppiStack_19c[0][-1];
            uStack_27c._4_4_ = (int *******)(uStack_188 + 0x24);
            if (0x1f < (uint)((int)appppppiStack_19c[0] + (-4 - (int)pppppppiVar13)))
            goto LAB_00a11108;
          }
          ppppppiStack_280 = (int ******)0xa1085d;
          uStack_27c._0_4_ = (undefined **)pppppppiVar13;
          FUN_01674ea0();
        }
        uStack_18c = 0;
        uStack_188 = 0xf;
        appppppiStack_19c[0] = (int ******)((uint)appppppiStack_19c[0] & 0xffffff00);
        uStack_27c._4_4_ = (int *******)0xa10886;
        FUN_005507b0();
        uStack_27c._4_4_ = (int *******)0xa10891;
        FUN_005507b0();
        uStack_27c._4_4_ = (int *******)0xa1089c;
        FUN_005507b0();
        uStack_27c._4_4_ = (int *******)0xa108a7;
        FUN_005507b0();
        goto LAB_00a108fd;
      }
      uStack_ec = uStack_ec & 0xffffffff;
      pppuStack_e4 = (undefined ***)&DAT_0000000f;
      pppppiStack_f8 = (int *****)((uint)pppppiStack_f8 & 0xffffff00);
      ppppppiStack_280 = (int ******)0xa0ffdd;
      FUN_005542c0();
      uStack_27c._4_4_ = (int *******)0x0;
      uStack_27c._0_4_ = (undefined **)&DAT_018bc9b8;
      uStack_8._0_1_ = 7;
      uStack_c8 = 0;
      uStack_c4 = 0xf;
      appppppiStack_d8[0] = (int ******)((uint)appppppiStack_d8[0] & 0xffffff00);
      ppppppiStack_280 = (int ******)0xa1000e;
      FUN_005542c0();
      uStack_27c._4_4_ = (int *******)0x1b;
      uStack_27c._0_4_ = (undefined **)0x193ef64;
      uStack_8._0_1_ = 8;
      uStack_b0 = 0;
      uStack_ac = 0xf;
      appppppiStack_c0[0] = (int ******)((uint)appppppiStack_c0[0] & 0xffffff00);
      ppppppiStack_280 = (int ******)0xa1003f;
      FUN_005542c0();
      uStack_27c._4_4_ = (int *******)0x12;
      uStack_27c._0_4_ = (undefined **)0x18c888c;
      uStack_8._0_1_ = 9;
      uStack_98 = 0;
      uStack_94 = 0xf;
      appppppiStack_a8[0] = (int ******)((uint)appppppiStack_a8[0] & 0xffffff00);
      ppppppiStack_280 = (int ******)0xa10070;
      FUN_005542c0();
      uStack_27c._4_4_ = (int *******)0x4;
      uStack_27c._0_4_ = (undefined **)&DAT_018c71bc;
      uStack_8._0_1_ = 10;
      uStack_80 = 0;
      uStack_7c = 0xf;
      appppppiStack_90[0] = (int ******)((uint)appppppiStack_90[0] & 0xffffff00);
      ppppppiStack_280 = (int ******)0xa1009b;
      FUN_005542c0();
      uStack_27c._4_4_ = (int *******)&pppppiStack_f8;
      uStack_8._0_1_ = 0xb;
      uStack_27c._0_4_ = (undefined **)appppppiStack_d8;
      ppppppiStack_280 = (int ******)appppppiStack_c0;
      ppppppiStack_284 = (int ******)appppppiStack_a8;
      ppppppiStack_288 = (int ******)appppppiStack_90;
      ppppppiStack_28c = (int ******)appppppiStack_19c;
      FUN_0151bcc0();
      uStack_27c._4_4_ = &ppppppiStack_54;
      uStack_8._0_1_ = 0xc;
      uStack_27c._0_4_ = (undefined **)0xa100e0;
      ppppppiStack_14 = (int ******)FUN_0151bb70();
      if (&ppppppiStack_74 != (int *******)ppppppiStack_14) {
        if (0xf < uStack_64._4_4_) {
          uStack_27c._4_4_ = (int *******)(uStack_64._4_4_ + 1);
          pppppppiVar13 = (int *******)ppppppiStack_74;
          if (0xfff < uStack_27c._4_4_) {
            pppppppiVar13 = (int *******)ppppppiStack_74[-1];
            uStack_27c._4_4_ = (int *******)(uStack_64._4_4_ + 0x24);
            if (0x1f < (uint)((int)ppppppiStack_74 + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
          }
          ppppppiStack_280 = (int ******)0xa1011b;
          uStack_27c._0_4_ = (undefined **)pppppppiVar13;
          FUN_01674ea0();
        }
        ppppppiStack_74 = (int ******)*ppppppiStack_14;
        pppppiStack_70 = ppppppiStack_14[1];
        pppppiStack_6c = ppppppiStack_14[2];
        pppppiStack_68 = ppppppiStack_14[3];
        uStack_64 = *(undefined8 *)(ppppppiStack_14 + 4);
        ppppppiStack_14[4] = (int *****)0x0;
        ppppppiStack_14[5] = (int *****)0xf;
        *(undefined *)ppppppiStack_14 = 0;
      }
      if (0xf < uStack_40) {
        uStack_27c._4_4_ = (int *******)(uStack_40 + 1);
        pppppppiVar13 = (int *******)ppppppiStack_54;
        if (0xfff < uStack_27c._4_4_) {
          pppppppiVar13 = (int *******)ppppppiStack_54[-1];
          uStack_27c._4_4_ = (int *******)(uStack_40 + 0x24);
          if (0x1f < (uint)((int)ppppppiStack_54 + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
        }
        ppppppiStack_280 = (int ******)0xa10186;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_01674ea0();
      }
      uStack_44 = 0;
      uStack_40 = 0xf;
      ppppppiStack_54 = (int ******)((uint)ppppppiStack_54 & 0xffffff00);
      uStack_8._0_1_ = 0xb;
      if (0xf < uStack_128) {
        uStack_27c._4_4_ = (int *******)(uStack_128 + 1);
        pppppppiVar13 = (int *******)ppppppiStack_13c;
        if (0xfff < uStack_27c._4_4_) {
          pppppppiVar13 = (int *******)ppppppiStack_13c[-1];
          uStack_27c._4_4_ = (int *******)(uStack_128 + 0x24);
          if (0x1f < (uint)((int)ppppppiStack_13c + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
        }
        ppppppiStack_280 = (int ******)0xa101d6;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_01674ea0();
      }
      uStack_12c = 0;
      uStack_128 = 0xf;
      ppppppiStack_13c = (int ******)((uint)ppppppiStack_13c & 0xffffff00);
      if (0xf < uStack_140) {
        uStack_27c._4_4_ = (int *******)(uStack_140 + 1);
        pppppppiVar13 = (int *******)ppppppiStack_154;
        if (0xfff < uStack_27c._4_4_) {
          pppppppiVar13 = (int *******)ppppppiStack_154[-1];
          uStack_27c._4_4_ = (int *******)(uStack_140 + 0x24);
          if (0x1f < (uint)((int)ppppppiStack_154 + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
        }
        ppppppiStack_280 = (int ******)0xa1022b;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_01674ea0();
      }
      uStack_144 = 0;
      uStack_140 = 0xf;
      ppppppiStack_154 = (int ******)((uint)ppppppiStack_154 & 0xffffff00);
      if (0xf < uStack_158) {
        uStack_27c._4_4_ = (int *******)(uStack_158 + 1);
        pppppppiVar13 = (int *******)ppppppiStack_16c;
        if (0xfff < uStack_27c._4_4_) {
          pppppppiVar13 = (int *******)ppppppiStack_16c[-1];
          uStack_27c._4_4_ = (int *******)(uStack_158 + 0x24);
          if (0x1f < (uint)((int)ppppppiStack_16c + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
        }
        ppppppiStack_280 = (int ******)0xa10280;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_01674ea0();
      }
      uStack_15c = 0;
      uStack_158 = 0xf;
      ppppppiStack_16c = (int ******)((uint)ppppppiStack_16c & 0xffffff00);
      if (0xf < uStack_170) {
        uStack_27c._4_4_ = (int *******)(uStack_170 + 1);
        pppppppiVar13 = (int *******)ppppppiStack_184;
        if (0xfff < uStack_27c._4_4_) {
          pppppppiVar13 = (int *******)ppppppiStack_184[-1];
          uStack_27c._4_4_ = (int *******)(uStack_170 + 0x24);
          if (0x1f < (uint)((int)ppppppiStack_184 + (-4 - (int)pppppppiVar13))) goto LAB_00a11108;
        }
        ppppppiStack_280 = (int ******)0xa102d5;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_01674ea0();
      }
      uStack_174 = 0;
      uStack_170 = 0xf;
      ppppppiStack_184 = (int ******)((uint)ppppppiStack_184 & 0xffffff00);
      if (0xf < uStack_188) {
        uStack_27c._4_4_ = (int *******)(uStack_188 + 1);
        pppppppiVar13 = (int *******)appppppiStack_19c[0];
        if (0xfff < uStack_27c._4_4_) {
          pppppppiVar13 = (int *******)appppppiStack_19c[0][-1];
          uStack_27c._4_4_ = (int *******)(uStack_188 + 0x24);
          if (0x1f < (uint)((int)appppppiStack_19c[0] + (-4 - (int)pppppppiVar13)))
          goto LAB_00a11108;
        }
        ppppppiStack_280 = (int ******)0xa1032a;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_01674ea0();
      }
      uStack_18c = 0;
      uStack_188 = 0xf;
      appppppiStack_19c[0] = (int ******)((uint)appppppiStack_19c[0] & 0xffffff00);
      uStack_8._0_1_ = 10;
      if (0xf < uStack_7c) {
        uStack_27c._4_4_ = (int *******)(uStack_7c + 1);
        pppppppiVar13 = (int *******)appppppiStack_90[0];
        if (0xfff < uStack_27c._4_4_) {
          pppppppiVar13 = (int *******)appppppiStack_90[0][-1];
          uStack_27c._4_4_ = (int *******)(uStack_7c + 0x24);
          if (0x1f < (uint)((int)appppppiStack_90[0] + (-4 - (int)pppppppiVar13)))
          goto LAB_00a11108;
        }
        ppppppiStack_280 = (int ******)0xa10380;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_01674ea0();
      }
      uStack_80 = 0;
      uStack_7c = 0xf;
      appppppiStack_90[0] = (int ******)((uint)appppppiStack_90[0] & 0xffffff00);
      uStack_8._0_1_ = 9;
      if (0xf < uStack_94) {
        uStack_27c._4_4_ = (int *******)(uStack_94 + 1);
        pppppppiVar13 = (int *******)appppppiStack_a8[0];
        if (0xfff < uStack_27c._4_4_) {
          pppppppiVar13 = (int *******)appppppiStack_a8[0][-1];
          uStack_27c._4_4_ = (int *******)(uStack_94 + 0x24);
          if (0x1f < (uint)((int)appppppiStack_a8[0] + (-4 - (int)pppppppiVar13)))
          goto LAB_00a11108;
        }
        ppppppiStack_280 = (int ******)0xa103d3;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_01674ea0();
      }
      uStack_98 = 0;
      uStack_94 = 0xf;
      appppppiStack_a8[0] = (int ******)((uint)appppppiStack_a8[0] & 0xffffff00);
      uStack_8._0_1_ = 8;
      if (0xf < uStack_ac) {
        uStack_27c._4_4_ = (int *******)(uStack_ac + 1);
        pppppppiVar13 = (int *******)appppppiStack_c0[0];
        if (0xfff < uStack_27c._4_4_) {
          pppppppiVar13 = (int *******)appppppiStack_c0[0][-1];
          uStack_27c._4_4_ = (int *******)(uStack_ac + 0x24);
          if (0x1f < (uint)((int)appppppiStack_c0[0] + (-4 - (int)pppppppiVar13)))
          goto LAB_00a11108;
        }
        ppppppiStack_280 = (int ******)0xa1042c;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_01674ea0();
      }
      uStack_b0 = 0;
      uStack_ac = 0xf;
      appppppiStack_c0[0] = (int ******)((uint)appppppiStack_c0[0] & 0xffffff00);
      uStack_8._0_1_ = 7;
      if (0xf < uStack_c4) {
        uStack_27c._4_4_ = (int *******)(uStack_c4 + 1);
        pppppppiVar13 = (int *******)appppppiStack_d8[0];
        if (0xfff < uStack_27c._4_4_) {
          pppppppiVar13 = (int *******)appppppiStack_d8[0][-1];
          uStack_27c._4_4_ = (int *******)(uStack_c4 + 0x24);
          if (0x1f < (uint)((int)appppppiStack_d8[0] + (-4 - (int)pppppppiVar13)))
          goto LAB_00a11108;
        }
        ppppppiStack_280 = (int ******)0xa10485;
        uStack_27c._0_4_ = (undefined **)pppppppiVar13;
        FUN_01674ea0();
      }
      uStack_c8 = 0;
      uStack_c4 = 0xf;
      appppppiStack_d8[0] = (int ******)((uint)appppppiStack_d8[0] & 0xffffff00);
      uStack_8._0_1_ = 6;
      if (&DAT_0000000f < pppuStack_e4) {
        uStack_27c._4_4_ = (int *******)((int)pppuStack_e4 + 1);
        ppppppiVar12 = (int ******)pppppiStack_f8;
        if ((undefined ***)0xfff < uStack_27c._4_4_) {
          ppppppiVar12 = (int ******)pppppiStack_f8[-1];
          uStack_27c._4_4_ = (int *******)(pppuStack_e4 + 9);
          if (0x1f < (uint)((int)pppppiStack_f8 + (-4 - (int)ppppppiVar12))) {
LAB_00a11108:
                    /* WARNING: Subroutine does not return */
            uStack_27c._4_4_ = (int *******)0xa1110d;
            FUN_017167a3();
          }
        }
        ppppppiStack_280 = (int ******)0xa104e2;
        uStack_27c._0_4_ = (undefined **)ppppppiVar12;
        FUN_01674ea0();
      }
    }
    uStack_27c._4_4_ = (int *******)0x18;
    uStack_27c._0_4_ = (undefined **)0xa1090d;
    ppppiStack_10c = (int ****)FUN_01674e20();
    if ((int *****)ppppiStack_10c == (int *****)0x0) {
      uStack_27c._0_4_ = (undefined **)0x0;
    }
    else {
      *(undefined *)ppppiStack_10c = 0;
      uStack_27c._4_4_ = &ppppppiStack_14;
      uStack_27c._0_4_ = &boost::lock_error::vftable_meta_ptr;
      ppppppiStack_280 = (int ******)&DAT_018be100;
      ppppppiStack_14 = (int ******)&DAT_0000000b;
      ppppppiStack_284 = (int ******)0xa10937;
      ppuVar14 = (undefined **)FUN_00563d40();
      ppuVar18 = (undefined **)&DAT_018be194;
      if (ppuVar14 != &boost::lock_error::vftable_meta_ptr) {
        ppuVar18 = ppuVar14;
      }
      ppppiStack_10c[1] = (int ***)*ppuVar18;
      ppppiStack_10c[2] = (int ***)0x0;
      ppppiStack_10c[3] = (int ***)0x3f800000;
      ppppiStack_10c[4] = (int ***)0x0;
      ppppiStack_10c[5] = (int ***)0x0;
      uStack_27c._0_4_ = (undefined **)ppppiStack_10c;
    }
    uStack_27c._4_4_ = (int *******)ppppppiStack_18;
    uStack_38 = 0;
    piStack_34 = (int *)0x0;
    ppppppiStack_280 = (int ******)0xa1098c;
    FUN_005c1af0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
    if ((int *******)ppppppiStack_3c == (int *******)0x0 &&
        (int *******)ppppppiStack_230 == (int *******)0x0) {
      if (cStack_19 == '\0') {
        pppppiStack_20 = (int *****)ppppiStack_28[7][0x110];
        ppppppiStack_14 = (int ******)ppppiStack_28[7][0x111];
      }
      else {
        pppppiStack_20 = (int *****)0xc8;
        ppppppiStack_14 = (int ******)0x0;
      }
      uStack_27c._4_4_ = (int *******)&DAT_01d65a80;
      uStack_27c._0_4_ = (undefined **)0xa109d5;
      iVar15 = FUN_005c4c00();
      ppppiStack_24 = (int ****)(iVar15 + 0x18);
      uStack_27c._4_4_ = (int *******)0xa109e0;
      uVar16 = FUN_0088da50();
      *ppppiStack_24 = (int ***)uVar16;
      uStack_27c._4_4_ = (int *******)0xa109ea;
      ppppppiStack_18 = (int ******)FUN_005c9e80();
      iVar15 = (int)ppppiStack_24[1];
      if ((int ******)iVar15 == ppppppiStack_18) {
        ppppiStack_24[2] = (int ***)pppppiStack_20;
        ppppiStack_24[3] = (int ***)ppppppiStack_14;
      }
      else {
        if (iVar15 != 0) {
          uStack_27c._4_4_ = (int *******)(ppppiStack_24 + 2);
          uStack_27c._0_4_ = (undefined **)0xa10a14;
          (**(code **)(iVar15 + 8))();
        }
        ppppiStack_24[2] = (int ***)pppppiStack_20;
        ppppiStack_24[3] = (int ***)ppppppiStack_14;
        ppppiStack_24[1] = (int ***)ppppppiStack_18;
      }
      if (cStack_19 == '\0') {
        pppiVar6 = (int ***)ppppiStack_28[7][0x10f];
        pppppiStack_20 = (int *****)((int)*pppiVar6 - (int)pppiVar6);
        ppppiStack_24 = (int ****)((int)pppiVar6[1] - (int)pppiVar6);
      }
      else {
        pppppiStack_20 = (int *****)0xc8;
        ppppiStack_24 = (int ****)0x0;
      }
      uStack_27c._4_4_ = (int *******)&DAT_01d65a98;
      uStack_27c._0_4_ = (undefined **)0xa10a6a;
      iVar15 = FUN_005c4c00();
      ppppppiStack_14 = (int ******)(iVar15 + 0x18);
      uStack_27c._4_4_ = (int *******)0xa10a75;
      pppppiVar17 = (int *****)FUN_0088da50();
      *ppppppiStack_14 = pppppiVar17;
      uStack_27c._4_4_ = (int *******)0xa10a7f;
      ppppppiStack_18 = (int ******)FUN_005c9e80();
      pppppiVar17 = ppppppiStack_14[1];
      if ((int ******)pppppiVar17 == ppppppiStack_18) {
        ppppppiStack_14[2] = pppppiStack_20;
        ppppppiStack_14[3] = (int *****)ppppiStack_24;
      }
      else {
        if (pppppiVar17 != (int *****)0x0) {
          uStack_27c._4_4_ = (int *******)(ppppppiStack_14 + 2);
          uStack_27c._0_4_ = (undefined **)0xa10aa9;
          (*(code *)pppppiVar17[2])();
        }
        ppppppiStack_14[2] = pppppiStack_20;
        ppppppiStack_14[3] = (int *****)ppppiStack_24;
        ppppppiStack_14[1] = (int *****)ppppppiStack_18;
      }
    }
    uStack_27c._4_4_ = (int *******)&DAT_01d65bb8;
    ppppppiStack_14 = (int ******)pppiVar5[10];
    uStack_27c._0_4_ = (undefined **)0xa10ada;
    iVar15 = FUN_005c4c00();
    ppppppiStack_18 = (int ******)(iVar15 + 0x18);
    uStack_27c._4_4_ = (int *******)0xa10ae5;
    uVar16 = FUN_0088cb40();
    uStack_27c._4_4_ = (int *******)ppppppiStack_14;
    *ppppppiStack_18 = (int *****)uVar16;
    uStack_27c._0_4_ = (undefined **)0xa10af5;
    FUN_005c17a0();
    ppppppiStack_18 = (int ******)appppppiStack_24c;
    if (0xf < uStack_238) {
      ppppppiStack_18 = appppppiStack_24c[0];
    }
    ppppppiStack_14 = (int ******)&ppppppiStack_28c;
    uStack_27c._0_4_ = (undefined **)0x0;
    uStack_27c._4_4_ = (int *******)0x0;
    if (ppppiStack_23c < (int *****)0x10) {
      ppppppiStack_28c = (int ******)*ppppppiStack_18;
      ppppppiStack_288 = ((int *******)ppppppiStack_18)[1];
      ppppppiStack_284 = ((int *******)ppppppiStack_18)[2];
      ppppppiStack_280 = ((int *******)ppppppiStack_18)[3];
      uStack_27c._0_4_ = (undefined **)ppppiStack_23c;
      uStack_27c._4_4_ = (int *******)0xf;
    }
    else {
      pppppiStack_20 = (int *****)((uint)ppppiStack_23c | 0xf);
      if ((int *****)0x7fffffff < pppppiStack_20) {
        pppppiStack_20 = (int *****)0x7fffffff;
      }
      pppppiVar17 = (int *****)FUN_00554060((int)pppppiStack_20 + 1);
      *ppppppiStack_14 = pppppiVar17;
      FUN_0170c6f0(pppppiVar17,ppppppiStack_18,(int)ppppiStack_23c + 1);
      ppppppiVar12 = ppppppiStack_14;
      ppppppiStack_14[4] = (int *****)ppppiStack_23c;
      ppppppiVar12[5] = pppppiStack_20;
    }
    pppppiStack_20 = (int *****)FUN_00a0b230(&ppppppiStack_54);
    uStack_27c._4_4_ = (int *******)&DAT_01d65bd0;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
    uStack_27c._0_4_ = (undefined **)0xa10ba4;
    iVar15 = FUN_005c4c00();
    ppppppiStack_14 = (int ******)(iVar15 + 0x18);
    uStack_27c._4_4_ = (int *******)0xa10baf;
    pppppiVar17 = (int *****)FUN_0088cb40();
    *ppppppiStack_14 = pppppiVar17;
    uStack_27c._4_4_ = (int *******)0xa10bb9;
    ppppppiStack_18 = (int ******)FUN_005c9d30();
    ppppppiVar12 = (int ******)ppppppiStack_14[1];
    if (ppppppiVar12 == ppppppiStack_18) {
      ppppppiStack_18 = ppppppiStack_14 + 2;
      if (ppppppiStack_18 != (int ******)pppppiStack_20) {
        uStack_27c._4_4_ = (int *******)0xa10bdc;
        FUN_005507b0();
        pppppiVar17 = (int *****)pppppiStack_20[1];
        pppppiVar8 = (int *****)pppppiStack_20[2];
        pppppiVar9 = (int *****)pppppiStack_20[3];
        *ppppppiStack_18 = (int *****)*pppppiStack_20;
        ppppppiStack_18[1] = pppppiVar17;
        ppppppiStack_18[2] = pppppiVar8;
        ppppppiStack_18[3] = pppppiVar9;
        *(undefined8 *)(ppppppiStack_18 + 4) = *(undefined8 *)(pppppiStack_20 + 4);
        pppppiStack_20[4] = (int ****)0x0;
        pppppiStack_20[5] = (int ****)0xf;
        *(char *)pppppiStack_20 = '\0';
      }
    }
    else {
      if (ppppppiVar12 != (int ******)0x0) {
        uStack_27c._4_4_ = (int *******)(ppppppiStack_14 + 2);
        uStack_27c._0_4_ = (undefined **)0xa10c12;
        (*(code *)ppppppiVar12[2])();
        ppppppiStack_14[1] = (int *****)0x0;
      }
      ppppppiStack_14[6] = (int *****)0x0;
      ppppppiStack_14[7] = (int *****)0x0;
      pppppiVar17 = (int *****)pppppiStack_20[1];
      pppppiVar8 = (int *****)pppppiStack_20[2];
      pppppiVar9 = (int *****)pppppiStack_20[3];
      ppppppiStack_14[2] = (int *****)*pppppiStack_20;
      ppppppiStack_14[3] = pppppiVar17;
      ppppppiStack_14[4] = pppppiVar8;
      ppppppiStack_14[5] = pppppiVar9;
      *(undefined8 *)(ppppppiStack_14 + 6) = *(undefined8 *)(pppppiStack_20 + 4);
      pppppiStack_20[4] = (int ****)0x0;
      pppppiStack_20[5] = (int ****)0xf;
      *(char *)pppppiStack_20 = '\0';
      ppppppiStack_14[1] = (int *****)ppppppiStack_18;
    }
    uStack_8._0_1_ = 0x14;
    uStack_27c._4_4_ = (int *******)0xa10c64;
    FUN_005507b0();
    uStack_27c._0_4_ = (undefined **)&pppppiStack_30;
    uStack_27c._4_4_ = (int *******)0x0;
    ppppppiStack_280 = (int ******)0xa10c6f;
    FUN_014c9d60();
    uStack_8._0_1_ = 0x16;
    uVar10 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x16;
    if (DAT_01d65a40 == '\0') {
      ppppppiStack_18 = (int ******)pppppiStack_30;
      uStack_27c._0_4_ = (undefined **)&ppppppiStack_74;
      if (0xf < uStack_64._4_4_) {
        uStack_27c._0_4_ = (undefined **)ppppppiStack_74;
      }
      uStack_27c._4_4_ = (int *******)(undefined4)uStack_64;
      ppppppiStack_280 = (int ******)0xa10d6d;
      uStack_8._0_1_ = uVar10;
      FUN_014cbbc0();
      uStack_27c._0_4_ = (undefined **)&DAT_018c88a0;
      pppppiStack_20 = pppppiStack_30;
      if ((int *******)ppppppiStack_3c == (int *******)0x0 &&
          (int *******)ppppppiStack_230 == (int *******)0x0) {
        uStack_27c._0_4_ = (undefined **)&DAT_018c3c98;
      }
      ppppppiStack_14 = (int ******)&uStack_27c;
      ppppppiStack_18 = (int ******)((int)(undefined **)uStack_27c + 1);
      pppppiVar17 = (int *****)(undefined **)uStack_27c;
      do {
        cVar2 = *(char *)pppppiVar17;
        pppppiVar17 = (int *****)((int)pppppiVar17 + 1);
      } while (cVar2 != '\0');
      uStack_27c._4_4_ = (int *******)((int)pppppiVar17 - (int)ppppppiStack_18);
      ppppppiStack_280 = (int ******)0xa10db0;
      FUN_014cba10();
      if (*(char *)((int)ppppiStack_28 + 0x8d) != '\0') {
        ppppppiStack_18 = (int ******)pppppiStack_30;
        uStack_27c._4_4_ = (int *******)0xa10dca;
        uStack_27c = FUN_00928340();
        ppppppiStack_284 = (int ******)&ppppppiStack_54;
        ppppppiStack_280 = (int ******)&DAT_018bed48;
        ppppppiStack_288 = (int ******)0xa10dda;
        pppppiVar17 = (int *****)FUN_01675640();
        uStack_27c._4_4_ = (int *******)pppppiVar17[4];
        uStack_8._0_1_ = 0x18;
        if ((int ****)0xf < pppppiVar17[5]) {
          pppppiVar17 = (int *****)*pppppiVar17;
        }
        ppppppiStack_284 = (int ******)&DAT_01d79ef0;
        if (0xf < DAT_01d79f04) {
          ppppppiStack_284 = (int ******)DAT_01d79ef0;
        }
        ppppppiStack_280 = (int ******)DAT_01d79f00;
        ppppppiStack_288 = (int ******)0xa10e1e;
        uStack_27c._0_4_ = (undefined **)pppppiVar17;
        FUN_014cb8a0();
        uStack_8._0_1_ = 0x16;
        uStack_27c._4_4_ = (int *******)0xa10e2a;
        FUN_005507b0();
      }
      pppppiStack_30[0x2c] = (int ****)0x0;
      ppppppiStack_18 = (int ******)pppppiStack_30;
      uStack_27c._0_4_ = (undefined **)&DAT_01d79f98;
      if (0xf < DAT_01d79fac) {
        uStack_27c._0_4_ = (undefined **)DAT_01d79f98;
      }
      uStack_27c._4_4_ = (int *******)DAT_01d79fa8;
      ppppppiStack_284 = (int ******)&DAT_01d79d70;
      if (0xf < DAT_01d79d84) {
        ppppppiStack_284 = (int ******)DAT_01d79d70;
      }
      ppppppiStack_280 = (int ******)DAT_01d79d80;
      ppppppiStack_288 = (int ******)0xa10e8b;
      FUN_014cb8a0();
    }
    else {
      uStack_27c._0_4_ = (undefined **)&DAT_018c88a0;
      if ((int *******)ppppppiStack_3c == (int *******)0x0 &&
          (int *******)ppppppiStack_230 == (int *******)0x0) {
        uStack_27c._0_4_ = (undefined **)&DAT_018c3c98;
      }
      uStack_44 = 0;
      uStack_40 = 0xf;
      ppppppiStack_54 = (int ******)((uint)ppppppiStack_54 & 0xffffff00);
      ppppppiStack_18 = (int ******)((int)(undefined **)uStack_27c + 1);
      pppppiVar17 = (int *****)(undefined **)uStack_27c;
      do {
        cVar2 = *(char *)pppppiVar17;
        pppppiVar17 = (int *****)((int)pppppiVar17 + 1);
      } while (cVar2 != '\0');
      uStack_27c._4_4_ = (int *******)((int)pppppiVar17 - (int)ppppppiStack_18);
      ppppppiStack_280 = (int ******)0xa10cc6;
      uVar16 = FUN_005542c0();
      uStack_8._0_1_ = 0x17;
      uStack_27c._4_4_ = (int *******)ppppiStack_28[0xd];
      ppppppiStack_280 =
           (int ******)CONCAT31((int3)((uint)uVar16 >> 8),*(undefined *)((int)ppppiStack_28 + 0x8d))
      ;
      uStack_27c._0_4_ = (undefined **)ppppiStack_28[0xc];
      if ((int ****)ppppiStack_28[10] != (int ****)0x0) {
        LOCK();
        ppppiVar7 = (int ****)(ppppiStack_28[10] + 1);
        *ppppiVar7 = (int ***)((int)*ppppiVar7 + 1);
        UNLOCK();
      }
      ppppppiStack_288 = (int ******)ppppiStack_28[9];
      ppppppiStack_284 = (int ******)ppppiStack_28[10];
      ppppppiStack_28c = (int ******)&ppppppiStack_74;
      if ((int *****)ppppiStack_2c != (int *****)0x0) {
        LOCK();
        ppppiStack_2c[1] = (int ***)((int)ppppiStack_2c[1] + 1);
        UNLOCK();
      }
      FUN_00a115a0(pppppiStack_30,ppppiStack_2c,&ppppppiStack_54);
      uStack_27c._4_4_ = (int *******)0xa10d42;
      FUN_005507b0();
    }
    uStack_1fc = 0;
    uStack_1f8 = 0xf;
    auStack_20c[0] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
    uStack_27c._4_4_ = (int *******)0xa10eaf;
    uStack_1f4 = FUN_008881d0();
    puStack_1f0 = (undefined *)0x0;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[1] = piStack_34[1] + 1;
      UNLOCK();
    }
    uStack_1ec = uStack_38;
    piStack_1e8 = piStack_34;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea93d0) {
      uStack_27c._4_4_ = (int *******)&DAT_01ea93d0;
      uStack_27c._0_4_ = (undefined **)0xa11117;
      FUN_016f3809();
      if (DAT_01ea93d0 == -1) {
        uStack_27c._4_4_ = (int *******)&DAT_01ea93d0;
        _DAT_01ea93c4 = FUN_0057bbb0;
        _DAT_01ea93c8 = FUN_005880a0;
        DAT_01ea93cc = FUN_0057d5e0;
        uStack_27c._0_4_ = (undefined **)0xa1114f;
        FUN_016f37bf();
      }
    }
    puStack_1f0 = &DAT_01ea93c4;
    uStack_27c._4_4_ = (int *******)0x1;
    uStack_27c._0_4_ = (undefined **)auStack_20c;
    uStack_8._0_1_ = 0x1a;
    ppppppiStack_280 = (int ******)&uStack_1f4;
    ppppppiStack_284 = (int ******)0xa10f30;
    FUN_0098fc00();
    uStack_8._0_1_ = 0x1b;
    if (puStack_1f0 != (undefined *)0x0) {
      uStack_27c._4_4_ = (int *******)&uStack_1ec;
      uStack_27c._0_4_ = (undefined **)0xa10f4d;
      (**(code **)(puStack_1f0 + 8))();
    }
    uStack_8._0_1_ = 0x19;
    if (cStack_19 == '\0') {
      uStack_78 = CONCAT31(uStack_78._1_3_,1);
      if (DAT_01d65a38 == '\0') goto LAB_00a10f67;
    }
    else {
LAB_00a10f67:
      uStack_78 = uStack_78 & 0xffffff00;
    }
    uStack_27c._4_4_ = (int *******)uStack_78;
    uStack_27c._0_4_ = (undefined **)auStack_20c;
    ppppppiStack_280 = (int ******)0xa10f7d;
    FUN_014cb780();
    ppppppiStack_18 = &pppppiStack_5c;
    if (piStack_dc != (int *)0x0) {
      LOCK();
      piStack_dc[2] = piStack_dc[2] + 1;
      UNLOCK();
    }
    pppppiStack_5c = pppppiStack_e0;
    piStack_58 = piStack_dc;
    uStack_27c._4_4_ = &ppppppiStack_124;
    uStack_8._0_1_ = 0x1c;
    uStack_27c._0_4_ = (undefined **)0xa10fbe;
    FUN_0054ef60();
    pppppiStack_104 = pppppiStack_5c;
    piStack_100 = piStack_58;
    pppuStack_e4 = &ppuStack_108;
    ppppppiStack_fc = ppppppiStack_54;
    pppppiStack_f8 = pppppiStack_50;
    uStack_f4 = uStack_4c;
    uStack_f0 = uStack_48;
    ppuStack_108 = std::
                   _Func_impl_no_alloc<class_<lambda_2e98fbd261150ecdb69f7dc9441cf65c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                   ::vftable;
    uStack_ec = CONCAT44(uStack_40,uStack_44);
    pppppiStack_5c = (int *****)0x0;
    piStack_58 = (int *)0x0;
    uStack_44 = 0;
    uStack_40 = 0xf;
    ppppppiStack_54 = (int ******)((uint)ppppppiStack_54 & 0xffffff00);
    uStack_27c._4_4_ = (int *******)0xa11026;
    FUN_005d11a0();
    uStack_27c._4_4_ = (int *******)&ppuStack_108;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
    uStack_27c._0_4_ = (undefined **)0xa11039;
    FUN_014cb530();
    if (pppuStack_e4 != (undefined ***)0x0) {
      uStack_27c._4_4_ =
           (int *******)CONCAT31((int3)((uint)&ppuStack_108 >> 8),pppuStack_e4 != &ppuStack_108);
      uStack_27c._0_4_ = (undefined **)0xa11056;
      (*(code *)(*pppuStack_e4)[4])();
    }
    uStack_27c._4_4_ = (int *******)0xa11061;
    FUN_005507b0();
    ppppppiStack_18 = (int ******)ppppiStack_2c;
    if ((int *****)ppppiStack_2c != (int *****)0x0) {
      LOCK();
      ppppiVar7 = (int ****)((int)ppppiStack_2c[1] + -1);
      ppppiStack_2c[1] = (int ***)ppppiVar7;
      UNLOCK();
      if (ppppiVar7 == (int ****)0x0) {
        uStack_27c._4_4_ = (int *******)0xa11079;
        (*(code *)**ppppiStack_2c)();
        LOCK();
        ppppiVar7 = (int ****)((int)ppppppiStack_18[2] + -1);
        ppppppiStack_18[2] = (int *****)ppppiVar7;
        UNLOCK();
        if (ppppiVar7 == (int ****)0x0) {
          uStack_27c._4_4_ = (int *******)0xa1108b;
          (*(code *)(*ppppppiStack_18)[1])();
        }
      }
    }
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar15 = piStack_34[1] + -1;
      piStack_34[1] = iVar15;
      UNLOCK();
      if (iVar15 == 0) {
        uStack_27c._4_4_ = (int *******)0xa110a0;
        (**(code **)*piStack_34)();
        LOCK();
        iVar15 = piStack_34[2] + -1;
        piStack_34[2] = iVar15;
        UNLOCK();
        if (iVar15 == 0) {
          uStack_27c._4_4_ = (int *******)0xa110b2;
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
    uStack_27c._4_4_ = (int *******)0xa110ba;
    FUN_005507b0();
    uStack_27c._4_4_ = (int *******)0xa110c5;
    FUN_009f1010();
    uStack_8._0_1_ = 0;
    uStack_27c._4_4_ = (int *******)0xa110d4;
    FUN_005507b0();
    ppppiVar4 = (int ****)*ppppiVar4;
  } while( true );
}



/* FUNCTION 19912 ; VA 0x00a11160 ; FUN_00a11160 */

void __thiscall FUN_00a11160(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dafd8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008c0cc0(&uStack_20,param_1);
  uStack_14 = *(undefined4 *)(param_1 + 0x1c);
  uStack_8 = 0;
  if (piStack_1c != (int *)0x0) {
    piVar1 = piStack_1c + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = 0;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[2] = piStack_1c[2] + 1;
    UNLOCK();
  }
  FUN_00a03a90(uStack_20,piStack_1c,param_2);
  if (piStack_1c != (int *)0x0) {
    piVar1 = piStack_1c + 2;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piStack_1c + 4))(uVar3);
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  FUN_0090ca30(uVar3);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19913 ; VA 0x00a11240 ; FUN_00a11240 */

void FUN_00a11240(undefined4 param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  if (0 < DAT_01ee6bc8) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0;
    FUN_0151f850("CommitStage",param_3);
    uVar2 = FUN_014ca0a0();
    FUN_0151f950(&DAT_018c8720,uVar2);
    FUN_0151f9c0("HttpErrorCode",param_1);
    FUN_0151f9c0("HttpStatusCode",*(undefined4 *)(param_2 + 0xc));
    FUN_0151f950("HttpErrorMessage",param_2 + 0x74);
    iVar1 = DAT_01ee6bc8;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("VersionHistoryCommitErrorHttp",0x1d);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_28,iVar1,0);
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      uVar3 = auStack_28[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_28[0] - 4);
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19914 ; VA 0x00a11370 ; FUN_00a11370 */

void FUN_00a11370(undefined4 param_1,char param_2)

{
  char cVar1;
  char *pcVar2;
  uint uVar3;
  char *pcVar4;
  uint uVar5;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  pcVar4 = "Studio.TeamCreate.CollabEditVersionHistory.";
  uStack_30 = 0;
  if (param_2 == '\0') {
    pcVar4 = "Studio.NonTeamCreate.VersionHistory.";
  }
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar2 = pcVar4;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar4,(int)pcVar2 - (int)(pcVar4 + 1));
  uStack_8 = 0;
  FUN_005f3cd0(auStack_28,auStack_40,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar5);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar5 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar5) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar5 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19915 ; VA 0x00a11480 ; FUN_00a11480 */

void FUN_00a11480(undefined4 param_1,undefined8 param_2,char param_3)

{
  char cVar1;
  uint uVar2;
  char *pcVar3;
  uint uVar4;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  pcVar3 = "Studio.ScriptVersionHistory.CommitTime.";
  uStack_30 = 0;
  if (param_3 == '\0') {
    pcVar3 = "Studio.NonTcScriptVersionHistory.CommitTime.";
  }
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  FUN_005f3cd0(auStack_28,auStack_40,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00878cf0(auStack_28,param_2,0);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19916 ; VA 0x00a115a0 ; FUN_00a115a0 */

int FUN_00a115a0(int param_1,int *param_2,undefined4 *param_3,undefined4 *param_4,undefined4 param_5
                ,int *param_6,char param_7,int param_8,int param_9)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined8 uVar8;
  int aiStack_2c [5];
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db008;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puVar3 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  ExceptionList = &pvStack_10;
  FUN_014cba10(param_3,*puVar3);
  puVar3 = param_4 + 4;
  if (0xf < (uint)param_4[5]) {
    param_4 = (undefined4 *)*param_4;
  }
  FUN_014cbbc0(param_4,*puVar3);
  *(undefined4 *)(param_1 + 0xb0) = 0;
  puVar3 = &DAT_01d79f98;
  if (0xf < DAT_01d79fac) {
    puVar3 = DAT_01d79f98;
  }
  puVar5 = &DAT_01d79d70;
  if (0xf < DAT_01d79d84) {
    puVar5 = DAT_01d79d70;
  }
  iVar4 = FUN_014cb8a0(puVar5,DAT_01d79d80,puVar3,DAT_01d79fa8);
  if (param_7 != '\0') {
    if ((param_9 < 0) ||
       ((uVar8 = CONCAT44(param_9,param_8), param_9 < 1 &&
        (uVar8 = CONCAT44(param_9,param_8), param_8 == 0)))) {
      uVar8 = FUN_00928340();
    }
    puVar5 = (undefined4 *)FUN_01675640(aiStack_2c,&DAT_018bed48,uVar8);
    puVar3 = puVar5 + 4;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    puVar6 = &DAT_01d79ef0;
    if (0xf < DAT_01d79f04) {
      puVar6 = DAT_01d79ef0;
    }
    iVar4 = FUN_014cb8a0(puVar6,DAT_01d79f00,puVar5,*puVar3);
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      iVar4 = aiStack_2c[0];
      if (0xfff < uVar7) {
        iVar4 = *(int *)(aiStack_2c[0] + -4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (aiStack_2c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar4 = FUN_01674ea0(iVar4,uVar7);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 19917 ; VA 0x00a11770 ; FUN_00a11770 */

void __thiscall FUN_00a11770(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  uint *puVar2;
  int *piVar3;
  int iVar4;
  uint *puVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint uVar10;
  int *piVar11;
  int aiStack_144 [5];
  uint uStack_130;
  undefined auStack_cc [8];
  int iStack_c4;
  int *piStack_c0;
  uint uStack_bc;
  undefined4 uStack_ac;
  uint uStack_a8;
  uint auStack_a4 [4];
  undefined4 uStack_94;
  uint uStack_90;
  undefined8 uStack_8c;
  undefined4 uStack_84;
  uint uStack_80;
  undefined4 uStack_70;
  uint uStack_6c;
  int iStack_64;
  int *piStack_60;
  int iStack_5c;
  int *piStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined4 *puStack_34;
  uint uStack_30;
  uint uStack_2c;
  int *piStack_28;
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db059;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  iVar6 = *param_2;
  uStack_14 = 0;
  if (param_2[1] - iVar6 >> 3 != 0) {
    iStack_1c = 0;
    ExceptionList = &pvStack_10;
    iStack_24 = param_1;
    do {
      piVar11 = *(int **)(iVar6 + 4 + uStack_2c * 8);
      if (piVar11 != (int *)0x0) {
        LOCK();
        piVar11[1] = piVar11[1] + 1;
        UNLOCK();
        piVar11 = *(int **)(iVar6 + 4 + uStack_2c * 8);
      }
      iStack_5c = *(int *)(iVar6 + uStack_2c * 8);
      uStack_8 = 0;
      piStack_58 = piVar11;
      if ((iStack_5c == 0) ||
         (iVar6 = *(int *)(iStack_5c + 0xc), puStack_18 = (undefined4 *)iStack_5c,
         iVar4 = FUN_00ae2430(),
         (uint)*(ushort *)(iVar4 + 0x1da) <
         (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
        uVar8 = uStack_14 | 2;
        piStack_48 = (int *)0x0;
        puVar9 = &uStack_4c;
        puStack_18 = (undefined4 *)0x0;
      }
      else {
        if (piVar11 != (int *)0x0) {
          LOCK();
          piVar11[1] = piVar11[1] + 1;
          UNLOCK();
        }
        puVar9 = &uStack_54;
        uVar8 = uStack_14 | 1;
        piStack_50 = piVar11;
      }
      uStack_14 = uVar8 | 4;
      piStack_60 = (int *)puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      piVar3 = piStack_48;
      iStack_64 = (int)puStack_18;
      piStack_28 = piStack_60;
      if (((uVar8 & 2) != 0) && (uStack_14 = uVar8 & 0xfffffffd | 4, piStack_48 != (int *)0x0)) {
        LOCK();
        iVar6 = piStack_48[1] + -1;
        piStack_48[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_48)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar3 = piStack_50;
      if (((uStack_14 & 1) != 0) && (uStack_14 = uStack_14 & 0xfffffffe, piStack_50 != (int *)0x0))
      {
        LOCK();
        iVar6 = piStack_50[1] + -1;
        piStack_50[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_50)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      uStack_ac = 0;
      uStack_a8 = 0xf;
      uStack_bc = uStack_bc & 0xffffff00;
      uStack_94 = 0;
      uStack_90 = 0xf;
      auStack_a4[0] = auStack_a4[0] & 0xffffff00;
      uStack_8c = 0;
      uStack_84 = 0;
      uStack_70 = 0;
      uStack_6c = 0xf;
      uStack_80 = uStack_80 & 0xffffff00;
      uStack_8._0_1_ = 2;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[1] = piStack_28[1] + 1;
        UNLOCK();
      }
      piStack_c0 = piStack_28;
      iStack_c4 = (int)puStack_18;
      puVar5 = (uint *)(*param_3 + iStack_1c);
      if (auStack_a4 != puVar5) {
        puVar2 = puVar5 + 4;
        if (0xf < puVar5[5]) {
          puVar5 = (uint *)*puVar5;
        }
        FUN_005542c0(puVar5,*puVar2);
      }
      puVar5 = (uint *)FUN_00ae4420();
      puStack_34 = (undefined4 *)0x0;
      uStack_30 = 0;
      puStack_18 = (undefined4 *)puVar5[4];
      if (0xf < puVar5[5]) {
        puVar5 = (uint *)*puVar5;
      }
      if (&DAT_0000000f < puStack_18) {
        uStack_20 = (uint)puStack_18 | 0xf;
        if (0x7fffffff < uStack_20) {
          uStack_20 = 0x7fffffff;
        }
        uVar8 = uStack_20 + 1;
        if (uVar8 < 0x1000) {
          if (uVar8 == 0) {
            uStack_44 = 0;
          }
          else {
            uStack_44 = FUN_01674e20(uVar8);
          }
        }
        else {
          uVar10 = uStack_20 + 0x24;
          if (uVar10 <= uVar8) {
            uVar10 = 0xffffffff;
          }
          iVar6 = FUN_01674e20(uVar10);
          if (iVar6 == 0) goto LAB_00a11c9a;
          uStack_44 = iVar6 + 0x23U & 0xffffffe0;
          *(int *)(uStack_44 - 4) = iVar6;
        }
        FUN_0170c6f0(uStack_44,puVar5,(undefined *)((int)puStack_18 + 1));
        uStack_30 = uStack_20;
      }
      else {
        uStack_44 = *puVar5;
        uStack_40 = puVar5[1];
        uStack_3c = puVar5[2];
        uStack_38 = puVar5[3];
        uStack_30 = 0xf;
      }
      iVar6 = iStack_24;
      uStack_8._0_1_ = 3;
      puStack_34 = puStack_18;
      FUN_0054ef60(&uStack_44);
      uStack_8._0_1_ = 4;
      FUN_00a042a0(&iStack_c4);
      uStack_8._0_1_ = 5;
      uStack_20 = **(uint **)(iVar6 + 0x3c);
      puStack_18 = *(undefined4 **)(uStack_20 + 4);
      uVar7 = FUN_00a03570(uStack_20,puStack_18,aiStack_144);
      if (*(int *)(iVar6 + 0x40) == 0x1fffffe) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(iVar6 + 0x40) = *(int *)(iVar6 + 0x40) + 1;
      *(undefined4 *)(uStack_20 + 4) = uVar7;
      *puStack_18 = uVar7;
      FUN_00a03690(auStack_cc,**(int **)(iVar6 + 0x3c) + 8,**(int **)(iVar6 + 0x3c));
      uStack_8._0_1_ = 3;
      FUN_009f1010();
      if (0xf < uStack_130) {
        uVar8 = uStack_130 + 1;
        iVar6 = aiStack_144[0];
        if (0xfff < uVar8) {
          iVar6 = *(int *)(aiStack_144[0] + -4);
          uVar8 = uStack_130 + 0x24;
          if (0x1f < (aiStack_144[0] - iVar6) - 4U) goto LAB_00a11c9a;
        }
        FUN_01674ea0(iVar6,uVar8);
      }
      uStack_8._0_1_ = 2;
      if (0xf < uStack_30) {
        uVar10 = uStack_30 + 1;
        uVar8 = uStack_44;
        if (0xfff < uVar10) {
          uVar8 = *(uint *)(uStack_44 - 4);
          uVar10 = uStack_30 + 0x24;
          if (0x1f < (uStack_44 - uVar8) - 4) goto LAB_00a11c9a;
        }
        FUN_01674ea0(uVar8,uVar10);
      }
      uStack_8._0_1_ = 1;
      if (0xf < uStack_6c) {
        uVar10 = uStack_6c + 1;
        uVar8 = uStack_80;
        if (0xfff < uVar10) {
          uVar8 = *(uint *)(uStack_80 - 4);
          uVar10 = uStack_6c + 0x24;
          if (0x1f < (uStack_80 - uVar8) - 4) goto LAB_00a11c9a;
        }
        FUN_01674ea0(uVar8,uVar10);
      }
      if (0xf < uStack_90) {
        uVar10 = uStack_90 + 1;
        uVar8 = auStack_a4[0];
        if (0xfff < uVar10) {
          uVar8 = *(uint *)(auStack_a4[0] - 4);
          uVar10 = uStack_90 + 0x24;
          if (0x1f < (auStack_a4[0] - uVar8) - 4) goto LAB_00a11c9a;
        }
        FUN_01674ea0(uVar8,uVar10);
      }
      if (0xf < uStack_a8) {
        uVar10 = uStack_a8 + 1;
        uVar8 = uStack_bc;
        if (0xfff < uVar10) {
          uVar8 = *(uint *)(uStack_bc - 4);
          uVar10 = uStack_a8 + 0x24;
          if (0x1f < (uStack_bc - uVar8) - 4) {
LAB_00a11c9a:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar8,uVar10);
      }
      piVar3 = piStack_c0;
      if (piStack_c0 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_c0[1] + -1;
        piStack_c0[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_c0)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar3 = piStack_28;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_28[1] + -1;
        piStack_28[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      uStack_8 = 0xffffffff;
      if (piVar11 != (int *)0x0) {
        LOCK();
        iVar6 = piVar11[1] + -1;
        piVar11[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar11)();
          LOCK();
          iVar6 = piVar11[2] + -1;
          piVar11[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      iStack_1c = iStack_1c + 0x18;
      uStack_2c = uStack_2c + 1;
      iVar6 = *param_2;
    } while (uStack_2c < (uint)(param_2[1] - iVar6 >> 3));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19918 ; VA 0x00a11ca0 ; FUN_00a11ca0 */

void __thiscall FUN_00a11ca0(int param_1,undefined4 param_2,undefined param_3)

{
  *(undefined4 *)(param_1 + 0x88) = param_2;
  *(undefined *)(param_1 + 0x8c) = param_3;
  FUN_00a0f1f0();
  return;
}



/* FUNCTION 19919 ; VA 0x00a11cc0 ; FUN_00a11cc0 */

int * __thiscall FUN_00a11cc0(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  undefined4 ****ppppuVar4;
  int iVar5;
  uint uVar6;
  undefined auStack_128 [24];
  undefined auStack_110 [60];
  int *piStack_d4;
  int *piStack_d0;
  int *piStack_c4;
  uint *puStack_c0;
  int *piStack_b4;
  uint uStack_a8;
  uint uStack_a4;
  undefined4 ***apppuStack_48 [3];
  undefined auStack_3c [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 ***apppuStack_30 [3];
  undefined auStack_24 [8];
  uint uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db0c2;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (DAT_01d65cbc == '\0') goto LAB_00a11e2a;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uStack_8 = 0;
  uVar1 = FUN_005925c0(param_1,&DAT_0193f580,param_2);
  uVar1 = FUN_00558890(uVar1);
  FUN_00558890(uVar1);
  if (DAT_01d65cbc != '\0') {
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uStack_38 = 0;
    uStack_34 = 0xf;
    apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffffff00);
    piStack_14 = (int *)0x2;
    if (((uStack_a4 & 2) == 0) && (uVar6 = *puStack_c0, uVar6 != 0)) {
      if (uVar6 < uStack_a8) {
        uVar6 = uStack_a8;
      }
      iVar2 = *piStack_d0;
      iVar5 = uVar6 - iVar2;
LAB_00a11dae:
      FUN_005542c0(iVar2,iVar5);
    }
    else if (((uStack_a4 & 4) == 0) && (*piStack_c4 != 0)) {
      iVar2 = *piStack_d4;
      iVar5 = (*piStack_c4 - iVar2) + *piStack_b4;
      goto LAB_00a11dae;
    }
    uStack_8 = 2;
    ppppuVar4 = apppuStack_48;
    if (0xf < uStack_34) {
      ppppuVar4 = (undefined4 ****)apppuStack_48[0];
    }
    FUN_01677650(DAT_01d65cbc,"ScopedNamedMutex(%s",ppppuVar4);
    uStack_8 = uStack_8 & 0xffffff00;
    if (0xf < uStack_34) {
      uVar6 = uStack_34 + 1;
      ppppuVar4 = (undefined4 ****)apppuStack_48[0];
      if (0xfff < uVar6) {
        ppppuVar4 = (undefined4 ****)apppuStack_48[0][-1];
        uVar6 = uStack_34 + 0x24;
        if (0x1f < (uint)((int)apppuStack_48[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar4,uVar6);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_005705c0();
LAB_00a11e2a:
  iVar2 = CreateMutexA(0,0,param_2);
  *param_1 = iVar2;
  if (iVar2 != 0) {
    iVar2 = WaitForSingleObject(iVar2,0xffffffff);
    if (iVar2 != -1) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    piVar3 = (int *)FUN_01685730();
    uStack_18 = GetLastError();
    piStack_14 = piVar3;
    if (DAT_01d65cbc != '\0') {
      (**(code **)(*piVar3 + 8))(apppuStack_30,uStack_18);
      uStack_8 = 5;
      ppppuVar4 = apppuStack_30;
      if (0xf < uStack_1c) {
        ppppuVar4 = (undefined4 ****)apppuStack_30[0];
      }
      FUN_01677650(DAT_01d65cbc,"ScopedNamedMutex: WaitForSingleObject failed: %s",ppppuVar4);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_1c) {
        uVar6 = uStack_1c + 1;
        ppppuVar4 = (undefined4 ****)apppuStack_30[0];
        if (0xfff < uVar6) {
          ppppuVar4 = (undefined4 ****)apppuStack_30[0][-1];
          uVar6 = uStack_1c + 0x24;
          if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar4,uVar6);
      }
    }
    FUN_00555370(auStack_128);
    uStack_8 = 6;
    uVar1 = FUN_005543f0();
    FUN_016756b0(auStack_3c,"ScopedNamedMutex: WaitForSingleObject failed: %s",uVar1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_3c,&DAT_01c17198);
  }
  piVar3 = (int *)FUN_01685730();
  uStack_18 = GetLastError();
  piStack_14 = piVar3;
  if (DAT_01d65cbc != '\0') {
    (**(code **)(*piVar3 + 8))(apppuStack_30,uStack_18);
    uStack_8 = 3;
    ppppuVar4 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar4 = (undefined4 ****)apppuStack_30[0];
    }
    FUN_01677650(DAT_01d65cbc,"ScopedNamedMutex: CreateMutex failed: %s",ppppuVar4);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_1c) {
      uVar6 = uStack_1c + 1;
      ppppuVar4 = (undefined4 ****)apppuStack_30[0];
      if (0xfff < uVar6) {
        ppppuVar4 = (undefined4 ****)apppuStack_30[0][-1];
        uVar6 = uStack_1c + 0x24;
        if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar4,uVar6);
    }
  }
  FUN_00555370(auStack_110);
  uStack_8 = 4;
  uVar1 = FUN_005543f0();
  FUN_016756b0(auStack_24,"ScopedNamedMutex: CreateMutex failed: %s",uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c17198);
}



/* FUNCTION 19920 ; VA 0x00a12030 ; FUN_00a12030 */

void __fastcall FUN_00a12030(int *param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  int aiStack_40 [5];
  uint uStack_2c;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*param_1 != 0) && (ExceptionList = &pvStack_10, iVar1 = ReleaseMutex(*param_1), iVar1 == 0))
  {
    if (DAT_01d65cbc == '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    piVar2 = (int *)FUN_01685730();
    uVar3 = GetLastError();
    FUN_00565940(3,1);
    uVar4 = FUN_005925c0(param_1,&DAT_0193f580);
    uVar4 = FUN_00558890(uVar4);
    (**(code **)(*piVar2 + 8))(apppuStack_28,uVar3);
    ppppuVar6 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar6 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0055b3b0(uVar4,ppppuVar6,uStack_18);
    FUN_005507b0();
    if (DAT_01d65cbc != '\0') {
      puVar5 = (undefined4 *)FUN_0058c4d0(aiStack_40);
      if (0xf < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      FUN_01677650(DAT_01d65cbc,"~ScopedNamedMutex(%s",puVar5);
      if (0xf < uStack_2c) {
        uVar7 = uStack_2c + 1;
        iVar1 = aiStack_40[0];
        if (0xfff < uVar7) {
          iVar1 = *(int *)(aiStack_40[0] + -4);
          uVar7 = uStack_2c + 0x24;
          if (0x1f < (aiStack_40[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar1,uVar7);
      }
    }
    FUN_005705c0();
    ExceptionList = pvStack_10;
    return;
  }
  if (DAT_01d65cbc != '\0') {
    FUN_016774b0(DAT_01d65cbc,"~ScopedNamedMutex(%p)",param_1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19921 ; VA 0x00a12190 ; FUN_00a12190 */

undefined4 * __thiscall FUN_00a12190(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_480cffa5aabb0a0171f595491510fd61>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[4] = param_2[2];
  param_1[5] = param_2[3];
  param_1[6] = param_2[4];
  param_1[7] = param_2[5];
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[8] = param_2[6];
  param_1[9] = param_2[7];
  param_2[6] = 0;
  param_2[7] = 0;
  return param_1;
}



/* FUNCTION 19922 ; VA 0x00a12210 ; FUN_00a12210 */

undefined4 * __thiscall
FUN_00a12210(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0193faf8;
  cVar3 = FUN_00a13270(param_2,param_3,param_4,param_5,param_6);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 19923 ; VA 0x00a12310 ; FUN_00a12310 */

void FUN_00a12310(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00616d10(param_1,param_2);
  param_4 = (undefined4 *)*param_4;
  *(undefined4 *)(iVar4 + 0x18) = 0;
  *(undefined4 *)(iVar4 + 0x1c) = 0;
  uVar1 = param_4[1];
  uVar2 = param_4[2];
  uVar3 = param_4[3];
  *(undefined4 *)(iVar4 + 8) = *param_4;
  *(undefined4 *)(iVar4 + 0xc) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar2;
  *(undefined4 *)(iVar4 + 0x14) = uVar3;
  *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(param_4 + 4);
  param_4[4] = 0;
  param_4[5] = 0xf;
  *(undefined *)param_4 = 0;
  *(undefined4 *)(iVar4 + 0x20) = 0;
  return;
}



/* FUNCTION 19924 ; VA 0x00a12360 ; FUN_00a12360 */

undefined4 FUN_00a12360(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db0e0;
  pvStack_10 = ExceptionList;
  uVar1 = *param_2;
  piVar2 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  uStack_8 = 1;
  iVar3 = FUN_0170d75d(uVar1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::PackageLink::RTTI_Type_Descriptor,0);
  if (iVar3 == 0) {
    iVar3 = 0;
    piVar4 = (int *)0x0;
  }
  else {
    piVar4 = piVar2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if ((iVar3 != 0) && ((iVar3 = FUN_00c0b480(), iVar3 == 0 || (iVar3 = FUN_00c0b480(), iVar3 == 1)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[1] + -1;
      piVar4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar3 = piVar4[2] + -1;
        piVar4[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar4 = piVar2 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar4 = piVar2 + 2;
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 19925 ; VA 0x00a124b0 ; FUN_00a124b0 */

int __thiscall FUN_00a124b0(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  
  iVar7 = *param_1;
  iVar8 = param_2 - iVar7 >> 3;
  iVar3 = param_1[1] - iVar7 >> 3;
  if (iVar3 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar6 = param_1[2] - iVar7 >> 3;
  uVar9 = uVar1;
  if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar9 = (uVar6 >> 1) + uVar6, uVar9 < uVar1)) {
    uVar9 = uVar1;
  }
  puVar4 = (undefined4 *)FUN_00578020(uVar9);
  puVar4[iVar8 * 2] = 0;
  puVar4[iVar8 * 2 + 1] = 0;
  puVar2 = puVar4 + iVar8 * 2;
  *puVar2 = *param_3;
  puVar2[1] = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  iVar3 = param_1[1];
  iVar7 = *param_1;
  puVar5 = puVar4;
  if (param_2 != iVar3) {
    FUN_006cfaf0(iVar7,param_2,puVar4,param_1);
    iVar3 = param_1[1];
    puVar5 = puVar2 + 2;
    iVar7 = param_2;
  }
  FUN_006cfaf0(iVar7,iVar3,puVar5,param_1);
  FUN_00777d00(puVar4,uVar1,uVar9);
  return *param_1 + iVar8 * 8;
}



/* FUNCTION 19926 ; VA 0x00a125a0 ; FUN_00a125a0 */

undefined4 * FUN_00a125a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  *puVar2 = std::
            _Func_impl_no_alloc<class_<lambda_480cffa5aabb0a0171f595491510fd61>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
            ::vftable;
  puVar2[2] = 0;
  puVar2[3] = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[2] = *param_1;
  puVar2[3] = param_1[1];
  puVar2[4] = param_1[2];
  puVar2[5] = param_1[3];
  puVar2[6] = param_1[4];
  puVar2[7] = param_1[5];
  puVar2[8] = 0;
  puVar2[9] = 0;
  if (param_1[7] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[7] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[8] = param_1[6];
  puVar2[9] = param_1[7];
  return puVar2;
}



/* FUNCTION 19927 ; VA 0x00a12620 ; FUN_00a12620 */

undefined4 FUN_00a12620(undefined4 param_1)

{
  undefined4 extraout_ECX;
  
  FUN_01674e20(0x28);
  FUN_00a12190(param_1);
  return extraout_ECX;
}



/* FUNCTION 19928 ; VA 0x00a12640 ; FUN_00a12640 */

undefined4 * FUN_00a12640(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  *puVar2 = std::
            _Func_impl_no_alloc<class_<lambda_cdeecfec3d3fad15adf9c8fa882ebced>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
            ::vftable;
  puVar2[2] = 0;
  puVar2[3] = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[2] = *param_1;
  puVar2[3] = param_1[1];
  puVar2[4] = param_1[2];
  puVar2[5] = param_1[3];
  puVar2[6] = param_1[4];
  puVar2[7] = param_1[5];
  puVar2[8] = param_1[6];
  return puVar2;
}



/* FUNCTION 19929 ; VA 0x00a126a0 ; FUN_00a126a0 */

undefined4 * FUN_00a126a0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x28);
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_cdeecfec3d3fad15adf9c8fa882ebced>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
            ::vftable;
  puVar1[2] = 0;
  puVar1[3] = 0;
  puVar1[2] = *param_1;
  puVar1[3] = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  puVar1[4] = param_1[2];
  puVar1[5] = param_1[3];
  puVar1[6] = param_1[4];
  puVar1[7] = param_1[5];
  puVar1[8] = param_1[6];
  return puVar1;
}



/* FUNCTION 19930 ; VA 0x00a12710 ; FUN_00a12710 */

void __thiscall FUN_00a12710(float *param_1,float *param_2,undefined4 *param_3,float *param_4)

{
  byte *pbVar1;
  float fVar2;
  float *pfVar3;
  undefined *puVar4;
  char cVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  float fVar9;
  uint uVar10;
  float fVar11;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db0f0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  pfStack_18 = (float *)param_3;
  if (0xf < (uint)param_3[5]) {
    pfStack_18 = (float *)*param_3;
  }
  uVar7 = 0;
  uVar10 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar7 + (int)pfStack_18);
      uVar7 = uVar7 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar7 < (uint)param_3[4]);
  }
  fVar9 = param_1[3];
  uVar10 = (uint)param_1[6] & uVar10;
  fVar11 = param_1[1];
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  puVar4 = &stack0xffffffd0;
  if (fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
    fVar11 = **(float **)((int)fVar9 + 4 + uVar10 * 8);
    ExceptionList = &pvStack_10;
    while (puVar4 = puStack_14, fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
      fVar11 = *(float *)((int)fVar11 + 4);
      piVar6 = (int *)((int)fVar11 + 8);
      if (0xf < *(uint *)((int)fVar11 + 0x1c)) {
        piVar6 = (int *)*piVar6;
      }
      puVar8 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar8 = (undefined4 *)*param_3;
      }
      cVar5 = FUN_0055c360(puVar8,param_3[4],piVar6,*(undefined4 *)((int)fVar11 + 0x18));
      fVar9 = param_1[3];
      if (cVar5 != '\0') {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_00780650(param_4);
        *param_2 = fVar11;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  puStack_14 = puVar4;
  pfStack_18 = param_4;
  fVar9 = *param_4;
  if (fVar11 != fVar9) {
    *(float *)param_4[1] = fVar9;
    **(float **)((int)fVar9 + 4) = fVar11;
    **(undefined4 **)((int)fVar11 + 4) = param_4;
    fVar2 = *(float *)((int)fVar11 + 4);
    *(undefined4 *)((int)fVar11 + 4) = *(undefined4 *)((int)fVar9 + 4);
    *(float *)((int)fVar9 + 4) = param_4[1];
    param_4[1] = fVar2;
  }
  fVar9 = param_1[3];
  fVar2 = *(float *)((int)fVar9 + uVar10 * 8);
  if (fVar2 == param_1[1]) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar10 * 8) = param_4;
  }
  else if (fVar2 == fVar11) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
  }
  else {
    pfVar3 = (float *)**(undefined4 **)((int)fVar9 + 4 + uVar10 * 8);
    *(float **)((int)fVar9 + 4 + uVar10 * 8) = pfVar3;
    if (pfVar3 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar10 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar10 * 8) + 4);
    }
  }
  fVar9 = param_1[7];
  uStack_8 = 2;
  fVar11 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
           (float)((double)(int)fVar9 + (double)(&DAT_018c0d90)[-((int)fVar9 >> 0x1f)]);
  if (*param_1 <= fVar11 && fVar11 != *param_1) {
    if ((uint)fVar9 < 0x200) {
      fVar9 = (float)((int)fVar9 << 3);
    }
    else if ((uint)fVar9 < 0x1fffffff) {
      fVar9 = (float)((int)fVar9 * 2);
    }
    FUN_005cb500(fVar9);
    pfVar3 = (float *)param_1[1];
    if ((float *)*pfVar3 != pfVar3) {
      fVar9 = pfVar3[1];
      do {
        fVar11 = *(float *)param_1[1];
        FUN_00a12710(auStack_24,(int)fVar11 + 8,fVar11);
      } while (fVar11 != fVar9);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19931 ; VA 0x00a12918 ; Catch_All@00a12918 */

void Catch_All_00a12918(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 0xc,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00a134d0(unaff_EBP + 8,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19932 ; VA 0x00a12940 ; FUN_00a12940 */

void __thiscall FUN_00a12940(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  
  uVar4 = (int)param_3 - (int)param_2 >> 3;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (uVar4 != 0) {
    if (0x1fffffff < uVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar3 = FUN_00578020(uVar4);
    *param_1 = iVar3;
    param_1[1] = iVar3;
    param_1[2] = *param_1 + uVar4 * 8;
    puVar5 = (undefined4 *)*param_1;
    if (param_2 != param_3) {
      do {
        *puVar5 = 0;
        puVar5[1] = 0;
        if (param_2[1] != 0) {
          LOCK();
          piVar1 = (int *)(param_2[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar5 = *param_2;
        puVar2 = param_2 + 1;
        param_2 = param_2 + 2;
        puVar5[1] = *puVar2;
        puVar5 = puVar5 + 2;
      } while (param_2 != param_3);
    }
    FUN_005596d0(puVar5,puVar5,param_1);
    param_1[1] = (int)puVar5;
  }
  return;
}



/* FUNCTION 19933 ; VA 0x00a129e0 ; FUN_00a129e0 */

void __thiscall FUN_00a129e0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db100;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count<class_boost::promise<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19934 ; VA 0x00a12a4e ; Catch_All@00a12a4e */

void Catch_All_00a12a4e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00572e40(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19935 ; VA 0x00a12a70 ; FUN_00a12a70 */

void __thiscall FUN_00a12a70(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db110;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count<class_std::vector<class_std::shared_ptr<class_RBX::PackageLink>,class_std::allocator<class_std::shared_ptr<class_RBX::PackageLink>_>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19936 ; VA 0x00a12ade ; Catch_All@00a12ade */

void Catch_All_00a12ade(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_0088df00(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19937 ; VA 0x00a12b00 ; FUN_00a12b00 */

int __thiscall FUN_00a12b00(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db120;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PackageLinkDummy*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19938 ; VA 0x00a12bd2 ; Catch_All@00a12bd2 */

void Catch_All_00a12bd2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19939 ; VA 0x00a12bf0 ; FUN_00a12bf0 */

undefined4 * __thiscall FUN_00a12bf0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  byte *pbVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  char cVar6;
  int *piVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined4 *puVar10;
  int *piVar11;
  uint uVar12;
  int *piVar13;
  undefined4 *puStack_18;
  uint uStack_14;
  undefined4 *puStack_10;
  int *piStack_c;
  int iStack_8;
  
  puVar10 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar10 = (undefined4 *)*param_3;
  }
  uVar9 = 0;
  uVar12 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar9 + (int)puVar10);
      uVar9 = uVar9 + 1;
      uVar12 = (*pbVar1 ^ uVar12) * 0x1000193;
    } while (uVar9 < (uint)param_3[4]);
  }
  uVar12 = *(uint *)(param_1 + 0x18) & uVar12;
  piVar2 = *(int **)(param_1 + 4);
  piVar13 = *(int **)(*(int *)(param_1 + 0xc) + uVar12 * 8);
  puStack_10 = (undefined4 *)(uVar12 * 8 + 4 + *(int *)(param_1 + 0xc));
  puVar10 = param_3;
  piStack_c = piVar13;
  iStack_8 = param_1;
  while( true ) {
    puVar4 = param_3;
    piVar7 = piVar2;
    if (piStack_c != piVar2) {
      piVar7 = *(int **)*puStack_10;
    }
    piVar11 = piVar2;
    puStack_18 = puVar10;
    if (piVar13 == piVar7) goto LAB_00a12cd3;
    piVar7 = piVar13 + 2;
    if (0xf < (uint)puVar10[5]) {
      puVar10 = (undefined4 *)*puVar10;
    }
    uStack_14 = piVar13[7];
    puStack_18 = (undefined4 *)piVar13[6];
    if (0xf < uStack_14) {
      piVar7 = (int *)*piVar7;
    }
    cVar6 = FUN_0055c360(piVar7,puStack_18,puVar10,param_3[4]);
    if (cVar6 != '\0') break;
    piVar13 = (int *)*piVar13;
    puVar10 = puVar4;
  }
  piVar7 = piVar13 + 2;
  if (0xf < uStack_14) {
    piVar7 = (int *)*piVar7;
  }
  puVar10 = puVar4;
  if (0xf < (uint)puVar4[5]) {
    puVar10 = (undefined4 *)*puVar4;
  }
  cVar6 = FUN_0055c360(puVar10,puVar4[4],piVar7,puStack_18);
  puStack_18 = puVar4;
  if (cVar6 != '\0') {
    piVar11 = piVar13;
  }
LAB_00a12cd3:
  iVar5 = iStack_8;
  if (piVar11 != piVar2) {
    *param_2 = piVar11;
    *(undefined *)(param_2 + 1) = 0;
    return param_2;
  }
  iVar3 = *piVar2;
  puVar10 = *(undefined4 **)(iVar3 + 4);
  uVar8 = FUN_00a12310(iVar3,puVar10,&DAT_018bdeda,&puStack_18,(int)&param_3 + 3);
  if (*(int *)(iVar5 + 8) == 0x71c71c6) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  *(int *)(iVar5 + 8) = *(int *)(iVar5 + 8) + 1;
  *(undefined4 *)(iVar3 + 4) = uVar8;
  *puVar10 = uVar8;
  FUN_00a12710(param_2,**(int **)(iVar5 + 4) + 8,**(int **)(iVar5 + 4));
  return param_2;
}



/* FUNCTION 19940 ; VA 0x00a12d50 ; FUN_00a12d50 */

undefined FUN_00a12d50(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined4 *param_9)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined uVar7;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017db148;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uStack_40 = param_1;
  uStack_38 = param_3;
  uStack_34 = param_4;
  uStack_30 = param_5;
  uStack_2c = param_6;
  piStack_3c = param_2;
  uStack_28 = param_7;
  uStack_8 = 1;
  uStack_7 = 0;
  cVar5 = FUN_00585a40(&uStack_40);
  uVar4 = uStack_38;
  piVar1 = piStack_3c;
  uVar3 = uStack_40;
  if (cVar5 == '\0') {
    if (piStack_3c != (int *)0x0) {
      LOCK();
      piStack_3c[2] = piStack_3c[2] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_34;
    uStack_18 = uStack_30;
    uStack_1c = uStack_2c;
    uStack_20 = uStack_28;
    uStack_8 = 2;
    puVar6 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = 0;
      puVar6[1] = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        piVar1[2] = piVar1[2] + 1;
        UNLOCK();
      }
      *puVar6 = uVar3;
      puVar6[1] = piVar1;
      puVar6[3] = uStack_14;
      puVar6[4] = uStack_18;
      puVar6[5] = uStack_1c;
      puVar6[2] = uVar4;
      puVar6[6] = uStack_20;
    }
    *param_9 = puVar6;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
    uVar7 = 1;
  }
  else {
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
    uVar7 = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 19941 ; VA 0x00a12ee0 ; FUN_00a12ee0 */

void __thiscall
FUN_00a12ee0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193fb2c;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 19942 ; VA 0x00a13000 ; FUN_00a13000 */

void __thiscall
FUN_00a13000(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193fb24;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 19943 ; VA 0x00a13120 ; FUN_00a13120 */

void __thiscall
FUN_00a13120(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_c = param_6;
  uStack_10 = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_28 = param_3;
  uStack_1c = param_6;
  uStack_18 = param_7;
  uStack_2c = param_2;
  uStack_24 = param_4;
  uStack_20 = param_5;
  cVar3 = FUN_00585a40(&uStack_2c);
  if (cVar3 == '\0') {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    uStack_10 = uStack_20;
    uStack_c = uStack_1c;
    uStack_14 = uStack_18;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_2c;
    param_1[3] = piStack_28;
    param_1[5] = uStack_20;
    param_1[4] = uStack_24;
    param_1[6] = uStack_1c;
    param_1[7] = uStack_18;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193fb34;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 19944 ; VA 0x00a13270 ; FUN_00a13270 */

undefined FUN_00a13270(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      int *param_5,undefined4 param_6,undefined4 *param_7)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_8;
  
  uStack_20 = param_1;
  uStack_1c = param_2;
  uStack_18 = param_3;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_14 = param_4;
  piStack_10 = param_5;
  cVar4 = FUN_00585a40(&uStack_20);
  piVar2 = piStack_10;
  if (cVar4 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[1] = piStack_10[1] + 1;
      UNLOCK();
    }
    uStack_8 = uStack_14;
    *param_7 = uStack_20;
    param_7[1] = uStack_1c;
    param_7[2] = uStack_18;
    param_7[3] = 0;
    param_7[4] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[1] = piStack_10[1] + 1;
      UNLOCK();
    }
    param_7[3] = uStack_14;
    param_7[4] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_10[1] + -1;
      piStack_10[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_10[1] + -1;
      piStack_10[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_10[1] + -1;
      piStack_10[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar2 = param_5 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 19945 ; VA 0x00a133b0 ; FUN_00a133b0 */

void __thiscall
FUN_00a133b0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193fb08;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 19946 ; VA 0x00a134d0 ; FUN_00a134d0 */

void __thiscall FUN_00a134d0(int param_1,int *param_2,int *param_3)

{
  byte *pbVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  
  piVar5 = param_3 + 2;
  if (0xf < (uint)param_3[7]) {
    piVar5 = (int *)*piVar5;
  }
  uVar3 = 0;
  uVar6 = 0x811c9dc5;
  if (param_3[6] != 0) {
    do {
      pbVar1 = (byte *)(uVar3 + (int)piVar5);
      uVar3 = uVar3 + 1;
      uVar6 = (*pbVar1 ^ uVar6) * 0x1000193;
    } while (uVar3 < (uint)param_3[6]);
  }
  iVar2 = (*(uint *)(param_1 + 0x18) & uVar6) * 8;
  piVar5 = *(int **)(*(int *)(param_1 + 0xc) + iVar2);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if ((int *)piVar4[1] == param_3) {
    if (piVar5 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar2 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar5 == param_3) {
    *piVar4 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00780650(param_3);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 19947 ; VA 0x00a13580 ; FUN_00a13580 */

int * FUN_00a13580(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00c6de80(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 19948 ; VA 0x00a13670 ; FUN_00a13670 */

int * FUN_00a13670(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00b63e30(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 19949 ; VA 0x00a13760 ; FUN_00a13760 */

int * FUN_00a13760(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00eb3a50(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 19950 ; VA 0x00a13850 ; FUN_00a13850 */

int __fastcall FUN_00a13850(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar5 = *piVar6;
      if ((iVar5 != 0) &&
         (iVar3 = *(int *)(iVar5 + 0xc), iVar4 = FUN_00eb3a50(),
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
         (uint)*(ushort *)(iVar4 + 0x1da))) {
        return iVar5;
      }
      iVar5 = FUN_00a13850();
      if (iVar5 != 0) {
        return iVar5;
      }
    }
  }
  return 0;
}



/* FUNCTION 19951 ; VA 0x00a138c0 ; FUN_00a138c0 */

int * FUN_00a138c0(int *param_1,undefined4 *param_2,undefined4 *param_3,int param_4,
                  undefined4 param_5,uint param_6)

{
  int *piVar1;
  undefined4 uVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  undefined4 *in_stack_00000038;
  int in_stack_0000003c;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017db178;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      piVar5 = (int *)param_2[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)param_2[1];
      }
      piVar1 = (int *)*param_2;
      uVar2 = *in_stack_00000038;
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      iVar4 = (**(code **)(*piVar1 + 0x54))(&param_6,uVar2,in_stack_0000003c);
      if (iVar4 != 0) {
        if (*(int **)(param_4 + 8) == (int *)0x0) {
          *(int *)(param_4 + 4) = iVar4;
        }
        else {
          **(int **)(param_4 + 8) = iVar4;
        }
        *(int *)(param_4 + 8) = iVar4;
      }
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar4 = piVar5[2] + -1;
          piVar5[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar4 = piVar5[2] + -1;
          piVar5[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      param_2 = param_2 + 2;
      ppvVar3 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar3;
  *param_1 = param_4;
  param_1[2] = 0;
  FUN_005880d0(&param_6);
  param_1[10] = (int)in_stack_00000038;
  param_1[0xb] = in_stack_0000003c;
  uStack_8 = 3;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_6 & 0xfffffffe))(&stack0x00000020,&stack0x00000020,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19952 ; VA 0x00a13a10 ; FUN_00a13a10 */

undefined4 FUN_00a13a10(undefined4 *param_1,int param_2,undefined4 *param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  float fVar7;
  double dVar8;
  float fVar9;
  float fVar10;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar3 = *(int *)(param_2 + 0x28);
  iVar5 = FUN_0088d870();
  if (iVar3 == iVar5) {
    piVar1 = param_3 + 4;
    if (*piVar1 != 0) {
      piVar6 = *(int **)(param_2 + 4);
      if (0xf < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      piVar2 = piVar6 + 4;
      if (0xf < (uint)piVar6[5]) {
        piVar6 = (int *)*piVar6;
      }
      cVar4 = FUN_0055c360(piVar6,*piVar2,param_3,*piVar1);
      if (cVar4 == '\0') {
        return 0;
      }
    }
    if ((*(uint *)(param_2 + 0x24) >> 4 & 1) != 0) {
      (**(code **)(**(int **)(param_2 + 0x34) + 0xc))(&fStack_10,*param_1);
      dVar8 = DAT_0193fb40;
      if (param_4 == 1) {
        dVar8 = 0.0;
      }
      fVar10 = (float)dVar8;
      fVar7 = (fStack_10 + fVar10) / DAT_018f784c;
      fVar9 = DAT_018ce2f4;
      if (fVar7 < 0.0) {
        fVar9 = DAT_018f7860;
      }
      fStack_10 = (float)(int)(fVar9 + fVar7);
      fVar7 = (fStack_c + fVar10) / DAT_018f784c;
      fVar9 = DAT_018ce2f4;
      if (fVar7 < 0.0) {
        fVar9 = DAT_018f7860;
      }
      fStack_c = (float)(int)(fVar9 + fVar7);
      fVar7 = (fStack_8 + fVar10) / DAT_018f784c;
      fVar9 = DAT_018f7860;
      if (0.0 <= fVar7) {
        fVar9 = DAT_018ce2f4;
      }
      fStack_8 = (float)(int)(fVar9 + fVar7);
      (**(code **)(**(int **)(param_2 + 0x34) + 0x10))(*param_1,&fStack_10);
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 19953 ; VA 0x00a13b60 ; FUN_00a13b60 */

void FUN_00a13b60(float *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  float fVar3;
  double dVar4;
  double dVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  
  fVar8 = DAT_018f7860;
  fVar9 = DAT_018e452c;
  fVar6 = DAT_018ce2f4;
  dVar4 = DAT_0193fb40;
  if (param_2 == 1) {
    dVar4 = 0.0;
  }
  fVar10 = (float)dVar4;
  if (param_2 == 2) {
    fVar3 = (param_1[9] + fVar10) / DAT_018e452c;
    fVar7 = DAT_018ce2f4;
    if (fVar3 < 0.0) {
      fVar7 = DAT_018f7860;
    }
    param_1[9] = (float)(int)(fVar7 + fVar3);
    fVar3 = (param_1[10] + fVar10) / fVar9;
    fVar7 = fVar6;
    if (fVar3 < 0.0) {
      fVar7 = fVar8;
    }
    param_1[10] = (float)(int)(fVar7 + fVar3);
    fVar3 = (param_1[0xb] + fVar10) / fVar9;
    fVar7 = fVar6;
    if (fVar3 < 0.0) {
      fVar7 = fVar8;
    }
    param_1[0xb] = (float)(int)(fVar7 + fVar3);
  }
  else if (param_2 == 1) {
    fVar6 = param_1[10] * param_1[10] + param_1[9] * param_1[9];
    dVar4 = (double)(param_1[0xb] * param_1[0xb] + fVar6);
    FUN_017267a0();
    dVar5 = (double)param_1[9];
    if (DAT_018e452c <=
        (float)(double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & DAT_018c0da0._4_4_,
                                SUB84(dVar5,0) & (uint)DAT_018c0da0)) {
      dVar5 = (double)(param_1[10] / param_1[9]);
      FUN_01728ca0();
      fVar7 = (float)dVar5;
    }
    else {
      fVar7 = 0.0;
    }
    fVar3 = 0.0;
    if (DAT_018e452c <=
        (float)(double)CONCAT44((uint)((ulonglong)(double)param_1[0xb] >> 0x20) & DAT_018c0da0._4_4_
                                ,SUB84((double)param_1[0xb],0) & (uint)DAT_018c0da0)) {
      dVar5 = (double)fVar6;
      FUN_017267a0();
      dVar5 = (double)((float)dVar5 / param_1[0xb]);
      FUN_01728ca0();
      fVar3 = (float)dVar5;
    }
    fVar7 = fVar7 + DAT_018f8ff0;
    fVar3 = fVar3 + DAT_018f8ff0;
    dVar5 = (double)(float)dVar4 + DAT_018c0d60;
    FUN_01727bb0();
    fVar8 = DAT_018f7860;
    fVar9 = DAT_018e452c;
    fVar6 = DAT_018ce2f4;
    fVar11 = ((float)dVar4 + 0.0) / DAT_018e452c;
    fVar12 = DAT_018ce2f4;
    if (fVar11 < 0.0) {
      fVar12 = DAT_018f7860;
    }
    fVar12 = (float)(int)(fVar12 + fVar11);
    if (DAT_018e452c <= fVar12) {
      fVar11 = (fVar7 + 0.0) / (float)(DAT_0191ad98 / dVar5);
      fVar7 = DAT_018ce2f4;
      if (fVar11 < 0.0) {
        fVar7 = DAT_018f7860;
      }
      fVar7 = (float)(int)(fVar7 + fVar11);
    }
    else {
      fVar7 = 0.0;
    }
    if (DAT_018e452c <= fVar12) {
      fVar11 = (fVar3 + 0.0) / (float)(DAT_0191ad98 / dVar5);
      fVar3 = DAT_018ce2f4;
      if (fVar11 < 0.0) {
        fVar3 = DAT_018f7860;
      }
      fVar3 = (float)(int)(fVar3 + fVar11);
    }
    else {
      fVar3 = 0.0;
    }
    param_1[9] = fVar12;
    param_1[10] = fVar7;
    param_1[0xb] = fVar3;
  }
  iVar2 = 3;
  do {
    iVar1 = 3;
    do {
      fVar3 = (*param_1 + fVar10) / fVar9;
      fVar7 = fVar6;
      if (fVar3 < 0.0) {
        fVar7 = fVar8;
      }
      *param_1 = (float)(int)(fVar7 + fVar3);
      param_1 = param_1 + 1;
      iVar1 = iVar1 + -1;
    } while (iVar1 != 0);
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  return;
}



/* FUNCTION 19954 ; VA 0x00a13eb0 ; FUN_00a13eb0 */

void * __thiscall FUN_00a13eb0(int param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  void *pvVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017db1a8;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puVar6 != (undefined4 *)0x0) {
    piStack_18 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
      piStack_18 = *(int **)(param_1 + 0x30);
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar1 = (undefined4 *)puVar6[1];
    puVar6 = (undefined4 *)*puVar6;
    uStack_8 = 0;
    pvVar4 = pvStack_10;
    for (; puVar6 != puVar1; puVar6 = puVar6 + 2) {
      piVar5 = (int *)puVar6[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)puVar6[1];
      }
      uStack_8._1_3_ = (undefined3)(uStack_8 >> 8);
      uStack_8._0_1_ = 2;
      iStack_28 = FUN_0170d75d(*puVar6,0,&RBX::Instance::RTTI_Type_Descriptor,
                               &RBX::PackageLink::RTTI_Type_Descriptor,0);
      if (iStack_28 == 0) {
        iStack_28 = 0;
        piStack_1c = (int *)0x0;
      }
      else {
        piStack_1c = piVar5;
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[1] = piVar5[1] + 1;
          UNLOCK();
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      piStack_24 = piStack_1c;
      piStack_20 = piStack_1c;
      if (iStack_28 != 0) {
        iStack_14 = *param_2;
        piVar2 = *(int **)(iStack_14 + 4);
        if (*(int **)(iStack_14 + 8) == piVar2) {
          FUN_005c1970(piVar2,&iStack_28);
        }
        else {
          *piVar2 = 0;
          piVar2[1] = 0;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            piStack_1c[1] = piStack_1c[1] + 1;
            UNLOCK();
          }
          piVar2[1] = (int)piStack_1c;
          *piVar2 = iStack_28;
          *(int *)(iStack_14 + 4) = *(int *)(iStack_14 + 4) + 8;
        }
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_24[2] + -1;
          piStack_24[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = piVar5[1] + -1;
        piVar5[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar3 = piVar5[2] + -1;
          piVar5[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      pvVar4 = (void *)FUN_00a13eb0(param_2);
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar5 = piStack_18 + 1;
      iVar3 = *piVar5;
      pvVar4 = (void *)*piVar5;
      *piVar5 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piStack_18)();
        LOCK();
        piVar5 = piStack_18 + 2;
        iVar3 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pvVar4 = (void *)(**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 19955 ; VA 0x00a14060 ; FUN_00a14060 */

void * __thiscall FUN_00a14060(int param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined uVar2;
  int iVar3;
  int *piVar4;
  void *pvVar5;
  int *piVar6;
  undefined4 *puVar7;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017db1e0;
  puVar7 = *(undefined4 **)(param_1 + 0x2c);
  pvVar5 = ExceptionList;
  if (puVar7 != (undefined4 *)0x0) {
    piStack_1c = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
      piStack_1c = *(int **)(param_1 + 0x30);
      puVar7 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar1 = (undefined4 *)puVar7[1];
    puVar7 = (undefined4 *)*puVar7;
    iStack_8 = 0;
    pvVar5 = pvStack_10;
    for (; puVar7 != puVar1; puVar7 = puVar7 + 2) {
      piVar6 = (int *)puVar7[1];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = (int *)puVar7[1];
      }
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 2;
      iStack_18 = FUN_0170d75d(*puVar7,0,&RBX::Instance::RTTI_Type_Descriptor,
                               &RBX::PackageLink::RTTI_Type_Descriptor,0);
      if (iStack_18 == 0) {
        iStack_18 = 0;
        piStack_14 = (int *)0x0;
      }
      else {
        piStack_14 = piVar6;
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[1] = piVar6[1] + 1;
          UNLOCK();
        }
      }
      iStack_8._0_1_ = 3;
      uVar2 = (undefined)iStack_8;
      iStack_8._0_1_ = 3;
      iStack_30 = iStack_18;
      piStack_2c = piStack_14;
      piStack_28 = piStack_14;
      piStack_24 = piStack_14;
      piStack_20 = piStack_14;
      if ((iStack_18 != 0) &&
         ((iVar3 = FUN_00c0b480(), piVar4 = piStack_28, iVar3 == 0 ||
          (piStack_14 = piStack_20, piVar4 = piStack_24, uVar2 = (undefined)iStack_8, iVar3 == 1))))
      {
        iVar3 = *param_2;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piVar4[2] = piVar4[2] + 1;
          UNLOCK();
        }
        iStack_38 = iStack_18;
        piStack_34 = piStack_2c;
        piStack_14 = *(int **)(iVar3 + 4);
        iStack_8._0_1_ = 4;
        if (*(int **)(iVar3 + 8) == piStack_14) {
          FUN_00a124b0(piStack_14,&iStack_38);
          uVar2 = (undefined)iStack_8;
          if (piStack_34 != (int *)0x0) {
            LOCK();
            iVar3 = piStack_34[2] + -1;
            piStack_34[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piStack_34 + 4))();
              uVar2 = (undefined)iStack_8;
            }
          }
        }
        else {
          iStack_38 = 0;
          piStack_34 = (int *)0x0;
          *piStack_14 = iStack_18;
          piStack_14[1] = (int)piStack_2c;
          *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 8;
          uVar2 = (undefined)iStack_8;
        }
      }
      iStack_8._0_1_ = uVar2;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          iVar3 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_2c + 4))();
          }
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar3 = piVar6[1] + -1;
        piVar6[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar3 = piVar6[2] + -1;
          piVar6[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      pvVar5 = (void *)FUN_00a14060(param_2);
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar6 = piStack_1c + 1;
      iVar3 = *piVar6;
      pvVar5 = (void *)*piVar6;
      *piVar6 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piStack_1c)();
        LOCK();
        piVar6 = piStack_1c + 2;
        iVar3 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pvVar5 = (void *)(**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 19956 ; VA 0x00a14270 ; FUN_00a14270 */

undefined4 * __thiscall FUN_00a14270(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  return param_1;
}



/* FUNCTION 19957 ; VA 0x00a142c0 ; FUN_00a142c0 */

void __fastcall FUN_00a142c0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a14300. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 19958 ; VA 0x00a14310 ; FUN_00a14310 */

int __thiscall FUN_00a14310(int param_1,int param_2,uint param_3)

{
  undefined4 uVar1;
  bool bVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  undefined4 uVar12;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017db239;
  pvStack_10 = ExceptionList;
  piStack_1c = (int *)0x0;
  iStack_18 = param_1;
  if ((param_2 == 0) && (*(int *)(param_3 + 0xc) == 200)) {
    uStack_28 = 0;
    piStack_24 = (int *)0x0;
    iStack_8 = param_2;
    ExceptionList = &pvStack_10;
    piVar4 = (int *)FUN_014c9fa0(&uStack_38);
    if (*piVar4 == 0) {
      uStack_3c = 0xf;
      auStack_50[0] = (uint)auStack_50[0]._1_3_ << 8;
      uStack_40 = 0;
    }
    else {
      uStack_40 = 0;
      uStack_3c = 0xf;
      auStack_50[0] = (uint)auStack_50[0]._1_3_ << 8;
      FUN_005542c0(*piVar4,piVar4[1]);
    }
    iStack_8 = CONCAT31(iStack_8._1_3_,1);
    piStack_1c = (int *)0x3;
    cVar3 = FUN_0098f070(auStack_50,&uStack_28,0);
    if ((cVar3 == '\0') || (piVar4 = (int *)FUN_00580040(&param_2,&DAT_01d65d48), *piVar4 == 0)) {
      bVar2 = false;
    }
    else {
      bVar2 = true;
    }
    iStack_8._0_1_ = 0;
    iStack_8._1_3_ = 0;
    FUN_005507b0();
    if (!bVar2) {
      piVar4 = *(int **)(param_1 + 0x1c);
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
        piVar4 = *(int **)(param_1 + 0x1c);
      }
      param_2 = *(undefined4 *)(param_1 + 0x10);
      uVar1 = *(undefined4 *)(param_1 + 0x18);
      param_3 = *(undefined4 *)(param_1 + 0x14);
      piVar9 = piVar4 + 2;
      if (piVar4 != (int *)0x0) {
        LOCK();
        *piVar9 = *piVar9 + 1;
        UNLOCK();
      }
      uVar12 = 0;
      if (piVar4 != (int *)0x0) {
        LOCK();
        *piVar9 = *piVar9 + 1;
        UNLOCK();
      }
      FUN_00a133b0(uVar1,piVar4,param_2,param_3);
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar8 = piVar4[2] + -1;
        piVar4[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar4 + 4))(uVar12);
        }
        piVar9 = piVar4 + 2;
        LOCK();
        iVar8 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
      FUN_0151ded0();
      uStack_40 = 0;
      uStack_3c = 0xf;
      auStack_50[0] = auStack_50[0] & 0xffffff00;
      FUN_005542c0("Success",7);
      iStack_8 = CONCAT31(iStack_8._1_3_,5);
      FUN_0058bd10(auStack_50);
      FUN_005507b0();
      iVar8 = FUN_00550b30();
      ExceptionList = pvStack_10;
      return iVar8;
    }
    piVar4 = (int *)FUN_0091d440(&DAT_01d65d48);
    iVar8 = *piVar4;
    iVar5 = FUN_008882f0();
    if (iVar8 != iVar5) {
LAB_00a147d3:
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piStack_30 = piVar4 + 2;
    if (piVar4[1] == 0) {
      piStack_30 = (int *)0x0;
    }
    piStack_2c = (int *)piStack_30[1];
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[1] = piStack_2c[1] + 1;
      UNLOCK();
      piStack_2c = (int *)piStack_30[1];
    }
    piStack_30 = (int *)*piStack_30;
    iStack_8._0_1_ = 2;
    iVar8 = piStack_30[1] - *piStack_30 >> 0x1f;
    piStack_1c = piStack_2c;
    piStack_14 = piStack_30;
    if ((piStack_30[1] - *piStack_30) / 0xd0 + iVar8 == iVar8) {
      if (DAT_01ee6c18 != '\0') {
        FUN_01677520(DAT_01ee6c18,"deleteSymbolicLinkForPlace failed Place[%lld] Package[%lld].",
                     *(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),
                     *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14));
      }
    }
    else {
      param_3 = 0;
      param_2 = 0;
      do {
        iVar8 = *piStack_14;
        if ((uint)((piStack_14[1] - iVar8) / 0xd0) <= param_3) {
          FUN_00577c40();
          goto LAB_00a147e2;
        }
        iVar5 = *(int *)(iVar8 + param_2);
        iVar6 = FUN_008881d0();
        if (iVar5 != iVar6) goto LAB_00a147d3;
        puVar7 = (undefined4 *)(param_2 + 8 + iVar8);
        if (*(int *)(iVar8 + 4 + param_2) == 0) {
          puVar7 = (undefined4 *)0x0;
        }
        piVar4 = (int *)puVar7[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[1] = piVar4[1] + 1;
          UNLOCK();
          piVar4 = (int *)puVar7[1];
        }
        uStack_38 = *puVar7;
        iStack_8._0_1_ = 3;
        piStack_34 = piVar4;
        if (DAT_01ee6c18 != '\0') {
          piStack_20 = (int *)FUN_0091d440(&DAT_01d65d60);
          iVar8 = *piStack_20;
          iVar5 = FUN_0088cb40();
          if (iVar8 != iVar5) goto LAB_00a147d3;
          piVar9 = piStack_20 + 2;
          if (piStack_20[1] == 0) {
            piVar9 = (int *)0x0;
          }
          if (0xf < (uint)piVar9[5]) {
            piVar9 = (int *)*piVar9;
          }
          FUN_01677520(DAT_01ee6c18,
                       "deleteSymbolicLinkForPlace failed Place[%lld] Package[%lld]: %s.",
                       *(undefined4 *)(iStack_18 + 8),*(undefined4 *)(iStack_18 + 0xc),
                       *(undefined4 *)(iStack_18 + 0x10),*(undefined4 *)(iStack_18 + 0x14),piVar9);
        }
        iStack_8._0_1_ = 2;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar8 = piVar4[1] + -1;
          piVar4[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar8 = piVar4[2] + -1;
            piVar4[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        param_2 = param_2 + 0xd0;
        param_3 = param_3 + 1;
      } while (param_3 < (uint)((piStack_14[1] - *piStack_14) / 0xd0));
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_005542c0("Failure",7);
    iStack_8 = CONCAT31(iStack_8._1_3_,4);
    FUN_0058bd10(auStack_50);
    iVar8 = FUN_005507b0();
    piVar4 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar9 = piStack_1c + 1;
      iVar5 = *piVar9;
      iVar8 = *piVar9;
      *piVar9 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar9 = piVar4 + 2;
        iVar5 = *piVar9;
        iVar8 = *piVar9;
        *piVar9 = iVar5 + -1;
        UNLOCK();
        if (iVar5 + -1 == 0) {
          iVar8 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar9 = piStack_24 + 1;
      iVar5 = *piVar9;
      iVar8 = *piVar9;
      *piVar9 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar8 = (**(code **)*piStack_24)();
        LOCK();
        piVar9 = piVar4 + 2;
        iVar5 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          iVar8 = (**(code **)(*piVar4 + 4))();
          ExceptionList = pvStack_10;
          return iVar8;
        }
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if (DAT_01ee6c18 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_01677520(DAT_01ee6c18,
                   "deleteSymbolicLinkForPlace failed Place[%lld] Package[%lld]: error code %d",
                   *(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),
                   *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14),param_2);
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_005542c0("Failure",7);
    iStack_8._0_1_ = 6;
    iStack_8._1_3_ = 0;
    iVar8 = FUN_0058bd10(auStack_50);
    if (0xf < uStack_3c) {
      uVar11 = uStack_3c + 1;
      uVar10 = auStack_50[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_50[0] - 4);
        uVar11 = uStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar10) - 4) {
LAB_00a147e2:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar8 = FUN_01674ea0(uVar10,uVar11);
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 19959 ; VA 0x00a147f0 ; FUN_00a147f0 */

void __thiscall FUN_00a147f0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 uVar7;
  
  if ((param_2 == 0) && (*(int *)(param_3 + 0xc) == 200)) {
    piVar6 = (int *)param_1[1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[2] = piVar6[2] + 1;
      UNLOCK();
      piVar6 = (int *)param_1[1];
    }
    uVar3 = param_1[4];
    uVar4 = *param_1;
    uVar5 = param_1[5];
    piVar1 = piVar6 + 2;
    if (piVar6 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar7 = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00a13000(uVar4,piVar6,uVar3,uVar5);
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)(*piVar6 + 4))(uVar7);
      }
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
    FUN_0151ded0();
    if (DAT_01ee6c18 != '\0') {
      FUN_01677520(DAT_01ee6c18,
                   "postPlacePackageRelationToSymbolicLinkEndpoint Success Place[%lld] Package[%lld]: Post successfully."
                   ,param_1[2],param_1[3],param_1[4],param_1[5]);
      return;
    }
  }
  else {
    if (DAT_01d84e8e != '\0') {
      FUN_01677520(DAT_01d84e8e,
                   "postPlacePackageRelationToSymbolicLinkEndpoint Error Place[%lld] Package[%lld]: %d"
                   ,param_1[2],param_1[3],param_1[4],param_1[5],param_2);
    }
    iVar2 = param_1[6];
    if (0 < iVar2) {
      uVar3 = param_1[5];
      uVar4 = param_1[4];
      uVar5 = param_1[3];
      uVar7 = param_1[2];
      if (param_1[1] != 0) {
        LOCK();
        piVar6 = (int *)(param_1[1] + 8);
        *piVar6 = *piVar6 + 1;
        UNLOCK();
      }
      FUN_00a19900(*param_1,param_1[1],uVar7,uVar5,uVar4,uVar3,iVar2);
      return;
    }
    piVar6 = (int *)param_1[1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[2] = piVar6[2] + 1;
      UNLOCK();
      piVar6 = (int *)param_1[1];
    }
    uVar3 = param_1[5];
    uVar4 = *param_1;
    uVar5 = param_1[4];
    piVar1 = piVar6 + 2;
    if (piVar6 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar7 = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00a12ee0(uVar4,piVar6,uVar5,uVar3);
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)(*piVar6 + 4))(uVar7);
      }
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
    FUN_0151ded0();
  }
  return;
}



/* FUNCTION 19960 ; VA 0x00a149f0 ; FUN_00a149f0 */

int __thiscall FUN_00a149f0(undefined4 *param_1,uint param_2,int *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  char *pcVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  int *piVar11;
  int *piVar12;
  char *pcVar13;
  uint uVar14;
  uint uVar15;
  byte *pbVar16;
  undefined auStack_78 [16];
  undefined4 uStack_68;
  undefined4 uStack_64;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  undefined auStack_48 [8];
  int *piStack_40;
  int *piStack_3c;
  byte *pbStack_38;
  int *piStack_34;
  int iStack_30;
  int iStack_2c;
  byte *pbStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar7 = param_3;
  puStack_c = &LAB_017db2a8;
  pvStack_10 = ExceptionList;
  pbStack_28 = (byte *)0x0;
  piStack_24 = (int *)0x0;
  uStack_8 = 0;
  uStack_7 = 0;
  puStack_14 = param_1;
  if (param_2 == 0) {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_0170d75d(param_3,0,&std::exception::RTTI_Type_Descriptor,
                         &RBX::http_status_error::RTTI_Type_Descriptor);
    if (iVar4 == 0) {
      pcVar5 = (char *)(**(code **)(*piVar7 + 4))();
      uStack_68 = 0;
      uStack_64 = 0xf;
      auStack_78[0] = 0;
      pcVar13 = pcVar5;
      do {
        cVar3 = *pcVar13;
        pcVar13 = pcVar13 + 1;
      } while (cVar3 != '\0');
      FUN_005542c0(pcVar5,(int)pcVar13 - (int)(pcVar5 + 1));
      uStack_8 = 2;
      uStack_50 = 0;
      uStack_4c = 0xf;
      auStack_60[0] = auStack_60[0] & 0xffffff00;
      FUN_005542c0("Get symbolic links",0x12);
      _uStack_8 = CONCAT31(uStack_7,3);
      if (param_1[4] != 0) {
        LOCK();
        piVar7 = (int *)(param_1[4] + 4);
        *piVar7 = *piVar7 + 1;
        UNLOCK();
      }
      FUN_00a19080(auStack_60,auStack_78,param_1[3],param_1[4]);
      FUN_005507b0();
    }
    else {
      FUN_0098f070(iVar4 + 0xc,&pbStack_28,0);
      uStack_50 = 0;
      uStack_4c = 0xf;
      auStack_60[0] = auStack_60[0] & 0xffffff00;
      FUN_005542c0("Get symbolic links",0x12);
      _uStack_8 = CONCAT31(uStack_7,1);
      if (param_1[4] != 0) {
        LOCK();
        piVar7 = (int *)(param_1[4] + 4);
        *piVar7 = *piVar7 + 1;
        UNLOCK();
      }
      uVar6 = param_1[3];
      uVar1 = param_1[4];
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
      }
      FUN_00a18cc0(auStack_60,pbStack_28,piStack_24,uVar6,uVar1);
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar3 = FUN_0098f070(param_2,&pbStack_28,0);
    if (cVar3 != '\0') {
      pbVar16 = pbStack_28 + *pbStack_28 + 1;
      uVar6 = FUN_0055c740(pbVar16,&DAT_01d65d30);
      FUN_00562fc0(&param_2,uVar6,&DAT_01d65d30,
                   -(uint)(pbVar16 != (byte *)0x0) & (uint)(pbVar16 + 1));
      if (param_2 != 0) {
        piVar7 = (int *)FUN_0091d440(&DAT_01d65d30);
        iVar4 = *piVar7;
        iVar8 = FUN_008882f0();
        if (iVar4 != iVar8) {
LAB_00a150a9:
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Variant cast failed");
        }
        piStack_40 = piVar7 + 2;
        if (piVar7[1] == 0) {
          piStack_40 = (int *)0x0;
        }
        piStack_3c = (int *)piStack_40[1];
        if (piStack_3c != (int *)0x0) {
          LOCK();
          piStack_3c[1] = piStack_3c[1] + 1;
          UNLOCK();
          piStack_3c = (int *)piStack_40[1];
        }
        piStack_40 = (int *)*piStack_40;
        uStack_8 = 5;
        iVar4 = piStack_40[1] - *piStack_40 >> 0x1f;
        param_2 = 0;
        piStack_20 = piStack_40;
        piStack_18 = piStack_3c;
        if ((piStack_40[1] - *piStack_40) / 0xd0 + iVar4 != iVar4) {
          param_3 = (int *)0x0;
          do {
            piVar7 = param_3;
            iVar4 = *piStack_20;
            if ((uint)((piStack_20[1] - iVar4) / 0xd0) <= param_2) {
              FUN_00577c40();
              goto LAB_00a150b8;
            }
            iVar8 = *(int *)((int)param_3 + iVar4);
            iVar9 = FUN_008881d0();
            if (iVar8 != iVar9) goto LAB_00a150a9;
            puVar10 = (undefined4 *)(iVar4 + 8 + (int)piVar7);
            if (*(int *)((int)piVar7 + iVar4 + 4) == 0) {
              puVar10 = (undefined4 *)0x0;
            }
            piVar7 = (int *)puVar10[1];
            if (piVar7 != (int *)0x0) {
              LOCK();
              piVar7[1] = piVar7[1] + 1;
              UNLOCK();
              piVar7 = (int *)puVar10[1];
            }
            pbStack_38 = (byte *)*puVar10;
            uStack_8 = 6;
            pbVar16 = pbStack_38 + *pbStack_38 + 1;
            piStack_34 = piVar7;
            uVar6 = FUN_0055c740(pbVar16,&DAT_01d65d00);
            FUN_00562fc0(&iStack_1c,uVar6,&DAT_01d65d00,
                         -(uint)(pbVar16 != (byte *)0x0) & (uint)(pbVar16 + 1));
            param_1 = puStack_14;
            if (iStack_1c != 0) {
              piVar11 = (int *)FUN_0091d440(&DAT_01d65d00);
              iVar4 = *piVar11;
              iVar9 = FUN_0088c8c0();
              iVar8 = *piVar11;
              if (iVar4 == iVar9) {
                iVar4 = FUN_0088c8c0();
                if (iVar8 != iVar4) goto LAB_00a150a9;
                piVar12 = piVar11 + 2;
                if (piVar11[1] == 0) {
                  piVar12 = (int *)0x0;
                }
                iStack_30 = *piVar12;
                iStack_2c = iStack_30 >> 0x1f;
              }
              else {
                iVar4 = FUN_0088da50();
                if (iVar8 != iVar4) {
                  uStack_50 = 0;
                  uStack_4c = 0xf;
                  auStack_60[0] = auStack_60[0] & 0xffffff00;
                  FUN_005542c0("AssetID is not a valid number",0x1d);
                  uStack_8 = 7;
                  uStack_68 = 0;
                  uStack_64 = 0xf;
                  auStack_78[0] = 0;
                  FUN_005542c0("requestGetSymbolicLinkPage",0x1a);
                  _uStack_8 = CONCAT31(uStack_7,8);
                  FUN_00557fc0(puStack_14 + 3);
                  FUN_00a19080(auStack_78,auStack_60);
                  FUN_005507b0();
                  FUN_005507b0();
                  FUN_00550b30();
                  iVar4 = FUN_00550b30();
                  goto LAB_00a15071;
                }
                iVar4 = *piVar11;
                iVar8 = FUN_0088da50();
                if (iVar4 != iVar8) goto LAB_00a150a9;
                piVar12 = piVar11 + 2;
                if (piVar11[1] == 0) {
                  piVar12 = (int *)0x0;
                }
                iStack_30 = *piVar12;
                iStack_2c = piVar12[1];
              }
              param_1 = puStack_14;
              FUN_005e5570(auStack_48,&iStack_30,param_2);
            }
            uStack_8 = 5;
            if (piVar7 != (int *)0x0) {
              LOCK();
              iVar4 = piVar7[1] + -1;
              piVar7[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piVar7)();
                LOCK();
                iVar4 = piVar7[2] + -1;
                piVar7[2] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)(*piVar7 + 4))();
                }
              }
            }
            param_3 = param_3 + 0x34;
            param_2 = param_2 + 1;
          } while (param_2 < (uint)((piStack_20[1] - *piStack_20) / 0xd0));
        }
        pbVar16 = pbStack_28 + *pbStack_28 + 1;
        uVar6 = FUN_0055c740(pbVar16,&DAT_01d65d78);
        FUN_00562fc0(&param_2,uVar6,&DAT_01d65d78,
                     -(uint)(pbVar16 != (byte *)0x0) & (uint)(pbVar16 + 1));
        if (param_2 == 0) {
LAB_00a14f44:
          uStack_50 = 0;
          uStack_4c = 0xf;
          auStack_60[0] = auStack_60[0] & 0xffffff00;
          FUN_005542c0("Success",7);
          _uStack_8 = CONCAT31(uStack_7,10);
          iVar4 = FUN_0058bd10(auStack_60);
          if (0xf < uStack_4c) {
            uVar15 = uStack_4c + 1;
            uVar14 = auStack_60[0];
            if (0xfff < uVar15) {
              uVar14 = *(uint *)(auStack_60[0] - 4);
              uVar15 = uStack_4c + 0x24;
              if (0x1f < (auStack_60[0] - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            iVar4 = FUN_01674ea0(uVar14,uVar15);
          }
        }
        else {
          piVar7 = (int *)FUN_0091d440(&DAT_01d65d78);
          iVar4 = *piVar7;
          iVar8 = FUN_00888530();
          if (iVar4 == iVar8) goto LAB_00a14f44;
          piVar7 = (int *)FUN_0091d440(&DAT_01d65d78);
          iVar4 = *piVar7;
          iVar8 = FUN_0088cb40();
          if (iVar4 != iVar8) {
LAB_00a150b8:
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Variant cast failed");
          }
          piVar11 = piVar7 + 2;
          if (piVar7[1] == 0) {
            piVar11 = (int *)0x0;
          }
          FUN_0054ef60(piVar11);
          uVar6 = param_1[2];
          uVar1 = *param_1;
          uVar2 = param_1[1];
          _uStack_8 = CONCAT31(uStack_7,9);
          if (param_1[4] != 0) {
            LOCK();
            piVar7 = (int *)(param_1[4] + 4);
            *piVar7 = *piVar7 + 1;
            UNLOCK();
          }
          FUN_00a196b0(uVar1,uVar2,auStack_78,uVar6,param_1[3],param_1[4]);
          iVar4 = FUN_005507b0();
        }
        piVar7 = piStack_18;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          piVar11 = piStack_18 + 1;
          iVar8 = *piVar11;
          iVar4 = *piVar11;
          *piVar11 = iVar8 + -1;
          UNLOCK();
          if (iVar8 + -1 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar11 = piVar7 + 2;
            iVar8 = *piVar11;
            iVar4 = *piVar11;
            *piVar11 = iVar8 + -1;
            UNLOCK();
            if (iVar8 + -1 == 0) {
              iVar4 = (**(code **)(*piVar7 + 4))();
            }
          }
        }
        goto LAB_00a15071;
      }
    }
    uStack_68 = 0;
    uStack_64 = 0xf;
    auStack_78[0] = 0;
    FUN_005542c0("Get symbolic links",0x12);
    _uStack_8 = CONCAT31(uStack_7,4);
    if (param_1[4] != 0) {
      LOCK();
      piVar7 = (int *)(param_1[4] + 4);
      *piVar7 = *piVar7 + 1;
      UNLOCK();
    }
    uVar6 = param_1[3];
    uVar1 = param_1[4];
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    FUN_00a18cc0(auStack_78,pbStack_28,piStack_24,uVar6,uVar1);
  }
  iVar4 = FUN_005507b0();
LAB_00a15071:
  piVar7 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar11 = piStack_24 + 1;
    iVar8 = *piVar11;
    iVar4 = *piVar11;
    *piVar11 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      iVar4 = (**(code **)*piStack_24)();
      LOCK();
      piVar11 = piVar7 + 2;
      iVar8 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        iVar4 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 19961 ; VA 0x00a150d0 ; FUN_00a150d0 */

int __thiscall FUN_00a150d0(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x68);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x54);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0xf;
  *(undefined *)(param_1 + 0x54) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  return param_1;
}



/* FUNCTION 19962 ; VA 0x00a15140 ; FUN_00a15140 */

void __fastcall FUN_00a15140(int param_1)

{
  FUN_00a125a0(param_1 + 8);
  return;
}



/* FUNCTION 19963 ; VA 0x00a15150 ; FUN_00a15150 */

void FUN_00a15150(undefined4 *param_1)

{
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_6193d039af4e004a0f7bcde761844bfa>,bool,class_std::shared_ptr<class_RBX::Instance>_>
             ::vftable;
  return;
}



/* FUNCTION 19964 ; VA 0x00a15160 ; FUN_00a15160 */

void __fastcall FUN_00a15160(int param_1)

{
  FUN_00a12640(param_1 + 8);
  return;
}



/* FUNCTION 19965 ; VA 0x00a15170 ; FUN_00a15170 */

void __thiscall FUN_00a15170(int param_1,char param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x28);
  }
  return;
}



/* FUNCTION 19966 ; VA 0x00a151d0 ; FUN_00a151d0 */

void __thiscall FUN_00a151d0(int param_1,char param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x28);
  }
  return;
}



/* FUNCTION 19967 ; VA 0x00a15210 ; FUN_00a15210 */

void __fastcall FUN_00a15210(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_0056cc10();
    FUN_01674ea0(iVar1,0xc);
  }
  return;
}



/* FUNCTION 19968 ; VA 0x00a15230 ; FUN_00a15230 */

void __fastcall FUN_00a15230(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_0088df00(1);
  }
  return;
}



/* FUNCTION 19969 ; VA 0x00a15240 ; FUN_00a15240 */

void FUN_00a15240(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a14310(*param_1,param_2);
  return;
}



/* FUNCTION 19970 ; VA 0x00a15260 ; FUN_00a15260 */

void __thiscall FUN_00a15260(int param_1,undefined4 param_2)

{
  FUN_00a12360(param_1 + 4,param_2);
  return;
}



/* FUNCTION 19971 ; VA 0x00a15280 ; FUN_00a15280 */

void FUN_00a15280(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a147f0(*param_1,param_2);
  return;
}



/* FUNCTION 19972 ; VA 0x00a152a0 ; FUN_00a152a0 */

void __fastcall FUN_00a152a0(int param_1)

{
  FUN_00a12190(param_1 + 8);
  return;
}



/* FUNCTION 19973 ; VA 0x00a152c0 ; FUN_00a152c0 */

undefined4 * __thiscall FUN_00a152c0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_cdeecfec3d3fad15adf9c8fa882ebced>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  param_2[5] = *(undefined4 *)(param_1 + 0x14);
  param_2[6] = *(undefined4 *)(param_1 + 0x18);
  param_2[7] = *(undefined4 *)(param_1 + 0x1c);
  param_2[8] = *(undefined4 *)(param_1 + 0x20);
  return param_2;
}



/* FUNCTION 19974 ; VA 0x00a15320 ; FUN_00a15320 */

TypeDescriptor * FUN_00a15320(void)

{
  return &<lambda_480cffa5aabb0a0171f595491510fd61>::RTTI_Type_Descriptor;
}



/* FUNCTION 19975 ; VA 0x00a15330 ; FUN_00a15330 */

TypeDescriptor * FUN_00a15330(void)

{
  return &<lambda_6193d039af4e004a0f7bcde761844bfa>::RTTI_Type_Descriptor;
}



/* FUNCTION 19976 ; VA 0x00a15340 ; FUN_00a15340 */

TypeDescriptor * FUN_00a15340(void)

{
  return &<lambda_cdeecfec3d3fad15adf9c8fa882ebced>::RTTI_Type_Descriptor;
}



/* FUNCTION 19977 ; VA 0x00a15350 ; FUN_00a15350 */

void __fastcall FUN_00a15350(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  
  piVar1 = (int *)*param_1;
  piVar6 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar6 != (int *)*param_1) {
    do {
      uVar2 = piVar6[7];
      piVar1 = (int *)*piVar6;
      if (0xf < uVar2) {
        iVar3 = piVar6[2];
        uVar5 = uVar2 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      piVar6[6] = 0;
      piVar6[7] = 0xf;
      *(undefined *)(piVar6 + 2) = 0;
      FUN_01674ea0(piVar6,0x24);
      piVar6 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 19978 ; VA 0x00a153d0 ; FUN_00a153d0 */

int * FUN_00a153d0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  int *piVar6;
  undefined4 ***apppuStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db2d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x40))(&piStack_24);
  uStack_8._0_1_ = 1;
  if (piStack_24 != (int *)0x0) {
    piVar6 = (int *)*piStack_24;
    piStack_24 = (int *)piStack_24[1];
    piStack_18 = piStack_24;
    if (piVar6 != piStack_24) {
      do {
        uStack_2c = 0;
        uStack_28 = 0xf;
        apppuStack_3c[0] = (undefined4 ***)((uint)apppuStack_3c[0] & 0xffffff00);
        FUN_005542c0("PackageLink",0xb);
        ppppuVar4 = apppuStack_3c;
        if (0xf < uStack_28) {
          ppppuVar4 = (undefined4 ****)apppuStack_3c[0];
        }
        uStack_8._0_1_ = 2;
        cStack_11 = FUN_008931b0(ppppuVar4);
        uStack_8._0_1_ = 1;
        if (0xf < uStack_28) {
          uVar5 = uStack_28 + 1;
          ppppuVar4 = (undefined4 ****)apppuStack_3c[0];
          if (0xfff < uVar5) {
            ppppuVar4 = (undefined4 ****)apppuStack_3c[0][-1];
            uVar5 = uStack_28 + 0x24;
            if (0x1f < (uint)((int)apppuStack_3c[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppuVar4,uVar5);
        }
        if (cStack_11 != '\0') {
          piVar1 = *(int **)(param_3 + 4);
          if (*(int **)(param_3 + 8) == piVar1) {
            piStack_24 = (int *)FUN_005c1970(piVar1,piVar6);
          }
          else {
            *piVar1 = 0;
            piVar1[1] = 0;
            if (piVar6[1] != 0) {
              LOCK();
              piVar2 = (int *)(piVar6[1] + 4);
              *piVar2 = *piVar2 + 1;
              UNLOCK();
            }
            *piVar1 = *piVar6;
            piStack_24 = (int *)piVar6[1];
            piVar1[1] = (int)piStack_24;
            *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 8;
          }
          if (piStack_20 != (int *)0x0) {
            LOCK();
            piVar6 = piStack_20 + 1;
            iVar3 = *piVar6;
            piStack_24 = (int *)*piVar6;
            *piVar6 = iVar3 + -1;
            UNLOCK();
            if (iVar3 + -1 == 0) {
              (**(code **)*piStack_20)();
              LOCK();
              piVar6 = piStack_20 + 2;
              iVar3 = *piVar6;
              piStack_24 = (int *)*piVar6;
              *piVar6 = iVar3 + -1;
              UNLOCK();
              if (iVar3 + -1 == 0) {
                piStack_24 = (int *)(**(code **)(*piStack_20 + 4))();
              }
            }
          }
          goto LAB_00a1550f;
        }
        if (piVar6[1] != 0) {
          LOCK();
          piVar1 = (int *)(piVar6[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        piStack_24 = (int *)FUN_00a153d0(*piVar6,piVar6[1],param_3);
        piVar6 = piVar6 + 2;
      } while (piVar6 != piStack_18);
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar6 = piStack_20 + 1;
    iVar3 = *piVar6;
    piStack_24 = (int *)*piVar6;
    *piVar6 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar6 = piStack_20 + 2;
      iVar3 = *piVar6;
      piStack_24 = (int *)*piVar6;
      *piVar6 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piStack_24 = (int *)(**(code **)(*piStack_20 + 4))();
      }
    }
  }
LAB_00a1550f:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar6 = param_2 + 1;
    iVar3 = *piVar6;
    piStack_24 = (int *)*piVar6;
    *piVar6 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piStack_24 = (int *)(**(code **)*param_2)();
      LOCK();
      piVar6 = param_2 + 2;
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_24 = (int *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_24;
}



/* FUNCTION 19979 ; VA 0x00a155c0 ; FUN_00a155c0 */

undefined4 FUN_00a155c0(int param_1,int *param_2,char param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  bool bVar6;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db2f8;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    return 0;
  }
  iVar5 = *param_2;
  iStack_14 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iVar5 != iStack_14) {
    do {
      FUN_00587490(&iStack_1c);
      uStack_8 = 0;
      if ((iStack_1c == 0) || (iVar4 = FUN_00c0b480(), iVar4 == -1)) {
        piVar2 = piStack_18;
        uStack_8 = 0xffffffff;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_18[1] + -1;
          piStack_18[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar4 = *piVar1 + -1;
            *piVar1 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
      }
      else {
        cVar3 = FUN_00983210(param_1);
        if ((param_3 == '\0') && (cVar3 != '\0')) {
          bVar6 = iVar4 == 1;
        }
        else {
          iVar4 = FUN_00a2e100(&iStack_1c);
          bVar6 = iVar4 != 3;
        }
        piVar2 = piStack_18;
        uStack_8 = 0xffffffff;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_18[1] + -1;
          piStack_18[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar4 = *piVar1 + -1;
            *piVar1 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        if (bVar6) {
          ExceptionList = pvStack_10;
          return 1;
        }
      }
      iVar5 = iVar5 + 8;
    } while (iVar5 != iStack_14);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 19980 ; VA 0x00a15700 ; FUN_00a15700 */

undefined8 FUN_00a15700(void)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined8 uVar3;
  undefined4 ***apppuStack_1c [4];
  int iStack_c;
  uint uStack_8;
  
  FUN_009cc5b0(apppuStack_1c);
  if (iStack_c != 0) {
    ppppuVar1 = apppuStack_1c;
    if (0xf < uStack_8) {
      ppppuVar1 = (undefined4 ****)apppuStack_1c[0];
    }
    uVar3 = FUN_0171d7b1(ppppuVar1,0,10);
    if (0xf < uStack_8) {
      uVar2 = uStack_8 + 1;
      ppppuVar1 = (undefined4 ****)apppuStack_1c[0];
      if (0xfff < uVar2) {
        ppppuVar1 = (undefined4 ****)apppuStack_1c[0][-1];
        uVar2 = uStack_8 + 0x24;
        if (0x1f < (uint)((int)apppuStack_1c[0] + (-4 - (int)ppppuVar1))) goto LAB_00a157aa;
      }
      FUN_01674ea0(ppppuVar1,uVar2);
    }
    return uVar3;
  }
  if (0xf < uStack_8) {
    uVar2 = uStack_8 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_1c[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_1c[0][-1];
      uVar2 = uStack_8 + 0x24;
      if (0x1f < (uint)((int)apppuStack_1c[0] + (-4 - (int)ppppuVar1))) {
LAB_00a157aa:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  return 0;
}



/* FUNCTION 19981 ; VA 0x00a157b0 ; FUN_00a157b0 */

int FUN_00a157b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5,int *param_6)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 ****ppppuVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uVar10;
  int aiStack_90 [9];
  int *piStack_6c;
  undefined4 ***apppuStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db366;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = (int *)FUN_01674e20(0xc);
  if (piStack_14 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    *piStack_14 = 0;
    piStack_14[1] = 0;
    *(undefined *)(piStack_14 + 2) = 0;
    piVar4 = piStack_14;
  }
  uStack_20 = 0;
  piStack_1c = (int *)0x0;
  FUN_00a129e0(piVar4,param_2);
  uStack_8._0_1_ = 1;
  uVar5 = FUN_00581b50(auStack_18);
  uStack_8._0_1_ = 2;
  FUN_005687b0(uVar5);
  piVar4 = piStack_14;
  uStack_8._0_1_ = 5;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_14[1] + -1;
    piStack_14[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar9 = *piVar1 + -1;
      *piVar1 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar4 + 8))();
      }
    }
  }
  uStack_8._0_1_ = 4;
  FUN_00fb9250(apppuStack_68,param_1,param_2,param_3,param_4);
  uStack_8._0_1_ = 6;
  FUN_014c9d60(auStack_28,0);
  uStack_8._0_1_ = 7;
  ppppuVar6 = apppuStack_68;
  if (0xf < uStack_54) {
    ppppuVar6 = (undefined4 ****)apppuStack_68[0];
  }
  FUN_014cbbc0(ppppuVar6,uStack_58);
  FUN_014cba30();
  puVar7 = &DAT_01d79fc8;
  if (0xf < DAT_01d79fdc) {
    puVar7 = DAT_01d79fc8;
  }
  puVar8 = &DAT_01d79d70;
  if (0xf < DAT_01d79d84) {
    puVar8 = DAT_01d79d70;
  }
  FUN_014cb8a0(puVar8,DAT_01d79d80,puVar7,DAT_01d79fd8);
  piVar4 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  uStack_50 = uStack_20;
  uStack_48 = param_1;
  uStack_44 = param_2;
  uStack_40 = param_3;
  piStack_4c = piStack_1c;
  uStack_3c = param_4;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  uStack_38 = param_5;
  piStack_34 = param_6;
  piStack_6c = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  piStack_6c = (int *)FUN_00a12620(&uStack_50);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_34[2] + -1;
    piStack_34[2] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)(*piStack_34 + 4))();
    }
  }
  piVar1 = piStack_4c;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar9 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_4c)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar9 = *piVar2 + -1;
      *piVar2 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 10;
  FUN_014cb530(aiStack_90);
  uStack_8._0_1_ = 7;
  if (piStack_6c != (int *)0x0) {
    (**(code **)(*piStack_6c + 0x10))
              (CONCAT31((int3)((uint)aiStack_90 >> 8),piStack_6c != aiStack_90));
  }
  if (piStack_30 != (int *)0x0) {
    iVar9 = (**(code **)(*piStack_30 + 0x14))();
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_24 + 1;
      iVar3 = *piVar1;
      iVar9 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piStack_24 + 2;
        iVar3 = *piVar1;
        iVar9 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar9 = (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 4;
    if (0xf < uStack_54) {
      uVar10 = uStack_54 + 1;
      ppppuVar6 = (undefined4 ****)apppuStack_68[0];
      if (0xfff < uVar10) {
        ppppuVar6 = (undefined4 ****)apppuStack_68[0][-1];
        uVar10 = uStack_54 + 0x24;
        if (0x1f < (uint)((int)apppuStack_68[0] + (-4 - (int)ppppuVar6))) goto LAB_00a15ad5;
      }
      iVar9 = FUN_01674ea0(ppppuVar6,uVar10);
    }
    uStack_58 = 0;
    uStack_54 = 0xf;
    apppuStack_68[0] = (undefined4 ***)((uint)apppuStack_68[0] & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_2c + 1;
      iVar3 = *piVar1;
      iVar9 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)(*piStack_2c + 4))();
        LOCK();
        piVar1 = piStack_2c + 2;
        iVar3 = *piVar1;
        iVar9 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar9 = (**(code **)(*piStack_2c + 8))();
        }
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 1;
      iVar3 = *piVar1;
      iVar9 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1;
        iVar9 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar9 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (param_6 != (int *)0x0) {
      LOCK();
      piVar4 = param_6 + 2;
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar9 = (**(code **)(*param_6 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return iVar9;
  }
  uVar5 = FUN_0056acb0();
  uStack_8._0_1_ = 0xb;
  FUN_00564940(uVar5);
LAB_00a15ad5:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 19982 ; VA 0x00a15ae0 ; FUN_00a15ae0 */

int * __thiscall FUN_00a15ae0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  iVar3 = FUN_005e9db0(param_3);
  iVar1 = *(int *)(param_1 + 0xc);
  puVar2 = *(undefined4 **)(param_1 + 4);
  iVar3 = iVar3 * 8;
  puVar4 = *(undefined4 **)(iVar1 + iVar3);
  puVar5 = puVar4;
  while( true ) {
    puVar6 = puVar2;
    if (puVar5 != puVar2) {
      puVar6 = (undefined4 *)**(undefined4 **)(iVar1 + 4 + iVar3);
    }
    if (puVar4 == puVar6) break;
    if ((puVar4[2] == *param_3) && (puVar4[3] == param_3[1])) {
      *param_2 = (int)puVar4;
      return param_2;
    }
    puVar4 = (undefined4 *)*puVar4;
    puVar5 = *(undefined4 **)(iVar1 + iVar3);
  }
  *param_2 = (int)puVar2;
  return param_2;
}



/* FUNCTION 19983 ; VA 0x00a15b50 ; FUN_00a15b50 */

undefined4 __thiscall FUN_00a15b50(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  int *piVar5;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8348;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(param_1 + 0x2c);
  if (piVar2 != (int *)0x0) {
    piVar5 = (int *)*piVar2;
    piStack_14 = (int *)piVar2[1];
    ExceptionList = &pvStack_10;
    if (piVar5 != piStack_14) {
      do {
        piStack_18 = (int *)piVar5[1];
        if (piStack_18 != (int *)0x0) {
          LOCK();
          piStack_18[1] = piStack_18[1] + 1;
          UNLOCK();
          piStack_18 = (int *)piVar5[1];
        }
        iStack_1c = *piVar5;
        uStack_8 = 0;
        if (*(int **)(param_2 + 0x24) == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_016ddc9c();
        }
        cVar4 = (**(code **)(**(int **)(param_2 + 0x24) + 8))(&iStack_1c);
        piVar2 = piStack_18;
        uStack_8 = 0xffffffff;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_18[1] + -1;
          piStack_18[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar3 = *piVar1 + -1;
            *piVar1 = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        if ((cVar4 != '\0') || (cVar4 = FUN_00a15b50(param_2), cVar4 != '\0')) {
          ExceptionList = pvStack_10;
          return 1;
        }
        piVar5 = piVar5 + 2;
      } while (piVar5 != piStack_14);
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 19984 ; VA 0x00a15c60 ; FUN_00a15c60 */

undefined4 * FUN_00a15c60(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db391;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0xc);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[2] = 0;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a12a70(puVar4,param_1);
  piStack_18 = (int *)param_1[1];
  uStack_14 = 1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
    piStack_18 = (int *)param_1[1];
  }
  uStack_1c = *param_1;
  uStack_8 = 1;
  FUN_00a13eb0(&uStack_1c);
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19985 ; VA 0x00a15d60 ; FUN_00a15d60 */

undefined4 FUN_00a15d60(undefined4 param_1,undefined4 param_2,byte param_3)

{
  undefined auStack_bc [160];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db3b3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00565940(0x22,1);
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 1;
  FUN_005c1970(0,param_2);
  FUN_00a24a80(auStack_bc,&uStack_1c,(param_3 ^ 1) * 2,0);
  FUN_0058c420(param_1);
  FUN_00577ac0();
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19986 ; VA 0x00a15e10 ; thunk_FUN_00eb3b50 */

void thunk_FUN_00eb3b50(void)

{
  int iVar1;
  
  if (DAT_01f25aac == 0) {
    iVar1 = FUN_00eb3a50();
    DAT_01f25aac = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19987 ; VA 0x00a15e20 ; FUN_00a15e20 */

undefined4 FUN_00a15e20(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_00d173f0(param_2);
  if (cVar1 == '\0') {
    FUN_00d169c0(param_1);
    return param_1;
  }
  FUN_0054ef60(param_2);
  return param_1;
}



/* FUNCTION 19988 ; VA 0x00a15e60 ; FUN_00a15e60 */

undefined4 * FUN_00a15e60(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db3c8;
  pvStack_10 = ExceptionList;
  if (param_2 == (undefined4 *)0x0) {
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    return param_1;
  }
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  param_2 = &uStack_1c;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a14060(&param_2);
  uVar1 = uStack_1c;
  uStack_1c = 0;
  param_1[1] = uStack_18;
  param_1[2] = uStack_14;
  *param_1 = uVar1;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_005e6280();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19989 ; VA 0x00a15f10 ; FUN_00a15f10 */

undefined4 FUN_00a15f10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int *piVar4;
  undefined uVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db421;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = (undefined4 *)FUN_01674e20(0xc);
  if (puStack_18 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    *puStack_18 = 0;
    puStack_18[1] = 0;
    *(undefined *)(puStack_18 + 2) = 0;
    puVar6 = puStack_18;
  }
  uStack_20 = 0;
  piStack_1c = (int *)0x0;
  FUN_00a129e0(puVar6,puStack_18);
  uStack_8 = 1;
  uVar7 = FUN_00581b50(auStack_30);
  uStack_8._0_1_ = 2;
  FUN_005687b0(uVar7);
  uStack_8._0_1_ = 5;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_2c + 4))();
      LOCK();
      iVar3 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_2c + 8))();
      }
    }
  }
  uStack_8._0_1_ = 4;
  FUN_005e5ff0();
  uStack_14 = 1;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  piVar4 = piStack_1c;
  uStack_8._0_1_ = 6;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  FUN_00a196b0(param_2,param_3,auStack_48,param_1,uStack_20,piStack_1c);
  uStack_8._0_1_ = 4;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_34) {
    uVar9 = uStack_34 + 1;
    uVar8 = auStack_48[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_48[0] - 4);
      uVar9 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  if (piStack_28 != (int *)0x0) {
    (**(code **)(*piStack_28 + 0x14))();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_24 + 4))();
        LOCK();
        iVar3 = piStack_24[2] + -1;
        piStack_24[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_24 + 8))();
        }
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[1] + -1;
      piVar4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar7 = FUN_0056acb0();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_00564940(uVar7);
  pcVar2 = (code *)swi(3);
  uVar7 = (*pcVar2)();
  return uVar7;
}



/* FUNCTION 19990 ; VA 0x00a16100 ; FUN_00a16100 */

undefined4 FUN_00a16100(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db44b;
  pvStack_10 = ExceptionList;
  iStack_14 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iStack_14 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iStack_14 + 4) = *(int *)(iStack_14 + 4) + 1;
    UNLOCK();
    iStack_14 = param_2[1];
  }
  uStack_18 = *param_2;
  uStack_8 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  FUN_00a12940(&uStack_18,&pvStack_10,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_016f32d1(&uStack_18,8,1,FUN_00550b30);
  FUN_00a16470(param_1,&uStack_24);
  FUN_00577ac0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19991 ; VA 0x00a161b0 ; FUN_00a161b0 */

undefined FUN_00a161b0(int param_1)

{
  undefined uVar1;
  undefined **appuStack_38 [9];
  undefined ***pppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db468;
  pvStack_10 = ExceptionList;
  if ((DAT_01d65ce8 != '\0') && (param_1 == 0)) {
    return 0;
  }
  pppuStack_14 = appuStack_38;
  appuStack_38[0] =
       std::
       _Func_impl_no_alloc<class_<lambda_6193d039af4e004a0f7bcde761844bfa>,bool,class_std::shared_ptr<class_RBX::Instance>_>
       ::vftable;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a15b50(pppuStack_14);
  if (pppuStack_14 != (undefined ***)0x0) {
    (*(code *)(*pppuStack_14)[4])(pppuStack_14 != appuStack_38);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19992 ; VA 0x00a16240 ; FUN_00a16240 */

bool FUN_00a16240(int param_1)

{
  int iVar1;
  
  if ((DAT_01d65ce8 != '\0') && (param_1 == 0)) {
    return false;
  }
  iVar1 = FUN_00a13850();
  return iVar1 != 0;
}



/* FUNCTION 19993 ; VA 0x00a16270 ; FUN_00a16270 */

undefined8 FUN_00a16270(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined8 uVar7;
  undefined auStack_11c [160];
  undefined auStack_7c [52];
  undefined4 ***apppuStack_48 [4];
  int iStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db4a3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089d950(&iStack_1c,3);
  uStack_8 = 0;
  if (iStack_1c == 0) {
    uStack_24 = 0;
    iStack_20 = 0;
    uStack_14 = 0;
    uVar5 = uStack_24;
  }
  else {
    auStack_7c[0] = 0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    FUN_00a18330(&iStack_1c);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    FUN_00a17010(iStack_1c,piStack_18,1,auStack_7c,param_2);
    uStack_8._0_1_ = 0;
    FUN_00565940(0x22,1);
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_005c1970(0,&iStack_1c);
    FUN_00a24a80(auStack_11c,&uStack_30,0,0);
    FUN_0058c420(apppuStack_48);
    ppppuVar3 = apppuStack_48;
    if (0xf < uStack_34) {
      ppppuVar3 = (undefined4 ****)apppuStack_48[0];
    }
    iVar6 = 0;
    uStack_14 = 0xcbf29ce4;
    uVar7 = 0xcbf29ce484222325;
    iStack_20 = (iStack_38 + (int)ppppuVar3) - (int)ppppuVar3;
    if ((undefined4 ****)(iStack_38 + (int)ppppuVar3) < ppppuVar3) {
      iStack_20 = 0;
    }
    uVar2 = 0xcbf29ce484222325;
    if (iStack_20 != 0) {
      do {
        uVar7 = FUN_016f39b0((int)*(char *)(iVar6 + (int)ppppuVar3) ^ (uint)uVar7,
                             (int)*(char *)(iVar6 + (int)ppppuVar3) >> 0x1f ^
                             (uint)((ulonglong)uVar7 >> 0x20),0x1b3,0x100);
        iVar6 = iVar6 + 1;
        uVar2 = uVar7;
      } while (iVar6 != iStack_20);
    }
    uStack_14 = (undefined4)((ulonglong)uVar2 >> 0x20);
    if (0xf < uStack_34) {
      uVar4 = uStack_34 + 1;
      ppppuVar3 = (undefined4 ****)apppuStack_48[0];
      if (0xfff < uVar4) {
        ppppuVar3 = (undefined4 ****)((undefined4 ****)apppuStack_48[0])[-1];
        uVar4 = uStack_34 + 0x24;
        if (0x1f < (uint)((int)apppuStack_48[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar3,uVar4);
    }
    FUN_00577ac0();
    FUN_005705c0();
    uVar5 = (int)uVar2;
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_18[1] + -1;
    piStack_18[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return CONCAT44(uStack_14,uVar5);
}



/* FUNCTION 19994 ; VA 0x00a16470 ; FUN_00a16470 */

/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_00a16470(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 *puVar5;
  char cVar6;
  undefined **ppuVar7;
  undefined **ppuVar8;
  undefined4 auStack_16c [2];
  uint uStack_164;
  undefined4 *puStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined8 uStack_14c;
  undefined ***pppuStack_144;
  undefined ***pppuStack_140;
  undefined auStack_134 [8];
  uint uStack_12c;
  undefined auStack_124 [28];
  int iStack_108;
  undefined **appuStack_104 [15];
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_b8;
  undefined **appuStack_b4 [18];
  undefined **ppuStack_6c;
  uint uStack_64;
  undefined4 *puStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined auStack_44 [4];
  undefined *puStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined *puStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db502;
  pvStack_10 = ExceptionList;
  pppuStack_140 = (undefined ***)&uStack_14;
  uStack_28 = 0;
  pppuStack_144 = (undefined ***)&boost::lock_error::vftable_meta_ptr;
  auStack_44[0] = 0;
  uStack_14 = 0xb;
  uStack_14c = 0x18be10000a164b5;
  ExceptionList = &pvStack_10;
  ppuVar7 = (undefined **)FUN_00563d40();
  ppuVar8 = ppuVar7 + -1;
  if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar8 = ppuVar7;
  }
  puStack_40 = *ppuVar8;
  uStack_3c = 0;
  uStack_38 = 0x3f800000;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_8 = 0;
  pppuStack_140 = (undefined ***)0xa164f0;
  pppuStack_144 = (undefined ***)FUN_00f27310();
  pppuStack_140 = (undefined ***)param_1;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_14c = CONCAT44(0xa1650a,(undefined4)uStack_14c);
  FUN_00882290();
  puVar5 = param_2;
  pppuStack_140 = (undefined ***)&param_2;
  uStack_20 = 1;
  pppuStack_144 = (undefined ***)0xa16520;
  cVar6 = FUN_00585a40();
  uVar3 = uStack_1c;
  if (cVar6 == '\0') {
    puStack_5c = param_2;
    uStack_64 = 0x193faf1;
  }
  else {
    uStack_64 = 0;
  }
  uStack_24 = *puVar5;
  puStack_2c = (undefined *)auStack_16c;
  uStack_14 = puVar5[1];
  uStack_8._0_1_ = 2;
  auStack_16c[0] = uStack_1c;
  uStack_164 = 0;
  puVar5 = auStack_16c;
  if (uStack_64 != 0) {
    uStack_164 = uStack_64;
    if ((uStack_64 & 1) == 0) {
      (**(code **)(uStack_64 & 0xfffffffe))(&puStack_5c,&puStack_15c,0);
      puVar5 = (undefined4 *)puStack_2c;
    }
    else {
      puStack_15c = puStack_5c;
      uStack_158 = uStack_58;
      uStack_154 = uStack_54;
      uStack_150 = uStack_50;
      uStack_14c = uStack_4c;
      puVar5 = auStack_16c;
    }
  }
  puStack_2c = (undefined *)puVar5;
  pppuStack_144 = (undefined ***)&uStack_20;
  pppuStack_140 = (undefined ***)auStack_44;
  FUN_00a138c0(auStack_134,uStack_24,uStack_14);
  uStack_8._0_1_ = 3;
  if (((uStack_12c != 0) && ((uStack_12c & 1) == 0)) &&
     (*(code **)(uStack_12c & 0xfffffffe) != (code *)0x0)) {
    pppuStack_144 = (undefined ***)auStack_124;
    pppuStack_140 = (undefined ***)0x2;
    uStack_14c = CONCAT44(pppuStack_144,0xa165e4);
    (**(code **)(uStack_12c & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  if (((uStack_64 != 0) && ((uStack_64 & 1) == 0)) &&
     (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
    pppuStack_144 = (undefined ***)&puStack_5c;
    pppuStack_140 = (undefined ***)0x2;
    uStack_14c = CONCAT44(pppuStack_144,0xa16608);
    (**(code **)(uStack_64 & 0xfffffffe))();
  }
  appuStack_104[0] = &PTR_018be314;
  pppuStack_140 = (undefined ***)0x0;
  pppuStack_144 = appuStack_104 + 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uStack_28 = 2;
  appuStack_b4[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_b8 = 0x48;
  uStack_14c = CONCAT44(0xa16648,(undefined4)uStack_14c);
  FUN_00554f20();
  uStack_8 = 7;
  *(undefined ***)(appuStack_104[0][1] + (int)appuStack_104) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_108 + (int)appuStack_104[0][1]) = appuStack_104[0][1] + -0x50;
  pppuStack_140 = (undefined ***)0xa16681;
  FUN_0054ee60();
  appuStack_104[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_c8 = 0;
  uStack_c4 = 4;
  pppuStack_140 = appuStack_104;
  uStack_8._0_1_ = 8;
  pppuStack_144 = (undefined ***)0xa166b2;
  FUN_00882920();
  ppuStack_6c = TextXmlWriter::vftable;
  pppuStack_140 = (undefined ***)auStack_44;
  uStack_8._0_1_ = 9;
  pppuStack_144 = (undefined ***)uVar3;
  uStack_14c = CONCAT44(0xa166ca,(undefined4)uStack_14c);
  FUN_00885590();
  uStack_8._0_1_ = 8;
  pppuStack_140 = (undefined ***)0xa166d6;
  FUN_0090eec0();
  pppuStack_140 = (undefined ***)0xa166e1;
  FUN_00581480();
  pppuStack_140 = (undefined ***)param_1;
  pppuStack_144 = (undefined ***)0xa166ef;
  FUN_0058c420();
  *(undefined ***)(appuStack_104[0][1] + (int)appuStack_104) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_108 + (int)appuStack_104[0][1]) = appuStack_104[0][1] + -0x50;
  pppuStack_140 = (undefined ***)0xa16721;
  FUN_0056b950();
  *(undefined ***)(appuStack_104[0][1] + (int)appuStack_104) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&iStack_108 + (int)appuStack_104[0][1]) = appuStack_104[0][1] + -8;
  pppuStack_140 = appuStack_b4;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  appuStack_b4[0] = std::ios_base::vftable;
  pppuStack_144 = (undefined ***)0xa16762;
  FUN_016de551();
  piVar4 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      pppuStack_140 = (undefined ***)0xa1677e;
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pppuStack_140 = (undefined ***)0xa1678d;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  pppuStack_140 = (undefined ***)0xa16795;
  FUN_00612650();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19995 ; VA 0x00a167b0 ; FUN_00a167b0 */

undefined4 FUN_00a167b0(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void **ppvVar4;
  char cVar5;
  int *piVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8348;
  puVar1 = (undefined4 *)*param_1;
  puVar2 = (undefined4 *)puVar1[1];
  ppvVar4 = &pvStack_10;
  pvStack_10 = ExceptionList;
  for (puVar7 = (undefined4 *)*puVar1; ExceptionList = ppvVar4, puVar7 != puVar2;
      puVar7 = puVar7 + 2) {
    piVar6 = (int *)puVar7[1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)puVar7[1];
    }
    uStack_8 = 0;
    cVar5 = FUN_008a3790(*puVar7,param_2);
    uStack_8 = 0xffffffff;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar3 = piVar6[1] + -1;
      piVar6[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar3 = piVar6[2] + -1;
        piVar6[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (cVar5 != '\0') break;
    ppvVar4 = (void **)ExceptionList;
  }
  ExceptionList = pvStack_10;
  return CONCAT31((int3)((uint)puVar1 >> 8),puVar7 != (undefined4 *)puVar1[1]);
}



/* FUNCTION 19996 ; VA 0x00a16860 ; FUN_00a16860 */

int FUN_00a16860(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a33830(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),0);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19997 ; VA 0x00a168e0 ; FUN_00a168e0 */

int FUN_00a168e0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a33830(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),2);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19998 ; VA 0x00a16960 ; FUN_00a16960 */

int FUN_00a16960(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a305c0(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),
                         *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14));
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19999 ; VA 0x00a169f0 ; FUN_00a169f0 */

void FUN_00a169f0(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  puVar2 = (undefined4 *)*param_1;
  iVar3 = puVar2[6];
  uVar4 = puVar2[5];
  uVar5 = puVar2[4];
  uVar6 = puVar2[3];
  uVar7 = puVar2[2];
  if (puVar2[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a186c0(*puVar2,puVar2[1],uVar7,uVar6,uVar5,uVar4,iVar3 + -1);
  return;
}


