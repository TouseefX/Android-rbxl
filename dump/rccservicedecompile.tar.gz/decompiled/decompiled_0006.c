/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 1500 ; VA 0x004eb4a0 ; FUN_004eb4a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eb4a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181057a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c9aa70(uVar2,0);
  FUN_009cb790(uVar1,s_GetCollisionGroups_0213aa2c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213a800 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PhysicsService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0213a838 = FUN_00c9ce20;
  _DAT_0213a83c = 0;
  _DAT_0213a824 = FUN_008882f0();
  FUN_016f3654(&LAB_01897cf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1501 ; VA 0x004eb540 ; FUN_004eb540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eb540(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181059a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c9aa70(uVar2,0);
  FUN_009cb790(uVar1,s_GetMaxCollisionGroups_0213aa40,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213a840 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PhysicsService,int___cdecl(void),0>::vftable;
  _DAT_0213a878 = FUN_0058c100;
  _DAT_0213a87c = 0;
  _DAT_0213a864 = FUN_0088c8c0();
  FUN_016f3654(&LAB_01897d00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1502 ; VA 0x004eb5e0 ; FUN_004eb5e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eb5e0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018105fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c9aa70();
  FUN_009cb790(uVar2,s_RemoveCollisionGroup_0213a938,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213a5b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PhysicsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0213a5f0 = FUN_00c9e520;
  _DAT_0213a5f4 = 0;
  DAT_0213a5f8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213a5dc = FUN_00888530();
  iVar1 = DAT_0213a5f8;
  if (DAT_0213a5f8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01897d10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1503 ; VA 0x004eb790 ; FUN_004eb790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eb790(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181062e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c9aa70(uVar2,0);
  FUN_009cb790(uVar1,s_RenameCollisionGroup_0213a95c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213a600 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PhysicsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0213a638 = FUN_00c9e610;
  _DAT_0213a63c = 0;
  _DAT_0213a640 = 0;
  _DAT_0213a644 = 0;
  uStack_8 = 2;
  FUN_00921260();
  FUN_016f3654(&LAB_01897d30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1504 ; VA 0x004eb850 ; FUN_004eb850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eb850(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181065e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c9aa70(uVar2,0);
  FUN_009cb790(uVar1,s_SetPartCollisionGroup_0213a974,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213a648 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PhysicsService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0213a680 = FUN_00c9e760;
  _DAT_0213a684 = 0;
  DAT_0213a688 = 0;
  _DAT_0213a68c = 0;
  uStack_8 = 2;
  FUN_00c9be10();
  FUN_016f3654(&LAB_01897d50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1505 ; VA 0x004ebbe0 ; FUN_004ebbe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ebbe0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810abc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ca4c20();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Constraints::Constraint,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::Constraints::Constraint::*)(void)const_,void_(__thiscall_RBX::Constraints::Constraint::*)(class_RBX::BrickColor_const&)>
              ::vftable;
    puVar3[2] = FUN_00ca5b30;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ca6800;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,s_Color_0213abec,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213ab90 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213abc4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213abb4 = _DAT_0213abb4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213ab90[2])();
    if (cVar1 != '\0') {
      _DAT_0213abb4 = _DAT_0213abb4 & 0xfffffff3;
    }
  }
  DAT_0213ab90 = RBX::Reflection::
                 PropDescriptor<class_RBX::Constraints::Constraint,class_RBX::BrickColor>::vftable;
  FUN_016f3654(&LAB_01897e80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1506 ; VA 0x004ebff0 ; FUN_004ebff0 */

void FUN_004ebff0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00cab6c0(FUN_00cad620,0,s_GetAlliesAsync_0213ad2c,s_groupId_0211fc28,0,uStack_10,0);
  FUN_016f3654(&LAB_01898140);
  return;
}



/* FUNCTION 1507 ; VA 0x004ec050 ; FUN_004ec050 */

void FUN_004ec050(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00cab6c0(FUN_00cad8c0,0,s_GetEnemiesAsync_0213ad3c,s_groupId_0211fc28,0,uStack_10,0);
  FUN_016f3654(&LAB_01898160);
  return;
}



/* FUNCTION 1508 ; VA 0x004ec0b0 ; FUN_004ec0b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ec0b0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181158c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ca9700();
  FUN_009cb820(uVar1,s_GetGroupInfoAsync_0213ad18,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213abf8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::GroupService,class_RBX::Reflection::Variant___cdecl(__int64),1>
       ::vftable;
  _DAT_0213ac30 = FUN_00cadb60;
  _DAT_0213ac34 = 0;
  DAT_0213ac38 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213ac1c = FUN_00888410();
  if (DAT_0213ac38 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_0213ac38);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_groupId_0211fc28);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_01898180);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1509 ; VA 0x004ec230 ; FUN_004ec230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ec230(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018115ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ca9700();
  FUN_009cb820(uVar1,s_GetGroupsAsync_0213ad4c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213acd0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::GroupService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(__int64),1>
       ::vftable;
  _DAT_0213ad08 = FUN_00cae220;
  _DAT_0213ad0c = 0;
  DAT_0213ad10 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213acf4 = FUN_008882f0();
  if (DAT_0213ad10 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_0213ad10);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_userId_0211fb64);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018981a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1510 ; VA 0x004ec3e0 ; FUN_004ec3e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ec3e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811ec4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00890320();
  uVar3 = FUN_00cb5a10();
  FUN_009ca670(uVar3,uVar2,s_TargetSurface_0213ada0,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213ad60 = RBX::Reflection::EnumPropDescriptor<class_RBX::SurfaceSelection,enum_RBX::NormalId>
                 ::vftable;
  _DAT_0213ad94 = uVar2;
  DAT_0213ad98 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213ad98 == (undefined4 *)0x0) {
    DAT_0213ad98 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213ad98 =
         RBX::Reflection::PropDescriptor<class_RBX::SurfaceSelection,enum_RBX::NormalId>::
         GetSetImpl<enum_RBX::NormalId_(__thiscall_RBX::SurfaceSelection::*)(void)const_,void_(__thiscall_RBX::SurfaceSelection::*)(enum_RBX::NormalId)>
         ::vftable;
    DAT_0213ad98[2] = &LAB_00cb5ed0;
    DAT_0213ad98[3] = 0;
    DAT_0213ad98[4] = FUN_00cb6120;
    DAT_0213ad98[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213ad9c = FUN_00890320();
  cVar1 = (*(code *)DAT_0213ad60[3])();
  if (cVar1 != '\0') {
    _DAT_0213ad84 = _DAT_0213ad84 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213ad60[2])();
  if (cVar1 != '\0') {
    _DAT_0213ad84 = _DAT_0213ad84 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01898220);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1511 ; VA 0x004ec560 ; FUN_004ec560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ec560(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181247c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cb6a80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Soundscape::SoundEffect,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Soundscape::SoundEffect::*)(void)const_,void_(__thiscall_RBX::Soundscape::SoundEffect::*)(bool)>
              ::vftable;
    puVar3[2] = FUN_009501e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00cbb290;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_Enabled_0212c1fc,s_State_0211d030,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213adb0 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213ade4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213add4 = _DAT_0213add4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213adb0[2])();
    if (cVar1 != '\0') {
      _DAT_0213add4 = _DAT_0213add4 & 0xfffffff3;
    }
  }
  DAT_0213adb0 = RBX::Reflection::PropDescriptor<class_RBX::Soundscape::SoundEffect,bool>::vftable;
  FUN_016f3654(&LAB_018982a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1512 ; VA 0x004ec690 ; FUN_004ec690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ec690(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018124ac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cb6a80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Soundscape::SoundEffect,int>::
              GetSetImpl<int_(__thiscall_RBX::Soundscape::SoundEffect::*)(void)const_,void_(__thiscall_RBX::Soundscape::SoundEffect::*)(int)>
              ::vftable;
    puVar3[2] = FUN_00cb95e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00cbb7a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_Priority_0213b47c,s_State_0211d030,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213ade8 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213ae1c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213ae0c = _DAT_0213ae0c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213ade8[2])();
    if (cVar1 != '\0') {
      _DAT_0213ae0c = _DAT_0213ae0c & 0xfffffff3;
    }
  }
  DAT_0213ade8 = RBX::Reflection::PropDescriptor<class_RBX::Soundscape::SoundEffect,int>::vftable;
  FUN_016f3654(&LAB_018982c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1513 ; VA 0x004ecdc0 ; FUN_004ecdc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ecdc0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018124e0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x1f);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00cb6380();
  FUN_009ca670(uVar2,&DAT_01edf850,s_SideChain_0213b54c,s_State_0211d030,uVar3,uVar4,uVar5,uVar6,0,0
               ,0);
  uStack_8 = 1;
  DAT_0213b440 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::Soundscape::CompressorSoundEffect,class_RBX::Instance>
                 ::vftable;
  _DAT_0213b474 =
       RBX::Reflection::
       RefPropDescriptor<class_RBX::Soundscape::CompressorSoundEffect,class_RBX::Instance>::vftable;
  DAT_0213b478 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213b478 == (undefined4 *)0x0) {
    DAT_0213b478 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213b478 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Soundscape::CompressorSoundEffect,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::Soundscape::CompressorSoundEffect::*)(void)const_,void_(__thiscall_RBX::Soundscape::CompressorSoundEffect::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_0213b478[2] = FUN_00cb93c0;
    DAT_0213b478[3] = 0;
    DAT_0213b478[4] = FUN_00cba9f0;
    DAT_0213b478[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0213b440[3])();
  if (cVar1 != '\0') {
    _DAT_0213b464 = _DAT_0213b464 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213b440[2])();
  if (cVar1 != '\0') {
    _DAT_0213b464 = _DAT_0213b464 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01898420);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1514 ; VA 0x004edfa0 ; FUN_004edfa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004edfa0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01812733;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cbc270();
  FUN_009cb970(uVar1,s_SourceValueChanged_0213b688,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0213b5c8 = 100;
  iStack_8 = 0;
  _DAT_0213b594 =
       RBX::Reflection::
       EventDesc<class_RBX::CustomEventReceiver,void___cdecl(float),class_rbx::signal<void___cdecl(float)>,class_rbx::signal<void___cdecl(float)>_RBX::CustomEventReceiver::*>
       ::vftable;
  FUN_0086e3d0(s_newValue_0211d29c);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0213b5bc = uStack_1c;
  _DAT_0213b5c0 = uStack_18;
  _DAT_0213b5c4 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0213b594 =
       RBX::Reflection::
       EventDesc<class_RBX::CustomEventReceiver,void___cdecl(float),class_rbx::signal<void___cdecl(float)>,class_rbx::signal<void___cdecl(float)>_RBX::CustomEventReceiver::*>
       ::vftable;
  FUN_016f3654(&LAB_01898a70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1515 ; VA 0x004ee0f0 ; FUN_004ee0f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ee0f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181274a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cbc270(uVar2,0);
  FUN_009cb790(uVar1,s_GetCurrentValue_0213b69c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213b5d0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::CustomEventReceiver,float___cdecl(void),0>::vftable
  ;
  _DAT_0213b608 = &LAB_00927190;
  _DAT_0213b60c = 0;
  _DAT_0213b5f4 = FUN_0088c960();
  FUN_016f3654(&LAB_01898a80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1516 ; VA 0x004ee190 ; FUN_004ee190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ee190(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812780;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x1f);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00cbc270();
  FUN_009ca670(uVar2,&DAT_01edf850,s_Source_0213b680,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_0213b558 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::CustomEventReceiver,class_RBX::Instance>::vftable;
  _DAT_0213b58c =
       RBX::Reflection::RefPropDescriptor<class_RBX::CustomEventReceiver,class_RBX::Instance>::
       vftable;
  DAT_0213b590 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213b590 == (undefined4 *)0x0) {
    DAT_0213b590 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213b590 =
         RBX::Reflection::PropDescriptor<class_RBX::CustomEventReceiver,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::CustomEventReceiver::*)(void)const_,void_(__thiscall_RBX::CustomEventReceiver::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_0213b590[2] = FUN_00927fa0;
    DAT_0213b590[3] = 0;
    DAT_0213b590[4] = FUN_00cbcf50;
    DAT_0213b590[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0213b558[3])();
  if (cVar1 != '\0') {
    _DAT_0213b57c = _DAT_0213b57c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213b558[2])();
  if (cVar1 != '\0') {
    _DAT_0213b57c = _DAT_0213b57c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01898a90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1517 ; VA 0x004ee5c0 ; FUN_004ee5c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ee5c0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("MatchingGraphicsQualityLevels",0x1d);
  _DAT_01f0424c = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1518 ; VA 0x004ee6b0 ; FUN_004ee6b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ee6b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181297a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cbd460(uVar2,0);
  FUN_009cb790(uVar1,s_GetCameraYInvertValue_0213c804,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213c158 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GameBasicSettings,int___cdecl(void),0>::vftable;
  _DAT_0213c190 = &LAB_00cbf0a0;
  _DAT_0213c194 = 0;
  _DAT_0213c17c = FUN_0088c8c0();
  FUN_016f3654(&LAB_01898b80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1519 ; VA 0x004ee750 ; FUN_004ee750 */

void FUN_004ee750(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00cbdf30(FUN_00cbf3a0,0,s_GetOnboardingCompleted_0213c888,s_onboardingId_0213c844,0,uStack_10,
               0);
  FUN_016f3654(&LAB_01898b90);
  return;
}



/* FUNCTION 1520 ; VA 0x004ee7b0 ; FUN_004ee7b0 */

void FUN_004ee7b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00cbdf30(FUN_00cbf580,0,s_GetTutorialState_0213c47c,s_tutorialId_0213c470,5,uStack_10,0);
  FUN_016f3654(&LAB_01898bb0);
  return;
}



/* FUNCTION 1521 ; VA 0x004ee810 ; FUN_004ee810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ee810(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181299a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cbd460(uVar2,0);
  FUN_009cb790(uVar1,s_InFullScreen_0213c5ac,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213bc08 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GameBasicSettings,bool___cdecl(void),0>::vftable;
  _DAT_0213bc40 = FUN_0086b910;
  _DAT_0213bc44 = 0;
  _DAT_0213bc2c = FUN_0088daf0();
  FUN_016f3654(&LAB_01898bd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1522 ; VA 0x004ee8b0 ; FUN_004ee8b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ee8b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018129ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cbd460(uVar2,0);
  FUN_009cb790(uVar1,s_InStudioMode_0213c5bc,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213bc48 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GameBasicSettings,bool___cdecl(void),0>::vftable;
  _DAT_0213bc80 = &LAB_008fc860;
  _DAT_0213bc84 = 0;
  _DAT_0213bc6c = FUN_0088daf0();
  FUN_016f3654(&LAB_01898be0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1523 ; VA 0x004ee950 ; FUN_004ee950 */

void FUN_004ee950(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00cbddb0(FUN_00cbfe30,0,s_ResetOnboardingCompleted_0213c86c,s_onboardingId_0213c844,5,
               uStack_10,0);
  FUN_016f3654(&LAB_01898bf0);
  return;
}



/* FUNCTION 1524 ; VA 0x004ee9b0 ; FUN_004ee9b0 */

void FUN_004ee9b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00cbddb0(FUN_00cc0c10,0,s_SetOnboardingCompleted_0213c854,s_onboardingId_0213c844,0,uStack_10,
               0);
  FUN_016f3654(&LAB_01898c10);
  return;
}



/* FUNCTION 1525 ; VA 0x004eea10 ; FUN_004eea10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eea10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018129ee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cbd460(uVar2,0);
  FUN_009cb790(uVar1,s_SetTutorialState_0213c490,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0213b950 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GameBasicSettings,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),2>
       ::vftable;
  _DAT_0213b988 = FUN_00cc16d0;
  _DAT_0213b98c = 0;
  _DAT_0213b990 = 0;
  DAT_0213b994 = 0;
  uStack_8 = 2;
  FUN_009218e0();
  FUN_016f3654(&LAB_01898c30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1526 ; VA 0x004eead0 ; FUN_004eead0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eead0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812a0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cbd460(uVar2,0);
  FUN_009cb790(uVar1,s_SetCameraYInvertVisible_0213c81c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213c198 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GameBasicSettings,void___cdecl(void),0>::vftable;
  _DAT_0213c1d0 = &LAB_00cbf020;
  _DAT_0213c1d4 = 0;
  _DAT_0213c1bc = FUN_00888530();
  FUN_016f3654(&LAB_01898c60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1527 ; VA 0x004eeb70 ; FUN_004eeb70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eeb70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812a2a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cbd460(uVar2,0);
  FUN_009cb790(uVar1,s_SetGamepadCameraSensitivityVisib_0213c588,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213bbc8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GameBasicSettings,void___cdecl(void),0>::vftable;
  _DAT_0213bc00 = &LAB_00cbf040;
  _DAT_0213bc04 = 0;
  _DAT_0213bbec = FUN_00888530();
  FUN_016f3654(&LAB_01898c70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1528 ; VA 0x004eef30 ; FUN_004eef30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eef30(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812a54;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cc1b10();
  uVar3 = FUN_00cbd460();
  FUN_009ca670(uVar3,uVar2,s_CameraMode_0211ff3c,s_Control_0211ffd0,uStack_24,0,0,0x1f,5,5,1);
  uStack_8 = 0;
  DAT_0213b710 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::CameraMode>
                 ::vftable;
  _DAT_0213b744 = uVar2;
  DAT_0213b748 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213b748 == (undefined4 *)0x0) {
    DAT_0213b748 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213b748 =
         RBX::Reflection::
         PropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::CameraMode>::
         GetSetImpl<enum_RBX::GameBasicSettings::CameraMode_(__thiscall_RBX::GameBasicSettings::*)(void)const_,void_(__thiscall_RBX::GameBasicSettings::*)(enum_RBX::GameBasicSettings::CameraMode)>
         ::vftable;
    DAT_0213b748[2] = &LAB_00ba5950;
    DAT_0213b748[3] = 0;
    DAT_0213b748[4] = FUN_00cbfff0;
    DAT_0213b748[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213b74c = FUN_00cc1b10();
  cVar1 = (*(code *)DAT_0213b710[3])();
  if (cVar1 != '\0') {
    _DAT_0213b734 = _DAT_0213b734 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213b710[2])();
  if (cVar1 != '\0') {
    _DAT_0213b734 = _DAT_0213b734 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01898d80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1529 ; VA 0x004ef590 ; FUN_004ef590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ef590(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812a74;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c51450();
  uVar3 = FUN_00cbd460();
  FUN_009ca670(uVar3,uVar2,s_ComputerCameraMovementMode_0213c3ec,s_Control_0211ffd0,uStack_24,0,0,
               0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213b790 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::ComputerCameraMovementMode>
                 ::vftable;
  _DAT_0213b7c4 = uVar2;
  DAT_0213b7c8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213b7c8 == (undefined4 *)0x0) {
    DAT_0213b7c8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213b7c8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::ComputerCameraMovementMode>
         ::
         GetSetImpl<enum_RBX::GameBasicSettings::ComputerCameraMovementMode_(__thiscall_RBX::GameBasicSettings::*)(void)const_,void_(__thiscall_RBX::GameBasicSettings::*)(enum_RBX::GameBasicSettings::ComputerCameraMovementMode)>
         ::vftable;
    DAT_0213b7c8[2] = FUN_00c54090;
    DAT_0213b7c8[3] = 0;
    DAT_0213b7c8[4] = FUN_00cc02b0;
    DAT_0213b7c8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213b7cc = FUN_00c51450();
  cVar1 = (*(code *)DAT_0213b790[3])();
  if (cVar1 != '\0') {
    _DAT_0213b7b4 = _DAT_0213b7b4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213b790[2])();
  if (cVar1 != '\0') {
    _DAT_0213b7b4 = _DAT_0213b7b4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01898e80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1530 ; VA 0x004ef6b0 ; FUN_004ef6b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ef6b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812a94;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c514e0();
  uVar3 = FUN_00cbd460();
  FUN_009ca670(uVar3,uVar2,s_ComputerMovementMode_0213c41c,s_Control_0211ffd0,uStack_24,0,0,0x1f,0,0
               ,1);
  uStack_8 = 0;
  DAT_0213b810 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::ComputerMovementMode>
                 ::vftable;
  _DAT_0213b844 = uVar2;
  DAT_0213b848 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213b848 == (undefined4 *)0x0) {
    DAT_0213b848 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213b848 =
         RBX::Reflection::
         PropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::ComputerMovementMode>
         ::
         GetSetImpl<enum_RBX::GameBasicSettings::ComputerMovementMode_(__thiscall_RBX::GameBasicSettings::*)(void)const_,void_(__thiscall_RBX::GameBasicSettings::*)(enum_RBX::GameBasicSettings::ComputerMovementMode)>
         ::vftable;
    DAT_0213b848[2] = &LAB_0074b4e0;
    DAT_0213b848[3] = 0;
    DAT_0213b848[4] = FUN_00cc0490;
    DAT_0213b848[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213b84c = FUN_00c514e0();
  cVar1 = (*(code *)DAT_0213b810[3])();
  if (cVar1 != '\0') {
    _DAT_0213b834 = _DAT_0213b834 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213b810[2])();
  if (cVar1 != '\0') {
    _DAT_0213b834 = _DAT_0213b834 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01898ea0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1531 ; VA 0x004ef7d0 ; FUN_004ef7d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ef7d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812ab4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cc1bc0();
  uVar3 = FUN_00cbd460();
  FUN_009ca670(uVar3,uVar2,s_ControlMode_0213c3c8,s_Control_0211ffd0,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213b6d0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::ControlMode>
                 ::vftable;
  _DAT_0213b704 = uVar2;
  DAT_0213b708 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213b708 == (undefined4 *)0x0) {
    DAT_0213b708 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213b708 =
         RBX::Reflection::
         PropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::ControlMode>::
         GetSetImpl<enum_RBX::GameBasicSettings::ControlMode_(__thiscall_RBX::GameBasicSettings::*)(void)const_,void_(__thiscall_RBX::GameBasicSettings::*)(enum_RBX::GameBasicSettings::ControlMode)>
         ::vftable;
    DAT_0213b708[2] = FUN_00855cc0;
    DAT_0213b708[3] = 0;
    DAT_0213b708[4] = FUN_00cc0650;
    DAT_0213b708[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213b70c = FUN_00cc1bc0();
  cVar1 = (*(code *)DAT_0213b6d0[3])();
  if (cVar1 != '\0') {
    _DAT_0213b6f4 = _DAT_0213b6f4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213b6d0[2])();
  if (cVar1 != '\0') {
    _DAT_0213b6f4 = _DAT_0213b6f4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01898ec0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1532 ; VA 0x004f0270 ; FUN_004f0270 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f0270(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812ad4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cc1c80();
  uVar3 = FUN_00cbd460();
  FUN_009ca670(uVar3,uVar2,s_SavedQualityLevel_0213c434,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0
               ,1);
  uStack_8 = 0;
  DAT_0213b850 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::RenderQualitySetting>
                 ::vftable;
  _DAT_0213b884 = uVar2;
  DAT_0213b888 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213b888 == (undefined4 *)0x0) {
    DAT_0213b888 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213b888 =
         RBX::Reflection::
         PropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::RenderQualitySetting>
         ::
         GetSetImpl<enum_RBX::GameBasicSettings::RenderQualitySetting_(__thiscall_RBX::GameBasicSettings::*)(void)const_,void_(__thiscall_RBX::GameBasicSettings::*)(enum_RBX::GameBasicSettings::RenderQualitySetting)>
         ::vftable;
    DAT_0213b888[2] = &LAB_00cb5ed0;
    DAT_0213b888[3] = 0;
    DAT_0213b888[4] = FUN_00cc1150;
    DAT_0213b888[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213b88c = FUN_00cc1c80();
  cVar1 = (*(code *)DAT_0213b850[3])();
  if (cVar1 != '\0') {
    _DAT_0213b874 = _DAT_0213b874 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213b850[2])();
  if (cVar1 != '\0') {
    _DAT_0213b874 = _DAT_0213b874 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018990e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1533 ; VA 0x004f0390 ; FUN_004f0390 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f0390(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812af4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cc1d30();
  uVar3 = FUN_00cbd460();
  FUN_009ca670(uVar3,uVar2,s_RotationType_0213c460,s_Control_0211ffd0,uStack_24,0,0,0x13,0,0,1);
  uStack_8 = 0;
  DAT_0213b8c8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::RotationType>
                 ::vftable;
  _DAT_0213b8fc = uVar2;
  DAT_0213b900 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213b900 == (undefined4 *)0x0) {
    DAT_0213b900 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213b900 =
         RBX::Reflection::
         PropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::RotationType>::
         GetSetImpl<enum_RBX::GameBasicSettings::RotationType_(__thiscall_RBX::GameBasicSettings::*)(void)const_,void_(__thiscall_RBX::GameBasicSettings::*)(enum_RBX::GameBasicSettings::RotationType)>
         ::vftable;
    DAT_0213b900[2] = FUN_0086b740;
    DAT_0213b900[3] = 0;
    DAT_0213b900[4] = FUN_00cc1200;
    DAT_0213b900[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213b904 = FUN_00cc1d30();
  cVar1 = (*(code *)DAT_0213b8c8[3])();
  if (cVar1 != '\0') {
    _DAT_0213b8ec = _DAT_0213b8ec & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213b8c8[2])();
  if (cVar1 != '\0') {
    _DAT_0213b8ec = _DAT_0213b8ec & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01899100);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1534 ; VA 0x004f0610 ; FUN_004f0610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f0610(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812b14;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c51570();
  uVar3 = FUN_00cbd460();
  FUN_009ca670(uVar3,uVar2,s_TouchCameraMovementMode_0213c3d4,s_Control_0211ffd0,uStack_24,0,0,0x1f,
               0,0,1);
  uStack_8 = 0;
  DAT_0213b750 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::TouchCameraMovementMode>
                 ::vftable;
  _DAT_0213b784 = uVar2;
  DAT_0213b788 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213b788 == (undefined4 *)0x0) {
    DAT_0213b788 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213b788 =
         RBX::Reflection::
         PropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::TouchCameraMovementMode>
         ::
         GetSetImpl<enum_RBX::GameBasicSettings::TouchCameraMovementMode_(__thiscall_RBX::GameBasicSettings::*)(void)const_,void_(__thiscall_RBX::GameBasicSettings::*)(enum_RBX::GameBasicSettings::TouchCameraMovementMode)>
         ::vftable;
    DAT_0213b788[2] = &LAB_00c11840;
    DAT_0213b788[3] = 0;
    DAT_0213b788[4] = FUN_00cc1300;
    DAT_0213b788[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213b78c = FUN_00c51570();
  cVar1 = (*(code *)DAT_0213b750[3])();
  if (cVar1 != '\0') {
    _DAT_0213b774 = _DAT_0213b774 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213b750[2])();
  if (cVar1 != '\0') {
    _DAT_0213b774 = _DAT_0213b774 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01899180);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1535 ; VA 0x004f0730 ; FUN_004f0730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f0730(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01812b34;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c51600();
  uVar3 = FUN_00cbd460();
  FUN_009ca670(uVar3,uVar2,s_TouchMovementMode_0213c408,s_Control_0211ffd0,uStack_24,0,0,0x1f,0,0,1)
  ;
  uStack_8 = 0;
  DAT_0213b7d0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::TouchMovementMode>
                 ::vftable;
  _DAT_0213b804 = uVar2;
  DAT_0213b808 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213b808 == (undefined4 *)0x0) {
    DAT_0213b808 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213b808 =
         RBX::Reflection::
         PropDescriptor<class_RBX::GameBasicSettings,enum_RBX::GameBasicSettings::TouchMovementMode>
         ::
         GetSetImpl<enum_RBX::GameBasicSettings::TouchMovementMode_(__thiscall_RBX::GameBasicSettings::*)(void)const_,void_(__thiscall_RBX::GameBasicSettings::*)(enum_RBX::GameBasicSettings::TouchMovementMode)>
         ::vftable;
    DAT_0213b808[2] = FUN_008f8770;
    DAT_0213b808[3] = 0;
    DAT_0213b808[4] = FUN_00cc14e0;
    DAT_0213b808[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213b80c = FUN_00c51600();
  cVar1 = (*(code *)DAT_0213b7d0[3])();
  if (cVar1 != '\0') {
    _DAT_0213b7f4 = _DAT_0213b7f4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213b7d0[2])();
  if (cVar1 != '\0') {
    _DAT_0213b7f4 = _DAT_0213b7f4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018991a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1536 ; VA 0x004f0da0 ; FUN_004f0da0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f0da0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181388e;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cce370(uVar2,0);
  FUN_009cb820(uVar1,s_GetDataFromEmptyScopeDataStoreAs_0213cb58,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213ca78 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::DataStoreService,class_RBX::Reflection::Variant___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0213cab0 = FUN_00cd4290;
  _DAT_0213cab4 = 0;
  _DAT_0213cab8 = 0;
  _DAT_0213cabc = 0;
  uStack_8 = 2;
  FUN_00cd2b40();
  FUN_016f3654(&LAB_018993d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1537 ; VA 0x004f1290 ; FUN_004f1290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f1290(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018138ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cce370();
  FUN_009cb790(uVar1,s_GetRequestBudgetForRequestType_0213cb14,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213c9c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataStoreService,int___cdecl(enum_RBX::DataStoreService::DataStoreRequestType),1>
       ::vftable;
  _DAT_0213c9f8 = FUN_00cd4820;
  _DAT_0213c9fc = 0;
  DAT_0213ca00 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213c9e4 = FUN_0088c8c0();
  puVar3 = DAT_0213ca00;
  if (DAT_0213ca00 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00896c30();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00897260();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00896c30();
  uVar2 = FUN_0086e3d0(s_requestType_0213cb08);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01899450);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1538 ; VA 0x004f1430 ; FUN_004f1430 */

void FUN_004f1430(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0213cad4;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0213cad4,pcVar2 + -0x213cad4);
  FUN_00ccf660(FUN_00cd3de0,0,s_GetDataStore_0213cae4,&DAT_0211a93c,s_scope_0213cadc);
  FUN_016f3654();
  return;
}



/* FUNCTION 1539 ; VA 0x004f14d0 ; FUN_004f14d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f14d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181390a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00cce370(uVar2,0);
  FUN_009cb790(uVar1,s_GetGlobalDataStore_0213cac0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213c8f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataStoreService,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_0213c928 = FUN_00cd4630;
  _DAT_0213c92c = 0;
  _DAT_0213c914 = FUN_0088cdc0();
  FUN_016f3654(&LAB_01899490);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1540 ; VA 0x004f1570 ; FUN_004f1570 */

void FUN_004f1570(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0213cad4;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0213cad4,pcVar2 + -0x213cad4);
  FUN_00ccf660(FUN_00cd46d0,0,s_GetOrderedDataStore_0213caf4,&DAT_0211a93c,s_scope_0213cadc);
  FUN_016f3654();
  return;
}



/* FUNCTION 1541 ; VA 0x004f1610 ; FUN_004f1610 */

void FUN_004f1610(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb3a0(auStack_14,0x1f);
  FUN_00cce270(s_LegacyNamingScheme_0213cb44,s_Behavior_0211a8f8,&LAB_00858c40,0,FUN_00cd83d0,0,
               *puVar1,puVar1[1],puVar1[2],puVar1[3],3);
  FUN_016f3654(&LAB_018994c0);
  return;
}



/* FUNCTION 1542 ; VA 0x004f1e30 ; FUN_004f1e30 */

void FUN_004f1e30(void)

{
  FUN_00cfadd0("DoubleSided","Appearance",0x7631e0,0,0xcfdaf0,0,0,0,0,0x1f,0,1);
  FUN_016f3654(&LAB_018995c0);
  return;
}



/* FUNCTION 1543 ; VA 0x004f1fb0 ; FUN_004f1fb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f1fb0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01815d7c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cfb1a0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x731590;
    *(undefined8 *)(puVar3 + 6) = 0xcfdd50;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::MeshPart,class_RBX::MeshId>::
              GetSetImpl<class_RBX::MeshId_const&_(__thiscall_RBX::MeshPart::*)(void)const_,void_(__thiscall_RBX::MeshPart::*)(class_RBX::MeshId)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,"MeshId","Appearance",uStack_3c,0,0,0x1f,0,7,0);
  DAT_01f04f88 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::MeshId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f04fbc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f04fac = _DAT_01f04fac & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f04f88[2])();
    if (cVar1 != '\0') {
      _DAT_01f04fac = _DAT_01f04fac & 0xfffffff3;
    }
  }
  DAT_01f04f88 = RBX::Reflection::PropDescriptor<class_RBX::MeshPart,class_RBX::MeshId>::vftable;
  FUN_016f3654(&LAB_01899600);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1544 ; VA 0x004f2100 ; FUN_004f2100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f2100(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01815dac;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cfb1a0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x93a140;
    *(undefined8 *)(puVar3 + 6) = 0xb51a86;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::MeshPart,class_RBX::BinaryString>::
              GetSetImpl<class_RBX::BinaryString_const&_(__thiscall_RBX::MeshPart::*)(void)const_,void_(__thiscall_RBX::MeshPart::*)(class_RBX::BinaryString_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cf00();
  FUN_009ca670(uVar2,uVar4,"PhysicsData",&DAT_018dbc3c,uStack_3c,0,0,0xe,6,6,0);
  DAT_01f050a0 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BinaryString>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f050d4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f050c4 = _DAT_01f050c4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f050a0[2])();
    if (cVar1 != '\0') {
      _DAT_01f050c4 = _DAT_01f050c4 & 0xfffffff3;
    }
  }
  DAT_01f050a0 = RBX::Reflection::PropDescriptor<class_RBX::MeshPart,class_RBX::BinaryString>::
                 vftable;
  FUN_016f3654(&LAB_01899620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1545 ; VA 0x004f2250 ; FUN_004f2250 */

void FUN_004f2250(void)

{
  FUN_00cface0("RenderFidelity","Appearance",0x70ddc0,0,0xcfe240,0,0,0,0,0x1f,0,1);
  FUN_016f3654(&LAB_01899640);
  return;
}



/* FUNCTION 1546 ; VA 0x004f22f0 ; FUN_004f22f0 */

void FUN_004f22f0(void)

{
  FUN_00cface0("RenderFidelityReplicate","Appearance",0x70ddc0,0,0xcfe3b0,0,0,0,0,2,0,1);
  FUN_016f3654(&LAB_01899660);
  return;
}



/* FUNCTION 1547 ; VA 0x004f2390 ; FUN_004f2390 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f2390(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01815ddc;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cfb1a0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x7315a0;
    *(undefined8 *)(puVar3 + 6) = 0xcfe3f0;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::MeshPart,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_const&_(__thiscall_RBX::MeshPart::*)(void)const_,void_(__thiscall_RBX::MeshPart::*)(class_RBX::TextureId)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,"TextureID","Appearance",uStack_3c,0,0,0x1f,0,0,0);
  DAT_01f04f50 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f04f84 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f04f74 = _DAT_01f04f74 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f04f50[2])();
    if (cVar1 != '\0') {
      _DAT_01f04f74 = _DAT_01f04f74 & 0xfffffff3;
    }
  }
  DAT_01f04f50 = RBX::Reflection::PropDescriptor<class_RBX::MeshPart,class_RBX::TextureId>::vftable;
  FUN_016f3654(&LAB_01899680);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1548 ; VA 0x004f24e0 ; FUN_004f24e0 */

void FUN_004f24e0(void)

{
  FUN_00cfadd0("HasJointOffset","Appearance",0x85e840,0,0xcfdb20,0,0,0,0,0x1e,0,7);
  FUN_016f3654(&LAB_018996a0);
  return;
}



/* FUNCTION 1549 ; VA 0x004f2580 ; FUN_004f2580 */

void FUN_004f2580(void)

{
  FUN_00cfadd0("HasSkinnedMesh","Appearance",0x7b43f0,0,0xcfdb50,0,0,0,0,0x1e,0,7);
  FUN_016f3654(&LAB_018996c0);
  return;
}



/* FUNCTION 1550 ; VA 0x004f2620 ; FUN_004f2620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f2620(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01815e0c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cfb1a0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x76df80;
    *(undefined8 *)(puVar3 + 6) = 0xcfdce0;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::MeshPart,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_const&_(__thiscall_RBX::MeshPart::*)(void)const_,void_(__thiscall_RBX::MeshPart::*)(class_G3D::Vector3_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,"JointOffset",&DAT_018dbc3c,uStack_3c,0,0,0x1e,0,7,0);
  DAT_01f05068 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f0509c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f0508c = _DAT_01f0508c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f05068[2])();
    if (cVar1 != '\0') {
      _DAT_01f0508c = _DAT_01f0508c & 0xfffffff3;
    }
  }
  DAT_01f05068 = RBX::Reflection::PropDescriptor<class_RBX::MeshPart,class_G3D::Vector3>::vftable;
  FUN_016f3654(&LAB_018996e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1551 ; VA 0x004f2960 ; FUN_004f2960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f2960(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01815e6c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00cfc290;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cfb1a0();
  FUN_009cb790(uVar2,"ApplyMesh",0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_01f05180 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_01f05148 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MeshPart,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_01f05188 = 0;
  DAT_01f0518c = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_01f0516c = FUN_00888530();
  puVar4 = DAT_01f0518c;
  if (DAT_01f0518c == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088cdc0();
    iStack_f8 = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_f4 = *puVar4;
    uStack_f0 = puVar4[1];
    iStack_f8 = FUN_006309e0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0("meshPart");
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_01899700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1552 ; VA 0x004f2dd0 ; FUN_004f2dd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f2dd0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01816134;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cff800();
  uVar3 = FUN_00cfed30();
  FUN_009ca670(uVar3,uVar2,s_BodyPart_0213cc70,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213cb88 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::CharacterMesh,enum_RBX::CharacterMesh::BodyPart>::
                 vftable;
  _DAT_0213cbbc = uVar2;
  DAT_0213cbc0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213cbc0 == (undefined4 *)0x0) {
    DAT_0213cbc0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213cbc0 =
         RBX::Reflection::PropDescriptor<class_RBX::CharacterMesh,enum_RBX::CharacterMesh::BodyPart>
         ::
         GetSetImpl<enum_RBX::CharacterMesh::BodyPart_(__thiscall_RBX::CharacterMesh::*)(void)const_,void_(__thiscall_RBX::CharacterMesh::*)(enum_RBX::CharacterMesh::BodyPart)>
         ::vftable;
    DAT_0213cbc0[2] = FUN_0074a340;
    DAT_0213cbc0[3] = 0;
    DAT_0213cbc0[4] = FUN_00cff740;
    DAT_0213cbc0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213cbc4 = FUN_00cff800();
  cVar1 = (*(code *)DAT_0213cb88[3])();
  if (cVar1 != '\0') {
    _DAT_0213cbac = _DAT_0213cbac & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213cb88[2])();
  if (cVar1 != '\0') {
    _DAT_0213cbac = _DAT_0213cbac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018998f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1553 ; VA 0x004f2ff0 ; FUN_004f2ff0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f2ff0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181633c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cffc50();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Decal,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::Decal::*)(void)const_,void_(__thiscall_RBX::Decal::*)(class_G3D::Color3)>
              ::vftable;
    puVar3[2] = FUN_0074a160;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d00aa0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,s_Color3_0213cef8,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213ce88 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213cebc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213ceac = _DAT_0213ceac & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213ce88[2])();
    if (cVar1 != '\0') {
      _DAT_0213ceac = _DAT_0213ceac & 0xfffffff3;
    }
  }
  DAT_0213ce88 = RBX::Reflection::PropDescriptor<class_RBX::Decal,class_G3D::Color3>::vftable;
  FUN_016f3654(&LAB_018999e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1554 ; VA 0x004f3660 ; FUN_004f3660 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f3660(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181636c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00cffc50();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Decal,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_const&_(__thiscall_RBX::Decal::*)(void)const_,void_(__thiscall_RBX::Decal::*)(class_RBX::TextureId)>
              ::vftable;
    puVar3[2] = &LAB_00764420;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d00d70;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_Texture_0213cec0,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213cd70 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213cda4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213cd94 = _DAT_0213cd94 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213cd70[2])();
    if (cVar1 != '\0') {
      _DAT_0213cd94 = _DAT_0213cd94 & 0xfffffff3;
    }
  }
  DAT_0213cd70 = RBX::Reflection::PropDescriptor<class_RBX::Decal,class_RBX::TextureId>::vftable;
  FUN_016f3654(&LAB_01899ae0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1555 ; VA 0x004f3890 ; FUN_004f3890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f3890(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181640c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d01590();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::BaseWrap,class_RBX::MeshId>::
              GetSetImpl<class_RBX::MeshId_const&_(__thiscall_RBX::BaseWrap::*)(void)const_,void_(__thiscall_RBX::BaseWrap::*)(class_RBX::MeshId_const&)>
              ::vftable;
    puVar3[2] = FUN_00d01ad0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d01ff0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,"CageMeshId","Appearance",uStack_24,0,0,0x1f,0,1,0);
  DAT_01f060f4 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::MeshId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f06128 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f06118 = _DAT_01f06118 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f060f4[2])();
    if (cVar1 != '\0') {
      _DAT_01f06118 = _DAT_01f06118 & 0xfffffff3;
    }
  }
  DAT_01f060f4 = RBX::Reflection::PropDescriptor<class_RBX::BaseWrap,class_RBX::MeshId>::vftable;
  FUN_016f3654(&LAB_01899be0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1556 ; VA 0x004f3ba0 ; FUN_004f3ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f3ba0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01816cb4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d0fb10();
  uVar3 = FUN_00d0f2a0();
  FUN_009ca670(uVar3,uVar2,s_MeshType_0213cf40,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213cf00 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::SpecialShape,enum_RBX::SpecialShape::MeshType>::
                 vftable;
  _DAT_0213cf34 = uVar2;
  DAT_0213cf38 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213cf38 == (undefined4 *)0x0) {
    DAT_0213cf38 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213cf38 =
         RBX::Reflection::PropDescriptor<class_RBX::SpecialShape,enum_RBX::SpecialShape::MeshType>::
         GetSetImpl<enum_RBX::SpecialShape::MeshType_(__thiscall_RBX::SpecialShape::*)(void)const_,void_(__thiscall_RBX::SpecialShape::*)(enum_RBX::SpecialShape::MeshType)>
         ::vftable;
    DAT_0213cf38[2] = &LAB_0074b4e0;
    DAT_0213cf38[3] = 0;
    DAT_0213cf38[4] = FUN_00d0fa40;
    DAT_0213cf38[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213cf3c = FUN_00d0fb10();
  cVar1 = (*(code *)DAT_0213cf00[3])();
  if (cVar1 != '\0') {
    _DAT_0213cf24 = _DAT_0213cf24 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213cf00[2])();
  if (cVar1 != '\0') {
    _DAT_0213cf24 = _DAT_0213cf24 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01899d50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1557 ; VA 0x004f3cc0 ; FUN_004f3cc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f3cc0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01816d8c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d0fc80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::FileMesh,class_RBX::MeshId>::
              GetSetImpl<class_RBX::MeshId_const&_(__thiscall_RBX::FileMesh::*)(void)const_,void_(__thiscall_RBX::FileMesh::*)(class_RBX::MeshId_const&)>
              ::vftable;
    puVar3[2] = FUN_0074ae10;
    puVar3[3] = 0;
    puVar3[4] = &LAB_008af4eb;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_MeshId_0213cca0,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213cf4c = RBX::Reflection::TypedPropertyDescriptor<class_RBX::MeshId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213cf80 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213cf70 = _DAT_0213cf70 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213cf4c[2])();
    if (cVar1 != '\0') {
      _DAT_0213cf70 = _DAT_0213cf70 & 0xfffffff3;
    }
  }
  DAT_0213cf4c = RBX::Reflection::PropDescriptor<class_RBX::FileMesh,class_RBX::MeshId>::vftable;
  FUN_016f3654(&LAB_01899df0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1558 ; VA 0x004f3df0 ; FUN_004f3df0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f3df0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01816dbc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d0fc80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::FileMesh,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_const&_(__thiscall_RBX::FileMesh::*)(void)const_,void_(__thiscall_RBX::FileMesh::*)(class_RBX::TextureId_const&)>
              ::vftable;
    puVar3[2] = FUN_0074b630;
    puVar3[3] = 0;
    puVar3[4] = &LAB_00a60d2f;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_TextureId_02132448,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213cf84 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213cfb8 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213cfa8 = _DAT_0213cfa8 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213cf84[2])();
    if (cVar1 != '\0') {
      _DAT_0213cfa8 = _DAT_0213cfa8 & 0xfffffff3;
    }
  }
  DAT_0213cf84 = RBX::Reflection::PropDescriptor<class_RBX::FileMesh,class_RBX::TextureId>::vftable;
  FUN_016f3654(&LAB_01899e10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1559 ; VA 0x004f3fe0 ; FUN_004f3fe0 */

void FUN_004f3fe0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00d11910(0x58,s_ItemAdded_0213d2dc,s_instance_02126630,CONCAT44(&DAT_0213d128,uStack_10),0);
  FUN_016f3654(&LAB_0189a070);
  return;
}



/* FUNCTION 1560 ; VA 0x004f4030 ; FUN_004f4030 */

void FUN_004f4030(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00d11910(0x5c,s_ItemRemoved_0213d2e8,s_instance_02126630,CONCAT44(&DAT_0213d170,uStack_10),0);
  FUN_016f3654(&LAB_0189a080);
  return;
}



/* FUNCTION 1561 ; VA 0x004f4080 ; FUN_004f4080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f4080(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181707e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d11090(uVar2,0);
  FUN_009cb790(uVar1,s_AddTag_0213d27c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213d008 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::CollectionService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_0213d040 = FUN_00d122e0;
  _DAT_0213d044 = 0;
  DAT_0213d048 = 0;
  _DAT_0213d04c = 0;
  uStack_8 = 2;
  FUN_00c9be10();
  FUN_016f3654(&LAB_0189a090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1562 ; VA 0x004f4140 ; FUN_004f4140 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f4140(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined4 uStack_20;
  undefined *puStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018170dc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  puStack_1c = &DAT_0213cfc0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d11090();
  FUN_009cb790(uVar2,s_GetCollection_0212f608,0,CONCAT44(puStack_1c,uStack_20),0);
  _DAT_0213d1b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::CollectionService,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0213d1f0 = FUN_00d130d0;
  _DAT_0213d1f4 = 0;
  DAT_0213d1f8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213d1dc = FUN_0088cc80();
  iVar1 = DAT_0213d1f8;
  if (DAT_0213d1f8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_class_0213d2d4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189a0f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1563 ; VA 0x004f42f0 ; FUN_004f42f0 */

void FUN_004f42f0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00d11790(FUN_00d131c0,0,s_GetInstanceAddedSignal_0213d2a0,&DAT_02125c60,0,uStack_10,0);
  FUN_016f3654(&LAB_0189a110);
  return;
}



/* FUNCTION 1564 ; VA 0x004f4350 ; FUN_004f4350 */

void FUN_004f4350(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00d11790(FUN_00d134a0,0,s_GetInstanceRemovedSignal_0213d2b8,&DAT_02125c60,0,uStack_10,0);
  FUN_016f3654(&LAB_0189a130);
  return;
}



/* FUNCTION 1565 ; VA 0x004f43b0 ; FUN_004f43b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f43b0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181713c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d11090();
  FUN_009cb790(uVar2,s_GetTagged_0213d270,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213cfc0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::CollectionService,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_0213cff8 = FUN_00d13780;
  _DAT_0213cffc = 0;
  DAT_0213d000 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213cfe4 = FUN_0088cc80();
  iVar1 = DAT_0213d000;
  if (DAT_0213d000 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_02125c60);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189a150);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1566 ; VA 0x004f4560 ; FUN_004f4560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f4560(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181719c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d11090();
  FUN_009cb790(uVar1,s_GetTags_0213d290,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213d098 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::CollectionService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_0213d0d0 = FUN_00d13a20;
  _DAT_0213d0d4 = 0;
  DAT_0213d0d8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213d0bc = FUN_008882f0();
  if (DAT_0213d0d8 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_006874f0(DAT_0213d0d8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_instance_02126630);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_0189a170);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1567 ; VA 0x004f46e0 ; FUN_004f46e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f46e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018171ce;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d11090(uVar2,0);
  FUN_009cb790(uVar1,s_HasTag_0213d298,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213d0e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::CollectionService,bool___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_0213d118 = FUN_00d13c80;
  _DAT_0213d11c = 0;
  DAT_0213d120 = 0;
  _DAT_0213d124 = 0;
  uStack_8 = 2;
  FUN_00d12950();
  FUN_016f3654(&LAB_0189a1c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1568 ; VA 0x004f47a0 ; FUN_004f47a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f47a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018171fe;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d11090(uVar2,0);
  FUN_009cb790(uVar1,s_RemoveTag_0213d284,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213d050 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::CollectionService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_0213d088 = FUN_00d14840;
  _DAT_0213d08c = 0;
  DAT_0213d090 = 0;
  _DAT_0213d094 = 0;
  uStack_8 = 2;
  FUN_00c9be10();
  FUN_016f3654(&LAB_0189a220);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1569 ; VA 0x004f4890 ; FUN_004f4890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f4890(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01817a42;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("color_dxt",9);
  uStack_8 = 0;
  _DAT_01d6c9c8 = 0;
  _DAT_01d6c9cc = 0xf;
  DAT_01d6c9b8 = 0;
  FUN_005542c0("norm_dxt",8);
  uStack_8._0_1_ = 1;
  _DAT_01d6c9e0 = 0;
  _DAT_01d6c9e4 = 0xf;
  DAT_01d6c9d0 = 0;
  FUN_005542c0("spec_dxt",8);
  uStack_8._0_1_ = 2;
  _DAT_01d6c9f8 = 0;
  _DAT_01d6c9fc = 0xf;
  DAT_01d6c9e8 = 0;
  FUN_005542c0("color_etc",9);
  uStack_8._0_1_ = 3;
  _DAT_01d6ca10 = 0;
  _DAT_01d6ca14 = 0xf;
  DAT_01d6ca00 = 0;
  FUN_005542c0("norm_etc",8);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  _DAT_01d6ca28 = 0;
  _DAT_01d6ca2c = 0xf;
  DAT_01d6ca18 = 0;
  FUN_005542c0("spec_etc",8);
  FUN_016f3654(&LAB_0189a3b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1570 ; VA 0x004f4a20 ; FUN_004f4a20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f4a20(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01817a64;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d18b20();
  uVar3 = FUN_00d17fd0();
  FUN_009ca670(uVar3,uVar2,s_AlphaMode_0213d494,s_Appearance_02119800,uStack_24,0,0,0x1f,3,3,1);
  uStack_8 = 0;
  DAT_0213d410 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::SurfaceAppearance,enum_RBX::SurfaceAppearance::AlphaMode>
                 ::vftable;
  _DAT_0213d444 = uVar2;
  DAT_0213d448 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213d448 == (undefined4 *)0x0) {
    DAT_0213d448 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213d448 =
         RBX::Reflection::
         PropDescriptor<class_RBX::SurfaceAppearance,enum_RBX::SurfaceAppearance::AlphaMode>::
         GetSetImpl<enum_RBX::SurfaceAppearance::AlphaMode_const_(__thiscall_RBX::SurfaceAppearance::*)(void)const_,void_(__thiscall_RBX::SurfaceAppearance::*)(enum_RBX::SurfaceAppearance::AlphaMode)>
         ::vftable;
    DAT_0213d448[2] = FUN_00762f90;
    DAT_0213d448[3] = 0;
    DAT_0213d448[4] = FUN_00d189a0;
    DAT_0213d448[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213d44c = FUN_00d18b20();
  cVar1 = (*(code *)DAT_0213d410[3])();
  if (cVar1 != '\0') {
    _DAT_0213d434 = _DAT_0213d434 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213d410[2])();
  if (cVar1 != '\0') {
    _DAT_0213d434 = _DAT_0213d434 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189a3f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1571 ; VA 0x004f4c30 ; FUN_004f4c30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f4c30(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01817a96;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00d17fd0();
  uStack_8 = 0;
  uVar4 = FUN_0088d190();
  FUN_009ca670(uVar3,uVar4,s_TexturePack_0213d488,s_Appearance_02119800,uStack_24,0,0,0x1e,6,6,0);
  DAT_0213d40c = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_0213d3d8 = RBX::Reflection::BoundProp<class_RBX::ContentId,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<class_RBX::ContentId,1>::
              BoundPropGetSet<class_RBX::SurfaceAppearance>::vftable;
    puVar5[1] = &DAT_0213d3d8;
    puVar5[2] = 0xb8;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_0213d40c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0213d40c;
    DAT_0213d40c = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_0213d40c;
  }
  DAT_0213d40c = puVar5;
  cVar2 = (*(code *)DAT_0213d3d8[3])();
  if (cVar2 != '\0') {
    _DAT_0213d3fc = _DAT_0213d3fc & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0213d3d8[2])();
  if (cVar2 != '\0') {
    _DAT_0213d3fc = _DAT_0213d3fc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189a470);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1572 ; VA 0x004f5070 ; FUN_004f5070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f5070(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01818344;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d25fb0();
  uVar3 = FUN_00d1e830();
  FUN_009ca670(uVar3,uVar2,s_FieldOfViewMode_0213df20,"Camera",uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213dc10 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Camera,enum_RBX::Camera::FieldOfViewMode>::vftable;
  _DAT_0213dc44 = uVar2;
  DAT_0213dc48 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213dc48 == (undefined4 *)0x0) {
    DAT_0213dc48 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213dc48 =
         RBX::Reflection::PropDescriptor<class_RBX::Camera,enum_RBX::Camera::FieldOfViewMode>::
         GetSetImpl<enum_RBX::Camera::FieldOfViewMode_(__thiscall_RBX::Camera::*)(void)const_,void_(__thiscall_RBX::Camera::*)(enum_RBX::Camera::FieldOfViewMode)>
         ::vftable;
    DAT_0213dc48[2] = FUN_00a9d3e0;
    DAT_0213dc48[3] = 0;
    DAT_0213dc48[4] = FUN_00d25440;
    DAT_0213dc48[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213dc4c = FUN_00d25fb0();
  cVar1 = (*(code *)DAT_0213dc10[3])();
  if (cVar1 != '\0') {
    _DAT_0213dc34 = _DAT_0213dc34 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213dc10[2])();
  if (cVar1 != '\0') {
    _DAT_0213dc34 = _DAT_0213dc34 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189a590);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1573 ; VA 0x004f54c0 ; FUN_004f54c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f54c0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01818370;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x1f);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00d1e830();
  FUN_009ca670(uVar2,&DAT_01edf850,s_CameraSubject_0213dda0,"Camera",uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_0213d760 = RBX::Reflection::RefPropDescriptor<class_RBX::Camera,class_RBX::Instance>::vftable;
  _DAT_0213d794 = RBX::Reflection::RefPropDescriptor<class_RBX::Camera,class_RBX::Instance>::vftable
  ;
  DAT_0213d798 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213d798 == (undefined4 *)0x0) {
    DAT_0213d798 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213d798 =
         RBX::Reflection::PropDescriptor<class_RBX::Camera,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::Camera::*)(void)const_,void_(__thiscall_RBX::Camera::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_0213d798[2] = &LAB_00d21620;
    DAT_0213d798[3] = 0;
    DAT_0213d798[4] = FUN_00d24b00;
    DAT_0213d798[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0213d760[3])();
  if (cVar1 != '\0') {
    _DAT_0213d784 = _DAT_0213d784 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213d760[2])();
  if (cVar1 != '\0') {
    _DAT_0213d784 = _DAT_0213d784 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189a5f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1574 ; VA 0x004f56e0 ; FUN_004f56e0 */

void FUN_004f56e0(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_0213d680,0x14);
  FUN_00d1e650(s_CoordinateFrame_0213dd88,&DAT_021197d4,FUN_00712f10,0,FUN_00d24840,0,*puVar1,
               puVar1[1],puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_0189a630);
  return;
}



/* FUNCTION 1575 ; VA 0x004f57c0 ; FUN_004f57c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f57c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181839c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d1e830();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Camera,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Camera::*)(void)const_,void_(__thiscall_RBX::Camera::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00d21670;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d25470;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_HeadLocked_0213de8c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213da88 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213dabc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213daac = _DAT_0213daac & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213da88[2])();
    if (cVar1 != '\0') {
      _DAT_0213daac = _DAT_0213daac & 0xfffffff3;
    }
  }
  DAT_0213da88 = RBX::Reflection::PropDescriptor<class_RBX::Camera,bool>::vftable;
  FUN_016f3654(&LAB_0189a670);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1576 ; VA 0x004f5a60 ; FUN_004f5a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f5a60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018183c4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d25f00();
  uVar3 = FUN_00d1e830();
  FUN_009ca670(uVar3,uVar2,s_CameraType_0213dcf8,"Camera",uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213d4a0 = RBX::Reflection::EnumPropDescriptor<class_RBX::Camera,enum_RBX::Camera::CameraType>
                 ::vftable;
  _DAT_0213d4d4 = uVar2;
  DAT_0213d4d8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213d4d8 == (undefined4 *)0x0) {
    DAT_0213d4d8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213d4d8 =
         RBX::Reflection::PropDescriptor<class_RBX::Camera,enum_RBX::Camera::CameraType>::
         GetSetImpl<enum_RBX::Camera::CameraType_(__thiscall_RBX::Camera::*)(void)const_,void_(__thiscall_RBX::Camera::*)(enum_RBX::Camera::CameraType)>
         ::vftable;
    DAT_0213d4d8[2] = &LAB_008b2f10;
    DAT_0213d4d8[3] = 0;
    DAT_0213d4d8[4] = FUN_00d24d00;
    DAT_0213d4d8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213d4dc = FUN_00d25f00();
  cVar1 = (*(code *)DAT_0213d4a0[3])();
  if (cVar1 != '\0') {
    _DAT_0213d4c4 = _DAT_0213d4c4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213d4a0[2])();
  if (cVar1 != '\0') {
    _DAT_0213d4c4 = _DAT_0213d4c4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189a6d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1577 ; VA 0x004f5b80 ; FUN_004f5b80 */

void FUN_004f5b80(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_0213d6f0,0x15);
  FUN_00d1e650(s_focus_02121fac,&DAT_021197d4,&LAB_00763950,0,FUN_00d249d0,0,*puVar1,puVar1[1],
               puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_0189a6f0);
  return;
}



/* FUNCTION 1578 ; VA 0x004f5be0 ; FUN_004f5be0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f5be0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018183ec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d1e830();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Camera,class_G3D::Vector2>::
              GetImpl<class_G3D::Vector2_(__thiscall_RBX::Camera::*)(void)const_>::vftable;
    puVar3[2] = FUN_00d22980;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_ViewportSize_0213dd6c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213d610 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213d644 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213d634 = _DAT_0213d634 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213d610[2])();
    if (cVar1 != '\0') {
      _DAT_0213d634 = _DAT_0213d634 & 0xfffffff3;
    }
  }
  DAT_0213d610 = RBX::Reflection::PropDescriptor<class_RBX::Camera,class_G3D::Vector2>::vftable;
  FUN_016f3654(&LAB_0189a710);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1579 ; VA 0x004f5d00 ; FUN_004f5d00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f5d00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830(uVar2,0);
  FUN_009cb970(uVar1,s_InterpolationFinished_0213de50,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213da4c = 0x5c;
  _DAT_0213da18 =
       RBX::Reflection::
       EventDesc<class_RBX::Camera,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Camera::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_0213da40 = 0;
  _DAT_0213da44 = 0;
  _DAT_0213da48 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_0213da18 =
       RBX::Reflection::
       EventDesc<class_RBX::Camera,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Camera::*>
       ::vftable;
  FUN_016f3654(&LAB_0189a730);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1580 ; VA 0x004f5df0 ; FUN_004f5df0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f5df0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01818423;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830();
  FUN_009cb970(uVar1,s_FirstPersonTransition_0213de74,3,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0213da84 = 0x60;
  iStack_8 = 0;
  _DAT_0213da50 =
       RBX::Reflection::
       EventDesc<class_RBX::Camera,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::Camera::*>
       ::vftable;
  FUN_0086e3d0(s_entering_0213de68);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0213da78 = uStack_1c;
  _DAT_0213da7c = uStack_18;
  _DAT_0213da80 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0213da50 =
       RBX::Reflection::
       EventDesc<class_RBX::Camera,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::Camera::*>
       ::vftable;
  FUN_016f3654(&LAB_0189a740);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1581 ; VA 0x004f5f40 ; FUN_004f5f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f5f40(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181847c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_1c = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830();
  FUN_009cb790(uVar1,s_GetLargestCutoffDistance_0213dec0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213db38 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Camera,float___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>),1>
       ::vftable;
  _DAT_0213db70 = &LAB_00d21680;
  _DAT_0213db74 = 0;
  DAT_0213db78 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213db5c = FUN_0088c960();
  if (DAT_0213db78 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_008aa360(DAT_0213db78);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cc80();
  uVar3 = FUN_0086e3d0(s_ignoreList_0213deb4);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_0189a750);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1582 ; VA 0x004f60c0 ; FUN_004f60c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f60c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018184ae;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830(uVar2,0);
  FUN_009cb790(uVar1,s_GetPartsObscuringTarget_0213dee8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213db80 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Camera,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>),2>
       ::vftable;
  _DAT_0213dbb8 = &LAB_00d21b60;
  _DAT_0213dbbc = 0;
  _DAT_0213dbc0 = 0;
  _DAT_0213dbc4 = 0;
  uStack_8 = 2;
  FUN_00d200d0();
  FUN_016f3654(&LAB_0189a7a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1583 ; VA 0x004f6180 ; FUN_004f6180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f6180(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018184ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830(uVar2,0);
  FUN_009cb790(uVar1,s_GetRenderCFrame_0213dea4,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213daf8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Camera,class_G3D::CoordinateFrame___cdecl(void),0>
       ::vftable;
  _DAT_0213db30 = FUN_00d22850;
  _DAT_0213db34 = 0;
  _DAT_0213db1c = FUN_00b00260();
  FUN_016f3654(&LAB_0189a7b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1584 ; VA 0x004f6220 ; FUN_004f6220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f6220(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018184ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830(uVar2,0);
  FUN_009cb790(uVar1,s_GetPanSpeed_0213dddc,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213d868 = RBX::Reflection::BoundFuncDesc<class_RBX::Camera,float___cdecl(void),0>::vftable;
  _DAT_0213d8a0 = &LAB_00d21b50;
  _DAT_0213d8a4 = 0;
  _DAT_0213d88c = FUN_0088c960();
  FUN_016f3654(&LAB_0189a7c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1585 ; VA 0x004f62c0 ; FUN_004f62c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f62c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181850a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830(uVar2,0);
  FUN_009cb790(uVar1,s_GetTiltSpeed_0213ddcc,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213d828 = RBX::Reflection::BoundFuncDesc<class_RBX::Camera,float___cdecl(void),0>::vftable;
  _DAT_0213d860 = &LAB_00d22880;
  _DAT_0213d864 = 0;
  _DAT_0213d84c = FUN_0088c960();
  FUN_016f3654(&LAB_0189a7d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1586 ; VA 0x004f6360 ; FUN_004f6360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f6360(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181852a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830(uVar2,0);
  FUN_009cb790(uVar1,s_GetRoll_0213ddc4,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213d7e8 = RBX::Reflection::BoundFuncDesc<class_RBX::Camera,float___cdecl(void),0>::vftable;
  _DAT_0213d820 = &LAB_00d22870;
  _DAT_0213d824 = 0;
  _DAT_0213d80c = FUN_0088c960();
  FUN_016f3654(&LAB_0189a7e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1587 ; VA 0x004f6400 ; FUN_004f6400 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f6400(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01818568;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830(uVar2,0);
  FUN_009cb790(uVar1,s_Interpolate_0213de44,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213d9c8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Camera,void___cdecl(class_G3D::CoordinateFrame,class_G3D::CoordinateFrame,float),3>
       ::vftable;
  _DAT_0213da00 = FUN_00d1fd60;
  _DAT_0213da04 = 0;
  DAT_0213da08 = 0;
  DAT_0213da0c = 0;
  DAT_0213da10 = 0;
  uStack_8 = 3;
  FUN_00d20680(s_endPos_0213de3c,s_endFocus_0213de30,s_duration_0213de24);
  FUN_016f3654(&LAB_0189a7f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1588 ; VA 0x004f64d0 ; FUN_004f64d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f64d0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018185cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_1c = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830();
  FUN_009cb790(uVar1,s_PanUnits_0213de0c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213d938 = RBX::Reflection::BoundFuncDesc<class_RBX::Camera,void___cdecl(int),1>::vftable;
  _DAT_0213d970 = FUN_00d23920;
  _DAT_0213d974 = 0;
  DAT_0213d978 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213d95c = FUN_00888530();
  puVar3 = DAT_0213d978;
  if (DAT_0213d978 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c8c0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005c9cc0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(s_units_0213de04);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189a840);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1589 ; VA 0x004f6670 ; FUN_004f6670 */

void FUN_004f6670(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00d1f0e0(FUN_00d27370,0,s_ScreenPointToRay_0213dd20,&DAT_0212a0b0,&DAT_0212a0ac,
               s_depth_0213dd04,0,0,uStack_10,0);
  FUN_016f3654(&LAB_0189a860);
  return;
}



/* FUNCTION 1590 ; VA 0x004f66e0 ; FUN_004f66e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f66e0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181862c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830();
  FUN_009cb790(uVar1,s_SetCameraPanMode_0213dde8,0,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_0213d8a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Camera,void___cdecl(enum_RBX::Camera::CameraPanMode),1>::vftable;
  _DAT_0213d8e0 = FUN_0090afd0;
  _DAT_0213d8e4 = 0;
  DAT_0213d8e8 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0213d8e8 == (undefined4 *)0x0) {
    DAT_0213d8e8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213d8e8 = 0;
  }
  uStack_8._0_1_ = 1;
  _DAT_0213d8cc = FUN_00888530();
  puVar3 = DAT_0213d8e8;
  if (DAT_0213d8e8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00d25e50();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00d26060();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_00d25e50();
  uVar2 = FUN_0086e3d0(&DAT_021313b0);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189a8b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1591 ; VA 0x004f68a0 ; FUN_004f68a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f68a0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181868c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830();
  FUN_009cb790(uVar1,s_SetImageServerView_0213df0c,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213dbc8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Camera,void___cdecl(class_G3D::CoordinateFrame),1>
       ::vftable;
  _DAT_0213dc00 = FUN_00d255d0;
  _DAT_0213dc04 = 0;
  DAT_0213dc08 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213dbec = FUN_00888530();
  puVar3 = DAT_0213dc08;
  if (DAT_0213dc08 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00b00260();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    uStack_e0 = puVar3[2];
    uStack_dc = puVar3[3];
    uStack_d8 = puVar3[4];
    uStack_d4 = puVar3[5];
    uStack_d0 = puVar3[6];
    uStack_cc = puVar3[7];
    uStack_c8 = puVar3[8];
    uStack_c4 = puVar3[9];
    uStack_c0 = puVar3[10];
    uStack_bc = puVar3[0xb];
    iStack_ec = FUN_00630d60();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_00b00260();
  uVar2 = FUN_0086e3d0(s_modelCoord_0213df00);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189a8d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1592 ; VA 0x004f6a60 ; FUN_004f6a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f6a60(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018186ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830();
  FUN_009cb790(uVar1,s_SetRoll_0213ddbc,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213d7a0 = RBX::Reflection::BoundFuncDesc<class_RBX::Camera,void___cdecl(float),1>::vftable;
  _DAT_0213d7d8 = FUN_00d25c20;
  _DAT_0213d7dc = 0;
  DAT_0213d7e0 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213d7c4 = FUN_00888530();
  puVar3 = DAT_0213d7e0;
  if (DAT_0213d7e0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c960();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00630820();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(s_rollAngle_0213ddb0);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189a8f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1593 ; VA 0x004f6c10 ; FUN_004f6c10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f6c10(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181874c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_1c = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830();
  FUN_009cb790(uVar1,s_TiltUnits_0213de18,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213d980 = RBX::Reflection::BoundFuncDesc<class_RBX::Camera,bool___cdecl(int),1>::vftable;
  _DAT_0213d9b8 = FUN_00d266f0;
  _DAT_0213d9bc = 0;
  DAT_0213d9c0 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213d9a4 = FUN_0088daf0();
  puVar3 = DAT_0213d9c0;
  if (DAT_0213d9c0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c8c0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005c9cc0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(s_units_0213de04);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189a910);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1594 ; VA 0x004f6db0 ; FUN_004f6db0 */

void FUN_004f6db0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00d1f0e0(FUN_00d273f0,0,s_ViewportPointToRay_0213dd0c,&DAT_0212a0b0,&DAT_0212a0ac,
               s_depth_0213dd04,0,0,uStack_10,0);
  FUN_016f3654(&LAB_0189a930);
  return;
}



/* FUNCTION 1595 ; VA 0x004f6e20 ; FUN_004f6e20 */

void FUN_004f6e20(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00d1ef50(FUN_00d23ee0,0,s_WorldToScreenPoint_0213dd58,s_worldPoint_0213dd34,0,uStack_10,0);
  FUN_016f3654(&LAB_0189a980);
  return;
}



/* FUNCTION 1596 ; VA 0x004f6e80 ; FUN_004f6e80 */

void FUN_004f6e80(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00d1ef50(FUN_00d24230,0,s_WorldToViewportPoint_0213dd40,s_worldPoint_0213dd34,0,uStack_10,0);
  FUN_016f3654(&LAB_0189a9a0);
  return;
}



/* FUNCTION 1597 ; VA 0x004f6ee0 ; FUN_004f6ee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f6ee0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018187ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d1e830();
  FUN_009cb790(uVar1,&DAT_0213ddfc,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213d8f0 = RBX::Reflection::BoundFuncDesc<class_RBX::Camera,bool___cdecl(float),1>::vftable;
  _DAT_0213d928 = FUN_00d27430;
  _DAT_0213d92c = 0;
  DAT_0213d930 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213d914 = FUN_0088daf0();
  puVar3 = DAT_0213d930;
  if (DAT_0213d930 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c960();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00630820();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(s_distance_02138028);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189a9c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1598 ; VA 0x004f7110 ; FUN_004f7110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f7110(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("EnableTextFieldContentType",0x1a);
  _DAT_01f07958 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1599 ; VA 0x004f73e0 ; FUN_004f73e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f73e0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("TextBoundsRoundUp",0x11);
  _DAT_01f07954 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1600 ; VA 0x004f74d0 ; FUN_004f74d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f74d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01818b78;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d27ac0(uVar2,0);
  FUN_009cb820(uVar1,s_FilterStringAsync_0212713c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213dfb8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::TextService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,enum_RBX::ChatService::TextFilterContext),3>
       ::vftable;
  _DAT_0213dff0 = FUN_00d2a2c0;
  _DAT_0213dff4 = 0;
  _DAT_0213dff8 = 0;
  DAT_0213dffc = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  DAT_0213e000 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0213e000 == (undefined4 *)0x0) {
    DAT_0213e000 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213e000 = 2;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00d29590(s_stringToFilter_0212712c,s_fromUserId_0213e160,s_textContext_0213e154);
  FUN_016f3654(&LAB_0189ace0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1601 ; VA 0x004f75c0 ; FUN_004f75c0 */

void FUN_004f75c0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00d28410(FUN_00d2a860,0,s_GetChatForUserAsync_0213e178,s_toUserId_0213e16c,0,uStack_10,0);
  FUN_016f3654(&LAB_0189ad20);
  return;
}



/* FUNCTION 1602 ; VA 0x004f7620 ; FUN_004f7620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f7620(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01818b9a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d279e0(uVar2,0);
  FUN_009cb820(uVar1,s_GetNonChatStringForBroadcastAsyn_0213e1ac,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213e098 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::TextFilterResultInstance,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_0213e0d0 = FUN_00d2abf0;
  _DAT_0213e0d4 = 0;
  _DAT_0213e0bc = FUN_0088cb40();
  FUN_016f3654(&LAB_0189ad40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1603 ; VA 0x004f76c0 ; FUN_004f76c0 */

void FUN_004f76c0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00d28410(FUN_00d2ac90,0,s_GetNonChatStringForUserAsync_0213e18c,s_toUserId_0213e16c,0,
               uStack_10,0);
  FUN_016f3654(&LAB_0189ad50);
  return;
}



/* FUNCTION 1604 ; VA 0x004f7720 ; FUN_004f7720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f7720(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01818be2;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d27ac0(uVar2,0);
  FUN_009cb790(uVar1,s_GetTextSize_0213e148,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213df68 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TextService,class_G3D::Vector2___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,enum_RBX::Text::Font,class_G3D::Vector2),4>
       ::vftable;
  _DAT_0213dfa0 = FUN_00d2ad30;
  _DAT_0213dfa4 = 0;
  _DAT_0213dfa8 = 0;
  DAT_0213dfac = 0;
  DAT_0213dfb0 = 0;
  DAT_0213dfb4 = 0;
  uStack_8 = 4;
  FUN_00d29140(s_string_0213e140,s_fontSize_0213e134,&DAT_0213e12c,s_frameSize_0213e120);
  FUN_016f3654(&LAB_0189ad70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1605 ; VA 0x004f7800 ; FUN_004f7800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f7800(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01818c3c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d27ac0();
  FUN_009cb790(uVar1,s_SetResolutionScale_0213e1d0,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213e0d8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::TextService,void___cdecl(float),1>::vftable;
  _DAT_0213e110 = FUN_00d2d420;
  _DAT_0213e114 = 0;
  DAT_0213e118 = (undefined4 *)0x0;
  uStack_8 = 1;
  _DAT_0213e0fc = FUN_00888530();
  puVar3 = DAT_0213e118;
  if (DAT_0213e118 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c960();
    puStack_ec = (undefined *)0x0;
    auStack_e8[0] = *puVar3;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead278) {
      FUN_016f3809(&DAT_01ead278);
      if (DAT_01ead278 == -1) {
        _DAT_01ead26c = FUN_005c65e0;
        _DAT_01ead270 = FUN_005c65e0;
        DAT_01ead274 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead278);
      }
    }
    puStack_ec = &DAT_01ead26c;
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(s_scale_0212ea20);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189adc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1606 ; VA 0x004f7ad0 ; FUN_004f7ad0 */

void FUN_004f7ad0(void)

{
  FUN_00d39110("style",PTR_s_Part_01d6cf80,0x74b660,0,0xd39c80,0,0,0,0,0xe,0);
  FUN_016f3654(&LAB_0189ae00);
  return;
}



/* FUNCTION 1607 ; VA 0x004f7ba0 ; FUN_004f7ba0 */

void FUN_004f7ba0(void)

{
  FUN_00d39110("Style",PTR_s_Part_01d6cf80,0x74b660,0,0xd39c80,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_0189ae40);
  return;
}



/* FUNCTION 1608 ; VA 0x004f7c40 ; FUN_004f7c40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f7c40(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018193fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d3a1d0();
  FUN_009cb790(uVar1,&DAT_0213e83c,0,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_0213e650 =
       RBX::Reflection::BoundFuncDesc<class_RBX::CustomParticleEmitter,void___cdecl(int),1>::vftable
  ;
  _DAT_0213e688 = FUN_00d3b000;
  _DAT_0213e68c = 0;
  DAT_0213e690 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0213e690 == (undefined4 *)0x0) {
    DAT_0213e690 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213e690 = 0x10;
  }
  uStack_8._0_1_ = 1;
  _DAT_0213e674 = FUN_00888530();
  puVar3 = DAT_0213e690;
  if (DAT_0213e690 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c8c0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005c9cc0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(s_particleCount_0213e82c);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189aec0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1609 ; VA 0x004f7e00 ; FUN_004f7e00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f7e00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181941a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d3a1d0(uVar2,0);
  FUN_009cb790(uVar1,s_Clear_0212a19c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213e698 =
       RBX::Reflection::BoundFuncDesc<class_RBX::CustomParticleEmitter,void___cdecl(void),0>::
       vftable;
  _DAT_0213e6d0 = FUN_00d3b100;
  _DAT_0213e6d4 = 0;
  _DAT_0213e6bc = FUN_00888530();
  FUN_016f3654(&LAB_0189aee0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1610 ; VA 0x004f7ea0 ; FUN_004f7ea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f7ea0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d3a1d0(uVar2,0);
  FUN_009cb970(uVar1,s_OnClearRequested_0213e854,0,CONCAT44(uVar3,uVar2),0);
  DAT_0213e74c = 0x60;
  _DAT_0213e718 =
       RBX::Reflection::
       EventDesc<class_RBX::CustomParticleEmitter,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::CustomParticleEmitter::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_0213e740 = 0;
  _DAT_0213e744 = 0;
  _DAT_0213e748 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_0213e718 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::CustomParticleEmitter,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::CustomParticleEmitter::*>
       ::vftable;
  _DAT_0213e750 = 1;
  _DAT_0213e754 = 0;
  FUN_016f3654(&LAB_0189aef0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1611 ; VA 0x004f7fb0 ; FUN_004f7fb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f7fb0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01819453;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d3a1d0();
  FUN_009cb970(uVar1,s_OnEmitRequested_0213e844,0,CONCAT44(uStack_2c,uStack_30),0);
  DAT_0213e70c = 0x58;
  iStack_8 = 0;
  _DAT_0213e6d8 =
       RBX::Reflection::
       EventDesc<class_RBX::CustomParticleEmitter,void___cdecl(int),class_rbx::remote_signal<void___cdecl(int)>,class_rbx::remote_signal<void___cdecl(int)>_RBX::CustomParticleEmitter::*>
       ::vftable;
  FUN_0086e3d0(s_particleCount_0213e82c);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0213e700 = uStack_1c;
  _DAT_0213e704 = uStack_18;
  _DAT_0213e708 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_0213e6d8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::CustomParticleEmitter,void___cdecl(int),class_rbx::remote_signal<void___cdecl(int)>,class_rbx::remote_signal<void___cdecl(int)>_RBX::CustomParticleEmitter::*>
       ::vftable;
  _DAT_0213e710 = 1;
  _DAT_0213e714 = 0;
  FUN_016f3654(&LAB_0189af00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1612 ; VA 0x004f8110 ; FUN_004f8110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f8110(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181947c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3a1d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::CustomParticleEmitter,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_const&_(__thiscall_RBX::CustomParticleEmitter::*)(void)const_,void_(__thiscall_RBX::CustomParticleEmitter::*)(class_G3D::Vector3_const&)>
              ::vftable;
    puVar3[2] = FUN_0084a870;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3b190;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_Acceleration_0213e7c8,s_Motion_0213e7c0,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213e4f8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213e52c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213e51c = _DAT_0213e51c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213e4f8[2])();
    if (cVar1 != '\0') {
      _DAT_0213e51c = _DAT_0213e51c & 0xfffffff3;
    }
  }
  DAT_0213e4f8 = RBX::Reflection::
                 PropDescriptor<class_RBX::CustomParticleEmitter,class_G3D::Vector3>::vftable;
  FUN_016f3654(&LAB_0189af10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1613 ; VA 0x004f8240 ; FUN_004f8240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f8240(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018194ac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3a1d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::CustomParticleEmitter,class_RBX::ColorSequence>::
              GetSetImpl<class_RBX::ColorSequence_const&_(__thiscall_RBX::CustomParticleEmitter::*)(void)const_,void_(__thiscall_RBX::CustomParticleEmitter::*)(class_RBX::ColorSequence_const&)>
              ::vftable;
    puVar3[2] = FUN_0074b630;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3b200;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00a8dcc0();
  FUN_009ca670(uVar2,uVar4,s_Color_0213abec,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213e220 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ColorSequence>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213e254 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213e244 = _DAT_0213e244 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213e220[2])();
    if (cVar1 != '\0') {
      _DAT_0213e244 = _DAT_0213e244 & 0xfffffff3;
    }
  }
  DAT_0213e220 = RBX::Reflection::
                 PropDescriptor<class_RBX::CustomParticleEmitter,class_RBX::ColorSequence>::vftable;
  FUN_016f3654(&LAB_0189af30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1614 ; VA 0x004f83f0 ; FUN_004f83f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f83f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018194d4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00890320();
  uVar3 = FUN_00d3a1d0();
  FUN_009ca670(uVar3,uVar2,s_EmissionDirection_0213e818,s_Emission_0213e758,uStack_24,0,0,0x1f,0,0,1
              );
  uStack_8 = 0;
  DAT_0213e610 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::CustomParticleEmitter,enum_RBX::NormalId>::vftable;
  _DAT_0213e644 = uVar2;
  DAT_0213e648 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213e648 == (undefined4 *)0x0) {
    DAT_0213e648 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213e648 =
         RBX::Reflection::PropDescriptor<class_RBX::CustomParticleEmitter,enum_RBX::NormalId>::
         GetSetImpl<enum_RBX::NormalId_(__thiscall_RBX::CustomParticleEmitter::*)(void)const_,void_(__thiscall_RBX::CustomParticleEmitter::*)(enum_RBX::NormalId)>
         ::vftable;
    DAT_0213e648[2] = &LAB_0074b660;
    DAT_0213e648[3] = 0;
    DAT_0213e648[4] = FUN_00d3b280;
    DAT_0213e648[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213e64c = FUN_00890320();
  cVar1 = (*(code *)DAT_0213e610[3])();
  if (cVar1 != '\0') {
    _DAT_0213e634 = _DAT_0213e634 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213e610[2])();
  if (cVar1 != '\0') {
    _DAT_0213e634 = _DAT_0213e634 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189af70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1615 ; VA 0x004f8a10 ; FUN_004f8a10 */

void FUN_004f8a10(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_0213e3e0,0x15);
  FUN_00d39fd0(s_VelocitySpread_0213e798,s_Emission_0213e758,FUN_00832150,0,FUN_00d3b560,0,*puVar1,
               puVar1[1],puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_0189b0d0);
  return;
}



/* FUNCTION 1616 ; VA 0x004f8a70 ; FUN_004f8a70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f8a70(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018194fc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3a1d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::CustomParticleEmitter,class_G3D::Vector2>::
              GetSetImpl<class_G3D::Vector2_(__thiscall_RBX::CustomParticleEmitter::*)(void)const_,void_(__thiscall_RBX::CustomParticleEmitter::*)(class_G3D::Vector2_const&)>
              ::vftable;
    puVar3[2] = FUN_00858ca0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3b5a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_SpreadAngle_0213e78c,s_Emission_0213e758,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213e3e0 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213e414 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213e404 = _DAT_0213e404 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213e3e0[2])();
    if (cVar1 != '\0') {
      _DAT_0213e404 = _DAT_0213e404 & 0xfffffff3;
    }
  }
  DAT_0213e3e0 = RBX::Reflection::
                 PropDescriptor<class_RBX::CustomParticleEmitter,class_G3D::Vector2>::vftable;
  FUN_016f3654(&LAB_0189b0f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1617 ; VA 0x004f8ba0 ; FUN_004f8ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f8ba0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181952c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3a1d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::CustomParticleEmitter,class_RBX::TextureId>
              ::
              GetSetImpl<class_RBX::TextureId_const&_(__thiscall_RBX::CustomParticleEmitter::*)(void)const_,void_(__thiscall_RBX::CustomParticleEmitter::*)(class_RBX::TextureId_const&)>
              ::vftable;
    puVar3[2] = FUN_00d01ad0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3b5f0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_Texture_0213cec0,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213e1e8 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213e21c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213e20c = _DAT_0213e20c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213e1e8[2])();
    if (cVar1 != '\0') {
      _DAT_0213e20c = _DAT_0213e20c & 0xfffffff3;
    }
  }
  DAT_0213e1e8 = RBX::Reflection::
                 PropDescriptor<class_RBX::CustomParticleEmitter,class_RBX::TextureId>::vftable;
  FUN_016f3654(&LAB_0189b110);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1618 ; VA 0x004f8e60 ; FUN_004f8e60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f8e60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181961c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3bb40();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Beam,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_const&_(__thiscall_RBX::Beam::*)(void)const_,void_(__thiscall_RBX::Beam::*)(class_RBX::TextureId_const&)>
              ::vftable;
    puVar3[2] = FUN_00d3acc0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3c660;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_Texture_0213cec0,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213e868 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213e89c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213e88c = _DAT_0213e88c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213e868[2])();
    if (cVar1 != '\0') {
      _DAT_0213e88c = _DAT_0213e88c & 0xfffffff3;
    }
  }
  DAT_0213e868 = RBX::Reflection::PropDescriptor<class_RBX::Beam,class_RBX::TextureId>::vftable;
  FUN_016f3654(&LAB_0189b1f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1619 ; VA 0x004f8f90 ; FUN_004f8f90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f8f90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181964c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3bb40();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Beam,class_RBX::NumberSequence>::
              GetSetImpl<class_RBX::NumberSequence_const&_(__thiscall_RBX::Beam::*)(void)const_,void_(__thiscall_RBX::Beam::*)(class_RBX::NumberSequence_const&)>
              ::vftable;
    puVar3[2] = FUN_00d3c220;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3c7b0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00a92ae0();
  FUN_009ca670(uVar2,uVar4,s_Transparency_021392fc,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213eb18 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::NumberSequence>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213eb4c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213eb3c = _DAT_0213eb3c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213eb18[2])();
    if (cVar1 != '\0') {
      _DAT_0213eb3c = _DAT_0213eb3c & 0xfffffff3;
    }
  }
  DAT_0213eb18 = RBX::Reflection::PropDescriptor<class_RBX::Beam,class_RBX::NumberSequence>::vftable
  ;
  FUN_016f3654(&LAB_0189b210);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1620 ; VA 0x004f90d0 ; FUN_004f90d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f90d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01819674;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3c960();
  uVar3 = FUN_00d3bb40();
  FUN_009ca670(uVar3,uVar2,s_TextureMode_0213ecb0,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213e8a0 = RBX::Reflection::EnumPropDescriptor<class_RBX::Beam,enum_RBX::TextureMode>::vftable
  ;
  _DAT_0213e8d4 = uVar2;
  DAT_0213e8d8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213e8d8 == (undefined4 *)0x0) {
    DAT_0213e8d8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213e8d8 =
         RBX::Reflection::PropDescriptor<class_RBX::Beam,enum_RBX::TextureMode>::
         GetSetImpl<enum_RBX::TextureMode_(__thiscall_RBX::Beam::*)(void)const_,void_(__thiscall_RBX::Beam::*)(enum_RBX::TextureMode)>
         ::vftable;
    DAT_0213e8d8[2] = &LAB_0074b4e0;
    DAT_0213e8d8[3] = 0;
    DAT_0213e8d8[4] = FUN_00d3c6f0;
    DAT_0213e8d8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213e8dc = FUN_00d3c960();
  cVar1 = (*(code *)DAT_0213e8a0[3])();
  if (cVar1 != '\0') {
    _DAT_0213e8c4 = _DAT_0213e8c4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213e8a0[2])();
  if (cVar1 != '\0') {
    _DAT_0213e8c4 = _DAT_0213e8c4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189b230);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1621 ; VA 0x004f91f0 ; FUN_004f91f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f91f0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018196cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d3bb40();
  FUN_009cb790(uVar1,s_SetTextureOffset_0213ed2c,0,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_0213ec68 = RBX::Reflection::BoundFuncDesc<class_RBX::Beam,void___cdecl(float),1>::vftable;
  _DAT_0213eca0 = FUN_00d3c720;
  _DAT_0213eca4 = 0;
  DAT_0213eca8 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0213eca8 == (undefined4 *)0x0) {
    DAT_0213eca8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213eca8 = 0;
  }
  uStack_8._0_1_ = 1;
  _DAT_0213ec8c = FUN_00888530();
  puVar3 = DAT_0213eca8;
  if (DAT_0213eca8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c960();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00630820();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(s_offset_0213ed24);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189b250);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1622 ; VA 0x004f93b0 ; FUN_004f93b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f93b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018196fc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3bb40();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Beam,class_RBX::ColorSequence>::
              GetSetImpl<class_RBX::ColorSequence_const&_(__thiscall_RBX::Beam::*)(void)const_,void_(__thiscall_RBX::Beam::*)(class_RBX::ColorSequence_const&)>
              ::vftable;
    puVar3[2] = FUN_00712f10;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3c470;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00a8dcc0();
  FUN_009ca670(uVar2,uVar4,s_Color_0213abec,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213eae0 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ColorSequence>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213eb14 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213eb04 = _DAT_0213eb04 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213eae0[2])();
    if (cVar1 != '\0') {
      _DAT_0213eb04 = _DAT_0213eb04 & 0xfffffff3;
    }
  }
  DAT_0213eae0 = RBX::Reflection::PropDescriptor<class_RBX::Beam,class_RBX::ColorSequence>::vftable;
  FUN_016f3654(&LAB_0189b290);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1623 ; VA 0x004f9960 ; FUN_004f9960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f9960(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181972c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3bb40();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Beam,int>::
              GetSetImpl<int_(__thiscall_RBX::Beam::*)(void)const_,void_(__thiscall_RBX::Beam::*)(int)>
              ::vftable;
    puVar3[2] = FUN_00855cc0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3c620;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_Segments_0213ecec,s_Shape_0213ecbc,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213ea38 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213ea6c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213ea5c = _DAT_0213ea5c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213ea38[2])();
    if (cVar1 != '\0') {
      _DAT_0213ea5c = _DAT_0213ea5c & 0xfffffff3;
    }
  }
  DAT_0213ea38 = RBX::Reflection::PropDescriptor<class_RBX::Beam,int>::vftable;
  FUN_016f3654(&LAB_0189b3d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1624 ; VA 0x004f9c90 ; FUN_004f9c90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f9c90(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181984a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d3cec0(uVar2,0);
  FUN_009cb790(uVar1,s_Clear_0212a19c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213f098 = RBX::Reflection::BoundFuncDesc<class_RBX::Trail,void___cdecl(void),0>::vftable;
  _DAT_0213f0d0 = FUN_00d3d630;
  _DAT_0213f0d4 = 0;
  _DAT_0213f0bc = FUN_00888530();
  FUN_016f3654(&LAB_0189b4d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1625 ; VA 0x004f9d30 ; FUN_004f9d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f9d30(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01819874;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3c960();
  uVar3 = FUN_00d3cec0();
  FUN_009ca670(uVar3,uVar2,s_TextureMode_0213ecb0,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213ed40 = RBX::Reflection::EnumPropDescriptor<class_RBX::Trail,enum_RBX::TextureMode>::
                 vftable;
  _DAT_0213ed74 = uVar2;
  DAT_0213ed78 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213ed78 == (undefined4 *)0x0) {
    DAT_0213ed78 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213ed78 =
         RBX::Reflection::PropDescriptor<class_RBX::Trail,enum_RBX::TextureMode>::
         GetSetImpl<enum_RBX::TextureMode_(__thiscall_RBX::Trail::*)(void)const_,void_(__thiscall_RBX::Trail::*)(enum_RBX::TextureMode)>
         ::vftable;
    DAT_0213ed78[2] = FUN_00762f90;
    DAT_0213ed78[3] = 0;
    DAT_0213ed78[4] = FUN_00d3dab0;
    DAT_0213ed78[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213ed7c = FUN_00d3c960();
  cVar1 = (*(code *)DAT_0213ed40[3])();
  if (cVar1 != '\0') {
    _DAT_0213ed64 = _DAT_0213ed64 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213ed40[2])();
  if (cVar1 != '\0') {
    _DAT_0213ed64 = _DAT_0213ed64 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189b4e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1626 ; VA 0x004f9e50 ; FUN_004f9e50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f9e50(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d3cec0(uVar2,0);
  FUN_009cb970(uVar1,s_OnClearRequested_0213e854,0,CONCAT44(uVar3,uVar2),0);
  DAT_0213f10c = 0x58;
  _DAT_0213f0d8 =
       RBX::Reflection::
       EventDesc<class_RBX::Trail,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Trail::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_0213f100 = 0;
  _DAT_0213f104 = 0;
  _DAT_0213f108 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_0213f0d8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Trail,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Trail::*>
       ::vftable;
  _DAT_0213f110 = 1;
  _DAT_0213f114 = 0;
  FUN_016f3654(&LAB_0189b500);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1627 ; VA 0x004fa060 ; FUN_004fa060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fa060(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181989c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3cec0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Trail,class_RBX::ColorSequence>::
              GetSetImpl<class_RBX::ColorSequence_const&_(__thiscall_RBX::Trail::*)(void)const_,void_(__thiscall_RBX::Trail::*)(class_RBX::ColorSequence_const&)>
              ::vftable;
    puVar3[2] = FUN_00d3c220;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3d820;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00a8dcc0();
  FUN_009ca670(uVar2,uVar4,s_Color_0213abec,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213ee68 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ColorSequence>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213ee9c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213ee8c = _DAT_0213ee8c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213ee68[2])();
    if (cVar1 != '\0') {
      _DAT_0213ee8c = _DAT_0213ee8c & 0xfffffff3;
    }
  }
  DAT_0213ee68 = RBX::Reflection::PropDescriptor<class_RBX::Trail,class_RBX::ColorSequence>::vftable
  ;
  FUN_016f3654(&LAB_0189b550);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1628 ; VA 0x004fa410 ; FUN_004fa410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fa410(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018198cc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3cec0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Trail,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_const&_(__thiscall_RBX::Trail::*)(void)const_,void_(__thiscall_RBX::Trail::*)(class_RBX::TextureId_const&)>
              ::vftable;
    puVar3[2] = FUN_0074ae10;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3da20;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_Texture_0213cec0,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213ef48 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213ef7c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213ef6c = _DAT_0213ef6c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213ef48[2])();
    if (cVar1 != '\0') {
      _DAT_0213ef6c = _DAT_0213ef6c & 0xfffffff3;
    }
  }
  DAT_0213ef48 = RBX::Reflection::PropDescriptor<class_RBX::Trail,class_RBX::TextureId>::vftable;
  FUN_016f3654(&LAB_0189b610);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1629 ; VA 0x004fa7f0 ; FUN_004fa7f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fa7f0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01819a1a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00d3dc90();
  FUN_006846c0(uVar3,s_BlastPressure_0213f328,&DAT_021197d4,0);
  uStack_8 = 0;
  DAT_0213f1e0 = RBX::Reflection::BoundProp<float,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::Explosion>::vftable;
    puVar4[1] = &DAT_0213f1e0;
    puVar4[2] = 0x90;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_0213f214 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0213f214;
    DAT_0213f214 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_0213f214;
  }
  DAT_0213f214 = puVar4;
  cVar2 = (*(code *)DAT_0213f1e0[3])();
  if (cVar2 != '\0') {
    _DAT_0213f204 = _DAT_0213f204 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0213f1e0[2])();
  if (cVar2 != '\0') {
    _DAT_0213f204 = _DAT_0213f204 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1630 ; VA 0x004fa910 ; FUN_004fa910 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fa910(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01819a56;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00d3dc90();
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar3,uVar4,s_Position_0212a74c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213f24c = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_0213f218 = RBX::Reflection::BoundProp<class_G3D::Vector3,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<class_G3D::Vector3,1>::
              BoundPropGetSet<class_RBX::Explosion>::vftable;
    puVar5[1] = &DAT_0213f218;
    puVar5[2] = 0x80;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_0213f24c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0213f24c;
    DAT_0213f24c = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_0213f24c;
  }
  DAT_0213f24c = puVar5;
  cVar2 = (*(code *)DAT_0213f218[3])();
  if (cVar2 != '\0') {
    _DAT_0213f23c = _DAT_0213f23c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0213f218[2])();
  if (cVar2 != '\0') {
    _DAT_0213f23c = _DAT_0213f23c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189b750);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1631 ; VA 0x004faa40 ; FUN_004faa40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004faa40(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01819a86;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00d3dc90();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_Visible_021392e8,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213f284 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_0213f250 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::Explosion>::vftable;
    puVar5[1] = &DAT_0213f250;
    puVar5[2] = 0x98;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_0213f284 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0213f284;
    DAT_0213f284 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_0213f284;
  }
  DAT_0213f284 = puVar5;
  cVar2 = (*(code *)DAT_0213f250[3])();
  if (cVar2 != '\0') {
    _DAT_0213f274 = _DAT_0213f274 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0213f250[2])();
  if (cVar2 != '\0') {
    _DAT_0213f274 = _DAT_0213f274 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189b770);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1632 ; VA 0x004faba0 ; FUN_004faba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004faba0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01819abe;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d3dc90();
  FUN_009cb970(uVar1,&DAT_0213f348,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0213f2fc = 0xa0;
  iStack_8 = 0;
  _DAT_0213f2c8 =
       RBX::Reflection::
       EventDesc<class_RBX::Explosion,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,float),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,float)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,float)>_RBX::Explosion::*>
       ::vftable;
  FUN_0086e3d0(&DAT_02123e0c);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_distance_02138028);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0213f2f0 = uStack_1c;
  _DAT_0213f2f4 = uStack_18;
  _DAT_0213f2f8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0213f2c8 =
       RBX::Reflection::
       EventDesc<class_RBX::Explosion,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,float),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,float)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,float)>_RBX::Explosion::*>
       ::vftable;
  FUN_016f3654(&LAB_0189b790);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1633 ; VA 0x004fae90 ; FUN_004fae90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fae90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01819ae4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3f7c0();
  uVar3 = FUN_00d3dc90();
  FUN_009ca670(uVar3,uVar2,s_ExplosionType_0213f338,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213f288 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Explosion,enum_RBX::Explosion::ExplosionType>::
                 vftable;
  _DAT_0213f2bc = uVar2;
  DAT_0213f2c0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213f2c0 == (undefined4 *)0x0) {
    DAT_0213f2c0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213f2c0 =
         RBX::Reflection::PropDescriptor<class_RBX::Explosion,enum_RBX::Explosion::ExplosionType>::
         GetSetImpl<enum_RBX::Explosion::ExplosionType_(__thiscall_RBX::Explosion::*)(void)const_,void_(__thiscall_RBX::Explosion::*)(enum_RBX::Explosion::ExplosionType)>
         ::vftable;
    DAT_0213f2c0[2] = FUN_00b5ece0;
    DAT_0213f2c0[3] = 0;
    DAT_0213f2c0[4] = FUN_00d3f740;
    DAT_0213f2c0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213f2c4 = FUN_00d3f7c0();
  cVar1 = (*(code *)DAT_0213f288[3])();
  if (cVar1 != '\0') {
    _DAT_0213f2ac = _DAT_0213f2ac & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213f288[2])();
  if (cVar1 != '\0') {
    _DAT_0213f2ac = _DAT_0213f2ac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189b800);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1634 ; VA 0x004fafc0 ; FUN_004fafc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fafc0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01819c5c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d3f900();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ForceField,bool>::
              GetSetImpl<bool_(__thiscall_RBX::ForceField::*)(void)const_,void_(__thiscall_RBX::ForceField::*)(bool)>
              ::vftable;
    puVar3[2] = FUN_007cfe50;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d3fe90;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_Visible_021392e8,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213f34c = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213f380 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213f370 = _DAT_0213f370 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213f34c[2])();
    if (cVar1 != '\0') {
      _DAT_0213f370 = _DAT_0213f370 & 0xfffffff3;
    }
  }
  DAT_0213f34c = RBX::Reflection::PropDescriptor<class_RBX::ForceField,bool>::vftable;
  FUN_016f3654(&LAB_0189b880);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1635 ; VA 0x004fb170 ; FUN_004fb170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fb170(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01819d3c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d400b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ViewportFrame,class_G3D::CoordinateFrame>::
              GetSetImpl<class_G3D::CoordinateFrame_const&_(__thiscall_RBX::ViewportFrame::*)(void)const_,void_(__thiscall_RBX::ViewportFrame::*)(class_G3D::CoordinateFrame_const&)>
              ::vftable;
    puVar3[2] = &LAB_008191c0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d40be0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,s_CameraCFrame_0213f548,&DAT_021197d4,uStack_24,0,0,0xe,0,0,0);
  DAT_0213f3c0 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213f3f4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213f3e4 = _DAT_0213f3e4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213f3c0[2])();
    if (cVar1 != '\0') {
      _DAT_0213f3e4 = _DAT_0213f3e4 & 0xfffffff3;
    }
  }
  DAT_0213f3c0 = RBX::Reflection::
                 PropDescriptor<class_RBX::ViewportFrame,class_G3D::CoordinateFrame>::vftable;
  FUN_016f3654(&LAB_0189b920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1636 ; VA 0x004fb2f0 ; FUN_004fb2f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fb2f0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01819d70;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0084) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0084,uVar3,0,0,0x15);
    if (DAT_01ee0084 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee0060 = RBX::Reflection::RefType<class_RBX::Camera*>::vftable;
      FUN_016f3654(&LAB_01881960);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee0084);
    }
  }
  uVar2 = FUN_00d400b0();
  FUN_009ca670(uVar2,&DAT_01ee0060,s_CurrentCamera_0211ba48,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,
               0,0);
  uStack_8 = 1;
  DAT_0213f384 = RBX::Reflection::RefPropDescriptor<class_RBX::ViewportFrame,class_RBX::Camera>::
                 vftable;
  _DAT_0213f3b8 =
       RBX::Reflection::RefPropDescriptor<class_RBX::ViewportFrame,class_RBX::Camera>::vftable;
  DAT_0213f3bc = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213f3bc == (undefined4 *)0x0) {
    DAT_0213f3bc = (undefined4 *)0x0;
  }
  else {
    *DAT_0213f3bc =
         RBX::Reflection::PropDescriptor<class_RBX::ViewportFrame,class_RBX::Camera*>::
         GetSetImpl<class_RBX::Camera*_(__thiscall_RBX::ViewportFrame::*)(void)const_,void_(__thiscall_RBX::ViewportFrame::*)(class_RBX::Camera*)>
         ::vftable;
    DAT_0213f3bc[2] = FUN_00d40720;
    DAT_0213f3bc[3] = 0;
    DAT_0213f3bc[4] = FUN_00d40c90;
    DAT_0213f3bc[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0213f384[3])();
  if (cVar1 != '\0') {
    _DAT_0213f3a8 = _DAT_0213f3a8 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213f384[2])();
  if (cVar1 != '\0') {
    _DAT_0213f3a8 = _DAT_0213f3a8 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189b960);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1637 ; VA 0x004fb610 ; FUN_004fb610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fb610(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01819d9c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d400b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ViewportFrame,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_(__thiscall_RBX::ViewportFrame::*)(void)const_,void_(__thiscall_RBX::ViewportFrame::*)(class_G3D::Vector3_const&)>
              ::vftable;
    puVar3[2] = FUN_00819200;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d41020;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_LightDirection_0213f598,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0)
  ;
  DAT_0213f510 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213f544 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213f534 = _DAT_0213f534 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213f510[2])();
    if (cVar1 != '\0') {
      _DAT_0213f534 = _DAT_0213f534 & 0xfffffff3;
    }
  }
  DAT_0213f510 = RBX::Reflection::PropDescriptor<class_RBX::ViewportFrame,class_G3D::Vector3>::
                 vftable;
  FUN_016f3654(&LAB_0189b9e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1638 ; VA 0x004fb9b0 ; FUN_004fb9b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fb9b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181a00c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d41250();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Light,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::Light::*)(void)const_,void_(__thiscall_RBX::Light::*)(class_G3D::Color3)>
              ::vftable;
    puVar3[2] = FUN_008389c0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d42210;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,&DAT_0194ebd8,"Appearance",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f08f18 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f08f4c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f08f3c = _DAT_01f08f3c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f08f18[2])();
    if (cVar1 != '\0') {
      _DAT_01f08f3c = _DAT_01f08f3c & 0xfffffff3;
    }
  }
  DAT_01f08f18 = RBX::Reflection::PropDescriptor<class_RBX::Light,class_G3D::Color3>::vftable;
  FUN_016f3654(&LAB_0189bac0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1639 ; VA 0x004fbb60 ; FUN_004fbb60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fbb60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181a034;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00890320();
  uVar3 = FUN_00d41430();
  FUN_009ca670(uVar3,uVar2,&DAT_01981ccc,"Appearance",uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f09068 = RBX::Reflection::EnumPropDescriptor<class_RBX::SpotLight,enum_RBX::NormalId>::
                 vftable;
  _DAT_01f0909c = uVar2;
  DAT_01f090a0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f090a0 == (undefined4 *)0x0) {
    DAT_01f090a0 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f090a0 =
         RBX::Reflection::PropDescriptor<class_RBX::SpotLight,enum_RBX::NormalId>::
         GetSetImpl<enum_RBX::NormalId_(__thiscall_RBX::SpotLight::*)(void)const_,void_(__thiscall_RBX::SpotLight::*)(enum_RBX::NormalId)>
         ::vftable;
    DAT_01f090a0[2] = FUN_008389e0;
    DAT_01f090a0[3] = 0;
    DAT_01f090a0[4] = FUN_00d42290;
    DAT_01f090a0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f090a4 = FUN_00890320();
  cVar1 = (*(code *)DAT_01f09068[3])();
  if (cVar1 != '\0') {
    _DAT_01f0908c = _DAT_01f0908c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f09068[2])();
  if (cVar1 != '\0') {
    _DAT_01f0908c = _DAT_01f0908c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189bb00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1640 ; VA 0x004fbc80 ; FUN_004fbc80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fbc80(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181a054;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00890320();
  uVar3 = FUN_00d41530();
  FUN_009ca670(uVar3,uVar2,&DAT_01981ccc,"Appearance",uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f09118 = RBX::Reflection::EnumPropDescriptor<class_RBX::SurfaceLight,enum_RBX::NormalId>::
                 vftable;
  _DAT_01f0914c = uVar2;
  DAT_01f09150 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f09150 == (undefined4 *)0x0) {
    DAT_01f09150 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f09150 =
         RBX::Reflection::PropDescriptor<class_RBX::SurfaceLight,enum_RBX::NormalId>::
         GetSetImpl<enum_RBX::NormalId_(__thiscall_RBX::SurfaceLight::*)(void)const_,void_(__thiscall_RBX::SurfaceLight::*)(enum_RBX::NormalId)>
         ::vftable;
    DAT_01f09150[2] = FUN_008389e0;
    DAT_01f09150[3] = 0;
    DAT_01f09150[4] = FUN_00d422b0;
    DAT_01f09150[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f09154 = FUN_00890320();
  cVar1 = (*(code *)DAT_01f09118[3])();
  if (cVar1 != '\0') {
    _DAT_01f0913c = _DAT_01f0913c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f09118[2])();
  if (cVar1 != '\0') {
    _DAT_01f0913c = _DAT_01f0913c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189bb20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1641 ; VA 0x004fc620 ; FUN_004fc620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fc620(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181aa6c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d4e2b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::HandleAdornment,class_G3D::CoordinateFrame>
              ::
              GetSetImpl<class_G3D::CoordinateFrame_(__thiscall_RBX::HandleAdornment::*)(void)const_,void_(__thiscall_RBX::HandleAdornment::*)(class_G3D::CoordinateFrame)>
              ::vftable;
    puVar3[2] = FUN_00d506b0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d54890;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,s_CFrame_0212a744,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213f5e0 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213f614 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213f604 = _DAT_0213f604 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213f5e0[2])();
    if (cVar1 != '\0') {
      _DAT_0213f604 = _DAT_0213f604 & 0xfffffff3;
    }
  }
  DAT_0213f5e0 = RBX::Reflection::
                 PropDescriptor<class_RBX::HandleAdornment,class_G3D::CoordinateFrame>::vftable;
  FUN_016f3654(&LAB_0189bd50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1642 ; VA 0x004fc750 ; FUN_004fc750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fc750(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181aa9c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d4e2b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::HandleAdornment,int>::
              GetSetImpl<int_(__thiscall_RBX::HandleAdornment::*)(void)const_,void_(__thiscall_RBX::HandleAdornment::*)(int)>
              ::vftable;
    puVar3[2] = &LAB_00a3d6e8;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d54cd0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_ZIndex_02139224,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213f618 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213f64c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213f63c = _DAT_0213f63c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213f618[2])();
    if (cVar1 != '\0') {
      _DAT_0213f63c = _DAT_0213f63c & 0xfffffff3;
    }
  }
  DAT_0213f618 = RBX::Reflection::PropDescriptor<class_RBX::HandleAdornment,int>::vftable;
  FUN_016f3654(&LAB_0189bd70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1643 ; VA 0x004fc880 ; FUN_004fc880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fc880(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181aacc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d4e2b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::HandleAdornment,bool>::
              GetSetImpl<bool_(__thiscall_RBX::HandleAdornment::*)(void)const_,void_(__thiscall_RBX::HandleAdornment::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_009f5e80;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d54800;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_AlwaysOnTop_0213f7dc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213f650 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213f684 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213f674 = _DAT_0213f674 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213f650[2])();
    if (cVar1 != '\0') {
      _DAT_0213f674 = _DAT_0213f674 & 0xfffffff3;
    }
  }
  DAT_0213f650 = RBX::Reflection::PropDescriptor<class_RBX::HandleAdornment,bool>::vftable;
  FUN_016f3654(&LAB_0189bd90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1644 ; VA 0x004fcbf0 ; FUN_004fcbf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fcbf0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181aaf4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d54d00();
  uVar3 = FUN_00d4e2b0();
  FUN_009ca670(uVar3,uVar2,s_AdornCullingMode_0213f7e8,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213f688 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::HandleAdornment,enum_RBX::AdornCullingMode>::vftable;
  _DAT_0213f6bc = uVar2;
  DAT_0213f6c0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213f6c0 == (undefined4 *)0x0) {
    DAT_0213f6c0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213f6c0 =
         RBX::Reflection::PropDescriptor<class_RBX::HandleAdornment,enum_RBX::AdornCullingMode>::
         GetSetImpl<enum_RBX::AdornCullingMode_(__thiscall_RBX::HandleAdornment::*)(void)const_,void_(__thiscall_RBX::HandleAdornment::*)(enum_RBX::AdornCullingMode)>
         ::vftable;
    DAT_0213f6c0[2] = &LAB_00d507c0;
    DAT_0213f6c0[3] = 0;
    DAT_0213f6c0[4] = FUN_00d54910;
    DAT_0213f6c0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213f6c4 = FUN_00d54d00();
  cVar1 = (*(code *)DAT_0213f688[3])();
  if (cVar1 != '\0') {
    _DAT_0213f6ac = _DAT_0213f6ac & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213f688[2])();
  if (cVar1 != '\0') {
    _DAT_0213f6ac = _DAT_0213f6ac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189be10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1645 ; VA 0x004fd010 ; FUN_004fd010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fd010(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181ab1c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d4e390();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ImageHandleAdornment,class_RBX::TextureId>
              ::
              GetSetImpl<class_RBX::TextureId_(__thiscall_RBX::ImageHandleAdornment::*)(void)const_,void_(__thiscall_RBX::ImageHandleAdornment::*)(class_RBX::TextureId)>
              ::vftable;
    puVar3[2] = FUN_00d507d0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d549a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,"Image",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,0);
  DAT_01f09e08 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f09e3c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f09e2c = _DAT_01f09e2c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f09e08[2])();
    if (cVar1 != '\0') {
      _DAT_01f09e2c = _DAT_01f09e2c & 0xfffffff3;
    }
  }
  DAT_01f09e08 = RBX::Reflection::
                 PropDescriptor<class_RBX::ImageHandleAdornment,class_RBX::TextureId>::vftable;
  FUN_016f3654(&LAB_0189beb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1646 ; VA 0x004fd140 ; FUN_004fd140 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fd140(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181ab4c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d4e390();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ImageHandleAdornment,class_G3D::Vector2>::
              GetSetImpl<class_G3D::Vector2_(__thiscall_RBX::ImageHandleAdornment::*)(void)const_,void_(__thiscall_RBX::ImageHandleAdornment::*)(class_G3D::Vector2)>
              ::vftable;
    puVar3[2] = FUN_00cbf370;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d54c00;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,&DAT_018dbc90,&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,0);
  DAT_01f09dd0 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f09e04 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f09df4 = _DAT_01f09df4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f09dd0[2])();
    if (cVar1 != '\0') {
      _DAT_01f09df4 = _DAT_01f09df4 & 0xfffffff3;
    }
  }
  DAT_01f09dd0 = RBX::Reflection::PropDescriptor<class_RBX::ImageHandleAdornment,class_G3D::Vector2>
                 ::vftable;
  FUN_016f3654(&LAB_0189bed0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1647 ; VA 0x004fd590 ; FUN_004fd590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fd590(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("AdornCullingMode",0x10);
  _DAT_01f09b9c = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1648 ; VA 0x004fd8e0 ; FUN_004fd8e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fd8e0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181af50;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd8bc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd8bc,uVar3,0,0,0x1f);
    if (DAT_01efd8bc == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01efd898 = RBX::Reflection::RefType<class_RBX::LocalizationTable*>::vftable;
      FUN_016f3654(&LAB_018956a0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efd8bc);
    }
  }
  uVar2 = FUN_00d59db0();
  FUN_009ca670(uVar2,&DAT_01efd898,s_RootLocalizationTable_02137088,s_Localization_021263c8,uVar3,
               uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_0213f9f4 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::GuiBase2d,class_RBX::LocalizationTable>::vftable;
  _DAT_0213fa28 =
       RBX::Reflection::RefPropDescriptor<class_RBX::GuiBase2d,class_RBX::LocalizationTable>::
       vftable;
  DAT_0213fa2c = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213fa2c == (undefined4 *)0x0) {
    DAT_0213fa2c = (undefined4 *)0x0;
  }
  else {
    *DAT_0213fa2c =
         RBX::Reflection::PropDescriptor<class_RBX::GuiBase2d,class_RBX::LocalizationTable*>::
         GetSetImpl<class_RBX::LocalizationTable*_(__thiscall_RBX::GuiBase2d::*)(void)const_,void_(__thiscall_RBX::GuiBase2d::*)(class_RBX::LocalizationTable*)>
         ::vftable;
    DAT_0213fa2c[2] = FUN_00d5c520;
    DAT_0213fa2c[3] = 0;
    DAT_0213fa2c[4] = FUN_00d5e140;
    DAT_0213fa2c[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0213f9f4[3])();
  if (cVar1 != '\0') {
    _DAT_0213fa18 = _DAT_0213fa18 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213f9f4[2])();
  if (cVar1 != '\0') {
    _DAT_0213fa18 = _DAT_0213fa18 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189c280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1649 ; VA 0x004fdc90 ; FUN_004fdc90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fdc90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181af7c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d59db0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiBase2d,int>::
              GetSetImpl<int_(__thiscall_RBX::GuiBase2d::*)(void)const_,void_(__thiscall_RBX::GuiBase2d::*)(int)>
              ::vftable;
    puVar3[2] = &LAB_00c3b2de;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d5e1b0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_ReplicatedInsertionOrder_0213faf0,&DAT_021197d4,uStack_24,0,0,0x22,6,6,
               0);
  DAT_0213fa30 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213fa64 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213fa54 = _DAT_0213fa54 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213fa30[2])();
    if (cVar1 != '\0') {
      _DAT_0213fa54 = _DAT_0213fa54 & 0xfffffff3;
    }
  }
  DAT_0213fa30 = RBX::Reflection::PropDescriptor<class_RBX::GuiBase2d,int>::vftable;
  FUN_016f3654(&LAB_0189c300);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1650 ; VA 0x004fdfb0 ; FUN_004fdfb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fdfb0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181b3ca;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d5e4a0(uVar2,0);
  FUN_009cb790(uVar1,s_GetLayoutNodeTree_0213fc20,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0213fbc0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiLayerCollector,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void)const_,0>
       ::vftable;
  _DAT_0213fbf8 = FUN_00d65d20;
  _DAT_0213fbfc = 0;
  _DAT_0213fbe4 = FUN_008881d0();
  FUN_016f3654(&LAB_0189c3b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1651 ; VA 0x004fe0a0 ; FUN_004fe0a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fe0a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181b3f4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d69b50();
  uVar3 = FUN_00d5e4a0();
  FUN_009ca670(uVar3,uVar2,s_ZIndexBehavior_0213fc00,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0213fb48 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GuiLayerCollector,enum_RBX::GuiLayerCollector::ZIndexBehavior>
                 ::vftable;
  _DAT_0213fb7c = uVar2;
  DAT_0213fb80 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213fb80 == (undefined4 *)0x0) {
    DAT_0213fb80 = (undefined4 *)0x0;
  }
  else {
    *DAT_0213fb80 =
         RBX::Reflection::
         PropDescriptor<class_RBX::GuiLayerCollector,enum_RBX::GuiLayerCollector::ZIndexBehavior>::
         GetSetImpl<enum_RBX::GuiLayerCollector::ZIndexBehavior_(__thiscall_RBX::GuiLayerCollector::*)(void)const_,void_(__thiscall_RBX::GuiLayerCollector::*)(enum_RBX::GuiLayerCollector::ZIndexBehavior)>
         ::vftable;
    DAT_0213fb80[2] = &LAB_00d66190;
    DAT_0213fb80[3] = 0;
    DAT_0213fb80[4] = FUN_00d69b00;
    DAT_0213fb80[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213fb84 = FUN_00d69b50();
  cVar1 = (*(code *)DAT_0213fb48[3])();
  if (cVar1 != '\0') {
    _DAT_0213fb6c = _DAT_0213fb6c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213fb48[2])();
  if (cVar1 != '\0') {
    _DAT_0213fb6c = _DAT_0213fb6c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189c400);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1652 ; VA 0x004fe1e0 ; FUN_004fe1e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fe1e0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181bdd6;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00d6abe0();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_CelestialBodiesShown_0213ff68,s_Appearance_02119800,uStack_24,0,0,0x1f,
               0,0,0);
  DAT_0213fed0 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_0213fe9c = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::Sky>::vftable;
    puVar5[1] = &DAT_0213fe9c;
    puVar5[2] = 0x11c;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_0213fed0 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0213fed0;
    DAT_0213fed0 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_0213fed0;
  }
  DAT_0213fed0 = puVar5;
  cVar2 = (*(code *)DAT_0213fe9c[3])();
  if (cVar2 != '\0') {
    _DAT_0213fec0 = _DAT_0213fec0 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0213fe9c[2])();
  if (cVar2 != '\0') {
    _DAT_0213fec0 = _DAT_0213fec0 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189c430);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1653 ; VA 0x004fe710 ; FUN_004fe710 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fe710(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181bdfc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d6abe0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Sky,int>::
              GetSetImpl<int_(__thiscall_RBX::Sky::*)(void)const_,void_(__thiscall_RBX::Sky::*)(int)>
              ::vftable;
    puVar3[2] = &LAB_00d6b610;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d6b7f0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_StarCount_0213ff5c,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213fe64 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213fe98 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213fe88 = _DAT_0213fe88 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213fe64[2])();
    if (cVar1 != '\0') {
      _DAT_0213fe88 = _DAT_0213fe88 & 0xfffffff3;
    }
  }
  DAT_0213fe64 = RBX::Reflection::PropDescriptor<class_RBX::Sky,int>::vftable;
  FUN_016f3654(&LAB_0189c550);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1654 ; VA 0x004fec90 ; FUN_004fec90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fec90(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181bf0a;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02140140;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d6bbd0(uVar2,&DAT_02140140);
  FUN_009cb790(uVar1,s_GetAxis_02140420,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021402b0 =
       RBX::Reflection::BoundGetterDesc<class_RBX::Attachment,class_G3D::Vector3>::vftable;
  _DAT_021402e8 = FUN_00a6bd30;
  _DAT_021402ec = 0;
  _DAT_021402d4 = FUN_0088d870();
  FUN_016f3654(&LAB_0189c6b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1655 ; VA 0x004fed30 ; FUN_004fed30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004fed30(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181bf2a;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02140178;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d6bbd0(uVar2,&DAT_02140178);
  FUN_009cb790(uVar1,s_GetSecondaryAxis_02140428,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021402f0 =
       RBX::Reflection::BoundGetterDesc<class_RBX::Attachment,class_G3D::Vector3>::vftable;
  _DAT_02140328 = FUN_00a6bce0;
  _DAT_0214032c = 0;
  _DAT_02140314 = FUN_0088d870();
  FUN_016f3654(&LAB_0189c6c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1656 ; VA 0x004fedd0 ; FUN_004fedd0 */

void FUN_004fedd0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00d6bf40(FUN_00d6d480,0,s_SetAxis_02140404,&DAT_02137c40,0,CONCAT44(&DAT_02140140,uStack_10),0
              );
  FUN_016f3654(&LAB_0189c6d0);
  return;
}



/* FUNCTION 1657 ; VA 0x004fee30 ; FUN_004fee30 */

void FUN_004fee30(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00d6bf40(FUN_00d6dc00,0,s_SetSecondaryAxis_0214040c,&DAT_02137c40,0,
               CONCAT44(&DAT_02140178,uStack_10),0);
  FUN_016f3654(&LAB_0189c6f0);
  return;
}



/* FUNCTION 1658 ; VA 0x004feea0 ; FUN_004feea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004feea0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181bf5c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d6bbd0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Attachment,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Attachment::*)(void)const_,void_(__thiscall_RBX::Attachment::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00d6cc90;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d6de30;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_Visible_021392e8,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_02140330 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02140364 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02140354 = _DAT_02140354 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02140330[2])();
    if (cVar1 != '\0') {
      _DAT_02140354 = _DAT_02140354 & 0xfffffff3;
    }
  }
  DAT_02140330 = RBX::Reflection::PropDescriptor<class_RBX::Attachment,bool>::vftable;
  FUN_016f3654(&LAB_0189c710);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1659 ; VA 0x004ff4e0 ; FUN_004ff4e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ff4e0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181c556;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00d76400();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_Enabled_0212c1fc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02140470 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_0214043c = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::Smoke>::vftable;
    puVar5[1] = &DAT_0214043c;
    puVar5[2] = 0x58;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_02140470 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02140470;
    DAT_02140470 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_02140470;
  }
  DAT_02140470 = puVar5;
  cVar2 = (*(code *)DAT_0214043c[3])();
  if (cVar2 != '\0') {
    _DAT_02140460 = _DAT_02140460 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0214043c[2])();
  if (cVar2 != '\0') {
    _DAT_02140460 = _DAT_02140460 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189c870);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1660 ; VA 0x004ff760 ; FUN_004ff760 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ff760(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181c57c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d76400();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Smoke,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::Smoke::*)(void)const_,void_(__thiscall_RBX::Smoke::*)(class_G3D::Color3)>
              ::vftable;
    puVar3[2] = FUN_008389c0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d76910;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,s_Color_0213abec,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02140474 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021404a8 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02140498 = _DAT_02140498 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02140474[2])();
    if (cVar1 != '\0') {
      _DAT_02140498 = _DAT_02140498 & 0xfffffff3;
    }
  }
  DAT_02140474 = RBX::Reflection::PropDescriptor<class_RBX::Smoke,class_G3D::Color3>::vftable;
  FUN_016f3654(&LAB_0189c910);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1661 ; VA 0x004ff930 ; FUN_004ff930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ff930(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181c646;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00d76d70();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_Enabled_0212c1fc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02140674 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02140640 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::Fire>::vftable;
    puVar5[1] = &DAT_02140640;
    puVar5[2] = 0x58;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_02140674 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02140674;
    DAT_02140674 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_02140674;
  }
  DAT_02140674 = puVar5;
  cVar2 = (*(code *)DAT_02140640[3])();
  if (cVar2 != '\0') {
    _DAT_02140664 = _DAT_02140664 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02140640[2])();
  if (cVar2 != '\0') {
    _DAT_02140664 = _DAT_02140664 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189c9d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1662 ; VA 0x004ffa70 ; FUN_004ffa70 */

void FUN_004ffa70(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_021406e8,0x15);
  FUN_00d76c70(&DAT_0212a31c,&DAT_021197d4,FUN_00832130,0,FUN_00d77400,0,*puVar1,puVar1[1],puVar1[2]
               ,puVar1[3],0);
  FUN_016f3654(&LAB_0189c9f0);
  return;
}



/* FUNCTION 1663 ; VA 0x004ffd90 ; FUN_004ffd90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ffd90(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181c706;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00d77570();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_Enabled_0212c1fc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02140858 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02140824 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::Sparkles>::vftable;
    puVar5[1] = &DAT_02140824;
    puVar5[2] = 0x58;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_02140858 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02140858;
    DAT_02140858 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_02140858;
  }
  DAT_02140858 = puVar5;
  cVar2 = (*(code *)DAT_02140824[3])();
  if (cVar2 != '\0') {
    _DAT_02140848 = _DAT_02140848 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02140824[2])();
  if (cVar2 != '\0') {
    _DAT_02140848 = _DAT_02140848 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189cb50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1664 ; VA 0x00500180 ; FUN_00500180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00500180(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181c8a4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ca6a20();
  uVar3 = FUN_00d787b0();
  FUN_009ca670(uVar3,uVar2,s_ActuatorType_02140c98,s_Hinge_02140c90,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021409b0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Constraints::HingeConstraint,enum_RBX::Constraints::ActuatorType>
                 ::vftable;
  _DAT_021409e4 = uVar2;
  DAT_021409e8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021409e8 == (undefined4 *)0x0) {
    DAT_021409e8 = (undefined4 *)0x0;
  }
  else {
    *DAT_021409e8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Constraints::HingeConstraint,enum_RBX::Constraints::ActuatorType>
         ::
         GetSetImpl<enum_RBX::Constraints::ActuatorType_(__thiscall_RBX::Constraints::HingeConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::HingeConstraint::*)(enum_RBX::Constraints::ActuatorType_const&)>
         ::vftable;
    DAT_021409e8[2] = FUN_00762f90;
    DAT_021409e8[3] = 0;
    DAT_021409e8[4] = FUN_00d7afc0;
    DAT_021409e8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021409ec = FUN_00ca6a20();
  cVar1 = (*(code *)DAT_021409b0[3])();
  if (cVar1 != '\0') {
    _DAT_021409d4 = _DAT_021409d4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021409b0[2])();
  if (cVar1 != '\0') {
    _DAT_021409d4 = _DAT_021409d4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189ccb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1665 ; VA 0x00500350 ; FUN_00500350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00500350(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181c8cc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d787b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Constraints::HingeConstraint,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Constraints::HingeConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::HingeConstraint::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00926b00;
    puVar3[3] = 0;
    puVar3[4] = FUN_00d7b110;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_LimitsEnabled_02140ca8,s_Hinge_02140c90,uStack_24,0,0,0x1f,0,0,0);
  DAT_021409f0 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02140a24 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02140a14 = _DAT_02140a14 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021409f0[2])();
    if (cVar1 != '\0') {
      _DAT_02140a14 = _DAT_02140a14 & 0xfffffff3;
    }
  }
  DAT_021409f0 = RBX::Reflection::PropDescriptor<class_RBX::Constraints::HingeConstraint,bool>::
                 vftable;
  FUN_016f3654(&LAB_0189ccf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1666 ; VA 0x00501050 ; FUN_00501050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501050(void)

{
  char *pcVar1;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181cb82;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  DAT_01f0f964 = FUN_00588320(0xe);
  DAT_01f0f968 = 0;
  _DAT_01f0f96c = 0x3f800000;
  _DAT_01f0f970 = 0;
  DAT_01f0f974 = 0;
  puStack_1c = &DAT_01f0f964;
  iStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 1;
  FUN_00d80290(&puStack_1c,&DAT_01988200,&DAT_01988200,"UserInputType");
  pcVar1 = &DAT_01988204;
  do {
    FUN_00d80290(&puStack_1c,pcVar1,pcVar1,"UserInputType");
    pcVar1 = pcVar1 + 4;
  } while (pcVar1 != "UserInputType");
  if (iStack_18 != 0) {
    FUN_01674ea0(iStack_18,0xc);
  }
  FUN_016f3654(&LAB_0189d030);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1667 ; VA 0x005011b0 ; FUN_005011b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005011b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181cba4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00d82070();
  uVar3 = FUN_00d7fd90();
  FUN_009ca670(uVar3,uVar2,s_UserInputState_02141170,s_State_0211d030,uStack_24,0,0,0x13,0,0,1);
  uStack_8 = 0;
  DAT_02141028 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::InputObject,enum_RBX::InputObject::UserInputState>::
                 vftable;
  _DAT_0214105c = uVar2;
  DAT_02141060 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02141060 == (undefined4 *)0x0) {
    DAT_02141060 = (undefined4 *)0x0;
  }
  else {
    *DAT_02141060 =
         RBX::Reflection::
         PropDescriptor<class_RBX::InputObject,enum_RBX::InputObject::UserInputState>::
         GetSetImpl<enum_RBX::InputObject::UserInputState_(__thiscall_RBX::InputObject::*)(void)const_,void_(__thiscall_RBX::InputObject::*)(enum_RBX::InputObject::UserInputState)>
         ::vftable;
    DAT_02141060[2] = FUN_008609e0;
    DAT_02141060[3] = 0;
    DAT_02141060[4] = FUN_00d81e50;
    DAT_02141060[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02141064 = FUN_00d82070();
  cVar1 = (*(code *)DAT_02141028[3])();
  if (cVar1 != '\0') {
    _DAT_0214104c = _DAT_0214104c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02141028[2])();
  if (cVar1 != '\0') {
    _DAT_0214104c = _DAT_0214104c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189d0c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1668 ; VA 0x00501340 ; FUN_00501340 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501340(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181cbfc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00d7fd90();
  FUN_009cb790(uVar1,s_IsModifierKeyDown_0214119c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02141118 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::InputObject,bool___cdecl(enum_RBX::InputObject::ModifierKey)const_,1>
       ::vftable;
  _DAT_02141150 = FUN_00d81b40;
  _DAT_02141154 = 0;
  DAT_02141158 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214113c = FUN_0088daf0();
  puVar3 = DAT_02141158;
  if (DAT_02141158 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00d81fc0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00d82120();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_00d81fc0();
  uVar2 = FUN_0086e3d0(s_modifierKey_02141190);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189d0e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1669 ; VA 0x005014e0 ; FUN_005014e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005014e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181cc24;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00896d50();
  uVar3 = FUN_00d7fd90();
  FUN_009ca670(uVar3,uVar2,s_KeyCode_02141188,&DAT_021197d4,uStack_24,0,0,0x13,0,0,1);
  uStack_8 = 0;
  DAT_021410d8 = RBX::Reflection::EnumPropDescriptor<class_RBX::InputObject,enum_RBX::KeyCode>::
                 vftable;
  _DAT_0214110c = uVar2;
  DAT_02141110 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02141110 == (undefined4 *)0x0) {
    DAT_02141110 = (undefined4 *)0x0;
  }
  else {
    *DAT_02141110 =
         RBX::Reflection::PropDescriptor<class_RBX::InputObject,enum_RBX::KeyCode>::
         GetSetImpl<enum_RBX::KeyCode_(__thiscall_RBX::InputObject::*)(void)const_,void_(__thiscall_RBX::InputObject::*)(enum_RBX::KeyCode)>
         ::vftable;
    DAT_02141110[2] = FUN_008f8770;
    DAT_02141110[3] = 0;
    DAT_02141110[4] = FUN_00d81ea0;
    DAT_02141110[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02141114 = FUN_00896d50();
  cVar1 = (*(code *)DAT_021410d8[3])();
  if (cVar1 != '\0') {
    _DAT_021410fc = _DAT_021410fc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021410d8[2])();
  if (cVar1 != '\0') {
    _DAT_021410fc = _DAT_021410fc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189d140);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1670 ; VA 0x00501650 ; FUN_00501650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501650(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181cc44;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b84a30();
  uVar3 = FUN_00d7fd90();
  FUN_009ca670(uVar3,uVar2,s_UserInputType_02141160,&DAT_021197d4,uStack_24,0,0,0x13,0,0,1);
  uStack_8 = 0;
  DAT_02140fe8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::InputObject,enum_RBX::InputObject::UserInputType>::
                 vftable;
  _DAT_0214101c = uVar2;
  DAT_02141020 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02141020 == (undefined4 *)0x0) {
    DAT_02141020 = (undefined4 *)0x0;
  }
  else {
    *DAT_02141020 =
         RBX::Reflection::
         PropDescriptor<class_RBX::InputObject,enum_RBX::InputObject::UserInputType>::
         GetSetImpl<enum_RBX::InputObject::UserInputType_(__thiscall_RBX::InputObject::*)(void)const_,void_(__thiscall_RBX::InputObject::*)(enum_RBX::InputObject::UserInputType)>
         ::vftable;
    DAT_02141020[2] = &LAB_008b4220;
    DAT_02141020[3] = 0;
    DAT_02141020[4] = FUN_00d81e80;
    DAT_02141020[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02141024 = FUN_00b84a30();
  cVar1 = (*(code *)DAT_02140fe8[3])();
  if (cVar1 != '\0') {
    _DAT_0214100c = _DAT_0214100c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02140fe8[2])();
  if (cVar1 != '\0') {
    _DAT_0214100c = _DAT_0214100c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189d180);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1671 ; VA 0x00501830 ; FUN_00501830 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501830(void)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_10 = 0;
  uStack_c = 0;
  FUN_0060e8c0(0,&uStack_10,&uStack_5);
  _DAT_01f0fe98 = 0;
  _DAT_01f0fe9c = 0;
  FUN_016f3654(&LAB_0189d270);
  return;
}



/* FUNCTION 1672 ; VA 0x00501880 ; FUN_00501880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501880(void)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_10 = 0;
  uStack_c = 0;
  FUN_0060e8c0(0,&uStack_10,&uStack_5);
  _DAT_01f0fe20 = 0;
  _DAT_01f0fe24 = 0;
  FUN_016f3654(&LAB_0189d2d0);
  return;
}



/* FUNCTION 1673 ; VA 0x005018d0 ; FUN_005018d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005018d0(void)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_10 = 0;
  uStack_c = 0;
  FUN_0060e8c0(0,&uStack_10,&uStack_5);
  _DAT_01f0fe38 = 0;
  _DAT_01f0fe3c = 0;
  FUN_016f3654(&LAB_0189d330);
  return;
}



/* FUNCTION 1674 ; VA 0x00501920 ; FUN_00501920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501920(void)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_10 = 0;
  uStack_c = 0;
  FUN_0060e8c0(0,&uStack_10,&uStack_5);
  _DAT_01f0fec8 = 0;
  _DAT_01f0fecc = 0;
  FUN_016f3654(&LAB_0189d390);
  return;
}



/* FUNCTION 1675 ; VA 0x00501970 ; FUN_00501970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501970(void)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_10 = 0;
  uStack_c = 0;
  FUN_0060e8c0(0,&uStack_10,&uStack_5);
  _DAT_01f0fe68 = 0;
  _DAT_01f0fe6c = 0;
  FUN_016f3654(&LAB_0189d3f0);
  return;
}



/* FUNCTION 1676 ; VA 0x005019c0 ; FUN_005019c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005019c0(void)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_10 = 0;
  uStack_c = 0;
  FUN_0060e8c0(0,&uStack_10,&uStack_5);
  _DAT_01f0fe50 = 0;
  _DAT_01f0fe54 = 0;
  FUN_016f3654(&LAB_0189d450);
  return;
}



/* FUNCTION 1677 ; VA 0x00501a10 ; FUN_00501a10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501a10(void)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_10 = 0;
  uStack_c = 0;
  FUN_0060e8c0(0,&uStack_10,&uStack_5);
  _DAT_01f0feb0 = 0;
  _DAT_01f0feb4 = 0;
  FUN_016f3654(&LAB_0189d4b0);
  return;
}



/* FUNCTION 1678 ; VA 0x00501a60 ; FUN_00501a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501a60(void)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_10 = 0;
  uStack_c = 0;
  FUN_0060e8c0(0,&uStack_10,&uStack_5);
  _DAT_01f0fe80 = 0;
  _DAT_01f0fe84 = 0;
  FUN_016f3654(&LAB_0189d510);
  return;
}



/* FUNCTION 1679 ; VA 0x00501ab0 ; FUN_00501ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501ab0(void)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_10 = 0;
  uStack_c = 0;
  FUN_0060e8c0(0,&uStack_10,&uStack_5);
  _DAT_01f0fe08 = 0;
  _DAT_01f0fe0c = 0;
  FUN_016f3654(&LAB_0189d570);
  return;
}



/* FUNCTION 1680 ; VA 0x00501c70 ; FUN_00501c70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501c70(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fbcc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f103d8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f103d8);
    if (DAT_01f103d8 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Surface","Complex",0x1f,0,0,0);
      _DAT_01f103b4 = RBX::Reflection::TType<class_RBX::Surface>::vftable;
      FUN_016f3654(&LAB_0189da10);
      FUN_016f37bf(&DAT_01f103d8);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1681 ; VA 0x00501d10 ; FUN_00501d10 */

void FUN_00501d10(void)

{
  FUN_00dada30("BackParamA","Surface Inputs",0xb08110,0,0xb0e670,0,0x1f,0);
  FUN_016f3654(&LAB_0189d6f0);
  return;
}



/* FUNCTION 1682 ; VA 0x00501d90 ; FUN_00501d90 */

void FUN_00501d90(void)

{
  FUN_00dada30("BackParamB","Surface Inputs",0xb08140,0,0xb0e700,0,0x1f,0);
  FUN_016f3654(&LAB_0189d710);
  return;
}



/* FUNCTION 1683 ; VA 0x00501e10 ; FUN_00501e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501e10(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fbf4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00daf140();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"BackSurfaceInput","Surface Inputs",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f108d0 = RBX::SurfaceEnumPropDescriptor<2,enum_RBX::LegacyController::InputType>::vftable;
  _DAT_01f10904 = uVar1;
  DAT_01f10908 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f10908 == (undefined4 *)0x0) {
    DAT_01f10908 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f10908 + 2) = 0xb07830;
    *(undefined8 *)(DAT_01f10908 + 6) = 0xb0ede0;
    *DAT_01f10908 =
         RBX::
         SurfaceGetSet<2,enum_RBX::LegacyController::InputType,enum_RBX::LegacyController::InputType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::LegacyController::InputType)>
         ::vftable;
    DAT_01f10908[4] = 0;
    DAT_01f10908[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1090c = FUN_00daf140();
  FUN_016f3654(&LAB_0189d730);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1684 ; VA 0x00501f20 ; FUN_00501f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00501f20(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fc14;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008970d0();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"BackSurface","Surface",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f10890 = RBX::SurfaceEnumPropDescriptor<2,enum_RBX::SurfaceType>::vftable;
  _DAT_01f108c4 = uVar1;
  DAT_01f108c8 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f108c8 == (undefined4 *)0x0) {
    DAT_01f108c8 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f108c8 + 2) = 0xb08890;
    *(undefined8 *)(DAT_01f108c8 + 6) = 0xb0ee60;
    *DAT_01f108c8 =
         RBX::
         SurfaceGetSet<2,enum_RBX::SurfaceType,enum_RBX::SurfaceType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::SurfaceType)>
         ::vftable;
    DAT_01f108c8[4] = 0;
    DAT_01f108c8[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f108cc = FUN_008970d0();
  FUN_016f3654(&LAB_0189d750);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1685 ; VA 0x00502030 ; FUN_00502030 */

void FUN_00502030(void)

{
  FUN_00dadbb0("BottomParamA","Surface Inputs",0xb08110,0,0xb0e670,0,0x1f,0);
  FUN_016f3654(&LAB_0189d770);
  return;
}



/* FUNCTION 1686 ; VA 0x005020b0 ; FUN_005020b0 */

void FUN_005020b0(void)

{
  FUN_00dadbb0("BottomParamB","Surface Inputs",0xb08140,0,0xb0e700,0,0x1f,0);
  FUN_016f3654(&LAB_0189d790);
  return;
}



/* FUNCTION 1687 ; VA 0x00502130 ; FUN_00502130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502130(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fc34;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00daf140();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"BottomSurfaceInput","Surface Inputs",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f10510 = RBX::SurfaceEnumPropDescriptor<4,enum_RBX::LegacyController::InputType>::vftable;
  _DAT_01f10544 = uVar1;
  DAT_01f10548 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f10548 == (undefined4 *)0x0) {
    DAT_01f10548 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f10548 + 2) = 0xb07830;
    *(undefined8 *)(DAT_01f10548 + 6) = 0xb0ede0;
    *DAT_01f10548 =
         RBX::
         SurfaceGetSet<4,enum_RBX::LegacyController::InputType,enum_RBX::LegacyController::InputType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::LegacyController::InputType)>
         ::vftable;
    DAT_01f10548[4] = 0;
    DAT_01f10548[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1054c = FUN_00daf140();
  FUN_016f3654(&LAB_0189d7b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1688 ; VA 0x00502240 ; FUN_00502240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502240(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fc54;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008970d0();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"BottomSurface","Surface",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f104d0 = RBX::SurfaceEnumPropDescriptor<4,enum_RBX::SurfaceType>::vftable;
  _DAT_01f10504 = uVar1;
  DAT_01f10508 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f10508 == (undefined4 *)0x0) {
    DAT_01f10508 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f10508 + 2) = 0xb08890;
    *(undefined8 *)(DAT_01f10508 + 6) = 0xb0ee60;
    *DAT_01f10508 =
         RBX::
         SurfaceGetSet<4,enum_RBX::SurfaceType,enum_RBX::SurfaceType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::SurfaceType)>
         ::vftable;
    DAT_01f10508[4] = 0;
    DAT_01f10508[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1050c = FUN_008970d0();
  FUN_016f3654(&LAB_0189d7d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1689 ; VA 0x00502350 ; FUN_00502350 */

void FUN_00502350(void)

{
  FUN_00dadc70("FrontParamA","Surface Inputs",0xb08110,0,0xb0e670,0,0x1f,0);
  FUN_016f3654(&LAB_0189d7f0);
  return;
}



/* FUNCTION 1690 ; VA 0x005023d0 ; FUN_005023d0 */

void FUN_005023d0(void)

{
  FUN_00dadc70("FrontParamB","Surface Inputs",0xb08140,0,0xb0e700,0,0x1f,0);
  FUN_016f3654(&LAB_0189d810);
  return;
}



/* FUNCTION 1691 ; VA 0x00502450 ; FUN_00502450 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502450(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fc74;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00daf140();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"FrontSurfaceInput","Surface Inputs",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f107e0 = RBX::SurfaceEnumPropDescriptor<5,enum_RBX::LegacyController::InputType>::vftable;
  _DAT_01f10814 = uVar1;
  DAT_01f10818 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f10818 == (undefined4 *)0x0) {
    DAT_01f10818 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f10818 + 2) = 0xb07830;
    *(undefined8 *)(DAT_01f10818 + 6) = 0xb0ede0;
    *DAT_01f10818 =
         RBX::
         SurfaceGetSet<5,enum_RBX::LegacyController::InputType,enum_RBX::LegacyController::InputType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::LegacyController::InputType)>
         ::vftable;
    DAT_01f10818[4] = 0;
    DAT_01f10818[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1081c = FUN_00daf140();
  FUN_016f3654(&LAB_0189d830);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1692 ; VA 0x00502560 ; FUN_00502560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502560(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fc94;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008970d0();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"FrontSurface","Surface",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f107a0 = RBX::SurfaceEnumPropDescriptor<5,enum_RBX::SurfaceType>::vftable;
  _DAT_01f107d4 = uVar1;
  DAT_01f107d8 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f107d8 == (undefined4 *)0x0) {
    DAT_01f107d8 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f107d8 + 2) = 0xb08890;
    *(undefined8 *)(DAT_01f107d8 + 6) = 0xb0ee60;
    *DAT_01f107d8 =
         RBX::
         SurfaceGetSet<5,enum_RBX::SurfaceType,enum_RBX::SurfaceType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::SurfaceType)>
         ::vftable;
    DAT_01f107d8[4] = 0;
    DAT_01f107d8[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f107dc = FUN_008970d0();
  FUN_016f3654(&LAB_0189d850);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1693 ; VA 0x00502670 ; FUN_00502670 */

void FUN_00502670(void)

{
  FUN_00dadaf0("LeftParamA","Surface Inputs",0xb08110,0,0xb0e670,0,0x1f,0);
  FUN_016f3654(&LAB_0189d870);
  return;
}



/* FUNCTION 1694 ; VA 0x005026f0 ; FUN_005026f0 */

void FUN_005026f0(void)

{
  FUN_00dadaf0("LeftParamB","Surface Inputs",0xb08140,0,0xb0e700,0,0x1f,0);
  FUN_016f3654(&LAB_0189d890);
  return;
}



/* FUNCTION 1695 ; VA 0x00502770 ; FUN_00502770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502770(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fcb4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00daf140();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"LeftSurfaceInput","Surface Inputs",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f10600 = RBX::SurfaceEnumPropDescriptor<3,enum_RBX::LegacyController::InputType>::vftable;
  _DAT_01f10634 = uVar1;
  DAT_01f10638 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f10638 == (undefined4 *)0x0) {
    DAT_01f10638 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f10638 + 2) = 0xb07830;
    *(undefined8 *)(DAT_01f10638 + 6) = 0xb0ede0;
    *DAT_01f10638 =
         RBX::
         SurfaceGetSet<3,enum_RBX::LegacyController::InputType,enum_RBX::LegacyController::InputType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::LegacyController::InputType)>
         ::vftable;
    DAT_01f10638[4] = 0;
    DAT_01f10638[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1063c = FUN_00daf140();
  FUN_016f3654(&LAB_0189d8b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1696 ; VA 0x00502880 ; FUN_00502880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502880(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fcd4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008970d0();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"LeftSurface","Surface",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f105c0 = RBX::SurfaceEnumPropDescriptor<3,enum_RBX::SurfaceType>::vftable;
  _DAT_01f105f4 = uVar1;
  DAT_01f105f8 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f105f8 == (undefined4 *)0x0) {
    DAT_01f105f8 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f105f8 + 2) = 0xb08890;
    *(undefined8 *)(DAT_01f105f8 + 6) = 0xb0ee60;
    *DAT_01f105f8 =
         RBX::
         SurfaceGetSet<3,enum_RBX::SurfaceType,enum_RBX::SurfaceType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::SurfaceType)>
         ::vftable;
    DAT_01f105f8[4] = 0;
    DAT_01f105f8[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f105fc = FUN_008970d0();
  FUN_016f3654(&LAB_0189d8d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1697 ; VA 0x00502990 ; FUN_00502990 */

void FUN_00502990(void)

{
  FUN_00dadd30("RightParamA","Surface Inputs",0xb08110,0,0xb0e670,0,0x1f,0);
  FUN_016f3654(&LAB_0189d8f0);
  return;
}



/* FUNCTION 1698 ; VA 0x00502a10 ; FUN_00502a10 */

void FUN_00502a10(void)

{
  FUN_00dadd30("RightParamB","Surface Inputs",0xb08140,0,0xb0e700,0,0x1f,0);
  FUN_016f3654(&LAB_0189d910);
  return;
}



/* FUNCTION 1699 ; VA 0x00502a90 ; FUN_00502a90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502a90(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fcf4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00daf140();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"RightSurfaceInput","Surface Inputs",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f106f0 = RBX::SurfaceEnumPropDescriptor<0,enum_RBX::LegacyController::InputType>::vftable;
  _DAT_01f10724 = uVar1;
  DAT_01f10728 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f10728 == (undefined4 *)0x0) {
    DAT_01f10728 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f10728 + 2) = 0xb07830;
    *(undefined8 *)(DAT_01f10728 + 6) = 0xb0ede0;
    *DAT_01f10728 =
         RBX::
         SurfaceGetSet<0,enum_RBX::LegacyController::InputType,enum_RBX::LegacyController::InputType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::LegacyController::InputType)>
         ::vftable;
    DAT_01f10728[4] = 0;
    DAT_01f10728[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1072c = FUN_00daf140();
  FUN_016f3654(&LAB_0189d930);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1700 ; VA 0x00502ba0 ; FUN_00502ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502ba0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fd14;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008970d0();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"RightSurface","Surface",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f106b0 = RBX::SurfaceEnumPropDescriptor<0,enum_RBX::SurfaceType>::vftable;
  _DAT_01f106e4 = uVar1;
  DAT_01f106e8 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f106e8 == (undefined4 *)0x0) {
    DAT_01f106e8 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f106e8 + 2) = 0xb08890;
    *(undefined8 *)(DAT_01f106e8 + 6) = 0xb0ee60;
    *DAT_01f106e8 =
         RBX::
         SurfaceGetSet<0,enum_RBX::SurfaceType,enum_RBX::SurfaceType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::SurfaceType)>
         ::vftable;
    DAT_01f106e8[4] = 0;
    DAT_01f106e8[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f106ec = FUN_008970d0();
  FUN_016f3654(&LAB_0189d950);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1701 ; VA 0x00502cb0 ; FUN_00502cb0 */

void FUN_00502cb0(void)

{
  FUN_00dad970("TopParamA","Surface Inputs",0xb08110,0,0xb0e670,0,0x1f,0);
  FUN_016f3654(&LAB_0189d970);
  return;
}



/* FUNCTION 1702 ; VA 0x00502d30 ; FUN_00502d30 */

void FUN_00502d30(void)

{
  FUN_00dad970("TopParamB","Surface Inputs",0xb08140,0,0xb0e700,0,0x1f,0);
  FUN_016f3654(&LAB_0189d990);
  return;
}



/* FUNCTION 1703 ; VA 0x00502db0 ; FUN_00502db0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502db0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fd34;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00daf140();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"TopSurfaceInput","Surface Inputs",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f10420 = RBX::SurfaceEnumPropDescriptor<1,enum_RBX::LegacyController::InputType>::vftable;
  _DAT_01f10454 = uVar1;
  DAT_01f10458 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f10458 == (undefined4 *)0x0) {
    DAT_01f10458 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f10458 + 2) = 0xb07830;
    *(undefined8 *)(DAT_01f10458 + 6) = 0xb0ede0;
    *DAT_01f10458 =
         RBX::
         SurfaceGetSet<1,enum_RBX::LegacyController::InputType,enum_RBX::LegacyController::InputType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::LegacyController::InputType)>
         ::vftable;
    DAT_01f10458[4] = 0;
    DAT_01f10458[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1045c = FUN_00daf140();
  FUN_016f3654(&LAB_0189d9b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1704 ; VA 0x00502ec0 ; FUN_00502ec0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502ec0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181fd54;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008970d0();
  uVar2 = FUN_00aff8c0();
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_009ca670(uVar2,uVar1,"TopSurface","Surface",uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  _DAT_01f103e0 = RBX::SurfaceEnumPropDescriptor<1,enum_RBX::SurfaceType>::vftable;
  _DAT_01f10414 = uVar1;
  DAT_01f10418 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01f10418 == (undefined4 *)0x0) {
    DAT_01f10418 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01f10418 + 2) = 0xb08890;
    *(undefined8 *)(DAT_01f10418 + 6) = 0xb0ee60;
    *DAT_01f10418 =
         RBX::
         SurfaceGetSet<1,enum_RBX::SurfaceType,enum_RBX::SurfaceType_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId)const_,void_(__thiscall_RBX::PartInstance::*)(enum_RBX::NormalId,enum_RBX::SurfaceType)>
         ::vftable;
    DAT_01f10418[4] = 0;
    DAT_01f10418[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1041c = FUN_008970d0();
  FUN_016f3654(&LAB_0189d9d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1705 ; VA 0x00502fe0 ; FUN_00502fe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00502fe0(void)

{
  char *pcVar1;
  char *pcVar2;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  
  uStack_1c = uStack_1c & 0xffffff00;
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  DAT_021416ac = uStack_1c;
  uRam021416b0 = uStack_18;
  uRam021416b4 = uStack_14;
  uRam021416b8 = uStack_10;
  _DAT_021416bc = 0xf00000000;
  FUN_016f3654(&LAB_0189da20);
  return;
}



/* FUNCTION 1706 ; VA 0x00503040 ; FUN_00503040 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503040(void)

{
  _DAT_0214185c = 0;
  _DAT_02141864 = 0;
  return;
}



/* FUNCTION 1707 ; VA 0x00503070 ; FUN_00503070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503070(void)

{
  _DAT_021417b8 = 0;
  _DAT_021417b0 = 0;
  _DAT_021417bc = 0;
  DAT_021417c0._4_4_ = 0;
  return;
}



/* FUNCTION 1708 ; VA 0x005033b0 ; FUN_005033b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005033b0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820826;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00daf7e0();
  uStack_8 = 0;
  uVar4 = FUN_0088cf00();
  FUN_009ca670(uVar3,uVar4,s_Value_021415bc,&DAT_021197d4,uStack_24,0,0,0xe,0,0,0);
  DAT_021416f8 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_021416c4 = RBX::Reflection::BoundProp<class_RBX::BinaryString,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<class_RBX::BinaryString,1>::
              BoundPropGetSet<class_RBX::Value<class_RBX::BinaryString>_>::vftable;
    puVar5[1] = &DAT_021416c4;
    puVar5[2] = 0x54;
    puVar5[4] = FUN_00db51d0;
    puVar5[5] = 0;
  }
  if (DAT_021416f8 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021416f8;
    DAT_021416f8 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_021416f8;
  }
  DAT_021416f8 = puVar5;
  cVar2 = (*(code *)DAT_021416c4[3])();
  if (cVar2 != '\0') {
    _DAT_021416e8 = _DAT_021416e8 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021416c4[2])();
  if (cVar2 != '\0') {
    _DAT_021416e8 = _DAT_021416e8 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189dba0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1709 ; VA 0x005034e0 ; FUN_005034e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005034e0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820856;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00daf8e0();
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar3,uVar4,s_Value_021415bc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214198c = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02141958 = RBX::Reflection::BoundProp<class_RBX::BrickColor,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<class_RBX::BrickColor,1>::
              BoundPropGetSet<class_RBX::Value<class_RBX::BrickColor>_>::vftable;
    puVar5[1] = &DAT_02141958;
    puVar5[2] = 0x54;
    puVar5[4] = &LAB_00db5200;
    puVar5[5] = 0;
  }
  if (DAT_0214198c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0214198c;
    DAT_0214198c = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_0214198c;
  }
  DAT_0214198c = puVar5;
  cVar2 = (*(code *)DAT_02141958[3])();
  if (cVar2 != '\0') {
    _DAT_0214197c = _DAT_0214197c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02141958[2])();
  if (cVar2 != '\0') {
    _DAT_0214197c = _DAT_0214197c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189dbc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1710 ; VA 0x00503610 ; FUN_00503610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503610(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820886;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00daf9e0();
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar3,uVar4,s_Value_021415bc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02141918 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_021418e4 = RBX::Reflection::BoundProp<class_G3D::Color3,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<class_G3D::Color3,1>::
              BoundPropGetSet<class_RBX::Value<class_G3D::Color3>_>::vftable;
    puVar5[1] = &DAT_021418e4;
    puVar5[2] = 0x54;
    puVar5[4] = &LAB_00db5210;
    puVar5[5] = 0;
  }
  if (DAT_02141918 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02141918;
    DAT_02141918 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_02141918;
  }
  DAT_02141918 = puVar5;
  cVar2 = (*(code *)DAT_021418e4[3])();
  if (cVar2 != '\0') {
    _DAT_02141908 = _DAT_02141908 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021418e4[2])();
  if (cVar2 != '\0') {
    _DAT_02141908 = _DAT_02141908 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189dbe0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1711 ; VA 0x00503740 ; FUN_00503740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503740(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018208b6;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00dafae0();
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar3,uVar4,s_Value_021415bc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214189c = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02141868 = RBX::Reflection::BoundProp<class_G3D::CoordinateFrame,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<class_G3D::CoordinateFrame,1>::
              BoundPropGetSet<class_RBX::Value<class_G3D::CoordinateFrame>_>::vftable;
    puVar5[1] = &DAT_02141868;
    puVar5[2] = 0x54;
    puVar5[4] = &LAB_00db5230;
    puVar5[5] = 0;
  }
  if (DAT_0214189c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0214189c;
    DAT_0214189c = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_0214189c;
  }
  DAT_0214189c = puVar5;
  cVar2 = (*(code *)DAT_02141868[3])();
  if (cVar2 != '\0') {
    _DAT_0214188c = _DAT_0214188c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02141868[2])();
  if (cVar2 != '\0') {
    _DAT_0214188c = _DAT_0214188c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189dc00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1712 ; VA 0x00503870 ; FUN_00503870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503870(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018208e6;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00dafbe0();
  uStack_8 = 0;
  uVar4 = FUN_0088d370();
  FUN_009ca670(uVar3,uVar4,s_Value_021415bc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_021417fc = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_021417c8 = RBX::Reflection::BoundProp<class_RBX::RbxRay,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<class_RBX::RbxRay,1>::
              BoundPropGetSet<class_RBX::Value<class_RBX::RbxRay>_>::vftable;
    puVar5[1] = &DAT_021417c8;
    puVar5[2] = 0x54;
    puVar5[4] = &LAB_00db5260;
    puVar5[5] = 0;
  }
  if (DAT_021417fc != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021417fc;
    DAT_021417fc = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_021417fc;
  }
  DAT_021417fc = puVar5;
  cVar2 = (*(code *)DAT_021417c8[3])();
  if (cVar2 != '\0') {
    _DAT_021417ec = _DAT_021417ec & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021417c8[2])();
  if (cVar2 != '\0') {
    _DAT_021417ec = _DAT_021417ec & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189dc20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1713 ; VA 0x005039a0 ; FUN_005039a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005039a0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820916;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00dafce0();
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar3,uVar4,s_Value_021415bc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02141774 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02141740 = RBX::Reflection::BoundProp<class_G3D::Vector3,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<class_G3D::Vector3,1>::
              BoundPropGetSet<class_RBX::Value<class_G3D::Vector3>_>::vftable;
    puVar5[1] = &DAT_02141740;
    puVar5[2] = 0x54;
    puVar5[4] = &LAB_00db5210;
    puVar5[5] = 0;
  }
  if (DAT_02141774 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02141774;
    DAT_02141774 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_02141774;
  }
  DAT_02141774 = puVar5;
  cVar2 = (*(code *)DAT_02141740[3])();
  if (cVar2 != '\0') {
    _DAT_02141764 = _DAT_02141764 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02141740[2])();
  if (cVar2 != '\0') {
    _DAT_02141764 = _DAT_02141764 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189dc40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1714 ; VA 0x00503ad0 ; FUN_00503ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503ad0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820946;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00dafde0();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_Value_021415bc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02141600 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_021415cc = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::Value<bool>_>::vftable;
    puVar5[1] = &DAT_021415cc;
    puVar5[2] = 0x54;
    puVar5[4] = &LAB_00db5290;
    puVar5[5] = 0;
  }
  if (DAT_02141600 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02141600;
    DAT_02141600 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_02141600;
  }
  DAT_02141600 = puVar5;
  cVar2 = (*(code *)DAT_021415cc[3])();
  if (cVar2 != '\0') {
    _DAT_021415f0 = _DAT_021415f0 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021415cc[2])();
  if (cVar2 != '\0') {
    _DAT_021415f0 = _DAT_021415f0 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189dc60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1715 ; VA 0x00503c00 ; FUN_00503c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503c00(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820970;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x1f);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00dafee0();
  FUN_009ca670(uVar2,&DAT_01edf850,s_Value_021415bc,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_02141488 = RBX::Reflection::RefPropDescriptor<class_RBX::ObjectValue,class_RBX::Instance>::
                 vftable;
  _DAT_021414bc =
       RBX::Reflection::RefPropDescriptor<class_RBX::ObjectValue,class_RBX::Instance>::vftable;
  DAT_021414c0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021414c0 == (undefined4 *)0x0) {
    DAT_021414c0 = (undefined4 *)0x0;
  }
  else {
    *DAT_021414c0 =
         RBX::Reflection::PropDescriptor<class_RBX::ObjectValue,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::ObjectValue::*)(void)const_,void_(__thiscall_RBX::ObjectValue::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_021414c0[2] = FUN_00db4dc0;
    DAT_021414c0[3] = 0;
    DAT_021414c0[4] = FUN_00db5850;
    DAT_021414c0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_02141488[3])();
  if (cVar1 != '\0') {
    _DAT_021414ac = _DAT_021414ac & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02141488[2])();
  if (cVar1 != '\0') {
    _DAT_021414ac = _DAT_021414ac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189dc80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1716 ; VA 0x00503da0 ; FUN_00503da0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503da0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018209a6;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00daffe0();
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar3,uVar4,s_Value_021415bc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0214128c = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02141258 = RBX::Reflection::
                 BoundProp<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,1>
                 ::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::
              BoundProp<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,1>
              ::BoundPropGetSet<class_RBX::StringValue>::vftable;
    puVar5[1] = &DAT_02141258;
    puVar5[2] = 0x54;
    puVar5[4] = FUN_00db52a0;
    puVar5[5] = 0;
  }
  if (DAT_0214128c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0214128c;
    DAT_0214128c = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_0214128c;
  }
  DAT_0214128c = puVar5;
  cVar2 = (*(code *)DAT_02141258[3])();
  if (cVar2 != '\0') {
    _DAT_0214127c = _DAT_0214127c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02141258[2])();
  if (cVar2 != '\0') {
    _DAT_0214127c = _DAT_0214127c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189dca0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1717 ; VA 0x00503ed0 ; FUN_00503ed0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503ed0(void)

{
  undefined4 extraout_var;
  
  FUN_00db1690(0x70,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_02141c5c =
       RBX::Reflection::
       EventDesc<class_RBX::ConstrainedValue<double>,void___cdecl(double),class_rbx::signal<void___cdecl(double)>,class_rbx::signal<void___cdecl(double)>_RBX::ConstrainedValue<double>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dcc0,extraout_var);
  return;
}



/* FUNCTION 1718 ; VA 0x00503f20 ; FUN_00503f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503f20(void)

{
  undefined4 extraout_var;
  
  FUN_00db17c0(0x70,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_02141ae0 =
       RBX::Reflection::
       EventDesc<class_RBX::ConstrainedValue<__int64>,void___cdecl(__int64),class_rbx::signal<void___cdecl(__int64)>,class_rbx::signal<void___cdecl(__int64)>_RBX::ConstrainedValue<__int64>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dcd0,extraout_var);
  return;
}



/* FUNCTION 1719 ; VA 0x00503f70 ; FUN_00503f70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503f70(void)

{
  undefined4 extraout_var;
  
  FUN_00db18f0(0x60,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_02141674 =
       RBX::Reflection::
       EventDesc<class_RBX::NumericValue<double>,void___cdecl(double),class_rbx::signal<void___cdecl(double)>,class_rbx::signal<void___cdecl(double)>_RBX::NumericValue<double>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dce0,extraout_var);
  return;
}



/* FUNCTION 1720 ; VA 0x00503fd0 ; FUN_00503fd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00503fd0(void)

{
  undefined4 extraout_var;
  
  FUN_00db1a20(0x60,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_02141584 =
       RBX::Reflection::
       EventDesc<class_RBX::NumericValue<__int64>,void___cdecl(__int64),class_rbx::signal<void___cdecl(__int64)>,class_rbx::signal<void___cdecl(__int64)>_RBX::NumericValue<__int64>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dcf0,extraout_var);
  return;
}



/* FUNCTION 1721 ; VA 0x00504020 ; FUN_00504020 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504020(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018209d3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00daf7e0();
  FUN_009cb970(uVar1,s_Changed_0211ac74,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02141730 = 0x6c;
  iStack_8 = 0;
  _DAT_021416fc =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_RBX::BinaryString>,void___cdecl(class_RBX::BinaryString),class_rbx::signal<void___cdecl(class_RBX::BinaryString)>,class_rbx::signal<void___cdecl(class_RBX::BinaryString)>_RBX::Value<class_RBX::BinaryString>::*>
       ::vftable;
  FUN_0086e3d0(s_value_0211ab70);
  FUN_0088cf00();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02141724 = uStack_1c;
  _DAT_02141728 = uStack_18;
  _DAT_0214172c = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021416fc =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_RBX::BinaryString>,void___cdecl(class_RBX::BinaryString),class_rbx::signal<void___cdecl(class_RBX::BinaryString)>,class_rbx::signal<void___cdecl(class_RBX::BinaryString)>_RBX::Value<class_RBX::BinaryString>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dd00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1722 ; VA 0x00504170 ; FUN_00504170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504170(void)

{
  undefined4 extraout_var;
  
  FUN_00db1b50(0x58,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_02141990 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_RBX::BrickColor>,void___cdecl(class_RBX::BrickColor),class_rbx::signal<void___cdecl(class_RBX::BrickColor)>,class_rbx::signal<void___cdecl(class_RBX::BrickColor)>_RBX::Value<class_RBX::BrickColor>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dd10,extraout_var);
  return;
}



/* FUNCTION 1723 ; VA 0x005041c0 ; FUN_005041c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005041c0(void)

{
  undefined4 extraout_var;
  
  FUN_00db1c80(0x60,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_0214191c =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_G3D::Color3>,void___cdecl(class_G3D::Color3),class_rbx::signal<void___cdecl(class_G3D::Color3)>,class_rbx::signal<void___cdecl(class_G3D::Color3)>_RBX::Value<class_G3D::Color3>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dd20,extraout_var);
  return;
}



/* FUNCTION 1724 ; VA 0x00504210 ; FUN_00504210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504210(void)

{
  undefined4 extraout_var;
  
  FUN_00db1db0(0x84,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_021418a0 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_G3D::CoordinateFrame>,void___cdecl(class_G3D::CoordinateFrame),class_rbx::signal<void___cdecl(class_G3D::CoordinateFrame)>,class_rbx::signal<void___cdecl(class_G3D::CoordinateFrame)>_RBX::Value<class_G3D::CoordinateFrame>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dd30,extraout_var);
  return;
}



/* FUNCTION 1725 ; VA 0x00504260 ; FUN_00504260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504260(void)

{
  undefined4 extraout_var;
  
  FUN_00db1ee0(0x6c,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_02141800 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_RBX::RbxRay>,void___cdecl(class_RBX::RbxRay),class_rbx::signal<void___cdecl(class_RBX::RbxRay)>,class_rbx::signal<void___cdecl(class_RBX::RbxRay)>_RBX::Value<class_RBX::RbxRay>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dd40,extraout_var);
  return;
}



/* FUNCTION 1726 ; VA 0x005042b0 ; FUN_005042b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005042b0(void)

{
  undefined4 extraout_var;
  
  FUN_00db2010(0x60,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_02141778 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_G3D::Vector3>,void___cdecl(class_G3D::Vector3),class_rbx::signal<void___cdecl(class_G3D::Vector3)>,class_rbx::signal<void___cdecl(class_G3D::Vector3)>_RBX::Value<class_G3D::Vector3>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dd50,extraout_var);
  return;
}



/* FUNCTION 1727 ; VA 0x00504300 ; FUN_00504300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504300(void)

{
  undefined4 extraout_var;
  
  FUN_00db2140(0x58,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_02141604 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<bool>,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::Value<bool>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dd60,extraout_var);
  return;
}



/* FUNCTION 1728 ; VA 0x00504350 ; FUN_00504350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504350(void)

{
  undefined4 extraout_var;
  
  FUN_00db23a0(0x6c,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_02141290 =
       RBX::Reflection::
       EventDesc<class_RBX::StringValue,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::StringValue::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dd70,extraout_var);
  return;
}



/* FUNCTION 1729 ; VA 0x00504900 ; FUN_00504900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504900(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db2140(0x58,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_02141604,uStack_10),0);
  _DAT_021411e8 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<bool>,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::Value<bool>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189de40);
  return;
}



/* FUNCTION 1730 ; VA 0x00504960 ; FUN_00504960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504960(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db1b50(0x58,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_02141990,uStack_10),0);
  _DAT_021413e0 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_RBX::BrickColor>,void___cdecl(class_RBX::BrickColor),class_rbx::signal<void___cdecl(class_RBX::BrickColor)>,class_rbx::signal<void___cdecl(class_RBX::BrickColor)>_RBX::Value<class_RBX::BrickColor>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189de50);
  return;
}



/* FUNCTION 1731 ; VA 0x005049c0 ; FUN_005049c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005049c0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db1db0(0x84,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_021418a0,uStack_10),0);
  _DAT_02141370 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_G3D::CoordinateFrame>,void___cdecl(class_G3D::CoordinateFrame),class_rbx::signal<void___cdecl(class_G3D::CoordinateFrame)>,class_rbx::signal<void___cdecl(class_G3D::CoordinateFrame)>_RBX::Value<class_G3D::CoordinateFrame>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189de60);
  return;
}



/* FUNCTION 1732 ; VA 0x00504a20 ; FUN_00504a20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504a20(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db1c80(0x60,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_0214191c,uStack_10),0);
  _DAT_021413a8 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_G3D::Color3>,void___cdecl(class_G3D::Color3),class_rbx::signal<void___cdecl(class_G3D::Color3)>,class_rbx::signal<void___cdecl(class_G3D::Color3)>_RBX::Value<class_G3D::Color3>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189de70);
  return;
}



/* FUNCTION 1733 ; VA 0x00504a80 ; FUN_00504a80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504a80(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db1690(0x70,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_02141c5c,uStack_10),0);
  _DAT_02141450 =
       RBX::Reflection::
       EventDesc<class_RBX::ConstrainedValue<double>,void___cdecl(double),class_rbx::signal<void___cdecl(double)>,class_rbx::signal<void___cdecl(double)>_RBX::ConstrainedValue<double>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189de80);
  return;
}



/* FUNCTION 1734 ; VA 0x00504ae0 ; FUN_00504ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504ae0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db18f0(0x60,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_02141674,uStack_10),0);
  _DAT_02141220 =
       RBX::Reflection::
       EventDesc<class_RBX::NumericValue<double>,void___cdecl(double),class_rbx::signal<void___cdecl(double)>,class_rbx::signal<void___cdecl(double)>_RBX::NumericValue<double>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189de90);
  return;
}



/* FUNCTION 1735 ; VA 0x00504b40 ; FUN_00504b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504b40(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db17c0(0x70,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_02141ae0,uStack_10),0);
  _DAT_02141418 =
       RBX::Reflection::
       EventDesc<class_RBX::ConstrainedValue<__int64>,void___cdecl(__int64),class_rbx::signal<void___cdecl(__int64)>,class_rbx::signal<void___cdecl(__int64)>_RBX::ConstrainedValue<__int64>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dea0);
  return;
}



/* FUNCTION 1736 ; VA 0x00504ba0 ; FUN_00504ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504ba0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db1a20(0x60,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_02141584,uStack_10),0);
  _DAT_021411b0 =
       RBX::Reflection::
       EventDesc<class_RBX::NumericValue<__int64>,void___cdecl(__int64),class_rbx::signal<void___cdecl(__int64)>,class_rbx::signal<void___cdecl(__int64)>_RBX::NumericValue<__int64>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189deb0);
  return;
}



/* FUNCTION 1737 ; VA 0x00504c00 ; FUN_00504c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504c00(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db1ee0(0x6c,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_02141800,uStack_10),0);
  _DAT_02141338 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_RBX::RbxRay>,void___cdecl(class_RBX::RbxRay),class_rbx::signal<void___cdecl(class_RBX::RbxRay)>,class_rbx::signal<void___cdecl(class_RBX::RbxRay)>_RBX::Value<class_RBX::RbxRay>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dec0);
  return;
}



/* FUNCTION 1738 ; VA 0x00504c60 ; FUN_00504c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504c60(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db23a0(0x6c,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_02141290,uStack_10),0);
  _DAT_021412c8 =
       RBX::Reflection::
       EventDesc<class_RBX::StringValue,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::StringValue::*>
       ::vftable;
  FUN_016f3654(&LAB_0189ded0);
  return;
}



/* FUNCTION 1739 ; VA 0x00504cc0 ; FUN_00504cc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504cc0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db2270(0x5c,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_021414c4,uStack_10),0);
  _DAT_021414fc =
       RBX::Reflection::
       EventDesc<class_RBX::ObjectValue,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ObjectValue::*>
       ::vftable;
  FUN_016f3654(&LAB_0189dee0);
  return;
}



/* FUNCTION 1740 ; VA 0x00504d20 ; FUN_00504d20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504d20(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db2010(0x60,s_changed_021415c4,s_value_0211ab70,0,CONCAT44(&DAT_02141778,uStack_10),0);
  _DAT_02141300 =
       RBX::Reflection::
       EventDesc<class_RBX::Value<class_G3D::Vector3>,void___cdecl(class_G3D::Vector3),class_rbx::signal<void___cdecl(class_G3D::Vector3)>,class_rbx::signal<void___cdecl(class_G3D::Vector3)>_RBX::Value<class_G3D::Vector3>::*>
       ::vftable;
  FUN_016f3654(&LAB_0189def0);
  return;
}



/* FUNCTION 1741 ; VA 0x00504d80 ; FUN_00504d80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504d80(void)

{
  undefined4 extraout_var;
  
  FUN_00db2270(0x5c,s_Changed_0211ac74,s_value_0211ab70,0,0,0,0);
  _DAT_021414c4 =
       RBX::Reflection::
       EventDesc<class_RBX::ObjectValue,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ObjectValue::*>
       ::vftable;
  FUN_016f3654(&LAB_0189df00,extraout_var);
  return;
}



/* FUNCTION 1742 ; VA 0x00504dd0 ; FUN_00504dd0 */

void FUN_00504dd0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00db6230(FUN_00db6720,0,s_AddSubPose_02141ed4,&DAT_02141ecc,0,uStack_10,0);
  FUN_016f3654(&LAB_0189e400);
  return;
}



/* FUNCTION 1743 ; VA 0x00504e30 ; FUN_00504e30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504e30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820dba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00db5c30(uVar2,0);
  FUN_009cb790(uVar1,s_GetSubPoses_02141ec0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02141dc0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::CFramePose,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02141df8 = FUN_00db6ac0;
  _DAT_02141dfc = 0;
  _DAT_02141de4 = FUN_0088cc80();
  FUN_016f3654(&LAB_0189e450);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1744 ; VA 0x00504ed0 ; FUN_00504ed0 */

void FUN_00504ed0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00db6230(FUN_00db6ea0,0,s_RemoveSubPose_02141ee0,&DAT_02141ecc,0,uStack_10,0);
  FUN_016f3654(&LAB_0189e460);
  return;
}



/* FUNCTION 1745 ; VA 0x00504f30 ; FUN_00504f30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00504f30(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820de4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00db7150();
  uVar3 = FUN_00db5d30();
  FUN_009ca670(uVar3,uVar2,s_EasingDirection_02141ea4,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02141d10 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::PoseBase,enum_RBX::Pose::PoseEasingDirection>::
                 vftable;
  _DAT_02141d44 = uVar2;
  DAT_02141d48 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02141d48 == (undefined4 *)0x0) {
    DAT_02141d48 = (undefined4 *)0x0;
  }
  else {
    *DAT_02141d48 =
         RBX::Reflection::PropDescriptor<class_RBX::PoseBase,enum_RBX::Pose::PoseEasingDirection>::
         GetSetImpl<enum_RBX::Pose::PoseEasingDirection_(__thiscall_RBX::PoseBase::*)(void)const_,void_(__thiscall_RBX::PoseBase::*)(enum_RBX::Pose::PoseEasingDirection)>
         ::vftable;
    DAT_02141d48[2] = FUN_008609e0;
    DAT_02141d48[3] = 0;
    DAT_02141d48[4] = FUN_00db6f10;
    DAT_02141d48[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02141d4c = FUN_00db7150();
  cVar1 = (*(code *)DAT_02141d10[3])();
  if (cVar1 != '\0') {
    _DAT_02141d34 = _DAT_02141d34 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02141d10[2])();
  if (cVar1 != '\0') {
    _DAT_02141d34 = _DAT_02141d34 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189e4b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1746 ; VA 0x00505050 ; FUN_00505050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00505050(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820e04;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00db7200();
  uVar3 = FUN_00db5d30();
  FUN_009ca670(uVar3,uVar2,s_EasingStyle_02141e98,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02141cd0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::PoseBase,enum_RBX::Pose::PoseEasingStyle>::vftable;
  _DAT_02141d04 = uVar2;
  DAT_02141d08 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02141d08 == (undefined4 *)0x0) {
    DAT_02141d08 = (undefined4 *)0x0;
  }
  else {
    *DAT_02141d08 =
         RBX::Reflection::PropDescriptor<class_RBX::PoseBase,enum_RBX::Pose::PoseEasingStyle>::
         GetSetImpl<enum_RBX::Pose::PoseEasingStyle_(__thiscall_RBX::PoseBase::*)(void)const_,void_(__thiscall_RBX::PoseBase::*)(enum_RBX::Pose::PoseEasingStyle)>
         ::vftable;
    DAT_02141d08[2] = FUN_00819220;
    DAT_02141d08[3] = 0;
    DAT_02141d08[4] = FUN_00db6f50;
    DAT_02141d08[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02141d0c = FUN_00db7200();
  cVar1 = (*(code *)DAT_02141cd0[3])();
  if (cVar1 != '\0') {
    _DAT_02141cf4 = _DAT_02141cf4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02141cd0[2])();
  if (cVar1 != '\0') {
    _DAT_02141cf4 = _DAT_02141cf4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189e4d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1747 ; VA 0x00505230 ; FUN_00505230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00505230(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820e2c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00db5b30();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PoseTemplate<double>,double>::
              GetSetImpl<double_const_(__thiscall_RBX::PoseTemplate<double>::*)(void)const_,void_(__thiscall_RBX::PoseTemplate<double>::*)(double_const&)>
              ::vftable;
    puVar3[2] = &LAB_00db6c20;
    puVar3[3] = 0;
    puVar3[4] = FUN_00db6f90;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088ca00();
  FUN_009ca670(uVar2,uVar4,s_Value_021415bc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02141ef0 = RBX::Reflection::TypedPropertyDescriptor<double>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02141f24 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02141f14 = _DAT_02141f14 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02141ef0[2])();
    if (cVar1 != '\0') {
      _DAT_02141f14 = _DAT_02141f14 & 0xfffffff3;
    }
  }
  DAT_02141ef0 = RBX::Reflection::PropDescriptor<class_RBX::PoseTemplate<double>,double>::vftable;
  FUN_016f3654(&LAB_0189e510);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1748 ; VA 0x00505360 ; FUN_00505360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00505360(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01820e5c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00db5c30();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::CFramePose,class_G3D::CoordinateFrame>::
              GetSetImpl<class_G3D::CoordinateFrame_const&_(__thiscall_RBX::CFramePose::*)(void)const_,void_(__thiscall_RBX::CFramePose::*)(class_G3D::CoordinateFrame_const&)>
              ::vftable;
    puVar3[2] = &LAB_0074b650;
    puVar3[3] = 0;
    puVar3[4] = FUN_00db6fe0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,s_CFrame_0212a744,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02141d50 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02141d84 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02141d74 = _DAT_02141d74 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02141d50[2])();
    if (cVar1 != '\0') {
      _DAT_02141d74 = _DAT_02141d74 & 0xfffffff3;
    }
  }
  DAT_02141d50 = RBX::Reflection::PropDescriptor<class_RBX::CFramePose,class_G3D::CoordinateFrame>::
                 vftable;
  FUN_016f3654(&LAB_0189e530);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1749 ; VA 0x00505660 ; FUN_00505660 */

void FUN_00505660(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00db81f0(FUN_00db90c0,0,s_GetButton_02142100,s_button_021420d0,0,uStack_10,0);
  FUN_016f3654(&LAB_0189e6a0);
  return;
}


