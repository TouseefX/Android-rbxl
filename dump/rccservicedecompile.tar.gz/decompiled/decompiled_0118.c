/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 29500 ; VA 0x00c84d80 ; FUN_00c84d80 */

undefined4 __thiscall FUN_00c84d80(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = 0;
  do {
    iVar2 = FUN_00c15be0(param_2,param_3,iVar4);
    iVar3 = FUN_0170d75d(iVar2,0,&RBX::Joint::RTTI_Type_Descriptor,
                         &RBX::BodyMover::RTTI_Type_Descriptor,0);
    if (iVar3 != 0) {
      cVar1 = FUN_00892700(*(undefined4 *)(param_1 + 0xc));
      if (cVar1 != '\0') {
        return 1;
      }
    }
    iVar4 = iVar4 + 1;
  } while (iVar2 != 0);
  return 0;
}



/* FUNCTION 29501 ; VA 0x00c84df0 ; FUN_00c84df0 */

void __fastcall FUN_00c84df0(undefined4 param_1)

{
  undefined uStack_5;
  
  (**(code **)(*DAT_02139ac8 + 0x10))(param_1,&uStack_5);
  return;
}



/* FUNCTION 29502 ; VA 0x00c84e10 ; FUN_00c84e10 */

void __thiscall FUN_00c84e10(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x164);
  *param_2 = *(undefined8 *)(param_1 + 0x15c);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 29503 ; VA 0x00c84e30 ; FUN_00c84e30 */

void __thiscall FUN_00c84e30(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x154);
  *param_2 = *(undefined8 *)(param_1 + 0x14c);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 29504 ; VA 0x00c84e50 ; FUN_00c84e50 */

void __thiscall FUN_00c84e50(int param_1,undefined8 *param_2)

{
  int iVar1;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x20) + 0x2c);
  if (iVar1 == 0) {
    uStack_10 = 0;
    uStack_8 = 0;
  }
  else {
    uStack_10 = *(undefined8 *)(iVar1 + 0x164);
    uStack_8 = *(undefined4 *)(iVar1 + 0x16c);
  }
  *param_2 = uStack_10;
  *(undefined4 *)(param_2 + 1) = uStack_8;
  return;
}



/* FUNCTION 29505 ; VA 0x00c84eb0 ; FUN_00c84eb0 */

void __thiscall FUN_00c84eb0(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  iVar1 = *(int *)(param_1 + 0x24);
  if (iVar1 == 0) {
    if ((*(char *)(param_1 + 0x3c) == '\0') ||
       (puVar2 = (undefined4 *)&DAT_01f30758, *(int *)(param_1 + 0x20) == param_1)) {
      puVar2 = (undefined4 *)(param_1 + 0x88);
    }
    uStack_28 = *puVar2;
    uStack_24 = puVar2[1];
    uStack_20 = puVar2[2];
    uStack_1c = puVar2[3];
    uVar4 = puVar2[4];
    uVar5 = puVar2[5];
    uVar6 = puVar2[6];
    uVar7 = puVar2[7];
    uVar3 = puVar2[8];
  }
  else {
    if (*(char *)(iVar1 + 4) != '\0') {
      FUN_00f958d0();
    }
    uStack_28 = *(undefined4 *)(iVar1 + 0x18);
    uStack_24 = *(undefined4 *)(iVar1 + 0x1c);
    uStack_20 = *(undefined4 *)(iVar1 + 0x20);
    uStack_1c = *(undefined4 *)(iVar1 + 0x24);
    uVar3 = *(undefined4 *)(iVar1 + 0x38);
    uVar4 = *(undefined4 *)(iVar1 + 0x28);
    uVar5 = *(undefined4 *)(iVar1 + 0x2c);
    uVar6 = *(undefined4 *)(iVar1 + 0x30);
    uVar7 = *(undefined4 *)(iVar1 + 0x34);
  }
  *param_2 = uStack_28;
  param_2[1] = uStack_24;
  param_2[2] = uStack_20;
  param_2[3] = uStack_1c;
  param_2[4] = uVar4;
  param_2[5] = uVar5;
  param_2[6] = uVar6;
  param_2[7] = uVar7;
  param_2[8] = uVar3;
  return;
}



/* FUNCTION 29506 ; VA 0x00c84f30 ; FUN_00c84f30 */

undefined4 __thiscall FUN_00c84f30(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar1 = *(int *)(param_1 + 0x24);
  if (iVar1 == 0) {
    if ((*(char *)(param_1 + 0x3c) == '\0') ||
       (puVar2 = (undefined4 *)&DAT_01f30758, *(int *)(param_1 + 0x20) == param_1)) {
      puVar2 = (undefined4 *)(param_1 + 0x88);
    }
    uStack_28 = *puVar2;
    uStack_24 = puVar2[1];
    uStack_20 = puVar2[2];
    uStack_1c = puVar2[3];
    uStack_3c = puVar2[4];
    uStack_38 = puVar2[5];
    uStack_34 = puVar2[6];
    uStack_30 = puVar2[7];
    uStack_2c = puVar2[8];
  }
  else {
    if (*(char *)(iVar1 + 4) != '\0') {
      FUN_00f958d0();
    }
    uStack_28 = *(undefined4 *)(iVar1 + 0x18);
    uStack_24 = *(undefined4 *)(iVar1 + 0x1c);
    uStack_20 = *(undefined4 *)(iVar1 + 0x20);
    uStack_1c = *(undefined4 *)(iVar1 + 0x24);
    uStack_2c = *(undefined4 *)(iVar1 + 0x38);
    uStack_3c = *(undefined4 *)(iVar1 + 0x28);
    uStack_38 = *(undefined4 *)(iVar1 + 0x2c);
    uStack_34 = *(undefined4 *)(iVar1 + 0x30);
    uStack_30 = *(undefined4 *)(iVar1 + 0x34);
  }
  uStack_4c = uStack_28;
  uStack_48 = uStack_24;
  uStack_44 = uStack_20;
  uStack_40 = uStack_1c;
  uStack_18 = uStack_3c;
  uStack_14 = uStack_38;
  uStack_10 = uStack_34;
  uStack_c = uStack_30;
  uStack_8 = uStack_2c;
  FUN_00c955f0(param_2,&uStack_4c);
  return param_2;
}



/* FUNCTION 29507 ; VA 0x00c84fc0 ; FUN_00c84fc0 */

void __thiscall FUN_00c84fc0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 0x164);
  uVar2 = *(undefined4 *)(param_1 + 0x168);
  uVar3 = *(undefined4 *)(param_1 + 0x16c);
  *param_2 = *(undefined4 *)(param_1 + 0x160);
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0x174);
  uVar2 = *(undefined4 *)(param_1 + 0x178);
  uVar3 = *(undefined4 *)(param_1 + 0x17c);
  param_2[4] = *(undefined4 *)(param_1 + 0x170);
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0x184);
  uVar2 = *(undefined4 *)(param_1 + 0x188);
  uVar3 = *(undefined4 *)(param_1 + 0x18c);
  param_2[8] = *(undefined4 *)(param_1 + 0x180);
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  return;
}



/* FUNCTION 29508 ; VA 0x00c84ff0 ; FUN_00c84ff0 */

void FUN_00c84ff0(void)

{
  int iVar1;
  
  if (DAT_01f00084 == 0) {
    iVar1 = FUN_00c80610();
    DAT_01f00084 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29509 ; VA 0x00c85010 ; FUN_00c85010 */

void FUN_00c85010(void)

{
  int iVar1;
  
  if (DAT_01f00d44 == 0) {
    iVar1 = FUN_00c80310();
    DAT_01f00d44 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29510 ; VA 0x00c85030 ; FUN_00c85030 */

void FUN_00c85030(void)

{
  int iVar1;
  
  if (DAT_01f004c4 == 0) {
    iVar1 = FUN_00c80410();
    DAT_01f004c4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29511 ; VA 0x00c85050 ; FUN_00c85050 */

void FUN_00c85050(void)

{
  int iVar1;
  
  if (DAT_01f002a4 == 0) {
    iVar1 = FUN_00c80510();
    DAT_01f002a4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29512 ; VA 0x00c85070 ; FUN_00c85070 */

void FUN_00c85070(void)

{
  int iVar1;
  
  if (DAT_01f00904 == 0) {
    iVar1 = FUN_00c806f0();
    DAT_01f00904 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29513 ; VA 0x00c85090 ; FUN_00c85090 */

void FUN_00c85090(void)

{
  int iVar1;
  
  if (DAT_01f006e4 == 0) {
    iVar1 = FUN_00c807f0();
    DAT_01f006e4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29514 ; VA 0x00c850b0 ; FUN_00c850b0 */

void FUN_00c850b0(void)

{
  int iVar1;
  
  if (DAT_01f00b24 == 0) {
    iVar1 = FUN_00c808f0();
    DAT_01f00b24 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29515 ; VA 0x00c850d0 ; FUN_00c850d0 */

void FUN_00c850d0(void)

{
  int iVar1;
  
  if (DAT_01f00f64 == 0) {
    iVar1 = FUN_00c809f0();
    DAT_01f00f64 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29516 ; VA 0x00c850f0 ; FUN_00c850f0 */

uint __fastcall FUN_00c850f0(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined auStack_10 [4];
  int *piStack_c;
  int iStack_8;
  
  iStack_8 = param_1 + 0xf0;
  piVar3 = (int *)FUN_00587490(auStack_10);
  piVar4 = piStack_c;
  iVar1 = *piVar3;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar2 = *piVar3 + -1;
      *piVar3 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (iVar1 != 0) {
    piVar4 = (int *)FUN_00587490(auStack_10);
    iVar1 = *(int *)(*piVar4 + 0xa8);
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[1] + -1;
      piStack_c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar4 = piStack_c + 2;
        iVar2 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
    return -(uint)(iVar1 != 0) & iVar1 + 0x50U;
  }
  return 0;
}



/* FUNCTION 29517 ; VA 0x00c85190 ; FUN_00c85190 */

void __thiscall FUN_00c85190(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x184);
  *param_2 = *(undefined8 *)(param_1 + 0x17c);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 29518 ; VA 0x00c851b0 ; FUN_00c851b0 */

void __thiscall FUN_00c851b0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x170);
  *param_2 = *(undefined8 *)(param_1 + 0x168);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 29519 ; VA 0x00c851d0 ; FUN_00c851d0 */

void __thiscall FUN_00c851d0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x160);
  *param_2 = *(undefined8 *)(param_1 + 0x158);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 29520 ; VA 0x00c851f0 ; FUN_00c851f0 */

void __thiscall FUN_00c851f0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x16c);
  *param_2 = *(undefined8 *)(param_1 + 0x164);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 29521 ; VA 0x00c85210 ; FUN_00c85210 */

void __thiscall FUN_00c85210(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x158);
  *param_2 = *(undefined8 *)(param_1 + 0x150);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 29522 ; VA 0x00c85230 ; FUN_00c85230 */

void __thiscall FUN_00c85230(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x15c);
  *param_2 = *(undefined8 *)(param_1 + 0x154);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 29523 ; VA 0x00c85250 ; FUN_00c85250 */

void __thiscall FUN_00c85250(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x178);
  *param_2 = *(undefined8 *)(param_1 + 0x170);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 29524 ; VA 0x00c85280 ; FUN_00c85280 */

uint FUN_00c85280(void)

{
  int iVar1;
  
  iVar1 = FUN_00c80310();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29525 ; VA 0x00c852a0 ; FUN_00c852a0 */

uint FUN_00c852a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c80410();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29526 ; VA 0x00c852c0 ; FUN_00c852c0 */

uint FUN_00c852c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c80510();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29527 ; VA 0x00c852e0 ; FUN_00c852e0 */

uint FUN_00c852e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c806f0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29528 ; VA 0x00c85300 ; FUN_00c85300 */

uint FUN_00c85300(void)

{
  int iVar1;
  
  iVar1 = FUN_00c807f0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29529 ; VA 0x00c85320 ; FUN_00c85320 */

uint FUN_00c85320(void)

{
  int iVar1;
  
  iVar1 = FUN_00c808f0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29530 ; VA 0x00c85340 ; FUN_00c85340 */

uint FUN_00c85340(void)

{
  int iVar1;
  
  iVar1 = FUN_00c809f0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29531 ; VA 0x00c85360 ; FUN_00c85360 */

uint FUN_00c85360(void)

{
  int iVar1;
  
  iVar1 = FUN_00c80310();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29532 ; VA 0x00c85380 ; FUN_00c85380 */

uint FUN_00c85380(void)

{
  int iVar1;
  
  iVar1 = FUN_00c80410();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29533 ; VA 0x00c853a0 ; FUN_00c853a0 */

uint FUN_00c853a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c80510();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29534 ; VA 0x00c853c0 ; FUN_00c853c0 */

uint FUN_00c853c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c806f0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29535 ; VA 0x00c853e0 ; FUN_00c853e0 */

uint FUN_00c853e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c807f0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29536 ; VA 0x00c85400 ; FUN_00c85400 */

uint FUN_00c85400(void)

{
  int iVar1;
  
  iVar1 = FUN_00c808f0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29537 ; VA 0x00c85420 ; FUN_00c85420 */

uint FUN_00c85420(void)

{
  int iVar1;
  
  iVar1 = FUN_00c809f0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29538 ; VA 0x00c85440 ; FUN_00c85440 */

int * __thiscall FUN_00c85440(int *param_1,int *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f410;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a3ee0(param_2);
  piStack_1c = (int *)0x0;
  piStack_14 = (int *)0x0;
  uStack_18 = uStack_18 & 0xffffff00;
  if ((int *)*param_2 == param_1) {
    piStack_1c = (int *)param_2[2];
    if (piStack_1c != (int *)0x0) {
      iVar7 = piStack_1c[3];
      iVar4 = FUN_00aff8c0();
      if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        puVar5 = (undefined4 *)FUN_00587490(auStack_28);
        piVar6 = piStack_24;
        piStack_14 = (int *)*puVar5;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar7 = piStack_24[1] + -1;
          piStack_24[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            piVar1 = piVar6 + 2;
            iVar7 = *piVar1 + -1;
            *piVar1 = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        uStack_18 = CONCAT31(uStack_18._1_3_,piStack_1c != piStack_14);
        piVar6 = (int *)FUN_0060dcd0(auStack_28,piStack_1c);
        iVar7 = piVar6[1];
        if (iVar7 != 0) {
          LOCK();
          *(int *)(iVar7 + 8) = *(int *)(iVar7 + 8) + 1;
          UNLOCK();
          iVar7 = piVar6[1];
        }
        param_1[0x51] = *piVar6;
        piVar6 = (int *)param_1[0x52];
        param_1[0x52] = iVar7;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar7 = piVar6[2] + -1;
          piVar6[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
        piVar6 = piStack_24;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar7 = piStack_24[1] + -1;
          piStack_24[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            piVar1 = piVar6 + 2;
            iVar7 = *piVar1 + -1;
            *piVar1 = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        piVar6 = (int *)FUN_00587490(auStack_28);
        uStack_8 = 0;
        goto LAB_00c8557b;
      }
    }
    piStack_1c = (int *)0x0;
  }
  else {
    piVar6 = (int *)FUN_00587490(auStack_28);
    uStack_8 = 1;
LAB_00c8557b:
    if (*piVar6 == 0) {
      piStack_14 = (int *)0x0;
    }
    else {
      piStack_14 = (int *)FUN_00a9d3f0(param_1);
    }
    piVar6 = piStack_24;
    uStack_8 = 0xffffffff;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_24[1] + -1;
      piStack_24[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar7 = *piVar1 + -1;
        *piVar1 = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  piVar1 = piStack_14;
  piVar6 = (int *)param_1[0x50];
  if (((piVar6 == piStack_14) && (piVar6 != (int *)0x0)) && (param_1[0x16] != 0)) {
    FUN_00c3dac0(param_1 + 0x15,0,uStack_18);
    piVar6 = (int *)param_1[0x50];
  }
  if ((piVar6 != (int *)0x0) && (piVar1 == (int *)0x0)) {
    if (param_1[0x16] != 0) {
      FUN_00c3dac0(param_1 + 0x15,0,uStack_18);
    }
    FUN_00ca4900(0,0);
    FUN_00ca4900(1,0);
  }
  param_1[0x50] = (int)piVar1;
  if (piVar1 != (int *)0x0) {
    piVar6 = (int *)FUN_00587490(auStack_28);
    piStack_14 = *(int **)(*piVar6 + 0xa8);
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_24[1] + -1;
      piStack_24[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar7 = piStack_24[2] + -1;
        piStack_24[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    uVar2 = *(undefined4 *)(param_1[0x50] + 0xd4);
    FUN_00ca4900(0,piStack_14);
    FUN_00ca4900(1,uVar2);
    piVar6 = piStack_14;
    cVar3 = (**(code **)(*param_1 + 0xa4))(piStack_14,uVar2);
    if (cVar3 == '\0') {
      FUN_00c3dac0(param_1 + 0x15,param_1[0x50],uStack_18);
      if (piVar6[0x6a] != 0) {
        FUN_00bc1c10(piVar6,0);
      }
    }
  }
  if (((int *)*param_2 == param_1) && (piStack_1c == (int *)0x0)) {
    param_2 = (int *)FUN_0060dcd0(auStack_20,0);
    iVar7 = param_2[1];
    if (iVar7 != 0) {
      LOCK();
      *(int *)(iVar7 + 8) = *(int *)(iVar7 + 8) + 1;
      UNLOCK();
      iVar7 = param_2[1];
    }
    param_2 = (int *)*param_2;
    param_1[0x51] = (int)param_2;
    piVar6 = (int *)param_1[0x52];
    param_1[0x52] = iVar7;
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 2;
      iVar7 = *piVar1;
      param_2 = (int *)*piVar1;
      *piVar1 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        param_2 = (int *)(**(code **)(*piVar6 + 4))();
      }
    }
    piVar6 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar7 = *piVar1;
      param_2 = (int *)*piVar1;
      *piVar1 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        param_2 = (int *)(**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          param_2 = (int *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29539 ; VA 0x00c857a0 ; FUN_00c857a0 */

void * __fastcall FUN_00c857a0(int param_1)

{
  int iVar1;
  int *piVar2;
  void *pvVar3;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  pvVar3 = ExceptionList;
  if (*(int *)(param_1 + 0x140) != 0) {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_00587490(auStack_18);
    uStack_8 = 0;
    pvVar3 = (void *)FUN_00bc1c10(*(undefined4 *)(*piVar2 + 0xa8),1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_14 + 1;
      iVar1 = *piVar2;
      pvVar3 = (void *)*piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        pvVar3 = (void *)(**(code **)*piStack_14)();
        LOCK();
        piVar2 = piStack_14 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          pvVar3 = (void *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 29540 ; VA 0x00c85830 ; FUN_00c85830 */

void FUN_00c85830(undefined4 param_1,undefined4 param_2)

{
  FUN_008a4210(param_1,param_2);
  FUN_00f958f0(param_1,param_2);
  return;
}



/* FUNCTION 29541 ; VA 0x00c85860 ; FUN_00c85860 */

int * __fastcall FUN_00c85860(int param_1)

{
  float *pfVar1;
  int *piVar2;
  undefined8 uVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  bool bVar8;
  float fVar9;
  float fStack_28;
  float fStack_24;
  undefined auStack_1c [4];
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af1f8;
  pvStack_10 = ExceptionList;
  bVar8 = false;
  piStack_18 = (int *)0x0;
  piVar6 = (int *)ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + -0xc) != 0) {
    ExceptionList = &pvStack_10;
    piVar6 = (int *)FUN_00587490(auStack_1c);
    bVar8 = true;
    if ((*piVar6 != 0) && (cStack_11 = '\x01', *(char *)(param_1 + 0x3c) == '\0'))
    goto LAB_00c858ad;
  }
  cStack_11 = '\0';
LAB_00c858ad:
  piVar4 = piStack_18;
  if ((bVar8) && (piStack_18 != (int *)0x0)) {
    LOCK();
    pfVar1 = (float *)(piStack_18 + 1);
    fVar9 = *pfVar1;
    piVar6 = (int *)*pfVar1;
    *pfVar1 = (float)((int)fVar9 + -1);
    UNLOCK();
    if ((float)((int)fVar9 + -1) == 0.0) {
      (**(code **)*piStack_18)();
      LOCK();
      pfVar1 = (float *)(piVar4 + 2);
      fVar9 = *pfVar1;
      piVar6 = (int *)*pfVar1;
      *pfVar1 = (float)((int)fVar9 + -1);
      UNLOCK();
      if ((float)((int)fVar9 + -1) == 0.0) {
        piVar6 = (int *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (cStack_11 != '\0') {
    FUN_00587490(auStack_1c);
    uStack_8 = 0;
    iVar7 = FUN_00b077e0();
    piVar5 = piStack_18;
    uStack_8 = 0xffffffff;
    uVar3 = *(undefined8 *)(iVar7 + 0x24);
    piVar4 = *(int **)(iVar7 + 0x2c);
    piVar6 = piVar4;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      pfVar1 = (float *)(piStack_18 + 1);
      fVar9 = *pfVar1;
      piVar6 = (int *)*pfVar1;
      *pfVar1 = (float)((int)fVar9 + -1);
      UNLOCK();
      if ((float)((int)fVar9 + -1) == 0.0) {
        piVar6 = (int *)(**(code **)*piStack_18)();
        LOCK();
        piVar2 = piVar5 + 2;
        iVar7 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          piVar6 = (int *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
    fStack_24 = (float)((ulonglong)uVar3 >> 0x20);
    fStack_28 = (float)uVar3;
    fStack_28 = fStack_28 - *(float *)(param_1 + 0x24);
    fStack_24 = fStack_24 - *(float *)(param_1 + 0x28);
    fVar9 = (float)piVar4 - *(float *)(param_1 + 0x2c);
    if (fStack_28 * fStack_28 + fStack_24 * fStack_24 + fVar9 * fVar9 <= DAT_01971798) {
      piVar6 = (int *)FUN_006eccd0();
      *(undefined *)(param_1 + 0x3c) = 1;
    }
  }
  ExceptionList = pvStack_10;
  return piVar6;
}



/* FUNCTION 29542 ; VA 0x00c859a0 ; FUN_00c859a0 */

int * __fastcall FUN_00c859a0(int param_1)

{
  int *piVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  undefined8 uVar5;
  int *piVar6;
  int iVar7;
  float *pfVar8;
  bool bVar9;
  float fVar10;
  undefined8 uStack_38;
  int *piStack_30;
  float fStack_2c;
  float fStack_28;
  undefined8 uStack_20;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af1f8;
  pvStack_10 = ExceptionList;
  bVar9 = false;
  piStack_18 = (int *)0x0;
  piStack_30 = (int *)ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + -0xc) != 0) {
    ExceptionList = &pvStack_10;
    piStack_30 = (int *)FUN_00587490((int)&uStack_20 + 4);
    bVar9 = true;
    if (((*piStack_30 != 0) && (*(char *)(param_1 + 0xc) != '\0')) &&
       (cStack_11 = '\x01', *(char *)(param_1 + 0x28) == '\0')) goto LAB_00c859f3;
  }
  cStack_11 = '\0';
LAB_00c859f3:
  piVar6 = piStack_18;
  if ((bVar9) && (piStack_18 != (int *)0x0)) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar7 = *piVar1;
    piStack_30 = (int *)*piVar1;
    *piVar1 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar7 = *piVar1;
      piStack_30 = (int *)*piVar1;
      *piVar1 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        piStack_30 = (int *)(**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (cStack_11 != '\0') {
    FUN_00587490((int)&uStack_20 + 4);
    uStack_8 = 0;
    iVar7 = FUN_00b077e0();
    piVar6 = piStack_18;
    uStack_8 = 0xffffffff;
    uVar5 = *(undefined8 *)(iVar7 + 0x24);
    fVar10 = *(float *)(iVar7 + 0x2c);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_18[1] + -1;
      piStack_18[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0x10) == 0) {
      uStack_38 = *(undefined8 *)(param_1 + 0x18);
      piStack_30 = *(int **)(param_1 + 0x20);
    }
    else {
      pfVar8 = (float *)FUN_00b077e0();
      fVar2 = *(float *)(param_1 + 0x18);
      fVar3 = *(float *)(param_1 + 0x1c);
      fVar4 = *(float *)(param_1 + 0x20);
      uStack_38 = CONCAT44(pfVar8[3] * fVar2 + pfVar8[4] * fVar3 + pfVar8[5] * fVar4 + pfVar8[10],
                           pfVar8[1] * fVar3 + fVar2 * *pfVar8 + pfVar8[2] * fVar4 + pfVar8[9]);
      piStack_30 = (int *)(pfVar8[6] * fVar2 + pfVar8[7] * fVar3 + pfVar8[8] * fVar4 + pfVar8[0xb]);
    }
    fStack_2c = (float)uVar5;
    fStack_28 = (float)((ulonglong)uVar5 >> 0x20);
    uStack_20 = uStack_38;
    uVar5 = uStack_20;
    uStack_20._4_4_ = (float)((ulonglong)uStack_38 >> 0x20);
    uStack_20._0_4_ = (float)uStack_38;
    piStack_18 = piStack_30;
    fVar10 = fVar10 - (float)piStack_30;
    if ((fStack_28 - uStack_20._4_4_) * (fStack_28 - uStack_20._4_4_) +
        (fStack_2c - (float)uStack_20) * (fStack_2c - (float)uStack_20) + fVar10 * fVar10 <=
        *(float *)(param_1 + 0x24) * *(float *)(param_1 + 0x24)) {
      uStack_20 = uVar5;
      piStack_30 = (int *)FUN_006eccd0();
      *(undefined *)(param_1 + 0x28) = 1;
    }
  }
  ExceptionList = pvStack_10;
  return piStack_30;
}



/* FUNCTION 29543 ; VA 0x00c85bb0 ; FUN_00c85bb0 */

void __thiscall FUN_00c85bb0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f437;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00cc2c00(param_2);
  puVar5 = *(undefined4 **)(param_1 + 0x120);
  if (puVar5 != (undefined4 *)0x0) {
    piVar3 = (int *)(*(int *)(param_1 + 0x2c) + 0x68);
    if (*(int *)(param_1 + 0x2c) == 0) {
      piVar3 = (int *)&DAT_00000018;
    }
    if ((*(int *)(puVar5[2] + 0x18) == *piVar3) && (*(int *)(puVar5[2] + 0x1c) == piVar3[1])) {
      piVar3 = (int *)(*(int *)(param_1 + 0x30) + 0x68);
      if (*(int *)(param_1 + 0x30) == 0) {
        piVar3 = (int *)&DAT_00000018;
      }
      if ((*(int *)(puVar5[3] + 0x18) == *piVar3) && (*(int *)(puVar5[3] + 0x1c) == piVar3[1]))
      goto LAB_00c85c3d;
    }
    (**(code **)*puVar5)(1);
    *(undefined4 *)(param_1 + 0x120) = 0;
  }
LAB_00c85c3d:
  uVar4 = FUN_01675290(DAT_01f04e08);
  uStack_8 = 0;
  if (*(int *)(param_1 + 0x120) == 0) {
    iVar1 = *(int *)(param_1 + 0x2c);
    iVar2 = *(int *)(param_1 + 0x30);
    puVar5 = (undefined4 *)FUN_01674e20(0x58);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      FUN_00c81f60(0x14,-(uint)(iVar1 != 0) & iVar1 + 0x50U,-(uint)(iVar2 != 0) & iVar2 + 0x50U,3,0)
      ;
      *puVar5 = RBX::Solver::ConstraintLegacyGyroAngularVelocity::vftable;
      puVar5[0xc] = 0;
      puVar5[0xd] = 0;
      puVar5[0xe] = 0;
      puVar5[0xf] = 0;
      puVar5[0x10] = 0;
      puVar5[0x11] = 0;
      puVar5[0x12] = 0;
      puVar5[0x13] = 0;
      puVar5[0x14] = 0;
      *(undefined *)(puVar5 + 0x15) = 0;
    }
    *(undefined4 **)(param_1 + 0x120) = puVar5;
  }
  uStack_8 = 2;
  FUN_01675290(uVar4);
  uStack_8 = 0xffffffff;
  (**(code **)(**(int **)(param_2 + 0x2c) + 0xc))(*(undefined4 *)(param_1 + 0x120));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29544 ; VA 0x00c85d40 ; FUN_00c85d40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c85d40(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f46a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00cc2c00(param_2);
  iVar1 = *(int *)(param_1 + 0x178);
  if (iVar1 != 0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x2c) + 0x68);
    if (*(int *)(param_1 + 0x2c) == 0) {
      piVar6 = (int *)&DAT_00000018;
    }
    if ((*(int *)(*(int *)(iVar1 + 8) + 0x18) == *piVar6) &&
       (*(int *)(*(int *)(iVar1 + 8) + 0x1c) == piVar6[1])) {
      piVar6 = (int *)(*(int *)(param_1 + 0x30) + 0x68);
      if (*(int *)(param_1 + 0x30) == 0) {
        piVar6 = (int *)&DAT_00000018;
      }
      if ((*(int *)(*(int *)(iVar1 + 0xc) + 0x18) == *piVar6) &&
         (*(int *)(*(int *)(iVar1 + 0xc) + 0x1c) == piVar6[1])) goto LAB_00c85ddb;
    }
    FUN_00ca3cc0();
    if (*(undefined4 **)(param_1 + 0x178) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(param_1 + 0x178))(1);
    }
    *(undefined4 *)(param_1 + 0x178) = 0;
  }
LAB_00c85ddb:
  uVar7 = FUN_01675290(DAT_01f04e08);
  iStack_8 = 0;
  if (*(int *)(param_1 + 0x178) == 0) {
    iVar1 = *(int *)(param_1 + 0x2c);
    iVar2 = *(int *)(param_1 + 0x30);
    puVar8 = (undefined4 *)FUN_01674e20(0x80);
    iStack_8._0_1_ = 1;
    if (puVar8 == (undefined4 *)0x0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      FUN_00c81f60(0xe,-(uint)(iVar1 != 0) & iVar1 + 0x50U,-(uint)(iVar2 != 0) & iVar2 + 0x50U,3,0);
      *puVar8 = RBX::Solver::ConstraintBodyAngularVelocity::vftable;
      puVar8[0xc] = 0;
      puVar8[0xd] = 0;
      puVar8[0xe] = 0;
      puVar8[0xf] = 0;
      puVar8[0x10] = 0;
      puVar8[0x11] = 0;
      puVar8[0x12] = 0;
      puVar8[0x13] = 0;
      puVar8[0x14] = 0;
      uVar5 = _DAT_01d71e68;
      uVar4 = uRam01d71e64;
      uVar3 = uRam01d71e60;
      puVar8[0x15] = _DAT_01d71e5c;
      puVar8[0x16] = uVar3;
      puVar8[0x17] = uVar4;
      puVar8[0x18] = uVar5;
      uVar5 = uRam01d71e78;
      uVar4 = _DAT_01d71e74;
      uVar3 = uRam01d71e70;
      puVar8[0x19] = _DAT_01d71e6c;
      puVar8[0x1a] = uVar3;
      puVar8[0x1b] = uVar4;
      puVar8[0x1c] = uVar5;
      puVar8[0x1d] = DAT_01d71e7c;
      *(undefined2 *)(puVar8 + 0x1e) = 2;
      *(undefined *)((int)puVar8 + 0x7a) = 1;
    }
    *(undefined4 **)(param_1 + 0x178) = puVar8;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_00ca3cf0();
  }
  iStack_8 = 2;
  FUN_01675290(uVar7);
  iStack_8 = 0xffffffff;
  (**(code **)(**(int **)(param_2 + 0x2c) + 0xc))(*(undefined4 *)(param_1 + 0x178));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29545 ; VA 0x00c85f10 ; FUN_00c85f10 */

void FUN_00c85f10(void)

{
  FUN_00cc2c00();
  return;
}



/* FUNCTION 29546 ; VA 0x00c85f20 ; FUN_00c85f20 */

void __thiscall FUN_00c85f20(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f497;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00cc2c00(param_2);
  if (*(int *)(param_1 + 0xec) == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar1 = *(int *)(param_1 + 0x104);
  if (iVar1 != 0) {
    piVar3 = (int *)(*(int *)(param_1 + 0x2c) + 0x68);
    if (*(int *)(param_1 + 0x2c) == 0) {
      piVar3 = (int *)&DAT_00000018;
    }
    if ((*(int *)(*(int *)(iVar1 + 8) + 0x18) == *piVar3) &&
       (*(int *)(*(int *)(iVar1 + 8) + 0x1c) == piVar3[1])) {
      piVar3 = (int *)(*(int *)(param_1 + 0x30) + 0x68);
      if (*(int *)(param_1 + 0x30) == 0) {
        piVar3 = (int *)&DAT_00000018;
      }
      if ((*(int *)(*(int *)(iVar1 + 0xc) + 0x18) == *piVar3) &&
         (*(int *)(*(int *)(iVar1 + 0xc) + 0x1c) == piVar3[1])) goto LAB_00c85fc9;
    }
    FUN_00ca3cc0();
    if (*(undefined4 **)(param_1 + 0x104) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(param_1 + 0x104))(1);
    }
    *(undefined4 *)(param_1 + 0x104) = 0;
  }
LAB_00c85fc9:
  uVar4 = FUN_01675290(DAT_01f04e08);
  iStack_8 = 0;
  if ((*(int *)(param_1 + 0xec) != 0) && (*(int *)(param_1 + 0x104) == 0)) {
    iVar1 = *(int *)(param_1 + 0x2c);
    iVar2 = *(int *)(param_1 + 0x30);
    puVar5 = (undefined4 *)FUN_01674e20(0x60);
    iStack_8._0_1_ = 1;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      FUN_00c81f60(0x11,-(uint)(iVar1 != 0) & iVar1 + 0x50U,-(uint)(iVar2 != 0) & iVar2 + 0x50U,3,0)
      ;
      *puVar5 = RBX::Solver::ConstraintLinearSpring::vftable;
      puVar5[0xc] = 0;
      puVar5[0xd] = 0;
      puVar5[0xe] = 0;
      puVar5[0xf] = 0;
      puVar5[0x10] = 0;
      puVar5[0x11] = 0;
      puVar5[0x12] = 0;
      puVar5[0x13] = 0;
      puVar5[0x14] = 0;
      puVar5[0x15] = 0;
      puVar5[0x16] = 0;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    *(undefined4 **)(param_1 + 0x104) = puVar5;
    FUN_00ca3cf0();
  }
  iStack_8 = 2;
  FUN_01675290(uVar4);
  iStack_8 = 0xffffffff;
  (**(code **)(**(int **)(param_2 + 0x2c) + 0xc))(*(undefined4 *)(param_1 + 0x104));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29547 ; VA 0x00c860f0 ; FUN_00c860f0 */

void __thiscall FUN_00c860f0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f4c7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00cc2c00(param_2);
  puVar5 = *(undefined4 **)(param_1 + 0x120);
  if (puVar5 != (undefined4 *)0x0) {
    piVar3 = (int *)(*(int *)(param_1 + 0x2c) + 0x68);
    if (*(int *)(param_1 + 0x2c) == 0) {
      piVar3 = (int *)&DAT_00000018;
    }
    if ((*(int *)(puVar5[2] + 0x18) == *piVar3) && (*(int *)(puVar5[2] + 0x1c) == piVar3[1])) {
      piVar3 = (int *)(*(int *)(param_1 + 0x30) + 0x68);
      if (*(int *)(param_1 + 0x30) == 0) {
        piVar3 = (int *)&DAT_00000018;
      }
      if ((*(int *)(puVar5[3] + 0x18) == *piVar3) && (*(int *)(puVar5[3] + 0x1c) == piVar3[1]))
      goto LAB_00c8617d;
    }
    (**(code **)*puVar5)(1);
    *(undefined4 *)(param_1 + 0x120) = 0;
  }
LAB_00c8617d:
  uVar4 = FUN_01675290(DAT_01f04e08);
  uStack_8 = 0;
  if (*(int *)(param_1 + 0x120) == 0) {
    iVar1 = *(int *)(param_1 + 0x2c);
    iVar2 = *(int *)(param_1 + 0x30);
    puVar5 = (undefined4 *)FUN_01674e20(0x48);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      FUN_00c81f60(10,-(uint)(iVar1 != 0) & iVar1 + 0x50U,-(uint)(iVar2 != 0) & iVar2 + 0x50U,3,0);
      *puVar5 = RBX::Solver::ConstraintLinearVelocity::vftable;
      puVar5[0xc] = 0;
      puVar5[0xd] = 0;
      puVar5[0xe] = 0;
      puVar5[0xf] = 0;
      puVar5[0x10] = 0;
      puVar5[0x11] = 0;
    }
    *(undefined4 **)(param_1 + 0x120) = puVar5;
  }
  uStack_8 = 2;
  FUN_01675290(uVar4);
  uStack_8 = 0xffffffff;
  (**(code **)(**(int **)(param_2 + 0x2c) + 0xc))(*(undefined4 *)(param_1 + 0x120));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29548 ; VA 0x00c86270 ; FUN_00c86270 */

void FUN_00c86270(void)

{
  int iVar1;
  
  if (DAT_01f002a4 == 0) {
    iVar1 = FUN_00c80510();
    DAT_01f002a4 = *(int *)(iVar1 + 4);
  }
  if (DAT_01f00904 == 0) {
    iVar1 = FUN_00c806f0();
    DAT_01f00904 = *(int *)(iVar1 + 4);
  }
  if (DAT_01f00b24 == 0) {
    iVar1 = FUN_00c808f0();
    DAT_01f00b24 = *(int *)(iVar1 + 4);
  }
  if (DAT_01f00d44 == 0) {
    iVar1 = FUN_00c80310();
    DAT_01f00d44 = *(int *)(iVar1 + 4);
  }
  if (DAT_01f004c4 == 0) {
    iVar1 = FUN_00c80410();
    DAT_01f004c4 = *(int *)(iVar1 + 4);
  }
  if (DAT_01f006e4 == 0) {
    iVar1 = FUN_00c807f0();
    DAT_01f006e4 = *(int *)(iVar1 + 4);
  }
  if (DAT_01f00f64 == 0) {
    iVar1 = FUN_00c809f0();
    DAT_01f00f64 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29549 ; VA 0x00c86310 ; FUN_00c86310 */

void __fastcall FUN_00c86310(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x120) != 0) {
    iVar1 = FUN_00ffd7b0();
    (**(code **)(**(int **)(iVar1 + 0x2c) + 0x10))(*(undefined4 *)(param_1 + 0x120));
  }
  FUN_00cc2c30();
  return;
}



/* FUNCTION 29550 ; VA 0x00c86340 ; FUN_00c86340 */

void __fastcall FUN_00c86340(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x178) != 0) {
    iVar1 = FUN_00ffd7b0();
    (**(code **)(**(int **)(iVar1 + 0x2c) + 0x10))(*(undefined4 *)(param_1 + 0x178));
  }
  FUN_00cc2c30();
  return;
}



/* FUNCTION 29551 ; VA 0x00c86370 ; thunk_FUN_00cc2c30 */

void __fastcall thunk_FUN_00cc2c30(int param_1)

{
  FUN_00ffd7b0();
  FUN_00f38340(-(uint)(param_1 != 0) & param_1 + 0xa8U);
  FUN_00ffd7f0();
  return;
}



/* FUNCTION 29552 ; VA 0x00c86380 ; FUN_00c86380 */

void __fastcall FUN_00c86380(int param_1)

{
  int iVar1;
  
  if ((*(int *)(param_1 + 0xec) != 0) && (*(int *)(param_1 + 0x104) != 0)) {
    iVar1 = FUN_00ffd7b0();
    (**(code **)(**(int **)(iVar1 + 0x2c) + 0x10))(*(undefined4 *)(param_1 + 0x104));
  }
  FUN_00cc2c30();
  return;
}



/* FUNCTION 29553 ; VA 0x00c863b0 ; FUN_00c863b0 */

int __thiscall FUN_00c863b0(int param_1,float param_2,float param_3,float param_4)

{
  float *pfVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  if (((NAN(param_2) || NAN(*(float *)(param_1 + 0x15c))) !=
       (param_2 == *(float *)(param_1 + 0x15c))) &&
     ((NAN(param_3) || NAN(*(float *)(param_1 + 0x160))) != (param_3 == *(float *)(param_1 + 0x160))
     )) {
    pfVar1 = (float *)(param_1 + 0x164);
    if ((NAN(param_4) || NAN(*pfVar1)) != (param_4 == *pfVar1)) {
      return CONCAT22((short)((uint)ExceptionList >> 0x10),
                      CONCAT11((param_4 == *pfVar1) << 6 | (NAN(param_4) || NAN(*pfVar1)) << 2 | 2U
                               | param_4 < *pfVar1,(char)ExceptionList));
    }
  }
  ExceptionList = &pvStack_10;
  *(ulonglong *)(param_1 + 0x15c) = CONCAT44(param_3,param_2);
  *(float *)(param_1 + 0x164) = param_4;
  iVar3 = FUN_008a4940(&DAT_01effca8);
  if (*(int *)(param_1 + 0x140) != 0) {
    piVar4 = (int *)FUN_00587490(auStack_18);
    uStack_8 = 0;
    iVar3 = FUN_00bc1c10(*(undefined4 *)(*piVar4 + 0xa8),1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_14 + 1;
      iVar2 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar4 = piStack_14 + 2;
        iVar2 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29554 ; VA 0x00c86490 ; FUN_00c86490 */

void __thiscall FUN_00c86490(int param_1,float param_2,float param_3,float param_4)

{
  if ((((NAN(param_2) || NAN(*(float *)(param_1 + 0x14c))) ==
        (param_2 == *(float *)(param_1 + 0x14c))) ||
      ((NAN(param_3) || NAN(*(float *)(param_1 + 0x150))) ==
       (param_3 == *(float *)(param_1 + 0x150)))) ||
     ((NAN(param_4) || NAN(*(float *)(param_1 + 0x154))) == (param_4 == *(float *)(param_1 + 0x154))
     )) {
    *(ulonglong *)(param_1 + 0x14c) = CONCAT44(param_3,param_2);
    *(float *)(param_1 + 0x154) = param_4;
    FUN_008a4940(&DAT_01effd18);
  }
  return;
}



/* FUNCTION 29555 ; VA 0x00c864f0 ; FUN_00c864f0 */

int __thiscall
FUN_00c864f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,float param_11,float param_12,float param_13)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (((((NAN(param_11) || NAN(*(float *)(param_1 + 0x184))) !=
         (param_11 == *(float *)(param_1 + 0x184))) &&
       (ExceptionList = &pvStack_10,
       (NAN(param_12) || NAN(*(float *)(param_1 + 0x188))) !=
       (param_12 == *(float *)(param_1 + 0x188)))) &&
      (ExceptionList = &pvStack_10,
      (NAN(param_13) || NAN(*(float *)(param_1 + 0x18c))) !=
      (param_13 == *(float *)(param_1 + 0x18c)))) &&
     (ExceptionList = &pvStack_10, iVar2 = FUN_01160ab0((undefined4 *)(param_1 + 0x160)),
     (char)iVar2 != '\0')) {
    ExceptionList = pvStack_10;
    return iVar2;
  }
  *(undefined4 *)(param_1 + 0x160) = param_2;
  *(undefined4 *)(param_1 + 0x164) = param_3;
  *(undefined4 *)(param_1 + 0x168) = param_4;
  *(undefined4 *)(param_1 + 0x16c) = param_5;
  *(undefined4 *)(param_1 + 0x170) = param_6;
  *(undefined4 *)(param_1 + 0x174) = param_7;
  *(undefined4 *)(param_1 + 0x178) = param_8;
  *(undefined4 *)(param_1 + 0x17c) = param_9;
  *(undefined4 *)(param_1 + 0x180) = param_10;
  *(float *)(param_1 + 0x184) = param_11;
  *(float *)(param_1 + 0x188) = param_12;
  *(float *)(param_1 + 0x18c) = param_13;
  iVar2 = FUN_008a4940(&DAT_01eff7e8);
  if (*(int *)(param_1 + 0x140) != 0) {
    piVar3 = (int *)FUN_00587490(auStack_18);
    uStack_8 = 0;
    iVar2 = FUN_00bc1c10(*(undefined4 *)(*piVar3 + 0xa8),1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_14 + 1;
      iVar1 = *piVar3;
      iVar2 = *piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar2 = (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          iVar2 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 29556 ; VA 0x00c865e0 ; FUN_00c865e0 */

void __thiscall FUN_00c865e0(int param_1,float param_2,float param_3,float param_4)

{
  if ((((NAN(param_2) || NAN(*(float *)(param_1 + 0x14c))) ==
        (param_2 == *(float *)(param_1 + 0x14c))) ||
      ((NAN(param_3) || NAN(*(float *)(param_1 + 0x150))) ==
       (param_3 == *(float *)(param_1 + 0x150)))) ||
     ((NAN(param_4) || NAN(*(float *)(param_1 + 0x154))) == (param_4 == *(float *)(param_1 + 0x154))
     )) {
    *(ulonglong *)(param_1 + 0x14c) = CONCAT44(param_3,param_2);
    *(float *)(param_1 + 0x154) = param_4;
    FUN_008a4940(&DAT_01effd88);
  }
  return;
}



/* FUNCTION 29557 ; VA 0x00c86640 ; FUN_00c86640 */

void __thiscall FUN_00c86640(int param_1,float param_2,float param_3,float param_4)

{
  if ((((NAN(param_2) || NAN(*(float *)(param_1 + 0x158))) ==
        (param_2 == *(float *)(param_1 + 0x158))) ||
      ((NAN(param_3) || NAN(*(float *)(param_1 + 0x15c))) ==
       (param_3 == *(float *)(param_1 + 0x15c)))) ||
     ((NAN(param_4) || NAN(*(float *)(param_1 + 0x160))) == (param_4 == *(float *)(param_1 + 0x160))
     )) {
    *(ulonglong *)(param_1 + 0x158) = CONCAT44(param_3,param_2);
    *(float *)(param_1 + 0x160) = param_4;
    FUN_008a4940(&DAT_01effdf8);
  }
  return;
}



/* FUNCTION 29558 ; VA 0x00c866a0 ; FUN_00c866a0 */

int __thiscall FUN_00c866a0(int param_1,float param_2,float param_3,float param_4)

{
  float *pfVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  if (((NAN(param_2) || NAN(*(float *)(param_1 + 0x164))) !=
       (param_2 == *(float *)(param_1 + 0x164))) &&
     ((NAN(param_3) || NAN(*(float *)(param_1 + 0x168))) != (param_3 == *(float *)(param_1 + 0x168))
     )) {
    pfVar1 = (float *)(param_1 + 0x16c);
    if ((NAN(param_4) || NAN(*pfVar1)) != (param_4 == *pfVar1)) {
      return CONCAT22((short)((uint)ExceptionList >> 0x10),
                      CONCAT11((param_4 == *pfVar1) << 6 | (NAN(param_4) || NAN(*pfVar1)) << 2 | 2U
                               | param_4 < *pfVar1,(char)ExceptionList));
    }
  }
  ExceptionList = &pvStack_10;
  *(ulonglong *)(param_1 + 0x164) = CONCAT44(param_3,param_2);
  *(float *)(param_1 + 0x16c) = param_4;
  iVar3 = FUN_008a4940(&DAT_01eff8c8);
  if (*(int *)(param_1 + 0x140) != 0) {
    piVar4 = (int *)FUN_00587490(auStack_18);
    uStack_8 = 0;
    iVar3 = FUN_00bc1c10(*(undefined4 *)(*piVar4 + 0xa8),1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_14 + 1;
      iVar2 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar4 = piStack_14 + 2;
        iVar2 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29559 ; VA 0x00c86780 ; FUN_00c86780 */

int __thiscall FUN_00c86780(int param_1,float param_2,float param_3,float param_4)

{
  float *pfVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  if (((NAN(param_2) || NAN(*(float *)(param_1 + 0x150))) !=
       (param_2 == *(float *)(param_1 + 0x150))) &&
     ((NAN(param_3) || NAN(*(float *)(param_1 + 0x154))) != (param_3 == *(float *)(param_1 + 0x154))
     )) {
    pfVar1 = (float *)(param_1 + 0x158);
    if ((NAN(param_4) || NAN(*pfVar1)) != (param_4 == *pfVar1)) {
      return CONCAT22((short)((uint)ExceptionList >> 0x10),
                      CONCAT11((param_4 == *pfVar1) << 6 | (NAN(param_4) || NAN(*pfVar1)) << 2 | 2U
                               | param_4 < *pfVar1,(char)ExceptionList));
    }
  }
  ExceptionList = &pvStack_10;
  *(ulonglong *)(param_1 + 0x150) = CONCAT44(param_3,param_2);
  *(float *)(param_1 + 0x158) = param_4;
  iVar3 = FUN_008a4940(&DAT_01effaa0);
  if (*(int *)(param_1 + 0x140) != 0) {
    piVar4 = (int *)FUN_00587490(auStack_18);
    uStack_8 = 0;
    iVar3 = FUN_00bc1c10(*(undefined4 *)(*piVar4 + 0xa8),1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_14 + 1;
      iVar2 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar4 = piStack_14 + 2;
        iVar2 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29560 ; VA 0x00c86860 ; FUN_00c86860 */

int __thiscall FUN_00c86860(int param_1,float param_2,float param_3,float param_4)

{
  float *pfVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  if (((NAN(param_2) || NAN(*(float *)(param_1 + 0x150))) !=
       (param_2 == *(float *)(param_1 + 0x150))) &&
     ((NAN(param_3) || NAN(*(float *)(param_1 + 0x154))) != (param_3 == *(float *)(param_1 + 0x154))
     )) {
    pfVar1 = (float *)(param_1 + 0x158);
    if ((NAN(param_4) || NAN(*pfVar1)) != (param_4 == *pfVar1)) {
      return CONCAT22((short)((uint)ExceptionList >> 0x10),
                      CONCAT11((param_4 == *pfVar1) << 6 | (NAN(param_4) || NAN(*pfVar1)) << 2 | 2U
                               | param_4 < *pfVar1,(char)ExceptionList));
    }
  }
  ExceptionList = &pvStack_10;
  *(ulonglong *)(param_1 + 0x150) = CONCAT44(param_3,param_2);
  *(float *)(param_1 + 0x158) = param_4;
  iVar3 = FUN_008a4940(&DAT_01effc38);
  if (*(int *)(param_1 + 0x140) != 0) {
    piVar4 = (int *)FUN_00587490(auStack_18);
    uStack_8 = 0;
    iVar3 = FUN_00bc1c10(*(undefined4 *)(*piVar4 + 0xa8),1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_14 + 1;
      iVar2 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar4 = piStack_14 + 2;
        iVar2 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29561 ; VA 0x00c86940 ; FUN_00c86940 */

int __thiscall FUN_00c86940(int param_1,float param_2,float param_3,float param_4)

{
  float *pfVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  if (((NAN(param_2) || NAN(*(float *)(param_1 + 0x154))) !=
       (param_2 == *(float *)(param_1 + 0x154))) &&
     ((NAN(param_3) || NAN(*(float *)(param_1 + 0x158))) != (param_3 == *(float *)(param_1 + 0x158))
     )) {
    pfVar1 = (float *)(param_1 + 0x15c);
    if ((NAN(param_4) || NAN(*pfVar1)) != (param_4 == *pfVar1)) {
      return CONCAT22((short)((uint)ExceptionList >> 0x10),
                      CONCAT11((param_4 == *pfVar1) << 6 | (NAN(param_4) || NAN(*pfVar1)) << 2 | 2U
                               | param_4 < *pfVar1,(char)ExceptionList));
    }
  }
  ExceptionList = &pvStack_10;
  *(ulonglong *)(param_1 + 0x154) = CONCAT44(param_3,param_2);
  *(float *)(param_1 + 0x15c) = param_4;
  iVar3 = FUN_008a4940(&DAT_01eff778);
  if (*(int *)(param_1 + 0x140) != 0) {
    piVar4 = (int *)FUN_00587490(auStack_18);
    uStack_8 = 0;
    iVar3 = FUN_00bc1c10(*(undefined4 *)(*piVar4 + 0xa8),1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_14 + 1;
      iVar2 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar4 = piStack_14 + 2;
        iVar2 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29562 ; VA 0x00c86a20 ; FUN_00c86a20 */

int __thiscall FUN_00c86a20(int param_1,float param_2,float param_3,float param_4)

{
  float *pfVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  if (((NAN(param_2) || NAN(*(float *)(param_1 + 0x170))) !=
       (param_2 == *(float *)(param_1 + 0x170))) &&
     ((NAN(param_3) || NAN(*(float *)(param_1 + 0x174))) != (param_3 == *(float *)(param_1 + 0x174))
     )) {
    pfVar1 = (float *)(param_1 + 0x178);
    if ((NAN(param_4) || NAN(*pfVar1)) != (param_4 == *pfVar1)) {
      return CONCAT22((short)((uint)ExceptionList >> 0x10),
                      CONCAT11((param_4 == *pfVar1) << 6 | (NAN(param_4) || NAN(*pfVar1)) << 2 | 2U
                               | param_4 < *pfVar1,(char)ExceptionList));
    }
  }
  ExceptionList = &pvStack_10;
  *(ulonglong *)(param_1 + 0x170) = CONCAT44(param_3,param_2);
  *(float *)(param_1 + 0x178) = param_4;
  *(undefined *)(param_1 + 0x188) = 0;
  iVar3 = FUN_008a4940(&DAT_01eff938);
  if (*(int *)(param_1 + 0x140) != 0) {
    piVar4 = (int *)FUN_00587490(auStack_18);
    uStack_8 = 0;
    iVar3 = FUN_00bc1c10(*(undefined4 *)(*piVar4 + 0xa8),1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_14 + 1;
      iVar2 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar4 = piStack_14 + 2;
        iVar2 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29563 ; VA 0x00c86b10 ; FUN_00c86b10 */

void __thiscall FUN_00c86b10(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x15c) != param_2) {
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x15c) = uVar1;
    piVar3 = *(int **)(param_1 + 0x160);
    *(undefined4 *)(param_1 + 0x160) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    *(undefined *)(param_1 + 0x174) = 0;
    FUN_008a4940(&DAT_02139828);
  }
  return;
}



/* FUNCTION 29564 ; VA 0x00c86bd0 ; FUN_00c86bd0 */

void __thiscall FUN_00c86bd0(int param_1,int param_2,float *param_3)

{
  float fVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 8);
  if ((((NAN(*(float *)(iVar2 + param_2)) || NAN(*param_3)) ==
        (*(float *)(iVar2 + param_2) == *param_3)) ||
      (fVar1 = *(float *)(iVar2 + 4 + param_2),
      (NAN(fVar1) || NAN(param_3[1])) == (fVar1 == param_3[1]))) ||
     (fVar1 = *(float *)(iVar2 + 8 + param_2),
     (NAN(fVar1) || NAN(param_3[2])) == (fVar1 == param_3[2]))) {
    *(undefined8 *)(iVar2 + param_2) = *(undefined8 *)param_3;
    *(float *)(iVar2 + 8 + param_2) = param_3[2];
    if (*(code **)(param_1 + 0x10) != (code *)0x0) {
      (**(code **)(param_1 + 0x10))(*(undefined4 *)(param_1 + 4));
    }
    FUN_008a4940(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 29565 ; VA 0x00c86c40 ; FUN_00c86c40 */

void __thiscall FUN_00c86c40(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x10))
            (*param_3,param_3[1],param_3[2],param_3[3],param_3[4],param_3[5],param_3[6],param_3[7],
             param_3[8],param_3[9],param_3[10],param_3[0xb]);
  return;
}



/* FUNCTION 29566 ; VA 0x00c86c80 ; FUN_00c86c80 */

int __thiscall FUN_00c86c80(int param_1,float param_2,float param_3,float param_4)

{
  float *pfVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  if (((NAN(param_2) || NAN(*(float *)(param_1 + 0x15c))) !=
       (param_2 == *(float *)(param_1 + 0x15c))) &&
     ((NAN(param_3) || NAN(*(float *)(param_1 + 0x160))) != (param_3 == *(float *)(param_1 + 0x160))
     )) {
    pfVar1 = (float *)(param_1 + 0x164);
    if ((NAN(param_4) || NAN(*pfVar1)) != (param_4 == *pfVar1)) {
      return CONCAT22((short)((uint)ExceptionList >> 0x10),
                      CONCAT11((param_4 == *pfVar1) << 6 | (NAN(param_4) || NAN(*pfVar1)) << 2 | 2U
                               | param_4 < *pfVar1,(char)ExceptionList));
    }
  }
  ExceptionList = &pvStack_10;
  *(ulonglong *)(param_1 + 0x15c) = CONCAT44(param_3,param_2);
  *(float *)(param_1 + 0x164) = param_4;
  iVar3 = FUN_008a4940(&DAT_01effb10);
  if (*(int *)(param_1 + 0x140) != 0) {
    piVar4 = (int *)FUN_00587490(auStack_18);
    uStack_8 = 0;
    iVar3 = FUN_00bc1c10(*(undefined4 *)(*piVar4 + 0xa8),1);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_14 + 1;
      iVar2 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar4 = piStack_14 + 2;
        iVar2 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29567 ; VA 0x00c86d60 ; FUN_00c86d60 */

int __fastcall FUN_00c86d60(int param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af1f8;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  FUN_00c82f60(0,auStack_14,&uStack_28,&uStack_34);
  cVar2 = FUN_00c93310(&uStack_28,(undefined8 *)(param_1 + 0xd4),0x3d4ccccd);
  if ((cVar2 != '\0') &&
     (iVar3 = FUN_00c93310(&uStack_34,param_1 + 0xe0,0x3d4ccccd), (char)iVar3 != '\0')) {
    ExceptionList = pvStack_10;
    return iVar3;
  }
  *(undefined8 *)(param_1 + 0xd4) = CONCAT44(uStack_24,uStack_28);
  *(undefined4 *)(param_1 + 0xdc) = uStack_20;
  *(ulonglong *)(param_1 + 0xe0) = CONCAT44(uStack_30,uStack_34);
  *(undefined4 *)(param_1 + 0xe8) = uStack_2c;
  piVar4 = (int *)FUN_00587490(auStack_1c);
  uStack_8 = 0;
  iVar3 = FUN_00bc1c10(*(undefined4 *)(*piVar4 + 0xa8),1);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_18 + 1;
    iVar1 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*piStack_18)();
      LOCK();
      piVar4 = piStack_18 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29568 ; VA 0x00c86e90 ; FUN_00c86e90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c86e90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f500;
  pvStack_10 = ExceptionList;
  if (DAT_01f00f74 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01188) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f01188);
      if (DAT_01f01188 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00e8aac0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_0197207c,0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f01180 = RBX::Creator<class_RBX::Seat>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f00f78,&DAT_01f01180);
        FUN_016f3654(FUN_018976d0);
        FUN_016f37bf(&DAT_01f01188);
      }
    }
    DAT_01f00f74 = &DAT_01f00f78;
  }
  ExceptionList = pvStack_10;
  return DAT_01f00f74;
}



/* FUNCTION 29569 ; VA 0x00c86f90 ; FUN_00c86f90 */

int __thiscall FUN_00c86f90(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180f510;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Seat*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29570 ; VA 0x00c87062 ; Catch_All@00c87062 */

void Catch_All_00c87062(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29571 ; VA 0x00c87080 ; FUN_00c87080 */

undefined4 * FUN_00c87080(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180f553;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c86e90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x138);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c87150(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c86f90(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29572 ; VA 0x00c87150 ; FUN_00c87150 */

undefined4 * __thiscall FUN_00c87150(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  double *pdVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  bool bVar9;
  undefined4 uStack_50;
  uint auStack_4c [2];
  code *pcStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  code *pcStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f5fd;
  pvStack_10 = ExceptionList;
  bVar9 = param_2 != (int *)0x0;
  ExceptionList = &pvStack_10;
  if (bVar9) {
    ExceptionList = &pvStack_10;
    param_1[0x15] = &DAT_01971f38;
    param_1[0x26] = &DAT_01971f40;
    param_1[0x4d] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  uStack_14 = (uint)bVar9;
  uStack_18 = (uint)bVar9;
  puStack_20 = param_1;
  FUN_00e8afd0(0);
  *param_1 = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  pdVar4 = (double *)FUN_01682800(&uStack_30);
  *(double *)(param_1 + 0x3e) = *pdVar4 - DAT_018cf100;
  FUN_01682800(param_1 + 0x40);
  FUN_00c18fe0(3);
  *param_1 = RBX::SeatImpl<class_RBX::BasicPartInstance>::vftable;
  param_1[0x16] = RBX::SeatImpl<class_RBX::BasicPartInstance>::vftable;
  param_1[0x1e] = RBX::SeatImpl<class_RBX::BasicPartInstance>::vftable;
  param_1[0x25] = RBX::SeatImpl<class_RBX::BasicPartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::SeatImpl<class_RBX::BasicPartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xd0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  *(undefined *)(param_1 + 0x46) = 0;
  *param_1 = RBX::
             DescribedCreatable<class_RBX::Seat,class_RBX::SeatImpl<class_RBX::BasicPartInstance>_>
             ::vftable;
  param_1[0x16] =
       RBX::DescribedCreatable<class_RBX::Seat,class_RBX::SeatImpl<class_RBX::BasicPartInstance>_>::
       vftable;
  param_1[0x1e] =
       RBX::DescribedCreatable<class_RBX::Seat,class_RBX::SeatImpl<class_RBX::BasicPartInstance>_>::
       vftable;
  param_1[0x25] =
       RBX::DescribedCreatable<class_RBX::Seat,class_RBX::SeatImpl<class_RBX::BasicPartInstance>_>::
       vftable;
  uStack_8 = 3;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::DescribedCreatable<class_RBX::Seat,class_RBX::SeatImpl<class_RBX::BasicPartInstance>_>::
       vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xd0;
  uVar5 = FUN_00c86e90();
  param_1[3] = uVar5;
  *param_1 = RBX::Seat::vftable;
  param_1[0x16] = RBX::Seat::vftable;
  param_1[0x1e] = RBX::Seat::vftable;
  param_1[0x25] = RBX::Seat::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::Seat::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xe0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  puStack_1c = param_1 + 0x4a;
  *puStack_1c = 0;
  puStack_24 = param_1 + 0x4b;
  *puStack_24 = 0;
  uStack_8._0_1_ = 6;
  uStack_8._1_3_ = 0;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_005542c0(&DAT_0197207c,4);
  uStack_8._0_1_ = 7;
  FUN_00b0dd50(auStack_4c);
  FUN_00c18fe0(3);
  uStack_8._0_1_ = 6;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (0xf < uStack_38) {
    uVar7 = uStack_38 + 1;
    uVar6 = auStack_4c[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_4c[0] - 4);
      uVar7 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar6) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  pcStack_34 = FUN_00c88030;
  uStack_30 = 0;
  pcStack_44 = FUN_00c88030;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8 = 9;
  uStack_28 = uVar5;
  puStack_2c = (undefined4 *)FUN_01674e20(0x30);
  if (puStack_2c == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    *puStack_2c = 0;
    puStack_2c[1] = 1;
    puStack_2c[2] = FUN_00c65540;
    puStack_2c[3] = _guard_check_icall;
    puStack_2c[4] = 0;
    puStack_2c[6] = pcStack_44;
    puStack_2c[7] = uStack_40;
    puStack_2c[8] = uStack_3c;
    puStack_2c[9] = uStack_38;
    puStack_2c[5] = param_1 + 0x48;
    *(ulonglong *)(puStack_2c + 10) = CONCAT44(uStack_50,param_1);
    puVar8 = puStack_2c;
  }
  FUN_016797d0(puVar8);
  if (puVar8 != (undefined4 *)0x0) {
    LOCK();
    puVar8[1] = puVar8[1] + 1;
    UNLOCK();
  }
  uStack_18 = uStack_14 | 8;
  uStack_8 = 10;
  uStack_14 = uStack_18;
  FUN_01675290(uVar5);
  uStack_14 = uStack_14 & 0xfffffff7;
  uStack_8 = 6;
  uStack_18 = uStack_14 | 4;
  if (puVar8 != (undefined4 *)0x0) {
    piVar1 = puVar8 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puVar8);
    }
  }
  puVar8 = puStack_20;
  pcStack_44 = FUN_00c65670;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0xc;
  puStack_2c = (undefined4 *)FUN_01674e20(0x30);
  if (puStack_2c == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    *puStack_2c = 0;
    puStack_2c[1] = 1;
    puStack_2c[2] = FUN_00c65510;
    puStack_2c[3] = _guard_check_icall;
    puStack_2c[4] = 0;
    puStack_2c[6] = pcStack_44;
    puStack_2c[7] = uStack_40;
    puStack_2c[8] = uStack_3c;
    puStack_2c[9] = uStack_38;
    puStack_2c[5] = puStack_1c;
    *(ulonglong *)(puStack_2c + 10) = CONCAT44(uStack_50,puVar8);
    puVar8 = puStack_2c;
  }
  FUN_016797d0(puVar8);
  if (puVar8 == (undefined4 *)0x0) {
    param_2 = (int *)&DAT_00000004;
  }
  else {
    param_2 = puVar8 + 1;
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
  }
  uStack_18 = uStack_14 | 0x24;
  uStack_8 = 0xd;
  puStack_2c = puVar8;
  FUN_01675290(uVar5);
  if (puVar8 != (undefined4 *)0x0) {
    LOCK();
    iVar2 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puVar8);
    }
  }
  ExceptionList = pvStack_10;
  return puStack_20;
}



/* FUNCTION 29573 ; VA 0x00c875e0 ; FUN_00c875e0 */

void __fastcall FUN_00c875e0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Seat>::vftable;
  uVar1 = FUN_00c86e90(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29574 ; VA 0x00c87620 ; thunk_FUN_00c87630 */

void __fastcall thunk_FUN_00c87630(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[0x45];
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x43];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0x42];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  *param_1 = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  FUN_00e8b2d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29575 ; VA 0x00c87630 ; FUN_00c87630 */

void __fastcall FUN_00c87630(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[0x45];
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x43];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0x42];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  *param_1 = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  FUN_00e8b2d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29576 ; VA 0x00c87735 ; FUN_00c87735 */

void FUN_00c87735(void)

{
  FUN_00c87760();
  return;
}



/* FUNCTION 29577 ; VA 0x00c87743 ; FUN_00c87743 */

void FUN_00c87743(void)

{
  FUN_00c877d0();
  return;
}



/* FUNCTION 29578 ; VA 0x00c87751 ; FUN_00c87751 */

void FUN_00c87751(void)

{
  FUN_00c87800();
  return;
}



/* FUNCTION 29579 ; VA 0x00c87760 ; FUN_00c87760 */

undefined4 * __thiscall FUN_00c87760(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  FUN_00e8b2d0();
  param_1[0x43] = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x110);
  }
  return param_1;
}



/* FUNCTION 29580 ; VA 0x00c877d0 ; FUN_00c877d0 */

undefined4 __thiscall FUN_00c877d0(undefined4 param_1,byte param_2)

{
  FUN_00c87630();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x128);
  }
  return param_1;
}



/* FUNCTION 29581 ; VA 0x00c87800 ; FUN_00c87800 */

undefined4 * __thiscall FUN_00c87800(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Seat::vftable;
  param_1[0x16] = RBX::Seat::vftable;
  param_1[0x1e] = RBX::Seat::vftable;
  param_1[0x25] = RBX::Seat::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::Seat::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xe0;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00c87630();
  param_1[0x4d] = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x138);
  }
  return param_1;
}



/* FUNCTION 29582 ; VA 0x00c878a0 ; FUN_00c878a0 */

undefined4 * FUN_00c878a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c87080(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29583 ; VA 0x00c87910 ; FUN_00c87910 */

void FUN_00c87910(undefined4 param_1)

{
  FUN_00c87b20(param_1,0);
  return;
}



/* FUNCTION 29584 ; VA 0x00c87930 ; FUN_00c87930 */

void __thiscall FUN_00c87930(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  code *pcVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  double *pdVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined auStack_40 [8];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cec9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  iVar6 = FUN_0097ee20(param_2);
  if (iVar6 == 1) {
    cVar5 = FUN_00c65a20(param_2);
    if (cVar5 != '\0') {
      pdVar7 = (double *)FUN_01682800(auStack_40);
      if ((double)DAT_01d68a54 < *pdVar7 - *(double *)(param_1 + 0x40)) {
        puVar8 = (undefined4 *)FUN_0060dcd0(auStack_40,param_2);
        uVar1 = *puVar8;
        uVar2 = puVar8[1];
        *puVar8 = 0;
        puVar8[1] = 0;
        uStack_30 = 0;
        uStack_2c = 0;
        uStack_38 = 0;
        uStack_34 = 0;
        uStack_8._0_1_ = 2;
        uStack_8._1_3_ = 0;
        pcVar3 = *(code **)(*piStack_14 + 8);
        uStack_1c = uVar1;
        uStack_18 = uVar2;
        uStack_110 = FUN_0088cdc0();
        uStack_10c = 0;
        uStack_1c = 0;
        uStack_18 = 0;
        uStack_108 = uVar1;
        uStack_104 = uVar2;
        uStack_10c = FUN_006309e0();
        uStack_8._0_1_ = 3;
        uStack_28 = 0;
        uStack_24 = 0;
        uStack_20 = 0;
        FUN_00687980(&uStack_110,auStack_40,pcVar3);
        piVar4 = piStack_14;
        uStack_8._0_1_ = 4;
        (*pcVar3)(&DAT_02139d08,&uStack_28,&uStack_30);
        uStack_8._0_1_ = 5;
        FUN_00577b20();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_016f32d1(&uStack_110,0xd0,1,FUN_0056e5b0);
        uStack_8 = 0xffffffff;
        FUN_00550b30();
        piVar9 = (int *)FUN_01682800(&uStack_38);
        piVar4[0x40] = *piVar9;
        piVar4[0x41] = piVar9[1];
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  else {
    FUN_00c87b20(param_2,0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29585 ; VA 0x00c87b20 ; FUN_00c87b20 */

void __thiscall FUN_00c87b20(undefined4 param_1,float param_2)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_4c [12];
  undefined auStack_40 [4];
  undefined4 uStack_3c;
  undefined *puStack_38;
  float fStack_34;
  int *apiStack_30 [2];
  undefined auStack_28 [12];
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = (int)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cf10;
  pvStack_10 = ExceptionList;
  if (((param_2 != 0.0) && (ExceptionList = &pvStack_10, iVar2 = FUN_009b7250(), iVar2 != 0)) &&
     (*(char *)(iVar4 + 0x21f) < '\x01')) {
    FUN_009b7250();
    iVar2 = FUN_00c155c0();
    if (iVar2 != 0) {
      FUN_00ca1550();
      iVar2 = FUN_00b08320();
      fStack_34 = *(float *)(iVar2 + 4) * DAT_018ce2f4;
      FUN_0060efa0();
      puStack_38 = &DAT_bf800000;
      uStack_1c = 0;
      puStack_18 = &DAT_bf800000;
      uStack_14 = 0;
      FUN_01163c80(&uStack_1c,0,&DAT_bf800000);
      puStack_38 = (undefined *)0x0;
      FUN_0060efa0();
      puStack_38 = &DAT_bf800000;
      uStack_1c = 0;
      puStack_18 = &DAT_bf800000;
      uStack_14 = 0;
      FUN_01163c80(&uStack_1c,0,&DAT_bf800000);
      param_2 = 0.0;
      if (*(int *)(iVar4 + 0x228) != 0) {
        puStack_18 = (undefined *)0x0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0();
        uStack_8 = 0;
        uVar3 = FUN_008a1240(auStack_28);
        iVar4 = FUN_00836510(uVar3);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
        if (iVar4 != 0) {
          iVar4 = FUN_00a6bd00(auStack_40);
          param_2 = *(float *)(iVar4 + 4) + 0.0;
        }
        uVar3 = FUN_009b4460(2);
        iVar4 = FUN_006e16a0(uVar3);
        if (iVar4 != 0) {
          puStack_18 = (undefined *)0x0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0();
          uStack_8 = 1;
          uVar3 = FUN_008a1240(auStack_28);
          fStack_34 = (float)FUN_00836510(uVar3);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          if (fStack_34 != 0.0) {
            iVar4 = FUN_00a6bd00(auStack_40);
            param_2 = param_2 - *(float *)(iVar4 + 4);
          }
          puStack_18 = (undefined *)0x0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0();
          uStack_8 = 2;
          uVar3 = FUN_008a1240(auStack_28);
          iVar4 = FUN_00836510(uVar3);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          if (iVar4 != 0) {
            iVar4 = FUN_00a6bd00(auStack_40);
            param_2 = *(float *)(iVar4 + 4) + param_2;
          }
        }
        uVar3 = FUN_009b4460(5);
        iVar4 = FUN_006e16a0(uVar3);
        if (iVar4 != 0) {
          puStack_18 = (undefined *)0x0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0();
          uStack_8 = 3;
          uVar3 = FUN_008a1240(auStack_28);
          iVar4 = FUN_00836510(uVar3);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          if (iVar4 != 0) {
            iVar4 = FUN_00a6bd00(auStack_40);
            param_2 = *(float *)(iVar4 + 8) + param_2;
          }
          FUN_00b08320();
        }
      }
      puStack_38 = (undefined *)0x0;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8e20
          ) && (FUN_016f3809(&DAT_01ef8e20), DAT_01ef8e20 == -1)) {
        DAT_01ef8e14._4_4_ = 0;
        DAT_01ef8e08._0_4_ = 0;
        DAT_01ef8e08._4_4_ = 0;
        DAT_01ef8e10 = 0;
        DAT_01ef8e14._0_4_ = 0;
        DAT_01ef8e1c = 0;
        FUN_016f37bf(&DAT_01ef8e20);
      }
      FUN_00c19180(&DAT_01ef8e08);
      FUN_00a950e0(apiStack_30);
      uStack_8 = 4;
      uStack_3c = 0;
      puStack_38 = (undefined *)0xf;
      auStack_4c[0] = 0;
      pcVar1 = *(code **)(*apiStack_30[0] + 0x38);
      FUN_005542c0();
      uStack_8._0_1_ = 5;
      (*pcVar1)(auStack_4c);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_005507b0();
      FUN_00c3d740();
      FUN_00c3d770();
      FUN_00c3ceb0();
      FUN_00c3cee0();
      param_2 = (float)((uint)param_2 & 0xffffff);
      (**(code **)(*DAT_02119b74 + 0x10))(apiStack_30[0],(int)&param_2 + 3);
      FUN_008a65e0(param_1,0);
      FUN_00550b30();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29586 ; VA 0x00c88030 ; FUN_00c88030 */

int __thiscall FUN_00c88030(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  bool bVar4;
  bool bVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180cf30;
  pvStack_10 = ExceptionList;
  uStack_18 = param_1;
  iStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar8 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar6 = FUN_0099be20();
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      iStack_14 = param_2;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      piStack_24 = param_3;
      bVar5 = true;
      bVar4 = false;
      puVar7 = &uStack_28;
      goto LAB_00c880be;
    }
  }
  piStack_1c = (int *)0x0;
  puVar7 = &uStack_20;
  iStack_14 = 0;
  bVar5 = false;
  bVar4 = true;
LAB_00c880be:
  piVar3 = (int *)puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  if (bVar4) {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar8 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar8 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  piVar2 = piStack_24;
  if ((bVar5) && (piStack_24 != (int *)0x0)) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar8 = FUN_00c87b20(iStack_14,0);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar2 = piVar3 + 1;
    iVar6 = *piVar2;
    iVar8 = *piVar2;
    *piVar2 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar6 = *piVar2;
      iVar8 = *piVar2;
      *piVar2 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar8 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar6 = *piVar3;
    iVar8 = *piVar3;
    *piVar3 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar8 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar6 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar8 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 29587 ; VA 0x00c881a0 ; FUN_00c881a0 */

void __fastcall FUN_00c881a0(int *param_1)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9648;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  (**(code **)(*param_1 + 8))(&DAT_02139d50,&uStack_24,&uStack_18);
  uStack_8 = 1;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29588 ; VA 0x00c88240 ; thunk_FUN_00e8aca0 */

void thunk_FUN_00e8aca0(void)

{
  int iVar1;
  
  if (DAT_01f21cf4 == 0) {
    iVar1 = FUN_00e8aac0();
    DAT_01f21cf4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29589 ; VA 0x00c88250 ; FUN_00c88250 */

void FUN_00c88250(void)

{
  int iVar1;
  
  if (DAT_01f0118c == 0) {
    iVar1 = FUN_00c86e90();
    DAT_01f0118c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29590 ; VA 0x00c88270 ; FUN_00c88270 */

undefined __fastcall FUN_00c88270(int param_1)

{
  return *(undefined *)(param_1 + 0xe8);
}



/* FUNCTION 29591 ; VA 0x00c88278 ; FUN_00c88278 */

void FUN_00c88278(void)

{
  FUN_00afc020();
  return;
}



/* FUNCTION 29592 ; VA 0x00c88290 ; FUN_00c88290 */

void FUN_00c88290(int param_1)

{
  undefined4 uVar1;
  
  if (param_1 != 0) {
    uVar1 = FUN_00c3c020();
    FUN_009ade20(uVar1);
    return;
  }
  FUN_009ade20(0);
  return;
}



/* FUNCTION 29593 ; VA 0x00c882c0 ; FUN_00c882c0 */

uint FUN_00c882c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c86e90();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29594 ; VA 0x00c882e0 ; FUN_00c882e0 */

uint FUN_00c882e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c86e90();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29595 ; VA 0x00c88300 ; FUN_00c88300 */

int * FUN_00c88300(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar1 = param_1[1];
      iVar2 = param_1[2];
      iVar3 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar1;
      param_2[2] = iVar2;
      param_2[3] = iVar3;
      param_2[4] = 0;
      param_2[5] = 0;
      if (param_1[5] != 0) {
        LOCK();
        piVar5 = (int *)(param_1[5] + 4);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
      param_2[4] = param_1[4];
      piVar5 = (int *)param_1[5];
      param_2[5] = (int)piVar5;
      if (param_3 != 1) {
        return piVar5;
      }
      piVar6 = (int *)param_1[5];
      if (piVar6 == (int *)0x0) {
        return piVar5;
      }
      LOCK();
      piVar5 = piVar6 + 1;
      iVar1 = *piVar5;
      piVar4 = (int *)*piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar4;
      }
      piVar4 = (int *)(**(code **)*piVar6)();
      LOCK();
      piVar5 = piVar6 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar4;
      }
                    /* WARNING: Could not recover jumptable at 0x00c883e4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar5 = (int *)(**(code **)(*piVar6 + 4))();
      return piVar5;
    }
    if (param_3 == 2) {
      piVar5 = (int *)param_2[5];
      if (piVar5 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar6 = piVar5 + 1;
      iVar1 = *piVar6;
      piVar4 = (int *)*piVar6;
      *piVar6 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar4;
      }
      piVar4 = (int *)(**(code **)*piVar5)();
      LOCK();
      piVar6 = piVar5 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar4;
      }
                    /* WARNING: Could not recover jumptable at 0x00c88356. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar5 = (int *)(**(code **)(*piVar5 + 4))();
      return piVar5;
    }
    if (param_3 == 3) {
      piVar6 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e0fe14);
      piVar5 = (int *)0x0;
      if (piVar6 == (int *)0x0) {
        piVar5 = param_1;
      }
      *param_2 = (int)piVar5;
      return piVar6;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf0<void,class_RBX::Seat>,class_boost::_bi::list1<class_boost::_bi::value<class_std::shared_ptr<class_RBX::Seat>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 29596 ; VA 0x00c88400 ; FUN_00c88400 */

void FUN_00c88400(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1e0fe9c);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::SeatImpl<class_RBX::BasicPartInstance>,class_std::shared_ptr<class_RBX::Instance>_>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::SeatImpl<class_RBX::BasicPartInstance>*>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 29597 ; VA 0x00c88470 ; FUN_00c88470 */

void __thiscall FUN_00c88470(undefined4 param_1,char param_2,int param_3)

{
  int iVar1;
  
  if (((param_2 == '\0') && (param_3 != 0)) && (iVar1 = FUN_009b52d0(param_1), param_3 == iVar1)) {
    FUN_009c4f20(0);
  }
  return;
}



/* FUNCTION 29598 ; VA 0x00c884a0 ; FUN_00c884a0 */

void __thiscall FUN_00c884a0(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  uint auStack_90 [2];
  code *pcStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  int *piStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  code *pcStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  undefined8 uStack_50;
  code *pcStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined8 uStack_38;
  code *pcStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f73f;
  pvStack_10 = ExceptionList;
  aiStack_18[1] = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01679490();
    pcVar2 = *(code **)(*param_1 + 0x164);
    iVar7 = FUN_00c65730();
    if (iVar7 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_00c3c020();
    }
    uVar8 = FUN_009ade20(uVar8);
    (*pcVar2)(0,uVar8);
  }
  FUN_00b0a250(param_2,param_3);
  if (param_3 != 0) {
    iVar7 = FUN_008a4100();
    pcStack_28 = FUN_00c662f0;
    uStack_24 = 0;
    uVar8 = *(undefined4 *)(iVar7 + 0xbc);
    pcStack_48 = FUN_00c662f0;
    uStack_44 = 0;
    uStack_40 = 0;
    piStack_3c = piStack_1c;
    uStack_38 = CONCAT44(piStack_1c,param_1);
    iStack_8 = 0;
    piStack_20 = param_1;
    cVar6 = FUN_00585a40(&pcStack_48);
    if (cVar6 == '\0') {
      uStack_68 = 0x19720e9;
      pcStack_60 = pcStack_48;
      uStack_5c = uStack_44;
      uStack_58 = uStack_40;
      piStack_54 = piStack_3c;
      uStack_50 = uStack_38;
    }
    else {
      uStack_68 = 0;
    }
    iStack_8._0_1_ = 1;
    auStack_90[0] = 0;
    pcVar2 = pcStack_88;
    uVar3 = uStack_84;
    uVar4 = uStack_80;
    piVar1 = piStack_7c;
    uVar5 = uStack_78;
    if ((uStack_68 != 0) &&
       (auStack_90[0] = uStack_68, pcVar2 = pcStack_60, uVar3 = uStack_5c, uVar4 = uStack_58,
       piVar1 = piStack_54, uVar5 = uStack_50, (uStack_68 & 1) == 0)) {
      (**(code **)(uStack_68 & 0xfffffffe))(&pcStack_60,&pcStack_88,0);
      pcVar2 = pcStack_88;
      uVar3 = uStack_84;
      uVar4 = uStack_80;
      piVar1 = piStack_7c;
      uVar5 = uStack_78;
    }
    uStack_78 = uVar5;
    piStack_7c = piVar1;
    uStack_80 = uVar4;
    uStack_84 = uVar3;
    pcStack_88 = pcVar2;
    iStack_8._0_1_ = 2;
    puVar9 = (undefined4 *)FUN_0060dcd0(&piStack_20,uVar8);
    if (puVar9[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar9[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_70 = *puVar9;
    uStack_6c = puVar9[1];
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar7 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar7 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if ((DAT_01d69070 != '\0') || (DAT_01d66be0 != '\0')) {
      FUN_00b08fb0();
    }
    iStack_8._0_1_ = 4;
    uVar8 = FUN_00affe60(aiStack_18,auStack_90);
    aiStack_18[1] = 1;
    FUN_00b01550();
    iStack_8._0_1_ = 5;
    if (uStack_68 != 0) {
      if (((uStack_68 & 1) == 0) && (*(code **)(uStack_68 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_68 & 0xfffffffe))(&pcStack_60,&pcStack_60,2);
      }
      uStack_68 = 0;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    cVar6 = FUN_01679300(uVar8);
    if (cVar6 != '\0') {
      FUN_01679490();
      FUN_016791c0(uVar8);
    }
    if (aiStack_18[0] != 0) {
      piVar1 = (int *)(aiStack_18[0] + 4);
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(aiStack_18[0]);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29599 ; VA 0x00c88720 ; FUN_00c88720 */

void __thiscall FUN_00c88720(undefined4 param_1,undefined *param_2,int *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  int aiStack_2c [2];
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cfb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_20 = param_1;
  iVar3 = FUN_008f7870(param_1);
  if (iVar3 != 0) {
    if ((*(int *)(iVar3 + 0x4a0) == 1) || (*(int *)(iVar3 + 0x4a0) == 3)) {
      FUN_00b0a450(param_2,param_3,param_4);
      ExceptionList = pvStack_10;
      return;
    }
    if (param_2 != &DAT_02139d08) {
      if (param_2 != &DAT_02139d50) {
        FUN_00b0a450(param_2,param_3,param_4);
        ExceptionList = pvStack_10;
        return;
      }
      FUN_0097c020(aiStack_2c,param_4,param_1);
      uStack_8 = 2;
      if ((aiStack_2c[0] != 0) && (iVar3 = *(int *)(aiStack_2c[0] + 100), iVar3 != 0)) {
        uStack_18 = FUN_00c65730();
        puVar1 = *(undefined4 **)(iVar3 + 0x2c);
        if (puVar1 != (undefined4 *)0x0) {
          piVar2 = (int *)puVar1[1];
          for (piVar7 = (int *)*puVar1; piVar7 != piVar2; piVar7 = piVar7 + 2) {
            iStack_14 = *piVar7;
            if ((iStack_14 != 0) &&
               (iVar3 = *(int *)(iStack_14 + 0xc), iVar6 = FUN_0099be20(), iVar4 = iStack_14,
               (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
               (uint)*(ushort *)(iVar6 + 0x1da))) goto LAB_00c888fc;
          }
        }
        iVar4 = 0;
LAB_00c888fc:
        iVar3 = FUN_00c88290(uStack_18);
        if (iVar3 == iVar4) {
          FUN_00b0a450(&DAT_02139d50,param_3,param_4);
        }
      }
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return;
    }
    if (((param_3[1] - *param_3) / 0xd0 == 1) ||
       (iVar3 = *(int *)*param_3, iVar4 = FUN_0088cdc0(), iVar3 == iVar4)) {
      uVar5 = FUN_00605c00();
      FUN_00557fc0(uVar5);
      uStack_8 = 0;
      if ((iStack_1c == 0) ||
         (iVar3 = *(int *)(iStack_1c + 0xc), iVar6 = FUN_0099be20(), iVar4 = iStack_1c,
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        iVar4 = 0;
      }
      iStack_14 = FUN_009b48a0(iVar4);
      iVar6 = FUN_00c65730();
      iVar3 = iStack_14;
      if (((((iVar6 == 0) && (iStack_1c != 0)) && (iVar4 != 0)) &&
          ((iStack_14 != 0 && (*(int *)(iVar4 + 0x194) == 0)))) &&
         (**(char **)(iVar4 + 0x22c) == (char)*(char **)(iVar4 + 0x22c))) {
        FUN_0097c020(&iStack_24,param_4,param_1);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if ((iStack_24 != 0) && (*(int *)(iStack_24 + 100) == iVar3)) {
          FUN_00b0a450(&DAT_02139d08,param_3,param_4);
        }
        FUN_00550b30();
      }
      FUN_00550b30();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29600 ; VA 0x00c88980 ; FUN_00c88980 */

void __thiscall FUN_00c88980(int param_1,char *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  int iStack_10;
  int *piStack_c;
  char cStack_5;
  
  cVar2 = *param_2;
  cStack_5 = *(char *)(param_1 + 0x118);
  if (cStack_5 != cVar2) {
    *(char *)(param_1 + 0x118) = cVar2;
    FUN_008a4940();
  }
  if ((cStack_5 == '\0') && (cVar2 != '\0')) {
    iVar3 = FUN_00c65730();
    if (iVar3 != 0) {
      FUN_00c3c020();
      iVar3 = FUN_009ade20();
      if (iVar3 != 0) {
        FUN_009c4f20();
      }
      FUN_008a65e0();
    }
    iVar3 = FUN_00c65730();
    if ((iVar3 != 0) && (iStack_10 = FUN_008f7870(), iStack_10 != 0)) {
      puStack_20 = &LAB_00c66ed0;
      uStack_1c = 0;
      FUN_0060dcd0();
      FUN_00c63690(&uStack_38,CONCAT44(uStack_1c,puStack_20),0);
      piVar1 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
      }
      piStack_c = piStack_24 + 1;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        *piStack_c = *piStack_c + 1;
        UNLOCK();
        LOCK();
        *piStack_c = *piStack_c + 1;
        UNLOCK();
      }
      FUN_00c63570(uStack_38,uStack_34,uStack_30,uStack_2c,uStack_28);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = *piStack_c;
        *piStack_c = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar3 = piVar1[1] + -1;
          piVar1[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar3 = piVar1[2] + -1;
            piVar1[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piStack_24 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      FUN_0090ca30();
    }
  }
  return;
}



/* FUNCTION 29601 ; VA 0x00c88b60 ; FUN_00c88b60 */

void __thiscall FUN_00c88b60(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x110) != param_2) {
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x110) = uVar1;
    piVar3 = *(int **)(param_1 + 0x114);
    *(undefined4 *)(param_1 + 0x114) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    FUN_008a4940(&DAT_02139cc8);
  }
  return;
}



/* FUNCTION 29602 ; VA 0x00c88c10 ; FUN_00c88c10 */

int * __thiscall FUN_00c88c10(int *param_1,int param_2,int *param_3)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  char *pcVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_2 == 0) {
    piVar2 = (int *)0x0;
    ExceptionList = &pvStack_10;
    if (param_1[0x44] != 0) {
      ExceptionList = &pvStack_10;
      piVar2 = (int *)FUN_009c4f20(0);
    }
    goto LAB_00c88d47;
  }
  iVar4 = *(int *)(param_2 + 0xc);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0099be20();
  iVar6 = 0;
  if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    iVar6 = param_2;
  }
  if ((iVar6 == 0) || (cVar1 = FUN_009b4a80(), cVar1 != '\0')) {
    pcVar7 = "Sit : param is not a Humanoid or humanoid is dead";
  }
  else {
    iVar4 = FUN_009b7250();
    if (iVar4 == 0) {
      pcVar7 = "Sit : Humanoid doesn\'t have HumanoidRootPart";
    }
    else {
      cVar1 = FUN_008b0500(iVar4);
      if ((cVar1 == '\0') || (piVar2 = (int *)FUN_008b0500(param_1), (char)piVar2 == '\0')) {
        pcVar7 = "Sit : Seat or Humanoid is not in Workspace.";
      }
      else {
        if (param_1[0x44] == iVar6) goto LAB_00c88d47;
        iVar4 = FUN_00c65730();
        if (iVar4 == 0) {
          piVar2 = *(int **)(iVar6 + 0x194);
          if (piVar2 != (int *)0x0) {
            if (piVar2 == param_1) goto LAB_00c88d47;
            iVar4 = piVar2[3];
            iVar3 = FUN_00e8aac0();
            piVar5 = (int *)0x0;
            if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
                (uint)*(ushort *)(iVar3 + 0x1da)) {
              piVar5 = piVar2;
            }
            if (piVar5 != (int *)0x0) {
              (**(code **)(*piVar5 + 0x160))();
            }
          }
          piVar2 = (int *)(**(code **)(*param_1 + 0x15c))(iVar6);
          goto LAB_00c88d47;
        }
        pcVar7 = "Sit : This Seat is occupied";
      }
    }
  }
  piVar2 = (int *)FUN_0086f2f0(3,pcVar7);
LAB_00c88d47:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar5 = param_3 + 1;
    iVar4 = *piVar5;
    piVar2 = (int *)*piVar5;
    *piVar5 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piVar2 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar5 = param_3 + 2;
      iVar4 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piVar2 = (int *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 29603 ; VA 0x00c88d90 ; FUN_00c88d90 */

int * __thiscall
FUN_00c88d90(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc8db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c88fe0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::SkateboardPlatform,int>::
              GetSetImpl<int_(__thiscall_RBX::SkateboardPlatform::*)(void)const_,void_(__thiscall_RBX::SkateboardPlatform::*)(int)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::SkateboardPlatform,int>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::SkateboardPlatform,int>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29604 ; VA 0x00c88ea0 ; FUN_00c88ea0 */

undefined4 * __thiscall
FUN_00c88ea0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01972b58;
  cVar3 = FUN_00bd6780(param_2,param_3,param_4,param_5,param_6,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 29605 ; VA 0x00c88fe0 ; FUN_00c88fe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c88fe0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f770;
  pvStack_10 = ExceptionList;
  if (DAT_01f01194 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f013a8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f013a8);
      if (DAT_01f013a8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00e8aac0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"SkateboardPlatform",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f013a0 = RBX::Creator<class_RBX::SkateboardPlatform>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f01198,&DAT_01f013a0);
        FUN_016f3654(FUN_018978a0);
        FUN_016f37bf(&DAT_01f013a8);
      }
    }
    DAT_01f01194 = &DAT_01f01198;
  }
  ExceptionList = pvStack_10;
  return DAT_01f01194;
}



/* FUNCTION 29606 ; VA 0x00c890e0 ; FUN_00c890e0 */

int __thiscall FUN_00c890e0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180f780;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::SkateboardPlatform*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29607 ; VA 0x00c891b2 ; Catch_All@00c891b2 */

void Catch_All_00c891b2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29608 ; VA 0x00c891d0 ; FUN_00c891d0 */

undefined4 FUN_00c891d0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_008e1b70();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 29609 ; VA 0x00c89230 ; FUN_00c89230 */

undefined4 * FUN_00c89230(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180f7c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c88fe0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x278);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c89590(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c890e0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29610 ; VA 0x00c89300 ; FUN_00c89300 */

undefined4 *
FUN_00c89300(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined auStack_1d0 [432];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f7fc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c88fe0();
  FUN_009cb970(uVar1,param_3,param_6,param_7,param_8);
  puStack_14[0xe] = param_1;
  puStack_14[0xf] = param_2;
  iStack_8 = 0;
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::SkateboardPlatform,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::SkateboardPlatform::*>
                ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687810(auStack_1d0,&uStack_20,param_6);
  iStack_8._0_1_ = 3;
  if (puStack_14 + 10 != &uStack_20) {
    FUN_0068a760();
    puStack_14[10] = uStack_20;
    puStack_14[0xb] = uStack_1c;
    puStack_14[0xc] = uStack_18;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
  }
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1d0,0xd8,2,FUN_00688b10);
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 29611 ; VA 0x00c89460 ; FUN_00c89460 */

undefined4 *
FUN_00c89460(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined auStack_f8 [216];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f831;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c88fe0();
  FUN_009cb970(uVar1,param_3,param_5,param_6,param_7);
  puStack_14[0xe] = param_1;
  puStack_14[0xf] = param_2;
  iStack_8 = 0;
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::SkateboardPlatform,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::SkateboardPlatform::*>
                ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687810(auStack_f8,&uStack_20,param_5);
  iStack_8._0_1_ = 2;
  if (puStack_14 + 10 != &uStack_20) {
    FUN_0068a760();
    puStack_14[10] = uStack_20;
    puStack_14[0xb] = uStack_1c;
    puStack_14[0xc] = uStack_18;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_f8,0xd8,1,FUN_00688b10);
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 29612 ; VA 0x00c89590 ; FUN_00c89590 */

undefined4 * __thiscall FUN_00c89590(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  double *pdVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  bool bVar9;
  undefined4 uStack_50;
  uint auStack_4c [2];
  code *pcStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  code *pcStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f952;
  pvStack_10 = ExceptionList;
  bVar9 = param_2 != (int *)0x0;
  ExceptionList = &pvStack_10;
  if (bVar9) {
    ExceptionList = &pvStack_10;
    param_1[0x15] = &DAT_0197271c;
    param_1[0x26] = &DAT_01972724;
    param_1[0x9d] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  uStack_14 = (uint)bVar9;
  uStack_18 = (uint)bVar9;
  puStack_1c = param_1;
  FUN_00e8afd0(0);
  *param_1 = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  uStack_8 = 4;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  pdVar4 = (double *)FUN_01682800(&uStack_30);
  *(double *)(param_1 + 0x3e) = *pdVar4 - DAT_018cf100;
  FUN_01682800(param_1 + 0x40);
  FUN_00c18fe0(3);
  *param_1 = RBX::PlatformImpl<class_RBX::BasicPartInstance>::vftable;
  param_1[0x16] = RBX::PlatformImpl<class_RBX::BasicPartInstance>::vftable;
  param_1[0x1e] = RBX::PlatformImpl<class_RBX::BasicPartInstance>::vftable;
  param_1[0x25] = RBX::PlatformImpl<class_RBX::BasicPartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::PlatformImpl<class_RBX::BasicPartInstance>::vftable;
  *(undefined4 *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  *param_1 = RBX::
             DescribedCreatable<class_RBX::SkateboardPlatform,class_RBX::PlatformImpl<class_RBX::BasicPartInstance>_>
             ::vftable;
  param_1[0x16] =
       RBX::
       DescribedCreatable<class_RBX::SkateboardPlatform,class_RBX::PlatformImpl<class_RBX::BasicPartInstance>_>
       ::vftable;
  param_1[0x1e] =
       RBX::
       DescribedCreatable<class_RBX::SkateboardPlatform,class_RBX::PlatformImpl<class_RBX::BasicPartInstance>_>
       ::vftable;
  param_1[0x25] =
       RBX::
       DescribedCreatable<class_RBX::SkateboardPlatform,class_RBX::PlatformImpl<class_RBX::BasicPartInstance>_>
       ::vftable;
  uStack_8 = 5;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::
       DescribedCreatable<class_RBX::SkateboardPlatform,class_RBX::PlatformImpl<class_RBX::BasicPartInstance>_>
       ::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xc0;
  uVar5 = FUN_00c88fe0();
  param_1[3] = uVar5;
  uStack_8 = 6;
  FUN_00ca27c0();
  param_1[0x6e] = RBX::Connector::vftable;
  param_1[0x6f] = 0xffffffff;
  param_1[0x70] = 0xffffffff;
  param_1[0x71] = 0xffffffff;
  param_1[0x72] = 0xffffffff;
  param_1[0x73] = 0xffffffff;
  param_1[0x74] = 0xffffffff;
  param_1[0x44] = RBX::KernelJoint::vftable;
  param_1[0x46] = RBX::KernelJoint::vftable;
  param_1[0x6e] = RBX::KernelJoint::vftable;
  uStack_8._0_1_ = 7;
  *(undefined *)(param_1 + 0x75) = 0;
  param_1[0x76] = 0;
  FUN_016f4053(param_1 + 0x77,4,2,FUN_00610ca0,FUN_005f60a0);
  *param_1 = RBX::SkateboardPlatform::vftable;
  param_1[0x16] = RBX::SkateboardPlatform::vftable;
  param_1[0x1e] = RBX::SkateboardPlatform::vftable;
  param_1[0x25] = RBX::SkateboardPlatform::vftable;
  param_1[0x44] = RBX::SkateboardPlatform::vftable;
  param_1[0x46] = RBX::SkateboardPlatform::vftable;
  param_1[0x6e] = RBX::SkateboardPlatform::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::SkateboardPlatform::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x220
  ;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  param_1[0x7c] = 0;
  param_1[0x7d] = 0;
  param_1[0x7e] = 0;
  param_1[0x7f] = 0;
  param_1[0x80] = 0;
  param_1[0x81] = 0;
  param_1[0x82] = 0;
  *(undefined *)(param_1 + 0x83) = 1;
  param_1[0x84] = 0;
  param_1[0x85] = 0;
  param_1[0x86] = 0;
  param_1[0x87] = 0;
  param_1[0x88] = 0;
  param_1[0x89] = 0;
  param_1[0x8a] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  param_1[0x8b] = 0;
  param_1[0x8e] = 0x42200000;
  param_1[0x8f] = 0x44fa0000;
  param_1[0x90] = 0x3fc00000;
  param_1[0x91] = 0x40200000;
  param_1[0x92] = 0x46c35000;
  param_1[0x93] = 0x46c35000;
  param_1[0x94] = 0;
  param_1[0x95] = 0;
  param_1[0x96] = 0;
  param_1[0x97] = 0;
  param_1[0x98] = 0;
  puStack_20 = param_1 + 0x99;
  *puStack_20 = 0;
  puStack_24 = param_1 + 0x9a;
  *puStack_24 = 0;
  uStack_8._0_1_ = 0x10;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_005542c0("SkateboardPlatform",0x12);
  uStack_8._0_1_ = 0x11;
  FUN_00b0dd50(auStack_4c);
  FUN_00c18fe0(3);
  uStack_8._0_1_ = 0x10;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x10;
  if (0xf < uStack_38) {
    uVar7 = uStack_38 + 1;
    uVar6 = auStack_4c[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_4c[0] - 4);
      uVar7 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar6) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  pcStack_34 = FUN_00c8b6c0;
  uStack_30 = 0;
  pcStack_44 = FUN_00c8b6c0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0x13;
  uStack_28 = uVar5;
  puStack_2c = (undefined4 *)FUN_01674e20(0x30);
  if (puStack_2c == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    *puStack_2c = 0;
    puStack_2c[1] = 1;
    puStack_2c[2] = FUN_00c65540;
    puStack_2c[3] = _guard_check_icall;
    puStack_2c[4] = 0;
    puStack_2c[6] = pcStack_44;
    puStack_2c[7] = uStack_40;
    puStack_2c[8] = uStack_3c;
    puStack_2c[9] = uStack_38;
    puStack_2c[5] = param_1 + 0x97;
    *(ulonglong *)(puStack_2c + 10) = CONCAT44(uStack_50,param_1);
    puVar8 = puStack_2c;
  }
  FUN_016797d0(puVar8);
  if (puVar8 != (undefined4 *)0x0) {
    LOCK();
    puVar8[1] = puVar8[1] + 1;
    UNLOCK();
  }
  uStack_18 = uStack_14 | 0x20;
  uStack_8 = 0x14;
  uStack_14 = uStack_18;
  FUN_01675290(uVar5);
  uStack_14 = uStack_14 & 0xffffffdf;
  uStack_8 = 0x10;
  uStack_18 = uStack_14 | 0x10;
  if (puVar8 != (undefined4 *)0x0) {
    piVar1 = puVar8 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puVar8);
    }
  }
  puVar8 = puStack_1c;
  pcStack_44 = FUN_00c8bc70;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0x16;
  puStack_2c = (undefined4 *)FUN_01674e20(0x30);
  if (puStack_2c == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    *puStack_2c = 0;
    puStack_2c[1] = 1;
    puStack_2c[2] = FUN_00c65510;
    puStack_2c[3] = _guard_check_icall;
    puStack_2c[4] = 0;
    puStack_2c[6] = pcStack_44;
    puStack_2c[7] = uStack_40;
    puStack_2c[8] = uStack_3c;
    puStack_2c[9] = uStack_38;
    puStack_2c[5] = puStack_20;
    *(ulonglong *)(puStack_2c + 10) = CONCAT44(uStack_50,puVar8);
    puVar8 = puStack_2c;
  }
  FUN_016797d0(puVar8);
  if (puVar8 == (undefined4 *)0x0) {
    param_2 = (int *)&DAT_00000004;
  }
  else {
    param_2 = puVar8 + 1;
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
  }
  uStack_18 = uStack_14 | 0x90;
  uStack_8 = 0x17;
  puStack_2c = puVar8;
  FUN_01675290(uVar5);
  if (puVar8 != (undefined4 *)0x0) {
    LOCK();
    iVar2 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puVar8);
    }
  }
  ExceptionList = pvStack_10;
  return puStack_1c;
}



/* FUNCTION 29613 ; VA 0x00c89bf0 ; FUN_00c89bf0 */

void __fastcall FUN_00c89bf0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::SkateboardPlatform>::vftable;
  uVar1 = FUN_00c88fe0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29614 ; VA 0x00c89c30 ; thunk_FUN_00c89c40 */

void __fastcall thunk_FUN_00c89c40(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar3 = param_1[0x43];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0x42];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  *param_1 = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  FUN_00e8b2d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29615 ; VA 0x00c89c40 ; FUN_00c89c40 */

void __fastcall FUN_00c89c40(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar3 = param_1[0x43];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0x42];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  *param_1 = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::BasicPartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  FUN_00e8b2d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29616 ; VA 0x00c89d1c ; FUN_00c89d1c */

void FUN_00c89d1c(void)

{
  FUN_00c89d60();
  return;
}



/* FUNCTION 29617 ; VA 0x00c89d2a ; FUN_00c89d2a */

void FUN_00c89d2a(void)

{
  FUN_00c89e80();
  return;
}



/* FUNCTION 29618 ; VA 0x00c89d38 ; FUN_00c89d38 */

void FUN_00c89d38(void)

{
  FUN_00c89e80();
  return;
}



/* FUNCTION 29619 ; VA 0x00c89d43 ; FUN_00c89d43 */

void FUN_00c89d43(void)

{
  FUN_00c89e80();
  return;
}



/* FUNCTION 29620 ; VA 0x00c89d4e ; FUN_00c89d4e */

void FUN_00c89d4e(void)

{
  FUN_00c89e80();
  return;
}



/* FUNCTION 29621 ; VA 0x00c89d60 ; FUN_00c89d60 */

int __thiscall FUN_00c89d60(int param_1,byte param_2)

{
  FUN_00c89c40();
  *(undefined ***)(param_1 + 0x114) = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x118);
  }
  return param_1;
}



/* FUNCTION 29622 ; VA 0x00c89d90 ; FUN_00c89d90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c89d90(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::SkateboardPlatform::MoveState>::vftable;
  _DAT_01f013b0 = _DAT_01f013b0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 29623 ; VA 0x00c89dc0 ; FUN_00c89dc0 */

undefined4 * __thiscall FUN_00c89dc0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SkateboardController*>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 29624 ; VA 0x00c89df0 ; FUN_00c89df0 */

undefined4 * __thiscall FUN_00c89df0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::SkateboardPlatform::MoveState>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 29625 ; VA 0x00c89e20 ; FUN_00c89e20 */

undefined4 * __thiscall FUN_00c89e20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SkateboardController*>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 29626 ; VA 0x00c89e50 ; FUN_00c89e50 */

undefined4 * __thiscall FUN_00c89e50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::SkateboardPlatform::MoveState>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 29627 ; VA 0x00c89e80 ; FUN_00c89e80 */

undefined4 * __thiscall FUN_00c89e80(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::SkateboardPlatform::vftable;
  param_1[0x16] = RBX::SkateboardPlatform::vftable;
  param_1[0x1e] = RBX::SkateboardPlatform::vftable;
  param_1[0x25] = RBX::SkateboardPlatform::vftable;
  param_1[0x44] = RBX::SkateboardPlatform::vftable;
  param_1[0x46] = RBX::SkateboardPlatform::vftable;
  param_1[0x6e] = RBX::SkateboardPlatform::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::SkateboardPlatform::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x220
  ;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uStack_8 = 0;
  FUN_01674ea0(param_1[0x8b]);
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  piVar2 = (int *)param_1[0x8a];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x86];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  uStack_8 = 1;
  FUN_016f32d1(param_1 + 0x77,4,2,FUN_005f60a0);
  param_1[0x44] = RBX::KernelJoint::vftable;
  param_1[0x46] = RBX::KernelJoint::vftable;
  param_1[0x6e] = RBX::Connector::vftable;
  FUN_00ca2b60();
  FUN_00c89c40();
  param_1[0x9d] = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x278);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29628 ; VA 0x00c8a040 ; thunk_FUN_00c8d570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c8d570(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fbf6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f0141c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f0141c);
    if (DAT_01f0141c == -1) {
      uStack_8 = 0;
      FUN_009ca470("MoveState");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01f013b8 = RBX::Reflection::EnumDesc<enum_RBX::SkateboardPlatform::MoveState>::vftable;
      FUN_009caf20(&DAT_01d68a68,5);
      FUN_016f3654(&LAB_018977c0);
      FUN_016f37bf(&DAT_01f0141c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f013b8;
}



/* FUNCTION 29629 ; VA 0x00c8a050 ; FUN_00c8a050 */

void __thiscall FUN_00c8a050(int *param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_1[1];
  if (iVar1 < param_1[2]) {
    iVar2 = *param_1;
    *(undefined4 *)(iVar2 + iVar1 * 8) = *param_2;
    *(undefined4 *)(iVar2 + 4 + iVar1 * 8) = param_2[1];
    param_1[1] = param_1[1] + 1;
    return;
  }
  if (((undefined4 *)*param_1 <= param_2) && (param_2 < (undefined4 *)*param_1 + iVar1 * 2)) {
    uStack_c = *param_2;
    uStack_8 = param_2[1];
    FUN_00c8a050(&uStack_c);
    return;
  }
  FUN_00c8d290(iVar1 + 1,0);
  iVar1 = *param_1;
  iVar2 = param_1[1];
  *(undefined4 *)(iVar1 + -8 + iVar2 * 8) = *param_2;
  *(undefined4 *)(iVar1 + -4 + iVar2 * 8) = param_2[1];
  return;
}



/* FUNCTION 29630 ; VA 0x00c8a0e0 ; FUN_00c8a0e0 */

void __thiscall FUN_00c8a0e0(int param_1,uint param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  int iVar10;
  float fVar11;
  
  iVar10 = (**(code **)(*(int *)(param_1 + 0x110) + 0x44))();
  fVar11 = (float)(param_2 ^ DAT_018c4ea0);
  FUN_00fa07b0();
  fVar1 = *(float *)(iVar10 + 0xb8);
  fVar2 = *(float *)(iVar10 + 0xb4);
  fVar3 = *(float *)(iVar10 + 0xbc);
  fVar4 = *(float *)(iVar10 + 0xc0);
  fVar5 = *(float *)(iVar10 + 0xc4);
  fVar6 = *(float *)(iVar10 + 200);
  fVar7 = *(float *)(iVar10 + 0xcc);
  fVar8 = *(float *)(iVar10 + 0xd0);
  fVar9 = *(float *)(iVar10 + 0xd4);
  iVar10 = *(int *)(*(int *)(iVar10 + 0x20) + 0x2c);
  if (iVar10 != 0) {
    FUN_00f9f070();
    *(float *)(iVar10 + 0x164) =
         fVar1 * 0.0 + fVar2 * 0.0 + fVar3 * fVar11 + *(float *)(iVar10 + 0x164);
    *(float *)(iVar10 + 0x168) =
         *(float *)(iVar10 + 0x168) + fVar5 * 0.0 + fVar4 * 0.0 + fVar6 * fVar11;
    *(float *)(iVar10 + 0x16c) =
         fVar8 * 0.0 + fVar7 * 0.0 + fVar9 * fVar11 + *(float *)(iVar10 + 0x16c);
  }
  return;
}



/* FUNCTION 29631 ; VA 0x00c8a210 ; FUN_00c8a210 */

void __thiscall FUN_00c8a210(int param_1,float param_2,float param_3,float param_4)

{
  *(float *)(param_1 + 0x200) = *(float *)(param_1 + 0x200) + param_2;
  *(float *)(param_1 + 0x204) = param_3 + *(float *)(param_1 + 0x204);
  *(float *)(param_1 + 0x208) = param_4 + *(float *)(param_1 + 0x208);
  return;
}



/* FUNCTION 29632 ; VA 0x00c8a260 ; FUN_00c8a260 */

void __thiscall FUN_00c8a260(int param_1,float param_2,float param_3,float param_4)

{
  *(float *)(param_1 + 0x200) = *(float *)(param_1 + 0x200) + param_2;
  *(float *)(param_1 + 0x204) = param_3 + *(float *)(param_1 + 0x204);
  *(float *)(param_1 + 0x208) = param_4 + *(float *)(param_1 + 0x208);
  return;
}



/* FUNCTION 29633 ; VA 0x00c8a2b0 ; FUN_00c8a2b0 */

void __fastcall FUN_00c8a2b0(int param_1)

{
  int iVar1;
  int iVar2;
  float10 fVar3;
  float fVar4;
  double dVar5;
  float fVar6;
  float fVar7;
  uint uVar8;
  float fVar9;
  float fVar10;
  undefined auStack_98 [36];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  float fStack_3c;
  undefined8 uStack_38;
  float fStack_30;
  float *pfStack_2c;
  undefined8 uStack_24;
  float fStack_1c;
  undefined8 uStack_18;
  undefined8 uStack_10;
  float fStack_8;
  
  fStack_8 = (float)(**(code **)(*(int *)(param_1 + -0xa8) + 0x44))();
  pfStack_2c = (float *)FUN_00b077e0();
  fStack_1c = *(float *)(*(int *)((int)fStack_8 + 0x20) + 0x2c);
  FUN_00fa07b0();
  uStack_74 = *(undefined4 *)((int)fStack_8 + 0xb4);
  uStack_70 = *(undefined4 *)((int)fStack_8 + 0xb8);
  uStack_6c = *(undefined4 *)((int)fStack_8 + 0xbc);
  uStack_68 = *(undefined4 *)((int)fStack_8 + 0xc0);
  uStack_64 = *(undefined4 *)((int)fStack_8 + 0xc4);
  uStack_60 = *(undefined4 *)((int)fStack_8 + 200);
  uStack_5c = *(undefined4 *)((int)fStack_8 + 0xcc);
  uStack_58 = *(undefined4 *)((int)fStack_8 + 0xd0);
  uStack_54 = *(undefined4 *)((int)fStack_8 + 0xd4);
  uStack_50 = *(undefined4 *)((int)fStack_8 + 0xd8);
  uStack_4c = *(undefined4 *)((int)fStack_8 + 0xdc);
  uStack_48 = *(undefined4 *)((int)fStack_8 + 0xe0);
  uStack_44 = *(undefined8 *)((int)fStack_8 + 0xe4);
  fStack_3c = *(float *)((int)fStack_8 + 0xec);
  uStack_38 = *(undefined8 *)((int)fStack_8 + 0xf0);
  fStack_30 = *(float *)((int)fStack_8 + 0xf8);
  iVar1 = FUN_011630b0(auStack_98);
  uVar8 = DAT_018c4ea0;
  uStack_10 = (double)CONCAT44(*(float *)(iVar1 + 0xc) * (float)uStack_38 +
                               *(float *)(iVar1 + 0x10) * uStack_38._4_4_ +
                               *(float *)(iVar1 + 0x14) * fStack_30,(undefined4)uStack_10);
  iVar2 = -*(int *)(param_1 + 0x34);
  uStack_18 = (double)CONCAT44(iVar2,(undefined4)uStack_18);
  fVar6 = (float)((uint)(*(float *)(iVar1 + 0x18) * (float)uStack_44 +
                         *(float *)(iVar1 + 0x1c) * uStack_44._4_4_ +
                        *(float *)(iVar1 + 0x20) * fStack_3c) ^ DAT_018c4ea0);
  *(float *)(param_1 + 0x68) = fVar6;
  if (*(int *)(param_1 + 0x30) < 1) {
    if ((*(int *)(param_1 + 0x30) < 0) && (DAT_018e452c < fVar6)) {
      fVar6 = (float)((uint)(*(float *)(param_1 + 0x88) * *(float *)(param_1 + 0x84)) ^ uVar8);
      goto LAB_00c8a412;
    }
  }
  else {
    if (0.0 <= fVar6) {
      if (*(float *)(param_1 + 0x80) <= fVar6) goto LAB_00c8a422;
      fVar6 = *(float *)(param_1 + 0x84);
    }
    else {
      fVar6 = *(float *)(param_1 + 0x88) * *(float *)(param_1 + 0x84);
    }
LAB_00c8a412:
    FUN_00c8a0e0(fVar6);
    iVar2 = (int)uStack_18._4_4_;
  }
LAB_00c8a422:
  fVar6 = *(float *)(param_1 + 0x2c);
  if (iVar2 < 1) {
    if (iVar2 < 0) {
      fVar7 = DAT_018f7864;
      if (DAT_018f7864 <= fVar6 - DAT_01972b7c) {
        fVar7 = fVar6 - DAT_01972b7c;
      }
      fVar6 = DAT_01972b80;
      if (fVar7 <= DAT_01972b80) {
        fVar6 = fVar7;
      }
      *(float *)(param_1 + 0x2c) = fVar6;
    }
    else {
      if (fVar6 <= DAT_01972b7c) {
        if (DAT_01900e74 <= fVar6) goto LAB_00c8a4a4;
        fVar6 = fVar6 + DAT_01972b7c;
      }
      else {
        fVar6 = fVar6 - DAT_01972b7c;
      }
      *(float *)(param_1 + 0x2c) = fVar6;
    }
  }
  else {
    fVar7 = DAT_018f9934;
    if (DAT_018f9934 <= fVar6 + DAT_01972b7c) {
      fVar7 = fVar6 + DAT_01972b7c;
    }
    fVar6 = DAT_018ce2f8;
    if (fVar7 <= DAT_018ce2f8) {
      fVar6 = fVar7;
    }
    *(float *)(param_1 + 0x2c) = fVar6;
  }
LAB_00c8a4a4:
  iVar2 = (**(code **)(*(int *)(param_1 + -0xa8) + 0x44))();
  dVar5 = (double)*(float *)(param_1 + 0x2c);
  if (DAT_018f9934 <
      (float)(double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) &
                              (uint)((ulonglong)DAT_018c0da0 >> 0x20),
                              SUB84(dVar5,0) & (uint)DAT_018c0da0)) {
    fVar6 = *(float *)(param_1 + 0x90);
    fVar4 = (*(float *)(param_1 + 0x8c) * *(float *)(param_1 + 0x2c) - uStack_10._4_4_) *
            *(float *)(param_1 + 0x94);
    fVar7 = (float)((uint)fVar6 ^ DAT_018c4ea0);
    if ((float)((uint)fVar6 ^ DAT_018c4ea0) <= fVar4) {
      fVar7 = fVar4;
    }
    if (fVar7 <= fVar6) {
      fVar6 = fVar7;
    }
    uStack_10._4_4_ = fVar6;
    FUN_00fa07b0();
    fVar6 = uStack_10._4_4_;
    uStack_10 = (double)CONCAT44(*(float *)(iVar2 + 0xb8) * uStack_10._4_4_ +
                                 *(float *)(iVar2 + 0xb4) * 0.0 + *(float *)(iVar2 + 0xbc) * 0.0,
                                 (undefined4)uStack_10);
    uStack_18 = (double)CONCAT44(*(float *)(iVar2 + 0xc4) * fVar6 + *(float *)(iVar2 + 0xc0) * 0.0 +
                                 *(float *)(iVar2 + 200) * 0.0,(undefined4)uStack_18);
    iVar1 = *(int *)(*(int *)(iVar2 + 0x20) + 0x2c);
    uStack_24 = (double)CONCAT44(*(float *)(iVar2 + 0xd0) * fVar6 + *(float *)(iVar2 + 0xcc) * 0.0 +
                                 *(float *)(iVar2 + 0xd4) * 0.0,(uint)uStack_24);
    if (iVar1 != 0) {
      FUN_00f9f070();
      *(float *)(iVar1 + 0x170) = uStack_10._4_4_ + *(float *)(iVar1 + 0x170);
      *(float *)(iVar1 + 0x174) = uStack_18._4_4_ + *(float *)(iVar1 + 0x174);
      *(float *)(iVar1 + 0x178) = uStack_24._4_4_ + *(float *)(iVar1 + 0x178);
    }
  }
  dVar5 = (double)(*(float *)(param_1 + 0x48) * *(float *)(param_1 + 0x48) +
                   *(float *)(param_1 + 0x4c) * *(float *)(param_1 + 0x4c) +
                  *(float *)(param_1 + 0x50) * *(float *)(param_1 + 0x50));
  fVar6 = fStack_8;
  if (NAN(dVar5) == (dVar5 == 0.0)) {
    uVar8 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    uStack_24 = (double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & uVar8,
                                 SUB84(dVar5,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    uStack_18 = (double)CONCAT44((uint)((ulonglong)(dVar5 - 0.0) >> 0x20) & uVar8,
                                 SUB84(dVar5 - 0.0,0) & (uint)DAT_018c0da0);
    fVar3 = (float10)FUN_01160810();
    fVar6 = fStack_8;
    uStack_10 = (double)fVar3;
    dVar5 = DAT_018f76b0;
    if ((NAN(uStack_24) || NAN(uStack_10)) == (uStack_24 == uStack_10)) {
      dVar5 = uStack_24 * DAT_018f76b0;
    }
    if (dVar5 < uStack_18) {
      iVar2 = *(int *)((int)fStack_8 + 0x24);
      if (iVar2 == 0) {
        if ((*(char *)((int)fStack_8 + 0x3c) == '\0') ||
           (*(float *)((int)fStack_8 + 0x20) == fStack_8)) {
          fStack_8 = *(float *)((int)fStack_8 + 0x84);
        }
        else {
          fStack_8 = 0.0;
        }
      }
      else {
        uStack_24._4_4_ = (float)iVar2;
        if (*(char *)(iVar2 + 4) != '\0') {
          FUN_00f958d0();
        }
        fStack_8 = *(float *)((int)uStack_24._4_4_ + 0x14);
      }
      uStack_24._4_4_ = *(float *)(*(int *)((int)fVar6 + 0x20) + 0x2c);
      uStack_10 = (double)CONCAT44(*(float *)(param_1 + 0x48) * fStack_8,(undefined4)uStack_10);
      uStack_18 = (double)CONCAT44(*(float *)(param_1 + 0x4c) * fStack_8,(undefined4)uStack_18);
      fStack_8 = *(float *)(param_1 + 0x50) * fStack_8;
      if (uStack_24._4_4_ != 0.0) {
        FUN_00f9f070();
        *(float *)((int)uStack_24._4_4_ + 0x17c) =
             *(float *)((int)uStack_24._4_4_ + 0x17c) + uStack_10._4_4_;
        *(float *)((int)uStack_24._4_4_ + 0x180) =
             *(float *)((int)uStack_24._4_4_ + 0x180) + uStack_18._4_4_;
        *(float *)((int)uStack_24._4_4_ + 0x184) =
             fStack_8 + *(float *)((int)uStack_24._4_4_ + 0x184);
      }
      uStack_24 = (double)(ulonglong)(uint)uStack_24;
      *(undefined8 *)(param_1 + 0x48) = 0;
      *(undefined4 *)(param_1 + 0x50) = 0;
    }
  }
  if ((*(int *)(param_1 + 100) == *(int *)(param_1 + 0x78)) && (*(char *)(param_1 + 0x54) != '\0'))
  {
    fVar7 = *(float *)((int)fStack_1c + 0x160);
    fVar9 = pfStack_2c[0xb] - *(float *)((int)fStack_1c + 0x44);
    fVar10 = pfStack_2c[9] - *(float *)((int)fStack_1c + 0x3c);
    iVar1 = *(int *)((int)fVar6 + 0x20);
    fVar4 = (pfStack_2c[10] - *(float *)((int)fStack_1c + 0x40)) * 0.0;
    iVar2 = *(int *)(iVar1 + 0x2c);
    fStack_1c = fVar4 - fVar9 * fVar7;
    uStack_18._4_4_ = fVar7;
    if (iVar2 != 0) {
      uStack_24._4_4_ = fVar9 * 0.0 - fVar10 * 0.0;
      uStack_10._4_4_ = fVar10 * fVar7 - fVar4;
      FUN_00f9f070();
      *(float *)(iVar2 + 0x170) = *(float *)(iVar2 + 0x170) + fStack_1c;
      *(float *)(iVar2 + 0x174) = uStack_24._4_4_ + *(float *)(iVar2 + 0x174);
      *(float *)(iVar2 + 0x178) = uStack_10._4_4_ + *(float *)(iVar2 + 0x178);
      iVar1 = *(int *)((int)fVar6 + 0x20);
    }
    iVar2 = *(int *)(iVar1 + 0x2c);
    fStack_1c = pfStack_2c[1] * uStack_18._4_4_ + *pfStack_2c * 0.0 + pfStack_2c[2] * 0.0;
    uStack_24._4_4_ = pfStack_2c[4] * uStack_18._4_4_ + pfStack_2c[3] * 0.0 + pfStack_2c[5] * 0.0;
    uStack_10._4_4_ = pfStack_2c[7] * uStack_18._4_4_ + pfStack_2c[6] * 0.0 + pfStack_2c[8] * 0.0;
    if (iVar2 != 0) {
      FUN_00f9f070();
      *(float *)(iVar2 + 0x164) = *(float *)(iVar2 + 0x164) + DAT_018f9988;
      *(float *)(iVar2 + 0x168) = uStack_18._4_4_ * DAT_018f7860 + *(float *)(iVar2 + 0x168);
      *(float *)(iVar2 + 0x16c) = *(float *)(iVar2 + 0x16c) + DAT_018f9988;
      iVar1 = *(int *)((int)fVar6 + 0x20);
    }
    iVar2 = *(int *)(iVar1 + 0x2c);
    if (iVar2 != 0) {
      FUN_00f9f070();
      *(float *)(iVar2 + 0x164) = fStack_1c + *(float *)(iVar2 + 0x164);
      *(float *)(iVar2 + 0x168) = uStack_24._4_4_ + *(float *)(iVar2 + 0x168);
      *(float *)(iVar2 + 0x16c) = uStack_10._4_4_ + *(float *)(iVar2 + 0x16c);
    }
  }
  return;
}



/* FUNCTION 29634 ; VA 0x00c8a980 ; FUN_00c8a980 */

undefined4 * __thiscall
FUN_00c8a980(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbbf1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x54) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0089f9f0;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x54 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29635 ; VA 0x00c8ab30 ; FUN_00c8ab30 */

undefined4 * __thiscall
FUN_00c8ab30(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbc31;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x54) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0089fb30;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x54 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29636 ; VA 0x00c8ace0 ; FUN_00c8ace0 */

undefined4 * __thiscall
FUN_00c8ace0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180fb11;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x54) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00c8ba90;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x54 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29637 ; VA 0x00c8ae90 ; FUN_00c8ae90 */

void FUN_00c8ae90(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c8d570();
    *param_2 = uVar3;
    iVar4 = FUN_00c8d620();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 29638 ; VA 0x00c8aef0 ; FUN_00c8aef0 */

void FUN_00c8aef0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c8d570();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29639 ; VA 0x00c8af30 ; FUN_00c8af30 */

int __fastcall FUN_00c8af30(int param_1)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  float *pfVar4;
  int iVar5;
  int iVar6;
  float fVar7;
  float fVar8;
  undefined4 **ppuStack_b0;
  float *pfStack_ac;
  undefined4 *apuStack_9c [4];
  float afStack_8c [8];
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined8 uStack_60;
  float fStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined **appuStack_48 [2];
  int *piStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  undefined ***pppuStack_30;
  undefined2 uStack_2c;
  undefined uStack_2a;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fb38;
  pvStack_10 = ExceptionList;
  pfStack_ac = (float *)0xc8af58;
  ExceptionList = &pvStack_10;
  pfVar4 = (float *)FUN_00b077e0();
  fStack_18 = (*pfVar4 * DAT_018f9988 - pfVar4[1] * DAT_018ce2f8) + pfVar4[2] * DAT_018f9988;
  fStack_1c = (pfVar4[3] * DAT_018f9988 - pfVar4[4] * DAT_018ce2f8) + pfVar4[5] * DAT_018f9988;
  fVar7 = pfVar4[7] * DAT_018ce2f8;
  fVar8 = pfVar4[6] * DAT_018f9988;
  fStack_14 = pfVar4[8] * DAT_018f9988;
  pfStack_ac = (float *)&iStack_24;
  *(undefined4 *)(param_1 + 0x21c) = 0;
  fStack_14 = (fVar8 - fVar7) + fStack_14;
  ppuStack_b0 = (undefined ****)0xc8aff8;
  iVar5 = FUN_00587490();
  iStack_8 = 0;
  if (((iStack_24 != 0) && (*(int *)(param_1 + 0x210) != 0)) &&
     (iVar6 = 0, 0 < *(int *)(param_1 + 0x230))) {
    fStack_3c = fStack_18 + fStack_18;
    fStack_38 = fStack_1c + fStack_1c;
    fStack_34 = fStack_14 + fStack_14;
    do {
      ppuStack_b0 = apuStack_9c;
      pfStack_ac = (float *)0x1;
      iVar5 = FUN_00ca3fa0();
      uStack_6c = *(undefined8 *)(iVar5 + 0x24);
      uStack_64 = *(undefined4 *)(iVar5 + 0x2c);
      uStack_60 = CONCAT44(fStack_38,fStack_3c);
      fStack_58 = fStack_34;
      if (*(int *)(iStack_24 + 0x34) == 0) {
LAB_00c8b16f:
        iVar5 = *(int *)(param_1 + 0x22c);
        *(undefined *)(iVar5 + 4 + iVar6 * 8) = 0;
      }
      else {
        FUN_0060dcd0(&ppuStack_b0,*(int *)(iStack_24 + 0x34));
        FUN_00f9b8c0();
        uStack_54 = 0;
        uStack_50 = 0;
        uStack_4c = 0;
        pppuStack_30 = appuStack_48;
        iStack_8._0_1_ = 2;
        pfStack_ac = afStack_8c;
        afStack_8c[5] = 0.0;
        ppuStack_b0 = &pppuStack_30;
        afStack_8c[6] = 0.0;
        uStack_2c = 0;
        afStack_8c[1] = 0.0;
        afStack_8c[2] = 0.0;
        afStack_8c[3] = 0.0;
        afStack_8c[4] = 0.0;
        uStack_2a = 0;
        uStack_28 = 0;
        cVar3 = FUN_00ce2b90(&uStack_6c);
        piVar2 = piStack_40;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        fStack_14 = 0.0;
        if (cVar3 != '\0') {
          fStack_14 = afStack_8c[0];
        }
        if (piStack_40 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_40[1] + -1;
          piStack_40[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            pfStack_ac = (float *)0xc8b13e;
            (**(code **)*piStack_40)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar5 = *piVar1 + -1;
            *piVar1 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              pfStack_ac = (float *)0xc8b14f;
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        appuStack_48[0] = RBX::HitTestFilter::vftable;
        if (fStack_14 == 0.0) goto LAB_00c8b16f;
        iVar5 = *(int *)(param_1 + 0x22c);
        *(undefined *)(iVar5 + 4 + iVar6 * 8) = 1;
        *(int *)(param_1 + 0x21c) = *(int *)(param_1 + 0x21c) + 1;
      }
      iVar6 = iVar6 + 1;
    } while (iVar6 < *(int *)(param_1 + 0x230));
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_20 + 1;
    iVar6 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      pfStack_ac = (float *)0xc8b1a0;
      iVar5 = (**(code **)*piStack_20)();
      LOCK();
      piVar2 = piStack_20 + 2;
      iVar6 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        pfStack_ac = (float *)0xc8b1af;
        iVar5 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 29640 ; VA 0x00c8b1c0 ; FUN_00c8b1c0 */

undefined4 * FUN_00c8b1c0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c89230(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29641 ; VA 0x00c8b230 ; FUN_00c8b230 */

void FUN_00c8b230(void)

{
  FUN_00c8b430();
  return;
}



/* FUNCTION 29642 ; VA 0x00c8b240 ; FUN_00c8b240 */

void __thiscall FUN_00c8b240(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  code *pcVar3;
  int *piVar4;
  int iVar5;
  double *pdVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cec9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  iVar5 = FUN_0097ee20(param_2);
  if (iVar5 == 1) {
    pdVar6 = (double *)FUN_01682800(auStack_40);
    if ((double)DAT_01d68a54 < *pdVar6 - *(double *)(param_1 + 0x40)) {
      puVar7 = (undefined4 *)FUN_0060dcd0(auStack_40,param_2);
      uVar1 = *puVar7;
      uVar2 = puVar7[1];
      *puVar7 = 0;
      puVar7[1] = 0;
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_38 = 0;
      uStack_34 = 0;
      uStack_8._0_1_ = 2;
      uStack_8._1_3_ = 0;
      pcVar3 = *(code **)(*piStack_14 + 8);
      uStack_1c = uVar1;
      uStack_18 = uVar2;
      uStack_110 = FUN_0088cdc0();
      uStack_10c = 0;
      uStack_1c = 0;
      uStack_18 = 0;
      uStack_108 = uVar1;
      uStack_104 = uVar2;
      uStack_10c = FUN_006309e0();
      uStack_8._0_1_ = 3;
      uStack_28 = 0;
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_00687980(&uStack_110,auStack_40,pcVar3);
      piVar4 = piStack_14;
      uStack_8._0_1_ = 4;
      (*pcVar3)(&DAT_0213a0c8,&uStack_28,&uStack_30);
      uStack_8._0_1_ = 5;
      FUN_00577b20();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_016f32d1(&uStack_110,0xd0,1,FUN_0056e5b0);
      uStack_8 = 0xffffffff;
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          iVar5 = piStack_3c[2] + -1;
          piStack_3c[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_3c + 4))();
          }
        }
      }
      piVar8 = (int *)FUN_01682800(&uStack_38);
      piVar4[0x40] = *piVar8;
      piVar4[0x41] = piVar8[1];
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    FUN_00c8b430(param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29643 ; VA 0x00c8b430 ; FUN_00c8b430 */

void __thiscall FUN_00c8b430(undefined4 param_1,uint param_2)

{
  code *pcVar1;
  int iVar2;
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined *puStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  int *apiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fb60;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_009b7250();
    if (iVar2 != 0) {
      FUN_009b77e0();
      FUN_0060efa0();
      puStack_28 = &DAT_bf800000;
      uStack_24 = 0;
      puStack_20 = &DAT_bf800000;
      uStack_1c = 0;
      FUN_01163c80(&uStack_24,0,&DAT_bf800000);
      FUN_00b08320();
      puStack_28 = (undefined *)0x0;
      FUN_0060efa0();
      puStack_28 = &DAT_bf800000;
      uStack_24 = 0;
      puStack_20 = &DAT_bf800000;
      uStack_1c = 0;
      FUN_01163c80(&uStack_24,0,&DAT_bf800000);
      puStack_28 = (undefined *)0x0;
      iVar2 = FUN_00c155c0();
      if (iVar2 != 0) {
        FUN_00ca1550();
        if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
            DAT_01ef8e20) {
          FUN_016f3809(&DAT_01ef8e20);
          if (DAT_01ef8e20 == -1) {
            DAT_01ef8e14._4_4_ = 0;
            DAT_01ef8e08._0_4_ = 0;
            DAT_01ef8e08._4_4_ = 0;
            DAT_01ef8e10 = 0;
            DAT_01ef8e14._0_4_ = 0;
            DAT_01ef8e1c = 0;
            FUN_016f37bf(&DAT_01ef8e20);
          }
        }
        FUN_00c19180(&DAT_01ef8e08);
        FUN_0099f370(apiStack_18);
        iStack_8 = 0;
        uStack_2c = 0;
        puStack_28 = (undefined *)0xf;
        auStack_3c[0] = 0;
        pcVar1 = *(code **)(*apiStack_18[0] + 0x38);
        FUN_005542c0();
        iStack_8._0_1_ = 1;
        (*pcVar1)(auStack_3c);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
        FUN_00c3d740();
        FUN_00c3d770();
        FUN_00c3ceb0();
        FUN_00c3cee0();
        param_2 = param_2 & 0xffffff;
        (**(code **)(*DAT_02119b74 + 0x10))(apiStack_18[0],(int)&param_2 + 3);
        FUN_008a65e0(param_1,0);
        FUN_00550b30();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29644 ; VA 0x00c8b6c0 ; FUN_00c8b6c0 */

int __thiscall FUN_00c8b6c0(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  bool bVar4;
  bool bVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180cf30;
  pvStack_10 = ExceptionList;
  uStack_18 = param_1;
  iStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar8 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar6 = FUN_0099be20();
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      iStack_14 = param_2;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      piStack_24 = param_3;
      bVar5 = true;
      bVar4 = false;
      puVar7 = &uStack_28;
      goto LAB_00c8b74e;
    }
  }
  piStack_1c = (int *)0x0;
  puVar7 = &uStack_20;
  iStack_14 = 0;
  bVar5 = false;
  bVar4 = true;
LAB_00c8b74e:
  piVar3 = (int *)puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  if (bVar4) {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar8 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar8 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  piVar2 = piStack_24;
  if ((bVar5) && (piStack_24 != (int *)0x0)) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar8 = FUN_00c8b430(iStack_14);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar2 = piVar3 + 1;
    iVar6 = *piVar2;
    iVar8 = *piVar2;
    *piVar2 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar6 = *piVar2;
      iVar8 = *piVar2;
      *piVar2 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar8 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar6 = *piVar3;
    iVar8 = *piVar3;
    *piVar3 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar8 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar6 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar8 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 29645 ; VA 0x00c8b830 ; FUN_00c8b830 */

int FUN_00c8b830(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180fb90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_20);
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((iStack_20 != 0) && (iVar3 = iStack_18, iStack_18 != 0)) &&
     (*(int *)(iStack_20 + 0x34) == iStack_18)) {
    iVar3 = FUN_008b2e60(iStack_18);
    if (iVar3 == 0) {
      FUN_00550b30();
      iVar3 = FUN_00550b30();
      goto LAB_00c8b8fb;
    }
    iVar3 = FUN_008a65e0(iVar3,0);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
LAB_00c8b8fb:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29646 ; VA 0x00c8b940 ; FUN_00c8b940 */

int FUN_00c8b940(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_3) {
    ExceptionList = &pvStack_10;
    param_1 = FUN_00c8c0a0(param_1);
    if (param_1 != 0) {
      param_1 = FUN_008a65e0(0,0);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_1 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_1 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29647 ; VA 0x00c8b9c0 ; FUN_00c8b9c0 */

void __thiscall FUN_00c8b9c0(int param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint *puVar5;
  int *piStack_18;
  uint uStack_14;
  undefined auStack_10 [4];
  uint uStack_c;
  int iStack_8;
  
  iVar4 = 0;
  iStack_8 = param_1;
  if (0 < *(int *)(param_2 + 0x14)) {
    do {
      iVar2 = *(int *)(*(int *)(param_2 + 0x10) + iVar4 * 4);
      piVar3 = (int *)(iVar2 + 0x24);
      if (iVar2 == 0) {
        piVar3 = (int *)0x2c;
      }
      piVar3 = (int *)(-(uint)(*piVar3 != 0) & *piVar3 - 8U);
      iVar2 = (**(code **)(*piVar3 + 0x10))();
      if (iVar2 == 7) {
        iVar2 = *(int *)(param_1 + 0x230);
        puVar5 = (uint *)(param_1 + 0x22c);
        uStack_c = uStack_c & 0xffffff00;
        if (iVar2 < *(int *)(param_1 + 0x234)) {
          uVar1 = *puVar5;
          *(int **)(uVar1 + iVar2 * 8) = piVar3;
          *(uint *)(uVar1 + 4 + iVar2 * 8) = uStack_c;
          *(int *)(param_1 + 0x230) = *(int *)(param_1 + 0x230) + 1;
          param_1 = iStack_8;
        }
        else if ((auStack_10 < (undefined *)*puVar5) ||
                ((undefined *)*puVar5 + iVar2 * 8 <= auStack_10)) {
          FUN_00c8d290(iVar2 + 1,0);
          uVar1 = *puVar5;
          iVar2 = *(int *)(param_1 + 0x230);
          *(int **)((uVar1 - 8) + iVar2 * 8) = piVar3;
          *(uint *)((uVar1 - 4) + iVar2 * 8) = uStack_c;
          param_1 = iStack_8;
        }
        else {
          uStack_14 = uStack_c;
          piStack_18 = piVar3;
          FUN_00c8a050(&piStack_18);
          param_1 = iStack_8;
        }
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < *(int *)(param_2 + 0x14));
  }
  return;
}



/* FUNCTION 29648 ; VA 0x00c8ba90 ; FUN_00c8ba90 */

void FUN_00c8ba90(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_00c8d570();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_00c8d620();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_00c8d570();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_00c8d620();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29649 ; VA 0x00c8bbc0 ; thunk_FUN_00c8bc70 */

void __fastcall thunk_FUN_00c8bc70(int param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  
LAB_00c8bc80:
  uVar9 = 0;
  iVar4 = FUN_005d6c30();
  if (iVar4 == 0) {
    return;
  }
  do {
    iVar4 = *(int *)(**(int **)(param_1 + 0x2c) + uVar9 * 8);
    piVar5 = *(int **)(iVar4 + 0x28);
    piVar1 = piVar5 + 4;
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    cVar3 = FUN_0055c360(piVar5,*piVar1,"PlatformMotor6D",0xf);
    if (cVar3 != '\0') {
      iVar2 = *(int *)(iVar4 + 0xc);
      iVar6 = FUN_00c395b0();
      iVar8 = 0;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        iVar8 = iVar4;
      }
      if (iVar8 != 0) break;
    }
    uVar9 = uVar9 + 1;
    uVar7 = FUN_005d6c30();
    if (uVar7 <= uVar9) {
      return;
    }
  } while( true );
  FUN_008a65e0(0,0);
  goto LAB_00c8bc80;
}



/* FUNCTION 29650 ; VA 0x00c8bbd0 ; FUN_00c8bbd0 */

void __fastcall FUN_00c8bbd0(int *param_1)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9648;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  (**(code **)(*param_1 + 8))(&DAT_0213a110,&uStack_24,&uStack_18);
  uStack_8 = 1;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29651 ; VA 0x00c8bc70 ; FUN_00c8bc70 */

void __fastcall FUN_00c8bc70(int param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  
LAB_00c8bc80:
  uVar9 = 0;
  iVar4 = FUN_005d6c30();
  if (iVar4 == 0) {
    return;
  }
  do {
    iVar4 = *(int *)(**(int **)(param_1 + 0x2c) + uVar9 * 8);
    piVar5 = *(int **)(iVar4 + 0x28);
    piVar1 = piVar5 + 4;
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    cVar3 = FUN_0055c360(piVar5,*piVar1,"PlatformMotor6D",0xf);
    if (cVar3 != '\0') {
      iVar2 = *(int *)(iVar4 + 0xc);
      iVar6 = FUN_00c395b0();
      iVar8 = 0;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        iVar8 = iVar4;
      }
      if (iVar8 != 0) break;
    }
    uVar9 = uVar9 + 1;
    uVar7 = FUN_005d6c30();
    if (uVar7 <= uVar9) {
      return;
    }
  } while( true );
  FUN_008a65e0(0,0);
  goto LAB_00c8bc80;
}



/* FUNCTION 29652 ; VA 0x00c8bd10 ; FUN_00c8bd10 */

int __fastcall FUN_00c8bd10(int param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  
  uVar9 = 0;
  iVar4 = FUN_005d6c30();
  if (iVar4 != 0) {
    do {
      iVar4 = *(int *)(**(int **)(param_1 + 0x2c) + uVar9 * 8);
      piVar5 = *(int **)(iVar4 + 0x28);
      piVar1 = piVar5 + 4;
      if (0xf < (uint)piVar5[5]) {
        piVar5 = (int *)*piVar5;
      }
      cVar3 = FUN_0055c360(piVar5,*piVar1,"PlatformMotor6D",0xf);
      if (cVar3 != '\0') {
        iVar2 = *(int *)(iVar4 + 0xc);
        iVar6 = FUN_00c395b0();
        iVar8 = 0;
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          iVar8 = iVar4;
        }
        if (iVar8 != 0) {
          return iVar8;
        }
      }
      uVar9 = uVar9 + 1;
      uVar7 = FUN_005d6c30();
    } while (uVar9 < uVar7);
  }
  return 0;
}



/* FUNCTION 29653 ; VA 0x00c8bda0 ; FUN_00c8bda0 */

void FUN_00c8bda0(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbef8;
  pvStack_10 = ExceptionList;
  iVar6 = *param_2;
  iVar4 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cdc0();
  if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined4 *)(iVar6 + 0xd8);
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  iVar6 = puVar3[1];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = puVar3[1];
  }
  uVar1 = *puVar3;
  param_2 = (int *)*param_2;
  uStack_8 = 0;
  iVar4 = *param_2;
  iVar2 = FUN_0088cdc0();
  if (iVar4 == iVar2) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar4 = piVar5[1];
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar5[1];
    }
    uStack_8 = 2;
    FUN_0089bce0(*piVar5,iVar4,uVar1,iVar6);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29654 ; VA 0x00c8bec0 ; FUN_00c8bec0 */

void FUN_00c8bec0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar1 = *param_2;
  iVar5 = *(int *)(iVar1 + 0xd0);
  iVar3 = FUN_00c8d570();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar1 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar1 = *param_2;
    uVar2 = *puVar4;
    iVar5 = FUN_00c8d570();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_006150c0(*piVar6,uVar2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29655 ; VA 0x00c8bf50 ; FUN_00c8bf50 */

void FUN_00c8bf50(void)

{
  int iVar1;
  
  if (DAT_01f013ac == 0) {
    iVar1 = FUN_00c88fe0();
    DAT_01f013ac = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29656 ; VA 0x00c8bf80 ; FUN_00c8bf80 */

undefined4 FUN_00c8bf80(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 29657 ; VA 0x00c8bfe0 ; FUN_00c8bfe0 */

undefined4 __fastcall FUN_00c8bfe0(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(*(int *)(param_1 + -0x68) + 0x70);
  if (*(int *)(param_1 + -0x68) == 0) {
    puVar1 = (undefined4 *)&DAT_00000020;
  }
  return *puVar1;
}



/* FUNCTION 29658 ; VA 0x00c8bff3 ; FUN_00c8bff3 */

void FUN_00c8bff3(void)

{
  FUN_00afc020();
  return;
}



/* FUNCTION 29659 ; VA 0x00c8c001 ; FUN_00c8c001 */

void FUN_00c8c001(void)

{
  FUN_00afc020();
  return;
}



/* FUNCTION 29660 ; VA 0x00c8c040 ; FUN_00c8c040 */

void __thiscall FUN_00c8c040(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c8d570();
  *param_3 = uVar3;
  iVar4 = FUN_00c8d620();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 29661 ; VA 0x00c8c0a0 ; FUN_00c8c0a0 */

int FUN_00c8c0a0(int param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  
  piVar4 = *(int **)(param_1 + 0x28);
  piVar1 = piVar4 + 4;
  if (0xf < (uint)piVar4[5]) {
    piVar4 = (int *)*piVar4;
  }
  cVar3 = FUN_0055c360(piVar4,*piVar1,"PlatformMotor6D",0xf);
  if (cVar3 != '\0') {
    iVar2 = *(int *)(param_1 + 0xc);
    iVar5 = FUN_00c395b0();
    iVar6 = 0;
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      iVar6 = param_1;
    }
    if (iVar6 != 0) {
      return iVar6;
    }
  }
  return 0;
}



/* FUNCTION 29662 ; VA 0x00c8c100 ; FUN_00c8c100 */

uint FUN_00c8c100(void)

{
  int iVar1;
  
  iVar1 = FUN_00c88fe0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29663 ; VA 0x00c8c120 ; FUN_00c8c120 */

uint FUN_00c8c120(void)

{
  int iVar1;
  
  iVar1 = FUN_00c88fe0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29664 ; VA 0x00c8c140 ; FUN_00c8c140 */

void FUN_00c8c140(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c8d570();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29665 ; VA 0x00c8c180 ; FUN_00c8c180 */

void FUN_00c8c180(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_00bd7070(param_1);
      if (param_3 != 1) {
        return;
      }
      piVar2 = *(int **)(param_1 + 0x10);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      piVar2 = *(int **)(param_1 + 8);
      if (piVar2 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00c8c23a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
    if (param_3 == 2) {
      piVar2 = (int *)param_2[4];
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      piVar2 = (int *)param_2[2];
      if (piVar2 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00c8c1d7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1e10784);
      iVar4 = 0;
      if (iVar3 == 0) {
        iVar4 = param_1;
      }
      *param_2 = iVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::ModelInstance>,class_std::weak_ptr<class_RBX::ModelInstance>),class_boost::_bi::list2<class_boost::_bi::value<class_std::weak_ptr<class_RBX::ModelInstance>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::ModelInstance>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 29666 ; VA 0x00c8c250 ; FUN_00c8c250 */

void FUN_00c8c250(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1e1082c);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::PlatformImpl<class_RBX::BasicPartInstance>,class_std::shared_ptr<class_RBX::Instance>_>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::PlatformImpl<class_RBX::BasicPartInstance>*>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 29667 ; VA 0x00c8c2c0 ; FUN_00c8c2c0 */

void __thiscall FUN_00c8c2c0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  FUN_00b09c70(param_2);
  iVar4 = FUN_008b45a0(param_1);
  if (iVar4 != *(int *)(param_1 + 0x210)) {
    if (*(int *)(param_1 + 0x224) != 0) {
      FUN_008a65e0(0,0);
      *(undefined4 *)(param_1 + 0x224) = 0;
      piVar2 = *(int **)(param_1 + 0x228);
      *(undefined4 *)(param_1 + 0x228) = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      *(undefined4 *)(param_1 + 0x214) = 0;
      piVar2 = *(int **)(param_1 + 0x218);
      *(undefined4 *)(param_1 + 0x218) = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0x210) != 0) {
      FUN_00c3dac0(param_1 + 0x110,0,1);
      FUN_00ca4900(0,0);
      FUN_00ca4900(1,0);
    }
    *(int *)(param_1 + 0x210) = iVar4;
    if (iVar4 != 0) {
      FUN_00ca4900(0,*(undefined4 *)(param_1 + 0xa8));
      FUN_00ca4900(1,*(undefined4 *)(*(int *)(param_1 + 0x210) + 0xd4));
      FUN_00c3dac0(param_1 + 0x110,*(undefined4 *)(param_1 + 0x210),1);
    }
  }
  return;
}



/* FUNCTION 29668 ; VA 0x00c8c3f0 ; FUN_00c8c3f0 */

void __thiscall FUN_00c8c3f0(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_40;
  code *pcStack_3c;
  undefined4 uStack_38;
  undefined *puStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1c21;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00c8c0a0(param_2);
  if (iVar3 != 0) {
    pcStack_3c = FUN_00c8b940;
    uStack_38 = 0;
    puStack_34 = (undefined *)0x0;
    uStack_30 = iStack_28;
    piStack_2c = param_1;
    iStack_28 = iVar3;
    FUN_00c63880(&pcStack_3c);
    uVar4 = FUN_00c3c020();
    iStack_14 = FUN_009ade20(uVar4);
    if (iStack_14 != 0) {
      iStack_20 = iStack_14;
      FUN_009c44c0(1);
      iStack_14 = iStack_14 + 0x780;
      puStack_34 = &LAB_00c662e0;
      uStack_30 = 0;
      piStack_2c = (int *)0x0;
      iStack_8 = 0;
      uVar4 = FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 1;
      uStack_24 = uVar4;
      puStack_18 = (undefined4 *)FUN_01674e20(0x30);
      if (puStack_18 == (undefined4 *)0x0) {
        puStack_18 = (undefined4 *)0x0;
      }
      else {
        *puStack_18 = 0;
        puStack_18[1] = 1;
        puStack_18[2] = FUN_00c65510;
        puStack_18[3] = _guard_check_icall;
        puStack_18[4] = 0;
        puStack_18[6] = puStack_34;
        puStack_18[7] = uStack_30;
        puStack_18[8] = piStack_2c;
        puStack_18[9] = iStack_28;
        puStack_18[5] = iStack_14;
        *(ulonglong *)(puStack_18 + 10) = CONCAT44(uStack_40,param_1);
      }
      FUN_016797d0(puStack_18);
      param_2 = puStack_18;
      if (puStack_18 != (undefined4 *)0x0) {
        LOCK();
        puStack_18[1] = puStack_18[1] + 1;
        UNLOCK();
      }
      uStack_1c = 1;
      iStack_8._0_1_ = 2;
      FUN_01675290(uVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      cVar2 = FUN_01679300(&param_2);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_2);
      }
      iStack_8 = 0xffffffff;
      if (param_2 != (undefined4 *)0x0) {
        piVar1 = param_2 + 1;
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(param_2);
        }
      }
      (**(code **)(*param_1 + 0x164))(1,iStack_20);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29669 ; VA 0x00c8c5d0 ; FUN_00c8c5d0 */

void __thiscall FUN_00c8c5d0(int *param_1,undefined4 param_2)

{
  code *pcVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined auStack_c [8];
  
  iVar2 = FUN_00c8c0a0(param_2);
  if (iVar2 != 0) {
    FUN_01679490();
    piVar3 = (int *)FUN_01682800(auStack_c);
    param_1[0x3e] = *piVar3;
    param_1[0x3f] = piVar3[1];
    pcVar1 = *(code **)(*param_1 + 0x164);
    uVar4 = FUN_00c3c020();
    uVar4 = FUN_009ade20(uVar4);
    (*pcVar1)(0,uVar4);
  }
  return;
}



/* FUNCTION 29670 ; VA 0x00c8c640 ; FUN_00c8c640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

double * __thiscall FUN_00c8c640(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  double *pdVar3;
  double *pdVar4;
  double *pdVar5;
  undefined auStack_1c [4];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pdVar3 = (double *)FUN_009ade20(param_2);
  pdVar5 = pdVar3;
  if ((((((pdVar3 != (double *)0x0) &&
         (pdVar4 = (double *)FUN_009b7250(), pdVar5 = pdVar4, pdVar4 != (double *)0x0)) &&
        (pdVar5 = (double *)FUN_01682800(auStack_18),
        _PTR_018dad08 < *pdVar5 - *(double *)(param_1 + 0x3e))) &&
       ((pdVar5 = (double *)FUN_00c8bd10(), pdVar5 == (double *)0x0 &&
        (pdVar5 = *(double **)((int)pdVar3 + 0x22c), *(char *)pdVar5 == (char)pdVar5)))) &&
      ((pdVar5 = (double *)FUN_009b4a80(), (char)pdVar5 == '\0' &&
       ((pdVar5 = (double *)FUN_00b03420(), (char)pdVar5 == '\0' &&
        (pdVar5 = (double *)FUN_008b0500(pdVar4), (char)pdVar5 != '\0')))))) &&
     (pdVar5 = (double *)FUN_008b0500(param_1), (char)pdVar5 != '\0')) {
    FUN_00b077e0();
    pdVar5 = (double *)FUN_011612d0(auStack_1c,1);
    if (DAT_01901f3c < *(float *)((int)pdVar5 + 4)) {
      pdVar5 = (double *)(**(code **)(*param_1 + 0x15c))(pdVar3);
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pdVar5 = (double *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pdVar5 = (double *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pdVar5 = (double *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pdVar5;
}



/* FUNCTION 29671 ; VA 0x00c8c760 ; FUN_00c8c760 */

void FUN_00c8c760(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined *puStack_7c;
  int iStack_78;
  undefined auStack_74 [4];
  undefined4 uStack_70;
  undefined auStack_6c [20];
  undefined4 uStack_58;
  undefined4 uStack_3c;
  undefined *puStack_38;
  int iStack_34;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined *puStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fbb0;
  pvStack_10 = ExceptionList;
  puStack_38 = (undefined *)0xc8c789;
  ExceptionList = &pvStack_10;
  iStack_18 = FUN_008b2e60();
  if (iStack_18 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  piVar1 = (int *)(iStack_18 + 0x144);
  iStack_34 = 0xc8c7a8;
  (**(code **)(*(int *)(iStack_18 + 0x144) + 4))();
  iStack_34 = param_1;
  puStack_38 = (undefined *)0xc8c7b3;
  FUN_00d24b00();
  iStack_34 = 0xc8c7ba;
  (**(code **)(*piVar1 + 4))();
  iStack_34 = 5;
  puStack_38 = (undefined *)0xc8c7c3;
  FUN_00d24d00();
  puStack_38 = auStack_24;
  iStack_34 = param_1;
  uStack_3c = 0xc8c7cd;
  puVar2 = (undefined4 *)FUN_0060dcd0();
  uStack_8 = 0;
  puStack_38 = (undefined *)*puVar2;
  iStack_34 = puVar2[1];
  *puVar2 = 0;
  puVar2[1] = 0;
  uStack_3c = 0xc8c807;
  FUN_0089be10();
  uStack_8 = 0xffffffff;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      iStack_34 = 0xc8c827;
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iStack_34 = 0xc8c836;
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  iStack_34 = 0;
  puStack_38 = (undefined *)0xc8c842;
  FUN_009c44c0();
  param_1 = *(int *)(param_1 + 0x34);
  if (param_1 == 0) {
LAB_00c8c86f:
    param_1 = 0;
  }
  else {
    iVar5 = *(int *)(param_1 + 0xc);
    iStack_34 = 0xc8c854;
    iVar3 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar3 + 0x1da) <
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) goto LAB_00c8c86f;
  }
  iVar5 = *(int *)(iStack_14 + 0x34);
  if (iVar5 != 0) {
    iVar3 = *(int *)(iVar5 + 0xc);
    iStack_34 = 0xc8c886;
    iVar4 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) goto LAB_00c8c8a3;
  }
  iVar5 = 0;
LAB_00c8c8a3:
  iStack_34 = iStack_18;
  puStack_38 = (undefined *)0xc8c8ab;
  iStack_18 = FUN_008f7870();
  if ((((iStack_18 != 0) && (iVar5 != 0)) && (param_1 != 0)) && (*(int *)(iVar5 + 0x34) == param_1))
  {
    iStack_34 = 1;
    uStack_58 = 0;
    puStack_1c = auStack_74;
    puStack_7c = auStack_74;
    iStack_78 = param_1;
    FUN_0060e0c0();
    uStack_8 = 1;
    FUN_0060e0c0(&puStack_7c,iVar5);
    uStack_8 = 0xffffffff;
    FUN_00bd6ae0(auStack_6c,FUN_00c8b830);
    uStack_70 = 0xc8c910;
    FUN_00c88ea0();
    uStack_58 = 0xc8c918;
    FUN_0090ca30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29672 ; VA 0x00c8c930 ; FUN_00c8c930 */

void __thiscall FUN_00c8c930(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  undefined *puVar8;
  int iStack_38;
  char *pcStack_34;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fbd0;
  pvStack_10 = ExceptionList;
  iStack_38 = 0xc8c956;
  ExceptionList = &pvStack_10;
  pcStack_34 = (char *)param_1;
  puStack_1c = (undefined *)FUN_008b2e60();
  if (puStack_1c == (undefined *)0x0) {
    ExceptionList = pvStack_10;
    return;
  }
  if (param_1 == 0) {
LAB_00c8c9b4:
    iStack_14 = 0;
  }
  else {
    iVar1 = *(int *)(param_1 + 0x34);
    iVar4 = param_1;
    if ((iVar1 != 0) && (iVar4 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      pcStack_34 = (char *)0xc8c97b;
      iVar4 = FUN_005c8ac0();
    }
    if (iVar4 == 0) goto LAB_00c8c9b4;
    iVar1 = *(int *)(iVar4 + 0xc);
    pcStack_34 = (char *)0xc8c98d;
    iVar4 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) goto LAB_00c8c9b4;
    pcStack_34 = (char *)0xc8c9af;
    iStack_14 = FUN_008e1b70();
  }
  pcStack_34 = auStack_24;
  iStack_38 = 0xc8c9c4;
  puVar5 = (undefined4 *)FUN_00c67cb0();
  uVar7 = *puVar5;
  uVar2 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x224) = uVar7;
  piVar3 = *(int **)(param_1 + 0x228);
  *(undefined4 *)(param_1 + 0x228) = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = piVar3[1] + -1;
    piVar3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      pcStack_34 = (char *)0xc8ca01;
      (**(code **)*piVar3)();
      LOCK();
      iVar1 = piVar3[2] + -1;
      piVar3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        pcStack_34 = (char *)0xc8ca11;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_20[1] + -1;
    piStack_20[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      pcStack_34 = (char *)0xc8ca27;
      (**(code **)*piStack_20)();
      LOCK();
      piVar3 = piStack_20 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        pcStack_34 = (char *)0xc8ca36;
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  iStack_38 = 0xc8ca42;
  pcStack_34 = (char *)param_1;
  FUN_00c686d0();
  pcStack_34 = (char *)0x0;
  iStack_38 = iStack_14;
  FUN_008a65e0();
  puVar8 = puStack_1c;
  pcStack_34 = (char *)0xc8ca64;
  (**(code **)(*(int *)((int)puStack_1c + 0x144) + 4))();
  iStack_38 = 0xc8ca6c;
  pcStack_34 = (char *)param_1;
  FUN_00d24b00();
  pcStack_34 = (char *)0xc8ca7b;
  (**(code **)(*(int *)((int)puVar8 + 0x144) + 4))();
  pcStack_34 = (char *)0x5;
  iStack_38 = 0xc8ca84;
  FUN_00d24d00();
  iStack_14 = *(int *)(param_2 + 0x34);
  if (iStack_14 != 0) {
    iVar1 = *(int *)(iStack_14 + 0xc);
    pcStack_34 = (char *)0xc8ca99;
    iVar4 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) goto LAB_00c8cabb;
  }
  iStack_14 = 0;
LAB_00c8cabb:
  iVar1 = *(int *)(param_1 + 0x34);
  if (iVar1 != 0) {
    iVar4 = *(int *)(iVar1 + 0xc);
    pcStack_34 = (char *)0xc8cace;
    iVar6 = FUN_00b63e30();
    if ((((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) && (*(char *)(iVar1 + 0x22) == '\0')) &&
       (iStack_14 != 0)) {
      pcStack_34 = (char *)0x0;
      iStack_38 = iStack_14;
      FUN_008a65e0();
      puStack_1c = (undefined *)&iStack_38;
      if (*(int *)(param_1 + 0x228) != 0) {
        LOCK();
        piVar3 = (int *)(*(int *)(param_1 + 0x228) + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      iStack_38 = *(int *)(param_1 + 0x224);
      pcStack_34 = *(char **)(param_1 + 0x228);
      puVar8 = auStack_18;
      uStack_8 = 0;
      uVar7 = FUN_0060dcd0(puVar8,param_2);
      uStack_8._0_1_ = 1;
      FUN_00557f90(uVar7);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_0089bce0(puVar8,param_2);
      pcStack_34 = (char *)0xc8cb76;
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return;
    }
  }
  pcStack_34 = 
  "Error mounting skateboard platform. Both Humanoid and SkateboardPlatform must be direct children of a Model"
  ;
  iStack_38 = 3;
  FUN_0086f2f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29673 ; VA 0x00c8cbb0 ; FUN_00c8cbb0 */

int __thiscall FUN_00c8cbb0(int param_1,char param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4a48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x224) != 0) {
    ExceptionList = &pvStack_10;
    FUN_008a65e0(0,0);
    *(undefined4 *)(param_1 + 0x224) = 0;
    piVar2 = *(int **)(param_1 + 0x228);
    *(undefined4 *)(param_1 + 0x228) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[1] + -1;
      piVar2[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  FUN_0060dcd0(&iStack_18,param_3);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    if (param_2 == '\0') {
      *(undefined4 *)(param_1 + 0x214) = 0;
      piVar2 = *(int **)(param_1 + 0x218);
      *(undefined4 *)(param_1 + 0x218) = 0;
    }
    else {
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[2] = piStack_14[2] + 1;
        UNLOCK();
      }
      *(int *)(param_1 + 0x214) = iStack_18;
      piVar2 = *(int **)(param_1 + 0x218);
      *(int **)(param_1 + 0x218) = piStack_14;
    }
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[2] + -1;
      piVar2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    iStack_18 = FUN_009b52d0(param_1);
    if (param_3 == iStack_18) {
      if (param_2 == '\0') {
        iStack_18 = FUN_00c8c760(param_3);
      }
      else {
        iStack_18 = FUN_00c8c930(param_3);
      }
      if (*(int *)(param_1 + 0x1e8) != 0) {
        *(undefined4 *)(param_1 + 0x1e8) = 0;
        iStack_18 = FUN_008a4940(&DAT_02139de0);
      }
      if (*(int *)(param_1 + 0x1ec) != 0) {
        *(undefined4 *)(param_1 + 0x1ec) = 0;
        iStack_18 = FUN_008a4940(&DAT_02139e18);
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_14 + 1;
    iVar1 = *piVar2;
    iStack_18 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iStack_18 = (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iStack_18 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 29674 ; VA 0x00c8cd30 ; FUN_00c8cd30 */

void __thiscall FUN_00c8cd30(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  uint auStack_90 [2];
  code *pcStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  int *piStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  code *pcStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  undefined8 uStack_50;
  code *pcStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined8 uStack_38;
  code *pcStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f73f;
  pvStack_10 = ExceptionList;
  aiStack_18[1] = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01679490();
    pcVar2 = *(code **)(*param_1 + 0x164);
    iVar7 = FUN_00c8bd10();
    if (iVar7 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_00c3c020();
    }
    uVar8 = FUN_009ade20(uVar8);
    (*pcVar2)(0,uVar8);
  }
  FUN_00b0a250(param_2,param_3);
  if (param_3 != 0) {
    iVar7 = FUN_008a4100();
    pcStack_28 = FUN_00c8c640;
    uStack_24 = 0;
    uVar8 = *(undefined4 *)(iVar7 + 0xbc);
    pcStack_48 = FUN_00c8c640;
    uStack_44 = 0;
    uStack_40 = 0;
    piStack_3c = piStack_1c;
    uStack_38 = CONCAT44(piStack_1c,param_1);
    iStack_8 = 0;
    piStack_20 = param_1;
    cVar6 = FUN_00585a40(&pcStack_48);
    if (cVar6 == '\0') {
      uStack_68 = 0x1972b75;
      pcStack_60 = pcStack_48;
      uStack_5c = uStack_44;
      uStack_58 = uStack_40;
      piStack_54 = piStack_3c;
      uStack_50 = uStack_38;
    }
    else {
      uStack_68 = 0;
    }
    iStack_8._0_1_ = 1;
    auStack_90[0] = 0;
    pcVar2 = pcStack_88;
    uVar3 = uStack_84;
    uVar4 = uStack_80;
    piVar1 = piStack_7c;
    uVar5 = uStack_78;
    if ((uStack_68 != 0) &&
       (auStack_90[0] = uStack_68, pcVar2 = pcStack_60, uVar3 = uStack_5c, uVar4 = uStack_58,
       piVar1 = piStack_54, uVar5 = uStack_50, (uStack_68 & 1) == 0)) {
      (**(code **)(uStack_68 & 0xfffffffe))(&pcStack_60,&pcStack_88,0);
      pcVar2 = pcStack_88;
      uVar3 = uStack_84;
      uVar4 = uStack_80;
      piVar1 = piStack_7c;
      uVar5 = uStack_78;
    }
    uStack_78 = uVar5;
    piStack_7c = piVar1;
    uStack_80 = uVar4;
    uStack_84 = uVar3;
    pcStack_88 = pcVar2;
    iStack_8._0_1_ = 2;
    puVar9 = (undefined4 *)FUN_0060dcd0(&piStack_20,uVar8);
    if (puVar9[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar9[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_70 = *puVar9;
    uStack_6c = puVar9[1];
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar7 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar7 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if ((DAT_01d69070 != '\0') || (DAT_01d66be0 != '\0')) {
      FUN_00b08fb0();
    }
    iStack_8._0_1_ = 4;
    uVar8 = FUN_00affe60(aiStack_18,auStack_90);
    aiStack_18[1] = 1;
    FUN_00b01550();
    iStack_8._0_1_ = 5;
    if (uStack_68 != 0) {
      if (((uStack_68 & 1) == 0) && (*(code **)(uStack_68 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_68 & 0xfffffffe))(&pcStack_60,&pcStack_60,2);
      }
      uStack_68 = 0;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    cVar6 = FUN_01679300(uVar8);
    if (cVar6 != '\0') {
      FUN_01679490();
      FUN_016791c0(uVar8);
    }
    if (aiStack_18[0] != 0) {
      piVar1 = (int *)(aiStack_18[0] + 4);
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(aiStack_18[0]);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29675 ; VA 0x00c8cfb0 ; FUN_00c8cfb0 */

void FUN_00c8cfb0(void)

{
  FUN_00c8cd30();
  return;
}



/* FUNCTION 29676 ; VA 0x00c8cfc0 ; FUN_00c8cfc0 */

void __thiscall FUN_00c8cfc0(undefined4 param_1,undefined *param_2,int *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  int aiStack_2c [2];
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cfb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_20 = param_1;
  iVar3 = FUN_008f7870(param_1);
  if (iVar3 != 0) {
    if ((*(int *)(iVar3 + 0x4a0) == 1) || (*(int *)(iVar3 + 0x4a0) == 3)) {
      FUN_00b0a450(param_2,param_3,param_4);
      ExceptionList = pvStack_10;
      return;
    }
    if (param_2 != &DAT_0213a0c8) {
      if (param_2 != &DAT_0213a110) {
        FUN_00b0a450(param_2,param_3,param_4);
        ExceptionList = pvStack_10;
        return;
      }
      FUN_0097c020(aiStack_2c,param_4,param_1);
      uStack_8 = 2;
      if ((aiStack_2c[0] != 0) && (iVar3 = *(int *)(aiStack_2c[0] + 100), iVar3 != 0)) {
        uStack_18 = FUN_00c8bd10();
        puVar1 = *(undefined4 **)(iVar3 + 0x2c);
        if (puVar1 != (undefined4 *)0x0) {
          piVar2 = (int *)puVar1[1];
          for (piVar7 = (int *)*puVar1; piVar7 != piVar2; piVar7 = piVar7 + 2) {
            iStack_14 = *piVar7;
            if ((iStack_14 != 0) &&
               (iVar3 = *(int *)(iStack_14 + 0xc), iVar6 = FUN_0099be20(), iVar4 = iStack_14,
               (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
               (uint)*(ushort *)(iVar6 + 0x1da))) goto LAB_00c8d19c;
          }
        }
        iVar4 = 0;
LAB_00c8d19c:
        iVar3 = FUN_00c88290(uStack_18);
        if (iVar3 == iVar4) {
          FUN_00b0a450(&DAT_0213a110,param_3,param_4);
        }
      }
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return;
    }
    if (((param_3[1] - *param_3) / 0xd0 == 1) ||
       (iVar3 = *(int *)*param_3, iVar4 = FUN_0088cdc0(), iVar3 == iVar4)) {
      uVar5 = FUN_00605c00();
      FUN_00557fc0(uVar5);
      uStack_8 = 0;
      if ((iStack_1c == 0) ||
         (iVar3 = *(int *)(iStack_1c + 0xc), iVar6 = FUN_0099be20(), iVar4 = iStack_1c,
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        iVar4 = 0;
      }
      iStack_14 = FUN_009b48a0(iVar4);
      iVar6 = FUN_00c8bd10();
      iVar3 = iStack_14;
      if (((((iVar6 == 0) && (iStack_1c != 0)) && (iVar4 != 0)) &&
          ((iStack_14 != 0 && (*(int *)(iVar4 + 0x194) == 0)))) &&
         (**(char **)(iVar4 + 0x22c) == (char)*(char **)(iVar4 + 0x22c))) {
        FUN_0097c020(&iStack_24,param_4,param_1);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if ((iStack_24 != 0) && (*(int *)(iStack_24 + 100) == iVar3)) {
          FUN_00b0a450(&DAT_0213a0c8,param_3,param_4);
        }
        FUN_00550b30();
      }
      FUN_00550b30();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29677 ; VA 0x00c8d220 ; FUN_00c8d220 */

void __thiscall FUN_00c8d220(undefined4 *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  
  puVar1 = (undefined4 *)*param_1;
  puVar2 = (undefined4 *)FUN_01674f30(param_1[2] << 3);
  *param_1 = puVar2;
  if ((int)param_1[2] < (int)param_2) {
    param_2 = param_1[2];
  }
  uVar4 = 0;
  uVar5 = param_2 & 0x1fffffff;
  if (puVar2 + param_2 * 2 < puVar2) {
    uVar5 = 0;
  }
  puVar3 = puVar1;
  if (uVar5 != 0) {
    do {
      *puVar2 = *puVar3;
      uVar4 = uVar4 + 1;
      puVar2[1] = puVar3[1];
      puVar2 = puVar2 + 2;
      puVar3 = puVar3 + 2;
    } while (uVar4 < uVar5);
  }
  FUN_01674ea0(puVar1);
  return;
}



/* FUNCTION 29678 ; VA 0x00c8d290 ; FUN_00c8d290 */

void __thiscall FUN_00c8d290(int *param_1,int param_2,char param_3)

{
  int iVar1;
  int iVar2;
  float fVar3;
  
  iVar2 = param_1[1];
  if (iVar2 == param_2) {
    return;
  }
  iVar1 = param_1[2];
  param_1[1] = param_2;
  if (iVar1 < param_2) {
    if (iVar1 == 0) {
      param_1[2] = param_2;
      param_2 = iVar2;
    }
    else {
      if (9 < param_2) {
        fVar3 = DAT_018df57c;
        if ((iVar1 * 8 < 0x61a81) && (fVar3 = DAT_018df580, 64000 < iVar1 * 8)) {
          fVar3 = DAT_018daf58;
        }
        iVar1 = ((int)((float)iVar1 * fVar3) - iVar1) + param_2;
        param_1[2] = iVar1;
        param_2 = iVar2;
        if (9 < iVar1) goto LAB_00c8d335;
      }
      param_1[2] = 10;
      param_2 = iVar2;
    }
  }
  else {
    if (((iVar1 / 3 < param_2) || (param_3 == '\0')) || (param_2 < 0xb)) goto LAB_00c8d33c;
    if (iVar2 <= param_2) {
      param_2 = iVar2;
    }
  }
LAB_00c8d335:
  FUN_00c8d220(param_2);
LAB_00c8d33c:
  if (iVar2 < param_1[1]) {
    do {
      iVar1 = *param_1;
      *(undefined4 *)(iVar1 + iVar2 * 8) = 0;
      *(undefined *)(iVar1 + 4 + iVar2 * 8) = 0;
      iVar2 = iVar2 + 1;
    } while (iVar2 < param_1[1]);
  }
  return;
}



/* FUNCTION 29679 ; VA 0x00c8d360 ; FUN_00c8d360 */

void __thiscall FUN_00c8d360(int param_1,int *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x1fc);
  if (iVar1 != *param_2) {
    *(int *)(param_1 + 0x1fc) = *param_2;
    FUN_008a4940(&DAT_02139e88);
    FUN_006150c0(*(undefined4 *)(param_1 + 0x1fc),iVar1);
  }
  return;
}



/* FUNCTION 29680 ; VA 0x00c8d3a0 ; FUN_00c8d3a0 */

void __thiscall FUN_00c8d3a0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00c67ac0(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 29681 ; VA 0x00c8d450 ; FUN_00c8d450 */

void __thiscall FUN_00c8d450(int param_1,uint param_2)

{
  if (*(uint *)(param_1 + 0x1ec) == param_2) {
    return;
  }
  if (0x7fffffff < param_2) {
    *(undefined4 *)(param_1 + 0x1ec) = 0xffffffff;
    FUN_008a4940();
    return;
  }
  if (0 < (int)param_2) {
    param_2 = 1;
  }
  *(uint *)(param_1 + 0x1ec) = param_2;
  FUN_008a4940();
  return;
}



/* FUNCTION 29682 ; VA 0x00c8d4a0 ; FUN_00c8d4a0 */

void __thiscall FUN_00c8d4a0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x20c) != param_2) {
    *(char *)(param_1 + 0x20c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 29683 ; VA 0x00c8d4d0 ; FUN_00c8d4d0 */

void __thiscall FUN_00c8d4d0(int param_1,uint param_2)

{
  if (*(uint *)(param_1 + 0x1e8) == param_2) {
    return;
  }
  if (0x7fffffff < param_2) {
    *(undefined4 *)(param_1 + 0x1e8) = 0xffffffff;
    FUN_008a4940();
    return;
  }
  if (0 < (int)param_2) {
    param_2 = 1;
  }
  *(uint *)(param_1 + 0x1e8) = param_2;
  FUN_008a4940();
  return;
}



/* FUNCTION 29684 ; VA 0x00c8d520 ; FUN_00c8d520 */

void __thiscall FUN_00c8d520(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c8d570();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29685 ; VA 0x00c8d570 ; FUN_00c8d570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c8d570(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fbf6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f0141c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f0141c);
    if (DAT_01f0141c == -1) {
      uStack_8 = 0;
      FUN_009ca470("MoveState");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01f013b8 = RBX::Reflection::EnumDesc<enum_RBX::SkateboardPlatform::MoveState>::vftable;
      FUN_009caf20(&DAT_01d68a68,5);
      FUN_016f3654(&LAB_018977c0);
      FUN_016f37bf(&DAT_01f0141c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f013b8;
}



/* FUNCTION 29686 ; VA 0x00c8d620 ; FUN_00c8d620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c8d620(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01454) {
    FUN_016f3809(&DAT_01f01454);
    if (DAT_01f01454 == -1) {
      _DAT_01f01448 = FUN_005c65e0;
      _DAT_01f0144c = FUN_005c65e0;
      _DAT_01f01450 = _guard_check_icall;
      FUN_016f37bf(&DAT_01f01454);
    }
  }
  return &DAT_01f01448;
}



/* FUNCTION 29687 ; VA 0x00c8d690 ; FUN_00c8d690 */

uint __fastcall FUN_00c8d690(int param_1)

{
  uint *puVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  undefined4 uStack_3c;
  int iStack_28;
  int *piStack_24;
  int iStack_18;
  char cStack_11;
  
  iStack_18 = param_1;
  if ((*(int *)(param_1 + 0xd8) != 0) || (*(int *)(param_1 + 0xdc) != 0)) {
    FUN_00bc1c10(*(undefined4 *)(param_1 + -0x68),1);
  }
  iVar7 = *(int *)(param_1 + 0x120);
  if (iVar7 != 0) {
    iVar4 = 0;
    *(undefined4 *)(param_1 + 0x120) = 0;
    if (0 < iVar7) {
      iVar4 = *(int *)(param_1 + 0x120);
    }
    if (*(int *)(param_1 + 0x124) < 0) {
      if (*(int *)(param_1 + 0x124) == 0) {
        uVar5 = 0;
      }
      else {
        uVar5 = 10;
      }
      *(undefined4 *)(param_1 + 0x124) = uVar5;
      FUN_00c8d220(iVar7);
      iVar4 = *(int *)(param_1 + 0x120);
    }
    if (iVar7 < iVar4) {
      do {
        iVar4 = *(int *)(param_1 + 0x11c);
        *(undefined4 *)(iVar4 + iVar7 * 8) = 0;
        *(undefined *)(iVar4 + 4 + iVar7 * 8) = 0;
        iVar7 = iVar7 + 1;
      } while (iVar7 < *(int *)(param_1 + 0x120));
    }
  }
  iVar7 = FUN_00c155c0();
  if (iVar7 != 0) {
    cVar3 = FUN_00ca0f40();
    if (cVar3 == '\0') {
      iStack_28 = 0;
      uVar5 = FUN_00ca1550();
      FUN_00c63a50(FUN_00c8b9c0,0,iStack_28,piStack_24,CONCAT44(uStack_3c,param_1 + -0x110),uVar5,0)
      ;
    }
  }
  FUN_00c8af30();
  iVar7 = iStack_18;
  uVar6 = FUN_00587490(&iStack_28);
  cStack_11 = iStack_28 != 0;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_24 + 1);
    uVar2 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      puVar1 = (uint *)(piStack_24 + 2);
      uVar2 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar2 - 1;
      UNLOCK();
      if (uVar2 - 1 == 0) {
        uVar6 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (cStack_11 != '\0') {
    uVar6 = *(uint *)(iVar7 + 0x10c);
    if (uVar6 == *(uint *)(iVar7 + 0x120)) {
      if (0 < *(int *)(iVar7 + 0xd8)) {
        iStack_18 = 2;
        uVar6 = FUN_00c8d360(&iStack_18);
        return uVar6 & 0xffffff00;
      }
      if (*(int *)(iVar7 + 0xd8) < 0) {
        iStack_18 = 3;
        uVar6 = FUN_00c8d360(&iStack_18);
        return uVar6 & 0xffffff00;
      }
      if (DAT_018ce2f8 <
          (float)(double)CONCAT44((uint)((ulonglong)(double)*(float *)(iVar7 + 0x110) >> 0x20) &
                                  DAT_018c0da0._4_4_,
                                  SUB84((double)*(float *)(iVar7 + 0x110),0) & (uint)DAT_018c0da0))
      {
        iStack_18 = 1;
        uVar6 = FUN_00c8d360(&iStack_18);
        return uVar6 & 0xffffff00;
      }
      iStack_18 = 0;
      uVar6 = FUN_00c8d360(&iStack_18);
      return uVar6 & 0xffffff00;
    }
    iVar7 = *(int *)(param_1 + 0xec);
    if (iVar7 != 4) {
      *(undefined4 *)(param_1 + 0xec) = 4;
      FUN_008a4940(&DAT_02139e88);
      uVar6 = FUN_006150c0(*(undefined4 *)(param_1 + 0xec),iVar7);
    }
  }
  return uVar6 & 0xffffff00;
}



/* FUNCTION 29688 ; VA 0x00c8d8e0 ; FUN_00c8d8e0 */

undefined * FUN_00c8d8e0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fc0c;
  pvStack_10 = ExceptionList;
  if (DAT_01f0145c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01668) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f01668);
      if (DAT_01f01668 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00e8aac0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Platform",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01897930);
        FUN_016f37bf(&DAT_01f01668);
      }
    }
    DAT_01f0145c = &DAT_01f01460;
  }
  ExceptionList = pvStack_10;
  return DAT_01f0145c;
}



/* FUNCTION 29689 ; VA 0x00c8d9c0 ; FUN_00c8d9c0 */

/* WARNING: Removing unreachable block (ram,0x00c8da2e) */
/* WARNING: Removing unreachable block (ram,0x00c8da3a) */
/* WARNING: Removing unreachable block (ram,0x00c8da48) */

undefined4 FUN_00c8d9c0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0089be10(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 29690 ; VA 0x00c8da70 ; FUN_00c8da70 */

void FUN_00c8da70(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  param_2 = (int *)*param_2;
  iVar2 = *param_2;
  iVar3 = FUN_0088cdc0();
  if (iVar2 == iVar3) {
    piVar4 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00c8d9c0(param_1,*piVar4,piVar4[1]);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29691 ; VA 0x00c8dad0 ; FUN_00c8dad0 */

int * __thiscall
FUN_00c8dad0(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808e5b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c8dce0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Accoutrement,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_const_(__thiscall_RBX::Accoutrement::*)(void)const_,void_(__thiscall_RBX::Accoutrement::*)(class_G3D::Vector3_const&)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Accoutrement,class_G3D::Vector3>::
                    vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Accoutrement,class_G3D::Vector3>::
                    vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29692 ; VA 0x00c8dbe0 ; FUN_00c8dbe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c8dbe0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fc70;
  pvStack_10 = ExceptionList;
  if (DAT_01f01ab8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01cd0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f01cd0);
      if (DAT_01f01cd0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c8dce0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Accessory",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f01cc8 = RBX::Creator<class_RBX::Accessory>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f01ac0,&DAT_01f01cc8);
        FUN_016f3654(FUN_01897a20);
        FUN_016f37bf(&DAT_01f01cd0);
      }
    }
    DAT_01f01ab8 = &DAT_01f01ac0;
  }
  ExceptionList = pvStack_10;
  return DAT_01f01ab8;
}



/* FUNCTION 29693 ; VA 0x00c8dce0 ; FUN_00c8dce0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c8dce0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fca0;
  pvStack_10 = ExceptionList;
  if (DAT_01f01678 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01890) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f01890);
      if (DAT_01f01890 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Accoutrement",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f01888 = RBX::Creator<class_RBX::Accoutrement>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f01680,&DAT_01f01888);
        FUN_016f3654(FUN_01897a80);
        FUN_016f37bf(&DAT_01f01890);
      }
    }
    DAT_01f01678 = &DAT_01f01680;
  }
  ExceptionList = pvStack_10;
  return DAT_01f01678;
}



/* FUNCTION 29694 ; VA 0x00c8dde0 ; FUN_00c8dde0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c8dde0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fcd0;
  pvStack_10 = ExceptionList;
  if (DAT_01f01898 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01ab0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f01ab0);
      if (DAT_01f01ab0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c8dce0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_01972c80,0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f01aa8 = RBX::Creator<class_RBX::Hat>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f018a0,&DAT_01f01aa8);
        FUN_016f3654(FUN_01897ae0);
        FUN_016f37bf(&DAT_01f01ab0);
      }
    }
    DAT_01f01898 = &DAT_01f018a0;
  }
  ExceptionList = pvStack_10;
  return DAT_01f01898;
}



/* FUNCTION 29695 ; VA 0x00c8dee0 ; FUN_00c8dee0 */

int __thiscall FUN_00c8dee0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180fce0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Accessory*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29696 ; VA 0x00c8dfb2 ; Catch_All@00c8dfb2 */

void Catch_All_00c8dfb2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29697 ; VA 0x00c8dfd0 ; FUN_00c8dfd0 */

int __thiscall FUN_00c8dfd0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180fcf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Accoutrement*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29698 ; VA 0x00c8e0a2 ; Catch_All@00c8e0a2 */

void Catch_All_00c8e0a2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29699 ; VA 0x00c8e0c0 ; FUN_00c8e0c0 */

int __thiscall FUN_00c8e0c0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180fd00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Hat*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29700 ; VA 0x00c8e192 ; Catch_All@00c8e192 */

void Catch_All_00c8e192(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29701 ; VA 0x00c8e1b0 ; FUN_00c8e1b0 */

undefined4 * FUN_00c8e1b0(undefined4 *param_1)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180fd7a;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00c8dbe0();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_18 = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(0xf4);
  puStack_1c = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4[0x1d] = &DAT_0197320c;
    puVar4[0x3c] = RBX::IHasLocation::vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_14 = 2;
    FUN_00c8e810(0);
    *puVar4 = RBX::DescribedCreatable<class_RBX::Accessory,class_RBX::Accoutrement>::vftable;
    puVar4[0x15] = RBX::DescribedCreatable<class_RBX::Accessory,class_RBX::Accoutrement>::vftable;
    puVar4[0x1c] = RBX::DescribedCreatable<class_RBX::Accessory,class_RBX::Accoutrement>::vftable;
    uStack_8 = 5;
    *(undefined ***)(*(int *)(puVar4[0x1d] + 4) + 0x74 + (int)puVar4) =
         RBX::DescribedCreatable<class_RBX::Accessory,class_RBX::Accoutrement>::vftable;
    *(int *)(*(int *)(puVar4[0x1d] + 4) + 0x70 + (int)puVar4) = *(int *)(puVar4[0x1d] + 4) + -0x7c;
    uVar5 = FUN_00c8dbe0();
    puVar4[3] = uVar5;
    *puVar4 = RBX::Accessory::vftable;
    puVar4[0x15] = RBX::Accessory::vftable;
    puVar4[0x1c] = RBX::Accessory::vftable;
    uStack_8 = 6;
    *(undefined ***)(*(int *)(puVar4[0x1d] + 4) + 0x74 + (int)puVar4) = RBX::Accessory::vftable;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    *(int *)(*(int *)(puVar4[0x1d] + 4) + 0x70 + (int)puVar4) = *(int *)(puVar4[0x1d] + 4) + -0x7c;
    FUN_005542c0("Accessory",9);
    uStack_8._0_1_ = 7;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 6;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (0xf < uStack_20) {
      uVar7 = uStack_20 + 1;
      uVar6 = auStack_34[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_34[0] - 4);
        uVar7 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c8dee0(puVar4,puStack_1c);
  uStack_14 = uStack_14 | 1;
  uStack_8 = 0xb;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29702 ; VA 0x00c8e370 ; FUN_00c8e370 */

undefined4 * FUN_00c8e370(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180fdc3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c8dce0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xf4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c8e810(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c8dfd0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29703 ; VA 0x00c8e440 ; FUN_00c8e440 */

undefined4 * FUN_00c8e440(undefined4 *param_1)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180fe3a;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00c8dde0();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_18 = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(0xf4);
  puStack_1c = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4[0x1d] = &DAT_0197301c;
    puVar4[0x3c] = RBX::IHasLocation::vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_14 = 2;
    FUN_00c8e810(0);
    *puVar4 = RBX::DescribedCreatable<class_RBX::Hat,class_RBX::Accoutrement>::vftable;
    puVar4[0x15] = RBX::DescribedCreatable<class_RBX::Hat,class_RBX::Accoutrement>::vftable;
    puVar4[0x1c] = RBX::DescribedCreatable<class_RBX::Hat,class_RBX::Accoutrement>::vftable;
    uStack_8 = 5;
    *(undefined ***)(*(int *)(puVar4[0x1d] + 4) + 0x74 + (int)puVar4) =
         RBX::DescribedCreatable<class_RBX::Hat,class_RBX::Accoutrement>::vftable;
    *(int *)(*(int *)(puVar4[0x1d] + 4) + 0x70 + (int)puVar4) = *(int *)(puVar4[0x1d] + 4) + -0x7c;
    uVar5 = FUN_00c8dde0();
    puVar4[3] = uVar5;
    *puVar4 = RBX::Hat::vftable;
    puVar4[0x15] = RBX::Hat::vftable;
    puVar4[0x1c] = RBX::Hat::vftable;
    uStack_8 = 6;
    *(undefined ***)(*(int *)(puVar4[0x1d] + 4) + 0x74 + (int)puVar4) = RBX::Hat::vftable;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    *(int *)(*(int *)(puVar4[0x1d] + 4) + 0x70 + (int)puVar4) = *(int *)(puVar4[0x1d] + 4) + -0x7c;
    FUN_005542c0(&DAT_01972c80,3);
    uStack_8._0_1_ = 7;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 6;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (0xf < uStack_20) {
      uVar7 = uStack_20 + 1;
      uVar6 = auStack_34[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_34[0] - 4);
        uVar7 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c8e0c0(puVar4,puStack_1c);
  uStack_14 = uStack_14 | 1;
  uStack_8 = 0xb;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29704 ; VA 0x00c8e600 ; FUN_00c8e600 */

int __fastcall FUN_00c8e600(int param_1)

{
  int iVar1;
  int iVar2;
  
  do {
    param_1 = *(int *)(param_1 + 0x34);
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00c8dce0();
  } while ((uint)*(ushort *)(iVar2 + 0x1da) <
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
  return param_1;
}



/* FUNCTION 29705 ; VA 0x00c8e640 ; FUN_00c8e640 */

int __fastcall FUN_00c8e640(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00c8dce0(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 29706 ; VA 0x00c8e6a0 ; FUN_00c8e6a0 */

undefined4 *
FUN_00c8e6a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined auStack_118 [216];
  undefined8 uStack_40;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180fe71;
  pvStack_1c = ExceptionList;
  uStack_40 = param_6;
  uStack_34 = param_2;
  ExceptionList = &pvStack_1c;
  uVar1 = FUN_00c8dce0();
  FUN_009cb970(uVar1,param_3,param_5,uStack_40,param_7);
  puStack_30[0xe] = param_1;
  puStack_30[0xf] = uStack_34;
  iStack_14 = 0;
  *puStack_30 = RBX::Reflection::
                EventDesc<class_RBX::Accoutrement,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Accoutrement::*>
                ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_118,&uStack_40,uStack_34);
  iStack_14._0_1_ = 2;
  if (puStack_30 + 10 != &uStack_2c) {
    FUN_0068a760();
    puStack_30[10] = uStack_2c;
    puStack_30[0xb] = uStack_28;
    puStack_30[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 3;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_118,0xd8,1,FUN_00688b10);
  puStack_30[0x10] = param_9;
  puStack_30[0x11] = param_8;
  *puStack_30 = RBX::Reflection::
                RemoteEventDesc<class_RBX::Accoutrement,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Accoutrement::*>
                ::vftable;
  ExceptionList = pvStack_1c;
  return puStack_30;
}



/* FUNCTION 29707 ; VA 0x00c8e810 ; FUN_00c8e810 */

undefined4 * __thiscall FUN_00c8e810(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ff64;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    param_1[0x1d] = &DAT_01972e2c;
    param_1[0x3c] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  uStack_14 = (uint)(param_2 != 0);
  puStack_18 = param_1;
  FUN_0089a7a0();
  uStack_8 = 1;
  *param_1 = RBX::DescribedCreatable<class_RBX::Accoutrement,class_RBX::Instance>::vftable;
  uVar1 = FUN_00c8dce0();
  param_1[3] = uVar1;
  param_1[0x15] = RBX::IAdornable::vftable;
  param_1[0x16] = 0xffffffff;
  param_1[0x17] = 0xffffffff;
  param_1[0x18] = 0xffffffff;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x1d] + 4) + 0x74 + (int)param_1) = RBX::CameraSubject::vftable;
  *param_1 = RBX::Accoutrement::vftable;
  param_1[0x15] = RBX::Accoutrement::vftable;
  param_1[0x1c] = RBX::Accoutrement::vftable;
  *(undefined ***)(*(int *)(param_1[0x1d] + 4) + 0x74 + (int)param_1) = RBX::Accoutrement::vftable;
  *(int *)(*(int *)(param_1[0x1d] + 4) + 0x70 + (int)param_1) = *(int *)(param_1[0x1d] + 4) + -0x7c;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0x3f800000;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0x3f800000;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0x3f800000;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  uStack_8._0_1_ = 0xf;
  uStack_8._1_3_ = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Accoutrement",0xc);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    uVar2 = auStack_30[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_30[0] - 4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29708 ; VA 0x00c8ea90 ; FUN_00c8ea90 */

void __fastcall FUN_00c8ea90(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Accessory>::vftable;
  uVar1 = FUN_00c8dbe0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29709 ; VA 0x00c8ead0 ; FUN_00c8ead0 */

void __fastcall FUN_00c8ead0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Accoutrement>::vftable;
  uVar1 = FUN_00c8dce0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29710 ; VA 0x00c8eb10 ; FUN_00c8eb10 */

void __fastcall FUN_00c8eb10(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Hat>::vftable;
  uVar1 = FUN_00c8dde0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29711 ; VA 0x00c8eb50 ; thunk_FUN_00c8eb60 */

void __fastcall thunk_FUN_00c8eb60(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Accoutrement::vftable;
  param_1[0x15] = RBX::Accoutrement::vftable;
  param_1[0x1c] = RBX::Accoutrement::vftable;
  *(undefined ***)(*(int *)(param_1[0x1d] + 4) + 0x74 + (int)param_1) = RBX::Accoutrement::vftable;
  *(int *)(*(int *)(param_1[0x1d] + 4) + 0x70 + (int)param_1) = *(int *)(param_1[0x1d] + 4) + -0x7c;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[0x36];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = param_1[0x35];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar4 = param_1[0x34];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar4 = param_1[0x33];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = (int *)param_1[0x25];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  iVar4 = param_1[0x23];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = param_1[0x22];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = (int *)param_1[0x21];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = (int *)param_1[0x1f];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  param_1[0x1c] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x1d] + 4) + 0x74 + (int)param_1) = RBX::CameraSubject::vftable;
  FUN_0115a710();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29712 ; VA 0x00c8eb60 ; FUN_00c8eb60 */

void __fastcall FUN_00c8eb60(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Accoutrement::vftable;
  param_1[0x15] = RBX::Accoutrement::vftable;
  param_1[0x1c] = RBX::Accoutrement::vftable;
  *(undefined ***)(*(int *)(param_1[0x1d] + 4) + 0x74 + (int)param_1) = RBX::Accoutrement::vftable;
  *(int *)(*(int *)(param_1[0x1d] + 4) + 0x70 + (int)param_1) = *(int *)(param_1[0x1d] + 4) + -0x7c;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[0x36];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = param_1[0x35];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar4 = param_1[0x34];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar4 = param_1[0x33];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = (int *)param_1[0x25];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  iVar4 = param_1[0x23];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = param_1[0x22];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = (int *)param_1[0x21];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = (int *)param_1[0x1f];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  param_1[0x1c] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x1d] + 4) + 0x74 + (int)param_1) = RBX::CameraSubject::vftable;
  FUN_0115a710();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29713 ; VA 0x00c8ed7f ; FUN_00c8ed7f */

void FUN_00c8ed7f(void)

{
  FUN_00c8ed90();
  return;
}



/* FUNCTION 29714 ; VA 0x00c8ed90 ; FUN_00c8ed90 */

int __thiscall FUN_00c8ed90(int param_1,byte param_2)

{
  FUN_00c8eb60();
  *(undefined ***)(param_1 + 0xf0) = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xf4);
  }
  return param_1;
}



/* FUNCTION 29715 ; VA 0x00c8edc0 ; FUN_00c8edc0 */

byte __fastcall FUN_00c8edc0(int param_1)

{
  char cVar1;
  int iVar2;
  
  iVar2 = FUN_00c48580();
  if (iVar2 == 0) {
    return 0;
  }
  cVar1 = FUN_00a97920(param_1);
  if (cVar1 == '\0') {
    return 1;
  }
  iVar2 = FUN_009ba880(*(undefined4 *)(param_1 + 0x34));
  if (iVar2 == 0) {
    return 2;
  }
  iVar2 = FUN_009b7250();
  return -(iVar2 != 0) & 4;
}



/* FUNCTION 29716 ; VA 0x00c8ee10 ; FUN_00c8ee10 */

undefined4 * __thiscall
FUN_00c8ee10(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8141;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x74) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00922c30;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x74 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29717 ; VA 0x00c8efd0 ; FUN_00c8efd0 */

void FUN_00c8efd0(void)

{
  int *piVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  uint auStack_74 [2];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined auStack_2c [4];
  int *piStack_28;
  int aiStack_24 [3];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01810009;
  pvStack_10 = ExceptionList;
  aiStack_24[1] = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00c48580();
  if (iVar4 == 0) {
    FUN_01679490();
  }
  else {
    iVar4 = FUN_008a4100();
    aiStack_24[2] = iVar4 + 0xa0;
    uVar2 = *(undefined4 *)(iVar4 + 0xa4);
    iStack_8 = 0;
    uStack_18 = uVar2;
    cVar3 = FUN_00585a40(&uStack_14);
    if (cVar3 == '\0') {
      uStack_44 = uStack_14;
      uStack_4c = 0x19733f9;
    }
    else {
      uStack_4c = 0;
    }
    iStack_8._0_1_ = 1;
    auStack_74[0] = 0;
    if (uStack_4c != 0) {
      auStack_74[0] = uStack_4c;
      if ((uStack_4c & 1) == 0) {
        (**(code **)(uStack_4c & 0xfffffffe))(&uStack_44,&uStack_6c,0);
      }
      else {
        uStack_6c = uStack_44;
        uStack_68 = uStack_40;
        uStack_64 = uStack_3c;
        uStack_60 = uStack_38;
        uStack_5c = uStack_34;
      }
    }
    iStack_8._0_1_ = 2;
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_2c,uVar2);
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_54 = *puVar5;
    uStack_50 = puVar5[1];
    iStack_8._0_1_ = 3;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_28[1] + -1;
      piStack_28[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar4 = piStack_28[2] + -1;
        piStack_28[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    FUN_00b09010();
    iStack_8._0_1_ = 4;
    aiStack_24[2] = FUN_0099e760(aiStack_24,auStack_74);
    aiStack_24[1] = 1;
    FUN_009a4a10();
    iStack_8._0_1_ = 5;
    if (uStack_4c != 0) {
      if (((uStack_4c & 1) == 0) && (*(code **)(uStack_4c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_4c & 0xfffffffe))(&uStack_44,&uStack_44,2);
      }
      uStack_4c = 0;
    }
    iVar4 = aiStack_24[2];
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    cVar3 = FUN_01679300(aiStack_24[2]);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(iVar4);
    }
    if (aiStack_24[0] != 0) {
      piVar1 = (int *)(aiStack_24[0] + 4);
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        FUN_01674ea0(aiStack_24[0]);
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29718 ; VA 0x00c8f1c0 ; FUN_00c8f1c0 */

undefined4 * FUN_00c8f1c0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c8e1b0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29719 ; VA 0x00c8f230 ; FUN_00c8f230 */

undefined4 * FUN_00c8f230(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c8e370(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29720 ; VA 0x00c8f2a0 ; FUN_00c8f2a0 */

undefined4 * FUN_00c8f2a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c8e440(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29721 ; VA 0x00c8f310 ; FUN_00c8f310 */

void __thiscall FUN_00c8f310(int param_1,int param_2)

{
  if (param_2 + 0x74 +
      *(int *)(*(int *)(param_2 + 0x74) + *(int *)(param_1 + 0x3c)) + *(int *)(param_1 + 0x38) != 0)
  {
    FUN_016795b0();
  }
  return;
}



/* FUNCTION 29722 ; VA 0x00c8f340 ; FUN_00c8f340 */

int FUN_00c8f340(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x18);
  iVar4 = *(int *)(param_1 + 0x1c);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  if (param_2 != iVar2) {
    if (param_2 == *(int *)(iVar2 + 0x78)) {
      FUN_00c91530(0,iVar4);
    }
    uVar3 = FUN_00c8edc0();
    if (iVar4 == 0) {
      iVar4 = FUN_005c8880(iVar2);
    }
    iVar4 = FUN_00c91530(uVar3,iVar4);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 29723 ; VA 0x00c8f430 ; FUN_00c8f430 */

int FUN_00c8f430(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x18);
  iVar4 = *(int *)(param_1 + 0x1c);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  if (param_2 != iVar2) {
    uVar3 = FUN_00c8edc0();
    if (iVar4 == 0) {
      iVar4 = FUN_005c8880(iVar2);
    }
    param_2 = FUN_00c91530(uVar3,iVar4);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29724 ; VA 0x00c8f510 ; FUN_00c8f510 */

void FUN_00c8f510(undefined4 param_1,undefined *param_2)

{
  if (param_2 == &DAT_0213ff80) {
    FUN_00c91c30();
    return;
  }
  return;
}



/* FUNCTION 29725 ; VA 0x00c8f530 ; FUN_00c8f530 */

int FUN_00c8f530(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  if (param_2 != 0) {
    param_2 = FUN_008a65e0(param_2,0);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29726 ; VA 0x00c8f5f0 ; FUN_00c8f5f0 */

int FUN_00c8f5f0(int param_1,int param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iStack_18 = param_2;
  piStack_14 = param_3;
  uStack_8 = 1;
  if (param_2 != 0) {
    puVar3 = (undefined4 *)FUN_00a13670(auStack_20,&iStack_18);
    iVar4 = puVar3[1];
    iVar1 = *(int *)(param_1 + 0x18);
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 1;
      UNLOCK();
      iVar4 = puVar3[1];
    }
    *(undefined4 *)(iVar1 + 0x80) = *puVar3;
    piVar2 = *(int **)(iVar1 + 0x84);
    *(int *)(iVar1 + 0x84) = iVar4;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar4 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    FUN_00c8f730(*(undefined4 *)(param_1 + 0x1c));
    param_2 = *(int *)(param_1 + 0x18);
    *(undefined4 *)(param_2 + 0x98) = 2;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar4 = *piVar2;
    param_2 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      param_2 = *piVar2;
      *piVar2 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar4 = *piVar2;
    param_2 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29727 ; VA 0x00c8f730 ; FUN_00c8f730 */

int __thiscall FUN_00c8f730(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  float *pfVar7;
  int *piVar8;
  undefined auStack_70 [36];
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  undefined8 uStack_40;
  int *piStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810030;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  if (DAT_01d68a9c == '\0') {
    piStack_1c = (int *)0x0;
    piVar4 = &iStack_20;
    piVar8 = (int *)0x2;
    iStack_2c = 0;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    piVar4 = (int *)FUN_00587490(auStack_34);
    piVar8 = (int *)0x1;
    iStack_2c = *piVar4;
  }
  piVar2 = (int *)piVar4[1];
  iStack_14 = iStack_2c;
  *piVar4 = 0;
  piVar4[1] = 0;
  uStack_8 = 0;
  piStack_28 = piVar2;
  if ((((uint)piVar8 & 2) != 0) &&
     (piStack_18 = (int *)((uint)piVar8 & 0xfffffffd), piVar8 = piStack_18, piStack_1c != (int *)0x0
     )) {
    LOCK();
    iVar5 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar5 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar5;
      UNLOCK();
      piVar8 = piStack_18;
      if (iVar5 == 0) {
        (**(code **)(*piStack_1c + 4))();
        piVar8 = piStack_18;
      }
    }
  }
  if ((((uint)piVar8 & 1) != 0) && (piStack_18 = piStack_30, piStack_30 != (int *)0x0)) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar5 = piStack_18[2] + -1;
      piStack_18[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar4 = piVar2;
  if (*(int *)(param_1 + 0x78) != 0) {
    iVar5 = FUN_00c48580();
    if ((iVar5 == 0) || (*(int *)(*(int *)(param_1 + 0x78) + 0x34) != iVar5)) {
      iVar5 = FUN_00c3c010();
    }
    else {
      iVar5 = FUN_00c3c020();
    }
    if (iVar5 != 0) {
      uVar6 = FUN_0060dcd0((int)&uStack_40 + 4,*(undefined4 *)(iVar5 + 0x34));
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      piVar8 = (int *)FUN_00a13670(&iStack_20,uVar6);
      iStack_2c = *piVar8;
      piVar4 = (int *)piVar8[1];
      *piVar8 = 0;
      piVar8[1] = 0;
      piStack_28 = piVar4;
      iStack_14 = iStack_2c;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar5 = piVar2[1] + -1;
        piVar2[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          piStack_18 = piVar2;
          (**(code **)*piVar2)();
          LOCK();
          iVar5 = piStack_18[2] + -1;
          piStack_18[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
      piStack_18 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar5 = piStack_18[2] + -1;
          piStack_18[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
      uStack_8 = uStack_8 & 0xffffff00;
      piStack_18 = piStack_38;
      if (piStack_38 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_38[1] + -1;
        piStack_38[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_38)();
          LOCK();
          iVar5 = piStack_18[2] + -1;
          piStack_18[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    FUN_008a65e0(0,0);
    *(undefined4 *)(param_1 + 0x78) = 0;
    piStack_18 = *(int **)(param_1 + 0x7c);
    *(undefined4 *)(param_1 + 0x7c) = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_18[1] + -1;
      piStack_18[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar5 = piStack_18[2] + -1;
        piStack_18[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  if ((iStack_14 != 0) && (iVar5 = FUN_009ba880(iStack_14), iVar5 != 0)) {
    (*(code *)**(undefined4 **)(iStack_14 + 0x54 + *(int *)(*(int *)(iStack_14 + 0x54) + 4)))
              (auStack_70);
    uStack_40._0_4_ = fStack_4c;
    piStack_18 = (int *)(fStack_48 + DAT_018e3f8c);
    piStack_38 = (int *)fStack_44;
    pfVar7 = (float *)FUN_011612d0(auStack_24,2);
    uStack_40 = CONCAT44((float)piStack_18 - pfVar7[1] * DAT_018f997c,
                         (float)uStack_40 - *pfVar7 * DAT_018f997c);
    piStack_38 = (int *)((float)piStack_38 - pfVar7[2] * DAT_018f997c);
    piStack_18 = (int *)FUN_00c48580();
    if ((piStack_18 != (int *)0x0) && (cVar3 = FUN_00b06670(), cVar3 == '\0')) {
      (**(code **)(*piStack_18 + 0x124))(1);
      FUN_00e70570(uStack_40,piStack_38);
      uStack_40 = 0x3f8000003f800000;
      piStack_38 = (int *)&DAT_3f800000;
      (**(code **)(*piStack_18 + 0x110))(&uStack_40);
    }
  }
  if (DAT_01d68a9c == '\0') {
    (**(code **)(*(int *)(param_1 + 0x70) + 8))(0x4479c000);
  }
  else {
    if ((param_2 != 0) && (cVar3 = FUN_0097c970(param_2,1), cVar3 != '\0')) {
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
      }
      FUN_00c90d20();
    }
    *(undefined4 *)(param_1 + 0x80) = 0;
    piVar8 = *(int **)(param_1 + 0x84);
    *(undefined4 *)(param_1 + 0x84) = 0;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar5 = piVar8[2] + -1;
      piVar8[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  FUN_00c8efd0();
  iVar5 = FUN_01679490();
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar8 = piVar4 + 1;
    iVar1 = *piVar8;
    iVar5 = *piVar8;
    *piVar8 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar5 = (**(code **)*piVar4)();
      LOCK();
      piVar8 = piVar4 + 2;
      iVar1 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 29728 ; VA 0x00c8fb30 ; FUN_00c8fb30 */

int __fastcall FUN_00c8fb30(int param_1)

{
  float *pfVar1;
  float fVar2;
  uint3 uVar3;
  float *pfVar4;
  float *pfVar5;
  int iVar6;
  undefined auStack_1c [12];
  undefined auStack_10 [12];
  undefined2 uVar7;
  
  pfVar4 = (float *)(**(code **)(param_1 + 8))(auStack_10);
  pfVar5 = (float *)(**(code **)(param_1 + 8))(auStack_1c);
  fVar2 = *pfVar4;
  uVar7 = (undefined2)((uint)pfVar5 >> 0x10);
  iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                               fVar2 < *pfVar5) << 8;
  if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
    fVar2 = pfVar4[1];
    pfVar1 = pfVar5 + 1;
    iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                                 fVar2 < *pfVar1) << 8;
    if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
      fVar2 = pfVar4[2];
      pfVar5 = pfVar5 + 2;
      uVar3 = CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                             fVar2 < *pfVar5);
      iVar6 = (uint)uVar3 << 8;
      if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
        return CONCAT31(uVar3,1);
      }
    }
  }
  return iVar6;
}



/* FUNCTION 29729 ; VA 0x00c8fbc0 ; FUN_00c8fbc0 */

undefined4 __fastcall FUN_00c8fbc0(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = (**(code **)(param_1 + 8))();
  iVar3 = (**(code **)(param_1 + 8))();
  if ((NAN(*(float *)(iVar2 + 0x24)) || NAN(*(float *)(iVar3 + 0x24))) !=
      (*(float *)(iVar2 + 0x24) == *(float *)(iVar3 + 0x24))) {
    if ((NAN(*(float *)(iVar2 + 0x28)) || NAN(*(float *)(iVar3 + 0x28))) !=
        (*(float *)(iVar2 + 0x28) == *(float *)(iVar3 + 0x28))) {
      if ((NAN(*(float *)(iVar2 + 0x2c)) || NAN(*(float *)(iVar3 + 0x2c))) !=
          (*(float *)(iVar2 + 0x2c) == *(float *)(iVar3 + 0x2c))) {
        cVar1 = FUN_01160ab0(iVar3);
        if (cVar1 != '\0') {
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 29730 ; VA 0x00c8fc50 ; FUN_00c8fc50 */

bool __fastcall FUN_00c8fc50(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (**(code **)(param_1 + 8))();
  iVar2 = (**(code **)(param_1 + 8))();
  return iVar2 == iVar1;
}



/* FUNCTION 29731 ; VA 0x00c8fca0 ; FUN_00c8fca0 */

int FUN_00c8fca0(int *param_1,undefined4 param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int *piStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0698;
  pvStack_10 = ExceptionList;
  if (param_1 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*param_1 + 0x40))(&piStack_1c);
    uStack_8 = 0;
    if ((piStack_1c != (int *)0x0) && (piVar5 = (int *)*piStack_1c, piVar5 != (int *)piStack_1c[1]))
    {
      do {
        iVar4 = *piVar5;
        if (iVar4 == 0) {
LAB_00c8fd77:
          iVar4 = FUN_00c8fca0(iVar4,param_2);
          if (iVar4 != 0) {
LAB_00c8fdd5:
            if (piStack_18 != (int *)0x0) {
              LOCK();
              iVar1 = piStack_18[1] + -1;
              piStack_18[1] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)*piStack_18)();
                LOCK();
                piVar5 = piStack_18 + 2;
                iVar1 = *piVar5;
                *piVar5 = *piVar5 + -1;
                UNLOCK();
                if (iVar1 == 1) {
                  (**(code **)(*piStack_18 + 4))();
                }
              }
            }
            ExceptionList = pvStack_10;
            return iVar4;
          }
        }
        else {
          iVar1 = *(int *)(iVar4 + 0xc);
          iVar3 = FUN_00d6bbd0();
          if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
              (uint)*(ushort *)(iVar3 + 0x1da)) {
            cVar2 = FUN_00558b30(*(undefined4 *)(iVar4 + 0x28),param_2);
            if (cVar2 != '\0') goto LAB_00c8fdd5;
          }
          iVar1 = *(int *)(iVar4 + 0xc);
          iVar3 = FUN_00c8dce0();
          if ((uint)*(ushort *)(iVar3 + 0x1da) <
              (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
            iVar1 = *(int *)(iVar4 + 0xc);
            iVar3 = FUN_00c46280();
            if ((uint)*(ushort *)(iVar3 + 0x1da) <
                (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))
            goto LAB_00c8fd77;
          }
        }
        piVar5 = piVar5 + 2;
      } while (piVar5 != (int *)piStack_1c[1]);
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar5 = piStack_18 + 2;
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 29732 ; VA 0x00c8fe20 ; FUN_00c8fe20 */

void FUN_00c8fe20(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  param_2 = (int *)*param_2;
  iVar3 = *param_2;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cdc0();
  if (iVar3 == iVar1) {
    piVar2 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar3 = piVar2[1];
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar3 = piVar2[1];
    }
    uStack_8 = 0;
    FUN_0089be10(*piVar2,iVar3);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29733 ; VA 0x00c8fed0 ; FUN_00c8fed0 */

void FUN_00c8fed0(uint *param_1)

{
  uint uVar1;
  uint *puVar2;
  undefined auStack_10 [12];
  
  puVar2 = (uint *)FUN_011612d0(auStack_10,2);
  uVar1 = DAT_018c4ea0;
  *param_1 = *puVar2 ^ DAT_018c4ea0;
  param_1[1] = puVar2[1] ^ uVar1;
  param_1[2] = puVar2[2] ^ uVar1;
  return;
}



/* FUNCTION 29734 ; VA 0x00c8ff20 ; FUN_00c8ff20 */

undefined4 FUN_00c8ff20(undefined4 param_1)

{
  FUN_011612d0(param_1,0);
  return param_1;
}



/* FUNCTION 29735 ; VA 0x00c8ff40 ; FUN_00c8ff40 */

undefined4 FUN_00c8ff40(undefined4 param_1)

{
  FUN_011612d0(param_1,1);
  return param_1;
}



/* FUNCTION 29736 ; VA 0x00c8ff60 ; FUN_00c8ff60 */

void FUN_00c8ff60(void)

{
  int iVar1;
  
  if (DAT_01f01cd4 == 0) {
    iVar1 = FUN_00c8dbe0();
    DAT_01f01cd4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29737 ; VA 0x00c8ff80 ; FUN_00c8ff80 */

void FUN_00c8ff80(void)

{
  int iVar1;
  
  if (DAT_01f01894 == 0) {
    iVar1 = FUN_00c8dce0();
    DAT_01f01894 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29738 ; VA 0x00c8ffa0 ; FUN_00c8ffa0 */

void FUN_00c8ffa0(void)

{
  int iVar1;
  
  if (DAT_01f01ab4 == 0) {
    iVar1 = FUN_00c8dde0();
    DAT_01f01ab4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29739 ; VA 0x00c8ffb7 ; FUN_00c8ffb7 */

void FUN_00c8ffb7(void)

{
  FUN_00c8ffc0();
  return;
}



/* FUNCTION 29740 ; VA 0x00c8ffc0 ; FUN_00c8ffc0 */

void FUN_00c8ffc0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar4 = FUN_00c48580();
  if (iVar4 == 0) {
    puVar6 = (undefined4 *)FUN_0060efa0();
  }
  else {
    puVar5 = (undefined4 *)FUN_00b077e0();
    puVar6 = &uStack_34;
    uStack_34 = *puVar5;
    uStack_30 = puVar5[1];
    uStack_2c = puVar5[2];
    uStack_28 = puVar5[3];
    uStack_24 = puVar5[4];
    uStack_20 = puVar5[5];
    uStack_1c = puVar5[6];
    uStack_18 = puVar5[7];
    uStack_14 = puVar5[8];
    uStack_10 = puVar5[9];
    uStack_c = puVar5[10];
    uStack_8 = puVar5[0xb];
  }
  uVar1 = puVar6[1];
  uVar2 = puVar6[2];
  uVar3 = puVar6[3];
  *param_1 = *puVar6;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = puVar6[5];
  uVar2 = puVar6[6];
  uVar3 = puVar6[7];
  param_1[4] = puVar6[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = puVar6[9];
  uVar2 = puVar6[10];
  uVar3 = puVar6[0xb];
  param_1[8] = puVar6[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  return;
}



/* FUNCTION 29741 ; VA 0x00c90030 ; FUN_00c90030 */

undefined4 __thiscall FUN_00c90030(int param_1,undefined4 param_2)

{
  (*(code *)**(undefined4 **)(param_1 + 4 + *(int *)(*(int *)(param_1 + 4) + 4)))(param_2);
  return param_2;
}



/* FUNCTION 29742 ; VA 0x00c90050 ; FUN_00c90050 */

undefined8 * __thiscall FUN_00c90050(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  undefined auStack_10 [12];
  
  puVar2 = (undefined8 *)(**(code **)(param_1 + 8))(auStack_10);
  uVar1 = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return param_2;
}



/* FUNCTION 29743 ; VA 0x00c900a0 ; FUN_00c900a0 */

undefined4 * __thiscall FUN_00c900a0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_2[4] = puVar4[4];
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_2[8] = puVar4[8];
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  return param_2;
}



/* FUNCTION 29744 ; VA 0x00c900f0 ; FUN_00c900f0 */

void __fastcall FUN_00c900f0(int param_1)

{
  (**(code **)(param_1 + 8))();
  return;
}



/* FUNCTION 29745 ; VA 0x00c90120 ; FUN_00c90120 */

int FUN_00c90120(int *param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  if ((*(int *)(iVar2 + 0x98) == 2) && (param_2 != 0)) {
    uVar3 = *(undefined4 *)(param_2 + 0x34);
    param_2 = FUN_009ba880(uVar3);
    if (param_2 != 0) {
      param_2 = FUN_009b7250();
      if (param_2 != 0) {
        param_2 = FUN_00c8e640();
        if (param_2 == 0) {
          param_2 = FUN_008a65e0(uVar3,0);
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29746 ; VA 0x00c90200 ; FUN_00c90200 */

uint FUN_00c90200(void)

{
  int iVar1;
  
  iVar1 = FUN_00c8dbe0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29747 ; VA 0x00c90220 ; FUN_00c90220 */

uint FUN_00c90220(void)

{
  int iVar1;
  
  iVar1 = FUN_00c8dce0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29748 ; VA 0x00c90240 ; FUN_00c90240 */

uint FUN_00c90240(void)

{
  int iVar1;
  
  iVar1 = FUN_00c8dde0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29749 ; VA 0x00c90260 ; FUN_00c90260 */

uint FUN_00c90260(void)

{
  int iVar1;
  
  iVar1 = FUN_00c8dbe0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}


