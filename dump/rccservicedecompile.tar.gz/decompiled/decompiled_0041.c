/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 10250 ; VA 0x0071eeb0 ; FUN_0071eeb0 */

int * __thiscall FUN_0071eeb0(int *param_1,int param_2)

{
  int iVar1;
  char cVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar2 = FUN_0071f4e0(param_2);
  if (cVar2 != '\0') {
    iVar1 = *param_1;
    FUN_0170d1f0(iVar1,0,param_2 * 4);
    param_1[1] = param_2 * 4 + iVar1;
  }
  return param_1;
}



/* FUNCTION 10251 ; VA 0x0071ef00 ; FUN_0071ef00 */

undefined4 * __thiscall FUN_0071ef00(undefined4 *param_1,undefined4 *param_2,undefined8 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = param_2[5];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  param_1[4] = param_2[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  param_1[8] = param_2[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  *(undefined8 *)(param_1 + 0xc) = *param_3;
  param_1[0xe] = *(undefined4 *)(param_3 + 1);
  *(undefined8 *)(param_1 + 0xf) = *(undefined8 *)((int)param_3 + 0xc);
  param_1[0x11] = *(undefined4 *)((int)param_3 + 0x14);
  return param_1;
}



/* FUNCTION 10252 ; VA 0x0071ef50 ; FUN_0071ef50 */

undefined4 * __thiscall FUN_0071ef50(undefined4 *param_1,int *param_2)

{
  undefined4 uVar1;
  char cVar2;
  char cVar3;
  char cVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ac64e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[3] = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  puStack_18 = param_1;
  FUN_016830f0(param_1 + 6);
  *(undefined *)(param_1 + 8) = 0;
  param_1[10] = 0;
  *(undefined *)(param_1 + 0xb) = 0;
  *(undefined *)(param_1 + 0xf) = 0;
  param_1[0x10] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = param_2;
  *(undefined *)(param_1 + 0x14) = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  FUN_016830f0(param_1 + 0x1a);
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  *(undefined8 *)(param_1 + 0x1e) = DAT_018ce300;
  param_1[0x20] = 0;
  *(undefined *)(param_1 + 0x26) = 1;
  _uStack_8 = CONCAT31(uStack_7,2);
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  *(undefined8 *)(param_1 + 0x28) = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  if (param_2 != (int *)0x0) {
    piStack_14 = (int *)param_2[0xd];
    if (piStack_14 == (int *)0x0) {
      piStack_14 = param_2;
    }
    else if (piStack_14[0xd] != 0) {
      piStack_14 = (int *)FUN_005c8ac0();
    }
    if ((piStack_14 != (int *)0x0) &&
       (iVar9 = piStack_14[3], iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
       (uint)*(ushort *)(iVar6 + 0x1da))) {
      FUN_005789c0(&DAT_01eaef08,&LAB_006c41e0);
      uVar7 = FUN_006c4340();
      piStack_14 = (int *)FUN_008aa140(uVar7);
      if (*piStack_14 == 0) {
        uVar7 = FUN_00c9ab50();
        piVar8 = (int *)FUN_008a9ba0(auStack_20,uVar7);
        iVar9 = *piVar8;
        iVar6 = piVar8[1];
        *piVar8 = 0;
        piVar8[1] = 0;
        *piStack_14 = iVar9;
        piVar8 = (int *)piStack_14[1];
        piStack_14[1] = iVar6;
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar9 = piVar8[1] + -1;
          piVar8[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar9 = piVar8[2] + -1;
            piVar8[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar9 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            iVar9 = piStack_1c[2] + -1;
            piStack_1c[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
      }
      iVar9 = *piStack_14;
      goto LAB_0071f160;
    }
  }
  iVar9 = 0;
LAB_0071f160:
  puVar10 = (undefined4 *)FUN_0060dcd0(auStack_28,iVar9);
  uVar7 = *puVar10;
  uVar1 = puVar10[1];
  *puVar10 = 0;
  puVar10[1] = 0;
  param_1[0x1c] = uVar7;
  piVar8 = (int *)param_1[0x1d];
  param_1[0x1d] = uVar1;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar9 = piVar8[1] + -1;
    piVar8[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar9 = piVar8[2] + -1;
      piVar8[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_24[1] + -1;
    piStack_24[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar8 = piStack_24 + 2;
      iVar9 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  cVar5 = (**(code **)(*param_2 + 0xd4))();
  *(char *)((int)param_1 + 0x51) = cVar5;
  cVar2 = DAT_01d609d8;
  cVar3 = DAT_01d609e0;
  cVar4 = DAT_01d609e8;
  if ((cVar5 == '\0') ||
     (cVar2 = DAT_01d609b8, cVar3 = DAT_01d609c0, cVar4 = DAT_01d609c8, DAT_01d609d0 == '\0')) {
    if (cVar4 == '\0') {
      if (cVar3 == '\0') {
        uVar7 = 2;
        if (cVar2 != '\0') {
          uVar7 = 0;
        }
        param_1[0x11] = uVar7;
      }
      else {
        param_1[0x11] = 1;
      }
    }
    else {
      param_1[0x11] = 2;
    }
  }
  else {
    param_1[0x11] = 3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10253 ; VA 0x0071f260 ; FUN_0071f260 */

undefined4 * __thiscall FUN_0071f260(float *param_1,undefined4 *param_2,int param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  undefined auStack_3c [44];
  float fStack_10;
  ulonglong uStack_c;
  
  fVar1 = *(float *)(param_3 + 0x24);
  fVar2 = *(float *)(param_3 + 0x28);
  fVar3 = *(float *)(param_3 + 0x2c);
  fVar4 = param_1[4];
  uStack_c = (ulonglong)
             (uint)(param_1[1] * fVar2 + fVar1 * *param_1 + param_1[2] * fVar3 + param_1[9]);
  fVar5 = param_1[3];
  fVar6 = param_1[5];
  fVar7 = param_1[10];
  fStack_10 = param_1[6] * fVar1 + param_1[7] * fVar2 + param_1[8] * fVar3 + param_1[0xb];
  puVar12 = (undefined4 *)FUN_01160c20(auStack_3c,param_3);
  uVar8 = puVar12[1];
  uVar9 = puVar12[2];
  uVar10 = puVar12[3];
  *param_2 = *puVar12;
  param_2[1] = uVar8;
  param_2[2] = uVar9;
  param_2[3] = uVar10;
  uVar9 = puVar12[5];
  uVar10 = puVar12[6];
  uVar11 = puVar12[7];
  uVar8 = puVar12[8];
  param_2[4] = puVar12[4];
  param_2[5] = uVar9;
  param_2[6] = uVar10;
  param_2[7] = uVar11;
  param_2[8] = uVar8;
  *(ulonglong *)(param_2 + 9) =
       CONCAT44(fVar5 * fVar1 + fVar4 * fVar2 + fVar6 * fVar3 + fVar7,(int)uStack_c);
  param_2[0xb] = fStack_10;
  return param_2;
}



/* FUNCTION 10254 ; VA 0x0071f340 ; FUN_0071f340 */

void FUN_0071f340(undefined4 param_1,undefined param_2)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  byte bVar5;
  char *pcVar6;
  byte bStack0000000b;
  undefined auStack_18 [4];
  float fStack_14;
  int iStack_10;
  int iStack_c;
  byte abStack_8 [4];
  
  iVar2 = FUN_00ca1550();
  bStack0000000b = 0;
  iStack_10 = 0;
  iVar2 = *(int *)(iVar2 + 0x1a0);
  if (iVar2 == 0) {
    param_2 = 0;
    FUN_006ad5e0(&param_2,1);
  }
  else {
    if (*(int *)(iVar2 + 0x30) != 0) {
      pcVar4 = *(char **)(iVar2 + 0x28);
      iStack_10 = 0;
      bStack0000000b = 0;
      do {
        if (pcVar4 == (char *)0x0) break;
        if (*pcVar4 != '\0') {
          iVar3 = DAT_01d60950;
          if (*(char *)(iStack_c + 0x2c) != '\0') {
            iVar3 = 1;
          }
          if ((int)(uint)bStack0000000b < iVar3) {
            bStack0000000b = bStack0000000b + 1;
          }
          else {
            iStack_10 = iStack_10 + 1;
          }
        }
        pcVar4 = pcVar4 + 0x60;
        if (pcVar4 == *(char **)(iVar2 + 0x24)) {
          pcVar4 = *(char **)(iVar2 + 0x20);
        }
      } while (pcVar4 != *(char **)(iVar2 + 0x2c));
    }
    bVar5 = bStack0000000b;
    abStack_8[0] = bStack0000000b;
    FUN_006ad5e0(abStack_8,1);
    if (*(int *)(iVar2 + 0x30) != 0) {
      pcVar4 = *(char **)(iVar2 + 0x28);
      pcVar1 = pcVar4;
      while (pcVar1 != (char *)0x0) {
        if (bVar5 == 0) {
          return;
        }
        if (*pcVar4 != '\0') {
          if (iStack_10 == 0) {
            bStack0000000b = bVar5 - 1;
            fStack_14 = (float)(*(double *)(iStack_c + 0xa0) - *(double *)(pcVar4 + 0x58));
            FUN_006a5c10(&fStack_14,auStack_18,4);
            FUN_006ad5e0(auStack_18,4);
            FUN_007218f0(param_1,pcVar4 + 0xc);
            FUN_00721cf0(param_1,pcVar4 + 0x3c);
            FUN_006b92d0(param_1,pcVar4 + 4);
          }
          else {
            iStack_10 = iStack_10 + -1;
          }
        }
        pcVar6 = pcVar4 + 0x60;
        if (pcVar6 == *(char **)(iVar2 + 0x24)) {
          pcVar6 = *(char **)(iVar2 + 0x20);
        }
        pcVar4 = (char *)0x0;
        if (pcVar6 != *(char **)(iVar2 + 0x2c)) {
          pcVar4 = pcVar6;
        }
        bVar5 = bStack0000000b;
        pcVar1 = (char *)0x0;
        if (pcVar6 != *(char **)(iVar2 + 0x2c)) {
          pcVar1 = pcVar6;
        }
      }
    }
    if ((bVar5 != 0) && (DAT_01eafc10 != '\0')) {
      FUN_01677520(DAT_01eafc10,"to many left 0x%x",bVar5);
      return;
    }
  }
  return;
}



/* FUNCTION 10255 ; VA 0x0071f4e0 ; FUN_0071f4e0 */

uint __thiscall FUN_0071f4e0(uint *param_1,uint param_2)

{
  uint in_EAX;
  uint uVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  param_2 = param_2 * 4;
  if (param_2 < 0x1000) {
    if (param_2 != 0) {
      uVar1 = FUN_01674e20(param_2);
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = *param_1 + param_2;
      return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = *param_1;
    return CONCAT31((int3)(*param_1 >> 8),1);
  }
  uVar1 = param_2 + 0x23;
  if (uVar1 <= param_2) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar1 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar1 - 4) = iVar2;
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 10256 ; VA 0x0071f5a0 ; FUN_0071f5a0 */

float10 FUN_0071f5a0(undefined8 param_1)

{
  return (float10)(double)CONCAT44((uint)((ulonglong)param_1 >> 0x20) & DAT_018c0da0._4_4_,
                                   (uint)param_1 & (uint)DAT_018c0da0);
}



/* FUNCTION 10257 ; VA 0x0071f5c0 ; FUN_0071f5c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_0071f5c0(undefined4 *param_1,float *param_2,int param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  float *pfVar12;
  undefined4 *puVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  undefined auStack_e4 [36];
  undefined auStack_c0 [36];
  undefined auStack_9c [44];
  float fStack_70;
  float fStack_64;
  float fStack_58;
  ulonglong uStack_54;
  ulonglong uStack_4c;
  ulonglong uStack_40;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  undefined8 uStack_14;
  float fStack_c;
  float fStack_8;
  
  fVar20 = *(float *)(param_3 + 0x3c) - param_2[0xf];
  fVar16 = *(float *)(param_3 + 0x40) - param_2[0x10];
  fVar18 = *(float *)(param_3 + 0x44) - param_2[0x11];
  fVar23 = *(float *)(param_3 + 0x24) - param_2[9];
  fVar21 = *(float *)(param_3 + 0x28) - param_2[10];
  uStack_54 = (ulonglong)(uint)(param_2[3] * fVar16 + *param_2 * fVar20 + param_2[6] * fVar18);
  fStack_8 = param_2[4] * fVar16 + param_2[1] * fVar20 + param_2[7] * fVar18;
  fVar19 = *(float *)(param_3 + 0x2c) - param_2[0xb];
  fStack_70 = param_2[5] * fVar16 + param_2[2] * fVar20 + param_2[8] * fVar18;
  fVar14 = *(float *)(param_3 + 0x34) -
           ((param_2[0x11] * fVar23 - param_2[0xf] * fVar19) + param_2[0xd]);
  fVar17 = *(float *)(param_3 + 0x30) -
           ((param_2[0x10] * fVar19 - param_2[0x11] * fVar21) + param_2[0xc]);
  fVar15 = *(float *)(param_3 + 0x38) -
           ((param_2[0xf] * fVar21 - param_2[0x10] * fVar23) + param_2[0xe]);
  uStack_4c = (ulonglong)(uint)(fVar17 * *param_2 + fVar14 * param_2[3] + fVar15 * param_2[6]);
  fVar16 = param_2[1];
  fVar18 = param_2[4];
  fVar19 = param_2[7];
  fStack_38 = (float)_DAT_018e3fb0;
  fStack_34 = (float)_UNK_018e3fb4;
  fStack_30 = (float)_UNK_018e3fb8;
  fStack_2c = (float)_UNK_018e3fbc;
  fStack_64 = fVar17 * param_2[2] + fVar14 * param_2[5] + fVar15 * param_2[8];
  fStack_28 = (float)_DAT_018e3fb0;
  fStack_24 = (float)_UNK_018e3fb4;
  fStack_20 = (float)_UNK_018e3fb8;
  fStack_1c = (float)_UNK_018e3fbc;
  fStack_18 = (float)_DAT_018e3fb0;
  uStack_14 = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
  fStack_c = (float)_UNK_018e3fbc;
  pfVar12 = (float *)FUN_011630b0(auStack_9c);
  fStack_38 = *pfVar12;
  fStack_34 = pfVar12[1];
  fStack_30 = pfVar12[2];
  fStack_2c = pfVar12[3];
  fStack_28 = pfVar12[4];
  fStack_24 = pfVar12[5];
  fStack_20 = pfVar12[6];
  fStack_1c = pfVar12[7];
  fStack_18 = pfVar12[8];
  pfVar12 = (float *)FUN_01160de0(auStack_c0);
  fVar20 = param_2[9];
  fVar21 = param_2[10];
  fVar23 = param_2[0xb];
  fVar1 = *(float *)(param_3 + 0x2c);
  fVar24 = pfVar12[1] * fVar21 + fVar20 * *pfVar12 + pfVar12[2] * fVar23;
  fVar22 = pfVar12[3] * fVar20 + pfVar12[4] * fVar21 + pfVar12[5] * fVar23;
  fVar2 = *(float *)(param_3 + 0x24);
  fVar3 = *(float *)(param_3 + 0x28);
  fStack_c = pfVar12[6] * fVar20 + pfVar12[7] * fVar21 + pfVar12[8] * fVar23;
  uStack_14 = CONCAT44(fVar22,fVar24);
  uStack_40 = (ulonglong)(uint)(fStack_38 * fVar2 + fStack_34 * fVar3 + fStack_30 * fVar1 + fVar24);
  fVar23 = fStack_28 * fVar3;
  fVar20 = fStack_2c * fVar2;
  fVar21 = fStack_24 * fVar1;
  fStack_58 = fStack_1c * fVar3 + fStack_20 * fVar2 + fStack_18 * fVar1 + fStack_c;
  puVar13 = (undefined4 *)FUN_01160c20(auStack_e4,param_3);
  uVar5 = puVar13[1];
  uVar6 = puVar13[2];
  uVar7 = puVar13[3];
  uVar8 = puVar13[4];
  uVar9 = puVar13[5];
  uVar10 = puVar13[6];
  uVar11 = puVar13[7];
  uVar4 = puVar13[8];
  *param_1 = *puVar13;
  param_1[1] = uVar5;
  param_1[2] = uVar6;
  param_1[3] = uVar7;
  param_1[4] = uVar8;
  param_1[5] = uVar9;
  param_1[6] = uVar10;
  param_1[7] = uVar11;
  param_1[8] = uVar4;
  param_1[9] = (int)uStack_40;
  param_1[10] = fVar23 + fVar20 + fVar21 + fVar22;
  param_1[0xb] = fStack_58;
  *(ulonglong *)(param_1 + 0xc) =
       CONCAT44(fVar17 * fVar16 + fVar14 * fVar18 + fVar15 * fVar19,(int)uStack_4c);
  param_1[0xe] = fStack_64;
  *(ulonglong *)(param_1 + 0xf) = CONCAT44(fStack_8,(int)uStack_54);
  param_1[0x11] = fStack_70;
  return param_1;
}



/* FUNCTION 10258 ; VA 0x0071f950 ; FUN_0071f950 */

uint __thiscall
FUN_0071f950(int param_1,int *param_2,undefined4 param_3,undefined4 param_4,int param_5,char param_6
            ,undefined *param_7)

{
  double dVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  short sVar12;
  undefined *puVar13;
  uint uVar14;
  uint uVar15;
  int iVar16;
  double *pdVar17;
  int iVar18;
  double dVar19;
  double dVar20;
  double dVar21;
  double dStack_20;
  undefined8 uStack_18;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  if (param_7 != (undefined *)0x0) {
    *param_7 = 0;
  }
  puVar13 = param_7;
  if (((int *)*param_2 != (int *)0x0) &&
     ((iStack_8 = param_1, param_6 != '\0' ||
      (puVar13 = (undefined *)(**(code **)(*(int *)*param_2 + 8))(),
      *(undefined **)(param_1 + 0x38) <= puVar13)))) {
    if ((param_5 != 0) &&
       ((uVar14 = (**(code **)(*(int *)*param_2 + 8))(), *(uint *)(param_1 + 0x38) <= uVar14 &&
        (1 < *(uint *)(param_1 + 0x40))))) {
      piVar2 = (int *)*param_2;
      uVar14 = FUN_0061e980();
      uVar15 = (**(code **)(*piVar2 + 8))();
      param_1 = iStack_8;
      if (uVar14 <= uVar15) {
        if (param_7 != (undefined *)0x0) {
          *param_7 = 1;
        }
        FUN_006ab6a0(param_5,1);
        param_1 = iStack_8;
      }
    }
    FUN_006b9320(*param_2,0);
    iVar16 = (**(code **)(*(int *)*param_2 + 8))();
    iVar3 = *(int *)(param_1 + 0x4c);
    *(int *)(param_1 + 0x34) = *(int *)(param_1 + 0x34) + iVar16;
    uVar4 = *(undefined4 *)(iVar3 + 0x74);
    uVar5 = *(undefined4 *)(iVar3 + 0x78);
    uVar6 = *(undefined4 *)(iVar3 + 0x7c);
    uVar7 = *(undefined4 *)(iVar3 + 0x80);
    uVar8 = *(undefined4 *)(iVar3 + 0x84);
    uVar9 = *(undefined4 *)(iVar3 + 0x88);
    uVar10 = *(undefined4 *)(iVar3 + 0x8c);
    uVar11 = *(undefined4 *)(iVar3 + 0x90);
    if (param_2[1] != 0) {
      LOCK();
      piVar2 = (int *)(param_2[1] + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    FUN_006afb30(*param_2,param_2[1],param_3,0,0,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,uVar10,uVar11,0
                 ,iVar3 + 0x17c8);
    pdVar17 = (double *)FUN_006243a0();
    if (*(char *)(pdVar17 + 1) == '\0') {
      FUN_016827a0(&uStack_10);
      dStack_20 = (double)CONCAT44(uStack_c,uStack_10) - *pdVar17;
      *(undefined4 *)pdVar17 = uStack_10;
      *(undefined4 *)((int)pdVar17 + 4) = uStack_c;
      uStack_18 = dStack_20;
      sVar12 = FUN_017265ed(&dStack_20);
      if (sVar12 < 1) {
        dVar1 = pdVar17[2];
        dVar19 = DAT_018c0d60 - dVar1;
        dVar20 = uStack_18;
        if (*(char *)(pdVar17 + 6) == '\0') {
          dVar20 = pdVar17[4] * dVar19 + dVar1 * uStack_18;
        }
        *(undefined *)(pdVar17 + 6) = 0;
        pdVar17[3] = uStack_18;
        pdVar17[4] = dVar20;
        pdVar17[5] = (uStack_18 - dVar20) * (uStack_18 - dVar20) * dVar1 + dVar19 * pdVar17[5];
      }
    }
    else {
      FUN_016827a0(&uStack_18);
      *(undefined4 *)pdVar17 = (undefined4)uStack_18;
      *(undefined4 *)((int)pdVar17 + 4) = uStack_18._4_4_;
      *(undefined *)(pdVar17 + 1) = 0;
    }
    iVar16 = iStack_8;
    iVar18 = FUN_006243a0();
    iVar3 = *(int *)(*param_2 + 0x18);
    dStack_20 = (double)iVar3;
    sVar12 = FUN_017265ed(&dStack_20);
    if (sVar12 < 1) {
      dVar1 = *(double *)(iVar18 + 0xa8);
      dVar21 = DAT_018c0d60 - dVar1;
      dVar19 = (double)iVar3;
      dVar20 = dVar19;
      if (*(char *)(iVar18 + 200) == '\0') {
        dVar20 = *(double *)(iVar18 + 0xb8) * dVar21 + dVar19 * dVar1;
      }
      *(int *)(iVar18 + 0xb0) = iVar3;
      *(double *)(iVar18 + 0xb8) = dVar20;
      *(undefined *)(iVar18 + 200) = 0;
      *(double *)(iVar18 + 0xc0) =
           (dVar19 - dVar20) * (dVar19 - dVar20) * dVar1 + *(double *)(iVar18 + 0xc0) * dVar21;
    }
    if (DAT_01d59fb8 != '\0') {
      piVar2 = (int *)(*(int *)(iVar16 + 0x4c) + 0x18d8);
      *piVar2 = *piVar2 + *(int *)(*param_2 + 0x18);
    }
    *param_2 = 0;
    piVar2 = (int *)param_2[1];
    param_2[1] = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    puVar13 = *(undefined **)(iVar16 + 0x30);
    if ((0 < (int)puVar13) && ((int)puVar13 <= *(int *)(iVar16 + 0x34))) {
      return CONCAT31((int3)((uint)puVar13 >> 8),1);
    }
  }
  return (uint)puVar13 & 0xffffff00;
}



/* FUNCTION 10259 ; VA 0x0071fc40 ; FUN_0071fc40 */

undefined FUN_0071fc40(double param_1,double param_2)

{
  float10 fVar1;
  double dVar2;
  double dVar3;
  uint uVar4;
  uint uVar5;
  
  if ((NAN(param_1) || NAN(param_2)) == (param_1 == param_2)) {
    dVar3 = (double)CONCAT44((uint)((ulonglong)param_1 >> 0x20) & DAT_018c0da0._4_4_,
                             SUB84(param_1,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    uVar4 = SUB84(param_1 - param_2,0) & (uint)DAT_018c0da0;
    uVar5 = (uint)((ulonglong)(param_1 - param_2) >> 0x20) & DAT_018c0da0._4_4_;
    fVar1 = (float10)FUN_01160810();
    dVar2 = DAT_018f76b0;
    if ((NAN(dVar3) || NAN((double)fVar1)) == (dVar3 == (double)fVar1)) {
      dVar2 = dVar3 * DAT_018f76b0;
    }
    if (dVar2 < (double)CONCAT44(uVar5,uVar4)) {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 10260 ; VA 0x0071fcc0 ; FUN_0071fcc0 */

undefined4 * __thiscall FUN_0071fcc0(int param_1,undefined4 *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  float *pfVar11;
  undefined auStack_34 [48];
  
  *param_2 = 0x3f800000;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0x3f800000;
  param_2[5] = 0;
  param_2[6] = 0;
  param_2[7] = 0;
  param_2[8] = 0x3f800000;
  param_2[9] = 0;
  param_2[10] = 0;
  param_2[0xb] = 0;
  puVar10 = (undefined4 *)FUN_011630b0(auStack_34);
  uVar7 = puVar10[1];
  uVar8 = puVar10[2];
  uVar9 = puVar10[3];
  *param_2 = *puVar10;
  param_2[1] = uVar7;
  param_2[2] = uVar8;
  param_2[3] = uVar9;
  uVar7 = puVar10[5];
  uVar8 = puVar10[6];
  uVar9 = puVar10[7];
  param_2[4] = puVar10[4];
  param_2[5] = uVar7;
  param_2[6] = uVar8;
  param_2[7] = uVar9;
  param_2[8] = puVar10[8];
  pfVar11 = (float *)FUN_01160de0(auStack_34);
  fVar1 = *(float *)(param_1 + 0x24);
  fVar2 = *(float *)(param_1 + 0x28);
  fVar3 = *(float *)(param_1 + 0x2c);
  fVar4 = pfVar11[6];
  fVar5 = pfVar11[7];
  fVar6 = pfVar11[8];
  *(ulonglong *)(param_2 + 9) =
       CONCAT44(pfVar11[3] * fVar1 + pfVar11[4] * fVar2 + pfVar11[5] * fVar3,
                pfVar11[1] * fVar2 + fVar1 * *pfVar11 + pfVar11[2] * fVar3);
  param_2[0xb] = fVar4 * fVar1 + fVar5 * fVar2 + fVar6 * fVar3;
  return param_2;
}



/* FUNCTION 10261 ; VA 0x0071fde0 ; FUN_0071fde0 */

void __thiscall FUN_0071fde0(int param_1,int *param_2,int *param_3,undefined4 param_4)

{
  uint uVar1;
  undefined uVar2;
  undefined uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined8 uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  undefined1 *puStack_50;
  undefined8 uStack_4c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac674;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eafcd0) {
    uStack_4c._4_4_ = &DAT_01eafcd0;
    uStack_4c._0_4_ = (char *)0x71ff9c;
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    if (DAT_01eafcd0 == -1) {
      uStack_4c._4_4_ = (undefined4 *)0xffffffff;
      uStack_4c._0_4_ = "Sort Priorities";
      puStack_50 = &DAT_018c5904;
      uStack_8 = 0;
      puStack_54 = (undefined4 *)0x71ffc4;
      uVar7 = FUN_0152dab0();
      DAT_01eafccc = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eafcc8 = (undefined4)uVar7;
      puStack_54 = &DAT_01eafcd0;
      uStack_8 = 0xffffffff;
      uStack_58 = 0x71ffe0;
      FUN_016f37bf();
    }
  }
  uVar5 = DAT_01eafccc;
  uVar4 = DAT_01eafcc8;
  uStack_4c._4_4_ = (undefined4 *)DAT_01eafccc;
  uStack_4c._0_4_ = (char *)DAT_01eafcc8;
  puStack_50 = (undefined1 *)0x71fe42;
  uVar7 = FUN_0152d930();
  uVar3 = DAT_01eafc36;
  uVar2 = DAT_01eafc35;
  uStack_8 = 1;
  uVar6 = *(uint *)(param_1 + 0x5c);
  uVar1 = (param_2[1] - *param_2) / 0x90;
  if (*(int *)(param_1 + 0x48) == 0) {
    if (uVar1 <= uVar6) goto LAB_0071ff34;
    iVar10 = param_3[1];
    iVar8 = *param_3;
    iVar9 = iVar8 + uVar6 * 4;
    FUN_0071ee30(param_4);
    FUN_0071ea20(&uStack_58,FUN_006dc930,uVar3,uVar2);
  }
  else {
    if (uVar1 <= uVar6) goto LAB_0071ff34;
    iVar10 = param_3[1];
    iVar8 = *param_3;
    iVar9 = iVar8 + uVar6 * 4;
    FUN_0071ee30(param_4);
    FUN_0071ea20(&uStack_58,FUN_006dc930,uVar3,uVar2);
  }
  FUN_0071ec00(iVar8,iVar9,iVar10);
  uVar6 = *(uint *)(param_1 + 0x5c);
LAB_0071ff34:
  *(uint *)(param_1 + 0x60) = uVar6;
  if (*(int *)(param_1 + 0x44) == 0) {
    *(undefined4 *)(param_1 + 0x54) = 0;
  }
  else {
    uVar6 = (param_2[1] - *param_2) / 0x90 - 1;
    if (uVar6 <= *(uint *)(param_1 + 0x54)) {
      *(uint *)(param_1 + 0x54) = uVar6;
    }
  }
  uStack_8 = 2;
  puStack_50 = (undefined1 *)uVar5;
  puStack_54 = (undefined4 *)uVar4;
  uStack_58 = 0x71ff7c;
  uStack_4c = uVar7;
  FUN_0152dda0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10262 ; VA 0x0071fff0 ; FUN_0071fff0 */

uint __thiscall
FUN_0071fff0(int param_1,int *param_2,undefined4 param_3,undefined4 param_4,int *param_5,
            undefined4 param_6)

{
  int iVar1;
  int iVar2;
  undefined uVar3;
  undefined uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  bool bVar9;
  undefined8 uVar10;
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined1 *puStack_e8;
  undefined8 uStack_e4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac694;
  pvStack_10 = ExceptionList;
  uVar7 = (param_2[1] - *param_2) / 0x90;
  if (uVar7 != 0) {
    uVar8 = *(uint *)(param_1 + 0x44);
    if (((uVar8 == 0) || (uVar8 == 2)) || (bVar9 = uVar8 == 3, ExceptionList = &pvStack_10, bVar9))
    {
      uVar7 = *(uint *)(param_1 + 0x58);
      ExceptionList = &pvStack_10;
      if (*(uint *)(param_1 + 0x60) < uVar7) {
        ExceptionList = &pvStack_10;
        if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
            DAT_01eafce0) {
          uStack_e4._4_4_ = &DAT_01eafce0;
          uStack_e4._0_4_ = (char *)0x720494;
          ExceptionList = &pvStack_10;
          FUN_016f3809();
          if (DAT_01eafce0 == -1) {
            uStack_e4._4_4_ = (undefined4 *)0xffffffff;
            uStack_e4._0_4_ = "Further Prioritization";
            puStack_e8 = &DAT_018c5904;
            uStack_8 = 0;
            puStack_ec = (undefined4 *)0x7204bc;
            uVar10 = FUN_0152dab0();
            DAT_01eafcdc = (undefined4)((ulonglong)uVar10 >> 0x20);
            DAT_01eafcd8 = (undefined4 *)uVar10;
            puStack_ec = &DAT_01eafce0;
            uStack_8 = 0xffffffff;
            uStack_f0 = 0x7204d8;
            FUN_016f37bf();
          }
        }
        uVar6 = DAT_01eafcdc;
        puVar5 = DAT_01eafcd8;
        uStack_e4._4_4_ = (undefined4 *)DAT_01eafcdc;
        uStack_e4._0_4_ = (char *)DAT_01eafcd8;
        puStack_e8 = (undefined1 *)0x720093;
        uVar10 = FUN_0152d930();
        uVar4 = DAT_01eafc36;
        uVar3 = DAT_01eafc35;
        uStack_8 = 1;
        iVar1 = (param_2[1] - *param_2) / 0x90;
        uVar7 = (uint)(iVar1 - *(int *)(param_1 + 0x60)) >> 1;
        if (uVar7 == 0) {
          *(int *)(param_1 + 0x60) = iVar1;
        }
        else {
          iVar2 = param_5[1];
          iVar1 = *param_5 + *(int *)(param_1 + 0x60) * 4;
          FUN_0071ee30(param_6);
          FUN_0071ea20(&uStack_f0,FUN_006dc930,uVar4,uVar3);
          FUN_0071ec00(iVar1,iVar1 + uVar7 * 4,iVar2);
          *(int *)(param_1 + 0x60) = *(int *)(param_1 + 0x60) + uVar7;
        }
        uStack_8 = 2;
        puStack_e8 = (undefined1 *)uVar6;
        puStack_ec = puVar5;
        uStack_f0 = 0x720157;
        uStack_e4 = uVar10;
        uVar7 = FUN_0152dda0();
        uVar8 = *(uint *)(param_1 + 0x44);
      }
      bVar9 = uVar8 == 3;
    }
    uStack_8 = 0xffffffff;
    if (uVar8 < 3 || bVar9) {
                    /* WARNING: Could not recover jumptable at 0x0072016d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar7 = (**(code **)(&DAT_007204e0 + uVar8 * 4))();
      return uVar7;
    }
  }
  ExceptionList = pvStack_10;
  return uVar7 & 0xffffff00;
}



/* FUNCTION 10263 ; VA 0x007204f0 ; FUN_007204f0 */

void __thiscall
FUN_007204f0(int param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (0 < *(int *)(param_3 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_3 + 0x10) + uStack_8 * 4);
      uVar4 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      uVar3 = FUN_00b06610(uVar4);
      cVar2 = FUN_006b8fb0(uVar3);
      if (cVar2 != '\0') {
        FUN_006b9320(param_2,uVar3);
        if (*(char *)(param_1 + 0x51) == '\0') {
          FUN_007215c0(param_2,uVar4,param_4,param_5,param_6);
        }
        else {
          uVar3 = *(undefined4 *)(param_2 + 0x18);
          FUN_007215c0(param_2,uVar4,param_4,param_5,param_6);
          FUN_006ab690(uVar3);
        }
        FUN_007204f0(param_2,uVar4,param_4,param_5,param_6);
      }
      uStack_8 = uStack_8 + 1;
    } while (uStack_8 < *(int *)(param_3 + 0x14));
  }
  return;
}



/* FUNCTION 10264 ; VA 0x007205c0 ; FUN_007205c0 */

void __thiscall FUN_007205c0(int param_1,int *param_2,int param_3,undefined4 param_4,int param_5)

{
  double dVar1;
  int *piVar2;
  char cVar3;
  short sVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  double *pdVar8;
  double dVar9;
  double dVar10;
  double dVar11;
  undefined8 uStack_1c;
  int iStack_14;
  int iStack_10;
  undefined4 uStack_9;
  char cStack_5;
  
  piVar2 = param_2;
  iStack_14 = (**(code **)(*param_2 + 8))();
  iVar7 = param_5;
  cStack_5 = *(char *)(param_5 + 0x56);
  param_2 = (int *)CONCAT31(param_2._1_3_,cStack_5 << 5 | *(byte *)(param_5 + 0x57));
  FUN_006ad5e0(&param_2,1);
  iStack_10 = iVar7 + 0x5c;
  cVar3 = FUN_00724670(piVar2);
  if (cVar3 == '\0') {
    param_2 = (int *)FUN_00c155c0();
    if (param_2 == (int *)0x0) {
      return;
    }
    iVar7 = piVar2[6];
    uStack_1c = (double)CONCAT44(iVar7,(undefined4)uStack_1c);
    uVar5 = FUN_00b084f0();
    uStack_9 = CONCAT31(uStack_9._1_3_,*(undefined *)(param_5 + 0x54));
    if (*(char *)(param_1 + 0x51) == '\0') {
      FUN_007215c0(piVar2,param_2,param_4,uStack_9,uVar5);
    }
    else {
      iVar7 = piVar2[6];
      FUN_007215c0(piVar2,param_2,param_4,uStack_9,uVar5);
      FUN_006ab690(iVar7);
      iVar7 = uStack_1c._4_4_;
    }
    if (cStack_5 == '\0') {
      uVar5 = FUN_00b084f0();
      FUN_007204f0(piVar2,param_2,param_4,*(undefined *)(param_5 + 0x54),uVar5);
      FUN_006b9320(piVar2,0);
    }
    if (*(char *)(param_1 + 0x51) != '\0') {
      iVar6 = (**(code **)(*piVar2 + 8))();
      FUN_00724700(piVar2,iVar7,iVar6 - iVar7);
    }
  }
  if ((DAT_01d5be00 != '\0') && (*(char *)(param_1 + 0x50) != '\0')) {
    iVar7 = FUN_006243a0();
    pdVar8 = (double *)FUN_016827a0(&uStack_1c);
    if (*(double *)(iVar7 + 0x1d0) <= *pdVar8 - *(double *)(iVar7 + 0x1c8)) {
      *(undefined4 *)(iVar7 + 0x1d8) = *(undefined4 *)(iVar7 + 0x1dc);
      *(undefined4 *)(iVar7 + 0x1dc) = 0;
      FUN_016827a0(&uStack_1c);
      *(undefined4 *)(iVar7 + 0x1c8) = (undefined4)uStack_1c;
      *(int *)(iVar7 + 0x1cc) = uStack_1c._4_4_;
    }
    *(int *)(iVar7 + 0x1dc) = *(int *)(iVar7 + 0x1dc) + 1;
    iVar7 = FUN_006243a0();
    param_3 = (**(code **)(*piVar2 + 8))();
    param_3 = param_3 - iStack_14;
    uStack_1c = (double)param_3;
    sVar4 = FUN_017265ed(&uStack_1c);
    if (sVar4 < 1) {
      dVar1 = *(double *)(iVar7 + 0x1e0);
      dVar11 = DAT_018c0d60 - dVar1;
      dVar9 = (double)param_3;
      dVar10 = dVar9;
      if (*(char *)(iVar7 + 0x200) == '\0') {
        dVar10 = *(double *)(iVar7 + 0x1f0) * dVar11 + dVar9 * dVar1;
      }
      *(int *)(iVar7 + 0x1e8) = param_3;
      *(double *)(iVar7 + 0x1f0) = dVar10;
      *(undefined *)(iVar7 + 0x200) = 0;
      *(double *)(iVar7 + 0x1f8) =
           (dVar9 - dVar10) * (dVar9 - dVar10) * dVar1 + *(double *)(iVar7 + 0x1f8) * dVar11;
    }
  }
  if (DAT_01d5a088 != '\0') {
    iVar7 = (**(code **)(*piVar2 + 8))();
    *(int *)(*(int *)(param_1 + 0x4c) + 0x3ad0) = iVar7 - iStack_14;
  }
  return;
}



/* FUNCTION 10265 ; VA 0x007207f0 ; FUN_007207f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_007207f0(int param_1,int *param_2,undefined4 param_3)

{
  float fVar1;
  int iVar2;
  float fVar3;
  undefined4 uVar4;
  char cVar5;
  char cVar6;
  undefined uVar7;
  int iVar8;
  int *piVar9;
  undefined4 uVar10;
  int iVar11;
  uint uVar12;
  undefined4 *puVar13;
  int *piVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  undefined8 uVar20;
  undefined4 uVar21;
  char *pcVar22;
  undefined4 uStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  undefined4 uStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  undefined4 uStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  char cStack_58;
  int aiStack_50 [2];
  int iStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  float *apfStack_38 [3];
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac6f0;
  pvStack_10 = ExceptionList;
  puVar13 = *(undefined4 **)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  puStack_1c = puVar13;
  if (((int)puVar13[0xd] < DAT_01eafc90) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eafc90), cVar5 = DAT_01d7ad48,
     DAT_01eafc90 == -1)) {
    uStack_8 = 0;
    uVar20 = FUN_0152dab0(&DAT_018c5904,"Physics Send",0xffffffff);
    uStack_20 = (undefined4)((ulonglong)uVar20 >> 0x20);
    if ((cVar5 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar20);
    }
    uStack_8 = 0xffffffff;
    DAT_01eafc88 = (int)uVar20;
    DAT_01eafc8c = uStack_20;
    FUN_016f37bf(&DAT_01eafc90);
    puVar13 = puStack_1c;
  }
  cStack_11 = DAT_01d7ad48;
  uStack_44 = DAT_01eafc88;
  uStack_68 = DAT_01eafc88;
  uStack_40 = DAT_01eafc8c;
  uStack_64 = DAT_01eafc8c;
  uStack_60 = FUN_01532c80(DAT_01eafc88,DAT_01eafc8c);
  cStack_58 = cStack_11;
  uStack_8 = 1;
  if (DAT_01d5b598 == '\0') {
    if ((int)puVar13[0xd] < DAT_01eafcb0) {
      FUN_016f3809(&DAT_01eafcb0);
      if (DAT_01eafcb0 == -1) {
        uStack_8._0_1_ = 3;
        uVar20 = FUN_0152da50(&DAT_018c5904);
        DAT_01eafcac = (undefined4)((ulonglong)uVar20 >> 0x20);
        DAT_01eafca8 = (undefined4)uVar20;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01eafcb0);
      }
    }
    pcVar22 = "Physics Bytes To Produce : %d";
    uVar10 = DAT_01eafca8;
    uVar21 = DAT_01eafcac;
  }
  else {
    if ((int)puVar13[0xd] < DAT_01eafca0) {
      FUN_016f3809(&DAT_01eafca0);
      if (DAT_01eafca0 == -1) {
        uStack_8._0_1_ = 2;
        uVar20 = FUN_0152da50(&DAT_018c5904);
        DAT_01eafc9c = (undefined4)((ulonglong)uVar20 >> 0x20);
        DAT_01eafc98 = (undefined4)uVar20;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01eafca0);
      }
    }
    pcVar22 = "PhysicsSender - Byte Budget : %d";
    uVar10 = DAT_01eafc98;
    uVar21 = DAT_01eafc9c;
  }
  piVar9 = param_2;
  FUN_0152d760(uVar10,uVar21,pcVar22,param_2);
  piVar14 = (int *)0x0;
  *(int **)(param_1 + 0x30) = piVar9;
  iStack_28 = 0;
  piStack_24 = (int *)0x0;
  uStack_98 = _DAT_018e3fb0;
  fStack_94 = _UNK_018e3fb4;
  fStack_90 = _UNK_018e3fb8;
  fStack_8c = _UNK_018e3fbc;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_88 = _DAT_018e3fb0;
  fStack_84 = _UNK_018e3fb4;
  fStack_80 = _UNK_018e3fb8;
  fStack_7c = _UNK_018e3fbc;
  uStack_20 = 0;
  uStack_78 = _DAT_018e3fb0;
  fStack_74 = _UNK_018e3fb4;
  fStack_70 = _UNK_018e3fb8;
  fStack_6c = _UNK_018e3fbc;
  iStack_3c = (**(code **)(**(int **)(param_1 + 0x4c) + 0xb4))();
  *(undefined *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  if (iStack_3c != 0) {
    FUN_00927e40(&uStack_98);
  }
  iVar8 = FUN_005c3ac0(*(undefined4 *)(param_1 + 0x4c));
  if (iVar8 == 0) {
    FUN_00550130("PhysicsSenderS2 unable to find workspace.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(apfStack_38,&DAT_01c17198);
  }
  if ((*(char *)(param_1 + 0x20) != '\0') ||
     (param_2 = (int *)((uint)param_2 & 0xffffff), DAT_01d609b0 == '\0')) {
    param_2 = (int *)CONCAT13(1,param_2._0_3_);
  }
  piVar9 = (int *)FUN_006d8c20(*(undefined4 *)(param_1 + 0x4c));
  piStack_18 = piVar9;
  if (*piVar9 != piVar9[1]) {
    *(undefined4 *)(param_1 + 0x58) = 0;
    if (param_2._3_1_ == '\0') {
      iStack_2c = (piVar9[1] - *piVar9) / 0x90;
      FUN_0071edc0(iStack_2c,(int)&param_2 + 3);
      uStack_8._0_1_ = 5;
      FUN_0071eeb0(iStack_2c,(int)&param_2 + 3);
      uStack_8._0_1_ = 6;
      if ((int)puStack_1c[0xd] < DAT_01eafcc0) {
        FUN_016f3809(&DAT_01eafcc0);
        if (DAT_01eafcc0 == -1) {
          uStack_8._0_1_ = 7;
          uVar20 = FUN_0152da50(&DAT_018c5904);
          DAT_01eafcbc = (undefined4)((ulonglong)uVar20 >> 0x20);
          DAT_01eafcb8 = (undefined4)uVar20;
          uStack_8._0_1_ = 6;
          FUN_016f37bf(&DAT_01eafcc0);
        }
      }
      FUN_0152d760(DAT_01eafcb8,DAT_01eafcbc,"Items Active: %zu",(piVar9[1] - *piVar9) / 0x90);
      piVar9 = piStack_18;
      fVar19 = DAT_018e0028;
      fVar3 = DAT_018ce320;
      iVar8 = 0;
      if (0 < iStack_2c) {
        iVar11 = 0;
        puStack_1c = (undefined4 *)(aiStack_50[0] - (int)apfStack_38[0]);
        do {
          fVar1 = DAT_018f76ac;
          *(int *)((int)puStack_1c + (int)apfStack_38[0]) = iVar8;
          iVar2 = *piStack_18;
          fVar18 = *(float *)(iVar11 + 0x30 + iVar2) - fStack_70;
          fVar17 = *(float *)(iVar11 + 0x2c + iVar2) - fStack_74;
          fVar15 = *(float *)(iVar11 + 0x34 + iVar2) - fStack_6c;
          fVar15 = fVar18 * fVar18 + fVar17 * fVar17 + fVar15 * fVar15;
          if (fVar1 <= fVar15) {
            fVar1 = fVar15;
          }
          fVar15 = fVar19;
          if (fVar1 <= fVar19) {
            fVar15 = fVar1;
          }
          if (*(int *)(param_1 + 0x44) == 3) {
            fVar1 = *(float *)(iVar11 + 0x3c + iVar2);
            fVar17 = *(float *)(iVar11 + 0x38 + iVar2);
            fVar18 = *(float *)(iVar11 + 0x40 + iVar2);
            fVar16 = (float)DAT_01d6096c;
            if (NAN(fVar16) != (fVar16 == 0.0)) {
              fVar16 = fVar3;
            }
            *apfStack_38[0] =
                 ((fVar17 * fVar17 + fVar1 * fVar1 + fVar18 * fVar18) *
                 *(float *)(iVar11 + 0x50 + iVar2)) / ((fVar16 / fVar3) * fVar15);
          }
          else {
            *apfStack_38[0] = fVar15;
          }
          iVar8 = iVar8 + 1;
          iVar11 = iVar11 + 0x90;
          apfStack_38[0] = apfStack_38[0] + 1;
          piVar14 = piStack_24;
        } while (iVar8 < iStack_2c);
      }
      uVar10 = 0;
      if (*(int *)(param_1 + 0x44) == 3) {
        uVar10 = 3;
      }
      *(undefined4 *)(param_1 + 0x48) = uVar10;
      FUN_0071fde0(piStack_18,aiStack_50,apfStack_38);
      param_2 = (int *)0x0;
      if (*(uint *)(param_1 + 0x24) < (uint)((piVar9[1] - *piVar9) / 0x90)) {
        while( true ) {
          cVar5 = FUN_0071fff0(piVar9,&param_2,iStack_2c,aiStack_50,apfStack_38);
          piVar9 = param_2;
          piVar14 = piStack_24;
          if (cVar5 == '\0') break;
          puStack_1c = (undefined4 *)*param_2;
          if (*(char *)(*(int *)(param_1 + 0x4c) + 0x37f8) == '\0') {
LAB_00720c47:
            cVar5 = FUN_00a33d60(*(int *)(param_1 + 0x4c) + 0x94);
            cVar6 = FUN_006210c0(*piVar9);
            if ((cVar5 != '\0') || (cVar6 != '\0')) goto LAB_00720d57;
            cVar5 = FUN_00721040(&iStack_28,puStack_1c,0,param_3,&uStack_20,piVar9);
            if (cVar5 != '\0') {
              piVar14 = piStack_24;
              if ((((*(int *)(param_1 + 0x44) == 0) && (*(char *)(param_1 + 0x51) == '\0')) &&
                  (iStack_3c != 0)) && (DAT_01d60a00 == '\0')) {
                fVar19 = ((float)piVar9[0xc] - fStack_70) * ((float)piVar9[0xc] - fStack_70) +
                         ((float)piVar9[0xb] - fStack_74) * ((float)piVar9[0xb] - fStack_74) +
                         ((float)piVar9[0xd] - fStack_6c) * ((float)piVar9[0xd] - fStack_6c);
                fVar3 = DAT_018f76ac;
                if (DAT_018f76ac <= fVar19) {
                  fVar3 = fVar19;
                }
                fVar19 = DAT_018e0028;
                if (fVar3 <= DAT_018e0028) {
                  fVar19 = fVar3;
                }
                FUN_00721570(iStack_3c,fVar19);
                piVar14 = piStack_24;
              }
              break;
            }
          }
          else {
            cVar5 = FUN_00621090(puStack_1c);
            if (cVar5 != '\0') goto LAB_00720c47;
LAB_00720d57:
            *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
          }
          piVar14 = piStack_24;
          piVar9 = piStack_18;
          if ((uint)((piStack_18[1] - *piStack_18) / 0x90) <= *(uint *)(param_1 + 0x24)) break;
        }
      }
      *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_1 + 0x58);
      FUN_0056d320();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (aiStack_50[0] != 0) {
        uVar12 = (iStack_48 - aiStack_50[0] >> 2) * 4;
        iVar8 = aiStack_50[0];
        if (0xfff < uVar12) {
          iVar8 = *(int *)(aiStack_50[0] + -4);
          uVar12 = uVar12 + 0x23;
          if (0x1f < (aiStack_50[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar8,uVar12);
      }
    }
    else {
      puStack_1c = (undefined4 *)piVar9[1];
      puVar13 = (undefined4 *)*piVar9;
      if (puVar13 != puStack_1c) {
        do {
          param_2 = (int *)*puVar13;
          if (*(char *)(*(int *)(param_1 + 0x4c) + 0x37f8) == '\0') {
LAB_007209bb:
            cVar5 = FUN_00a33d60(*(int *)(param_1 + 0x4c) + 0x94);
            cVar6 = FUN_006210c0(param_2);
            if ((cVar5 != '\0') || (cVar6 != '\0')) goto LAB_00720a08;
            cVar5 = FUN_00721040(&iStack_28,param_2,0,param_3,&uStack_20,puVar13);
            *(int *)(param_1 + 0x58) = *(int *)(param_1 + 0x58) + 1;
            piVar14 = piStack_24;
            if (cVar5 != '\0') break;
          }
          else {
            cVar5 = FUN_00621090(param_2);
            if (cVar5 != '\0') goto LAB_007209bb;
LAB_00720a08:
            *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
          }
          puVar13 = puVar13 + 0x24;
          piVar14 = piStack_24;
        } while (puVar13 != puStack_1c);
      }
      *(int *)(param_1 + 0x5c) =
           (int)(((longlong)*(int *)(param_1 + 0x58) * (longlong)DAT_01d60928 & 0xffffffffU) / 100);
    }
    if (iStack_28 != 0) {
      FUN_0071f950(&iStack_28,param_3,uStack_20,0,1,0);
      piVar14 = piStack_24;
    }
  }
  if ((*(int *)(param_1 + 0x30) == -1) || (*(int *)(param_1 + 0x34) < *(int *)(param_1 + 0x30))) {
    uVar7 = 1;
  }
  else {
    uVar7 = 0;
  }
  iVar8 = *(int *)(param_1 + 0x24);
  *(undefined *)(param_1 + 0x20) = uVar7;
  *(int *)(param_1 + 0x28) = iVar8;
  if (DAT_01d5a088 != '\0') {
    if (*piStack_18 == piStack_18[1]) {
      *(undefined4 *)(*(int *)(param_1 + 0x4c) + 0x3acc) = 0x3f800000;
    }
    else {
      iVar11 = (piStack_18[1] - *piStack_18) / 0x90;
      *(float *)(*(int *)(param_1 + 0x4c) + 0x3acc) =
           (float)((double)iVar8 + (double)(&DAT_018c0d90)[-(iVar8 >> 0x1f)]) /
           (float)((double)iVar11 + (double)(&DAT_018c0d90)[-(iVar11 >> 0x1f)]);
    }
  }
  uVar10 = *(undefined4 *)(param_1 + 0x34);
  if (piVar14 != (int *)0x0) {
    LOCK();
    iVar8 = piVar14[1] + -1;
    piVar14[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar14)();
      LOCK();
      piVar9 = piVar14 + 2;
      iVar8 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piVar14 + 4))();
      }
    }
  }
  uVar4 = uStack_40;
  uVar21 = uStack_44;
  uStack_8 = 8;
  FUN_0152dda0(uStack_44,uStack_40,uStack_60);
  if ((cStack_11 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar21,uVar4,uStack_60);
  }
  ExceptionList = pvStack_10;
  return uVar10;
}



/* FUNCTION 10266 ; VA 0x00721040 ; FUN_00721040 */

char __thiscall
FUN_00721040(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,undefined4 param_5,
            int *param_6,int param_7)

{
  undefined4 uVar1;
  char cVar2;
  char cVar3;
  undefined4 uVar4;
  char cStack_5;
  
  cStack_5 = '\0';
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
  cVar2 = FUN_00721150(param_2);
  if (cVar2 != '\0') {
    *param_6 = *param_6 + 1;
  }
  uVar4 = (**(code **)(*(int *)*param_2 + 8))();
  uVar1 = *param_2;
  if ((param_3 != 0) && (*(char *)(param_7 + 0x55) != '\0')) {
    FUN_006b9320(uVar1,param_3);
    FUN_007205c0(uVar1,param_3,param_4,param_7);
    *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + 1;
    cVar2 = FUN_0071f950(param_2,param_5,*param_6,uVar4,0,&cStack_5);
    if (cStack_5 == '\0') {
      return cVar2;
    }
    FUN_00721150(param_2);
    (**(code **)(*(int *)*param_2 + 8))();
    if (*(char *)(param_7 + 0x55) != '\0') {
      uVar1 = *param_2;
      FUN_006b9320(uVar1,param_3);
      FUN_007205c0(uVar1,param_3,param_4,param_7);
      *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + 1;
    }
    *param_6 = *param_6 + 1;
    cVar3 = FUN_0071f950(param_2,param_5,*param_6,0,0,&cStack_5);
    if ((cVar3 != '\0') || (cVar2 != '\0')) {
      return '\x01';
    }
  }
  return '\0';
}



/* FUNCTION 10267 ; VA 0x00721150 ; FUN_00721150 */

undefined4 __thiscall FUN_00721150(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  double *pdVar6;
  int iVar7;
  float10 fVar8;
  undefined auStack_3c [4];
  undefined auStack_38 [8];
  double dStack_30;
  undefined8 uStack_28;
  undefined8 uStack_20;
  float fStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac70f;
  pvStack_10 = ExceptionList;
  if (*param_2 != 0) {
    return 0;
  }
  if (*(int *)(param_1 + 0x30) == -1) {
    ExceptionList = &pvStack_10;
    iVar7 = FUN_0061e980();
  }
  else {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_0061e980();
    iVar7 = *(int *)(param_1 + 0x30) - *(int *)(param_1 + 0x34);
    if (iVar4 < iVar7) {
      iVar7 = iVar4;
    }
  }
  *(int *)(param_1 + 0x38) = iVar7;
  fStack_18 = (float)(iVar7 / 2 + iVar7);
  puVar5 = (undefined4 *)FUN_01674e20(0x34);
  uStack_20 = (double)CONCAT44(puVar5,(undefined4)uStack_20);
  uStack_8 = 0;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    puVar5[1] = 1;
    puVar5[2] = 1;
    *puVar5 = std::_Ref_count_obj<class_RBX::Network::NetworkStream>::vftable;
    FUN_006ab2f0(fStack_18);
  }
  uStack_8 = 0xffffffff;
  *piVar2 = (int)(puVar5 + 3);
  piVar2 = (int *)piVar2[1];
  param_2[1] = (int)puVar5;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar7 = piVar2[1] + -1;
    piVar2[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  auStack_14[0] = 0x1b;
  FUN_006ad5e0(auStack_14,1);
  iVar7 = FUN_005c3ac0(*(undefined4 *)(param_1 + 0x4c));
  uStack_20 = (double)CONCAT44(iVar7,(undefined4)uStack_20);
  if (iVar7 == 0) {
    FUN_00550130("PhysicsSenderS2 unable to find workspace.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_3c,&DAT_01c17198);
  }
  iVar7 = *(int *)(iVar7 + 0x1b4);
  if (DAT_01d67c90 == '\0') {
    iVar7 = *(int *)(iVar7 + 0x4c);
    fVar8 = (float10)FUN_00bb5be0();
    fStack_18 = (float)(fVar8 * (float10)iVar7);
  }
  else {
    fStack_18 = (float)*(int *)(iVar7 + 0x4c) * *(float *)(iVar7 + 0x610);
  }
  pdVar6 = (double *)FUN_0151da60(auStack_38);
  fVar8 = (float10)FUN_00bbddf0();
  uStack_20 = (double)(fVar8 + (float10)fStack_18);
  dStack_30 = *pdVar6 + uStack_20;
  uStack_20 = (double)FUN_00626840(&dStack_30);
  uStack_28 = uStack_20;
  FUN_006a5c10(&uStack_20,&dStack_30,8);
  FUN_006ad5e0(&dStack_30,8);
  puVar5 = (undefined4 *)FUN_00626680(auStack_38,&uStack_28);
  *(undefined4 *)(param_1 + 0xa0) = *puVar5;
  *(undefined4 *)(param_1 + 0xa4) = puVar5[1];
  uVar3 = *(uint *)(param_1 + 0xa8);
  iVar7 = uVar3 + 1;
  *(int *)(param_1 + 0xa8) = iVar7;
  iVar4 = *(int *)(param_1 + 0xac) + (uint)(0xfffffffe < uVar3);
  *(int *)(param_1 + 0xac) = iVar4;
  uStack_20 = (double)CONCAT44(iVar4,iVar7);
  FUN_006a5c10(&uStack_20,&dStack_30,8);
  FUN_006ad5e0(&dStack_30,8);
  param_2 = (int *)CONCAT31(param_2._1_3_,0x85);
  FUN_006ad5e0(&param_2,1);
  *(undefined4 *)(param_1 + 0x40) = 0;
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 10268 ; VA 0x007213c0 ; FUN_007213c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_007213c0(int param_1,undefined4 *param_2,int param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  float *pfVar8;
  undefined4 *puVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined auStack_94 [36];
  undefined auStack_70 [44];
  float fStack_44;
  ulonglong uStack_3c;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  fStack_34 = (float)_DAT_018e3fb0;
  fStack_30 = (float)_UNK_018e3fb4;
  fStack_2c = (float)_UNK_018e3fb8;
  fStack_28 = (float)_UNK_018e3fbc;
  fStack_24 = (float)_DAT_018e3fb0;
  fStack_20 = (float)_UNK_018e3fb4;
  fStack_1c = (float)_UNK_018e3fb8;
  fStack_18 = (float)_UNK_018e3fbc;
  fStack_14 = (float)_DAT_018e3fb0;
  uStack_10 = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
  fStack_8 = (float)_UNK_018e3fbc;
  pfVar8 = (float *)FUN_011630b0(auStack_94);
  fStack_34 = *pfVar8;
  fStack_30 = pfVar8[1];
  fStack_2c = pfVar8[2];
  fStack_28 = pfVar8[3];
  fStack_24 = pfVar8[4];
  fStack_20 = pfVar8[5];
  fStack_1c = pfVar8[6];
  fStack_18 = pfVar8[7];
  fStack_14 = pfVar8[8];
  pfVar8 = (float *)FUN_01160de0(auStack_70);
  fVar1 = *(float *)(param_1 + 0x24);
  fVar2 = *(float *)(param_1 + 0x28);
  fVar3 = *(float *)(param_1 + 0x2c);
  fVar13 = pfVar8[1] * fVar2 + fVar1 * *pfVar8 + pfVar8[2] * fVar3;
  fVar12 = pfVar8[3] * fVar1 + pfVar8[4] * fVar2 + pfVar8[5] * fVar3;
  fStack_8 = pfVar8[6] * fVar1 + pfVar8[7] * fVar2 + pfVar8[8] * fVar3;
  uStack_10 = CONCAT44(fVar12,fVar13);
  fVar1 = *(float *)(param_3 + 0x28);
  fVar2 = *(float *)(param_3 + 0x24);
  fVar3 = *(float *)(param_3 + 0x2c);
  fVar10 = fVar1 * fStack_24;
  uStack_3c = (ulonglong)(uint)(fVar2 * fStack_34 + fVar1 * fStack_30 + fVar3 * fStack_2c + fVar13);
  fVar11 = fVar2 * fStack_28;
  fVar13 = fVar3 * fStack_20;
  fStack_44 = fVar2 * fStack_1c + fVar1 * fStack_18 + fVar3 * fStack_14 + fStack_8;
  puVar9 = (undefined4 *)FUN_01160c20(auStack_70,param_3);
  uVar4 = puVar9[1];
  uVar5 = puVar9[2];
  uVar6 = puVar9[3];
  *param_2 = *puVar9;
  param_2[1] = uVar4;
  param_2[2] = uVar5;
  param_2[3] = uVar6;
  uVar5 = puVar9[5];
  uVar6 = puVar9[6];
  uVar7 = puVar9[7];
  uVar4 = puVar9[8];
  param_2[4] = puVar9[4];
  param_2[5] = uVar5;
  param_2[6] = uVar6;
  param_2[7] = uVar7;
  param_2[8] = uVar4;
  *(ulonglong *)(param_2 + 9) = CONCAT44(fVar11 + fVar10 + fVar13 + fVar12,(int)uStack_3c);
  param_2[0xb] = fStack_44;
  return param_2;
}



/* FUNCTION 10269 ; VA 0x00721570 ; FUN_00721570 */

void FUN_00721570(int param_1,float param_2)

{
  double dVar1;
  
  if (param_1 != 0) {
    dVar1 = (double)param_2;
    FUN_017267a0();
    if ((float)dVar1 < *(float *)(param_1 + 0x188)) {
      FUN_00934730((float)dVar1);
    }
  }
  return;
}



/* FUNCTION 10270 ; VA 0x007215c0 ; FUN_007215c0 */

void __thiscall
FUN_007215c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  
  FUN_006de000(0,1);
  FUN_00ca17b0((int *)(param_1 + 0xc));
  FUN_006ad4e0(*(undefined4 *)(param_1 + 0x10),param_2);
  uVar3 = param_2;
  iVar4 = *(int *)(param_1 + 0xc);
  iVar1 = iVar4 + *(int *)(param_1 + 0x10) * 0x1c;
  for (; iVar4 != iVar1; iVar4 = iVar4 + 0x1c) {
    FUN_007216a0(uVar3,iVar4);
  }
  if (*(char *)(param_1 + 0x51) != '\0') {
    if ((char)param_5 != '\0') {
      FUN_0071f340(uVar3,param_3);
      return;
    }
    uVar2 = (uint)param_5 >> 8;
    param_5 = CONCAT31((int3)uVar2,1);
    FUN_006ad5e0(&param_5,1);
    param_5 = param_4;
    FUN_006a5c10(&param_5,&param_2,4);
    FUN_006ad5e0(&param_2,4);
  }
  FUN_00721c00(uVar3,param_3,param_6);
  return;
}



/* FUNCTION 10271 ; VA 0x007216a0 ; FUN_007216a0 */

void __thiscall FUN_007216a0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  float10 fVar4;
  double dVar5;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined auStack_4c [36];
  double dStack_28;
  double dStack_20;
  double dStack_18;
  int iStack_10;
  char acStack_c [6];
  char cStack_6;
  char cStack_5;
  
  dVar5 = (double)(*(float *)(param_3 + 0x10) * *(float *)(param_3 + 0x10) +
                   *(float *)(param_3 + 0x14) * *(float *)(param_3 + 0x14) +
                  *(float *)(param_3 + 0x18) * *(float *)(param_3 + 0x18));
  iStack_10 = param_1;
  if (NAN(dVar5) == (dVar5 == 0.0)) {
    dStack_18 = (double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & DAT_018c0da0._4_4_,
                                 SUB84(dVar5,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    dStack_28 = (double)CONCAT44((uint)((ulonglong)(dVar5 - 0.0) >> 0x20) & DAT_018c0da0._4_4_,
                                 SUB84(dVar5 - 0.0,0) & (uint)DAT_018c0da0);
    fVar4 = (float10)FUN_01160810();
    dStack_20 = (double)fVar4;
    dVar5 = DAT_018f76b0;
    if ((NAN(dStack_18) || NAN(dStack_20)) == (dStack_18 == dStack_20)) {
      dVar5 = dStack_18 * DAT_018f76b0;
    }
    cStack_5 = '\x01';
    if (dStack_28 <= dVar5) goto LAB_00721742;
  }
  else {
LAB_00721742:
    cStack_5 = '\0';
  }
  dVar5 = (double)*(float *)(param_3 + 0xc);
  if (NAN(dVar5) == (dVar5 == 0.0)) {
    dStack_28 = (double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & DAT_018c0da0._4_4_,
                                 SUB84(dVar5,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    dStack_18 = (double)CONCAT44((uint)((ulonglong)(dVar5 - 0.0) >> 0x20) & DAT_018c0da0._4_4_,
                                 SUB84(dVar5 - 0.0,0) & (uint)DAT_018c0da0);
    fVar4 = (float10)FUN_01160810();
    dStack_20 = (double)fVar4;
    dVar5 = DAT_018f76b0;
    if ((NAN(dStack_28) || NAN(dStack_20)) == (dStack_28 == dStack_20)) {
      dVar5 = dStack_28 * DAT_018f76b0;
    }
    if (dVar5 < dStack_18) {
      cStack_6 = '\x01';
      goto LAB_007217b9;
    }
  }
  cStack_6 = '\0';
LAB_007217b9:
  acStack_c[0] = cStack_6 * '\x02' + cStack_5;
  FUN_006ad5e0(acStack_c,1);
  if (cStack_5 != '\0') {
    iVar1 = (**(code **)(*param_2 + 8))();
    FUN_00723700(param_2,param_3 + 0x10);
    if ((DAT_01d5be00 != '\0') && (*(char *)(param_1 + 0x50) != '\0')) {
      FUN_006243a0();
      FUN_00620900(1);
      FUN_006243a0();
      iVar2 = (**(code **)(*param_2 + 8))();
      FUN_0062b8f0(iVar2 - iVar1);
      param_1 = iStack_10;
    }
  }
  if (cStack_6 != '\0') {
    iVar1 = (**(code **)(*param_2 + 8))();
    puVar3 = (undefined4 *)FUN_01161370(auStack_4c,param_3,*(undefined4 *)(param_3 + 0xc));
    uStack_7c = *puVar3;
    uStack_78 = puVar3[1];
    uStack_74 = puVar3[2];
    uStack_70 = puVar3[3];
    uStack_6c = puVar3[4];
    uStack_68 = puVar3[5];
    uStack_64 = puVar3[6];
    uStack_60 = puVar3[7];
    uStack_5c = puVar3[8];
    uStack_58 = *(undefined8 *)(param_3 + 0x10);
    uStack_50 = *(undefined4 *)(param_3 + 0x18);
    FUN_007234e0(param_2,&uStack_7c);
    if ((DAT_01d5be00 != '\0') && (*(char *)(param_1 + 0x50) != '\0')) {
      FUN_006243a0();
      FUN_00620900(1);
      FUN_006243a0();
      iVar2 = (**(code **)(*param_2 + 8))();
      FUN_0062b8f0(iVar2 - iVar1);
    }
  }
  return;
}



/* FUNCTION 10272 ; VA 0x007218f0 ; FUN_007218f0 */

void FUN_007218f0(int *param_1,int param_2)

{
  double dVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  double *pdVar6;
  double dVar7;
  double dVar8;
  double dVar9;
  double dStack_14;
  undefined8 uStack_c;
  
  iVar3 = (**(code **)(*param_1 + 8))();
  FUN_00723700(param_1,param_2 + 0x24);
  iVar4 = (**(code **)(*param_1 + 8))();
  iVar4 = iVar4 - iVar3;
  FUN_00723280(param_1,param_2);
  iVar5 = (**(code **)(*param_1 + 8))();
  iVar3 = (iVar5 - iVar4) - iVar3;
  if ((DAT_01d5be00 != '\0') && (*(char *)(uStack_c._4_4_ + 0x50) != '\0')) {
    iVar5 = FUN_006243a0();
    pdVar6 = (double *)FUN_016827a0(&dStack_14);
    if (*(double *)(iVar5 + 0x210) <= *pdVar6 - *(double *)(iVar5 + 0x208)) {
      *(undefined4 *)(iVar5 + 0x218) = *(undefined4 *)(iVar5 + 0x21c);
      *(undefined4 *)(iVar5 + 0x21c) = 0;
      FUN_016827a0(&uStack_c);
      *(undefined4 *)(iVar5 + 0x208) = (undefined4)uStack_c;
      *(int *)(iVar5 + 0x20c) = uStack_c._4_4_;
    }
    *(int *)(iVar5 + 0x21c) = *(int *)(iVar5 + 0x21c) + 1;
    iVar5 = FUN_006243a0();
    dStack_14 = (double)iVar4;
    uStack_c = dStack_14;
    sVar2 = FUN_017265ed(&dStack_14);
    if (sVar2 < 1) {
      dVar1 = *(double *)(iVar5 + 0x220);
      dVar7 = DAT_018c0d60 - dVar1;
      dVar8 = uStack_c;
      if (*(char *)(iVar5 + 0x240) == '\0') {
        dVar8 = *(double *)(iVar5 + 0x230) * dVar7 + uStack_c * dVar1;
      }
      *(double *)(iVar5 + 0x230) = dVar8;
      *(int *)(iVar5 + 0x228) = iVar4;
      *(undefined *)(iVar5 + 0x240) = 0;
      *(double *)(iVar5 + 0x238) =
           (uStack_c - dVar8) * (uStack_c - dVar8) * dVar1 + dVar7 * *(double *)(iVar5 + 0x238);
    }
    iVar5 = FUN_006243a0();
    pdVar6 = (double *)FUN_016827a0(&dStack_14);
    if (*(double *)(iVar5 + 0x250) <= *pdVar6 - *(double *)(iVar5 + 0x248)) {
      *(undefined4 *)(iVar5 + 600) = *(undefined4 *)(iVar5 + 0x25c);
      *(undefined4 *)(iVar5 + 0x25c) = 0;
      FUN_016827a0(&uStack_c);
      *(undefined4 *)(iVar5 + 0x248) = (undefined4)uStack_c;
      *(int *)(iVar5 + 0x24c) = uStack_c._4_4_;
    }
    *(int *)(iVar5 + 0x25c) = *(int *)(iVar5 + 0x25c) + 1;
    iVar5 = FUN_006243a0();
    dStack_14 = (double)iVar3;
    sVar2 = FUN_017265ed(&dStack_14);
    if (sVar2 < 1) {
      dVar1 = *(double *)(iVar5 + 0x260);
      dVar9 = DAT_018c0d60 - dVar1;
      dVar7 = (double)iVar3;
      dVar8 = dVar7;
      if (*(char *)(iVar5 + 0x280) == '\0') {
        dVar8 = *(double *)(iVar5 + 0x270) * dVar9 + dVar7 * dVar1;
      }
      *(int *)(iVar5 + 0x268) = iVar3;
      *(double *)(iVar5 + 0x270) = dVar8;
      *(undefined *)(iVar5 + 0x280) = 0;
      *(double *)(iVar5 + 0x278) =
           (dVar7 - dVar8) * (dVar7 - dVar8) * dVar1 + *(double *)(iVar5 + 0x278) * dVar9;
    }
    iVar5 = FUN_006243a0();
    pdVar6 = (double *)FUN_016827a0(&dStack_14);
    if (*(double *)(iVar5 + 400) <= *pdVar6 - *(double *)(iVar5 + 0x188)) {
      *(undefined4 *)(iVar5 + 0x198) = *(undefined4 *)(iVar5 + 0x19c);
      *(undefined4 *)(iVar5 + 0x19c) = 0;
      FUN_016827a0(&uStack_c);
      *(undefined4 *)(iVar5 + 0x188) = (undefined4)uStack_c;
      *(int *)(iVar5 + 0x18c) = uStack_c._4_4_;
    }
    *(int *)(iVar5 + 0x19c) = *(int *)(iVar5 + 0x19c) + 1;
    iVar5 = FUN_006243a0();
    dStack_14 = (double)(iVar3 + iVar4);
    uStack_c = dStack_14;
    sVar2 = FUN_017265ed(&dStack_14);
    if (sVar2 < 1) {
      dVar1 = *(double *)(iVar5 + 0x1a0);
      dVar7 = DAT_018c0d60 - dVar1;
      dVar8 = uStack_c;
      if (*(char *)(iVar5 + 0x1c0) == '\0') {
        dVar8 = *(double *)(iVar5 + 0x1b0) * dVar7 + uStack_c * dVar1;
      }
      *(int *)(iVar5 + 0x1a8) = iVar3 + iVar4;
      *(double *)(iVar5 + 0x1b0) = dVar8;
      *(undefined *)(iVar5 + 0x1c0) = 0;
      *(double *)(iVar5 + 0x1b8) =
           (uStack_c - dVar8) * (uStack_c - dVar8) * dVar1 + dVar7 * *(double *)(iVar5 + 0x1b8);
    }
  }
  return;
}



/* FUNCTION 10273 ; VA 0x00721c00 ; FUN_00721c00 */

void __thiscall FUN_00721c00(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_9c [72];
  undefined auStack_54 [48];
  undefined auStack_24 [24];
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (param_4 != 0) {
    cVar1 = (**(code **)(**(int **)(param_1 + 0x4c) + 0xd4))();
    if ((cVar1 != '\0') || (*(int *)(param_4 + 0x18) != 0)) {
      uVar2 = FUN_00c157b0();
      FUN_00ca1550();
      FUN_00c15e70(auStack_9c);
      FUN_0071f5c0(auStack_54,uVar2,auStack_9c);
      FUN_007218f0(param_2,auStack_54);
      FUN_00721cf0(param_2,auStack_24);
      FUN_006b9320(param_2,param_4);
      return;
    }
  }
  FUN_00ca1550();
  FUN_00c15e70(auStack_54);
  FUN_007218f0(param_2,auStack_54);
  FUN_00721cf0(param_2,auStack_24);
  uStack_c = 0xffffffff;
  uStack_8 = 0;
  FUN_006b92d0(param_2,&uStack_c);
  return;
}



/* FUNCTION 10274 ; VA 0x00721cf0 ; FUN_00721cf0 */

void __thiscall FUN_00721cf0(int param_1,int *param_2,int param_3)

{
  double dVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  double *pdVar5;
  int iVar6;
  double dVar7;
  double dVar8;
  double dVar9;
  undefined8 uStack_c;
  
  iVar3 = (**(code **)(*param_2 + 8))();
  FUN_00723c10(param_2,param_3);
  FUN_00723c10(param_2,param_3 + 0xc);
  if ((DAT_01d5be00 != '\0') && (*(char *)(param_1 + 0x50) != '\0')) {
    iVar4 = FUN_006243a0();
    pdVar5 = (double *)FUN_016827a0(&uStack_c);
    if (*(double *)(iVar4 + 0x290) <= *pdVar5 - *(double *)(iVar4 + 0x288)) {
      *(undefined4 *)(iVar4 + 0x298) = *(undefined4 *)(iVar4 + 0x29c);
      *(undefined4 *)(iVar4 + 0x29c) = 0;
      FUN_016827a0(&uStack_c);
      *(undefined4 *)(iVar4 + 0x288) = (undefined4)uStack_c;
      *(undefined4 *)(iVar4 + 0x28c) = uStack_c._4_4_;
    }
    *(int *)(iVar4 + 0x29c) = *(int *)(iVar4 + 0x29c) + 1;
    iVar4 = FUN_006243a0();
    iVar6 = (**(code **)(*param_2 + 8))();
    iVar6 = iVar6 - iVar3;
    uStack_c = (double)iVar6;
    sVar2 = FUN_017265ed(&uStack_c);
    if (sVar2 < 1) {
      dVar1 = *(double *)(iVar4 + 0x2a0);
      dVar9 = DAT_018c0d60 - dVar1;
      dVar7 = (double)iVar6;
      dVar8 = dVar7;
      if (*(char *)(iVar4 + 0x2c0) == '\0') {
        dVar8 = *(double *)(iVar4 + 0x2b0) * dVar9 + dVar7 * dVar1;
      }
      *(int *)(iVar4 + 0x2a8) = iVar6;
      *(double *)(iVar4 + 0x2b0) = dVar8;
      *(undefined *)(iVar4 + 0x2c0) = 0;
      *(double *)(iVar4 + 0x2b8) =
           (dVar7 - dVar8) * (dVar7 - dVar8) * dVar1 + *(double *)(iVar4 + 0x2b8) * dVar9;
    }
  }
  return;
}



/* FUNCTION 10275 ; VA 0x00721e30 ; FUN_00721e30 */

int __thiscall FUN_00721e30(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac736;
  pvStack_10 = ExceptionList;
  piVar6 = (int *)(param_1 + 8);
  ExceptionList = &pvStack_10;
  *piVar6 = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  piStack_18 = piVar6;
  iStack_14 = param_1;
  iVar3 = FUN_005cb2b0(0,0);
  *piVar6 = iVar3;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(int *)(param_1 + 0x14) = param_2;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  uStack_8 = 1;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0x7fffffff;
  *(undefined4 *)(param_1 + 0x3c) = 0x80000000;
  FUN_01682800(param_1 + 0x40);
  FUN_016830f0(param_1 + 0x48);
  *(undefined8 *)(param_1 + 0x50) = 0;
  *(undefined8 *)(param_1 + 0x58) = DAT_018db070;
  if (param_2 != 0) {
    iVar3 = *(int *)(param_2 + 0x34);
    if ((iVar3 != 0) && (param_2 = iVar3, *(int *)(iVar3 + 0x34) != 0)) {
      param_2 = FUN_005c8ac0();
    }
    if ((param_2 != 0) &&
       (iVar3 = *(int *)(param_2 + 0xc), iVar4 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      FUN_005789c0(&DAT_01eaef08,&LAB_006c41e0);
      uVar5 = FUN_006c4340();
      piVar6 = (int *)FUN_008aa140(uVar5);
      if (*piVar6 == 0) {
        uVar5 = FUN_00c9ab50();
        piVar7 = (int *)FUN_008a9ba0(auStack_1c,uVar5);
        iVar3 = *piVar7;
        iVar4 = piVar7[1];
        *piVar7 = 0;
        piVar7[1] = 0;
        *piVar6 = iVar3;
        piVar7 = (int *)piVar6[1];
        piVar6[1] = iVar4;
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar3 = piVar7[1] + -1;
          piVar7[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            iVar3 = piVar7[2] + -1;
            piVar7[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        piVar7 = piStack_18;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_18[1] + -1;
          piStack_18[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar3 = *piVar1 + -1;
            *piVar1 = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
      }
      iVar3 = *piVar6;
      goto LAB_00722002;
    }
  }
  iVar3 = 0;
LAB_00722002:
  puVar8 = (undefined4 *)FUN_0060dcd0(auStack_24,iVar3);
  uVar5 = *puVar8;
  uVar2 = puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  *(undefined4 *)(param_1 + 0x18) = uVar5;
  piVar6 = *(int **)(param_1 + 0x1c);
  *(undefined4 *)(param_1 + 0x1c) = uVar2;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar3 = piVar6[1] + -1;
    piVar6[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar3 = piVar6[2] + -1;
      piVar6[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar6 = piStack_20 + 2;
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10276 ; VA 0x00722090 ; FUN_00722090 */

int __thiscall FUN_00722090(int param_1,undefined4 param_2,undefined4 param_3)

{
  double dVar1;
  undefined8 uVar2;
  int iVar3;
  double dVar4;
  
  iVar3 = 0;
  dVar1 = *(double *)(param_1 + 0x58);
  dVar4 = ((double)CONCAT44(param_3,param_2) - *(double *)(param_1 + 0x48)) +
          *(double *)(param_1 + 0x50);
  if (dVar1 < dVar4) {
    dVar4 = dVar4 - dVar1;
    *(double *)(param_1 + 0x50) = dVar4;
    uVar2 = *(undefined8 *)((uint)(dVar1 < dVar4) * 8 + 0x50 + param_1);
    *(undefined4 *)(param_1 + 0x48) = param_2;
    *(undefined8 *)(param_1 + 0x50) = uVar2;
    *(undefined4 *)(param_1 + 0x4c) = param_3;
    iVar3 = (int)((double)DAT_01d5b544 * dVar1);
  }
  return iVar3;
}



/* FUNCTION 10277 ; VA 0x00722100 ; FUN_00722100 */

void __thiscall FUN_00722100(int *param_1,int param_2)

{
  undefined4 uVar1;
  double *pdVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [8];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee50;
  pvStack_10 = ExceptionList;
  if (param_2 < 10) {
    ExceptionList = &pvStack_10;
    *param_1 = *param_1 + 1;
  }
  else if (param_2 < 100) {
    ExceptionList = &pvStack_10;
    param_1[1] = param_1[1] + 1;
  }
  else if (param_2 < 1000) {
    ExceptionList = &pvStack_10;
    param_1[2] = param_1[2] + 1;
  }
  else {
    ExceptionList = &pvStack_10;
    param_1[3] = param_1[3] + 1;
  }
  if (param_2 < param_1[6]) {
    param_1[6] = param_2;
  }
  if (param_1[7] < param_2) {
    param_1[7] = param_2;
  }
  param_1[5] = param_1[5] + param_2;
  param_1[4] = param_1[4] + 1;
  pdVar2 = (double *)FUN_01682800(auStack_20);
  if ((double)DAT_01eafce4 < *pdVar2 - *(double *)(param_1 + 8)) {
    FUN_0151f6f0(0xffffffff,0,0);
    iStack_8 = 0;
    FUN_0151f9c0("LessThan10",*param_1);
    FUN_0151f9c0("10To100",param_1[1]);
    FUN_0151f9c0("100To1000",param_1[2]);
    FUN_0151f9c0("1000Plus",param_1[3]);
    FUN_0151f9c0("Count",param_1[4]);
    FUN_0151f9c0(&DAT_018f777c,param_1[6]);
    FUN_0151f9c0(&DAT_018f7780,param_1[7]);
    FUN_0151f9c0(&DAT_018f7784,param_1[5] / param_1[4]);
    FUN_0151f9c0("DatacenterId",DAT_01d7a884);
    uVar1 = DAT_01eafce8;
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("PhysicsTouchQueue",0x11);
    iStack_8._0_1_ = 1;
    FUN_01520d20(auStack_38,uVar1,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_24) {
      uVar4 = uStack_24 + 1;
      uVar3 = auStack_38[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_38[0] - 4);
        uVar4 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[6] = 0x7fffffff;
    param_1[7] = -0x80000000;
    FUN_01682800(&iStack_18);
    param_1[8] = iStack_18;
    param_1[9] = iStack_14;
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10278 ; VA 0x00722310 ; FUN_00722310 */

void __thiscall FUN_00722310(int *param_1,undefined4 param_2,double *param_3)

{
  int *piVar1;
  double dVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  double *pdVar10;
  char cVar11;
  short sVar12;
  undefined4 uVar13;
  int iVar14;
  uint uVar15;
  int iVar16;
  double *pdVar17;
  int *piVar18;
  int *piVar19;
  double dVar20;
  undefined8 uVar21;
  double dStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  double dStack_48;
  int *piStack_40;
  int *piStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined8 uStack_24;
  undefined8 uStack_1c;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac777;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_28 = param_1;
  uVar13 = FUN_01675290(DAT_01eafd18);
  param_1[1] = (int)param_3;
  *param_1 = 0;
  uStack_8 = 0;
  uStack_34 = uVar13;
  if (DAT_01d60a48 != '\0') {
    FUN_00722100(param_1[3] + *(int *)(param_1[6] + 0xa4));
  }
  piStack_30 = param_1 + 2;
  param_3 = *(double **)(param_1[6] + 0xec);
  if (param_1[4] < (int)param_3) {
    FUN_00c9d780(piStack_30);
    param_1[4] = (int)param_3;
  }
  if (param_1[3] == 0) {
    if (DAT_01d5b598 != '\0') {
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eafd28
          ) && (FUN_016f3809(&DAT_01eafd28), DAT_01eafd28 == -1)) {
        uStack_8._0_1_ = 1;
        uVar21 = FUN_0152da50(&DAT_018c5904);
        DAT_01eafd24 = (undefined4)((ulonglong)uVar21 >> 0x20);
        DAT_01eafd20 = (undefined4)uVar21;
        uStack_8 = (uint)uStack_8._1_3_ << 8;
        FUN_016f37bf(&DAT_01eafd28);
      }
      FUN_0152d740(DAT_01eafd20,DAT_01eafd24,"No Touch Data to Send");
    }
  }
  else {
    dStack_48 = DAT_018c0d60;
    piVar19 = piStack_28;
    do {
      uVar13 = uStack_34;
      if (piVar19[1] <= *piVar19) break;
      iVar16 = piVar19[1] - *piVar19;
      iVar14 = FUN_0061e980();
      if (iVar16 < iVar14) {
        iVar14 = iVar16;
      }
      uStack_24 = (double)CONCAT44(iVar14,(undefined4)uStack_24);
      iStack_38 = FUN_01674e20(0x28);
      uStack_8._0_1_ = 3;
      if (iStack_38 == 0) {
        uVar13 = 0;
      }
      else {
        uVar13 = FUN_006ab2f0((int)uStack_24._4_4_ / 2 + uStack_24._4_4_);
      }
      uStack_8._0_1_ = 0;
      piStack_40 = (int *)0x0;
      piStack_3c = (int *)0x0;
      FUN_00604a80(uVar13,param_3);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      param_3 = (double *)CONCAT31(param_3._1_3_,0x86);
      FUN_006ad5e0(&param_3,1);
      uStack_1c = (double)((ulonglong)uStack_1c & 0xffffffff);
      uStack_2c = *(undefined4 *)(piVar19[5] + 0x94);
      pdVar17 = *(double **)piVar19[2];
      if (pdVar17 != (double *)piVar19[2]) {
        do {
          cVar11 = FUN_00a33d60(&uStack_2c);
          if (cVar11 == '\0') {
            uStack_1c = (double)CONCAT44(uStack_1c._4_4_ + 1,(undefined4)uStack_1c);
            param_3 = (double *)CONCAT13(*(int *)(pdVar17 + 3) == 0,param_3._0_3_);
            FUN_006b9320(piStack_40,*(int *)(pdVar17 + 1));
            FUN_006b9320(piStack_40,*(int *)(pdVar17 + 2));
            auStack_14[0] = param_3._3_1_;
            FUN_006ad5e0(auStack_14,1);
            uVar15 = (**(code **)(*piStack_40 + 8))();
            if (uStack_24._4_4_ < uVar15) break;
          }
          pdVar17 = *(double **)pdVar17;
        } while (pdVar17 != (double *)piVar19[2]);
      }
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eafd38
          ) && (FUN_016f3809(&DAT_01eafd38), DAT_01eafd38 == -1)) {
        uStack_8._0_1_ = 5;
        uVar21 = FUN_0152da50(&DAT_018c5904);
        DAT_01eafd34 = (undefined4)((ulonglong)uVar21 >> 0x20);
        DAT_01eafd30 = (undefined4)uVar21;
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        FUN_016f37bf(&DAT_01eafd38);
      }
      FUN_0152d760(DAT_01eafd30,DAT_01eafd34,
                   "Touches Written in Touch Serializer : %u from list %zu",uStack_1c._4_4_,
                   piVar19[3]);
      piVar18 = piStack_30;
      if (pdVar17 == (double *)piVar19[2]) {
        FUN_0067b770();
      }
      else {
        pdVar10 = *(double **)piVar19[2];
        while (pdVar10 != pdVar17) {
          param_3 = *(double **)pdVar10;
          **(int **)((int)pdVar10 + 4) = (int)param_3;
          *(int *)(*(int *)pdVar10 + 4) = *(int *)((int)pdVar10 + 4);
          piVar18[1] = piVar18[1] + -1;
          FUN_0067ae90(pdVar10);
          pdVar10 = param_3;
          piVar19 = piStack_28;
        }
      }
      piVar18 = piStack_40;
      if (uStack_1c._4_4_ != 0) {
        FUN_006b9320(piStack_40,0);
        iVar14 = piVar19[5];
        param_3 = *(double **)(iVar14 + 0x6c);
        uVar13 = *(undefined4 *)(iVar14 + 0x74);
        uVar3 = *(undefined4 *)(iVar14 + 0x78);
        uVar4 = *(undefined4 *)(iVar14 + 0x7c);
        uVar5 = *(undefined4 *)(iVar14 + 0x80);
        uVar6 = *(undefined4 *)(iVar14 + 0x84);
        uVar7 = *(undefined4 *)(iVar14 + 0x88);
        uVar8 = *(undefined4 *)(iVar14 + 0x8c);
        uVar9 = *(undefined4 *)(iVar14 + 0x90);
        if (piStack_3c != (int *)0x0) {
          LOCK();
          piStack_3c[1] = piStack_3c[1] + 1;
          UNLOCK();
        }
        FUN_006afb30(piVar18,piStack_3c,param_2,3,0,uVar13,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9
                     ,0,iVar14 + 0x17d8);
        iVar14 = FUN_006243a0();
        pdVar17 = (double *)(iVar14 + 0xf8);
        if (*(char *)(iVar14 + 0x100) == '\0') {
          FUN_016827a0(&uStack_50);
          uStack_24 = (double)CONCAT44(uStack_4c,uStack_50) - *pdVar17;
          *(undefined4 *)pdVar17 = uStack_50;
          *(undefined4 *)(iVar14 + 0xfc) = uStack_4c;
          uStack_1c = uStack_24;
          sVar12 = FUN_017265ed(&uStack_1c);
          if (sVar12 < 1) {
            dVar2 = *(double *)(iVar14 + 0x108);
            dVar20 = uStack_24;
            if (*(char *)(iVar14 + 0x128) == '\0') {
              dVar20 = (dStack_48 - dVar2) * *(double *)(iVar14 + 0x118) + uStack_24 * dVar2;
            }
            *(double *)(iVar14 + 0x110) = uStack_24;
            *(double *)(iVar14 + 0x118) = dVar20;
            *(undefined *)(iVar14 + 0x128) = 0;
            *(double *)(iVar14 + 0x120) =
                 (dStack_48 - dVar2) * *(double *)(iVar14 + 0x120) +
                 dVar2 * (uStack_24 - dVar20) * (uStack_24 - dVar20);
          }
        }
        else {
          FUN_016827a0(&uStack_58);
          *(undefined4 *)pdVar17 = uStack_58;
          *(undefined4 *)(iVar14 + 0xfc) = uStack_54;
          *(undefined *)(iVar14 + 0x100) = 0;
        }
        iVar14 = FUN_006243a0();
        piVar18 = piStack_40;
        param_3 = (double *)(iVar14 + 0x138);
        iVar14 = (**(code **)(*piStack_40 + 8))();
        uStack_24 = (double)CONCAT44(iVar14,(undefined4)uStack_24);
        dStack_60 = (double)iVar14;
        uStack_1c = dStack_60;
        sVar12 = FUN_017265ed(&dStack_60);
        if (sVar12 < 1) {
          dVar2 = *param_3;
          dVar20 = uStack_1c;
          if (*(char *)(param_3 + 4) == '\0') {
            dVar20 = (dStack_48 - dVar2) * param_3[2] + uStack_1c * dVar2;
          }
          param_3[2] = dVar20;
          *(uint *)(param_3 + 1) = uStack_24._4_4_;
          *(undefined *)(param_3 + 4) = 0;
          param_3[3] = (dStack_48 - dVar2) * param_3[3] +
                       dVar2 * (uStack_1c - dVar20) * (uStack_1c - dVar20);
        }
        if (DAT_01d59fb8 != '\0') {
          iVar14 = (**(code **)(*piVar18 + 8))();
          *(int *)(piVar19[5] + 0x18dc) = *(int *)(piVar19[5] + 0x18dc) + iVar14;
          piVar18 = piStack_40;
        }
        iVar14 = (**(code **)(*piVar18 + 8))();
        *piVar19 = *piVar19 + iVar14;
      }
      if (piVar19[3] == 0) {
        FUN_00c9e320();
      }
      piVar18 = piStack_3c;
      uStack_8 = uStack_8 & 0xffffff00;
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar14 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          piVar1 = piVar18 + 2;
          iVar14 = *piVar1 + -1;
          *piVar1 = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piVar18 + 4))();
          }
        }
      }
      uVar13 = uStack_34;
    } while (piVar19[3] != 0);
  }
  uStack_8 = 6;
  FUN_01675290(uVar13);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10279 ; VA 0x00722890 ; FUN_00722890 */

void FUN_00722890(undefined4 param_1)

{
  Sleep(param_1);
  return;
}



/* FUNCTION 10280 ; VA 0x007228a0 ; FUN_007228a0 */

undefined4 * __fastcall FUN_007228a0(undefined4 *param_1)

{
  FUN_005f7140();
  *param_1 = 0xffffffff;
  param_1[0xb] = 0xffffffff;
  return param_1;
}



/* FUNCTION 10281 ; VA 0x007228c0 ; FUN_007228c0 */

void __fastcall FUN_007228c0(int *param_1)

{
  if (*param_1 != -1) {
    Ordinal_3(*param_1);
  }
  if (param_1[0xb] != -1) {
    CloseHandle(param_1[0xb]);
    param_1[0xb] = -1;
  }
  *param_1 = -1;
  return;
}



/* FUNCTION 10282 ; VA 0x007228f0 ; FUN_007228f0 */

undefined4 __fastcall FUN_007228f0(undefined4 param_1)

{
  InitializeCriticalSection(param_1);
  return param_1;
}



/* FUNCTION 10283 ; VA 0x00722900 ; FUN_00722900 */

void __fastcall FUN_00722900(undefined4 param_1)

{
  DeleteCriticalSection(param_1);
  return;
}



/* FUNCTION 10284 ; VA 0x00722910 ; FUN_00722910 */

void __fastcall FUN_00722910(undefined4 param_1)

{
  EnterCriticalSection(param_1);
  return;
}



/* FUNCTION 10285 ; VA 0x00722920 ; FUN_00722920 */

void __fastcall FUN_00722920(undefined4 param_1)

{
  LeaveCriticalSection(param_1);
  return;
}



/* FUNCTION 10286 ; VA 0x00722930 ; FUN_00722930 */

undefined4 FUN_00722930(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  iVar1 = FUN_0172775e(0,2000000,param_1,param_2,0,&uStack_8);
  SetThreadPriority(iVar1,param_3);
  if (iVar1 == 0) {
    return 1;
  }
  CloseHandle(iVar1);
  return 0;
}



/* FUNCTION 10287 ; VA 0x00722980 ; FUN_00722980 */

undefined4 * __fastcall FUN_00722980(undefined4 *param_1)

{
  *param_1 = 0xffffffff;
  return param_1;
}



/* FUNCTION 10288 ; VA 0x00722990 ; FUN_00722990 */

void __fastcall FUN_00722990(int *param_1)

{
  if (*param_1 != -1) {
    CloseHandle(*param_1);
    *param_1 = -1;
  }
  return;
}



/* FUNCTION 10289 ; VA 0x007229b0 ; FUN_007229b0 */

void __fastcall FUN_007229b0(undefined4 *param_1)

{
  undefined4 uVar1;
  
  uVar1 = CreateEventA(0,0,0,0);
  *param_1 = uVar1;
  return;
}



/* FUNCTION 10290 ; VA 0x007229d0 ; FUN_007229d0 */

void __fastcall FUN_007229d0(undefined4 *param_1)

{
  SetEvent(*param_1);
  return;
}



/* FUNCTION 10291 ; VA 0x007229e0 ; FUN_007229e0 */

void __thiscall FUN_007229e0(undefined4 *param_1,undefined4 param_2)

{
  WaitForSingleObject(*param_1,param_2);
  return;
}



/* FUNCTION 10292 ; VA 0x00722a00 ; FUN_00722a00 */

undefined4 * __fastcall FUN_00722a00(undefined4 *param_1)

{
  LOCK();
  *param_1 = 0;
  UNLOCK();
  return param_1;
}



/* FUNCTION 10293 ; VA 0x00722a10 ; FUN_00722a10 */

int __fastcall FUN_00722a10(int *param_1)

{
  int iVar1;
  
  LOCK();
  iVar1 = *param_1;
  *param_1 = *param_1 + -1;
  UNLOCK();
  return iVar1 + -1;
}



/* FUNCTION 10294 ; VA 0x00722a20 ; FUN_00722a20 */

int __fastcall FUN_00722a20(int *param_1)

{
  int iVar1;
  
  LOCK();
  iVar1 = *param_1;
  *param_1 = *param_1 + 1;
  UNLOCK();
  return iVar1 + 1;
}



/* FUNCTION 10295 ; VA 0x00722a30 ; FUN_00722a30 */

undefined4 * __thiscall FUN_00722a30(undefined4 *param_1,undefined4 param_2,undefined2 param_3)

{
  param_1[1] = param_2;
  *(undefined2 *)(param_1 + 2) = param_3;
  *param_1 = RBX::Network::Rupp::Ipv4Tlv::vftable;
  return param_1;
}



/* FUNCTION 10296 ; VA 0x00722a50 ; FUN_00722a50 */

undefined4 * __thiscall
FUN_00722a50(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined2 param_6)

{
  *(undefined2 *)(param_1 + 5) = param_6;
  *param_1 = RBX::Network::Rupp::Ipv6Tlv::vftable;
  param_1[1] = param_2;
  param_1[2] = param_3;
  param_1[3] = param_4;
  param_1[4] = param_5;
  return param_1;
}



/* FUNCTION 10297 ; VA 0x00722a70 ; FUN_00722a70 */

undefined4 __thiscall FUN_00722a70(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 10298 ; VA 0x00722a90 ; FUN_00722a90 */

undefined4 __fastcall FUN_00722a90(int param_1)

{
  char cVar1;
  
  cVar1 = FUN_006a58d0(param_1 + 4,4);
  if (cVar1 != '\0') {
    cVar1 = FUN_005fda50();
    if (cVar1 == '\0') {
      cVar1 = FUN_006a5ae0(&stack0x00000004,0x10,1);
      if (cVar1 != '\0') {
        FUN_006a5c10(&stack0x00000004,param_1 + 8,2);
        return 0;
      }
    }
    else {
      cVar1 = FUN_006a5ae0(param_1 + 8,0x10,1);
      if (cVar1 != '\0') {
        return 0;
      }
    }
  }
  return 1;
}



/* FUNCTION 10299 ; VA 0x00722b00 ; FUN_00722b00 */

undefined4 __fastcall FUN_00722b00(int param_1)

{
  char cVar1;
  
  cVar1 = FUN_006a58d0(param_1 + 4,0x10);
  if (cVar1 != '\0') {
    cVar1 = FUN_005fda50();
    if (cVar1 == '\0') {
      cVar1 = FUN_006a5ae0(&stack0x00000004,0x10,1);
      if (cVar1 != '\0') {
        FUN_006a5c10(&stack0x00000004,param_1 + 0x14,2);
        return 0;
      }
    }
    else {
      cVar1 = FUN_006a5ae0(param_1 + 0x14,0x10,1);
      if (cVar1 != '\0') {
        return 0;
      }
    }
  }
  return 1;
}



/* FUNCTION 10300 ; VA 0x00722b70 ; FUN_00722b70 */

undefined FUN_00722b70(void)

{
  return 2;
}



/* FUNCTION 10301 ; VA 0x00722b80 ; FUN_00722b80 */

void __fastcall FUN_00722b80(int param_1)

{
  char cVar1;
  
  FUN_006a5e80(param_1 + 4,4);
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(param_1 + 8,&stack0x00000004,2);
    FUN_006a6060(&stack0x00000004,0x10,1);
    return;
  }
  FUN_006a6060(param_1 + 8,0x10,1);
  return;
}



/* FUNCTION 10302 ; VA 0x00722be0 ; FUN_00722be0 */

void __fastcall FUN_00722be0(int param_1)

{
  char cVar1;
  
  FUN_006a5e80(param_1 + 4,0x10);
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(param_1 + 0x14,&stack0x00000004,2);
    FUN_006a6060(&stack0x00000004,0x10,1);
    return;
  }
  FUN_006a6060(param_1 + 0x14,0x10,1);
  return;
}



/* FUNCTION 10303 ; VA 0x00722c40 ; FUN_00722c40 */

void FUN_00722c40(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  double dVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  ushort auStack_30 [2];
  uint uStack_2c;
  float afStack_28 [4];
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  
  FUN_00607c10(param_1,auStack_30);
  FUN_006ab0b0(param_1,&uStack_2c);
  uVar1 = uStack_2c >> 0x1e;
  fVar5 = ((float)((int)((uint)auStack_30[0] << 0x11) >> 0x11) / DAT_018ce328) * DAT_01eafd9c;
  fVar4 = ((float)((int)(uStack_2c * 4) >> 0x11) / DAT_018ce328) * DAT_01eafd9c;
  afStack_28[*(int *)(&DAT_018f781c + uVar1 * 0xc)] = fVar5;
  fVar3 = ((float)((int)(uStack_2c << 0x11) >> 0x11) / DAT_018ce328) * DAT_01eafd9c;
  afStack_28[*(int *)(&DAT_018f7820 + uVar1 * 0xc)] = fVar4;
  afStack_28[*(int *)(&DAT_018f7824 + uVar1 * 0xc)] = fVar3;
  fVar3 = DAT_018ce2f8 - (fVar4 * fVar4 + fVar5 * fVar5 + fVar3 * fVar3);
  if (fVar3 <= DAT_018ce2f0) {
    fVar3 = DAT_018ce2f0;
  }
  dVar2 = (double)fVar3;
  FUN_017267a0();
  afStack_28[uVar1] = (float)dVar2;
  dVar2 = (double)(afStack_28[1] * afStack_28[1] + afStack_28[0] * afStack_28[0] +
                   afStack_28[2] * afStack_28[2] + afStack_28[3] * afStack_28[3]);
  FUN_017267a0();
  fStack_c = DAT_018ce2f8 / (float)dVar2;
  fStack_18 = afStack_28[0] * fStack_c;
  fStack_14 = afStack_28[1] * fStack_c;
  fStack_10 = afStack_28[2] * fStack_c;
  fStack_c = afStack_28[3] * fStack_c;
  FUN_00cf7180(param_2);
  return;
}



/* FUNCTION 10304 ; VA 0x00722da0 ; FUN_00722da0 */

void FUN_00722da0(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  double dVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  uint uStack_1c;
  float afStack_18 [5];
  
  FUN_006ab0b0(param_1,&uStack_1c);
  uVar1 = uStack_1c >> 0x1e;
  fVar5 = ((float)((int)(uStack_1c * 4) >> 0x16) / DAT_018f7850) * DAT_01eafd9c;
  fVar4 = ((float)((int)(uStack_1c << 0xc) >> 0x16) / DAT_018f7850) * DAT_01eafd9c;
  afStack_18[*(int *)(&DAT_018f781c + uVar1 * 0xc)] = fVar5;
  fVar3 = ((float)((int)(uStack_1c << 0x16) >> 0x16) / DAT_018f7850) * DAT_01eafd9c;
  afStack_18[*(int *)(&DAT_018f7820 + uVar1 * 0xc)] = fVar4;
  afStack_18[*(int *)(&DAT_018f7824 + uVar1 * 0xc)] = fVar3;
  fVar3 = DAT_018ce2f8 - (fVar4 * fVar4 + fVar5 * fVar5 + fVar3 * fVar3);
  if (fVar3 <= DAT_018ce2f0) {
    fVar3 = DAT_018ce2f0;
  }
  dVar2 = (double)fVar3;
  FUN_017267a0();
  afStack_18[uVar1] = (float)dVar2;
  FUN_00cf7180(param_2);
  return;
}



/* FUNCTION 10305 ; VA 0x00722ea0 ; FUN_00722ea0 */

void FUN_00722ea0(undefined4 param_1,float *param_2)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  float10 fVar6;
  float fVar7;
  float fVar8;
  undefined4 uVar9;
  uint *puVar10;
  undefined auStack_68 [36];
  undefined auStack_44 [24];
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8af8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_006abe60(&bStack_11,1);
  if (cVar1 != '\0') {
    uVar5 = bStack_11 >> 2 & 1;
    uStack_24 = (uint)(bStack_11 >> 3);
    uVar3 = bStack_11 >> 1 & 1;
    uVar2 = bStack_11 & 1;
    uStack_20 = uVar5;
    uStack_1c = uVar3;
    if (uStack_24 < 5) {
      FUN_006ab0b0();
      uVar3 = uStack_20 << 10;
      uVar4 = uStack_18 >> 10 & 0x3ff | (int)(uStack_1c << 0x1f) >> 0x15;
      uVar2 = (int)(uVar2 << 0x1f) >> 0x15 | uStack_18 & 0x3ff;
      fVar6 = (float10)FUN_017277f1(DAT_018c0d60,uStack_24);
      fVar8 = DAT_018f7854;
      fVar7 = (float)fVar6;
      *param_2 = ((float)((int)((uStack_18 >> 0x14 | uVar3) << 0x15) >> 0x15) / DAT_018f7854) *
                 fVar7;
    }
    else if (uStack_24 < 0xb) {
      puVar10 = &uStack_18;
      uVar9 = param_1;
      FUN_00607c10();
      FUN_00607c10(param_1,&uStack_1c,uVar9,puVar10);
      FUN_00607c10(param_1,&uStack_20);
      uVar4 = (int)((uVar3 << 0x10 | uStack_1c & 0xffff) << 0xf) >> 0xf;
      uVar2 = (int)((uVar2 << 0x10 | uStack_20 & 0xffff) << 0xf) >> 0xf;
      fVar6 = (float10)FUN_017277f1(DAT_018c0d60,uStack_24);
      fVar8 = DAT_018da9a0;
      fVar7 = (float)fVar6;
      *param_2 = ((float)((int)((uVar5 << 0x10 | uStack_18 & 0xffff) << 0xf) >> 0xf) / DAT_018da9a0)
                 * fVar7;
    }
    else {
      puVar10 = &uStack_28;
      uVar9 = param_1;
      FUN_006ab0b0();
      FUN_006ab0b0(param_1,&uStack_2c,uVar9,puVar10);
      uVar3 = uStack_20 << 0x15;
      uVar2 = (int)(uVar2 << 0x1f) >> 10 | uStack_2c & 0x1fffff;
      uVar4 = (int)(((uStack_28 & 0x7ff | uStack_1c << 0xb) << 10 | uStack_2c >> 0x15) << 10) >> 10;
      fVar6 = (float10)FUN_017277f1(DAT_018c0d60,uStack_24);
      fVar8 = DAT_018f785c;
      fVar7 = (float)fVar6;
      *param_2 = ((float)((int)((uStack_28 >> 0xb | uVar3) << 10) >> 10) / DAT_018f785c) * fVar7;
    }
    param_2[1] = ((float)(int)uVar4 / fVar8) * fVar7;
    param_2[2] = ((float)(int)uVar2 / fVar8) * fVar7;
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0054eff0("readFast past end for uint8_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_44);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_68,&DAT_01c27108);
}



/* FUNCTION 10306 ; VA 0x00723140 ; FUN_00723140 */

void FUN_00723140(undefined4 param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  char cVar3;
  float10 fVar4;
  undefined auStack_54 [36];
  undefined auStack_30 [24];
  int iStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_006abe60(&bStack_11,1);
  if (cVar3 == '\0') {
    FUN_0054eff0("readFast past end for uint8_t");
    uStack_8 = 0;
    FUN_005f8ef0(auStack_30);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_54,&DAT_01c27108);
  }
  if (bStack_11 == 0) {
    param_2[2] = 0.0;
    param_2[1] = 0.0;
    *param_2 = 0.0;
    ExceptionList = pvStack_10;
    return;
  }
  FUN_006ab0b0();
  fVar4 = (float10)FUN_017277f1(DAT_018c0d60,(bStack_11 >> 4) - 1);
  fVar2 = DAT_018f7858;
  fVar1 = (float)fVar4;
  *param_2 = ((float)(iStack_18 >> 0x14) / DAT_018f7858) * fVar1;
  param_2[1] = ((float)((iStack_18 << 0xc) >> 0x14) / fVar2) * fVar1;
  param_2[2] = ((float)(int)((iStack_18 << 0x18) >> 0x14 | bStack_11 & 0xf) / fVar2) * fVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10307 ; VA 0x00723280 ; FUN_00723280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00723280(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  double dVar3;
  uint uVar4;
  uint uVar5;
  float fVar6;
  undefined auStack_40 [4];
  float fStack_3c;
  uint auStack_38 [2];
  float fStack_30;
  uint uStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float afStack_18 [5];
  
  FUN_00cf6ea0(param_2);
  dVar3 = (double)(fStack_24 * fStack_24 + fStack_28 * fStack_28 + fStack_20 * fStack_20 +
                  fStack_1c * fStack_1c);
  FUN_017267a0();
  fVar6 = DAT_018ce2f8 / (float)dVar3;
  fStack_24 = fVar6 * fStack_24;
  fStack_28 = fVar6 * fStack_28;
  fStack_20 = fVar6 * fStack_20;
  uVar4 = (uint)DAT_018c0da0;
  uVar5 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fStack_1c = fVar6 * fStack_1c;
  uVar2 = (uint)((float)(double)CONCAT44((uint)((ulonglong)(double)fStack_28 >> 0x20) & uVar5,
                                         SUB84((double)fStack_28,0) & uVar4) <
                (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_24 >> 0x20) & uVar5,
                                        SUB84((double)fStack_24,0) & uVar4));
  afStack_18[0] = fStack_28;
  afStack_18[1] = fStack_24;
  afStack_18[2] = fStack_20;
  afStack_18[3] = fStack_1c;
  if ((float)(double)CONCAT44((uint)((ulonglong)(double)afStack_18[uVar2] >> 0x20) & uVar5,
                              SUB84((double)afStack_18[uVar2],0) & uVar4) <
      (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_20 >> 0x20) & uVar5,
                              SUB84((double)fStack_20,0) & uVar4)) {
    uVar2 = 2;
  }
  if ((float)(double)CONCAT44((uint)((ulonglong)(double)afStack_18[uVar2] >> 0x20) & uVar5,
                              SUB84((double)afStack_18[uVar2],0) & uVar4) <
      (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_1c >> 0x20) & uVar5,
                              SUB84((double)fStack_1c,0) & uVar4)) {
    uVar2 = 3;
  }
  if (afStack_18[uVar2] <= 0.0 && afStack_18[uVar2] != 0.0) {
    afStack_18[0] = (float)((uint)fStack_28 ^ DAT_018c4ea0);
    afStack_18[1] = (float)((uint)fStack_24 ^ _UNK_018c4ea4);
    afStack_18[2] = (float)((uint)fStack_20 ^ _UNK_018c4ea8);
    afStack_18[3] = (float)((uint)fStack_1c ^ _UNK_018c4eac);
  }
  iVar1 = *(int *)(&DAT_018f7824 + uVar2 * 0xc);
  fStack_30 = DAT_01eafd9c;
  fStack_3c = DAT_018ce2f4;
  fVar6 = DAT_018f7860;
  if (0.0 <= afStack_18[*(int *)(&DAT_018f781c + uVar2 * 0xc)]) {
    fVar6 = DAT_018ce2f4;
  }
  auStack_38[0] =
       (int)((afStack_18[*(int *)(&DAT_018f781c + uVar2 * 0xc)] / DAT_01eafd9c) * DAT_018ce328 +
            fVar6) & 0x7fff;
  fVar6 = DAT_018ce2f4;
  if (afStack_18[*(int *)(&DAT_018f7820 + uVar2 * 0xc)] < 0.0) {
    fVar6 = DAT_018f7860;
  }
  uStack_2c = (int)((afStack_18[*(int *)(&DAT_018f7820 + uVar2 * 0xc)] / DAT_01eafd9c) *
                    DAT_018ce328 + fVar6) & 0x7fff;
  if (afStack_18[iVar1] < 0.0) {
    fStack_3c = DAT_018f7860;
  }
  FUN_006a5c10(auStack_38,auStack_40,2);
  FUN_006ad5e0(auStack_40,2);
  uStack_2c = (int)((afStack_18[iVar1] / fStack_30) * DAT_018ce328 + fStack_3c) & 0x7fffU |
              (uVar2 << 0xf | uStack_2c) << 0xf;
  FUN_006a5c10(&uStack_2c,&fStack_30,4);
  FUN_006ad5e0(&fStack_30,4);
  return;
}



/* FUNCTION 10308 ; VA 0x007234e0 ; FUN_007234e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007234e0(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  double dVar2;
  float fVar3;
  uint uVar4;
  uint uVar5;
  float fVar6;
  float fVar7;
  uint uStack_30;
  undefined auStack_2c [4];
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float afStack_18 [5];
  
  FUN_00cf6ea0(param_2);
  dVar2 = (double)(fStack_24 * fStack_24 + fStack_28 * fStack_28 + fStack_20 * fStack_20 +
                  fStack_1c * fStack_1c);
  FUN_017267a0();
  fVar6 = DAT_018ce2f8 / (float)dVar2;
  fStack_24 = fVar6 * fStack_24;
  fStack_28 = fVar6 * fStack_28;
  fStack_20 = fVar6 * fStack_20;
  uVar4 = (uint)DAT_018c0da0;
  uVar5 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fStack_1c = fVar6 * fStack_1c;
  uVar1 = (uint)((float)(double)CONCAT44((uint)((ulonglong)(double)fStack_28 >> 0x20) & uVar5,
                                         SUB84((double)fStack_28,0) & uVar4) <
                (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_24 >> 0x20) & uVar5,
                                        SUB84((double)fStack_24,0) & uVar4));
  afStack_18[0] = fStack_28;
  afStack_18[1] = fStack_24;
  afStack_18[2] = fStack_20;
  afStack_18[3] = fStack_1c;
  if ((float)(double)CONCAT44((uint)((ulonglong)(double)afStack_18[uVar1] >> 0x20) & uVar5,
                              SUB84((double)afStack_18[uVar1],0) & uVar4) <
      (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_20 >> 0x20) & uVar5,
                              SUB84((double)fStack_20,0) & uVar4)) {
    uVar1 = 2;
  }
  if ((float)(double)CONCAT44((uint)((ulonglong)(double)afStack_18[uVar1] >> 0x20) & uVar5,
                              SUB84((double)afStack_18[uVar1],0) & uVar4) <
      (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_1c >> 0x20) & uVar5,
                              SUB84((double)fStack_1c,0) & uVar4)) {
    uVar1 = 3;
  }
  if (afStack_18[uVar1] <= 0.0 && afStack_18[uVar1] != 0.0) {
    afStack_18[0] = (float)((uint)fStack_28 ^ DAT_018c4ea0);
    afStack_18[1] = (float)((uint)fStack_24 ^ _UNK_018c4ea4);
    afStack_18[2] = (float)((uint)fStack_20 ^ _UNK_018c4ea8);
    afStack_18[3] = (float)((uint)fStack_1c ^ _UNK_018c4eac);
  }
  fVar6 = DAT_018f7860;
  if (0.0 <= afStack_18[*(int *)(&DAT_018f781c + uVar1 * 0xc)]) {
    fVar6 = DAT_018ce2f4;
  }
  fVar7 = DAT_018f7860;
  if (0.0 <= afStack_18[*(int *)(&DAT_018f7820 + uVar1 * 0xc)]) {
    fVar7 = DAT_018ce2f4;
  }
  fVar3 = DAT_018ce2f4;
  if (afStack_18[*(int *)(&DAT_018f7824 + uVar1 * 0xc)] < 0.0) {
    fVar3 = DAT_018f7860;
  }
  uStack_30 = (int)((afStack_18[*(int *)(&DAT_018f7824 + uVar1 * 0xc)] / DAT_01eafd9c) *
                    DAT_018f7850 + fVar3) & 0x3ffU |
              ((uVar1 << 10 |
               (int)((afStack_18[*(int *)(&DAT_018f781c + uVar1 * 0xc)] / DAT_01eafd9c) *
                     DAT_018f7850 + fVar6) & 0x3ffU) << 10 |
              (int)((afStack_18[*(int *)(&DAT_018f7820 + uVar1 * 0xc)] / DAT_01eafd9c) *
                    DAT_018f7850 + fVar7) & 0x3ffU) << 10;
  FUN_006a5c10(&uStack_30,auStack_2c,4);
  FUN_006ad5e0(auStack_2c,4);
  return;
}



/* FUNCTION 10309 ; VA 0x00723700 ; FUN_00723700 */

void FUN_00723700(undefined4 param_1,float *param_2)

{
  float *pfVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  float10 fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  uint uStack_10;
  uint uStack_c;
  int iStack_8;
  
  pfVar1 = param_2;
  uVar3 = (uint)DAT_018c0da0;
  uVar4 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fVar9 = (float)(double)CONCAT44((uint)((ulonglong)(double)*param_2 >> 0x20) & uVar4,
                                  SUB84((double)*param_2,0) & uVar3);
  fVar8 = (float)(double)CONCAT44((uint)((ulonglong)(double)param_2[1] >> 0x20) & uVar4,
                                  SUB84((double)param_2[1],0) & uVar3);
  fVar6 = (float)(double)CONCAT44((uint)((ulonglong)(double)param_2[2] >> 0x20) & uVar4,
                                  SUB84((double)param_2[2],0) & uVar3);
  if (fVar8 <= fVar9) {
    fVar8 = fVar9;
  }
  if (fVar6 <= fVar8) {
    fVar6 = fVar8;
  }
  iStack_8 = 0;
  FUN_0171de34((double)fVar6,&iStack_8);
  if (iStack_8 < 1) {
    iStack_8 = 0;
  }
  else if (0x1f < iStack_8) {
    iStack_8 = 0x1f;
  }
  fVar5 = (float10)FUN_017277f1(DAT_018c0d60,iStack_8);
  fVar6 = *pfVar1;
  fVar8 = (float)fVar5;
  cVar2 = (char)iStack_8;
  param_2._1_3_ = (undefined3)((uint)fVar8 >> 8);
  if (iStack_8 < 5) {
    fVar9 = DAT_018f7860;
    if (0.0 <= fVar6) {
      fVar9 = DAT_018ce2f4;
    }
    fVar6 = fVar6 / fVar8;
    fVar7 = DAT_018f7864;
    if ((DAT_018f7864 < fVar6) && (fVar7 = fVar6, DAT_018ce2f8 <= fVar6)) {
      fVar7 = DAT_018ce2f8;
    }
    uStack_c = (int)(fVar7 * DAT_018f7854 + fVar9) & 0x7ff;
    fVar6 = DAT_018f7860;
    if (0.0 <= pfVar1[1]) {
      fVar6 = DAT_018ce2f4;
    }
    fVar7 = pfVar1[1] / fVar8;
    fVar9 = DAT_018f7864;
    if ((DAT_018f7864 < fVar7) && (fVar9 = fVar7, DAT_018ce2f8 <= fVar7)) {
      fVar9 = DAT_018ce2f8;
    }
    uStack_10 = (int)(fVar9 * DAT_018f7854 + fVar6) & 0x7ff;
    fVar6 = DAT_018ce2f4;
    if (pfVar1[2] < 0.0) {
      fVar6 = DAT_018f7860;
    }
    fVar8 = pfVar1[2] / fVar8;
    fVar9 = DAT_018f7864;
    if ((fVar8 <= DAT_018f7864) || (fVar7 = DAT_018ce2f8, fVar9 = fVar8, fVar8 < DAT_018ce2f8)) {
      fVar7 = fVar9;
    }
    uVar3 = (uint)(fVar7 * DAT_018f7854 + fVar6);
    param_2 = (float *)CONCAT31(param_2._1_3_,
                                (((byte)(uStack_c >> 10) | cVar2 * '\x02') * '\x02' |
                                (byte)(uStack_10 >> 10)) * '\x02' | (byte)((uVar3 & 0x7ff) >> 10));
    FUN_006ad5e0();
    param_2 = (float *)(((uStack_c & 0x3ff) << 10 | uStack_10 & 0x3ff) << 10 | uVar3 & 0x3ff);
    FUN_006a5c10(&param_2,&uStack_10,4);
    FUN_006ad5e0();
    return;
  }
  if (iStack_8 < 0xb) {
    fVar9 = DAT_018f7860;
    if (0.0 <= fVar6) {
      fVar9 = DAT_018ce2f4;
    }
    fVar6 = fVar6 / fVar8;
    fVar7 = DAT_018f7864;
    if ((DAT_018f7864 < fVar6) && (fVar7 = fVar6, DAT_018ce2f8 <= fVar6)) {
      fVar7 = DAT_018ce2f8;
    }
    uStack_10 = (int)(fVar7 * DAT_018da9a0 + fVar9) & 0x1ffff;
    fVar6 = DAT_018f7860;
    if (0.0 <= pfVar1[1]) {
      fVar6 = DAT_018ce2f4;
    }
    fVar7 = pfVar1[1] / fVar8;
    fVar9 = DAT_018f7864;
    if ((DAT_018f7864 < fVar7) && (fVar9 = fVar7, DAT_018ce2f8 <= fVar7)) {
      fVar9 = DAT_018ce2f8;
    }
    uStack_c = (int)(fVar9 * DAT_018da9a0 + fVar6) & 0x1ffff;
    fVar6 = DAT_018ce2f4;
    if (pfVar1[2] < 0.0) {
      fVar6 = DAT_018f7860;
    }
    fVar8 = pfVar1[2] / fVar8;
    fVar9 = DAT_018f7864;
    if ((fVar8 <= DAT_018f7864) || (fVar7 = DAT_018ce2f8, fVar9 = fVar8, fVar8 < DAT_018ce2f8)) {
      fVar7 = fVar9;
    }
    uVar3 = (uint)(fVar7 * DAT_018da9a0 + fVar6);
    param_2 = (float *)CONCAT31(param_2._1_3_,
                                (((byte)(uStack_10 >> 0x10) | cVar2 * '\x02') * '\x02' |
                                (byte)(uStack_c >> 0x10)) * '\x02' | (byte)(uVar3 >> 0x10) & 1);
    FUN_006ad5e0();
    uStack_10 = uStack_10 & 0xffff;
    FUN_006a5c10(&uStack_10,&param_2,2);
    FUN_006ad5e0();
    uStack_10 = uStack_c & 0xffff;
    FUN_006a5c10(&uStack_10,&param_2,2);
    FUN_006ad5e0();
    uStack_10 = uVar3 & 0xffff;
    FUN_006a5c10(&uStack_10,&param_2,2);
    FUN_006ad5e0();
    return;
  }
  fVar9 = DAT_018f7860;
  if (0.0 <= fVar6) {
    fVar9 = DAT_018ce2f4;
  }
  fVar6 = fVar6 / fVar8;
  fVar7 = DAT_018f7864;
  if ((DAT_018f7864 < fVar6) && (fVar7 = fVar6, DAT_018ce2f8 <= fVar6)) {
    fVar7 = DAT_018ce2f8;
  }
  uStack_10 = (int)(fVar7 * DAT_018f785c + fVar9) & 0x3fffff;
  fVar6 = DAT_018f7860;
  if (0.0 <= pfVar1[1]) {
    fVar6 = DAT_018ce2f4;
  }
  fVar7 = pfVar1[1] / fVar8;
  fVar9 = DAT_018f7864;
  if ((DAT_018f7864 < fVar7) && (fVar9 = fVar7, DAT_018ce2f8 <= fVar7)) {
    fVar9 = DAT_018ce2f8;
  }
  uVar3 = (uint)(fVar9 * DAT_018f785c + fVar6);
  fVar6 = DAT_018ce2f4;
  if (pfVar1[2] < 0.0) {
    fVar6 = DAT_018f7860;
  }
  fVar8 = pfVar1[2] / fVar8;
  fVar9 = DAT_018f7864;
  if ((fVar8 <= DAT_018f7864) || (fVar7 = DAT_018ce2f8, fVar9 = fVar8, fVar8 < DAT_018ce2f8)) {
    fVar7 = fVar9;
  }
  uStack_c = uVar3 & 0x1fffff;
  uVar4 = (uint)(fVar7 * DAT_018f785c + fVar6);
  param_2 = (float *)CONCAT31(param_2._1_3_,
                              (((byte)(uStack_10 >> 0x15) | cVar2 * '\x02') * '\x02' |
                              (byte)((uVar3 & 0x3fffff) >> 0x15)) * '\x02' |
                              (byte)((uVar4 & 0x3fffff) >> 0x15));
  FUN_006ad5e0();
  param_2 = (float *)(uStack_c >> 10 | uStack_10 << 0xb);
  FUN_006a5c10(&param_2,&uStack_10,4);
  FUN_006ad5e0();
  param_2 = (float *)((uStack_c & 0x3ff) << 0x15 | uVar4 & 0x1fffff);
  FUN_006a5c10(&param_2,&uStack_10,4);
  FUN_006ad5e0();
  return;
}



/* FUNCTION 10310 ; VA 0x00723c10 ; FUN_00723c10 */

void FUN_00723c10(undefined4 param_1,float *param_2)

{
  float *pfVar1;
  float10 fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  uint uVar6;
  float fVar7;
  float fVar8;
  uint uVar9;
  float fVar10;
  float fVar11;
  uint uStack_10;
  uint uStack_c;
  int iStack_8;
  
  pfVar1 = param_2;
  uVar6 = (uint)DAT_018c0da0;
  uVar9 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fVar11 = (float)(double)CONCAT44((uint)((ulonglong)(double)*param_2 >> 0x20) & uVar9,
                                   SUB84((double)*param_2,0) & uVar6);
  fVar10 = (float)(double)CONCAT44((uint)((ulonglong)(double)param_2[1] >> 0x20) & uVar9,
                                   SUB84((double)param_2[1],0) & uVar6);
  fVar7 = (float)(double)CONCAT44((uint)((ulonglong)(double)param_2[2] >> 0x20) & uVar9,
                                  SUB84((double)param_2[2],0) & uVar6);
  if (fVar10 <= fVar11) {
    fVar10 = fVar11;
  }
  if (fVar7 <= fVar10) {
    fVar7 = fVar10;
  }
  if (DAT_018f784c <= fVar7) {
    iStack_8 = 0;
    FUN_0171de34((double)fVar7,&iStack_8);
    if (iStack_8 < 1) {
      iStack_8 = 0;
    }
    else if (0xe < iStack_8) {
      iStack_8 = 0xe;
    }
    fVar2 = (float10)FUN_017277f1(DAT_018c0d60,iStack_8);
    fVar7 = (float)fVar2;
    fVar10 = DAT_018f7860;
    if (0.0 <= *pfVar1) {
      fVar10 = DAT_018ce2f4;
    }
    fVar3 = *pfVar1 / fVar7;
    fVar11 = DAT_018f7864;
    if ((DAT_018f7864 < fVar3) && (fVar11 = fVar3, DAT_018ce2f8 <= fVar3)) {
      fVar11 = DAT_018ce2f8;
    }
    fVar11 = fVar11 * DAT_018f7858;
    fVar3 = DAT_018f7860;
    if (0.0 <= pfVar1[1]) {
      fVar3 = DAT_018ce2f4;
    }
    fVar4 = pfVar1[1] / fVar7;
    fVar5 = DAT_018f7864;
    if ((DAT_018f7864 < fVar4) && (fVar5 = fVar4, DAT_018ce2f8 <= fVar4)) {
      fVar5 = DAT_018ce2f8;
    }
    uStack_c = (int)(fVar5 * DAT_018f7858 + fVar3) & 0xfff;
    fVar3 = DAT_018ce2f4;
    if (pfVar1[2] < 0.0) {
      fVar3 = DAT_018f7860;
    }
    fVar4 = pfVar1[2] / fVar7;
    fVar5 = DAT_018f7864;
    if ((fVar4 <= DAT_018f7864) || (fVar8 = DAT_018ce2f8, fVar5 = fVar4, fVar4 < DAT_018ce2f8)) {
      fVar8 = fVar5;
    }
    uStack_10 = (int)(fVar8 * DAT_018f7858 + fVar3) & 0xfff;
    param_2 = (float *)CONCAT31((int3)((uint)fVar7 >> 8),
                                ((char)iStack_8 + '\x01') * '\x10' | (byte)uStack_10 & 0xf);
    FUN_006ad5e0(&param_2,1);
    param_2 = (float *)(((int)(fVar11 + fVar10) << 0xc | uStack_c) << 8 | uStack_10 >> 4);
    FUN_006a5c10(&param_2,&uStack_10,4);
    FUN_006ad5e0(&uStack_10,4);
    return;
  }
  param_2 = (float *)((uint)param_2 & 0xffffff00);
  FUN_006ad5e0();
  return;
}



/* FUNCTION 10311 ; VA 0x00723e10 ; FUN_00723e10 */

float10 FUN_00723e10(float param_1,undefined4 param_2)

{
  float10 fVar1;
  
  fVar1 = (float10)FUN_017277f1((double)param_1,param_2);
  return (float10)(float)fVar1;
}



/* FUNCTION 10312 ; VA 0x00723e40 ; FUN_00723e40 */

undefined4 * __fastcall FUN_00723e40(undefined4 *param_1)

{
  undefined4 uVar1;
  int *piVar2;
  undefined **ppuVar3;
  int iVar4;
  int iVar5;
  undefined **ppuVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac7a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Network::GuidRegistryService,class_RBX::ServiceInstance>::
             vftable;
  uVar1 = FUN_005eddf0();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::Network::GuidRegistryService::vftable;
  piVar2 = (int *)FUN_01674e20(0x4c);
  if (piVar2 == (int *)0x0) {
    piVar2 = (int *)0x0;
  }
  else {
    *piVar2 = 0;
    ppuVar6 = (undefined **)&DAT_018be100;
    *(undefined *)(piVar2 + 1) = 0;
    iVar4 = 0x26;
    do {
      iVar5 = iVar4 >> 1;
      if (ppuVar6[iVar5] < &DAT_0000000b) {
        ppuVar6 = ppuVar6 + iVar5 + 1;
        iVar5 = iVar4 + (-1 - iVar5);
      }
      iVar4 = iVar5;
    } while (0 < iVar5);
    ppuVar3 = ppuVar6 + -1;
    if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar3 = ppuVar6;
    }
    piVar2[2] = (int)*ppuVar3;
    piVar2[3] = 0;
    piVar2[4] = 0x3f800000;
    piVar2[5] = 0;
    piVar2[6] = 0;
    FUN_016dee4c(piVar2 + 7,2);
  }
  param_1[0x16] = piVar2;
  if (piVar2 != (int *)0x0) {
    LOCK();
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10313 ; VA 0x00723f50 ; FUN_00723f50 */

undefined4 * __thiscall FUN_00723f50(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  
  *param_1 = RBX::Network::GuidRegistryService::vftable;
  piVar2 = (int *)param_1[0x16];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar2 != (int *)0x0)) {
      FUN_016dedfb(piVar2 + 7);
      FUN_00612220();
      FUN_01674ea0(piVar2,0x4c);
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 10314 ; VA 0x00723fc0 ; thunk_FUN_005ee470 */

void thunk_FUN_005ee470(void)

{
  int iVar1;
  
  if (DAT_01eaa7b4 == 0) {
    iVar1 = FUN_005eddf0();
    DAT_01eaa7b4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 10315 ; VA 0x00723fd0 ; FUN_00723fd0 */

undefined4 * __thiscall FUN_00723fd0(undefined4 *param_1,undefined4 param_2)

{
  param_1[1] = param_2;
  param_1[2] = 1;
  param_1[3] = 0;
  *param_1 = RBX::Network::DeserializedJoinDataItem::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  return param_1;
}



/* FUNCTION 10316 ; VA 0x00724010 ; FUN_00724010 */

undefined4 * __thiscall FUN_00724010(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::DeserializedJoinDataItem::vftable;
  FUN_00612ce0();
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 10317 ; VA 0x00724050 ; FUN_00724050 */

undefined4 __thiscall FUN_00724050(undefined4 param_1,int *param_2)

{
  (**(code **)(*param_2 + 0x1b8))(param_1);
  return 1;
}



/* FUNCTION 10318 ; VA 0x00724070 ; FUN_00724070 */

int __fastcall FUN_00724070(int param_1)

{
  *(undefined *)(param_1 + 600) = 0;
  return param_1;
}



/* FUNCTION 10319 ; VA 0x00724080 ; FUN_00724080 */

undefined4 __thiscall FUN_00724080(int param_1,byte *param_2,uint param_3,int *param_4,int *param_5)

{
  int iVar1;
  byte bVar2;
  byte *pbVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  uint uStack_8;
  
  if (((param_2 != (byte *)0x0) && (0xf < param_3)) && ((param_3 & 0xf) == 0)) {
    if (0xf < param_3 - 0x10) {
      uStack_8 = param_3 - 0x10 >> 4;
      piVar4 = param_4;
      do {
        piVar4 = piVar4 + 4;
        uVar6 = (0x10 - (int)param_4) + (int)piVar4;
        FUN_00cf72a0(param_1 + 0x240,param_1 + 0x120,param_2 + (uVar6 - 0x10),0x10,piVar4);
        uVar5 = 0;
        pbVar3 = param_2;
        do {
          if (uVar6 == param_3) {
            bVar2 = *pbVar3;
          }
          else {
            bVar2 = pbVar3[uVar6];
          }
          *(byte *)((int)piVar4 + uVar5) = *(byte *)((int)piVar4 + uVar5) ^ bVar2;
          uVar5 = uVar5 + 1;
          pbVar3 = pbVar3 + 1;
        } while (uVar5 < 0x10);
        uStack_8 = uStack_8 - 1;
      } while (uStack_8 != 0);
    }
    FUN_00cf72a0(param_1 + 0x240,param_1 + 0x120,param_2,0x10,param_4);
    iVar1 = *param_4;
    uVar6 = (uint)(*(byte *)((int)param_4 + 5) & 0xf);
    *param_5 = (param_3 - uVar6) + -6;
    FUN_00724850(param_4 + 1,(param_3 - uVar6) + -4 + uVar6);
    if (iVar1 == 0) {
      FUN_0170cc70(param_4,(int)param_4 + uVar6 + 6,*param_5);
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 10320 ; VA 0x007241d0 ; FUN_007241d0 */

void __thiscall
FUN_007241d0(int param_1,undefined4 *param_2,int param_3,undefined4 *param_4,int *param_5)

{
  int iVar1;
  undefined uVar2;
  char cVar3;
  byte *pbVar4;
  uint uVar5;
  byte bVar6;
  byte *pbVar7;
  uint uVar8;
  uint uVar9;
  
  uVar2 = FUN_01679e10();
  bVar6 = 0xf - ((char)param_3 + 5U & 0xf);
  cVar3 = FUN_01679e10();
  uVar9 = (uint)bVar6;
  *param_5 = uVar9 + param_3 + 6;
  if (param_2 == param_4) {
    FUN_0170cc70();
  }
  else {
    FUN_0170c6f0((int)param_4 + uVar9 + 6,param_2,param_3);
  }
  uVar8 = 0;
  *(undefined *)(param_4 + 1) = uVar2;
  *(byte *)((int)param_4 + 5) = cVar3 << 4 | bVar6;
  if (uVar9 != 0) {
    do {
      uVar2 = FUN_01679e10();
      *(undefined *)((int)param_4 + uVar8 + 6) = uVar2;
      uVar8 = uVar8 + 1;
    } while (uVar8 < uVar9);
  }
  FUN_00724850(param_4 + 1,uVar9 + param_3 + 2);
  *param_4 = 0;
  FUN_00cf7610(param_1 + 0x240,param_1,param_4,0x10,param_4);
  uVar9 = *param_5 - 0x10;
  if (0xf < uVar9) {
    pbVar7 = (byte *)((int)param_4 + uVar9);
    uVar8 = 0;
    do {
      uVar5 = 0;
      pbVar4 = pbVar7;
      do {
        *pbVar4 = *pbVar4 ^ pbVar4[uVar8 - uVar9];
        pbVar4[1] = pbVar4[1] ^ *(byte *)((int)param_4 + uVar5 + uVar8 + 1);
        pbVar4[2] = pbVar4[2] ^ *(byte *)((int)param_4 + uVar5 + uVar8 + 2);
        iVar1 = uVar5 + uVar8 + 3;
        uVar5 = uVar5 + 4;
        pbVar4[3] = pbVar4[3] ^ *(byte *)((int)param_4 + iVar1);
        pbVar4 = pbVar4 + 4;
      } while (uVar5 < 0x10);
      FUN_00cf7610(param_1 + 0x240,param_1,pbVar7,0x10,pbVar7);
      pbVar7 = pbVar7 + -0x10;
      uVar5 = uVar9 - 0x10;
      uVar8 = uVar9;
      uVar9 = uVar5;
    } while (0xf < uVar5);
  }
  return;
}



/* FUNCTION 10321 ; VA 0x00724320 ; FUN_00724320 */

void __thiscall FUN_00724320(int param_1,undefined4 param_2)

{
  *(undefined *)(param_1 + 600) = 1;
  FUN_00cf79c0(param_1,0,0x10,param_2);
  FUN_00cf79c0(param_1 + 0x120,1,0x10,param_2);
  FUN_00cf7950(param_1 + 0x240,1,0);
  return;
}



/* FUNCTION 10322 ; VA 0x00724370 ; FUN_00724370 */

undefined4 * __thiscall
FUN_00724370(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac7b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a360a0("ModelCompleteness Mega Job",1,0,param_2,param_3,8);
  *param_1 = RBX::Network::ModelCompletenessJob::vftable;
  param_1[0x4a] = param_4;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  param_1[0x4b] = param_2;
  param_1[0x4c] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10323 ; VA 0x00724450 ; FUN_00724450 */

undefined4 * __thiscall FUN_00724450(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = RBX::Network::ModelCompletenessJob::vftable;
  piVar1 = (int *)param_1[0x4c];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x138);
  }
  return param_1;
}



/* FUNCTION 10324 ; VA 0x007244a0 ; FUN_007244a0 */

undefined4 __fastcall FUN_007244a0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined8 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ac7ec;
  pvStack_10 = ExceptionList;
  iVar5 = 0;
  piVar4 = (int *)0x0;
  iVar2 = *(int *)(param_1 + 0x130);
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    piVar4 = (int *)(iVar2 + 4);
    iVar2 = *(int *)(iVar2 + 4);
    ExceptionList = &pvStack_10;
    while (iVar2 != 0) {
      LOCK();
      iVar5 = *piVar4;
      if (iVar2 == iVar5) {
        *piVar4 = iVar2 + 1;
        iVar5 = iVar2;
      }
      UNLOCK();
      if (iVar5 == iVar2) {
        iVar5 = *(int *)(param_1 + 300);
        piVar4 = *(int **)(param_1 + 0x130);
        goto LAB_007244fd;
      }
      iVar2 = *piVar4;
    }
    iVar5 = 0;
    piVar4 = (int *)0x0;
  }
LAB_007244fd:
  iStack_8 = 0;
  if (iVar5 != 0) {
    if (DAT_01d5b7f8 == '\0') {
      uVar3 = FUN_006d8590();
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eafde8
          ) && (FUN_016f3809(&DAT_01eafde8), DAT_01eafde8 == -1)) {
        iStack_8._0_1_ = 1;
        uVar6 = FUN_0152da50(&DAT_018c5904);
        DAT_01eafde4 = (undefined4)((ulonglong)uVar6 >> 0x20);
        DAT_01eafde0 = (undefined4)uVar6;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_016f37bf(&DAT_01eafde8);
      }
      FUN_0152d760(DAT_01eafde0,DAT_01eafde4,"Model completeness signals sent : %d",uVar3);
    }
    if (DAT_01d5b278 != '\0') {
      FUN_008e9840(iVar5 + 0xc);
      iStack_8 = CONCAT31(iStack_8._1_3_,2);
      FUN_006dd5a0(iVar5);
      FUN_008eb130();
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar2 = piVar4[1] + -1;
      piVar4[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 10325 ; VA 0x00724670 ; FUN_00724670 */

bool __fastcall FUN_00724670(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac808;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01eadc98);
  iVar1 = *param_1;
  uStack_8 = 0;
  if (iVar1 != 0) {
    uVar3 = (**(code **)(param_1[1] + 8))();
    uVar4 = (**(code **)(param_1[1] + 4))();
    FUN_006ad5e0(uVar4,uVar3);
  }
  uStack_8 = 2;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return iVar1 != 0;
}



/* FUNCTION 10326 ; VA 0x00724700 ; FUN_00724700 */

void __thiscall FUN_00724700(int *param_1,int *param_2,int param_3,undefined4 param_4)

{
  uint *puVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac838;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eafe0c);
  uStack_8 = 0;
  if (*param_1 == 0) {
    puVar1 = (uint *)(param_1 + 0xb);
    if (puVar1 == (uint *)0x0) {
      uVar3 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      FUN_00564990(uVar3);
    }
    LOCK();
    uVar2 = *puVar1;
    *puVar1 = *puVar1 | 0x80000000;
    UNLOCK();
    uStack_8._0_1_ = 4;
    uStack_8._1_3_ = 0;
    if ((-1 < (int)uVar2) && (*param_1 == 0)) {
      FUN_006ab670();
      iVar4 = (**(code **)(*param_2 + 4))(param_4);
      FUN_006ad5e0(iVar4 + param_3,param_4);
      LOCK();
      *param_1 = 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (-1 < (int)uVar2) {
      LOCK();
      uVar2 = *puVar1;
      *puVar1 = *puVar1 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puVar1;
        *puVar1 = *puVar1 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          iVar4 = param_1[0xc];
          if (param_1[0xc] == 0) {
            iVar4 = CreateEventA(0,0,0,0);
            if (iVar4 == 0) {
              uVar3 = FUN_005503c0();
                    /* WARNING: Subroutine does not return */
              FUN_0054e630(uVar3);
            }
            LOCK();
            iVar5 = param_1[0xc];
            if (iVar5 == 0) {
              param_1[0xc] = iVar4;
              iVar5 = 0;
            }
            UNLOCK();
            if (iVar5 != 0) {
              CloseHandle(iVar4);
              iVar4 = iVar5;
            }
          }
          SetEvent(iVar4);
        }
      }
    }
  }
  uStack_8 = 7;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10327 ; VA 0x00724850 ; FUN_00724850 */

void __thiscall FUN_00724850(short *param_1,int param_2,uint param_3)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = 0;
  if (param_3 != 0) {
    iVar3 = *(int *)(param_1 + 4);
    do {
      bVar1 = (byte)((ushort)*param_1 >> 8) ^ *(byte *)(uVar2 + param_2);
      uVar2 = uVar2 + 1;
      iVar3 = iVar3 + (uint)bVar1;
      *param_1 = ((ushort)bVar1 + *param_1) * param_1[1] + param_1[2];
      *(int *)(param_1 + 4) = iVar3;
    } while (uVar2 < param_3);
  }
  return;
}



/* FUNCTION 10328 ; VA 0x007248a0 ; FUN_007248a0 */

undefined4 * __thiscall FUN_007248a0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_1 = std::_Func_impl_no_alloc<class_<lambda_2147801f6b5147ded16624f97b395062>,void>::vftable
  ;
  param_1[1] = *param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = param_2[1];
  param_1[3] = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  uVar1 = param_2[4];
  uVar2 = param_2[5];
  uVar3 = param_2[6];
  param_1[4] = param_2[3];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 7);
  param_2[7] = 0;
  param_2[8] = 0xf;
  *(undefined *)(param_2 + 3) = 0;
  return param_1;
}



/* FUNCTION 10329 ; VA 0x00724920 ; FUN_00724920 */

undefined4 * __thiscall FUN_00724920(undefined4 *param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_0000001c;
  undefined4 auStack_74 [5];
  undefined4 uStack_60;
  int iStack_5c;
  int *piStack_58;
  int aiStack_48 [5];
  uint uStack_34;
  undefined4 uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac868;
  pvStack_10 = ExceptionList;
  piStack_58 = &param_3;
  uStack_8 = 0;
  iStack_5c = 0x72495b;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  uStack_30 = param_2;
  piStack_58 = aiStack_48;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_5c = 0x724977;
  FUN_0054ef60();
  piStack_58 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = auStack_74;
  auStack_74[0] = uStack_30;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_018f8fd0;
  cVar1 = FUN_00728610();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_58 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_58 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)0x724a56;
        FUN_017167a3();
      }
    }
    uStack_60 = 0x7249da;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_34) {
    piStack_58 = (int *)(uStack_34 + 1);
    iVar2 = aiStack_48[0];
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(aiStack_48[0] + -4);
      piStack_58 = (int *)(uStack_34 + 0x24);
      if (0x1f < (aiStack_48[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)0x724a5b;
        FUN_017167a3();
      }
    }
    uStack_60 = 0x724a0a;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_0000001c) {
    piStack_58 = (int *)(in_stack_0000001c + 1);
    iVar2 = param_3;
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(param_3 + -4);
      piStack_58 = (int *)(in_stack_0000001c + 0x24);
      if (0x1f < (param_3 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)&UNK_00724a60;
        FUN_017167a3();
      }
    }
    uStack_60 = 0x724a3a;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10330 ; VA 0x00724a70 ; FUN_00724a70 */

undefined4 * __thiscall FUN_00724a70(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_1 = std::_Func_impl_no_alloc<class_<lambda_5d9b30ac53976d77147019cfb284dd58>,void>::vftable
  ;
  param_1[1] = *param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = param_2[1];
  param_1[3] = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  uVar1 = param_2[4];
  uVar2 = param_2[5];
  uVar3 = param_2[6];
  param_1[4] = param_2[3];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 7);
  param_2[7] = 0;
  param_2[8] = 0xf;
  *(undefined *)(param_2 + 3) = 0;
  return param_1;
}



/* FUNCTION 10331 ; VA 0x00724af0 ; FUN_00724af0 */

undefined4 * __thiscall FUN_00724af0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_0000001c;
  undefined4 auStack_74 [5];
  undefined4 uStack_60;
  int iStack_5c;
  int *piStack_58;
  int aiStack_48 [5];
  uint uStack_34;
  undefined4 uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac898;
  pvStack_10 = ExceptionList;
  piStack_58 = &param_3;
  uStack_8 = 0;
  iStack_5c = 0x724b2b;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  uStack_30 = param_2;
  piStack_58 = aiStack_48;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_5c = 0x724b47;
  FUN_0054ef60();
  piStack_58 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = auStack_74;
  auStack_74[0] = uStack_30;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_018f8fc8;
  cVar1 = FUN_007287b0();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_58 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_58 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)0x724c26;
        FUN_017167a3();
      }
    }
    uStack_60 = 0x724baa;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_34) {
    piStack_58 = (int *)(uStack_34 + 1);
    iVar2 = aiStack_48[0];
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(aiStack_48[0] + -4);
      piStack_58 = (int *)(uStack_34 + 0x24);
      if (0x1f < (aiStack_48[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)0x724c2b;
        FUN_017167a3();
      }
    }
    uStack_60 = 0x724bda;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_0000001c) {
    piStack_58 = (int *)(in_stack_0000001c + 1);
    iVar2 = param_3;
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(param_3 + -4);
      piStack_58 = (int *)(in_stack_0000001c + 0x24);
      if (0x1f < (param_3 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)&UNK_00724c30;
        FUN_017167a3();
      }
    }
    uStack_60 = 0x724c0a;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10332 ; VA 0x00724c40 ; FUN_00724c40 */

undefined4 * __thiscall FUN_00724c40(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac8c3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::_Func_impl_no_alloc<class_<lambda_9fadf1c1803edebae3f930ab7385f7ad>,void>::vftable
  ;
  param_1[2] = *param_2;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[3] = param_2[1];
  param_1[4] = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[0xf] = 0;
  piVar1 = (int *)param_2[0xd];
  uStack_8 = 1;
  if (piVar1 != (int *)0x0) {
    if (piVar1 == param_2 + 4) {
      uVar2 = (**(code **)(*piVar1 + 4))(param_1 + 6);
      param_1[0xf] = uVar2;
      piVar1 = (int *)param_2[0xd];
      if (piVar1 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(*piVar1 + 0x10))(piVar1 != param_2 + 4);
    }
    else {
      param_1[0xf] = piVar1;
    }
    param_2[0xd] = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10333 ; VA 0x00724d10 ; FUN_00724d10 */

undefined4 * __thiscall FUN_00724d10(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac8c3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_a94a0a1906c0a96a9aa9e2584a09f398>,void,class_RBX::SharedString,class_G3D::CoordinateFrame,class_G3D::Vector3>
             ::vftable;
  param_1[2] = *param_2;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[3] = param_2[1];
  param_1[4] = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[0xf] = 0;
  piVar1 = (int *)param_2[0xd];
  uStack_8 = 1;
  if (piVar1 != (int *)0x0) {
    if (piVar1 == param_2 + 4) {
      uVar2 = (**(code **)(*piVar1 + 4))(param_1 + 6);
      param_1[0xf] = uVar2;
      piVar1 = (int *)param_2[0xd];
      if (piVar1 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(*piVar1 + 0x10))(piVar1 != param_2 + 4);
    }
    else {
      param_1[0xf] = piVar1;
    }
    param_2[0xd] = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10334 ; VA 0x00724de0 ; FUN_00724de0 */

undefined4 * __thiscall
FUN_00724de0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined **ppuVar5;
  int *in_stack_00000038;
  undefined4 uStack_98;
  undefined4 uStack_94;
  int *piStack_90;
  undefined auStack_88 [36];
  undefined4 uStack_64;
  int *piStack_60;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  int aiStack_40 [9];
  int *piStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ac906;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_50;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_50 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_4c = param_3;
  piStack_48 = param_4;
  piStack_18 = aiStack_40;
  piStack_1c = (int *)0x0;
  uStack_8 = 2;
  uStack_7 = 0;
  if (in_stack_00000038 != (int *)0x0) {
    piStack_60 = aiStack_40;
    uStack_64 = 0x724e5e;
    piStack_1c = (int *)(**(code **)*in_stack_00000038)();
  }
  piStack_60 = param_1 + 2;
  piStack_18 = &uStack_98;
  uStack_98 = uStack_50;
  if (piStack_48 != (int *)0x0) {
    LOCK();
    piStack_48[1] = piStack_48[1] + 1;
    UNLOCK();
  }
  uStack_94 = uStack_4c;
  piStack_90 = piStack_48;
  puStack_14 = (undefined4 *)auStack_88;
  uStack_64 = 0;
  uStack_8 = 5;
  piVar3 = &uStack_98;
  if (piStack_1c != (int *)0x0) {
    uStack_64 = (**(code **)*piStack_1c)(puStack_14);
    piVar3 = piStack_18;
  }
  piStack_18 = piVar3;
  ppuVar5 = &PTR_FUN_018f8fe0;
  _uStack_8 = CONCAT31(uStack_7,3);
  cVar4 = FUN_00728950();
  if (cVar4 == '\0') {
    ppuVar5 = (undefined **)0x0;
  }
  *param_1 = ppuVar5;
  if (piStack_1c != (int *)0x0) {
    piStack_60 = (int *)(uint)(piStack_1c != aiStack_40);
    uStack_64 = 0x724ee8;
    (**(code **)(*piStack_1c + 0x10))();
    piStack_1c = (int *)0x0;
  }
  piVar3 = piStack_48;
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_48[1] + -1;
    piStack_48[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_60 = (int *)0x724f08;
      (**(code **)*piStack_48)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_60 = (int *)0x724f18;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (in_stack_00000038 != (int *)0x0) {
    piStack_60 = (int *)(uint)(in_stack_00000038 != (int *)&stack0x00000014);
    uStack_64 = 0x724f30;
    (**(code **)(*in_stack_00000038 + 0x10))();
    in_stack_00000038 = (int *)0x0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_60 = (int *)0x724f4d;
      (**(code **)*param_4)();
      LOCK();
      piVar3 = param_4 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_60 = (int *)0x724f5c;
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10335 ; VA 0x00724f80 ; FUN_00724f80 */

undefined4 * __thiscall FUN_00724f80(undefined4 *param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_0000001c;
  undefined4 auStack_74 [5];
  undefined4 uStack_60;
  int iStack_5c;
  int *piStack_58;
  int aiStack_48 [5];
  uint uStack_34;
  undefined4 uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac928;
  pvStack_10 = ExceptionList;
  piStack_58 = &param_3;
  uStack_8 = 0;
  iStack_5c = 0x724fbb;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  uStack_30 = param_2;
  piStack_58 = aiStack_48;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_5c = 0x724fd7;
  FUN_0054ef60();
  piStack_58 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = auStack_74;
  auStack_74[0] = uStack_30;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_018f8fc0;
  cVar1 = FUN_00728ae0();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_58 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_58 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)0x7250b6;
        FUN_017167a3();
      }
    }
    uStack_60 = 0x72503a;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_34) {
    piStack_58 = (int *)(uStack_34 + 1);
    iVar2 = aiStack_48[0];
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(aiStack_48[0] + -4);
      piStack_58 = (int *)(uStack_34 + 0x24);
      if (0x1f < (aiStack_48[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)0x7250bb;
        FUN_017167a3();
      }
    }
    uStack_60 = 0x72506a;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_0000001c) {
    piStack_58 = (int *)(in_stack_0000001c + 1);
    iVar2 = param_3;
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(param_3 + -4);
      piStack_58 = (int *)(in_stack_0000001c + 0x24);
      if (0x1f < (param_3 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)&UNK_007250c0;
        FUN_017167a3();
      }
    }
    uStack_60 = 0x72509a;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10336 ; VA 0x007250d0 ; FUN_007250d0 */

undefined4 * __thiscall FUN_007250d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac8c3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_d99a02d8abd0c177beb66b74bbd030e7>,void,class_RBX::SharedString,class_G3D::CoordinateFrame,class_G3D::Vector3>
             ::vftable;
  param_1[2] = *param_2;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[3] = param_2[1];
  param_1[4] = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[0xf] = 0;
  piVar1 = (int *)param_2[0xd];
  uStack_8 = 1;
  if (piVar1 != (int *)0x0) {
    if (piVar1 == param_2 + 4) {
      uVar2 = (**(code **)(*piVar1 + 4))(param_1 + 6);
      param_1[0xf] = uVar2;
      piVar1 = (int *)param_2[0xd];
      if (piVar1 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(*piVar1 + 0x10))(piVar1 != param_2 + 4);
    }
    else {
      param_1[0xf] = piVar1;
    }
    param_2[0xd] = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10337 ; VA 0x007251a0 ; FUN_007251a0 */

undefined4 * __thiscall FUN_007251a0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_1 = std::_Func_impl_no_alloc<class_<lambda_ee81a1eb500ea1d1cd6c30e2827a211f>,void>::vftable
  ;
  param_1[1] = *param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = param_2[1];
  param_1[3] = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  uVar1 = param_2[4];
  uVar2 = param_2[5];
  uVar3 = param_2[6];
  param_1[4] = param_2[3];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 7);
  param_2[7] = 0;
  param_2[8] = 0xf;
  *(undefined *)(param_2 + 3) = 0;
  return param_1;
}



/* FUNCTION 10338 ; VA 0x00725220 ; FUN_00725220 */

undefined4 * __thiscall FUN_00725220(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac8c3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::_Func_impl_no_alloc<class_<lambda_f0c80228f4fcb25338a5703a60ccc5f9>,void>::vftable
  ;
  param_1[2] = *param_2;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[3] = param_2[1];
  param_1[4] = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[0xf] = 0;
  piVar1 = (int *)param_2[0xd];
  uStack_8 = 1;
  if (piVar1 != (int *)0x0) {
    if (piVar1 == param_2 + 4) {
      uVar2 = (**(code **)(*piVar1 + 4))(param_1 + 6);
      param_1[0xf] = uVar2;
      piVar1 = (int *)param_2[0xd];
      if (piVar1 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(*piVar1 + 0x10))(piVar1 != param_2 + 4);
    }
    else {
      param_1[0xf] = piVar1;
    }
    param_2[0xd] = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10339 ; VA 0x007252f0 ; FUN_007252f0 */

undefined4 * __thiscall FUN_007252f0(undefined4 *param_1)

{
  int *piVar1;
  int *in_stack_00000028;
  undefined auStack_6c [32];
  undefined4 uStack_4c;
  int *piStack_48;
  int aiStack_3c [9];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ac960;
  pvStack_10 = ExceptionList;
  piStack_14 = aiStack_3c;
  piStack_18 = (int *)0x0;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (in_stack_00000028 != (int *)0x0) {
    piStack_48 = aiStack_3c;
    uStack_4c = 0x725339;
    ExceptionList = &pvStack_10;
    piStack_18 = (int *)(**(code **)*in_stack_00000028)();
  }
  piStack_14 = (int *)auStack_6c;
  *param_1 = 0;
  piStack_48 = (int *)0x0;
  uStack_8 = 3;
  piVar1 = (int *)auStack_6c;
  if (piStack_18 != (int *)0x0) {
    piStack_48 = (int *)(**(code **)*piStack_18)(auStack_6c);
    piVar1 = piStack_14;
  }
  piStack_14 = piVar1;
  _uStack_8 = CONCAT31(uStack_7,2);
  FUN_00728c80();
  if (piStack_18 != (int *)0x0) {
    piStack_48 = (int *)(uint)(piStack_18 != aiStack_3c);
    uStack_4c = 0x725387;
    (**(code **)(*piStack_18 + 0x10))();
  }
  if (in_stack_00000028 != (int *)0x0) {
    piStack_48 = (int *)(uint)(in_stack_00000028 != (int *)&stack0x00000004);
    uStack_4c = 0x72539f;
    (**(code **)(*in_stack_00000028 + 0x10))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10340 ; VA 0x007253f0 ; FUN_007253f0 */

int FUN_007253f0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac970;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0072dad0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054ef60(*param_2);
  *(undefined4 *)(iVar1 + 0x28) = 0;
  *(undefined4 *)(iVar1 + 0x2c) = 0;
  *(undefined4 *)(iVar1 + 0x30) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 10341 ; VA 0x00725462 ; Catch_All@00725462 */

void Catch_All_00725462(void)

{
  int unaff_EBP;
  
  FUN_0072df00(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10342 ; VA 0x00725480 ; FUN_00725480 */

void FUN_00725480(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = FUN_00575bc0();
  *(undefined2 *)(iVar2 + 0xc) = 0;
  puVar1 = (undefined4 *)*param_2;
  *(undefined4 *)(iVar2 + 0x10) = *puVar1;
  *(undefined4 *)(iVar2 + 0x14) = puVar1[1];
  *(undefined4 *)(iVar2 + 0x18) = 0;
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  *(undefined4 *)(iVar2 + 0x20) = 0;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  *(undefined4 *)(iVar2 + 0x28) = 0;
  return;
}



/* FUNCTION 10343 ; VA 0x007254b0 ; FUN_007254b0 */

void FUN_007254b0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = FUN_00601de0();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *param_1;
  *(undefined4 *)(iVar1 + 0x14) = param_1[1];
  return;
}



/* FUNCTION 10344 ; VA 0x007254d0 ; FUN_007254d0 */

int __thiscall FUN_007254d0(uint *param_1,uint param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_8 = 0xff;
  uStack_7 = 0xffffff;
  puStack_c = &LAB_017ac998;
  pvStack_10 = ExceptionList;
  uVar2 = *param_1;
  iVar4 = (int)(param_1[1] - uVar2) / 0x28;
  if (iVar4 == 0x6666666) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar7 = (int)(param_1[2] - uVar2) / 0x28;
  uVar9 = uVar1;
  if ((uVar7 <= 0x6666666 - (uVar7 >> 1)) && (uVar9 = (uVar7 >> 1) + uVar7, uVar9 < uVar1)) {
    uVar9 = uVar1;
  }
  uVar7 = uVar9 * 0x28;
  if (uVar9 < 0x6666667) {
    if (0xfff < uVar7) goto LAB_0072558d;
    if (uVar7 == 0) {
      uVar7 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_0072558d:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_00725744;
    uVar7 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar4;
  }
  iVar5 = ((int)(param_2 - uVar2) / 0x28) * 0x28;
  iVar4 = iVar5 + uVar7;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  if (*(undefined4 **)(param_3 + 0x24) != (undefined4 *)0x0) {
    uVar6 = (**(code **)**(undefined4 **)(param_3 + 0x24))(iVar4);
    *(undefined4 *)(iVar5 + uVar7 + 0x24) = uVar6;
  }
  uVar2 = param_1[1];
  uStack_8 = 0;
  if (param_2 == uVar2) {
    uVar8 = uVar7;
    for (uVar3 = *param_1; uStack_8 = 2, uVar3 != uVar2; uVar3 = uVar3 + 0x28) {
      *(undefined4 *)(uVar8 + 0x24) = 0;
      uStack_8 = 3;
      if (*(undefined4 **)(uVar3 + 0x24) != (undefined4 *)0x0) {
        uVar6 = (**(code **)**(undefined4 **)(uVar3 + 0x24))(uVar8);
        *(undefined4 *)(uVar8 + 0x24) = uVar6;
      }
      uVar8 = uVar8 + 0x28;
    }
    FUN_0072a040();
  }
  else {
    FUN_0072e430(*param_1,param_2,uVar7);
    FUN_0072e430(param_2,param_1[1],iVar4 + 0x28);
  }
  if (*param_1 != 0) {
    FUN_005f6200(*param_1,param_1[1]);
    uVar2 = *param_1;
    uVar8 = ((int)(param_1[2] - *param_1) / 0x28) * 0x28;
    uVar3 = uVar2;
    if (0xfff < uVar8) {
      uVar3 = *(uint *)(uVar2 - 4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (uVar2 - uVar3) - 4) {
LAB_00725744:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar8);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + uVar1 * 0x28;
  param_1[2] = uVar7 + uVar9 * 0x28;
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 10345 ; VA 0x0072571a ; Catch_All@0072571a */

void Catch_All_0072571a(void)

{
  int unaff_EBP;
  
  FUN_005f6200(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x24));
  FUN_005f6c10(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10346 ; VA 0x00725750 ; FUN_00725750 */

int __thiscall FUN_00725750(int *param_1,int param_2,undefined2 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined2 *puVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  
  iVar2 = *param_1;
  iVar8 = param_2 - iVar2;
  iVar3 = param_1[1] - iVar2 >> 1;
  if (iVar3 == 0x7fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar6 = param_1[2] - iVar2 >> 1;
  uVar7 = uVar1;
  if ((uVar6 <= 0x7fffffff - (uVar6 >> 1)) && (uVar7 = (uVar6 >> 1) + uVar6, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  iVar4 = FUN_005540c0(uVar7);
  iVar3 = (iVar8 >> 1) * 2;
  puVar5 = (undefined2 *)(iVar4 + iVar3);
  *puVar5 = *param_3;
  iVar2 = param_1[1];
  if (param_2 == iVar2) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar4,*param_1,iVar2 - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar4,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(puVar5 + 1,param_2,param_1[1] - param_2);
  }
  FUN_0072daf0(iVar4,uVar1,uVar7);
  return *param_1 + iVar3;
}



/* FUNCTION 10347 ; VA 0x00725860 ; FUN_00725860 */

int __thiscall FUN_00725860(int *param_1,int param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  
  iVar1 = *param_1;
  iVar7 = param_2 - iVar1;
  iVar2 = (param_1[1] - iVar1) / 7;
  if (iVar2 == 0x24924924) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar1) / 7;
  uVar6 = uVar5;
  if ((uVar3 <= 0x24924924 - (uVar3 >> 1)) && (uVar6 = (uVar3 >> 1) + uVar3, uVar6 < uVar5)) {
    uVar6 = uVar5;
  }
  iVar4 = FUN_0072e8f0(uVar6);
  iVar1 = (iVar7 / 7) * 7;
  *(undefined4 *)(iVar1 + iVar4) = *param_3;
  *(undefined2 *)(iVar1 + 4 + iVar4) = *(undefined2 *)(param_3 + 1);
  *(undefined *)(iVar1 + 6 + iVar4) = *(undefined *)((int)param_3 + 6);
  if (param_2 == param_1[1]) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar4,*param_1,param_1[1] - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar4,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar4 + iVar1 + 7,param_2,param_1[1] - param_2);
  }
  iVar7 = *param_1;
  if (iVar7 != 0) {
    uVar5 = ((param_1[2] - iVar7) / 7) * 7;
    iVar8 = iVar7;
    if (0xfff < uVar5) {
      iVar8 = *(int *)(iVar7 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar7 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar5);
  }
  *param_1 = iVar4;
  param_1[1] = (iVar2 + 1) * 7 + iVar4;
  param_1[2] = uVar6 * 7 + iVar4;
  return *param_1 + iVar1;
}



/* FUNCTION 10348 ; VA 0x00725a20 ; FUN_00725a20 */

int __thiscall FUN_00725a20(int *param_1,undefined4 *param_2,undefined4 param_3)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  undefined4 *puVar13;
  int iVar14;
  undefined4 *puVar15;
  
  iVar4 = ((int)param_2 - *param_1) / 0x48;
  iVar11 = (param_1[1] - *param_1) / 0x48;
  if (iVar11 == 0x38e38e3) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar11 + 1;
  uVar12 = (param_1[2] - *param_1) / 0x48;
  uVar9 = uVar1;
  if ((uVar12 <= 0x38e38e3 - (uVar12 >> 1)) && (uVar9 = (uVar12 >> 1) + uVar12, uVar9 < uVar1)) {
    uVar9 = uVar1;
  }
  uVar12 = uVar9 * 0x48;
  if (uVar9 < 0x38e38e4) {
    if (0xfff < uVar12) goto LAB_00725ab6;
    if (uVar12 == 0) {
      puVar15 = (undefined4 *)0x0;
    }
    else {
      puVar15 = (undefined4 *)FUN_01674e20(uVar12);
    }
  }
  else {
    uVar12 = 0xffffffff;
LAB_00725ab6:
    uVar10 = uVar12 + 0x23;
    if (uVar10 <= uVar12) {
      uVar10 = 0xffffffff;
    }
    iVar11 = FUN_01674e20(uVar10);
    if (iVar11 == 0) goto LAB_00725c22;
    puVar15 = (undefined4 *)(iVar11 + 0x23U & 0xffffffe0);
    puVar15[-1] = iVar11;
  }
  FUN_00728e50(param_1,puVar15 + iVar4 * 0x12,param_3);
  puVar3 = (undefined4 *)param_1[1];
  puVar13 = (undefined4 *)*param_1;
  puVar8 = puVar15;
  if (param_2 == puVar3) {
    for (; puVar13 != puVar3; puVar13 = puVar13 + 0x12) {
      *puVar8 = 0;
      puVar8[1] = 0;
      if (puVar13[1] != 0) {
        LOCK();
        piVar2 = (int *)(puVar13[1] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      *puVar8 = *puVar13;
      puVar8[1] = puVar13[1];
      iVar11 = puVar13[2];
      puVar8[2] = iVar11;
      LOCK();
      piVar2 = (int *)(iVar11 + 0x28);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
      uVar5 = puVar13[4];
      uVar6 = puVar13[5];
      uVar7 = puVar13[6];
      puVar8[3] = puVar13[3];
      puVar8[4] = uVar5;
      puVar8[5] = uVar6;
      puVar8[6] = uVar7;
      uVar5 = puVar13[8];
      uVar6 = puVar13[9];
      uVar7 = puVar13[10];
      puVar8[7] = puVar13[7];
      puVar8[8] = uVar5;
      puVar8[9] = uVar6;
      puVar8[10] = uVar7;
      uVar5 = puVar13[0xc];
      uVar6 = puVar13[0xd];
      uVar7 = puVar13[0xe];
      puVar8[0xb] = puVar13[0xb];
      puVar8[0xc] = uVar5;
      puVar8[0xd] = uVar6;
      puVar8[0xe] = uVar7;
      *(undefined8 *)(puVar8 + 0xf) = *(undefined8 *)(puVar13 + 0xf);
      puVar8[0x11] = puVar13[0x11];
      puVar8 = puVar8 + 0x12;
    }
    FUN_005f3dd0(puVar8,puVar8,param_1);
  }
  else {
    FUN_0072e380(puVar13,param_2,puVar15);
    FUN_0072e380(param_2,param_1[1],puVar15 + iVar4 * 0x12 + 0x12);
  }
  if (*param_1 != 0) {
    FUN_005f3dd0(*param_1,param_1[1],param_1);
    iVar11 = *param_1;
    uVar12 = ((param_1[2] - iVar11) / 0x48) * 0x48;
    iVar14 = iVar11;
    if (0xfff < uVar12) {
      iVar14 = *(int *)(iVar11 + -4);
      uVar12 = uVar12 + 0x23;
      if (0x1f < (iVar11 - iVar14) - 4U) {
LAB_00725c22:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar14,uVar12);
  }
  *param_1 = (int)puVar15;
  param_1[1] = (int)(puVar15 + uVar1 * 0x12);
  param_1[2] = (int)(puVar15 + uVar9 * 0x12);
  return *param_1 + iVar4 * 0x48;
}



/* FUNCTION 10349 ; VA 0x00725c30 ; FUN_00725c30 */

int __thiscall FUN_00725c30(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  uint uVar12;
  
  iVar1 = ((int)param_2 - *param_1) / 0x1c;
  iVar2 = (param_1[1] - *param_1) / 0x1c;
  if (iVar2 == 0x9249249) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = (param_1[2] - *param_1) / 0x1c;
  uVar12 = iVar2 + 1;
  if (uVar3 <= 0x9249249 - (uVar3 >> 1)) {
    uVar12 = (uVar3 >> 1) + uVar3;
    if (uVar12 < iVar2 + 1U) {
      uVar12 = iVar2 + 1U;
    }
  }
  puVar7 = (undefined4 *)FUN_0072e960(uVar12);
  puVar8 = puVar7 + iVar1 * 7;
  uVar4 = param_3[1];
  uVar5 = param_3[2];
  uVar6 = param_3[3];
  *puVar8 = *param_3;
  puVar8[1] = uVar4;
  puVar8[2] = uVar5;
  puVar8[3] = uVar6;
  *(undefined8 *)(puVar8 + 4) = *(undefined8 *)(param_3 + 4);
  puVar8[6] = param_3[6];
  puVar11 = (undefined4 *)param_1[1];
  puVar9 = (undefined4 *)*param_1;
  if (param_2 == puVar11) {
    FUN_0072e4f0(puVar9,puVar11,puVar7);
  }
  else {
    puVar10 = puVar7;
    if (puVar9 != param_2) {
      do {
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        *puVar10 = *puVar9;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        *(undefined8 *)(puVar10 + 4) = *(undefined8 *)(puVar9 + 4);
        puVar11 = puVar9 + 6;
        puVar9 = puVar9 + 7;
        puVar10[6] = *puVar11;
        puVar10 = puVar10 + 7;
      } while (puVar9 != param_2);
      puVar11 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar11) {
      do {
        uVar4 = param_2[1];
        uVar5 = param_2[2];
        uVar6 = param_2[3];
        puVar8[7] = *param_2;
        puVar8[8] = uVar4;
        puVar8[9] = uVar5;
        puVar8[10] = uVar6;
        *(undefined8 *)(puVar8 + 0xb) = *(undefined8 *)(param_2 + 4);
        puVar9 = param_2 + 6;
        param_2 = param_2 + 7;
        puVar8[0xd] = *puVar9;
        puVar8 = puVar8 + 7;
      } while (param_2 != puVar11);
    }
  }
  FUN_0072db50(puVar7,iVar2 + 1,uVar12);
  return *param_1 + iVar1 * 0x1c;
}



/* FUNCTION 10350 ; VA 0x00725d90 ; FUN_00725d90 */

int __thiscall FUN_00725d90(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  
  uVar9 = *param_1;
  iVar4 = (int)(param_1[1] - uVar9) >> 3;
  if (iVar4 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar6 = (int)(param_1[2] - uVar9) >> 3;
  uVar8 = uVar1;
  if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar8 = (uVar6 >> 1) + uVar6, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  uVar6 = uVar8 * 8;
  if (uVar8 < 0x20000000) {
    uVar8 = uVar6;
    if (0xfff < uVar6) goto LAB_00725e01;
    if (uVar6 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_01674e20(uVar6);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_00725e01:
    uVar5 = uVar8 + 0x23;
    if (uVar5 <= uVar8) {
      uVar5 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar5);
    if (iVar4 == 0) goto LAB_00725f21;
    uVar8 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar4;
  }
  iVar4 = ((int)(param_2 - uVar9) >> 3) * 8;
  *(undefined4 *)(iVar4 + uVar8) = 0;
  *(undefined4 *)(iVar4 + 4 + uVar8) = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar2 = (int *)(param_3[1] + 8);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar4 + uVar8) = *param_3;
  *(undefined4 *)(iVar4 + 4 + uVar8) = param_3[1];
  uVar5 = param_1[1];
  uVar9 = *param_1;
  uVar7 = uVar8;
  if (param_2 != uVar5) {
    FUN_006cfaf0(uVar9,param_2,uVar8,param_1);
    uVar5 = param_1[1];
    uVar7 = iVar4 + 8 + uVar8;
    uVar9 = param_2;
  }
  FUN_006cfaf0(uVar9,uVar5,uVar7,param_1);
  uVar9 = *param_1;
  if (uVar9 != 0) {
    uVar5 = param_1[1];
    if (uVar9 != uVar5) {
      do {
        piVar2 = *(int **)(uVar9 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        uVar9 = uVar9 + 8;
      } while (uVar9 != uVar5);
      uVar9 = *param_1;
    }
    uVar7 = param_1[2] - uVar9 & 0xfffffff8;
    uVar5 = uVar9;
    if (0xfff < uVar7) {
      uVar5 = *(uint *)(uVar9 - 4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uVar9 - uVar5) - 4) {
LAB_00725f21:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar7);
  }
  *param_1 = uVar8;
  param_1[1] = uVar8 + uVar1 * 8;
  param_1[2] = uVar6 + uVar8;
  return *param_1 + iVar4;
}



/* FUNCTION 10351 ; VA 0x00725f30 ; FUN_00725f30 */

undefined4 * FUN_00725f30(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac9bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  *puVar2 = std::_Func_impl_no_alloc<class_<lambda_2147801f6b5147ded16624f97b395062>,void>::vftable;
  puVar2[1] = *param_1;
  puVar2[2] = 0;
  puVar2[3] = 0;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[2] = param_1[1];
  puVar2[3] = param_1[2];
  uStack_8 = 1;
  FUN_0054ef60(param_1 + 3);
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 10352 ; VA 0x00725fc2 ; Catch_All@00725fc2 */

void Catch_All_00725fc2(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10353 ; VA 0x00725fe0 ; FUN_00725fe0 */

undefined4 FUN_00725fe0(undefined4 param_1)

{
  undefined4 extraout_ECX;
  
  FUN_01674e20(0x28);
  FUN_007248a0(param_1);
  return extraout_ECX;
}



/* FUNCTION 10354 ; VA 0x00726000 ; FUN_00726000 */

undefined4 * FUN_00726000(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac9db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  *puVar2 = std::_Func_impl_no_alloc<class_<lambda_5d9b30ac53976d77147019cfb284dd58>,void>::vftable;
  puVar2[1] = *param_1;
  puVar2[2] = 0;
  puVar2[3] = 0;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[2] = param_1[1];
  puVar2[3] = param_1[2];
  uStack_8 = 1;
  FUN_0054ef60(param_1 + 3);
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 10355 ; VA 0x00726092 ; Catch_All@00726092 */

void Catch_All_00726092(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10356 ; VA 0x007260b0 ; FUN_007260b0 */

undefined4 FUN_007260b0(undefined4 param_1)

{
  undefined4 extraout_ECX;
  
  FUN_01674e20(0x28);
  FUN_00724a70(param_1);
  return extraout_ECX;
}



/* FUNCTION 10357 ; VA 0x007260d0 ; FUN_007260d0 */

undefined4 * FUN_007260d0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aca03;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x40);
  *puVar2 = std::_Func_impl_no_alloc<class_<lambda_9fadf1c1803edebae3f930ab7385f7ad>,void>::vftable;
  puVar2[2] = *param_1;
  puVar2[3] = 0;
  puVar2[4] = 0;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[3] = param_1[1];
  puVar2[4] = param_1[2];
  puVar2[0xf] = 0;
  uStack_8 = 2;
  if ((undefined4 *)param_1[0xd] != (undefined4 *)0x0) {
    uVar3 = (*(code *)**(undefined4 **)param_1[0xd])(puVar2 + 6);
    puVar2[0xf] = uVar3;
  }
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 10358 ; VA 0x00726172 ; Catch_All@00726172 */

void Catch_All_00726172(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10359 ; VA 0x00726190 ; FUN_00726190 */

undefined4 FUN_00726190(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aca10;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01674e20(0x40);
  uStack_8 = 0;
  FUN_00724c40(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 10360 ; VA 0x007261e4 ; Catch_All@007261e4 */

void Catch_All_007261e4(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10361 ; VA 0x00726200 ; FUN_00726200 */

undefined4 * FUN_00726200(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aca33;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x40);
  *puVar2 = std::
            _Func_impl_no_alloc<class_<lambda_a94a0a1906c0a96a9aa9e2584a09f398>,void,class_RBX::SharedString,class_G3D::CoordinateFrame,class_G3D::Vector3>
            ::vftable;
  puVar2[2] = *param_1;
  puVar2[3] = 0;
  puVar2[4] = 0;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[3] = param_1[1];
  puVar2[4] = param_1[2];
  puVar2[0xf] = 0;
  uStack_8 = 2;
  if ((undefined4 *)param_1[0xd] != (undefined4 *)0x0) {
    uVar3 = (*(code *)**(undefined4 **)param_1[0xd])(puVar2 + 6);
    puVar2[0xf] = uVar3;
  }
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 10362 ; VA 0x007262a2 ; Catch_All@007262a2 */

void Catch_All_007262a2(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10363 ; VA 0x007262c0 ; FUN_007262c0 */

undefined4 FUN_007262c0(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aca40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01674e20(0x40);
  uStack_8 = 0;
  FUN_00724d10(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 10364 ; VA 0x00726314 ; Catch_All@00726314 */

void Catch_All_00726314(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10365 ; VA 0x00726330 ; FUN_00726330 */

undefined4 * FUN_00726330(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aca63;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x40);
  *puVar2 = std::
            _Func_impl_no_alloc<class_<lambda_d99a02d8abd0c177beb66b74bbd030e7>,void,class_RBX::SharedString,class_G3D::CoordinateFrame,class_G3D::Vector3>
            ::vftable;
  puVar2[2] = *param_1;
  puVar2[3] = 0;
  puVar2[4] = 0;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[3] = param_1[1];
  puVar2[4] = param_1[2];
  puVar2[0xf] = 0;
  uStack_8 = 2;
  if ((undefined4 *)param_1[0xd] != (undefined4 *)0x0) {
    uVar3 = (*(code *)**(undefined4 **)param_1[0xd])(puVar2 + 6);
    puVar2[0xf] = uVar3;
  }
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 10366 ; VA 0x007263d2 ; Catch_All@007263d2 */

void Catch_All_007263d2(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10367 ; VA 0x007263f0 ; FUN_007263f0 */

undefined4 FUN_007263f0(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aca70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01674e20(0x40);
  uStack_8 = 0;
  FUN_007250d0(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 10368 ; VA 0x00726444 ; Catch_All@00726444 */

void Catch_All_00726444(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10369 ; VA 0x00726460 ; FUN_00726460 */

undefined4 * FUN_00726460(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aca8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  *puVar2 = std::_Func_impl_no_alloc<class_<lambda_ee81a1eb500ea1d1cd6c30e2827a211f>,void>::vftable;
  puVar2[1] = *param_1;
  puVar2[2] = 0;
  puVar2[3] = 0;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[2] = param_1[1];
  puVar2[3] = param_1[2];
  uStack_8 = 1;
  FUN_0054ef60(param_1 + 3);
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 10370 ; VA 0x007264f2 ; Catch_All@007264f2 */

void Catch_All_007264f2(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10371 ; VA 0x00726510 ; FUN_00726510 */

undefined4 FUN_00726510(undefined4 param_1)

{
  undefined4 extraout_ECX;
  
  FUN_01674e20(0x28);
  FUN_007251a0(param_1);
  return extraout_ECX;
}



/* FUNCTION 10372 ; VA 0x00726530 ; FUN_00726530 */

undefined4 * FUN_00726530(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017acab3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x40);
  *puVar2 = std::_Func_impl_no_alloc<class_<lambda_f0c80228f4fcb25338a5703a60ccc5f9>,void>::vftable;
  puVar2[2] = *param_1;
  puVar2[3] = 0;
  puVar2[4] = 0;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[3] = param_1[1];
  puVar2[4] = param_1[2];
  puVar2[0xf] = 0;
  uStack_8 = 2;
  if ((undefined4 *)param_1[0xd] != (undefined4 *)0x0) {
    uVar3 = (*(code *)**(undefined4 **)param_1[0xd])(puVar2 + 6);
    puVar2[0xf] = uVar3;
  }
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 10373 ; VA 0x007265d2 ; Catch_All@007265d2 */

void Catch_All_007265d2(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10374 ; VA 0x007265f0 ; FUN_007265f0 */

undefined4 FUN_007265f0(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017acac0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01674e20(0x40);
  uStack_8 = 0;
  FUN_00725220(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 10375 ; VA 0x00726644 ; Catch_All@00726644 */

void Catch_All_00726644(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10376 ; VA 0x00726660 ; FUN_00726660 */

void __thiscall
FUN_00726660(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x4ec4ec2 < (uint)param_1[1]) {
    FUN_0072dd40(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00726712:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00726712;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 10377 ; VA 0x007267c0 ; FUN_007267c0 */

void __thiscall
FUN_007267c0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  if (0xaaaaaa8 < (uint)param_1[1]) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  piVar3 = (int *)FUN_007254b0(param_5);
  param_1[1] = param_1[1] + 1;
  piVar3[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = piVar3;
    *(int **)*param_1 = piVar3;
    iVar4 = *param_1;
  }
  else {
    if (param_3 != '\0') {
      *param_4 = piVar3;
      if (param_4 == *(undefined4 **)*param_1) {
        *(int **)*param_1 = piVar3;
      }
      goto LAB_00726818;
    }
    param_4[2] = piVar3;
    iVar4 = *param_1;
    if (param_4 != *(undefined4 **)(iVar4 + 8)) goto LAB_00726818;
  }
  *(int **)(iVar4 + 8) = piVar3;
LAB_00726818:
  cVar1 = *(char *)(piVar3[1] + 0xc);
  piVar6 = piVar3;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = piVar3;
      return;
    }
    piVar2 = (int *)piVar6[1];
    piVar5 = *(int **)piVar2[1];
    if (piVar2 == piVar5) {
      piVar5 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar5 + 3) == '\0') {
LAB_00726871:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar5 + 3) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        piVar6 = *(int **)(piVar6[1] + 4);
      }
      else {
        if (piVar6 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar6 = piVar2;
        }
        *(undefined *)(piVar6[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar6[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar5 + 3) == '\0') goto LAB_00726871;
      if (piVar6 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar6 = piVar2;
      }
      *(undefined *)(piVar6[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
      iVar4 = *(int *)(piVar6[1] + 4);
      piVar2 = *(int **)(iVar4 + 8);
      *(int *)(iVar4 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar4;
      }
      piVar2[1] = *(int *)(iVar4 + 4);
      if (iVar4 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar5 = *(int **)(iVar4 + 4);
        if (iVar4 == *piVar5) {
          *piVar5 = (int)piVar2;
        }
        else {
          piVar5[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar4;
      *(int **)(iVar4 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar6[1] + 0xc);
  } while( true );
}



/* FUNCTION 10378 ; VA 0x00726920 ; FUN_00726920 */

undefined4 * __thiscall
FUN_00726920(int *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acad0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    param_3 = (int *)*param_1;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
  }
  else {
    piVar2 = (int *)*param_1;
    if (param_3 != (int *)*piVar2) {
      if (param_3 != piVar2) {
        ExceptionList = &pvStack_10;
        cVar1 = FUN_00558ea0(param_4,param_3 + 4);
        if (cVar1 != '\0') {
          piStack_18 = param_3;
          piVar2 = (int *)FUN_0056f560();
          cVar1 = FUN_00558ea0(*piVar2 + 0x10,param_4);
          if (cVar1 != '\0') {
            if (*(char *)(piStack_18[2] + 0xd) == '\0') {
              uVar4 = 1;
              param_3 = param_3;
            }
            else {
              uVar4 = 0;
              param_3 = piStack_18;
            }
            goto LAB_00726969;
          }
        }
        cVar1 = FUN_00558ea0(param_3 + 4,param_4);
        if (cVar1 != '\0') {
          piStack_18 = param_3;
          piVar2 = (int *)FUN_00551320();
          if ((*piVar2 == *param_1) || (cVar1 = FUN_00558ea0(param_4,piStack_18 + 4), cVar1 != '\0')
             ) {
            if (*(char *)(param_3[2] + 0xd) == '\0') {
              uVar4 = 1;
              param_3 = piStack_18;
            }
            else {
              uVar4 = 0;
              param_3 = param_3;
            }
            goto LAB_00726969;
          }
        }
LAB_00726a8a:
        uStack_8 = 0xffffffff;
        puVar3 = (undefined4 *)FUN_00726ef0(auStack_20,0,param_4,param_5);
        *param_2 = *puVar3;
        ExceptionList = pvStack_10;
        return param_2;
      }
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      cVar1 = FUN_00558ea0(piVar2[2] + 0x10,param_4);
      if (cVar1 == '\0') goto LAB_00726a8a;
      param_3 = *(int **)(*param_1 + 8);
      uVar4 = 0;
      goto LAB_00726969;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_00558ea0(param_4,param_3 + 4);
    if (cVar1 == '\0') goto LAB_00726a8a;
  }
  uVar4 = 1;
LAB_00726969:
  FUN_0055a140(param_2,uVar4,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10379 ; VA 0x00726abc ; Catch_All@00726abc */

void Catch_All_00726abc(void)

{
  int unaff_EBP;
  
  FUN_005763d0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10380 ; VA 0x00726ae0 ; FUN_00726ae0 */

undefined4 * __thiscall
FUN_00726ae0(int *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acae0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    param_3 = (int *)*param_1;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
  }
  else {
    piVar2 = (int *)*param_1;
    if (param_3 != (int *)*piVar2) {
      if (param_3 != piVar2) {
        ExceptionList = &pvStack_10;
        cVar1 = FUN_00558ea0(param_4,param_3 + 4);
        if (cVar1 != '\0') {
          piStack_18 = param_3;
          piVar2 = (int *)FUN_0056f560();
          cVar1 = FUN_00558ea0(*piVar2 + 0x10,param_4);
          if (cVar1 != '\0') {
            if (*(char *)(piStack_18[2] + 0xd) == '\0') {
              uVar4 = 1;
              param_3 = param_3;
            }
            else {
              uVar4 = 0;
              param_3 = piStack_18;
            }
            goto LAB_00726b29;
          }
        }
        cVar1 = FUN_00558ea0(param_3 + 4,param_4);
        if (cVar1 != '\0') {
          piStack_18 = param_3;
          piVar2 = (int *)FUN_00551320();
          if ((*piVar2 == *param_1) || (cVar1 = FUN_00558ea0(param_4,piStack_18 + 4), cVar1 != '\0')
             ) {
            if (*(char *)(param_3[2] + 0xd) == '\0') {
              uVar4 = 1;
              param_3 = piStack_18;
            }
            else {
              uVar4 = 0;
              param_3 = param_3;
            }
            goto LAB_00726b29;
          }
        }
LAB_00726c4a:
        uStack_8 = 0xffffffff;
        puVar3 = (undefined4 *)FUN_00727020(auStack_20,0,param_4,param_5);
        *param_2 = *puVar3;
        ExceptionList = pvStack_10;
        return param_2;
      }
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      cVar1 = FUN_00558ea0(piVar2[2] + 0x10,param_4);
      if (cVar1 == '\0') goto LAB_00726c4a;
      param_3 = *(int **)(*param_1 + 8);
      uVar4 = 0;
      goto LAB_00726b29;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_00558ea0(param_4,param_3 + 4);
    if (cVar1 == '\0') goto LAB_00726c4a;
  }
  uVar4 = 1;
LAB_00726b29:
  FUN_00726660(param_2,uVar4,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10381 ; VA 0x00726c7c ; Catch_All@00726c7c */

void Catch_All_00726c7c(void)

{
  int unaff_EBP;
  
  FUN_0072dd40(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10382 ; VA 0x00726ca0 ; FUN_00726ca0 */

undefined4 * __thiscall
FUN_00726ca0(undefined4 *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  int iVar1;
  undefined *puVar2;
  char cVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acaf0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    FUN_007130b0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piStack_20 = (int *)*param_1;
  if (param_3 == (int *)*piStack_20) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    if ((param_4[1] <= (uint)param_3[5]) &&
       ((param_4[1] < (uint)param_3[5] ||
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0, *param_4 < (uint)param_3[4]))))
    {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_007130b0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piStack_20) {
    iVar1 = piStack_20[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    if ((*(uint *)(iVar1 + 0x14) <= param_4[1]) &&
       ((*(uint *)(iVar1 + 0x14) < param_4[1] ||
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0,
        *(uint *)(iVar1 + 0x10) < *param_4)))) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_007130b0(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    puVar2 = &stack0xffffffd0;
    if ((param_4[1] <= (uint)param_3[5]) &&
       ((param_4[1] < (uint)param_3[5] ||
        (ExceptionList = &pvStack_10, puVar2 = &stack0xffffffd0, *param_4 < (uint)param_3[4])))) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar4 = (int *)FUN_0056f560();
      cVar3 = FUN_0072da80(*piVar4 + 0x10,param_4);
      puVar2 = puStack_14;
      if (cVar3 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_007130b0(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_007130b0(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    puStack_14 = puVar2;
    cVar3 = FUN_0072da80(param_3 + 4,param_4);
    if (cVar3 != '\0') {
      piStack_18 = param_3;
      FUN_00551320();
      piVar4 = piStack_18;
      if ((piStack_18 == piStack_20) ||
         (cVar3 = FUN_0072da80(param_4,piStack_18 + 4), cVar3 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_007130b0(param_2,1,piVar4,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_007130b0(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = (undefined4 *)FUN_00727150(auStack_24,0,param_4,param_5);
  *param_2 = *puVar5;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10383 ; VA 0x00726ed7 ; Catch_All@00726ed7 */

void Catch_All_00726ed7(void)

{
  int unaff_EBP;
  
  FUN_00576e30(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10384 ; VA 0x00726ef0 ; FUN_00726ef0 */

void __thiscall
FUN_00726ef0(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_4;
  puStack_c = &LAB_017acb00;
  pvStack_10 = ExceptionList;
  cVar3 = '\x01';
  uStack_8 = 0;
  puVar5 = (undefined4 *)((undefined4 *)*param_1)[1];
  puVar6 = (undefined4 *)*param_1;
  ExceptionList = &pvStack_10;
  while (*(char *)((int)puVar5 + 0xd) == '\0') {
    if ((char)param_3 == '\0') {
      cVar3 = FUN_00558ea0(uVar1,puVar5 + 4);
    }
    else {
      cVar3 = FUN_00558ea0(puVar5 + 4,uVar1);
      cVar3 = cVar3 == '\0';
    }
    puVar6 = puVar5;
    if (cVar3 == '\0') {
      puVar5 = (undefined4 *)puVar5[2];
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
  }
  param_3 = puVar6;
  if (cVar3 != '\0') {
    if (puVar6 == *(undefined4 **)*param_1) {
      cVar3 = '\x01';
      goto LAB_00726f7d;
    }
    FUN_0056f560();
  }
  puVar5 = param_3;
  cVar4 = FUN_00558ea0(param_3 + 4,uVar1);
  uVar2 = param_5;
  if (cVar4 == '\0') {
    FUN_0056cac0();
    FUN_01674ea0(uVar2,0x30);
    *param_2 = puVar5;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00726f7d:
  puVar5 = (undefined4 *)FUN_0055a140(&param_3,cVar3,puVar6,uVar1,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10385 ; VA 0x00726fff ; Catch_All@00726fff */

void Catch_All_00726fff(void)

{
  int unaff_EBP;
  
  FUN_005763d0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10386 ; VA 0x00727020 ; FUN_00727020 */

void __thiscall
FUN_00727020(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_4;
  puStack_c = &LAB_017acb10;
  pvStack_10 = ExceptionList;
  cVar3 = '\x01';
  uStack_8 = 0;
  puVar5 = (undefined4 *)((undefined4 *)*param_1)[1];
  puVar6 = (undefined4 *)*param_1;
  ExceptionList = &pvStack_10;
  while (*(char *)((int)puVar5 + 0xd) == '\0') {
    if ((char)param_3 == '\0') {
      cVar3 = FUN_00558ea0(uVar1,puVar5 + 4);
    }
    else {
      cVar3 = FUN_00558ea0(puVar5 + 4,uVar1);
      cVar3 = cVar3 == '\0';
    }
    puVar6 = puVar5;
    if (cVar3 == '\0') {
      puVar5 = (undefined4 *)puVar5[2];
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
  }
  param_3 = puVar6;
  if (cVar3 != '\0') {
    if (puVar6 == *(undefined4 **)*param_1) {
      cVar3 = '\x01';
      goto LAB_007270ad;
    }
    FUN_0056f560();
  }
  puVar5 = param_3;
  cVar4 = FUN_00558ea0(param_3 + 4,uVar1);
  uVar2 = param_5;
  if (cVar4 == '\0') {
    FUN_005f5950();
    FUN_01674ea0(uVar2,0x34);
    *param_2 = puVar5;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_007270ad:
  puVar5 = (undefined4 *)FUN_00726660(&param_3,cVar3,puVar6,uVar1,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10387 ; VA 0x0072712f ; Catch_All@0072712f */

void Catch_All_0072712f(void)

{
  int unaff_EBP;
  
  FUN_0072dd40(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10388 ; VA 0x00727150 ; FUN_00727150 */

void __thiscall
FUN_00727150(int *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  uint uVar1;
  uint *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  char cVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_4;
  puStack_c = &LAB_017acb20;
  pvStack_10 = ExceptionList;
  cVar5 = '\x01';
  puVar4 = (undefined4 *)*param_1;
  uStack_8 = 0;
  if (*(char *)((int)puVar4[1] + 0xd) == '\0') {
    uVar1 = param_4[1];
    puVar3 = (undefined4 *)puVar4[1];
    do {
      puVar4 = puVar3;
      if (param_3 == '\0') {
        if (((uint)puVar4[5] < uVar1) ||
           (((uint)puVar4[5] <= uVar1 && ((uint)puVar4[4] <= *param_4)))) {
          cVar5 = '\0';
          goto LAB_007271d3;
        }
        puVar3 = (undefined4 *)*puVar4;
        cVar5 = '\x01';
      }
      else {
        if ((uVar1 < (uint)puVar4[5]) ||
           ((uVar1 <= (uint)puVar4[5] && (*param_4 <= (uint)puVar4[4])))) {
          cVar5 = '\x01';
        }
        else {
          cVar5 = '\0';
        }
        if (cVar5 == '\0') {
LAB_007271d3:
          puVar3 = (undefined4 *)puVar4[2];
        }
        else {
          puVar3 = (undefined4 *)*puVar4;
        }
      }
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar4;
  if (cVar5 != '\0') {
    if (puVar4 == *(undefined4 **)*param_1) {
      cVar5 = '\x01';
      ExceptionList = &pvStack_10;
      goto LAB_007271f5;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  puVar3 = _param_3;
  if ((puVar2[1] < (uint)_param_3[5]) ||
     ((puVar2[1] <= (uint)_param_3[5] && (*puVar2 <= (uint)_param_3[4])))) {
    FUN_01674ea0(param_5,0x30);
    *param_2 = puVar3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_007271f5:
  puVar4 = (undefined4 *)FUN_007130b0(&param_3,cVar5,puVar4,puVar2,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10389 ; VA 0x0072726e ; Catch_All@0072726e */

void Catch_All_0072726e(void)

{
  int unaff_EBP;
  
  FUN_00576e30(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10390 ; VA 0x00727290 ; FUN_00727290 */

undefined4 * __thiscall
FUN_00727290(undefined4 *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  char cVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acb30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  cVar7 = '\x01';
  piVar2 = (int *)*param_1;
  piVar8 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    uVar3 = param_4[1];
    piVar6 = (int *)piVar2[1];
    do {
      piVar8 = piVar6;
      if (param_3 == '\0') {
        if (((uint)piVar8[5] < uVar3) ||
           (((uint)piVar8[5] <= uVar3 && ((uint)piVar8[4] <= *param_4)))) {
          cVar7 = '\0';
          goto LAB_0072731d;
        }
        piVar6 = (int *)*piVar8;
        cVar7 = '\x01';
      }
      else {
        if ((uVar3 < (uint)piVar8[5]) ||
           ((uVar3 <= (uint)piVar8[5] && (*param_4 <= (uint)piVar8[4])))) {
          cVar7 = '\x01';
        }
        else {
          cVar7 = '\0';
        }
        if (cVar7 == '\0') {
LAB_0072731d:
          piVar6 = (int *)piVar8[2];
        }
        else {
          piVar6 = (int *)*piVar8;
        }
      }
    } while (*(char *)((int)piVar6 + 0xd) == '\0');
  }
  piVar6 = piVar8;
  if (cVar7 != '\0') {
    if (piVar8 == (int *)*piVar2) {
      cVar7 = '\x01';
      goto LAB_00727343;
    }
    if (*(char *)((int)piVar8 + 0xd) == '\0') {
      piVar6 = (int *)*piVar8;
      if (*(char *)((int)piVar6 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar6[2] + 0xd);
        piVar2 = (int *)piVar6[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar6 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar8[1] + 0xd);
        piVar2 = (int *)piVar8[1];
        piVar6 = piVar8;
        while ((piVar4 = piVar2, cVar1 == '\0' && (piVar6 == (int *)*piVar4))) {
          cVar1 = *(char *)(piVar4[1] + 0xd);
          piVar2 = (int *)piVar4[1];
          piVar6 = piVar4;
        }
        if (*(char *)((int)piVar6 + 0xd) == '\0') {
          piVar6 = piVar4;
        }
      }
    }
    else {
      piVar6 = (int *)piVar8[2];
    }
  }
  if ((param_4[1] < (uint)piVar6[5]) ||
     ((param_4[1] <= (uint)piVar6[5] && (*param_4 <= (uint)piVar6[4])))) {
    *param_2 = piVar6;
    *(undefined *)(param_2 + 1) = 0;
    return param_2;
  }
LAB_00727343:
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_007267c0(&param_3,cVar7,piVar8,param_4,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10391 ; VA 0x0072740a ; Catch_All@0072740a */

void Catch_All_0072740a(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10392 ; VA 0x00727420 ; FUN_00727420 */

void FUN_00727420(int *param_1,int *param_2,int *param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  iVar1 = *param_1;
  iVar5 = *param_2;
  uVar3 = FUN_00734a30(iVar5 * 7 + *param_4);
  uVar4 = FUN_00734a30(iVar1 * 7 + *param_4);
  if (uVar3 < uVar4) {
    *param_2 = iVar1;
    *param_1 = iVar5;
    iVar5 = *param_2;
  }
  iVar1 = *param_3;
  uVar3 = FUN_00734a30(iVar5 * 7 + *param_4);
  uVar4 = FUN_00734a30(iVar1 * 7 + *param_4);
  if (uVar4 < uVar3) {
    *param_3 = iVar5;
    *param_2 = iVar1;
    iVar5 = *param_4;
    iVar2 = *param_1;
    uVar3 = FUN_00734a30(iVar2 * 7 + iVar5);
    uVar4 = FUN_00734a30(iVar1 * 7 + iVar5);
    if (uVar4 < uVar3) {
      *param_2 = iVar2;
      *param_1 = iVar1;
    }
  }
  return;
}



/* FUNCTION 10393 ; VA 0x00727510 ; FUN_00727510 */

void FUN_00727510(int *param_1,int *param_2,int *param_3,int param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = *(int *)(param_4 + 0xc);
  iVar2 = *param_2;
  if (*(ushort *)(iVar3 + iVar2 * 6) < *(ushort *)(iVar3 + *param_1 * 6)) {
    *param_2 = *param_1;
    *param_1 = iVar2;
    iVar2 = *param_2;
    iVar3 = *(int *)(param_4 + 0xc);
  }
  iVar1 = *param_3;
  if (*(ushort *)(iVar3 + iVar1 * 6) < *(ushort *)(iVar3 + iVar2 * 6)) {
    *param_3 = iVar2;
    *param_2 = iVar1;
    if (*(ushort *)(*(int *)(param_4 + 0xc) + iVar1 * 6) <
        *(ushort *)(*(int *)(param_4 + 0xc) + *param_1 * 6)) {
      *param_2 = *param_1;
      *param_1 = iVar1;
    }
  }
  return;
}



/* FUNCTION 10394 ; VA 0x00727590 ; FUN_00727590 */

void FUN_00727590(uint *param_1,int *param_2,int *param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piStack_14;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piVar7 = param_3 + -1;
  piStack_8 = param_2 + ((int)param_3 - (int)param_2 >> 3);
  iVar2 = (int)piVar7 - (int)param_2 >> 2;
  if (iVar2 < 0x29) {
    FUN_00727420(param_2,piStack_8,piVar7,param_4);
  }
  else {
    iVar2 = iVar2 + 1 >> 3;
    FUN_00727420(param_2,param_2 + iVar2,param_2 + iVar2 * 2,param_4);
    FUN_00727420(piStack_8 + -iVar2,piStack_8,piStack_8 + iVar2,param_4);
    FUN_00727420(piVar7 + iVar2 * -2,piVar7 + -iVar2,piVar7,param_4);
    FUN_00727420(param_2 + iVar2,piStack_8,piVar7 + -iVar2,param_4);
  }
  piVar7 = piStack_8 + 1;
  if (param_2 < piStack_8) {
    iVar2 = *param_4;
    do {
      uVar3 = FUN_00734a30(piStack_8[-1] * 7 + iVar2);
      uVar4 = FUN_00734a30(*piStack_8 * 7 + iVar2);
      if ((uVar3 < uVar4) || (uVar4 < uVar3)) break;
      piStack_8 = piStack_8 + -1;
    } while (param_2 < piStack_8);
  }
  piVar6 = piStack_8;
  piVar8 = piVar7;
  piStack_14 = piVar7;
  piStack_c = piVar7;
  piStack_10 = piStack_8;
  if (piVar7 < param_3) {
    iVar2 = *param_4;
    uVar3 = FUN_00734a30(*piStack_8 * 7 + iVar2);
    do {
      uVar4 = FUN_00734a30(*piVar7 * 7 + iVar2);
      piVar8 = piVar7;
      piStack_14 = piVar7;
      piStack_c = piVar7;
      if ((uVar4 < uVar3) || (uVar3 < uVar4)) break;
      piVar7 = piVar7 + 1;
      piVar8 = piVar7;
      piStack_14 = piVar7;
      piStack_c = piVar7;
    } while (piVar7 < param_3);
  }
joined_r0x007276f7:
  do {
    piVar5 = piStack_10;
    if (param_3 <= piVar8) {
joined_r0x00727760:
      while (piVar9 = piVar8, param_2 < piVar6) {
        piVar5 = piVar5 + -1;
        iVar2 = *piVar5;
        iVar1 = *param_4;
        uVar3 = FUN_00734a30(iVar2 * 7 + iVar1);
        uVar4 = FUN_00734a30(*piStack_8 * 7 + iVar1);
        piVar7 = piStack_c;
        if (uVar4 <= uVar3) {
          piVar6 = piStack_10;
          piVar9 = piStack_14;
          if (uVar4 < uVar3) break;
          piStack_8 = piStack_8 + -1;
          if (piStack_8 != piVar5) {
            iVar1 = *piStack_8;
            *piStack_8 = iVar2;
            *piVar5 = iVar1;
          }
        }
        piStack_10 = piStack_10 + -1;
        piVar8 = piStack_14;
        piVar6 = piStack_10;
      }
      if (piVar6 == param_2) {
        if (piVar9 == param_3) {
          param_1[1] = (uint)piVar7;
          *param_1 = (uint)piStack_8;
          return;
        }
        if (piVar7 != piVar9) {
          iVar2 = *piStack_8;
          *piStack_8 = *piVar7;
          *piVar7 = iVar2;
        }
        iVar2 = *piStack_8;
        piVar7 = piVar7 + 1;
        *piStack_8 = *piVar9;
        piStack_8 = piStack_8 + 1;
        *piVar9 = iVar2;
        piVar8 = piVar9 + 1;
        piStack_14 = piVar9 + 1;
        piStack_c = piVar7;
      }
      else {
        piVar6 = piVar6 + -1;
        piStack_10 = piVar6;
        if (piVar9 == param_3) {
          piStack_8 = piStack_8 + -1;
          if (piVar6 != piStack_8) {
            iVar2 = *piVar6;
            *piVar6 = *piStack_8;
            *piStack_8 = iVar2;
          }
          iVar2 = *piStack_8;
          piVar7 = piVar7 + -1;
          *piStack_8 = *piVar7;
          *piVar7 = iVar2;
          piVar8 = piVar9;
          piStack_c = piVar7;
        }
        else {
          iVar2 = *piVar9;
          *piVar9 = *piVar6;
          *piVar6 = iVar2;
          piVar8 = piVar9 + 1;
          piStack_14 = piVar9 + 1;
        }
      }
      goto joined_r0x007276f7;
    }
    iVar2 = *param_4;
    uVar3 = FUN_00734a30(*piVar8 * 7 + iVar2);
    uVar4 = FUN_00734a30(*piStack_8 * 7 + iVar2);
    piVar6 = piStack_10;
    if (uVar3 <= uVar4) {
      piStack_c = piVar7;
      piStack_14 = piVar8;
      if (uVar3 < uVar4) goto joined_r0x00727760;
      if (piVar7 != piVar8) {
        iVar2 = *piVar7;
        *piVar7 = *piVar8;
        *piVar8 = iVar2;
      }
      piVar7 = piVar7 + 1;
    }
    piVar8 = piVar8 + 1;
    piStack_14 = piVar8;
    piStack_c = piVar7;
  } while( true );
}



/* FUNCTION 10395 ; VA 0x00727880 ; FUN_00727880 */

void FUN_00727880(uint *param_1,int *param_2,int *param_3,int param_4)

{
  ushort uVar1;
  ushort uVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piVar5 = param_3 + -1;
  piVar8 = param_2 + ((int)param_3 - (int)param_2 >> 3);
  iVar3 = (int)piVar5 - (int)param_2 >> 2;
  if (iVar3 < 0x29) {
    FUN_00727510(param_2,piVar8,piVar5,param_4);
  }
  else {
    iVar3 = iVar3 + 1 >> 3;
    FUN_00727510(param_2,param_2 + iVar3,param_2 + iVar3 * 2,param_4);
    FUN_00727510(piVar8 + -iVar3,piVar8,piVar8 + iVar3,param_4);
    FUN_00727510(piVar5 + iVar3 * -2,piVar5 + -iVar3,piVar5,param_4);
    FUN_00727510(param_2 + iVar3,piVar8,piVar5 + -iVar3,param_4);
  }
  piVar5 = piVar8 + 1;
  if (param_2 < piVar8) {
    do {
      uVar1 = *(ushort *)(*(int *)(param_4 + 0xc) + piVar8[-1] * 6);
      uVar2 = *(ushort *)(*(int *)(param_4 + 0xc) + *piVar8 * 6);
      if ((uVar1 < uVar2) || (uVar1 >= uVar2 && uVar1 != uVar2)) break;
      piVar8 = piVar8 + -1;
    } while (param_2 < piVar8);
  }
  piVar6 = piVar5;
  piStack_10 = piVar5;
  piStack_8 = piVar5;
  piStack_c = piVar8;
  piVar9 = piVar8;
  if (piVar5 < param_3) {
    uVar1 = *(ushort *)(*(int *)(param_4 + 0xc) + *piVar8 * 6);
    do {
      uVar2 = *(ushort *)(*(int *)(param_4 + 0xc) + *piVar5 * 6);
      piVar6 = piVar5;
      piStack_10 = piVar5;
      piStack_8 = piVar5;
      if ((uVar2 < uVar1) || (uVar2 >= uVar1 && uVar2 != uVar1)) break;
      piVar5 = piVar5 + 1;
      piVar6 = piVar5;
      piStack_10 = piVar5;
      piStack_8 = piVar5;
    } while (piVar5 < param_3);
  }
joined_r0x00727997:
  do {
    piVar4 = piVar8;
    if (param_3 <= piVar5) {
joined_r0x007279e9:
      while (piVar7 = piVar6, param_2 < piVar8) {
        piVar4 = piVar4 + -1;
        uVar1 = *(ushort *)(*(int *)(param_4 + 0xc) + *piVar4 * 6);
        uVar2 = *(ushort *)(*(int *)(param_4 + 0xc) + *piVar9 * 6);
        piVar5 = piStack_10;
        if (uVar2 <= uVar1) {
          piVar7 = piStack_8;
          piStack_c = piVar8;
          if (uVar2 < uVar1) break;
          piVar9 = piVar9 + -1;
          if (piVar9 != piVar4) {
            iVar3 = *piVar9;
            *piVar9 = *piVar4;
            *piVar4 = iVar3;
          }
        }
        piStack_c = piVar8 + -1;
        piVar6 = piStack_8;
        piVar8 = piStack_c;
      }
      if (piVar8 == param_2) {
        if (piVar5 == param_3) {
          *param_1 = (uint)piVar9;
          param_1[1] = (uint)piVar7;
          return;
        }
        if (piVar7 != piVar5) {
          iVar3 = *piVar9;
          *piVar9 = *piVar7;
          *piVar7 = iVar3;
        }
        iVar3 = *piVar9;
        *piVar9 = *piVar5;
        *piVar5 = iVar3;
        piVar5 = piVar5 + 1;
        piVar6 = piVar7 + 1;
        piStack_10 = piVar5;
        piStack_8 = piVar7 + 1;
        piVar9 = piVar9 + 1;
      }
      else {
        piVar8 = piVar8 + -1;
        piStack_c = piVar8;
        if (piVar5 == param_3) {
          piVar9 = piVar9 + -1;
          if (piVar8 != piVar9) {
            iVar3 = *piVar8;
            *piVar8 = *piVar9;
            *piVar9 = iVar3;
          }
          piVar6 = piVar7 + -1;
          iVar3 = *piVar9;
          *piVar9 = piVar7[-1];
          *piVar6 = iVar3;
          piStack_8 = piVar6;
        }
        else {
          iVar3 = *piVar5;
          *piVar5 = *piVar8;
          piVar5 = piVar5 + 1;
          *piVar8 = iVar3;
          piVar6 = piVar7;
          piStack_10 = piVar5;
        }
      }
      goto joined_r0x00727997;
    }
    uVar1 = *(ushort *)(*(int *)(param_4 + 0xc) + *piVar9 * 6);
    uVar2 = *(ushort *)(*(int *)(param_4 + 0xc) + *piVar5 * 6);
    piVar8 = piStack_c;
    if (uVar2 <= uVar1) {
      piVar4 = piStack_c;
      piStack_8 = piVar6;
      piStack_10 = piVar5;
      if (uVar2 < uVar1) goto joined_r0x007279e9;
      if (piVar6 != piVar5) {
        iVar3 = *piVar6;
        *piVar6 = *piVar5;
        *piVar5 = iVar3;
      }
      piVar6 = piVar6 + 1;
    }
    piVar5 = piVar5 + 1;
    piStack_10 = piVar5;
    piStack_8 = piVar6;
  } while( true );
}



/* FUNCTION 10396 ; VA 0x00727ac0 ; FUN_00727ac0 */

void FUN_00727ac0(int param_1,int param_2,uint param_3,int *param_4,int *param_5)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar1 = (int)(param_3 - 1) >> 1;
  iVar4 = param_2;
  iVar5 = param_2;
  if (param_2 < iVar1) {
    do {
      uVar2 = FUN_00734a30(*(int *)(param_1 + 8 + iVar4 * 8) * 7 + *param_5);
      uVar3 = FUN_00734a30(*(int *)(param_1 + 4 + iVar4 * 8) * 7 + *param_5);
      iVar5 = (2 - (uint)(uVar2 < uVar3)) + iVar4 * 2;
      *(undefined4 *)(param_1 + iVar4 * 4) = *(undefined4 *)(param_1 + iVar5 * 4);
      iVar4 = iVar5;
    } while (iVar5 < iVar1);
  }
  if ((iVar5 == iVar1) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar5 * 4) = *(undefined4 *)(param_1 + -4 + param_3 * 4);
    iVar5 = param_3 - 1;
  }
  while( true ) {
    if (iVar5 <= param_2) {
      *(int *)(param_1 + iVar5 * 4) = *param_4;
      return;
    }
    iVar1 = iVar5 + -1 >> 1;
    iVar4 = *(int *)(param_1 + iVar1 * 4);
    uVar2 = FUN_00734a30(iVar4 * 7 + *param_5);
    uVar3 = FUN_00734a30(*param_4 * 7 + *param_5);
    if (uVar3 <= uVar2) break;
    *(int *)(param_1 + iVar5 * 4) = iVar4;
    iVar5 = iVar1;
  }
  *(int *)(param_1 + iVar5 * 4) = *param_4;
  return;
}



/* FUNCTION 10397 ; VA 0x00727be0 ; FUN_00727be0 */

void FUN_00727be0(int param_1,int param_2,uint param_3,int *param_4,int param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = (int)(param_3 - 1) >> 1;
  iVar2 = param_2;
  iVar3 = param_2;
  if (param_2 < iVar1) {
    do {
      iVar3 = (2 - (uint)(*(ushort *)
                           (*(int *)(param_5 + 0xc) + *(int *)(param_1 + 8 + iVar2 * 8) * 6) <
                         *(ushort *)
                          (*(int *)(param_5 + 0xc) + *(int *)(param_1 + 4 + iVar2 * 8) * 6))) +
              iVar2 * 2;
      *(undefined4 *)(param_1 + iVar2 * 4) = *(undefined4 *)(param_1 + iVar3 * 4);
      iVar2 = iVar3;
    } while (iVar3 < iVar1);
  }
  if ((iVar3 == iVar1) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar3 * 4) = *(undefined4 *)(param_1 + -4 + param_3 * 4);
    iVar3 = param_3 - 1;
  }
  while( true ) {
    if (iVar3 <= param_2) {
      *(int *)(param_1 + iVar3 * 4) = *param_4;
      return;
    }
    iVar1 = iVar3 + -1 >> 1;
    iVar2 = *(int *)(param_1 + iVar1 * 4);
    if (*(ushort *)(*(int *)(param_5 + 0xc) + *param_4 * 6) <=
        *(ushort *)(*(int *)(param_5 + 0xc) + iVar2 * 6)) break;
    *(int *)(param_1 + iVar3 * 4) = iVar2;
    iVar3 = iVar1;
  }
  *(int *)(param_1 + iVar3 * 4) = *param_4;
  return;
}



/* FUNCTION 10398 ; VA 0x00727cd0 ; FUN_00727cd0 */

void __thiscall FUN_00727cd0(int *param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uStack_c;
  
  uVar2 = param_2;
  iVar1 = param_1[1];
  iVar3 = *param_1;
  uVar4 = iVar1 - iVar3 >> 1;
  uStack_c = param_1[2] - iVar3 >> 1;
  if (param_2 <= uStack_c) {
    if (param_2 <= uVar4) {
      if (param_2 != uVar4) {
        param_1[1] = iVar3 + param_2 * 2;
      }
      return;
    }
    iVar3 = (param_2 - uVar4) * 2;
    FUN_0170d1f0(iVar1,0,iVar3);
    param_1[1] = iVar1 + iVar3;
    return;
  }
  if (0x7fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x7fffffff - (uStack_c >> 1) < uStack_c) {
    uStack_c = param_2;
  }
  else {
    uStack_c = (uStack_c >> 1) + uStack_c;
    if (uStack_c < param_2) {
      uStack_c = param_2;
    }
  }
  iVar3 = FUN_005540c0(uStack_c);
  FUN_0170d1f0(iVar3 + uVar4 * 2,0,(uVar2 - uVar4) * 2);
  iVar1 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(iVar3,iVar1,param_1[1] - iVar1);
  FUN_0072daf0(iVar3,uVar2,uStack_c);
  return;
}



/* FUNCTION 10399 ; VA 0x00727dd0 ; FUN_00727dd0 */

int __thiscall FUN_00727dd0(int *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  
  uVar5 = param_2;
  iVar2 = *param_1;
  uVar3 = (param_1[1] - iVar2) / 0x1c;
  iVar6 = (param_1[2] - iVar2) * -0x6db6db6d;
  uVar4 = (param_1[2] - iVar2) / 0x1c;
  if (param_2 <= uVar4) {
    if (param_2 <= uVar3) {
      if (param_2 != uVar3) {
        iVar6 = iVar2 + param_2 * 0x1c;
        param_1[1] = iVar6;
      }
      return iVar6;
    }
    iVar6 = FUN_0072d120(param_1[1],param_2 - uVar3);
    param_1[1] = iVar6;
    return iVar6;
  }
  if (0x9249249 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = param_2;
  if ((uVar4 <= 0x9249249 - (uVar4 >> 1)) && (uVar1 = (uVar4 >> 1) + uVar4, uVar1 < param_2)) {
    uVar1 = param_2;
  }
  param_2 = uVar1;
  iVar6 = FUN_0072e960(param_2);
  FUN_0072d120(iVar6 + uVar3 * 0x1c,uVar5 - uVar3);
  FUN_0072e4f0(*param_1,param_1[1],iVar6);
  iVar6 = FUN_0072db50(iVar6,uVar5,param_2);
  return iVar6;
}



/* FUNCTION 10400 ; VA 0x00727ee0 ; FUN_00727ee0 */

void __thiscall FUN_00727ee0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acb40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::CSGMesh>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10401 ; VA 0x00727f4e ; Catch_All@00727f4e */

void Catch_All_00727f4e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10402 ; VA 0x00727f70 ; FUN_00727f70 */

void __thiscall FUN_00727f70(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acb50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_G3D::GImage>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10403 ; VA 0x00727fde ; Catch_All@00727fde */

void Catch_All_00727fde(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10404 ; VA 0x00728000 ; FUN_00728000 */

void FUN_00728000(int *param_1,int *param_2,int param_3,int *param_4)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  int *piStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  int *piStack_10;
  int *piStack_c;
  uint uStack_8;
  
  iVar3 = (int)param_2 - (int)param_1;
  piVar7 = param_2;
  piVar9 = param_1;
  piVar6 = piStack_10;
  piVar2 = param_4;
  iVar8 = param_3;
  do {
    iVar3 = iVar3 >> 2;
    param_4 = piVar2;
    if (iVar3 < 0x21) {
LAB_0072808a:
      if (((1 < iVar3) && (piVar9 != piVar7)) && (piStack_1c = piVar9 + 1, piStack_1c != piVar7)) {
        uStack_8 = 4;
        do {
          piStack_c = (int *)*piStack_1c;
          iStack_20 = (int)piStack_c * 7;
          iStack_18 = iStack_20 + *piVar2;
          piStack_10 = piStack_1c;
          uVar4 = FUN_00734a30(*piVar9 * 7 + *piVar2);
          uVar5 = FUN_00734a30(iStack_18);
          if (uVar5 < uVar4) {
            FUN_0170cc70(piVar9 + 1,piVar9,uStack_8);
            *piVar9 = (int)piStack_c;
          }
          else {
            piStack_14 = (int *)(uStack_8 + -4 + (int)piVar9);
            piStack_24 = (int *)*piStack_14;
            uVar4 = FUN_00734a30((int)piStack_24 * 7 + *piVar2);
            uVar5 = FUN_00734a30(iStack_18);
            piVar7 = piStack_24;
            if (uVar5 < uVar4) {
              do {
                *piStack_10 = (int)piVar7;
                piStack_10 = piStack_14;
                piStack_14 = piStack_14 + -1;
                piVar7 = (int *)*piStack_14;
                uVar4 = FUN_00734a30((int)piVar7 * 7 + *piVar2);
                uVar5 = FUN_00734a30(iStack_20 + *piVar2);
                piVar9 = param_1;
              } while (uVar5 < uVar4);
            }
            *piStack_10 = (int)piStack_c;
          }
          uStack_8 = uStack_8 + 4;
          piStack_1c = piStack_1c + 1;
        } while (piStack_1c != param_2);
      }
      return;
    }
    if (iVar8 < 1) {
      if (0x20 < iVar3) {
        param_2 = (int *)((int)piVar7 - (int)piVar9);
        uStack_8 = (int)param_2 >> 2;
        piStack_10 = (int *)((int)param_2 >> 3);
        if (0 < (int)piStack_10) {
          piStack_1c = (int *)(uStack_8 - 1);
          piStack_c = (int *)((int)piStack_1c >> 1);
          do {
            piVar7 = param_4;
            iStack_18 = piVar9[(int)piStack_10 + -1];
            piVar6 = (int *)((int)piStack_10 + -1);
            param_1 = piVar6;
            piStack_10 = piVar6;
            if ((int)piVar6 < (int)piStack_c) {
              do {
                piStack_14 = (int *)((int)piVar6 * 2);
                uVar4 = FUN_00734a30(piVar9[(int)piVar6 * 2 + 2] * 7 + *piVar7);
                uVar5 = FUN_00734a30(piVar9[(int)piStack_14 + 1] * 7 + *piVar7);
                param_1 = (int *)((2 - (uint)(uVar4 < uVar5)) + (int)piStack_14);
                piVar9[(int)piVar6] = piVar9[(int)param_1];
                piVar6 = param_1;
              } while ((int)param_1 < (int)piStack_c);
            }
            if ((param_1 == piStack_c) && ((uStack_8 & 1) == 0)) {
              piVar9[(int)param_1] = piVar9[uStack_8 - 1];
              param_1 = piStack_1c;
            }
            piVar6 = (int *)((int)param_1 + -1 >> 1);
            piStack_14 = piVar6;
            if ((int)piStack_10 < (int)param_1) {
              iStack_20 = iStack_18 * 7;
              do {
                piStack_24 = (int *)piVar9[(int)piVar6];
                piStack_14 = piVar6;
                uVar4 = FUN_00734a30((int)piStack_24 * 7 + *piVar7);
                uVar5 = FUN_00734a30(iStack_20 + *piVar7);
                if (uVar5 <= uVar4) break;
                piVar9[(int)param_1] = (int)piStack_24;
                param_1 = piStack_14;
                piVar6 = (int *)((int)piStack_14 + -1 >> 1);
                bVar1 = (int)piStack_10 < (int)piStack_14;
                piStack_14 = piVar6;
              } while (bVar1);
            }
            piVar9[(int)param_1] = iStack_18;
            piVar6 = piStack_10;
          } while (0 < (int)piStack_10);
        }
        piStack_10 = piVar6;
        iVar3 = (int)param_2;
        if ((int)uStack_8 < 2) {
          return;
        }
        do {
          if (1 < (int)uStack_8) {
            param_2 = *(int **)((int)piVar9 + iVar3 + -4);
            *(int *)((int)piVar9 + iVar3 + -4) = *piVar9;
            FUN_00727ac0(piVar9,0,iVar3 + -4 >> 2,&param_2,param_4);
          }
          iVar3 = iVar3 + -4;
          uStack_8 = iVar3 >> 2;
        } while (1 < (int)uStack_8);
        return;
      }
      goto LAB_0072808a;
    }
    piStack_10 = piVar6;
    FUN_00727590(&piStack_28,piVar9,piVar7,piVar2);
    iVar8 = (iVar8 >> 1) + (iVar8 >> 2);
    if ((int)((int)piStack_28 - (int)piVar9 & 0xfffffffcU) <
        (int)((int)piVar7 - (int)piStack_24 & 0xfffffffcU)) {
      FUN_00728000(piVar9,piStack_28,iVar8,param_4);
      param_1 = piStack_24;
      piVar9 = piStack_24;
    }
    else {
      FUN_00728000(piStack_24,piVar7,iVar8,param_4);
      param_2 = piStack_28;
      piVar7 = piStack_28;
    }
    iVar3 = (int)piVar7 - (int)piVar9;
    piVar6 = piStack_10;
    piVar2 = param_4;
  } while( true );
}



/* FUNCTION 10405 ; VA 0x00728330 ; FUN_00728330 */

void FUN_00728330(int *param_1,int *param_2,int param_3,int param_4)

{
  ushort uVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  uint uStack_10;
  int iStack_c;
  int *piStack_8;
  
  iVar3 = (int)param_2 - (int)param_1;
  piVar6 = param_2;
  piVar5 = param_1;
  iVar8 = param_3;
  do {
    iVar3 = iVar3 >> 2;
    if (iVar3 < 0x21) {
LAB_007283ba:
      if (((1 < iVar3) && (piVar5 != piVar6)) && (piStack_1c = piVar5 + 1, piStack_1c != piVar6)) {
        piStack_20 = piVar5 + -1;
        iStack_c = 4;
        uStack_10 = param_4;
        do {
          piVar6 = param_2;
          iVar3 = *piStack_1c;
          iStack_18 = *(int *)(uStack_10 + 0xc);
          iStack_24 = iVar3 * 6;
          uVar1 = *(ushort *)(iStack_24 + iStack_18);
          uStack_14 = (uint)uVar1;
          if (uVar1 < *(ushort *)(iStack_18 + *piVar5 * 6)) {
            piStack_28 = (int *)iVar3;
            piStack_8 = piStack_1c;
            FUN_0170cc70(piVar5 + 1,piVar5,iStack_c);
            *piVar5 = iVar3;
          }
          else {
            iVar8 = *(int *)((int)piStack_20 + iStack_c);
            piVar5 = piStack_1c;
            piVar2 = (int *)((int)piStack_20 + iStack_c);
            piVar7 = piStack_1c;
            if (uVar1 < *(ushort *)(iStack_18 + iVar8 * 6)) {
              do {
                piVar5 = piVar2;
                *piVar7 = iVar8;
                iVar8 = piVar5[-1];
                piVar2 = piVar5 + -1;
                piVar7 = piVar5;
              } while (*(ushort *)(iStack_24 + *(int *)(uStack_10 + 0xc)) <
                       *(ushort *)(*(int *)(uStack_10 + 0xc) + iVar8 * 6));
            }
            *piVar5 = iVar3;
            piVar5 = param_1;
          }
          iStack_c = iStack_c + 4;
          piStack_1c = piStack_1c + 1;
        } while (piStack_1c != piVar6);
      }
      return;
    }
    if (iVar8 < 1) {
      if (0x20 < iVar3) {
        iVar8 = (int)piVar6 - (int)piVar5;
        uVar4 = iVar8 >> 2;
        iVar3 = iVar8 >> 3;
        if (0 < iVar3) {
          piStack_20 = (int *)(uVar4 - 1);
          iStack_c = (int)piStack_20 >> 1;
          do {
            iStack_18 = piVar5[iVar3 + -1];
            iVar3 = iVar3 + -1;
            uStack_14 = iVar3;
            while ((int)uStack_14 < iStack_c) {
              piStack_1c = (int *)(uStack_14 * 2);
              iVar9 = (2 - (uint)(*(ushort *)
                                   (*(int *)(param_4 + 0xc) + piVar5[uStack_14 * 2 + 2] * 6) <
                                 *(ushort *)
                                  (*(int *)(param_4 + 0xc) + piVar5[uStack_14 * 2 + 1] * 6))) +
                      (int)piStack_1c;
              piVar5[uStack_14] = piVar5[iVar9];
              uStack_14 = iVar9;
            }
            iVar9 = uStack_14;
            if ((uStack_14 == iStack_c) && ((uVar4 & 1) == 0)) {
              piVar5[uStack_14] = piVar5[uVar4 - 1];
              iVar9 = (int)piStack_20;
            }
            if (iVar3 < iVar9) {
              piStack_1c = (int *)(iStack_18 * 6);
              do {
                iVar10 = iVar9 + -1 >> 1;
                uStack_14 = piVar5[iVar10];
                piVar5 = param_1;
                if (*(ushort *)((int)piStack_1c + *(int *)(param_4 + 0xc)) <=
                    *(ushort *)(*(int *)(param_4 + 0xc) + uStack_14 * 6)) break;
                param_1[iVar9] = uStack_14;
                iVar9 = iVar10;
              } while (iVar3 < iVar10);
            }
            piVar5[iVar9] = iStack_18;
            piStack_8 = (int *)iVar3;
          } while (0 < iVar3);
        }
        uStack_10 = uVar4;
        if ((int)uVar4 < 2) {
          return;
        }
        do {
          if (1 < (int)uVar4) {
            param_2 = *(int **)((int)piVar5 + iVar8 + -4);
            *(int *)((int)piVar5 + iVar8 + -4) = *piVar5;
            FUN_00727be0(piVar5,0,iVar8 + -4 >> 2,&param_2,param_4);
          }
          iVar8 = iVar8 + -4;
          uVar4 = iVar8 >> 2;
        } while (1 < (int)uVar4);
        return;
      }
      goto LAB_007283ba;
    }
    FUN_00727880(&piStack_2c,piVar5,piVar6,param_4);
    iVar8 = (iVar8 >> 1) + (iVar8 >> 2);
    if ((int)((int)piStack_2c - (int)piVar5 & 0xfffffffcU) <
        (int)((int)piVar6 - (int)piStack_28 & 0xfffffffcU)) {
      FUN_00728330(piVar5,piStack_2c,iVar8,param_4);
      param_1 = piStack_28;
      piVar5 = piStack_28;
    }
    else {
      FUN_00728330(piStack_28,piVar6,iVar8,param_4);
      param_2 = piStack_2c;
      piVar6 = piStack_2c;
    }
    iVar3 = (int)piVar6 - (int)piVar5;
  } while( true );
}



/* FUNCTION 10406 ; VA 0x00728610 ; FUN_00728610 */

undefined FUN_00728610(undefined4 param_1,int param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined uVar7;
  uint in_stack_0000001c;
  int *in_stack_00000020;
  int aiStack_48 [5];
  uint uStack_34;
  undefined4 uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acb87;
  pvStack_10 = ExceptionList;
  uStack_30 = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(&uStack_30);
  uVar1 = uStack_30;
  if (cVar2 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x1c);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_0054ef60(aiStack_48);
    }
    *in_stack_00000020 = (int)puVar3;
    if (0xf < uStack_34) {
      uVar5 = uStack_34 + 1;
      iVar4 = aiStack_48[0];
      if (0xfff < uVar5) {
        iVar4 = *(int *)(aiStack_48[0] + -4);
        uVar5 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      uVar5 = auStack_2c[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_2c[0] - 4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uVar7 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      uVar5 = auStack_2c[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_2c[0] - 4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uVar7 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 10407 ; VA 0x007287b0 ; FUN_007287b0 */

undefined FUN_007287b0(undefined4 param_1,int param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined uVar7;
  uint in_stack_0000001c;
  int *in_stack_00000020;
  int aiStack_48 [5];
  uint uStack_34;
  undefined4 uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acbc7;
  pvStack_10 = ExceptionList;
  uStack_30 = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(&uStack_30);
  uVar1 = uStack_30;
  if (cVar2 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x1c);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_0054ef60(aiStack_48);
    }
    *in_stack_00000020 = (int)puVar3;
    if (0xf < uStack_34) {
      uVar5 = uStack_34 + 1;
      iVar4 = aiStack_48[0];
      if (0xfff < uVar5) {
        iVar4 = *(int *)(aiStack_48[0] + -4);
        uVar5 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      uVar5 = auStack_2c[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_2c[0] - 4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uVar7 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      uVar5 = auStack_2c[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_2c[0] - 4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uVar7 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 10408 ; VA 0x00728950 ; FUN_00728950 */

undefined FUN_00728950(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  int *in_stack_00000038;
  undefined4 *in_stack_0000003c;
  undefined auStack_88 [8];
  int *piStack_80;
  int aiStack_78 [9];
  int *piStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  undefined auStack_40 [36];
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017acc1d;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_50;
  uStack_50 = param_1;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_4c = param_2;
  piStack_48 = param_3;
  puStack_18 = auStack_40;
  uStack_1c = 0;
  uStack_8 = 2;
  uStack_7 = 0;
  if (in_stack_00000038 != (int *)0x0) {
    uStack_1c = (**(code **)*in_stack_00000038)(auStack_40);
  }
  uStack_8 = 3;
  cVar3 = FUN_00585a40(&uStack_50);
  if (cVar3 == '\0') {
    FUN_00729480(&uStack_50);
    uStack_8 = 4;
    puStack_18 = (undefined *)FUN_01674e20(0x38);
    uStack_8 = 5;
    if (puStack_18 == (undefined *)0x0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00729480(auStack_88);
    }
    *in_stack_0000003c = uVar4;
    if (piStack_54 != (int *)0x0) {
      (**(code **)(*piStack_54 + 0x10))(piStack_54 != aiStack_78);
      piStack_54 = (int *)0x0;
    }
    if (piStack_80 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_80[1] + -1;
      piStack_80[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_80)();
        LOCK();
        iVar2 = piStack_80[2] + -1;
        piStack_80[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_80 + 4))();
        }
      }
    }
    FUN_00729eb0();
    uVar5 = 1;
  }
  else {
    FUN_00729eb0();
    uVar5 = 0;
  }
  if (in_stack_00000038 != (int *)0x0) {
    (**(code **)(*in_stack_00000038 + 0x10))(in_stack_00000038 != (int *)&stack0x00000014);
    in_stack_00000038 = (int *)0x0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 10409 ; VA 0x00728ae0 ; FUN_00728ae0 */

undefined FUN_00728ae0(undefined4 param_1,int param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined uVar7;
  uint in_stack_0000001c;
  int *in_stack_00000020;
  int aiStack_48 [5];
  uint uStack_34;
  undefined4 uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acc57;
  pvStack_10 = ExceptionList;
  uStack_30 = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(&uStack_30);
  uVar1 = uStack_30;
  if (cVar2 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x1c);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_0054ef60(aiStack_48);
    }
    *in_stack_00000020 = (int)puVar3;
    if (0xf < uStack_34) {
      uVar5 = uStack_34 + 1;
      iVar4 = aiStack_48[0];
      if (0xfff < uVar5) {
        iVar4 = *(int *)(aiStack_48[0] + -4);
        uVar5 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      uVar5 = auStack_2c[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_2c[0] - 4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uVar7 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      uVar5 = auStack_2c[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_2c[0] - 4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uVar7 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 10410 ; VA 0x00728c80 ; FUN_00728c80 */

void __thiscall FUN_00728c80(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined **ppuVar5;
  int *piVar6;
  int *in_stack_00000028;
  int aiStack_90 [9];
  int *piStack_6c;
  int aiStack_68 [9];
  int *piStack_44;
  int aiStack_40 [9];
  int *piStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017accc2;
  pvStack_10 = ExceptionList;
  piStack_18 = aiStack_90;
  piStack_6c = (int *)0x0;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (in_stack_00000028 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    piStack_6c = (int *)(**(code **)*in_stack_00000028)(aiStack_90);
  }
  piStack_18 = aiStack_40;
  piStack_1c = (int *)0x0;
  uStack_8 = 3;
  if (piStack_6c != (int *)0x0) {
    piStack_1c = (int *)(**(code **)*piStack_6c)(aiStack_40);
  }
  piVar6 = piStack_6c;
  piVar3 = in_stack_00000028;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(aiStack_40);
  if (cVar2 == '\0') {
    piStack_18 = aiStack_68;
    piStack_44 = (int *)0x0;
    uStack_8 = 5;
    if (piStack_1c != (int *)0x0) {
      piStack_44 = (int *)(**(code **)*piStack_1c)(aiStack_68);
    }
    uStack_8 = 6;
    piVar3 = (int *)FUN_01674e20(0x28);
    uStack_8 = 7;
    piStack_18 = piVar3;
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3[9] = 0;
      uStack_8 = 8;
      if (piStack_44 != (int *)0x0) {
        iVar4 = (**(code **)*piStack_44)(piVar3);
        piVar3[9] = iVar4;
      }
    }
    param_1[2] = piVar3;
    if (piStack_44 != (int *)0x0) {
      (**(code **)(*piStack_44 + 0x10))(piStack_44 != aiStack_68);
      piStack_44 = (int *)0x0;
    }
    if (piStack_1c != (int *)0x0) {
      (**(code **)(*piStack_1c + 0x10))(piStack_1c != aiStack_40);
      piStack_1c = (int *)0x0;
    }
    bVar1 = true;
    piVar6 = piStack_6c;
    piVar3 = in_stack_00000028;
  }
  else {
    if (piStack_1c != (int *)0x0) {
      (**(code **)(*piStack_1c + 0x10))(piStack_1c != aiStack_40);
      piStack_1c = (int *)0x0;
      piVar6 = piStack_6c;
      piVar3 = in_stack_00000028;
    }
    bVar1 = false;
  }
  if (piVar6 != (int *)0x0) {
    (**(code **)(*piVar6 + 0x10))(piVar6 != aiStack_90);
    piVar3 = in_stack_00000028;
  }
  ppuVar5 = &PTR_FUN_018f8fe8;
  if (!bVar1) {
    ppuVar5 = (undefined **)0x0;
  }
  *puStack_14 = ppuVar5;
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x10))(piVar3 != (int *)&stack0x00000004);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10411 ; VA 0x00728e50 ; FUN_00728e50 */

void FUN_00728e50(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  *param_2 = 0;
  param_2[1] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  iVar2 = param_3[2];
  param_2[2] = iVar2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  uVar3 = param_3[4];
  uVar4 = param_3[5];
  uVar5 = param_3[6];
  param_2[3] = param_3[3];
  param_2[4] = uVar3;
  param_2[5] = uVar4;
  param_2[6] = uVar5;
  uVar3 = param_3[8];
  uVar4 = param_3[9];
  uVar5 = param_3[10];
  param_2[7] = param_3[7];
  param_2[8] = uVar3;
  param_2[9] = uVar4;
  param_2[10] = uVar5;
  uVar3 = param_3[0xc];
  uVar4 = param_3[0xd];
  uVar5 = param_3[0xe];
  param_2[0xb] = param_3[0xb];
  param_2[0xc] = uVar3;
  param_2[0xd] = uVar4;
  param_2[0xe] = uVar5;
  *(undefined8 *)(param_2 + 0xf) = *(undefined8 *)(param_3 + 0xf);
  param_2[0x11] = param_3[0x11];
  return;
}



/* FUNCTION 10412 ; VA 0x00728eb0 ; FUN_00728eb0 */

int FUN_00728eb0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00cfb1a0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 10413 ; VA 0x00728ef0 ; FUN_00728ef0 */

int * FUN_00728ef0(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00cfe630(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 10414 ; VA 0x00728fe0 ; FUN_00728fe0 */

void __thiscall FUN_00728fe0(int param_1,undefined4 *param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  bool bVar7;
  
  uVar4 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar3 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3 = (int *)*puVar1;
    }
    if (piVar3 != (int *)0x0) {
      do {
        if (param_3 == piVar3[1]) {
          piVar2 = piVar3 + 2;
          uVar6 = 0x18;
          piVar5 = param_4;
          while (*piVar5 == *piVar2) {
            piVar5 = piVar5 + 1;
            piVar2 = piVar2 + 1;
            bVar7 = uVar6 < 4;
            uVar6 = uVar6 - 4;
            if (bVar7) {
              *param_2 = piVar3;
              return;
            }
          }
        }
        else if ((uint)piVar3[1] % *(uint *)(param_1 + 4) != uVar4) {
          *param_2 = 0;
          return;
        }
        piVar3 = (int *)*piVar3;
      } while (piVar3 != (int *)0x0);
      *param_2 = 0;
      return;
    }
  }
  *param_2 = piVar3;
  return;
}



/* FUNCTION 10415 ; VA 0x00729090 ; FUN_00729090 */

void __thiscall FUN_00729090(int param_1,undefined4 *param_2,uint param_3,float *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar2 = (int *)0x0;
    }
    else {
      piVar2 = (int *)*puVar1;
    }
    if (piVar2 != (int *)0x0) {
      do {
        if (param_3 == piVar2[1]) {
          if ((((NAN(*param_4) || NAN((float)piVar2[2])) != (*param_4 == (float)piVar2[2])) &&
              ((NAN(param_4[1]) || NAN((float)piVar2[3])) != (param_4[1] == (float)piVar2[3]))) &&
             ((NAN(param_4[2]) || NAN((float)piVar2[4])) != (param_4[2] == (float)piVar2[4])))
          break;
        }
        else if ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar2 = (int *)*piVar2;
        if (piVar2 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar2;
  return;
}



/* FUNCTION 10416 ; VA 0x00729140 ; FUN_00729140 */

bool FUN_00729140(undefined4 param_1)

{
  short sVar1;
  
  sVar1 = FUN_01726720(&param_1);
  return sVar1 < 1;
}



/* FUNCTION 10417 ; VA 0x00729170 ; FUN_00729170 */

void __thiscall FUN_00729170(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_01674e20(0x24,param_1);
  if (puVar4 != (undefined4 *)0x0) {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::
              _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>
              ::vftable;
    puVar4[7] = 0;
    puVar4[8] = 0;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar4[3] = *param_3;
    puVar4[4] = uVar1;
    puVar4[5] = uVar2;
    puVar4[6] = uVar3;
    *(undefined8 *)(puVar4 + 7) = *(undefined8 *)(param_3 + 4);
    param_3[4] = 0;
    param_3[5] = 0xf;
    *(undefined *)param_3 = 0;
    *param_2 = (int)(puVar4 + 3);
    param_2[1] = (int)puVar4;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 10418 ; VA 0x007291f0 ; FUN_007291f0 */

void FUN_007291f0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = param_2[1];
  uVar1 = *param_2;
  *param_1 = 0;
  param_1[1] = 0;
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
    iVar2 = param_2[1];
  }
  *param_1 = uVar1;
  param_1[1] = iVar2;
  return;
}



/* FUNCTION 10419 ; VA 0x00729220 ; FUN_00729220 */

void * __thiscall FUN_00729220(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvVar4;
  int *piVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puVar6 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
      piVar5 = *(int **)(param_1 + 0x30);
    }
    puVar3 = (undefined4 *)puVar6[1];
    puVar6 = (undefined4 *)*puVar6;
    uStack_8 = 0;
    pvVar4 = pvStack_10;
    for (; puVar6 != puVar3; puVar6 = puVar6 + 2) {
      if (puVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_0072b740(*puVar6,puVar6[1]);
      pvVar4 = (void *)FUN_00729220(param_2);
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 10420 ; VA 0x007292f0 ; FUN_007292f0 */

void * __thiscall FUN_007292f0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvVar4;
  int *piVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puVar6 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
      piVar5 = *(int **)(param_1 + 0x30);
    }
    puVar3 = (undefined4 *)puVar6[1];
    puVar6 = (undefined4 *)*puVar6;
    uStack_8 = 0;
    pvVar4 = pvStack_10;
    for (; puVar6 != puVar3; puVar6 = puVar6 + 2) {
      if (puVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_0072c080(*puVar6,puVar6[1]);
      pvVar4 = (void *)FUN_007292f0(param_2);
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 10421 ; VA 0x007293c0 ; FUN_007293c0 */

undefined4 * __thiscall FUN_007293c0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac8c3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[0xd] = 0;
  uStack_8 = 1;
  if ((undefined4 *)param_2[0xd] != (undefined4 *)0x0) {
    uVar5 = (*(code *)**(undefined4 **)param_2[0xd])(param_1 + 4);
    param_1[0xd] = uVar5;
  }
  iVar2 = param_2[0xe];
  param_1[0xe] = iVar2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  uVar5 = param_2[0x10];
  uVar3 = param_2[0x11];
  uVar4 = param_2[0x12];
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = uVar5;
  param_1[0x11] = uVar3;
  param_1[0x12] = uVar4;
  uVar5 = param_2[0x14];
  uVar3 = param_2[0x15];
  uVar4 = param_2[0x16];
  param_1[0x13] = param_2[0x13];
  param_1[0x14] = uVar5;
  param_1[0x15] = uVar3;
  param_1[0x16] = uVar4;
  uVar5 = param_2[0x18];
  uVar3 = param_2[0x19];
  uVar4 = param_2[0x1a];
  param_1[0x17] = param_2[0x17];
  param_1[0x18] = uVar5;
  param_1[0x19] = uVar3;
  param_1[0x1a] = uVar4;
  *(undefined8 *)(param_1 + 0x1b) = *(undefined8 *)(param_2 + 0x1b);
  param_1[0x1d] = param_2[0x1d];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10422 ; VA 0x00729480 ; FUN_00729480 */

undefined4 * __thiscall FUN_00729480(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ac8c3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[0xd] = 0;
  uStack_8 = 1;
  if ((undefined4 *)param_2[0xd] != (undefined4 *)0x0) {
    uVar2 = (*(code *)**(undefined4 **)param_2[0xd])(param_1 + 4);
    param_1[0xd] = uVar2;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10423 ; VA 0x00729510 ; FUN_00729510 */

int * __thiscall FUN_00729510(int *param_1,undefined4 *param_2,uint param_3,int param_4)

{
  int iVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017acd0a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bf148;
    param_1[4] = (int)&DAT_018bf150;
    param_1[0x1a] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x18;
  param_1[2] = 0;
  param_1[3] = 0;
  FUN_00554f20(param_1 + 6,0);
  *(undefined ***)((int)param_1 + *(int *)(param_1[4] + 4) + 0x10) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(param_1[4] + 4) + 0xc + (int)param_1) = *(int *)(param_1[4] + 4) + -8;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x20;
  uStack_8 = 5;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x68;
  FUN_0054ee60();
  param_1[6] = (int)std::
                    basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                    ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  uVar6 = (~param_3 & 1) << 2;
  uVar4 = uVar6 | 2;
  if ((param_3 & 2) != 0) {
    uVar4 = uVar6;
  }
  uVar6 = uVar4 | 8;
  if ((param_3 & 8) == 0) {
    uVar6 = uVar4;
  }
  uVar4 = uVar6 | 0x10;
  if ((param_3 & 4) == 0) {
    uVar4 = uVar6;
  }
  uVar6 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (uVar6 < 0x80000000) {
    if ((uVar6 == 0) || (((byte)uVar4 & 6) == 6)) {
      param_1[0x14] = 0;
    }
    else {
      iVar3 = FUN_00554060(uVar6);
      FUN_0170c6f0(iVar3,param_2,uVar6);
      param_1[0x14] = uVar6 + iVar3;
      if ((uVar4 & 4) == 0) {
        *(int *)param_1[9] = iVar3;
        *(int *)param_1[0xd] = iVar3;
        *(uint *)param_1[0x11] = uVar6;
      }
      if ((uVar4 & 2) == 0) {
        iVar1 = param_1[0x14];
        iVar7 = iVar3;
        if ((uVar4 & 0x18) != 0) {
          iVar7 = iVar1;
        }
        *(int *)param_1[10] = iVar3;
        *(int *)param_1[0xe] = iVar7;
        *(int *)param_1[0x12] = iVar1 - iVar7;
        if ((uVar4 & 4) != 0) {
          *(int *)param_1[9] = iVar3;
          *(undefined4 *)param_1[0xd] = 0;
          *(int *)param_1[0x11] = iVar3;
        }
      }
      uVar4 = uVar4 | 1;
    }
    param_1[0x15] = uVar4;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_010c5e30();
  pcVar2 = (code *)swi(3);
  piVar5 = (int *)(*pcVar2)();
  return piVar5;
}



/* FUNCTION 10424 ; VA 0x00729710 ; FUN_00729710 */

int * __thiscall FUN_00729710(int *param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x7fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_005540c0(param_2);
    *param_1 = iVar2;
    iVar1 = param_2 * 2;
    param_1[1] = iVar2;
    param_1[2] = *param_1 + iVar1;
    iVar2 = *param_1;
    FUN_0170d1f0(iVar2,0,iVar1);
    param_1[1] = iVar1 + iVar2;
  }
  return param_1;
}



/* FUNCTION 10425 ; VA 0x00729780 ; FUN_00729780 */

uint * __thiscall FUN_00729780(uint *param_1,uint param_2,undefined4 *param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x15555555 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar5 = param_2 * 0xc;
    if (uVar5 < 0x1000) {
      if (uVar5 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar5);
      }
    }
    else {
      uVar2 = uVar5 + 0x23;
      if (uVar2 <= uVar5) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar5;
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar4 = *param_3;
        puVar4[1] = 0;
        puVar4[2] = 0;
        if (param_3[2] != 0) {
          LOCK();
          piVar1 = (int *)(param_3[2] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        puVar4[1] = param_3[1];
        puVar4[2] = param_3[2];
        puVar4 = puVar4 + 3;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar4;
  }
  return param_1;
}



/* FUNCTION 10426 ; VA 0x00729860 ; FUN_00729860 */

int * __thiscall FUN_00729860(int *param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x24924924 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_0072e8f0(param_2);
    *param_1 = iVar2;
    param_1[1] = iVar2;
    iVar1 = param_2 * 7;
    param_1[2] = *param_1 + iVar1;
    iVar2 = *param_1;
    if (param_2 != 0) {
      FUN_0170d1f0(iVar2,0,iVar1);
      iVar2 = iVar2 + iVar1;
    }
    param_1[1] = iVar2;
  }
  return param_1;
}



/* FUNCTION 10427 ; VA 0x007298d0 ; FUN_007298d0 */

uint * __thiscall FUN_007298d0(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x5d1745d < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar4 = param_2 * 0x2c;
    if (uVar4 < 0x1000) {
      if (uVar4 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar4);
      }
    }
    else {
      uVar1 = uVar4 + 0x23;
      if (uVar1 <= uVar4) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar4;
    puVar3 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      iVar2 = (int)puVar3 + 0xe;
      do {
        puVar3[1] = 0;
        puVar3[2] = 0;
        puVar3[3] = 0;
        puVar3[4] = 0;
        puVar3[5] = 0;
        puVar3[6] = 0;
        puVar3[7] = 0;
        puVar3[8] = 0;
        puVar3[9] = 0;
        puVar3[10] = 0;
        *puVar3 = 0;
        puVar3 = puVar3 + 0xb;
        *(undefined4 *)(iVar2 + -10) = 0;
        *(undefined4 *)(iVar2 + -6) = 0;
        *(undefined4 *)(iVar2 + -2) = 0;
        *(undefined4 *)(iVar2 + 2) = 0;
        *(undefined4 *)(iVar2 + 6) = 0;
        *(undefined4 *)(iVar2 + 10) = 0;
        *(undefined4 *)(iVar2 + 0xe) = 0;
        *(undefined4 *)(iVar2 + 0x12) = 0;
        *(undefined4 *)(iVar2 + 0x16) = 0;
        *(undefined4 *)(iVar2 + 0x1a) = 0;
        param_2 = param_2 - 1;
        iVar2 = iVar2 + 0x2c;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar3;
  }
  return param_1;
}



/* FUNCTION 10428 ; VA 0x00729a20 ; FUN_00729a20 */

undefined4 * __thiscall FUN_00729a20(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acdf7;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  piStack_2c = (int *)0x0;
  uStack_8 = 2;
  puStack_28 = param_1;
  FUN_00729780(0,&uStack_34,&uStack_11);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_2c[2] + -1;
    piStack_2c[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_2c + 4))();
    }
  }
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x14] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  puVar6 = param_1 + 0x1e;
  uStack_8._0_1_ = 8;
  *puVar6 = 0;
  param_1[0x1f] = 0;
  piStack_20 = puVar6;
  uVar5 = FUN_0072dab0();
  *puVar6 = uVar5;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  puVar6 = param_1 + 0x22;
  uStack_8._0_1_ = 10;
  *puVar6 = 0;
  param_1[0x23] = 0;
  piStack_20 = puVar6;
  uVar5 = FUN_00575b10();
  *puVar6 = uVar5;
  puVar6 = param_1 + 0x24;
  uStack_8._0_1_ = 0xb;
  *puVar6 = 0;
  param_1[0x25] = 0;
  piStack_20 = puVar6;
  uVar5 = FUN_00575b10();
  *puVar6 = uVar5;
  puVar6 = param_1 + 0x26;
  uStack_8._0_1_ = 0xc;
  *puVar6 = 0;
  param_1[0x27] = 0;
  piStack_20 = puVar6;
  uVar5 = FUN_00575b10();
  *puVar6 = uVar5;
  uStack_8._0_1_ = 0xd;
  if ((-(uint)(param_2 != (undefined4 *)0x0) & (int)param_2 + 0xcU) == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_005c2760();
  }
  FUN_0060dcd0(param_1 + 0x28,uVar5);
  param_1[0x13] = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 1;
  uStack_30 = 0;
  piStack_2c = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  puVar6 = (undefined4 *)FUN_0151d9e0(auStack_1c,&uStack_30,4,&uStack_4c);
  uVar5 = *puVar6;
  uVar2 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  param_1[0x16] = uVar5;
  piStack_20 = (int *)param_1[0x17];
  param_1[0x17] = uVar2;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_20[2] + -1;
      piStack_20[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  piStack_20 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_20[2] + -1;
      piStack_20[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  piStack_20 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar3 = piStack_20[2] + -1;
      piStack_20[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  piStack_18 = (int *)((int)param_2 + 0x2b8);
  uStack_8._0_1_ = 0x10;
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 0x11;
  piStack_2c = (int *)uVar5;
  piStack_20 = (int *)FUN_01674e20(0x1c);
  if (piStack_20 == (undefined4 *)0x0) {
    piStack_20 = (undefined4 *)0x0;
  }
  else {
    *piStack_20 = 0;
    piStack_20[1] = 1;
    piStack_20[2] = (int)FUN_00730b60;
    piStack_20[3] = (int)_guard_check_icall;
    piStack_20[4] = 0;
    piStack_20[5] = (int)piStack_18;
    piStack_20[6] = (int)param_1;
  }
  FUN_016797d0(piStack_20);
  param_2 = piStack_20;
  if (piStack_20 != (undefined4 *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  uStack_24 = 1;
  uStack_8._0_1_ = 0x12;
  FUN_01675290(uVar5);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  cVar4 = FUN_01679300(&param_2);
  if (cVar4 != '\0') {
    FUN_01679490();
    FUN_016791c0(&param_2);
  }
  if (param_2 != (undefined4 *)0x0) {
    piVar1 = param_2 + 1;
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(param_2);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10429 ; VA 0x00729dd0 ; FUN_00729dd0 */

void __fastcall FUN_00729dd0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0xc);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar4 = *(int **)(param_1 + 8);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00729e3d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 10430 ; VA 0x00729e50 ; FUN_00729e50 */

int __fastcall FUN_00729e50(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_0056cd30();
  piVar3 = *(int **)(param_1 + 0x34);
  if (piVar3 != (int *)0x0) {
    iVar4 = (**(code **)(*piVar3 + 0x10))(piVar3 != (int *)(param_1 + 0x10));
    *(undefined4 *)(param_1 + 0x34) = 0;
  }
  piVar3 = *(int **)(param_1 + 8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00729ea2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 10431 ; VA 0x00729eb0 ; FUN_00729eb0 */

void __fastcall FUN_00729eb0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x34);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x10))(piVar2 != (int *)(param_1 + 0x10));
    *(undefined4 *)(param_1 + 0x34) = 0;
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00729efa. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 10432 ; VA 0x00729f00 ; FUN_00729f00 */

void __fastcall FUN_00729f00(int *param_1)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  piVar5 = *(int **)(iVar1 + 4);
  uStack_8 = 0;
  iVar4 = iVar1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (*(char *)((int)piVar5 + 0xd) == '\0') {
    do {
      FUN_00713520(piVar5[2]);
      piVar2 = (int *)*piVar5;
      FUN_01674ea0(piVar5,0x30);
      piVar5 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar4 = *param_1;
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  *(int *)(iVar4 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10433 ; VA 0x00729fa0 ; FUN_00729fa0 */

void __fastcall FUN_00729fa0(int *param_1)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  piVar5 = *(int **)(iVar1 + 4);
  uStack_8 = 0;
  iVar4 = iVar1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (*(char *)((int)piVar5 + 0xd) == '\0') {
    do {
      FUN_00601e60(piVar5[2]);
      piVar2 = (int *)*piVar5;
      FUN_01674ea0(piVar5,0x18);
      piVar5 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar4 = *param_1;
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  *(int *)(iVar4 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10434 ; VA 0x0072a040 ; FUN_0072a040 */

void __fastcall FUN_0072a040(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar1 = (int *)param_1[1];
  for (piVar3 = (int *)*param_1; piVar3 != piVar1; piVar3 = piVar3 + 10) {
    piVar2 = (int *)piVar3[9];
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0x10))(piVar2 != piVar3);
      piVar3[9] = 0;
    }
  }
  return;
}



/* FUNCTION 10435 ; VA 0x0072a080 ; FUN_0072a080 */

void __fastcall FUN_0072a080(int *param_1)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  piVar5 = *(int **)(iVar1 + 4);
  uStack_8 = 0;
  iVar4 = iVar1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (*(char *)((int)piVar5 + 0xd) == '\0') {
    do {
      FUN_00713520(piVar5[2]);
      piVar2 = (int *)*piVar5;
      FUN_01674ea0(piVar5,0x30);
      piVar5 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar4 = *param_1;
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  *(int *)(iVar4 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10436 ; VA 0x0072a090 ; FUN_0072a090 */

void __fastcall FUN_0072a090(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0x28);
  }
  return;
}



/* FUNCTION 10437 ; VA 0x0072a0b0 ; FUN_0072a0b0 */

void __fastcall FUN_0072a0b0(int *param_1)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  piVar5 = *(int **)(iVar1 + 4);
  uStack_8 = 0;
  iVar4 = iVar1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (*(char *)((int)piVar5 + 0xd) == '\0') {
    do {
      FUN_00601e60(piVar5[2]);
      piVar2 = (int *)*piVar5;
      FUN_01674ea0(piVar5,0x18);
      piVar5 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar4 = *param_1;
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  *(int *)(iVar4 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10438 ; VA 0x0072a0c0 ; FUN_0072a0c0 */

void __fastcall FUN_0072a0c0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 10439 ; VA 0x0072a140 ; FUN_0072a140 */

void __fastcall FUN_0072a140(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 10440 ; VA 0x0072a150 ; thunk_FUN_006f8c50 */

void __fastcall thunk_FUN_006f8c50(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x20);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 10441 ; VA 0x0072a160 ; FUN_0072a160 */

void __fastcall FUN_0072a160(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffffe;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 10442 ; VA 0x0072a1c0 ; FUN_0072a1c0 */

void __fastcall FUN_0072a1c0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x1c) * 0x1c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 10443 ; VA 0x0072a240 ; thunk_FUN_0072e310 */

void __fastcall thunk_FUN_0072e310(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x2c) * 0x2c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 10444 ; VA 0x0072a250 ; FUN_0072a250 */

void __fastcall FUN_0072a250(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffe;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0072e2a0();
  return;
}



/* FUNCTION 10445 ; VA 0x0072a2b0 ; FUN_0072a2b0 */

/* WARNING: Removing unreachable block (ram,0x0072a3e3) */

int * __thiscall FUN_0072a2b0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int aiStack_60 [9];
  int *piStack_3c;
  int aiStack_38 [9];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ace18;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (*(undefined4 **)(param_2 + 0x24) != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    piStack_14 = (int *)(**(code **)**(undefined4 **)(param_2 + 0x24))(aiStack_38);
  }
  uStack_8 = 1;
  if ((piStack_14 != aiStack_38) && (piVar1 = (int *)param_1[9], piVar1 != param_1)) {
    param_1[9] = (int)piStack_14;
    piStack_14 = piVar1;
    goto LAB_0072a3fc;
  }
  piStack_3c = (int *)0x0;
  if (piStack_14 != (int *)0x0) {
    piVar1 = piStack_14;
    if (piStack_14 == aiStack_38) {
      piStack_3c = (int *)(**(code **)(*piStack_14 + 4))(aiStack_60);
      if (piStack_14 == (int *)0x0) goto LAB_0072a35d;
      (**(code **)(*piStack_14 + 0x10))(piStack_14 != aiStack_38);
      piVar1 = piStack_3c;
    }
    piStack_3c = piVar1;
    piStack_14 = (int *)0x0;
  }
LAB_0072a35d:
  piVar1 = (int *)param_1[9];
  if (piVar1 != (int *)0x0) {
    if (piVar1 == param_1) {
      piStack_14 = (int *)(**(code **)(*piVar1 + 4))(aiStack_38);
      piVar1 = (int *)param_1[9];
      if (piVar1 == (int *)0x0) goto LAB_0072a3a8;
      (**(code **)(*piVar1 + 0x10))(piVar1 != param_1);
      piVar1 = piStack_14;
    }
    piStack_14 = piVar1;
    param_1[9] = 0;
  }
LAB_0072a3a8:
  if (piStack_3c != (int *)0x0) {
    if (piStack_3c == aiStack_60) {
      iVar2 = (**(code **)(*piStack_3c + 4))(param_1);
      param_1[9] = iVar2;
      if (piStack_3c != (int *)0x0) {
        (**(code **)(*piStack_3c + 0x10))(piStack_3c != aiStack_60);
        piStack_3c = (int *)0x0;
      }
    }
    else {
      param_1[9] = (int)piStack_3c;
    }
  }
LAB_0072a3fc:
  if (piStack_14 != (int *)0x0) {
    (**(code **)(*piStack_14 + 0x10))(piStack_14 != aiStack_38);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10446 ; VA 0x0072a430 ; FUN_0072a430 */

undefined4 * __thiscall FUN_0072a430(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  
  uVar1 = *param_2;
  uVar2 = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  *param_1 = uVar1;
  piVar3 = (int *)param_1[1];
  param_1[1] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[2] + -1;
    piVar3[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 10447 ; VA 0x0072a470 ; FUN_0072a470 */

int * __thiscall FUN_0072a470(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int *piStack_8;
  
  piVar1 = param_2;
  piStack_8 = param_1;
  FUN_007323a0(&param_2,param_2);
  piVar2 = param_2;
  if (param_2 != (int *)*param_1) {
    cVar3 = FUN_00558ea0(piVar1,param_2 + 4);
    if (cVar3 == '\0') {
      return piVar2 + 10;
    }
  }
  piStack_8 = piVar1;
  iVar4 = FUN_00559280(&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
  FUN_00726920(&param_2,piVar2,iVar4 + 0x10,iVar4);
  return param_2 + 10;
}



/* FUNCTION 10448 ; VA 0x0072a4f0 ; FUN_0072a4f0 */

undefined4 * __thiscall FUN_0072a4f0(int *param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piStack_8;
  
  piVar1 = param_2;
  puVar3 = (undefined4 *)*param_1;
  puVar5 = puVar3;
  puVar6 = (undefined4 *)puVar3[1];
  piStack_8 = param_1;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    do {
      puVar5 = puVar6;
      cVar2 = FUN_00558ea0(puVar5 + 4,piVar1);
      if (cVar2 == '\0') {
        puVar6 = (undefined4 *)*puVar5;
      }
      else {
        puVar6 = (undefined4 *)puVar5[2];
        puVar5 = puVar3;
      }
      puVar3 = puVar5;
    } while (*(char *)((int)puVar6 + 0xd) == '\0');
    puVar3 = (undefined4 *)*piStack_8;
  }
  if ((puVar5 != puVar3) && (cVar2 = FUN_00558ea0(piVar1,puVar5 + 4), cVar2 == '\0')) {
    return puVar5 + 10;
  }
  piStack_8 = piVar1;
  iVar4 = FUN_007253f0(&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
  FUN_00726ae0(&param_2,puVar5,iVar4 + 0x10,iVar4);
  return param_2 + 10;
}



/* FUNCTION 10449 ; VA 0x0072a5a0 ; FUN_0072a5a0 */

int * __thiscall FUN_0072a5a0(byte *param_1,uint *param_2)

{
  uint *puVar1;
  int *piVar2;
  undefined8 uVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  int *piVar12;
  uint uVar13;
  uint uVar14;
  int *piVar15;
  undefined4 *puVar16;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar12 = (int *)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ace38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar11 = FUN_00731ca0(param_2);
  FUN_00728fe0(&param_2,uVar11,piVar12,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    iVar7 = *piVar12;
    iVar8 = piVar12[1];
    iVar9 = piVar12[2];
    iVar10 = piVar12[3];
    uStack_8 = 0;
    uVar3 = *(undefined8 *)(piVar12 + 4);
    iVar4 = piVar12[6];
    piVar12 = (int *)FUN_01674e20(0x28);
    *piVar12 = 0;
    piVar12[1] = 0;
    piVar12[9] = 0;
    piVar12[2] = iVar7;
    piVar12[3] = iVar8;
    piVar12[4] = iVar9;
    piVar12[5] = iVar10;
    *(undefined8 *)(piVar12 + 6) = uVar3;
    piVar12[8] = iVar4;
    if (piVar12 + 9 != (int *)0x0) {
      piVar12[9] = 0;
    }
    uVar5 = *(uint *)(param_1 + 8);
    uVar13 = uVar5 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar13 = FUN_005c9310(uVar13);
      if (uVar13 <= *(uint *)(param_1 + 4)) {
        uVar13 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar13);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar13) {
      param_2 = (uint *)0x1;
      uVar14 = uVar5 >> 1;
      if ((uVar5 >> 1) + uVar5 <= uVar13) {
        uVar14 = 1;
      }
      uVar13 = FUN_005c9310(uVar14 + uVar5);
      puVar1 = (uint *)(param_1 + 4);
      if (uVar13 != *puVar1) {
        param_2 = puVar1;
        FUN_005d2b00(uVar13);
        puVar16 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
        puVar6 = (undefined4 *)*puVar16;
        while (puVar6 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar6[1] % *param_2) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar6[1] % *param_2) * 4) == 0) {
            *piVar2 = (int)puVar16;
            puVar16 = puVar6;
          }
          else {
            *puVar16 = *puVar6;
            *puVar6 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar6;
          }
          puVar6 = (undefined4 *)*puVar16;
        }
      }
    }
    piVar12[1] = uVar11;
    uVar13 = *(uint *)(param_1 + 4);
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uVar11 % uVar13) * 4);
    if ((int *)*piVar2 == (int *)0x0) {
      piVar15 = (int *)(*(int *)(param_1 + 0x14) + uVar13 * 4);
      if (*piVar15 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar15 + 4) % uVar13) * 4) = piVar12;
      }
      *piVar2 = (int)piVar15;
      *piVar12 = *piVar15;
    }
    else {
      *piVar12 = *(int *)*piVar2;
      piVar15 = (int *)*piVar2;
    }
    *piVar15 = (int)piVar12;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar12 + 2;
  }
  ExceptionList = pvStack_10;
  return (int *)param_2 + 2;
}



/* FUNCTION 10450 ; VA 0x0072a7a0 ; FUN_0072a7a0 */

int * __thiscall FUN_0072a7a0(byte *param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined8 *puVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar4 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ace58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01165540();
  FUN_00729090(&param_2,uVar5,puVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (undefined8 *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)(param_2 + 1);
  }
  uVar1 = *puVar4;
  iVar8 = *(int *)(puVar4 + 1);
  uStack_8 = 0;
  piVar6 = (int *)FUN_01674e20(0x20);
  *piVar6 = 0;
  piVar6[1] = 0;
  piVar6[5] = 0;
  piVar6[6] = 0;
  piVar6[7] = 0;
  *(undefined8 *)(piVar6 + 2) = uVar1;
  piVar6[4] = iVar8;
  piVar6[5] = 0;
  piVar6[6] = 0;
  piVar6[7] = 0;
  uVar2 = *(uint *)(param_1 + 8);
  uVar7 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005c9310(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (undefined8 *)0x1;
    uVar9 = uVar2 >> 1;
    if ((uVar2 >> 1) + uVar2 <= uVar7) {
      uVar9 = 1;
    }
    iVar8 = FUN_005c9310(uVar9 + uVar2);
    if (iVar8 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar8);
      puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar11;
      while (puVar3 != (undefined4 *)0x0) {
        piVar10 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4)
        ;
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar10 = (int)puVar11;
          puVar11 = puVar3;
        }
        else {
          *puVar11 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar10;
          *(undefined4 **)*piVar10 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar11;
      }
    }
  }
  piVar6[1] = uVar5;
  uVar5 = uVar5 % *(uint *)(param_1 + 4);
  piVar10 = *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
  puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
  if (piVar10 == (int *)0x0) {
    piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar10 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar6;
    }
    *puVar11 = piVar10;
    *piVar6 = *piVar10;
  }
  else {
    *piVar6 = *piVar10;
    piVar10 = (int *)*puVar11;
  }
  *piVar10 = (int)piVar6;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piVar6 + 2;
}



/* FUNCTION 10451 ; VA 0x0072a990 ; FUN_0072a990 */

void FUN_0072a990(float *param_1,double param_2,float *param_3)

{
  float fVar1;
  
  fVar1 = (float)param_2;
  *param_1 = *param_3 * fVar1;
  param_1[1] = param_3[1] * fVar1;
  param_1[2] = param_3[2] * fVar1;
  return;
}



/* FUNCTION 10452 ; VA 0x0072a9d0 ; FUN_0072a9d0 */

void __thiscall FUN_0072a9d0(float *param_1,float *param_2,float param_3)

{
  param_3 = DAT_018ce2f8 / param_3;
  *param_2 = *param_1 * param_3;
  param_2[1] = param_1[1] * param_3;
  param_2[2] = param_1[2] * param_3;
  return;
}



/* FUNCTION 10453 ; VA 0x0072aa10 ; FUN_0072aa10 */

void __fastcall FUN_0072aa10(int *param_1)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  int aiStack_120 [2];
  undefined4 uStack_118;
  undefined *puStack_114;
  int **ppiStack_110;
  int *piStack_10c;
  int *piStack_108;
  undefined auStack_f8 [176];
  int *piStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  uint *puStack_30;
  char cStack_2c;
  int *piStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ace9b;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  puStack_30 = (uint *)(*param_1 + 0x80);
  cStack_2c = '\0';
  piStack_108 = (int *)0x72aa51;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  FUN_00587410();
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)0x0;
  iStack_20 = 0;
  piStack_108 = (int *)0x1;
  piStack_10c = (int *)0x3;
  ppiStack_110 = (int **)param_1[1];
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  puStack_114 = (undefined *)0x72aa83;
  FUN_00729510();
  piStack_108 = (int *)0x0;
  piStack_10c = (int *)0x0;
  ppiStack_110 = &piStack_28;
  iStack_8._0_1_ = 2;
  puStack_114 = auStack_f8;
  uStack_118 = 0x72aa9b;
  FUN_00a204e0();
  piVar7 = piStack_28;
  if (piStack_28 == piStack_24) goto LAB_0072ac46;
  if (*piStack_28 == 0) {
LAB_0072aaf6:
    piStack_34 = (int *)0x0;
    puVar6 = &uStack_38;
    piVar7 = (int *)&DAT_00000006;
    piVar8 = (int *)0x0;
  }
  else {
    iVar2 = *(int *)(*piStack_28 + 0xc);
    piStack_108 = (int *)0x72aab8;
    iVar5 = FUN_00cfe630();
    if ((uint)*(ushort *)(iVar5 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) goto LAB_0072aaf6;
    piVar8 = (int *)*piVar7;
    piStack_3c = (int *)piVar7[1];
    if (piStack_3c != (int *)0x0) {
      LOCK();
      piStack_3c[1] = piStack_3c[1] + 1;
      UNLOCK();
      piStack_3c = (int *)piVar7[1];
    }
    piVar7 = (int *)&DAT_00000005;
    puVar6 = &uStack_40;
    piStack_14 = piVar8;
  }
  piVar3 = (int *)puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_34;
  piStack_48 = piVar8;
  piStack_44 = piVar3;
  if ((((uint)piVar7 & 2) != 0) &&
     (piStack_14 = (int *)((uint)piVar7 & 0xfffffffd), piVar7 = piStack_14, piStack_34 != (int *)0x0
     )) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_108 = (int *)0x72ab3f;
      (**(code **)*piStack_34)();
      LOCK();
      piVar7 = piVar4 + 2;
      iVar2 = *piVar7 + -1;
      *piVar7 = iVar2;
      UNLOCK();
      piVar7 = piStack_14;
      if (iVar2 == 0) {
        piStack_108 = (int *)0x72ab50;
        (**(code **)(*piVar4 + 4))();
        piVar7 = piStack_14;
      }
    }
  }
  piVar4 = piStack_3c;
  if ((((uint)piVar7 & 1) != 0) && (piStack_3c != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_108 = (int *)0x72ab6f;
      (**(code **)*piStack_3c)();
      LOCK();
      piVar7 = piVar4 + 2;
      iVar2 = *piVar7 + -1;
      *piVar7 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_108 = (int *)0x72ab80;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  iStack_8._0_1_ = 3;
  if (piVar8 != (int *)0x0) {
    piStack_108 = (int *)0x72ab94;
    puVar6 = (undefined4 *)FUN_00cfa7a0();
    piStack_108 = (int *)0x72ab9a;
    piStack_10c = (int *)(**(code **)*puVar6)();
    piStack_108 = piStack_1c;
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    ppiStack_110 = (int **)0x72abb4;
    FUN_00727ee0();
    iStack_8._0_1_ = 4;
    piStack_10c = (int *)0x72abc1;
    piStack_108 = piVar8 + 0x17;
    FUN_00cf9ed0();
    piStack_108 = &uStack_18;
    piVar7 = piStack_1c + 3;
    ppiStack_110 = (int **)0x72abd9;
    piStack_10c = piVar7;
    FUN_0072a470();
    piStack_10c = (int *)0x72abe0;
    FUN_0056ecd0();
    piStack_108 = (int *)0x0;
    piStack_1c = aiStack_120;
    FUN_0054ef60(piVar7);
    FUN_00733a30();
    piVar7 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_108 = (int *)0x72ac10;
        (**(code **)*piStack_14)();
        LOCK();
        piVar8 = piVar7 + 2;
        iVar2 = *piVar8 + -1;
        *piVar8 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_108 = (int *)0x72ac21;
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_108 = (int *)0x72ac35;
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_108 = (int *)0x72ac46;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
LAB_0072ac46:
  piStack_108 = (int *)0x72ac51;
  FUN_005705c0();
  piVar8 = piStack_24;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  piVar7 = piStack_28;
  if (piStack_28 != (int *)0x0) {
    for (; piVar7 != piVar8; piVar7 = piVar7 + 2) {
      piVar3 = (int *)piVar7[1];
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_108 = (int *)0x72ac7e;
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            piStack_108 = (int *)0x72ac8f;
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    piStack_108 = (int *)((iStack_20 - (int)piStack_28 >> 3) * 8);
    piVar7 = piStack_28;
    if (0xfff < piStack_108) {
      piVar7 = (int *)piStack_28[-1];
      piStack_108 = (int *)((int)piStack_108 + 0x23);
      if (0x1f < (uint)((int)piStack_28 + (-4 - (int)piVar7))) {
                    /* WARNING: Subroutine does not return */
        piStack_108 = (int *)&UNK_0072ad31;
        FUN_017167a3();
      }
    }
    ppiStack_110 = (int **)0x72acc9;
    piStack_10c = piVar7;
    FUN_01674ea0();
    piStack_28 = (int *)0x0;
    piStack_24 = (int *)0x0;
    iStack_20 = 0;
  }
  iStack_8 = 5;
  if (cStack_2c != '\0') {
    LOCK();
    uVar1 = *puStack_30;
    *puStack_30 = *puStack_30 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_30;
      *puStack_30 = *puStack_30 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        piStack_108 = (int *)0x72ad14;
        piStack_108 = (int *)FUN_00554e40();
        piStack_10c = (int *)0x72ad1b;
        SetEvent();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10454 ; VA 0x0072ad40 ; FUN_0072ad40 */

/* WARNING: Type propagation algorithm not settling */

uint __thiscall
FUN_0072ad40(int *param_1,int param_2,int *param_3,int *param_4,uint param_5,int *param_6,
            undefined4 param_7,int *param_8)

{
  int *piVar1;
  int *piVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  undefined auStack_10c [4];
  undefined4 uStack_108;
  int *piStack_104;
  undefined4 uStack_f4;
  uint uStack_f0;
  undefined ***pppuStack_ec;
  int *piStack_e8;
  undefined **appuStack_d8 [15];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_8c;
  undefined **ppuStack_88;
  int iStack_40;
  uint uStack_3c;
  int *piStack_38;
  undefined auStack_34 [24];
  uint *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acf25;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)0x0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((param_5 == 0) && (ExceptionList = &pvStack_10, param_3 != (int *)0x0)) {
    appuStack_d8[0] = &PTR_018be314;
    piStack_e8 = (int *)param_5;
    pppuStack_ec = appuStack_d8 + 1;
    uStack_8 = 3;
    puStack_14 = (undefined *)0x1;
    ppuStack_88 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_8c = 0x48;
    uStack_f0 = 0x72adc4;
    ExceptionList = &pvStack_10;
    FUN_00554f20();
    uStack_8 = 5;
    *(undefined ***)(appuStack_d8[0][1] + (int)appuStack_d8) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)(appuStack_d8[0][1] + (int)&stack0xffffff24) = appuStack_d8[0][1] + -0x50;
    piStack_e8 = (int *)0x72adfd;
    FUN_0054ee60();
    appuStack_d8[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_9c = 0;
    uStack_98 = 4;
    uStack_8._0_1_ = 6;
    piStack_e8 = *(int **)(*(int *)(*param_3 + 4) + 0x38 + (int)param_3);
    pppuStack_ec = (undefined ***)0x72ae36;
    FUN_0056f130();
    piStack_e8 = (int *)auStack_34;
    pppuStack_ec = (undefined ***)0x72ae45;
    piStack_e8 = (int *)FUN_0058c400();
    pppuStack_ec = (undefined ***)&puStack_1c;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    uStack_f0 = 0x72ae53;
    piStack_e8 = (int *)FUN_00729170();
    pppuStack_ec = (undefined ***)0x72ae5f;
    FUN_005587e0();
    piVar2 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_18[1] + -1;
      piStack_18[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        piStack_e8 = (int *)0x72ae75;
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          piStack_e8 = (int *)0x72ae85;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piStack_e8 = (int *)0x72ae8d;
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    piStack_e8 = (int *)0x72ae9c;
    FUN_00570540();
  }
  if (param_2 == 1) {
    if ((param_5 != 0) && (*(int *)(param_5 + 0x10) != 0)) {
      iStack_40 = *param_1;
      piStack_18 = &iStack_40;
      puStack_14 = auStack_10c;
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      uStack_3c = param_5;
      piStack_38 = param_6;
      uStack_8._0_1_ = 10;
      FUN_0054ef60(param_1 + 1);
      piStack_e8 = (int *)0x0;
      uStack_8._0_1_ = 0xc;
      piStack_e8 = (int *)FUN_007260b0(&iStack_40);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00729dd0();
      param_5 = FUN_0072e530();
    }
  }
  else {
    piVar2 = param_1 + 1;
    if (DAT_01eafe10 != 0) {
      piStack_e8 = piVar2;
      if (0xf < (uint)param_1[6]) {
        piStack_e8 = (int *)*piVar2;
      }
      uStack_f0 = (uint)DAT_01eafe10;
      pppuStack_ec = (undefined ***)0x18f8c98;
      uStack_f4 = 0x72aece;
      FUN_01677520();
    }
    puStack_1c = (uint *)(*param_1 + 0x80);
    piStack_18 = (int *)((uint)piStack_18 & 0xffffff00);
    piStack_e8 = (int *)0x72aee5;
    FUN_00587410();
    uStack_8._0_1_ = 8;
    pppuStack_ec = (undefined ***)0x72aef7;
    piStack_e8 = piVar2;
    FUN_00730c30();
    piStack_e8 = (int *)0x18f8cbc;
    uStack_108 = 0x72af0c;
    piStack_104 = piVar2;
    FUN_0054ef60();
    piStack_104 = (int *)0x72af13;
    param_5 = FUN_00733a30();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if ((char)piStack_18 != '\0') {
      LOCK();
      param_5 = *puStack_1c;
      *puStack_1c = *puStack_1c + 0x80000000;
      UNLOCK();
      if (((param_5 & 0x40000000) == 0) && (-0x80000000 < (int)param_5)) {
        LOCK();
        uVar4 = *puStack_1c;
        *puStack_1c = *puStack_1c | 0x40000000;
        UNLOCK();
        if ((uVar4 >> 0x1e & 1) == 0) {
          piStack_e8 = (int *)0x72af53;
          piStack_e8 = (int *)FUN_00554e40();
          pppuStack_ec = (undefined ***)0x72af5a;
          param_5 = SetEvent();
        }
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    puVar3 = (uint *)(param_4 + 1);
    uVar4 = *puVar3;
    param_5 = *puVar3;
    *puVar3 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      piStack_e8 = (int *)0x72aff8;
      (**(code **)*param_4)();
      LOCK();
      puVar3 = (uint *)(param_4 + 2);
      uVar4 = *puVar3;
      param_5 = *puVar3;
      *puVar3 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        piStack_e8 = (int *)0x72b008;
        param_5 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    puVar3 = (uint *)(param_6 + 1);
    uVar4 = *puVar3;
    param_5 = *puVar3;
    *puVar3 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      piStack_e8 = (int *)0x72b01e;
      (**(code **)*param_6)();
      LOCK();
      puVar3 = (uint *)(param_6 + 2);
      uVar4 = *puVar3;
      param_5 = *puVar3;
      *puVar3 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        piStack_e8 = (int *)0x72b02e;
        param_5 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    puVar3 = (uint *)(param_8 + 1);
    uVar4 = *puVar3;
    param_5 = *puVar3;
    *puVar3 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      piStack_e8 = (int *)0x72b044;
      param_5 = (**(code **)*param_8)();
      LOCK();
      piVar2 = param_8 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        piStack_e8 = (int *)0x72b053;
        param_5 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_5;
}



/* FUNCTION 10455 ; VA 0x0072b070 ; FUN_0072b070 */

void __fastcall FUN_0072b070(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 uStack_d0;
  int iStack_cc;
  int iStack_c8;
  uint uStack_c4;
  char *pcStack_c0;
  undefined *puStack_bc;
  int *piStack_b8;
  undefined auStack_a8 [116];
  undefined4 uStack_34;
  int *piStack_30;
  int *piStack_2c;
  uint uStack_28;
  int *piStack_24;
  uint *puStack_20;
  char cStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017acf72;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff4c;
  pcStack_c0 = (char *)param_1[1];
  puStack_bc = *(undefined **)((int)pcStack_c0 + 0x10);
  if (0xf < *(uint *)((int)pcStack_c0 + 0x14)) {
    pcStack_c0 = *(char **)pcStack_c0;
  }
  piStack_b8 = (int *)0x5;
  uStack_c4 = 0x72b0b0;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  uVar4 = FUN_011602a0();
  uStack_28 = uVar4;
  if (uVar4 < 5) {
    iStack_cc = param_1[1];
    iStack_c8 = *(int *)(iStack_cc + 0x10);
    if (0xf < *(uint *)(iStack_cc + 0x14)) {
      iStack_cc = *(int *)iStack_cc;
    }
    piStack_b8 = (int *)0x0;
    puStack_bc = (undefined *)0x0;
    pcStack_c0 = (char *)0x1;
    uStack_c4 = 0;
    uStack_d0 = 0x72b0e4;
    FUN_0115eea0();
    piStack_b8 = (int *)0x14;
    uStack_8 = 2;
    puStack_bc = (undefined *)0x72b0f2;
    piStack_2c = (int *)FUN_01674e20();
    uStack_8._0_1_ = 3;
    if (piStack_2c == (int *)0x0) {
      puStack_bc = (undefined *)0x0;
    }
    else {
      piStack_b8 = (int *)0x3;
      puStack_bc = (undefined *)0x0;
      pcStack_c0 = (char *)0x0;
      uStack_c4 = 0x72b10d;
      puStack_bc = (undefined *)FUN_0115f610();
    }
    piStack_b8 = piStack_18;
    uStack_8._0_1_ = 2;
    uStack_34 = 0;
    piStack_30 = (int *)0x0;
    pcStack_c0 = (char *)0x72b12f;
    FUN_00727f70();
    uVar3 = uStack_34;
    puStack_bc = auStack_a8;
    uStack_8._0_1_ = 5;
    pcStack_c0 = (char *)0x72b145;
    piStack_b8 = (int *)uVar4;
    FUN_0115ffa0();
    piStack_b8 = (int *)0x72b14c;
    FUN_0115fe50();
    puStack_20 = (uint *)(*param_1 + 0x80);
    cStack_1c = '\0';
    piStack_b8 = (int *)0x72b160;
    FUN_00587410();
    piStack_b8 = param_1 + 3;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    puStack_bc = (undefined *)0x72b178;
    piStack_2c = piStack_b8;
    puVar5 = (undefined4 *)FUN_0072a470();
    piVar6 = piStack_30;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piStack_30[1] = piStack_30[1] + 1;
      UNLOCK();
    }
    *puVar5 = uVar3;
    piStack_24 = (int *)puVar5[1];
    puVar5[1] = piStack_30;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_b8 = (int *)0x72b1a2;
        (**(code **)*piStack_24)();
        LOCK();
        iVar2 = piStack_24[2] + -1;
        piStack_24[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_b8 = (int *)0x72b1b3;
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    piStack_b8 = (int *)0x0;
    piStack_24 = &uStack_d0;
    FUN_0054ef60(piStack_2c);
    FUN_00733a30();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (cStack_1c != '\0') {
      LOCK();
      uVar4 = *puStack_20;
      *puStack_20 = *puStack_20 + 0x80000000;
      UNLOCK();
      if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
        LOCK();
        uVar4 = *puStack_20;
        *puStack_20 = *puStack_20 | 0x40000000;
        UNLOCK();
        if ((uVar4 >> 0x1e & 1) == 0) {
          piStack_b8 = (int *)0x72b20e;
          piStack_b8 = (int *)FUN_00554e40();
          puStack_bc = (undefined *)0x72b215;
          SetEvent();
          FUN_0072b2b9();
          return;
        }
      }
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = piVar6[1] + -1;
      piVar6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_b8 = (int *)0x72b2cc;
        (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          piStack_b8 = (int *)0x72b2db;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    piStack_b8 = (int *)0x72b2e6;
    FUN_0115f010();
    ExceptionList = pvStack_10;
    return;
  }
  puStack_20 = (uint *)(*param_1 + 0x80);
  cStack_1c = '\0';
  piStack_b8 = (int *)0x72b30b;
  FUN_00587410();
  piVar6 = param_1 + 3;
  uStack_8 = 0;
  puStack_bc = (undefined *)0x72b323;
  piStack_b8 = piVar6;
  FUN_00730c30();
  piStack_b8 = (int *)0x18f8bf4;
  piStack_18 = &uStack_d0;
  FUN_0054ef60(piVar6);
  FUN_00733a30();
  if (DAT_01eafe10 != 0) {
    if (0xf < (uint)param_1[8]) {
      piVar6 = (int *)*piVar6;
    }
    puStack_bc = (undefined *)uStack_28;
    uStack_c4 = (uint)DAT_01eafe10;
    pcStack_c0 = "ModelLod: fetched texture format %d not recognized, id %s";
    iStack_c8 = 0x72b362;
    piStack_b8 = piVar6;
    FUN_01677520();
  }
  uStack_8 = 1;
  if (cStack_1c != '\0') {
    LOCK();
    uVar4 = *puStack_20;
    *puStack_20 = *puStack_20 + 0x80000000;
    UNLOCK();
    if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
      LOCK();
      uVar4 = *puStack_20;
      *puStack_20 = *puStack_20 | 0x40000000;
      UNLOCK();
      if ((uVar4 >> 0x1e & 1) == 0) {
        piStack_b8 = (int *)0x72b398;
        piStack_b8 = (int *)FUN_00554e40();
        puStack_bc = (undefined *)0x72b39f;
        SetEvent();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10456 ; VA 0x0072b21a ; Catch@0072b21a */

undefined * Catch_0072b21a(void)

{
  int *piVar1;
  int unaff_EBP;
  undefined auStack_1c [8];
  undefined4 uStack_14;
  uint uStack_10;
  char *pcStack_c;
  char *pcStack_8;
  int *piStack_4;
  
  piVar1 = *(int **)(unaff_EBP + -0x14);
  *(undefined *)(unaff_EBP + -4) = 9;
  *(undefined *)(unaff_EBP + -0x18) = 0;
  *(int *)(unaff_EBP + -0x1c) = *piVar1 + 0x80;
  piStack_4 = (int *)0x72b235;
  FUN_00587410();
  piVar1 = piVar1 + 3;
  *(undefined *)(unaff_EBP + -4) = 10;
  pcStack_8 = (char *)0x72b24a;
  piStack_4 = piVar1;
  FUN_00730c30();
  piStack_4 = (int *)0x18f8c4c;
  *(undefined **)(unaff_EBP + -0x14) = auStack_1c;
  FUN_0054ef60(piVar1);
  FUN_00733a30();
  if (DAT_01eafe10 != 0) {
    piStack_4 = *(int **)(unaff_EBP + -0x24);
    pcStack_8 = "Unknown exception";
    if (*(char **)(unaff_EBP + -0x38) != (char *)0x0) {
      pcStack_8 = *(char **)(unaff_EBP + -0x38);
    }
    uStack_10 = (uint)DAT_01eafe10;
    pcStack_c = "ModelLod: texture failed to decode %s format %d";
    uStack_14 = 0x72b28f;
    FUN_01677520();
  }
  piStack_4 = (int *)0x72b29a;
  FUN_00550b60();
  piStack_4 = (int *)(unaff_EBP + -0x38);
  *(undefined ***)(unaff_EBP + -0x3c) = std::exception::vftable;
  pcStack_8 = (char *)0x72b2aa;
  FUN_0170c289();
  return &DAT_0072b2b3;
}



/* FUNCTION 10457 ; VA 0x0072b2b9 ; FUN_0072b2b9 */

void FUN_0072b2b9(void)

{
  int *piVar1;
  int iVar2;
  int unaff_EBP;
  int *unaff_ESI;
  int unaff_EDI;
  
  if (unaff_ESI != (int *)0x0) {
    LOCK();
    iVar2 = unaff_ESI[1] + unaff_EDI;
    unaff_ESI[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*unaff_ESI)();
      LOCK();
      piVar1 = unaff_ESI + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + unaff_EDI;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*unaff_ESI + 4))();
      }
    }
  }
  FUN_0115f010();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 10458 ; VA 0x0072b3b0 ; FUN_0072b3b0 */

/* WARNING: Type propagation algorithm not settling */

int __thiscall
FUN_0072b3b0(int *param_1,int *param_2,int *param_3,int *param_4,int param_5,int *param_6,
            undefined4 param_7,int *param_8)

{
  undefined **ppuVar1;
  int *piVar2;
  int iVar3;
  undefined *puVar4;
  undefined **ppuVar5;
  char cVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  int aiStack_10c [2];
  int *piStack_104;
  undefined auStack_100 [12];
  undefined4 uStack_f4;
  undefined4 *puStack_f0;
  undefined ***pppuStack_ec;
  int *piStack_e8;
  undefined **appuStack_d8 [15];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_8c;
  undefined **ppuStack_88;
  undefined *puStack_40;
  int iStack_3c;
  int *piStack_38;
  undefined auStack_34 [24];
  undefined auStack_1c [4];
  undefined **ppuStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017acfed;
  pvStack_10 = ExceptionList;
  ppuStack_18 = (undefined **)0x0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if ((param_5 == 0) && (ExceptionList = &pvStack_10, param_3 != (int *)0x0)) {
    appuStack_d8[0] = &PTR_018be314;
    piStack_e8 = (int *)param_5;
    pppuStack_ec = appuStack_d8 + 1;
    uStack_8 = 3;
    ppuStack_18 = (undefined **)0x1;
    ppuStack_88 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_8c = 0x48;
    puStack_f0 = (undefined4 *)0x72b437;
    ExceptionList = &pvStack_10;
    FUN_00554f20();
    uStack_8 = 5;
    *(undefined ***)(appuStack_d8[0][1] + (int)appuStack_d8) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)(appuStack_d8[0][1] + (int)&stack0xffffff24) = appuStack_d8[0][1] + -0x50;
    piStack_e8 = (int *)0x72b470;
    FUN_0054ee60();
    appuStack_d8[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_9c = 0;
    uStack_98 = 4;
    uStack_8._0_1_ = 6;
    piStack_e8 = *(int **)(*(int *)(*param_3 + 4) + 0x38 + (int)param_3);
    pppuStack_ec = (undefined ***)0x72b4a9;
    FUN_0056f130();
    piStack_e8 = (int *)auStack_34;
    pppuStack_ec = (undefined ***)0x72b4b8;
    piStack_e8 = (int *)FUN_0058c400();
    pppuStack_ec = (undefined ***)auStack_1c;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    puStack_f0 = (undefined4 *)0x72b4c6;
    piStack_e8 = (int *)FUN_00729170();
    pppuStack_ec = (undefined ***)0x72b4d2;
    FUN_005587e0();
    ppuVar5 = ppuStack_18;
    if (ppuStack_18 != (undefined **)0x0) {
      LOCK();
      puVar4 = ppuStack_18[1] + -1;
      ppuStack_18[1] = puVar4;
      UNLOCK();
      if (puVar4 == (undefined *)0x0) {
        piStack_e8 = (int *)0x72b4e8;
        (**(code **)*ppuStack_18)();
        LOCK();
        ppuVar1 = ppuVar5 + 2;
        puVar4 = *ppuVar1 + -1;
        *ppuVar1 = puVar4;
        UNLOCK();
        if (puVar4 == (undefined *)0x0) {
          piStack_e8 = (int *)0x72b4f8;
          (**(code **)(*ppuVar5 + 4))();
        }
      }
    }
    piStack_e8 = (int *)0x72b500;
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    piStack_e8 = (int *)0x72b50f;
    FUN_00570540();
  }
  piVar10 = piStack_14;
  if (param_2 == (int *)0x1) {
    iVar7 = param_5;
    if ((param_5 != 0) && (*(int *)(param_5 + 0x10) != 0)) {
      param_2 = (int *)*piStack_14;
      ppuStack_18 = &puStack_40;
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      piStack_38 = param_6;
      piVar10 = piStack_14 + 1;
      uStack_8._0_1_ = 8;
      puStack_40 = (undefined *)param_2;
      iStack_3c = param_5;
      piStack_14 = aiStack_10c;
      FUN_0054ef60(piVar10);
      piStack_e8 = (int *)0x0;
      uStack_8._0_1_ = 10;
      piStack_e8 = (int *)FUN_00726510(&puStack_40);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00729dd0();
      iVar7 = FUN_0072e530();
    }
  }
  else {
    piVar2 = piStack_14 + 1;
    if (DAT_01eafe10 != 0) {
      piStack_e8 = piVar2;
      if (0xf < (uint)piStack_14[6]) {
        piStack_e8 = (int *)*piVar2;
      }
      puStack_f0 = (undefined4 *)(uint)DAT_01eafe10;
      pppuStack_ec = (undefined ***)0x18f8bc0;
      uStack_f4 = 0x72b544;
      FUN_01677520();
    }
    ppuStack_18 = (undefined **)(*piVar10 + 0x90);
    piVar10 = (int *)*ppuStack_18;
    cVar6 = *(char *)(piVar10[1] + 0xd);
    param_2 = piVar10;
    piVar8 = (int *)piVar10[1];
    while (cVar6 == '\0') {
      pppuStack_ec = (undefined ***)(piVar8 + 4);
      puStack_f0 = (undefined4 *)0x72b56c;
      piStack_e8 = piVar2;
      cVar6 = FUN_00558ea0();
      if (cVar6 == '\0') {
        if (*(char *)((int)piVar10 + 0xd) != '\0') {
          piStack_e8 = piVar8 + 4;
          puStack_f0 = (undefined4 *)0x72b588;
          pppuStack_ec = (undefined ***)piVar2;
          cVar6 = FUN_00558ea0();
          if (cVar6 != '\0') {
            piVar10 = piVar8;
          }
        }
        piVar9 = (int *)*piVar8;
        param_2 = piVar8;
      }
      else {
        piVar9 = (int *)piVar8[2];
      }
      piVar8 = piVar9;
      cVar6 = *(char *)((int)piVar9 + 0xd);
    }
    piVar8 = piVar10;
    if (*(char *)((int)piVar10 + 0xd) != '\0') {
      piVar8 = (int *)(*ppuStack_18 + 4);
    }
    cVar6 = *(char *)(*piVar8 + 0xd);
    piVar8 = (int *)*piVar8;
    piVar9 = param_2;
    while (param_2 = piVar9, cVar6 == '\0') {
      piStack_e8 = piVar8 + 4;
      puStack_f0 = (undefined4 *)0x72b5bf;
      pppuStack_ec = (undefined ***)piVar2;
      cVar6 = FUN_00558ea0();
      if (cVar6 == '\0') {
        piVar9 = (int *)piVar8[2];
      }
      else {
        piVar9 = (int *)*piVar8;
        piVar10 = piVar8;
      }
      cVar6 = *(char *)((int)piVar9 + 0xd);
      piVar8 = piVar9;
      piVar9 = param_2;
    }
    while (param_2 != piVar10) {
      piStack_e8 = (int *)0x72b5e8;
      FUN_00551320();
    }
    puStack_f0 = &param_2;
    uStack_f4 = 0x72b5fb;
    pppuStack_ec = (undefined ***)piVar9;
    piStack_e8 = piVar10;
    FUN_005f6cc0();
    piStack_e8 = (int *)0x18f8be0;
    param_2 = (int *)auStack_100;
    aiStack_10c[1] = 0x72b613;
    piStack_104 = piVar2;
    FUN_0054ef60();
    piStack_104 = (int *)0x72b61a;
    iVar7 = FUN_00733a30();
  }
  piVar10 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar2 = param_4 + 1;
    iVar3 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piStack_e8 = (int *)0x72b6c3;
      (**(code **)*param_4)();
      LOCK();
      piVar2 = piVar10 + 2;
      iVar3 = *piVar2;
      iVar7 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piStack_e8 = (int *)0x72b6d3;
        iVar7 = (**(code **)(*piVar10 + 4))();
      }
    }
  }
  piVar10 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar2 = param_6 + 1;
    iVar3 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piStack_e8 = (int *)0x72b6e9;
      (**(code **)*param_6)();
      LOCK();
      piVar2 = piVar10 + 2;
      iVar3 = *piVar2;
      iVar7 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piStack_e8 = (int *)0x72b6f9;
        iVar7 = (**(code **)(*piVar10 + 4))();
      }
    }
  }
  piVar10 = param_8;
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar2 = param_8 + 1;
    iVar3 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piStack_e8 = (int *)0x72b70f;
      iVar7 = (**(code **)*param_8)();
      LOCK();
      piVar2 = piVar10 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_e8 = (int *)0x72b71e;
        iVar7 = (**(code **)(*piVar10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 10459 ; VA 0x0072b740 ; FUN_0072b740 */

int * __thiscall FUN_0072b740(uint *param_1,int param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 ****ppppuVar9;
  uint uStack_b0;
  undefined4 ***pppuStack_ac;
  undefined4 uStack_a8;
  uint *puStack_a4;
  undefined4 uStack_a0;
  undefined4 ***pppuStack_9c;
  undefined4 ***pppuStack_98;
  undefined4 ***pppuStack_94;
  uint auStack_84 [8];
  uint auStack_64 [2];
  undefined4 **appuStack_5c [4];
  int iStack_4c;
  undefined4 ***apppuStack_44 [4];
  int iStack_34;
  uint uStack_30;
  int iStack_2c;
  uint uStack_28;
  uint *puStack_24;
  uint uStack_20;
  undefined *puStack_1c;
  undefined4 **ppuStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ad060;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  piVar6 = (int *)ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 == 0) goto LAB_0072bd2d;
  iVar7 = *(int *)(param_2 + 0xc);
  pppuStack_94 = (undefined4 ***)0x72b77a;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00b50240();
  piVar6 = (int *)(uint)*(ushort *)(iVar5 + 0x1da);
  if (piVar6 < (int *)((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    if (param_2 != 0) {
      iVar7 = *(int *)(param_2 + 0xc);
      pppuStack_94 = (undefined4 ***)0x72b9bd;
      iVar5 = FUN_00cfb1a0();
      piVar6 = (int *)(uint)*(ushort *)(iVar5 + 0x1da);
      if (piVar6 < (int *)((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
        if (param_2 != 0) {
          iVar7 = *(int *)(param_2 + 0xc);
          pppuStack_94 = (undefined4 ***)0x72bd0d;
          iVar5 = FUN_00aff8c0();
          piVar6 = (int *)(uint)*(ushort *)(iVar5 + 0x1da);
          if ((int *)((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) <= piVar6
             ) {
            piVar6 = (int *)param_1[3];
            *piVar6 = *piVar6 + 1;
          }
        }
      }
      else {
        pppuStack_94 = (undefined4 ***)(param_2 + 0x154);
        pppuStack_98 = (undefined4 ****)0x72b9eb;
        FUN_0054ef60();
        uStack_8 = 7;
        if (iStack_4c != 0) {
          pppuStack_94 = (undefined4 ***)(param_2 + 0x16c);
          pppuStack_98 = (undefined4 ***)0x72ba08;
          FUN_0054ef60();
          iStack_2c = *param_1 + 0x80;
          uStack_8 = 8;
          uStack_28 = uStack_28 & 0xffffff00;
          pppuStack_94 = (undefined4 ***)0x72ba20;
          FUN_00587410();
          pppuStack_94 = appuStack_5c;
          pppuStack_98 = (undefined4 ***)&puStack_1c;
          uStack_8 = 9;
          pppuStack_9c = (undefined4 ***)0x72ba39;
          FUN_00730f80();
          pppuStack_94 = apppuStack_44;
          pppuStack_98 = &ppuStack_18;
          pppuStack_9c = (undefined4 ****)0x72ba4e;
          FUN_00730f80();
          if (puStack_1c == *(undefined **)(*param_1 + 0x90)) {
            *(int *)(param_1[5] + 0x30) = *(int *)(param_1[5] + 0x30) + 1;
            pppuStack_94 = appuStack_5c;
            pppuStack_98 = (undefined4 ***)0x72ba76;
            FUN_0072a4f0();
            pppuStack_98 = (undefined4 ***)0x72ba7e;
            pppuStack_94 = (undefined4 ***)(param_1 + 5);
            FUN_00733c70();
            puStack_24 = (uint *)0x0;
            uStack_20 = 0;
            pppuStack_94 = appuStack_5c;
            _uStack_8 = CONCAT31(uStack_7,10);
            pppuStack_98 = (undefined4 ***)0x72baa1;
            puVar8 = (undefined4 *)FUN_0072a470();
            puStack_24 = (uint *)0x0;
            uStack_20 = 0;
            *puVar8 = 0;
            piVar6 = (int *)puVar8[1];
            puVar8[1] = 0;
            if (piVar6 != (int *)0x0) {
              LOCK();
              iVar7 = piVar6[1] + -1;
              piVar6[1] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                pppuStack_94 = (undefined4 ***)0x72bad5;
                (**(code **)*piVar6)();
                LOCK();
                iVar7 = piVar6[2] + -1;
                piVar6[2] = iVar7;
                UNLOCK();
                if (iVar7 == 0) {
                  pppuStack_94 = (undefined4 ***)0x72bae5;
                  (**(code **)(*piVar6 + 4))();
                }
              }
            }
            uStack_8 = 9;
            pppuStack_94 = (undefined4 ***)0x72baf1;
            FUN_00550b30();
            cStack_11 = '\0';
            if ((iStack_34 != 0) &&
               ((undefined4 ***)ppuStack_18 == *(undefined4 ****)(*param_1 + 0x98))) {
              cStack_11 = '\x01';
              *(int *)(param_1[5] + 0x30) = *(int *)(param_1[5] + 0x30) + 1;
              pppuStack_94 = apppuStack_44;
              pppuStack_98 = (undefined4 ***)0x72bb2b;
              FUN_0072a4f0();
              pppuStack_98 = (undefined4 ***)0x72bb33;
              pppuStack_94 = (undefined4 ***)(param_1 + 5);
              FUN_00733c70();
              puStack_24 = (uint *)0x0;
              uStack_20 = 0;
              pppuStack_94 = apppuStack_44;
              _uStack_8 = CONCAT31(uStack_7,0xb);
              pppuStack_98 = (undefined4 ***)0x72bb56;
              puVar8 = (undefined4 *)FUN_0072a470();
              puStack_24 = (uint *)0x0;
              uStack_20 = 0;
              *puVar8 = 0;
              piVar6 = (int *)puVar8[1];
              puVar8[1] = 0;
              if (piVar6 != (int *)0x0) {
                LOCK();
                iVar7 = piVar6[1] + -1;
                piVar6[1] = iVar7;
                UNLOCK();
                if (iVar7 == 0) {
                  pppuStack_94 = (undefined4 ***)0x72bb87;
                  (**(code **)*piVar6)();
                  LOCK();
                  iVar7 = piVar6[2] + -1;
                  piVar6[2] = iVar7;
                  UNLOCK();
                  if (iVar7 == 0) {
                    pppuStack_94 = (undefined4 ***)0x72bb97;
                    (**(code **)(*piVar6 + 4))();
                  }
                }
              }
              uStack_8 = 9;
              pppuStack_94 = (undefined4 ***)0x72bba3;
              FUN_00550b30();
            }
            *(int *)param_1[4] = *(int *)param_1[4] + 1;
            pppuStack_94 = (undefined4 ***)0x72bbb0;
            FUN_0058c660();
            uStack_b0 = *param_1;
            pppuStack_94 = (undefined4 ***)0x0;
            puStack_1c = (undefined *)&uStack_b0;
            FUN_0054ef60(appuStack_5c);
            FUN_00724af0();
            uStack_8 = 0xc;
            pppuStack_94 = (undefined4 ***)0x72bbe3;
            uStack_a0 = FUN_008ccd50();
            pppuStack_94 = (undefined4 ***)0x1;
            pppuStack_98 = (undefined4 ****)0x0;
            pppuStack_9c = (undefined4 ***)&DAT_01d62f20;
            puStack_a4 = auStack_84;
            pppuStack_ac = appuStack_5c;
            uStack_a8 = 0x41a00000;
            uStack_b0 = 0x72bc04;
            FUN_008cd330();
            uStack_8 = 9;
            pppuStack_94 = (undefined4 ***)0x72bc10;
            FUN_00550990();
            if (cStack_11 != '\0') {
              uStack_b0 = *param_1;
              pppuStack_94 = (undefined4 ***)0x0;
              puStack_1c = (undefined *)&uStack_b0;
              FUN_0054ef60(apppuStack_44);
              FUN_00724920();
              uStack_8 = 0xd;
              pppuStack_94 = (undefined4 ***)0x72bc4d;
              uStack_a0 = FUN_008ccda0();
              pppuStack_94 = (undefined4 ***)0x1;
              pppuStack_98 = (undefined4 ****)0x0;
              pppuStack_9c = (undefined4 ***)&DAT_01d62f20;
              puStack_a4 = auStack_84;
              pppuStack_ac = apppuStack_44;
              uStack_a8 = 0x425c0000;
              uStack_b0 = 0x72bc6e;
              FUN_008cd330();
              pppuStack_94 = (undefined4 ***)0x72bc76;
              FUN_00550990();
            }
          }
          else {
            if (*(int *)(puStack_1c + 0x28) == 0) {
              *(int *)(param_1[5] + 0x30) = *(int *)(param_1[5] + 0x30) + 1;
              pppuStack_94 = appuStack_5c;
              pppuStack_98 = (undefined4 ***)0x72bc95;
              FUN_0072a4f0();
              pppuStack_98 = (undefined4 ****)0x72bc9d;
              pppuStack_94 = (undefined4 ***)(param_1 + 5);
              FUN_00733c70();
              *(int *)param_1[4] = *(int *)param_1[4] + 1;
            }
            if (((iStack_34 != 0) &&
                ((undefined4 ***)ppuStack_18 != *(undefined4 ****)(*param_1 + 0x98))) &&
               ((undefined4 **)ppuStack_18[10] == (undefined4 **)0x0)) {
              *(int *)(param_1[5] + 0x30) = *(int *)(param_1[5] + 0x30) + 1;
              pppuStack_94 = apppuStack_44;
              pppuStack_98 = (undefined4 ***)0x72bcd2;
              FUN_0072a4f0();
              pppuStack_98 = (undefined4 ****)0x72bcda;
              pppuStack_94 = (undefined4 ***)(param_1 + 5);
              FUN_00733c70();
              *(int *)param_1[4] = *(int *)param_1[4] + 1;
            }
          }
          *(int *)param_1[3] = *(int *)param_1[3] + 1;
          pppuStack_94 = (undefined4 ***)0x72bcec;
          FUN_00550b60();
          pppuStack_94 = (undefined4 ***)0x72bcf4;
          FUN_005507b0();
        }
        pppuStack_94 = (undefined4 ***)0x72bcfc;
        piVar6 = (int *)FUN_005507b0();
      }
    }
    goto LAB_0072bd2d;
  }
  pppuStack_94 = (undefined4 ***)(param_2 + 0x1a4);
  pppuStack_98 = (undefined4 ****)0x72b7a8;
  piVar6 = (int *)FUN_0054ef60();
  uStack_8 = 1;
  if (iStack_34 != 0) {
    puStack_24 = (uint *)(*param_1 + 0x80);
    uStack_20 = uStack_20 & 0xffffff00;
    pppuStack_94 = (undefined4 ***)0x72b7ca;
    FUN_00587410();
    uVar3 = *param_1;
    pppuStack_94 = apppuStack_44;
    pppuStack_98 = &ppuStack_18;
    _uStack_8 = CONCAT31(uStack_7,2);
    pppuStack_9c = (undefined4 ****)0x72b7e3;
    FUN_007323a0();
    if ((undefined4 ***)ppuStack_18 == *(undefined4 ****)(uVar3 + 0x88)) {
LAB_0072b802:
      ppuStack_18 = *(undefined4 ***)(uVar3 + 0x88);
    }
    else {
      pppuStack_94 = (undefined4 ***)(ppuStack_18 + 4);
      pppuStack_98 = apppuStack_44;
      pppuStack_9c = (undefined4 ****)0x72b7fb;
      cVar4 = FUN_00558ea0();
      if (cVar4 != '\0') goto LAB_0072b802;
    }
    piVar6 = (int *)*param_1;
    if ((undefined4 ***)ppuStack_18 == (undefined4 ***)piVar6[0x22]) {
      *(int *)(param_1[5] + 0x30) = *(int *)(param_1[5] + 0x30) + 1;
      pppuStack_94 = apppuStack_44;
      pppuStack_98 = (undefined4 ***)0x72b82d;
      iVar7 = FUN_0072a4f0();
      pppuStack_98 = *(undefined4 ****)(iVar7 + 4);
      if ((undefined4 ***)*(uint **)(iVar7 + 8) == pppuStack_98) {
        pppuStack_9c = (undefined4 ***)0x72b848;
        pppuStack_94 = (undefined4 ***)(param_1 + 5);
        FUN_006030d0();
      }
      else {
        *pppuStack_98 = (undefined4 **)param_1[5];
        *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 4;
      }
      iStack_2c = 0;
      uStack_28 = 0;
      *(int *)param_1[4] = *(int *)param_1[4] + 1;
      pppuStack_94 = (undefined4 ***)&iStack_2c;
      pppuStack_98 = apppuStack_44;
      uStack_8 = 3;
      pppuStack_9c = (undefined4 ***)0x72b874;
      FUN_0072a470();
      pppuStack_98 = (undefined4 ***)0x72b87b;
      FUN_005587e0();
      uStack_8 = 2;
      pppuStack_94 = (undefined4 ***)0x72b887;
      FUN_00550b30();
      pppuStack_94 = (undefined4 ***)0x72b88f;
      FUN_0058c660();
      uStack_b0 = *param_1;
      pppuStack_94 = (undefined4 ***)0x0;
      puStack_1c = (undefined *)&uStack_b0;
      FUN_0054ef60(apppuStack_44);
      FUN_00724f80();
      uStack_8 = 4;
      pppuStack_94 = (undefined4 ***)0x72b8c2;
      uStack_a0 = FUN_008ccd80();
      pppuStack_94 = (undefined4 ***)0x1;
      pppuStack_98 = (undefined4 ****)0x0;
      pppuStack_9c = (undefined4 ***)&DAT_01d62f20;
      puStack_a4 = auStack_64;
      pppuStack_ac = apppuStack_44;
      uStack_a8 = 0x41a00000;
      uStack_b0 = 0x72b8e3;
      FUN_008cd330();
      _uStack_8 = CONCAT31(uStack_7,5);
      if (((auStack_64[0] != 0) && ((auStack_64[0] & 1) == 0)) &&
         (*(code **)(auStack_64[0] & 0xfffffffe) != (code *)0x0)) {
        pppuStack_9c = appuStack_5c;
        pppuStack_94 = (undefined4 ***)0x2;
        uStack_a0 = 0x72b904;
        pppuStack_98 = pppuStack_9c;
        (**(code **)(auStack_64[0] & 0xfffffffe))();
      }
      piVar6 = (int *)param_1[3];
LAB_0072b934:
      *piVar6 = *piVar6 + 1;
    }
    else if (((undefined4 ***)ppuStack_18)[10] == (undefined4 **)0x0) {
      *(int *)(param_1[5] + 0x30) = *(int *)(param_1[5] + 0x30) + 1;
      pppuStack_94 = apppuStack_44;
      pppuStack_98 = (undefined4 ***)0x72b929;
      FUN_0072a4f0();
      pppuStack_98 = (undefined4 ****)0x72b931;
      pppuStack_94 = (undefined4 ***)(param_1 + 5);
      FUN_00733c70();
      piVar6 = (int *)param_1[4];
      goto LAB_0072b934;
    }
    uStack_8 = 6;
    if ((char)uStack_20 != '\0') {
      LOCK();
      piVar6 = (int *)*puStack_24;
      *puStack_24 = *puStack_24 + 0x80000000;
      UNLOCK();
      if ((((uint)piVar6 & 0x40000000) == 0) && (-0x80000000 < (int)piVar6)) {
        LOCK();
        uVar3 = *puStack_24;
        *puStack_24 = *puStack_24 | 0x40000000;
        UNLOCK();
        if ((uVar3 >> 0x1e & 1) == 0) {
          pppuStack_94 = (undefined4 ***)0x72b966;
          pppuStack_94 = (undefined4 ***)FUN_00554e40();
          pppuStack_98 = (undefined4 ****)0x72b96d;
          piVar6 = (int *)SetEvent();
        }
      }
    }
  }
  if (0xf < uStack_30) {
    pppuStack_94 = (undefined4 ***)(uStack_30 + 1);
    ppppuVar9 = (undefined4 ****)apppuStack_44[0];
    if (0xfff < pppuStack_94) {
      ppppuVar9 = (undefined4 ****)apppuStack_44[0][-1];
      pppuStack_94 = (undefined4 ***)(uStack_30 + 0x24);
      if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_94 = (undefined4 ***)&UNK_0072bd6d;
        FUN_017167a3();
      }
    }
    pppuStack_9c = (undefined4 ****)0x72b9a2;
    pppuStack_98 = ppppuVar9;
    piVar6 = (int *)FUN_01674ea0();
  }
LAB_0072bd2d:
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    piVar6 = (int *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pppuStack_94 = (undefined4 ***)0x72bd46;
      piVar6 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar7 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        pppuStack_94 = (undefined4 ***)0x72bd55;
        piVar6 = (int *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar6;
}



/* FUNCTION 10460 ; VA 0x0072bd70 ; FUN_0072bd70 */

void __fastcall FUN_0072bd70(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined *puVar4;
  undefined auStack_8c [24];
  undefined4 uStack_74;
  uint uStack_70;
  char *pcStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int aiStack_48 [9];
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ad093;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01eafe10 != 0) {
    uStack_68 = param_1[1];
    uStack_70 = (uint)DAT_01eafe10;
    pcStack_6c = "ModelMeshComputer fetches completed for %p";
    uStack_74 = 0x72bdaa;
    ExceptionList = &pvStack_10;
    FUN_01677520();
  }
  uStack_58 = *param_1;
  puStack_1c = &uStack_58;
  piStack_50 = (int *)param_1[2];
  puStack_18 = auStack_8c;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    piStack_50[1] = piStack_50[1] + 1;
    UNLOCK();
    piStack_50 = (int *)param_1[2];
  }
  uStack_54 = param_1[1];
  piStack_20 = aiStack_48;
  piStack_24 = (int *)0x0;
  uStack_8 = 1;
  puVar4 = auStack_8c;
  uStack_14 = uStack_58;
  if ((undefined4 *)param_1[0xd] != (undefined4 *)0x0) {
    piStack_24 = (int *)(*(code *)**(undefined4 **)param_1[0xd])(aiStack_48);
    puVar4 = puStack_18;
  }
  puStack_18 = puVar4;
  uStack_68 = 0;
  uStack_8 = 3;
  uStack_68 = FUN_007262c0(&uStack_58);
  uStack_8 = 0xffffffff;
  if (piStack_24 != (int *)0x0) {
    (**(code **)(*piStack_24 + 0x10))
              (CONCAT31((int3)((uint)aiStack_48 >> 8),piStack_24 != aiStack_48));
    piStack_24 = (int *)0x0;
  }
  piVar2 = piStack_50;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_50[1] + -1;
    piStack_50[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_1[2] != 0) {
    LOCK();
    piVar2 = (int *)(param_1[2] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  FUN_0072e9d0(param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10461 ; VA 0x0072bed0 ; FUN_0072bed0 */

void __thiscall
FUN_0072bed0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15,undefined4 param_16)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  int iStack_60;
  int *piStack_5c;
  int iStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad0b8;
  pvStack_10 = ExceptionList;
  piStack_5c = (int *)param_1[2];
  ExceptionList = &pvStack_10;
  if (piStack_5c != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piStack_5c[1] = piStack_5c[1] + 1;
    UNLOCK();
    piStack_5c = (int *)param_1[2];
  }
  iStack_60 = param_1[1];
  iStack_58 = param_2;
  LOCK();
  *(int *)(param_2 + 0x28) = *(int *)(param_2 + 0x28) + 1;
  UNLOCK();
  uStack_1c = param_16;
  uStack_54 = param_3;
  uStack_50 = param_4;
  uStack_4c = param_5;
  uStack_48 = param_6;
  uStack_44 = param_7;
  uStack_40 = param_8;
  uStack_3c = param_9;
  uStack_38 = param_10;
  uStack_34 = param_11;
  uStack_30 = param_12;
  uStack_2c = param_13;
  uStack_28 = param_14;
  uStack_24 = param_15;
  iVar4 = *param_1;
  uStack_8 = 1;
  if (*(int *)(iVar4 + 0x74) == *(int *)(iVar4 + 0x70)) {
    FUN_00725a20(*(int *)(iVar4 + 0x70),&iStack_60);
  }
  else {
    FUN_00728e50(iVar4 + 0x6c);
    *(int *)(iVar4 + 0x70) = *(int *)(iVar4 + 0x70) + 0x48;
  }
  puStack_18 = (uint *)*param_1;
  cStack_14 = '\0';
  FUN_00587410();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (DAT_01eafe10 != '\0') {
    iVar4 = *param_1;
    FUN_01677520(DAT_01eafe10,"ModelMeshComputer compute completed for %p %zu / %zu",param_1[1],
                 *(int *)(iVar4 + 0x4c) + 1,*(int *)(iVar4 + 0x44) - *(int *)(iVar4 + 0x40) >> 3);
  }
  iVar4 = *param_1;
  piVar1 = (int *)(iVar4 + 0x4c);
  *piVar1 = *piVar1 + 1;
  if (*(int *)(iVar4 + 0x4c) == *(int *)(*param_1 + 0x44) - *(int *)(*param_1 + 0x40) >> 3) {
    if ((int *)param_1[0xd] == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddc9c();
    }
    (**(code **)(*(int *)param_1[0xd] + 8))();
    FUN_00733020();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (cStack_14 != '\0') {
    LOCK();
    uVar3 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar3 & 0x40000000) == 0) && (-0x80000000 < (int)uVar3)) {
      LOCK();
      uVar3 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar3 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
      }
    }
  }
  FUN_0056cd30();
  piVar1 = piStack_5c;
  if (piStack_5c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_5c[1] + -1;
    piStack_5c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_5c)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10462 ; VA 0x0072c080 ; FUN_0072c080 */

uint * __thiscall FUN_0072c080(int *param_1,uint *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  undefined8 uVar3;
  int iVar4;
  uint *puVar5;
  undefined *puVar6;
  char cVar7;
  int iVar8;
  undefined4 uVar9;
  float *pfVar10;
  undefined4 *puVar11;
  float *pfVar12;
  int iVar13;
  uint uVar14;
  uint uVar15;
  float10 extraout_ST0;
  double dVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  uint auStack_130 [4];
  int iStack_120;
  uint uStack_11c;
  float fStack_118;
  float fStack_114;
  float fStack_110;
  float fStack_10c;
  float fStack_108;
  float fStack_104;
  float fStack_100;
  float fStack_fc;
  float fStack_f8;
  float fStack_f4;
  float fStack_f0;
  float fStack_ec;
  undefined auStack_e8 [8];
  float fStack_e0;
  float fStack_dc;
  float fStack_d8;
  float fStack_d4;
  undefined8 uStack_d0;
  float fStack_c8;
  undefined auStack_c4 [20];
  undefined8 uStack_b0;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  uint *puStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  uint *puStack_64;
  int *piStack_60;
  float fStack_5c;
  float fStack_58;
  int iStack_54;
  uint *puStack_50;
  int *piStack_4c;
  int iStack_48;
  int *piStack_44;
  uint uStack_40;
  uint *puStack_3c;
  int *piStack_38;
  uint *puStack_34;
  undefined4 uStack_30;
  uint *puStack_2c;
  uint uStack_28;
  uint *puStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017ad109;
  pvStack_1c = ExceptionList;
  uStack_14 = 0;
  puStack_2c = param_2;
  ExceptionList = &pvStack_1c;
  piStack_38 = param_1;
  puVar6 = &stack0xfffffffc;
  if (param_2 != (uint *)0x0) {
    uVar15 = param_2[3];
    ExceptionList = &pvStack_1c;
    iVar8 = FUN_00b50240();
    if ((uint)*(ushort *)(iVar8 + 0x1da) <
        (uint)*(ushort *)(uVar15 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) {
      puStack_2c = param_2;
      puVar6 = puStack_20;
      if (param_2 != (uint *)0x0) {
        uVar15 = param_2[3];
        iVar8 = FUN_00cfb1a0();
        puVar5 = puStack_2c;
        if ((uint)*(ushort *)(iVar8 + 0x1da) <
            (uint)*(ushort *)(uVar15 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) {
          puStack_2c = param_2;
          puVar6 = puStack_20;
          if (param_2 != (uint *)0x0) {
            uVar15 = param_2[3];
            iVar8 = FUN_00aff8c0();
            param_2 = (uint *)(uint)*(ushort *)(iVar8 + 0x1da);
            puVar6 = puStack_20;
            if ((uint *)((uint)*(ushort *)(uVar15 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) <=
                param_2) {
              FUN_00746d50(&uStack_30,*(undefined4 *)param_1[5],0,*(undefined4 *)param_1[4],0,0,0);
              uStack_14 = CONCAT31(uStack_14._1_3_,6);
              (**(code **)(*uStack_30 + 0x10))(puStack_2c);
              puVar11 = (undefined4 *)FUN_00b077e0();
              uStack_160 = *puVar11;
              uStack_15c = puVar11[1];
              uStack_158 = puVar11[2];
              uStack_154 = puVar11[3];
              uStack_150 = puVar11[4];
              uStack_14c = puVar11[5];
              uStack_148 = puVar11[6];
              uStack_144 = puVar11[7];
              uStack_140 = puVar11[8];
              uStack_13c = puVar11[9];
              uStack_138 = puVar11[10];
              uStack_134 = puVar11[0xb];
              FUN_0071fcc0(auStack_c4);
              FUN_0071f260(&fStack_94,&uStack_160);
              uVar15 = 0;
              uStack_28 = (((int *)param_1[2])[1] - *(int *)param_1[2]) / 0x1c;
              iVar8 = (**(code **)(*uStack_30 + 0x18))();
              if (iVar8 != 0) {
                do {
                  iVar8 = param_1[3];
                  puVar11 = *(undefined4 **)(iVar8 + 4);
                  piStack_44 = (int *)(*(ushort *)(*(int *)param_1[4] + uVar15 * 2) + uStack_28);
                  if (*(undefined4 **)(iVar8 + 8) == puVar11) {
                    FUN_0063d9b0(puVar11,&piStack_44);
                  }
                  else {
                    *puVar11 = piStack_44;
                    *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 4;
                  }
                  uVar15 = uVar15 + 1;
                  uVar14 = (**(code **)(*uStack_30 + 0x18))();
                } while (uVar15 < uVar14);
              }
              puStack_24 = (uint *)0x0;
              iVar8 = (**(code **)(*uStack_30 + 0x14))();
              if (iVar8 != 0) {
                iVar8 = 0;
                do {
                  uStack_40 = *(uint *)param_1[5];
                  fStack_a8 = *(float *)(uStack_40 + 8 + iVar8);
                  uStack_b0 = *(undefined8 *)(uStack_40 + iVar8);
                  fVar18 = ((float)*(byte *)(uStack_40 + 0xc + iVar8) - DAT_018f8ffc) / DAT_018f8ff8
                  ;
                  fVar17 = ((float)*(byte *)(uStack_40 + 0xd + iVar8) - DAT_018f8ffc) / DAT_018f8ff8
                  ;
                  fVar19 = (fVar18 + fVar18) - DAT_018ce2f8;
                  fVar18 = (fVar17 + fVar17) - DAT_018ce2f8;
                  uVar15 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
                  fStack_58 = (DAT_018ce2f8 -
                              (float)(double)CONCAT44((uint)((ulonglong)(double)fVar19 >> 0x20) &
                                                      uVar15,SUB84((double)fVar19,0) &
                                                             (uint)DAT_018c0da0)) -
                              (float)(double)CONCAT44((uint)((ulonglong)(double)fVar18 >> 0x20) &
                                                      uVar15,SUB84((double)fVar18,0) &
                                                             (uint)DAT_018c0da0);
                  fVar17 = 0.0;
                  if (0.0 <= (float)((uint)fStack_58 ^ DAT_018c4ea0)) {
                    fVar17 = (float)((uint)fStack_58 ^ DAT_018c4ea0);
                  }
                  fVar20 = DAT_018ce2f8;
                  if (fVar17 <= DAT_018ce2f8) {
                    fVar20 = fVar17;
                  }
                  fVar17 = fVar20;
                  if (0.0 <= fVar19) {
                    fVar17 = (float)((uint)fVar20 ^ DAT_018c4ea0);
                  }
                  piStack_44 = (int *)(fVar17 + fVar19);
                  fStack_5c = (float)((uint)fVar20 ^ DAT_018c4ea0);
                  if (fVar18 < 0.0) {
                    fStack_5c = fVar20;
                  }
                  fStack_5c = fStack_5c + fVar18;
                  dVar16 = (double)(fStack_5c * fStack_5c + (float)piStack_44 * (float)piStack_44 +
                                   fStack_58 * fStack_58);
                  FUN_017267a0();
                  iVar4 = param_1[2];
                  puVar11 = *(undefined4 **)(iVar4 + 4);
                  fStack_9c = DAT_018ce2f8 / (float)dVar16;
                  puStack_98 = *(uint **)(uStack_40 + 0x10 + iVar8);
                  fStack_a4 = fStack_9c * (float)piStack_44;
                  fStack_a0 = fStack_9c * fStack_5c;
                  fStack_9c = fStack_9c * fStack_58;
                  if (*(undefined4 **)(iVar4 + 8) == puVar11) {
                    FUN_00725c30(puVar11,&uStack_b0);
                  }
                  else {
                    *puVar11 = (undefined4)uStack_b0;
                    puVar11[1] = uStack_b0._4_4_;
                    puVar11[2] = fStack_a8;
                    puVar11[3] = fStack_a4;
                    *(ulonglong *)(puVar11 + 4) = CONCAT44(fStack_9c,fStack_a0);
                    puVar11[6] = puStack_98;
                    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 0x1c;
                  }
                  iVar8 = iVar8 + 0x2c;
                  puStack_24 = (uint *)((int)puStack_24 + 1);
                  uVar15 = (**(code **)(*uStack_30 + 0x14))();
                } while (puStack_24 < uVar15);
              }
              puStack_24 = (uint *)0x0;
              param_2 = (uint *)(**(code **)(*uStack_30 + 0x14))();
              if (param_2 != (uint *)0x0) {
                iVar8 = uStack_28 * 0x1c;
                do {
                  iVar4 = *(int *)param_1[2];
                  puStack_24 = (uint *)((int)puStack_24 + 1);
                  fVar17 = *(float *)(iVar4 + 4 + iVar8);
                  fVar18 = *(float *)(iVar4 + iVar8);
                  fVar19 = *(float *)(iVar4 + 8 + iVar8);
                  *(ulonglong *)(iVar4 + iVar8) =
                       CONCAT44(fStack_88 * fVar18 + fStack_84 * fVar17 + fStack_80 * fVar19 +
                                fStack_6c,
                                fStack_94 * fVar18 + fStack_90 * fVar17 + fStack_8c * fVar19 +
                                fStack_70);
                  fStack_e0 = fStack_7c * fVar18 + fStack_78 * fVar17 + fStack_74 * fVar19 +
                              fStack_68;
                  *(float *)(iVar4 + 8 + iVar8) = fStack_e0;
                  iVar8 = iVar8 + 0x1c;
                  param_2 = (uint *)(**(code **)(*uStack_30 + 0x14))();
                } while (puStack_24 < param_2);
              }
              puVar6 = puStack_20;
              if (uStack_30 != (uint *)0x0) {
                param_2 = (uint *)(**(code **)*uStack_30)(1);
                puVar6 = puStack_20;
              }
            }
          }
        }
        else {
          FUN_0054ef60(puStack_2c + 0x55);
          uStack_14._0_1_ = 2;
          FUN_0054ef60(puVar5 + 0x5b);
          puStack_64 = (uint *)(*param_1 + 0x80);
          uStack_14._0_1_ = 3;
          piStack_60 = (int *)((uint)piStack_60 & 0xffffff00);
          FUN_00587410();
          puStack_24 = (uint *)(*param_1 + 0x90);
          uStack_14 = CONCAT31(uStack_14._1_3_,4);
          FUN_007323a0(&uStack_28,&fStack_100);
          uVar15 = uStack_28;
          if ((uStack_28 == *puStack_24) ||
             (cVar7 = FUN_00558ea0(&fStack_100,uStack_28 + 0x10), cVar7 != '\0')) {
            uVar15 = *puStack_24;
          }
          if (uVar15 == *(uint *)(*param_1 + 0x90)) {
            param_2 = (uint *)(uint)DAT_01eafe10;
            if (DAT_01eafe10 != 0) {
              param_2 = (uint *)FUN_01677520(DAT_01eafe10,
                                             "model lod generator: mesh not loaded (yet)");
            }
          }
          else {
            piStack_4c = *(int **)(uVar15 + 0x28);
            iStack_54 = 0;
            if ((iStack_120 != 0) &&
               (FUN_00730f80(&uStack_28,auStack_130), uStack_28 != *(uint *)(*param_1 + 0x98))) {
              iStack_54 = *(int *)(uStack_28 + 0x28);
            }
            puVar11 = (undefined4 *)FUN_00b077e0();
            uStack_160 = *puVar11;
            uStack_15c = puVar11[1];
            uStack_158 = puVar11[2];
            uStack_154 = puVar11[3];
            uStack_150 = puVar11[4];
            uStack_14c = puVar11[5];
            uStack_148 = puVar11[6];
            uStack_144 = puVar11[7];
            uStack_140 = puVar11[8];
            uStack_13c = puVar11[9];
            uStack_138 = puVar11[10];
            uStack_134 = puVar11[0xb];
            FUN_0071fcc0(auStack_c4);
            FUN_0071f260(&fStack_94,&uStack_160);
            pfVar10 = (float *)FUN_00b08320();
            pfVar12 = (float *)FUN_0074adf0(auStack_e8);
            fStack_58 = *pfVar10 / *pfVar12;
            fStack_5c = pfVar10[1] / pfVar12[1];
            piStack_44 = (int *)(pfVar10[2] / pfVar12[2]);
            FUN_00b06fb0(&fStack_dc);
            param_2 = (uint *)FUN_00b08910();
            puStack_3c = (uint *)(float)((float10)1 - extraout_ST0);
            if (0.0 < (float)puStack_3c) {
              puStack_34 = (uint *)((((int *)param_1[2])[1] - *(int *)param_1[2]) / 0x1c);
              puStack_2c = (uint *)0x0;
              iVar8 = piStack_4c[6];
              iVar4 = piStack_4c[7] - iVar8 >> 0x1f;
              if ((piStack_4c[7] - iVar8) / 0xc + iVar4 != iVar4) {
                uStack_30 = (uint *)0x0;
                do {
                  iVar4 = param_1[3];
                  uStack_28 = (int)puStack_34 + *(int *)((int)uStack_30 + iVar8);
                  puVar5 = *(uint **)(iVar4 + 4);
                  if (*(uint **)(iVar4 + 8) == puVar5) {
                    FUN_0063d9b0(puVar5,&uStack_28);
                  }
                  else {
                    *puVar5 = uStack_28;
                    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 4;
                  }
                  iVar4 = piStack_38[3];
                  uStack_28 = (int)puStack_34 + *(int *)((int)uStack_30 + iVar8 + 4);
                  puVar5 = *(uint **)(iVar4 + 4);
                  if (*(uint **)(iVar4 + 8) == puVar5) {
                    FUN_0063d9b0(puVar5,&uStack_28);
                  }
                  else {
                    *puVar5 = uStack_28;
                    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 4;
                  }
                  param_1 = piStack_38;
                  uStack_28 = (int)puStack_34 + *(int *)((int)uStack_30 + iVar8 + 8);
                  iVar8 = piStack_38[3];
                  puVar5 = *(uint **)(iVar8 + 4);
                  if (*(uint **)(iVar8 + 8) == puVar5) {
                    FUN_0063d9b0(puVar5,&uStack_28);
                  }
                  else {
                    *puVar5 = uStack_28;
                    *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 4;
                  }
                  uStack_30 = uStack_30 + 3;
                  puStack_2c = (uint *)((int)puStack_2c + 1);
                  iVar8 = piStack_4c[6];
                } while (puStack_2c < (uint *)((piStack_4c[7] - iVar8) / 0xc));
              }
              puStack_50 = (uint *)0x0;
              uStack_28 = piStack_4c[1];
              iVar8 = *piStack_4c;
              iVar4 = (int)(uStack_28 - iVar8) >> 0x1f;
              if ((int)(uStack_28 - iVar8) / 0x28 + iVar4 != iVar4) {
                puStack_24 = (uint *)0x0;
                fVar17 = DAT_018f9000;
                do {
                  fStack_c8 = *(float *)((int)puStack_24 + 8 + iVar8);
                  uVar9 = *(undefined4 *)((int)puStack_24 + 4 + iVar8);
                  uStack_b0 = CONCAT44(uVar9,*(undefined4 *)((int)puStack_24 + iVar8));
                  fStack_a4 = 0.0;
                  fStack_a0 = 0.0;
                  fStack_9c = 0.0;
                  if (((iStack_54 == 0) ||
                      (uStack_28 = *(uint *)(iStack_54 + 0xc), (int)uStack_28 < 1)) ||
                     (uStack_40 = *(uint *)(iStack_54 + 0x10), (int)uStack_40 < 1)) {
                    puStack_98 = (uint *)CONCAT22(CONCAT11((char)(int)((float)*(byte *)((int)
                                                  puStack_24 + 0x27 + iVar8) * (float)puStack_3c),
                                                  (char)(int)(((float)*(byte *)((int)puStack_24 +
                                                                                0x26 + iVar8) /
                                                              fVar17) * fStack_d4 * fVar17)),
                                                  CONCAT11((char)(int)(((float)*(byte *)((int)
                                                  puStack_24 + 0x25 + iVar8) / fVar17) * fStack_d8 *
                                                  fVar17),(char)(int)(((float)*(byte *)((int)
                                                  puStack_24 + 0x24 + iVar8) / fVar17) * fStack_dc *
                                                  fVar17)));
                    puStack_2c = puStack_98;
                  }
                  else {
                    iVar4 = *(int *)(iStack_54 + 4);
                    iVar13 = ((uint)(int)((float)(int)uStack_40 *
                                         *(float *)((int)puStack_24 + 0x1c + iVar8)) % uStack_40) *
                             uStack_28 +
                             (uint)(int)((float)(int)uStack_28 *
                                        *(float *)((int)puStack_24 + 0x18 + iVar8)) % uStack_28;
                    uStack_30 = (uint *)CONCAT13(*(undefined *)(iVar4 + 3 + iVar13 * 4),
                                                 CONCAT12(*(undefined *)(iVar4 + 2 + iVar13 * 4),
                                                          CONCAT11(*(undefined *)
                                                                    (iVar4 + 1 + iVar13 * 4),
                                                                   *(undefined *)
                                                                    (iVar4 + iVar13 * 4))));
                    puStack_98 = uStack_30;
                    param_1 = piStack_38;
                  }
                  iVar4 = param_1[2];
                  puVar11 = *(undefined4 **)(iVar4 + 4);
                  fStack_a8 = fStack_c8;
                  if (*(undefined4 **)(iVar4 + 8) == puVar11) {
                    FUN_00725c30(puVar11,&uStack_b0);
                    fVar17 = DAT_018f9000;
                  }
                  else {
                    *puVar11 = *(undefined4 *)((int)puStack_24 + iVar8);
                    puVar11[1] = uVar9;
                    puVar11[2] = fStack_c8;
                    puVar11[3] = 0;
                    *(undefined8 *)(puVar11 + 4) = 0;
                    puVar11[6] = puStack_98;
                    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 0x1c;
                  }
                  puStack_50 = (uint *)((int)puStack_50 + 1);
                  puStack_24 = (uint *)((int)puStack_24 + 0x28);
                  uStack_28 = piStack_4c[1];
                  iVar8 = *piStack_4c;
                } while (puStack_50 < (uint *)((int)(uStack_28 - iVar8) / 0x28));
              }
              puStack_24 = (uint *)0x0;
              param_2 = (uint *)((int)(uStack_28 - iVar8) / 0x28);
              if (param_2 != (uint *)0x0) {
                iVar8 = (int)puStack_34 * 0x1c;
                do {
                  puStack_24 = (uint *)((int)puStack_24 + 1);
                  iVar4 = *(int *)param_1[2];
                  uVar3 = *(undefined8 *)(iVar8 + iVar4);
                  fStack_c8 = *(float *)(iVar8 + 8 + iVar4);
                  uStack_d0._4_4_ = (float)((ulonglong)uVar3 >> 0x20);
                  uStack_d0._4_4_ = uStack_d0._4_4_ * fStack_5c;
                  uStack_d0._0_4_ = (float)uVar3;
                  uStack_d0._0_4_ = (float)uStack_d0 * fStack_58;
                  fVar17 = fStack_c8 * (float)piStack_44;
                  fStack_e0 = uStack_d0._4_4_ * fStack_78 + (float)uStack_d0 * fStack_7c +
                              fVar17 * fStack_74 + fStack_68;
                  *(ulonglong *)(iVar8 + iVar4) =
                       CONCAT44(uStack_d0._4_4_ * fStack_84 + (float)uStack_d0 * fStack_88 +
                                fVar17 * fStack_80 + fStack_6c,
                                uStack_d0._4_4_ * fStack_90 + (float)uStack_d0 * fStack_94 +
                                fVar17 * fStack_8c + fStack_70);
                  *(float *)(iVar8 + 8 + iVar4) = fStack_e0;
                  iVar8 = iVar8 + 0x1c;
                  param_2 = (uint *)((piStack_4c[1] - *piStack_4c) / 0x28);
                  uStack_d0 = uVar3;
                } while (puStack_24 < param_2);
              }
            }
          }
          uStack_14 = CONCAT31(uStack_14._1_3_,5);
          if ((char)piStack_60 != '\0') {
            LOCK();
            param_2 = (uint *)*puStack_64;
            *puStack_64 = *puStack_64 + 0x80000000;
            UNLOCK();
            if ((((uint)param_2 & 0x40000000) == 0) && (-0x80000000 < (int)param_2)) {
              LOCK();
              uVar15 = *puStack_64;
              *puStack_64 = *puStack_64 | 0x40000000;
              UNLOCK();
              if ((uVar15 >> 0x1e & 1) == 0) {
                uVar9 = FUN_00554e40();
                param_2 = (uint *)SetEvent(uVar9);
              }
            }
          }
          if (0xf < uStack_11c) {
            uVar14 = uStack_11c + 1;
            uVar15 = auStack_130[0];
            if (0xfff < uVar14) {
              uVar15 = *(uint *)(auStack_130[0] - 4);
              uVar14 = uStack_11c + 0x24;
              if (0x1f < (auStack_130[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            param_2 = (uint *)FUN_01674ea0(uVar15,uVar14);
          }
          iStack_120 = 0;
          uStack_11c = 0xf;
          auStack_130[0] = auStack_130[0] & 0xffffff00;
          puVar6 = puStack_20;
          if (0xf < (uint)fStack_ec) {
            uVar15 = (int)fStack_ec + 1;
            fVar17 = fStack_100;
            if (0xfff < uVar15) {
              fVar17 = *(float *)((int)fStack_100 + -4);
              uVar15 = (int)fStack_ec + 0x24;
              if (0x1f < ((int)fStack_100 - (int)fVar17) - 4U) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            param_2 = (uint *)FUN_01674ea0(fVar17,uVar15);
            puVar6 = puStack_20;
          }
        }
      }
    }
    else {
      iStack_48 = 0;
      piStack_44 = (int *)0x0;
      puStack_3c = puStack_2c + 0x69;
      puStack_24 = (uint *)(*param_1 + 0x88);
      uStack_14 = CONCAT31(uStack_14._1_3_,1);
      FUN_007323a0(&uStack_28,puStack_3c);
      uVar15 = uStack_28;
      if ((uStack_28 == *puStack_24) ||
         (cVar7 = FUN_00558ea0(puStack_3c,uStack_28 + 0x10), cVar7 != '\0')) {
        uVar15 = *puStack_24;
      }
      if (uVar15 == *(uint *)(*param_1 + 0x88)) {
        uVar9 = FUN_00b53ad0(&puStack_64,0);
        param_2 = (uint *)FUN_005587e0(uVar9);
        piVar2 = piStack_60;
        if (piStack_60 != (int *)0x0) {
          LOCK();
          piVar1 = piStack_60 + 1;
          iVar8 = *piVar1;
          param_2 = (uint *)*piVar1;
          *piVar1 = iVar8 + -1;
          UNLOCK();
          if (iVar8 + -1 == 0) {
            (**(code **)*piStack_60)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar8 = *piVar1;
            param_2 = (uint *)*piVar1;
            *piVar1 = iVar8 + -1;
            UNLOCK();
            if (iVar8 + -1 == 0) {
              param_2 = (uint *)(**(code **)(*piVar2 + 4))();
            }
          }
        }
      }
      else {
        param_2 = (uint *)FUN_0056ecd0(uVar15 + 0x28);
      }
      iVar8 = iStack_48;
      if (iStack_48 != 0) {
        pfVar10 = (float *)FUN_00b077e0();
        fStack_94 = *pfVar10;
        fStack_90 = pfVar10[1];
        fStack_8c = pfVar10[2];
        fStack_88 = pfVar10[3];
        fStack_84 = pfVar10[4];
        fStack_80 = pfVar10[5];
        fStack_7c = pfVar10[6];
        fStack_78 = pfVar10[7];
        fStack_74 = pfVar10[8];
        fStack_70 = pfVar10[9];
        fStack_6c = pfVar10[10];
        fStack_68 = pfVar10[0xb];
        FUN_0071fcc0(&uStack_160);
        FUN_0071f260(&fStack_118,&fStack_94);
        puStack_3c = (uint *)((((int *)param_1[2])[1] - *(int *)param_1[2]) / 0x1c);
        puStack_24 = (uint *)0x0;
        if (*(int *)(iVar8 + 0x20) - *(int *)(iVar8 + 0x1c) >> 2 != 0) {
          do {
            iVar4 = param_1[3];
            uStack_28 = *(int *)(*(int *)(iVar8 + 0x1c) + (int)puStack_24 * 4) + (int)puStack_3c;
            puStack_50 = *(uint **)(iVar4 + 4);
            if (*(uint **)(iVar4 + 8) == puStack_50) {
              FUN_0063d9b0(puStack_50,&uStack_28);
            }
            else {
              *puStack_50 = uStack_28;
              *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 4;
            }
            puStack_24 = (uint *)((int)puStack_24 + 1);
            param_1 = piStack_38;
          } while (puStack_24 < (uint)(*(int *)(iVar8 + 0x20) - *(int *)(iVar8 + 0x1c) >> 2));
        }
        puStack_24 = *(uint **)(iVar8 + 0x14);
        iVar8 = *(int *)(iVar8 + 0x10);
        puStack_34 = (uint *)0x0;
        iVar4 = (int)puStack_24 - iVar8 >> 0x1f;
        if (((int)puStack_24 - iVar8) / 0x54 + iVar4 != iVar4) {
          piStack_38 = (int *)0x0;
          do {
            fStack_a8 = *(float *)((int)piStack_38 + iVar8 + 8);
            uStack_b0 = *(undefined8 *)((int)piStack_38 + iVar8);
            fStack_9c = *(float *)((int)piStack_38 + iVar8 + 0x14);
            uVar3 = *(undefined8 *)((int)piStack_38 + iVar8 + 0xc);
            puStack_98 = *(uint **)((int)piStack_38 + iVar8 + 0x18);
            iVar8 = param_1[2];
            fStack_a4 = (float)uVar3;
            fStack_a0 = (float)((ulonglong)uVar3 >> 0x20);
            puVar11 = *(undefined4 **)(iVar8 + 4);
            if (*(undefined4 **)(iVar8 + 8) == puVar11) {
              FUN_00725c30(puVar11,&uStack_b0);
            }
            else {
              uStack_b0._4_4_ = (undefined4)((ulonglong)uStack_b0 >> 0x20);
              *puVar11 = (undefined4)uStack_b0;
              puVar11[1] = uStack_b0._4_4_;
              puVar11[2] = fStack_a8;
              puVar11[3] = fStack_a4;
              *(ulonglong *)(puVar11 + 4) = CONCAT44(fStack_9c,fStack_a0);
              puVar11[6] = puStack_98;
              *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 0x1c;
            }
            piStack_38 = piStack_38 + 0x15;
            puStack_34 = (uint *)((int)puStack_34 + 1);
            puStack_24 = *(uint **)(iStack_48 + 0x14);
            iVar8 = *(int *)(iStack_48 + 0x10);
          } while (puStack_34 < (uint)(((int)puStack_24 - iVar8) / 0x54));
        }
        puStack_34 = (uint *)0x0;
        param_2 = (uint *)(((int)puStack_24 - iVar8) / 0x54);
        if (param_2 != (uint *)0x0) {
          iVar8 = (int)puStack_3c * 0x1c;
          do {
            puStack_34 = (uint *)((int)puStack_34 + 1);
            iVar4 = *(int *)param_1[2];
            fVar17 = *(float *)(iVar4 + 4 + iVar8);
            fVar18 = *(float *)(iVar4 + iVar8);
            fVar19 = *(float *)(iVar4 + 8 + iVar8);
            fStack_d4 = fVar18 * fStack_100 + fVar17 * fStack_fc + fVar19 * fStack_f8 + fStack_ec;
            *(ulonglong *)(iVar4 + iVar8) =
                 CONCAT44(fVar18 * fStack_10c + fVar17 * fStack_108 + fVar19 * fStack_104 +
                          fStack_f0,
                          fVar18 * fStack_118 + fVar17 * fStack_114 + fVar19 * fStack_110 +
                          fStack_f4);
            *(float *)(iVar4 + 8 + iVar8) = fStack_d4;
            iVar8 = iVar8 + 0x1c;
            param_2 = (uint *)((*(int *)(iStack_48 + 0x14) - *(int *)(iStack_48 + 0x10)) / 0x54);
          } while (puStack_34 < param_2);
        }
      }
      piVar2 = piStack_44;
      puVar6 = puStack_20;
      if (piStack_44 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_44 + 1;
        iVar8 = *piVar1;
        param_2 = (uint *)*piVar1;
        *piVar1 = iVar8 + -1;
        UNLOCK();
        if (iVar8 + -1 == 0) {
          (**(code **)*piStack_44)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar8 = *piVar1;
          param_2 = (uint *)*piVar1;
          *piVar1 = iVar8 + -1;
          UNLOCK();
          puVar6 = puStack_20;
          if (iVar8 + -1 == 0) {
            param_2 = (uint *)(**(code **)(*piVar2 + 4))();
            puVar6 = puStack_20;
          }
        }
      }
    }
  }
  puStack_20 = puVar6;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar8 = *piVar2;
    param_2 = (uint *)*piVar2;
    *piVar2 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      param_2 = (uint *)(**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar8 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        param_2 = (uint *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return param_2;
}



/* FUNCTION 10463 ; VA 0x0072cfe0 ; FUN_0072cfe0 */

void __fastcall FUN_0072cfe0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined *puVar4;
  undefined auStack_8c [36];
  undefined4 uStack_68;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int aiStack_48 [9];
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad143;
  pvStack_10 = ExceptionList;
  puStack_18 = auStack_8c;
  puStack_1c = &uStack_58;
  uStack_58 = *param_1;
  piStack_50 = (int *)param_1[2];
  ExceptionList = &pvStack_10;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piStack_50[1] = piStack_50[1] + 1;
    UNLOCK();
    piStack_50 = (int *)param_1[2];
  }
  uStack_54 = param_1[1];
  piStack_20 = aiStack_48;
  piStack_24 = (int *)0x0;
  uStack_8 = 1;
  puVar4 = auStack_8c;
  uStack_14 = uStack_58;
  if ((undefined4 *)param_1[0xd] != (undefined4 *)0x0) {
    piStack_24 = (int *)(*(code *)**(undefined4 **)param_1[0xd])(aiStack_48);
    puVar4 = puStack_18;
  }
  puStack_18 = puVar4;
  uStack_68 = 0;
  uStack_8 = 3;
  uStack_68 = FUN_007265f0(&uStack_58);
  uStack_8 = 0xffffffff;
  if (piStack_24 != (int *)0x0) {
    (**(code **)(*piStack_24 + 0x10))
              (CONCAT31((int3)((uint)aiStack_48 >> 8),piStack_24 != aiStack_48));
    piStack_24 = (int *)0x0;
  }
  piVar2 = piStack_50;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_50[1] + -1;
    piStack_50[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_1[2] != 0) {
    LOCK();
    piVar2 = (int *)(param_1[2] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  FUN_00730db0(param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10464 ; VA 0x0072d120 ; FUN_0072d120 */

void FUN_0072d120(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  
  if (param_2 != 0) {
    puVar1 = param_1 + 5;
    do {
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      param_1[4] = 0;
      param_1[5] = 0;
      param_1[6] = 0;
      *param_1 = 0;
      param_1 = param_1 + 7;
      puVar1[-4] = 0;
      puVar1[-3] = 0;
      puVar1[-2] = 0;
      puVar1[-1] = 0;
      *puVar1 = 0;
      puVar1[1] = 0;
      param_2 = param_2 + -1;
      puVar1 = puVar1 + 7;
    } while (param_2 != 0);
  }
  return;
}



/* FUNCTION 10465 ; VA 0x0072d1a0 ; FUN_0072d1a0 */

/* WARNING: Type propagation algorithm not settling */

uint __thiscall
FUN_0072d1a0(int *param_1,int *param_2,int *param_3,int *param_4,uint param_5,int *param_6,
            undefined4 param_7,int *param_8)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  char cVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int aiStack_110 [2];
  int *piStack_108;
  undefined auStack_104 [12];
  undefined4 uStack_f8;
  undefined4 *puStack_f4;
  undefined ***pppuStack_f0;
  int *piStack_ec;
  undefined **appuStack_dc [15];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_90;
  undefined **ppuStack_8c;
  undefined *puStack_44;
  uint uStack_40;
  int *piStack_3c;
  undefined auStack_38 [24];
  uint *puStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined **ppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad1c5;
  pvStack_10 = ExceptionList;
  ppuStack_14 = (undefined **)0x0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  if ((param_5 == 0) && (ExceptionList = &pvStack_10, param_3 != (int *)0x0)) {
    appuStack_dc[0] = &PTR_018be314;
    piStack_ec = (int *)param_5;
    pppuStack_f0 = appuStack_dc + 1;
    uStack_8 = 3;
    ppuStack_14 = (undefined **)0x1;
    ppuStack_8c = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_90 = 0x48;
    puStack_f4 = (undefined4 *)0x72d227;
    ExceptionList = &pvStack_10;
    FUN_00554f20();
    uStack_8 = 5;
    *(undefined ***)(appuStack_dc[0][1] + (int)appuStack_dc) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)(appuStack_dc[0][1] + (int)&stack0xffffff20) = appuStack_dc[0][1] + -0x50;
    piStack_ec = (int *)0x72d260;
    FUN_0054ee60();
    appuStack_dc[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_a0 = 0;
    uStack_9c = 4;
    uStack_8._0_1_ = 6;
    piStack_ec = *(int **)(*(int *)(*param_3 + 4) + 0x38 + (int)param_3);
    pppuStack_f0 = (undefined ***)0x72d299;
    FUN_0056f130();
    piStack_ec = (int *)auStack_38;
    pppuStack_f0 = (undefined ***)0x72d2a8;
    piStack_ec = (int *)FUN_0058c400();
    pppuStack_f0 = (undefined ***)&puStack_20;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    puStack_f4 = (undefined4 *)0x72d2b6;
    piStack_ec = (int *)FUN_00729170();
    pppuStack_f0 = (undefined ***)0x72d2c2;
    FUN_005587e0();
    piVar9 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        piStack_ec = (int *)0x72d2d8;
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar9 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          piStack_ec = (int *)0x72d2e8;
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    piStack_ec = (int *)0x72d2f0;
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    piStack_ec = (int *)0x72d2ff;
    FUN_00570540();
  }
  piVar9 = piStack_18;
  if (param_2 == (int *)0x1) {
    uVar6 = param_5;
    if ((param_5 != 0) && (*(int *)(param_5 + 0x10) != 0)) {
      param_2 = (int *)*piStack_18;
      ppuStack_14 = &puStack_44;
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      piStack_3c = param_6;
      piVar9 = piStack_18 + 1;
      uStack_8._0_1_ = 10;
      puStack_44 = (undefined *)param_2;
      uStack_40 = param_5;
      piStack_18 = aiStack_110;
      FUN_0054ef60(piVar9);
      piStack_ec = (int *)0x0;
      uStack_8._0_1_ = 0xc;
      piStack_ec = (int *)FUN_00725fe0(&puStack_44);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00729dd0();
      uVar6 = FUN_0072e530();
    }
  }
  else {
    piVar1 = piStack_18 + 1;
    if (DAT_01eafe10 != 0) {
      piStack_ec = piVar1;
      if (0xf < (uint)piStack_18[6]) {
        piStack_ec = (int *)*piVar1;
      }
      puStack_f4 = (undefined4 *)(uint)DAT_01eafe10;
      pppuStack_f0 = (undefined ***)0x18f8bc0;
      uStack_f8 = 0x72d334;
      FUN_01677520();
    }
    puStack_20 = (uint *)(*piVar9 + 0x80);
    piStack_1c = (int *)((uint)piStack_1c & 0xffffff00);
    piStack_ec = (int *)0x72d34b;
    FUN_00587410();
    ppuStack_14 = (undefined **)(*piVar9 + 0x88);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    piVar9 = (int *)*ppuStack_14;
    cVar5 = *(char *)(piVar9[1] + 0xd);
    param_2 = piVar9;
    piVar7 = (int *)piVar9[1];
    while (cVar5 == '\0') {
      pppuStack_f0 = (undefined ***)(piVar7 + 4);
      puStack_f4 = (undefined4 *)0x72d37a;
      piStack_ec = piVar1;
      cVar5 = FUN_00558ea0();
      if (cVar5 == '\0') {
        if (*(char *)((int)piVar9 + 0xd) != '\0') {
          piStack_ec = piVar7 + 4;
          puStack_f4 = (undefined4 *)0x72d396;
          pppuStack_f0 = (undefined ***)piVar1;
          cVar5 = FUN_00558ea0();
          if (cVar5 != '\0') {
            piVar9 = piVar7;
          }
        }
        piVar8 = (int *)*piVar7;
        param_2 = piVar7;
      }
      else {
        piVar8 = (int *)piVar7[2];
      }
      piVar7 = piVar8;
      cVar5 = *(char *)((int)piVar8 + 0xd);
    }
    piVar7 = piVar9;
    if (*(char *)((int)piVar9 + 0xd) != '\0') {
      piVar7 = (int *)(*ppuStack_14 + 4);
    }
    cVar5 = *(char *)(*piVar7 + 0xd);
    piVar7 = (int *)*piVar7;
    piVar8 = param_2;
    while (param_2 = piVar8, cVar5 == '\0') {
      piStack_ec = piVar7 + 4;
      puStack_f4 = (undefined4 *)0x72d3cd;
      pppuStack_f0 = (undefined ***)piVar1;
      cVar5 = FUN_00558ea0();
      if (cVar5 == '\0') {
        piVar8 = (int *)piVar7[2];
      }
      else {
        piVar8 = (int *)*piVar7;
        piVar9 = piVar7;
      }
      cVar5 = *(char *)((int)piVar8 + 0xd);
      piVar7 = piVar8;
      piVar8 = param_2;
    }
    while (param_2 != piVar9) {
      piStack_ec = (int *)0x72d3f8;
      FUN_00551320();
    }
    puStack_f4 = &param_2;
    uStack_f8 = 0x72d40b;
    pppuStack_f0 = (undefined ***)piVar8;
    piStack_ec = piVar9;
    FUN_005f6cc0();
    piStack_ec = (int *)0x18f8be0;
    param_2 = (int *)auStack_104;
    aiStack_110[1] = 0x72d423;
    piStack_108 = piVar1;
    FUN_0054ef60();
    piStack_108 = (int *)0x72d42a;
    uVar6 = FUN_00733a30();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if ((char)piStack_1c != '\0') {
      LOCK();
      uVar6 = *puStack_20;
      *puStack_20 = *puStack_20 + 0x80000000;
      UNLOCK();
      if (((uVar6 & 0x40000000) == 0) && (-0x80000000 < (int)uVar6)) {
        LOCK();
        uVar3 = *puStack_20;
        *puStack_20 = *puStack_20 | 0x40000000;
        UNLOCK();
        if ((uVar3 >> 0x1e & 1) == 0) {
          piStack_ec = (int *)0x72d45a;
          piStack_ec = (int *)FUN_00554e40();
          pppuStack_f0 = (undefined ***)0x72d461;
          uVar6 = SetEvent();
        }
      }
    }
  }
  piVar9 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(param_4 + 1);
    uVar3 = *puVar2;
    uVar6 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_ec = (int *)0x72d47a;
      (**(code **)*param_4)();
      LOCK();
      puVar2 = (uint *)(piVar9 + 2);
      uVar3 = *puVar2;
      uVar6 = *puVar2;
      *puVar2 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        piStack_ec = (int *)0x72d48a;
        uVar6 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  piVar9 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(param_6 + 1);
    uVar3 = *puVar2;
    uVar6 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_ec = (int *)0x72d4a0;
      (**(code **)*param_6)();
      LOCK();
      puVar2 = (uint *)(piVar9 + 2);
      uVar3 = *puVar2;
      uVar6 = *puVar2;
      *puVar2 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        piStack_ec = (int *)0x72d4b0;
        uVar6 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  piVar9 = param_8;
  if (param_8 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(param_8 + 1);
    uVar3 = *puVar2;
    uVar6 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_ec = (int *)0x72d4c6;
      uVar6 = (**(code **)*param_8)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piStack_ec = (int *)0x72d4d5;
        uVar6 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 10466 ; VA 0x0072d580 ; FUN_0072d580 */

void __thiscall
FUN_0072d580(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined8 param_15,undefined4 param_16)

{
  char cVar1;
  undefined **ppuVar2;
  undefined4 uVar3;
  undefined auStack_2f0 [120];
  undefined auStack_278 [120];
  undefined auStack_200 [120];
  undefined auStack_188 [120];
  undefined auStack_110 [120];
  undefined4 uStack_98;
  undefined4 uStack_94;
  int iStack_90;
  undefined auStack_88 [36];
  undefined4 uStack_64;
  int iStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ad23c;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_008f7870(param_1[1]);
  uStack_98 = *param_1;
  puStack_1c = &uStack_98;
  iStack_90 = param_1[2];
  if (iStack_90 != 0) {
    LOCK();
    *(int *)(iStack_90 + 4) = *(int *)(iStack_90 + 4) + 1;
    UNLOCK();
    iStack_90 = param_1[2];
  }
  uStack_94 = param_1[1];
  puStack_20 = auStack_88;
  uStack_64 = 0;
  iStack_8._0_1_ = 2;
  if ((undefined4 *)param_1[0xd] != (undefined4 *)0x0) {
    uStack_64 = (*(code *)**(undefined4 **)param_1[0xd])(auStack_88);
  }
  iStack_60 = param_2;
  LOCK();
  *(int *)(param_2 + 0x28) = *(int *)(param_2 + 0x28) + 1;
  UNLOCK();
  uStack_24 = param_16;
  uStack_5c = param_3;
  uStack_58 = param_4;
  uStack_54 = param_5;
  uStack_50 = param_6;
  uStack_4c = param_7;
  uStack_48 = param_8;
  uStack_44 = param_9;
  uStack_40 = param_10;
  uStack_3c = param_11;
  uStack_38 = param_12;
  uStack_34 = param_13;
  uStack_30 = param_14;
  uStack_2c = param_15;
  iStack_8._0_1_ = 3;
  FUN_007293c0(&uStack_98);
  iStack_8._0_1_ = 4;
  uVar3 = 0;
  FUN_007293c0(auStack_2f0);
  iStack_8._0_1_ = 5;
  FUN_007293c0(auStack_278);
  iStack_8._0_1_ = 6;
  FUN_007293c0(auStack_200);
  iStack_8._0_1_ = 7;
  cVar1 = FUN_00585a40(auStack_110,uVar3);
  if (cVar1 == '\0') {
    FUN_007293c0(auStack_110);
    iStack_8._0_1_ = 8;
    puStack_20 = (undefined *)FUN_01674e20(0x78);
    iStack_8._0_1_ = 9;
    if (puStack_20 != (undefined *)0x0) {
      FUN_007293c0(auStack_188);
    }
    FUN_00729e50();
    FUN_00729e50();
    cStack_11 = '\x01';
  }
  else {
    FUN_00729e50();
    cStack_11 = '\0';
  }
  FUN_00729e50();
  ppuVar2 = &PTR_FUN_018f8fd8;
  if (cStack_11 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  FUN_00729e50(ppuVar2);
  FUN_00729e50();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00729e50();
  FUN_0090ca30(ppuVar2);
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10467 ; VA 0x0072d7a0 ; FUN_0072d7a0 */

uint __fastcall FUN_0072d7a0(int *param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 *puStack_38;
  int *piStack_34;
  undefined4 uStack_24;
  int *piStack_20;
  uint *puStack_1c;
  char cStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ad260;
  pvStack_10 = ExceptionList;
  puStack_38 = &uStack_24;
  piStack_34 = (int *)param_1[1];
  uStack_3c = 0x72d7cc;
  ExceptionList = &pvStack_10;
  FUN_0114fa10();
  puStack_1c = (uint *)(*param_1 + 0x80);
  uStack_8 = 0;
  cStack_18 = '\0';
  piStack_34 = (int *)0x72d7ea;
  FUN_00587410();
  piStack_34 = param_1 + 3;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puStack_38 = (undefined4 *)0x72d7ff;
  puVar5 = (undefined4 *)FUN_0072a470();
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  *puVar5 = uStack_24;
  piVar3 = (int *)puVar5[1];
  puVar5[1] = piStack_20;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      piStack_34 = (int *)0x72d830;
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        piStack_34 = (int *)0x72d840;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piStack_34 = (int *)0x0;
  puStack_14 = auStack_4c;
  FUN_0054ef60(param_1 + 3);
  uVar6 = FUN_00733a30();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (cStack_18 != '\0') {
    LOCK();
    uVar6 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar6 & 0x40000000) == 0) && (-0x80000000 < (int)uVar6)) {
      LOCK();
      uVar2 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        piStack_34 = (int *)0x72d88c;
        piStack_34 = (int *)FUN_00554e40();
        puStack_38 = (undefined4 *)0x72d893;
        uVar6 = SetEvent();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_20 + 1);
    uVar2 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      piStack_34 = (int *)0x72d8a9;
      uVar6 = (**(code **)*piStack_20)();
      LOCK();
      piVar3 = piStack_20 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piStack_34 = (int *)0x72d8b8;
        uVar6 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 10468 ; VA 0x0072d8d0 ; FUN_0072d8d0 */

void __fastcall FUN_0072d8d0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined *puVar4;
  undefined auStack_8c [36];
  undefined4 uStack_68;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int aiStack_48 [9];
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad293;
  pvStack_10 = ExceptionList;
  puStack_18 = auStack_8c;
  puStack_1c = &uStack_58;
  uStack_58 = *param_1;
  piStack_50 = (int *)param_1[2];
  ExceptionList = &pvStack_10;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piStack_50[1] = piStack_50[1] + 1;
    UNLOCK();
    piStack_50 = (int *)param_1[2];
  }
  uStack_54 = param_1[1];
  piStack_20 = aiStack_48;
  piStack_24 = (int *)0x0;
  uStack_8 = 1;
  puVar4 = auStack_8c;
  uStack_14 = uStack_58;
  if ((undefined4 *)param_1[0xd] != (undefined4 *)0x0) {
    piStack_24 = (int *)(*(code *)**(undefined4 **)param_1[0xd])(aiStack_48);
    puVar4 = puStack_18;
  }
  puStack_18 = puVar4;
  uStack_68 = 0;
  uStack_8 = 3;
  uStack_68 = FUN_007263f0(&uStack_58);
  uStack_8 = 0xffffffff;
  if (piStack_24 != (int *)0x0) {
    (**(code **)(*piStack_24 + 0x10))
              (CONCAT31((int3)((uint)aiStack_48 >> 8),piStack_24 != aiStack_48));
    piStack_24 = (int *)0x0;
  }
  piVar2 = piStack_50;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_50[1] + -1;
    piStack_50[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_1[2] != 0) {
    LOCK();
    piVar2 = (int *)(param_1[2] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  FUN_0072e9d0(param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10469 ; VA 0x0072da10 ; FUN_0072da10 */

void __fastcall FUN_0072da10(int param_1)

{
  undefined auStack_10 [12];
  
  if (*(int **)(param_1 + 0x24) != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0072da1d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(param_1 + 0x24) + 8))();
    return;
  }
  FUN_016ddb1f();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01d4e5ec);
}



/* FUNCTION 10470 ; VA 0x0072da20 ; FUN_0072da20 */

void __fastcall FUN_0072da20(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad2a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int **)(param_1 + 0x24) != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(param_1 + 0x24) + 8))
              (&stack0x00000004,&stack0x00000008,&stack0x00000038);
    FUN_0056cd30();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
  FUN_016ddc9c();
}



/* FUNCTION 10471 ; VA 0x0072da80 ; FUN_0072da80 */

uint FUN_0072da80(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = param_1[1];
  if ((uVar1 <= param_2[1]) && ((uVar1 < param_2[1] || (uVar1 = *param_1, uVar1 < *param_2)))) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 10472 ; VA 0x0072dab0 ; FUN_0072dab0 */

void FUN_0072dab0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x34);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 10473 ; VA 0x0072dad0 ; FUN_0072dad0 */

void __fastcall FUN_0072dad0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x34);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 10474 ; VA 0x0072daf0 ; FUN_0072daf0 */

void __thiscall FUN_0072daf0(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffffe;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 2;
  param_1[2] = param_2 + param_4 * 2;
  return;
}



/* FUNCTION 10475 ; VA 0x0072db50 ; FUN_0072db50 */

void __thiscall FUN_0072db50(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x1c) * 0x1c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x1c;
  param_1[2] = param_2 + param_4 * 0x1c;
  return;
}



/* FUNCTION 10476 ; VA 0x0072dbe0 ; FUN_0072dbe0 */

void __fastcall FUN_0072dbe0(int param_1)

{
  FUN_00725f30(param_1 + 4);
  return;
}



/* FUNCTION 10477 ; VA 0x0072dbf0 ; FUN_0072dbf0 */

void FUN_0072dbf0(undefined4 *param_1)

{
  *param_1 = std::_Func_impl_no_alloc<class_<lambda_3354f2be7bc98ee13c22b413eb6cdd34>,void>::vftable
  ;
  return;
}



/* FUNCTION 10478 ; VA 0x0072dc00 ; FUN_0072dc00 */

void __fastcall FUN_0072dc00(int param_1)

{
  FUN_00726000(param_1 + 4);
  return;
}



/* FUNCTION 10479 ; VA 0x0072dc10 ; FUN_0072dc10 */

void __thiscall FUN_0072dc10(int param_1,undefined4 *param_2)

{
  *param_2 = std::_Func_impl_no_alloc<class_<lambda_7ccdc3f125b8f9188f7cea3685f0313c>,void>::vftable
  ;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 10480 ; VA 0x0072dc30 ; FUN_0072dc30 */

void __fastcall FUN_0072dc30(int param_1)

{
  FUN_007260d0(param_1 + 8);
  return;
}



/* FUNCTION 10481 ; VA 0x0072dc40 ; FUN_0072dc40 */

void __fastcall FUN_0072dc40(int param_1)

{
  FUN_00726200(param_1 + 8);
  return;
}



/* FUNCTION 10482 ; VA 0x0072dc50 ; FUN_0072dc50 */

void __fastcall FUN_0072dc50(int param_1)

{
  FUN_00726330(param_1 + 8);
  return;
}



/* FUNCTION 10483 ; VA 0x0072dc60 ; FUN_0072dc60 */

void __fastcall FUN_0072dc60(int param_1)

{
  FUN_00726460(param_1 + 4);
  return;
}



/* FUNCTION 10484 ; VA 0x0072dc70 ; FUN_0072dc70 */

void __fastcall FUN_0072dc70(int param_1)

{
  FUN_00726530(param_1 + 8);
  return;
}



/* FUNCTION 10485 ; VA 0x0072dc80 ; FUN_0072dc80 */

void __thiscall FUN_0072dc80(int param_1,undefined4 *param_2)

{
  *param_2 = std::_Func_impl_no_alloc<class_<lambda_fe8208ab3e340b85ba43ba13f4dc2d14>,void>::vftable
  ;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 10486 ; VA 0x0072dca0 ; FUN_0072dca0 */

void __thiscall FUN_0072dca0(undefined4 param_1,char param_2)

{
  FUN_00729dd0();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x28);
  }
  return;
}



/* FUNCTION 10487 ; VA 0x0072dcd0 ; FUN_0072dcd0 */

void __thiscall FUN_0072dcd0(int param_1,char param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x3c);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x10))(piVar2 != (int *)(param_1 + 0x18));
    *(undefined4 *)(param_1 + 0x3c) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x40);
  }
  return;
}



/* FUNCTION 10488 ; VA 0x0072dd40 ; FUN_0072dd40 */

void FUN_0072dd40(undefined4 param_1)

{
  FUN_005f5950();
  FUN_01674ea0(param_1,0x34);
  return;
}



/* FUNCTION 10489 ; VA 0x0072dd60 ; FUN_0072dd60 */

void FUN_0072dd60(void)

{
  FUN_0072aa10();
  return;
}



/* FUNCTION 10490 ; VA 0x0072dd70 ; FUN_0072dd70 */

void FUN_0072dd70(void)

{
  if (DAT_01eafe11 != '\0') {
    FUN_01677520(DAT_01eafe11,"Model Mesh Computer Finished");
  }
  return;
}



/* FUNCTION 10491 ; VA 0x0072dd90 ; FUN_0072dd90 */

void FUN_0072dd90(void)

{
  FUN_0072b070();
  return;
}



/* FUNCTION 10492 ; VA 0x0072dda0 ; FUN_0072dda0 */

void __fastcall FUN_0072dda0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = *(int **)(*(int *)(param_1 + 4) + 0x2c);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 8))();
    iVar2 = *(int *)(param_1 + 4);
    if (iVar2 != 0) {
      piVar1 = *(int **)(iVar2 + 0x2c);
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x10))(piVar1 != (int *)(iVar2 + 8));
        *(undefined4 *)(iVar2 + 0x2c) = 0;
      }
      piVar1 = *(int **)(iVar2 + 4);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      FUN_01674ea0(iVar2,0x38);
    }
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddc9c();
}



/* FUNCTION 10493 ; VA 0x0072de10 ; FUN_0072de10 */

void FUN_0072de10(void)

{
  FUN_0072bd70();
  return;
}



/* FUNCTION 10494 ; VA 0x0072de20 ; FUN_0072de20 */

void FUN_0072de20(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  
  uVar3 = *param_2;
  uVar4 = param_2[1];
  uVar5 = param_2[2];
  uVar6 = param_2[3];
  uVar7 = param_2[4];
  uVar8 = param_2[5];
  uVar9 = param_2[6];
  uVar10 = param_2[7];
  uVar11 = param_2[8];
  uVar12 = param_2[9];
  uVar13 = param_2[10];
  uVar14 = param_2[0xb];
  iVar2 = *param_1;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  FUN_0072bed0(iVar2,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,uVar10,uVar11,uVar12,uVar13,uVar14);
  return;
}



/* FUNCTION 10495 ; VA 0x0072de80 ; FUN_0072de80 */

void FUN_0072de80(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  
  uVar3 = *param_2;
  uVar4 = param_2[1];
  uVar5 = param_2[2];
  uVar6 = param_2[3];
  uVar7 = param_2[4];
  uVar8 = param_2[5];
  uVar9 = param_2[6];
  uVar10 = param_2[7];
  uVar11 = param_2[8];
  uVar12 = param_2[9];
  uVar13 = param_2[10];
  uVar14 = param_2[0xb];
  iVar2 = *param_1;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  FUN_0072d580(iVar2,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,uVar10,uVar11,uVar12,uVar13,uVar14);
  return;
}



/* FUNCTION 10496 ; VA 0x0072dee0 ; FUN_0072dee0 */

void FUN_0072dee0(void)

{
  FUN_0072d7a0();
  return;
}



/* FUNCTION 10497 ; VA 0x0072def0 ; FUN_0072def0 */

void FUN_0072def0(void)

{
  FUN_0072d8d0();
  return;
}



/* FUNCTION 10498 ; VA 0x0072df00 ; FUN_0072df00 */

void FUN_0072df00(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x34);
  return;
}



/* FUNCTION 10499 ; VA 0x0072df20 ; FUN_0072df20 */

void __fastcall FUN_0072df20(int param_1)

{
  FUN_007248a0(param_1 + 4);
  return;
}


