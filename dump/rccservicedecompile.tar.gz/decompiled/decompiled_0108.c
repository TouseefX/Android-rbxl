/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 27000 ; VA 0x00bff1c0 ; FUN_00bff1c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bff1c0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018047a0;
  pvStack_10 = ExceptionList;
  if (DAT_01ef7d2c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef7f40) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef7f40);
      if (DAT_01ef7f40 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ReplicatedScriptService",1,uStack_20,0,0,0xb,0,0);
        _DAT_01ef7f38 = RBX::Creator<class_RBX::ReplicatedScriptService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef7d30,&DAT_01ef7f38);
        FUN_016f3654(FUN_01892be0);
        FUN_016f37bf(&DAT_01ef7f40);
      }
    }
    DAT_01ef7d2c = &DAT_01ef7d30;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef7d2c;
}



/* FUNCTION 27001 ; VA 0x00bff2c0 ; FUN_00bff2c0 */

void FUN_00bff2c0(void)

{
  int iVar1;
  
  if (DAT_01ef7f44 == 0) {
    iVar1 = FUN_00bff1c0();
    DAT_01ef7f44 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27002 ; VA 0x00bff2e0 ; FUN_00bff2e0 */

undefined2 __fastcall FUN_00bff2e0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00b73ae0();
  return CONCAT11((char)(*(ushort *)(iVar2 + 0x1da) >> 8),
                  (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
                  (uint)*(ushort *)(iVar2 + 0x1da));
}



/* FUNCTION 27003 ; VA 0x00bff310 ; FUN_00bff310 */

undefined4 * __fastcall FUN_00bff310(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018042a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a650(PTR_s_ReplicatedScriptService_01960c3c);
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ReplicatedScriptService,class_RBX::ServiceInstance>
             ::vftable;
  uVar1 = FUN_00bff1c0();
  param_1[3] = uVar1;
  param_1[0x16] = RBX::IScriptFilter::vftable;
  *param_1 = RBX::ReplicatedScriptService::vftable;
  param_1[0x16] = RBX::ReplicatedScriptService::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27004 ; VA 0x00bff380 ; FUN_00bff380 */

void __fastcall FUN_00bff380(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ReplicatedScriptService>::vftable;
  uVar1 = FUN_00bff1c0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27005 ; VA 0x00bff3c0 ; FUN_00bff3c0 */

undefined4 FUN_00bff3c0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (DAT_01d68100 != '\0') {
    return 1;
  }
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00b9e640();
  if ((uint)*(ushort *)(iVar2 + 0x1da) <
      (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b73ae0();
    if ((uint)*(ushort *)(iVar2 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_009ec190();
      if ((uint)*(ushort *)(iVar2 + 0x1da) <
          (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
        return 0;
      }
    }
  }
  return 1;
}



/* FUNCTION 27006 ; VA 0x00bff450 ; FUN_00bff450 */

undefined4 * FUN_00bff450(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00673100(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27007 ; VA 0x00bff4c0 ; FUN_00bff4c0 */

uint FUN_00bff4c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bff1c0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27008 ; VA 0x00bff4e0 ; FUN_00bff4e0 */

uint FUN_00bff4e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bff1c0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27009 ; VA 0x00bff500 ; FUN_00bff500 */

undefined4 __thiscall FUN_00bff500(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  
  if ((DAT_01d680f8 != '\0') && (param_1 = param_1 + -0x58, param_2 != 0)) {
    if ((*(int *)(param_2 + 0x34) != param_1) &&
       (cVar2 = FUN_008a3680(*(int *)(param_2 + 0x34)), cVar2 == '\0')) {
      return 0;
    }
    iVar3 = FUN_008f7870(param_1);
    if (iVar3 != 0) {
      iVar3 = *(int *)(iVar3 + 0x4a0);
      iVar1 = *(int *)(param_2 + 0xc);
      iVar4 = FUN_00b739e0();
      if ((uint)*(ushort *)(iVar4 + 0x1da) <
          (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) {
        cVar2 = FUN_00bff2e0();
        if ((cVar2 != '\0') && ((iVar3 == 2 || (iVar3 == 3)))) {
          return 1;
        }
      }
      else if (((iVar3 == 1) || (iVar3 == 3)) && (iVar3 = FUN_0097bfc0(param_1), iVar3 != 0)) {
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 27010 ; VA 0x00bff5b0 ; FUN_00bff5b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bff5b0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018047d0;
  pvStack_10 = ExceptionList;
  if (DAT_01ef7f48 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8160) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef8160);
      if (DAT_01ef8160 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RobloxReplicatedStorage",1,uStack_20,0,0,3,5,0);
        _DAT_01ef8158 = RBX::Creator<class_RBX::RobloxReplicatedStorage>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef7f50,&DAT_01ef8158);
        FUN_016f3654(FUN_01892c40);
        FUN_016f37bf(&DAT_01ef8160);
      }
    }
    DAT_01ef7f48 = &DAT_01ef7f50;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef7f48;
}



/* FUNCTION 27011 ; VA 0x00bff6b0 ; FUN_00bff6b0 */

void FUN_00bff6b0(void)

{
  int iVar1;
  
  if (DAT_01ef8164 == 0) {
    iVar1 = FUN_00bff5b0();
    DAT_01ef8164 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27012 ; VA 0x00bff6d0 ; FUN_00bff6d0 */

undefined4 * __fastcall FUN_00bff6d0(undefined4 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018047f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::RobloxReplicatedStorage,class_RBX::ServiceInstance>
             ::vftable;
  uVar1 = FUN_00bff5b0();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::RobloxReplicatedStorage::vftable;
  FUN_0054eff0("RobloxReplicatedStorage");
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(aiStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27013 ; VA 0x00bff780 ; FUN_00bff780 */

void __fastcall FUN_00bff780(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::RobloxReplicatedStorage>::vftable;
  uVar1 = FUN_00bff5b0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27014 ; VA 0x00bff7c0 ; FUN_00bff7c0 */

undefined4 * FUN_00bff7c0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_006735a0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27015 ; VA 0x00bff830 ; FUN_00bff830 */

uint FUN_00bff830(void)

{
  int iVar1;
  
  iVar1 = FUN_00bff5b0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27016 ; VA 0x00bff850 ; FUN_00bff850 */

uint FUN_00bff850(void)

{
  int iVar1;
  
  iVar1 = FUN_00bff5b0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27017 ; VA 0x00bff870 ; FUN_00bff870 */

undefined4 * __thiscall
FUN_00bff870(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01961b10;
  cVar3 = FUN_00b8d740(param_2,param_3,param_4,param_5,param_6);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 27018 ; VA 0x00bff970 ; FUN_00bff970 */

undefined4 * __thiscall
FUN_00bff970(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01961adc;
  cVar3 = FUN_00c00640(param_2,param_3,param_4,param_5,param_6);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27019 ; VA 0x00bffae0 ; FUN_00bffae0 */

undefined4 * __thiscall
FUN_00bffae0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01961b18;
  cVar3 = FUN_00b8d740(param_2,param_3,param_4,param_5,param_6);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 27020 ; VA 0x00bffbe0 ; FUN_00bffbe0 */

int * __thiscall
FUN_00bffbe0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c00240();
  FUN_00684820(uVar3,param_2,param_3,0,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::FunctionalTest>::
              vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27021 ; VA 0x00bffcb0 ; FUN_00bffcb0 */

int * __thiscall
FUN_00bffcb0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804848;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c00340();
  FUN_005c44c0(uVar3,param_2,param_3,0,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<int,0>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<int,0>::BoundPropGetSet<class_RBX::TestService>::vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27022 ; VA 0x00bffd80 ; FUN_00bffd80 */

int * __thiscall
FUN_00bffd80(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804868;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c00340();
  FUN_00684770(uVar3,param_2,param_3,0,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<double,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<double,1>::BoundPropGetSet<class_RBX::TestService>::vftable
    ;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27023 ; VA 0x00bffe50 ; FUN_00bffe50 */

int * __thiscall
FUN_00bffe50(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c00340();
  FUN_00684820(uVar3,param_2,param_3,0,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::TestService>::vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27024 ; VA 0x00bfff20 ; FUN_00bfff20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00bfff20(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8634) {
    FUN_016f3809(&DAT_01ef8634);
    if (DAT_01ef8634 == -1) {
      _DAT_01ef8628 = FUN_005c65e0;
      _DAT_01ef862c = FUN_005c65e0;
      _DAT_01ef8630 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef8634);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01ef8628) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01ef8628;
  return param_1;
}



/* FUNCTION 27025 ; VA 0x00bfffd0 ; FUN_00bfffd0 */

int FUN_00bfffd0(undefined4 param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018048a0;
  pvStack_10 = ExceptionList;
  uStack_14 = **(undefined4 **)(param_3 + 8);
  puVar3 = *(undefined4 **)(param_3 + 4);
  piVar8 = (int *)puVar3[1];
  ExceptionList = &pvStack_10;
  if (piVar8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)puVar3[1];
  }
  uStack_1c = *puVar3;
  uStack_8 = 0;
  piStack_18 = piVar8;
  FUN_0054ef60();
  pcVar4 = (code *)*param_2;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(auStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar5 = (*pcVar4)();
  if (0xf < uStack_20) {
    uVar7 = uStack_20 + 1;
    uVar6 = auStack_34[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_34[0] - 4);
      uVar7 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(uVar6,uVar7);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar1 = piVar8 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar8)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 27026 ; VA 0x00c00100 ; FUN_00c00100 */

int FUN_00c00100(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018048d0;
  pvStack_10 = ExceptionList;
  uStack_14 = *(undefined4 *)param_3[3];
  uStack_18 = CONCAT31(uStack_18._1_3_,*(undefined *)*param_3);
  puVar3 = (undefined4 *)param_3[2];
  piVar8 = (int *)puVar3[1];
  ExceptionList = &pvStack_10;
  if (piVar8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)puVar3[1];
  }
  uStack_20 = *puVar3;
  uStack_8 = 0;
  piStack_1c = piVar8;
  FUN_0054ef60();
  pcVar4 = (code *)*param_2;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar5 = (*pcVar4)(uStack_18);
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(uVar6,uVar7);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar1 = piVar8 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar8)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 27027 ; VA 0x00c00240 ; FUN_00c00240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c00240(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804900;
  pvStack_10 = ExceptionList;
  if (DAT_01ef8398 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef85b0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef85b0);
      if (DAT_01ef85b0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"FunctionalTest",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ef85a8 = RBX::Creator<class_RBX::FunctionalTest>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef83a0,&DAT_01ef85a8);
        FUN_016f3654(FUN_01893050);
        FUN_016f37bf(&DAT_01ef85b0);
      }
    }
    DAT_01ef8398 = &DAT_01ef83a0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef8398;
}



/* FUNCTION 27028 ; VA 0x00c00340 ; FUN_00c00340 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c00340(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804930;
  pvStack_10 = ExceptionList;
  if (DAT_01ef817c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8390) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef8390);
      if (DAT_01ef8390 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"TestService",1,uStack_20,0,0,0x1b,0,0);
        _DAT_01ef8388 = RBX::Creator<class_RBX::TestService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef8180,&DAT_01ef8388);
        FUN_016f3654(FUN_018930b0);
        FUN_016f37bf(&DAT_01ef8390);
      }
    }
    DAT_01ef817c = &DAT_01ef8180;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef817c;
}



/* FUNCTION 27029 ; VA 0x00c00440 ; FUN_00c00440 */

void FUN_00c00440(void)

{
  int iVar1;
  
  if (DAT_01ef8394 == 0) {
    iVar1 = FUN_00c00340();
    DAT_01ef8394 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27030 ; VA 0x00c00460 ; FUN_00c00460 */

int __thiscall FUN_00c00460(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804940;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::FunctionalTest*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27031 ; VA 0x00c00532 ; Catch_All@00c00532 */

void Catch_All_00c00532(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27032 ; VA 0x00c00550 ; FUN_00c00550 */

int __thiscall FUN_00c00550(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804950;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PhysicsSettings*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27033 ; VA 0x00c00622 ; Catch_All@00c00622 */

void Catch_All_00c00622(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27034 ; VA 0x00c00640 ; FUN_00c00640 */

undefined FUN_00c00640(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      int *param_9)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  undefined4 *puVar7;
  undefined uVar8;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01804978;
  pvStack_10 = ExceptionList;
  uStack_40 = param_1;
  uStack_3c = param_2;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_38 = param_3;
  uStack_30 = param_5;
  uStack_28 = param_7;
  piStack_34 = param_4;
  uStack_24 = param_8;
  uStack_8 = 1;
  uStack_7 = 0;
  cVar6 = FUN_00585a40(&uStack_40);
  piVar2 = piStack_34;
  uVar5 = uStack_3c;
  uVar4 = uStack_40;
  if (cVar6 == '\0') {
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[1] = piStack_34[1] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_38;
    uStack_18 = uStack_30;
    uStack_1c = uStack_28;
    uStack_20 = uStack_24;
    uStack_8 = 2;
    puVar7 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar7 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      *puVar7 = uVar4;
      puVar7[1] = uVar5;
      puVar7[2] = 0;
      puVar7[3] = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
      }
      puVar7[2] = uStack_14;
      puVar7[3] = piVar2;
      puVar7[4] = uStack_18;
      puVar7[6] = uStack_1c;
      puVar7[7] = uStack_20;
    }
    *param_9 = (int)puVar7;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_34[1] + -1;
      piStack_34[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar8 = 1;
  }
  else {
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_34[1] + -1;
      piStack_34[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar8 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 27035 ; VA 0x00c00810 ; FUN_00c00810 */

undefined4 *
FUN_00c00810(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined8 param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  piVar1 = param_5 + 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00c01580(param_4,param_5,param_6);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  param_1[2] = uStack_1c;
  param_1[3] = piStack_18;
  param_1[4] = uStack_14;
  param_1[6] = (undefined4)param_7;
  param_1[7] = param_7._4_4_;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 27036 ; VA 0x00c00950 ; FUN_00c00950 */

undefined4 *
FUN_00c00950(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  piVar1 = param_5 + 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00c01620(param_4,param_5,param_6,param_7,param_8,param_9,param_10);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (piStack_c != (int *)0x0) {
    LOCK();
    piStack_c[1] = piStack_c[1] + 1;
    UNLOCK();
  }
  param_1[2] = uStack_10;
  param_1[3] = piStack_c;
  param_1[4] = uStack_8;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 27037 ; VA 0x00c00a60 ; FUN_00c00a60 */

undefined4 *
FUN_00c00a60(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  piVar1 = param_5 + 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00c01580(param_4,param_5,param_6);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (piStack_c != (int *)0x0) {
    LOCK();
    piStack_c[1] = piStack_c[1] + 1;
    UNLOCK();
  }
  param_1[2] = uStack_10;
  param_1[3] = piStack_c;
  param_1[4] = uStack_8;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 27038 ; VA 0x00c00b60 ; FUN_00c00b60 */

void FUN_00c00b60(int *param_1,undefined *param_2,undefined *param_3,int param_4,int param_5)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (int)param_3 - (int)param_2;
  iVar2 = 0;
  if (param_3 < param_2) {
    iVar1 = 0;
  }
  if (iVar1 != 0) {
    do {
      FUN_005ed940(param_5,*param_2);
      if (param_4 != 0) {
        FUN_00558890(param_5,param_4);
      }
      iVar2 = iVar2 + 1;
      param_2 = param_2 + 1;
    } while (iVar2 != iVar1);
  }
  *param_1 = param_4;
  param_1[1] = param_5;
  return;
}



/* FUNCTION 27039 ; VA 0x00c00bd0 ; FUN_00c00bd0 */

undefined4 * FUN_00c00bd0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018049de;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c00240();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x88);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::FunctionalTest,class_RBX::Instance>::vftable;
    uVar4 = FUN_00c00240();
    puVar3[3] = uVar4;
    *puVar3 = RBX::FunctionalTest::vftable;
    puVar3[0x15] = 0;
    puVar3[0x16] = 0;
    *(undefined *)(puVar3 + 0x17) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    uStack_8._0_1_ = 5;
    *(undefined *)(puVar3 + 0x18) = 0;
    FUN_005542c0(&DAT_018d743c,1);
    *(undefined8 *)(puVar3 + 0x1e) = DAT_018cf108;
    *(undefined2 *)(puVar3 + 0x20) = 0x101;
    *(undefined *)((int)puVar3 + 0x82) = 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c00460(puVar3,param_1);
  uStack_8 = 9;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27040 ; VA 0x00c00d00 ; FUN_00c00d00 */

undefined4 * FUN_00c00d00(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804a20;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e39980();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x60);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e39c00();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c00550(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27041 ; VA 0x00c00dc0 ; FUN_00c00dc0 */

void FUN_00c00dc0(undefined4 *param_1,char *param_2,char *param_3,code *param_4)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  char *pcVar4;
  int iVar5;
  uint uVar6;
  char *pcVar7;
  undefined auStack_14 [12];
  char *pcStack_8;
  
  cVar1 = *param_2;
  if (cVar1 == '(') {
    iVar5 = 0x2900;
  }
  else if (cVar1 == '[') {
    iVar5 = 0x5d00;
  }
  else {
    iVar5 = (uint)((cVar1 != '{') - 1U & 0x7d) << 8;
  }
  uVar6 = CONCAT31((int3)((uint)iVar5 >> 8),1);
  pcStack_8 = (char *)CONCAT31(pcStack_8._1_3_,(char)((uint)iVar5 >> 8));
  pcVar2 = pcStack_8;
  pcVar7 = param_2 + 1;
joined_r0x00c00df8:
  do {
    if (pcVar7 == param_3) {
      pcVar7 = "Missing closing bracket";
LAB_00c00e7e:
      FUN_00550130(pcVar7);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_14,&DAT_01c17198);
    }
    cVar1 = *pcVar7;
    if (cVar1 == (char)(uVar6 >> 8)) {
      *param_1 = pcVar7 + 1;
      return;
    }
    if ((cVar1 != ' ') && (cVar1 != '\t')) {
      if (cVar1 != ',') {
        if ((char)uVar6 == '\0') {
          pcVar7 = "argument not separated by comma";
          goto LAB_00c00e7e;
        }
        FUN_00c00f00(&pcStack_8,pcVar7,param_3,pcVar2);
        pcVar3 = pcVar7;
        pcVar4 = pcVar7;
        if (pcVar7 != pcStack_8) {
          do {
            cVar1 = *pcVar3;
            uVar6 = CONCAT31((int3)(uVar6 >> 8),cVar1);
            if ((cVar1 != ' ') && (cVar1 != '\t')) {
              pcVar4 = pcVar3 + 1;
            }
            pcVar3 = pcVar3 + 1;
          } while (pcVar3 != pcStack_8);
          if (pcVar4 != pcVar7) {
            (*param_4)();
          }
        }
        uVar6 = uVar6 & 0xffffff00;
        pcVar7 = pcStack_8;
        goto joined_r0x00c00df8;
      }
      uVar6 = CONCAT31((int3)(uVar6 >> 8),1);
    }
    pcVar7 = pcVar7 + 1;
  } while( true );
}



/* FUNCTION 27042 ; VA 0x00c00ea0 ; FUN_00c00ea0 */

void FUN_00c00ea0(undefined4 *param_1,char *param_2,char *param_3)

{
  char *pcVar1;
  undefined auStack_10 [12];
  
  pcVar1 = param_2 + 1;
  do {
    if (pcVar1 == param_3) {
      FUN_00550130("Missing string closure");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_10,&DAT_01c17198);
    }
    if (*pcVar1 == '\\') {
      pcVar1 = pcVar1 + 1;
    }
    else if (*pcVar1 == *param_2) {
      *param_1 = pcVar1 + 1;
      return;
    }
    pcVar1 = pcVar1 + 1;
  } while( true );
}



/* FUNCTION 27043 ; VA 0x00c00f00 ; FUN_00c00f00 */

undefined4 * FUN_00c00f00(undefined4 *param_1,char *param_2,char *param_3,char param_4)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined auStack_c [4];
  undefined auStack_8 [4];
  
  if (param_2 != param_3) {
    do {
      cVar1 = *param_2;
      if ((cVar1 == param_4) || (cVar1 == ',')) {
        *param_1 = param_2;
        return param_1;
      }
      if (cVar1 == '\'') {
        puVar2 = (undefined4 *)FUN_00c00ea0(auStack_8,param_2,param_3);
        param_2 = (char *)*puVar2;
      }
      else if (cVar1 == '\"') {
        puVar2 = (undefined4 *)FUN_00c00ea0(auStack_c,param_2,param_3);
        param_2 = (char *)*puVar2;
      }
      else {
        if (cVar1 == '(') {
          puVar2 = &uStack_10;
        }
        else {
          if (cVar1 != '[') {
            param_2 = param_2 + 1;
            goto LAB_00c00fa7;
          }
          puVar2 = &uStack_14;
        }
        puVar2 = (undefined4 *)FUN_00c00dc0(puVar2,param_2,param_3,_guard_check_icall,uStack_14);
        param_2 = (char *)*puVar2;
      }
LAB_00c00fa7:
    } while (param_2 != param_3);
  }
  *param_1 = param_3;
  return param_1;
}



/* FUNCTION 27044 ; VA 0x00c00fd0 ; FUN_00c00fd0 */

void FUN_00c00fd0(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804a38;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(*param_2 + 0x270);
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0088c8c0();
  if (iVar2 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  piVar3 = (int *)*param_2;
  iVar2 = *piVar3;
  iVar4 = FUN_0088daf0();
  if (iVar2 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  piVar5 = piVar3 + 2;
  iVar2 = *param_2;
  if (piVar3[1] == 0) {
    piVar5 = (int *)0x0;
  }
  iVar4 = *(int *)(iVar2 + 0x1a0);
  uVar1 = *(undefined *)piVar5;
  iVar6 = FUN_0088cdc0();
  if (iVar4 != iVar6) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar4 = iVar2 + 0x1a8;
  if (*(int *)(iVar2 + 0x1a4) == 0) {
    iVar4 = 0;
  }
  if (*(int *)(iVar4 + 4) != 0) {
    LOCK();
    piVar3 = (int *)(*(int *)(iVar4 + 4) + 4);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
  }
  iVar2 = *param_2;
  uStack_8 = 0;
  iVar4 = *(int *)(iVar2 + 0xd0);
  iVar6 = FUN_0088cb40();
  if (iVar4 == iVar6) {
    iVar4 = iVar2 + 0xd8;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      iVar4 = 0;
    }
    FUN_0054ef60(iVar4);
    uStack_8 = 0xffffffff;
    FUN_00c059f0(param_1,CONCAT31((int3)((uint)piVar5 >> 8),uVar1));
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27045 ; VA 0x00c01110 ; FUN_00c01110 */

undefined4 * __thiscall
FUN_00c01110(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int param_6)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint in_stack_00000028;
  undefined4 *in_stack_0000002c;
  undefined8 in_stack_00000030;
  undefined4 in_stack_00000038;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804ab2;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00c00240();
  FUN_009cb790(uVar2,param_4,in_stack_0000002c,in_stack_00000030,in_stack_00000038);
  param_1[0xe] = param_2;
  uStack_8._0_1_ = 1;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::FunctionalTest,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  in_stack_0000002c = (undefined4 *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 2;
  if (in_stack_0000002c == (undefined4 *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0054ef60(&param_6);
  }
  param_1[0x10] = uVar2;
  uStack_8._0_1_ = 3;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    in_stack_0000002c = &uStack_1b8;
    uStack_8 = 5;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    in_stack_0000002c = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,in_stack_0000002c);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  uStack_8 = 3;
  if ((uVar4 & 1) != 0) {
    uStack_8 = 7;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if (0xf < in_stack_00000028) {
    if (0xfff < in_stack_00000028 + 1) {
      if (0x1f < (param_6 - *(int *)(param_6 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27046 ; VA 0x00c012f0 ; FUN_00c012f0 */

undefined4 * __thiscall
FUN_00c012f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,int *param_10,undefined4 param_11,undefined8 param_12,
            undefined4 param_13)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804af1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c00340();
  FUN_009cb790(uVar3,param_4,param_11,param_12,param_13);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::TestService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int),3>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 2;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (param_10 != (int *)0x0) {
      LOCK();
      param_10[1] = param_10[1] + 1;
      UNLOCK();
    }
    *puVar4 = param_9;
    puVar4[1] = param_10;
  }
  param_1[0x11] = puVar4;
  uStack_8._0_1_ = 3;
  puVar4 = (undefined4 *)FUN_01674e20(4);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = param_8;
  }
  param_1[0x12] = puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00c03340(param_5,param_6,param_7);
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27047 ; VA 0x00c01410 ; FUN_00c01410 */

undefined4 * __thiscall
FUN_00c01410(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,int *param_11,undefined4 param_12,
            undefined8 param_13,undefined4 param_14)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804b3c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c00340();
  FUN_009cb790(uVar3,param_4,param_12,param_13,param_14);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::TestService,void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int),4>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 3;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (param_11 != (int *)0x0) {
      LOCK();
      param_11[1] = param_11[1] + 1;
      UNLOCK();
    }
    *puVar4 = param_10;
    puVar4[1] = param_11;
  }
  param_1[0x12] = puVar4;
  uStack_8._0_1_ = 4;
  puVar4 = (undefined4 *)FUN_01674e20(4);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = param_9;
  }
  param_1[0x13] = puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00c03680(param_5,param_6,param_7,param_8);
  if (param_11 != (int *)0x0) {
    LOCK();
    iVar2 = param_11[1] + -1;
    param_11[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_11)();
      LOCK();
      piVar1 = param_11 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_11 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27048 ; VA 0x00c01530 ; FUN_00c01530 */

undefined4 * __thiscall FUN_00c01530(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  return param_1;
}



/* FUNCTION 27049 ; VA 0x00c01580 ; FUN_00c01580 */

undefined4 * __thiscall
FUN_00c01580(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  param_1[2] = param_4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 27050 ; VA 0x00c01620 ; FUN_00c01620 */

undefined4 __thiscall
FUN_00c01620(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    piVar1 = param_3 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piVar1 = param_3 + 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00c01580(param_2,param_3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar2 = param_3[2] + -1;
        param_3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 27051 ; VA 0x00c01720 ; FUN_00c01720 */

undefined4 * __thiscall FUN_00c01720(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = RBX::ScriptContext::ScriptStartOptions::LuaSyntaxError::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  return param_1;
}



/* FUNCTION 27052 ; VA 0x00c01760 ; FUN_00c01760 */

undefined4 * __thiscall FUN_00c01760(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  undefined4 uStack_c;
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  uStack_c = (**(code **)(*param_3 + 4))();
  *param_1 = std::exception::vftable;
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(&uStack_c,param_1 + 1);
  param_1[3] = param_2;
  *param_1 = RBX::ScriptContext::ScriptStartOptions::LuaSyntaxError::vftable;
  return param_1;
}



/* FUNCTION 27053 ; VA 0x00c017b0 ; FUN_00c017b0 */

int * __thiscall FUN_00c017b0(int *param_1,undefined4 param_2)

{
  uint uVar1;
  undefined2 *puVar2;
  char cVar3;
  undefined uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  char *pcVar8;
  uint uVar9;
  undefined4 ***pppuVar10;
  uint uVar11;
  uint uVar12;
  undefined4 ****ppppuVar13;
  undefined4 ****ppppuVar14;
  int iVar15;
  char acStack_460 [1040];
  undefined auStack_50 [12];
  undefined auStack_44 [4];
  int *piStack_40;
  undefined4 ***apppuStack_38 [4];
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804b9d;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffb94;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  FUN_00729510(param_2,3,1);
  piVar7 = param_1 + 0x2c;
  *piVar7 = (int)&PTR_018bf148;
  param_1[0x30] = (int)&DAT_018bf150;
  param_1[0x46] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
  uStack_8 = 1;
  uStack_20 = 1;
  uStack_18 = 1;
  FUN_00564f30(param_1 + 0x32,0);
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  *(undefined ***)((int)piVar7 + *(int *)(*piVar7 + 4)) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)(*(int *)(*piVar7 + 4) + -4 + (int)piVar7) = *(int *)(*piVar7 + 4) + -0x68;
  FUN_0054ee60();
  param_1[0x32] =
       (int)std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
            vftable;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  iVar15 = 0;
  do {
    piVar7 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8._0_1_ = 5;
    piStack_40 = piVar7;
    (**(code **)(*piVar7 + 4))();
    uStack_20 = uStack_20 | 2;
    uStack_8._0_1_ = 6;
    piVar5 = (int *)FUN_0054e7d0(auStack_44);
    uVar4 = (**(code **)(*piVar5 + 0x20))(10);
    uStack_8._0_1_ = 7;
    if ((piVar7 != (int *)0x0) &&
       (puVar6 = (undefined4 *)(**(code **)(*piVar7 + 8))(), puVar6 != (undefined4 *)0x0)) {
      (**(code **)*puVar6)(1);
    }
    param_1 = piStack_1c;
    uStack_8._0_1_ = 4;
    piVar7 = (int *)FUN_00c05c60(acStack_460,0x400,0,uVar4);
    if ((*(byte *)(*(int *)(*piVar7 + 4) + 0xc + (int)piVar7) & 6) != 0) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    iVar15 = iVar15 + 1;
    uStack_28 = 0;
    pcVar8 = acStack_460;
    uStack_24 = 0xf;
    apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
    do {
      cVar3 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar3 != '\0');
    FUN_005542c0(acStack_460,(int)pcVar8 - (int)(acStack_460 + 1));
    uVar11 = uStack_28;
    uStack_8._0_1_ = 8;
    if (1000 < uStack_28) {
      FUN_00550130("Line too long");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_50,&DAT_01c17198);
    }
    uStack_18 = uStack_24;
    if (uStack_28 < uStack_24) {
      ppppuVar14 = apppuStack_38;
      if (0xf < uStack_24) {
        ppppuVar14 = (undefined4 ****)apppuStack_38[0];
      }
      puVar2 = (undefined2 *)(uStack_28 + (int)ppppuVar14);
      uStack_28 = uStack_28 + 1;
      *puVar2 = 10;
    }
    else {
      if (uStack_28 == 0x7fffffff) {
        FUN_00554040();
LAB_00c01af6:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar12 = uStack_28 + 1 | 0xf;
      if (uVar12 < 0x80000000) {
        if (0x7fffffff - (uStack_24 >> 1) < uStack_24) {
          uVar12 = 0x7fffffff;
        }
        else {
          uVar1 = uStack_24 + (uStack_24 >> 1);
          if (uVar12 < uVar1) {
            uVar12 = uVar1;
          }
        }
      }
      else {
        uVar12 = 0x7fffffff;
      }
      uVar1 = uVar12 + 1;
      if (uVar1 < 0x1000) {
        if (uVar1 == 0) {
          ppppuVar14 = (undefined4 ****)0x0;
        }
        else {
          ppppuVar14 = (undefined4 ****)FUN_01674e20(uVar1);
        }
      }
      else {
        uVar9 = uVar12 + 0x24;
        if (uVar9 <= uVar1) {
          uVar9 = 0xffffffff;
        }
        pppuVar10 = (undefined4 ***)FUN_01674e20(uVar9);
        if (pppuVar10 == (undefined4 ***)0x0) goto LAB_00c01af6;
        ppppuVar14 = (undefined4 ****)((int)pppuVar10 + 0x23U & 0xffffffe0);
        ppppuVar14[-1] = pppuVar10;
      }
      pppuVar10 = apppuStack_38[0];
      uStack_28 = uVar11 + 1;
      uStack_24 = uVar12;
      if (uStack_18 < 0x10) {
        FUN_0170c6f0(ppppuVar14,apppuStack_38,uVar11);
        *(undefined2 *)(uVar11 + (int)ppppuVar14) = 10;
        param_1 = piStack_1c;
        apppuStack_38[0] = ppppuVar14;
      }
      else {
        FUN_0170c6f0(ppppuVar14,apppuStack_38[0],uVar11);
        uVar12 = uStack_18 + 1;
        *(undefined2 *)(uVar11 + (int)ppppuVar14) = 10;
        ppppuVar13 = (undefined4 ****)pppuVar10;
        if (0xfff < uVar12) {
          ppppuVar13 = (undefined4 ****)pppuVar10[-1];
          uVar12 = uStack_18 + 0x24;
          if (0x1f < (uint)((int)pppuVar10 + (-4 - (int)ppppuVar13))) goto LAB_00c01af6;
        }
        FUN_01674ea0(ppppuVar13,uVar12);
        param_1 = piStack_1c;
        apppuStack_38[0] = ppppuVar14;
      }
    }
    FUN_00c070f0(iVar15,apppuStack_38);
    uStack_8._0_1_ = 4;
    if (0xf < uStack_24) {
      uVar11 = uStack_24 + 1;
      ppppuVar14 = (undefined4 ****)apppuStack_38[0];
      if (0xfff < uVar11) {
        ppppuVar14 = (undefined4 ****)apppuStack_38[0][-1];
        uVar11 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar14))) goto LAB_00c01af6;
      }
      FUN_01674ea0(ppppuVar14,uVar11);
    }
  } while( true );
}



/* FUNCTION 27054 ; VA 0x00c01aba ; Catch@00c01aba */

void Catch_00c01aba(void)

{
  int unaff_EBP;
  
  FUN_00c01760(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x38));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x5c,&DAT_01cb33dc);
}



/* FUNCTION 27055 ; VA 0x00c01b00 ; FUN_00c01b00 */

undefined4 * __fastcall FUN_00c01b00(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804ca7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::TestService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00c00340();
  param_1[3] = uVar1;
  *param_1 = RBX::TestService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  *(undefined *)(param_1 + 0x24) = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  *(undefined *)(param_1 + 0x30) = 1;
  param_1[0x35] = 0;
  param_1[0x36] = 0xf;
  uStack_8._0_1_ = 7;
  uStack_8._1_3_ = 0;
  *(undefined *)(param_1 + 0x31) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  *(undefined8 *)(param_1 + 0x38) = DAT_018d8a10;
  param_1[0x3a] = 0x10101;
  param_1[0x3b] = 0;
  *(undefined *)(param_1 + 0x3c) = 0;
  *(undefined8 *)(param_1 + 0x3e) = 0;
  param_1[0x40] = 0;
  param_1[0x48] = 0;
  param_1[0x50] = 0;
  param_1[0x58] = 0;
  param_1[0x60] = 0;
  param_1[0x68] = 0;
  param_1[0x70] = 0;
  param_1[0x71] = 0;
  param_1[0x72] = 0;
  param_1[0x73] = 0;
  param_1[0x74] = 0;
  param_1[0x75] = 0;
  uStack_8._0_1_ = 0x12;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("TestService",0xb);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27056 ; VA 0x00c01d30 ; FUN_00c01d30 */

void __fastcall FUN_00c01d30(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_005c4ac0();
  FUN_009cb8b0();
  return;
}



/* FUNCTION 27057 ; VA 0x00c01da0 ; FUN_00c01da0 */

void __fastcall FUN_00c01da0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),1);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 27058 ; VA 0x00c01e20 ; FUN_00c01e20 */

void __fastcall FUN_00c01e20(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::FunctionalTest>::vftable;
  uVar1 = FUN_00c00240(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27059 ; VA 0x00c01e60 ; FUN_00c01e60 */

void __fastcall FUN_00c01e60(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::TestService>::vftable;
  uVar1 = FUN_00c00340(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27060 ; VA 0x00c01ea0 ; FUN_00c01ea0 */

void FUN_00c01ea0(void)

{
  FUN_005705c0();
  FUN_005705c0();
  return;
}



/* FUNCTION 27061 ; VA 0x00c01ec0 ; FUN_00c01ec0 */

void __fastcall FUN_00c01ec0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804cc0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::TestService::vftable;
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x75];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0x74];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uVar4 = param_1[0x68];
  uStack_8 = 2;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x6a,param_1 + 0x6a,2);
      }
    }
    param_1[0x68] = 0;
  }
  uVar4 = param_1[0x60];
  uStack_8 = 3;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x62,param_1 + 0x62,2);
      }
    }
    param_1[0x60] = 0;
  }
  uVar4 = param_1[0x58];
  uStack_8 = 4;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x5a,param_1 + 0x5a,2);
      }
    }
    param_1[0x58] = 0;
  }
  uVar4 = param_1[0x50];
  uStack_8 = 5;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x52,param_1 + 0x52,2);
      }
    }
    param_1[0x50] = 0;
  }
  uVar4 = param_1[0x48];
  uStack_8 = 6;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x4a,param_1 + 0x4a,2);
      }
    }
    param_1[0x48] = 0;
  }
  uVar4 = param_1[0x40];
  uStack_8 = 7;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x42,param_1 + 0x42,2);
      }
    }
    param_1[0x40] = 0;
  }
  uVar4 = param_1[0x36];
  uStack_8 = 0xffffffff;
  if (0xf < uVar4) {
    iVar3 = param_1[0x31];
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x35] = 0;
  param_1[0x36] = 0xf;
  *(undefined *)(param_1 + 0x31) = 0;
  FUN_00577ac0();
  uVar4 = param_1[0x1c];
  uStack_8 = 8;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x1e,param_1 + 0x1e,2);
      }
    }
    param_1[0x1c] = 0;
  }
  piVar1 = (int *)param_1[0x1b];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 9;
  FUN_01679490();
  iVar3 = param_1[0x19];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 10;
  FUN_01679490();
  iVar3 = param_1[0x18];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  piVar1 = (int *)param_1[0x17];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27062 ; VA 0x00c02230 ; FUN_00c02230 */

/* WARNING: Removing unreachable block (ram,0x00c022e9) */
/* WARNING: Removing unreachable block (ram,0x00c02361) */
/* WARNING: Removing unreachable block (ram,0x00c022db) */
/* WARNING: Removing unreachable block (ram,0x00c022f9) */
/* WARNING: Removing unreachable block (ram,0x00c0231c) */
/* WARNING: Removing unreachable block (ram,0x00c02328) */
/* WARNING: Removing unreachable block (ram,0x00c02336) */

undefined4 __thiscall
FUN_00c02230(uint *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804ce8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))
                      (param_1 + 2,param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8
                       ,param_9,param_10);
    ExceptionList = pvStack_10;
    return uVar1;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 27063 ; VA 0x00c02370 ; FUN_00c02370 */

/* WARNING: Removing unreachable block (ram,0x00c0242c) */
/* WARNING: Removing unreachable block (ram,0x00c024a4) */
/* WARNING: Removing unreachable block (ram,0x00c0241e) */
/* WARNING: Removing unreachable block (ram,0x00c0243c) */
/* WARNING: Removing unreachable block (ram,0x00c0245f) */
/* WARNING: Removing unreachable block (ram,0x00c0246b) */
/* WARNING: Removing unreachable block (ram,0x00c02479) */

undefined4 __thiscall
FUN_00c02370(uint *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804d18;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))
                      (param_1 + 2,param_2,param_3,param_4,param_5,param_6,CONCAT44(param_8,param_7)
                       ,param_9,param_10,param_11);
    ExceptionList = pvStack_10;
    return uVar1;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 27064 ; VA 0x00c024b0 ; FUN_00c024b0 */

/* WARNING: Removing unreachable block (ram,0x00c0254e) */
/* WARNING: Removing unreachable block (ram,0x00c0255e) */
/* WARNING: Removing unreachable block (ram,0x00c02564) */

void * __thiscall FUN_00c024b0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  uint in_stack_00000018;
  int *in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804d58;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 == 0) {
    pvVar3 = ExceptionList;
    ExceptionList = &pvStack_10;
    if (0xf < in_stack_00000018) {
      if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      ExceptionList = &pvStack_10;
      pvVar3 = (void *)FUN_01674ea0();
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 4;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290();
    pvVar3 = (void *)FUN_005507b0();
  }
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = in_stack_00000020 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*in_stack_00000020 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 27065 ; VA 0x00c025f3 ; Catch@00c025f3 */

undefined * Catch_00c025f3(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x28));
  return &DAT_00c02604;
}



/* FUNCTION 27066 ; VA 0x00c02620 ; FUN_00c02620 */

/* WARNING: Removing unreachable block (ram,0x00c026be) */
/* WARNING: Removing unreachable block (ram,0x00c026ce) */
/* WARNING: Removing unreachable block (ram,0x00c026d4) */

void * __thiscall FUN_00c02620(int *param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  uint in_stack_0000001c;
  int *in_stack_00000024;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804d98;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 == 0) {
    pvVar3 = ExceptionList;
    ExceptionList = &pvStack_10;
    if (0xf < in_stack_0000001c) {
      if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 + -4)) - 4U)) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      ExceptionList = &pvStack_10;
      pvVar3 = (void *)FUN_01674ea0();
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 4;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290();
    pvVar3 = (void *)FUN_005507b0();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000024 + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = in_stack_00000024 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*in_stack_00000024 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 27067 ; VA 0x00c02766 ; Catch@00c02766 */

undefined * Catch_00c02766(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x28));
  return &DAT_00c02777;
}



/* FUNCTION 27068 ; VA 0x00c02790 ; FUN_00c02790 */

undefined4 __thiscall FUN_00c02790(undefined4 param_1,byte param_2)

{
  FUN_00c01d30();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 27069 ; VA 0x00c027c0 ; FUN_00c027c0 */

undefined4 __thiscall FUN_00c027c0(undefined4 param_1,byte param_2)

{
  FUN_00c01da0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 27070 ; VA 0x00c027f0 ; FUN_00c027f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c027f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::FunctionalTest::Result>::vftable;
  _DAT_01ef85b8 = _DAT_01ef85b8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 27071 ; VA 0x00c02820 ; FUN_00c02820 */

int __thiscall FUN_00c02820(int param_1,byte param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x60);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  piVar4 = *(int **)(param_1 + 0x58);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x88);
  }
  return param_1;
}



/* FUNCTION 27072 ; VA 0x00c028c0 ; FUN_00c028c0 */

undefined4 * __thiscall FUN_00c028c0(undefined4 *param_1,byte param_2)

{
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 27073 ; VA 0x00c028f0 ; FUN_00c028f0 */

undefined4 __thiscall FUN_00c028f0(undefined4 param_1,byte param_2)

{
  FUN_00c01ec0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1d8);
  }
  return param_1;
}



/* FUNCTION 27074 ; VA 0x00c02920 ; thunk_FUN_00c08100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c08100(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805526;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8624) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8624);
    if (DAT_01ef8624 == -1) {
      uStack_8 = 0;
      FUN_009ca470("FunctionalTestResult");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef85c0 = RBX::Reflection::EnumDesc<enum_RBX::FunctionalTest::Result>::vftable;
      FUN_009caf20(&DAT_01d68118,3);
      FUN_016f3654(&LAB_01892ef0);
      FUN_016f37bf(&DAT_01ef8624);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef85c0;
}



/* FUNCTION 27075 ; VA 0x00c02930 ; FUN_00c02930 */

void FUN_00c02930(int param_1,int param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00591430(0,0,param_2,param_3 - param_2);
  if (*(int *)(param_1 + 8) == *(int *)(param_1 + 4)) {
    FUN_00559960(*(int *)(param_1 + 4),auStack_28);
  }
  else {
    FUN_0054ef60(auStack_28);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x18;
  }
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27076 ; VA 0x00c029f0 ; FUN_00c029f0 */

bool FUN_00c029f0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    iVar1 = FUN_00e09790();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      return false;
    }
  }
  iVar2 = FUN_0170d75d(param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::Script::RTTI_Type_Descriptor,0);
  return iVar2 == 0;
}



/* FUNCTION 27077 ; VA 0x00c02a50 ; FUN_00c02a50 */

/* WARNING: Removing unreachable block (ram,0x00c02b38) */
/* WARNING: Removing unreachable block (ram,0x00c02b46) */
/* WARNING: Removing unreachable block (ram,0x00c02cac) */
/* WARNING: Removing unreachable block (ram,0x00c02b5a) */

int __thiscall FUN_00c02a50(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  int *in_stack_00000020;
  int *in_stack_00000024;
  int **in_stack_00000028;
  undefined4 in_stack_ffffff94;
  undefined4 in_stack_ffffff98;
  undefined4 in_stack_ffffff9c;
  undefined8 in_stack_ffffffa0;
  int *in_stack_ffffffa8;
  int *piStack_54;
  int *piStack_50;
  int *piStack_4c;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = in_stack_00000020;
  puStack_c = &LAB_01804f40;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0xf0) != '\0') {
    ExceptionList = &pvStack_10;
    if (in_stack_00000024 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      in_stack_00000024[1] = in_stack_00000024[1] + 1;
      UNLOCK();
    }
    piStack_14 = in_stack_00000024;
    piStack_20 = in_stack_00000020;
    piStack_1c = in_stack_00000024;
    piStack_4c = (int *)&param_3;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    piStack_50 = (int *)0xc02ab3;
    FUN_0054ef60();
    piStack_4c = &uStack_28;
    piStack_50 = (int *)in_stack_00000028;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_8._0_1_ = 4;
    piStack_20 = (int *)0x0;
    piStack_1c = (int *)0x0;
    piStack_54 = piStack_14;
    in_stack_ffffffa0 = CONCAT44(uStack_2c,uStack_30);
    FUN_00c05760(param_1,param_2,uStack_40,uStack_3c,uStack_38,uStack_34,in_stack_ffffffa0,piVar3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    in_stack_ffffff94 = uStack_3c;
    in_stack_ffffff98 = uStack_38;
    in_stack_ffffff9c = uStack_34;
    in_stack_ffffffa8 = piVar3;
  }
  piVar3 = (int *)in_stack_00000028;
  *(int *)(param_1 + 0x9c) = *(int *)(param_1 + 0x9c) + 1;
  piStack_4c = (int *)&DAT_02133970;
  piStack_50 = (int *)0xc02b7d;
  FUN_008a4940();
  if ((char)param_2 == '\0') {
    *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 1;
    piStack_4c = (int *)&DAT_021339e0;
    piStack_50 = (int *)0xc02b96;
    FUN_008a4940();
  }
  if (*(int *)(param_1 + 0x140) == 0) {
    if ((char)param_2 == '\0') {
      piStack_4c = (int *)&param_3;
      if (in_stack_00000024 != (int *)0x0) {
        LOCK();
        in_stack_00000024[1] = in_stack_00000024[1] + 1;
        UNLOCK();
      }
      piStack_54 = in_stack_00000024;
      piStack_50 = piVar3;
      param_2 = FUN_00c06f60();
    }
  }
  else {
    in_stack_00000028 = &piStack_54;
    if (in_stack_00000024 != (int *)0x0) {
      LOCK();
      in_stack_00000024[1] = in_stack_00000024[1] + 1;
      UNLOCK();
    }
    piStack_54 = in_stack_00000020;
    piStack_50 = in_stack_00000024;
    uStack_8._0_1_ = 5;
    piStack_4c = piVar3;
    FUN_0054ef60(&param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    param_2 = FUN_00c02370(param_2,in_stack_ffffff94,in_stack_ffffff98,in_stack_ffffff9c,
                           in_stack_ffffffa0,in_stack_ffffffa8);
  }
  if (0xf < in_stack_0000001c) {
    piStack_4c = (int *)(in_stack_0000001c + 1);
    piVar3 = param_3;
    if (0xfff < piStack_4c) {
      piVar3 = (int *)param_3[-1];
      piStack_4c = (int *)(in_stack_0000001c + 0x24);
      if (0x1f < (uint)((int)param_3 + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
        piStack_4c = (int *)&UNK_00c02cb6;
        FUN_017167a3();
      }
    }
    piStack_54 = (int *)0xc02c5d;
    piStack_50 = piVar3;
    param_2 = FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = (int *)((uint)param_3 & 0xffffff00);
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000024 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_4c = (int *)0xc02c8b;
      param_2 = (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_4c = (int *)0xc02c9a;
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27078 ; VA 0x00c02cc0 ; FUN_00c02cc0 */

int __thiscall FUN_00c02cc0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int in_stack_00000014;
  uint in_stack_00000018;
  int *in_stack_0000001c;
  int *in_stack_00000020;
  int **in_stack_00000024;
  int *piStack_40;
  int *piStack_3c;
  int **ppiStack_38;
  int *apiStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804f81;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8._1_3_ = 0;
  if (*(int *)(param_1 + 0x160) == 0) {
    ppiStack_38 = (int **)(in_stack_00000014 + 0xb);
    uStack_8 = 3;
    uStack_1c = 0;
    uStack_18 = 0xf;
    apiStack_2c[0] = (int *)((uint)apiStack_2c[0] & 0xffffff00);
    uStack_14 = 1;
    piStack_3c = (int *)0xc02d76;
    ExceptionList = &pvStack_10;
    FUN_0058a190();
    ppiStack_38 = (int **)0xb;
    piStack_3c = (int *)0x196135c;
    piStack_40 = (int *)0xc02d85;
    FUN_00554150();
    ppiStack_38 = (int **)in_stack_00000014;
    piStack_3c = (int *)&param_2;
    if (0xf < in_stack_00000018) {
      piStack_3c = param_2;
    }
    piStack_40 = (int *)0xc02d9c;
    FUN_00554150();
    ppiStack_38 = apiStack_2c;
    piStack_3c = (int *)in_stack_00000024;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      in_stack_00000020[1] = in_stack_00000020[1] + 1;
      UNLOCK();
    }
    piStack_40 = in_stack_00000020;
    iVar3 = FUN_00c06f60(1,in_stack_0000001c);
    if (0xf < uStack_18) {
      ppiStack_38 = (int **)(uStack_18 + 1);
      piVar4 = apiStack_2c[0];
      if (0xfff < ppiStack_38) {
        piVar4 = (int *)apiStack_2c[0][-1];
        ppiStack_38 = (int **)(uStack_18 + 0x24);
        if (0x1f < (uint)((int)apiStack_2c[0] + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
          ppiStack_38 = (int **)0xc02e8a;
          FUN_017167a3();
        }
      }
      piStack_40 = (int *)0xc02e06;
      piStack_3c = piVar4;
      iVar3 = FUN_01674ea0();
    }
  }
  else {
    ppiStack_38 = in_stack_00000024;
    in_stack_00000024 = &piStack_40;
    ExceptionList = &pvStack_10;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      in_stack_00000020[1] = in_stack_00000020[1] + 1;
      UNLOCK();
    }
    piStack_40 = in_stack_0000001c;
    piStack_3c = in_stack_00000020;
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar3 = FUN_00c02230();
  }
  if (0xf < in_stack_00000018) {
    ppiStack_38 = (int **)(in_stack_00000018 + 1);
    piVar4 = param_2;
    if (0xfff < ppiStack_38) {
      piVar4 = (int *)param_2[-1];
      ppiStack_38 = (int **)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
        ppiStack_38 = (int **)&UNK_00c02e8f;
        FUN_017167a3();
      }
    }
    piStack_40 = (int *)0xc02e36;
    piStack_3c = piVar4;
    iVar3 = FUN_01674ea0();
  }
  piVar4 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (int *)((uint)param_2 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppiStack_38 = (int **)0xc02e64;
      iVar3 = (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppiStack_38 = (int **)0xc02e73;
        iVar3 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27079 ; VA 0x00c02e90 ; FUN_00c02e90 */

undefined4 * __thiscall
FUN_00c02e90(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804fc1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c04770;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27080 ; VA 0x00c03040 ; FUN_00c03040 */

undefined4 * __thiscall
FUN_00c03040(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805001;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c04960;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27081 ; VA 0x00c031f0 ; FUN_00c031f0 */

void FUN_00c031f0(undefined4 param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  cVar1 = FUN_009cb5f0(param_1,auStack_8);
  if (cVar1 != '\0') {
    uVar2 = FUN_00c08100();
    *param_2 = uVar2;
    FUN_00bfff20(auStack_8);
  }
  return;
}



/* FUNCTION 27082 ; VA 0x00c03220 ; FUN_00c03220 */

void FUN_00c03220(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c08100();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27083 ; VA 0x00c03260 ; FUN_00c03260 */

undefined4 * FUN_00c03260(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c00bd0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27084 ; VA 0x00c032d0 ; FUN_00c032d0 */

undefined4 * FUN_00c032d0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00674ea0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27085 ; VA 0x00c03340 ; FUN_00c03340 */

void __thiscall FUN_00c03340(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar2 = *(int *)(param_1 + 0x40);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar2);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_28c = FUN_0088c8c0();
    iStack_288 = 0;
    auStack_284[0] = *puVar5;
    iStack_288 = FUN_005c9cc0();
    puVar5 = &uStack_28c;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088c8c0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27086 ; VA 0x00c03680 ; FUN_00c03680 */

void __thiscall
FUN_00c03680(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int *piVar1;
  undefined *puVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar4 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar4;
  puVar2 = *(undefined **)(param_1 + 0x40);
  if (puVar2 == (undefined *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar7 = 2;
  }
  else {
    uStack_ec = FUN_0088daf0();
    iStack_e8 = 0;
    uStack_e4 = CONCAT31(uStack_e4._1_3_,*puVar2);
    iStack_e8 = FUN_005c9ef0();
    puStack_18 = &uStack_ec;
    uVar7 = 1;
  }
  uStack_8 = (uint)(puVar2 == (undefined *)0x0);
  uStack_14 = uVar7;
  uVar4 = FUN_0088daf0();
  uVar5 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar5,uVar4,puStack_18);
  if ((uVar7 & 2) != 0) {
    uVar7 = uVar7 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 1) != 0) {
    uVar7 = uVar7 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar7;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar3 = *(int *)(param_1 + 0x44);
  if (iVar3 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 5;
    uVar7 = uVar7 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar3);
    iStack_e8 = FUN_005c9d30();
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar7 = uVar7 | 4;
  }
  uStack_14 = uVar7;
  uVar4 = FUN_0088cb40();
  uVar5 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar5,uVar4,puVar6);
  if ((uVar7 & 8) != 0) {
    uVar7 = uVar7 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 4) != 0) {
    uVar7 = uVar7 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar7;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x48);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 9;
    uVar7 = uVar7 | 0x20;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    iStack_e8 = FUN_006309e0();
    puVar6 = &uStack_ec;
    uStack_8 = 8;
    uVar7 = uVar7 | 0x10;
  }
  uStack_14 = uVar7;
  uVar4 = FUN_0088cdc0();
  uVar5 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar5,uVar4,puVar6);
  if ((uVar7 & 0x20) != 0) {
    uVar7 = uVar7 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x10) != 0) {
    uVar7 = uVar7 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar7;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 0xd;
    uVar7 = uVar7 | 0x80;
  }
  else {
    uStack_28c = FUN_0088c8c0();
    iStack_288 = 0;
    auStack_284[0] = *puVar6;
    iStack_288 = FUN_005c9cc0();
    puVar6 = &uStack_28c;
    uStack_8 = 0xc;
    uVar7 = uVar7 | 0x40;
  }
  uStack_14 = uVar7;
  uVar4 = FUN_0088c8c0();
  uVar5 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar5,uVar4,puVar6);
  if ((char)uVar7 < '\0') {
    uVar7 = uVar7 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar7;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar7 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27087 ; VA 0x00c03ab0 ; FUN_00c03ab0 */

undefined4 FUN_00c03ab0(undefined4 param_1,undefined4 *param_2,char *param_3,undefined4 param_4)

{
  uint *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *****pppppuVar4;
  undefined4 uVar5;
  uint uVar6;
  char *pcVar7;
  int iVar8;
  undefined4 ****appppuStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  undefined auStack_20 [4];
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_1c = FUN_0058eea0(param_3,0);
  if ((int)uStack_1c < 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  uVar6 = param_2[5];
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  pcVar7 = param_3 + 1;
  do {
    cVar2 = *param_3;
    param_3 = param_3 + 1;
  } while (cVar2 != '\0');
  pcVar7 = (char *)((int)puVar3 + (int)(param_3 + (uStack_1c - (int)pcVar7)));
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  puVar1 = param_2 + 4;
  uStack_18 = *puVar1;
  for (; (pcVar7 != (char *)((int)puVar3 + uStack_18) && ((*pcVar7 == ' ' || (*pcVar7 == '\t'))));
      pcVar7 = pcVar7 + 1) {
  }
  if (*pcVar7 == '(') {
    puVar3 = param_2;
    if (0xf < uVar6) {
      puVar3 = (undefined4 *)*param_2;
    }
    FUN_00c00dc0(&uStack_18,pcVar7,(int)puVar3 + uStack_18,_guard_check_icall,uStack_1c);
    uStack_2c = 0;
    uStack_28 = 0xf;
    appppuStack_3c[0] = (undefined4 ****)((uint)appppuStack_3c[0] & 0xffffff00);
    uVar6 = uStack_1c;
    if (*puVar1 < uStack_1c) {
      uVar6 = *puVar1;
    }
    puVar3 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar3 = (undefined4 *)*param_2;
    }
    FUN_005542c0(puVar3,uVar6);
    pppppuVar4 = appppuStack_3c;
    if (0xf < uStack_28) {
      pppppuVar4 = (undefined4 *****)appppuStack_3c[0];
    }
    iVar8 = iStack_14 + 0xc0;
    uStack_8 = 0;
    FUN_0055b3b0(iVar8,pppppuVar4,uStack_2c);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
    uVar5 = FUN_00558890(iVar8,"Game:GetService(\'TestService\'):",param_4,&DAT_019360f0);
    uVar5 = FUN_00558890(uVar5);
    FUN_00558890(uVar5);
    uVar6 = uStack_18;
    iVar8 = iStack_14 + 0xc0;
    FUN_00c00b60(auStack_20,pcVar7 + 1,uStack_18 - 1,0,iVar8);
    FUN_00558890(iVar8,", script, ");
    uVar5 = FUN_005af260(param_1,&DAT_018d2114);
    FUN_00558890(uVar5);
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_00c00b60(auStack_20,uVar6,*puVar1 + (int)param_2,0,iVar8);
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_00550130("Expected \'(\'");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c17198);
}



/* FUNCTION 27088 ; VA 0x00c03ca0 ; FUN_00c03ca0 */

undefined4 FUN_00c03ca0(undefined4 param_1,undefined4 *param_2,char *param_3,undefined4 param_4)

{
  uint *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 ****ppppuVar4;
  undefined4 uVar5;
  uint uVar6;
  char *pcVar7;
  int iVar8;
  undefined4 ***apppuStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  undefined auStack_20 [4];
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_1c = FUN_0058eea0(param_3,0);
  if ((int)uStack_1c < 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  uVar6 = param_2[5];
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  pcVar7 = param_3 + 1;
  do {
    cVar2 = *param_3;
    param_3 = param_3 + 1;
  } while (cVar2 != '\0');
  pcVar7 = (char *)((int)puVar3 + (int)(param_3 + (uStack_1c - (int)pcVar7)));
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  puVar1 = param_2 + 4;
  uStack_18 = *puVar1;
  for (; (pcVar7 != (char *)(uStack_18 + (int)puVar3) && ((*pcVar7 == ' ' || (*pcVar7 == '\t'))));
      pcVar7 = pcVar7 + 1) {
  }
  if (*pcVar7 != '(') {
    FUN_00550130("Expected \'(\'");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  FUN_00c00dc0(&uStack_18,pcVar7,(int)puVar3 + uStack_18,_guard_check_icall,uStack_1c);
  uStack_2c = 0;
  uStack_28 = 0xf;
  apppuStack_3c[0] = (undefined4 ***)((uint)apppuStack_3c[0] & 0xffffff00);
  uVar6 = uStack_1c;
  if (*puVar1 < uStack_1c) {
    uVar6 = *puVar1;
  }
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  FUN_005542c0(puVar3,uVar6);
  ppppuVar4 = apppuStack_3c;
  if (0xf < uStack_28) {
    ppppuVar4 = (undefined4 ****)apppuStack_3c[0];
  }
  iVar8 = iStack_14 + 0xc0;
  uStack_8 = 0;
  FUN_0055b3b0(iVar8,ppppuVar4,uStack_2c);
  uStack_8 = 0xffffffff;
  FUN_005507b0();
  uVar5 = FUN_00558890(iVar8,"Game:GetService(\'TestService\'):",param_4,&DAT_019360f0);
  uVar5 = FUN_00558890(uVar5);
  FUN_00558890(uVar5);
  iVar8 = uStack_18 - 1;
  FUN_00c00b60(auStack_20,pcVar7 + 1,iVar8,0,iStack_14 + 0xc0);
  FUN_00558890(iStack_14 + 0xc0,", [==[test failed: ");
  FUN_00c00b60(auStack_20,pcVar7 + 1,iVar8,0,iStack_14 + 0xc0);
  FUN_00558890(iStack_14 + 0xc0,"]==], script, ");
  uVar5 = FUN_005af260(param_1,&DAT_018d2114);
  FUN_00558890(uVar5);
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00c00b60(auStack_20,uStack_18,*puVar1 + (int)param_2,0,iStack_14 + 0xc0);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 27089 ; VA 0x00c03ec0 ; FUN_00c03ec0 */

undefined4
FUN_00c03ec0(undefined4 param_1,undefined4 *param_2,char *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  char cVar1;
  byte bVar2;
  uint uVar3;
  bool bVar4;
  byte bVar10;
  undefined4 *puVar5;
  char *pcVar6;
  byte *pbVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  byte *pbVar11;
  byte *pbVar12;
  byte *pbVar13;
  int iVar14;
  char *pcVar15;
  undefined auStack_50 [24];
  undefined4 *puStack_38;
  int iStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [4];
  undefined auStack_28 [4];
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  byte *pbStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01805020;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = FUN_0058eea0(param_3,0);
  if (iStack_1c < 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  uVar3 = param_2[5];
  puVar5 = param_2;
  if (0xf < uVar3) {
    puVar5 = (undefined4 *)*param_2;
  }
  pcVar15 = param_3 + 1;
  do {
    cVar1 = *param_3;
    param_3 = param_3 + 1;
  } while (cVar1 != '\0');
  pcVar6 = (char *)((int)puVar5 + (int)(param_3 + (iStack_1c - (int)pcVar15)));
  puVar5 = param_2;
  if (0xf < uVar3) {
    puVar5 = (undefined4 *)*param_2;
  }
  piStack_24 = param_2 + 4;
  for (; (pcVar6 != (char *)((int)puVar5 + *piStack_24) && ((*pcVar6 == ' ' || (*pcVar6 == '\t'))));
      pcVar6 = pcVar6 + 1) {
  }
  if (*pcVar6 == '(') {
    puStack_38 = (undefined4 *)0x0;
    iStack_34 = 0;
    uStack_30 = 0;
    iStack_8 = 0;
    puVar5 = param_2;
    if (0xf < uVar3) {
      puVar5 = (undefined4 *)*param_2;
    }
    pbVar11 = (byte *)((int)puVar5 + *piStack_24);
    cVar1 = *pcVar6;
    if (cVar1 == '(') {
      bVar10 = 0x29;
    }
    else if (cVar1 == '[') {
      bVar10 = 0x5d;
    }
    else {
      bVar10 = (cVar1 != '{') - 1U & 0x7d;
    }
    param_3 = (char *)CONCAT31((int3)((uint)pcVar15 >> 8),bVar10);
    bVar4 = true;
    pbVar12 = (byte *)(pcVar6 + 1);
    pbStack_18 = pbVar11;
    if ((byte *)(pcVar6 + 1) != pbVar11) {
      do {
        bVar2 = *pbVar12;
        if (bVar2 == bVar10) {
          if ((iStack_34 - (int)puStack_38) / 0x18 == 2) {
            puVar9 = (undefined4 *)FUN_0058c540(auStack_50,0,iStack_1c);
            puVar5 = puVar9 + 4;
            iStack_8._0_1_ = 1;
            if (0xf < (uint)puVar9[5]) {
              puVar9 = (undefined4 *)*puVar9;
            }
            iVar14 = iStack_20 + 0xc0;
            FUN_0055b3b0(iVar14,puVar9,*puVar5);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_005507b0();
            FUN_00558890(iVar14,&DAT_019617c8);
            uVar8 = FUN_00558890(iVar14,"local aZZZZ = ");
            puVar5 = puStack_38;
            if (0xf < (uint)puStack_38[5]) {
              puVar5 = (undefined4 *)*puStack_38;
            }
            uVar8 = FUN_0055b3b0(uVar8,puVar5,puStack_38[4]);
            uVar8 = FUN_00558890(uVar8," local bZZZZ = ");
            puVar5 = puStack_38 + 6;
            if (0xf < (uint)puStack_38[0xb]) {
              puVar5 = (undefined4 *)*puVar5;
            }
            uVar8 = FUN_0055b3b0(uVar8,puVar5,puStack_38[10],&DAT_018c0cc8);
            FUN_00558890(uVar8);
            uVar8 = FUN_00558890(iVar14,"if aZZZZ ",param_5," bZZZZ then ");
            uVar8 = FUN_00558890(uVar8);
            FUN_00558890(uVar8);
            uVar8 = FUN_00558890(iVar14,"Game:GetService(\'TestService\'):",param_4,"(true, [==[");
            uVar8 = FUN_00558890(uVar8);
            uVar8 = FUN_00558890(uVar8);
            puVar5 = puStack_38;
            if (0xf < (uint)puStack_38[5]) {
              puVar5 = (undefined4 *)*puStack_38;
            }
            uVar8 = FUN_0055b3b0(uVar8,puVar5,puStack_38[4]);
            uVar8 = FUN_00558890(uVar8,&DAT_018c0cc8,param_5,&DAT_018c0cc8);
            uVar8 = FUN_00558890(uVar8);
            uVar8 = FUN_00558890(uVar8);
            puVar5 = puStack_38 + 6;
            if (0xf < (uint)puStack_38[0xb]) {
              puVar5 = (undefined4 *)*puVar5;
            }
            uVar8 = FUN_0055b3b0(uVar8,puVar5,puStack_38[10]);
            FUN_00558890(uVar8,"]==], script, ");
            uVar8 = FUN_005af260(param_1,&DAT_01961808);
            FUN_00558890(uVar8);
            FUN_00558890(iVar14,"else ");
            uVar8 = FUN_00558890(iVar14,"Game:GetService(\'TestService\'):",param_4,
                                 "(false, [==[test ");
            uVar8 = FUN_00558890(uVar8);
            uVar8 = FUN_00558890(uVar8);
            puVar5 = puStack_38;
            if (0xf < (uint)puStack_38[5]) {
              puVar5 = (undefined4 *)*puStack_38;
            }
            uVar8 = FUN_0055b3b0(uVar8,puVar5,puStack_38[4]);
            uVar8 = FUN_00558890(uVar8,&DAT_018c0cc8,param_5,&DAT_018c0cc8);
            uVar8 = FUN_00558890(uVar8);
            uVar8 = FUN_00558890(uVar8);
            puVar5 = puStack_38 + 6;
            if (0xf < (uint)puStack_38[0xb]) {
              puVar5 = (undefined4 *)*puVar5;
            }
            uVar8 = FUN_0055b3b0(uVar8,puVar5,puStack_38[10]);
            uVar8 = FUN_00558890(uVar8," failed []==] .. tostring(aZZZZ) .. \' ",param_6,
                                 " \' .. tostring(bZZZZ) .. \']\', script, ");
            uVar8 = FUN_00558890(uVar8);
            FUN_00558890(uVar8);
            uVar8 = FUN_005af260(param_1,&DAT_01961808);
            FUN_00558890(uVar8);
            FUN_00558890(iVar14,&DAT_019618b4);
            FUN_00558890(iVar14,&DAT_0195b0c0);
            if (0xf < (uint)param_2[5]) {
              param_2 = (undefined4 *)*param_2;
            }
            FUN_00c00b60(auStack_28,pbVar12 + 1,*piStack_24 + (int)param_2,0,iVar14);
            thunk_FUN_00577a40();
            ExceptionList = pvStack_10;
            return 1;
          }
          uVar8 = FUN_0058c070();
          FUN_016756b0(auStack_2c,"Expected 2 arguments but got %d",uVar8);
          goto LAB_00c04319;
        }
        if ((bVar2 == 0x20) || (bVar2 == 9)) {
LAB_00c03fc9:
          pbVar13 = pbVar12 + 1;
        }
        else {
          if (bVar2 == 0x2c) {
            bVar4 = true;
            goto LAB_00c03fc9;
          }
          if (!bVar4) {
            pcVar15 = "argument not separated by comma";
            goto LAB_00c04311;
          }
          FUN_00c00f00(&pbStack_14,pbVar12,pbVar11,param_3);
          pbVar13 = pbStack_14;
          pbVar7 = pbVar12;
          pbVar11 = pbVar12;
          if (pbVar12 != pbStack_14) {
            do {
              if ((*pbVar7 != 0x20) && (*pbVar7 != 9)) {
                pbVar11 = pbVar7 + 1;
              }
              pbVar7 = pbVar7 + 1;
            } while (pbVar7 != pbStack_14);
            if (pbVar11 != pbVar12) {
              FUN_00c02930(&puStack_38,pbVar12,pbVar11);
            }
          }
          bVar4 = false;
          pbVar11 = pbStack_18;
        }
        pbVar12 = pbVar13;
      } while (pbVar13 != pbVar11);
    }
    pcVar15 = "Missing closing bracket";
  }
  else {
    pcVar15 = "Expected \'(\'";
  }
LAB_00c04311:
  FUN_00550130(pcVar15);
LAB_00c04319:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_2c,&DAT_01c17198);
}



/* FUNCTION 27090 ; VA 0x00c04330 ; FUN_00c04330 */

undefined4 FUN_00c04330(undefined4 param_1,undefined4 *param_2,char *param_3,undefined4 param_4)

{
  uint *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 ****ppppuVar4;
  undefined4 uVar5;
  uint uVar6;
  char *pcVar7;
  int iVar8;
  undefined4 ***apppuStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  undefined auStack_20 [4];
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_1c = FUN_0058eea0(param_3,0);
  if ((int)uStack_1c < 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  uVar6 = param_2[5];
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  pcVar7 = param_3 + 1;
  do {
    cVar2 = *param_3;
    param_3 = param_3 + 1;
  } while (cVar2 != '\0');
  pcVar7 = (char *)((int)puVar3 + (int)(param_3 + (uStack_1c - (int)pcVar7)));
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  puVar1 = param_2 + 4;
  uStack_18 = *puVar1;
  for (; (pcVar7 != (char *)(uStack_18 + (int)puVar3) && ((*pcVar7 == ' ' || (*pcVar7 == '\t'))));
      pcVar7 = pcVar7 + 1) {
  }
  if (*pcVar7 != '(') {
    FUN_00550130("Expected \'(\'");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  FUN_00c00dc0(&uStack_18,pcVar7,(int)puVar3 + uStack_18,_guard_check_icall,uStack_1c);
  uStack_2c = 0;
  uStack_28 = 0xf;
  apppuStack_3c[0] = (undefined4 ***)((uint)apppuStack_3c[0] & 0xffffff00);
  uVar6 = uStack_1c;
  if (*puVar1 < uStack_1c) {
    uVar6 = *puVar1;
  }
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  FUN_005542c0(puVar3,uVar6);
  ppppuVar4 = apppuStack_3c;
  if (0xf < uStack_28) {
    ppppuVar4 = (undefined4 ****)apppuStack_3c[0];
  }
  iVar8 = iStack_14 + 0xc0;
  uStack_8 = 0;
  FUN_0055b3b0(iVar8,ppppuVar4,uStack_2c);
  uStack_8 = 0xffffffff;
  FUN_005507b0();
  uVar5 = FUN_00558890(iVar8,"Game:GetService(\'TestService\'):",param_4,"(ypcall(function() ");
  uVar5 = FUN_00558890(uVar5);
  FUN_00558890(uVar5);
  iVar8 = uStack_18 - 1;
  FUN_00c00b60(auStack_20,pcVar7 + 1,iVar8,0,iStack_14 + 0xc0);
  FUN_00558890(iStack_14 + 0xc0," end) == true, \'Exception thrown by \' .. [==[");
  FUN_00c00b60(auStack_20,pcVar7 + 1,iVar8,0,iStack_14 + 0xc0);
  FUN_00558890(iStack_14 + 0xc0,"]==], script, ");
  uVar5 = FUN_005af260(param_1,&DAT_018d2114);
  FUN_00558890(uVar5);
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00c00b60(auStack_20,uStack_18,*puVar1 + (int)param_2,0,iStack_14 + 0xc0);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 27091 ; VA 0x00c04550 ; FUN_00c04550 */

undefined4 FUN_00c04550(undefined4 param_1,undefined4 *param_2,char *param_3,undefined4 param_4)

{
  uint *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 ****ppppuVar4;
  undefined4 uVar5;
  uint uVar6;
  char *pcVar7;
  int iVar8;
  undefined4 ***apppuStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  undefined auStack_20 [4];
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_1c = FUN_0058eea0(param_3,0);
  if ((int)uStack_1c < 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  uVar6 = param_2[5];
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  pcVar7 = param_3 + 1;
  do {
    cVar2 = *param_3;
    param_3 = param_3 + 1;
  } while (cVar2 != '\0');
  pcVar7 = (char *)((int)puVar3 + (int)(param_3 + (uStack_1c - (int)pcVar7)));
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  puVar1 = param_2 + 4;
  uStack_18 = *puVar1;
  for (; (pcVar7 != (char *)(uStack_18 + (int)puVar3) && ((*pcVar7 == ' ' || (*pcVar7 == '\t'))));
      pcVar7 = pcVar7 + 1) {
  }
  if (*pcVar7 != '(') {
    FUN_00550130("Expected \'(\'");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  puVar3 = param_2;
  if (0xf < uVar6) {
    puVar3 = (undefined4 *)*param_2;
  }
  FUN_00c00dc0(&uStack_18,pcVar7,(int)puVar3 + uStack_18,_guard_check_icall,uStack_1c);
  uStack_2c = 0;
  uStack_28 = 0xf;
  apppuStack_3c[0] = (undefined4 ***)((uint)apppuStack_3c[0] & 0xffffff00);
  uVar6 = uStack_1c;
  if (*puVar1 < uStack_1c) {
    uVar6 = *puVar1;
  }
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  FUN_005542c0(puVar3,uVar6);
  ppppuVar4 = apppuStack_3c;
  if (0xf < uStack_28) {
    ppppuVar4 = (undefined4 ****)apppuStack_3c[0];
  }
  iVar8 = iStack_14 + 0xc0;
  uStack_8 = 0;
  FUN_0055b3b0(iVar8,ppppuVar4,uStack_2c);
  uStack_8 = 0xffffffff;
  FUN_005507b0();
  uVar5 = FUN_00558890(iVar8,"Game:GetService(\'TestService\'):",param_4,"(ypcall(function() ");
  uVar5 = FUN_00558890(uVar5);
  FUN_00558890(uVar5);
  iVar8 = uStack_18 - 1;
  FUN_00c00b60(auStack_20,pcVar7 + 1,iVar8,0,iStack_14 + 0xc0);
  FUN_00558890(iStack_14 + 0xc0," end) == false, \'Exception expected in \' .. [==[");
  FUN_00c00b60(auStack_20,pcVar7 + 1,iVar8,0,iStack_14 + 0xc0);
  FUN_00558890(iStack_14 + 0xc0,"]==], script, ");
  uVar5 = FUN_005af260(param_1,&DAT_018d2114);
  FUN_00558890(uVar5);
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00c00b60(auStack_20,uStack_18,*puVar1 + (int)param_2,0,iStack_14 + 0xc0);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 27092 ; VA 0x00c04770 ; FUN_00c04770 */

int FUN_00c04770(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180507f;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar5;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  FUN_0054ef60(&param_2);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = in_stack_00000020;
  piStack_1b4 = in_stack_00000024;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000028;
  uStack_ec = FUN_005c9cc0();
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 6;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar6 = FUN_01675290(uVar5);
  if (0xf < in_stack_0000001c) {
    uVar8 = in_stack_0000001c + 1;
    uVar7 = param_2;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(param_2 - 4);
      uVar8 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar7,uVar8);
  }
  piVar4 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000024 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 27093 ; VA 0x00c04960 ; FUN_00c04960 */

int FUN_00c04960(int param_1,undefined param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined uStack_358;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018050ea;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar5;
  uStack_360 = FUN_0088daf0();
  uStack_35c = 0;
  uStack_358 = param_2;
  uStack_35c = FUN_005c9ef0();
  uStack_8._0_1_ = 3;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  FUN_0054ef60(&param_3);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = in_stack_00000024;
  piStack_1b4 = in_stack_00000028;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 5;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = in_stack_0000002c;
  uStack_ec = FUN_005c9cc0();
  uStack_8._0_1_ = 6;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_360,&uStack_20,pcVar3);
  uStack_8._0_1_ = 7;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 8;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_360,0xd0,4,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  iVar6 = FUN_01675290(uVar5);
  if (0xf < in_stack_00000020) {
    uVar8 = in_stack_00000020 + 1;
    uVar7 = param_3;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(param_3 - 4);
      uVar8 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar7,uVar8);
  }
  piVar4 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 27094 ; VA 0x00c04b80 ; FUN_00c04b80 */

int FUN_00c04b80(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  int *in_stack_00000024;
  undefined4 *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805110;
  pvStack_10 = ExceptionList;
  puStack_1c = &param_2;
  puStack_18 = &stack0x00000020;
  uStack_8 = 1;
  puStack_14 = &stack0x00000028;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00bfffd0(param_1,param_1 + 0x18,&puStack_1c,0);
  if (0xf < in_stack_0000001c) {
    uVar6 = in_stack_0000001c + 1;
    uVar5 = param_2;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(param_2 - 4);
      uVar6 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar5,uVar6);
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000024 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 27095 ; VA 0x00c04c50 ; FUN_00c04c50 */

int FUN_00c04c50(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  int *in_stack_00000028;
  undefined *puStack_20;
  undefined4 *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805130;
  pvStack_10 = ExceptionList;
  puStack_20 = (undefined *)&param_2;
  puStack_1c = &param_3;
  uStack_8 = 1;
  puStack_18 = &stack0x00000024;
  puStack_14 = &stack0x0000002c;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00c00100(param_1,param_1 + 0x18,&puStack_20,0);
  if (0xf < in_stack_00000020) {
    uVar6 = in_stack_00000020 + 1;
    uVar5 = param_3;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(param_3 - 4);
      uVar6 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar5,uVar6);
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 27096 ; VA 0x00c04d30 ; FUN_00c04d30 */

void __fastcall FUN_00c04d30(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0cf0;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x90) != '\0') {
    ExceptionList = &pvStack_10;
    *(undefined *)(param_1 + 0x90) = 0;
    if (*(uint *)(param_1 + 0x1a0) == 0) {
      if (*(int *)(param_1 + 0x9c) == 0) {
        FUN_0086edd0(1,"TestService: Doesn\'t include any assertions",6);
      }
      else {
        FUN_0086f2f0(1,"TestService: Run completed, tests: %u, warns: %u, errors: %u",
                     *(int *)(param_1 + 0x9c),*(undefined4 *)(param_1 + 0xa0),
                     *(undefined4 *)(param_1 + 0xa4));
      }
    }
    else {
      (**(code **)((*(uint *)(param_1 + 0x1a0) & 0xfffffffe) + 4))(param_1 + 0x1a8);
    }
    FUN_00c08b60();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27097 ; VA 0x00c04dd0 ; FUN_00c04dd0 */

void __thiscall FUN_00c04dd0(int param_1,int param_2,int param_3)

{
  FUN_00558b30(param_2 + *(int *)(param_1 + 8),param_3 + *(int *)(param_1 + 8));
  return;
}



/* FUNCTION 27098 ; VA 0x00c04df0 ; FUN_00c04df0 */

void __thiscall FUN_00c04df0(int param_1,int param_2)

{
  int iVar1;
  uint in_stack_00000018;
  undefined4 uStack_38;
  undefined *puStack_34;
  char *pcStack_30;
  undefined auStack_24 [16];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01805150;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if (*(int *)(param_1 + 0x54) == 0) {
    pcStack_30 = "Can\'t find TestService";
    puStack_34 = (undefined *)0xc04eae;
    ExceptionList = &pvStack_10;
    FUN_00550130();
    pcStack_30 = "";
    puStack_34 = auStack_24;
                    /* WARNING: Subroutine does not return */
    uStack_38 = 0xc04ebc;
    FUN_0170c2a8();
  }
  pcStack_30 = (char *)0x0;
  puStack_14 = (undefined *)&uStack_38;
  uStack_38 = 0;
  puStack_34 = (undefined *)0x0;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00c02a50(0);
  pcStack_30 = (char *)0xc04e5f;
  FUN_00c04d30();
  if (0xf < in_stack_00000018) {
    pcStack_30 = (char *)(in_stack_00000018 + 1);
    iVar1 = param_2;
    if (0xfff < pcStack_30) {
      iVar1 = *(int *)(param_2 + -4);
      pcStack_30 = (char *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        pcStack_30 = &UNK_00c04ec1;
        FUN_017167a3();
      }
    }
    uStack_38 = 0xc04e8c;
    puStack_34 = (undefined *)iVar1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27099 ; VA 0x00c04ed0 ; FUN_00c04ed0 */

int __thiscall FUN_00c04ed0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int *in_stack_0000001c;
  int *in_stack_00000020;
  int **in_stack_00000024;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805178;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x9c) = *(int *)(param_1 + 0x9c) + 1;
  piStack_20 = (int *)&DAT_02133970;
  uStack_8 = 1;
  piStack_24 = (int *)0xc04f04;
  FUN_008a4940();
  *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 1;
  piStack_20 = (int *)&DAT_021339e0;
  piStack_24 = (int *)0xc04f16;
  FUN_008a4940();
  if (*(int *)(param_1 + 0x140) == 0) {
    piStack_20 = (int *)&param_2;
    piStack_24 = (int *)in_stack_00000024;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      in_stack_00000020[1] = in_stack_00000020[1] + 1;
      UNLOCK();
    }
    piStack_28 = in_stack_00000020;
    iVar3 = FUN_00c06f60(3,in_stack_0000001c);
  }
  else {
    piStack_20 = (int *)in_stack_00000024;
    in_stack_00000024 = &piStack_28;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      in_stack_00000020[1] = in_stack_00000020[1] + 1;
      UNLOCK();
    }
    piStack_28 = in_stack_0000001c;
    piStack_24 = in_stack_00000020;
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar3 = FUN_00c02370(0);
  }
  if (0xf < in_stack_00000018) {
    piStack_20 = (int *)(in_stack_00000018 + 1);
    piVar4 = param_2;
    if (0xfff < piStack_20) {
      piVar4 = (int *)param_2[-1];
      piStack_20 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
        piStack_20 = (int *)&UNK_00c0502c;
        FUN_017167a3();
      }
    }
    piStack_28 = (int *)0xc04fd8;
    piStack_24 = piVar4;
    iVar3 = FUN_01674ea0();
  }
  piVar4 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (int *)((uint)param_2 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_20 = (int *)0xc05006;
      iVar3 = (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_20 = (int *)0xc05015;
        iVar3 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27100 ; VA 0x00c05030 ; FUN_00c05030 */

undefined4 FUN_00c05030(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018051a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300();
  FUN_009d05b0(param_2,param_3,3);
  iStack_18 = FUN_009d1340(auStack_20,param_2,param_3,2,iVar3 - param_3,iStack_14 + 0x44);
  uStack_8 = 0;
  uVar4 = FUN_009d09d0(auStack_38,param_2,param_3,1,iVar3 - param_3,iStack_14 + 0x40);
  pcVar2 = *(code **)(iStack_14 + 0x38);
  if (*(int *)(iStack_18 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iStack_18 + 4) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  FUN_0054ef60(uVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (*pcVar2)();
  if (0xf < uStack_24) {
    uVar6 = uStack_24 + 1;
    uVar5 = auStack_38[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_38[0] - 4);
      uVar6 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 27101 ; VA 0x00c05190 ; FUN_00c05190 */

undefined4 FUN_00c05190(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018051d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01256300();
  FUN_009d05b0(param_2,param_3,4);
  iStack_18 = FUN_009d1340(auStack_24,param_2,param_3,3,iVar4 - param_3,iStack_14 + 0x48);
  uStack_8 = 0;
  uStack_1c = FUN_009d09d0(auStack_3c,param_2,param_3,2,iVar4 - param_3,iStack_14 + 0x44);
  uStack_8._0_1_ = 1;
  uVar3 = FUN_009d1aa0(param_2,param_3);
  pcVar2 = *(code **)(iStack_14 + 0x38);
  if (*(int *)(iStack_18 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iStack_18 + 4) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  FUN_0054ef60(uStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (*pcVar2)(uVar3);
  if (0xf < uStack_28) {
    uVar6 = uStack_28 + 1;
    uVar5 = auStack_3c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_3c[0] - 4);
      uVar6 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_20[1] + -1;
    piStack_20[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 27102 ; VA 0x00c05310 ; FUN_00c05310 */

int __thiscall FUN_00c05310(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int in_stack_00000014;
  uint in_stack_00000018;
  int *in_stack_0000001c;
  int *in_stack_00000020;
  int **in_stack_00000024;
  int *piStack_40;
  int *piStack_3c;
  int **ppiStack_38;
  int *apiStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804f81;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x9c) = *(int *)(param_1 + 0x9c) + 1;
  ppiStack_38 = (int **)&DAT_02133970;
  uStack_8 = 1;
  piStack_3c = (int *)0xc0534d;
  FUN_008a4940();
  *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 1;
  ppiStack_38 = (int **)&DAT_021339e0;
  piStack_3c = (int *)0xc0535f;
  FUN_008a4940();
  if (*(int *)(param_1 + 0x140) == 0) {
    ppiStack_38 = (int **)(in_stack_00000014 + 6);
    uStack_8._0_1_ = 3;
    uStack_1c = 0;
    uStack_18 = 0xf;
    apiStack_2c[0] = (int *)((uint)apiStack_2c[0] & 0xffffff00);
    uStack_14 = 1;
    piStack_3c = (int *)0xc053ea;
    FUN_0058a190();
    ppiStack_38 = (int **)0x6;
    piStack_3c = (int *)0x1961368;
    piStack_40 = (int *)0xc053f9;
    FUN_00554150();
    ppiStack_38 = (int **)in_stack_00000014;
    piStack_3c = (int *)&param_2;
    if (0xf < in_stack_00000018) {
      piStack_3c = param_2;
    }
    piStack_40 = (int *)0xc05410;
    FUN_00554150();
    ppiStack_38 = apiStack_2c;
    piStack_3c = (int *)in_stack_00000024;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      in_stack_00000020[1] = in_stack_00000020[1] + 1;
      UNLOCK();
    }
    piStack_40 = in_stack_00000020;
    FUN_00c06f60(3,in_stack_0000001c);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_18) {
      ppiStack_38 = (int **)(uStack_18 + 1);
      piVar4 = apiStack_2c[0];
      if (0xfff < ppiStack_38) {
        piVar4 = (int *)apiStack_2c[0][-1];
        ppiStack_38 = (int **)(uStack_18 + 0x24);
        if (0x1f < (uint)((int)apiStack_2c[0] + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
          ppiStack_38 = (int **)0xc05509;
          FUN_017167a3();
        }
      }
      piStack_40 = (int *)0xc0547e;
      piStack_3c = piVar4;
      FUN_01674ea0();
    }
  }
  else {
    ppiStack_38 = in_stack_00000024;
    in_stack_00000024 = &piStack_40;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      in_stack_00000020[1] = in_stack_00000020[1] + 1;
      UNLOCK();
    }
    piStack_40 = in_stack_0000001c;
    piStack_3c = in_stack_00000020;
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00c02370(0);
  }
  ppiStack_38 = (int **)0xc05488;
  iVar3 = FUN_00c04d30();
  if (0xf < in_stack_00000018) {
    ppiStack_38 = (int **)(in_stack_00000018 + 1);
    piVar4 = param_2;
    if (0xfff < ppiStack_38) {
      piVar4 = (int *)param_2[-1];
      ppiStack_38 = (int **)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
        ppiStack_38 = (int **)&UNK_00c0550e;
        FUN_017167a3();
      }
    }
    piStack_40 = (int *)0xc054b5;
    piStack_3c = piVar4;
    iVar3 = FUN_01674ea0();
  }
  piVar4 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (int *)((uint)param_2 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppiStack_38 = (int **)0xc054e3;
      iVar3 = (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppiStack_38 = (int **)0xc054f2;
        iVar3 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27103 ; VA 0x00c05510 ; FUN_00c05510 */

undefined * FUN_00c05510(undefined *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805214;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c017b0(param_2);
  uStack_8 = 1;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  if (((*(uint *)(iVar1 + 0x104) & 2) == 0) && (uVar3 = **(uint **)(iVar1 + 0xe8), uVar3 != 0)) {
    iVar2 = **(int **)(iVar1 + 0xd8);
    if (uVar3 < *(uint *)(iVar1 + 0x100)) {
      uVar3 = *(uint *)(iVar1 + 0x100);
    }
    iVar1 = uVar3 - iVar2;
  }
  else {
    if (((*(uint *)(iVar1 + 0x104) & 4) != 0) || (**(int **)(iVar1 + 0xe4) == 0)) goto LAB_00c055c6;
    iVar2 = **(int **)(iVar1 + 0xd4);
    iVar1 = (**(int **)(iVar1 + 0xf4) - iVar2) + **(int **)(iVar1 + 0xe4);
  }
  FUN_005542c0(iVar2,iVar1);
LAB_00c055c6:
  FUN_005705c0();
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27104 ; VA 0x00c055f0 ; FUN_00c055f0 */

int FUN_00c055f0(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5,undefined4 param_6,uint param_7,int param_8,int *param_9,
                int *param_10,undefined4 param_11)

{
  int *piVar1;
  int iVar2;
  undefined8 uVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  undefined4 in_stack_ffffffbc;
  undefined4 in_stack_ffffffc0;
  undefined4 in_stack_ffffffc4;
  undefined8 in_stack_ffffffc8;
  undefined4 in_stack_ffffffd0;
  int iStack_2c;
  uint uStack_28;
  undefined *puStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uVar7 = (uint)param_10;
  puStack_c = &LAB_01805238;
  pvStack_10 = ExceptionList;
  puStack_24 = (undefined *)param_10;
  param_10 = &iStack_2c;
  ExceptionList = &pvStack_10;
  if (param_9 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)((int)param_9 + 4) = *(int *)((int)param_9 + 4) + 1;
    UNLOCK();
  }
  iStack_2c = param_8;
  uStack_28 = (uint)param_9;
  uStack_8 = 2;
  uStack_7 = 0;
  FUN_0054ef60(&param_2);
  _uStack_8 = CONCAT31(uStack_7,1);
  FUN_00c058d0(param_1,in_stack_ffffffbc,in_stack_ffffffc0,in_stack_ffffffc4,in_stack_ffffffc8,
               in_stack_ffffffd0);
  iVar6 = param_8;
  uVar4 = param_2;
  puStack_24 = (undefined *)param_11;
  uStack_28 = uVar7;
  iStack_2c = (int)param_9;
  param_8 = 0;
  param_9 = (int *)0x0;
  uVar3 = CONCAT44(param_7,param_6);
  param_6 = 0;
  param_7 = 0xf;
  param_2 = param_2 & 0xffffff00;
  iVar6 = FUN_00c07550(param_1,uVar4,param_3,param_4,param_5,uVar3,iVar6);
  if (0xf < param_7) {
    puStack_24 = (undefined *)(param_7 + 1);
    uVar7 = param_2;
    if (0xfff < puStack_24) {
      uVar7 = *(uint *)(param_2 - 4);
      puStack_24 = (undefined *)(param_7 + 0x24);
      if (0x1f < (param_2 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_24 = &UNK_00c05757;
        FUN_017167a3();
      }
    }
    iStack_2c = 0xc05703;
    uStack_28 = uVar7;
    iVar6 = FUN_01674ea0();
  }
  piVar5 = param_9;
  param_6 = 0;
  param_7 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (param_9 != (int *)0x0) {
    LOCK();
    piVar1 = param_9 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_24 = (undefined *)0xc05731;
      iVar6 = (**(code **)*param_9)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_24 = (undefined *)0xc05740;
        iVar6 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 27105 ; VA 0x00c05760 ; FUN_00c05760 */

int FUN_00c05760(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                undefined4 param_5,undefined4 param_6,undefined4 param_7,uint param_8,
                undefined4 param_9,int *param_10,undefined4 param_11,undefined4 param_12)

{
  int *piVar1;
  int iVar2;
  undefined8 uVar3;
  uint uVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  undefined4 in_stack_ffffffb8;
  undefined4 in_stack_ffffffbc;
  undefined4 in_stack_ffffffc0;
  undefined8 in_stack_ffffffc4;
  undefined4 in_stack_ffffffcc;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01805268;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)((int)param_10 + 4) = *(int *)((int)param_10 + 4) + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uStack_7 = 0;
  FUN_0054ef60(&param_3);
  _uStack_8 = CONCAT31(uStack_7,1);
  FUN_00c059f0(param_1,param_2,in_stack_ffffffb8,in_stack_ffffffbc,in_stack_ffffffc0,
               in_stack_ffffffc4,in_stack_ffffffcc);
  uVar5 = param_9;
  uVar4 = param_3;
  param_9 = 0;
  param_10 = (int *)0x0;
  uVar3 = CONCAT44(param_8,param_7);
  param_7 = 0;
  param_8 = 0xf;
  param_3 = param_3 & 0xffffff00;
  iVar7 = FUN_00c07730(param_1,param_2,uVar4,param_4,param_5,param_6,uVar3,uVar5);
  if (0xf < param_8) {
    if (0xfff < param_8 + 1) {
      if (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar7 = FUN_01674ea0();
  }
  piVar6 = param_10;
  param_7 = 0;
  param_8 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (param_10 != (int *)0x0) {
    LOCK();
    piVar1 = param_10 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*param_10)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 27106 ; VA 0x00c058d0 ; FUN_00c058d0 */

/* WARNING: Removing unreachable block (ram,0x00c05978) */
/* WARNING: Removing unreachable block (ram,0x00c059de) */
/* WARNING: Removing unreachable block (ram,0x00c0596a) */
/* WARNING: Removing unreachable block (ram,0x00c05988) */
/* WARNING: Removing unreachable block (ram,0x00c059ab) */
/* WARNING: Removing unreachable block (ram,0x00c059b7) */
/* WARNING: Removing unreachable block (ram,0x00c059c5) */

undefined4
FUN_00c058d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805110;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c024b0(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8,param_9,
                       param_10);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 27107 ; VA 0x00c059f0 ; FUN_00c059f0 */

/* WARNING: Removing unreachable block (ram,0x00c05a9b) */
/* WARNING: Removing unreachable block (ram,0x00c05b01) */
/* WARNING: Removing unreachable block (ram,0x00c05a8d) */
/* WARNING: Removing unreachable block (ram,0x00c05aab) */
/* WARNING: Removing unreachable block (ram,0x00c05ace) */
/* WARNING: Removing unreachable block (ram,0x00c05ada) */
/* WARNING: Removing unreachable block (ram,0x00c05ae8) */

undefined4
FUN_00c059f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805130;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c02620(param_2,param_3,param_4,param_5,param_6,CONCAT44(param_8,param_7),param_9,
                       param_10,param_11);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 27108 ; VA 0x00c05b10 ; FUN_00c05b10 */

void FUN_00c05b10(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804a38;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(*param_2 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088c8c0();
  if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar1 = *param_2;
  iVar2 = *(int *)(iVar1 + 0xd0);
  iVar3 = FUN_0088cdc0();
  if (iVar2 == iVar3) {
    iVar2 = iVar1 + 0xd8;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      iVar2 = 0;
    }
    if (*(int *)(iVar2 + 4) != 0) {
      LOCK();
      piVar4 = (int *)(*(int *)(iVar2 + 4) + 4);
      *piVar4 = *piVar4 + 1;
      UNLOCK();
    }
    param_2 = (int *)*param_2;
    uStack_8 = 0;
    iVar1 = *param_2;
    iVar2 = FUN_0088cb40();
    if (iVar1 == iVar2) {
      piVar4 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar4 = (int *)0x0;
      }
      FUN_0054ef60(piVar4);
      uStack_8 = 0xffffffff;
      FUN_00c058d0(param_1);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 27109 ; VA 0x00c05c20 ; FUN_00c05c20 */

void FUN_00c05c20(undefined4 param_1,undefined4 param_2)

{
  FUN_00c00fd0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 27110 ; VA 0x00c05c40 ; FUN_00c05c40 */

void FUN_00c05c40(void)

{
  int iVar1;
  
  if (DAT_01ef85b4 == 0) {
    iVar1 = FUN_00c00240();
    DAT_01ef85b4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27111 ; VA 0x00c05c60 ; FUN_00c05c60 */

int * __thiscall FUN_00c05c60(int *param_1,undefined *param_2,int param_3,int param_4,uint param_5)

{
  uint *puVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  bool bVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805290;
  pvStack_10 = ExceptionList;
  uVar6 = 0;
  ExceptionList = &pvStack_10;
  param_1[2] = 0;
  param_1[3] = 0;
  piVar4 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 4))();
  }
  uStack_8 = 0;
  cVar3 = FUN_00593b40(1);
  uStack_8 = 1;
  if (((cVar3 != '\0') && (-1 < param_4)) && ((0 < param_4 || (param_3 != 0)))) {
    uStack_8 = 2;
    piVar4 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if ((*(byte **)piVar4[7] == (byte *)0x0) || (*(int *)piVar4[0xb] < 1)) {
      uVar6 = (**(code **)(*piVar4 + 0x18))();
    }
    else {
      uVar6 = (uint)**(byte **)piVar4[7];
    }
    while( true ) {
      if (uVar6 == 0xffffffff) {
        piVar4 = (int *)FUN_00c05dc5();
        return piVar4;
      }
      if (uVar6 == (param_5 & 0xff)) break;
      bVar7 = param_3 != 0;
      param_3 = param_3 + -1;
      param_4 = param_4 + -1 + (uint)bVar7;
      if ((param_4 < 1) && ((param_4 < 0 || (param_3 == 0)))) {
        piVar4 = (int *)FUN_00c05dc5();
        return piVar4;
      }
      *param_2 = (char)uVar6;
      param_2 = param_2 + 1;
      puVar1 = (uint *)(param_1 + 2);
      uVar6 = *puVar1;
      *puVar1 = *puVar1 + 1;
      param_1[3] = param_1[3] + (uint)(0xfffffffe < uVar6);
      uVar6 = FUN_0058c090();
    }
    puVar1 = (uint *)(param_1 + 2);
    uVar6 = *puVar1;
    *puVar1 = *puVar1 + 1;
    param_1[3] = param_1[3] + (uint)(0xfffffffe < uVar6);
    piVar4 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if (*(int *)piVar4[7] != 0) {
      iVar2 = *(int *)piVar4[0xb];
      if (0 < iVar2) {
        *(int *)piVar4[0xb] = iVar2 + -1;
        *(int *)piVar4[7] = *(int *)piVar4[7] + 1;
        piVar4 = (int *)FUN_00c05dc5();
        return piVar4;
      }
    }
    (**(code **)(*piVar4 + 0x1c))();
    piVar4 = (int *)FUN_00c05dc5();
    return piVar4;
  }
  *param_2 = 0;
  if (param_1[2] == 0 && param_1[3] == 0) {
    uVar6 = 2;
  }
  uVar6 = uVar6 | *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
  uVar5 = uVar6 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar5 = uVar6;
  }
  FUN_00554460(uVar5,0);
  uStack_8 = 4;
  piVar4 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27112 ; VA 0x00c05da6 ; Catch_All@00c05da6 */

undefined * Catch_All_00c05da6(void)

{
  FUN_005565b0(4,1);
  return &DAT_00c05dbf;
}



/* FUNCTION 27113 ; VA 0x00c05dc5 ; FUN_00c05dc5 */

void FUN_00c05dc5(void)

{
  int *piVar1;
  uint uVar2;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  uint uVar3;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  **(undefined **)(unaff_EBP + 8) = 0;
  if (unaff_ESI[2] == 0 && unaff_ESI[3] == 0) {
    unaff_EDI = unaff_EDI | 2;
  }
  uVar3 = unaff_EDI | *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc);
  uVar2 = uVar3 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar2 = uVar3;
  }
  FUN_00554460(uVar2,0);
  *(undefined4 *)(unaff_EBP + -4) = 4;
  piVar1 = *(int **)(*(int *)(**(int **)(unaff_EBP + -0x24) + 4) + 0x38 +
                    (int)*(int **)(unaff_EBP + -0x24));
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 27114 ; VA 0x00c05e30 ; FUN_00c05e30 */

void FUN_00c05e30(int *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)*param_1;
  (*(code *)*puVar1)(puVar1[4],*(undefined8 *)(puVar1 + 6));
  return;
}



/* FUNCTION 27115 ; VA 0x00c05e60 ; FUN_00c05e60 */

int FUN_00c05e60(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = (*(code *)*param_1)(param_1[4]);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27116 ; VA 0x00c05ed0 ; FUN_00c05ed0 */

int FUN_00c05ed0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                int *param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018052b0;
  pvStack_10 = ExceptionList;
  uVar3 = param_1[4];
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  pcVar4 = (code *)*param_1;
  uStack_8 = 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  iVar5 = (*pcVar4)(uVar3,param_2,param_3,param_4,param_5,param_6);
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 27117 ; VA 0x00c05fb0 ; FUN_00c05fb0 */

uint FUN_00c05fb0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c00240();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27118 ; VA 0x00c05fd0 ; FUN_00c05fd0 */

uint FUN_00c05fd0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c00340();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27119 ; VA 0x00c05ff0 ; FUN_00c05ff0 */

uint FUN_00c05ff0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c00240();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27120 ; VA 0x00c06010 ; FUN_00c06010 */

uint FUN_00c06010(void)

{
  int iVar1;
  
  iVar1 = FUN_00c00340();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27121 ; VA 0x00c06030 ; FUN_00c06030 */

void FUN_00c06030(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c08100();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27122 ; VA 0x00c06070 ; FUN_00c06070 */

void FUN_00c06070(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dfbbac);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::_mfi::mf1<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::TestService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::TestService*>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 27123 ; VA 0x00c060e0 ; FUN_00c060e0 */

int * FUN_00c060e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[3];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c061ce. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c06136. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dfbdcc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::TestService,int>,class_boost::_bi::list2<class_boost::_bi::value<class_std::shared_ptr<class_RBX::TestService>_>,class_boost::_bi::value<int>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 27124 ; VA 0x00c061f0 ; FUN_00c061f0 */

void FUN_00c061f0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      iVar2 = FUN_01674e20(0x20);
      if (iVar2 != 0) {
        iVar3 = FUN_00c01530(iVar3);
        *param_2 = iVar3;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        FUN_01674ea0(iVar3,0x20);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dfbaf4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::TestService,int,double>,class_boost::_bi::list3<class_boost::_bi::value<class_std::shared_ptr<class_RBX::TestService>_>,class_boost::_bi::value<int>,class_boost::_bi::value<double>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 27125 ; VA 0x00c062e0 ; FUN_00c062e0 */

int * FUN_00c062e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[3];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c063ce. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c06336. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dfbcbc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf5<void,class_RBX::TestService,int,char_const*,char_const*,class_std::shared_ptr<class_RBX::LuaSourceContainer>,int>,class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::TestService>_>,class_boost::_bi::value<int>,struct_boost::arg<1>,struct_boost::arg<2>,struct_boost::arg<3>,struct_boost::arg<4>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 27126 ; VA 0x00c063f0 ; FUN_00c063f0 */

/* WARNING: Removing unreachable block (ram,0x00c064d2) */
/* WARNING: Removing unreachable block (ram,0x00c064e0) */
/* WARNING: Removing unreachable block (ram,0x00c06615) */
/* WARNING: Removing unreachable block (ram,0x00c064f4) */

int __thiscall FUN_00c063f0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int *in_stack_0000001c;
  int *in_stack_00000020;
  int **in_stack_00000024;
  undefined4 in_stack_ffffff94;
  undefined4 in_stack_ffffff98;
  undefined4 in_stack_ffffff9c;
  undefined8 in_stack_ffffffa0;
  int *in_stack_ffffffa8;
  int *piStack_54;
  int *piStack_50;
  int *piStack_4c;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar1 = in_stack_00000020;
  piVar4 = in_stack_0000001c;
  puStack_c = &LAB_018052f0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (*(char *)(param_1 + 0xf0) != '\0') {
    ExceptionList = &pvStack_10;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      in_stack_00000020[1] = in_stack_00000020[1] + 1;
      UNLOCK();
    }
    piStack_20 = in_stack_0000001c;
    piStack_1c = in_stack_00000020;
    piStack_4c = (int *)&param_2;
    uStack_8 = 2;
    uStack_7 = 0;
    piStack_50 = (int *)0xc06451;
    FUN_0054ef60();
    param_1 = iStack_14;
    piStack_4c = &uStack_28;
    uStack_28 = 0;
    piStack_50 = (int *)in_stack_00000024;
    uStack_24 = 0;
    uStack_8 = 4;
    piStack_20 = (int *)0x0;
    piStack_1c = (int *)0x0;
    piStack_54 = piVar1;
    in_stack_ffffffa0 = CONCAT44(uStack_2c,uStack_30);
    FUN_00c055f0(iStack_14,uStack_40,uStack_3c,uStack_38,uStack_34,in_stack_ffffffa0,piVar4);
    in_stack_ffffff94 = uStack_3c;
    in_stack_ffffff98 = uStack_38;
    in_stack_ffffff9c = uStack_34;
    in_stack_ffffffa8 = piVar4;
  }
  uStack_8 = 1;
  if (*(int *)(param_1 + 0x100) == 0) {
    piStack_4c = (int *)&param_2;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      in_stack_00000020[1] = in_stack_00000020[1] + 1;
      UNLOCK();
    }
    piStack_54 = in_stack_00000020;
    piStack_50 = (int *)in_stack_00000024;
    iVar3 = FUN_00c06f60();
  }
  else {
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      in_stack_00000020[1] = in_stack_00000020[1] + 1;
      UNLOCK();
    }
    piStack_54 = in_stack_0000001c;
    piStack_50 = in_stack_00000020;
    uStack_8 = 5;
    piStack_4c = (int *)in_stack_00000024;
    in_stack_00000024 = &piStack_54;
    FUN_0054ef60(&param_2);
    uStack_8 = 1;
    iVar3 = FUN_00c02230(in_stack_ffffff94,in_stack_ffffff98,in_stack_ffffff9c,in_stack_ffffffa0,
                         in_stack_ffffffa8);
  }
  if (0xf < in_stack_00000018) {
    piStack_4c = (int *)(in_stack_00000018 + 1);
    piVar4 = param_2;
    if (0xfff < piStack_4c) {
      piVar4 = (int *)param_2[-1];
      piStack_4c = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
        piStack_4c = (int *)&UNK_00c0661f;
        FUN_017167a3();
      }
    }
    piStack_54 = (int *)0xc065c6;
    piStack_50 = piVar4;
    iVar3 = FUN_01674ea0();
  }
  piVar4 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (int *)((uint)param_2 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_4c = (int *)0xc065f4;
      iVar3 = (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_4c = (int *)0xc06603;
        iVar3 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27127 ; VA 0x00c06620 ; FUN_00c06620 */

int __thiscall FUN_00c06620(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 *in_stack_00000028;
  undefined4 uStack_28;
  int *piStack_24;
  undefined *puStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805238;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x9c) = *(int *)(param_1 + 0x9c) + 1;
  puStack_20 = &DAT_02133970;
  uStack_8 = 1;
  piStack_24 = (int *)0xc06654;
  iVar3 = FUN_008a4940();
  if ((char)param_2 == '\0') {
    *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 1;
    puStack_20 = &DAT_021339e0;
    piStack_24 = (int *)0xc0666c;
    iVar3 = FUN_008a4940();
  }
  if (*(int *)(param_1 + 0x140) != 0) {
    puStack_20 = (undefined *)in_stack_00000028;
    in_stack_00000028 = &uStack_28;
    if (in_stack_00000024 != (int *)0x0) {
      LOCK();
      in_stack_00000024[1] = in_stack_00000024[1] + 1;
      UNLOCK();
    }
    uStack_28 = in_stack_00000020;
    piStack_24 = in_stack_00000024;
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar3 = FUN_00c02370(param_2);
  }
  if (0xf < in_stack_0000001c) {
    puStack_20 = (undefined *)(in_stack_0000001c + 1);
    piVar4 = param_3;
    if (0xfff < puStack_20) {
      piVar4 = (int *)param_3[-1];
      puStack_20 = (undefined *)(in_stack_0000001c + 0x24);
      if (0x1f < (uint)((int)param_3 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
        puStack_20 = &UNK_00c06748;
        FUN_017167a3();
      }
    }
    uStack_28 = 0xc066f4;
    piStack_24 = piVar4;
    iVar3 = FUN_01674ea0();
  }
  piVar4 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = (int *)((uint)param_3 & 0xffffff00);
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000024 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_20 = (undefined *)0xc06722;
      iVar3 = (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_20 = (undefined *)0xc06731;
        iVar3 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27128 ; VA 0x00c06750 ; FUN_00c06750 */

void * __thiscall FUN_00c06750(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  void **ppvVar3;
  void *pvVar4;
  int *piVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  undefined4 *in_stack_00000024;
  undefined4 uStack_28;
  int *piStack_24;
  undefined *puStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805178;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pvVar4 = ExceptionList;
  ppvVar3 = &pvStack_10;
  if ((*(char *)(param_1 + 0xf0) == '\0') && (ppvVar3 = &pvStack_10, *(int *)(param_1 + 0x100) != 0)
     ) {
    puStack_20 = (undefined *)in_stack_00000024;
    in_stack_00000024 = &uStack_28;
    ExceptionList = &pvStack_10;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      in_stack_00000020[1] = in_stack_00000020[1] + 1;
      UNLOCK();
    }
    uStack_28 = in_stack_0000001c;
    piStack_24 = in_stack_00000020;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    FUN_0054ef60(&param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    pvVar4 = (void *)FUN_00c02230();
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  if (0xf < in_stack_00000018) {
    puStack_20 = (undefined *)(in_stack_00000018 + 1);
    piVar5 = param_2;
    if (0xfff < puStack_20) {
      piVar5 = (int *)param_2[-1];
      puStack_20 = (undefined *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)piVar5))) {
                    /* WARNING: Subroutine does not return */
        puStack_20 = &UNK_00c06856;
        FUN_017167a3();
      }
    }
    uStack_28 = 0xc06802;
    piStack_24 = piVar5;
    pvVar4 = (void *)FUN_01674ea0();
  }
  piVar5 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (int *)((uint)param_2 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_20 = (undefined *)0xc06830;
      pvVar4 = (void *)(**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_20 = (undefined *)0xc0683f;
        pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 27129 ; VA 0x00c06860 ; FUN_00c06860 */

void __thiscall FUN_00c06860(int param_1,int param_2)

{
  int *piVar1;
  
  if (param_2 == *(int *)(param_1 + 0x94)) {
    piVar1 = (int *)(param_1 + 0x98);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      FUN_00c04d30();
    }
  }
  return;
}



/* FUNCTION 27130 ; VA 0x00c06880 ; FUN_00c06880 */

int __thiscall
FUN_00c06880(int param_1,int param_2,char *param_3,undefined4 param_4,undefined4 param_5,
            int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  char *pcVar4;
  undefined uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01805310;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 == *(int *)(param_1 + 0x94)) {
    ExceptionList = &pvStack_10;
    if (param_6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_6[1] = param_6[1] + 1;
      UNLOCK();
    }
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    uVar5 = 0;
    pcVar4 = param_3;
    do {
      cVar3 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar3 != '\0');
    FUN_005542c0(param_3,(int)pcVar4 - (int)(param_3 + 1));
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    param_2 = FUN_00c05310(uVar5);
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27131 ; VA 0x00c06960 ; FUN_00c06960 */

undefined4 * __thiscall FUN_00c06960(int param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805328;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_008a4210(param_2,param_3);
  if (param_3 != 0) {
    puVar4 = (undefined4 *)FUN_00677340();
    puVar4 = (undefined4 *)FUN_006ebdf0(auStack_20,*puVar4);
    uVar6 = *puVar4;
    uVar1 = puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    *(undefined4 *)(param_1 + 0x54) = uVar6;
    piVar5 = *(int **)(param_1 + 0x58);
    *(undefined4 *)(param_1 + 0x58) = uVar1;
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar2 = piVar5 + 1;
      iVar7 = *piVar2;
      puVar4 = (undefined4 *)*piVar2;
      *piVar2 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar2 = piVar5 + 2;
        iVar7 = *piVar2;
        puVar4 = (undefined4 *)*piVar2;
        *piVar2 = iVar7 + -1;
        UNLOCK();
        if (iVar7 + -1 == 0) {
          puVar4 = (undefined4 *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar5 = piStack_1c + 1;
      iVar7 = *piVar5;
      puVar4 = (undefined4 *)*piVar5;
      *piVar5 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar5 = piStack_1c + 2;
        iVar7 = *piVar5;
        puVar4 = (undefined4 *)*piVar5;
        *piVar5 = iVar7 + -1;
        UNLOCK();
        if (iVar7 + -1 == 0) {
          puVar4 = (undefined4 *)(**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0x54) == 0) {
      piVar5 = (int *)FUN_00677340();
      iVar7 = *piVar5;
      if (*piVar5 == 0) {
        FUN_00674ea0(&iStack_18);
        uStack_8 = 0;
        FUN_008a5700(param_3);
        FUN_005789c0(&DAT_01eadd8c,&LAB_00670d70);
        uVar6 = FUN_00676430();
        piVar5 = (int *)FUN_008aa140(uVar6);
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        *piVar5 = iStack_18;
        piVar2 = (int *)piVar5[1];
        piVar5[1] = (int)piStack_14;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar7 = piVar2[1] + -1;
          piVar2[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar7 = piVar2[2] + -1;
            piVar2[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        uStack_8 = 0xffffffff;
        iVar7 = iStack_18;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_14[1] + -1;
          piStack_14[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            iVar3 = piStack_14[2] + -1;
            piStack_14[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piStack_14 + 4))();
            }
          }
        }
      }
      uVar6 = FUN_006ebdf0(auStack_28,iVar7);
      puVar4 = (undefined4 *)FUN_005587e0(uVar6);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piVar5 = piStack_24 + 1;
        iVar7 = *piVar5;
        puVar4 = (undefined4 *)*piVar5;
        *piVar5 = iVar7 + -1;
        UNLOCK();
        if (iVar7 + -1 == 0) {
          puVar4 = (undefined4 *)(**(code **)*piStack_24)();
          LOCK();
          piVar5 = piStack_24 + 2;
          iVar7 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            puVar4 = (undefined4 *)(**(code **)(*piStack_24 + 4))();
          }
        }
      }
      if (*(char *)(param_1 + 0x5c) != '\0') {
        iVar7 = *(int *)(param_1 + 0x54);
        piVar5 = (int *)(param_1 + 0x60);
        if ((int *)(iVar7 + 0xc4) != piVar5) {
          if (0xf < *(uint *)(param_1 + 0x74)) {
            piVar5 = (int *)*piVar5;
          }
          FUN_005542c0(piVar5,*(undefined4 *)(param_1 + 0x70));
          iVar7 = *(int *)(param_1 + 0x54);
        }
        *(undefined8 *)(iVar7 + 0xe0) = *(undefined8 *)(param_1 + 0x78);
        *(undefined *)(*(int *)(param_1 + 0x54) + 0xe8) = *(undefined *)(param_1 + 0x80);
        *(undefined *)(*(int *)(param_1 + 0x54) + 0xe9) = *(undefined *)(param_1 + 0x81);
        puVar4 = (undefined4 *)(uint)*(byte *)(param_1 + 0x82);
        *(byte *)(*(int *)(param_1 + 0x54) + 0xea) = *(byte *)(param_1 + 0x82);
        *(undefined *)(param_1 + 0x5c) = 1;
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 27132 ; VA 0x00c06ba0 ; FUN_00c06ba0 */

void __thiscall FUN_00c06ba0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = (int)param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805392;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a4210(param_2,param_3);
  if (iVar2 == 0) {
    if (param_2 != (undefined4 *)0x0) {
      FUN_01679490();
      FUN_01679490();
    }
  }
  else {
    FUN_006eccd0();
    uStack_8 = 0;
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8 = 1;
    param_3 = (undefined4 *)uVar4;
    puVar5 = (undefined4 *)FUN_01674e20(0x28);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = 0;
      puVar5[1] = 1;
      puVar5[2] = FUN_00c04b80;
      puVar5[3] = _guard_check_icall;
      puVar5[4] = 0;
      puVar5[5] = param_1 + 0x1c0;
      puVar5[6] = FUN_00c06750;
      puVar5[7] = 0;
      puVar5[8] = param_1;
      puVar5[9] = uStack_24;
    }
    FUN_016797d0(puVar5);
    if (puVar5 != (undefined4 *)0x0) {
      LOCK();
      puVar5[1] = puVar5[1] + 1;
      UNLOCK();
    }
    uStack_8 = 2;
    param_2 = puVar5;
    FUN_01675290(uVar4);
    uStack_8 = 3;
    cVar3 = FUN_01679300(&param_2);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_2);
    }
    uStack_8 = 0xffffffff;
    if (param_2 != (undefined4 *)0x0) {
      piVar1 = param_2 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(param_2);
      }
    }
    param_2 = (undefined4 *)(param_1 + 0x1c8);
    FUN_006eccd0();
    uStack_8 = 4;
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8 = 5;
    puVar5 = (undefined4 *)FUN_01674e20(0x28);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = 0;
      puVar5[1] = 1;
      puVar5[2] = FUN_00c04c50;
      puVar5[3] = _guard_check_icall;
      puVar5[4] = 0;
      puVar5[5] = param_2;
      puVar5[6] = FUN_00c06620;
      puVar5[7] = 0;
      puVar5[8] = param_1;
      puVar5[9] = uStack_24;
    }
    FUN_016797d0(puVar5);
    if (puVar5 != (undefined4 *)0x0) {
      LOCK();
      puVar5[1] = puVar5[1] + 1;
      UNLOCK();
    }
    uStack_8 = 6;
    param_3 = puVar5;
    FUN_01675290(uVar4);
    uStack_8 = 7;
    cVar3 = FUN_01679300(&param_3);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_3);
    }
    if (param_3 != (undefined4 *)0x0) {
      piVar1 = param_3 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(param_3);
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27133 ; VA 0x00c06e50 ; FUN_00c06e50 */

void __thiscall FUN_00c06e50(int param_1,int param_2,undefined8 param_3)

{
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  char *pcStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018053a8;
  pvStack_10 = ExceptionList;
  if ((param_2 == *(int *)(param_1 + 0x94)) && (*(char *)(param_1 + 0x90) != '\0')) {
    ExceptionList = &pvStack_10;
    *(int *)(param_1 + 0x9c) = *(int *)(param_1 + 0x9c) + 1;
    *(undefined *)(param_1 + 0x90) = 0;
    uStack_24 = 0x213397000c06ea0;
    FUN_008a4940();
    *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 1;
    uStack_24 = 0x21339e000c06eb2;
    FUN_008a4940();
    if (*(int *)(param_1 + 0x140) == 0) {
      uStack_24 = param_3;
      pcStack_28 = "TestService: Tests failed to complete in %g seconds";
      uStack_2c = 3;
      uStack_30 = 0xc06f28;
      FUN_0086f2f0();
    }
    else {
      pcStack_28 = (char *)0x0;
      uStack_24 = 0;
      uStack_8 = 0;
      FUN_01675640(auStack_40,"Tests failed to complete in %g seconds",param_3);
      uStack_8 = 0xffffffff;
      FUN_00c02370();
    }
    if (*(int *)(param_1 + 0x1a0) != 0) {
      uStack_24 = CONCAT44(0xc06f3f,(undefined4)uStack_24);
      FUN_005515c0();
    }
    uStack_24 = CONCAT44(0xc06f46,(undefined4)uStack_24);
    FUN_00c08b60();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27134 ; VA 0x00c06f60 ; FUN_00c06f60 */

int FUN_00c06f60(undefined4 param_1,int param_2,int *param_3,undefined4 param_4,undefined4 *param_5)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_2 == 0) {
    if (0xf < (uint)param_5[5]) {
      param_5 = (undefined4 *)*param_5;
    }
    ExceptionList = &pvStack_10;
    iVar2 = FUN_0086f2f0(param_1,"TestService: %s",param_5);
  }
  else {
    if (0xf < (uint)param_5[5]) {
      param_5 = (undefined4 *)*param_5;
    }
    piVar3 = *(int **)(param_2 + 0x28);
    if (0xf < (uint)piVar3[5]) {
      piVar3 = (int *)*piVar3;
    }
    ExceptionList = &pvStack_10;
    iVar2 = FUN_0086f2f0(param_1,"TestService.%s(%d): %s",piVar3,param_4,param_5);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar1 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar2 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 27135 ; VA 0x00c07010 ; FUN_00c07010 */

void __thiscall FUN_00c07010(int param_1,int param_2)

{
  int iVar1;
  uint in_stack_00000018;
  undefined4 uStack_38;
  undefined *puStack_34;
  char *pcStack_30;
  undefined auStack_24 [16];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01805150;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if (*(int *)(param_1 + 0x54) == 0) {
    pcStack_30 = "Can\'t find TestService";
    puStack_34 = (undefined *)0xc070ce;
    ExceptionList = &pvStack_10;
    FUN_00550130();
    pcStack_30 = "";
    puStack_34 = auStack_24;
                    /* WARNING: Subroutine does not return */
    uStack_38 = 0xc070dc;
    FUN_0170c2a8();
  }
  pcStack_30 = (char *)0x0;
  puStack_14 = (undefined *)&uStack_38;
  uStack_38 = 0;
  puStack_34 = (undefined *)0x0;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00c02a50(1);
  pcStack_30 = (char *)0xc0707f;
  FUN_00c04d30();
  if (0xf < in_stack_00000018) {
    pcStack_30 = (char *)(in_stack_00000018 + 1);
    iVar1 = param_2;
    if (0xfff < pcStack_30) {
      iVar1 = *(int *)(param_2 + -4);
      pcStack_30 = (char *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        pcStack_30 = &UNK_00c070e1;
        FUN_017167a3();
      }
    }
    uStack_38 = 0xc070ac;
    puStack_34 = (undefined *)iVar1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27136 ; VA 0x00c070f0 ; FUN_00c070f0 */

void __thiscall FUN_00c070f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  
  cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_CHECK_EQUAL","Check",&DAT_018c393c,&DAT_0196154c);
  if (cVar1 == '\0') {
    cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_CHECK_NE","Check",&DAT_01961568,&DAT_018c393c);
    if (cVar1 == '\0') {
      cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_CHECK_GE","Check",&DAT_0196157c,&DAT_018c3500);
      if (cVar1 == '\0') {
        cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_CHECK_LE","Check",&DAT_01961590,&DAT_018c34a0);
        if (cVar1 == '\0') {
          cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_CHECK_GT","Check",&DAT_018c34a0,&DAT_01961590);
          if (cVar1 == '\0') {
            cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_CHECK_LT","Check",&DAT_018c3500,&DAT_0196157c)
            ;
            if (cVar1 == '\0') {
              cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_WARN_EQUAL",&DAT_019615c4,&DAT_018c393c,
                                   &DAT_0196154c);
              if (cVar1 == '\0') {
                cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_WARN_NE",&DAT_019615c4,&DAT_0196154c,
                                     &DAT_018c393c);
                if (cVar1 == '\0') {
                  cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_WARN_GE",&DAT_019615c4,&DAT_0196157c,
                                       &DAT_018c3500);
                  if (cVar1 == '\0') {
                    cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_WARN_LE",&DAT_019615c4,&DAT_01961590,
                                         &DAT_018c34a0);
                    if (cVar1 == '\0') {
                      cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_WARN_GT",&DAT_019615c4,&DAT_018c34a0
                                           ,&DAT_01961590);
                      if (cVar1 == '\0') {
                        cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_WARN_LT",&DAT_019615c4,
                                             &DAT_018c3500,&DAT_0196157c);
                        if (cVar1 == '\0') {
                          cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_REQUIRE_EQUAL","Require",
                                               &DAT_018c393c,&DAT_0196154c);
                          if (cVar1 == '\0') {
                            cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_REQUIRE_NE","Require",
                                                 &DAT_0196154c,&DAT_018c393c);
                            if (cVar1 == '\0') {
                              cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_REQUIRE_GE","Require",
                                                   &DAT_0196157c,&DAT_018c3500);
                              if (cVar1 == '\0') {
                                cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_REQUIRE_LE","Require",
                                                     &DAT_01961590,&DAT_018c34a0);
                                if (cVar1 == '\0') {
                                  cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_REQUIRE_GT","Require",
                                                       &DAT_018c34a0,&DAT_01961590);
                                  if (cVar1 == '\0') {
                                    cVar1 = FUN_00c03ec0(param_2,param_3,"RBX_REQUIRE_LT","Require",
                                                         &DAT_018c3500,&DAT_0196157c);
                                    if (cVar1 == '\0') {
                                      cVar1 = FUN_00c03ab0(param_2,param_3,"RBX_WARN_MESSAGE",
                                                           &DAT_019615c4);
                                      if (cVar1 == '\0') {
                                        cVar1 = FUN_00c03ab0(param_2,param_3,"RBX_CHECK_MESSAGE",
                                                             "Check");
                                        if (cVar1 == '\0') {
                                          cVar1 = FUN_00c03ab0(param_2,param_3,"RBX_REQUIRE_MESSAGE"
                                                               ,"Require");
                                          if (cVar1 == '\0') {
                                            cVar1 = FUN_00c04550(param_2,param_3,"RBX_WARN_THROW",
                                                                 &DAT_019615c4);
                                            if (cVar1 == '\0') {
                                              cVar1 = FUN_00c04550(param_2,param_3,"RBX_CHECK_THROW"
                                                                   ,"Check");
                                              if (cVar1 == '\0') {
                                                cVar1 = FUN_00c04550(param_2,param_3,
                                                                     "RBX_REQUIRE_THROW","Require");
                                                if (cVar1 == '\0') {
                                                  cVar1 = FUN_00c04330(param_2,param_3,
                                                                       "RBX_WARN_NO_THROW",
                                                                       &DAT_019615c4);
                                                  if (cVar1 == '\0') {
                                                    cVar1 = FUN_00c04330(param_2,param_3,
                                                                         "RBX_CHECK_NO_THROW",
                                                                         "Check");
                                                    if (cVar1 == '\0') {
                                                      cVar1 = FUN_00c04330(param_2,param_3,
                                                                           "RBX_REQUIRE_NO_THROW",
                                                                           "Require");
                                                      if (cVar1 == '\0') {
                                                        cVar1 = FUN_00c03ca0(param_2,param_3,
                                                                             "RBX_WARN",
                                                                             &DAT_019615c4);
                                                        if (cVar1 == '\0') {
                                                          cVar1 = FUN_00c03ca0(param_2,param_3,
                                                                               "RBX_CHECK","Check");
                                                          if (cVar1 == '\0') {
                                                            cVar1 = FUN_00c03ca0(param_2,param_3,
                                                                                 "RBX_REQUIRE",
                                                                                 "Require");
                                                            if (cVar1 == '\0') {
                                                              cVar1 = FUN_00c03ab0(param_2,param_3,
                                                                                   "RBX_ERROR",
                                                                                   "Error");
                                                              if (cVar1 == '\0') {
                                                                cVar1 = FUN_00c03ab0(param_2,param_3
                                                                                     ,"RBX_FAIL",
                                                                                     &DAT_019569dc);
                                                                if (cVar1 == '\0') {
                                                                  cVar1 = FUN_00c03ab0(param_2,
                                                  param_3,"RBX_MESSAGE","Message");
                                                  if (cVar1 == '\0') {
                                                    cVar1 = FUN_00c03ab0(param_2,param_3,
                                                                         "RBX_CHECKPOINT",
                                                                         "Checkpoint");
                                                    if (cVar1 == '\0') {
                                                      FUN_00558840(param_1 + 0xc0,param_3);
                                                    }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}



/* FUNCTION 27137 ; VA 0x00c07550 ; FUN_00c07550 */

/* WARNING: Removing unreachable block (ram,0x00c076bc) */
/* WARNING: Removing unreachable block (ram,0x00c07722) */
/* WARNING: Removing unreachable block (ram,0x00c076ae) */
/* WARNING: Removing unreachable block (ram,0x00c076cc) */
/* WARNING: Removing unreachable block (ram,0x00c076ef) */
/* WARNING: Removing unreachable block (ram,0x00c076fb) */
/* WARNING: Removing unreachable block (ram,0x00c07709) */

undefined4
FUN_00c07550(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined8 uStack_278;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805407;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  uStack_288 = param_2;
  uStack_284 = param_3;
  uStack_280 = param_4;
  uStack_27c = param_5;
  uStack_278 = CONCAT44(param_7,param_6);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 2;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1b8 = param_8;
  uStack_1bc = 0;
  uStack_1b4 = param_9;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = param_10;
  uStack_ec = FUN_005c9cc0();
  uStack_8._0_1_ = 4;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_290,&uStack_20,param_1);
  uStack_8._0_1_ = 5;
  (*pcVar1)(uStack_14,&uStack_20,param_11);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar2 = FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 27138 ; VA 0x00c07730 ; FUN_00c07730 */

/* WARNING: Removing unreachable block (ram,0x00c078c9) */
/* WARNING: Removing unreachable block (ram,0x00c0792f) */
/* WARNING: Removing unreachable block (ram,0x00c078bb) */
/* WARNING: Removing unreachable block (ram,0x00c078d9) */
/* WARNING: Removing unreachable block (ram,0x00c078fc) */
/* WARNING: Removing unreachable block (ram,0x00c07908) */
/* WARNING: Removing unreachable block (ram,0x00c07916) */

undefined4
FUN_00c07730(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined uStack_358;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined8 uStack_278;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805472;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_360 = FUN_0088daf0();
  uStack_35c = 0;
  uStack_358 = (undefined)param_2;
  uStack_35c = FUN_005c9ef0();
  uStack_8._0_1_ = 2;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  uStack_288 = param_3;
  uStack_284 = param_4;
  uStack_280 = param_5;
  uStack_27c = param_6;
  uStack_278 = CONCAT44(param_8,param_7);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1b8 = param_9;
  uStack_1bc = 0;
  uStack_1b4 = param_10;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = param_11;
  uStack_ec = FUN_005c9cc0();
  uStack_8._0_1_ = 5;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_360,&uStack_20,param_2);
  uStack_8._0_1_ = 6;
  (*pcVar1)(uStack_14,&uStack_20,param_12);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar2 = FUN_016f32d1(&uStack_360,0xd0,4,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 27139 ; VA 0x00c07940 ; FUN_00c07940 */

int __thiscall FUN_00c07940(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  char cVar5;
  int in_stack_00000018;
  uint in_stack_0000001c;
  int *in_stack_00000020;
  int *in_stack_00000024;
  int **in_stack_00000028;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  char acStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018054b1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x9c) = *(int *)(param_1 + 0x9c) + 1;
  piStack_3c = (int *)&DAT_02133970;
  uStack_8 = 1;
  piStack_40 = (int *)0xc0797e;
  iVar3 = FUN_008a4940();
  cVar5 = (char)param_2;
  if (cVar5 == '\0') {
    *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 1;
    piStack_3c = (int *)&DAT_021339e0;
    piStack_40 = (int *)0xc07997;
    iVar3 = FUN_008a4940();
  }
  if (*(int *)(param_1 + 0x140) == 0) {
    if (cVar5 != '\0') goto LAB_00c07aa2;
    piStack_3c = (int *)(in_stack_00000018 + 6);
    uStack_8._0_1_ = 3;
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_14 = 1;
    piStack_40 = (int *)0xc07a30;
    acStack_2c[0] = cVar5;
    FUN_0058a190();
    piStack_3c = (int *)0x6;
    piStack_40 = (int *)0x1961368;
    piStack_44 = (int *)0xc07a3f;
    FUN_00554150();
    piStack_3c = (int *)in_stack_00000018;
    piStack_40 = (int *)&param_3;
    if (0xf < in_stack_0000001c) {
      piStack_40 = param_3;
    }
    piStack_44 = (int *)0xc07a56;
    FUN_00554150();
    piStack_3c = (int *)acStack_2c;
    piStack_40 = (int *)in_stack_00000028;
    if (in_stack_00000024 != (int *)0x0) {
      LOCK();
      in_stack_00000024[1] = in_stack_00000024[1] + 1;
      UNLOCK();
    }
    piStack_44 = in_stack_00000024;
    FUN_00c06f60(3,in_stack_00000020);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piStack_3c = (int *)0xc07a9b;
    FUN_005507b0();
  }
  else {
    piStack_3c = (int *)in_stack_00000028;
    in_stack_00000028 = &piStack_44;
    if (in_stack_00000024 != (int *)0x0) {
      LOCK();
      in_stack_00000024[1] = in_stack_00000024[1] + 1;
      UNLOCK();
    }
    piStack_44 = in_stack_00000020;
    piStack_40 = in_stack_00000024;
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar3 = FUN_00c02370(param_2);
    if (cVar5 != '\0') goto LAB_00c07aa2;
  }
  piStack_3c = (int *)0xc07aa2;
  iVar3 = FUN_00c04d30();
LAB_00c07aa2:
  if (0xf < in_stack_0000001c) {
    piStack_3c = (int *)(in_stack_0000001c + 1);
    piVar4 = param_3;
    if (0xfff < piStack_3c) {
      piVar4 = (int *)param_3[-1];
      piStack_3c = (int *)(in_stack_0000001c + 0x24);
      if (0x1f < (uint)((int)param_3 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
        piStack_3c = (int *)&UNK_00c07b24;
        FUN_017167a3();
      }
    }
    piStack_44 = (int *)0xc07acf;
    piStack_40 = piVar4;
    iVar3 = FUN_01674ea0();
  }
  piVar4 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = (int *)((uint)param_3 & 0xffffff00);
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000024 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_3c = (int *)0xc07afd;
      iVar3 = (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_3c = (int *)0xc07b0c;
        iVar3 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27140 ; VA 0x00c07b30 ; FUN_00c07b30 */

void __thiscall
FUN_00c07b30(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined8 param_8,uint param_9)

{
  uint auStack_50 [2];
  undefined auStack_48 [24];
  uint auStack_30 [2];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018054e0;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0x90) == '\0') {
    auStack_30[0] = 0;
    ExceptionList = &pvStack_10;
    if (param_2 != 0) {
      auStack_30[0] = param_2;
      if ((param_2 & 1) == 0) {
        ExceptionList = &pvStack_10;
        (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_28,0);
      }
      else {
        uStack_28 = param_4;
        uStack_24 = param_5;
        uStack_20 = param_6;
        uStack_1c = param_7;
        uStack_18 = param_8;
        ExceptionList = &pvStack_10;
      }
    }
    if ((uint *)(param_1 + 0x70) != auStack_30) {
      auStack_50[0] = 0;
      uStack_8._0_1_ = 3;
      FUN_005880d0(auStack_30);
      FUN_005880d0((uint *)(param_1 + 0x70));
      FUN_005880d0(auStack_50);
      uStack_8._0_1_ = 4;
      if (auStack_50[0] != 0) {
        if (((auStack_50[0] & 1) == 0) && (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
        }
        auStack_50[0] = 0;
      }
    }
    uStack_8._0_1_ = 5;
    if (auStack_30[0] != 0) {
      if (((auStack_30[0] & 1) == 0) && (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_30[0] & 0xfffffffe))(&uStack_28,&uStack_28,2);
      }
      auStack_30[0] = 0;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_00c07ca0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  uStack_8 = 7;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27141 ; VA 0x00c07ca0 ; FUN_00c07ca0 */

void __fastcall FUN_00c07ca0(int param_1)

{
  int iVar1;
  undefined uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_b8 [8];
  undefined4 uStack_b0;
  undefined8 uStack_ac;
  undefined auStack_a4 [28];
  undefined4 uStack_88;
  char *pcStack_84;
  undefined4 uStack_80;
  undefined uStack_7c;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  code *pcStack_64;
  undefined8 uStack_60;
  undefined auStack_4c [12];
  undefined auStack_40 [12];
  undefined auStack_34 [12];
  undefined auStack_28 [4];
  int *piStack_24;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805500;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa8;
  iStack_1c = param_1;
  if (*(char *)(param_1 + 0x90) != '\0') {
    uStack_60 = 5.151604931454663e-301;
    ExceptionList = &pvStack_10;
    FUN_00550130();
    uStack_60 = (double)CONCAT44(&DAT_01c17198,auStack_34);
                    /* WARNING: Subroutine does not return */
    pcStack_64 = (code *)0xc0803e;
    FUN_0170c2a8();
  }
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x94) = *(int *)(param_1 + 0x94) + 1;
  *(undefined *)(param_1 + 0x90) = 1;
  *(undefined4 *)(param_1 + 0x9c) = 0;
  *(undefined4 *)(param_1 + 0xa0) = 0;
  *(undefined4 *)(param_1 + 0xa4) = 0;
  uStack_60 = 1.1482496450487395e-298;
  puStack_14 = &stack0xffffffa8;
  FUN_008a4940();
  uStack_60 = 1.148300682902879e-298;
  FUN_008a4940();
  uStack_60 = 1.1483517207570184e-298;
  FUN_008a4940();
  uStack_60 = (double)CONCAT44(0xc07d25,(undefined4)uStack_60);
  FUN_00c081b0();
  uStack_60 = (double)CONCAT44(0xc07d2e,(undefined4)uStack_60);
  uVar3 = FUN_00e39f60();
  *(undefined4 *)(param_1 + 0xac) = uVar3;
  uStack_60 = (double)CONCAT44(0xc07d3b,(undefined4)uStack_60);
  uVar2 = FUN_00e39f20();
  *(undefined *)(param_1 + 0xb0) = uVar2;
  uStack_60 = (double)CONCAT44(0xc07d48,(undefined4)uStack_60);
  uVar2 = FUN_00e3a0a0();
  *(undefined *)(param_1 + 0xb1) = uVar2;
  if ((*(char *)(param_1 + 0xea) == '\0') || (*(char *)(param_1 + 0xe8) == '\0')) {
    piStack_18 = (int *)&pcStack_64;
    pcStack_64 = (code *)0x0;
    uStack_60 = 0.0;
    uStack_8 = 0;
    uStack_80 = 0x18;
    uStack_6c = 0;
    uStack_68 = 0xf;
    pcStack_84 = "Running performance test";
    uStack_7c = 0;
    uStack_88 = 0xc07da0;
    FUN_005542c0();
    uStack_8 = 0xffffffff;
    uStack_80 = 0xc07dae;
    FUN_00c063f0();
    if (*(char *)(param_1 + 0xe8) == '\0') {
      uVar3 = 1;
      goto LAB_00c07dbd;
    }
  }
  uVar3 = 0;
LAB_00c07dbd:
  uStack_60 = (double)CONCAT44(uVar3,0xc07dc4);
  FUN_00e3a420();
  uStack_60._4_4_ = (uint)*(byte *)(param_1 + 0xe9);
  uStack_60 = (double)CONCAT44(uStack_60._4_4_,0xc07dd3);
  FUN_00e3a210();
  uStack_60._4_4_ = (uint)*(byte *)(param_1 + 0xea);
  uStack_60 = (double)CONCAT44(uStack_60._4_4_,0xc07de2);
  FUN_00e3a900();
  piStack_18 = *(int **)(param_1 + 0x34);
  piVar4 = (int *)param_1;
  if ((piStack_18 != (int *)0x0) && (piVar4 = piStack_18, *(int *)((int)piStack_18 + 0x34) != 0)) {
    uStack_60 = (double)CONCAT44(0xc07df8,(undefined4)uStack_60);
    piVar4 = (int *)FUN_005c8ac0();
  }
  piStack_18 = piVar4;
  if (piStack_18 != (int *)0x0) {
    iVar1 = *(int *)((int)piStack_18 + 0xc);
    uStack_60 = (double)CONCAT44(0xc07e12,(undefined4)uStack_60);
    iVar5 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      uStack_60 = 6.4403285500520894e-307;
      pcStack_64 = (code *)0xc07e40;
      FUN_005789c0();
      uStack_60 = (double)CONCAT44(0xc07e48,(undefined4)uStack_60);
      uVar3 = FUN_005cf500();
      uStack_60 = (double)CONCAT44(uVar3,0xc07e53);
      piStack_18 = (int *)FUN_008aa140();
      if (*piStack_18 == 0) {
        uStack_60 = (double)CONCAT44(0xc07e64,(undefined4)uStack_60);
        uVar3 = FUN_009eebd0();
        uStack_60 = (double)CONCAT44(uVar3,auStack_28);
        pcStack_64 = (code *)0xc07e70;
        piVar4 = (int *)FUN_008a9ba0();
        iVar1 = *piVar4;
        iVar5 = piVar4[1];
        *piVar4 = 0;
        piVar4[1] = 0;
        *piStack_18 = iVar1;
        piVar4 = (int *)piStack_18[1];
        piStack_18[1] = iVar5;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar1 = piVar4[1] + -1;
          piVar4[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            uStack_60 = (double)CONCAT44(0xc07ea3,(undefined4)uStack_60);
            (**(code **)*piVar4)();
            LOCK();
            iVar1 = piVar4[2] + -1;
            piVar4[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              uStack_60 = (double)CONCAT44(0xc07eb6,(undefined4)uStack_60);
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_24[1] + -1;
          piStack_24[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            uStack_60 = (double)CONCAT44(0xc07ed2,(undefined4)uStack_60);
            (**(code **)*piStack_24)();
            LOCK();
            piVar4 = piStack_24 + 2;
            iVar1 = *piVar4;
            *piVar4 = *piVar4 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              uStack_60 = (double)CONCAT44(0xc07ee4,(undefined4)uStack_60);
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
      }
      piStack_18 = (int *)*piStack_18;
      if (piStack_18 != (int *)0x0) {
        uStack_ac = *(double *)(param_1 + 0xe0);
        if (DAT_018d8a10 < uStack_ac) {
          uStack_60 = (double)DAT_0193fb48;
          pcStack_84 = (char *)0x0;
          uStack_b0 = *(undefined4 *)(iStack_1c + 0x94);
          FUN_006ebdf0(auStack_b8,iStack_1c);
          FUN_00c00810(auStack_a4,FUN_00c08ad0,0);
          uStack_ac = (double)CONCAT44(0xc07f57,(undefined4)uStack_ac);
          FUN_00bff970();
          pcStack_84 = (char *)0xc07f5f;
          FUN_009eef30();
          uStack_ac = *(double *)(iStack_1c + 0xe0);
        }
        pcStack_84 = (char *)0x0;
        uStack_b0 = *(undefined4 *)(iStack_1c + 0x94);
        uStack_60 = uStack_ac;
        FUN_006ebdf0(auStack_b8,iStack_1c);
        FUN_00c00810(auStack_a4,FUN_00c06e50,0);
        uStack_ac = (double)CONCAT44(0xc07fb0,(undefined4)uStack_ac);
        FUN_00bff970();
        pcStack_84 = (char *)0xc07fb8;
        FUN_009eef30();
        iVar1 = iStack_1c;
        uStack_60 = (double)CONCAT44(iStack_1c,0xc07fc1);
        iVar5 = FUN_00606cd0();
        if (iVar5 == 0) {
          uStack_60 = 5.1517900575997134e-301;
          FUN_00550130();
          uStack_60 = (double)CONCAT44(&DAT_01c17198,auStack_40);
                    /* WARNING: Subroutine does not return */
          pcStack_64 = Catch_All_00c08059;
          FUN_0170c2a8();
        }
        *(undefined4 *)(iVar1 + 0xa8) = *(undefined4 *)(iVar5 + 0x68);
        if ((*(int *)(iVar5 + 0x68) != 2) && (*(char *)(iVar1 + 0xc0) != '\0')) {
          uStack_60 = 2.12822875368869e-314;
          FUN_00999b50();
        }
        uStack_8 = 1;
        uStack_60 = (double)CONCAT44(0xc07ff7,(undefined4)uStack_60);
        FUN_00c088f0();
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  uStack_60 = 5.1516903742908076e-301;
  FUN_00550130();
  uStack_60 = (double)CONCAT44(&DAT_01c17198,auStack_4c);
                    /* WARNING: Subroutine does not return */
  pcStack_64 = (code *)0xc08023;
  FUN_0170c2a8();
}



/* FUNCTION 27142 ; VA 0x00c08059 ; Catch_All@00c08059 */

void Catch_All_00c08059(void)

{
  int unaff_EBP;
  undefined *puStack_c;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  uStack_4 = 0;
  *(undefined ***)(unaff_EBP + -0x1c) = &puStack_c;
  FUN_005502b0();
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_0054eff0("Failed to start test scripts");
  *(undefined *)(unaff_EBP + -4) = 2;
  FUN_00c05310();
  uStack_4 = 0;
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  puStack_c = &UNK_00c08090;
  FUN_0170c2a8();
}



/* FUNCTION 27143 ; VA 0x00c080a0 ; FUN_00c080a0 */

void __thiscall FUN_00c080a0(int param_1,int param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)(*(int *)(param_1 + 8) + param_2);
  cVar1 = FUN_00558b30(puVar2,param_3);
  if (cVar1 == '\0') {
    if (puVar2 != param_3) {
      puVar2 = param_3 + 4;
      if (0xf < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      FUN_005542c0(param_3,*puVar2);
    }
    if (*(code **)(param_1 + 0x10) != (code *)0x0) {
      (**(code **)(param_1 + 0x10))(*(undefined4 *)(param_1 + 4));
    }
    FUN_008a4940(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 27144 ; VA 0x00c08100 ; FUN_00c08100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c08100(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805526;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8624) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8624);
    if (DAT_01ef8624 == -1) {
      uStack_8 = 0;
      FUN_009ca470("FunctionalTestResult");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef85c0 = RBX::Reflection::EnumDesc<enum_RBX::FunctionalTest::Result>::vftable;
      FUN_009caf20(&DAT_01d68118,3);
      FUN_016f3654(&LAB_01892ef0);
      FUN_016f37bf(&DAT_01ef8624);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef85c0;
}



/* FUNCTION 27145 ; VA 0x00c081b0 ; FUN_00c081b0 */

int FUN_00c081b0(void)

{
  uint uVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805540;
  pvStack_10 = ExceptionList;
  iVar4 = DAT_01ef8178;
  if (DAT_01ef8178 == 0) {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_00910d90();
    cStack_14 = '\0';
    iVar4 = *piVar2;
    puStack_18 = (uint *)(iVar4 + 0x94);
    FUN_00587410();
    uStack_8 = 0;
    if (DAT_01ef8178 == 0) {
      FUN_00c00d00(auStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_008a65e0(iVar4,0);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar2 = piStack_1c + 2;
          iVar4 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    iVar4 = DAT_01ef8178;
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar3 = FUN_00554e40();
          SetEvent(uVar3);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 27146 ; VA 0x00c082a0 ; FUN_00c082a0 */

void __thiscall FUN_00c082a0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined *puVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  uint *puVar7;
  undefined4 *puVar8;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined8 uStack_178;
  uint auStack_170 [2];
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined8 uStack_158;
  uint uStack_150;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined8 uStack_138;
  uint uStack_130;
  undefined4 uStack_12c;
  code *pcStack_128;
  code *pcStack_124;
  int *piStack_120;
  code **ppcStack_11c;
  undefined8 uStack_118;
  undefined auStack_104 [16];
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  uint auStack_dc [2];
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined8 uStack_c4;
  uint auStack_bc [2];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined8 uStack_a4;
  uint auStack_9c [2];
  code *pcStack_94;
  code *pcStack_90;
  int *piStack_8c;
  code **ppcStack_88;
  undefined8 uStack_84;
  uint auStack_7c [2];
  code *apcStack_74 [6];
  int iStack_5c;
  uint auStack_58 [2];
  code *pcStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  uint *puStack_38;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  int *piStack_28;
  code **ppcStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018055b6;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffef0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_5c = param_1;
  puVar3 = &stack0xfffffef0;
  if (param_1 != 0) {
    iVar6 = *(int *)(param_1 + 0x34);
    iVar5 = param_1;
    ExceptionList = &pvStack_10;
    puVar3 = &stack0xfffffef0;
    if ((iVar6 != 0) &&
       (iVar5 = iVar6, ExceptionList = &pvStack_10, puVar3 = &stack0xfffffef0,
       *(int *)(iVar6 + 0x34) != 0)) {
      uStack_118 = CONCAT44(0xc082eb,(undefined4)uStack_118);
      ExceptionList = &pvStack_10;
      iVar5 = FUN_005c8ac0();
      puVar3 = puStack_14;
    }
    puStack_14 = puVar3;
    puVar3 = puStack_14;
    if (iVar5 != 0) {
      iStack_1c = *(int *)(iVar5 + 0xc);
      uStack_118 = CONCAT44(0xc08304,(undefined4)uStack_118);
      iVar6 = FUN_008a8c30();
      puVar3 = puStack_14;
      if ((uint)*(ushort *)(iStack_1c + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        uStack_118 = CONCAT44(0xc0832d,(undefined4)uStack_118);
        iStack_1c = FUN_0055ea10();
        puVar3 = puStack_14;
        if (iStack_1c != 0) {
          uStack_118 = 0;
          ppcStack_11c = (code **)0x0;
          piStack_120 = (int *)0x2;
          pcStack_124 = (code *)0xc0834b;
          FUN_01255470();
          auStack_dc[0] = 0;
          auStack_bc[0] = 0;
          auStack_9c[0] = 0;
          uStack_118 = CONCAT44(*(undefined4 *)(param_1 + 0x94),(undefined4)uStack_118);
          uStack_8._0_1_ = 1;
          pcStack_124 = (code *)&ppcStack_11c;
          pcStack_128 = (code *)0xc08382;
          piStack_120 = (int *)param_1;
          FUN_006ebdf0();
          piStack_120 = (int *)0x0;
          pcStack_124 = FUN_00c06860;
          uStack_12c = 0xc08392;
          pcStack_128 = (code *)&uStack_34;
          FUN_00c00a60();
          uStack_118 = uStack_118 & 0xffffffff;
          uStack_12c = uStack_34;
          pcStack_128 = pcStack_30;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            piStack_28[1] = piStack_28[1] + 1;
            UNLOCK();
          }
          pcStack_124 = pcStack_2c;
          piStack_120 = piStack_28;
          ppcStack_11c = ppcStack_24;
          uStack_130 = 0xc083da;
          puVar7 = (uint *)FUN_00bff870();
          if (auStack_dc != puVar7) {
            auStack_58[0] = 0;
            uStack_8._0_1_ = 4;
            uStack_118 = CONCAT44(puVar7,0xc083fa);
            FUN_005880d0();
            uStack_118 = CONCAT44(auStack_dc,0xc08408);
            FUN_005880d0();
            uStack_118 = CONCAT44(auStack_58,0xc08417);
            FUN_005880d0();
            uStack_8._0_1_ = 5;
            if (((auStack_58[0] != 0) && ((auStack_58[0] & 1) == 0)) &&
               (*(code **)(auStack_58[0] & 0xfffffffe) != (code *)0x0)) {
              ppcStack_11c = &pcStack_50;
              uStack_118 = CONCAT44(2,ppcStack_11c);
              piStack_120 = (int *)0xc08438;
              (**(code **)(auStack_58[0] & 0xfffffffe))();
            }
          }
          uStack_8._0_1_ = 6;
          if (((auStack_7c[0] != 0) && ((auStack_7c[0] & 1) == 0)) &&
             (*(code **)(auStack_7c[0] & 0xfffffffe) != (code *)0x0)) {
            ppcStack_11c = apcStack_74;
            uStack_118 = CONCAT44(2,ppcStack_11c);
            piStack_120 = (int *)0xc0845c;
            (**(code **)(auStack_7c[0] & 0xfffffffe))();
          }
          piVar2 = piStack_28;
          uStack_8._0_1_ = 1;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            iVar6 = piStack_28[1] + -1;
            piStack_28[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              uStack_118 = CONCAT44(0xc0847a,(undefined4)uStack_118);
              (**(code **)*piStack_28)();
              LOCK();
              piVar1 = piVar2 + 2;
              iVar6 = *piVar1 + -1;
              *piVar1 = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                uStack_118 = CONCAT44(0xc0848b,(undefined4)uStack_118);
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
          uStack_118 = (ulonglong)CONCAT14(DAT_01ef8170,(uint)DAT_01ef8171);
          ppcStack_11c = (code **)(uint)DAT_01ef8172;
          piStack_120 = (int *)(uint)DAT_01ef8173;
          pcStack_124 = *(code **)(param_1 + 0x94);
          uStack_138 = CONCAT44(&uStack_12c,0xc084c0);
          uStack_130 = param_1;
          FUN_006ebdf0();
          uStack_130 = 0;
          uStack_138 = CONCAT44(FUN_00c06880,&uStack_34);
          uStack_13c = 0xc084d0;
          FUN_00c00950();
          uStack_118 = uStack_118 & 0xffffffff;
          uStack_12c = uStack_34;
          pcStack_128 = pcStack_30;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            piStack_28[1] = piStack_28[1] + 1;
            UNLOCK();
          }
          pcStack_124 = pcStack_2c;
          piStack_120 = piStack_28;
          ppcStack_11c = ppcStack_24;
          uStack_130 = 0xc08518;
          puVar7 = (uint *)FUN_00bffae0();
          if (auStack_bc != puVar7) {
            auStack_58[0] = 0;
            uStack_8._0_1_ = 9;
            uStack_118 = CONCAT44(puVar7,0xc08538);
            FUN_005880d0();
            uStack_118 = CONCAT44(auStack_bc,0xc08546);
            FUN_005880d0();
            uStack_118 = CONCAT44(auStack_58,0xc08555);
            FUN_005880d0();
            uStack_8._0_1_ = 10;
            if (((auStack_58[0] != 0) && ((auStack_58[0] & 1) == 0)) &&
               (*(code **)(auStack_58[0] & 0xfffffffe) != (code *)0x0)) {
              ppcStack_11c = &pcStack_50;
              uStack_118 = CONCAT44(2,ppcStack_11c);
              piStack_120 = (int *)0xc08576;
              (**(code **)(auStack_58[0] & 0xfffffffe))();
            }
          }
          uStack_8._0_1_ = 0xb;
          if (((auStack_7c[0] != 0) && ((auStack_7c[0] & 1) == 0)) &&
             (*(code **)(auStack_7c[0] & 0xfffffffe) != (code *)0x0)) {
            ppcStack_11c = apcStack_74;
            uStack_118 = CONCAT44(2,ppcStack_11c);
            piStack_120 = (int *)0xc0859a;
            (**(code **)(auStack_7c[0] & 0xfffffffe))();
          }
          uStack_8._0_1_ = 1;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            iVar6 = piStack_28[1] + -1;
            piStack_28[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              uStack_118 = CONCAT44(0xc085b8,(undefined4)uStack_118);
              (**(code **)*piStack_28)();
              LOCK();
              iVar6 = piStack_28[2] + -1;
              piStack_28[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                uStack_118 = CONCAT44(0xc085c9,(undefined4)uStack_118);
                (**(code **)(*piStack_28 + 4))();
              }
            }
          }
          uStack_118 = CONCAT44(0xc085ce,(undefined4)uStack_118);
          puVar8 = (undefined4 *)FUN_01255560();
          uStack_f4 = *puVar8;
          uStack_f0 = puVar8[1];
          uStack_ec = puVar8[2];
          uStack_e8 = puVar8[3];
          uStack_e4 = *(undefined8 *)(puVar8 + 4);
          pcStack_2c = FUN_00c05510;
          piStack_28 = (int *)0x0;
          uStack_118 = CONCAT44(&pcStack_2c,0xc08607);
          ppcStack_24 = (code **)param_1;
          cVar4 = FUN_00585a40();
          if (cVar4 == '\0') {
            pcStack_50 = pcStack_2c;
            uStack_4c = piStack_28;
            iStack_48 = (int)ppcStack_24;
            uStack_44 = uStack_20;
            auStack_58[0] = 0x1961b21;
          }
          else {
            auStack_58[0] = 0;
          }
          auStack_7c[0] = 0;
          uStack_8._0_1_ = 0xd;
          uStack_118 = CONCAT44(auStack_58,0xc08641);
          FUN_005880d0();
          uStack_118 = CONCAT44(auStack_9c,0xc08650);
          FUN_005880d0();
          uStack_118 = CONCAT44(auStack_7c,0xc0865f);
          FUN_005880d0();
          uStack_8._0_1_ = 0xe;
          if (((auStack_7c[0] != 0) && ((auStack_7c[0] & 1) == 0)) &&
             (*(code **)(auStack_7c[0] & 0xfffffffe) != (code *)0x0)) {
            ppcStack_11c = apcStack_74;
            uStack_118 = CONCAT44(2,ppcStack_11c);
            piStack_120 = (int *)0xc08680;
            (**(code **)(auStack_7c[0] & 0xfffffffe))();
          }
          uStack_8._0_1_ = 0xf;
          if (((auStack_58[0] != 0) && ((auStack_58[0] & 1) == 0)) &&
             (*(code **)(auStack_58[0] & 0xfffffffe) != (code *)0x0)) {
            ppcStack_11c = &pcStack_50;
            uStack_118 = CONCAT44(2,ppcStack_11c);
            piStack_120 = (int *)0xc086a4;
            (**(code **)(auStack_58[0] & 0xfffffffe))();
          }
          puVar8 = *(undefined4 **)(param_1 + 0xb8);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          if (*(undefined4 **)(param_1 + 0xbc) == puVar8) {
            uStack_118 = CONCAT44(param_2,puVar8);
            ppcStack_11c = (code **)0xc086f4;
            FUN_005c1970();
          }
          else {
            *puVar8 = 0;
            puVar8[1] = 0;
            if (param_2[1] != 0) {
              LOCK();
              piVar2 = (int *)(param_2[1] + 4);
              *piVar2 = *piVar2 + 1;
              UNLOCK();
            }
            *puVar8 = *param_2;
            puVar8[1] = param_2[1];
            *(int *)(param_1 + 0xb8) = *(int *)(param_1 + 0xb8) + 8;
          }
          puStack_18 = (undefined *)&uStack_188;
          puStack_38 = auStack_170;
          uStack_188 = uStack_f4;
          uStack_184 = uStack_f0;
          uStack_180 = uStack_ec;
          uStack_17c = uStack_e8;
          uStack_178 = uStack_e4;
          auStack_170[0] = 0;
          puVar8 = &uStack_188;
          if (auStack_dc[0] != 0) {
            auStack_170[0] = auStack_dc[0];
            if ((auStack_dc[0] & 1) == 0) {
              (**(code **)(auStack_dc[0] & 0xfffffffe))(&uStack_d4,&uStack_168,0);
              puVar8 = (undefined4 *)puStack_18;
            }
            else {
              uStack_168 = uStack_d4;
              uStack_164 = uStack_d0;
              uStack_160 = uStack_cc;
              uStack_15c = uStack_c8;
              uStack_158 = uStack_c4;
              puVar8 = &uStack_188;
            }
          }
          puStack_18 = (undefined *)puVar8;
          uStack_150 = 0;
          uStack_8._0_1_ = 0x10;
          if (auStack_bc[0] != 0) {
            uStack_150 = auStack_bc[0];
            if ((auStack_bc[0] & 1) == 0) {
              (**(code **)(auStack_bc[0] & 0xfffffffe))(&uStack_b4,&uStack_148,0);
            }
            else {
              uStack_148 = uStack_b4;
              uStack_144 = uStack_b0;
              uStack_140 = uStack_ac;
              uStack_13c = uStack_a8;
              uStack_138 = uStack_a4;
            }
          }
          uStack_130 = 0;
          uStack_8._0_1_ = 0x11;
          if (auStack_9c[0] != 0) {
            uStack_130 = auStack_9c[0];
            if ((auStack_9c[0] & 1) == 0) {
              (**(code **)(auStack_9c[0] & 0xfffffffe))(&pcStack_94,&pcStack_128,0);
            }
            else {
              pcStack_128 = pcStack_94;
              pcStack_124 = pcStack_90;
              piStack_120 = piStack_8c;
              ppcStack_11c = ppcStack_88;
              uStack_118 = uStack_84;
            }
          }
          uStack_8._0_1_ = 1;
          if (param_2[1] != 0) {
            LOCK();
            piVar2 = (int *)(param_2[1] + 8);
            *piVar2 = *piVar2 + 1;
            UNLOCK();
          }
          FUN_0094a730(*param_2,param_2[1]);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
          if (auStack_9c[0] != 0) {
            if (((auStack_9c[0] & 1) == 0) &&
               (*(code **)(auStack_9c[0] & 0xfffffffe) != (code *)0x0)) {
              ppcStack_11c = &pcStack_94;
              uStack_118 = CONCAT44(2,ppcStack_11c);
              piStack_120 = (int *)0xc08857;
              (**(code **)(auStack_9c[0] & 0xfffffffe))();
            }
            auStack_9c[0] = 0;
          }
          uStack_118 = CONCAT44(0xc0886f,(undefined4)uStack_118);
          FUN_008c3510();
          ExceptionList = pvStack_10;
          return;
        }
      }
    }
  }
  puStack_14 = puVar3;
  uStack_118 = 0x19614e800c088d4;
  FUN_00550130();
  uStack_118 = CONCAT44(&DAT_01c17198,auStack_104);
                    /* WARNING: Subroutine does not return */
  ppcStack_11c = (code **)&UNK_00c088e5;
  FUN_0170c2a8();
}



/* FUNCTION 27147 ; VA 0x00c08882 ; Catch@00c08882 */

undefined4 Catch_00c08882(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  undefined auStack_c [8];
  undefined4 uStack_4;
  
  uStack_4 = 0;
  *(undefined **)(unaff_EBP + -0x34) = auStack_c;
  FUN_00557fc0(*(undefined4 *)(unaff_EBP + 8));
  *(undefined *)(unaff_EBP + -4) = 0x14;
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0xf4) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 0x13;
  FUN_00c05310();
  return 0xc0886f;
}



/* FUNCTION 27148 ; VA 0x00c088f0 ; FUN_00c088f0 */

int * __fastcall FUN_00c088f0(int param_1)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_018055d0;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 0x30);
  bVar4 = false;
  bVar3 = false;
  piStack_20 = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piStack_14[1] = piStack_14[1] + 1;
    UNLOCK();
    piStack_14 = *(int **)(param_1 + 0x30);
  }
  piVar6 = *(int **)(param_1 + 0x2c);
  iStack_8 = 0;
  iStack_1c = param_1;
  if (piVar6 != (int *)0x0) {
    piVar8 = (int *)*piVar6;
    piVar6 = (int *)piVar6[1];
    piStack_20 = piVar6;
    if (piVar8 != piVar6) {
      do {
        if ((*piVar8 == 0) ||
           (iVar2 = *(int *)(*piVar8 + 0xc), iVar5 = FUN_00b73ae0(),
           (uint)*(ushort *)(iVar5 + 0x1da) <
           (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
          bVar3 = true;
          piStack_24 = (int *)0x0;
          piVar6 = &iStack_28;
          iStack_18 = 0;
        }
        else {
          piStack_2c = (int *)piVar8[1];
          iStack_18 = *piVar8;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
            piStack_2c = (int *)piVar8[1];
          }
          bVar4 = true;
          piVar6 = &iStack_30;
        }
        piVar7 = (int *)piVar6[1];
        *piVar6 = 0;
        piVar6[1] = 0;
        iStack_38 = iStack_18;
        piStack_34 = piVar7;
        if ((bVar3) && (bVar3 = false, piStack_24 != (int *)0x0)) {
          LOCK();
          piVar1 = piStack_24 + 1;
          iVar2 = *piVar1;
          piVar6 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            piVar1 = piStack_24 + 2;
            iVar2 = *piVar1;
            piVar6 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar6 = (int *)(**(code **)(*piStack_24 + 4))();
            }
          }
        }
        if ((bVar4) && (bVar4 = false, piStack_2c != (int *)0x0)) {
          LOCK();
          piVar1 = piStack_2c + 1;
          iVar2 = *piVar1;
          piVar6 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            piVar1 = piStack_2c + 2;
            iVar2 = *piVar1;
            piVar6 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar6 = (int *)(**(code **)(*piStack_2c + 4))();
            }
          }
        }
        iStack_8._0_1_ = 1;
        if (iStack_18 != 0) {
          *(int *)(iStack_1c + 0x98) = *(int *)(iStack_1c + 0x98) + 1;
          piVar6 = (int *)FUN_00c082a0(&iStack_38);
          piVar7 = piStack_34;
        }
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (piVar7 != (int *)0x0) {
          LOCK();
          piVar1 = piVar7 + 1;
          iVar2 = *piVar1;
          piVar6 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar2 = *piVar1;
            piVar6 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar6 = (int *)(**(code **)(*piVar7 + 4))();
            }
          }
        }
        piVar8 = piVar8 + 2;
      } while (piVar8 != piStack_20);
    }
  }
  piVar8 = piStack_14;
  if (*(int *)(iStack_1c + 0x98) == 0) {
    piVar6 = (int *)FUN_00c04d30();
  }
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar7 = piVar8 + 1;
    iVar2 = *piVar7;
    piVar6 = (int *)*piVar7;
    *piVar7 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar6 = (int *)(**(code **)*piVar8)();
      LOCK();
      piVar7 = piVar8 + 2;
      iVar2 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar6 = (int *)(**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar6;
}



/* FUNCTION 27149 ; VA 0x00c08ad0 ; FUN_00c08ad0 */

void __thiscall FUN_00c08ad0(int param_1,int param_2,undefined8 param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0cf0;
  pvStack_10 = ExceptionList;
  if ((param_2 == *(int *)(param_1 + 0x94)) && (*(char *)(param_1 + 0x90) != '\0')) {
    if (*(uint *)(param_1 + 0x180) != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)((*(uint *)(param_1 + 0x180) & 0xfffffffe) + 4))(param_1 + 0x188);
      ExceptionList = pvStack_10;
      return;
    }
    ExceptionList = &pvStack_10;
    FUN_0086f2f0(1,"TestService: Waiting a total of %g seconds for the test to end",param_3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27150 ; VA 0x00c08b60 ; FUN_00c08b60 */

void __fastcall FUN_00c08b60(int param_1)

{
  int *piVar1;
  void **ppvVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined auStack_28 [16];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0cf0;
  pvStack_10 = ExceptionList;
  puVar5 = *(undefined4 **)(param_1 + 0xb8);
  puStack_14 = *(undefined4 **)(param_1 + 0xb4);
  ExceptionList = &pvStack_10;
  ppvVar2 = &pvStack_10;
  puStack_18 = puVar5;
  if (puStack_14 != puVar5) {
    do {
      if (param_1 == 0) {
LAB_00c08ce3:
        FUN_00550130("Unable to stop test script");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_28,&DAT_01c17198);
      }
      iVar4 = *(int *)(param_1 + 0x34);
      iVar3 = param_1;
      if ((iVar4 != 0) && (iVar3 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
        iVar3 = FUN_005c8ac0();
      }
      if (((iVar3 == 0) ||
          (iVar4 = *(int *)(iVar3 + 0xc), iVar3 = FUN_008a8c30(),
          (uint)*(ushort *)(iVar3 + 0x1da) <
          (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) ||
         (iVar4 = FUN_0055ea10(), puVar5 = puStack_14, iVar4 == 0)) goto LAB_00c08ce3;
      if (puStack_14[1] != 0) {
        LOCK();
        piVar1 = (int *)(puStack_14[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00959050(*puStack_14,puStack_14[1]);
      puStack_14 = puVar5 + 2;
    } while (puStack_14 != puStack_18);
    puVar5 = *(undefined4 **)(param_1 + 0xb8);
    ppvVar2 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar2;
  puVar6 = (undefined4 *)(param_1 + 0xb4);
  FUN_005596d0(*puVar6,puVar5,puVar6);
  *(undefined4 *)(param_1 + 0xb8) = *puVar6;
  *(undefined4 *)(param_1 + 0x98) = 0;
  iVar4 = FUN_00606cd0(param_1);
  if (((iVar4 != 0) && (*(int *)(param_1 + 0xa8) == 0)) && (*(int *)(iVar4 + 0x68) != 0)) {
    FUN_00999b50(0);
  }
  FUN_00c081b0();
  FUN_00e3a420(*(undefined4 *)(param_1 + 0xac));
  FUN_00e3a210(*(undefined *)(param_1 + 0xb0));
  FUN_00e3a900(*(undefined *)(param_1 + 0xb1));
  if (*(uint *)(param_1 + 0x70) != 0) {
    (**(code **)((*(uint *)(param_1 + 0x70) & 0xfffffffe) + 4))(param_1 + 0x78);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27151 ; VA 0x00c08d00 ; FUN_00c08d00 */

void __thiscall FUN_00c08d00(int param_1,int param_2)

{
  int iVar1;
  uint in_stack_00000018;
  undefined4 uStack_38;
  undefined *puStack_34;
  char *pcStack_30;
  undefined auStack_24 [16];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01805150;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if (*(int *)(param_1 + 0x54) == 0) {
    pcStack_30 = "Can\'t find TestService";
    puStack_34 = (undefined *)0xc08dbe;
    ExceptionList = &pvStack_10;
    FUN_00550130();
    pcStack_30 = "";
    puStack_34 = auStack_24;
                    /* WARNING: Subroutine does not return */
    uStack_38 = 0xc08dcc;
    FUN_0170c2a8();
  }
  pcStack_30 = (char *)0x0;
  puStack_14 = (undefined *)&uStack_38;
  uStack_38 = 0;
  puStack_34 = (undefined *)0x0;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00c08de0(0);
  pcStack_30 = (char *)0xc08d6f;
  FUN_00c04d30();
  if (0xf < in_stack_00000018) {
    pcStack_30 = (char *)(in_stack_00000018 + 1);
    iVar1 = param_2;
    if (0xfff < pcStack_30) {
      iVar1 = *(int *)(param_2 + -4);
      pcStack_30 = (char *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        pcStack_30 = &UNK_00c08dd1;
        FUN_017167a3();
      }
    }
    uStack_38 = 0xc08d9c;
    puStack_34 = (undefined *)iVar1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27152 ; VA 0x00c08de0 ; FUN_00c08de0 */

int __thiscall FUN_00c08de0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  int *in_stack_00000020;
  int *in_stack_00000024;
  int **in_stack_00000028;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805238;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x9c) = *(int *)(param_1 + 0x9c) + 1;
  piStack_20 = (int *)&DAT_02133970;
  uStack_8 = 1;
  piStack_24 = (int *)0xc08e14;
  iVar3 = FUN_008a4940();
  if ((char)param_2 == '\0') {
    *(int *)(param_1 + 0xa0) = *(int *)(param_1 + 0xa0) + 1;
    piStack_20 = (int *)&DAT_021339a8;
    piStack_24 = (int *)0xc08e2d;
    iVar3 = FUN_008a4940();
  }
  if (*(int *)(param_1 + 0x120) == 0) {
    if ((char)param_2 == '\0') {
      piStack_20 = (int *)&param_3;
      piStack_24 = (int *)in_stack_00000028;
      if (in_stack_00000024 != (int *)0x0) {
        LOCK();
        in_stack_00000024[1] = in_stack_00000024[1] + 1;
        UNLOCK();
      }
      piStack_28 = in_stack_00000024;
      iVar3 = FUN_00c06f60(2,in_stack_00000020);
    }
  }
  else {
    piStack_20 = (int *)in_stack_00000028;
    in_stack_00000028 = &piStack_28;
    if (in_stack_00000024 != (int *)0x0) {
      LOCK();
      in_stack_00000024[1] = in_stack_00000024[1] + 1;
      UNLOCK();
    }
    piStack_28 = in_stack_00000020;
    piStack_24 = in_stack_00000024;
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar3 = FUN_00c02370(param_2);
  }
  if (0xf < in_stack_0000001c) {
    piStack_20 = (int *)(in_stack_0000001c + 1);
    piVar4 = param_3;
    if (0xfff < piStack_20) {
      piVar4 = (int *)param_3[-1];
      piStack_20 = (int *)(in_stack_0000001c + 0x24);
      if (0x1f < (uint)((int)param_3 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
        piStack_20 = (int *)&UNK_00c08f47;
        FUN_017167a3();
      }
    }
    piStack_28 = (int *)0xc08ef2;
    piStack_24 = piVar4;
    iVar3 = FUN_01674ea0();
  }
  piVar4 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = (int *)((uint)param_3 & 0xffffff00);
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000024 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_20 = (int *)0xc08f20;
      iVar3 = (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_20 = (int *)0xc08f2f;
        iVar3 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27153 ; VA 0x00c08f50 ; FUN_00c08f50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c08f50(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805600;
  pvStack_10 = ExceptionList;
  if (DAT_01ef8638 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8850) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef8850);
      if (DAT_01ef8850 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ServerStorage",1,uStack_20,0,0,9,0,0);
        _DAT_01ef8848 = RBX::Creator<class_RBX::ServerStorage>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef8640,&DAT_01ef8848);
        FUN_016f3654(FUN_01893110);
        FUN_016f37bf(&DAT_01ef8850);
      }
    }
    DAT_01ef8638 = &DAT_01ef8640;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef8638;
}



/* FUNCTION 27154 ; VA 0x00c09050 ; FUN_00c09050 */

void FUN_00c09050(void)

{
  int iVar1;
  
  if (DAT_01ef8854 == 0) {
    iVar1 = FUN_00c08f50();
    DAT_01ef8854 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27155 ; VA 0x00c09070 ; FUN_00c09070 */

undefined4 * __fastcall FUN_00c09070(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805628;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ServerStorage,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00c08f50();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::ServerStorage::vftable;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("ServerStorage",0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27156 ; VA 0x00c09140 ; FUN_00c09140 */

void __fastcall FUN_00c09140(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ServerStorage>::vftable;
  uVar1 = FUN_00c08f50(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27157 ; VA 0x00c09180 ; FUN_00c09180 */

undefined4 __fastcall FUN_00c09180(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  
  cVar1 = FUN_00971ce0(param_1,1);
  if (cVar1 == '\0') {
    iVar2 = FUN_0090c170();
    if (*(char *)(iVar2 + 0xc4) == '\0') {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 27158 ; VA 0x00c091b0 ; FUN_00c091b0 */

undefined4 * FUN_00c091b0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00673c20(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27159 ; VA 0x00c09220 ; FUN_00c09220 */

uint FUN_00c09220(void)

{
  int iVar1;
  
  iVar1 = FUN_00c08f50();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27160 ; VA 0x00c09240 ; FUN_00c09240 */

uint FUN_00c09240(void)

{
  int iVar1;
  
  iVar1 = FUN_00c08f50();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27161 ; VA 0x00c09260 ; FUN_00c09260 */

int * __thiscall
FUN_00c09260(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805653;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00c0ea70();
  uVar3 = FUN_00c096f0();
  FUN_009ca670(uVar3,iVar2,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,1);
  param_1[0xd] = iVar2;
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::
                  EnumPropDescriptor<class_RBX::PolicyService,enum_RBX::TriStateBoolean>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::PropDescriptor<class_RBX::PolicyService,enum_RBX::TriStateBoolean>::
              GetSetImpl<enum_RBX::TriStateBoolean_(__thiscall_RBX::PolicyService::*)(void)const_,void_(__thiscall_RBX::PolicyService::*)(enum_RBX::TriStateBoolean)>
              ::vftable;
    puVar4[2] = param_4;
    puVar4[3] = param_5;
    puVar4[4] = param_6;
    puVar4[5] = param_7;
  }
  param_1[0xe] = (int)puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar2 = FUN_00c0ea70();
  param_1[0xf] = iVar2;
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27162 ; VA 0x00c09340 ; FUN_00c09340 */

undefined4 * __thiscall
FUN_00c09340(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01962660;
  cVar3 = FUN_00c09810(param_2,param_3,param_4,param_5,param_6,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 27163 ; VA 0x00c09480 ; FUN_00c09480 */

undefined4 * __thiscall
FUN_00c09480(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01962658;
  cVar3 = FUN_008df530(param_2,param_3,param_4,param_5,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 27164 ; VA 0x00c095b0 ; FUN_00c095b0 */

undefined4 * __thiscall
FUN_00c095b0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01962650;
  cVar3 = FUN_00c09810(param_2,param_3,param_4,param_5,param_6,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 27165 ; VA 0x00c096f0 ; FUN_00c096f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c096f0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805680;
  pvStack_10 = ExceptionList;
  if (DAT_01ef88b0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8ac8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef8ac8);
      if (DAT_01ef8ac8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"PolicyService",1,uStack_20,0,0,1,0,0);
        _DAT_01ef8ac0 = RBX::Creator<class_RBX::PolicyService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef88b8,&DAT_01ef8ac0);
        FUN_016f3654(FUN_018933a0);
        FUN_016f37bf(&DAT_01ef8ac8);
      }
    }
    DAT_01ef88b0 = &DAT_01ef88b8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef88b0;
}



/* FUNCTION 27166 ; VA 0x00c097f0 ; FUN_00c097f0 */

void FUN_00c097f0(void)

{
  int iVar1;
  
  if (DAT_01ef8acc == 0) {
    iVar1 = FUN_00c096f0();
    DAT_01ef8acc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27167 ; VA 0x00c09810 ; FUN_00c09810 */

undefined FUN_00c09810(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,undefined4 *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined uVar4;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uStack_18 = param_1;
  piStack_14 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_10 = param_3;
  piStack_c = param_4;
  uStack_8 = param_5;
  cVar3 = FUN_00585a40(&uStack_18);
  if (cVar3 == '\0') {
    FUN_00c09c10(&uStack_18);
    *param_6 = 0;
    param_6[1] = 0;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    *param_6 = uStack_2c;
    param_6[1] = piStack_28;
    param_6[2] = 0;
    param_6[3] = 0;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[2] = piStack_20[2] + 1;
      UNLOCK();
    }
    param_6[2] = uStack_24;
    param_6[3] = piStack_20;
    param_6[4] = uStack_1c;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[2] + -1;
      piStack_20[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    uVar4 = 1;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    uVar4 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  return uVar4;
}



/* FUNCTION 27168 ; VA 0x00c09980 ; FUN_00c09980 */

/* WARNING: Restarted to delay deadcode elimination for space: ram */

code * FUN_00c09980(code *param_1)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_298;
  code **ppcStack_294;
  undefined auStack_290 [184];
  undefined4 uStack_1d8;
  undefined *puStack_1d4;
  undefined4 *puStack_1d0;
  int *piStack_1cc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_e4;
  code **ppcStack_e0;
  undefined auStack_dc [200];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018056cc;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  piStack_1cc = (int *)0xc099ac;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_008881d0();
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = in_stack_00000024;
  piStack_1b4 = in_stack_00000028;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8a9c) {
    piStack_1cc = &DAT_01ea8a9c;
    puStack_1d0 = (undefined4 *)0xc09bb6;
    FUN_016f3809();
    if (DAT_01ea8a9c == -1) {
      piStack_1cc = &DAT_01ea8a9c;
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      puStack_1d0 = (undefined4 *)0xc09bee;
      FUN_016f37bf();
    }
  }
  piStack_1cc = (int *)auStack_dc;
  puStack_1d0 = &uStack_1b8;
  uStack_8._0_1_ = 2;
  ppcStack_e0 = (code **)0x0;
  puStack_1d4 = (undefined *)0xc09a46;
  uStack_e4 = uVar5;
  (*DAT_01ea8a90)();
  ppcStack_e0 = &DAT_01ea8a90;
  uStack_8._0_1_ = 3;
  if (param_1 != (code *)0x0) {
    puStack_14 = (undefined *)&uStack_298;
    pcVar3 = *(code **)(((uint)param_1 & 0xfffffffe) + 4);
    uStack_298 = uStack_e4;
    ppcStack_294 = (code **)0x0;
    (*DAT_01ea8a94)(auStack_dc,auStack_290);
    ppcStack_294 = ppcStack_e0;
    if (ppcStack_e0 != (code **)0x0) {
      (*ppcStack_e0[2])(auStack_dc);
      ppcStack_e0 = (code **)0x0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    uStack_e4 = FUN_00888530();
    if (ppcStack_e0 != (code **)0x0) {
      (*ppcStack_e0[2])(auStack_dc);
      ppcStack_e0 = (code **)0x0;
    }
    uStack_8._0_1_ = 3;
    (*pcVar3)(&stack0x0000000c);
    uStack_8._0_1_ = 6;
    if (ppcStack_e0 != (code **)0x0) {
      piStack_1cc = (int *)auStack_dc;
      puStack_1d0 = (undefined4 *)0xc09b29;
      (*ppcStack_e0[2])();
    }
    uStack_8._0_1_ = 7;
    piStack_1cc = &uStack_1b8;
    puStack_1d0 = (undefined4 *)0xc09b46;
    (*DAT_01ea8a98)();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
       (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
      puStack_1d4 = &stack0x0000000c;
      piStack_1cc = (int *)0x2;
      uStack_1d8 = 0xc09b6a;
      puStack_1d0 = (undefined4 *)puStack_1d4;
      param_1 = (code *)(*param_1)();
    }
    piVar4 = in_stack_00000028;
    if (in_stack_00000028 != (int *)0x0) {
      LOCK();
      piVar1 = in_stack_00000028 + 1;
      iVar2 = *piVar1;
      param_1 = (code *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_1cc = (int *)0xc09b8d;
        param_1 = (code *)(**(code **)*in_stack_00000028)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          piStack_1cc = (int *)0xc09b9c;
          param_1 = (code *)(**(code **)(*piVar4 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  piStack_1cc = (int *)0xc09c01;
  piStack_1cc = (int *)FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
  puStack_1d0 = (undefined4 *)&UNK_00c09c0b;
  FUN_0054e5e0();
}



/* FUNCTION 27169 ; VA 0x00c09c10 ; FUN_00c09c10 */

undefined4 * __thiscall FUN_00c09c10(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  return param_1;
}



/* FUNCTION 27170 ; VA 0x00c09c70 ; FUN_00c09c70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_00c09c70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  undefined4 *puStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180572b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00c096f0();
  FUN_009cb820(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::PolicyService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(class_std::shared_ptr<class_RBX::Instance>_const&),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8 = 1;
  uVar2 = FUN_008881d0();
  param_1[9] = uVar2;
  puVar3 = (undefined4 *)param_1[0x10];
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cdc0();
    puStack_e4 = (undefined4 *)0x0;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e0 = *puVar3;
    uStack_dc = puVar3[1];
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead288) {
      FUN_016f3809(&DAT_01ead288);
      if (DAT_01ead288 == -1) {
        DAT_01ead27c = FUN_0057bbb0;
        _DAT_01ead280 = FUN_005880a0;
        DAT_01ead284 = FUN_0057d5e0;
        FUN_016f37bf(&DAT_01ead288);
      }
    }
    puStack_e4 = &DAT_01ead27c;
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_e4 != (undefined4 *)0x0) {
      (*(code *)puStack_e4[2])(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27171 ; VA 0x00c09e80 ; FUN_00c09e80 */

undefined4 * __fastcall FUN_00c09e80(undefined4 *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  char cVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  uint uVar9;
  uint uVar10;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018057a4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::PolicyService,class_RBX::ServiceInstance>::vftable;
  uVar6 = FUN_00c096f0();
  param_1[3] = uVar6;
  *param_1 = RBX::PolicyService::vftable;
  uStack_8 = 1;
  param_1[0x16] = 0;
  puStack_14 = param_1;
  cVar5 = FUN_00585a40(&puStack_14);
  if (cVar5 == '\0') {
    param_1[0x18] = puStack_14;
    param_1[0x16] = &DAT_01962649;
  }
  else {
    param_1[0x16] = 0;
  }
  uStack_8._0_1_ = 2;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  puStack_14 = (undefined4 *)FUN_01674e20(0x14);
  if (puStack_14 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    puStack_14[1] = 1;
    puStack_14[2] = 1;
    *puStack_14 = std::_Ref_count_obj<class_RBX::PolicyServiceAnalyticsStatReporter>::vftable;
    puStack_14[3] = RBX::PolicyServiceAnalyticsStatReporter::vftable;
    puStack_14[4] = 0;
    puVar7 = puStack_14;
  }
  param_1[0x21] = puVar7;
  param_1[0x20] = puVar7 + 3;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  uStack_8._0_1_ = 4;
  param_1[0x24] = 0;
  puVar7 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8._0_1_ = 5;
  puStack_14 = puVar7;
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    puVar7[1] = 1;
    puVar1 = puVar7 + 4;
    puVar7[2] = 1;
    *puVar7 = std::
              _Ref_count_obj<class_RBX::AsyncPlayerCallbackQueueHandler<class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_>_>
              ::vftable;
    uVar6 = DAT_01d68150;
    puVar7[3] = RBX::
                AsyncPlayerCallbackQueueHandler<class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_>
                ::vftable;
    *puVar1 = 0;
    puVar7[5] = 0;
    puVar7[6] = 0;
    puStack_1c = puVar1;
    uVar8 = FUN_008ed990(0,0);
    puVar7[5] = uVar8;
    puVar7[7] = 0;
    puVar7[8] = 0;
    puVar7[9] = 0;
    uStack_8._0_1_ = 7;
    *puVar1 = 0x3f800000;
    FUN_005cb500(8);
    puStack_14[0xc] = uVar6;
    puVar7 = puStack_14;
    param_1 = puStack_18;
  }
  uStack_8._0_1_ = 4;
  param_1[0x22] = puVar7 + 3;
  piVar3 = (int *)param_1[0x23];
  param_1[0x23] = puVar7;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  FUN_005542c0("PolicyService",0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_008a6520(auStack_34);
  if (0xf < uStack_20) {
    uVar10 = uStack_20 + 1;
    uVar9 = auStack_34[0];
    if (0xfff < uVar10) {
      uVar9 = *(uint *)(auStack_34[0] - 4);
      uVar10 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar10);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27172 ; VA 0x00c0a0d0 ; FUN_00c0a0d0 */

void __fastcall FUN_00c0a0d0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::PolicyService>::vftable;
  uVar1 = FUN_00c096f0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27173 ; VA 0x00c0a110 ; FUN_00c0a110 */

void __fastcall FUN_00c0a110(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00c0aca0();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x28);
  return;
}



/* FUNCTION 27174 ; VA 0x00c0a180 ; FUN_00c0a180 */

void __fastcall FUN_00c0a180(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    FUN_008c3510();
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x40);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 27175 ; VA 0x00c0a240 ; FUN_00c0a240 */

void __fastcall FUN_00c0a240(undefined4 *param_1)

{
  FUN_00c0aca0();
  FUN_01674ea0(*param_1,0x28);
  return;
}



/* FUNCTION 27176 ; VA 0x00c0a260 ; FUN_00c0a260 */

int * __thiscall FUN_00c0a260(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  int *piStack_10;
  int *piStack_c;
  int iStack_8;
  
  piVar4 = param_2;
  iStack_8 = param_1;
  iVar6 = FUN_00a1aa40(param_2);
  iVar5 = iStack_8;
  iVar1 = *(int *)(param_1 + 0xc);
  piVar2 = *(int **)(param_1 + 4);
  iVar6 = iVar6 * 8;
  piVar8 = *(int **)(iVar1 + iVar6);
  piVar9 = piVar8;
  while( true ) {
    piVar10 = piVar2;
    if (piVar9 != piVar2) {
      piVar10 = (int *)**(undefined4 **)(iVar1 + 4 + iVar6);
    }
    if (piVar8 == piVar10) goto LAB_00c0a2bc;
    if ((piVar8[2] == *piVar4) && (piVar8[3] == piVar4[1])) break;
    piVar8 = (int *)*piVar8;
    piVar9 = *(int **)(iVar1 + iVar6);
  }
  if (piVar8 == piVar2) {
LAB_00c0a2bc:
    iVar6 = *piVar2;
    piStack_c = piVar4;
    puVar3 = *(undefined4 **)(iVar6 + 4);
    uVar7 = FUN_00c0a3e0(iVar6,puVar3,&DAT_018bdeda,&piStack_c,(int)&param_2 + 3);
    if (*(int *)(iVar5 + 8) == 0x6666665) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(iVar5 + 8) = *(int *)(iVar5 + 8) + 1;
    *(undefined4 *)(iVar6 + 4) = uVar7;
    *puVar3 = uVar7;
    FUN_00c0a4a0(&piStack_10,**(int **)(iVar5 + 4) + 8,**(int **)(iVar5 + 4));
    piVar8 = piStack_10;
  }
  return piVar8 + 4;
}



/* FUNCTION 27177 ; VA 0x00c0a330 ; FUN_00c0a330 */

undefined4 FUN_00c0a330(undefined4 param_1,undefined4 param_2)

{
  FUN_00c0a350(param_1,param_2);
  return param_1;
}



/* FUNCTION 27178 ; VA 0x00c0a350 ; FUN_00c0a350 */

void __thiscall FUN_00c0a350(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  iVar2 = FUN_00a1aa40(param_3 + 2);
  iVar2 = iVar2 * 8;
  piVar1 = *(int **)(*(int *)(param_1 + 0xc) + iVar2);
  piVar3 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if ((int *)piVar3[1] == param_3) {
    if (piVar1 == param_3) {
      *piVar3 = *(int *)(param_1 + 4);
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar2) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar3[1] = param_3[1];
    }
  }
  else if (piVar1 == param_3) {
    *piVar3 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00c0a180();
  FUN_01674ea0(param_3,0x28);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 27179 ; VA 0x00c0a3e0 ; FUN_00c0a3e0 */

int FUN_00c0a3e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018057b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008ed990(param_1,param_2);
  puVar1 = (undefined4 *)(iVar2 + 0x10);
  uStack_8 = 0;
  puVar3 = (undefined4 *)*param_4;
  *(undefined4 *)(iVar2 + 8) = *puVar3;
  *(undefined4 *)(iVar2 + 0xc) = puVar3[1];
  *puVar1 = 0;
  *(undefined4 *)(iVar2 + 0x14) = 0;
  *(undefined4 *)(iVar2 + 0x18) = 0;
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  *(undefined4 *)(iVar2 + 0x20) = 0;
  puVar3 = (undefined4 *)FUN_01674e20(8);
  *puVar1 = puVar3;
  *puVar3 = 0;
  puVar3[1] = 0;
  *(undefined4 **)*puVar1 = puVar1;
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 27180 ; VA 0x00c0a485 ; Catch_All@00c0a485 */

void Catch_All_00c0a485(void)

{
  int unaff_EBP;
  
  FUN_005f6c10(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27181 ; VA 0x00c0a4a0 ; FUN_00c0a4a0 */

void __thiscall FUN_00c0a4a0(float *param_1,float *param_2,int *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  int iVar3;
  float fVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018057c0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  iVar3 = FUN_00a1aa40(param_3);
  fVar4 = param_1[1];
  fVar5 = *(float *)((int)param_1[3] + iVar3 * 8);
  if (fVar4 != fVar5) {
    fVar4 = **(float **)((int)param_1[3] + 4 + iVar3 * 8);
    while (fVar4 != fVar5) {
      fVar4 = *(float *)((int)fVar4 + 4);
      if ((*param_3 == *(int *)((int)fVar4 + 8)) && (param_3[1] == *(int *)((int)fVar4 + 0xc))) {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_00c0a180();
        FUN_01674ea0(param_4,0x28);
        *param_2 = fVar4;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  if (fVar4 != fVar5) {
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar4;
    **(undefined4 **)((int)fVar4 + 4) = param_4;
    fVar1 = *(float *)((int)fVar4 + 4);
    *(undefined4 *)((int)fVar4 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + iVar3 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + iVar3 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + iVar3 * 8) = param_4;
  }
  else if (fVar1 == fVar4) {
    *(float **)((int)fVar5 + iVar3 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + iVar3 * 8);
    *(float **)((int)fVar5 + 4 + iVar3 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + iVar3 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + iVar3 * 8) + 4);
    }
  }
  fVar4 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar4 + (double)(&DAT_018c0d90)[-((int)fVar4 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar4 < 0x200) {
      fVar4 = (float)((int)fVar4 << 3);
    }
    else if ((uint)fVar4 < 0x1fffffff) {
      fVar4 = (float)((int)fVar4 * 2);
    }
    FUN_005cb500(fVar4);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar4 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00c0a4a0(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar4);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27182 ; VA 0x00c0a666 ; Catch_All@00c0a666 */

void Catch_All_00c0a666(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00c0a330(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27183 ; VA 0x00c0a690 ; FUN_00c0a690 */

int __thiscall FUN_00c0a690(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018057e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar6 = FUN_00587490(&iStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iStack_20 != 0) {
      uVar3 = param_1[4];
      if (DAT_01d68200 == '\0') {
        if (piStack_1c != (int *)0x0) {
          LOCK();
          piStack_1c[1] = piStack_1c[1] + 1;
          UNLOCK();
        }
        iVar6 = FUN_00c0d030(iStack_20,piStack_1c,param_2,uVar3);
      }
      else {
        if (param_1[3] != 0) {
          LOCK();
          piVar1 = (int *)(param_1[3] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        uVar4 = param_1[2];
        uVar5 = param_1[3];
        if (param_1[1] != 0) {
          LOCK();
          piVar1 = (int *)(param_1[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        iVar6 = FUN_00c0cd90(*param_1,param_1[1],uVar4,uVar5,param_2,uVar3);
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar2 = *piVar1;
        iVar6 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar6 = (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 27184 ; VA 0x00c0a7e0 ; FUN_00c0a7e0 */

/* WARNING: Removing unreachable block (ram,0x00c0a88a) */
/* WARNING: Removing unreachable block (ram,0x00c0a896) */
/* WARNING: Removing unreachable block (ram,0x00c0a8a4) */

void __thiscall FUN_00c0a7e0(uint *param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  code *pcVar1;
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805818;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0();
  }
  pcVar1 = *(code **)((*param_1 & 0xfffffffe) + 4);
  ExceptionList = &pvStack_10;
  FUN_005880d0();
  uStack_8._0_1_ = 4;
  FUN_005880d0(&param_4);
  uStack_8._0_1_ = 2;
  (*pcVar1)(param_1 + 2,param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))();
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27185 ; VA 0x00c0a930 ; FUN_00c0a930 */

undefined4 * __thiscall FUN_00c0a930(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::
             AsyncPlayerCallbackQueueHandler<class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_>
             ::vftable;
  FUN_00c0a110();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 27186 ; VA 0x00c0a960 ; FUN_00c0a960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c0a960(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TriStateBoolean>::vftable;
  _DAT_01ef8ad0 = _DAT_01ef8ad0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 27187 ; VA 0x00c0a990 ; FUN_00c0a990 */

undefined4 * __thiscall FUN_00c0a990(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TriStateBoolean>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 27188 ; VA 0x00c0a9c0 ; FUN_00c0a9c0 */

undefined4 * __thiscall FUN_00c0a9c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TriStateBoolean>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 27189 ; VA 0x00c0a9f0 ; FUN_00c0a9f0 */

undefined4 * __thiscall FUN_00c0a9f0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::PolicyService::vftable;
  piVar2 = (int *)param_1[0x23];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x21];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[0x16];
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    param_1[0x16] = 0;
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x98);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27190 ; VA 0x00c0aad0 ; FUN_00c0aad0 */

undefined4 * __thiscall FUN_00c0aad0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::PolicyServiceAnalyticsStatReporter::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 27191 ; VA 0x00c0ab00 ; FUN_00c0ab00 */

void __fastcall FUN_00c0ab00(int param_1)

{
  (**(code **)(*(int *)(param_1 + 0xc) + 0x48))(0);
  return;
}



/* FUNCTION 27192 ; VA 0x00c0ab10 ; FUN_00c0ab10 */

void FUN_00c0ab10(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 uint *param_5,uint *param_6)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7930;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef885e);
  auStack_6c[0] = 0;
  uVar1 = *param_6;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_6 + 2;
      uStack_7c = 0xc0ab87;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_6[2];
      uStack_60 = param_6[3];
      uStack_5c = param_6[4];
      uStack_58 = param_6[5];
      uStack_54 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_5;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_a8 = param_5[2];
      uStack_a4 = param_5[3];
      uStack_a0 = param_5[4];
      uStack_9c = param_5[5];
      uStack_98 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_009602e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0xc0ac69;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_90 = param_4;
  uStack_8 = 0xffffffff;
  uStack_98 = CONCAT44(0xc0ac86,(undefined4)uStack_98);
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27193 ; VA 0x00c0aca0 ; FUN_00c0aca0 */

void __fastcall FUN_00c0aca0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar2 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_00c0a180();
      FUN_01674ea0(piVar2,0x28);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 27194 ; VA 0x00c0ace0 ; FUN_00c0ace0 */

void FUN_00c0ace0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c0ea70();
    *param_2 = uVar3;
    iVar4 = FUN_00c0eb20();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 27195 ; VA 0x00c0ad40 ; FUN_00c0ad40 */

void FUN_00c0ad40(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c0ea70();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27196 ; VA 0x00c0ad80 ; FUN_00c0ad80 */

undefined4 * FUN_00c0ad80(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_006729f0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27197 ; VA 0x00c0adf0 ; FUN_00c0adf0 */

int __thiscall FUN_00c0adf0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  int iVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00a1aa40(param_2);
  iVar6 = *(int *)(param_1 + 0xc);
  piVar1 = *(int **)(iVar6 + iVar3 * 8);
  piVar2 = *(int **)(param_1 + 4);
  iVar3 = iVar3 * 8 + 4;
  piVar7 = piVar1;
  while( true ) {
    piVar4 = piVar2;
    if (piVar1 != piVar2) {
      piVar4 = (int *)**(undefined4 **)(iVar3 + iVar6);
    }
    if (piVar7 == piVar4) goto LAB_00c0aeb2;
    iVar9 = param_2[1];
    if ((piVar7[2] == *param_2) && (piVar4 = piVar7, piVar7[3] == iVar9)) break;
    piVar7 = (int *)*piVar7;
  }
  while( true ) {
    piVar5 = piVar2;
    if (piVar1 != piVar2) {
      iVar9 = param_2[1];
      piVar5 = (int *)**(undefined4 **)(iVar3 + iVar6);
    }
    if (((piVar4 == piVar5) || (*param_2 != piVar4[2])) || (iVar9 != piVar4[3])) break;
    piVar4 = (int *)*piVar4;
  }
  if (piVar7 == piVar4) {
LAB_00c0aeb2:
    piVar7 = piVar2;
    piVar4 = piVar2;
  }
  iVar3 = 0;
  for (piVar1 = piVar7; piVar1 != piVar4; piVar1 = (int *)*piVar1) {
    iVar3 = iVar3 + 1;
  }
  if ((piVar7 == (int *)*piVar2) && (piVar4 == piVar2)) {
    uStack_8 = 0;
    FUN_00c0aca0();
    FUN_005cb500(8);
  }
  else if (piVar7 != piVar4) {
    do {
      piVar1 = (int *)*piVar7;
      iVar6 = FUN_00a1aa40(piVar7 + 2);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0xc) + iVar6 * 8);
      if ((int *)puVar8[1] == piVar7) {
        if ((int *)*puVar8 == piVar7) {
          *puVar8 = *(undefined4 *)(param_1 + 4);
          *(undefined4 *)(iVar6 * 8 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
        }
        else {
          puVar8[1] = piVar7[1];
        }
      }
      else if ((int *)*puVar8 == piVar7) {
        *puVar8 = piVar1;
      }
      *(int *)piVar7[1] = *piVar7;
      *(int *)(*piVar7 + 4) = piVar7[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      FUN_00c0a180();
      FUN_01674ea0(piVar7,0x28);
      piVar7 = piVar1;
    } while (piVar1 != piVar4);
    ExceptionList = pvStack_10;
    return iVar3;
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27198 ; VA 0x00c0afa0 ; FUN_00c0afa0 */

void __thiscall FUN_00c0afa0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  uint in_stack_0000002c;
  undefined4 uStack_f4;
  int iStack_f0;
  undefined auStack_ec [200];
  undefined auStack_24 [4];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c85cb;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)*param_3)();
  if (iVar4 != 0) {
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8._0_1_ = 2;
    uStack_f4 = FUN_00888530();
    iStack_f0 = 0;
    uStack_8._0_1_ = 3;
    cVar3 = (**(code **)(*param_3 + 4))(1,&uStack_f4);
    if (cVar3 != '\0') {
      puVar5 = (undefined4 *)FUN_0088a3d0();
      if (puVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar5[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_18 = *puVar5;
      piStack_14 = (int *)puVar5[1];
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (iStack_f0 != 0) {
        (**(code **)(iStack_f0 + 8))(auStack_ec);
      }
      FUN_00550b30();
      goto LAB_00c0b0ce;
    }
    uStack_8._0_1_ = 5;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(auStack_ec);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00550b30();
  }
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_24,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_18 = *puVar5;
  piStack_14 = (int *)puVar5[1];
LAB_00c0b0ce:
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00c0ab10(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27199 ; VA 0x00c0b1a0 ; FUN_00c0b1a0 */

undefined4 * __thiscall FUN_00c0b1a0(int *param_1,undefined4 *param_2,int param_3,int *param_4)

{
  undefined4 *puVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined auStack_a8 [16];
  int iStack_98;
  undefined auStack_90 [16];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined auStack_78 [24];
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined auStack_48 [8];
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [12];
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180588f;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  uStack_14 = 1;
  iVar4 = FUN_008f7870(param_1);
  uStack_1c = CONCAT44(uStack_1c._4_4_,(undefined4)uStack_1c);
  if ((iVar4 == 0) || (uStack_1c = CONCAT44(uStack_1c._4_4_,(undefined4)uStack_1c), param_3 == 0))
  goto LAB_00c0b40f;
  if ((*(int *)(iVar4 + 0x4a0) == 2) && (DAT_01d5a4c0 == '\0')) {
    uStack_1c = FUN_00928340();
    uStack_50 = 0xf00000000;
    uStack_60 = uStack_60 & 0xffffff00;
    uStack_8._0_1_ = 3;
    FUN_0054ef60(param_3 + 0x2a8);
    uStack_14 = 3;
    uStack_8._0_1_ = 4;
    FUN_016819e0(auStack_28,auStack_78);
    uStack_8._0_1_ = 5;
    cVar3 = FUN_016816d0();
    if (cVar3 == '\0') {
      cVar3 = FUN_01681870();
      if (cVar3 == '\0') goto LAB_00c0b2e7;
      FUN_0167eea0(auStack_48,"ClientIpAddress");
      cVar3 = FUN_0167e580();
      if (cVar3 == '\0') goto LAB_00c0b2e7;
      uStack_80 = 0;
      uStack_7c = 0xf;
      auStack_90[0] = 0;
      uStack_8._0_1_ = 6;
      FUN_01681580(&uStack_40,auStack_90);
      uStack_14 = 7;
      FUN_005507b0();
    }
    else {
LAB_00c0b2e7:
      if (DAT_01d681e0 == '\0') {
        (**(code **)(*param_1 + 0xd0))();
      }
      else {
        (**(code **)(*(int *)param_1[0x20] + 0x2c))();
      }
      uStack_30 = 0;
      uStack_2c = 0xf;
      uStack_40 = uStack_40 & 0xffffff00;
      uStack_14 = 7;
    }
    FUN_0167ec40();
    FUN_005507b0();
    uStack_60 = uStack_40;
    uStack_40 = uStack_40 & 0xffffff00;
    uStack_5c = uStack_3c;
    uStack_58 = uStack_38;
    uStack_54 = uStack_34;
    uStack_50 = CONCAT44(uStack_2c,uStack_30);
    uStack_30 = 0;
    uStack_2c = 0xf;
    FUN_005507b0();
    uStack_8._0_1_ = 3;
    FUN_005507b0();
    FUN_0054ef60(param_3 + 0x470);
    uStack_14 = 0xf;
    uStack_8._0_1_ = 7;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if (((int)uStack_50 == 0) || (iStack_98 == 0)) {
      uStack_8._0_1_ = uVar2;
      if (DAT_01d681e0 == '\0') {
        (**(code **)(*param_1 + 0xa4))();
      }
      else {
        puVar6 = (undefined4 *)FUN_0054db20();
        (**(code **)*puVar6)();
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Empty parameter value");
    }
    uVar5 = FUN_010771d0(auStack_78,uStack_1c,&uStack_60,auStack_a8);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_00551230(uVar5);
    FUN_005507b0();
    FUN_005507b0();
  }
  else {
    puVar6 = (undefined4 *)FUN_01076fa0(auStack_78);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (param_2 != puVar6) {
      puVar1 = puVar6 + 4;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_005542c0(puVar6,*puVar1);
    }
  }
  FUN_005507b0();
LAB_00c0b40f:
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar4 = param_4[1] + -1;
    param_4[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar4 = param_4[2] + -1;
      param_4[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27200 ; VA 0x00c0b480 ; FUN_00c0b480 */

undefined4 __fastcall FUN_00c0b480(int param_1)

{
  return *(undefined4 *)(param_1 + 0x78);
}



/* FUNCTION 27201 ; VA 0x00c0b490 ; FUN_00c0b490 */

void __thiscall FUN_00c0b490(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  bool bVar3;
  bool bVar4;
  undefined *puVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  undefined4 *puVar9;
  int iVar10;
  uint in_stack_00000028;
  char *pcStack_64;
  undefined4 uStack_60;
  undefined uStack_5c;
  undefined4 uStack_54;
  undefined *puStack_50;
  undefined4 *puStack_4c;
  undefined *puStack_48;
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018058c8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  piStack_20 = (int *)0x0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_1c = param_1;
  puVar5 = &stack0xffffffbc;
  if (*param_2 == 0) {
LAB_00c0b50e:
    puStack_14 = puVar5;
    piStack_20 = (int *)0x0;
    puVar9 = &uStack_24;
    iStack_18 = 0;
    bVar4 = false;
    bVar3 = true;
  }
  else {
    iVar10 = *(int *)(*param_2 + 0xc);
    puStack_48 = (undefined *)0xc0b4d3;
    ExceptionList = &pvStack_10;
    iVar6 = FUN_00913630();
    puVar5 = puStack_14;
    if ((uint)*(ushort *)(iVar6 + 0x1da) <
        (uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) goto LAB_00c0b50e;
    piStack_34 = (int *)param_2[1];
    iStack_18 = *param_2;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[1] = piStack_34[1] + 1;
      UNLOCK();
      piStack_34 = (int *)param_2[1];
    }
    bVar4 = true;
    bVar3 = false;
    puVar9 = &uStack_38;
  }
  piVar2 = (int *)puVar9[1];
  iStack_30 = iStack_18;
  piStack_2c = piVar2;
  *puVar9 = 0;
  puVar9[1] = 0;
  if ((bVar3) && (piStack_20 != (int *)0x0)) {
    LOCK();
    iVar10 = piStack_20[1] + -1;
    piStack_20[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      puStack_48 = (undefined *)0xc0b557;
      (**(code **)*piStack_20)();
      LOCK();
      iVar10 = piStack_20[2] + -1;
      piStack_20[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        puStack_48 = (undefined *)0xc0b568;
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  piVar7 = piStack_34;
  if ((bVar4) && (piStack_34 != (int *)0x0)) {
    LOCK();
    iVar10 = piStack_34[1] + -1;
    piStack_34[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      puStack_48 = (undefined *)0xc0b588;
      (**(code **)*piStack_34)();
      LOCK();
      piVar8 = piVar7 + 2;
      iVar10 = *piVar8 + -1;
      *piVar8 = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        puStack_48 = (undefined *)0xc0b598;
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  iVar10 = iStack_18;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_18 == 0) {
    uStack_60 = 0x19;
    puStack_4c = (undefined4 *)iStack_18;
    puStack_48 = (undefined *)0xf;
    pcStack_64 = "Instance was not a player";
    uStack_5c = 0;
    FUN_005542c0();
    uStack_60 = 0xc0b5c8;
    FUN_005e65e0();
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar10 = piVar2[1] + -1;
      piVar2[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        puStack_48 = (undefined *)0xc0b5db;
        (**(code **)*piVar2)();
        LOCK();
        piVar7 = piVar2 + 2;
        iVar10 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar10 == 1) {
          puStack_48 = (undefined *)0xc0b5ea;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (param_3 != 0) {
      if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
        puStack_50 = &stack0x00000010;
        puStack_48 = (undefined *)0x2;
        uStack_54 = 0xc0b60b;
        puStack_4c = (undefined4 *)puStack_50;
        (**(code **)(param_3 & 0xfffffffe))();
      }
      param_3 = 0;
    }
    uStack_8 = 4;
    if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
       (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
      puStack_50 = &stack0x00000030;
      puStack_48 = (undefined *)0x2;
      uStack_54 = 0xc0b8be;
      puStack_4c = (undefined4 *)puStack_50;
      (**(code **)(in_stack_00000028 & 0xfffffffe))();
    }
    ExceptionList = pvStack_10;
    return;
  }
  puStack_48 = (undefined *)uStack_1c;
  puStack_4c = (undefined4 *)0xc0b629;
  iVar6 = FUN_008f7870();
  if ((iVar6 != 0) && (*(int *)(iVar6 + 0x4a0) == 1)) {
    piStack_20 = (int *)(iVar6 + 0xc);
    puStack_48 = &LAB_0055d570;
    puStack_4c = (undefined4 *)&DAT_01ea8a70;
    puStack_50 = (undefined *)0xc0b656;
    FUN_005789c0();
    puStack_48 = (undefined *)0xc0b65e;
    puStack_48 = (undefined *)FUN_00560c40();
    puStack_4c = (undefined4 *)0xc0b667;
    piVar7 = (int *)FUN_008aa140();
    if (*piVar7 == 0) {
      puStack_48 = (undefined *)0xc0b678;
      puStack_48 = (undefined *)FUN_00961660();
      puStack_4c = &uStack_38;
      puStack_50 = (undefined *)0xc0b685;
      piVar8 = (int *)FUN_008a9ba0();
      iVar10 = *piVar8;
      iVar6 = piVar8[1];
      *piVar8 = 0;
      piVar8[1] = 0;
      *piVar7 = iVar10;
      piVar8 = (int *)piVar7[1];
      piVar7[1] = iVar6;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar10 = piVar8[1] + -1;
        piVar8[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          puStack_48 = (undefined *)0xc0b6b5;
          (**(code **)*piVar8)();
          LOCK();
          iVar10 = piVar8[2] + -1;
          piVar8[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            puStack_48 = (undefined *)0xc0b6c5;
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      piVar8 = piStack_34;
      iVar10 = iStack_18;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_34[1] + -1;
        piStack_34[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          puStack_48 = (undefined *)0xc0b6de;
          (**(code **)*piStack_34)();
          LOCK();
          piVar1 = piVar8 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          iVar10 = iStack_18;
          if (iVar6 == 0) {
            puStack_48 = (undefined *)0xc0b6ee;
            (**(code **)(*piVar8 + 4))();
            iVar10 = iStack_18;
          }
        }
      }
    }
    if (*piVar7 == 0) {
      uStack_60 = 0x11;
      pcStack_64 = "Players not found";
    }
    else {
      if (*(int *)(*piVar7 + 0xf4) == iVar10) goto LAB_00c0b765;
      uStack_60 = 0x41;
      pcStack_64 = "This method cannot be called on the client for a non-local player";
    }
    puStack_4c = (undefined4 *)0x0;
    puStack_48 = (undefined *)0xf;
    uStack_5c = 0;
    FUN_005542c0();
    uStack_60 = 0xc0b724;
    FUN_005e65e0();
    puStack_48 = (undefined *)0xc0b72c;
    FUN_00550b30();
    puStack_48 = (undefined *)0xc0b734;
    FUN_00550990();
    puStack_48 = (undefined *)0xc0b73c;
    FUN_00550990();
    ExceptionList = pvStack_10;
    return;
  }
LAB_00c0b765:
  uStack_8._0_1_ = 5;
  if (DAT_01d665a0 == '\0') {
    FUN_0054f510(&stack0x00000028);
    uStack_8._0_1_ = 7;
    FUN_0054f510(&param_3);
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_00c0b8e0(iVar10,piVar2);
    FUN_00c0b846();
    return;
  }
  piStack_20 = (int *)&pcStack_64;
  FUN_0054f510(&stack0x00000028);
  uStack_8._0_1_ = 6;
  FUN_0054f510(&param_3);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar2[1] = piVar2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00c0a7e0(iVar10,piVar2);
  FUN_00c0b846();
  return;
}



/* FUNCTION 27202 ; VA 0x00c0b816 ; Catch@00c0b816 */

undefined * Catch_00c0b816(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  undefined auStack_18 [24];
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x24) + 4))();
  FUN_01675640(auStack_18,"Failed to get policy info: %s",uVar1);
  FUN_005e65e0();
  return &DAT_00c0b840;
}



/* FUNCTION 27203 ; VA 0x00c0b846 ; FUN_00c0b846 */

void FUN_00c0b846(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int unaff_EBP;
  int *unaff_ESI;
  int unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 2;
  if (unaff_ESI != (int *)0x0) {
    LOCK();
    iVar3 = unaff_ESI[1] + unaff_EDI;
    unaff_ESI[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*unaff_ESI)();
      LOCK();
      piVar1 = unaff_ESI + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + unaff_EDI;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*unaff_ESI + 4))();
      }
    }
  }
  uVar2 = *(uint *)(unaff_EBP + 0xc);
  *(undefined *)(unaff_EBP + -4) = 9;
  if (uVar2 != 0) {
    if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uVar2 & 0xfffffffe))(unaff_EBP + 0x14,unaff_EBP + 0x14,2);
    }
    *(undefined4 *)(unaff_EBP + 0xc) = 0;
  }
  *(undefined4 *)(unaff_EBP + -4) = 10;
  uVar2 = *(uint *)(unaff_EBP + 0x2c);
  if (((uVar2 != 0) && ((uVar2 & 1) == 0)) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uVar2 & 0xfffffffe))(unaff_EBP + 0x34,unaff_EBP + 0x34,2);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 27204 ; VA 0x00c0b8e0 ; FUN_00c0b8e0 */

void FUN_00c0b8e0(int param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 *param_8,ulonglong param_9,
                 uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,int param_15,undefined8 param_16)

{
  int *piVar1;
  undefined4 uVar2;
  uint *puVar3;
  undefined *puVar4;
  int iVar5;
  int *piVar6;
  uint auStack_80 [2];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 *puStack_6c;
  ulonglong uStack_68;
  uint auStack_60 [2];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  undefined8 uStack_48;
  undefined8 uStack_34;
  int iStack_2c;
  int *piStack_28;
  undefined *puStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805910;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc0;
  piVar6 = *(int **)(param_1 + 0x48c);
  ExceptionList = &pvStack_10;
  if (piVar6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = *(int **)(param_1 + 0x48c);
  }
  uStack_34._0_4_ = *(int *)(param_1 + 0x488);
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  uStack_34._4_4_ = piVar6;
  if ((int)uStack_34 == 0) {
    puVar4 = &stack0xffffffc0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      puVar4 = &stack0xffffffc0;
      if (iVar5 == 0) {
        uStack_48 = CONCAT44(0xc0ba2b,(undefined4)uStack_48);
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        puVar4 = puStack_14;
        if (iVar5 == 0) {
          uStack_48 = CONCAT44(0xc0ba3b,(undefined4)uStack_48);
          (**(code **)(*piVar6 + 4))();
          puVar4 = puStack_14;
        }
      }
    }
    puStack_14 = puVar4;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    piStack_1c = param_2;
    iStack_2c = param_1;
    piStack_28 = param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    uStack_48 = CONCAT44(0xc0ba6a,(undefined4)uStack_48);
    uStack_34 = FUN_00928340();
    uStack_48 = CONCAT44(&uStack_34,0xc0ba7c);
    iVar5 = FUN_00c0a260();
    piVar6 = piStack_1c;
    iStack_20 = *(int *)(iVar5 + 0x10);
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_48 = CONCAT44(0xc0ba98,(undefined4)uStack_48);
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_48 = CONCAT44(0xc0baa8,(undefined4)uStack_48);
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    puStack_24 = (undefined *)auStack_60;
    piStack_28 = (int *)auStack_60;
    uStack_8._0_1_ = 7;
    piStack_1c = (int *)piStack_18[0x22];
    auStack_60[0] = 0;
    puVar3 = auStack_60;
    if (param_10 != 0) {
      auStack_60[0] = param_10;
      if ((param_10 & 1) == 0) {
        uStack_68 = ZEXT48(&uStack_58);
        puStack_6c = &param_12;
        uStack_70 = 0xc0bafc;
        (**(code **)(param_10 & 0xfffffffe))();
        puVar3 = (uint *)puStack_24;
      }
      else {
        uStack_58 = param_12;
        uStack_54 = param_13;
        uStack_50 = param_14;
        puStack_4c = (undefined4 *)param_15;
        uStack_48 = param_16;
        puVar3 = auStack_60;
      }
    }
    puStack_24 = (undefined *)puVar3;
    piStack_28 = (int *)auStack_80;
    uStack_8._0_1_ = 8;
    auStack_80[0] = 0;
    puVar3 = auStack_80;
    if (param_3 != 0) {
      auStack_80[0] = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_78,0);
        puVar3 = (uint *)piStack_28;
      }
      else {
        uStack_78 = param_5;
        uStack_74 = param_6;
        uStack_70 = param_7;
        puStack_6c = param_8;
        uStack_68 = param_9;
        puVar3 = auStack_80;
      }
    }
    piStack_28 = (int *)puVar3;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00c0d6b0(param_1,param_2);
    uVar2 = DAT_01d68160;
    uStack_8 = 2;
    if (iStack_20 == 0) {
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      puStack_4c = (undefined4 *)param_1;
      uStack_48 = CONCAT44(uVar2,param_2);
      uStack_50 = 0xc0bbbd;
      FUN_00c0e4f0();
      if (DAT_01d681e0 == '\0') {
        uStack_48 = CONCAT44(0xc0bbdd,(undefined4)uStack_48);
        (**(code **)(*piStack_18 + 0xcc))();
      }
      else {
        uStack_48 = CONCAT44(0xc0bbd1,(undefined4)uStack_48);
        (**(code **)(*(int *)piStack_18[0x20] + 0x28))();
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar5 = param_2[1] + -1;
      param_2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_48 = CONCAT44(0xc0bbf3,(undefined4)uStack_48);
        (**(code **)*param_2)();
        LOCK();
        piVar6 = param_2 + 2;
        iVar5 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          uStack_48 = CONCAT44(0xc0bc02,(undefined4)uStack_48);
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    if (((param_3 != 0) && ((param_3 & 1) == 0)) &&
       (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_4c = &param_5;
      uStack_48 = CONCAT44(2,puStack_4c);
      uStack_50 = 0xc0bc23;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    uStack_8 = 0xb;
  }
  else {
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
    }
    uStack_48 = CONCAT44(piVar6,(int)uStack_34);
    puStack_4c = (undefined4 *)0xc0b963;
    puStack_14 = &stack0xffffffc0;
    FUN_0096e3d0();
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_48 = CONCAT44(0xc0b97b,(undefined4)uStack_48);
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_48 = CONCAT44(0xc0b98b,(undefined4)uStack_48);
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar5 = param_2[1] + -1;
      param_2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_48 = CONCAT44(0xc0b9a1,(undefined4)uStack_48);
        (**(code **)*param_2)();
        LOCK();
        piVar6 = param_2 + 2;
        iVar5 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          uStack_48 = CONCAT44(0xc0b9b0,(undefined4)uStack_48);
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (((param_3 != 0) && ((param_3 & 1) == 0)) &&
       (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_4c = &param_5;
      uStack_48 = CONCAT44(2,puStack_4c);
      uStack_50 = 0xc0b9d1;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    uStack_8 = 5;
  }
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_4c = &param_12;
    uStack_48 = CONCAT44(2,puStack_4c);
    uStack_50 = 0xc0b9ff;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27205 ; VA 0x00c0bc39 ; Catch@00c0bc39 */

void Catch_00c0bc39(void)

{
  int *piVar1;
  int unaff_EBP;
  
  if (DAT_01d681e0 == '\0') {
    piVar1 = (int *)(*(int *)(unaff_EBP + -0x14) + 0x90);
    *piVar1 = *piVar1 + 1;
  }
  else {
    piVar1 = (int *)FUN_0054db20();
    (**(code **)(*piVar1 + 0x40))();
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("GetPolicyInfoForPlayerAsync is called too many times");
}



/* FUNCTION 27206 ; VA 0x00c0bc70 ; FUN_00c0bc70 */

undefined4 * __thiscall FUN_00c0bc70(int *param_1,undefined4 *param_2)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined8 uStack_2c;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805930;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa0;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  iVar1 = FUN_008f7870(param_1);
  if ((iVar1 != 0) && (*(int *)(iVar1 + 0x4a0) != 1)) {
    *param_2 = 0;
    param_2[1] = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  uStack_2c = 0xf00000000;
  uStack_3c = uStack_3c & 0xffffff00;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_0153ef20(auStack_24);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(&DAT_01d681e8);
  puVar2 = (uint *)FUN_01541e00(auStack_54);
  if (&uStack_3c != puVar2) {
    FUN_005507b0();
    uStack_3c = *puVar2;
    uStack_38 = puVar2[1];
    uStack_34 = puVar2[2];
    uStack_30 = puVar2[3];
    uStack_2c = *(undefined8 *)(puVar2 + 4);
    puVar2[4] = 0;
    puVar2[5] = 0xf;
    *(undefined *)puVar2 = 0;
  }
  if (0xf < uStack_40) {
    uVar4 = uStack_40 + 1;
    uVar3 = auStack_54[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_54[0] - 4);
      uVar4 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_20[1] + -1;
    piStack_20[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar1 = piStack_20[2] + -1;
      piStack_20[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  uStack_8 = 0;
  if ((int)uStack_2c == 0) {
    if (DAT_01d681e0 == '\0') {
      (**(code **)(*param_1 + 0xdc))();
    }
    else {
      (**(code **)(*(int *)param_1[0x20] + 0x38))();
    }
    *param_2 = 0;
    param_2[1] = 0;
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_2;
  }
  uStack_8 = 4;
  FUN_00c0d480(param_2,&uStack_3c);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27207 ; VA 0x00c0be42 ; Catch_All@00c0be42 */

undefined * Catch_All_00c0be42(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  FUN_0086f2f0(2,"Failed to parse stored policy info response.");
  if (DAT_01d681e0 == '\0') {
    (**(code **)(**(int **)(unaff_EBP + -0x14) + 0xb8))();
  }
  else {
    (**(code **)(**(int **)(*(int *)(unaff_EBP + -0x14) + 0x80) + 0x14))();
  }
  puVar1 = *(undefined4 **)(unaff_EBP + 8);
  *puVar1 = 0;
  puVar1[1] = 0;
  return &LAB_00c0be8b;
}



/* FUNCTION 27208 ; VA 0x00c0bea9 ; Catch_All@00c0bea9 */

undefined * Catch_All_00c0bea9(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  if (DAT_01d681e0 == '\0') {
    (**(code **)(**(int **)(unaff_EBP + -0x14) + 0xd8))();
  }
  else {
    (**(code **)(**(int **)(*(int *)(unaff_EBP + -0x14) + 0x80) + 0x34))();
  }
  puVar1 = *(undefined4 **)(unaff_EBP + 8);
  *puVar1 = 0;
  puVar1[1] = 0;
  return &LAB_00c0be8b;
}



/* FUNCTION 27209 ; VA 0x00c0bef0 ; FUN_00c0bef0 */

void __thiscall FUN_00c0bef0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c0ea70();
  *param_3 = uVar3;
  iVar4 = FUN_00c0eb20();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 27210 ; VA 0x00c0bf50 ; FUN_00c0bf50 */

int __thiscall
FUN_00c0bf50(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint *puVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  uint uStack_4c;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined8 uStack_28;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805968;
  pvStack_10 = ExceptionList;
  iStack_14 = param_1 + 4;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_28 = FUN_00928340();
  iVar4 = FUN_00c0a260(&uStack_28);
  if (*(int *)(iVar4 + 0x10) == 0) {
    FUN_0054db20();
    uVar7 = FUN_00928340();
    uStack_28 = uVar7;
    FUN_00c0adf0(&uStack_28);
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Player doesn\'t have any queued callbacks");
  }
  while( true ) {
    puVar5 = (uint *)FUN_008765a0();
    uStack_4c = 0;
    uVar3 = *puVar5;
    if (uVar3 != 0) {
      uStack_4c = uVar3;
      if ((uVar3 & 1) == 0) {
        (**(code **)(uVar3 & 0xfffffffe))(puVar5 + 2,&uStack_44,0);
      }
      else {
        uStack_44 = puVar5[2];
        uStack_40 = puVar5[3];
        uStack_3c = puVar5[4];
        uStack_38 = puVar5[5];
        uStack_34 = puVar5[6];
        uStack_30 = puVar5[7];
      }
    }
    FUN_008c3510();
    piVar1 = (int *)(iVar4 + 0x10);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      *(undefined4 *)(iVar4 + 0xc) = 0;
    }
    else {
      *(int *)(iVar4 + 0xc) = *(int *)(iVar4 + 0xc) + 1;
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    uStack_20 = param_4;
    piStack_1c = param_5;
    uStack_8._0_1_ = 3;
    if (uStack_4c == 0) break;
    uStack_20 = 0;
    piStack_1c = (int *)0x0;
    (**(code **)((uStack_4c & 0xfffffffe) + 4))(&uStack_44,param_4,param_5);
    uStack_8._0_1_ = 5;
    if (((uStack_4c != 0) && ((uStack_4c & 1) == 0)) &&
       (*(code **)(uStack_4c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_4c & 0xfffffffe))(&uStack_44,&uStack_44,2);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (*(int *)(iVar4 + 0x10) == 0) {
      uVar7 = FUN_00928340();
      uStack_28 = uVar7;
      iVar4 = FUN_00c0adf0(&uStack_28);
      if (param_3 != (int *)0x0) {
        LOCK();
        piVar1 = param_3 + 1;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*param_3)();
          LOCK();
          piVar1 = param_3 + 2;
          iVar2 = *piVar1;
          iVar4 = *piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            iVar4 = (**(code **)(*param_3 + 4))();
          }
        }
      }
      if (param_5 != (int *)0x0) {
        LOCK();
        piVar1 = param_5 + 1;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar4 = (**(code **)*param_5)();
          LOCK();
          piVar1 = param_5 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            iVar4 = (**(code **)(*param_5 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar4;
    }
  }
  uVar6 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar6);
}



/* FUNCTION 27211 ; VA 0x00c0c140 ; FUN_00c0c140 */

int __thiscall FUN_00c0c140(int param_1,undefined4 param_2,int *param_3,uint *param_4)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint *puVar5;
  uint uVar6;
  undefined8 uVar7;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_24;
  int iStack_1c;
  uint uStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018059a8;
  pvStack_10 = ExceptionList;
  iStack_1c = param_1 + 4;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_24 = FUN_00928340();
  iVar3 = FUN_00c0a260();
  if (*(int *)(iVar3 + 0x10) == 0) {
    FUN_0054db20();
    uVar7 = FUN_00928340();
    uStack_24 = uVar7;
    FUN_00c0adf0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  do {
    iVar4 = FUN_008765a0();
    uStack_60 = 0;
    uVar6 = *(uint *)(iVar4 + 0x20);
    if (uVar6 != 0) {
      uStack_60 = uVar6;
      if ((uVar6 & 1) == 0) {
        (**(code **)(uVar6 & 0xfffffffe))(iVar4 + 0x28,&uStack_58,0);
      }
      else {
        uStack_58 = *(undefined4 *)(iVar4 + 0x28);
        uStack_54 = *(undefined4 *)(iVar4 + 0x2c);
        uStack_50 = *(undefined4 *)(iVar4 + 0x30);
        uStack_4c = *(undefined4 *)(iVar4 + 0x34);
        uStack_48 = *(undefined8 *)(iVar4 + 0x38);
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_008c3510();
    uVar6 = in_stack_0000001c;
    piVar1 = (int *)(iVar3 + 0x10);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      *(undefined4 *)(iVar3 + 0xc) = 0;
    }
    else {
      *(int *)(iVar3 + 0xc) = *(int *)(iVar3 + 0xc) + 1;
    }
    puStack_14 = (uint *)&param_4;
    if (0xf < in_stack_00000020) {
      puStack_14 = param_4;
    }
    uStack_30 = 0;
    uStack_2c = 0;
    if (in_stack_0000001c < 0x10) {
      uStack_40 = *puStack_14;
      uStack_3c = puStack_14[1];
      uStack_38 = puStack_14[2];
      uStack_34 = puStack_14[3];
      uStack_2c = 0xf;
    }
    else {
      uStack_18 = in_stack_0000001c | 0xf;
      if (0x7fffffff < uStack_18) {
        uStack_18 = 0x7fffffff;
      }
      if (uStack_18 + 1 < 0x1000) {
        if (uStack_18 == 0xffffffff) {
          uStack_40 = 0;
        }
        else {
          uStack_40 = FUN_01674e20();
        }
      }
      else {
        iVar4 = FUN_01674e20();
        if (iVar4 == 0) goto LAB_00c0c3e1;
        uStack_40 = iVar4 + 0x23U & 0xffffffe0;
        *(int *)(uStack_40 - 4) = iVar4;
      }
      FUN_0170c6f0(uStack_40,puStack_14,uVar6 + 1);
      uStack_2c = uStack_18;
    }
    uVar2 = uStack_40;
    uStack_30 = uVar6;
    uStack_8._0_1_ = 3;
    if (uStack_60 == 0) {
      FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0();
    }
    uStack_40 = uStack_40 & 0xffffff00;
    uStack_30 = 0;
    uStack_2c = 0xf;
    (**(code **)((uStack_60 & 0xfffffffe) + 4))(&uStack_58,uVar2,uStack_3c,uStack_38,uStack_34);
    uStack_8._0_1_ = 5;
    if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
       (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
  } while (*(int *)(iVar3 + 0x10) != 0);
  uVar7 = FUN_00928340();
  uStack_24 = uVar7;
  iVar3 = FUN_00c0adf0();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar6 = in_stack_00000020 + 1;
    puVar5 = param_4;
    if (0xfff < uVar6) {
      puVar5 = (uint *)param_4[-1];
      uVar6 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_4 + (-4 - (int)puVar5))) {
LAB_00c0c3e1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(puVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27212 ; VA 0x00c0c3f0 ; FUN_00c0c3f0 */

void FUN_00c0c3f0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018059c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00c0c140(*param_1,param_1[1]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27213 ; VA 0x00c0c472 ; Catch_All@00c0c472 */

undefined4 Catch_All_00c0c472(void)

{
  int unaff_EBP;
  
  FUN_0086f2f0(2,"Player doesn\'t have any queued callbacks");
  if (DAT_01d681e0 == '\0') {
    (**(code **)(**(int **)(unaff_EBP + -0x14) + 0xbc))();
  }
  else {
    (**(code **)(**(int **)(*(int *)(unaff_EBP + -0x14) + 0x80) + 0x18))();
  }
  return 0xc0c45f;
}



/* FUNCTION 27214 ; VA 0x00c0c4b0 ; FUN_00c0c4b0 */

int FUN_00c0c4b0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018059d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c0bf50(*param_1,param_1[1],param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27215 ; VA 0x00c0c579 ; Catch_All@00c0c579 */

undefined4 Catch_All_00c0c579(void)

{
  int unaff_EBP;
  
  FUN_0086f2f0(2,"Player doesn\'t have any queued callbacks");
  if (DAT_01d681e0 == '\0') {
    (**(code **)(**(int **)(unaff_EBP + -0x14) + 0xbc))();
  }
  else {
    (**(code **)(**(int **)(*(int *)(unaff_EBP + -0x14) + 0x80) + 0x18))();
  }
  return 0xc0c53e;
}



/* FUNCTION 27216 ; VA 0x00c0c5c0 ; FUN_00c0c5c0 */

void __fastcall FUN_00c0c5c0(int param_1)

{
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 1;
  return;
}



/* FUNCTION 27217 ; VA 0x00c0c5d0 ; FUN_00c0c5d0 */

int FUN_00c0c5d0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018057e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  piVar2 = piStack_14;
  if (iStack_18 != 0) {
    iVar4 = FUN_00587490(&iStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iStack_20 != 0) {
      iVar4 = *(int *)(param_1 + 0x10);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      iVar4 = FUN_00c0e4f0(iStack_20,piStack_1c,iVar4 + -1);
    }
    piVar2 = piStack_14;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar2 = piStack_1c + 2;
        iVar3 = *piVar2;
        iVar4 = *piVar2;
        *piVar2 = iVar3 + -1;
        UNLOCK();
        piVar2 = piStack_14;
        if (iVar3 + -1 == 0) {
          iVar4 = (**(code **)(*piStack_1c + 4))();
          piVar2 = piStack_14;
        }
      }
    }
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 27218 ; VA 0x00c0c6c0 ; FUN_00c0c6c0 */

void FUN_00c0c6c0(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c0a690(&param_2);
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27219 ; VA 0x00c0c730 ; FUN_00c0c730 */

int FUN_00c0c730(undefined4 param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_0000001c;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805a08;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8._0_1_ = 1;
  if (iStack_18 != 0) {
    iVar3 = FUN_00587490(&iStack_20);
    uStack_8._0_1_ = 2;
    if (iStack_20 != 0) {
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      iVar3 = FUN_00c0d290(iStack_20,piStack_1c,&param_2);
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000001c) {
    uVar4 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_2 + -4);
      uVar4 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27220 ; VA 0x00c0c850 ; FUN_00c0c850 */

void FUN_00c0c850(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5
                 ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
                 ulonglong param_10,uint param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint auStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e75c0;
  pvStack_10 = ExceptionList;
  param_1 = auStack_3c;
  uStack_8 = 2;
  auStack_3c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_3c;
  if (param_11 != 0) {
    auStack_3c[0] = param_11;
    if ((param_11 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_13;
      uStack_4c = 0xc0c8bb;
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))();
      puVar3 = param_1;
    }
    else {
      uStack_34 = param_13;
      uStack_30 = param_14;
      uStack_2c = param_15;
      puStack_28 = (undefined4 *)param_16;
      uStack_24 = param_17;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_3c;
    }
  }
  param_1 = puVar3;
  uStack_8._0_1_ = 3;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_54,0);
    }
    else {
      uStack_54 = param_6;
      uStack_50 = param_7;
      uStack_4c = param_8;
      puStack_48 = param_9;
      uStack_44 = param_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00c0b8e0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_24 = CONCAT44(0xc0c952,(undefined4)uStack_24);
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_24 = CONCAT44(0xc0c961,(undefined4)uStack_24);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_6;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xc0c982;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_13;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xc0c9b0;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27221 ; VA 0x00c0c9d0 ; FUN_00c0c9d0 */

uint FUN_00c0c9d0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c096f0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27222 ; VA 0x00c0c9f0 ; FUN_00c0c9f0 */

uint FUN_00c0c9f0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c096f0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27223 ; VA 0x00c0ca10 ; FUN_00c0ca10 */

void FUN_00c0ca10(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c0ea70();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27224 ; VA 0x00c0ca50 ; FUN_00c0ca50 */

void FUN_00c0ca50(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_00c09c10(param_1);
      if (param_3 != 1) {
        return;
      }
      piVar2 = *(int **)(param_1 + 0xc);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      piVar2 = *(int **)(param_1 + 4);
      if (piVar2 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00c0cb0f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
    if (param_3 == 2) {
      piVar2 = (int *)param_2[3];
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      piVar2 = (int *)param_2[1];
      if (piVar2 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00c0caa6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dfcf60);
      iVar4 = 0;
      if (iVar3 == 0) {
        iVar4 = param_1;
      }
      *param_2 = iVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_7f67f040f3272957711a5905d696ecc2>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 27225 ; VA 0x00c0cb30 ; FUN_00c0cb30 */

void FUN_00c0cb30(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      if (param_3 != 1) {
        return;
      }
      piVar3 = (int *)param_1[3];
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[2] + -1;
        piVar3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
      piVar3 = (int *)param_1[1];
      if (piVar3 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00c0cc34. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[2] + -1;
        piVar3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00c0cb86. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
    if (param_3 == 3) {
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dfcf98);
      piVar3 = (int *)0x0;
      if (iVar2 == 0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return;
    }
  }
  *param_2 = (int)&<lambda_81671265af70ac6949bf03171353973f>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 27226 ; VA 0x00c0cc50 ; FUN_00c0cc50 */

void FUN_00c0cc50(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_00c09c10(param_1);
      if (param_3 != 1) {
        return;
      }
      piVar2 = *(int **)(param_1 + 0xc);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      piVar2 = *(int **)(param_1 + 4);
      if (piVar2 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00c0cd0f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
    if (param_3 == 2) {
      piVar2 = (int *)param_2[3];
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      piVar2 = (int *)param_2[1];
      if (piVar2 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00c0cca6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dfcfd0);
      iVar4 = 0;
      if (iVar3 == 0) {
        iVar4 = param_1;
      }
      *param_2 = iVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_901751f6c7efc2d3248dcbd9b239471b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 27227 ; VA 0x00c0cd30 ; FUN_00c0cd30 */

void FUN_00c0cd30(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dfd008);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_ee2b07e64acddf70a96477303042beb3>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 27228 ; VA 0x00c0cd90 ; FUN_00c0cd90 */

int __thiscall
FUN_00c0cd90(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int param_7)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined8 uVar4;
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  int aiStack_30 [2];
  int iStack_28;
  int *piStack_24;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805a50;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffac;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  iVar3 = FUN_00587490();
  uStack_8._0_1_ = 2;
  if (iStack_28 == 0) {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_24 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piStack_24 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  else {
    if (param_7 < 1) {
      (**(code **)(*param_1 + 0xc0))(param_6,0);
      FUN_00587490();
      uStack_8._0_1_ = 5;
      if (iStack_1c != 0) {
        uVar4 = CONCAT44(aiStack_30,0xc0cf5e);
        FUN_00c0bc70();
        uStack_8._0_1_ = 6;
        if (aiStack_30[0] == 0) {
          uStack_8._0_1_ = 5;
          FUN_00550b30();
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("Http request failed to get policy info.",0x27);
          uStack_8._0_1_ = 7;
          FUN_00c0c3f0(&iStack_1c,auStack_48);
          FUN_005507b0();
        }
        else {
          FUN_00557fc0(aiStack_30);
          FUN_00c0c4b0(&iStack_1c,uVar4);
          FUN_00550b30();
        }
      }
      FUN_00550b30();
    }
    else {
      uStack_8._0_1_ = 3;
      if (DAT_01d681d0 != '\0') {
        if (DAT_01d681d8 == '\0') {
          (**(code **)(*param_1 + 0xc4))();
        }
        else {
          (**(code **)(*param_1 + 0xc0))(param_6,(DAT_01d68160 - param_7) + 1);
        }
      }
      iVar3 = FUN_008f7870();
      if (iVar3 != 0) {
        iVar3 = FUN_005cf2a0();
        if (iVar3 != 0) {
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[2] = param_3[2] + 1;
            UNLOCK();
          }
          if (param_5 != (int *)0x0) {
            LOCK();
            param_5[2] = param_5[2] + 1;
            UNLOCK();
          }
          FUN_00c095b0(param_2,param_3,param_4,param_5,param_7,0);
          FUN_009eef30();
        }
      }
    }
    iVar3 = FUN_00550b30();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27229 ; VA 0x00c0cf02 ; Catch@00c0cf02 */

undefined * Catch_00c0cf02(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_0086f2f0(2,"Http request failed to get policy info: %s",uVar1);
  return &DAT_00c0cf20;
}



/* FUNCTION 27230 ; VA 0x00c0d030 ; FUN_00c0d030 */

int __thiscall
FUN_00c0d030(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  code *pcVar6;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar5 = param_5;
  puStack_c = &LAB_01805a78;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  uStack_8 = 0;
  piStack_18 = param_1;
  if (param_5 < 1) {
    if (DAT_01d681e0 == '\0') {
      ExceptionList = &pvStack_10;
      (**(code **)(*param_1 + 0xc0))(param_4,0);
    }
    else {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffbc;
      (**(code **)(*(int *)param_1[0x20] + 0x1c))();
    }
    FUN_00c0bc70(&iStack_1c);
    piVar3 = piStack_18;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_1c == 0) {
      uStack_8._0_1_ = 0;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_18[1] + -1;
        piStack_18[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          iVar5 = piVar3[2] + -1;
          piVar3[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      FUN_005542c0("Http request failed to get policy info.",0x27);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_00c0c3f0(&param_2,auStack_38);
      iVar5 = FUN_005507b0();
      piVar2 = param_3;
    }
    else {
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      iVar5 = FUN_00c0c4b0(&param_2,iStack_1c,piStack_18);
      piVar2 = param_3;
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar4 = *piVar1;
        iVar5 = *piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar2 = piVar3 + 2;
          iVar4 = *piVar2;
          iVar5 = *piVar2;
          *piVar2 = iVar4 + -1;
          UNLOCK();
          piVar2 = param_3;
          if (iVar4 + -1 == 0) {
            iVar5 = (**(code **)(*piVar3 + 4))();
            piVar2 = param_3;
          }
        }
      }
    }
  }
  else {
    uStack_8 = 1;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffbc;
    if (DAT_01d681d0 != '\0') {
      if (DAT_01d681d8 == '\0') {
        if (DAT_01d681e0 == '\0') {
          pcVar6 = *(code **)(*param_1 + 0xc4);
        }
        else {
          pcVar6 = *(code **)(*(int *)param_1[0x20] + 0x20);
        }
        ExceptionList = &pvStack_10;
        puStack_14 = &stack0xffffffbc;
        (*pcVar6)((DAT_01d68160 - param_5) + 1);
      }
      else if (DAT_01d681e0 == '\0') {
        ExceptionList = &pvStack_10;
        puStack_14 = &stack0xffffffbc;
        (**(code **)(*param_1 + 0xc0))(param_4,(DAT_01d68160 - param_5) + 1);
      }
      else {
        ExceptionList = &pvStack_10;
        puStack_14 = &stack0xffffffbc;
        (**(code **)(*(int *)param_1[0x20] + 0x1c))(param_4,(DAT_01d68160 - param_5) + 1);
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar5 = FUN_00c0e4f0(param_2,param_3,iVar5 + -1);
    piVar2 = param_3;
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar3 = piVar2 + 1;
    iVar4 = *piVar3;
    iVar5 = *piVar3;
    *piVar3 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      param_3 = piVar2;
      iVar5 = (**(code **)*piVar2)();
      LOCK();
      piVar3 = piVar2 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 27231 ; VA 0x00c0d12d ; Catch@00c0d12d */

undefined * Catch_00c0d12d(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_0086f2f0(2,"Http request failed to get policy info: %s",uVar1);
  return &DAT_00c0d14b;
}



/* FUNCTION 27232 ; VA 0x00c0d290 ; FUN_00c0d290 */

int FUN_00c0d290(undefined4 param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uVar4 = param_3;
  puStack_c = &LAB_01805aa8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c0d480(&uStack_20,param_3);
  _uStack_8 = CONCAT31(uStack_7,2);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  FUN_00934170(uStack_20,piStack_1c);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  FUN_00c0c4b0(&param_1,uStack_20,piStack_1c);
  iVar5 = FUN_00c0eb90(uVar4);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)(*piStack_1c + 4))();
        iVar5 = FUN_00c0d3ef();
        return iVar5;
      }
    }
  }
  piVar1 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 27233 ; VA 0x00c0d374 ; Catch_All@00c0d374 */

undefined * Catch_All_00c0d374(void)

{
  int *piVar1;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -0x24) = 0;
  *(undefined4 *)(unaff_EBP + -0x20) = 0xf;
  *(undefined *)(unaff_EBP + -0x34) = 0;
  FUN_005542c0("Failed to parse policy info response.",0x25);
  piVar1 = *(int **)(unaff_EBP + -0x14);
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_00c0c3f0(unaff_EBP + 8,unaff_EBP + -0x34);
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_005507b0();
  FUN_0086f2f0(2,"Failed to parse policy info response.");
  if (DAT_01d681e0 == '\0') {
    (**(code **)(*piVar1 + 0xb4))();
  }
  else {
    (**(code **)(*(int *)piVar1[0x20] + 0x10))();
  }
  return &DAT_00c0d3ec;
}



/* FUNCTION 27234 ; VA 0x00c0d3ef ; FUN_00c0d3ef */

void FUN_00c0d3ef(void)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int unaff_EBP;
  int unaff_ESI;
  
  piVar2 = *(int **)(unaff_EBP + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + unaff_ESI;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + unaff_ESI;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 27235 ; VA 0x00c0d430 ; FUN_00c0d430 */

void __thiscall FUN_00c0d430(int *param_1,int param_2,int param_3)

{
  FUN_008a4210(param_2,param_3);
  if ((param_2 != 0) && (param_3 == 0)) {
    if (DAT_01d681e0 != '\0') {
      (**(code **)(*(int *)param_1[0x20] + 4))();
      return;
    }
    (**(code **)(*param_1 + 0xa8))();
  }
  return;
}



/* FUNCTION 27236 ; VA 0x00c0d480 ; FUN_00c0d480 */

undefined4 FUN_00c0d480(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  char *****pppppcVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  undefined4 *puVar9;
  int iStack_118;
  int iStack_114;
  int aiStack_110 [50];
  int iStack_48;
  int *piStack_44;
  undefined auStack_40 [4];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  char ****appppcStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805ae3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_118 = FUN_00888530();
  iStack_114 = 0;
  uStack_8 = 0;
  FUN_0098ef90(param_2,&iStack_118,0);
  iVar6 = iStack_118;
  iVar3 = FUN_008881d0();
  if (iVar6 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar4 = aiStack_110;
  if (iStack_114 == 0) {
    piVar4 = (int *)0x0;
  }
  piVar8 = (int *)piVar4[1];
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)piVar4[1];
  }
  iVar6 = *piVar4;
  auStack_40[0] = 0;
  iStack_48 = iVar6;
  piStack_44 = piVar8;
  uStack_3c = FUN_00588320(0xb);
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_8._0_1_ = 2;
  if (*(int *)(iVar6 + 8) == 0) {
    puVar9 = (undefined4 *)0x0;
  }
  else {
    puVar9 = *(undefined4 **)(*(int *)(iVar6 + 0x14) + *(int *)(iVar6 + 4) * 4);
  }
  do {
    if (puVar9 == (undefined4 *)0x0) {
      FUN_006369a0(param_1,auStack_40);
      FUN_0056d080();
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar6 = piVar8[1] + -1;
        piVar8[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          piVar4 = piVar8 + 2;
          iVar6 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      uStack_8 = 4;
      if (iStack_114 != 0) {
        (**(code **)(iStack_114 + 8))(aiStack_110);
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_0054ef60(puVar9 + 2);
    pppppcVar5 = appppcStack_28;
    if (0xf < uStack_14) {
      pppppcVar5 = (char *****)appppcStack_28[0];
    }
    cVar2 = FUN_017256a7((int)*(char *)pppppcVar5);
    pppppcVar5 = appppcStack_28;
    if (0xf < uStack_14) {
      pppppcVar5 = (char *****)appppcStack_28[0];
    }
    *(char *)pppppcVar5 = cVar2;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar6 = FUN_005c4c00(appppcStack_28);
    piVar4 = puVar9 + 9;
    piVar1 = (int *)(iVar6 + 0x1c);
    *(undefined4 *)(iVar6 + 0x18) = puVar9[8];
    if (piVar4 != piVar1) {
      if (*piVar1 != 0) {
        (**(code **)(*piVar1 + 8))(iVar6 + 0x20);
        *piVar1 = 0;
      }
      if ((undefined4 *)*piVar4 != (undefined4 *)0x0) {
        (**(code **)*piVar4)(puVar9 + 10,iVar6 + 0x20);
        *piVar1 = *piVar4;
      }
    }
    uStack_8._0_1_ = 2;
    if (0xf < uStack_14) {
      uVar7 = uStack_14 + 1;
      pppppcVar5 = (char *****)appppcStack_28[0];
      if (0xfff < uVar7) {
        pppppcVar5 = (char *****)appppcStack_28[0][-1];
        uVar7 = uStack_14 + 0x24;
        if ((char *)0x1f < (char *)((int)appppcStack_28[0] + (-4 - (int)pppppcVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppcVar5,uVar7);
    }
    puVar9 = (undefined4 *)*puVar9;
  } while( true );
}



/* FUNCTION 27237 ; VA 0x00c0d6b0 ; FUN_00c0d6b0 */

void __thiscall
FUN_00c0d6b0(int param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint auStack_60 [2];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  uint auStack_40 [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined8 uStack_20;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805b20;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uStack_20 = FUN_00928340();
  iVar4 = FUN_00c0a260(&uStack_20);
  iStack_14 = iVar4;
  if (*(uint *)(param_1 + 0x24) <= *(uint *)(iVar4 + 0x10)) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Callback queue exceeded");
  }
  auStack_60[0] = 0;
  if (param_4 != 0) {
    auStack_60[0] = param_4;
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_58,0);
    }
    else {
      uStack_58 = param_6;
      uStack_54 = param_7;
      uStack_50 = param_8;
      uStack_4c = param_9;
      uStack_48 = param_10;
    }
  }
  uStack_8._0_1_ = 3;
  auStack_40[0] = 0;
  if (param_11 != 0) {
    auStack_40[0] = param_11;
    if ((param_11 & 1) == 0) {
      (**(code **)(param_11 & 0xfffffffe))(&param_13,&uStack_38,0);
    }
    else {
      uStack_38 = param_13;
      uStack_34 = param_14;
      uStack_30 = param_15;
      uStack_2c = param_16;
      uStack_28 = param_17;
    }
  }
  uVar7 = *(uint *)(iVar4 + 8);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uVar7 <= *(int *)(iVar4 + 0x10) + 1U) {
    FUN_006afce0(1);
    uVar7 = *(uint *)(iVar4 + 8);
  }
  uVar7 = uVar7 - 1 & *(uint *)(iVar4 + 0xc);
  *(uint *)(iVar4 + 0xc) = uVar7;
  iVar6 = *(int *)(iVar4 + 4);
  iVar2 = (*(int *)(iVar4 + 8) - 1U & *(int *)(iVar4 + 0x10) + uVar7) * 4;
  if (*(int *)(iVar2 + iVar6) == 0) {
    uVar5 = FUN_01674e20(0x40);
    *(undefined4 *)(iVar2 + *(int *)(iVar4 + 4)) = uVar5;
    iVar6 = *(int *)(iVar4 + 4);
  }
  puVar3 = *(undefined4 **)(iVar2 + iVar6);
  *puVar3 = 0;
  puStack_18 = puVar3;
  FUN_005880d0(auStack_60);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puVar3[8] = 0;
  FUN_005880d0(auStack_40);
  *(int *)(iStack_14 + 0x10) = *(int *)(iStack_14 + 0x10) + 1;
  FUN_008c3510();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar4 = param_3[1] + -1;
    param_3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  uStack_8 = 7;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_11 & 0xfffffffe))(&param_13,&param_13,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27238 ; VA 0x00c0d8b0 ; FUN_00c0d8b0 */

void __fastcall FUN_00c0d8b0(int param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uVar1 = *(undefined4 *)(param_1 + 0x90);
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_PlayerCallbackQueueExceededCount",0x2e);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,uVar1,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27239 ; VA 0x00c0d950 ; FUN_00c0d950 */

void __fastcall FUN_00c0d950(int param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uVar1 = *(undefined4 *)(param_1 + 4);
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_PlayerCallbackQueueExceededCount",0x2e);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,uVar1,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27240 ; VA 0x00c0d9f0 ; FUN_00c0d9f0 */

void FUN_00c0d9f0(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_PlayerNotHavingQueuedCallback",0x2b);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27241 ; VA 0x00c0da90 ; FUN_00c0da90 */

void FUN_00c0da90(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_GetStoredHttpResponseEmpty",0x28);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27242 ; VA 0x00c0db30 ; FUN_00c0db30 */

void FUN_00c0db30(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_GetStoredHttpResponseError",0x28);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27243 ; VA 0x00c0dbd0 ; FUN_00c0dbd0 */

void FUN_00c0dbd0(int param_1,int param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805b63;
  pvStack_10 = ExceptionList;
  if (param_2 < 1) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("PolicyService_HttpRequestFailure",0x20);
    uStack_8 = 3;
    FUN_008783f0(auStack_28,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar2 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
    if (*(int *)(param_1 + 0x10) != 0) {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 4;
      FUN_0151f950("HttpError",param_1);
      uVar1 = DAT_01d68168;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      FUN_005542c0("PolicyServiceFailure",0x14);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      FUN_01520d20(auStack_40,uVar1,0);
      FUN_005507b0();
      FUN_0151f7f0();
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675640(auStack_28,"PolicyService_HttpRequestFailure_%d_Attempt",param_2);
    uStack_8 = 0;
    FUN_008783f0(uVar1,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar2 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
    if (*(int *)(param_1 + 0x10) != 0) {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 1;
      FUN_0151f950("HttpError",param_1);
      FUN_0151f9c0("Retry",param_2);
      uVar1 = DAT_01d68170;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = auStack_28[0] & 0xffffff00;
      FUN_005542c0("PolicyServiceFailure",0x14);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_01520d20(auStack_28,uVar1,0);
      FUN_005507b0();
      FUN_0151f7f0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27244 ; VA 0x00c0de10 ; FUN_00c0de10 */

void FUN_00c0de10(undefined4 param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675640(aiStack_28,"PolicyService_HttpRequestFailure_%d_Attempt",param_1);
  uStack_8 = 0;
  FUN_008783f0(uVar1,1,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27245 ; VA 0x00c0dea0 ; FUN_00c0dea0 */

void FUN_00c0dea0(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_HttpRequestFailure",0x20);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27246 ; VA 0x00c0df40 ; FUN_00c0df40 */

uint FUN_00c0df40(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01679ce0();
  uVar2 = uVar1 / 10000;
  if ((int)(uVar1 % 10000) < DAT_01d68158) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("PolicyService_HttpRequestPolicyInfo",0x23);
    uStack_8 = 0;
    uVar2 = FUN_008783f0(auStack_28,1,0);
    if (0xf < uStack_14) {
      uVar2 = uStack_14 + 1;
      uVar1 = auStack_28[0];
      if (0xfff < uVar2) {
        uVar1 = *(uint *)(auStack_28[0] - 4);
        uVar2 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uVar2 = FUN_01674ea0(uVar1,uVar2);
    }
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 27247 ; VA 0x00c0dff0 ; FUN_00c0dff0 */

void FUN_00c0dff0(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_ParsingError_InvalidJson",0x26);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27248 ; VA 0x00c0e090 ; FUN_00c0e090 */

void FUN_00c0e090(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_ParsingError_InvalidStoredJson",0x2c);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27249 ; VA 0x00c0e130 ; FUN_00c0e130 */

void FUN_00c0e130(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_ParseOriginIpAddressFromGameSessionIdError",0x38);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}


