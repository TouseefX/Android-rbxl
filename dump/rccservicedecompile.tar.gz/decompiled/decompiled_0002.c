/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 500 ; VA 0x004914b0 ; FUN_004914b0 */

void FUN_004914b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00918370(FUN_00934910,0,s_SetSuperSafeChat_0211fa1c,s_value_0211ab70,1,uStack_10,0);
  FUN_016f3654(&LAB_01884490);
  return;
}



/* FUNCTION 501 ; VA 0x00491510 ; FUN_00491510 */

void FUN_00491510(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00918370(FUN_00934c50,0,s_SetUnder13_0211f9e4,s_value_0211ab70,6,uStack_10,0);
  FUN_016f3654(&LAB_018844b0);
  return;
}



/* FUNCTION 502 ; VA 0x00491570 ; FUN_00491570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00491570(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c76ba;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_0211d938;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,&DAT_0211d938);
  FUN_009cb820(uVar1,s_waitForDataReady_0211f7ec,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211d978 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::Player,bool___cdecl(void),0>::vftable;
  _DAT_0211d9b0 = FUN_009364f0;
  _DAT_0211d9b4 = 0;
  _DAT_0211d99c = FUN_0088daf0();
  FUN_016f3654(&LAB_018844d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 503 ; VA 0x00491610 ; FUN_00491610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00491610(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c771c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb820(uVar1,s_GetFriendsOnline_0211fc48,0,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_0211e858 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Player,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(int),1>
       ::vftable;
  _DAT_0211e890 = FUN_00926f10;
  _DAT_0211e894 = 0;
  DAT_0211e898 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0211e898 == (undefined4 *)0x0) {
    DAT_0211e898 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211e898 = 200;
  }
  uStack_8._0_1_ = 1;
  _DAT_0211e87c = FUN_008882f0();
  puVar3 = DAT_0211e898;
  if (DAT_0211e898 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c8c0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005c9cc0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(s_maxFriends_0211fc3c);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018844e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 504 ; VA 0x004917d0 ; FUN_004917d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004917d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c773a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_GetMouse_0211f864,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211da88 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>::
       vftable;
  _DAT_0211dac0 = FUN_009273f0;
  _DAT_0211dac4 = 0;
  _DAT_0211daac = FUN_0088cdc0();
  FUN_016f3654(&LAB_01884500);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 505 ; VA 0x00491870 ; FUN_00491870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00491870(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c779c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb820(uVar1,s_GetRankInGroup_0211fc5c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211e8a0 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::Player,int___cdecl(__int64),1>::vftable;
  _DAT_0211e8d8 = FUN_00927ac0;
  _DAT_0211e8dc = 0;
  DAT_0211e8e0 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211e8c4 = FUN_0088c8c0();
  puVar3 = DAT_0211e8e0;
  if (DAT_0211e8e0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088da50();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    iStack_ec = FUN_005c9e80();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(s_groupId_0211fc28);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01884510);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 506 ; VA 0x00491a20 ; FUN_00491a20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00491a20(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c77fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb820(uVar1,s_GetRoleInGroup_0211fc6c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211e8e8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Player,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(__int64),1>
       ::vftable;
  _DAT_0211e920 = FUN_00928010;
  _DAT_0211e924 = 0;
  DAT_0211e928 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211e90c = FUN_0088cb40();
  puVar3 = DAT_0211e928;
  if (DAT_0211e928 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088da50();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    iStack_ec = FUN_005c9e80();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(s_groupId_0211fc28);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01884530);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 507 ; VA 0x00491bd0 ; FUN_00491bd0 */

void FUN_00491bd0(void)

{
  FUN_009184f0(FUN_00929fd0,0,s_LoadBoolean_0211f88c,&DAT_0211f870,0,1,0);
  FUN_016f3654(&LAB_01884550);
  return;
}



/* FUNCTION 508 ; VA 0x00491c30 ; FUN_00491c30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00491c30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c781a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb820(uVar1,s_LoadCharacterBlocking_0211f9bc,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211e018 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::Player,void___cdecl(void),0>::vftable;
  _DAT_0211e050 = FUN_0092a0f0;
  _DAT_0211e054 = 0;
  _DAT_0211e03c = FUN_00888530();
  FUN_016f3654(&LAB_01884570);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 509 ; VA 0x00491cd0 ; FUN_00491cd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00491cd0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c783a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_LoadData_0211f790,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211d810 = RBX::Reflection::BoundFuncDesc<class_RBX::Player,void___cdecl(void),0>::vftable;
  _DAT_0211d848 = FUN_0092c090;
  _DAT_0211d84c = 0;
  _DAT_0211d834 = FUN_00888530();
  FUN_016f3654(&LAB_01884580);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 510 ; VA 0x00491d70 ; FUN_00491d70 */

void FUN_00491d70(void)

{
  FUN_00917b70(FUN_0092c4b0,0,s_LoadInstance_0211f8bc,&DAT_0211f870,0,1,0);
  FUN_016f3654(&LAB_01884590);
  return;
}



/* FUNCTION 511 ; VA 0x00491dd0 ; FUN_00491dd0 */

void FUN_00491dd0(void)

{
  FUN_00917cf0(FUN_0092c540,0,s_LoadNumber_0211f8a4,&DAT_0211f870,0,1,0);
  FUN_016f3654(&LAB_018845b0);
  return;
}



/* FUNCTION 512 ; VA 0x00491e30 ; FUN_00491e30 */

void FUN_00491e30(void)

{
  FUN_009179f0(FUN_0092c5d0,0,s_LoadString_0211f874,&DAT_0211f870,0,1,0);
  FUN_016f3654(&LAB_018845d0);
  return;
}



/* FUNCTION 513 ; VA 0x00491e90 ; FUN_00491e90 */

void FUN_00491e90(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009181d0(FUN_00930dc0,0,s_RequestFriendship_0211f808,s_player_0211f800,5,uStack_10,0);
  FUN_016f3654(&LAB_018845f0);
  return;
}



/* FUNCTION 514 ; VA 0x00491ef0 ; FUN_00491ef0 */

void FUN_00491ef0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009181d0(FUN_00931690,0,s_RevokeFriendship_0211f81c,s_player_0211f800,5,uStack_10,0);
  FUN_016f3654(&LAB_01884640);
  return;
}



/* FUNCTION 515 ; VA 0x00491f50 ; FUN_00491f50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00491f50(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c786e;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_SaveBoolean_0211f898,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0211dba0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),2>
       ::vftable;
  _DAT_0211dbd8 = FUN_00931e40;
  _DAT_0211dbdc = 0;
  _DAT_0211dbe0 = 0;
  DAT_0211dbe4 = 0;
  uStack_8 = 2;
  FUN_009218e0();
  FUN_016f3654(&LAB_01884690);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 516 ; VA 0x00492010 ; FUN_00492010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00492010(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c788a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_SaveData_0211f79c,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211d850 = RBX::Reflection::BoundFuncDesc<class_RBX::Player,void___cdecl(void),0>::vftable;
  _DAT_0211d888 = FUN_00931f00;
  _DAT_0211d88c = 0;
  _DAT_0211d874 = FUN_00888530();
  FUN_016f3654(&LAB_018846c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 517 ; VA 0x004920b0 ; FUN_004920b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004920b0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c78be;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_SaveInstance_0211f8cc,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0211dcc0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_0211dcf8 = FUN_009320a0;
  _DAT_0211dcfc = 0;
  _DAT_0211dd00 = 0;
  DAT_0211dd04 = 0;
  uStack_8 = 2;
  FUN_00921690();
  FUN_016f3654(&LAB_018846d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 518 ; VA 0x00492170 ; FUN_00492170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00492170(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c78ee;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_SaveNumber_0211f8b0,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0211dc30 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,double),2>
       ::vftable;
  _DAT_0211dc68 = FUN_009321a0;
  _DAT_0211dc6c = 0;
  _DAT_0211dc70 = 0;
  DAT_0211dc74 = 0;
  uStack_8 = 2;
  FUN_00921490();
  FUN_016f3654(&LAB_01884730);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 519 ; VA 0x00492230 ; FUN_00492230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00492230(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c791e;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_SaveString_0211f880,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0211db10 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0211db48 = FUN_00932270;
  _DAT_0211db4c = 0;
  _DAT_0211db50 = 0;
  _DAT_0211db54 = 0;
  uStack_8 = 2;
  FUN_00921260();
  FUN_016f3654(&LAB_01884760);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 520 ; VA 0x004922f0 ; FUN_004922f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004922f0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c797c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb790(uVar1,s_AddToBlockList_02120180,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211f638 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),1>
       ::vftable;
  _DAT_0211f670 = FUN_0091d250;
  _DAT_0211f674 = 0;
  DAT_0211f678 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211f65c = FUN_00888530();
  if (DAT_0211f678 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1420(DAT_0211f678);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_008882f0();
  uVar3 = FUN_0086e3d0(s_userIds_02120178);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_01884780);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 521 ; VA 0x00492470 ; FUN_00492470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00492470(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c79ae;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_UpdatePlayerBlocked_02120198,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0211f680 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Player,void___cdecl(__int64,bool),2>::vftable;
  _DAT_0211f6b8 = FUN_00936300;
  _DAT_0211f6bc = 0;
  DAT_0211f6c0 = 0;
  DAT_0211f6c4 = 0;
  uStack_8 = 2;
  FUN_00921d30();
  FUN_016f3654(&LAB_018847d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 522 ; VA 0x00492530 ; FUN_00492530 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00492530(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c79ca;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb820(uVar1,s_WaitForDataReady_0211f7d8,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211d938 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::Player,bool___cdecl(void),0>::vftable;
  _DAT_0211d970 = FUN_009364f0;
  _DAT_0211d974 = 0;
  _DAT_0211d95c = FUN_0088daf0();
  FUN_016f3654(&LAB_01884810);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 523 ; VA 0x00492610 ; FUN_00492610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00492610(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c79ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb820(uVar1,s_LoadCharacter_0211f970,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211df90 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::Player,void___cdecl(void),0>::vftable;
  _DAT_0211dfc8 = FUN_0092cb30;
  _DAT_0211dfcc = 0;
  _DAT_0211dfb4 = FUN_00888530();
  FUN_016f3654(&LAB_018848e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 524 ; VA 0x004926b0 ; FUN_004926b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004926b0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7a4c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00913630();
  FUN_009cb820(uVar2,s_LoadCharacterWithHumanoidDescrip_0211f994,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211dfd0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_0211e008 = FUN_0092cd50;
  _DAT_0211e00c = 0;
  DAT_0211e010 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211dff4 = FUN_00888530();
  puVar4 = DAT_0211e010;
  if (DAT_0211e010 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_humanoidDescription_0211f980);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_018848f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 525 ; VA 0x00492880 ; FUN_00492880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00492880(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7a7e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,&DAT_0211f968,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0211df48 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Player,void___cdecl(class_G3D::Vector3,bool),2>::
       vftable;
  _DAT_0211df80 = FUN_0092e710;
  _DAT_0211df84 = 0;
  DAT_0211df88 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  DAT_0211df8c = (undefined *)FUN_01674e20(1);
  if (DAT_0211df8c == (undefined *)0x0) {
    DAT_0211df8c = (undefined *)0x0;
  }
  else {
    *DAT_0211df8c = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00921b00();
  FUN_016f3654(&LAB_01884940);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 526 ; VA 0x00492960 ; FUN_00492960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00492960(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7aa4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_005f3000();
  uVar3 = FUN_00913630();
  FUN_009ca670(uVar3,uVar2,s_ChatMode_0211fd44,&DAT_021197d4,uStack_24,0,0,0x15,5,5,1);
  uStack_8 = 0;
  DAT_0211eb40 = RBX::Reflection::EnumPropDescriptor<class_RBX::Player,enum_RBX::Player::ChatMode>::
                 vftable;
  _DAT_0211eb74 = uVar2;
  DAT_0211eb78 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_0211eb78 == (undefined4 *)0x0) {
    DAT_0211eb78 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211eb78 =
         RBX::Reflection::PropDescriptor<class_RBX::Player,enum_RBX::Player::ChatMode>::
         GetImpl<enum_RBX::Player::ChatMode_(__thiscall_RBX::Player::*)(void)const_>::vftable;
    DAT_0211eb78[2] = FUN_00926be0;
    DAT_0211eb78[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211eb7c = FUN_005f3000();
  cVar1 = (*(code *)DAT_0211eb40[3])();
  if (cVar1 != '\0') {
    _DAT_0211eb64 = _DAT_0211eb64 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211eb40[2])();
  if (cVar1 != '\0') {
    _DAT_0211eb64 = _DAT_0211eb64 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884a80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 527 ; VA 0x00492a70 ; FUN_00492a70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00492a70(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7ac4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_005f3120();
  uVar3 = FUN_00913630();
  FUN_009ca670(uVar3,uVar2,s_ChatPrivacyMode_0211fd50,&DAT_021197d4,uStack_24,0,0,2,5,5,1);
  uStack_8 = 0;
  DAT_0211eb80 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Player,enum_RBX::Player::ChatPrivacyMode>::vftable;
  _DAT_0211ebb4 = uVar2;
  DAT_0211ebb8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211ebb8 == (undefined4 *)0x0) {
    DAT_0211ebb8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211ebb8 =
         RBX::Reflection::PropDescriptor<class_RBX::Player,enum_RBX::Player::ChatPrivacyMode>::
         GetSetImpl<enum_RBX::Player::ChatPrivacyMode_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(enum_RBX::Player::ChatPrivacyMode)>
         ::vftable;
    DAT_0211ebb8[2] = &LAB_0061ebe0;
    DAT_0211ebb8[3] = 0;
    DAT_0211ebb8[4] = FUN_009330e0;
    DAT_0211ebb8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211ebbc = FUN_005f3120();
  cVar1 = (*(code *)DAT_0211eb80[3])();
  if (cVar1 != '\0') {
    _DAT_0211eba4 = _DAT_0211eba4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211eb80[2])();
  if (cVar1 != '\0') {
    _DAT_0211eba4 = _DAT_0211eba4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884aa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 528 ; VA 0x00492b90 ; FUN_00492b90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00492b90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7aec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00913630();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Player,class_G3D::CoordinateFrame>::
              GetSetImpl<class_G3D::CoordinateFrame_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(class_G3D::CoordinateFrame_const&)>
              ::vftable;
    puVar3[2] = FUN_00926c60;
    puVar3[3] = 0;
    puVar3[4] = FUN_00933220;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,s_CloudEditCameraCoordinateFrame_02120078,&DAT_021197d4,uStack_24,0,0,2,0
               ,0,0);
  DAT_0211f420 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211f454 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211f444 = _DAT_0211f444 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211f420[2])();
    if (cVar1 != '\0') {
      _DAT_0211f444 = _DAT_0211f444 & 0xfffffff3;
    }
  }
  DAT_0211f420 = RBX::Reflection::PropDescriptor<class_RBX::Player,class_G3D::CoordinateFrame>::
                 vftable;
  FUN_016f3654(&LAB_01884ac0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 529 ; VA 0x00493120 ; FUN_00493120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00493120(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7b14;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935b10();
  uVar3 = FUN_00913630();
  FUN_009ca670(uVar3,uVar2,s_CameraMode_0211ff3c,s_Camera_0211ff34,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0211f0d8 = RBX::Reflection::EnumPropDescriptor<class_RBX::Player,enum_RBX::Camera::CameraMode>
                 ::vftable;
  _DAT_0211f10c = uVar2;
  DAT_0211f110 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211f110 == (undefined4 *)0x0) {
    DAT_0211f110 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211f110 =
         RBX::Reflection::PropDescriptor<class_RBX::Player,enum_RBX::Camera::CameraMode>::
         GetSetImpl<enum_RBX::Camera::CameraMode_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(enum_RBX::Camera::CameraMode)>
         ::vftable;
    DAT_0211f110[2] = &LAB_00926b80;
    DAT_0211f110[3] = 0;
    DAT_0211f110[4] = FUN_00932670;
    DAT_0211f110[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211f114 = FUN_00935b10();
  cVar1 = (*(code *)DAT_0211f0d8[3])();
  if (cVar1 != '\0') {
    _DAT_0211f0fc = _DAT_0211f0fc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211f0d8[2])();
  if (cVar1 != '\0') {
    _DAT_0211f0fc = _DAT_0211f0fc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884ba0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 530 ; VA 0x00493240 ; FUN_00493240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00493240(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7b34;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935ba0();
  uVar3 = FUN_00913630();
  FUN_009ca670(uVar3,uVar2,s_DevCameraOcclusionMode_0211ffb8,s_Camera_0211ff34,uStack_24,0,0,0x1f,0,
               0,1);
  uStack_8 = 0;
  DAT_0211f240 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Player,enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode>
                 ::vftable;
  _DAT_0211f274 = uVar2;
  DAT_0211f278 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211f278 == (undefined4 *)0x0) {
    DAT_0211f278 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211f278 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Player,enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode>
         ::
         GetSetImpl<enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode)>
         ::vftable;
    DAT_0211f278[2] = &LAB_00926d80;
    DAT_0211f278[3] = 0;
    DAT_0211f278[4] = FUN_00933380;
    DAT_0211f278[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211f27c = FUN_00935ba0();
  cVar1 = (*(code *)DAT_0211f240[3])();
  if (cVar1 != '\0') {
    _DAT_0211f264 = _DAT_0211f264 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211f240[2])();
  if (cVar1 != '\0') {
    _DAT_0211f264 = _DAT_0211f264 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884bc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 531 ; VA 0x00493360 ; FUN_00493360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00493360(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7b54;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935cc0();
  uVar3 = FUN_00913630();
  FUN_009ca670(uVar3,uVar2,s_DevComputerMovementMode_0211fff0,s_Control_0211ffd0,uStack_24,0,0,0x1f,
               0,0,1);
  uStack_8 = 0;
  DAT_0211f2c0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Player,enum_RBX::StarterPlayerService::DeveloperComputerMovementMode>
                 ::vftable;
  _DAT_0211f2f4 = uVar2;
  DAT_0211f2f8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211f2f8 == (undefined4 *)0x0) {
    DAT_0211f2f8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211f2f8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Player,enum_RBX::StarterPlayerService::DeveloperComputerMovementMode>
         ::
         GetSetImpl<enum_RBX::StarterPlayerService::DeveloperComputerMovementMode_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(enum_RBX::StarterPlayerService::DeveloperComputerMovementMode)>
         ::vftable;
    DAT_0211f2f8[2] = &LAB_00926db0;
    DAT_0211f2f8[3] = 0;
    DAT_0211f2f8[4] = FUN_00933520;
    DAT_0211f2f8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211f2fc = FUN_00935cc0();
  cVar1 = (*(code *)DAT_0211f2c0[3])();
  if (cVar1 != '\0') {
    _DAT_0211f2e4 = _DAT_0211f2e4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211f2c0[2])();
  if (cVar1 != '\0') {
    _DAT_0211f2e4 = _DAT_0211f2e4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884be0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 532 ; VA 0x00493480 ; FUN_00493480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00493480(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7b74;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935de0();
  uVar3 = FUN_00913630();
  FUN_009ca670(uVar3,uVar2,s_DevTouchMovementMode_0211ffd8,s_Control_0211ffd0,uStack_24,0,0,0x1f,0,0
               ,1);
  uStack_8 = 0;
  DAT_0211f280 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Player,enum_RBX::StarterPlayerService::DeveloperTouchMovementMode>
                 ::vftable;
  _DAT_0211f2b4 = uVar2;
  DAT_0211f2b8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211f2b8 == (undefined4 *)0x0) {
    DAT_0211f2b8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211f2b8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Player,enum_RBX::StarterPlayerService::DeveloperTouchMovementMode>
         ::
         GetSetImpl<enum_RBX::StarterPlayerService::DeveloperTouchMovementMode_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(enum_RBX::StarterPlayerService::DeveloperTouchMovementMode)>
         ::vftable;
    DAT_0211f2b8[2] = &LAB_00926de0;
    DAT_0211f2b8[3] = 0;
    DAT_0211f2b8[4] = FUN_00933790;
    DAT_0211f2b8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211f2bc = FUN_00935de0();
  cVar1 = (*(code *)DAT_0211f280[3])();
  if (cVar1 != '\0') {
    _DAT_0211f2a4 = _DAT_0211f2a4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211f280[2])();
  if (cVar1 != '\0') {
    _DAT_0211f2a4 = _DAT_0211f2a4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884c00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 533 ; VA 0x00493720 ; FUN_00493720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00493720(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7ba0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1f5c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee1f5c,uVar3,0,0,0x1f);
    if (DAT_01ee1f5c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee1f38 = RBX::Reflection::RefType<class_RBX::SpawnLocation*>::vftable;
      FUN_016f3654(&LAB_01884fa0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee1f5c);
    }
  }
  uVar2 = FUN_00913630();
  FUN_009ca670(uVar2,&DAT_01ee1f38,s_RespawnLocation_0211fb4c,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,
               0,0,0);
  uStack_8 = 1;
  DAT_0211e4a8 = RBX::Reflection::RefPropDescriptor<class_RBX::Player,class_RBX::SpawnLocation>::
                 vftable;
  _DAT_0211e4dc =
       RBX::Reflection::RefPropDescriptor<class_RBX::Player,class_RBX::SpawnLocation>::vftable;
  DAT_0211e4e0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211e4e0 == (undefined4 *)0x0) {
    DAT_0211e4e0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211e4e0 =
         RBX::Reflection::PropDescriptor<class_RBX::Player,class_RBX::SpawnLocation*>::
         GetSetImpl<class_RBX::SpawnLocation*_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(class_RBX::SpawnLocation*)>
         ::vftable;
    DAT_0211e4e0[2] = FUN_00926cb0;
    DAT_0211e4e0[3] = 0;
    DAT_0211e4e0[4] = FUN_00934690;
    DAT_0211e4e0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0211e4a8[3])();
  if (cVar1 != '\0') {
    _DAT_0211e4cc = _DAT_0211e4cc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211e4a8[2])();
  if (cVar1 != '\0') {
    _DAT_0211e4cc = _DAT_0211e4cc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884c60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 534 ; VA 0x00494000 ; FUN_00494000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00494000(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7bc4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935c30();
  uVar3 = FUN_00913630();
  FUN_009ca670(uVar3,uVar2,s_DevComputerCameraMode_0211ff8c,s_Camera_0211ff34,uStack_24,0,0,0x1f,0,0
               ,1);
  uStack_8 = 0;
  DAT_0211f1c8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Player,enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode>
                 ::vftable;
  _DAT_0211f1fc = uVar2;
  DAT_0211f200 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211f200 == (undefined4 *)0x0) {
    DAT_0211f200 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211f200 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Player,enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode>
         ::
         GetSetImpl<enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode)>
         ::vftable;
    DAT_0211f200[2] = &LAB_00926da0;
    DAT_0211f200[3] = 0;
    DAT_0211f200[4] = FUN_00933450;
    DAT_0211f200[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211f204 = FUN_00935c30();
  cVar1 = (*(code *)DAT_0211f1c8[3])();
  if (cVar1 != '\0') {
    _DAT_0211f1ec = _DAT_0211f1ec & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211f1c8[2])();
  if (cVar1 != '\0') {
    _DAT_0211f1ec = _DAT_0211f1ec & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884dc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 535 ; VA 0x004941e0 ; FUN_004941e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004941e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7be4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935d50();
  uVar3 = FUN_00913630();
  FUN_009ca670(uVar3,uVar2,s_DevTouchCameraMode_0211ff78,s_Camera_0211ff34,uStack_24,0,0,0x1f,0,0,1)
  ;
  uStack_8 = 0;
  DAT_0211f188 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Player,enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode>
                 ::vftable;
  _DAT_0211f1bc = uVar2;
  DAT_0211f1c0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211f1c0 == (undefined4 *)0x0) {
    DAT_0211f1c0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211f1c0 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Player,enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode>
         ::
         GetSetImpl<enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode)>
         ::vftable;
    DAT_0211f1c0[2] = &LAB_00926dd0;
    DAT_0211f1c0[3] = 0;
    DAT_0211f1c0[4] = FUN_009336c0;
    DAT_0211f1c0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211f1c4 = FUN_00935d50();
  cVar1 = (*(code *)DAT_0211f188[3])();
  if (cVar1 != '\0') {
    _DAT_0211f1ac = _DAT_0211f1ac & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211f188[2])();
  if (cVar1 != '\0') {
    _DAT_0211f1ac = _DAT_0211f1ac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884e00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 536 ; VA 0x00494470 ; FUN_00494470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00494470(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7c04;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_005f32d0();
  uVar3 = FUN_00913630();
  FUN_009ca670(uVar3,uVar2,s_MembershipType_0211fd94,&DAT_021197d4,uStack_24,0,0,0x15,0,0,1);
  uStack_8 = 0;
  DAT_0211eca0 = RBX::Reflection::EnumPropDescriptor<class_RBX::Player,enum_RBX::MembershipType>::
                 vftable;
  _DAT_0211ecd4 = uVar2;
  DAT_0211ecd8 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_0211ecd8 == (undefined4 *)0x0) {
    DAT_0211ecd8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211ecd8 =
         RBX::Reflection::PropDescriptor<class_RBX::Player,enum_RBX::MembershipType>::
         GetImpl<enum_RBX::MembershipType_(__thiscall_RBX::Player::*)(void)const_>::vftable;
    DAT_0211ecd8[2] = FUN_005d48b0;
    DAT_0211ecd8[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211ecdc = FUN_005f32d0();
  cVar1 = (*(code *)DAT_0211eca0[3])();
  if (cVar1 != '\0') {
    _DAT_0211ecc4 = _DAT_0211ecc4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211eca0[2])();
  if (cVar1 != '\0') {
    _DAT_0211ecc4 = _DAT_0211ecc4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884e60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 537 ; VA 0x00494580 ; FUN_00494580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00494580(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7c24;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_005f32d0();
  uVar3 = FUN_00913630();
  FUN_009ca670(uVar3,uVar2,s_MembershipTypeReplicate_0211fda4,&DAT_021197d4,uStack_24,0,0,2,0,0,1);
  uStack_8 = 0;
  DAT_0211ece0 = RBX::Reflection::EnumPropDescriptor<class_RBX::Player,enum_RBX::MembershipType>::
                 vftable;
  _DAT_0211ed14 = uVar2;
  DAT_0211ed18 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211ed18 == (undefined4 *)0x0) {
    DAT_0211ed18 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211ed18 =
         RBX::Reflection::PropDescriptor<class_RBX::Player,enum_RBX::MembershipType>::
         GetSetImpl<enum_RBX::MembershipType_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(enum_RBX::MembershipType)>
         ::vftable;
    DAT_0211ed18[2] = FUN_005d48b0;
    DAT_0211ed18[3] = 0;
    DAT_0211ed18[4] = FUN_00933eb0;
    DAT_0211ed18[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211ed1c = FUN_005f32d0();
  cVar1 = (*(code *)DAT_0211ece0[3])();
  if (cVar1 != '\0') {
    _DAT_0211ed04 = _DAT_0211ed04 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211ece0[2])();
  if (cVar1 != '\0') {
    _DAT_0211ed04 = _DAT_0211ed04 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01884e80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 538 ; VA 0x00494760 ; FUN_00494760 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00494760(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7c4c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00913630();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Player,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(class_RBX::BrickColor)>
              ::vftable;
    puVar3[2] = FUN_0065b450;
    puVar3[3] = 0;
    puVar3[4] = FUN_00934a60;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,s_TeamColor_0211fd68,&DAT_0211fd60,uStack_24,0,0,0x1f,0,0,0);
  DAT_0211ebc0 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211ebf4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211ebe4 = _DAT_0211ebe4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211ebc0[2])();
    if (cVar1 != '\0') {
      _DAT_0211ebe4 = _DAT_0211ebe4 & 0xfffffff3;
    }
  }
  DAT_0211ebc0 = RBX::Reflection::PropDescriptor<class_RBX::Player,class_RBX::BrickColor>::vftable;
  FUN_016f3654(&LAB_01884ec0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 539 ; VA 0x00494a00 ; FUN_00494a00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00494a00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7c6a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_RemoveCharacter_0211f9d4,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211e058 = RBX::Reflection::BoundFuncDesc<class_RBX::Player,void___cdecl(void),0>::vftable;
  _DAT_0211e090 = FUN_009303a0;
  _DAT_0211e094 = 0;
  _DAT_0211e07c = FUN_00888530();
  FUN_016f3654(&LAB_01884f80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 540 ; VA 0x00494bc0 ; FUN_00494bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00494bc0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9963;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00937b90();
  FUN_009cb970(uVar1,s_VideoRecordingChangeRequest_0212034c,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02120284 = 0x9c;
  iStack_8 = 0;
  _DAT_02120250 =
       RBX::Reflection::
       EventDesc<class_RBX::GameSettings,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::GameSettings::*>
       ::vftable;
  FUN_0086e3d0(s_recording_02120340);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02120278 = uStack_1c;
  _DAT_0212027c = uStack_18;
  _DAT_02120280 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02120250 =
       RBX::Reflection::
       EventDesc<class_RBX::GameSettings,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::GameSettings::*>
       ::vftable;
  FUN_016f3654(&LAB_01885000);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 541 ; VA 0x00494d10 ; FUN_00494d10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00494d10(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9996;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00937b90();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_VideoCaptureEnabled_02120370,s_Video_02120368,uStack_24,0,0,0x1f,0,0,0)
  ;
  DAT_021202bc = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02120288 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::GameSettings>::vftable;
    puVar5[1] = &DAT_02120288;
    puVar5[2] = 0xa0;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_021202bc != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021202bc;
    DAT_021202bc = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_021202bc;
  }
  DAT_021202bc = puVar5;
  cVar2 = (*(code *)DAT_02120288[3])();
  if (cVar2 != '\0') {
    _DAT_021202ac = _DAT_021202ac & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02120288[2])();
  if (cVar2 != '\0') {
    _DAT_021202ac = _DAT_021202ac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01885010);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 542 ; VA 0x00494e40 ; FUN_00494e40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00494e40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c99bc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00937b90();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GameSettings,bool>::
              GetSetImpl<bool_(__thiscall_RBX::GameSettings::*)(void)const_,void_(__thiscall_RBX::GameSettings::*)(bool)>
              ::vftable;
    puVar3[2] = FUN_00926d60;
    puVar3[3] = 0;
    puVar3[4] = FUN_00938750;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_VideoRecording_02120384,s_Video_02120368,uStack_24,0,0,0x15,5,6,0);
  DAT_021202c0 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021202f4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021202e4 = _DAT_021202e4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021202c0[2])();
    if (cVar1 != '\0') {
      _DAT_021202e4 = _DAT_021202e4 & 0xfffffff3;
    }
  }
  DAT_021202c0 = RBX::Reflection::PropDescriptor<class_RBX::GameSettings,bool>::vftable;
  FUN_016f3654(&LAB_01885030);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 543 ; VA 0x00495150 ; FUN_00495150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00495150(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017caf66;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0093f0f0();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_ScriptsDisabled_02120590,s_State_0211d030,uStack_24,0,0,0x15,3,3,0);
  DAT_0212045c = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02120428 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::ScriptContext>::vftable
    ;
    puVar5[1] = &DAT_02120428;
    puVar5[2] = 0x180;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_0212045c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0212045c;
    DAT_0212045c = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_0212045c;
  }
  DAT_0212045c = puVar5;
  cVar2 = (*(code *)DAT_02120428[3])();
  if (cVar2 != '\0') {
    _DAT_0212044c = _DAT_0212044c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02120428[2])();
  if (cVar2 != '\0') {
    _DAT_0212044c = _DAT_0212044c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018851e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 544 ; VA 0x004956f0 ; FUN_004956f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004956f0(void)

{
  undefined4 uVar1;
  undefined auStack_2b4 [648];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cafa9;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0093f0f0();
  FUN_009cb970(uVar1,s_Error_021205c8,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021204dc = 0x294;
  iStack_8 = 0;
  _DAT_021204a8 =
       RBX::Reflection::
       EventDesc<class_RBX::ScriptContext,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::ScriptContext::*>
       ::vftable;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_stackTrace_021205bc);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_script_021205b4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b4,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_021204d0 = uStack_1c;
  _DAT_021204d4 = uStack_18;
  _DAT_021204d8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b4,0xd8,3,FUN_00688b10);
  _DAT_021204a8 =
       RBX::Reflection::
       EventDesc<class_RBX::ScriptContext,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::ScriptContext::*>
       ::vftable;
  FUN_016f3654(&LAB_01885260);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 545 ; VA 0x00495890 ; FUN_00495890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00495890(void)

{
  undefined4 extraout_var;
  
  FUN_00944410(0x298,s_ErrorDetailed_021205e8,s_message_02119b14,s_stackTrace_021205bc,
               s_script_021205b4,s_details_021205e0,s_securityLevel_021205d0,5,0,0,0);
  _DAT_021204e0 =
       RBX::Reflection::
       EventDesc<class_RBX::ScriptContext,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int)>_RBX::ScriptContext::*>
       ::vftable;
  FUN_016f3654(&LAB_01885270,extraout_var);
  return;
}



/* FUNCTION 546 ; VA 0x00495900 ; FUN_00495900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00495900(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cafde;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0093f0f0(uVar2,0);
  FUN_009cb790(uVar1,s_AddCoreScriptLocal_02120558,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02120398 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ScriptContext,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_021203d0 = FUN_0094a3b0;
  _DAT_021203d4 = 0;
  _DAT_021203d8 = 0;
  DAT_021203dc = 0;
  uStack_8 = 2;
  FUN_00921690();
  FUN_016f3654(&LAB_01885280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 547 ; VA 0x004959c0 ; FUN_004959c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004959c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017caffa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0093f0f0(uVar2,0);
  FUN_009cb790(uVar1,s_GetCoverageStats_021205f8,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02120518 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ScriptContext,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02120550 = FUN_0094fc40;
  _DAT_02120554 = 0;
  _DAT_0212053c = FUN_008882f0();
  FUN_016f3654(&LAB_018852e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 548 ; VA 0x00495a60 ; FUN_00495a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00495a60(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb05c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0093f0f0();
  FUN_009cb790(uVar2,s_LoadInternalModules_0212057c,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021203e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ScriptContext,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_02120418 = FUN_00951950;
  _DAT_0212041c = 0;
  DAT_02120420 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02120404 = FUN_00888530();
  puVar4 = DAT_02120420;
  if (DAT_02120420 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_loadIntoParent_0212056c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_018852f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 549 ; VA 0x00495c30 ; FUN_00495c30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00495c30(void)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined8 auStack_e8 [25];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb0bc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0093f0f0();
  FUN_009cb790(uVar2,s_SetTimeout_021205a8,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02120460 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ScriptContext,void___cdecl(double),1>::vftable;
  _DAT_02120498 = FUN_0095c840;
  _DAT_0212049c = 0;
  DAT_021204a0 = (undefined8 *)0x0;
  uStack_8 = 1;
  _DAT_02120484 = FUN_00888530();
  puVar1 = DAT_021204a0;
  if (DAT_021204a0 == (undefined8 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088ca00();
    puStack_ec = (undefined *)0x0;
    auStack_e8[0] = *puVar1;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead488) {
      FUN_016f3809(&DAT_01ead488);
      if (DAT_01ead488 == -1) {
        _DAT_01ead47c = FUN_00619e80;
        _DAT_01ead480 = FUN_00619e80;
        DAT_01ead484 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead488);
      }
    }
    puStack_ec = &DAT_01ead47c;
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088ca00();
  uVar3 = FUN_0086e3d0(s_seconds_021205a0);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01885340);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 550 ; VA 0x00495e40 ; FUN_00495e40 */

void __fastcall FUN_00495e40(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_00943750();
  DAT_01ee2aa4 = uVar1;
  FUN_0093dc90(uVar1,param_1);
  _guard_check_icall(&DAT_01ee2aa4,uVar1,uVar1);
  FUN_016f3654(FUN_01885360);
  return;
}



/* FUNCTION 551 ; VA 0x00495ea0 ; FUN_00495ea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00495ea0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cb0e4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  DAT_01ee2aec = FUN_005cb2b0(0,0);
  _DAT_01ee2af4 = 0;
  _DAT_01ee2af8 = 0;
  _DAT_01ee2afc = 0;
  uStack_8 = 1;
  _DAT_01ee2ae8 = 0x3f800000;
  FUN_005cb500(8);
  FUN_016f3654(&LAB_01885470);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 552 ; VA 0x00495f30 ; FUN_00495f30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00495f30(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce61e;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb970(uVar1,s_CloudEditApplyEditsMessage_02121868,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212124c = 0x32c;
  iStack_8 = 0;
  _DAT_02121218 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Players::*>
       ::vftable;
  FUN_0086e3d0(s_playerName_0212185c);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_scriptName_02121850);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02121240 = uStack_1c;
  _DAT_02121244 = uStack_18;
  _DAT_02121248 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_02121218 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Players,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Players::*>
       ::vftable;
  _DAT_02121250 = 1;
  _DAT_02121254 = 0;
  FUN_016f3654(&LAB_01885480);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 553 ; VA 0x004960c0 ; FUN_004960c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004960c0(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce65e;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb970(uVar1,s_CloudEditServerMessage_02121838,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212120c = 0x31c;
  iStack_8 = 0;
  _DAT_021211d8 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(enum_RBX::MessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(enum_RBX::MessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(enum_RBX::MessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Players::*>
       ::vftable;
  FUN_0086e3d0(s_messageType_0212182c);
  thunk_FUN_0086f380();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02121200 = uStack_1c;
  _DAT_02121204 = uStack_18;
  _DAT_02121208 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_021211d8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Players,void___cdecl(enum_RBX::MessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(enum_RBX::MessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(enum_RBX::MessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Players::*>
       ::vftable;
  _DAT_02121210 = 1;
  _DAT_02121214 = 0;
  FUN_016f3654(&LAB_01885490);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 554 ; VA 0x004962a0 ; FUN_004962a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004962a0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce693;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb970(uVar1,s_RequestCloudEditKick_021217b4,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212110c = 0x2e4;
  iStack_8 = 0;
  _DAT_021210d8 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(__int64),class_rbx::remote_signal<void___cdecl(__int64)>,class_rbx::remote_signal<void___cdecl(__int64)>_RBX::Players::*>
       ::vftable;
  FUN_0086e3d0(s_playerId_02119448);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02121100 = uStack_1c;
  _DAT_02121104 = uStack_18;
  _DAT_02121108 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_021210d8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Players,void___cdecl(__int64),class_rbx::remote_signal<void___cdecl(__int64)>,class_rbx::remote_signal<void___cdecl(__int64)>_RBX::Players::*>
       ::vftable;
  _DAT_02121110 = 0;
  _DAT_02121114 = 0;
  FUN_016f3654(&LAB_018854b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 555 ; VA 0x00496c30 ; FUN_00496c30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00496c30(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce6aa;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02120978;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580(uVar2,&DAT_02120978);
  FUN_009cb790(uVar1,s_getPlayers_0212152c,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02120a68 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Players,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02120aa0 = FUN_005d57a0;
  _DAT_02120aa4 = 0;
  _DAT_02120a8c = FUN_0088cc80();
  FUN_016f3654(&LAB_01885700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 556 ; VA 0x00496cd0 ; FUN_00496cd0 */

void FUN_00496cd0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00967750(FUN_00988f90,0,s_getPlayerFromCharacter_02121578,s_character_0211fe0c,0,
               CONCAT44(&DAT_02120ae8,uStack_10),0);
  FUN_016f3654(&LAB_01885710);
  return;
}



/* FUNCTION 557 ; VA 0x00496d30 ; FUN_00496d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00496d30(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce6ca;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02120978;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580(uVar2,&DAT_02120978);
  FUN_009cb790(uVar1,s_players_02121524,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02120a28 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Players,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02120a60 = FUN_005d57a0;
  _DAT_02120a64 = 0;
  _DAT_02120a4c = FUN_0088cc80();
  FUN_016f3654(&LAB_01885760);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 558 ; VA 0x00496dd0 ; FUN_00496dd0 */

void FUN_00496dd0(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,PTR_DAT_02120610,0x10);
  FUN_0095f080(s_localPlayer_0212145c,&DAT_021197d4,&LAB_0097f520,0,0,*puVar1,puVar1[1],puVar1[2],
               puVar1[3],0);
  FUN_016f3654(&LAB_01885770);
  return;
}



/* FUNCTION 559 ; VA 0x00496e30 ; FUN_00496e30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00496e30(void)

{
  undefined4 uVar1;
  undefined auStack_2b4 [648];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce719;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb970(uVar1,s_FriendRequestEvent_021215a4,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02120bf4 = 0x29c;
  iStack_8 = 0;
  _DAT_02120bc0 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendEventType),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendEventType)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendEventType)>_RBX::Players::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_friendRequestEvent_02121590);
  thunk_FUN_00bfa7a0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b4,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02120be8 = uStack_1c;
  _DAT_02120bec = uStack_18;
  _DAT_02120bf0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b4,0xd8,3,FUN_00688b10);
  _DAT_02120bc0 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendEventType),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendEventType)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendEventType)>_RBX::Players::*>
       ::vftable;
  FUN_016f3654(&LAB_01885790);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 560 ; VA 0x00496fd0 ; FUN_00496fd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00496fd0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce753;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb970(uVar1,s_GameAnnounce_021214d4,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02120924 = 0x2c4;
  iStack_8 = 0;
  _DAT_021208f0 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Players::*>
       ::vftable;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02120918 = uStack_1c;
  _DAT_0212091c = uStack_18;
  _DAT_02120920 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021208f0 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Players::*>
       ::vftable;
  FUN_016f3654(&LAB_018857a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 561 ; VA 0x00497120 ; FUN_00497120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497120(void)

{
  undefined4 extraout_var;
  
  FUN_00967d70(0x2c8,s_PlayerConnecting_021215d4,s_player_0211f800,3,0,0,0);
  _DAT_02120c68 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Players::*>
       ::vftable;
  FUN_016f3654(&LAB_018857b0,extraout_var);
  return;
}



/* FUNCTION 562 ; VA 0x00497170 ; FUN_00497170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497170(void)

{
  undefined4 extraout_var;
  
  FUN_00967d70(0x2cc,s_PlayerDisconnecting_021215e8,s_player_0211f800,3,0,0,0);
  _DAT_02120ca0 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Players::*>
       ::vftable;
  FUN_016f3654(&LAB_018857c0,extraout_var);
  return;
}



/* FUNCTION 563 ; VA 0x004971c0 ; FUN_004971c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004971c0(void)

{
  undefined4 extraout_var;
  
  FUN_00967d70(0x2e0,s_PlayerMembershipChanged_0212160c,s_player_0211f800,0,0,0,0);
  _DAT_02120d10 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Players::*>
       ::vftable;
  FUN_016f3654(&LAB_018857d0,extraout_var);
  return;
}



/* FUNCTION 564 ; VA 0x00497210 ; FUN_00497210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497210(void)

{
  undefined4 extraout_var;
  
  FUN_00967d70(0x2d0,s_PlayerRejoining_021215fc,s_player_0211f800,3,0,0,0);
  _DAT_02120cd8 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Players::*>
       ::vftable;
  FUN_016f3654(&LAB_018857e0,extraout_var);
  return;
}



/* FUNCTION 565 ; VA 0x00497260 ; FUN_00497260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497260(void)

{
  undefined4 extraout_var;
  
  FUN_00967d70(0x2ac,s_PlayerRemoving_021215c4,s_player_0211f800,0,0,0,0);
  _DAT_02120c30 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Players::*>
       ::vftable;
  FUN_016f3654(&LAB_018857f0,extraout_var);
  return;
}



/* FUNCTION 566 ; VA 0x004972b0 ; FUN_004972b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004972b0(void)

{
  undefined4 uVar1;
  undefined auStack_38c [864];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce7a4;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb970(uVar1,s_PlayerChatted_021214c4,3,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021208ec = 0x2c0;
  iStack_8 = 0;
  _DAT_021208b8 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(enum_RBX::Players::PlayerChatType,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(enum_RBX::Players::PlayerChatType,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(enum_RBX::Players::PlayerChatType,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::Players::*>
       ::vftable;
  FUN_0086e3d0(s_chatType_021214b8);
  thunk_FUN_005f33f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(s_targetPlayer_021214a8);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_38c,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  _DAT_021208e0 = uStack_1c;
  _DAT_021208e4 = uStack_18;
  _DAT_021208e8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_38c,0xd8,4,FUN_00688b10);
  _DAT_021208b8 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(enum_RBX::Players::PlayerChatType,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(enum_RBX::Players::PlayerChatType,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(enum_RBX::Players::PlayerChatType,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::Players::*>
       ::vftable;
  FUN_016f3654(&LAB_01885800);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 567 ; VA 0x00497470 ; FUN_00497470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497470(void)

{
  undefined4 extraout_var;
  
  FUN_00967d70(0x2a4,s_PlayerAdded_021215b8,s_player_0211f800,0,0,0,0);
  _DAT_02120bf8 =
       RBX::Reflection::
       EventDesc<class_RBX::Players,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Players::*>
       ::vftable;
  FUN_016f3654(&LAB_01885810,extraout_var);
  return;
}



/* FUNCTION 568 ; VA 0x004975b0 ; FUN_004975b0 */

void FUN_004975b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009678f0(FUN_00972b50,0,&DAT_02121488,s_message_02119b14,1,uStack_10,0);
  FUN_016f3654(&LAB_01885850);
  return;
}



/* FUNCTION 569 ; VA 0x00497610 ; FUN_00497610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497610(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce7ce;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580(uVar2,0);
  FUN_009cb790(uVar1,s_WhisperChat_0212149c,3,CONCAT44(uVar3,uVar2),0);
  _DAT_02120870 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Players,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_021208a8 = FUN_0098d870;
  _DAT_021208ac = 0;
  _DAT_021208b0 = 0;
  DAT_021208b4 = 0;
  uStack_8 = 2;
  FUN_00921690();
  FUN_016f3654(&LAB_01885870);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 570 ; VA 0x004976d0 ; FUN_004976d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004976d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce808;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580(uVar2,0);
  FUN_009cb790(uVar1,s_ReportAbuse_021214f4,3,CONCAT44(uVar3,uVar2),0);
  _DAT_02120928 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Players,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),3>
       ::vftable;
  _DAT_02120960 = FUN_0098ab10;
  _DAT_02120964 = 0;
  _DAT_02120968 = 0;
  _DAT_0212096c = 0;
  _DAT_02120970 = 0;
  uStack_8 = 3;
  FUN_00977d40(s_player_0211f800,s_reason_02119920,s_optionalMessage_021214e4);
  FUN_016f3654(&LAB_018858d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 571 ; VA 0x004977a0 ; FUN_004977a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004977a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce82a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580(uVar2,0);
  FUN_009cb790(uVar1,s_SetRealPlace_02121958,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021213c0 = RBX::Reflection::BoundFuncDesc<class_RBX::Players,void___cdecl(void),0>::vftable;
  _DAT_021213f8 = &LAB_0098cbd0;
  _DAT_021213fc = 0;
  _DAT_021213e4 = FUN_00888530();
  FUN_016f3654(&LAB_018858e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 572 ; VA 0x00497840 ; FUN_00497840 */

void FUN_00497840(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009678f0(FUN_0098d250,0,s_TeamChat_02121490,s_message_02119b14,1,uStack_10,0);
  FUN_016f3654(&LAB_018858f0);
  return;
}



/* FUNCTION 573 ; VA 0x004978a0 ; FUN_004978a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004978a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce84a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580(uVar2,0);
  FUN_009cb790(uVar1,s_GetPlayers_02121500,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02120978 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Players,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021209b0 = FUN_005d57a0;
  _DAT_021209b4 = 0;
  _DAT_0212099c = FUN_0088cc80();
  FUN_016f3654(&LAB_01885910);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 574 ; VA 0x00497940 ; FUN_00497940 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497940(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce888;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580(uVar2,0);
  FUN_009cb820(uVar1,s_GetUserThumbnailAsync_02121914,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02121318 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Players,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(__int64,enum_RBX::Players::ThumbnailType,enum_RBX::Players::ThumbnailSize),3>
       ::vftable;
  _DAT_02121350 = FUN_00980bc0;
  _DAT_02121354 = 0;
  DAT_02121358 = 0;
  DAT_0212135c = 0;
  DAT_02121360 = 0;
  uStack_8 = 3;
  FUN_00978590(s_userId_0211fb64,s_thumbnailType_02121904,s_thumbnailSize_021218f4);
  FUN_016f3654(&LAB_01885920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 575 ; VA 0x00497a10 ; FUN_00497a10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497a10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce8c8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580(uVar2,0);
  FUN_009cb820(uVar1,s_CreateHumanoidModelFromDescripti_02121728,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02120fb0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Players,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::HumanoidRigType,enum_RBX::AssetTypeVerification),3>
       ::vftable;
  _DAT_02120fe8 = FUN_00974640;
  _DAT_02120fec = 0;
  _DAT_02120ff0 = 0;
  _DAT_02120ff4 = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  _DAT_02120ff8 = (undefined4 *)FUN_01674e20(4);
  if (_DAT_02120ff8 == (undefined4 *)0x0) {
    _DAT_02120ff8 = (undefined4 *)0x0;
  }
  else {
    *_DAT_02120ff8 = 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_009788b0(s_description_0212171c,s_rigType_02121714,s_assetTypeVerification_021216fc);
  FUN_016f3654(&LAB_01885970);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 576 ; VA 0x00497b00 ; FUN_00497b00 */

void FUN_00497b00(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00967a70(FUN_00974d80,0,s_CreateHumanoidModelFromUserId_021216dc,s_userId_0211fb64,0,uStack_10
               ,0);
  FUN_016f3654(&LAB_01885980);
  return;
}



/* FUNCTION 577 ; VA 0x00497b60 ; FUN_00497b60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497b60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce8ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580(uVar2,0);
  FUN_009cb790(uVar1,s_CreateLocalPlayer_02121538,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02120aa8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Players,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_02120ae0 = FUN_00975ff0;
  _DAT_02120ae4 = 0;
  _DAT_02120acc = FUN_0088cdc0();
  FUN_016f3654(&LAB_018859a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 578 ; VA 0x00497c00 ; FUN_00497c00 */

void FUN_00497c00(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00967a70(FUN_0097cfe0,0,s_GetCharacterAppearanceAsync_021216a0,s_userId_0211fb64,0,uStack_10,0
              );
  FUN_016f3654(&LAB_018859b0);
  return;
}



/* FUNCTION 579 ; VA 0x00497c60 ; FUN_00497c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497c60(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce94c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb820(uVar1,s_GetCharacterAppearanceInfoAsync_021216bc,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02120f20 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Players,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(__int64),1>
       ::vftable;
  _DAT_02120f58 = FUN_0097d780;
  _DAT_02120f5c = 0;
  DAT_02120f60 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02120f44 = FUN_008881d0();
  puVar3 = DAT_02120f60;
  if (DAT_02120f60 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088da50();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    iStack_ec = FUN_005c9e80();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(s_userId_0211fb64);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_018859d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 580 ; VA 0x00497e10 ; FUN_00497e10 */

void FUN_00497e10(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00967a70(FUN_0097e1d0,0,s_GetHumanoidDescriptionFromOutfit_0212177c,s_outfitId_02121770,0,
               uStack_10,0);
  FUN_016f3654(&LAB_018859f0);
  return;
}



/* FUNCTION 581 ; VA 0x00497e70 ; FUN_00497e70 */

void FUN_00497e70(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00967a70(FUN_0097e5b0,0,s_GetHumanoidDescriptionFromUserId_0212174c,s_userId_0211fb64,0,
               uStack_10,0);
  FUN_016f3654(&LAB_01885a10);
  return;
}



/* FUNCTION 582 ; VA 0x00497ed0 ; FUN_00497ed0 */

void FUN_00497ed0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00967a70(FUN_0097e9b0,0,s_GetFriendsAsync_02121690,s_userId_0211fb64,0,uStack_10,0);
  FUN_016f3654(&LAB_01885a30);
  return;
}



/* FUNCTION 583 ; VA 0x00497f30 ; FUN_00497f30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00497f30(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce9ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb820(uVar1,s_GetNameFromUserIdAsync_02121678,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02120e48 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Players,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(__int64),1>
       ::vftable;
  _DAT_02120e80 = FUN_0097f540;
  _DAT_02120e84 = 0;
  DAT_02120e88 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02120e6c = FUN_0088cb40();
  puVar3 = DAT_02120e88;
  if (DAT_02120e88 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088da50();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    iStack_ec = FUN_005c9e80();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(s_userId_0211fb64);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01885a50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 584 ; VA 0x004980e0 ; FUN_004980e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004980e0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cea0c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb790(uVar1,s_GetPlayerByUserId_021217a0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02121090 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Players,class_std::shared_ptr<class_RBX::Instance>___cdecl(__int64),1>
       ::vftable;
  _DAT_021210c8 = FUN_00980280;
  _DAT_021210cc = 0;
  DAT_021210d0 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021210b4 = FUN_0088cdc0();
  puVar3 = DAT_021210d0;
  if (DAT_021210d0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088da50();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    iStack_ec = FUN_005c9e80();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(s_userId_0211fb64);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01885a70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 585 ; VA 0x00498290 ; FUN_00498290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00498290(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cea6c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00961580();
  FUN_009cb820(uVar2,s_GetUserIdFromNameAsync_02121660,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02120e00 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Players,__int64___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02120e38 = FUN_00980610;
  _DAT_02120e3c = 0;
  DAT_02120e40 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02120e24 = FUN_0088da50();
  iVar1 = DAT_02120e40;
  if (DAT_02120e40 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_userName_02121654);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01885a90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 586 ; VA 0x00498440 ; FUN_00498440 */

void FUN_00498440(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00967750(FUN_00988f90,0,s_GetPlayerFromCharacter_0212154c,s_character_0211fe0c,0,uStack_10,0);
  FUN_016f3654(&LAB_01885ab0);
  return;
}



/* FUNCTION 587 ; VA 0x004984a0 ; FUN_004984a0 */

void FUN_004984a0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00967750(FUN_00988f90,0,s_playerFromCharacter_02121564,s_character_0211fe0c,0,
               CONCAT44(&DAT_02120ae8,uStack_10),0);
  FUN_016f3654(&LAB_01885b00);
  return;
}



/* FUNCTION 588 ; VA 0x00498500 ; FUN_00498500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00498500(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ceacc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb790(uVar1,s_SetChatStyle_0212162c,1,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_02120d48 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Players,void___cdecl(enum_RBX::Players::ChatOption),1>::vftable;
  _DAT_02120d80 = FUN_0098c800;
  _DAT_02120d84 = 0;
  DAT_02120d88 = (undefined4 *)FUN_01674e20(4);
  if (DAT_02120d88 == (undefined4 *)0x0) {
    DAT_02120d88 = (undefined4 *)0x0;
  }
  else {
    *DAT_02120d88 = 0;
  }
  uStack_8._0_1_ = 1;
  _DAT_02120d6c = FUN_00888530();
  puVar3 = DAT_02120d88;
  if (DAT_02120d88 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_005f3090();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005f3700();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_005f3090();
  uVar2 = FUN_0086e3d0(s_style_02121624);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01885b50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 589 ; VA 0x004986c0 ; FUN_004986c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004986c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ceb1c;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580(uVar2,0);
  FUN_009cb790(uVar1,s_SetLocalPlayerInfo_02121944,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02121368 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Players,void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MembershipType,bool),5>
       ::vftable;
  _DAT_021213a0 = FUN_0098c9f0;
  _DAT_021213a4 = 0;
  DAT_021213a8 = 0;
  _DAT_021213ac = 0;
  _DAT_021213b0 = 0;
  DAT_021213b4 = 0;
  DAT_021213b8 = 0;
  uStack_8 = 5;
  FUN_00978080(s_userId_0211fb64,s_userName_02121654,s_displayName_02121938,
               s_membershipType_0211fa30,s_isUnder13_0212192c);
  FUN_016f3654(&LAB_01885b70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 590 ; VA 0x00498ca0 ; FUN_00498ca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00498ca0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ceb4c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00961580();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Players,float>::
              GetSetImpl<float_(__thiscall_RBX::Players::*)(void)const_,void_(__thiscall_RBX::Players::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00855cd0;
    puVar3[3] = 0;
    puVar3[4] = FUN_0098cc90;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_RespawnTime_0212147c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_021207a4 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021207d8 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021207c8 = _DAT_021207c8 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021207a4[2])();
    if (cVar1 != '\0') {
      _DAT_021207c8 = _DAT_021207c8 & 0xfffffff3;
    }
  }
  DAT_021207a4 = RBX::Reflection::PropDescriptor<class_RBX::Players,float>::vftable;
  FUN_016f3654(&LAB_01885cf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 591 ; VA 0x00498ff0 ; FUN_00498ff0 */

void FUN_00498ff0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d17ea;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00551260("rbxasset://configs/ReflectionLoggerConfig/EphemeralCounterWhitelist.json");
  uStack_8 = 0;
  FUN_009cbbb0(&DAT_01d6491c);
  FUN_016f3654(&LAB_01886030);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 592 ; VA 0x00499190 ; FUN_00499190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499190(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("CoreScriptVersionEnabled",0x18);
  _DAT_01ee3498 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 593 ; VA 0x00499270 ; FUN_00499270 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499270(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1ac3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690();
  FUN_009cb970(uVar1,s_Heartbeat_02121e98,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021219d4 = 0xe0;
  iStack_8 = 0;
  _DAT_021219a0 =
       RBX::Reflection::
       EventDesc<class_RBX::RunService,void___cdecl(double),class_rbx::signal<void___cdecl(double)>,class_rbx::signal<void___cdecl(double)>_RBX::RunService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_02121e88);
  FUN_0088ca00();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021219c8 = uStack_1c;
  _DAT_021219cc = uStack_18;
  _DAT_021219d0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021219a0 =
       RBX::Reflection::
       EventDesc<class_RBX::RunService,void___cdecl(double),class_rbx::signal<void___cdecl(double)>,class_rbx::signal<void___cdecl(double)>_RBX::RunService::*>
       ::vftable;
  FUN_016f3654(&LAB_01886100);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 594 ; VA 0x004993c0 ; FUN_004993c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004993c0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1af3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690();
  FUN_009cb970(uVar1,s_RenderStepped_02121ea4,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02121a10 = FUN_00999430;
  _DAT_02121a14 = 0;
  iStack_8 = 0;
  _DAT_021219d8 =
       RBX::Reflection::
       EventDesc<class_RBX::RunService,void___cdecl(double),class_rbx::signal<void___cdecl(double)>,class_rbx::signal<void___cdecl(double)>*_(__thiscall_RBX::RunService::*)(bool)>
       ::vftable;
  FUN_0086e3d0(&DAT_02121e88);
  FUN_0088ca00();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02121a00 = uStack_1c;
  _DAT_02121a04 = uStack_18;
  _DAT_02121a08 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021219d8 =
       RBX::Reflection::
       EventDesc<class_RBX::RunService,void___cdecl(double),class_rbx::signal<void___cdecl(double)>,class_rbx::signal<void___cdecl(double)>*_(__thiscall_RBX::RunService::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_01886110);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 595 ; VA 0x00499520 ; FUN_00499520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499520(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1b2e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690();
  FUN_009cb970(uVar1,s_Stepped_02121e90,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212199c = 0xdc;
  iStack_8 = 0;
  _DAT_02121968 =
       RBX::Reflection::
       EventDesc<class_RBX::RunService,void___cdecl(double,double),class_rbx::signal<void___cdecl(double,double)>,class_rbx::signal<void___cdecl(double,double)>_RBX::RunService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0211fe58);
  FUN_0088ca00();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(&DAT_02121e88);
  FUN_0088ca00();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02121990 = uStack_1c;
  _DAT_02121994 = uStack_18;
  _DAT_02121998 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02121968 =
       RBX::Reflection::
       EventDesc<class_RBX::RunService,void___cdecl(double,double),class_rbx::signal<void___cdecl(double,double)>,class_rbx::signal<void___cdecl(double,double)>_RBX::RunService::*>
       ::vftable;
  FUN_016f3654(&LAB_01886120);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 596 ; VA 0x00499690 ; FUN_00499690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499690(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1b4a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02121ec0,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121ad8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RunService,void___cdecl(void),0>::vftable;
  _DAT_02121b10 = FUN_0099a8d0;
  _DAT_02121b14 = 0;
  _DAT_02121afc = FUN_00888530();
  FUN_016f3654(&LAB_01886130);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 597 ; VA 0x00499730 ; FUN_00499730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499730(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1b88;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_BindToRenderStep_02121ef8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02121ba0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RunService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,class_RBX::Lua::WeakFunctionRef),3>
       ::vftable;
  _DAT_02121bd8 = FUN_00997ed0;
  _DAT_02121bdc = 0;
  _DAT_02121be0 = 0;
  DAT_02121be4 = 0;
  DAT_02121be8 = 0;
  uStack_8 = 3;
  FUN_00998530(&DAT_0211a93c,s_priority_02121eec,s_function_0211d1fc);
  FUN_016f3654(&LAB_01886140);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 598 ; VA 0x00499800 ; FUN_00499800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499800(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1baa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_GetCoreScriptVersion_02121f58,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121d70 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RunService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void)const_,0>
       ::vftable;
  _DAT_02121da8 = FUN_009993d0;
  _DAT_02121dac = 0;
  _DAT_02121d94 = FUN_0088cb40();
  FUN_016f3654(&LAB_01886180);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 599 ; VA 0x004998a0 ; FUN_004998a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004998a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1bca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_GetRobloxVersion_02121f44,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121d30 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RunService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_02121d68 = FUN_00999490;
  _DAT_02121d6c = 0;
  _DAT_02121d54 = FUN_0088cb40();
  FUN_016f3654(&LAB_01886190);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 600 ; VA 0x00499940 ; FUN_00499940 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499940(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1bea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_IsClient_02121f18,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121c30 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RunService,bool___cdecl(void),0>::vftable;
  _DAT_02121c68 = &LAB_009994e0;
  _DAT_02121c6c = 0;
  _DAT_02121c54 = FUN_0088daf0();
  FUN_016f3654(&LAB_018861a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 601 ; VA 0x004999e0 ; FUN_004999e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004999e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1c0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_IsEdit_02121f3c,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121cf0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RunService,bool___cdecl(void),0>::vftable;
  _DAT_02121d28 = FUN_009994f0;
  _DAT_02121d2c = 0;
  _DAT_02121d14 = FUN_0088daf0();
  FUN_016f3654(&LAB_018861b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 602 ; VA 0x00499a80 ; FUN_00499a80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499a80(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1c2a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_IsRunMode_02121f30,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121cb0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RunService,bool___cdecl(void),0>::vftable;
  _DAT_02121ce8 = FUN_009993f0;
  _DAT_02121cec = 0;
  _DAT_02121cd4 = FUN_0088daf0();
  FUN_016f3654(&LAB_018861c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 603 ; VA 0x00499b20 ; FUN_00499b20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499b20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1c4a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_IsRunning_02121ec8,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121b18 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RunService,bool___cdecl(void),0>::vftable;
  _DAT_02121b50 = &LAB_00999510;
  _DAT_02121b54 = 0;
  _DAT_02121b3c = FUN_0088daf0();
  FUN_016f3654(&LAB_018861d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 604 ; VA 0x00499bc0 ; FUN_00499bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499bc0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1c6a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_IsServer_02121f0c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121bf0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RunService,bool___cdecl(void),0>::vftable;
  _DAT_02121c28 = &LAB_00999520;
  _DAT_02121c2c = 0;
  _DAT_02121c14 = FUN_0088daf0();
  FUN_016f3654(&LAB_018861e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 605 ; VA 0x00499c60 ; FUN_00499c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499c60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1c8a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_IsStudio_02121f24,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121c70 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RunService,bool___cdecl(void),0>::vftable;
  _DAT_02121ca8 = FUN_00585a40;
  _DAT_02121cac = 0;
  _DAT_02121c94 = FUN_0088daf0();
  FUN_016f3654(&LAB_018861f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 606 ; VA 0x00499d00 ; FUN_00499d00 */

void FUN_00499d00(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00996480(FUN_00938740,0,s_Set3dRenderingEnabled_02121f94,s_enable_02121f70,5,uStack_10,0);
  FUN_016f3654(&LAB_01886200);
  return;
}



/* FUNCTION 607 ; VA 0x00499d60 ; FUN_00499d60 */

void FUN_00499d60(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00996480(FUN_00999b40,0,s_SetRobloxGuiFocused_02121fb4,s_focus_02121fac,5,uStack_10,0);
  FUN_016f3654(&LAB_01886220);
  return;
}



/* FUNCTION 608 ; VA 0x00499dc0 ; FUN_00499dc0 */

void FUN_00499dc0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00996480(FUN_00999bd0,0,s_setThrottleFramerateEnabled_02121f78,s_enable_02121f70,5,uStack_10,0
              );
  FUN_016f3654(&LAB_01886240);
  return;
}



/* FUNCTION 609 ; VA 0x00499e20 ; FUN_00499e20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499e20(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1cec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690();
  FUN_009cb790(uVar1,s_UnbindFromRenderStep_02121ed4,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02121b58 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RunService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02121b90 = FUN_0099a950;
  _DAT_02121b94 = 0;
  DAT_02121b98 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02121b7c = FUN_00888530();
  if (DAT_02121b98 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02121b98);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_01886260);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 610 ; VA 0x00499fb0 ; FUN_00499fb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00499fb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1d0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_Pause_02121eb8,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121a58 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RunService,void___cdecl(void),0>::vftable;
  _DAT_02121a90 = FUN_00999780;
  _DAT_02121a94 = 0;
  _DAT_02121a7c = FUN_00888530();
  FUN_016f3654(&LAB_018862a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 611 ; VA 0x0049a050 ; FUN_0049a050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049a050(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1d2a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,s_Reset_0211d424,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121a98 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RunService,void___cdecl(void),0>::vftable;
  _DAT_02121ad0 = FUN_0099a8d0;
  _DAT_02121ad4 = 0;
  _DAT_02121abc = FUN_00888530();
  FUN_016f3654(&LAB_018862c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 612 ; VA 0x0049a0f0 ; FUN_0049a0f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049a0f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1d4a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00995690(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02121eb4,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02121a18 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RunService,void___cdecl(void),0>::vftable;
  _DAT_02121a50 = &LAB_005f7090;
  _DAT_02121a54 = 0;
  _DAT_02121a3c = FUN_00888530();
  FUN_016f3654(&LAB_018862d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 613 ; VA 0x0049a190 ; FUN_0049a190 */

void FUN_0049a190(void)

{
  FUN_0099ad30(s_Health_XML_02123b70,&DAT_02123b60,0xfffffecc00927160,0,0xfffffecc009c36b0,0,0,0,0,
               0xe,0);
  FUN_016f3654(&LAB_018862e0);
  return;
}



/* FUNCTION 614 ; VA 0x0049a220 ; FUN_0049a220 */

void FUN_0049a220(void)

{
  FUN_0099af90(&DAT_02123cb8,s_Control_0211ffd0,0xfffffecc009b4e10,0,0xfffffecc009c39b0,0,0,0,0,0x15
               ,0);
  FUN_016f3654(&LAB_01886300);
  return;
}



/* FUNCTION 615 ; VA 0x0049a470 ; FUN_0049a470 */

void FUN_0049a470(void)

{
  FUN_0099af90(s_JumpReplicate_02123cc0,s_Control_0211ffd0,0xfffffecc009b4e10,0,0xfffffecc009c39b0,0
               ,0,0,0,2,0);
  FUN_016f3654(&LAB_01886360);
  return;
}



/* FUNCTION 616 ; VA 0x0049a5e0 ; FUN_0049a5e0 */

void FUN_0049a5e0(void)

{
  FUN_0099af90(&DAT_02123cd0,s_Control_0211ffd0,0xfffffecc009b6ee0,0,0xfffffecc009c4f20,0,0,0,0,0x13
               ,0);
  FUN_016f3654(&LAB_018863a0);
  return;
}



/* FUNCTION 617 ; VA 0x0049a940 ; FUN_0049a940 */

void FUN_0049a940(void)

{
  undefined4 *puVar1;
  undefined auStack_2c [16];
  code *pcStack_1c;
  undefined4 uStack_18;
  code *pcStack_10;
  undefined4 uStack_c;
  
  puVar1 = (undefined4 *)FUN_009cb3a0(auStack_2c,0x14);
  pcStack_10 = FUN_00553510;
  uStack_c = 0xfffffecc;
  pcStack_1c = FUN_009b4e80;
  uStack_18 = 0xfffffecc;
  FUN_0099aea0(s_LeftLeg_02123b4c,&DAT_021197d4,0xfffffecc009b4e80,0,0xfffffecc00553510,0,*puVar1,
               puVar1[1],puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_01886400);
  return;
}



/* FUNCTION 618 ; VA 0x0049a9d0 ; FUN_0049a9d0 */

void FUN_0049a9d0(void)

{
  undefined4 *puVar1;
  undefined auStack_2c [16];
  code *pcStack_1c;
  undefined4 uStack_18;
  code *pcStack_10;
  undefined4 uStack_c;
  
  puVar1 = (undefined4 *)FUN_009cb3a0(auStack_2c,0x14);
  pcStack_10 = FUN_00553510;
  uStack_c = 0xfffffecc;
  pcStack_1c = FUN_009b6d40;
  uStack_18 = 0xfffffecc;
  FUN_0099aea0(s_RightLeg_02123b54,&DAT_021197d4,0xfffffecc009b6d40,0,0xfffffecc00553510,0,*puVar1,
               puVar1[1],puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_01886420);
  return;
}



/* FUNCTION 619 ; VA 0x0049aa60 ; FUN_0049aa60 */

void FUN_0049aa60(void)

{
  undefined4 *puVar1;
  undefined auStack_2c [16];
  code *pcStack_1c;
  undefined4 uStack_18;
  code *pcStack_10;
  undefined4 uStack_c;
  
  puVar1 = (undefined4 *)FUN_009cb3a0(auStack_2c,0x14);
  pcStack_10 = FUN_00553510;
  uStack_c = 0xfffffecc;
  pcStack_1c = FUN_009b7250;
  uStack_18 = 0xfffffecc;
  FUN_0099aea0(s_Torso_02123b44,&DAT_021197d4,0xfffffecc009b7250,0,0xfffffecc00553510,0,*puVar1,
               puVar1[1],puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_01886440);
  return;
}



/* FUNCTION 620 ; VA 0x0049ae50 ; FUN_0049ae50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049ae50(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  _DAT_01ee37b8 = (float)dVar1 * DAT_018ce328;
  return;
}



/* FUNCTION 621 ; VA 0x0049aef0 ; FUN_0049aef0 */

void FUN_0049aef0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_009a0700(0xfffffecc009c6ff0,0,s_takeDamage_02123de0,s_amount_02123dcc,0,
               CONCAT44(&DAT_02122a38,uStack_10),0);
  FUN_016f3654(&LAB_018864c0);
  return;
}



/* FUNCTION 622 ; VA 0x0049af60 ; FUN_0049af60 */

void FUN_0049af60(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_009a0550(0xfffffecc009b8d60,0,s_loadAnimation_02124180,s_animation_02124164,0,
               CONCAT44(&DAT_02129120,uStack_10),0);
  FUN_016f3654(&LAB_018864e0);
  return;
}



/* FUNCTION 623 ; VA 0x0049afd0 ; FUN_0049afd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049afd0(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d32da;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_GetPlayingAnimationTracks_02124190,0,CONCAT44(&DAT_02129168,uStack_1c),0);
  _DAT_021238e0 = 0xfffffecc009b67c0;
  uStack_8 = 0;
  _DAT_021238a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021238e8 = 0;
  _DAT_021238cc = FUN_008882f0();
  FUN_016f3654(&LAB_01886530);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 624 ; VA 0x0049b080 ; FUN_0049b080 */

void FUN_0049b080(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_009a0550(0xfffffecc009b8d60,0,s_LoadAnimation_02124170,s_animation_02124164,0,
               CONCAT44(&DAT_02129120,uStack_10),0);
  FUN_016f3654(&LAB_01886540);
  return;
}



/* FUNCTION 625 ; VA 0x0049b0f0 ; FUN_0049b0f0 */

void FUN_0049b0f0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009a0880(0xfffffecc009a7120,0,s_AddAccessory_0212413c,s_accessory_02124130,0,uStack_10,0);
  FUN_016f3654(&LAB_01886590);
  return;
}



/* FUNCTION 626 ; VA 0x0049b160 ; FUN_0049b160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049b160(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3313;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,s_ServerApplyDescription_0212401c,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021233b8 = 0x5fc;
  _DAT_021233bc = 0;
  iStack_8 = 0;
  _DAT_02123380 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::Humanoid::*>
       ::vftable;
  FUN_0086e3d0(s_status_02123f34);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021233a8 = uStack_1c;
  _DAT_021233ac = uStack_18;
  _DAT_021233b0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_02123380 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Humanoid,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::Humanoid::*>
       ::vftable;
  _DAT_021233c0 = 0;
  _DAT_021233c4 = 0;
  FUN_016f3654(&LAB_018865e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 627 ; VA 0x0049b2d0 ; FUN_0049b2d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049b2d0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d332a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_BuildRigFromAttachments_0212414c,0,uStack_1c,0);
  _DAT_02123808 = 0xfffffecc009aa270;
  uStack_8 = 0;
  _DAT_021237d0 = RBX::Reflection::BoundFuncDesc<class_RBX::Humanoid,void___cdecl(void),0>::vftable;
  _DAT_02123810 = 0;
  _DAT_021237f4 = FUN_00888530();
  FUN_016f3654(&LAB_018865f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 628 ; VA 0x0049b380 ; FUN_0049b380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049b380(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d334a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_GetAccessories_0212410c,0,uStack_1c,0);
  _DAT_02123730 = 0xfffffecc009b37e0;
  uStack_8 = 0;
  _DAT_021236f8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02123738 = 0;
  _DAT_0212371c = FUN_008882f0();
  FUN_016f3654(&LAB_01886600);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 629 ; VA 0x0049b430 ; FUN_0049b430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049b430(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d33ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_009b4290;
  uStack_28 = 0xfffffecc;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0099be20();
  FUN_009cb790(uVar2,s_GetBodyPartR15_021240dc,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02123698 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_02123660 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,enum_RBX::Humanoid::R15PartType___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_021236a0 = 0;
  DAT_021236a4 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02123684 = FUN_009c6730();
  puVar4 = DAT_021236a4;
  if (DAT_021236a4 == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088cdc0();
    iStack_f8 = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_f4 = *puVar4;
    uStack_f0 = puVar4[1];
    iStack_f8 = FUN_006309e0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(&DAT_02123e0c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_01886610);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 630 ; VA 0x0049b610 ; FUN_0049b610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049b610(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d340c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_009b4ea0;
  uStack_28 = 0xfffffecc;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0099be20();
  FUN_009cb790(uVar2,s_GetLimb_021240ac,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02123608 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_021235d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,enum_RBX::Humanoid::Limb___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_02123610 = 0;
  DAT_02123614 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021235f4 = FUN_009c65d0();
  puVar4 = DAT_02123614;
  if (DAT_02123614 == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088cdc0();
    iStack_f8 = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_f4 = *puVar4;
    uStack_f0 = puVar4[1];
    iStack_f8 = FUN_006309e0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(&DAT_02123e0c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_01886660);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 631 ; VA 0x0049b7f0 ; FUN_0049b7f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049b7f0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 auStack_f4 [50];
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d346c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_009b6ef0;
  uStack_28 = 0xfffffecc;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_GetStateEnabled_0212406c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02123530 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_021234f8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,bool___cdecl(enum_RBX::HUMAN::StateType),1>::vftable;
  _DAT_02123538 = 0;
  DAT_0212353c = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212351c = FUN_0088daf0();
  puVar3 = DAT_0212353c;
  if (DAT_0212353c == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar3 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = thunk_FUN_009c67e0();
    iStack_f8 = 0;
    auStack_f4[0] = *puVar3;
    iStack_f8 = FUN_009c6c60();
    puVar3 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_009c67e0();
  uVar2 = FUN_0086e3d0(s_state_02123f08);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
  }
  FUN_016f3654(&LAB_018866b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 632 ; VA 0x0049b9a0 ; FUN_0049b9a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049b9a0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d348a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_RemoveAccessories_0212411c,0,uStack_1c,0);
  _DAT_02123778 = 0xfffffecc009bf650;
  uStack_8 = 0;
  _DAT_02123740 = RBX::Reflection::BoundFuncDesc<class_RBX::Humanoid,void___cdecl(void),0>::vftable;
  _DAT_02123780 = 0;
  _DAT_02123764 = FUN_00888530();
  FUN_016f3654(&LAB_018866d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 633 ; VA 0x0049ba50 ; FUN_0049ba50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049ba50(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d34be;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_ReplaceBodyPartR15_021240f8,0,uStack_1c,0);
  _DAT_021236e0 = 0xfffffecc009c0e80;
  _DAT_021236a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,bool___cdecl(enum_RBX::Humanoid::R15PartType,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_021236e8 = 0;
  _DAT_021236ec = 0;
  _DAT_021236f0 = 0;
  uStack_8 = 2;
  FUN_009af230();
  FUN_016f3654(&LAB_018866e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 634 ; VA 0x0049bb20 ; FUN_0049bb20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049bb20(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d34f3;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,s_ServerEquipTool_0212400c,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02123370 = 0x5f4;
  _DAT_02123374 = 0;
  iStack_8 = 0;
  _DAT_02123338 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Humanoid::*>
       ::vftable;
  FUN_0086e3d0(&DAT_02123f98);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02123360 = uStack_1c;
  _DAT_02123364 = uStack_18;
  _DAT_02123368 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_02123338 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Humanoid,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Humanoid::*>
       ::vftable;
  _DAT_02123378 = 0;
  _DAT_0212337c = 0;
  FUN_016f3654(&LAB_018866f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 635 ; VA 0x0049bc90 ; FUN_0049bc90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049bc90(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d351e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_SetStateEnabled_0212407c,0,uStack_1c,0);
  _DAT_02123578 = 0xfffffecc009c4fb0;
  _DAT_02123540 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,void___cdecl(enum_RBX::HUMAN::StateType,bool),2>::vftable;
  _DAT_02123580 = 0;
  DAT_02123584 = 0;
  DAT_02123588 = 0;
  uStack_8 = 2;
  FUN_009af010();
  FUN_016f3654(&LAB_01886700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 636 ; VA 0x0049bd90 ; FUN_0049bd90 */

void FUN_0049bd90(void)

{
  FUN_009a0f30(0x5ec,0,s_CustomStatusAdded_02123fe4,s_status_02123f34,1,0);
  FUN_016f3654(&LAB_018867b0);
  return;
}



/* FUNCTION 637 ; VA 0x0049bdf0 ; FUN_0049bdf0 */

void FUN_0049bdf0(void)

{
  FUN_009a0f30(0x5f0,0,s_CustomStatusRemoved_02123ff8,s_status_02123f34,1,0);
  FUN_016f3654(&LAB_018867c0);
  return;
}



/* FUNCTION 638 ; VA 0x0049be50 ; FUN_0049be50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049be50(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20(uVar2,0);
  FUN_009cb970(uVar1,&DAT_02123e40,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02122bd8 = 0x608;
  _DAT_02122bdc = 0;
  _DAT_02122ba0 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Humanoid::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02122bc8 = 0;
  _DAT_02122bcc = 0;
  _DAT_02122bd0 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_02122ba0 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Humanoid::*>
       ::vftable;
  FUN_016f3654(&LAB_018867d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 639 ; VA 0x0049c010 ; FUN_0049c010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049c010(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  undefined4 uStack_2c;
  undefined *puStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3553;
  pvStack_10 = ExceptionList;
  uStack_2c = CONCAT31(uStack_2c._1_3_,1);
  puStack_28 = &DAT_021291a8;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,s_AnimationPlayed_021241bc,0,CONCAT44(puStack_28,uStack_2c),0);
  _DAT_02123928 = 0x654;
  _DAT_0212392c = 0;
  iStack_8 = 0;
  _DAT_021238f0 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Humanoid::*>
       ::vftable;
  FUN_0086e3d0(s_animationTrack_021241ac);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02123918 = uStack_1c;
  _DAT_0212391c = uStack_18;
  _DAT_02123920 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021238f0 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Humanoid::*>
       ::vftable;
  FUN_016f3654(&LAB_01886820);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 640 ; VA 0x0049c170 ; FUN_0049c170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049c170(void)

{
  undefined4 uVar1;
  undefined auStack_1e8 [432];
  undefined *puStack_38;
  undefined4 uStack_34;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d358e;
  pvStack_10 = ExceptionList;
  puStack_38 = &LAB_009b5520;
  uStack_34 = 0xfffffecc;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,s_Touched_021240d4,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02123650 = CONCAT44(uStack_34,puStack_38);
  _DAT_02123658 = 0;
  iStack_8 = 0;
  _DAT_02123618 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::Humanoid::*)(bool)>
       ::vftable;
  FUN_0086e3d0(s_touchingPart_021240c4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_humanoidPart_021240b4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e8,&puStack_38,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02123640 = uStack_1c;
  _DAT_02123644 = uStack_18;
  _DAT_02123648 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e8,0xd8,2,FUN_00688b10);
  _DAT_02123618 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::Humanoid::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_01886830);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 641 ; VA 0x0049c3f0 ; FUN_0049c3f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049c3f0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d35ce;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,s_Seated_02123ebc,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02122e18 = 0x630;
  _DAT_02122e1c = 0;
  iStack_8 = 0;
  _DAT_02122de0 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>_RBX::Humanoid::*>
       ::vftable;
  FUN_0086e3d0(s_active_02123e64);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_currentSeatPart_02123eac);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02122e08 = uStack_1c;
  _DAT_02122e0c = uStack_18;
  _DAT_02122e10 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02122de0 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>_RBX::Humanoid::*>
       ::vftable;
  FUN_016f3654(&LAB_01886890);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 642 ; VA 0x0049c570 ; FUN_0049c570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049c570(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d360e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,s_StateChanged_02123eec,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02122ed8 = 0x638;
  _DAT_02122edc = 0;
  iStack_8 = 0;
  _DAT_02122ea0 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(enum_RBX::HUMAN::StateType,enum_RBX::HUMAN::StateType),class_rbx::signal<void___cdecl(enum_RBX::HUMAN::StateType,enum_RBX::HUMAN::StateType)>,class_rbx::signal<void___cdecl(enum_RBX::HUMAN::StateType,enum_RBX::HUMAN::StateType)>_RBX::Humanoid::*>
       ::vftable;
  FUN_0086e3d0(&DAT_02123ee8);
  thunk_FUN_009c67e0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(&DAT_02123ee4);
  thunk_FUN_009c67e0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02122ec8 = uStack_1c;
  _DAT_02122ecc = uStack_18;
  _DAT_02122ed0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02122ea0 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(enum_RBX::HUMAN::StateType,enum_RBX::HUMAN::StateType),class_rbx::signal<void___cdecl(enum_RBX::HUMAN::StateType,enum_RBX::HUMAN::StateType)>,class_rbx::signal<void___cdecl(enum_RBX::HUMAN::StateType,enum_RBX::HUMAN::StateType)>_RBX::Humanoid::*>
       ::vftable;
  FUN_016f3654(&LAB_018868a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 643 ; VA 0x0049c6f0 ; FUN_0049c6f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049c6f0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d364e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,s_StateEnabledChanged_02124098,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021235c8 = 0x63c;
  _DAT_021235cc = 0;
  iStack_8 = 0;
  _DAT_02123590 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(enum_RBX::HUMAN::StateType,bool),class_rbx::signal<void___cdecl(enum_RBX::HUMAN::StateType,bool)>,class_rbx::signal<void___cdecl(enum_RBX::HUMAN::StateType,bool)>_RBX::Humanoid::*>
       ::vftable;
  FUN_0086e3d0(s_state_02123f08);
  thunk_FUN_009c67e0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_isEnabled_0212408c);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_021235b8 = uStack_1c;
  _DAT_021235bc = uStack_18;
  _DAT_021235c0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02123590 =
       RBX::Reflection::
       EventDesc<class_RBX::Humanoid,void___cdecl(enum_RBX::HUMAN::StateType,bool),class_rbx::signal<void___cdecl(enum_RBX::HUMAN::StateType,bool)>,class_rbx::signal<void___cdecl(enum_RBX::HUMAN::StateType,bool)>_RBX::Humanoid::*>
       ::vftable;
  FUN_016f3654(&LAB_018868b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 644 ; VA 0x0049c870 ; FUN_0049c870 */

void FUN_0049c870(void)

{
  FUN_009a1070(0x5e4,0,s_StatusAdded_02123fc8,s_status_02123f34,1,0);
  FUN_016f3654(&LAB_018868c0);
  return;
}



/* FUNCTION 645 ; VA 0x0049c8d0 ; FUN_0049c8d0 */

void FUN_0049c8d0(void)

{
  FUN_009a1070(0x5e8,0,s_StatusRemoved_02123fd4,s_status_02123f34,1,0);
  FUN_016f3654(&LAB_018868d0);
  return;
}



/* FUNCTION 646 ; VA 0x0049c990 ; FUN_0049c990 */

void FUN_0049c990(void)

{
  FUN_009a0a30(0xfffffecc009a7260,0,s_AddCustomStatus_02123f64,s_status_02123f34,0,1,0);
  FUN_016f3654(&LAB_01886900);
  return;
}



/* FUNCTION 647 ; VA 0x0049ca00 ; FUN_0049ca00 */

void FUN_0049ca00(void)

{
  FUN_009a0bb0(0xfffffecc009a7360,0,s_AddStatus_02123f3c,s_status_02123f34,0,0,1,0);
  FUN_016f3654(&LAB_01886920);
  return;
}



/* FUNCTION 648 ; VA 0x0049ca80 ; FUN_0049ca80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049ca80(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d367e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb820(uVar1,s_ApplyDescription_021241cc,0,uStack_1c,0);
  _DAT_02123968 = 0xfffffecc009b9000;
  _DAT_02123930 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Humanoid,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::AssetTypeVerification),2>
       ::vftable;
  _DAT_02123970 = 0;
  _DAT_02123974 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02123978 = (undefined4 *)FUN_01674e20(4);
  if (_DAT_02123978 == (undefined4 *)0x0) {
    _DAT_02123978 = (undefined4 *)0x0;
  }
  else {
    *_DAT_02123978 = 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_009af480();
  FUN_016f3654(&LAB_01886940);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 649 ; VA 0x0049cb70 ; FUN_0049cb70 */

void FUN_0049cb70(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009a0880(0xfffffecc009b9240,0,s_ApplyDescriptionBlocking_021241e0,
               s_humanoidDescription_0211f980,5,uStack_10,0);
  FUN_016f3654(&LAB_01886950);
  return;
}



/* FUNCTION 650 ; VA 0x0049cbe0 ; FUN_0049cbe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049cbe0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d36dc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_009b9980;
  uStack_28 = 0xfffffecc;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0099be20();
  FUN_009cb820(uVar2,s_ApplyDescriptionClientServer_021241fc,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02123a00 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_021239c8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Humanoid,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_02123a08 = 0;
  DAT_02123a0c = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021239ec = FUN_00888530();
  puVar4 = DAT_02123a0c;
  if (DAT_02123a0c == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088cdc0();
    iStack_f8 = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_f4 = *puVar4;
    uStack_f0 = puVar4[1];
    iStack_f8 = FUN_006309e0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_humanoidDescription_0211f980);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_018869a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 651 ; VA 0x0049cdc0 ; FUN_0049cdc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049cdc0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 auStack_f4 [50];
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d373c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_009ab490;
  uStack_28 = 0xfffffecc;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_ChangeState_02123f10,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02122f60 = CONCAT44(uStack_28,pcStack_2c);
  uStack_8 = 0;
  _DAT_02122f28 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,void___cdecl(enum_RBX::HUMAN::StateType),1>::vftable;
  _DAT_02122f68 = 0;
  DAT_02122f6c = (undefined4 *)FUN_01674e20(4);
  if (DAT_02122f6c == (undefined4 *)0x0) {
    DAT_02122f6c = (undefined4 *)0x0;
  }
  else {
    *DAT_02122f6c = 0x12;
  }
  uStack_8._0_1_ = 1;
  _DAT_02122f4c = FUN_00888530();
  puVar3 = DAT_02122f6c;
  if (DAT_02122f6c == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar3 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = thunk_FUN_009c67e0();
    iStack_f8 = 0;
    auStack_f4[0] = *puVar3;
    iStack_f8 = FUN_009c6c60();
    puVar3 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_009c67e0();
  uVar2 = FUN_0086e3d0(s_state_02123f08);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
  }
  FUN_016f3654(&LAB_018869f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 652 ; VA 0x0049cfa0 ; FUN_0049cfa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049cfa0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d375a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_GetAppliedDescription_0212421c,0,uStack_1c,0);
  _DAT_02123a48 = 0xfffffecc009b3d60;
  uStack_8 = 0;
  _DAT_02123a10 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_02123a50 = 0;
  _DAT_02123a34 = FUN_0088cdc0();
  FUN_016f3654(&LAB_01886a10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 653 ; VA 0x0049d050 ; FUN_0049d050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049d050(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d377a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_GetState_02123efc,0,uStack_1c,0);
  _DAT_02122f18 = 0xfffffecc009b4a60;
  uStack_8 = 0;
  _DAT_02122ee0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,enum_RBX::HUMAN::StateType___cdecl(void),0>::vftable;
  _DAT_02122f20 = 0;
  _DAT_02122f04 = thunk_FUN_009c67e0();
  FUN_016f3654(&LAB_01886a20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 654 ; VA 0x0049d100 ; FUN_0049d100 */

void FUN_0049d100(void)

{
  FUN_009a0a30(0xfffffecc009b7c50,0,s_HasCustomStatus_02123f88,s_status_02123f34,0,1,0);
  FUN_016f3654(&LAB_01886a30);
  return;
}



/* FUNCTION 655 ; VA 0x0049d170 ; FUN_0049d170 */

void FUN_0049d170(void)

{
  FUN_009a0bb0(0xfffffecc009b7d10,0,s_HasStatus_02123f58,s_status_02123f34,0,0,1,0);
  FUN_016f3654(&LAB_01886a50);
  return;
}



/* FUNCTION 656 ; VA 0x0049d1f0 ; FUN_0049d1f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049d1f0(void)

{
  undefined4 uVar1;
  uint uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d37be;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_MoveTo_02123e20,0,uStack_2c,0);
  _DAT_02122b48 = 0xfffffecc009bb480;
  _DAT_02122b10 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,void___cdecl(class_G3D::Vector3,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_02122b50 = 0;
  _DAT_02122b54 = 0;
  uStack_8 = 3;
  _DAT_02122b58 = (undefined4 *)FUN_01674e20(8);
  if (_DAT_02122b58 == (undefined4 *)0x0) {
    _DAT_02122b58 = (undefined4 *)0x0;
  }
  else {
    *_DAT_02122b58 = 0;
    _DAT_02122b58[1] = 0;
  }
  _uStack_8 = CONCAT31(uStack_7,4);
  FUN_009aeb90();
  FUN_016f3654(&LAB_01886a70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 657 ; VA 0x0049d300 ; FUN_0049d300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049d300(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [200];
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d381c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_009bd670;
  uStack_28 = 0xfffffecc;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb820(uVar1,s_PlayEmoteAndGetAnimTrackById_02124264,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02123b28 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_02123af0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Humanoid,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(__int64),1>
       ::vftable;
  _DAT_02123b30 = 0;
  DAT_02123b34 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02123b14 = FUN_0088cbe0();
  if (DAT_02123b34 == 0) {
    uStack_fc = FUN_00888530();
    iStack_f8 = 0;
    puVar2 = &uStack_fc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_02123b34);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_emoteId_0212424c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  FUN_016f3654(&LAB_01886a80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 658 ; VA 0x0049d490 ; FUN_0049d490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049d490(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [200];
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d387c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_009be480;
  uStack_28 = 0xfffffecc;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0099be20();
  FUN_009cb820(uVar2,s_PlayEmote_02124240,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02123a90 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_02123a58 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Humanoid,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02123a98 = 0;
  DAT_02123a9c = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02123a7c = FUN_0088daf0();
  iVar1 = DAT_02123a9c;
  if (DAT_02123a9c == 0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088cb40();
    iStack_f8 = 0;
    FUN_0054ef60(iVar1);
    iStack_f8 = FUN_005c9d30();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_emoteName_02124234);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
  }
  FUN_016f3654(&LAB_01886aa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 659 ; VA 0x0049d650 ; FUN_0049d650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049d650(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d38ae;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb820(uVar1,s_PlayEmoteById_02124254,5,uStack_1c,0);
  _DAT_02123ad8 = 0xfffffecc009bd8b0;
  _DAT_02123aa0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Humanoid,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64),2>
       ::vftable;
  _DAT_02123ae0 = 0;
  _DAT_02123ae4 = 0;
  DAT_02123ae8 = 0;
  uStack_8 = 2;
  FUN_009af6d0();
  FUN_016f3654(&LAB_01886ac0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 660 ; VA 0x0049d720 ; FUN_0049d720 */

void FUN_0049d720(void)

{
  FUN_009a0a30(0xfffffecc009bf820,0,s_RemoveCustomStatus_02123f74,s_status_02123f34,0,1,0);
  FUN_016f3654(&LAB_01886af0);
  return;
}



/* FUNCTION 661 ; VA 0x0049d790 ; FUN_0049d790 */

void FUN_0049d790(void)

{
  FUN_009a0bb0(0xfffffecc009bf8c0,0,s_RemoveStatus_02123f48,s_status_02123f34,0,0,1,0);
  FUN_016f3654(&LAB_01886b10);
  return;
}



/* FUNCTION 662 ; VA 0x0049d810 ; FUN_0049d810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049d810(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [200];
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d390c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_009c3070;
  uStack_28 = 0xfffffecc;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0099be20();
  FUN_009cb790(uVar2,s_SetClickToWalkEnabled_02123df4,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02122b00 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_02122ac8 = RBX::Reflection::BoundFuncDesc<class_RBX::Humanoid,void___cdecl(bool),1>::vftable;
  _DAT_02122b08 = 0;
  DAT_02122b0c = (undefined *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02122aec = FUN_00888530();
  puVar1 = DAT_02122b0c;
  if (DAT_02122b0c == (undefined *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088daf0();
    iStack_f8 = 0;
    auStack_f4[0] = *puVar1;
    iStack_f8 = FUN_005c9ef0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_enabled_02123dec);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
  }
  FUN_016f3654(&LAB_01886b30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 663 ; VA 0x0049d9c0 ; FUN_0049d9c0 */

void FUN_0049d9c0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009a0700(0xfffffecc009c6ff0,0,s_TakeDamage_02123dd4,s_amount_02123dcc,0,uStack_10,0);
  FUN_016f3654(&LAB_01886b50);
  return;
}



/* FUNCTION 664 ; VA 0x0049da30 ; FUN_0049da30 */

void FUN_0049da30(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009a0880(0xfffffecc009b1040,0,s_EquipTool_02123fa0,&DAT_02123f98,0,uStack_10,0);
  FUN_016f3654(&LAB_01886b70);
  return;
}



/* FUNCTION 665 ; VA 0x0049daa0 ; FUN_0049daa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049daa0(void)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d392a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_GetStatuses_02123fbc,0,1,0);
  _DAT_02123228 = 0xfffffecc009b70a0;
  uStack_8 = 0;
  _DAT_021231f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Humanoid,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02123230 = 0;
  _DAT_02123214 = FUN_008882f0();
  FUN_016f3654(&LAB_01886bc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 666 ; VA 0x0049db50 ; FUN_0049db50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049db50(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d394a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,s_UnequipTools_02123fac,0,uStack_1c,0);
  _DAT_021231e0 = 0xfffffecc009c7940;
  uStack_8 = 0;
  _DAT_021231a8 = RBX::Reflection::BoundFuncDesc<class_RBX::Humanoid,void___cdecl(void),0>::vftable;
  _DAT_021231e8 = 0;
  _DAT_021231cc = FUN_00888530();
  FUN_016f3654(&LAB_01886bd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 667 ; VA 0x0049dc00 ; FUN_0049dc00 */

void FUN_0049dc00(void)

{
  uint uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined8 uStack_17c;
  undefined8 uStack_174;
  undefined4 uStack_16c;
  uint uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined8 uStack_158;
  undefined8 uStack_150;
  undefined4 uStack_148;
  uint uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined8 uStack_12c;
  undefined4 uStack_124;
  uint uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined8 uStack_110;
  undefined8 uStack_108;
  undefined4 uStack_100;
  uint uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined8 uStack_ec;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  uint uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined4 uStack_b8;
  uint uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  uint uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  uint uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d39a2;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_24 = 0;
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = uStack_48 & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("FaceCenterAttachment",0x14);
  uStack_174 = CONCAT44((int)uStack_24,(int)uStack_24);
  uStack_28 = uStack_14;
  uStack_18c = uStack_48;
  uStack_188 = uStack_44;
  uStack_184 = uStack_40;
  uStack_180 = uStack_3c;
  uStack_16c = uStack_14;
  uStack_17c = CONCAT44(uStack_34,uStack_38);
  uStack_8 = 0;
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = uStack_48 & 0xffffff00;
  uStack_14 = 0xbf19999a;
  uStack_5c = 0;
  uStack_58 = 0xf;
  uStack_6c = uStack_6c & 0xffffff00;
  uStack_30 = uStack_174;
  FUN_005542c0("FaceFrontAttachment",0x13);
  uStack_150 = CONCAT44((int)uStack_24,(int)uStack_24);
  uStack_4c = uStack_14;
  uStack_168 = uStack_6c;
  uStack_164 = uStack_68;
  uStack_160 = uStack_64;
  uStack_15c = uStack_60;
  uStack_148 = uStack_14;
  uStack_158 = CONCAT44(uStack_58,uStack_5c);
  uStack_8._0_1_ = 1;
  uStack_5c = 0;
  uStack_58 = 0xf;
  uStack_6c = uStack_6c & 0xffffff00;
  uStack_14 = 0;
  uStack_80 = 0;
  uStack_7c = 0xf;
  uStack_90 = uStack_90 & 0xffffff00;
  uStack_54 = uStack_150;
  FUN_005542c0("HairAttachment",0xe);
  uStack_12c = CONCAT44(DAT_01901f38,(undefined4)uStack_24);
  uStack_70 = uStack_14;
  uStack_144 = uStack_90;
  uStack_140 = uStack_8c;
  uStack_13c = uStack_88;
  uStack_138 = uStack_84;
  uStack_124 = uStack_14;
  uStack_134 = CONCAT44(uStack_7c,uStack_80);
  uStack_8._0_1_ = 2;
  uStack_80 = 0;
  uStack_7c = 0xf;
  uStack_90 = uStack_90 & 0xffffff00;
  uStack_14 = 0;
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  uStack_b4 = uStack_b4 & 0xffffff00;
  uStack_78 = uStack_12c;
  FUN_005542c0("HatAttachment",0xd);
  uStack_108 = CONCAT44(DAT_01901f38,(undefined4)uStack_24);
  uStack_94 = uStack_14;
  uStack_120 = uStack_b4;
  uStack_11c = uStack_b0;
  uStack_118 = uStack_ac;
  uStack_114 = uStack_a8;
  uStack_100 = uStack_14;
  uStack_110 = CONCAT44(uStack_a0,uStack_a4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  uStack_b4 = uStack_b4 & 0xffffff00;
  uStack_14 = 0;
  uStack_c8 = 0;
  uStack_c4 = 0xf;
  uStack_d8 = uStack_d8 & 0xffffff00;
  uStack_9c = uStack_108;
  FUN_005542c0("NeckRigAttachment",0x11);
  uStack_e4 = CONCAT44(DAT_018f7860,(int)uStack_24);
  uStack_b8 = uStack_14;
  uStack_fc = uStack_d8;
  uStack_f8 = uStack_d4;
  uStack_f4 = uStack_d0;
  uStack_f0 = uStack_cc;
  uStack_dc = uStack_14;
  uStack_ec = CONCAT44(uStack_c4,uStack_c8);
  uStack_c8 = 0;
  uStack_c4 = 0xf;
  uStack_d8 = uStack_d8 & 0xffffff00;
  uStack_8 = 4;
  uStack_c0 = uStack_e4;
  FUN_009a1ed0(&uStack_18c,&uStack_d8);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_18c,0x24,5,FUN_005507b0);
  FUN_016f3654(&LAB_01886be0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 668 ; VA 0x0049df50 ; FUN_0049df50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049df50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d39ec;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("HumanoidRootPart",0x10);
  uStack_8 = 0;
  _DAT_01d64b38 = 0;
  _DAT_01d64b3c = 0xf;
  DAT_01d64b28 = 0;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_8._0_1_ = 1;
  _DAT_01d64b50 = 0;
  _DAT_01d64b54 = 0xf;
  DAT_01d64b40 = 0;
  FUN_005542c0("Right Arm",9);
  uStack_8._0_1_ = 2;
  _DAT_01d64b68 = 0;
  _DAT_01d64b6c = 0xf;
  DAT_01d64b58 = 0;
  FUN_005542c0("Left Arm",8);
  uStack_8._0_1_ = 3;
  _DAT_01d64b80 = 0;
  _DAT_01d64b84 = 0xf;
  DAT_01d64b70 = 0;
  FUN_005542c0("Right Leg",9);
  uStack_8._0_1_ = 4;
  _DAT_01d64b98 = 0;
  _DAT_01d64b9c = 0xf;
  DAT_01d64b88 = 0;
  FUN_005542c0("Left Leg",8);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  _DAT_01d64bb0 = 0;
  _DAT_01d64bb4 = 0xf;
  DAT_01d64ba0 = 0;
  FUN_005542c0("Torso",5);
  FUN_016f3654(&LAB_01886bf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 669 ; VA 0x0049e0c0 ; FUN_0049e0c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049e0c0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3a3c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("HumanoidRootPart",0x10);
  uStack_8 = 0;
  _DAT_01d64be0 = 0;
  _DAT_01d64be4 = 0xf;
  DAT_01d64bd0 = 0;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_8._0_1_ = 1;
  _DAT_01d64bf8 = 0;
  _DAT_01d64bfc = 0xf;
  DAT_01d64be8 = 0;
  FUN_005542c0("RightArm",8);
  uStack_8._0_1_ = 2;
  _DAT_01d64c10 = 0;
  _DAT_01d64c14 = 0xf;
  DAT_01d64c00 = 0;
  FUN_005542c0("LeftArm",7);
  uStack_8._0_1_ = 3;
  _DAT_01d64c28 = 0;
  _DAT_01d64c2c = 0xf;
  DAT_01d64c18 = 0;
  FUN_005542c0("RightLeg",8);
  uStack_8._0_1_ = 4;
  _DAT_01d64c40 = 0;
  _DAT_01d64c44 = 0xf;
  DAT_01d64c30 = 0;
  FUN_005542c0("LeftLeg",7);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  _DAT_01d64c58 = 0;
  _DAT_01d64c5c = 0xf;
  DAT_01d64c48 = 0;
  FUN_005542c0("UpperTorso",10);
  FUN_016f3654(&LAB_01886c10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 670 ; VA 0x0049e230 ; FUN_0049e230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049e230(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3ae6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_8 = 0;
  DAT_01d64c7c = 1;
  _DAT_01d64c90 = 0;
  DAT_01d64c94 = 0xf;
  DAT_01d64c80 = 0;
  FUN_005542c0("UpperTorso",10);
  uStack_8._0_1_ = 1;
  _DAT_01d64c98 = 2;
  _DAT_01d64cac = 0;
  _DAT_01d64cb0 = 0xf;
  DAT_01d64c9c = 0;
  FUN_005542c0("LowerTorso",10);
  uStack_8._0_1_ = 2;
  _DAT_01d64cb4 = 3;
  _DAT_01d64cc8 = 0;
  _DAT_01d64ccc = 0xf;
  DAT_01d64cb8 = 0;
  FUN_005542c0("LeftFoot",8);
  uStack_8._0_1_ = 3;
  _DAT_01d64cd0 = 4;
  _DAT_01d64ce4 = 0;
  _DAT_01d64ce8 = 0xf;
  DAT_01d64cd4 = 0;
  FUN_005542c0("LeftLowerLeg",0xc);
  uStack_8._0_1_ = 4;
  _DAT_01d64cec = 5;
  _DAT_01d64d00 = 0;
  _DAT_01d64d04 = 0xf;
  DAT_01d64cf0 = 0;
  FUN_005542c0("LeftUpperLeg",0xc);
  uStack_8._0_1_ = 5;
  _DAT_01d64d08 = 6;
  _DAT_01d64d1c = 0;
  _DAT_01d64d20 = 0xf;
  DAT_01d64d0c = 0;
  FUN_005542c0("RightFoot",9);
  uStack_8._0_1_ = 6;
  _DAT_01d64d24 = 7;
  _DAT_01d64d38 = 0;
  _DAT_01d64d3c = 0xf;
  DAT_01d64d28 = 0;
  FUN_005542c0("RightLowerLeg",0xd);
  uStack_8._0_1_ = 7;
  _DAT_01d64d40 = 8;
  _DAT_01d64d54 = 0;
  _DAT_01d64d58 = 0xf;
  DAT_01d64d44 = 0;
  FUN_005542c0("RightUpperLeg",0xd);
  uStack_8._0_1_ = 8;
  _DAT_01d64d5c = 9;
  _DAT_01d64d70 = 0;
  _DAT_01d64d74 = 0xf;
  DAT_01d64d60 = 0;
  FUN_005542c0("LeftHand",8);
  uStack_8._0_1_ = 9;
  _DAT_01d64d78 = 10;
  _DAT_01d64d8c = 0;
  _DAT_01d64d90 = 0xf;
  DAT_01d64d7c = 0;
  FUN_005542c0("LeftLowerArm",0xc);
  uStack_8._0_1_ = 10;
  _DAT_01d64d94 = 0xb;
  _DAT_01d64da8 = 0;
  _DAT_01d64dac = 0xf;
  DAT_01d64d98 = 0;
  FUN_005542c0("LeftUpperArm",0xc);
  uStack_8._0_1_ = 0xb;
  _DAT_01d64db0 = 0xc;
  _DAT_01d64dc4 = 0;
  _DAT_01d64dc8 = 0xf;
  DAT_01d64db4 = 0;
  FUN_005542c0("RightHand",9);
  uStack_8._0_1_ = 0xc;
  _DAT_01d64dcc = 0xd;
  _DAT_01d64de0 = 0;
  _DAT_01d64de4 = 0xf;
  DAT_01d64dd0 = 0;
  FUN_005542c0("RightLowerArm",0xd);
  uStack_8._0_1_ = 0xd;
  _DAT_01d64de8 = 0xe;
  _DAT_01d64dfc = 0;
  _DAT_01d64e00 = 0xf;
  DAT_01d64dec = 0;
  FUN_005542c0("RightUpperArm",0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  _DAT_01d64e04 = 0xf;
  _DAT_01d64e18 = 0;
  _DAT_01d64e1c = 0xf;
  DAT_01d64e08 = 0;
  FUN_005542c0("HumanoidRootPart",0x10);
  FUN_016f3654(&LAB_01886c30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 671 ; VA 0x0049e5e0 ; FUN_0049e5e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049e5e0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3b22;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("BodyHeightScale",0xf);
  uStack_8 = 0;
  _DAT_01d64e48 = 0;
  DAT_01d64e4c = 0xf;
  DAT_01d64e38 = 0;
  FUN_005542c0("BodyWidthScale",0xe);
  uStack_8._0_1_ = 1;
  _DAT_01d64e60 = 0;
  _DAT_01d64e64 = 0xf;
  DAT_01d64e50 = 0;
  FUN_005542c0("BodyDepthScale",0xe);
  uStack_8._0_1_ = 2;
  _DAT_01d64e78 = 0;
  _DAT_01d64e7c = 0xf;
  DAT_01d64e68 = 0;
  FUN_005542c0("HeadScale",9);
  uStack_8._0_1_ = 3;
  _DAT_01d64e90 = 0;
  _DAT_01d64e94 = 0xf;
  DAT_01d64e80 = 0;
  FUN_005542c0("BodyTypeScale",0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  _DAT_01d64ea8 = 0;
  _DAT_01d64eac = 0xf;
  DAT_01d64e98 = 0;
  FUN_005542c0("BodyProportionScale",0x13);
  FUN_016f3654(&LAB_01886c50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 672 ; VA 0x0049e720 ; FUN_0049e720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049e720(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3b4e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,&DAT_0211f968,0,uStack_1c,0);
  _DAT_021224b0 = 0xfffffecc009ba920;
  _DAT_02122478 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Humanoid,void___cdecl(class_G3D::Vector3,bool),2>::
       vftable;
  _DAT_021224b8 = 0;
  DAT_021224bc = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  DAT_021224c0 = (undefined *)FUN_01674e20(1);
  if (DAT_021224c0 == (undefined *)0x0) {
    DAT_021224c0 = (undefined *)0x0;
  }
  else {
    *DAT_021224c0 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_009aede0();
  FUN_016f3654(&LAB_01886c70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 673 ; VA 0x0049e810 ; FUN_0049e810 */

void FUN_0049e810(void)

{
  FUN_0099af90(s_AutoJumpEnabled_0211fd7c,s_Jump_Settings_02123ba0,0xfffffecc009b3f00,0,
               0xfffffecc009c2d70,0,0,0,0,0x1f,0);
  FUN_016f3654(&LAB_01886db0);
  return;
}



/* FUNCTION 674 ; VA 0x0049e8a0 ; FUN_0049e8a0 */

void FUN_0049e8a0(void)

{
  FUN_0099af90(s_AutoRotate_02123ce4,s_Control_0211ffd0,0xfffffecc009b3f10,0,0xfffffecc009c2dd0,0,0,
               0,0,0x1f,0);
  FUN_016f3654(&LAB_01886dd0);
  return;
}



/* FUNCTION 675 ; VA 0x0049e9e0 ; FUN_0049e9e0 */

void FUN_0049e9e0(void)

{
  FUN_0099af90(s_BreakJointsOnDeath_02123cf0,s_Behavior_0211a8f8,0xfffffecc009b4750,0,
               0xfffffecc009c2f00,0,0,0,0,0x1f,0);
  FUN_016f3654(&LAB_01886e10);
  return;
}



/* FUNCTION 676 ; VA 0x0049ea70 ; FUN_0049ea70 */

void FUN_0049ea70(void)

{
  FUN_0099b0a0(s_CameraMaxDistance_02123d98,&DAT_021197d4,0x9b5430,0,0xf81e60,0,0,0,0,2,0);
  FUN_016f3654(&LAB_01886e30);
  return;
}



/* FUNCTION 677 ; VA 0x0049eb00 ; FUN_0049eb00 */

void FUN_0049eb00(void)

{
  FUN_0099b0a0(s_CameraMinDistance_02123d84,&DAT_021197d4,0x9b5480,0,0xf81e90,0,0,0,0,2,0);
  FUN_016f3654(&LAB_01886e50);
  return;
}



/* FUNCTION 678 ; VA 0x0049eb90 ; FUN_0049eb90 */

void FUN_0049eb90(void)

{
  FUN_0099aca0(s_CameraOffset_02123dac,&DAT_021197d4,0xfffffecc009b4760,0,0xfffffecc009c3010,0,0,0,0
               ,0x13,0);
  FUN_016f3654(&LAB_01886e70);
  return;
}



/* FUNCTION 679 ; VA 0x0049ec20 ; FUN_0049ec20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049ec20(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3b7c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0099be20();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xfffffecc009b4ab0;
    *(undefined8 *)(puVar3 + 6) = 0xfffffecc009c3140;
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Humanoid,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_DisplayName_0211fb6c,&DAT_021197d4,uStack_3c,0,0,0x1f,0,0,0);
  DAT_02122358 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212238c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212237c = _DAT_0212237c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02122358[2])();
    if (cVar1 != '\0') {
      _DAT_0212237c = _DAT_0212237c & 0xfffffff3;
    }
  }
  DAT_02122358 = RBX::Reflection::
                 PropDescriptor<class_RBX::Humanoid,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_01886e90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 680 ; VA 0x0049ed70 ; FUN_0049ed70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049ed70(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3ba4;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00896e70();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,s_FloorMaterial_02123d14,s_Control_0211ffd0,uStack_30,0,0,0x13,0,0,1);
  uStack_8 = 0;
  DAT_02122770 = RBX::Reflection::EnumPropDescriptor<class_RBX::Humanoid,enum_RBX::PartMaterial>::
                 vftable;
  _DAT_021227a4 = uVar2;
  DAT_021227a8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021227a8 == (undefined4 *)0x0) {
    DAT_021227a8 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_021227a8 + 2) = 0xfffffecc009b4c90;
    *DAT_021227a8 =
         RBX::Reflection::PropDescriptor<class_RBX::Humanoid,enum_RBX::PartMaterial>::
         GetImpl<enum_RBX::PartMaterial_(__thiscall_RBX::Humanoid::*)(void)const_>::vftable;
    DAT_021227a8[4] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021227ac = FUN_00896e70();
  cVar1 = (*(code *)DAT_02122770[3])();
  if (cVar1 != '\0') {
    _DAT_02122794 = _DAT_02122794 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02122770[2])();
  if (cVar1 != '\0') {
    _DAT_02122794 = _DAT_02122794 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01886eb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 681 ; VA 0x0049ee90 ; FUN_0049ee90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049ee90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3bc4;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00896e70();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,s_FloorMaterialInternal_02123d24,s_Control_0211ffd0,uStack_3c,0,0,2,0,0,1
              );
  uStack_8 = 0;
  DAT_021227b0 = RBX::Reflection::EnumPropDescriptor<class_RBX::Humanoid,enum_RBX::PartMaterial>::
                 vftable;
  _DAT_021227e4 = uVar2;
  DAT_021227e8 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_021227e8 == (undefined4 *)0x0) {
    DAT_021227e8 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_021227e8 + 2) = 0xfffffecc009b4c90;
    *(undefined8 *)(DAT_021227e8 + 6) = 0xfffffecc009c3540;
    *DAT_021227e8 =
         RBX::Reflection::PropDescriptor<class_RBX::Humanoid,enum_RBX::PartMaterial>::
         GetSetImpl<enum_RBX::PartMaterial_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(enum_RBX::PartMaterial)>
         ::vftable;
    DAT_021227e8[4] = 0;
    DAT_021227e8[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021227ec = FUN_00896e70();
  cVar1 = (*(code *)DAT_021227b0[3])();
  if (cVar1 != '\0') {
    _DAT_021227d4 = _DAT_021227d4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021227b0[2])();
  if (cVar1 != '\0') {
    _DAT_021227d4 = _DAT_021227d4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01886ed0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 682 ; VA 0x0049f0b0 ; FUN_0049f0b0 */

void FUN_0049f0b0(void)

{
  FUN_0099ad30(s_Health_02123b68,&DAT_02123b60,0xfffffecc00927160,0,0xfffffecc009c38b0,0,0,0,0,0x15,
               0);
  FUN_016f3654(&LAB_01886f10);
  return;
}



/* FUNCTION 683 ; VA 0x0049f2e0 ; FUN_0049f2e0 */

void FUN_0049f2e0(void)

{
  FUN_0099ac10(s_MoveDirectionInternal_02123d4c,s_Control_0211ffd0,0xfffffecc009b5410,0,
               0xfffffecc009c3ea0,0,0,0,0,2,0);
  FUN_016f3654(&LAB_01886f70);
  return;
}



/* FUNCTION 684 ; VA 0x0049f610 ; FUN_0049f610 */

void FUN_0049f610(void)

{
  FUN_0099af90(s_PlatformStand_02123cd4,s_Control_0211ffd0,0xfffffecc009b67b0,0,0xfffffecc009c44c0,0
               ,0,0,0,0x13,0);
  FUN_016f3654(&LAB_01886ff0);
  return;
}



/* FUNCTION 685 ; VA 0x0049f6a0 ; FUN_0049f6a0 */

void FUN_0049f6a0(void)

{
  FUN_0099af90(s_RequiresNeck_02123d04,s_Behavior_0211a8f8,0xfffffecc009b6b30,0,0xfffffecc009c45f0,0
               ,0,0,0,0x1f,0);
  FUN_016f3654(&LAB_01887010);
  return;
}



/* FUNCTION 686 ; VA 0x0049f730 ; FUN_0049f730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049f730(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3be4;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0098d050();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,s_RigType_02123d7c,&DAT_021197d4,uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021228d0 = RBX::Reflection::EnumPropDescriptor<class_RBX::Humanoid,enum_RBX::HumanoidRigType>
                 ::vftable;
  _DAT_02122904 = uVar2;
  DAT_02122908 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_02122908 == (undefined4 *)0x0) {
    DAT_02122908 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_02122908 + 2) = 0xfffffecc0074b4f0;
    *(undefined8 *)(DAT_02122908 + 6) = 0xfffffecc009c4660;
    *DAT_02122908 =
         RBX::Reflection::PropDescriptor<class_RBX::Humanoid,enum_RBX::HumanoidRigType>::
         GetSetImpl<enum_RBX::HumanoidRigType_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(enum_RBX::HumanoidRigType)>
         ::vftable;
    DAT_02122908[4] = 0;
    DAT_02122908[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0212290c = FUN_0098d050();
  cVar1 = (*(code *)DAT_021228d0[3])();
  if (cVar1 != '\0') {
    _DAT_021228f4 = _DAT_021228f4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021228d0[2])();
  if (cVar1 != '\0') {
    _DAT_021228f4 = _DAT_021228f4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01887030);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 687 ; VA 0x0049f870 ; FUN_0049f870 */

void FUN_0049f870(void)

{
  FUN_0099adc0(s_RootPart_02123b38,&DAT_021197d4,0xfffffecc009b7250,0,0,0,0,0,0x1f,0);
  FUN_016f3654(&LAB_01887050);
  return;
}



/* FUNCTION 688 ; VA 0x0049f8e0 ; FUN_0049f8e0 */

void FUN_0049f8e0(void)

{
  FUN_0099adc0(s_SeatPart_02123c78,s_Control_0211ffd0,0xfffffecc009b6e70,0,0,0,0,0,0x13,0);
  FUN_016f3654(&LAB_01887070);
  return;
}



/* FUNCTION 689 ; VA 0x0049f950 ; FUN_0049f950 */

void FUN_0049f950(void)

{
  FUN_0099af90(s_Strafe_02123d74,s_Control_0211ffd0,0xfffffecc009b71a0,0,0xfffffecc009c5040,0,0,0,0,
               2,0);
  FUN_016f3654(&LAB_01887090);
  return;
}



/* FUNCTION 690 ; VA 0x0049f9e0 ; FUN_0049f9e0 */

void FUN_0049f9e0(void)

{
  FUN_0099aca0(s_TargetPoint_02123cac,s_Control_0211ffd0,0xfffffecc009b71b0,0,0xfffffecc009c5250,0,0
               ,0,0,0x13,0);
  FUN_016f3654(&LAB_018870b0);
  return;
}



/* FUNCTION 691 ; VA 0x0049fb50 ; FUN_0049fb50 */

void FUN_0049fb50(void)

{
  FUN_0099ac10(s_WalkDirection_02123d3c,s_Control_0211ffd0,0xfffffecc009b7810,0,0xfffffecc009c5830,0
               ,0,0,0,2,0);
  FUN_016f3654(&LAB_018870f0);
  return;
}



/* FUNCTION 692 ; VA 0x0049fbe0 ; FUN_0049fbe0 */

void FUN_0049fbe0(void)

{
  FUN_0099aea0(s_WalkToPart_02123c94,s_Control_0211ffd0,0xfffffecc009b7c10,0,0xfffffecc009c5b10,0,0,
               0,0,0x13,0);
  FUN_016f3654(&LAB_01887110);
  return;
}



/* FUNCTION 693 ; VA 0x0049fc70 ; FUN_0049fc70 */

void FUN_0049fc70(void)

{
  FUN_0099aca0(s_WalkToPoint_02123ca0,s_Control_0211ffd0,0xfffffecc00731570,0,0xfffffecc009c5c00,0,0
               ,0,0,0x13,0);
  FUN_016f3654(&LAB_01887130);
  return;
}



/* FUNCTION 694 ; VA 0x0049fd00 ; FUN_0049fd00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049fd00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3c04;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935b10();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,s_CameraMode_0211ff3c,&DAT_021197d4,uStack_3c,0,0,2,0,0,1);
  uStack_8 = 0;
  DAT_021229b8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Humanoid,enum_RBX::Camera::CameraMode>::vftable;
  _DAT_021229ec = uVar2;
  DAT_021229f0 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_021229f0 == (undefined4 *)0x0) {
    DAT_021229f0 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_021229f0 + 2) = 0x5817e0;
    *(undefined8 *)(DAT_021229f0 + 6) = 0xf81e40;
    *DAT_021229f0 =
         RBX::Reflection::PropDescriptor<class_RBX::Humanoid,enum_RBX::Camera::CameraMode>::
         GetSetImpl<enum_RBX::Camera::CameraMode_(__thiscall_RBX::ICharacterSubject::*)(void)const_,void_(__thiscall_RBX::ICharacterSubject::*)(enum_RBX::Camera::CameraMode)>
         ::vftable;
    DAT_021229f0[4] = 0;
    DAT_021229f0[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021229f4 = FUN_00935b10();
  cVar1 = (*(code *)DAT_021229b8[3])();
  if (cVar1 != '\0') {
    _DAT_021229dc = _DAT_021229dc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021229b8[2])();
  if (cVar1 != '\0') {
    _DAT_021229dc = _DAT_021229dc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01887150);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 695 ; VA 0x0049fe40 ; FUN_0049fe40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049fe40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3c24;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009c63c0();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,s_CollisionType_02123dbc,s_Behavior_0211a8f8,uStack_3c,0,0,0x1f,0,1,1);
  uStack_8 = 0;
  DAT_021229f8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Humanoid,enum_RBX::Humanoid::CollisionType>::vftable;
  _DAT_02122a2c = uVar2;
  DAT_02122a30 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_02122a30 == (undefined4 *)0x0) {
    DAT_02122a30 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_02122a30 + 2) = 0xfffffecc009b4890;
    *(undefined8 *)(DAT_02122a30 + 6) = 0xfffffecc009c3080;
    *DAT_02122a30 =
         RBX::Reflection::PropDescriptor<class_RBX::Humanoid,enum_RBX::Humanoid::CollisionType>::
         GetSetImpl<enum_RBX::Humanoid::CollisionType_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(enum_RBX::Humanoid::CollisionType)>
         ::vftable;
    DAT_02122a30[4] = 0;
    DAT_02122a30[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02122a34 = FUN_009c63c0();
  cVar1 = (*(code *)DAT_021229f8[3])();
  if (cVar1 != '\0') {
    _DAT_02122a1c = _DAT_02122a1c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021229f8[2])();
  if (cVar1 != '\0') {
    _DAT_02122a1c = _DAT_02122a1c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01887170);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 696 ; VA 0x0049ff80 ; FUN_0049ff80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0049ff80(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3c44;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009c6470();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,s_DisplayDistanceType_02124044,&DAT_021197d4,uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02123408 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Humanoid,enum_RBX::Humanoid::HumanoidDisplayDistanceType>
                 ::vftable;
  _DAT_0212343c = uVar2;
  DAT_02123440 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_02123440 == (undefined4 *)0x0) {
    DAT_02123440 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_02123440 + 2) = 0xfffffecc009b4aa0;
    *(undefined8 *)(DAT_02123440 + 6) = 0xfffffecc009c30e0;
    *DAT_02123440 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Humanoid,enum_RBX::Humanoid::HumanoidDisplayDistanceType>::
         GetSetImpl<enum_RBX::Humanoid::HumanoidDisplayDistanceType_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(enum_RBX::Humanoid::HumanoidDisplayDistanceType)>
         ::vftable;
    DAT_02123440[4] = 0;
    DAT_02123440[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02123444 = FUN_009c6470();
  cVar1 = (*(code *)DAT_02123408[3])();
  if (cVar1 != '\0') {
    _DAT_0212342c = _DAT_0212342c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02123408[2])();
  if (cVar1 != '\0') {
    _DAT_0212342c = _DAT_0212342c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01887190);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 697 ; VA 0x004a00c0 ; FUN_004a00c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a00c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3c64;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009c6520();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,s_HealthDisplayType_02124058,&DAT_021197d4,uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02123448 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Humanoid,enum_RBX::Humanoid::HumanoidHealthDisplayType>
                 ::vftable;
  _DAT_0212347c = uVar2;
  DAT_02123480 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_02123480 == (undefined4 *)0x0) {
    DAT_02123480 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_02123480 + 2) = 0xfffffecc009b4d80;
    *(undefined8 *)(DAT_02123480 + 6) = 0xfffffecc009c3850;
    *DAT_02123480 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Humanoid,enum_RBX::Humanoid::HumanoidHealthDisplayType>::
         GetSetImpl<enum_RBX::Humanoid::HumanoidHealthDisplayType_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(enum_RBX::Humanoid::HumanoidHealthDisplayType)>
         ::vftable;
    DAT_02123480[4] = 0;
    DAT_02123480[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02123484 = FUN_009c6520();
  cVar1 = (*(code *)DAT_02123448[3])();
  if (cVar1 != '\0') {
    _DAT_0212346c = _DAT_0212346c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02123448[2])();
  if (cVar1 != '\0') {
    _DAT_0212346c = _DAT_0212346c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018871b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 698 ; VA 0x004a0200 ; FUN_004a0200 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a0200(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3c84;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009c6680();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,s_NameOcclusion_02124034,&DAT_021197d4,uStack_3c,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021233c8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Humanoid,enum_RBX::Humanoid::NameOcclusion>::vftable;
  _DAT_021233fc = uVar2;
  DAT_02123400 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_02123400 == (undefined4 *)0x0) {
    DAT_02123400 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_02123400 + 2) = 0xfffffecc009b54a0;
    *(undefined8 *)(DAT_02123400 + 6) = 0xfffffecc009c4390;
    *DAT_02123400 =
         RBX::Reflection::PropDescriptor<class_RBX::Humanoid,enum_RBX::Humanoid::NameOcclusion>::
         GetSetImpl<enum_RBX::Humanoid::NameOcclusion_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(enum_RBX::Humanoid::NameOcclusion)>
         ::vftable;
    DAT_02123400[4] = 0;
    DAT_02123400[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02123404 = FUN_009c6680();
  cVar1 = (*(code *)DAT_021233c8[3])();
  if (cVar1 != '\0') {
    _DAT_021233ec = _DAT_021233ec & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021233c8[2])();
  if (cVar1 != '\0') {
    _DAT_021233ec = _DAT_021233ec & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018871d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 699 ; VA 0x004a0340 ; FUN_004a0340 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a0340(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3ca4;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009c67e0();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,s_NetworkHumanoidState_02123c50,&DAT_021197d4,uStack_3c,0,0,2,0,0,1);
  uStack_8 = 0;
  DAT_02122438 = RBX::Reflection::EnumPropDescriptor<class_RBX::Humanoid,enum_RBX::HUMAN::StateType>
                 ::vftable;
  _DAT_0212246c = uVar2;
  DAT_02122470 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_02122470 == (undefined4 *)0x0) {
    DAT_02122470 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_02122470 + 2) = 0xfffffecc009b5510;
    *(undefined8 *)(DAT_02122470 + 6) = 0xfffffecc009c43f0;
    *DAT_02122470 =
         RBX::Reflection::PropDescriptor<class_RBX::Humanoid,enum_RBX::HUMAN::StateType>::
         GetSetImpl<enum_RBX::HUMAN::StateType_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(enum_RBX::HUMAN::StateType)>
         ::vftable;
    DAT_02122470[4] = 0;
    DAT_02122470[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02122474 = FUN_009c67e0();
  cVar1 = (*(code *)DAT_02122438[3])();
  if (cVar1 != '\0') {
    _DAT_0212245c = _DAT_0212245c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02122438[2])();
  if (cVar1 != '\0') {
    _DAT_0212245c = _DAT_0212245c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018871f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 700 ; VA 0x004a0560 ; FUN_004a0560 */

void FUN_004a0560(void)

{
  FUN_0099ad30(s_InternalHeadScale_02123c20,&DAT_021197d4,0xfffffecc009b4d40,0,0xfffffecc009c3690,0,
               0,0,0,0xc,0);
  FUN_016f3654(&LAB_01887230);
  return;
}



/* FUNCTION 701 ; VA 0x004a05f0 ; FUN_004a05f0 */

void FUN_004a05f0(void)

{
  FUN_0099ad30(s_InternalOriginalHipHeight_02123c34,&DAT_021197d4,0xfffffecc009b5ab0,0,
               0xfffffecc009c4450,0,0,0,0,2,0);
  FUN_016f3654(&LAB_01887250);
  return;
}



/* FUNCTION 702 ; VA 0x004a0680 ; FUN_004a0680 */

void FUN_004a0680(void)

{
  uint uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined4 uStack_468;
  undefined8 uStack_464;
  undefined8 uStack_45c;
  undefined4 uStack_454;
  uint uStack_450;
  undefined4 uStack_44c;
  undefined4 uStack_448;
  undefined4 uStack_444;
  undefined8 uStack_440;
  undefined8 uStack_438;
  undefined4 uStack_430;
  uint uStack_42c;
  undefined4 uStack_428;
  undefined4 uStack_424;
  undefined4 uStack_420;
  undefined8 uStack_41c;
  undefined8 uStack_414;
  undefined4 uStack_40c;
  uint uStack_408;
  undefined4 uStack_404;
  undefined4 uStack_400;
  undefined4 uStack_3fc;
  undefined8 uStack_3f8;
  undefined8 uStack_3f0;
  undefined4 uStack_3e8;
  uint uStack_3e4;
  undefined4 uStack_3e0;
  undefined4 uStack_3dc;
  undefined4 uStack_3d8;
  undefined8 uStack_3d4;
  undefined8 uStack_3cc;
  undefined4 uStack_3c4;
  uint uStack_3c0;
  undefined4 uStack_3bc;
  undefined4 uStack_3b8;
  undefined4 uStack_3b4;
  undefined8 uStack_3b0;
  undefined8 uStack_3a8;
  undefined4 uStack_3a0;
  uint uStack_39c;
  undefined4 uStack_398;
  undefined4 uStack_394;
  undefined4 uStack_390;
  undefined8 uStack_38c;
  undefined8 uStack_384;
  undefined4 uStack_37c;
  uint uStack_378;
  undefined4 uStack_374;
  undefined4 uStack_370;
  undefined4 uStack_36c;
  undefined8 uStack_368;
  undefined8 uStack_360;
  undefined4 uStack_358;
  uint uStack_354;
  undefined4 uStack_350;
  undefined4 uStack_34c;
  undefined4 uStack_348;
  undefined8 uStack_344;
  undefined8 uStack_33c;
  undefined4 uStack_334;
  uint uStack_330;
  undefined4 uStack_32c;
  undefined4 uStack_328;
  undefined4 uStack_324;
  undefined8 uStack_320;
  undefined8 uStack_318;
  undefined4 uStack_310;
  uint uStack_30c;
  undefined4 uStack_308;
  undefined4 uStack_304;
  undefined4 uStack_300;
  undefined8 uStack_2fc;
  undefined8 uStack_2f4;
  undefined4 uStack_2ec;
  uint uStack_2e8;
  undefined4 uStack_2e4;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined8 uStack_2d8;
  undefined8 uStack_2d0;
  undefined4 uStack_2c8;
  uint uStack_2c4;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined8 uStack_2b4;
  undefined8 uStack_2ac;
  undefined4 uStack_2a4;
  uint uStack_2a0;
  undefined4 uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined8 uStack_290;
  undefined8 uStack_288;
  undefined4 uStack_280;
  uint uStack_27c;
  undefined4 uStack_278;
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined8 uStack_26c;
  undefined8 uStack_264;
  undefined4 uStack_25c;
  uint uStack_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined8 uStack_240;
  undefined4 uStack_238;
  uint uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined8 uStack_21c;
  undefined4 uStack_214;
  uint uStack_210;
  undefined4 uStack_20c;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined8 uStack_1f8;
  undefined4 uStack_1f0;
  uint uStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined8 uStack_1d4;
  undefined4 uStack_1cc;
  uint uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined8 uStack_1b0;
  undefined4 uStack_1a8;
  uint uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined8 uStack_18c;
  undefined4 uStack_184;
  uint uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined8 uStack_168;
  undefined4 uStack_160;
  uint uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined8 uStack_144;
  undefined4 uStack_13c;
  uint uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  uint uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined8 uStack_fc;
  undefined4 uStack_f4;
  uint uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_d0;
  uint uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined8 uStack_b4;
  undefined4 uStack_ac;
  uint uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_88;
  uint uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  ulonglong uStack_3c;
  undefined8 uStack_30;
  undefined8 uStack_24;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3d60;
  pvStack_10 = ExceptionList;
  uStack_3c = (ulonglong)DAT_0193990c;
  uStack_30._4_4_ = 0x3f80cbe4;
  uStack_e0 = 0;
  uStack_dc = 0xf;
  uStack_f0 = uStack_f0 & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("LeftLowerArm",0xc);
  uStack_45c = CONCAT44(DAT_0193996c,(undefined4)uStack_3c);
  uStack_d0 = uStack_30._4_4_;
  uStack_474 = uStack_f0;
  uStack_470 = uStack_ec;
  uStack_46c = uStack_e8;
  uStack_468 = uStack_e4;
  uStack_454 = uStack_30._4_4_;
  uStack_464 = CONCAT44(uStack_dc,uStack_e0);
  uStack_8 = 0;
  uStack_e0 = 0;
  uStack_dc = 0xf;
  uStack_f0 = uStack_f0 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_01939904;
  uStack_24._4_4_ = 0x3f81b4e8;
  uStack_104 = 0;
  uStack_100 = 0xf;
  uStack_114 = uStack_114 & 0xffffff00;
  uStack_d8 = uStack_45c;
  FUN_005542c0("LowerTorso",10);
  uStack_438 = CONCAT44(DAT_01939914,(int)uStack_30);
  uStack_f4 = uStack_24._4_4_;
  uStack_450 = uStack_114;
  uStack_44c = uStack_110;
  uStack_448 = uStack_10c;
  uStack_444 = uStack_108;
  uStack_430 = uStack_24._4_4_;
  uStack_440 = CONCAT44(uStack_100,uStack_104);
  uStack_8._0_1_ = 1;
  uStack_104 = 0;
  uStack_100 = 0xf;
  uStack_114 = uStack_114 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_019398e0;
  uStack_24._4_4_ = 0x3f657336;
  uStack_128 = 0;
  uStack_124 = 0xf;
  uStack_138 = uStack_138 & 0xffffff00;
  uStack_fc = uStack_438;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_414 = CONCAT44(DAT_019398f0,(int)uStack_30);
  uStack_118 = uStack_24._4_4_;
  uStack_42c = uStack_138;
  uStack_428 = uStack_134;
  uStack_424 = uStack_130;
  uStack_420 = uStack_12c;
  uStack_40c = uStack_24._4_4_;
  uStack_41c = CONCAT44(uStack_124,uStack_128);
  uStack_8._0_1_ = 2;
  uStack_128 = 0;
  uStack_124 = 0xf;
  uStack_138 = uStack_138 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_019398e4;
  uStack_24._4_4_ = 0x3f81b4e8;
  uStack_14c = 0;
  uStack_148 = 0xf;
  uStack_15c = uStack_15c & 0xffffff00;
  uStack_120 = uStack_414;
  FUN_005542c0("UpperTorso",10);
  uStack_3f0 = CONCAT44(DAT_01939968,(int)uStack_30);
  uStack_13c = uStack_24._4_4_;
  uStack_408 = uStack_15c;
  uStack_404 = uStack_158;
  uStack_400 = uStack_154;
  uStack_3fc = uStack_150;
  uStack_3e8 = uStack_24._4_4_;
  uStack_3f8 = CONCAT44(uStack_148,uStack_14c);
  uStack_8._0_1_ = 3;
  uStack_14c = 0;
  uStack_148 = 0xf;
  uStack_15c = uStack_15c & 0xffffff00;
  uStack_30 = (ulonglong)DAT_019398f8;
  uStack_24._4_4_ = 0x3f8c0f79;
  uStack_170 = 0;
  uStack_16c = 0xf;
  uStack_180 = uStack_180 & 0xffffff00;
  uStack_144 = uStack_3f0;
  FUN_005542c0("RightHand",9);
  uStack_3cc = CONCAT44(DAT_01939964,(undefined4)uStack_30);
  uStack_160 = uStack_24._4_4_;
  uStack_3e4 = uStack_180;
  uStack_3e0 = uStack_17c;
  uStack_3dc = uStack_178;
  uStack_3d8 = uStack_174;
  uStack_3c4 = uStack_24._4_4_;
  uStack_3d4 = CONCAT44(uStack_16c,uStack_170);
  uStack_8._0_1_ = 4;
  uStack_170 = 0;
  uStack_16c = 0xf;
  uStack_180 = uStack_180 & 0xffffff00;
  uStack_24 = (ulonglong)DAT_01939920;
  uStack_14 = 0x3f807482;
  uStack_194 = 0;
  uStack_190 = 0xf;
  uStack_1a4 = uStack_1a4 & 0xffffff00;
  uStack_168 = uStack_3cc;
  FUN_005542c0("RightFoot",9);
  uStack_3a8 = CONCAT44(DAT_01939958,(undefined4)uStack_24);
  uStack_184 = uStack_14;
  uStack_3c0 = uStack_1a4;
  uStack_3bc = uStack_1a0;
  uStack_3b8 = uStack_19c;
  uStack_3b4 = uStack_198;
  uStack_3a0 = uStack_14;
  uStack_3b0 = CONCAT44(uStack_190,uStack_194);
  uStack_8._0_1_ = 5;
  uStack_194 = 0;
  uStack_190 = 0xf;
  uStack_1a4 = uStack_1a4 & 0xffffff00;
  uStack_14 = 0x3f807482;
  uStack_1b8 = 0;
  uStack_1b4 = 0xf;
  uStack_1c8 = uStack_1c8 & 0xffffff00;
  uStack_18c = uStack_3a8;
  FUN_005542c0("LeftFoot",8);
  uStack_384 = CONCAT44(DAT_01939958,(int)uStack_24);
  uStack_1a8 = uStack_14;
  uStack_39c = uStack_1c8;
  uStack_398 = uStack_1c4;
  uStack_394 = uStack_1c0;
  uStack_390 = uStack_1bc;
  uStack_37c = uStack_14;
  uStack_38c = CONCAT44(uStack_1b4,uStack_1b8);
  uStack_8._0_1_ = 6;
  uStack_1b8 = 0;
  uStack_1b4 = 0xf;
  uStack_1c8 = uStack_1c8 & 0xffffff00;
  uStack_14 = 0x3f80cbe4;
  uStack_1dc = 0;
  uStack_1d8 = 0xf;
  uStack_1ec = uStack_1ec & 0xffffff00;
  uStack_1b0 = uStack_384;
  FUN_005542c0("LeftUpperArm",0xc);
  uStack_360 = CONCAT44(DAT_0193996c,(undefined4)uStack_3c);
  uStack_1cc = uStack_14;
  uStack_378 = uStack_1ec;
  uStack_374 = uStack_1e8;
  uStack_370 = uStack_1e4;
  uStack_36c = uStack_1e0;
  uStack_358 = uStack_14;
  uStack_368 = CONCAT44(uStack_1d8,uStack_1dc);
  uStack_8._0_1_ = 7;
  uStack_1dc = 0;
  uStack_1d8 = 0xf;
  uStack_1ec = uStack_1ec & 0xffffff00;
  uStack_14 = 0x3f80cbe4;
  uStack_200 = 0;
  uStack_1fc = 0xf;
  uStack_210 = uStack_210 & 0xffffff00;
  uStack_1d4 = uStack_360;
  FUN_005542c0("RightLowerArm",0xd);
  uStack_33c = CONCAT44(DAT_0193996c,(undefined4)uStack_3c);
  uStack_1f0 = uStack_14;
  uStack_354 = uStack_210;
  uStack_350 = uStack_20c;
  uStack_34c = uStack_208;
  uStack_348 = uStack_204;
  uStack_334 = uStack_14;
  uStack_344 = CONCAT44(uStack_1fc,uStack_200);
  uStack_8._0_1_ = 8;
  uStack_200 = 0;
  uStack_1fc = 0xf;
  uStack_210 = uStack_210 & 0xffffff00;
  uStack_14 = 0x3f8c0f79;
  uStack_224 = 0;
  uStack_220 = 0xf;
  uStack_234 = uStack_234 & 0xffffff00;
  uStack_1f8 = uStack_33c;
  FUN_005542c0("LeftHand",8);
  uStack_318 = CONCAT44(DAT_01939964,(int)uStack_30);
  uStack_214 = uStack_14;
  uStack_330 = uStack_234;
  uStack_32c = uStack_230;
  uStack_328 = uStack_22c;
  uStack_324 = uStack_228;
  uStack_310 = uStack_14;
  uStack_320 = CONCAT44(uStack_220,uStack_224);
  uStack_8._0_1_ = 9;
  uStack_224 = 0;
  uStack_220 = 0xf;
  uStack_234 = uStack_234 & 0xffffff00;
  uStack_24 = (ulonglong)DAT_01939900;
  uStack_14 = 0x3f68ca12;
  uStack_248 = 0;
  uStack_244 = 0xf;
  uStack_258 = uStack_258 & 0xffffff00;
  uStack_21c = uStack_318;
  FUN_005542c0("RightUpperLeg",0xd);
  uStack_2f4 = CONCAT44(DAT_01939990,(undefined4)uStack_24);
  uStack_238 = uStack_14;
  uStack_30c = uStack_258;
  uStack_308 = uStack_254;
  uStack_304 = uStack_250;
  uStack_300 = uStack_24c;
  uStack_2ec = uStack_14;
  uStack_2fc = CONCAT44(uStack_244,uStack_248);
  uStack_8._0_1_ = 10;
  uStack_248 = 0;
  uStack_244 = 0xf;
  uStack_258 = uStack_258 & 0xffffff00;
  uStack_14 = 0x3f80cbe4;
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_60 = uStack_60 & 0xffffff00;
  uStack_240 = uStack_2f4;
  FUN_005542c0("RightUpperArm",0xd);
  uStack_2d0 = CONCAT44(DAT_0193996c,(int)uStack_3c);
  uStack_40 = uStack_14;
  uStack_2e8 = uStack_60;
  uStack_2e4 = uStack_5c;
  uStack_2e0 = uStack_58;
  uStack_2dc = uStack_54;
  uStack_60 = uStack_60 & 0xffffff00;
  uStack_2d8 = CONCAT44(uStack_4c,uStack_50);
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_2c8 = uStack_14;
  uStack_8._0_1_ = 0xb;
  uStack_48 = uStack_2d0;
  FUN_005507b0();
  uStack_14 = 0x3f68ca12;
  uStack_74 = 0;
  uStack_70 = 0xf;
  uStack_84 = uStack_84 & 0xffffff00;
  FUN_005542c0("RightLowerLeg",0xd);
  uStack_2ac = CONCAT44(DAT_01939978,(undefined4)uStack_24);
  uStack_64 = uStack_14;
  uStack_2c4 = uStack_84;
  uStack_2c0 = uStack_80;
  uStack_2bc = uStack_7c;
  uStack_2b8 = uStack_78;
  uStack_84 = uStack_84 & 0xffffff00;
  uStack_2b4 = CONCAT44(uStack_70,uStack_74);
  uStack_74 = 0;
  uStack_70 = 0xf;
  uStack_2a4 = uStack_14;
  uStack_8._0_1_ = 0xc;
  uStack_6c = uStack_2ac;
  FUN_005507b0();
  uStack_14 = 0x3f68ca12;
  uStack_98 = 0;
  uStack_94 = 0xf;
  uStack_a8 = uStack_a8 & 0xffffff00;
  FUN_005542c0("LeftUpperLeg",0xc);
  uStack_288 = CONCAT44(DAT_01939990,(undefined4)uStack_24);
  uStack_88 = uStack_14;
  uStack_2a0 = uStack_a8;
  uStack_29c = uStack_a4;
  uStack_298 = uStack_a0;
  uStack_294 = uStack_9c;
  uStack_a8 = uStack_a8 & 0xffffff00;
  uStack_290 = CONCAT44(uStack_94,uStack_98);
  uStack_98 = 0;
  uStack_94 = 0xf;
  uStack_280 = uStack_14;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  uStack_90 = uStack_288;
  FUN_005507b0();
  uStack_14 = 0x3f68ca12;
  uStack_bc = 0;
  uStack_b8 = 0xf;
  uStack_cc = uStack_cc & 0xffffff00;
  FUN_005542c0("LeftLowerLeg",0xc);
  uStack_264 = CONCAT44(DAT_01939978,(int)uStack_24);
  uStack_ac = uStack_14;
  uStack_27c = uStack_cc;
  uStack_278 = uStack_c8;
  uStack_274 = uStack_c4;
  uStack_270 = uStack_c0;
  uStack_cc = uStack_cc & 0xffffff00;
  uStack_26c = CONCAT44(uStack_b8,uStack_bc);
  uStack_bc = 0;
  uStack_b8 = 0xf;
  uStack_25c = uStack_14;
  uStack_b4 = uStack_264;
  FUN_005507b0();
  uStack_8 = 0xe;
  FUN_009a1ed0(&uStack_474,&uStack_258);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_474,0x24,0xf,FUN_005507b0);
  FUN_016f3654(&LAB_018872d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 703 ; VA 0x004a10a0 ; FUN_004a10a0 */

void FUN_004a10a0(void)

{
  uint uStack_470;
  undefined4 uStack_46c;
  undefined4 uStack_468;
  undefined4 uStack_464;
  undefined8 uStack_460;
  undefined8 uStack_458;
  undefined4 uStack_450;
  uint uStack_44c;
  undefined4 uStack_448;
  undefined4 uStack_444;
  undefined4 uStack_440;
  undefined8 uStack_43c;
  undefined8 uStack_434;
  undefined4 uStack_42c;
  uint uStack_428;
  undefined4 uStack_424;
  undefined4 uStack_420;
  undefined4 uStack_41c;
  undefined8 uStack_418;
  undefined8 uStack_410;
  undefined4 uStack_408;
  uint uStack_404;
  undefined4 uStack_400;
  undefined4 uStack_3fc;
  undefined4 uStack_3f8;
  undefined8 uStack_3f4;
  undefined8 uStack_3ec;
  undefined4 uStack_3e4;
  uint uStack_3e0;
  undefined4 uStack_3dc;
  undefined4 uStack_3d8;
  undefined4 uStack_3d4;
  undefined8 uStack_3d0;
  undefined8 uStack_3c8;
  undefined4 uStack_3c0;
  uint uStack_3bc;
  undefined4 uStack_3b8;
  undefined4 uStack_3b4;
  undefined4 uStack_3b0;
  undefined8 uStack_3ac;
  undefined8 uStack_3a4;
  undefined4 uStack_39c;
  uint uStack_398;
  undefined4 uStack_394;
  undefined4 uStack_390;
  undefined4 uStack_38c;
  undefined8 uStack_388;
  undefined8 uStack_380;
  undefined4 uStack_378;
  uint uStack_374;
  undefined4 uStack_370;
  undefined4 uStack_36c;
  undefined4 uStack_368;
  undefined8 uStack_364;
  undefined8 uStack_35c;
  undefined4 uStack_354;
  uint uStack_350;
  undefined4 uStack_34c;
  undefined4 uStack_348;
  undefined4 uStack_344;
  undefined8 uStack_340;
  undefined8 uStack_338;
  undefined4 uStack_330;
  uint uStack_32c;
  undefined4 uStack_328;
  undefined4 uStack_324;
  undefined4 uStack_320;
  undefined8 uStack_31c;
  undefined8 uStack_314;
  undefined4 uStack_30c;
  uint uStack_308;
  undefined4 uStack_304;
  undefined4 uStack_300;
  undefined4 uStack_2fc;
  undefined8 uStack_2f8;
  undefined8 uStack_2f0;
  undefined4 uStack_2e8;
  uint uStack_2e4;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined8 uStack_2d4;
  undefined8 uStack_2cc;
  undefined4 uStack_2c4;
  uint uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined4 uStack_2b4;
  undefined8 uStack_2b0;
  undefined8 uStack_2a8;
  undefined4 uStack_2a0;
  uint uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined8 uStack_28c;
  undefined8 uStack_284;
  undefined4 uStack_27c;
  uint uStack_278;
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined8 uStack_268;
  undefined8 uStack_260;
  undefined4 uStack_258;
  uint uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined8 uStack_23c;
  undefined4 uStack_234;
  uint uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined8 uStack_218;
  undefined4 uStack_210;
  uint uStack_20c;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined4 uStack_1f8;
  undefined8 uStack_1f4;
  undefined4 uStack_1ec;
  uint uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined8 uStack_1d0;
  undefined4 uStack_1c8;
  uint uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined8 uStack_1ac;
  undefined4 uStack_1a4;
  uint uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined8 uStack_188;
  undefined4 uStack_180;
  uint uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined8 uStack_164;
  undefined4 uStack_15c;
  uint uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined8 uStack_140;
  undefined4 uStack_138;
  uint uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined8 uStack_11c;
  undefined4 uStack_114;
  uint uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  uint uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined8 uStack_d4;
  undefined4 uStack_cc;
  uint uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined8 uStack_b0;
  undefined4 uStack_a8;
  uint uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  undefined4 uStack_84;
  uint uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  ulonglong uStack_38;
  undefined8 uStack_2c;
  ulonglong uStack_24;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3e20;
  pvStack_10 = ExceptionList;
  uStack_38 = (ulonglong)DAT_019398dc;
  uStack_2c._4_4_ = 0x3f843b3d;
  uStack_dc = 0;
  uStack_d8 = 0xf;
  uStack_ec = uStack_ec & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("LeftLowerArm",0xc);
  uStack_458 = CONCAT44(DAT_01939998,(undefined4)uStack_38);
  uStack_cc = uStack_2c._4_4_;
  uStack_470 = uStack_ec;
  uStack_46c = uStack_e8;
  uStack_468 = uStack_e4;
  uStack_464 = uStack_e0;
  uStack_450 = uStack_2c._4_4_;
  uStack_460 = CONCAT44(uStack_d8,uStack_dc);
  uStack_8 = 0;
  uStack_dc = 0;
  uStack_d8 = 0xf;
  uStack_ec = uStack_ec & 0xffffff00;
  uStack_24 = (ulonglong)DAT_01939908;
  uStack_2c._4_4_ = 0x3f8a8734;
  uStack_100 = 0;
  uStack_fc = 0xf;
  uStack_110 = uStack_110 & 0xffffff00;
  uStack_d4 = uStack_458;
  FUN_005542c0("LowerTorso",10);
  uStack_434 = CONCAT44(DAT_01939970,(undefined4)uStack_24);
  uStack_f0 = uStack_2c._4_4_;
  uStack_44c = uStack_110;
  uStack_448 = uStack_10c;
  uStack_444 = uStack_108;
  uStack_440 = uStack_104;
  uStack_42c = uStack_2c._4_4_;
  uStack_43c = CONCAT44(uStack_fc,uStack_100);
  uStack_8._0_1_ = 1;
  uStack_100 = 0;
  uStack_fc = 0xf;
  uStack_110 = uStack_110 & 0xffffff00;
  uStack_2c = (ulonglong)DAT_018f9944;
  uStack_14 = 0x3f200000;
  uStack_124 = 0;
  uStack_120 = 0xf;
  uStack_134 = uStack_134 & 0xffffff00;
  uStack_f8 = uStack_434;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_410 = CONCAT44((int)uStack_2c,(int)uStack_2c);
  uStack_428 = uStack_134;
  uStack_424 = uStack_130;
  uStack_420 = uStack_12c;
  uStack_41c = uStack_128;
  uStack_114 = uStack_14;
  uStack_418 = CONCAT44(uStack_120,uStack_124);
  uStack_408 = uStack_14;
  uStack_8._0_1_ = 2;
  uStack_124 = 0;
  uStack_120 = 0xf;
  uStack_134 = uStack_134 & 0xffffff00;
  uStack_14 = 0x3f8a8734;
  uStack_148 = 0;
  uStack_144 = 0xf;
  uStack_158 = uStack_158 & 0xffffff00;
  uStack_11c = uStack_410;
  FUN_005542c0("UpperTorso",10);
  uStack_3ec = CONCAT44(DAT_01939970,(int)uStack_24);
  uStack_138 = uStack_14;
  uStack_404 = uStack_158;
  uStack_400 = uStack_154;
  uStack_3fc = uStack_150;
  uStack_3f8 = uStack_14c;
  uStack_3e4 = uStack_14;
  uStack_3f4 = CONCAT44(uStack_144,uStack_148);
  uStack_8._0_1_ = 3;
  uStack_148 = 0;
  uStack_144 = 0xf;
  uStack_158 = uStack_158 & 0xffffff00;
  uStack_2c = (ulonglong)DAT_019398c8;
  uStack_14 = 0x3f5527dc;
  uStack_16c = 0;
  uStack_168 = 0xf;
  uStack_17c = uStack_17c & 0xffffff00;
  uStack_140 = uStack_3ec;
  FUN_005542c0("RightHand",9);
  uStack_3c8 = CONCAT44(DAT_0193992c,(undefined4)uStack_2c);
  uStack_15c = uStack_14;
  uStack_3e0 = uStack_17c;
  uStack_3dc = uStack_178;
  uStack_3d8 = uStack_174;
  uStack_3d4 = uStack_170;
  uStack_3c0 = uStack_14;
  uStack_3d0 = CONCAT44(uStack_168,uStack_16c);
  uStack_8._0_1_ = 4;
  uStack_16c = 0;
  uStack_168 = 0xf;
  uStack_17c = uStack_17c & 0xffffff00;
  uStack_24 = (ulonglong)DAT_019398c4;
  uStack_14 = 0x3f897c90;
  uStack_190 = 0;
  uStack_18c = 0xf;
  uStack_1a0 = uStack_1a0 & 0xffffff00;
  uStack_164 = uStack_3c8;
  FUN_005542c0("RightFoot",9);
  uStack_3a4 = CONCAT44(DAT_01939938,(undefined4)uStack_24);
  uStack_180 = uStack_14;
  uStack_3bc = uStack_1a0;
  uStack_3b8 = uStack_19c;
  uStack_3b4 = uStack_198;
  uStack_3b0 = uStack_194;
  uStack_39c = uStack_14;
  uStack_3ac = CONCAT44(uStack_18c,uStack_190);
  uStack_8._0_1_ = 5;
  uStack_190 = 0;
  uStack_18c = 0xf;
  uStack_1a0 = uStack_1a0 & 0xffffff00;
  uStack_14 = 0x3f897c90;
  uStack_1b4 = 0;
  uStack_1b0 = 0xf;
  uStack_1c4 = uStack_1c4 & 0xffffff00;
  uStack_188 = uStack_3a4;
  FUN_005542c0("LeftFoot",8);
  uStack_380 = CONCAT44(DAT_01939938,(int)uStack_24);
  uStack_1a4 = uStack_14;
  uStack_398 = uStack_1c4;
  uStack_394 = uStack_1c0;
  uStack_390 = uStack_1bc;
  uStack_38c = uStack_1b8;
  uStack_378 = uStack_14;
  uStack_388 = CONCAT44(uStack_1b0,uStack_1b4);
  uStack_8._0_1_ = 6;
  uStack_1b4 = 0;
  uStack_1b0 = 0xf;
  uStack_1c4 = uStack_1c4 & 0xffffff00;
  uStack_14 = 0x3f843b3d;
  uStack_1d8 = 0;
  uStack_1d4 = 0xf;
  uStack_1e8 = uStack_1e8 & 0xffffff00;
  uStack_1ac = uStack_380;
  FUN_005542c0("LeftUpperArm",0xc);
  uStack_35c = CONCAT44(DAT_01939998,(undefined4)uStack_38);
  uStack_1c8 = uStack_14;
  uStack_374 = uStack_1e8;
  uStack_370 = uStack_1e4;
  uStack_36c = uStack_1e0;
  uStack_368 = uStack_1dc;
  uStack_354 = uStack_14;
  uStack_364 = CONCAT44(uStack_1d4,uStack_1d8);
  uStack_8._0_1_ = 7;
  uStack_1d8 = 0;
  uStack_1d4 = 0xf;
  uStack_1e8 = uStack_1e8 & 0xffffff00;
  uStack_14 = 0x3f843b3d;
  uStack_1fc = 0;
  uStack_1f8 = 0xf;
  uStack_20c = uStack_20c & 0xffffff00;
  uStack_1d0 = uStack_35c;
  FUN_005542c0("RightLowerArm",0xd);
  uStack_338 = CONCAT44(DAT_01939998,(undefined4)uStack_38);
  uStack_1ec = uStack_14;
  uStack_350 = uStack_20c;
  uStack_34c = uStack_208;
  uStack_348 = uStack_204;
  uStack_344 = uStack_200;
  uStack_330 = uStack_14;
  uStack_340 = CONCAT44(uStack_1f8,uStack_1fc);
  uStack_8._0_1_ = 8;
  uStack_1fc = 0;
  uStack_1f8 = 0xf;
  uStack_20c = uStack_20c & 0xffffff00;
  uStack_14 = 0x3f5527dc;
  uStack_220 = 0;
  uStack_21c = 0xf;
  uStack_230 = uStack_230 & 0xffffff00;
  uStack_1f4 = uStack_338;
  FUN_005542c0("LeftHand",8);
  uStack_314 = CONCAT44(DAT_0193992c,(int)uStack_2c);
  uStack_210 = uStack_14;
  uStack_32c = uStack_230;
  uStack_328 = uStack_22c;
  uStack_324 = uStack_228;
  uStack_320 = uStack_224;
  uStack_30c = uStack_14;
  uStack_31c = CONCAT44(uStack_21c,uStack_220);
  uStack_8._0_1_ = 9;
  uStack_220 = 0;
  uStack_21c = 0xf;
  uStack_230 = uStack_230 & 0xffffff00;
  uStack_24 = (ulonglong)DAT_01939918;
  uStack_14 = 0x3f726c9b;
  uStack_244 = 0;
  uStack_240 = 0xf;
  uStack_254 = uStack_254 & 0xffffff00;
  uStack_218 = uStack_314;
  FUN_005542c0("RightUpperLeg",0xd);
  uStack_2f0 = CONCAT44(DAT_01939970,(undefined4)uStack_24);
  uStack_234 = uStack_14;
  uStack_308 = uStack_254;
  uStack_304 = uStack_250;
  uStack_300 = uStack_24c;
  uStack_2fc = uStack_248;
  uStack_2e8 = uStack_14;
  uStack_2f8 = CONCAT44(uStack_240,uStack_244);
  uStack_8._0_1_ = 10;
  uStack_244 = 0;
  uStack_240 = 0xf;
  uStack_254 = uStack_254 & 0xffffff00;
  uStack_14 = 0x3f843b3d;
  uStack_4c = 0;
  uStack_48 = 0xf;
  uStack_5c = uStack_5c & 0xffffff00;
  uStack_23c = uStack_2f0;
  FUN_005542c0("RightUpperArm",0xd);
  uStack_2cc = CONCAT44(DAT_01939998,(int)uStack_38);
  uStack_3c = uStack_14;
  uStack_2e4 = uStack_5c;
  uStack_2e0 = uStack_58;
  uStack_2dc = uStack_54;
  uStack_2d8 = uStack_50;
  uStack_5c = uStack_5c & 0xffffff00;
  uStack_2d4 = CONCAT44(uStack_48,uStack_4c);
  uStack_4c = 0;
  uStack_48 = 0xf;
  uStack_2c4 = uStack_14;
  uStack_8._0_1_ = 0xb;
  uStack_44 = uStack_2cc;
  FUN_005507b0();
  uStack_14 = 0x3f726c9b;
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = uStack_80 & 0xffffff00;
  FUN_005542c0("RightLowerLeg",0xd);
  uStack_2a8 = CONCAT44(DAT_01939970,(undefined4)uStack_24);
  uStack_2c0 = uStack_80;
  uStack_2bc = uStack_7c;
  uStack_2b8 = uStack_78;
  uStack_2b4 = uStack_74;
  uStack_60 = uStack_14;
  uStack_2b0 = CONCAT44(uStack_6c,uStack_70);
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = uStack_80 & 0xffffff00;
  uStack_2a0 = uStack_14;
  uStack_8._0_1_ = 0xc;
  uStack_68 = uStack_2a8;
  FUN_005507b0();
  uStack_14 = 0x3f726c9b;
  uStack_94 = 0;
  uStack_90 = 0xf;
  uStack_a4 = uStack_a4 & 0xffffff00;
  FUN_005542c0("LeftUpperLeg",0xc);
  uStack_284 = CONCAT44(DAT_01939970,(undefined4)uStack_24);
  uStack_84 = uStack_14;
  uStack_29c = uStack_a4;
  uStack_298 = uStack_a0;
  uStack_294 = uStack_9c;
  uStack_290 = uStack_98;
  uStack_a4 = uStack_a4 & 0xffffff00;
  uStack_28c = CONCAT44(uStack_90,uStack_94);
  uStack_94 = 0;
  uStack_90 = 0xf;
  uStack_27c = uStack_14;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  uStack_8c = uStack_284;
  FUN_005507b0();
  uStack_14 = 0x3f726c9b;
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_c8 = uStack_c8 & 0xffffff00;
  FUN_005542c0("LeftLowerLeg",0xc);
  uStack_260 = CONCAT44(DAT_01939970,(int)uStack_24);
  uStack_a8 = uStack_14;
  uStack_278 = uStack_c8;
  uStack_274 = uStack_c4;
  uStack_270 = uStack_c0;
  uStack_26c = uStack_bc;
  uStack_c8 = uStack_c8 & 0xffffff00;
  uStack_268 = CONCAT44(uStack_b4,uStack_b8);
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_258 = uStack_14;
  uStack_b0 = uStack_260;
  FUN_005507b0();
  uStack_8 = 0xe;
  FUN_009a1ed0(&uStack_470,&uStack_254);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_470,0x24,0xf,FUN_005507b0);
  FUN_016f3654(&LAB_018872e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 704 ; VA 0x004a1aa0 ; FUN_004a1aa0 */

void FUN_004a1aa0(void)

{
  uint uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined4 uStack_468;
  undefined8 uStack_464;
  undefined8 uStack_45c;
  undefined4 uStack_454;
  uint uStack_450;
  undefined4 uStack_44c;
  undefined4 uStack_448;
  undefined4 uStack_444;
  undefined8 uStack_440;
  undefined8 uStack_438;
  undefined4 uStack_430;
  uint uStack_42c;
  undefined4 uStack_428;
  undefined4 uStack_424;
  undefined4 uStack_420;
  undefined8 uStack_41c;
  undefined8 uStack_414;
  undefined4 uStack_40c;
  uint uStack_408;
  undefined4 uStack_404;
  undefined4 uStack_400;
  undefined4 uStack_3fc;
  undefined8 uStack_3f8;
  undefined8 uStack_3f0;
  undefined4 uStack_3e8;
  uint uStack_3e4;
  undefined4 uStack_3e0;
  undefined4 uStack_3dc;
  undefined4 uStack_3d8;
  undefined8 uStack_3d4;
  undefined8 uStack_3cc;
  undefined4 uStack_3c4;
  uint uStack_3c0;
  undefined4 uStack_3bc;
  undefined4 uStack_3b8;
  undefined4 uStack_3b4;
  undefined8 uStack_3b0;
  undefined8 uStack_3a8;
  undefined4 uStack_3a0;
  uint uStack_39c;
  undefined4 uStack_398;
  undefined4 uStack_394;
  undefined4 uStack_390;
  undefined8 uStack_38c;
  undefined8 uStack_384;
  undefined4 uStack_37c;
  uint uStack_378;
  undefined4 uStack_374;
  undefined4 uStack_370;
  undefined4 uStack_36c;
  undefined8 uStack_368;
  undefined8 uStack_360;
  undefined4 uStack_358;
  uint uStack_354;
  undefined4 uStack_350;
  undefined4 uStack_34c;
  undefined4 uStack_348;
  undefined8 uStack_344;
  undefined8 uStack_33c;
  undefined4 uStack_334;
  uint uStack_330;
  undefined4 uStack_32c;
  undefined4 uStack_328;
  undefined4 uStack_324;
  undefined8 uStack_320;
  undefined8 uStack_318;
  undefined4 uStack_310;
  uint uStack_30c;
  undefined4 uStack_308;
  undefined4 uStack_304;
  undefined4 uStack_300;
  undefined8 uStack_2fc;
  undefined8 uStack_2f4;
  undefined4 uStack_2ec;
  uint uStack_2e8;
  undefined4 uStack_2e4;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined8 uStack_2d8;
  undefined8 uStack_2d0;
  undefined4 uStack_2c8;
  uint uStack_2c4;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined8 uStack_2b4;
  undefined8 uStack_2ac;
  undefined4 uStack_2a4;
  uint uStack_2a0;
  undefined4 uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined8 uStack_290;
  undefined8 uStack_288;
  undefined4 uStack_280;
  uint uStack_27c;
  undefined4 uStack_278;
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined8 uStack_26c;
  undefined8 uStack_264;
  undefined4 uStack_25c;
  uint uStack_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined8 uStack_240;
  undefined4 uStack_238;
  uint uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined8 uStack_21c;
  undefined4 uStack_214;
  uint uStack_210;
  undefined4 uStack_20c;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined8 uStack_1f8;
  undefined4 uStack_1f0;
  uint uStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined8 uStack_1d4;
  undefined4 uStack_1cc;
  uint uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined8 uStack_1b0;
  undefined4 uStack_1a8;
  uint uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined8 uStack_18c;
  undefined4 uStack_184;
  uint uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined8 uStack_168;
  undefined4 uStack_160;
  uint uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined8 uStack_144;
  undefined4 uStack_13c;
  uint uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  uint uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined8 uStack_fc;
  undefined4 uStack_f4;
  uint uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_d0;
  uint uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined8 uStack_b4;
  undefined4 uStack_ac;
  uint uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_88;
  uint uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  ulonglong uStack_3c;
  undefined8 uStack_30;
  undefined8 uStack_24;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3d60;
  pvStack_10 = ExceptionList;
  uStack_3c = (ulonglong)DAT_019398d0;
  uStack_30._4_4_ = 0x3f6b13fb;
  uStack_e0 = 0;
  uStack_dc = 0xf;
  uStack_f0 = uStack_f0 & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("LeftLowerArm",0xc);
  uStack_45c = CONCAT44(DAT_01939984,(undefined4)uStack_3c);
  uStack_d0 = uStack_30._4_4_;
  uStack_474 = uStack_f0;
  uStack_470 = uStack_ec;
  uStack_46c = uStack_e8;
  uStack_468 = uStack_e4;
  uStack_454 = uStack_30._4_4_;
  uStack_464 = CONCAT44(uStack_dc,uStack_e0);
  uStack_8 = 0;
  uStack_e0 = 0;
  uStack_dc = 0xf;
  uStack_f0 = uStack_f0 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_019398ec;
  uStack_24._4_4_ = 0x3f7645b2;
  uStack_104 = 0;
  uStack_100 = 0xf;
  uStack_114 = uStack_114 & 0xffffff00;
  uStack_d8 = uStack_45c;
  FUN_005542c0("LowerTorso",10);
  uStack_438 = CONCAT44(DAT_019398f4,(int)uStack_30);
  uStack_f4 = uStack_24._4_4_;
  uStack_450 = uStack_114;
  uStack_44c = uStack_110;
  uStack_448 = uStack_10c;
  uStack_444 = uStack_108;
  uStack_430 = uStack_24._4_4_;
  uStack_440 = CONCAT44(uStack_100,uStack_104);
  uStack_8._0_1_ = 1;
  uStack_104 = 0;
  uStack_100 = 0xf;
  uStack_114 = uStack_114 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_019398b4;
  uStack_24._4_4_ = 0x3f183c68;
  uStack_128 = 0;
  uStack_124 = 0xf;
  uStack_138 = uStack_138 & 0xffffff00;
  uStack_fc = uStack_438;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_414 = CONCAT44(DAT_018f9944,(int)uStack_30);
  uStack_118 = uStack_24._4_4_;
  uStack_42c = uStack_138;
  uStack_428 = uStack_134;
  uStack_424 = uStack_130;
  uStack_420 = uStack_12c;
  uStack_40c = uStack_24._4_4_;
  uStack_41c = CONCAT44(uStack_124,uStack_128);
  uStack_8._0_1_ = 2;
  uStack_128 = 0;
  uStack_124 = 0xf;
  uStack_138 = uStack_138 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_019398d8;
  uStack_24._4_4_ = 0x3f7645b2;
  uStack_14c = 0;
  uStack_148 = 0xf;
  uStack_15c = uStack_15c & 0xffffff00;
  uStack_120 = uStack_414;
  FUN_005542c0("UpperTorso",10);
  uStack_3f0 = CONCAT44(DAT_01939954,(int)uStack_30);
  uStack_13c = uStack_24._4_4_;
  uStack_408 = uStack_15c;
  uStack_404 = uStack_158;
  uStack_400 = uStack_154;
  uStack_3fc = uStack_150;
  uStack_3e8 = uStack_24._4_4_;
  uStack_3f8 = CONCAT44(uStack_148,uStack_14c);
  uStack_8._0_1_ = 3;
  uStack_14c = 0;
  uStack_148 = 0xf;
  uStack_15c = uStack_15c & 0xffffff00;
  uStack_30 = (ulonglong)DAT_019398b8;
  uStack_24._4_4_ = 0x3f3d78c4;
  uStack_170 = 0;
  uStack_16c = 0xf;
  uStack_180 = uStack_180 & 0xffffff00;
  uStack_144 = uStack_3f0;
  FUN_005542c0("RightHand",9);
  uStack_3cc = CONCAT44(DAT_0193992c,(undefined4)uStack_30);
  uStack_160 = uStack_24._4_4_;
  uStack_3e4 = uStack_180;
  uStack_3e0 = uStack_17c;
  uStack_3dc = uStack_178;
  uStack_3d8 = uStack_174;
  uStack_3c4 = uStack_24._4_4_;
  uStack_3d4 = CONCAT44(uStack_16c,uStack_170);
  uStack_8._0_1_ = 4;
  uStack_170 = 0;
  uStack_16c = 0xf;
  uStack_180 = uStack_180 & 0xffffff00;
  uStack_24 = (ulonglong)DAT_019398c0;
  uStack_14 = 0x3f746bab;
  uStack_194 = 0;
  uStack_190 = 0xf;
  uStack_1a4 = uStack_1a4 & 0xffffff00;
  uStack_168 = uStack_3cc;
  FUN_005542c0("RightFoot",9);
  uStack_3a8 = CONCAT44(DAT_019398e8,(undefined4)uStack_24);
  uStack_184 = uStack_14;
  uStack_3c0 = uStack_1a4;
  uStack_3bc = uStack_1a0;
  uStack_3b8 = uStack_19c;
  uStack_3b4 = uStack_198;
  uStack_3a0 = uStack_14;
  uStack_3b0 = CONCAT44(uStack_190,uStack_194);
  uStack_8._0_1_ = 5;
  uStack_194 = 0;
  uStack_190 = 0xf;
  uStack_1a4 = uStack_1a4 & 0xffffff00;
  uStack_14 = 0x3f746bab;
  uStack_1b8 = 0;
  uStack_1b4 = 0xf;
  uStack_1c8 = uStack_1c8 & 0xffffff00;
  uStack_18c = uStack_3a8;
  FUN_005542c0("LeftFoot",8);
  uStack_384 = CONCAT44(DAT_019398e8,(int)uStack_24);
  uStack_1a8 = uStack_14;
  uStack_39c = uStack_1c8;
  uStack_398 = uStack_1c4;
  uStack_394 = uStack_1c0;
  uStack_390 = uStack_1bc;
  uStack_37c = uStack_14;
  uStack_38c = CONCAT44(uStack_1b4,uStack_1b8);
  uStack_8._0_1_ = 6;
  uStack_1b8 = 0;
  uStack_1b4 = 0xf;
  uStack_1c8 = uStack_1c8 & 0xffffff00;
  uStack_14 = 0x3f6b13fb;
  uStack_1dc = 0;
  uStack_1d8 = 0xf;
  uStack_1ec = uStack_1ec & 0xffffff00;
  uStack_1b0 = uStack_384;
  FUN_005542c0("LeftUpperArm",0xc);
  uStack_360 = CONCAT44(DAT_01939984,(undefined4)uStack_3c);
  uStack_1cc = uStack_14;
  uStack_378 = uStack_1ec;
  uStack_374 = uStack_1e8;
  uStack_370 = uStack_1e4;
  uStack_36c = uStack_1e0;
  uStack_358 = uStack_14;
  uStack_368 = CONCAT44(uStack_1d8,uStack_1dc);
  uStack_8._0_1_ = 7;
  uStack_1dc = 0;
  uStack_1d8 = 0xf;
  uStack_1ec = uStack_1ec & 0xffffff00;
  uStack_14 = 0x3f6b13fb;
  uStack_200 = 0;
  uStack_1fc = 0xf;
  uStack_210 = uStack_210 & 0xffffff00;
  uStack_1d4 = uStack_360;
  FUN_005542c0("RightLowerArm",0xd);
  uStack_33c = CONCAT44(DAT_01939984,(undefined4)uStack_3c);
  uStack_1f0 = uStack_14;
  uStack_354 = uStack_210;
  uStack_350 = uStack_20c;
  uStack_34c = uStack_208;
  uStack_348 = uStack_204;
  uStack_334 = uStack_14;
  uStack_344 = CONCAT44(uStack_1fc,uStack_200);
  uStack_8._0_1_ = 8;
  uStack_200 = 0;
  uStack_1fc = 0xf;
  uStack_210 = uStack_210 & 0xffffff00;
  uStack_14 = 0x3f3d78c4;
  uStack_224 = 0;
  uStack_220 = 0xf;
  uStack_234 = uStack_234 & 0xffffff00;
  uStack_1f8 = uStack_33c;
  FUN_005542c0("LeftHand",8);
  uStack_318 = CONCAT44(DAT_0193992c,(int)uStack_30);
  uStack_214 = uStack_14;
  uStack_330 = uStack_234;
  uStack_32c = uStack_230;
  uStack_328 = uStack_22c;
  uStack_324 = uStack_228;
  uStack_310 = uStack_14;
  uStack_320 = CONCAT44(uStack_220,uStack_224);
  uStack_8._0_1_ = 9;
  uStack_224 = 0;
  uStack_220 = 0xf;
  uStack_234 = uStack_234 & 0xffffff00;
  uStack_24 = (ulonglong)DAT_019398fc;
  uStack_14 = 0x3f577cfc;
  uStack_248 = 0;
  uStack_244 = 0xf;
  uStack_258 = uStack_258 & 0xffffff00;
  uStack_21c = uStack_318;
  FUN_005542c0("RightUpperLeg",0xd);
  uStack_2f4 = CONCAT44(DAT_0193995c,(undefined4)uStack_24);
  uStack_238 = uStack_14;
  uStack_30c = uStack_258;
  uStack_308 = uStack_254;
  uStack_304 = uStack_250;
  uStack_300 = uStack_24c;
  uStack_2ec = uStack_14;
  uStack_2fc = CONCAT44(uStack_244,uStack_248);
  uStack_8._0_1_ = 10;
  uStack_248 = 0;
  uStack_244 = 0xf;
  uStack_258 = uStack_258 & 0xffffff00;
  uStack_14 = 0x3f6b13fb;
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_60 = uStack_60 & 0xffffff00;
  uStack_240 = uStack_2f4;
  FUN_005542c0("RightUpperArm",0xd);
  uStack_2d0 = CONCAT44(DAT_01939984,(int)uStack_3c);
  uStack_40 = uStack_14;
  uStack_2e8 = uStack_60;
  uStack_2e4 = uStack_5c;
  uStack_2e0 = uStack_58;
  uStack_2dc = uStack_54;
  uStack_60 = uStack_60 & 0xffffff00;
  uStack_2d8 = CONCAT44(uStack_4c,uStack_50);
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_2c8 = uStack_14;
  uStack_8._0_1_ = 0xb;
  uStack_48 = uStack_2d0;
  FUN_005507b0();
  uStack_14 = 0x3f577cfc;
  uStack_74 = 0;
  uStack_70 = 0xf;
  uStack_84 = uStack_84 & 0xffffff00;
  FUN_005542c0("RightLowerLeg",0xd);
  uStack_2ac = CONCAT44(DAT_0193993c,(undefined4)uStack_24);
  uStack_64 = uStack_14;
  uStack_2c4 = uStack_84;
  uStack_2c0 = uStack_80;
  uStack_2bc = uStack_7c;
  uStack_2b8 = uStack_78;
  uStack_84 = uStack_84 & 0xffffff00;
  uStack_2b4 = CONCAT44(uStack_70,uStack_74);
  uStack_74 = 0;
  uStack_70 = 0xf;
  uStack_2a4 = uStack_14;
  uStack_8._0_1_ = 0xc;
  uStack_6c = uStack_2ac;
  FUN_005507b0();
  uStack_14 = 0x3f577cfc;
  uStack_98 = 0;
  uStack_94 = 0xf;
  uStack_a8 = uStack_a8 & 0xffffff00;
  FUN_005542c0("LeftUpperLeg",0xc);
  uStack_288 = CONCAT44(DAT_0193995c,(undefined4)uStack_24);
  uStack_88 = uStack_14;
  uStack_2a0 = uStack_a8;
  uStack_29c = uStack_a4;
  uStack_298 = uStack_a0;
  uStack_294 = uStack_9c;
  uStack_a8 = uStack_a8 & 0xffffff00;
  uStack_290 = CONCAT44(uStack_94,uStack_98);
  uStack_98 = 0;
  uStack_94 = 0xf;
  uStack_280 = uStack_14;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  uStack_90 = uStack_288;
  FUN_005507b0();
  uStack_14 = 0x3f577cfc;
  uStack_bc = 0;
  uStack_b8 = 0xf;
  uStack_cc = uStack_cc & 0xffffff00;
  FUN_005542c0("LeftLowerLeg",0xc);
  uStack_264 = CONCAT44(DAT_0193993c,(int)uStack_24);
  uStack_ac = uStack_14;
  uStack_27c = uStack_cc;
  uStack_278 = uStack_c8;
  uStack_274 = uStack_c4;
  uStack_270 = uStack_c0;
  uStack_cc = uStack_cc & 0xffffff00;
  uStack_26c = CONCAT44(uStack_b8,uStack_bc);
  uStack_bc = 0;
  uStack_b8 = 0xf;
  uStack_25c = uStack_14;
  uStack_b4 = uStack_264;
  FUN_005507b0();
  uStack_8 = 0xe;
  FUN_009a1ed0(&uStack_474,&uStack_258);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_474,0x24,0xf,FUN_005507b0);
  FUN_016f3654(&LAB_018872f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 705 ; VA 0x004a24c0 ; FUN_004a24c0 */

void FUN_004a24c0(void)

{
  uint uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined4 uStack_468;
  undefined8 uStack_464;
  undefined8 uStack_45c;
  undefined4 uStack_454;
  uint uStack_450;
  undefined4 uStack_44c;
  undefined4 uStack_448;
  undefined4 uStack_444;
  undefined8 uStack_440;
  undefined8 uStack_438;
  undefined4 uStack_430;
  uint uStack_42c;
  undefined4 uStack_428;
  undefined4 uStack_424;
  undefined4 uStack_420;
  undefined8 uStack_41c;
  undefined8 uStack_414;
  undefined4 uStack_40c;
  uint uStack_408;
  undefined4 uStack_404;
  undefined4 uStack_400;
  undefined4 uStack_3fc;
  undefined8 uStack_3f8;
  undefined8 uStack_3f0;
  undefined4 uStack_3e8;
  uint uStack_3e4;
  undefined4 uStack_3e0;
  undefined4 uStack_3dc;
  undefined4 uStack_3d8;
  undefined8 uStack_3d4;
  undefined8 uStack_3cc;
  undefined4 uStack_3c4;
  uint uStack_3c0;
  undefined4 uStack_3bc;
  undefined4 uStack_3b8;
  undefined4 uStack_3b4;
  undefined8 uStack_3b0;
  undefined8 uStack_3a8;
  undefined4 uStack_3a0;
  uint uStack_39c;
  undefined4 uStack_398;
  undefined4 uStack_394;
  undefined4 uStack_390;
  undefined8 uStack_38c;
  undefined8 uStack_384;
  undefined4 uStack_37c;
  uint uStack_378;
  undefined4 uStack_374;
  undefined4 uStack_370;
  undefined4 uStack_36c;
  undefined8 uStack_368;
  undefined8 uStack_360;
  undefined4 uStack_358;
  uint uStack_354;
  undefined4 uStack_350;
  undefined4 uStack_34c;
  undefined4 uStack_348;
  undefined8 uStack_344;
  undefined8 uStack_33c;
  undefined4 uStack_334;
  uint uStack_330;
  undefined4 uStack_32c;
  undefined4 uStack_328;
  undefined4 uStack_324;
  undefined8 uStack_320;
  undefined8 uStack_318;
  undefined4 uStack_310;
  uint uStack_30c;
  undefined4 uStack_308;
  undefined4 uStack_304;
  undefined4 uStack_300;
  undefined8 uStack_2fc;
  undefined8 uStack_2f4;
  undefined4 uStack_2ec;
  uint uStack_2e8;
  undefined4 uStack_2e4;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined8 uStack_2d8;
  undefined8 uStack_2d0;
  undefined4 uStack_2c8;
  uint uStack_2c4;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined8 uStack_2b4;
  undefined8 uStack_2ac;
  undefined4 uStack_2a4;
  uint uStack_2a0;
  undefined4 uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined8 uStack_290;
  undefined8 uStack_288;
  undefined4 uStack_280;
  uint uStack_27c;
  undefined4 uStack_278;
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined8 uStack_26c;
  undefined8 uStack_264;
  undefined4 uStack_25c;
  uint uStack_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined8 uStack_240;
  undefined4 uStack_238;
  uint uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined8 uStack_21c;
  undefined4 uStack_214;
  uint uStack_210;
  undefined4 uStack_20c;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined8 uStack_1f8;
  undefined4 uStack_1f0;
  uint uStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined8 uStack_1d4;
  undefined4 uStack_1cc;
  uint uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined8 uStack_1b0;
  undefined4 uStack_1a8;
  uint uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined8 uStack_18c;
  undefined4 uStack_184;
  uint uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined8 uStack_168;
  undefined4 uStack_160;
  uint uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined8 uStack_144;
  undefined4 uStack_13c;
  uint uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  uint uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined8 uStack_fc;
  undefined4 uStack_f4;
  uint uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_d0;
  uint uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined8 uStack_b4;
  undefined4 uStack_ac;
  uint uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_88;
  uint uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  ulonglong uStack_3c;
  undefined8 uStack_30;
  undefined8 uStack_24;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3d60;
  pvStack_10 = ExceptionList;
  uStack_3c = (ulonglong)DAT_01939910;
  uStack_30._4_4_ = 0x3f94c2a5;
  uStack_e0 = 0;
  uStack_dc = 0xf;
  uStack_f0 = uStack_f0 & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("LeftLowerArm",0xc);
  uStack_45c = CONCAT44(DAT_019399a4,(undefined4)uStack_3c);
  uStack_d0 = uStack_30._4_4_;
  uStack_474 = uStack_f0;
  uStack_470 = uStack_ec;
  uStack_46c = uStack_e8;
  uStack_468 = uStack_e4;
  uStack_454 = uStack_30._4_4_;
  uStack_464 = CONCAT44(uStack_dc,uStack_e0);
  uStack_8 = 0;
  uStack_e0 = 0;
  uStack_dc = 0xf;
  uStack_f0 = uStack_f0 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_01939928;
  uStack_24._4_4_ = 0x3f9bd81a;
  uStack_104 = 0;
  uStack_100 = 0xf;
  uStack_114 = uStack_114 & 0xffffff00;
  uStack_d8 = uStack_45c;
  FUN_005542c0("LowerTorso",10);
  uStack_438 = CONCAT44(DAT_019399a0,(int)uStack_30);
  uStack_f4 = uStack_24._4_4_;
  uStack_450 = uStack_114;
  uStack_44c = uStack_110;
  uStack_448 = uStack_10c;
  uStack_444 = uStack_108;
  uStack_430 = uStack_24._4_4_;
  uStack_440 = CONCAT44(uStack_100,uStack_104);
  uStack_8._0_1_ = 1;
  uStack_104 = 0;
  uStack_100 = 0xf;
  uStack_114 = uStack_114 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_019398bc;
  uStack_24._4_4_ = 0x3f2828f6;
  uStack_128 = 0;
  uStack_124 = 0xf;
  uStack_138 = uStack_138 & 0xffffff00;
  uStack_fc = uStack_438;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_414 = CONCAT44(DAT_018f9944,(int)uStack_30);
  uStack_118 = uStack_24._4_4_;
  uStack_42c = uStack_138;
  uStack_428 = uStack_134;
  uStack_424 = uStack_130;
  uStack_420 = uStack_12c;
  uStack_40c = uStack_24._4_4_;
  uStack_41c = CONCAT44(uStack_124,uStack_128);
  uStack_8._0_1_ = 2;
  uStack_128 = 0;
  uStack_124 = 0xf;
  uStack_138 = uStack_138 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_0193994c;
  uStack_24._4_4_ = 0x3f9bd81a;
  uStack_14c = 0;
  uStack_148 = 0xf;
  uStack_15c = uStack_15c & 0xffffff00;
  uStack_120 = uStack_414;
  FUN_005542c0("UpperTorso",10);
  uStack_3f0 = CONCAT44(DAT_01939988,(int)uStack_30);
  uStack_13c = uStack_24._4_4_;
  uStack_408 = uStack_15c;
  uStack_404 = uStack_158;
  uStack_400 = uStack_154;
  uStack_3fc = uStack_150;
  uStack_3e8 = uStack_24._4_4_;
  uStack_3f8 = CONCAT44(uStack_148,uStack_14c);
  uStack_8._0_1_ = 3;
  uStack_14c = 0;
  uStack_148 = 0xf;
  uStack_15c = uStack_15c & 0xffffff00;
  uStack_30 = (ulonglong)DAT_019398d4;
  uStack_24._4_4_ = 0x3f6fccd8;
  uStack_170 = 0;
  uStack_16c = 0xf;
  uStack_180 = uStack_180 & 0xffffff00;
  uStack_144 = uStack_3f0;
  FUN_005542c0("RightHand",9);
  uStack_3cc = CONCAT44(DAT_0193992c,(undefined4)uStack_30);
  uStack_160 = uStack_24._4_4_;
  uStack_3e4 = uStack_180;
  uStack_3e0 = uStack_17c;
  uStack_3dc = uStack_178;
  uStack_3d8 = uStack_174;
  uStack_3c4 = uStack_24._4_4_;
  uStack_3d4 = CONCAT44(uStack_16c,uStack_170);
  uStack_8._0_1_ = 4;
  uStack_170 = 0;
  uStack_16c = 0xf;
  uStack_180 = uStack_180 & 0xffffff00;
  uStack_24 = (ulonglong)DAT_019398cc;
  uStack_14 = 0x3f9aac22;
  uStack_194 = 0;
  uStack_190 = 0xf;
  uStack_1a4 = uStack_1a4 & 0xffffff00;
  uStack_168 = uStack_3cc;
  FUN_005542c0("RightFoot",9);
  uStack_3a8 = CONCAT44(DAT_01939960,(undefined4)uStack_24);
  uStack_184 = uStack_14;
  uStack_3c0 = uStack_1a4;
  uStack_3bc = uStack_1a0;
  uStack_3b8 = uStack_19c;
  uStack_3b4 = uStack_198;
  uStack_3a0 = uStack_14;
  uStack_3b0 = CONCAT44(uStack_190,uStack_194);
  uStack_8._0_1_ = 5;
  uStack_194 = 0;
  uStack_190 = 0xf;
  uStack_1a4 = uStack_1a4 & 0xffffff00;
  uStack_14 = 0x3f9aac22;
  uStack_1b8 = 0;
  uStack_1b4 = 0xf;
  uStack_1c8 = uStack_1c8 & 0xffffff00;
  uStack_18c = uStack_3a8;
  FUN_005542c0("LeftFoot",8);
  uStack_384 = CONCAT44(DAT_01939960,(int)uStack_24);
  uStack_1a8 = uStack_14;
  uStack_39c = uStack_1c8;
  uStack_398 = uStack_1c4;
  uStack_394 = uStack_1c0;
  uStack_390 = uStack_1bc;
  uStack_37c = uStack_14;
  uStack_38c = CONCAT44(uStack_1b4,uStack_1b8);
  uStack_8._0_1_ = 6;
  uStack_1b8 = 0;
  uStack_1b4 = 0xf;
  uStack_1c8 = uStack_1c8 & 0xffffff00;
  uStack_14 = 0x3f94c2a5;
  uStack_1dc = 0;
  uStack_1d8 = 0xf;
  uStack_1ec = uStack_1ec & 0xffffff00;
  uStack_1b0 = uStack_384;
  FUN_005542c0("LeftUpperArm",0xc);
  uStack_360 = CONCAT44(DAT_019399a4,(undefined4)uStack_3c);
  uStack_1cc = uStack_14;
  uStack_378 = uStack_1ec;
  uStack_374 = uStack_1e8;
  uStack_370 = uStack_1e4;
  uStack_36c = uStack_1e0;
  uStack_358 = uStack_14;
  uStack_368 = CONCAT44(uStack_1d8,uStack_1dc);
  uStack_8._0_1_ = 7;
  uStack_1dc = 0;
  uStack_1d8 = 0xf;
  uStack_1ec = uStack_1ec & 0xffffff00;
  uStack_14 = 0x3f94c2a5;
  uStack_200 = 0;
  uStack_1fc = 0xf;
  uStack_210 = uStack_210 & 0xffffff00;
  uStack_1d4 = uStack_360;
  FUN_005542c0("RightLowerArm",0xd);
  uStack_33c = CONCAT44(DAT_019399a4,(undefined4)uStack_3c);
  uStack_1f0 = uStack_14;
  uStack_354 = uStack_210;
  uStack_350 = uStack_20c;
  uStack_34c = uStack_208;
  uStack_348 = uStack_204;
  uStack_334 = uStack_14;
  uStack_344 = CONCAT44(uStack_1fc,uStack_200);
  uStack_8._0_1_ = 8;
  uStack_200 = 0;
  uStack_1fc = 0xf;
  uStack_210 = uStack_210 & 0xffffff00;
  uStack_14 = 0x3f6fccd8;
  uStack_224 = 0;
  uStack_220 = 0xf;
  uStack_234 = uStack_234 & 0xffffff00;
  uStack_1f8 = uStack_33c;
  FUN_005542c0("LeftHand",8);
  uStack_318 = CONCAT44(DAT_0193992c,(int)uStack_30);
  uStack_214 = uStack_14;
  uStack_330 = uStack_234;
  uStack_32c = uStack_230;
  uStack_328 = uStack_22c;
  uStack_324 = uStack_228;
  uStack_310 = uStack_14;
  uStack_320 = CONCAT44(uStack_220,uStack_224);
  uStack_8._0_1_ = 9;
  uStack_224 = 0;
  uStack_220 = 0xf;
  uStack_234 = uStack_234 & 0xffffff00;
  uStack_24 = (ulonglong)DAT_01939944;
  uStack_14 = 0x3f885d17;
  uStack_248 = 0;
  uStack_244 = 0xf;
  uStack_258 = uStack_258 & 0xffffff00;
  uStack_21c = uStack_318;
  FUN_005542c0("RightUpperLeg",0xd);
  uStack_2f4 = CONCAT44(DAT_01939980,(undefined4)uStack_24);
  uStack_238 = uStack_14;
  uStack_30c = uStack_258;
  uStack_308 = uStack_254;
  uStack_304 = uStack_250;
  uStack_300 = uStack_24c;
  uStack_2ec = uStack_14;
  uStack_2fc = CONCAT44(uStack_244,uStack_248);
  uStack_8._0_1_ = 10;
  uStack_248 = 0;
  uStack_244 = 0xf;
  uStack_258 = uStack_258 & 0xffffff00;
  uStack_14 = 0x3f94c2a5;
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_60 = uStack_60 & 0xffffff00;
  uStack_240 = uStack_2f4;
  FUN_005542c0("RightUpperArm",0xd);
  uStack_2d0 = CONCAT44(DAT_019399a4,(int)uStack_3c);
  uStack_40 = uStack_14;
  uStack_2e8 = uStack_60;
  uStack_2e4 = uStack_5c;
  uStack_2e0 = uStack_58;
  uStack_2dc = uStack_54;
  uStack_60 = uStack_60 & 0xffffff00;
  uStack_2d8 = CONCAT44(uStack_4c,uStack_50);
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_2c8 = uStack_14;
  uStack_8._0_1_ = 0xb;
  uStack_48 = uStack_2d0;
  FUN_005507b0();
  uStack_14 = 0x3f885d17;
  uStack_74 = 0;
  uStack_70 = 0xf;
  uStack_84 = uStack_84 & 0xffffff00;
  FUN_005542c0("RightLowerLeg",0xd);
  uStack_2ac = CONCAT44(DAT_01939994,(undefined4)uStack_24);
  uStack_64 = uStack_14;
  uStack_2c4 = uStack_84;
  uStack_2c0 = uStack_80;
  uStack_2bc = uStack_7c;
  uStack_2b8 = uStack_78;
  uStack_84 = uStack_84 & 0xffffff00;
  uStack_2b4 = CONCAT44(uStack_70,uStack_74);
  uStack_74 = 0;
  uStack_70 = 0xf;
  uStack_2a4 = uStack_14;
  uStack_8._0_1_ = 0xc;
  uStack_6c = uStack_2ac;
  FUN_005507b0();
  uStack_14 = 0x3f885d17;
  uStack_98 = 0;
  uStack_94 = 0xf;
  uStack_a8 = uStack_a8 & 0xffffff00;
  FUN_005542c0("LeftUpperLeg",0xc);
  uStack_288 = CONCAT44(DAT_01939980,(undefined4)uStack_24);
  uStack_88 = uStack_14;
  uStack_2a0 = uStack_a8;
  uStack_29c = uStack_a4;
  uStack_298 = uStack_a0;
  uStack_294 = uStack_9c;
  uStack_a8 = uStack_a8 & 0xffffff00;
  uStack_290 = CONCAT44(uStack_94,uStack_98);
  uStack_98 = 0;
  uStack_94 = 0xf;
  uStack_280 = uStack_14;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  uStack_90 = uStack_288;
  FUN_005507b0();
  uStack_14 = 0x3f885d17;
  uStack_bc = 0;
  uStack_b8 = 0xf;
  uStack_cc = uStack_cc & 0xffffff00;
  FUN_005542c0("LeftLowerLeg",0xc);
  uStack_264 = CONCAT44(DAT_01939994,(int)uStack_24);
  uStack_ac = uStack_14;
  uStack_27c = uStack_cc;
  uStack_278 = uStack_c8;
  uStack_274 = uStack_c4;
  uStack_270 = uStack_c0;
  uStack_cc = uStack_cc & 0xffffff00;
  uStack_26c = CONCAT44(uStack_b8,uStack_bc);
  uStack_bc = 0;
  uStack_b8 = 0xf;
  uStack_25c = uStack_14;
  uStack_b4 = uStack_264;
  FUN_005507b0();
  uStack_8 = 0xe;
  FUN_009a1ed0(&uStack_474,&uStack_258);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_474,0x24,0xf,FUN_005507b0);
  FUN_016f3654(&LAB_01887300);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 706 ; VA 0x004a2ee0 ; FUN_004a2ee0 */

void FUN_004a2ee0(void)

{
  uint uStack_470;
  undefined4 uStack_46c;
  undefined4 uStack_468;
  undefined4 uStack_464;
  undefined8 uStack_460;
  undefined8 uStack_458;
  undefined4 uStack_450;
  uint uStack_44c;
  undefined4 uStack_448;
  undefined4 uStack_444;
  undefined4 uStack_440;
  undefined8 uStack_43c;
  undefined8 uStack_434;
  undefined4 uStack_42c;
  uint uStack_428;
  undefined4 uStack_424;
  undefined4 uStack_420;
  undefined4 uStack_41c;
  undefined8 uStack_418;
  undefined8 uStack_410;
  undefined4 uStack_408;
  uint uStack_404;
  undefined4 uStack_400;
  undefined4 uStack_3fc;
  undefined4 uStack_3f8;
  undefined8 uStack_3f4;
  undefined8 uStack_3ec;
  undefined4 uStack_3e4;
  uint uStack_3e0;
  undefined4 uStack_3dc;
  undefined4 uStack_3d8;
  undefined4 uStack_3d4;
  undefined8 uStack_3d0;
  undefined8 uStack_3c8;
  undefined4 uStack_3c0;
  uint uStack_3bc;
  undefined4 uStack_3b8;
  undefined4 uStack_3b4;
  undefined4 uStack_3b0;
  undefined8 uStack_3ac;
  undefined8 uStack_3a4;
  undefined4 uStack_39c;
  uint uStack_398;
  undefined4 uStack_394;
  undefined4 uStack_390;
  undefined4 uStack_38c;
  undefined8 uStack_388;
  undefined8 uStack_380;
  undefined4 uStack_378;
  uint uStack_374;
  undefined4 uStack_370;
  undefined4 uStack_36c;
  undefined4 uStack_368;
  undefined8 uStack_364;
  undefined8 uStack_35c;
  undefined4 uStack_354;
  uint uStack_350;
  undefined4 uStack_34c;
  undefined4 uStack_348;
  undefined4 uStack_344;
  undefined8 uStack_340;
  undefined8 uStack_338;
  undefined4 uStack_330;
  uint uStack_32c;
  undefined4 uStack_328;
  undefined4 uStack_324;
  undefined4 uStack_320;
  undefined8 uStack_31c;
  undefined8 uStack_314;
  undefined4 uStack_30c;
  uint uStack_308;
  undefined4 uStack_304;
  undefined4 uStack_300;
  undefined4 uStack_2fc;
  undefined8 uStack_2f8;
  undefined8 uStack_2f0;
  undefined4 uStack_2e8;
  uint uStack_2e4;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined8 uStack_2d4;
  undefined8 uStack_2cc;
  undefined4 uStack_2c4;
  uint uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined4 uStack_2b4;
  undefined8 uStack_2b0;
  undefined8 uStack_2a8;
  undefined4 uStack_2a0;
  uint uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined8 uStack_28c;
  undefined8 uStack_284;
  undefined4 uStack_27c;
  uint uStack_278;
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined8 uStack_268;
  undefined8 uStack_260;
  undefined4 uStack_258;
  uint uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined8 uStack_23c;
  undefined4 uStack_234;
  uint uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined8 uStack_218;
  undefined4 uStack_210;
  uint uStack_20c;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined4 uStack_1f8;
  undefined8 uStack_1f4;
  undefined4 uStack_1ec;
  uint uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined8 uStack_1d0;
  undefined4 uStack_1c8;
  uint uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined8 uStack_1ac;
  undefined4 uStack_1a4;
  uint uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined8 uStack_188;
  undefined4 uStack_180;
  uint uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined8 uStack_164;
  undefined4 uStack_15c;
  uint uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined8 uStack_140;
  undefined4 uStack_138;
  uint uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined8 uStack_11c;
  undefined4 uStack_114;
  uint uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  uint uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined8 uStack_d4;
  undefined4 uStack_cc;
  uint uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined8 uStack_b0;
  undefined4 uStack_a8;
  uint uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  undefined4 uStack_84;
  uint uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  ulonglong uStack_38;
  undefined8 uStack_2c;
  ulonglong uStack_24;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3e20;
  pvStack_10 = ExceptionList;
  uStack_38 = (ulonglong)DAT_019398dc;
  uStack_2c._4_4_ = 0x3f843b3d;
  uStack_dc = 0;
  uStack_d8 = 0xf;
  uStack_ec = uStack_ec & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("LeftLowerArm",0xc);
  uStack_458 = CONCAT44(DAT_01939998,(undefined4)uStack_38);
  uStack_cc = uStack_2c._4_4_;
  uStack_470 = uStack_ec;
  uStack_46c = uStack_e8;
  uStack_468 = uStack_e4;
  uStack_464 = uStack_e0;
  uStack_450 = uStack_2c._4_4_;
  uStack_460 = CONCAT44(uStack_d8,uStack_dc);
  uStack_8 = 0;
  uStack_dc = 0;
  uStack_d8 = 0xf;
  uStack_ec = uStack_ec & 0xffffff00;
  uStack_24 = (ulonglong)DAT_01939908;
  uStack_2c._4_4_ = 0x3f8a8734;
  uStack_100 = 0;
  uStack_fc = 0xf;
  uStack_110 = uStack_110 & 0xffffff00;
  uStack_d4 = uStack_458;
  FUN_005542c0("LowerTorso",10);
  uStack_434 = CONCAT44(DAT_01939970,(undefined4)uStack_24);
  uStack_f0 = uStack_2c._4_4_;
  uStack_44c = uStack_110;
  uStack_448 = uStack_10c;
  uStack_444 = uStack_108;
  uStack_440 = uStack_104;
  uStack_42c = uStack_2c._4_4_;
  uStack_43c = CONCAT44(uStack_fc,uStack_100);
  uStack_8._0_1_ = 1;
  uStack_100 = 0;
  uStack_fc = 0xf;
  uStack_110 = uStack_110 & 0xffffff00;
  uStack_2c = (ulonglong)DAT_018f9944;
  uStack_14 = 0x3f200000;
  uStack_124 = 0;
  uStack_120 = 0xf;
  uStack_134 = uStack_134 & 0xffffff00;
  uStack_f8 = uStack_434;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_410 = CONCAT44((int)uStack_2c,(int)uStack_2c);
  uStack_428 = uStack_134;
  uStack_424 = uStack_130;
  uStack_420 = uStack_12c;
  uStack_41c = uStack_128;
  uStack_114 = uStack_14;
  uStack_418 = CONCAT44(uStack_120,uStack_124);
  uStack_408 = uStack_14;
  uStack_8._0_1_ = 2;
  uStack_124 = 0;
  uStack_120 = 0xf;
  uStack_134 = uStack_134 & 0xffffff00;
  uStack_14 = 0x3f8a8734;
  uStack_148 = 0;
  uStack_144 = 0xf;
  uStack_158 = uStack_158 & 0xffffff00;
  uStack_11c = uStack_410;
  FUN_005542c0("UpperTorso",10);
  uStack_3ec = CONCAT44(DAT_01939970,(int)uStack_24);
  uStack_138 = uStack_14;
  uStack_404 = uStack_158;
  uStack_400 = uStack_154;
  uStack_3fc = uStack_150;
  uStack_3f8 = uStack_14c;
  uStack_3e4 = uStack_14;
  uStack_3f4 = CONCAT44(uStack_144,uStack_148);
  uStack_8._0_1_ = 3;
  uStack_148 = 0;
  uStack_144 = 0xf;
  uStack_158 = uStack_158 & 0xffffff00;
  uStack_2c = (ulonglong)DAT_019398c8;
  uStack_14 = 0x3f5527dc;
  uStack_16c = 0;
  uStack_168 = 0xf;
  uStack_17c = uStack_17c & 0xffffff00;
  uStack_140 = uStack_3ec;
  FUN_005542c0("RightHand",9);
  uStack_3c8 = CONCAT44(DAT_0193992c,(undefined4)uStack_2c);
  uStack_15c = uStack_14;
  uStack_3e0 = uStack_17c;
  uStack_3dc = uStack_178;
  uStack_3d8 = uStack_174;
  uStack_3d4 = uStack_170;
  uStack_3c0 = uStack_14;
  uStack_3d0 = CONCAT44(uStack_168,uStack_16c);
  uStack_8._0_1_ = 4;
  uStack_16c = 0;
  uStack_168 = 0xf;
  uStack_17c = uStack_17c & 0xffffff00;
  uStack_24 = (ulonglong)DAT_019398c4;
  uStack_14 = 0x3f897c90;
  uStack_190 = 0;
  uStack_18c = 0xf;
  uStack_1a0 = uStack_1a0 & 0xffffff00;
  uStack_164 = uStack_3c8;
  FUN_005542c0("RightFoot",9);
  uStack_3a4 = CONCAT44(DAT_01939938,(undefined4)uStack_24);
  uStack_180 = uStack_14;
  uStack_3bc = uStack_1a0;
  uStack_3b8 = uStack_19c;
  uStack_3b4 = uStack_198;
  uStack_3b0 = uStack_194;
  uStack_39c = uStack_14;
  uStack_3ac = CONCAT44(uStack_18c,uStack_190);
  uStack_8._0_1_ = 5;
  uStack_190 = 0;
  uStack_18c = 0xf;
  uStack_1a0 = uStack_1a0 & 0xffffff00;
  uStack_14 = 0x3f897c90;
  uStack_1b4 = 0;
  uStack_1b0 = 0xf;
  uStack_1c4 = uStack_1c4 & 0xffffff00;
  uStack_188 = uStack_3a4;
  FUN_005542c0("LeftFoot",8);
  uStack_380 = CONCAT44(DAT_01939938,(int)uStack_24);
  uStack_1a4 = uStack_14;
  uStack_398 = uStack_1c4;
  uStack_394 = uStack_1c0;
  uStack_390 = uStack_1bc;
  uStack_38c = uStack_1b8;
  uStack_378 = uStack_14;
  uStack_388 = CONCAT44(uStack_1b0,uStack_1b4);
  uStack_8._0_1_ = 6;
  uStack_1b4 = 0;
  uStack_1b0 = 0xf;
  uStack_1c4 = uStack_1c4 & 0xffffff00;
  uStack_14 = 0x3f843b3d;
  uStack_1d8 = 0;
  uStack_1d4 = 0xf;
  uStack_1e8 = uStack_1e8 & 0xffffff00;
  uStack_1ac = uStack_380;
  FUN_005542c0("LeftUpperArm",0xc);
  uStack_35c = CONCAT44(DAT_01939998,(undefined4)uStack_38);
  uStack_1c8 = uStack_14;
  uStack_374 = uStack_1e8;
  uStack_370 = uStack_1e4;
  uStack_36c = uStack_1e0;
  uStack_368 = uStack_1dc;
  uStack_354 = uStack_14;
  uStack_364 = CONCAT44(uStack_1d4,uStack_1d8);
  uStack_8._0_1_ = 7;
  uStack_1d8 = 0;
  uStack_1d4 = 0xf;
  uStack_1e8 = uStack_1e8 & 0xffffff00;
  uStack_14 = 0x3f843b3d;
  uStack_1fc = 0;
  uStack_1f8 = 0xf;
  uStack_20c = uStack_20c & 0xffffff00;
  uStack_1d0 = uStack_35c;
  FUN_005542c0("RightLowerArm",0xd);
  uStack_338 = CONCAT44(DAT_01939998,(undefined4)uStack_38);
  uStack_1ec = uStack_14;
  uStack_350 = uStack_20c;
  uStack_34c = uStack_208;
  uStack_348 = uStack_204;
  uStack_344 = uStack_200;
  uStack_330 = uStack_14;
  uStack_340 = CONCAT44(uStack_1f8,uStack_1fc);
  uStack_8._0_1_ = 8;
  uStack_1fc = 0;
  uStack_1f8 = 0xf;
  uStack_20c = uStack_20c & 0xffffff00;
  uStack_14 = 0x3f5527dc;
  uStack_220 = 0;
  uStack_21c = 0xf;
  uStack_230 = uStack_230 & 0xffffff00;
  uStack_1f4 = uStack_338;
  FUN_005542c0("LeftHand",8);
  uStack_314 = CONCAT44(DAT_0193992c,(int)uStack_2c);
  uStack_210 = uStack_14;
  uStack_32c = uStack_230;
  uStack_328 = uStack_22c;
  uStack_324 = uStack_228;
  uStack_320 = uStack_224;
  uStack_30c = uStack_14;
  uStack_31c = CONCAT44(uStack_21c,uStack_220);
  uStack_8._0_1_ = 9;
  uStack_220 = 0;
  uStack_21c = 0xf;
  uStack_230 = uStack_230 & 0xffffff00;
  uStack_24 = (ulonglong)DAT_01939918;
  uStack_14 = 0x3f726c9b;
  uStack_244 = 0;
  uStack_240 = 0xf;
  uStack_254 = uStack_254 & 0xffffff00;
  uStack_218 = uStack_314;
  FUN_005542c0("RightUpperLeg",0xd);
  uStack_2f0 = CONCAT44(DAT_01939970,(undefined4)uStack_24);
  uStack_234 = uStack_14;
  uStack_308 = uStack_254;
  uStack_304 = uStack_250;
  uStack_300 = uStack_24c;
  uStack_2fc = uStack_248;
  uStack_2e8 = uStack_14;
  uStack_2f8 = CONCAT44(uStack_240,uStack_244);
  uStack_8._0_1_ = 10;
  uStack_244 = 0;
  uStack_240 = 0xf;
  uStack_254 = uStack_254 & 0xffffff00;
  uStack_14 = 0x3f843b3d;
  uStack_4c = 0;
  uStack_48 = 0xf;
  uStack_5c = uStack_5c & 0xffffff00;
  uStack_23c = uStack_2f0;
  FUN_005542c0("RightUpperArm",0xd);
  uStack_2cc = CONCAT44(DAT_01939998,(int)uStack_38);
  uStack_3c = uStack_14;
  uStack_2e4 = uStack_5c;
  uStack_2e0 = uStack_58;
  uStack_2dc = uStack_54;
  uStack_2d8 = uStack_50;
  uStack_5c = uStack_5c & 0xffffff00;
  uStack_2d4 = CONCAT44(uStack_48,uStack_4c);
  uStack_4c = 0;
  uStack_48 = 0xf;
  uStack_2c4 = uStack_14;
  uStack_8._0_1_ = 0xb;
  uStack_44 = uStack_2cc;
  FUN_005507b0();
  uStack_14 = 0x3f726c9b;
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = uStack_80 & 0xffffff00;
  FUN_005542c0("RightLowerLeg",0xd);
  uStack_2a8 = CONCAT44(DAT_01939970,(undefined4)uStack_24);
  uStack_2c0 = uStack_80;
  uStack_2bc = uStack_7c;
  uStack_2b8 = uStack_78;
  uStack_2b4 = uStack_74;
  uStack_60 = uStack_14;
  uStack_2b0 = CONCAT44(uStack_6c,uStack_70);
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = uStack_80 & 0xffffff00;
  uStack_2a0 = uStack_14;
  uStack_8._0_1_ = 0xc;
  uStack_68 = uStack_2a8;
  FUN_005507b0();
  uStack_14 = 0x3f726c9b;
  uStack_94 = 0;
  uStack_90 = 0xf;
  uStack_a4 = uStack_a4 & 0xffffff00;
  FUN_005542c0("LeftUpperLeg",0xc);
  uStack_284 = CONCAT44(DAT_01939970,(undefined4)uStack_24);
  uStack_84 = uStack_14;
  uStack_29c = uStack_a4;
  uStack_298 = uStack_a0;
  uStack_294 = uStack_9c;
  uStack_290 = uStack_98;
  uStack_a4 = uStack_a4 & 0xffffff00;
  uStack_28c = CONCAT44(uStack_90,uStack_94);
  uStack_94 = 0;
  uStack_90 = 0xf;
  uStack_27c = uStack_14;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  uStack_8c = uStack_284;
  FUN_005507b0();
  uStack_14 = 0x3f726c9b;
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_c8 = uStack_c8 & 0xffffff00;
  FUN_005542c0("LeftLowerLeg",0xc);
  uStack_260 = CONCAT44(DAT_01939970,(int)uStack_24);
  uStack_a8 = uStack_14;
  uStack_278 = uStack_c8;
  uStack_274 = uStack_c4;
  uStack_270 = uStack_c0;
  uStack_26c = uStack_bc;
  uStack_c8 = uStack_c8 & 0xffffff00;
  uStack_268 = CONCAT44(uStack_b4,uStack_b8);
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_258 = uStack_14;
  uStack_b0 = uStack_260;
  FUN_005507b0();
  uStack_8 = 0xe;
  FUN_009a1ed0(&uStack_470,&uStack_254);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_470,0x24,0xf,FUN_005507b0);
  FUN_016f3654(&LAB_01887310);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 707 ; VA 0x004a38e0 ; FUN_004a38e0 */

void FUN_004a38e0(void)

{
  uint uStack_480;
  undefined4 uStack_47c;
  undefined4 uStack_478;
  undefined4 uStack_474;
  undefined8 uStack_470;
  undefined8 uStack_468;
  undefined4 uStack_460;
  uint uStack_45c;
  undefined4 uStack_458;
  undefined4 uStack_454;
  undefined4 uStack_450;
  undefined8 uStack_44c;
  undefined8 uStack_444;
  undefined4 uStack_43c;
  uint uStack_438;
  undefined4 uStack_434;
  undefined4 uStack_430;
  undefined4 uStack_42c;
  undefined8 uStack_428;
  undefined8 uStack_420;
  undefined4 uStack_418;
  uint uStack_414;
  undefined4 uStack_410;
  undefined4 uStack_40c;
  undefined4 uStack_408;
  undefined8 uStack_404;
  undefined8 uStack_3fc;
  undefined4 uStack_3f4;
  uint uStack_3f0;
  undefined4 uStack_3ec;
  undefined4 uStack_3e8;
  undefined4 uStack_3e4;
  undefined8 uStack_3e0;
  undefined8 uStack_3d8;
  undefined4 uStack_3d0;
  uint uStack_3cc;
  undefined4 uStack_3c8;
  undefined4 uStack_3c4;
  undefined4 uStack_3c0;
  undefined8 uStack_3bc;
  undefined8 uStack_3b4;
  undefined4 uStack_3ac;
  uint uStack_3a8;
  undefined4 uStack_3a4;
  undefined4 uStack_3a0;
  undefined4 uStack_39c;
  undefined8 uStack_398;
  undefined8 uStack_390;
  undefined4 uStack_388;
  uint uStack_384;
  undefined4 uStack_380;
  undefined4 uStack_37c;
  undefined4 uStack_378;
  undefined8 uStack_374;
  undefined8 uStack_36c;
  undefined4 uStack_364;
  uint uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_354;
  undefined8 uStack_350;
  undefined8 uStack_348;
  undefined4 uStack_340;
  uint uStack_33c;
  undefined4 uStack_338;
  undefined4 uStack_334;
  undefined4 uStack_330;
  undefined8 uStack_32c;
  undefined8 uStack_324;
  undefined4 uStack_31c;
  uint uStack_318;
  undefined4 uStack_314;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  undefined8 uStack_308;
  undefined8 uStack_300;
  undefined4 uStack_2f8;
  uint uStack_2f4;
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  undefined4 uStack_2e8;
  undefined8 uStack_2e4;
  undefined8 uStack_2dc;
  undefined4 uStack_2d4;
  uint uStack_2d0;
  undefined4 uStack_2cc;
  undefined4 uStack_2c8;
  undefined4 uStack_2c4;
  undefined8 uStack_2c0;
  undefined8 uStack_2b8;
  undefined4 uStack_2b0;
  uint uStack_2ac;
  undefined4 uStack_2a8;
  undefined4 uStack_2a4;
  undefined4 uStack_2a0;
  undefined8 uStack_29c;
  undefined8 uStack_294;
  undefined4 uStack_28c;
  uint uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined8 uStack_278;
  undefined8 uStack_270;
  undefined4 uStack_268;
  uint uStack_264;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  undefined4 uStack_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined8 uStack_24c;
  undefined4 uStack_244;
  uint uStack_240;
  undefined4 uStack_23c;
  undefined4 uStack_238;
  undefined4 uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined8 uStack_228;
  undefined4 uStack_220;
  uint uStack_21c;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined4 uStack_208;
  undefined8 uStack_204;
  undefined4 uStack_1fc;
  uint uStack_1f8;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined8 uStack_1e0;
  undefined4 uStack_1d8;
  uint uStack_1d4;
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined8 uStack_1bc;
  undefined4 uStack_1b4;
  uint uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined8 uStack_198;
  undefined4 uStack_190;
  uint uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined8 uStack_174;
  undefined4 uStack_16c;
  uint uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined8 uStack_150;
  undefined4 uStack_148;
  uint uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined8 uStack_12c;
  undefined4 uStack_124;
  uint uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined8 uStack_108;
  undefined4 uStack_100;
  uint uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  uint uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined4 uStack_b8;
  uint uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  uint uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  uint uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  undefined4 uStack_4c;
  undefined8 uStack_44;
  ulonglong uStack_3c;
  undefined8 uStack_30;
  undefined8 uStack_24;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3ee0;
  pvStack_10 = ExceptionList;
  uStack_3c = (ulonglong)DAT_01939950;
  uStack_44._4_4_ = 0x3f90e560;
  uStack_ec = 0;
  uStack_e8 = 0xf;
  uStack_fc = uStack_fc & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("LeftLowerArm",0xc);
  uStack_468 = CONCAT44(DAT_0193998c,(undefined4)uStack_3c);
  uStack_dc = uStack_44._4_4_;
  uStack_480 = uStack_fc;
  uStack_47c = uStack_f8;
  uStack_478 = uStack_f4;
  uStack_474 = uStack_f0;
  uStack_460 = uStack_44._4_4_;
  uStack_470 = CONCAT44(uStack_e8,uStack_ec);
  uStack_8 = 0;
  uStack_ec = 0;
  uStack_e8 = 0xf;
  uStack_fc = uStack_fc & 0xffffff00;
  uStack_44 = (ulonglong)DAT_01939948;
  uStack_30._4_4_ = 0x3f908312;
  uStack_110 = 0;
  uStack_10c = 0xf;
  uStack_120 = uStack_120 & 0xffffff00;
  uStack_e4 = uStack_468;
  FUN_005542c0("LeftFoot",8);
  uStack_444 = CONCAT44(DAT_01939974,(undefined4)uStack_44);
  uStack_100 = uStack_30._4_4_;
  uStack_45c = uStack_120;
  uStack_458 = uStack_11c;
  uStack_454 = uStack_118;
  uStack_450 = uStack_114;
  uStack_43c = uStack_30._4_4_;
  uStack_44c = CONCAT44(uStack_10c,uStack_110);
  uStack_8._0_1_ = 1;
  uStack_110 = 0;
  uStack_10c = 0xf;
  uStack_120 = uStack_120 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_019398f0;
  uStack_24._4_4_ = 0x3f7126e9;
  uStack_134 = 0;
  uStack_130 = 0xf;
  uStack_144 = uStack_144 & 0xffffff00;
  uStack_108 = uStack_444;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_420 = CONCAT44((undefined4)uStack_30,(undefined4)uStack_30);
  uStack_438 = uStack_144;
  uStack_434 = uStack_140;
  uStack_430 = uStack_13c;
  uStack_42c = uStack_138;
  uStack_124 = uStack_24._4_4_;
  uStack_428 = CONCAT44(uStack_130,uStack_134);
  uStack_418 = uStack_24._4_4_;
  uStack_8._0_1_ = 2;
  uStack_134 = 0;
  uStack_130 = 0xf;
  uStack_144 = uStack_144 & 0xffffff00;
  uStack_24 = (ulonglong)DAT_01939924;
  uStack_30._4_4_ = 0x3f91eb85;
  uStack_158 = 0;
  uStack_154 = 0xf;
  uStack_168 = uStack_168 & 0xffffff00;
  uStack_12c = uStack_420;
  FUN_005542c0("UpperTorso",10);
  uStack_3fc = CONCAT44(DAT_0193997c,(undefined4)uStack_24);
  uStack_148 = uStack_30._4_4_;
  uStack_414 = uStack_168;
  uStack_410 = uStack_164;
  uStack_40c = uStack_160;
  uStack_408 = uStack_15c;
  uStack_3f4 = uStack_30._4_4_;
  uStack_404 = CONCAT44(uStack_154,uStack_158);
  uStack_8._0_1_ = 3;
  uStack_158 = 0;
  uStack_154 = 0xf;
  uStack_168 = uStack_168 & 0xffffff00;
  uStack_30 = (ulonglong)DAT_01939940;
  uStack_14 = 0x3f9d9168;
  uStack_17c = 0;
  uStack_178 = 0xf;
  uStack_18c = uStack_18c & 0xffffff00;
  uStack_150 = uStack_3fc;
  FUN_005542c0("RightHand",9);
  uStack_3d8 = CONCAT44(DAT_01939964,(undefined4)uStack_30);
  uStack_16c = uStack_14;
  uStack_3f0 = uStack_18c;
  uStack_3ec = uStack_188;
  uStack_3e8 = uStack_184;
  uStack_3e4 = uStack_180;
  uStack_3d0 = uStack_14;
  uStack_3e0 = CONCAT44(uStack_178,uStack_17c);
  uStack_8._0_1_ = 4;
  uStack_17c = 0;
  uStack_178 = 0xf;
  uStack_18c = uStack_18c & 0xffffff00;
  uStack_14 = 0x3f91eb85;
  uStack_1a0 = 0;
  uStack_19c = 0xf;
  uStack_1b0 = uStack_1b0 & 0xffffff00;
  uStack_174 = uStack_3d8;
  FUN_005542c0("LowerTorso",10);
  uStack_3b4 = CONCAT44(DAT_0193997c,(int)uStack_24);
  uStack_190 = uStack_14;
  uStack_3cc = uStack_1b0;
  uStack_3c8 = uStack_1ac;
  uStack_3c4 = uStack_1a8;
  uStack_3c0 = uStack_1a4;
  uStack_3ac = uStack_14;
  uStack_3bc = CONCAT44(uStack_19c,uStack_1a0);
  uStack_8._0_1_ = 5;
  uStack_1a0 = 0;
  uStack_19c = 0xf;
  uStack_1b0 = uStack_1b0 & 0xffffff00;
  uStack_24 = (ulonglong)DAT_0193991c;
  uStack_14 = 0x3f82f1aa;
  uStack_1c4 = 0;
  uStack_1c0 = 0xf;
  uStack_1d4 = uStack_1d4 & 0xffffff00;
  uStack_198 = uStack_3b4;
  FUN_005542c0("LeftUpperLeg",0xc);
  uStack_390 = CONCAT44(DAT_0193999c,(undefined4)uStack_24);
  uStack_1b4 = uStack_14;
  uStack_3a8 = uStack_1d4;
  uStack_3a4 = uStack_1d0;
  uStack_3a0 = uStack_1cc;
  uStack_39c = uStack_1c8;
  uStack_388 = uStack_14;
  uStack_398 = CONCAT44(uStack_1c0,uStack_1c4);
  uStack_8._0_1_ = 6;
  uStack_1c4 = 0;
  uStack_1c0 = 0xf;
  uStack_1d4 = uStack_1d4 & 0xffffff00;
  uStack_14 = 0x3f90e560;
  uStack_1e8 = 0;
  uStack_1e4 = 0xf;
  uStack_1f8 = uStack_1f8 & 0xffffff00;
  uStack_1bc = uStack_390;
  FUN_005542c0("LeftUpperArm",0xc);
  uStack_36c = CONCAT44(DAT_0193998c,(undefined4)uStack_3c);
  uStack_1d8 = uStack_14;
  uStack_384 = uStack_1f8;
  uStack_380 = uStack_1f4;
  uStack_37c = uStack_1f0;
  uStack_378 = uStack_1ec;
  uStack_364 = uStack_14;
  uStack_374 = CONCAT44(uStack_1e4,uStack_1e8);
  uStack_8._0_1_ = 7;
  uStack_1e8 = 0;
  uStack_1e4 = 0xf;
  uStack_1f8 = uStack_1f8 & 0xffffff00;
  uStack_14 = 0x3f90e560;
  uStack_20c = 0;
  uStack_208 = 0xf;
  uStack_21c = uStack_21c & 0xffffff00;
  uStack_1e0 = uStack_36c;
  FUN_005542c0("RightLowerArm",0xd);
  uStack_348 = CONCAT44(DAT_0193998c,(undefined4)uStack_3c);
  uStack_1fc = uStack_14;
  uStack_360 = uStack_21c;
  uStack_35c = uStack_218;
  uStack_358 = uStack_214;
  uStack_354 = uStack_210;
  uStack_340 = uStack_14;
  uStack_350 = CONCAT44(uStack_208,uStack_20c);
  uStack_8._0_1_ = 8;
  uStack_20c = 0;
  uStack_208 = 0xf;
  uStack_21c = uStack_21c & 0xffffff00;
  uStack_14 = 0x3f9d9168;
  uStack_230 = 0;
  uStack_22c = 0xf;
  uStack_240 = uStack_240 & 0xffffff00;
  uStack_204 = uStack_348;
  FUN_005542c0("LeftHand",8);
  uStack_324 = CONCAT44(DAT_01939964,(int)uStack_30);
  uStack_220 = uStack_14;
  uStack_33c = uStack_240;
  uStack_338 = uStack_23c;
  uStack_334 = uStack_238;
  uStack_330 = uStack_234;
  uStack_31c = uStack_14;
  uStack_32c = CONCAT44(uStack_22c,uStack_230);
  uStack_8._0_1_ = 9;
  uStack_230 = 0;
  uStack_22c = 0xf;
  uStack_240 = uStack_240 & 0xffffff00;
  uStack_14 = 0x3f90e560;
  uStack_254 = 0;
  uStack_250 = 0xf;
  uStack_264 = uStack_264 & 0xffffff00;
  uStack_228 = uStack_324;
  FUN_005542c0("RightUpperArm",0xd);
  uStack_300 = CONCAT44(DAT_0193998c,(int)uStack_3c);
  uStack_244 = uStack_14;
  uStack_318 = uStack_264;
  uStack_314 = uStack_260;
  uStack_310 = uStack_25c;
  uStack_30c = uStack_258;
  uStack_2f8 = uStack_14;
  uStack_308 = CONCAT44(uStack_250,uStack_254);
  uStack_8._0_1_ = 10;
  uStack_254 = 0;
  uStack_250 = 0xf;
  uStack_264 = uStack_264 & 0xffffff00;
  uStack_14 = 0x3f82f1aa;
  uStack_5c = 0;
  uStack_58 = 0xf;
  uStack_6c = uStack_6c & 0xffffff00;
  uStack_24c = uStack_300;
  FUN_005542c0("RightUpperLeg",0xd);
  uStack_2dc = CONCAT44(DAT_0193999c,(undefined4)uStack_24);
  uStack_4c = uStack_14;
  uStack_2f4 = uStack_6c;
  uStack_2f0 = uStack_68;
  uStack_2ec = uStack_64;
  uStack_2e8 = uStack_60;
  uStack_6c = uStack_6c & 0xffffff00;
  uStack_2e4 = CONCAT44(uStack_58,uStack_5c);
  uStack_5c = 0;
  uStack_58 = 0xf;
  uStack_2d4 = uStack_14;
  uStack_8._0_1_ = 0xb;
  uStack_54 = uStack_2dc;
  FUN_005507b0();
  uStack_14 = 0x3f82f1aa;
  uStack_80 = 0;
  uStack_7c = 0xf;
  uStack_90 = uStack_90 & 0xffffff00;
  FUN_005542c0("RightLowerLeg",0xd);
  uStack_2b8 = CONCAT44(DAT_0193999c,(undefined4)uStack_24);
  uStack_2d0 = uStack_90;
  uStack_2cc = uStack_8c;
  uStack_2c8 = uStack_88;
  uStack_2c4 = uStack_84;
  uStack_70 = uStack_14;
  uStack_2c0 = CONCAT44(uStack_7c,uStack_80);
  uStack_80 = 0;
  uStack_7c = 0xf;
  uStack_90 = uStack_90 & 0xffffff00;
  uStack_2b0 = uStack_14;
  uStack_8._0_1_ = 0xc;
  uStack_78 = uStack_2b8;
  FUN_005507b0();
  uStack_14 = 0x3f908312;
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  uStack_b4 = uStack_b4 & 0xffffff00;
  FUN_005542c0("RightFoot",9);
  uStack_294 = CONCAT44(DAT_01939974,(int)uStack_44);
  uStack_94 = uStack_14;
  uStack_2ac = uStack_b4;
  uStack_2a8 = uStack_b0;
  uStack_2a4 = uStack_ac;
  uStack_2a0 = uStack_a8;
  uStack_b4 = uStack_b4 & 0xffffff00;
  uStack_29c = CONCAT44(uStack_a0,uStack_a4);
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  uStack_28c = uStack_14;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  uStack_9c = uStack_294;
  FUN_005507b0();
  uStack_14 = 0x3f82f1aa;
  uStack_c8 = 0;
  uStack_c4 = 0xf;
  uStack_d8 = uStack_d8 & 0xffffff00;
  FUN_005542c0("LeftLowerLeg",0xc);
  uStack_270 = CONCAT44(DAT_0193999c,(int)uStack_24);
  uStack_b8 = uStack_14;
  uStack_288 = uStack_d8;
  uStack_284 = uStack_d4;
  uStack_280 = uStack_d0;
  uStack_27c = uStack_cc;
  uStack_d8 = uStack_d8 & 0xffffff00;
  uStack_278 = CONCAT44(uStack_c4,uStack_c8);
  uStack_c8 = 0;
  uStack_c4 = 0xf;
  uStack_268 = uStack_14;
  uStack_c0 = uStack_270;
  FUN_005507b0();
  uStack_8 = 0xe;
  FUN_009a1ed0(&uStack_480,&uStack_264);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_480,0x24,0xf,FUN_005507b0);
  FUN_016f3654(&LAB_01887320);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 708 ; VA 0x004a4310 ; FUN_004a4310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_004a4310(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d58c2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  _DAT_01d6526c = FUN_00575af0(param_1);
  DAT_01d65274 = 0;
  _DAT_01d65288 = 0;
  _DAT_01d6528c = 0xf;
  DAT_01d65278 = 0;
  PTR_vftable_01d65268 = (undefined *)RBX::ClientAppSettings::vftable;
  _DAT_01d652b4 = 0;
  _DAT_01d652b8 = 0xf;
  DAT_01d652a4 = 0;
  _DAT_01d652cc = 0;
  _DAT_01d652d0 = 0xf;
  DAT_01d652bc = 0;
  _DAT_01d652f8 = 0;
  _DAT_01d652fc = 0xf;
  DAT_01d652e8 = 0;
  _DAT_01d65310 = 0;
  _DAT_01d65314 = 0xf;
  DAT_01d65300 = 0;
  uStack_8 = 4;
  DAT_01ee421c = &PTR_vftable_01d65268;
  FUN_009c96b0();
  FUN_016f3654(&LAB_018873b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 709 ; VA 0x004a4fa0 ; FUN_004a4fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a4fa0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d633a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_009d5f50();
  FUN_006846c0(uVar3,s_Brightness_02124a58,s_Appearance_02119800,0);
  uStack_8 = 0;
  DAT_02124770 = RBX::Reflection::BoundProp<float,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::Lighting>::vftable;
    puVar4[1] = &DAT_02124770;
    puVar4[2] = 0x100;
    puVar4[4] = &LAB_009d8680;
    puVar4[5] = 0;
  }
  if (DAT_021247a4 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021247a4;
    DAT_021247a4 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_021247a4;
  }
  DAT_021247a4 = puVar4;
  cVar2 = (*(code *)DAT_02124770[3])();
  if (cVar2 != '\0') {
    _DAT_02124794 = _DAT_02124794 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02124770[2])();
  if (cVar2 != '\0') {
    _DAT_02124794 = _DAT_02124794 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 710 ; VA 0x004a5240 ; FUN_004a5240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a5240(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6384;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00712f70();
  uVar3 = FUN_009d5f50();
  FUN_009ca670(uVar3,uVar2,s_Technology_02124a4c,s_Appearance_02119800,uStack_24,0,0,0xf,0,0,1);
  uStack_8 = 0;
  DAT_02124730 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Lighting,enum_RBX::LightingTechnology>::vftable;
  _DAT_02124764 = uVar2;
  DAT_02124768 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02124768 == (undefined4 *)0x0) {
    DAT_02124768 = (undefined4 *)0x0;
  }
  else {
    *DAT_02124768 =
         RBX::Reflection::PropDescriptor<class_RBX::Lighting,enum_RBX::LightingTechnology>::
         GetSetImpl<enum_RBX::LightingTechnology_(__thiscall_RBX::Lighting::*)(void)const_,void_(__thiscall_RBX::Lighting::*)(enum_RBX::LightingTechnology)>
         ::vftable;
    DAT_02124768[2] = FUN_009d7c30;
    DAT_02124768[3] = 0;
    DAT_02124768[4] = FUN_009d8c60;
    DAT_02124768[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0212476c = FUN_00712f70();
  cVar1 = (*(code *)DAT_02124730[3])();
  if (cVar1 != '\0') {
    _DAT_02124754 = _DAT_02124754 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02124730[2])();
  if (cVar1 != '\0') {
    _DAT_02124754 = _DAT_02124754 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01887560);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 711 ; VA 0x004a5b00 ; FUN_004a5b00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a5b00(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d63b3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009d5f50();
  FUN_009cb970(uVar1,s_LightingChanged_021248cc,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021242bc = 0x138;
  iStack_8 = 0;
  _DAT_02124288 =
       RBX::Reflection::
       EventDesc<class_RBX::Lighting,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::Lighting::*>
       ::vftable;
  FUN_0086e3d0(s_skyChanged_021248c0);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021242b0 = uStack_1c;
  _DAT_021242b4 = uStack_18;
  _DAT_021242b8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02124288 =
       RBX::Reflection::
       EventDesc<class_RBX::Lighting,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::Lighting::*>
       ::vftable;
  FUN_016f3654(&LAB_018876c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 712 ; VA 0x004a5c50 ; FUN_004a5c50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a5c50(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d63ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009d5f50(uVar2,0);
  FUN_009cb790(uVar1,s_GetMinutesAfterMidnight_0212493c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02124428 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Lighting,double___cdecl(void),0>::vftable;
  _DAT_02124460 = FUN_009d7b90;
  _DAT_02124464 = 0;
  _DAT_0212444c = FUN_0088ca00();
  FUN_016f3654(&LAB_018876d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 713 ; VA 0x004a5cf0 ; FUN_004a5cf0 */

void FUN_004a5cf0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009d67e0(FUN_009d8ad0,0,s_SetMinutesAfterMidnight_0212495c,s_minutes_02124954,0,uStack_10,0);
  FUN_016f3654(&LAB_018876e0);
  return;
}



/* FUNCTION 714 ; VA 0x004a5d50 ; FUN_004a5d50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a5d50(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d63ea;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02124428;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009d5f50(uVar2,&DAT_02124428);
  FUN_009cb790(uVar1,s_getMinutesAfterMidnight_02124974,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021244b0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Lighting,double___cdecl(void),0>::vftable;
  _DAT_021244e8 = FUN_009d7b90;
  _DAT_021244ec = 0;
  _DAT_021244d4 = FUN_0088ca00();
  FUN_016f3654(&LAB_01887700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 715 ; VA 0x004a5df0 ; FUN_004a5df0 */

void FUN_004a5df0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_009d67e0(FUN_009d8ad0,0,s_setMinutesAfterMidnight_0212498c,s_minutes_02124954,0,
               CONCAT44(&DAT_02124468,uStack_10),0);
  FUN_016f3654(&LAB_01887710);
  return;
}



/* FUNCTION 716 ; VA 0x004a5fd0 ; FUN_004a5fd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a5fd0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d640a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009d5f50(uVar2,0);
  FUN_009cb790(uVar1,s_GetMoonPhase_02124908,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02124368 = RBX::Reflection::BoundFuncDesc<class_RBX::Lighting,float___cdecl(void),0>::vftable
  ;
  _DAT_021243a0 = &LAB_009d7bd0;
  _DAT_021243a4 = 0;
  _DAT_0212438c = FUN_0088c960();
  FUN_016f3654(&LAB_01887770);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 717 ; VA 0x004a6070 ; FUN_004a6070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a6070(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d642a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009d5f50(uVar2,0);
  FUN_009cb790(uVar1,s_GetMoonDirection_02124918,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021243a8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Lighting,class_G3D::Vector3___cdecl(void),0>::
       vftable;
  _DAT_021243e0 = FUN_009d7be0;
  _DAT_021243e4 = 0;
  _DAT_021243cc = FUN_0088d870();
  FUN_016f3654(&LAB_01887780);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 718 ; VA 0x004a6110 ; FUN_004a6110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a6110(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d644a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009d5f50(uVar2,0);
  FUN_009cb790(uVar1,s_GetSunDirection_0212492c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021243e8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Lighting,class_G3D::Vector3___cdecl(void),0>::
       vftable;
  _DAT_02124420 = FUN_009d7c10;
  _DAT_02124424 = 0;
  _DAT_0212440c = FUN_0088d870();
  FUN_016f3654(&LAB_01887790);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 719 ; VA 0x004a61b0 ; FUN_004a61b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a61b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d647c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009d5f50();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Lighting,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::Lighting::*)(void)const_,void_(__thiscall_RBX::Lighting::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)>
              ::vftable;
    puVar3[2] = FUN_009d7c70;
    puVar3[3] = 0;
    puVar3[4] = FUN_009d8e00;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_TimeOfDay_021248dc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_021242c0 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021242f4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021242e4 = _DAT_021242e4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021242c0[2])();
    if (cVar1 != '\0') {
      _DAT_021242e4 = _DAT_021242e4 & 0xfffffff3;
    }
  }
  DAT_021242c0 = RBX::Reflection::
                 PropDescriptor<class_RBX::Lighting,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_018877a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 720 ; VA 0x004a65f0 ; FUN_004a65f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a65f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d65dc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009d9830();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ColorCorrectionEffect,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_const&_(__thiscall_RBX::ColorCorrectionEffect::*)(void)const_,void_(__thiscall_RBX::ColorCorrectionEffect::*)(class_G3D::Color3_const&)>
              ::vftable;
    puVar3[2] = &LAB_009d9ac0;
    puVar3[3] = 0;
    puVar3[4] = FUN_009d9ba0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,s_TintColor_02124c6c,s_State_0211d030,uStack_24,0,0,0x1f,0,0,0);
  DAT_02124c1c = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02124c50 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02124c40 = _DAT_02124c40 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02124c1c[2])();
    if (cVar1 != '\0') {
      _DAT_02124c40 = _DAT_02124c40 & 0xfffffff3;
    }
  }
  DAT_02124c1c = RBX::Reflection::PropDescriptor<class_RBX::ColorCorrectionEffect,class_G3D::Color3>
                 ::vftable;
  FUN_016f3654(&LAB_01887940);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 721 ; VA 0x004a6750 ; FUN_004a6750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a6750(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6c0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009de430(uVar2,0);
  FUN_009cb790(uVar1,"GetContentMemoryData",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01ee4d30 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MeshContentProvider,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_01ee4d68 = FUN_009de840;
  _DAT_01ee4d6c = 0;
  _DAT_01ee4d54 = FUN_008881d0();
  FUN_016f3654(&LAB_018879d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 722 ; VA 0x004a6820 ; FUN_004a6820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a6820(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("SelectionServiceAddRemove",0x19);
  _DAT_01ee51a8 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 723 ; VA 0x004a6880 ; FUN_004a6880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a6880(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009df5a0(uVar2,0);
  FUN_009cb970(uVar1,s_SelectionChanged_02124e40,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02124dc4 = 0xa8;
  _DAT_02124d90 =
       RBX::Reflection::
       EventDesc<class_RBX::Selection,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Selection::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02124db8 = 0;
  _DAT_02124dbc = 0;
  _DAT_02124dc0 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_02124d90 =
       RBX::Reflection::
       EventDesc<class_RBX::Selection,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Selection::*>
       ::vftable;
  FUN_016f3654(&LAB_01887a00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 724 ; VA 0x004a6970 ; FUN_004a6970 */

void FUN_004a6970(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009df970(FUN_009e0120,0,&DAT_02124e28,s_instancesToAdd_02124e18,1,uStack_10,0);
  FUN_016f3654(&LAB_01887a10);
  return;
}



/* FUNCTION 725 ; VA 0x004a69d0 ; FUN_004a69d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a69d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6f1a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009df5a0(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02124e04,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02124c78 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Selection,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02124cb0 = FUN_0085e880;
  _DAT_02124cb4 = 0;
  _DAT_02124c9c = FUN_0088cc80();
  FUN_016f3654(&LAB_01887a60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 726 ; VA 0x004a6a70 ; FUN_004a6a70 */

void FUN_004a6a70(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009df970(FUN_009e0c40,0,s_Remove_0211a9f0,s_instancesToRemove_02124e2c,1,uStack_10,0);
  FUN_016f3654(&LAB_01887a70);
  return;
}



/* FUNCTION 727 ; VA 0x004a6ad0 ; FUN_004a6ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a6ad0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6f7c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009df5a0();
  FUN_009cb790(uVar1,&DAT_02124e14,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02124cb8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Selection,void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>),1>
       ::vftable;
  _DAT_02124cf0 = FUN_009e0d10;
  _DAT_02124cf4 = 0;
  DAT_02124cf8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02124cdc = FUN_00888530();
  if (DAT_02124cf8 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_008aa360(DAT_02124cf8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cc80();
  uVar3 = FUN_0086e3d0(s_selection_02124e08);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_01887ac0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 728 ; VA 0x004a6c50 ; FUN_004a6c50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a6c50(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6fb0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x15);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_009df5a0();
  FUN_009ca670(uVar2,&DAT_01edf850,s_ActiveInstance_02124e54,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,5
               ,5,0);
  uStack_8 = 1;
  DAT_02124dc8 = RBX::Reflection::RefPropDescriptor<class_RBX::Selection,class_RBX::Instance>::
                 vftable;
  _DAT_02124dfc =
       RBX::Reflection::RefPropDescriptor<class_RBX::Selection,class_RBX::Instance>::vftable;
  DAT_02124e00 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_02124e00 == (undefined4 *)0x0) {
    DAT_02124e00 = (undefined4 *)0x0;
  }
  else {
    *DAT_02124e00 =
         RBX::Reflection::PropDescriptor<class_RBX::Selection,class_RBX::Instance*>::
         GetImpl<class_RBX::Instance*_(__thiscall_RBX::Selection::*)(void)const_>::vftable;
    DAT_02124e00[2] = FUN_009e0720;
    DAT_02124e00[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_02124dc8[3])();
  if (cVar1 != '\0') {
    _DAT_02124dec = _DAT_02124dec & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02124dc8[2])();
  if (cVar1 != '\0') {
    _DAT_02124dec = _DAT_02124dec & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01887b10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 729 ; VA 0x004a6de0 ; FUN_004a6de0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a6de0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d74b6;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_009e1b40();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_HttpEnabled_0212529c,&DAT_021197d4,uStack_24,0,0,0x1f,3,3,0);
  DAT_02125134 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02125100 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::HttpService>::vftable;
    puVar5[1] = &DAT_02125100;
    puVar5[2] = 0xe2;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_02125134 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02125134;
    DAT_02125134 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_02125134;
  }
  DAT_02125134 = puVar5;
  cVar2 = (*(code *)DAT_02125100[3])();
  if (cVar2 != '\0') {
    _DAT_02125124 = _DAT_02125124 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02125100[2])();
  if (cVar2 != '\0') {
    _DAT_02125124 = _DAT_02125124 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01887b40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 730 ; VA 0x004a72b0 ; FUN_004a72b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a72b0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("StudioBrowserSandboxing",0x17);
  _DAT_01ee5454 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 731 ; VA 0x004a73b0 ; FUN_004a73b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a73b0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d750c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009e1b40();
  FUN_009cb790(uVar2,s_JSONDecode_0212522c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02124f58 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HttpService,class_RBX::Reflection::Variant___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02124f90 = FUN_009e5c50;
  _DAT_02124f94 = 0;
  DAT_02124f98 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02124f7c = FUN_00888410();
  iVar1 = DAT_02124f98;
  if (DAT_02124f98 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_input_02125224);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01887ce0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 732 ; VA 0x004a7560 ; FUN_004a7560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a7560(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d756c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009e1b40();
  FUN_009cb790(uVar1,s_JSONEncode_02125238,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02124fa0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HttpService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_RBX::Reflection::Variant),1>
       ::vftable;
  _DAT_02124fd8 = FUN_009e5df0;
  _DAT_02124fdc = 0;
  DAT_02124fe0 = (undefined4 *)0x0;
  uStack_8 = 1;
  _DAT_02124fc4 = FUN_0088cb40();
  puVar4 = DAT_02124fe0;
  if (DAT_02124fe0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = *DAT_02124fe0;
    puStack_ec = (undefined4 *)0x0;
    puVar2 = (undefined4 *)DAT_02124fe0[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)();
      puVar2 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
    puStack_ec = puVar2;
  }
  uVar1 = FUN_00888410();
  uVar3 = FUN_0086e3d0(s_input_02125224);
  FUN_00888b30(uVar3,uVar1,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(auStack_e8);
    }
  }
  FUN_016f3654(FUN_01887d00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 733 ; VA 0x004a7710 ; FUN_004a7710 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a7710(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d75cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009e1b40();
  FUN_009cb820(uVar2,s_RequestAsync_02125214,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02124f10 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::HttpService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),1>
       ::vftable;
  _DAT_02124f48 = FUN_009e8e20;
  _DAT_02124f4c = 0;
  DAT_02124f50 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02124f34 = FUN_008881d0();
  puVar4 = DAT_02124f50;
  if (DAT_02124f50 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_008881d0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_0058c000();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_008881d0();
  uVar3 = FUN_0086e3d0(s_requestOptions_02125204);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01887d70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 734 ; VA 0x004a78e0 ; FUN_004a78e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a78e0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d762c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009e1b40();
  FUN_009cb790(uVar2,s_RequestInternal_0212528c,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021250b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HttpService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),1>
       ::vftable;
  _DAT_021250f0 = FUN_009ea810;
  _DAT_021250f4 = 0;
  DAT_021250f8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021250dc = FUN_0088cdc0();
  puVar4 = DAT_021250f8;
  if (DAT_021250f8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_008881d0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_0058c000();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_008881d0();
  uVar3 = FUN_0086e3d0(s_options_02125284);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01887dc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 735 ; VA 0x004a7ab0 ; FUN_004a7ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a7ab0(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d768c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009e1b40();
  FUN_009cb790(uVar2,s_GenerateGUID_02125264,0,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_02125030 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HttpService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(bool),1>
       ::vftable;
  _DAT_02125068 = FUN_009e75f0;
  _DAT_0212506c = 0;
  DAT_02125070 = (undefined *)FUN_01674e20(1);
  if (DAT_02125070 == (undefined *)0x0) {
    DAT_02125070 = (undefined *)0x0;
  }
  else {
    *DAT_02125070 = 1;
  }
  uStack_8._0_1_ = 1;
  _DAT_02125054 = FUN_0088cb40();
  puVar1 = DAT_02125070;
  if (DAT_02125070 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar1;
    iStack_ec = FUN_005c9ef0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_wrapInCurlyBraces_02125250);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01887e10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 736 ; VA 0x004a7c60 ; FUN_004a7c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a7c60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d76aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009e1b40(uVar2,0);
  FUN_009cb790(uVar1,s_GetHttpEnabled_021252a8,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125138 =
       RBX::Reflection::BoundFuncDesc<class_RBX::HttpService,bool___cdecl(void),0>::vftable;
  _DAT_02125170 = &LAB_009e79e0;
  _DAT_02125174 = 0;
  _DAT_0212515c = FUN_0088daf0();
  FUN_016f3654(&LAB_01887e30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 737 ; VA 0x004a7d00 ; FUN_004a7d00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a7d00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d76ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009e1b40(uVar2,0);
  FUN_009cb790(uVar1,s_GetUserAgent_02125274,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02125078 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HttpService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_021250b0 = FUN_009e79f0;
  _DAT_021250b4 = 0;
  _DAT_0212509c = FUN_0088cb40();
  FUN_016f3654(&LAB_01887e40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 738 ; VA 0x004a7ec0 ; FUN_004a7ec0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a7ec0(void)

{
  int iVar1;
  undefined4 *puVar2;
  char *pcVar3;
  undefined4 uVar4;
  char *pcVar5;
  void **ppvVar6;
  undefined auStack_f0 [8];
  void *apvStack_e8 [6];
  undefined uStack_d0;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined uStack_70;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined uStack_58;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined uStack_40;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined uStack_28;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7763;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&DAT_01d65608);
  uStack_8 = 0;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  uStack_d0 = 0;
  FUN_005542c0(&DAT_018c8720,3);
  uStack_8._0_1_ = 1;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  uStack_b8 = 0;
  FUN_005542c0(&DAT_018c3bf4,4);
  uStack_8._0_1_ = 2;
  uStack_90 = 0;
  uStack_8c = 0xf;
  uStack_a0 = 0;
  FUN_005542c0("Headers",7);
  uStack_8._0_1_ = 3;
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = 0;
  FUN_005542c0("Timeout",7);
  uStack_8._0_1_ = 4;
  uStack_60 = 0;
  uStack_5c = 0xf;
  uStack_70 = 0;
  FUN_005542c0("Priority",8);
  uStack_8._0_1_ = 5;
  uStack_48 = 0;
  uStack_44 = 0xf;
  uStack_58 = 0;
  FUN_005542c0("CachePolicy",0xb);
  uStack_8._0_1_ = 6;
  uStack_30 = 0;
  uStack_2c = 0xf;
  uStack_40 = 0;
  FUN_005542c0(&DAT_0193beb0,0xb);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = 0;
  pcVar3 = "AllowSandboxing";
  do {
    pcVar5 = pcVar3;
    pcVar3 = pcVar5 + 1;
  } while (*pcVar5 != '\0');
  FUN_005542c0(&DAT_0193bb40,pcVar5 + -0x193bb40);
  uStack_8 = 8;
  _DAT_01ee5460 = 0;
  DAT_01ee5464 = (int *)0x0;
  DAT_01ee5468 = 0;
  DAT_01ee5464 = (int *)FUN_005cb2b0(0,0);
  DAT_01ee546c = 0;
  _DAT_01ee5470 = 0;
  _DAT_01ee5474 = 0;
  uStack_8._0_1_ = 10;
  _DAT_01ee5460 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  ppvVar6 = apvStack_e8;
  do {
    iVar1 = *DAT_01ee5464;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar4 = FUN_0086f8b0(iVar1,puVar2,ppvVar6);
    if (DAT_01ee5468 == 0x7fffffe) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01ee5468 = DAT_01ee5468 + 1;
    *(undefined4 *)(iVar1 + 4) = uVar4;
    *puVar2 = uVar4;
    FUN_005ca750(auStack_f0,*DAT_01ee5464 + 8,*DAT_01ee5464);
    ppvVar6 = ppvVar6 + 6;
  } while (ppvVar6 != &pvStack_10);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(apvStack_e8,0x18,9,FUN_005507b0);
  FUN_016f3654(&LAB_018881b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 739 ; VA 0x004a8180 ; FUN_004a8180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a8180(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d77bc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009e1b40();
  FUN_009cb790(uVar2,s_SetHttpEnabled_021252b8,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02125178 =
       RBX::Reflection::BoundFuncDesc<class_RBX::HttpService,void___cdecl(bool),1>::vftable;
  _DAT_021251b0 = FUN_009eb480;
  _DAT_021251b4 = 0;
  DAT_021251b8 = (undefined *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212519c = FUN_00888530();
  puVar1 = DAT_021251b8;
  if (DAT_021251b8 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar1;
    iStack_ec = FUN_005c9ef0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_enabled_02123dec);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01888240);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 740 ; VA 0x004a8320 ; FUN_004a8320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a8320(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d781c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009e1b40();
  FUN_009cb790(uVar2,s_UrlEncode_02125244,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02124fe8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HttpService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02125020 = FUN_009eb780;
  _DAT_02125024 = 0;
  DAT_02125028 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212500c = FUN_0088cb40();
  iVar1 = DAT_02125028;
  if (DAT_02125028 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_input_02125224);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01888260);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 741 ; VA 0x004a84d0 ; FUN_004a84d0 */

/* WARNING: Removing unreachable block (ram,0x004a8649) */
/* WARNING: Removing unreachable block (ram,0x004a85d9) */
/* WARNING: Removing unreachable block (ram,0x004a8629) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a84d0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7880;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00888530();
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_009e1b40();
  FUN_009cb820(uVar2,s_GetAsync_021251d0,0,uStack_20,0);
  _DAT_02124e68 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::HttpService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_RBX::Reflection::Variant),3>
       ::vftable;
  _DAT_02124ea0 = FUN_009eb810;
  _DAT_02124ea4 = 0;
  _DAT_02124ea8 = 0;
  uStack_8._0_1_ = 3;
  DAT_02124eac = (undefined *)FUN_01674e20(1);
  if (DAT_02124eac == (undefined *)0x0) {
    DAT_02124eac = (undefined *)0x0;
  }
  else {
    *DAT_02124eac = 0;
  }
  uStack_8._0_1_ = 4;
  DAT_02124eb0 = (undefined4 *)FUN_01674e20(0xd0);
  if (DAT_02124eb0 == (undefined4 *)0x0) {
    DAT_02124eb0 = (undefined4 *)0x0;
  }
  else {
    *DAT_02124eb0 = uVar1;
    DAT_02124eb0[1] = 0;
    DAT_02124eb0[1] = 0;
  }
  uStack_8._0_1_ = 6;
  FUN_009e5930(&DAT_0211c024,s_nocache_021251c8,s_headers_021251c0);
  uStack_8 = 8;
  FUN_016f3654(FUN_01888280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 742 ; VA 0x004a8680 ; FUN_004a8680 */

/* WARNING: Removing unreachable block (ram,0x004a8834) */
/* WARNING: Removing unreachable block (ram,0x004a87ba) */
/* WARNING: Removing unreachable block (ram,0x004a8814) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a8680(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d78f4;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00888530();
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_009e1b40();
  FUN_009cb820(uVar2,s_PostAsync_021251f8,0,uStack_20,0);
  _DAT_02124eb8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::HttpService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::HttpService::HttpContentType,bool,class_RBX::Reflection::Variant),5>
       ::vftable;
  _DAT_02124ef0 = FUN_009ebc90;
  _DAT_02124ef4 = 0;
  _DAT_02124ef8 = 0;
  _DAT_02124efc = 0;
  uStack_8._0_1_ = 4;
  _DAT_02124f00 = (undefined4 *)FUN_01674e20(4);
  if (_DAT_02124f00 == (undefined4 *)0x0) {
    _DAT_02124f00 = (undefined4 *)0x0;
  }
  else {
    *_DAT_02124f00 = 0;
  }
  uStack_8._0_1_ = 5;
  _DAT_02124f04 = (undefined *)FUN_01674e20(1);
  if (_DAT_02124f04 == (undefined *)0x0) {
    _DAT_02124f04 = (undefined *)0x0;
  }
  else {
    *_DAT_02124f04 = 0;
  }
  uStack_8._0_1_ = 6;
  _DAT_02124f08 = (undefined4 *)FUN_01674e20(0xd0);
  if (_DAT_02124f08 == (undefined4 *)0x0) {
    _DAT_02124f08 = (undefined4 *)0x0;
  }
  else {
    *_DAT_02124f08 = uVar1;
    _DAT_02124f08[1] = 0;
    _DAT_02124f08[1] = 0;
  }
  uStack_8._0_1_ = 8;
  FUN_009e5420(&DAT_0211c024,&DAT_0211cf8c,s_content_type_021251e8,s_compress_021251dc,
               s_headers_021251c0);
  uStack_8 = 10;
  FUN_016f3654(&LAB_01888310);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 743 ; VA 0x004a8860 ; FUN_004a8860 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a8860(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d829c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009ec190();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ModuleScript,bool>::
              GetSetImpl<bool_(__thiscall_RBX::ModuleScript::*)(void)const_,void_(__thiscall_RBX::ModuleScript::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_005d57e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_0063cc10;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,"Confidential",&DAT_018dbc3c,uStack_24,0,0,0x20,6,6,0);
  DAT_01ee5798 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01ee57cc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01ee57bc = _DAT_01ee57bc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01ee5798[2])();
    if (cVar1 != '\0') {
      _DAT_01ee57bc = _DAT_01ee57bc & 0xfffffff3;
    }
  }
  DAT_01ee5798 = RBX::Reflection::PropDescriptor<class_RBX::ModuleScript,bool>::vftable;
  FUN_016f3654(&LAB_01888320);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 744 ; VA 0x004a8990 ; FUN_004a8990 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a8990(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d82cc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009ec190();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ModuleScript,class_RBX::ContentId>::
              GetSetImpl<class_RBX::ContentId_const&_(__thiscall_RBX::LuaSourceContainer::*)(void)const_,void_(__thiscall_RBX::LuaSourceContainer::*)(class_RBX::ContentId_const&)>
              ::vftable;
    puVar3[2] = FUN_00ae4430;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ae67a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,"LinkedSource",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,0);
  DAT_01ee5760 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ContentId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01ee5794 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01ee5784 = _DAT_01ee5784 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01ee5760[2])();
    if (cVar1 != '\0') {
      _DAT_01ee5784 = _DAT_01ee5784 & 0xfffffff3;
    }
  }
  DAT_01ee5760 = RBX::Reflection::PropDescriptor<class_RBX::ModuleScript,class_RBX::ContentId>::
                 vftable;
  FUN_016f3654(&LAB_01888340);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 745 ; VA 0x004a8ac0 ; FUN_004a8ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a8ac0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d82fc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009ec190();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ModuleScript,class_RBX::ProtectedString>::
              GetSetImpl<class_RBX::ProtectedString_(__thiscall_RBX::ModuleScript::*)(void)const_,void_(__thiscall_RBX::ModuleScript::*)(class_RBX::ProtectedString_const&)>
              ::vftable;
    puVar3[2] = FUN_009ed300;
    puVar3[3] = 0;
    puVar3[4] = FUN_009eda70;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00886600();
  FUN_009ca670(uVar2,uVar4,"Source",&DAT_018dbc3c,uStack_24,0,0,0x1f,1,1,0);
  DAT_01ee5728 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ProtectedString>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01ee575c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01ee574c = _DAT_01ee574c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01ee5728[2])();
    if (cVar1 != '\0') {
      _DAT_01ee574c = _DAT_01ee574c & 0xfffffff3;
    }
  }
  DAT_01ee5728 = RBX::Reflection::PropDescriptor<class_RBX::ModuleScript,class_RBX::ProtectedString>
                 ::vftable;
  FUN_016f3654(&LAB_01888360);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 746 ; VA 0x004a8c40 ; FUN_004a8c40 */

void FUN_004a8c40(void)

{
  char ****ppppcVar1;
  char ****ppppcVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  char ***apppcStack_54 [4];
  int iStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af408;
  pvStack_10 = ExceptionList;
  iStack_44 = 0;
  uStack_40 = 0xf;
  apppcStack_54[0] = (char ***)((uint)apppcStack_54[0] & 0xffffff00);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  do {
    FUN_01531f50(apppcStack_54);
    ppppcVar2 = apppcStack_54;
    if (0xf < uStack_40) {
      ppppcVar2 = (char ****)apppcStack_54[0];
    }
    ppppcVar1 = apppcStack_54;
    if (0xf < uStack_40) {
      ppppcVar1 = (char ****)apppcStack_54[0];
    }
    iVar4 = ((int)ppppcVar2 + iStack_44) - (int)ppppcVar1;
    uVar3 = 0;
    iVar6 = 0;
    if ((char ****)((int)ppppcVar2 + iStack_44) < ppppcVar1) {
      iVar4 = 0;
    }
    if (iVar4 != 0) {
      do {
        iVar6 = iVar6 + 1;
        uVar3 = uVar3 ^ *(char *)ppppcVar1 + -0x61c88647 + uVar3 * 0x40 + (uVar3 >> 2);
        ppppcVar1 = (char ****)((int)ppppcVar1 + 1);
      } while (iVar6 != iVar4);
    }
    uStack_28 = uVar3 * 2 + 1;
    uStack_3c = uStack_28;
  } while (uStack_28 == 1);
  uStack_20 = 1;
  uStack_38 = 0;
  uVar3 = uStack_38;
  uStack_34 = 0;
  uStack_38 = 0;
  iStack_24 = 0;
  uStack_14 = 0;
  iStack_18 = 1;
  iStack_2c = 0;
  iStack_1c = 0;
  uVar5 = uStack_38;
  uStack_38 = uVar3;
  do {
    uVar7 = FUN_016f3900(uStack_14,iStack_18,uStack_28,iStack_2c);
    iVar4 = iStack_1c;
    uStack_34 = (undefined4)uVar7;
    uStack_30 = uStack_20;
    iStack_1c = iStack_24;
    uVar8 = FUN_016f39b0(uVar7,uStack_20,iStack_24);
    uVar3 = uStack_14;
    iVar6 = iStack_18;
    uStack_20 = uVar5 - (uint)uVar8;
    iStack_24 = (iVar4 - (int)((ulonglong)uVar8 >> 0x20)) - (uint)(uVar5 < (uint)uVar8);
    uStack_14 = uStack_28;
    iStack_18 = iStack_2c;
    uVar7 = FUN_016f39b0(uStack_34,(int)((ulonglong)uVar7 >> 0x20),uStack_28,iStack_2c);
    uStack_28 = uVar3 - (uint)uVar7;
    iStack_2c = (iVar6 - (int)((ulonglong)uVar7 >> 0x20)) - (uint)(uVar3 < (uint)uVar7);
    uVar5 = uStack_30;
  } while (uStack_28 != 0 || iStack_2c != 0);
  DAT_01ee59f8 = uStack_3c;
  DAT_01ee59fc = uStack_30;
  if (0xf < uStack_40) {
    uVar3 = uStack_40 + 1;
    ppppcVar2 = (char ****)apppcStack_54[0];
    if (0xfff < uVar3) {
      ppppcVar2 = (char ****)apppcStack_54[0][-1];
      uVar3 = uStack_40 + 0x24;
      if ((char *)0x1f < (char *)((int)apppcStack_54[0] + (-4 - (int)ppppcVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppcVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 747 ; VA 0x004a9120 ; FUN_004a9120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a9120(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d88f3;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009ef640();
  FUN_009cb970(uVar1,s_CommitRejectedInfo_0212572c,3,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02125524 = 0x74;
  iStack_8 = 0;
  _DAT_021254f0 =
       RBX::Reflection::
       EventDesc<class_RBX::VersionControlService,void___cdecl(int),class_rbx::remote_signal<void___cdecl(int)>,class_rbx::remote_signal<void___cdecl(int)>_RBX::VersionControlService::*>
       ::vftable;
  FUN_0086e3d0(s_reason_02119920);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02125518 = uStack_1c;
  _DAT_0212551c = uStack_18;
  _DAT_02125520 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_021254f0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::VersionControlService,void___cdecl(int),class_rbx::remote_signal<void___cdecl(int)>,class_rbx::remote_signal<void___cdecl(int)>_RBX::VersionControlService::*>
       ::vftable;
  _DAT_02125528 = 0;
  _DAT_0212552c = 0;
  FUN_016f3654(&LAB_018884a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 748 ; VA 0x004a9280 ; FUN_004a9280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a9280(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8939;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009ef640();
  FUN_009cb970(uVar1,s_LockedScriptBatchCommit_021256f0,3,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021254a4 = 0x9c;
  iStack_8 = 0;
  _DAT_02125470 =
       RBX::Reflection::
       EventDesc<class_RBX::VersionControlService,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::VersionControlService::*>
       ::vftable;
  FUN_0086e3d0(s_scriptGuidTuple_021256cc);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_scriptTextTuple_021256a8);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_commitMessage_02125698);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02125498 = uStack_1c;
  _DAT_0212549c = uStack_18;
  _DAT_021254a0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_02125470 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::VersionControlService,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::VersionControlService::*>
       ::vftable;
  _DAT_021254a8 = 0;
  _DAT_021254ac = 0;
  FUN_016f3654(&LAB_018884b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 749 ; VA 0x004a9430 ; FUN_004a9430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a9430(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009ef640(uVar2,0);
  FUN_009cb970(uVar1,s_RequestAllEditorsSignal_02125770,3,CONCAT44(uVar3,uVar2),0);
  _DAT_021255e4 = 0xa4;
  _DAT_021255b0 =
       RBX::Reflection::
       EventDesc<class_RBX::VersionControlService,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::VersionControlService::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_021255d8 = 0;
  _DAT_021255dc = 0;
  _DAT_021255e0 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_021255b0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::VersionControlService,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::VersionControlService::*>
       ::vftable;
  _DAT_021255e8 = 0;
  _DAT_021255ec = 0;
  FUN_016f3654(&LAB_018884c0);
  ExceptionList = pvStack_10;
  return;
}


