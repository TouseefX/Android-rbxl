/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 19250 ; VA 0x009dc1c0 ; FUN_009dc1c0 */

void FUN_009dc1c0(undefined4 *param_1,undefined4 param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  FUN_00551320();
  iVar3 = FUN_00553830(param_2);
  uVar1 = *(uint *)(iVar3 + 0x24);
  if (0xf < uVar1) {
    iVar2 = *(int *)(iVar3 + 0x10);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(iVar3 + 0x20) = 0;
  *(undefined4 *)(iVar3 + 0x24) = 0xf;
  *(undefined *)(iVar3 + 0x10) = 0;
  FUN_01674ea0(iVar3,0x2c);
  *param_1 = param_2;
  return;
}



/* FUNCTION 19251 ; VA 0x009dc250 ; FUN_009dc250 */

/* WARNING: Removing unreachable block (ram,0x009dc2db) */
/* WARNING: Removing unreachable block (ram,0x009dc2ee) */
/* WARNING: Removing unreachable block (ram,0x009dc2f5) */
/* WARNING: Removing unreachable block (ram,0x009dc2fc) */

undefined __fastcall FUN_009dc250(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d69b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  if (*(int *)(*(int *)(param_1 + 0xc) + 8) == 0) {
    uVar4 = 0;
  }
  else {
    piVar1 = *(int **)(param_1 + 8);
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0xc) + 4);
    for (puVar3 = (undefined4 *)*puVar2; puVar3 != puVar2; puVar3 = (undefined4 *)*puVar3) {
      (**(code **)(*piVar1 + 8))(puVar3 + 2,puVar3 + 9,puVar3[8]);
    }
    FUN_009dc0b0();
    uVar4 = 1;
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 19252 ; VA 0x009dc320 ; FUN_009dc320 */

/* WARNING: Removing unreachable block (ram,0x009dc3b4) */
/* WARNING: Removing unreachable block (ram,0x009dc3c7) */
/* WARNING: Removing unreachable block (ram,0x009dc3ce) */
/* WARNING: Removing unreachable block (ram,0x009dc3d5) */

undefined FUN_009dc320(undefined4 param_1,undefined4 param_2,char param_3)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d69b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uVar1 = param_2;
  uStack_8 = 0;
  cVar2 = FUN_009dc400(param_1,param_2,auStack_14,1);
  if (cVar2 == '\0') {
    cVar2 = FUN_009dc400(param_1,uVar1,&param_2,1);
    if (cVar2 == '\0') {
      uVar3 = 0;
    }
    else if (param_3 == '\0') {
      uVar3 = 1;
    }
    else {
      FUN_009dccd0(param_1,uVar1,param_2);
      uVar3 = 1;
    }
  }
  else {
    uVar3 = 1;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 19253 ; VA 0x009dc400 ; FUN_009dc400 */

undefined4 __thiscall
FUN_009dc400(int param_1,int param_2,undefined4 *param_3,undefined4 *param_4,char param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  
  iVar2 = param_2;
  iVar6 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar4 = FUN_0055c740(iVar6,param_2);
  FUN_009da8d0(&param_2,uVar4,iVar2,-(uint)(iVar6 != 0) & iVar6 + 1U);
  iVar6 = param_2;
  if (param_2 == 0) {
    return 0;
  }
  if (param_5 != '\0') {
    FUN_009dcd40(&param_5,iVar2);
  }
  if (param_3 != (undefined4 *)0x0) {
    iVar2 = *(int *)(iVar6 + 0x20);
    iVar5 = *(int *)(iVar2 + 0x28);
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = *(int *)(iVar2 + 0x28);
    }
    *param_3 = *(undefined4 *)(iVar2 + 0x24);
    piVar3 = (int *)param_3[1];
    param_3[1] = iVar5;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar2 = piVar3[1] + -1;
      piVar3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  if (param_4 != (undefined4 *)0x0) {
    *param_4 = *(undefined4 *)(*(int *)(iVar6 + 0x20) + 0x20);
  }
  return 1;
}



/* FUNCTION 19254 ; VA 0x009dc4d0 ; FUN_009dc4d0 */

void FUN_009dc4d0(void)

{
  int iVar1;
  
  if (DAT_01ee4d2c == 0) {
    iVar1 = FUN_009d9c00();
    DAT_01ee4d2c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19255 ; VA 0x009dc4f0 ; FUN_009dc4f0 */

undefined4 FUN_009dc4f0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d69d8;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined4 *)0x0;
  piStack_14 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_009dc320(param_1,&puStack_18,0);
  piVar3 = piStack_14;
  if (cVar4 == '\0') {
    uVar5 = 0;
  }
  else {
    uVar5 = *puStack_18;
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return uVar5;
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 19256 ; VA 0x009dc5a0 ; FUN_009dc5a0 */

undefined4 __thiscall FUN_009dc5a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6a09;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  uStack_8 = 0;
  if (param_1 == 0) {
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
    param_1 = FUN_005c8ac0();
  }
  if (((param_1 != 0) &&
      (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
      (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
      (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_005c2760(), iVar2 != 0)) {
    FUN_008cc060(param_2);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19257 ; VA 0x009dc670 ; FUN_009dc670 */

bool FUN_009dc670(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba938;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009dc5a0(aiStack_28,param_1);
  uStack_8 = 0;
  iVar1 = FUN_009dc4f0(aiStack_28);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return iVar1 == 1;
}



/* FUNCTION 19258 ; VA 0x009dc700 ; FUN_009dc700 */

/* WARNING: Removing unreachable block (ram,0x009dc793) */
/* WARNING: Removing unreachable block (ram,0x009dc7a6) */
/* WARNING: Removing unreachable block (ram,0x009dc7ad) */
/* WARNING: Removing unreachable block (ram,0x009dc7b4) */

bool __thiscall FUN_009dc700(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009dc4f0(param_2);
  if (iVar2 == 0) {
    FUN_00587410();
    iVar2 = param_1 + 0x71 + (uint)*(byte *)(param_1 + 0x70);
    uVar3 = FUN_0055c740(iVar2,iVar1);
    FUN_00562fc0(&param_2,uVar3,iVar1,-(uint)(iVar2 != 0) & iVar2 + 1U);
    ExceptionList = pvStack_10;
    return param_2 != 0;
  }
  ExceptionList = pvStack_10;
  return true;
}



/* FUNCTION 19259 ; VA 0x009dc7e0 ; FUN_009dc7e0 */

bool __thiscall FUN_009dc7e0(int param_1,int param_2)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  int aiStack_30 [5];
  uint uStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6a28;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009dc5a0(aiStack_30,param_2);
  puStack_18 = (uint *)(param_1 + 0x68);
  uStack_8 = 0;
  cStack_14 = '\0';
  FUN_00587410();
  iVar3 = param_1 + 0x71 + (uint)*(byte *)(param_1 + 0x70);
  uVar1 = FUN_0055c740(iVar3,aiStack_30);
  FUN_00562fc0(&param_2,uVar1,aiStack_30,-(uint)(iVar3 != 0) & iVar3 + 1U);
  bVar4 = param_2 != 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (cStack_14 != '\0') {
    LOCK();
    uVar2 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        uVar1 = FUN_00554e40();
        SetEvent(uVar1);
      }
    }
  }
  if (0xf < uStack_1c) {
    uVar2 = uStack_1c + 1;
    iVar3 = aiStack_30[0];
    if (0xfff < uVar2) {
      iVar3 = *(int *)(aiStack_30[0] + -4);
      uVar2 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  ExceptionList = pvStack_10;
  return bVar4;
}



/* FUNCTION 19260 ; VA 0x009dc8f0 ; FUN_009dc8f0 */

/* WARNING: Removing unreachable block (ram,0x009dc945) */
/* WARNING: Removing unreachable block (ram,0x009dc958) */
/* WARNING: Removing unreachable block (ram,0x009dc95f) */
/* WARNING: Removing unreachable block (ram,0x009dc966) */

void FUN_009dc8f0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_009dc990(param_1,param_2,param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19261 ; VA 0x009dc990 ; FUN_009dc990 */

void __thiscall FUN_009dc990(uint *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  uint uVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  byte *pbVar7;
  int iStack_c;
  uint *puStack_8;
  
  iVar6 = param_1[2] + 0xd + (uint)*(byte *)(param_1[2] + 0xc);
  puStack_8 = param_1;
  uVar3 = FUN_0055c740(iVar6,param_2);
  FUN_009da8d0(&iStack_c,uVar3,param_2,-(uint)(iVar6 != 0) & iVar6 + 1U);
  if (iStack_c != 0) {
    FUN_009dd490(&iStack_c);
  }
  piVar5 = (int *)param_1[3];
  iVar6 = (int)piVar5 + *(byte *)(piVar5 + 3) + 0xd;
  uVar3 = FUN_0055c740(iVar6,param_2);
  FUN_009da8d0(&iStack_c,uVar3,param_2,-(uint)(iVar6 != 0) & iVar6 + 1U);
  if (iStack_c != 0) {
    FUN_009dd490(&iStack_c);
    piVar5 = (int *)puStack_8[3];
  }
  uVar1 = puStack_8[2];
  if (puStack_8[1] == 0) {
    uVar4 = *(int *)(uVar1 + 0x24) + piVar5[9] + param_4;
  }
  else {
    uVar4 = piVar5[2] + 1 + *(int *)(uVar1 + 8);
  }
  if ((*puStack_8 < uVar4) && (*(int *)(uVar1 + 8) != 0)) {
    pbVar7 = (byte *)(uVar1 + 0xc) + *(byte *)(uVar1 + 0xc) + 1;
    iVar6 = *(int *)(*(int *)(uVar1 + 4) + 4) + 8;
    uVar3 = FUN_0055c740(pbVar7,iVar6);
    FUN_009da8d0(&iStack_c,uVar3,iVar6,-(uint)(pbVar7 != (byte *)0x0) & (uint)(pbVar7 + 1));
    puVar2 = puStack_8;
    piVar5 = (int *)puStack_8[3];
    if (iStack_c != 0) {
      FUN_009dd490(&iStack_c);
      piVar5 = (int *)puVar2[3];
    }
  }
  (**(code **)(*piVar5 + 8))(param_2,param_3,param_4);
  return;
}



/* FUNCTION 19262 ; VA 0x009dcac0 ; FUN_009dcac0 */

void __thiscall FUN_009dcac0(int param_1,undefined4 param_2,undefined4 *param_3,int param_4)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined auStack_68 [8];
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int iStack_50;
  uint uStack_4c;
  int iStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  undefined auStack_18 [4];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6a60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_009dcd40(&puStack_14,param_2);
  if (puStack_14 != (undefined4 *)0x0) {
    FUN_009dd490(&puStack_14);
  }
  iStack_28 = param_4;
  iVar2 = param_3[1];
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
    iVar2 = param_3[1];
  }
  uVar3 = *param_3;
  uStack_8 = 0;
  uStack_24 = uVar3;
  iStack_20 = iVar2;
  FUN_0054ef60(param_2);
  _iStack_50 = CONCAT44(uVar3,param_4);
  uStack_24 = 0;
  iStack_20 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar1 = **(int **)(param_1 + 4);
  puStack_14 = *(undefined4 **)(iVar1 + 4);
  iStack_48 = iVar2;
  uVar3 = FUN_009d9d60(iVar1,puStack_14,auStack_68);
  if (*(int *)(param_1 + 8) != 0x5d1745c) {
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puStack_14 = uVar3;
    FUN_009db220();
    uStack_8 = 0xffffffff;
    uVar3 = **(undefined4 **)(param_1 + 4);
    FUN_0054ef60(param_2);
    uStack_60 = uStack_44;
    uStack_44 = uStack_44 & 0xffffff00;
    uStack_5c = uStack_40;
    uStack_58 = uStack_3c;
    uStack_54 = uStack_38;
    uStack_4c = uStack_30;
    uStack_34 = 0;
    uStack_30 = 0xf;
    uStack_8 = 3;
    iStack_48 = uVar3;
    uStack_2c = uVar3;
    FUN_009da730(auStack_18,&uStack_60,&uStack_60);
    if (0xf < uStack_4c) {
      uVar5 = uStack_4c + 1;
      uVar4 = uStack_60;
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(uStack_60 - 4);
        uVar5 = uStack_4c + 0x24;
        if (0x1f < (uStack_60 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
    *(int *)(iStack_1c + 0x24) = *(int *)(iStack_1c + 0x24) + param_4;
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 19263 ; VA 0x009dcc60 ; FUN_009dcc60 */

void __thiscall FUN_009dcc60(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  if (param_4 <= *(uint *)(param_1 + 0x28)) {
    FUN_009dc150(*(uint *)(param_1 + 0x28) - param_4);
    FUN_009dcac0(param_2,param_3,param_4);
  }
  return;
}



/* FUNCTION 19264 ; VA 0x009dcc90 ; FUN_009dcc90 */

void __thiscall FUN_009dcc90(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_009ddc10(-(uint)(*(int *)(param_1 + 0x28) != 0) & *(int *)(param_1 + 0x28) - 1U);
  FUN_009dcac0(param_2,param_3,param_4);
  return;
}



/* FUNCTION 19265 ; VA 0x009dccd0 ; FUN_009dccd0 */

void __thiscall FUN_009dccd0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  (**(code **)(**(int **)(param_1 + 8) + 8))(param_2,param_3,param_4);
  iVar2 = *(int *)(param_1 + 0xc) + 0xd + (uint)*(byte *)(*(int *)(param_1 + 0xc) + 0xc);
  uVar1 = FUN_0055c740(iVar2,param_2);
  FUN_009da8d0(&param_4,uVar1,param_2,-(uint)(iVar2 != 0) & iVar2 + 1U);
  if (param_4 != 0) {
    FUN_009dd490(&param_4);
  }
  return;
}



/* FUNCTION 19266 ; VA 0x009dcd40 ; FUN_009dcd40 */

int * __thiscall FUN_009dcd40(int param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  
  iVar5 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar4 = FUN_0055c740(iVar5,param_3);
  FUN_009da8d0(param_2,uVar4,param_3,-(uint)(iVar5 != 0) & iVar5 + 1U);
  if (*param_2 != 0) {
    piVar1 = *(int **)(*param_2 + 0x20);
    piVar2 = (int *)**(int **)(param_1 + 4);
    if (((piVar1 != *(int **)(param_1 + 4)) && (iVar5 = *piVar1, piVar2 != piVar1)) &&
       (piVar2 != (int *)iVar5)) {
      *(int *)piVar1[1] = iVar5;
      **(int **)(iVar5 + 4) = (int)piVar2;
      *(int **)piVar2[1] = piVar1;
      iVar3 = piVar2[1];
      piVar2[1] = *(undefined4 *)(iVar5 + 4);
      *(int *)(iVar5 + 4) = piVar1[1];
      piVar1[1] = iVar3;
    }
  }
  return param_2;
}



/* FUNCTION 19267 ; VA 0x009dcdd0 ; FUN_009dcdd0 */

int FUN_009dcdd0(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puVar3 = (undefined4 *)*param_1;
  pcVar4 = (code *)*puVar3;
  ExceptionList = &pvStack_10;
  if (param_6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (puVar3[2] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar5 = (*pcVar4)(puVar3[1],puVar3[2],param_2,param_3,param_4,param_5,param_6,puVar3 + 3);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 19268 ; VA 0x009dcf00 ; FUN_009dcf00 */

void FUN_009dcf00(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4a6f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x24);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_009dab90(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar2,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc338c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::CacheableContentProvider>,enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::basic_istream<char,struct_std::char_traits<char>_>_>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),class_boost::_bi::list5<class_boost::_bi::value<class_std::weak_ptr<class_RBX::CacheableContentProvider>_>,struct_boost::arg<1>,struct_boost::arg<2>,struct_boost::arg<3>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 19269 ; VA 0x009dd050 ; FUN_009dd050 */

void __thiscall FUN_009dd050(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  uint *puStack_24;
  char cStack_20;
  uint *puStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac258;
  pvStack_10 = ExceptionList;
  uStack_18 = uStack_18 & 0xffffff00;
  puStack_1c = (uint *)(param_1 + 0x68);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_00676530(&puStack_24,param_2,param_2);
  uStack_8 = 1;
  if ((char)uStack_18 != '\0') {
    LOCK();
    uVar1 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar2 = FUN_00554e40();
        SetEvent(uVar2);
      }
    }
  }
  iVar3 = *(int *)(param_1 + 100);
  uStack_8 = 0xffffffff;
  puStack_24 = (uint *)(iVar3 + 0x10);
  cStack_20 = '\0';
  iStack_14 = iVar3;
  FUN_00587410();
  iVar3 = *(int *)(iVar3 + 8) + 0xd + (uint)*(byte *)(*(int *)(iVar3 + 8) + 0xc);
  uVar2 = FUN_0055c740(iVar3,param_2);
  FUN_009da8d0(&uStack_18,uVar2,param_2,-(uint)(iVar3 != 0) & iVar3 + 1U);
  iVar3 = iStack_14;
  if (uStack_18 != 0) {
    FUN_009dd490(&uStack_18);
  }
  iVar3 = (uint)*(byte *)(*(int *)(iVar3 + 0xc) + 0xc) + *(int *)(iVar3 + 0xc) + 0xd;
  uVar2 = FUN_0055c740(iVar3,param_2);
  FUN_009da8d0(&param_2,uVar2,param_2,-(uint)(iVar3 != 0) & iVar3 + 1U);
  if (param_2 != 0) {
    FUN_009dd490(&param_2);
  }
  uStack_8 = 2;
  if (cStack_20 != '\0') {
    LOCK();
    uVar1 = *puStack_24;
    *puStack_24 = *puStack_24 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_24;
      *puStack_24 = *puStack_24 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar2 = FUN_00554e40();
        SetEvent(uVar2);
      }
    }
  }
  LOCK();
  *(int *)(param_1 + 0x60) = *(int *)(param_1 + 0x60) + -1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19270 ; VA 0x009dd1e0 ; FUN_009dd1e0 */

/* WARNING: Removing unreachable block (ram,0x009dd308) */
/* WARNING: Removing unreachable block (ram,0x009dd31b) */
/* WARNING: Removing unreachable block (ram,0x009dd322) */
/* WARNING: Removing unreachable block (ram,0x009dd329) */

int __thiscall FUN_009dd1e0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6a80;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_00587410();
  uStack_24 = 0;
  piStack_20 = (int *)0x0;
  iStack_18 = *(int *)(param_1 + 0xc);
  uStack_8 = 1;
  iVar6 = iStack_18 + 0xd + (uint)*(byte *)(iStack_18 + 0xc);
  uVar4 = FUN_0055c740(iVar6,param_2);
  iVar6 = FUN_009da8d0(&iStack_14,uVar4,param_2,-(uint)(iVar6 != 0) & iVar6 + 1U);
  if (iStack_14 != 0) {
    FUN_009dcd40(&iStack_14,param_2);
    piVar1 = piStack_20;
    iVar6 = *(int *)(iStack_14 + 0x20);
    piVar5 = *(int **)(iVar6 + 0x28);
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(iVar6 + 0x28);
    }
    uStack_24 = *(undefined4 *)(iVar6 + 0x24);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_20[1] + -1;
      piStack_20[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puVar3 = (undefined4 *)*piStack_20;
        piStack_20 = piVar5;
        (*(code *)*puVar3)();
        LOCK();
        piVar5 = piVar1 + 2;
        iVar6 = *piVar5 + -1;
        *piVar5 = iVar6;
        UNLOCK();
        piVar5 = piStack_20;
        if (iVar6 == 0) {
          (**(code **)(*piVar1 + 4))();
          piVar5 = piStack_20;
        }
      }
    }
    piStack_20 = piVar5;
    iVar6 = FUN_009dccd0(param_2,&uStack_24,*(undefined4 *)(*(int *)(iStack_14 + 0x20) + 0x20));
    piVar5 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar6 = (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 19271 ; VA 0x009dd350 ; FUN_009dd350 */

void __fastcall FUN_009dd350(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  *(int *)(iVar1 + 0x1c) = *(int *)(iVar1 + 0x1c) + 1;
  if (*(uint *)(iVar1 + 0x18) <= *(uint *)(iVar1 + 0x1c)) {
    *(undefined4 *)(iVar1 + 0x1c) = 0;
    FUN_009dc250();
  }
  return;
}



/* FUNCTION 19272 ; VA 0x009dd370 ; FUN_009dd370 */

void FUN_009dd370(undefined4 param_1,int param_2)

{
  FUN_009dde60();
  FUN_008a4210(param_1,param_2);
  FUN_00f45260(param_1,param_2);
  if (param_2 != 0) {
    FUN_009ddcd0();
  }
  return;
}



/* FUNCTION 19273 ; VA 0x009dd3b0 ; FUN_009dd3b0 */

void __thiscall FUN_009dd3b0(int *param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6a90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_009dc4f0(param_2);
  if (iVar3 != 0) {
    LOCK();
    param_1[0x18] = param_1[0x18] + -1;
    UNLOCK();
    ExceptionList = pvStack_10;
    return;
  }
  pcVar2 = *(code **)(*param_1 + 0xa4);
  if (*(int *)(param_2 + 0x1c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x1c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(param_2,*(undefined4 *)(param_2 + 0x18),*(undefined4 *)(param_2 + 0x1c));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19274 ; VA 0x009dd449 ; Catch@009dd449 */

undefined4 Catch_009dd449(void)

{
  undefined4 uVar1;
  int *piVar2;
  int unaff_EBP;
  int *piVar3;
  
  piVar2 = *(int **)(unaff_EBP + -0x14);
  piVar3 = *(int **)(unaff_EBP + 8);
  (**(code **)(*piVar2 + 0xa8))(piVar3);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  if (0xf < (uint)piVar3[5]) {
    piVar3 = (int *)*piVar3;
  }
  piVar2 = (int *)piVar2[10];
  if (0xf < (uint)piVar2[5]) {
    piVar2 = (int *)*piVar2;
  }
  FUN_0086f2f0(3,"%s failed to process %s because %s",piVar2,piVar3,uVar1);
  return 0x9dd3ee;
}



/* FUNCTION 19275 ; VA 0x009dd490 ; FUN_009dd490 */

uint __thiscall FUN_009dd490(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) - *(int *)(*(int *)(*param_2 + 0x20) + 0x20);
  piVar1 = *(int **)(*param_2 + 0x20);
  *(int *)piVar1[1] = *piVar1;
  *(int *)(*piVar1 + 4) = piVar1[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_009db220();
  FUN_01674ea0(piVar1,0x2c);
  param_2 = (int *)*param_2;
  piVar1 = (int *)*param_2;
  uVar6 = (uint)param_2[1] % *(uint *)(param_1 + 0x10);
  piVar2 = *(int **)(*(int *)(param_1 + 0x20) + uVar6 * 4);
  for (piVar8 = (int *)*piVar2; piVar8 != param_2; piVar8 = (int *)*piVar8) {
    piVar2 = piVar8;
  }
  do {
    *piVar2 = *piVar8;
    uVar7 = piVar8[7];
    if (0xf < uVar7) {
      iVar3 = piVar8[2];
      uVar5 = uVar7 + 1;
      iVar4 = iVar3;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar3 + -4);
        uVar5 = uVar7 + 0x24;
        if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    piVar8[6] = 0;
    piVar8[7] = 0xf;
    *(undefined *)(piVar8 + 2) = 0;
    FUN_01674ea0(piVar8,0x24);
    *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
    uVar7 = uVar6;
    if (*piVar2 == 0) {
LAB_009dd571:
      uVar5 = *(uint *)(param_1 + 0x20);
      if (*(int **)(uVar5 + uVar6 * 4) == piVar2) {
        *(undefined4 *)(uVar5 + uVar6 * 4) = 0;
      }
    }
    else {
      uVar7 = *(uint *)(*piVar2 + 4);
      uVar5 = uVar7 / *(uint *)(param_1 + 0x10);
      uVar7 = uVar7 % *(uint *)(param_1 + 0x10);
      if (uVar6 != uVar7) {
        *(int **)(*(int *)(param_1 + 0x20) + uVar7 * 4) = piVar2;
        goto LAB_009dd571;
      }
    }
    piVar8 = (int *)*piVar2;
    uVar6 = uVar7;
    if (piVar8 == piVar1) {
      return uVar5;
    }
  } while( true );
}



/* FUNCTION 19276 ; VA 0x009dd5a0 ; FUN_009dd5a0 */

int * __thiscall
FUN_009dd5a0(int param_1,int *param_2,int *param_3,uint *param_4,int **param_5,int **param_6,
            int *param_7)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uStack_dc;
  undefined *puStack_d8;
  int iStack_d4;
  int *piStack_d0;
  int **ppiStack_cc;
  uint *puStack_c8;
  uint *puStack_c4;
  int **ppiStack_c0;
  int **ppiStack_bc;
  int **ppiStack_b8;
  int **ppiStack_b4;
  undefined4 uStack_a8;
  int *piStack_a4;
  int iStack_a0;
  undefined auStack_9c [24];
  uint auStack_84 [2];
  int *apiStack_7c [6];
  undefined4 uStack_64;
  int *piStack_60;
  int iStack_5c;
  undefined auStack_58 [24];
  int iStack_40;
  int *apiStack_3c [4];
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  uint *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6aeb;
  pvStack_10 = ExceptionList;
  ppiStack_b4 = (int **)param_3;
  ppiStack_b8 = apiStack_3c;
  ppiStack_bc = (int **)0x9dd5d1;
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  FUN_009dc5a0();
  uStack_8 = 0;
  if (iStack_2c == 0) {
    *param_2 = 0;
    *param_7 = 2;
    param_2[1] = 0;
    if (0xf < uStack_28) {
      ppiStack_b4 = (int **)(uStack_28 + 1);
      piVar4 = apiStack_3c[0];
      if (0xfff < ppiStack_b4) {
        piVar4 = (int *)apiStack_3c[0][-1];
        ppiStack_b4 = (int **)(uStack_28 + 0x24);
        if (0x1f < (uint)((int)apiStack_3c[0] + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
          ppiStack_b4 = (int **)&UNK_009ddadf;
          FUN_017167a3();
        }
      }
      ppiStack_bc = (int **)0x9dd62c;
      ppiStack_b8 = (int **)piVar4;
      FUN_01674ea0();
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    puStack_18 = (uint *)(param_1 + 0x68);
    piStack_14 = (int *)((uint)piStack_14 & 0xffffff00);
    ppiStack_b4 = (int **)0x9dd655;
    FUN_00587410();
    iVar5 = param_1 + 0x71 + (uint)*(byte *)(param_1 + 0x70);
    ppiStack_b4 = apiStack_3c;
    ppiStack_bc = (int **)0x9dd668;
    ppiStack_b8 = (int **)iVar5;
    ppiStack_bc = (int **)FUN_0055c740();
    ppiStack_b8 = apiStack_3c;
    ppiStack_b4 = (int **)(-(uint)(iVar5 != 0) & iVar5 + 1U);
    ppiStack_c0 = &param_3;
    puStack_c4 = (uint *)0x9dd686;
    FUN_00562fc0();
    if (param_3 == (int *)0x0) {
      uStack_8._0_1_ = 2;
      if ((char)piStack_14 != '\0') {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 + 0x80000000;
        UNLOCK();
        if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
          LOCK();
          uVar1 = *puStack_18;
          *puStack_18 = *puStack_18 | 0x40000000;
          UNLOCK();
          if ((uVar1 >> 0x1e & 1) == 0) {
            ppiStack_b4 = (int **)0x9dd721;
            ppiStack_b4 = (int **)FUN_00554e40();
            ppiStack_b8 = (int **)0x9dd728;
            SetEvent();
          }
        }
      }
      iVar5 = iStack_24;
      piStack_20 = (int *)0x0;
      piStack_1c = (int *)0x0;
      ppiStack_b8 = &piStack_20;
      ppiStack_b4 = (int **)0x0;
      ppiStack_bc = apiStack_3c;
      uStack_8._0_1_ = 3;
      ppiStack_c0 = (int **)0x9dd74f;
      cVar2 = FUN_009dc320();
      if (cVar2 == '\0') {
        ppiStack_b4 = (int **)iVar5;
        ppiStack_b8 = (int **)0x9dd85c;
        iStack_40 = FUN_005c28f0();
        if (iStack_40 != 0) {
          ppiStack_b4 = (int **)0x14;
          ppiStack_b8 = (int **)0x9dd871;
          param_6 = (int **)FUN_01674e20();
          if (param_6 == (int **)0x0) {
            ppiStack_b8 = (int **)0x0;
          }
          else {
            *param_6 = (int *)0x0;
            param_6[1] = (int *)0x0;
            param_6[2] = (int *)0x0;
            param_6[3] = (int *)0x7f7fffff;
            param_6[4] = (int *)0x0;
            ppiStack_b8 = param_6;
          }
          puStack_18 = (uint *)0x0;
          piStack_14 = (int *)0x0;
          ppiStack_bc = (int **)0x9dd8bb;
          ppiStack_b4 = param_6;
          FUN_009da350();
          piVar4 = piStack_1c;
          piStack_20 = (int *)puStack_18;
          piStack_1c = piStack_14;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar3 = piVar4[1] + -1;
            piVar4[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              ppiStack_b4 = (int **)0x9dd8de;
              (**(code **)*piVar4)();
              LOCK();
              iVar3 = piVar4[2] + -1;
              piVar4[2] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                ppiStack_b4 = (int **)0x9dd8ef;
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          puStack_18 = param_4;
          *piStack_20 = 0;
          iVar3 = DAT_01ee4b18;
          LOCK();
          DAT_01ee4b18 = DAT_01ee4b18 + 1;
          UNLOCK();
          ppiStack_b4 = (int **)0x0;
          piStack_20[3] = (int)param_4;
          ppiStack_b8 = &piStack_20;
          ppiStack_bc = apiStack_3c;
          piStack_20[4] = iVar3;
          ppiStack_c0 = (int **)0x9dd92f;
          FUN_009dc8f0();
          LOCK();
          *(int *)(iVar5 + 0x60) = *(int *)(iVar5 + 0x60) + 1;
          UNLOCK();
          param_6 = (int **)CONCAT31(param_6._1_3_,DAT_01ee4b11);
          piStack_14 = (int *)&puStack_c8;
          param_3 = (int *)CONCAT31(param_3._1_3_,DAT_01ee4b12);
          iStack_24 = CONCAT31(iStack_24._1_3_,DAT_01ee4b13);
          ppiStack_cc = apiStack_3c;
          piStack_d0 = (int *)0x9dd964;
          FUN_0054ef60();
          ppiStack_cc = param_6;
          uStack_8._0_1_ = 5;
          piStack_d0 = param_3;
          iStack_d4 = iStack_24;
          FUN_0068f9a0(&uStack_dc,iVar5);
          uStack_8._0_1_ = 3;
          FUN_009da5a0(&uStack_a8,FUN_009dba60);
          uStack_64 = uStack_a8;
          param_6 = &piStack_60;
          if (iStack_a0 != 0) {
            LOCK();
            *(int *)(iStack_a0 + 8) = *(int *)(iStack_a0 + 8) + 1;
            UNLOCK();
          }
          piStack_60 = piStack_a4;
          iStack_5c = iStack_a0;
          ppiStack_b4 = (int **)auStack_9c;
          uStack_8._0_1_ = 7;
          ppiStack_b8 = (int **)0x9dd9e2;
          FUN_0054ef60();
          auStack_84[0] = 0;
          iStack_d4 = uStack_64;
          param_6 = &piStack_d0;
          if (iStack_5c != 0) {
            LOCK();
            *(int *)(iStack_5c + 8) = *(int *)(iStack_5c + 8) + 1;
            UNLOCK();
          }
          piStack_d0 = piStack_60;
          ppiStack_cc = (int **)iStack_5c;
          puStack_d8 = auStack_58;
          uStack_8._0_1_ = 9;
          uStack_dc = 0x9dda2f;
          FUN_0054ef60();
          uStack_8._0_1_ = 8;
          puStack_d8 = (undefined *)0x9dda3b;
          FUN_009da3e0();
          ppiStack_b4 = (int **)0x9dda43;
          FUN_005d11a0();
          ppiStack_b4 = (int **)0x9dda4e;
          FUN_005d11a0();
          puStack_c4 = auStack_84;
          ppiStack_b4 = (int **)0x1;
          ppiStack_b8 = (int **)0x0;
          ppiStack_bc = (int **)&DAT_01d62f20;
          ppiStack_c0 = param_5;
          uStack_8._0_1_ = 10;
          ppiStack_cc = apiStack_3c;
          puStack_c8 = param_4;
          piStack_d0 = (int *)0x9dda79;
          FUN_008cd330();
          uStack_8._0_1_ = 0xb;
          if (((auStack_84[0] != 0) && ((auStack_84[0] & 1) == 0)) &&
             (*(code **)(auStack_84[0] & 0xfffffffe) != (code *)0x0)) {
            ppiStack_bc = apiStack_7c;
            ppiStack_b4 = (int **)0x2;
            ppiStack_c0 = (int **)0x9dda9a;
            ppiStack_b8 = ppiStack_bc;
            (**(code **)(auStack_84[0] & 0xfffffffe))();
          }
        }
        *param_2 = 0;
        *param_7 = 0;
        param_2[1] = 0;
      }
      else {
        iVar3 = *piStack_20;
        *param_7 = iVar3;
        if (iVar3 == 1) {
          if ((char)param_6 != '\0') {
            ppiStack_b4 = apiStack_3c;
            ppiStack_b8 = (int **)0x9dd77c;
            FUN_009dd1e0();
          }
        }
        else {
          ppiStack_b4 = (int **)iVar5;
          ppiStack_b8 = (int **)0x9dd787;
          iVar3 = FUN_005c28f0();
          iVar5 = DAT_01ee4b18;
          if (iVar3 != 0) {
            if ((float)param_4 < (float)piStack_20[3]) {
              puStack_18 = param_4;
              LOCK();
              DAT_01ee4b18 = DAT_01ee4b18 + 1;
              UNLOCK();
              piStack_20[3] = (int)param_4;
              piStack_20[4] = iVar5;
              ppiStack_b4 = (int **)0x9dd7ce;
              FUN_009db100();
              ppiStack_b4 = apiStack_3c;
              uStack_8._0_1_ = 4;
              ppiStack_b8 = (int **)0x9dd7de;
              FUN_00551230();
              ppiStack_b4 = (int **)0x0;
              ppiStack_b8 = (int **)(piStack_20 + 3);
              ppiStack_bc = (int **)auStack_84;
              ppiStack_c0 = (int **)0x9dd7f2;
              FUN_009dbc60();
              uStack_8._0_1_ = 3;
              ppiStack_b4 = (int **)0x9dd7fe;
              FUN_0056cac0();
            }
            ppiStack_b4 = (int **)param_4;
            if (DAT_01d62f40 == '\0') {
              ppiStack_bc = (int **)0x9dd828;
              ppiStack_b8 = apiStack_3c;
              FUN_008dac50();
            }
            else {
              ppiStack_b8 = param_5;
              ppiStack_c0 = (int **)0x9dd820;
              ppiStack_bc = apiStack_3c;
              FUN_008dab00();
            }
          }
        }
        iVar5 = piStack_20[2];
        *param_2 = 0;
        param_2[1] = 0;
        if (iVar5 != 0) {
          LOCK();
          *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
          UNLOCK();
          iVar5 = piStack_20[2];
        }
        *param_2 = piStack_20[1];
        param_2[1] = iVar5;
      }
      ppiStack_b4 = (int **)0x9ddabe;
      FUN_00550b30();
    }
    else {
      *param_2 = 0;
      *param_7 = 2;
      param_2[1] = 0;
      uStack_8._0_1_ = 1;
      if ((char)piStack_14 != '\0') {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 + 0x80000000;
        UNLOCK();
        if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
          LOCK();
          uVar1 = *puStack_18;
          *puStack_18 = *puStack_18 | 0x40000000;
          UNLOCK();
          if ((uVar1 >> 0x1e & 1) == 0) {
            ppiStack_b4 = (int **)0x9dd6e5;
            ppiStack_b4 = (int **)FUN_00554e40();
            ppiStack_b8 = (int **)0x9dd6ec;
            SetEvent();
          }
        }
      }
    }
    ppiStack_b4 = (int **)0x9ddac6;
    FUN_005507b0();
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19277 ; VA 0x009ddae0 ; FUN_009ddae0 */

/* WARNING: Removing unreachable block (ram,0x009ddbce) */
/* WARNING: Removing unreachable block (ram,0x009ddbe1) */
/* WARNING: Removing unreachable block (ram,0x009ddbe8) */
/* WARNING: Removing unreachable block (ram,0x009ddbef) */

void __thiscall FUN_009ddae0(uint *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179aeb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  *param_1 = param_2;
  uStack_8 = 0;
  (**(code **)(*(int *)param_1[2] + 4))(param_2);
  (**(code **)(*(int *)param_1[3] + 4))(param_2);
  uVar1 = param_1[2];
  if (param_1[1] == 0) {
    uVar2 = *(int *)(param_1[3] + 0x24) + *(int *)(uVar1 + 0x24);
  }
  else {
    uVar2 = *(int *)(param_1[3] + 8) + *(int *)(uVar1 + 8);
  }
  while ((param_2 < uVar2 && (*(int *)(uVar1 + 8) != 0))) {
    iVar5 = *(byte *)(uVar1 + 0xc) + 0xd + uVar1;
    iVar4 = *(int *)(*(int *)(uVar1 + 4) + 4) + 8;
    uVar3 = FUN_0055c740(iVar5,iVar4);
    FUN_009da8d0(&iStack_14,uVar3,iVar4,-(uint)(iVar5 != 0) & iVar5 + 1U);
    if (iStack_14 != 0) {
      FUN_009dd490(&iStack_14);
    }
    uVar1 = param_1[2];
    if (param_1[1] == 0) {
      uVar2 = *(int *)(param_1[3] + 0x24) + *(int *)(uVar1 + 0x24);
    }
    else {
      uVar2 = *(int *)(param_1[3] + 8) + *(int *)(uVar1 + 8);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19278 ; VA 0x009ddc10 ; FUN_009ddc10 */

void __thiscall FUN_009ddc10(int param_1,uint param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iStack_8;
  
  uVar1 = *(uint *)(param_1 + 8);
  iStack_8 = param_1;
  while (param_2 < uVar1) {
    iVar3 = *(int *)(*(int *)(param_1 + 4) + 4) + 8;
    iVar4 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
    uVar2 = FUN_0055c740(iVar4,iVar3);
    FUN_009da8d0(&iStack_8,uVar2,iVar3,-(uint)(iVar4 != 0) & iVar4 + 1U);
    if (iStack_8 != 0) {
      FUN_009dd490(&iStack_8);
    }
    uVar1 = *(uint *)(param_1 + 8);
  }
  return;
}



/* FUNCTION 19279 ; VA 0x009ddc80 ; FUN_009ddc80 */

void __thiscall FUN_009ddc80(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x28) = param_2;
  FUN_009dc150();
  return;
}



/* FUNCTION 19280 ; VA 0x009ddca0 ; FUN_009ddca0 */

void __thiscall FUN_009ddca0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x28) = param_2;
  FUN_009ddc10();
  return;
}



/* FUNCTION 19281 ; VA 0x009ddcc0 ; FUN_009ddcc0 */

void FUN_009ddcc0(void)

{
  FUN_009ddae0();
  return;
}



/* FUNCTION 19282 ; VA 0x009ddcd0 ; FUN_009ddcd0 */

void __fastcall FUN_009ddcd0(int param_1)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  char cVar5;
  undefined4 uVar6;
  code *pcStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  uint *puStack_1c;
  char cStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6b18;
  pvStack_10 = ExceptionList;
  cStack_18 = '\0';
  puStack_1c = (uint *)(param_1 + 0x88);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  *(undefined *)(param_1 + 200) = 0;
  cVar5 = FUN_0168a370();
  if (cVar5 == '\0') {
    pcStack_2c = FUN_009de110;
    uStack_28 = 0;
    iStack_24 = param_1;
    puStack_14 = (undefined4 *)FUN_009da9e0(&pcStack_2c);
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      puStack_14[1] = puStack_14[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 1;
    cVar5 = FUN_0168a8f0();
    if (cVar5 == '\0') {
      uVar6 = FUN_005503c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      FUN_0054e630(uVar6);
    }
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      puStack_14[1] = puStack_14[1] + 1;
      UNLOCK();
    }
    puVar3 = *(undefined4 **)(param_1 + 0xc4);
    *(undefined4 **)(param_1 + 0xc4) = puStack_14;
    if (puVar3 != (undefined4 *)0x0) {
      LOCK();
      iVar4 = puVar3[1] + -1;
      puVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*puVar3)(0);
        uVar6 = GetProcessHeap(0,puVar3);
        HeapFree(uVar6);
      }
    }
    puVar3 = puStack_14;
    puStack_14 = (undefined4 *)0x0;
    if (puVar3 != (undefined4 *)0x0) {
      LOCK();
      iVar4 = puVar3[1] + -1;
      puVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*puVar3)(0);
        uVar6 = GetProcessHeap(0,puVar3);
        HeapFree(uVar6);
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_016899e0();
    puVar3 = puStack_14;
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      piVar1 = puStack_14 + 1;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)*puStack_14)(0);
        uVar6 = GetProcessHeap(0,puVar3);
        HeapFree(uVar6);
      }
    }
  }
  uStack_8 = 4;
  if (cStack_18 != '\0') {
    LOCK();
    uVar2 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        uVar6 = FUN_00554e40();
        SetEvent(uVar6);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19283 ; VA 0x009dde60 ; FUN_009dde60 */

void __fastcall FUN_009dde60(int param_1)

{
  uint uVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  int **ppiVar6;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  uint *puStack_1c;
  char acStack_18 [4];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6b50;
  pvStack_10 = ExceptionList;
  piStack_2c = (int *)0x0;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  piStack_2c = (int *)FUN_00845d90();
  uStack_8 = 0;
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  piStack_24 = (int *)FUN_00575af0();
  uStack_8._0_1_ = 1;
  cVar2 = FUN_0168a370();
  if (cVar2 != '\0') {
    puStack_1c = (uint *)(param_1 + 0x88);
    acStack_18[0] = '\0';
    FUN_00587410();
    uStack_8._0_1_ = 2;
    *(undefined *)(param_1 + 200) = 1;
    FUN_00588350();
    uStack_8._0_1_ = 3;
    if (acStack_18[0] != '\0') {
      LOCK();
      uVar1 = *puStack_1c;
      *puStack_1c = *puStack_1c + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_1c;
        *puStack_1c = *puStack_1c | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar3 = FUN_00554e40();
          SetEvent(uVar3);
        }
      }
    }
    uStack_8._0_1_ = 1;
    piVar4 = (int *)FUN_01689dd0(auStack_14);
    piVar5 = (int *)FUN_01689df0(acStack_18);
    if (*piVar4 == *piVar5) {
      uVar3 = FUN_0056b4a0(0x24,"boost thread: trying joining itself");
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
      FUN_0054e630(uVar3);
    }
    FUN_0168a200();
  }
  puStack_1c = (uint *)(param_1 + 0x88);
  acStack_18[0] = '\0';
  FUN_00587410();
  ppiVar6 = (int **)(param_1 + 0xb0);
  if (ppiVar6 != &piStack_2c) {
    piVar4 = *ppiVar6;
    *ppiVar6 = piStack_2c;
    uVar3 = *(undefined4 *)(param_1 + 0xb4);
    *(undefined4 *)(param_1 + 0xb4) = uStack_28;
    piStack_2c = piVar4;
    uStack_28 = uVar3;
  }
  ppiVar6 = (int **)(param_1 + 0xbc);
  if (ppiVar6 != &piStack_24) {
    piVar4 = *ppiVar6;
    *ppiVar6 = piStack_24;
    uVar3 = *(undefined4 *)(param_1 + 0xc0);
    *(undefined4 *)(param_1 + 0xc0) = uStack_20;
    piStack_24 = piVar4;
    uStack_20 = uVar3;
  }
  uStack_8._0_1_ = 5;
  if (acStack_18[0] != '\0') {
    LOCK();
    uVar1 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        SetEvent(uVar3);
      }
    }
  }
  piVar4 = piStack_24;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00576640(piStack_24[1]);
  piStack_24[1] = (int)piVar4;
  *piStack_24 = (int)piVar4;
  piStack_24[2] = (int)piVar4;
  uStack_20 = 0;
  FUN_01674ea0(piStack_24,0x2c);
  piVar4 = piStack_2c;
  uStack_8 = 7;
  FUN_009dbc10(piStack_2c[1]);
  piStack_2c[1] = (int)piVar4;
  *piStack_2c = (int)piVar4;
  piStack_2c[2] = (int)piVar4;
  uStack_28 = 0;
  FUN_01674ea0(piStack_2c,0x38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19284 ; VA 0x009de0a0 ; FUN_009de0a0 */

int FUN_009de0a0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6b68;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_009dc8f0(param_1,&param_2,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 19285 ; VA 0x009de110 ; FUN_009de110 */

void __fastcall FUN_009de110(int *param_1)

{
  uint uVar1;
  int iVar2;
  undefined3 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int *piVar8;
  uint *puVar9;
  int *piVar10;
  int *piVar11;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 auStack_5c [4];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  uint *puStack_34;
  char cStack_30;
  undefined auStack_2c [4];
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6b98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x10))();
  if (0xf < (uint)puVar5[5]) {
    puVar5 = (undefined4 *)*puVar5;
  }
  FUN_0151a220(puVar5);
  uVar6 = FUN_01675290(param_1[0x2e]);
  uStack_4c = 0;
  uStack_48 = 0xf;
  auStack_5c[0]._0_1_ = 0;
  uStack_44 = 0;
  piStack_40 = (int *)0x0;
  uStack_8._1_3_ = 0;
  uVar3 = uStack_8._1_3_;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_20 = uVar6;
  if (*(char *)(param_1 + 0x32) == '\0') {
    puVar9 = (uint *)(param_1 + 0x22);
    do {
      cStack_30 = '\0';
      puStack_34 = puVar9;
      FUN_00587410();
      piVar8 = piStack_14;
      uStack_8._0_1_ = 2;
      if (*(char *)(param_1 + 0x32) != '\0') {
LAB_009de3ca:
        uStack_8._0_1_ = 3;
        uVar3 = uStack_8._1_3_;
        if (cStack_30 != '\0') {
          LOCK();
          uVar1 = *puStack_34;
          *puStack_34 = *puStack_34 + 0x80000000;
          UNLOCK();
          if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
            LOCK();
            uVar1 = *puStack_34;
            *puStack_34 = *puStack_34 | 0x40000000;
            UNLOCK();
            if ((uVar1 >> 0x1e & 1) == 0) {
              uVar7 = FUN_00554e40();
              SetEvent(uVar7);
              uVar3 = uStack_8._1_3_;
            }
          }
        }
        break;
      }
      cVar4 = '\0';
      do {
        if (piVar8[0x2d] != 0) break;
        uStack_3c = 0xfffffffe;
        uStack_38 = 0x7fffffff;
        piStack_24 = (int *)0xfffffffe;
        FUN_00564d70(&piStack_24,&uStack_3c,0);
        FUN_00560fc0(&puStack_34,0,0,0xffffffff,0xffffffff,1,uStack_68,uStack_64,uStack_60);
        cVar4 = *(char *)(piVar8 + 0x32);
      } while (cVar4 == '\0');
      uVar6 = uStack_20;
      if (cVar4 != '\0') goto LAB_009de3ca;
      piStack_24 = piStack_14 + 0x2c;
      iVar2 = *(int *)*piStack_24;
      puVar5 = (undefined4 *)(iVar2 + 0x18);
      if (auStack_5c != puVar5) {
        if (0xf < *(uint *)(iVar2 + 0x2c)) {
          puVar5 = (undefined4 *)*puVar5;
        }
        FUN_005542c0(puVar5,*(undefined4 *)(iVar2 + 0x28));
      }
      piVar11 = piStack_40;
      piVar8 = *(int **)(iVar2 + 0x34);
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
        piVar8 = *(int **)(iVar2 + 0x34);
      }
      uStack_44 = *(undefined4 *)(iVar2 + 0x30);
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_40[1] + -1;
        piStack_40[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          puVar5 = (undefined4 *)*piStack_40;
          piStack_40 = piVar8;
          (*(code *)*puVar5)();
          LOCK();
          piVar8 = piVar11 + 2;
          iVar2 = *piVar8 + -1;
          *piVar8 = iVar2;
          UNLOCK();
          piVar8 = piStack_40;
          if (iVar2 == 0) {
            (**(code **)(*piVar11 + 4))();
            piVar8 = piStack_40;
          }
        }
      }
      piStack_40 = piVar8;
      uStack_28 = *(undefined4 *)(*(int *)*piStack_24 + 0x10);
      uVar7 = FUN_00553830(*(int *)*piStack_24);
      FUN_0056cac0();
      FUN_01674ea0(uVar7,0x38);
      piVar10 = piStack_14 + 0x2f;
      piVar8 = (int *)*piVar10;
      piVar11 = (int *)piVar8[1];
      piStack_24 = piVar8;
      piStack_1c = piVar10;
      piStack_18 = piVar8;
      if (*(char *)((int)piVar11 + 0xd) == '\0') {
        do {
          cVar4 = FUN_00570370(piVar11 + 4,auStack_5c);
          if (cVar4 == '\0') {
            piVar8 = (int *)*piVar11;
            piStack_18 = piVar11;
          }
          else {
            piVar8 = (int *)piVar11[2];
          }
          piVar11 = piVar8;
        } while (*(char *)((int)piVar8 + 0xd) == '\0');
        piVar8 = (int *)*piVar10;
        uVar6 = uStack_20;
      }
      piStack_24 = piVar8;
      if ((piStack_18 != piVar8) &&
         (cVar4 = FUN_00570370(auStack_5c,piStack_18 + 4), piVar8 = piStack_24, cVar4 == '\0')) {
        piVar8 = piStack_18;
      }
      FUN_009dc1c0(auStack_2c,piVar8);
      uStack_8._0_1_ = 4;
      if (cStack_30 != '\0') {
        LOCK();
        uVar1 = *puStack_34;
        *puStack_34 = *puStack_34 + 0x80000000;
        UNLOCK();
        if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
          LOCK();
          uVar1 = *puStack_34;
          *puStack_34 = *puStack_34 | 0x40000000;
          UNLOCK();
          if ((uVar1 >> 0x1e & 1) == 0) {
            uVar7 = FUN_00554e40();
            SetEvent(uVar7);
          }
        }
      }
      param_1 = piStack_14;
      uStack_8._0_1_ = 1;
      FUN_009dd3b0(auStack_5c,uStack_28);
      puVar9 = (uint *)(param_1 + 0x22);
      uVar3 = uStack_8._1_3_;
    } while (*(char *)(param_1 + 0x32) == '\0');
  }
  uStack_8._1_3_ = uVar3;
  FUN_0056cac0();
  uStack_8 = 5;
  FUN_01675290(uVar6);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19286 ; VA 0x009de430 ; FUN_009de430 */

undefined * FUN_009de430(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6bbc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee4d74 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4f80) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee4f80);
      if (DAT_01ee4f80 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_009d9c00();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"MeshContentProvider",1,uStack_20,0,0,0x11,0,0);
        FUN_016f3654(&LAB_018879e0);
        FUN_016f37bf(&DAT_01ee4f80);
      }
    }
    DAT_01ee4d74 = &DAT_01ee4d78;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee4d74;
}



/* FUNCTION 19287 ; VA 0x009de510 ; FUN_009de510 */

void FUN_009de510(void)

{
  int iVar1;
  
  if (DAT_01ee4f84 == 0) {
    iVar1 = FUN_009de430();
    DAT_01ee4f84 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19288 ; VA 0x009de530 ; FUN_009de530 */

undefined4 * __fastcall FUN_009de530(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6bf6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_009dad40(0,0x6000000,DAT_01f30664);
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::MeshContentProvider,class_RBX::CacheableContentProvider>::
             vftable;
  param_1[0x16] =
       RBX::Described<class_RBX::MeshContentProvider,class_RBX::CacheableContentProvider>::vftable;
  uVar1 = FUN_009de430();
  param_1[3] = uVar1;
  *param_1 = RBX::MeshContentProvider::vftable;
  param_1[0x16] = RBX::MeshContentProvider::vftable;
  param_1[0x33] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_00551260("MeshContentProvider");
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19289 ; VA 0x009de620 ; thunk_FUN_009db2e0 */

void __fastcall thunk_FUN_009db2e0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::CacheableContentProvider::vftable;
  param_1[0x16] = RBX::CacheableContentProvider::vftable;
  FUN_009dde60();
  uStack_8 = 0;
  FUN_016899e0();
  puVar3 = (undefined4 *)param_1[0x31];
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    iVar4 = puVar3[1] + -1;
    puVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*puVar3)(0);
      uVar5 = GetProcessHeap(0,puVar3);
      HeapFree(uVar5);
    }
  }
  iVar4 = param_1[0x2f];
  piVar1 = param_1 + 0x2f;
  uStack_8 = 1;
  FUN_00576640(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar1 + 4) = iVar4;
  *(int *)*piVar1 = iVar4;
  *(int *)(*piVar1 + 8) = iVar4;
  param_1[0x30] = 0;
  FUN_01674ea0(*piVar1,0x2c);
  iVar4 = param_1[0x2c];
  piVar1 = param_1 + 0x2c;
  uStack_8 = 2;
  FUN_009dbc10(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar1 + 4) = iVar4;
  *(int *)*piVar1 = iVar4;
  *(int *)(*piVar1 + 8) = iVar4;
  param_1[0x2d] = 0;
  FUN_01674ea0(*piVar1,0x38);
  iVar4 = param_1[0x2b];
  if ((iVar4 != 0) && (iVar4 != -1)) {
    CloseHandle(iVar4);
  }
  FUN_0056d500();
  LOCK();
  iVar4 = param_1[0x25];
  param_1[0x25] = 0;
  UNLOCK();
  if (iVar4 != 0) {
    CloseHandle(iVar4);
  }
  LOCK();
  iVar4 = param_1[0x23];
  param_1[0x23] = 0;
  UNLOCK();
  if (iVar4 != 0) {
    CloseHandle(iVar4);
  }
  FUN_00612580();
  LOCK();
  iVar4 = param_1[0x1b];
  param_1[0x1b] = 0;
  UNLOCK();
  if (iVar4 != 0) {
    CloseHandle(iVar4);
  }
  iVar4 = param_1[0x19];
  if (iVar4 != 0) {
    LOCK();
    iVar2 = *(int *)(iVar4 + 0x14);
    *(int *)(iVar4 + 0x14) = 0;
    UNLOCK();
    if (iVar2 != 0) {
      CloseHandle(iVar2);
    }
    if (*(undefined4 **)(iVar4 + 0xc) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(iVar4 + 0xc))(1);
    }
    if (*(undefined4 **)(iVar4 + 8) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(iVar4 + 8))(1);
    }
    FUN_01674ea0(iVar4,0x20);
  }
  FUN_00f45160();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19290 ; VA 0x009de625 ; FUN_009de625 */

void FUN_009de625(void)

{
  FUN_009de630();
  return;
}



/* FUNCTION 19291 ; VA 0x009de630 ; FUN_009de630 */

undefined4 * __thiscall FUN_009de630(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::MeshContentProvider::vftable;
  param_1[0x16] = RBX::MeshContentProvider::vftable;
  FUN_016790b0();
  FUN_009db2e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd0);
  }
  return param_1;
}



/* FUNCTION 19292 ; VA 0x009de670 ; FUN_009de670 */

undefined4 __thiscall FUN_009de670(int *param_1,undefined4 *param_2,int param_3,int *param_4)

{
  undefined4 uVar1;
  int *piVar2;
  code *pcVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6c3f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    puVar6 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar6 = (undefined4 *)*param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_0086f2f0(3,"MeshContentProvider failed to process %s because \'could not fetch\'",puVar6);
    FUN_009dd050(param_2);
  }
  else {
    ExceptionList = &pvStack_10;
    piStack_14 = (int *)FUN_01674e20(0x14);
    uStack_8._0_1_ = 1;
    if (piStack_14 == (int *)0x0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_009db080(0,0,0);
    }
    uStack_8._0_1_ = 0;
    puStack_18 = (undefined4 *)0x0;
    piStack_14 = (int *)0x0;
    FUN_009da350(uVar5,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    puVar6 = (undefined4 *)FUN_0114fa10(auStack_20,param_3);
    uVar5 = *puVar6;
    uVar1 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    puStack_18[1] = uVar5;
    piVar2 = (int *)puStack_18[2];
    puStack_18[2] = uVar1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar4 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    piVar2 = piStack_14;
    *puStack_18 = 1;
    pcVar3 = *(code **)(*param_1 + 0xac);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    (*pcVar3)(param_2,puStack_18,piStack_14);
    LOCK();
    param_1[0x18] = param_1[0x18] + -1;
    UNLOCK();
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar4 = param_4[1] + -1;
    param_4[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 19293 ; VA 0x009de840 ; FUN_009de840 */

int * FUN_009de840(int *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_3c [4];
  int iStack_38;
  int iStack_34;
  int iStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6c60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
    puStack_18 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
              ::vftable;
    *(undefined *)(puVar1 + 3) = 0;
    puStack_18 = puVar1;
    uVar2 = FUN_00588320(0xb);
    puVar1[4] = uVar2;
    puVar1[5] = 0;
    puVar1[6] = 0x3f800000;
    puVar1[7] = 0;
    puVar1[8] = 0;
  }
  uStack_8 = 0;
  puStack_24 = puVar1 + 3;
  puStack_20 = puVar1;
  FUN_009de9e0(auStack_3c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_34 == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4 = *(int **)(iStack_28 + iStack_38 * 4);
  }
  puVar5 = puVar1 + 3;
  if (piVar4 != (int *)0x0) {
    iStack_1c = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    do {
      iStack_14 = piVar4[8];
      iVar3 = FUN_005c4c00(piVar4 + 2);
      uVar2 = FUN_0088c8c0();
      *(undefined4 *)(iVar3 + 0x18) = uVar2;
      if ((*(int *)(iStack_1c + 0x34) < DAT_01ea8c18) &&
         (FUN_016f3809(&DAT_01ea8c18), DAT_01ea8c18 == -1)) {
        DAT_01ea8c0c = FUN_005c65e0;
        DAT_01ea8c10 = FUN_005c65e0;
        DAT_01ea8c14 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ea8c18);
      }
      puVar1 = *(undefined4 **)(iVar3 + 0x1c);
      if ((code **)puVar1 == &DAT_01ea8c0c) {
        *(int *)(iVar3 + 0x20) = iStack_14;
      }
      else {
        if (puVar1 != (undefined4 *)0x0) {
          (*(code *)puVar1[2])(iVar3 + 0x20);
        }
        *(int *)(iVar3 + 0x20) = iStack_14;
        *(code ***)(iVar3 + 0x1c) = &DAT_01ea8c0c;
      }
      piVar4 = (int *)*piVar4;
      puVar1 = puStack_18;
      puVar5 = puStack_24;
    } while (piVar4 != (int *)0x0);
  }
  *param_1 = (int)puVar5;
  param_1[1] = (int)puVar1;
  FUN_005d1280();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19294 ; VA 0x009de9e0 ; FUN_009de9e0 */

undefined * __thiscall FUN_009de9e0(int param_1,undefined *param_2)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  uint *puStack_20;
  char cStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6c91;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005693c0(param_1 + 0x10);
  uStack_8 = 1;
  *param_2 = 0;
  uVar4 = FUN_00588320(0xb);
  *(undefined4 *)(param_2 + 4) = uVar4;
  *(undefined4 *)(param_2 + 8) = 0;
  *(undefined4 *)(param_2 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0;
  piVar2 = *(int **)(*(int *)(param_1 + 0xc) + 4);
  piVar6 = (int *)*piVar2;
  if (piVar6 != piVar2) {
    do {
      iVar3 = piVar6[8];
      iVar5 = FUN_00789c40(piVar6 + 2);
      *(int *)(iVar5 + 0x18) = iVar3;
      piVar6 = (int *)*piVar6;
    } while (piVar6 != (int *)*(int *)(*(int *)(param_1 + 0xc) + 4));
  }
  piVar2 = *(int **)(*(int *)(param_1 + 8) + 4);
  piVar6 = (int *)*piVar2;
  if (piVar6 != piVar2) {
    do {
      iVar3 = piVar6[8];
      iVar5 = FUN_00789c40(piVar6 + 2);
      *(int *)(iVar5 + 0x18) = iVar3;
      piVar6 = (int *)*piVar6;
    } while (piVar6 != (int *)*(int *)(*(int *)(param_1 + 8) + 4));
  }
  uStack_8 = 2;
  if (cStack_1c != '\0') {
    LOCK();
    uVar1 = *puStack_20;
    *puStack_20 = *puStack_20 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_20;
      *puStack_20 = *puStack_20 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar4 = FUN_00554e40();
        SetEvent(uVar4);
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19295 ; VA 0x009deb00 ; FUN_009deb00 */

int FUN_009deb00(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6cb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar1 = *(int **)(param_2 + 4);
  if (piVar1 == (int *)0x0) {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_009dc8f0(param_1,&param_2,0);
  }
  else {
    piVar5 = *(int **)(param_2 + 8);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_2 + 8);
    }
    uStack_8 = 1;
    if (DAT_01d71780 == '\0') {
      if (DAT_01d71760 == '\0') {
        cVar2 = FUN_01151c00(piVar1);
        if (cVar2 == '\0') {
          iVar4 = ((piVar1[1] - *piVar1) / 0x28) * 0x28 + ((piVar1[7] - piVar1[6]) / 0xc) * 0xc;
        }
        else {
          iVar4 = piVar1[0x19];
          iVar3 = FUN_01151ea0(piVar1);
          iVar4 = iVar3 * 0x28 + *(int *)(iVar4 + 4) * 0xc;
        }
      }
      else {
        iVar4 = (((piVar1[7] - piVar1[6]) / 0xc) * 3 + ((piVar1[1] - *piVar1) / 0x28) * 10 +
                (piVar1[0x1a] - piVar1[0x19] >> 2)) * 4;
      }
    }
    else if (DAT_01d71760 == '\0') {
      cVar2 = FUN_01151c00();
      if (cVar2 == '\0') {
        iVar4 = FUN_01151e50(piVar1);
      }
      else {
        iVar4 = FUN_01151d60();
      }
    }
    else {
      iVar4 = FUN_01151df0(piVar1);
    }
    iVar4 = FUN_009dc8f0(param_1,&param_2,iVar4);
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar3 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar4 = (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  piVar1 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar5 = param_3 + 1;
    iVar3 = *piVar5;
    iVar4 = *piVar5;
    *piVar5 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar3 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 19296 ; VA 0x009decf0 ; FUN_009decf0 */

undefined * FUN_009decf0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6ccc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee4f90 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee51a0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee51a0);
      if (DAT_01ee51a0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_009d9c00();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"SolidModelContentProvider",1,uStack_20,0,0,0x11,0,0);
        FUN_016f3654(&LAB_018879f0);
        FUN_016f37bf(&DAT_01ee51a0);
      }
    }
    DAT_01ee4f90 = &DAT_01ee4f98;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee4f90;
}



/* FUNCTION 19297 ; VA 0x009dedd0 ; FUN_009dedd0 */

void FUN_009dedd0(void)

{
  int iVar1;
  
  if (DAT_01ee51a4 == 0) {
    iVar1 = FUN_009decf0();
    DAT_01ee51a4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19298 ; VA 0x009dedf0 ; FUN_009dedf0 */

undefined4 * __fastcall FUN_009dedf0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6cf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_009dad40(0,0x6000000,DAT_01ee4f88);
  uStack_8 = 0;
  *param_1 = RBX::
             Described<class_RBX::SolidModelContentProvider,class_RBX::CacheableContentProvider>::
             vftable;
  param_1[0x16] =
       RBX::Described<class_RBX::SolidModelContentProvider,class_RBX::CacheableContentProvider>::
       vftable;
  uVar1 = FUN_009decf0();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::SolidModelContentProvider::vftable;
  param_1[0x16] = RBX::SolidModelContentProvider::vftable;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("SolidModelContentProvider",0x19);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19299 ; VA 0x009deeca ; FUN_009deeca */

void FUN_009deeca(void)

{
  FUN_009deee0();
  return;
}



/* FUNCTION 19300 ; VA 0x009deee0 ; FUN_009deee0 */

undefined4 * __thiscall FUN_009deee0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::SolidModelContentProvider::vftable;
  param_1[0x16] = RBX::SolidModelContentProvider::vftable;
  FUN_009db2e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xcc);
  }
  return param_1;
}



/* FUNCTION 19301 ; VA 0x009def20 ; FUN_009def20 */

undefined4 FUN_009def20(undefined4 *param_1,int param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  code *pcVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  uint uVar9;
  undefined **appuStack_f8 [2];
  undefined8 uStack_f0;
  undefined *apuStack_e8 [2];
  undefined auStack_e0 [76];
  undefined4 uStack_94;
  undefined **ppuStack_90;
  int iStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  int *piStack_38;
  undefined4 *puStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6d84;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  uStack_8 = 0;
  if (param_2 == 0) {
    puVar7 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar7 = (undefined4 *)*param_1;
    }
    ExceptionList = &pvStack_10;
    FUN_0086f2f0(3,"SolidModelContentProvider failed to process %s because \'could not fetch\'",
                 puVar7);
    FUN_009dd050(param_1);
  }
  else {
    ExceptionList = &pvStack_10;
    piStack_14 = (int *)FUN_01674e20(0x14);
    uStack_8._0_1_ = 1;
    if (piStack_14 == (int *)0x0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_009db080(0,0,0);
    }
    uStack_8._0_1_ = 0;
    puStack_34 = (undefined4 *)0x0;
    piStack_30 = (int *)0x0;
    FUN_009da350(uVar5,param_1);
    piStack_2c = (int *)0x0;
    piStack_28 = (int *)0x0;
    iStack_24 = 0;
    appuStack_f8[0] = &PTR_018bf148;
    apuStack_e8[0] = &DAT_018bf150;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    piStack_14 = (int *)0x1;
    ppuStack_90 = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
    uStack_94 = 0x50;
    uStack_f0 = 0;
    FUN_00554f20(auStack_e0,0);
    *(undefined ***)((int)apuStack_e8 + *(int *)(apuStack_e8[0] + 4)) =
         std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    *(int *)((int)apuStack_e8 + *(int *)(apuStack_e8[0] + 4) + -4) =
         *(int *)(apuStack_e8[0] + 4) + -8;
    *(undefined ***)((int)appuStack_f8 + (int)appuStack_f8[0][1]) =
         std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined **)(auStack_e0 + (int)(appuStack_f8[0][1] + -0x1c)) = appuStack_f8[0][1] + -0x20;
    uStack_8 = 9;
    *(undefined ***)((int)appuStack_f8 + (int)appuStack_f8[0][1]) =
         std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)(auStack_e0 + (int)(appuStack_f8[0][1] + -0x1c)) = appuStack_f8[0][1] + -0x68;
    FUN_005657a0(param_2,3);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    FUN_00a204e0(appuStack_f8,&piStack_2c,0,0);
    piStack_14 = piStack_2c;
    if ((int)piStack_28 - (int)piStack_2c >> 3 == 0) {
      puVar7 = param_1;
      if (0xf < (uint)param_1[5]) {
        puVar7 = (undefined4 *)*param_1;
      }
      FUN_0086f2f0(3,"SolidModelContentProvider failed to process %s because \'could not fetch\'",
                   puVar7);
      FUN_009dd050(param_1);
    }
    else {
      if ((*piStack_2c == 0) ||
         (iVar1 = *(int *)(*piStack_2c + 0xc), iVar6 = FUN_00cfe630(),
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        piStack_1c = (int *)0x0;
        puVar7 = &uStack_20;
        iStack_18 = 0;
        piVar8 = (int *)0x21;
      }
      else {
        piStack_3c = (int *)piStack_14[1];
        iStack_18 = *piStack_14;
        if (piStack_3c != (int *)0x0) {
          LOCK();
          piStack_3c[1] = piStack_3c[1] + 1;
          UNLOCK();
          piStack_3c = (int *)piStack_14[1];
        }
        puVar7 = &uStack_40;
        piVar8 = (int *)0x11;
      }
      iStack_48 = iStack_18;
      piVar2 = (int *)puVar7[1];
      *puVar7 = 0;
      puVar7[1] = 0;
      piVar4 = piStack_1c;
      piStack_44 = piVar2;
      if ((((uint)piVar8 & 0x20) != 0) &&
         (piStack_14 = (int *)((uint)piVar8 & 0xffffffdf | 0x40), piVar8 = piStack_14,
         piStack_1c != (int *)0x0)) {
        LOCK();
        iVar1 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar8 = piVar4 + 2;
          iVar1 = *piVar8 + -1;
          *piVar8 = iVar1;
          UNLOCK();
          piVar8 = piStack_14;
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
            piVar8 = piStack_14;
          }
        }
      }
      piVar4 = piStack_3c;
      if ((((uint)piVar8 & 0x10) != 0) && (piStack_3c != (int *)0x0)) {
        LOCK();
        iVar1 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          piVar8 = piVar4 + 2;
          iVar1 = *piVar8 + -1;
          *piVar8 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      uStack_8._0_1_ = 0xb;
      if (iStack_18 != 0) {
        iVar1 = iStack_18 + 0x5c;
        puVar7 = (undefined4 *)FUN_00cfa7a0();
        uVar5 = (**(code **)*puVar7)();
        uStack_20 = 0;
        piStack_1c = (int *)0x0;
        FUN_00727ee0(uVar5,param_1);
        uStack_8._0_1_ = 0xc;
        FUN_00cf9ed0(iVar1);
        piVar8 = piStack_1c;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          piStack_1c[1] = piStack_1c[1] + 1;
          UNLOCK();
          if (piStack_1c != (int *)0x0) {
            LOCK();
            piStack_1c[1] = piStack_1c[1] + 1;
            UNLOCK();
          }
        }
        *(undefined4 *)(iStack_18 + 0x54) = uStack_20;
        piStack_14 = *(int **)(iStack_18 + 0x58);
        *(int **)(iStack_18 + 0x58) = piStack_1c;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_14[1] + -1;
          piStack_14[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            iVar1 = piStack_14[2] + -1;
            piStack_14[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_14 + 4))();
            }
          }
        }
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar1 = piVar8[1] + -1;
          piVar8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar1 = piVar8[2] + -1;
            piVar8[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar2[1] = piVar2[1] + 1;
          UNLOCK();
        }
        puStack_34[1] = iStack_18;
        piVar8 = (int *)puStack_34[2];
        puStack_34[2] = piVar2;
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar1 = piVar8[1] + -1;
          piVar8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar1 = piVar8[2] + -1;
            piVar8[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        FUN_00550b30();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = piVar2[1] + -1;
        piVar2[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar1 = piVar2[2] + -1;
          piVar2[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      puVar7 = puStack_34;
      pcVar3 = *(code **)(*piStack_38 + 0xac);
      if (piStack_30 != (int *)0x0) {
        LOCK();
        piStack_30[1] = piStack_30[1] + 1;
        UNLOCK();
      }
      (*pcVar3)(param_1,puStack_34,piStack_30);
      *puVar7 = 1;
      LOCK();
      piStack_38[0x18] = piStack_38[0x18] + -1;
      UNLOCK();
    }
    FUN_005705c0();
    piVar2 = piStack_28;
    piVar8 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      for (; piVar8 != piVar2; piVar8 = piVar8 + 2) {
        piVar4 = (int *)piVar8[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar1 = piVar4[1] + -1;
          piVar4[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar1 = piVar4[2] + -1;
            piVar4[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
      }
      uVar9 = iStack_24 - (int)piStack_2c & 0xfffffff8;
      piVar8 = piStack_2c;
      if (0xfff < uVar9) {
        piVar8 = (int *)piStack_2c[-1];
        uVar9 = uVar9 + 0x23;
        if (0x1f < (uint)((int)piStack_2c + (-4 - (int)piVar8))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(piVar8,uVar9);
      piStack_2c = (int *)0x0;
      piStack_28 = (int *)0x0;
      iStack_24 = 0;
    }
    piVar8 = piStack_30;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_30[1] + -1;
      piStack_30[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar2 = piVar8 + 2;
        iVar1 = *piVar2 + -1;
        *piVar2 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar8 = param_3 + 2;
      iVar1 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 19302 ; VA 0x009df460 ; FUN_009df460 */

int FUN_009df460(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6da8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar3 = *(int *)(param_2 + 4);
  if (iVar3 == 0) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_009dc8f0(param_1,&param_2,0);
  }
  else {
    piVar5 = *(int **)(param_2 + 8);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_2 + 8);
    }
    piVar4 = *(int **)(iVar3 + 0x58);
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = *(int **)(iVar3 + 0x58);
    }
    iVar3 = *(int *)(iVar3 + 0x54);
    uStack_8 = 2;
    iVar3 = FUN_009dc8f0(param_1,&param_2,
                         (((*(int *)(iVar3 + 0x14) - *(int *)(iVar3 + 0x10)) / 0x54) * 0x15 +
                         (*(int *)(iVar3 + 0x20) - *(int *)(iVar3 + 0x1c) >> 2)) * 4);
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar4 = piVar5 + 1;
      iVar2 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar4 = piVar5 + 2;
        iVar2 = *piVar4;
        iVar3 = *piVar4;
        *piVar4 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  piVar5 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar4 = param_3 + 1;
    iVar2 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar4 = piVar5 + 2;
      iVar2 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19303 ; VA 0x009df5a0 ; FUN_009df5a0 */

undefined * FUN_009df5a0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6dcc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee51b0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee53c0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee53c0);
      if (DAT_01ee53c0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Selection",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01887b30);
        FUN_016f37bf(&DAT_01ee53c0);
      }
    }
    DAT_01ee51b0 = &DAT_01ee51b8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee51b0;
}



/* FUNCTION 19304 ; VA 0x009df680 ; FUN_009df680 */

void FUN_009df680(void)

{
  int iVar1;
  
  if (DAT_01ee53c4 == 0) {
    iVar1 = FUN_009df5a0();
    DAT_01ee53c4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19305 ; VA 0x009df6a0 ; FUN_009df6a0 */

void __thiscall FUN_009df6a0(float *param_1,float *param_2,byte *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  float fVar3;
  uint uVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d6de0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  fVar3 = param_1[1];
  uVar4 = (uint)param_1[6] &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193;
  fVar5 = *(float *)((int)param_1[3] + uVar4 * 8);
  pfStack_1c = param_1;
  if (fVar3 != fVar5) {
    fVar3 = **(float **)((int)param_1[3] + 4 + uVar4 * 8);
    while (fVar3 != fVar5) {
      fVar3 = *(float *)((int)fVar3 + 4);
      if (*(int *)param_3 == *(int *)((int)fVar3 + 8)) {
        ExceptionList = &pvStack_10;
        puStack_14 = &stack0xffffffd0;
        FUN_009dff50(param_4);
        *param_2 = fVar3;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  ExceptionList = &pvStack_10;
  if (fVar3 != fVar5) {
    ExceptionList = &pvStack_10;
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar3;
    **(undefined4 **)((int)fVar3 + 4) = param_4;
    fVar1 = *(float *)((int)fVar3 + 4);
    *(undefined4 *)((int)fVar3 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar4 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar4 * 8) = param_4;
  }
  else if (fVar1 == fVar3) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar4 * 8);
    *(float **)((int)fVar5 + 4 + uVar4 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar4 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar4 * 8) + 4);
    }
  }
  fVar3 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar3 + (double)(&DAT_018c0d90)[-((int)fVar3 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar3 < 0x200) {
      fVar3 = (float)((int)fVar3 << 3);
    }
    else if ((uint)fVar3 < 0x1fffffff) {
      fVar3 = (float)((int)fVar3 * 2);
    }
    FUN_005cb500(fVar3);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar3 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_009df6a0(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar3);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19306 ; VA 0x009df86a ; Catch_All@009df86a */

void Catch_All_009df86a(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_009df8a0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19307 ; VA 0x009df8a0 ; FUN_009df8a0 */

void __thiscall FUN_009df8a0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*(byte *)(param_3 + 2) ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 9))
            * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 10)) * 0x1000193 ^
          (uint)*(byte *)((int)param_3 + 0xb)) * 0x1000193) * 8;
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar4[1] == param_3) {
    if ((int *)*piVar4 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if ((int *)*piVar4 == param_3) {
    *piVar4 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  iVar3 = param_3[3];
  if (iVar3 != 0) {
    piVar4 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_01674ea0(param_3,0x10);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 19308 ; VA 0x009df970 ; FUN_009df970 */

undefined4 * __thiscall
FUN_009df970(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6e3b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_009df5a0();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Selection,void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>_const&),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_00888530();
  param_1[9] = uVar1;
  if (param_1[0x10] == 0) {
    uStack_e8 = FUN_00888530();
    iStack_e4 = 0;
    param_6 = &uStack_e8;
    uStack_8 = 3;
    uVar3 = 2;
  }
  else {
    param_6 = (undefined4 *)FUN_008aa360(param_1[0x10]);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar3 = 1;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088cc80();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,param_6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar3;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if ((uVar3 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19309 ; VA 0x009dfad0 ; FUN_009dfad0 */

undefined4 * __fastcall FUN_009dfad0(undefined4 *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_30 [2];
  undefined *puStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6efc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Selection,class_RBX::ServiceInstance>::vftable;
  uVar4 = FUN_009df5a0();
  param_1[3] = uVar4;
  *param_1 = RBX::Selection::vftable;
  uStack_24 = 0;
  puStack_20 = (undefined4 *)0x0;
  uStack_1c = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  puStack_18 = (undefined4 *)FUN_01674e20(0xc);
  uStack_8._0_1_ = 3;
  if (puStack_18 == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00569460(&uStack_24);
  }
  uStack_8._0_1_ = 2;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  FUN_008aaf20(uVar4,puStack_18);
  FUN_00577ac0();
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  puVar1 = param_1 + 0x1b;
  uStack_8._0_1_ = 6;
  *puVar1 = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  puStack_18 = puVar1;
  uVar4 = FUN_005e9aa0(0,0);
  param_1[0x1c] = uVar4;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  uStack_8._0_1_ = 8;
  *puVar1 = 0x3f800000;
  FUN_005cb500(8);
  puVar1 = puStack_14;
  puStack_14[0x27] = 0;
  puStack_14[0x28] = 0xf;
  *(undefined *)(puStack_14 + 0x23) = 0;
  puStack_14[0x29] = 0;
  puStack_14[0x2a] = 0;
  puStack_14[0x2b] = 0;
  puStack_14[0x2c] = 0;
  uStack_8._0_1_ = 0xe;
  puStack_20 = (undefined4 *)0x0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Selection",9);
  uStack_8._0_1_ = 0xf;
  FUN_008a6520(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    uVar6 = auStack_30[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_30[0] - 4);
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  puStack_28 = &LAB_009e0870;
  uStack_24 = 0;
  puStack_20 = puVar1;
  puVar5 = (undefined4 *)FUN_00836450(&puStack_18,&puStack_28);
  uVar4 = puVar1[0x2c];
  puVar1[0x2c] = *puVar5;
  *puVar5 = uVar4;
  if (puStack_18 != (undefined4 *)0x0) {
    piVar2 = puStack_18 + 1;
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(puStack_18);
    }
  }
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 19310 ; VA 0x009dfd10 ; FUN_009dfd10 */

void __fastcall FUN_009dfd10(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_009dfd70();
  return;
}



/* FUNCTION 19311 ; VA 0x009dfd70 ; FUN_009dfd70 */

void __fastcall FUN_009dfd70(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  
  piVar4 = (int *)*param_1;
  piVar5 = (int *)*piVar4;
  *piVar4 = (int)piVar4;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar4 = (int *)*param_1;
  if (piVar5 != piVar4) {
    do {
      iVar2 = piVar5[3];
      piVar3 = (int *)*piVar5;
      if (iVar2 != 0) {
        piVar4 = (int *)(iVar2 + 4);
        LOCK();
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          FUN_01674ea0(iVar2);
        }
      }
      FUN_01674ea0(piVar5,0x10);
      piVar4 = (int *)*param_1;
      piVar5 = piVar3;
    } while (piVar3 != piVar4);
  }
  FUN_01674ea0(piVar4,0x10);
  return;
}



/* FUNCTION 19312 ; VA 0x009dfde0 ; FUN_009dfde0 */

void __fastcall FUN_009dfde0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_009dfd70();
  return;
}



/* FUNCTION 19313 ; VA 0x009dfdf0 ; FUN_009dfdf0 */

void __fastcall FUN_009dfdf0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  *param_1 = RBX::Selection::vftable;
  iVar3 = param_1[0x2c];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uVar6 = param_1[0x28];
  if (0xf < uVar6) {
    iVar3 = param_1[0x23];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_009dff16;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x27] = 0;
  param_1[0x28] = 0xf;
  *(undefined *)(param_1 + 0x23) = 0;
  FUN_009dfd10();
  iVar3 = param_1[0x18];
  if (iVar3 != 0) {
    uVar6 = param_1[0x1a] - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_009dff16:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    param_1[0x18] = 0;
    param_1[0x19] = 0;
    param_1[0x1a] = 0;
  }
  piVar1 = (int *)param_1[0x17];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0089b230();
  return;
}



/* FUNCTION 19314 ; VA 0x009dff20 ; FUN_009dff20 */

undefined4 __thiscall FUN_009dff20(undefined4 param_1,byte param_2)

{
  FUN_009dfdf0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb4);
  }
  return param_1;
}



/* FUNCTION 19315 ; VA 0x009dff50 ; FUN_009dff50 */

void __thiscall FUN_009dff50(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  iVar3 = param_2[3];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_01674ea0(param_2,0x10);
  return;
}



/* FUNCTION 19316 ; VA 0x009dffa0 ; FUN_009dffa0 */

void __thiscall FUN_009dffa0(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 100);
  if (*(undefined4 **)(param_1 + 0x68) != puVar1) {
    *puVar1 = param_2;
    *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + 4;
    return;
  }
  FUN_006030d0(puVar1,&param_2);
  return;
}



/* FUNCTION 19317 ; VA 0x009dffd0 ; FUN_009dffd0 */

int * __thiscall FUN_009dffd0(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6fd0;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1[0xd] != 0) {
    ExceptionList = &pvStack_10;
    param_1 = (int *)FUN_005c8ac0();
    piVar3 = param_1;
  }
  if (param_2 == (int *)0x0) {
    ExceptionList = pvStack_10;
    return piVar3;
  }
  if (param_1 == (int *)0x0) {
    ExceptionList = pvStack_10;
    return piVar3;
  }
  piVar3 = param_2;
  if (param_2[0xd] != 0) {
    piVar3 = (int *)FUN_005c8ac0();
  }
  if (piVar3 != param_1) {
    ExceptionList = pvStack_10;
    return piVar3;
  }
  FUN_0060dcd0(&iStack_18,param_2);
  uStack_8 = 0;
  piVar4 = (int *)FUN_008a86c0();
  piVar3 = (int *)piVar4[1];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
    piVar3 = (int *)piVar4[1];
  }
  piVar2 = (int *)((int *)*piVar4)[1];
  piVar4 = *(int **)*piVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piVar4 != piVar2) {
    do {
      if (*piVar4 == iStack_18) break;
      piVar4 = piVar4 + 2;
    } while (piVar4 != piVar2);
    piVar5 = piStack_14;
    if (piVar4 != piVar2) goto LAB_009e00c5;
  }
  FUN_005c93e0(&iStack_18);
  FUN_009e0370(iStack_18);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piStack_14[1] = piStack_14[1] + 1;
    UNLOCK();
  }
  piVar4 = (int *)FUN_009e0880(iStack_18,piStack_14);
  piVar5 = piStack_14;
LAB_009e00c5:
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar2 = piVar3 + 1;
    iVar1 = *piVar2;
    piVar4 = (int *)*piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar1 = *piVar2;
      piVar4 = (int *)*piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        piVar4 = (int *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar3 = piVar5 + 1;
    iVar1 = *piVar3;
    piVar4 = (int *)*piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      piVar4 = (int *)(**(code **)*piVar5)();
      LOCK();
      piVar3 = piVar5 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        piVar4 = (int *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 19318 ; VA 0x009e0120 ; FUN_009e0120 */

void FUN_009e0120(int *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = (undefined4 *)((undefined4 *)*param_1)[1];
  for (puVar2 = *(undefined4 **)*param_1; puVar2 != puVar1; puVar2 = puVar2 + 2) {
    FUN_009dffd0(*puVar2);
  }
  return;
}



/* FUNCTION 19319 ; VA 0x009e0150 ; FUN_009e0150 */

void __fastcall FUN_009e0150(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_24 [4];
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d6ff7;
  pvStack_10 = ExceptionList;
  piVar4 = *(int **)(param_1 + 0x58);
  ExceptionList = &pvStack_10;
  if (*piVar4 != piVar4[1]) {
    do {
      iVar1 = piVar4[1];
      piVar4 = *(int **)(iVar1 + -4);
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
        piVar4 = *(int **)(iVar1 + -4);
      }
      puStack_14 = *(undefined4 **)(iVar1 + -8);
      puStack_18 = *(undefined4 **)(param_1 + 0x58);
      iStack_8 = 0;
      if (puStack_18 == (undefined4 *)0x0) {
        puStack_18 = (undefined4 *)FUN_01674e20(0x18);
        if (puStack_18 == (undefined4 *)0x0) {
          *(undefined4 *)(param_1 + 0x58) = 0xc;
          piVar5 = *(int **)(param_1 + 0x5c);
          *(undefined4 *)(param_1 + 0x5c) = 0;
        }
        else {
          puStack_18[1] = 1;
          puStack_18[2] = 1;
          *puStack_18 = std::
                        _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                        ::vftable;
          puStack_18[3] = 0;
          puStack_18[4] = 0;
          puStack_18[5] = 0;
          *(undefined4 **)(param_1 + 0x58) = puStack_18 + 3;
          piVar5 = *(int **)(param_1 + 0x5c);
          *(undefined4 **)(param_1 + 0x5c) = puStack_18;
        }
LAB_009e0261:
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
      }
      else if ((*(int *)(param_1 + 0x5c) != 0) && (1 < *(int *)(*(int *)(param_1 + 0x5c) + 4))) {
        puVar3 = (undefined4 *)FUN_01674e20(0x18);
        iStack_8._0_1_ = 1;
        puStack_20 = puVar3;
        if (puVar3 == (undefined4 *)0x0) {
          puVar3 = (undefined4 *)0x0;
        }
        else {
          puVar3[1] = 1;
          puVar3[2] = 1;
          *puVar3 = std::
                    _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                    ::vftable;
          FUN_00569460(puStack_18);
        }
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        *(undefined4 **)(param_1 + 0x58) = puVar3 + 3;
        piVar5 = *(int **)(param_1 + 0x5c);
        *(undefined4 **)(param_1 + 0x5c) = puVar3;
        goto LAB_009e0261;
      }
      puStack_18 = *(undefined4 **)(param_1 + 0x58);
      piVar5 = *(int **)(puStack_18[1] + -4);
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar1 = piVar5[1] + -1;
        piVar5[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar1 = piVar5[2] + -1;
          piVar5[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      puStack_18[1] = puStack_18[1] + -8;
      puStack_18 = puStack_14;
      FUN_0094f6a0(&uStack_1c,&puStack_18);
      uVar2 = uStack_1c;
      FUN_01679490();
      FUN_009df8a0(auStack_24,uVar2);
      piVar5 = piVar4 + 1;
      if (piVar4 != (int *)0x0) {
        LOCK();
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
      FUN_009e0960(puStack_14,piVar4);
      iStack_8 = 0xffffffff;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = *piVar5;
        *piVar5 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar1 = piVar4[2] + -1;
          piVar4[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = *(int **)(param_1 + 0x58);
    } while (*piVar4 != piVar4[1]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19320 ; VA 0x009e0370 ; FUN_009e0370 */

void __thiscall FUN_009e0370(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar2 = param_2;
  puStack_c = &LAB_017d7031;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  piStack_1c = (int *)(param_2 + 0x48);
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 1;
  puStack_28 = puVar3;
  puStack_18 = (undefined4 *)FUN_01674e20(0x28);
  if (puStack_18 == (undefined4 *)0x0) {
    puStack_18 = (undefined4 *)0x0;
  }
  else {
    *puStack_18 = 0;
    puStack_18[1] = 1;
    puStack_18[2] = FUN_009e0510;
    puStack_18[3] = _guard_check_icall;
    puStack_18[4] = 0;
    puStack_18[5] = piStack_1c;
    puStack_18[6] = &LAB_008af4eb;
    puStack_18[7] = 0;
    puStack_18[8] = param_1;
    puStack_18[9] = iVar2;
  }
  FUN_016797d0(puStack_18);
  if (puStack_18 != (undefined4 *)0x0) {
    LOCK();
    puStack_18[1] = puStack_18[1] + 1;
    UNLOCK();
  }
  uStack_20 = 1;
  iStack_8._0_1_ = 2;
  FUN_01675290(puVar3);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_0094f6a0(&piStack_1c,&param_2);
  piVar5 = piStack_1c;
  if (piStack_1c == *(int **)(param_1 + 0x70)) {
    piStack_1c = &param_2;
    iStack_24 = **(int **)(param_1 + 0x70);
    puStack_28 = *(undefined4 **)(iStack_24 + 4);
    uVar4 = FUN_007086b0(iStack_24,puStack_28,&DAT_018bdeda,&piStack_1c,&uStack_11);
    if (*(int *)(param_1 + 0x74) == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 0x74) = *(int *)(param_1 + 0x74) + 1;
    *(undefined4 *)(iStack_24 + 4) = uVar4;
    *puStack_28 = uVar4;
    FUN_009df6a0(&piStack_2c,**(int **)(param_1 + 0x70) + 8,**(int **)(param_1 + 0x70));
    piVar5 = piStack_2c;
  }
  iVar2 = piVar5[3];
  piVar5[3] = (int)puStack_18;
  if (iVar2 != 0) {
    piVar5 = (int *)(iVar2 + 4);
    LOCK();
    iVar1 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19321 ; VA 0x009e0510 ; FUN_009e0510 */

int FUN_009e0510(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4ed0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)(param_1 + 0x18))(*(undefined4 *)(param_1 + 0x24));
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19322 ; VA 0x009e05a0 ; FUN_009e05a0 */

undefined4 __thiscall FUN_009e05a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbe08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d1050(auStack_18,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  (**(code **)(param_1 + 0x38))(uVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 19323 ; VA 0x009e0640 ; FUN_009e0640 */

undefined4 __thiscall FUN_009e0640(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_34 [4];
  int *piStack_30;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017d7048;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined4 *)FUN_009d1050(auStack_34,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcStack_28 = *(code **)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcStack_28)(*puVar3,puVar3[1]);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[1] + -1;
    piStack_30[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piStack_30 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 19324 ; VA 0x009e0720 ; FUN_009e0720 */

undefined4 __fastcall FUN_009e0720(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  uint uStack_c;
  undefined4 uStack_8;
  
  iVar3 = (*(int **)(param_1 + 0x58))[1];
  uStack_c = 0;
  if (iVar3 - **(int **)(param_1 + 0x58) >> 3 == 0) {
    piStack_10 = (int *)0x0;
    puVar6 = &uStack_14;
    uVar5 = 2;
    uStack_8 = 0;
  }
  else {
    piStack_18 = *(int **)(iVar3 + -4);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
      piStack_18 = *(int **)(iVar3 + -4);
    }
    puVar6 = &uStack_1c;
    uStack_8 = *(undefined4 *)(iVar3 + -8);
    uVar5 = 1;
  }
  piVar4 = (int *)puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar2 = piStack_10;
  if (((uVar5 & 2) != 0) &&
     (uStack_c = uVar5 & 0xfffffffd, uVar5 = uStack_c, piStack_10 != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_10[1] + -1;
    piStack_10[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_10)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      uVar5 = uStack_c;
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
        uVar5 = uStack_c;
      }
    }
  }
  piVar2 = piStack_18;
  if (((uVar5 & 1) != 0) && (piStack_18 != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar2 = piVar4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return uStack_8;
}



/* FUNCTION 19325 ; VA 0x009e0820 ; FUN_009e0820 */

void __thiscall FUN_009e0820(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x34) != 0) {
    param_1 = FUN_005c8ac0();
  }
  if ((param_2 != 0) && (param_1 != 0)) {
    iVar1 = param_2;
    if (*(int *)(param_2 + 0x34) != 0) {
      iVar1 = FUN_005c8ac0();
    }
    if (iVar1 == param_1) {
      return;
    }
  }
  FUN_009e0a80(param_2);
  return;
}



/* FUNCTION 19326 ; VA 0x009e0880 ; FUN_009e0880 */

int __thiscall FUN_009e0880(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_24 [20];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7070;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_008c2680(param_2,param_3,0,0);
  puVar4 = *(undefined4 **)(param_1 + 0x60);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (puVar4 != *(undefined4 **)(param_1 + 100)) {
    do {
      (*(code *)**(undefined4 **)*puVar4)(auStack_24);
      puVar4 = puVar4 + 1;
    } while (puVar4 != *(undefined4 **)(param_1 + 100));
  }
  FUN_005e6780(auStack_24);
  iVar3 = FUN_0056b650();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19327 ; VA 0x009e0960 ; FUN_009e0960 */

int __thiscall FUN_009e0960(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_24 [20];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7070;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_008c2680(0,0,param_2,param_3);
  puVar4 = *(undefined4 **)(param_1 + 0x60);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (puVar4 != *(undefined4 **)(param_1 + 100)) {
    do {
      (*(code *)**(undefined4 **)*puVar4)(auStack_24);
      puVar4 = puVar4 + 1;
    } while (puVar4 != *(undefined4 **)(param_1 + 100));
  }
  FUN_005e6780(auStack_24);
  iVar3 = FUN_0056b650();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 19328 ; VA 0x009e0a40 ; FUN_009e0a40 */

void __thiscall FUN_009e0a40(int param_1,int param_2)

{
  int *piVar1;
  
  for (piVar1 = *(int **)(param_1 + 0x60);
      (piVar1 != *(int **)(param_1 + 100) && (*piVar1 != param_2)); piVar1 = piVar1 + 1) {
  }
  FUN_0170cc70(piVar1,piVar1 + 1,(int)*(int **)(param_1 + 100) - (int)(piVar1 + 1));
  *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + -4;
  return;
}



/* FUNCTION 19329 ; VA 0x009e0a80 ; FUN_009e0a80 */

int FUN_009e0a80(undefined4 param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7090;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  piVar2 = (int *)FUN_008a86c0();
  piVar5 = (int *)piVar2[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)piVar2[1];
  }
  piVar2 = (int *)*piVar2;
  iStack_8 = 0;
  piStack_28 = piVar2;
  piStack_24 = piVar5;
  piStack_20 = piVar2;
  piStack_14 = piVar5;
  piVar3 = (int *)FUN_0060dcd0(&piStack_30,param_1);
  piVar6 = (int *)*piVar2;
  if (piVar6 != (int *)piVar2[1]) {
    do {
      if (*piVar6 == *piVar3) break;
      piVar6 = piVar6 + 2;
    } while (piVar6 != (int *)piVar2[1]);
  }
  piStack_1c = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar4 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (piVar6 != (int *)piStack_20[1]) {
    piVar2 = (int *)piVar6[1];
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
      piVar2 = (int *)piVar6[1];
    }
    piStack_30 = (int *)*piVar6;
    iStack_8._0_1_ = 1;
    piStack_2c = piVar2;
    piStack_1c = piStack_30;
    FUN_008a00a0(&piStack_20,piVar6);
    FUN_0094f6a0(&piStack_20,&param_1);
    piVar5 = piStack_20;
    FUN_01679490();
    FUN_009df8a0(&param_1,piVar5);
    piVar6 = piVar2 + 1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    FUN_009e0960(piStack_1c,piVar2);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    piVar5 = piStack_14;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = *piVar6;
      *piVar6 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        piVar5 = piStack_14;
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
          piVar5 = piStack_14;
        }
      }
    }
  }
  iVar4 = FUN_006eccd0();
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar2 = piVar5 + 1;
    iVar1 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar4 = (**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar4 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 19330 ; VA 0x009e0c40 ; FUN_009e0c40 */

void FUN_009e0c40(int *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = (undefined4 *)((undefined4 *)*param_1)[1];
  for (puVar2 = *(undefined4 **)*param_1; puVar2 != puVar1; puVar2 = puVar2 + 2) {
    FUN_009e0a80(*puVar2);
  }
  return;
}



/* FUNCTION 19331 ; VA 0x009e0c70 ; FUN_009e0c70 */

void FUN_009e0c70(undefined4 param_1)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  FUN_009e1010(param_1,auStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19332 ; VA 0x009e0d10 ; FUN_009e0d10 */

uint __thiscall FUN_009e0d10(int param_1,int *param_2,int *param_3)

{
  uint *puVar1;
  uint uVar2;
  undefined4 uVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined *puStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined auStack_28 [4];
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017d70b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_005542c0(&DAT_018bc9b8,0);
  uVar4 = **(uint **)(param_1 + 0x58);
  if ((uVar4 != (*(uint **)(param_1 + 0x58))[1]) ||
     ((param_2 != (int *)0x0 && (uVar4 = param_2[1] - *param_2, 7 < uVar4)))) {
    FUN_01679490();
    FUN_009e0150();
    if (param_2 != (int *)0x0) {
      piVar5 = (int *)FUN_008a86c0();
      piStack_34 = (int *)piVar5[1];
      if (piStack_34 != (int *)0x0) {
        LOCK();
        piStack_34[1] = piStack_34[1] + 1;
        UNLOCK();
        piStack_34 = (int *)piVar5[1];
      }
      iStack_38 = *piVar5;
      piVar5 = (int *)*param_2;
      iStack_24 = iStack_38;
      piStack_1c = piStack_34;
      if (piVar5 != (int *)param_2[1]) {
        do {
          piVar9 = (int *)piVar5[1];
          if (piVar9 != (int *)0x0) {
            LOCK();
            piVar9[1] = piVar9[1] + 1;
            UNLOCK();
            piVar9 = (int *)piVar5[1];
          }
          iStack_30 = *piVar5;
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          iVar6 = iStack_14;
          piStack_2c = piVar9;
          iStack_18 = iStack_30;
          if (*(int *)(iStack_14 + 0x34) != 0) {
            iVar6 = FUN_005c8ac0();
          }
          iStack_20 = iVar6;
          if ((iStack_18 == 0) || (iVar6 == 0)) {
LAB_009e0fc9:
            param_1 = iStack_14;
            if (piVar9 != (int *)0x0) {
              LOCK();
              iVar6 = piVar9[1] + -1;
              piVar9[1] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)*piVar9)();
                LOCK();
                iVar6 = piVar9[2] + -1;
                piVar9[2] = iVar6;
                UNLOCK();
                param_1 = iStack_14;
                if (iVar6 == 0) {
                  (**(code **)(*piVar9 + 4))();
                  param_1 = iStack_14;
                }
              }
            }
            break;
          }
          iVar6 = iStack_18;
          if (*(int *)(iStack_18 + 0x34) != 0) {
            iVar6 = FUN_005c8ac0();
          }
          if (iVar6 != iStack_20) goto LAB_009e0fc9;
          iStack_20 = iStack_18;
          piVar7 = (int *)FUN_0094f6a0(auStack_28,&iStack_20);
          if (*piVar7 == *(int *)(iStack_14 + 0x70)) {
            piVar7 = *(int **)(iStack_24 + 4);
            if (*(int **)(iStack_24 + 8) == piVar7) {
              FUN_005c1970(piVar7,&iStack_30);
              iStack_18 = iStack_30;
              piVar9 = piStack_2c;
            }
            else {
              *piVar7 = 0;
              piVar7[1] = 0;
              if (piVar9 != (int *)0x0) {
                LOCK();
                piVar9[1] = piVar9[1] + 1;
                UNLOCK();
              }
              *piVar7 = iStack_18;
              piVar7[1] = (int)piVar9;
              *(int *)(iStack_24 + 4) = *(int *)(iStack_24 + 4) + 8;
            }
            FUN_009e0370(iStack_18);
            if (piVar9 != (int *)0x0) {
              LOCK();
              piVar9[1] = piVar9[1] + 1;
              UNLOCK();
            }
            FUN_009e0880(iStack_18,piVar9);
          }
          if (piVar9 != (int *)0x0) {
            LOCK();
            iVar6 = piVar9[1] + -1;
            piVar9[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piVar9)();
              LOCK();
              iVar6 = piVar9[2] + -1;
              piVar9[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piVar9 + 4))();
              }
            }
          }
          piVar5 = piVar5 + 2;
          param_1 = iStack_14;
        } while (piVar5 != (int *)param_2[1]);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar6 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    puStack_40 = &LAB_009e0870;
    uStack_3c = 0;
    iStack_38 = param_1;
    puVar8 = (undefined4 *)FUN_00836450(&iStack_24,&puStack_40);
    uVar3 = *(undefined4 *)(param_1 + 0xb0);
    *(undefined4 *)(param_1 + 0xb0) = *puVar8;
    *puVar8 = uVar3;
    if (iStack_24 != 0) {
      piVar5 = (int *)(iStack_24 + 4);
      LOCK();
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        FUN_01674ea0(iStack_24);
      }
    }
    FUN_006eccd0();
    uVar4 = FUN_006eccd0();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar2 = *puVar1;
    uVar4 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar4 = (**(code **)*param_3)();
      LOCK();
      piVar5 = param_3 + 2;
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        uVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 19333 ; VA 0x009e1010 ; FUN_009e1010 */

int __thiscall FUN_009e1010(int param_1,int param_2,int *param_3)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  int *piStack_40;
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d70fe;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((int *)(param_1 + 0x8c) != param_3) {
    piVar3 = param_3;
    if (0xf < (uint)param_3[5]) {
      piVar3 = (int *)*param_3;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0(piVar3,param_3[4]);
  }
  FUN_0060dcd0(&piStack_40,param_2);
  piVar6 = *(int **)(param_1 + 0x58);
  piVar3 = (int *)(param_1 + 0x58);
  iStack_8 = 0;
  piStack_34 = piVar3;
  if (*piVar6 != piVar6[1]) {
    do {
      iVar5 = piVar6[1];
      piVar6 = *(int **)(iVar5 + -4);
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = *(int **)(iVar5 + -4);
      }
      piStack_18 = *(int **)(iVar5 + -8);
      iStack_8._0_1_ = 1;
      if (piStack_18 == piStack_40) {
        param_3 = (int *)*piVar3;
        if (param_3[1] - *param_3 >> 3 == 1) {
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          piVar3 = piStack_3c;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar5 = piVar6[1] + -1;
            piVar6[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar5 = piVar6[2] + -1;
              piVar6[2] = iVar5;
              UNLOCK();
              piVar3 = piStack_3c;
              if (iVar5 == 0) {
                (**(code **)(*piVar6 + 4))();
                piVar3 = piStack_3c;
              }
            }
          }
          goto LAB_009e14f6;
        }
        if (param_3 == (int *)0x0) {
          puVar4 = (undefined4 *)FUN_01674e20(0x18);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            puVar4[1] = 1;
            puVar4[2] = 1;
            *puVar4 = std::
                      _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                      ::vftable;
            puVar4[3] = 0;
            puVar4[4] = 0;
            puVar4[5] = 0;
          }
          *piVar3 = (int)(puVar4 + 3);
          param_3 = (int *)piVar3[1];
          piVar3[1] = (int)puVar4;
          if (param_3 != (int *)0x0) {
            LOCK();
            iVar5 = param_3[1] + -1;
            param_3[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*param_3)();
LAB_009e119f:
              LOCK();
              iVar5 = param_3[2] + -1;
              param_3[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*param_3 + 4))();
              }
            }
          }
        }
        else if ((piVar3[1] != 0) && (1 < *(int *)(piVar3[1] + 4))) {
          puStack_20 = (undefined4 *)FUN_01674e20(0x18);
          iStack_8._0_1_ = 2;
          if (puStack_20 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            puStack_20[1] = 1;
            puStack_20[2] = 1;
            *puStack_20 = std::
                          _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                          ::vftable;
            FUN_00569460(param_3);
            puVar4 = puStack_20;
          }
          *piVar3 = (int)(puVar4 + 3);
          param_3 = (int *)piVar3[1];
          piVar3[1] = (int)puVar4;
          if (param_3 != (int *)0x0) {
            LOCK();
            iVar5 = param_3[1] + -1;
            param_3[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*param_3)();
              goto LAB_009e119f;
            }
          }
        }
        param_3 = (int *)piVar3[1];
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
          param_3 = (int *)piVar3[1];
        }
        piStack_28 = (int *)*piVar3;
        puVar4 = (undefined4 *)*piStack_28;
        iVar5 = piStack_28[1];
        iStack_1c = puVar4[1];
        if (iStack_1c != 0) {
          LOCK();
          *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
          UNLOCK();
          iStack_1c = puVar4[1];
        }
        *(undefined4 *)(iVar5 + -8) = *puVar4;
        piStack_24 = *(int **)(iVar5 + -4);
        *(int *)(iVar5 + -4) = iStack_1c;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_24[1] + -1;
          piStack_24[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar5 = piStack_24[2] + -1;
            piStack_24[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
        puVar4 = (undefined4 *)*piStack_28;
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[1] = piVar6[1] + 1;
          UNLOCK();
        }
        *puVar4 = piStack_18;
        piStack_28 = (int *)puVar4[1];
        puVar4[1] = piVar6;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_28[1] + -1;
          piStack_28[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            iVar5 = piStack_28[2] + -1;
            piStack_28[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piStack_28 + 4))();
            }
          }
        }
        if (param_3 != (int *)0x0) {
          LOCK();
          iVar5 = param_3[1] + -1;
          param_3[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*param_3)();
            LOCK();
            iVar5 = param_3[2] + -1;
            param_3[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*param_3 + 4))();
            }
          }
        }
      }
      else {
        param_3 = (int *)*piVar3;
        if (param_3 == (int *)0x0) {
          puVar4 = (undefined4 *)FUN_01674e20(0x18);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            puVar4[1] = 1;
            puVar4[2] = 1;
            *puVar4 = std::
                      _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                      ::vftable;
            puVar4[3] = 0;
            puVar4[4] = 0;
            puVar4[5] = 0;
          }
          *piVar3 = (int)(puVar4 + 3);
          param_3 = (int *)piVar3[1];
          piVar3[1] = (int)puVar4;
          if (param_3 != (int *)0x0) {
            LOCK();
            iVar5 = param_3[1] + -1;
            param_3[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*param_3)();
LAB_009e136c:
              LOCK();
              iVar5 = param_3[2] + -1;
              param_3[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*param_3 + 4))();
              }
            }
          }
        }
        else if ((piVar3[1] != 0) && (1 < *(int *)(piVar3[1] + 4))) {
          puStack_2c = (undefined4 *)FUN_01674e20(0x18);
          iStack_8._0_1_ = 3;
          if (puStack_2c == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            puStack_2c[1] = 1;
            puStack_2c[2] = 1;
            *puStack_2c = std::
                          _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                          ::vftable;
            FUN_00569460(param_3);
            puVar4 = puStack_2c;
          }
          iStack_8._0_1_ = 1;
          *piVar3 = (int)(puVar4 + 3);
          param_3 = (int *)piVar3[1];
          piVar3[1] = (int)puVar4;
          if (param_3 != (int *)0x0) {
            LOCK();
            iVar5 = param_3[1] + -1;
            param_3[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*param_3)();
              goto LAB_009e136c;
            }
          }
        }
        param_3 = (int *)*piVar3;
        piVar3 = *(int **)(*(int *)((int)param_3 + 4) + -4);
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar5 = piVar3[1] + -1;
          piVar3[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar5 = piVar3[2] + -1;
            piVar3[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        *(int *)((int)param_3 + 4) = *(int *)((int)param_3 + 4) + -8;
        param_3 = piStack_18;
        FUN_0094f6a0(&uStack_30,&param_3);
        uVar2 = uStack_30;
        FUN_01679490();
        FUN_009df8a0(auStack_38,uVar2);
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[1] = piVar6[1] + 1;
          UNLOCK();
        }
        FUN_009e0960(piStack_18,piVar6);
        piVar3 = piStack_34;
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar5 = piVar6[1] + -1;
        piVar6[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar5 = piVar6[2] + -1;
          piVar6[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      piVar6 = (int *)*piVar3;
      param_1 = iStack_14;
    } while (*piVar6 != piVar6[1]);
  }
  piVar3 = piStack_3c;
  if (piStack_40 != (int *)0x0) {
    if (*(int *)(param_1 + 0x34) != 0) {
      param_1 = FUN_005c8ac0();
    }
    piVar3 = piStack_3c;
    if ((param_2 != 0) && (param_1 != 0)) {
      if (*(int *)(param_2 + 0x34) != 0) {
        param_2 = FUN_005c8ac0();
      }
      piVar3 = piStack_3c;
      if (param_2 == param_1) {
        FUN_008a86c0();
        FUN_005c93e0(&piStack_40);
        FUN_009e0370(piStack_40);
        if (piStack_3c != (int *)0x0) {
          LOCK();
          piStack_3c[1] = piStack_3c[1] + 1;
          UNLOCK();
        }
        FUN_009e0880(piStack_40,piStack_3c);
        piVar3 = piStack_3c;
      }
    }
  }
LAB_009e14f6:
  iVar5 = FUN_006eccd0();
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar6 = piVar3 + 1;
    iVar1 = *piVar6;
    iVar5 = *piVar6;
    *piVar6 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar5 = (**(code **)*piVar3)();
      LOCK();
      piVar6 = piVar3 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 19334 ; VA 0x009e1540 ; FUN_009e1540 */

uint __thiscall FUN_009e1540(int *param_1,int *param_2,int *param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  undefined *puStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  undefined auStack_34 [4];
  undefined auStack_30 [4];
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017d7128;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar4 = *(uint *)param_1[0x16];
  piStack_14 = param_1;
  if ((uVar4 != ((uint *)param_1[0x16])[1]) ||
     ((ExceptionList = &pvStack_10, param_2 != (int *)0x0 &&
      (uVar4 = param_2[1] - *param_2, ExceptionList = &pvStack_10, 7 < uVar4)))) {
    ExceptionList = &pvStack_10;
    FUN_01679490();
    if (param_2 != (int *)0x0) {
      puVar5 = (undefined4 *)FUN_008a86c0();
      piStack_40 = (int *)puVar5[1];
      if (piStack_40 != (int *)0x0) {
        LOCK();
        piStack_40[1] = piStack_40[1] + 1;
        UNLOCK();
        piStack_40 = (int *)puVar5[1];
      }
      piStack_44 = (int *)*puVar5;
      puVar5 = (undefined4 *)*param_2;
      piStack_20 = piStack_40;
      puStack_1c = piStack_44;
      if (puVar5 != (undefined4 *)param_2[1]) {
        do {
          piVar7 = (int *)puVar5[1];
          if (piVar7 != (int *)0x0) {
            LOCK();
            piVar7[1] = piVar7[1] + 1;
            UNLOCK();
            piVar7 = (int *)puVar5[1];
          }
          piStack_3c = (int *)*puVar5;
          piStack_28 = (int *)puStack_1c[1];
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          piVar6 = (int *)*puStack_1c;
          piStack_38 = piVar7;
          piStack_18 = piStack_3c;
          if (piVar6 == piStack_28) {
LAB_009e1625:
            piStack_24 = piStack_14;
            if (piStack_14[0xd] != 0) {
              piStack_24 = piVar7;
              piStack_24 = (int *)FUN_005c8ac0();
            }
            if ((piStack_18 != (int *)0x0) && (piStack_24 != (int *)0x0)) {
              piVar6 = piStack_18;
              if (piStack_18[0xd] != 0) {
                piVar6 = (int *)FUN_005c8ac0();
              }
              if (piVar6 == piStack_24) {
                if ((int *)puStack_1c[2] == piStack_28) {
                  FUN_005c1970(piStack_28,&piStack_3c);
                  piStack_18 = piStack_3c;
                  piVar7 = piStack_38;
                }
                else {
                  *piStack_28 = 0;
                  piStack_28[1] = 0;
                  if (piVar7 != (int *)0x0) {
                    LOCK();
                    piVar7[1] = piVar7[1] + 1;
                    UNLOCK();
                  }
                  *piStack_28 = (int)piStack_18;
                  piStack_28[1] = (int)piVar7;
                  puStack_1c[1] = puStack_1c[1] + 8;
                }
                FUN_009e0370(piStack_18);
                if (piVar7 != (int *)0x0) {
                  LOCK();
                  piVar7[1] = piVar7[1] + 1;
                  UNLOCK();
                }
                FUN_009e0880(piStack_18,piVar7);
              }
            }
          }
          else {
            do {
              if ((int *)*piVar6 == piStack_3c) break;
              piVar6 = piVar6 + 2;
            } while (piVar6 != piStack_28);
            if (piVar6 == piStack_28) goto LAB_009e1625;
            piStack_24 = piVar7;
            FUN_008a00a0(auStack_30,piVar6);
            piStack_28 = piStack_18;
            FUN_0094f6a0(&iStack_2c,&piStack_28);
            iVar3 = iStack_2c;
            FUN_01679490();
            FUN_009df8a0(auStack_34,iVar3);
            piVar7 = piStack_24;
            if (piStack_24 != (int *)0x0) {
              LOCK();
              piStack_24[1] = piStack_24[1] + 1;
              UNLOCK();
            }
            FUN_009e0960(piStack_18,piStack_24);
          }
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar3 = piVar7[1] + -1;
            piVar7[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piVar7)();
              LOCK();
              iVar3 = piVar7[2] + -1;
              piVar7[2] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
          puVar5 = puVar5 + 2;
          param_1 = piStack_14;
        } while (puVar5 != (undefined4 *)param_2[1]);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_20[1] + -1;
        piStack_20[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar3 = piStack_20[2] + -1;
          piStack_20[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
    }
    puStack_4c = &LAB_009e0870;
    uStack_48 = 0;
    piStack_44 = param_1;
    piVar7 = (int *)FUN_00836450(&iStack_2c,&puStack_4c);
    iVar3 = param_1[0x2c];
    param_1[0x2c] = *piVar7;
    *piVar7 = iVar3;
    if (iStack_2c != 0) {
      piVar7 = (int *)(iStack_2c + 4);
      LOCK();
      iVar3 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(iStack_2c);
      }
    }
    uVar4 = FUN_006eccd0();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar2 = *puVar1;
    uVar4 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar4 = (**(code **)*param_3)();
      LOCK();
      piVar7 = param_3 + 2;
      iVar3 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 19335 ; VA 0x009e1850 ; FUN_009e1850 */

undefined4 * __thiscall FUN_009e1850(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193c8fc;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 19336 ; VA 0x009e1980 ; FUN_009e1980 */

undefined4 * __thiscall
FUN_009e1980(undefined4 *param_1,undefined param_2,undefined4 param_3,undefined param_4,int param_5)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000024;
  undefined auStack_8c [4];
  undefined4 uStack_88;
  undefined uStack_84;
  undefined4 uStack_70;
  int iStack_6c;
  int *piStack_68;
  int aiStack_50 [5];
  uint uStack_3c;
  undefined uStack_38;
  undefined4 uStack_34;
  undefined uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7158;
  pvStack_10 = ExceptionList;
  piStack_68 = &param_5;
  uStack_8 = 0;
  iStack_6c = 0x9e19c7;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  uStack_38 = param_2;
  uStack_34 = param_3;
  uStack_30 = param_4;
  piStack_68 = aiStack_50;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_6c = 0x9e19ef;
  FUN_0054ef60();
  piStack_68 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_8c;
  auStack_8c[0] = uStack_38;
  uStack_88 = uStack_34;
  uStack_84 = uStack_30;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_0193c904;
  cVar1 = FUN_009e1e00();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_68 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_68) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_68 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_68 = (int *)0x9e1ada;
        FUN_017167a3();
      }
    }
    uStack_70 = 0x9e1a5e;
    iStack_6c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_3c) {
    piStack_68 = (int *)(uStack_3c + 1);
    iVar2 = aiStack_50[0];
    if (0xfff < piStack_68) {
      iVar2 = *(int *)(aiStack_50[0] + -4);
      piStack_68 = (int *)(uStack_3c + 0x24);
      if (0x1f < (aiStack_50[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_68 = (int *)0x9e1adf;
        FUN_017167a3();
      }
    }
    uStack_70 = 0x9e1a8e;
    iStack_6c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000024) {
    piStack_68 = (int *)(in_stack_00000024 + 1);
    iVar2 = param_5;
    if (0xfff < piStack_68) {
      iVar2 = *(int *)(param_5 + -4);
      piStack_68 = (int *)(in_stack_00000024 + 0x24);
      if (0x1f < (param_5 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_68 = (int *)&UNK_009e1ae4;
        FUN_017167a3();
      }
    }
    uStack_70 = 0x9e1abe;
    iStack_6c = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19337 ; VA 0x009e1af0 ; FUN_009e1af0 */

int * __thiscall FUN_009e1af0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_009eb560();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 19338 ; VA 0x009e1b40 ; FUN_009e1b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009e1b40(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7190;
  pvStack_10 = ExceptionList;
  if (DAT_01ee548c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee56a0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee56a0);
      if (DAT_01ee56a0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"HttpService",1,uStack_20,0,0,0xb,0,0);
        _DAT_01ee5698 = RBX::Creator<class_RBX::HttpService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee5490,&DAT_01ee5698);
        FUN_016f3654(FUN_018881e0);
        FUN_016f37bf(&DAT_01ee56a0);
      }
    }
    DAT_01ee548c = &DAT_01ee5490;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee548c;
}



/* FUNCTION 19339 ; VA 0x009e1c40 ; FUN_009e1c40 */

void FUN_009e1c40(void)

{
  int iVar1;
  
  if (DAT_01ee56a4 == 0) {
    iVar1 = FUN_009e1b40();
    DAT_01ee56a4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19340 ; VA 0x009e1c60 ; FUN_009e1c60 */

undefined4 * FUN_009e1c60(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d71a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x48);
  uStack_8 = 0;
  *puVar4 = std::
            _Func_impl_no_alloc<class_<lambda_06fff998a638d1023b269b0aa641b7a8>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
            ::vftable;
  puVar4[2] = 0;
  uVar1 = *param_1;
  if (uVar1 != 0) {
    puVar4[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,puVar4 + 4,0);
    }
    else {
      uVar1 = param_1[3];
      uVar2 = param_1[4];
      uVar3 = param_1[5];
      puVar4[4] = param_1[2];
      puVar4[5] = uVar1;
      puVar4[6] = uVar2;
      puVar4[7] = uVar3;
      *(undefined8 *)(puVar4 + 8) = *(undefined8 *)(param_1 + 6);
    }
  }
  puVar4[10] = 0;
  uVar1 = param_1[8];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar1 != 0) {
    puVar4[10] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 10,puVar4 + 0xc,0);
      ExceptionList = pvStack_10;
      return puVar4;
    }
    uVar1 = param_1[0xb];
    uVar2 = param_1[0xc];
    uVar3 = param_1[0xd];
    puVar4[0xc] = param_1[10];
    puVar4[0xd] = uVar1;
    puVar4[0xe] = uVar2;
    puVar4[0xf] = uVar3;
    *(undefined8 *)(puVar4 + 0x10) = *(undefined8 *)(param_1 + 0xe);
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 19341 ; VA 0x009e1d47 ; Catch_All@009e1d47 */

void Catch_All_009e1d47(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x48);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19342 ; VA 0x009e1d60 ; FUN_009e1d60 */

undefined4 * FUN_009e1d60(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d71c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x48);
  uStack_8 = 0;
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_06fff998a638d1023b269b0aa641b7a8>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
            ::vftable;
  puVar1[2] = 0;
  FUN_005880d0(param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar1[10] = 0;
  FUN_005880d0(param_1 + 0x20);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 19343 ; VA 0x009e1ddd ; Catch_All@009e1ddd */

void Catch_All_009e1ddd(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x48);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19344 ; VA 0x009e1e00 ; FUN_009e1e00 */

undefined FUN_009e1e00(undefined param_1,undefined4 param_2,undefined param_3,int param_4)

{
  undefined4 uVar1;
  undefined uVar2;
  char cVar3;
  undefined *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined uVar8;
  uint in_stack_00000024;
  int *in_stack_00000028;
  int aiStack_50 [5];
  uint uStack_3c;
  undefined auStack_38 [4];
  undefined4 uStack_34;
  undefined uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7207;
  pvStack_10 = ExceptionList;
  auStack_38[0] = param_1;
  uStack_34 = param_2;
  uStack_30 = param_3;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_4);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_38);
  uVar2 = uStack_30;
  uVar1 = uStack_34;
  uVar8 = auStack_38[0];
  if (cVar3 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    puVar4 = (undefined *)FUN_01674e20(0x24);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar4;
    if (puVar4 == (undefined *)0x0) {
      puVar4 = (undefined *)0x0;
    }
    else {
      *puVar4 = uVar8;
      puVar4[8] = uVar2;
      *(undefined4 *)(puVar4 + 4) = uVar1;
      FUN_0054ef60(aiStack_50);
    }
    *in_stack_00000028 = (int)puVar4;
    if (0xf < uStack_3c) {
      uVar6 = uStack_3c + 1;
      iVar5 = aiStack_50[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_50[0] + -4);
        uVar6 = uStack_3c + 0x24;
        if (0x1f < (aiStack_50[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uVar8 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uVar8 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000024) {
    uVar6 = in_stack_00000024 + 1;
    iVar5 = param_4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_4 + -4);
      uVar6 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 19345 ; VA 0x009e1fd0 ; FUN_009e1fd0 */

void __thiscall FUN_009e1fd0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  undefined uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_3;
  uStack_14 = param_2;
  uStack_c = param_4;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    cStack_5 = uStack_c;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    *(undefined *)(param_1 + 4) = uStack_c;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193c8f4;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 19346 ; VA 0x009e20e0 ; FUN_009e20e0 */

void FUN_009e20e0(int *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iStack_8c;
  int iStack_88;
  char cStack_84;
  int iStack_80;
  char acStack_7c [72];
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7233;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff68;
  iStack_8c = -0x3ea8cf1e;
  iStack_88 = 0x7f0725e3;
  cStack_84 = '\0';
  iStack_80 = 0;
  acStack_7c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_80;
  do {
    iStack_80 = iVar1;
    if (*param_1 == iStack_8c) {
LAB_009e2236:
      if ((iStack_80 != 0) && (iStack_80 != -1)) {
        CloseHandle(iStack_80);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_88;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_80 == 0) {
        if (acStack_7c[0] == '\0') {
          FUN_005881c0(acStack_7c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_7c);
        if ((iStack_80 != 0) && (iStack_80 != -1)) {
          CloseHandle(iStack_80);
        }
        iStack_80 = iVar1;
        if (iVar1 != 0) goto LAB_009e21a4;
      }
      else {
LAB_009e21a4:
        ResetEvent(iStack_80);
      }
      uStack_8._0_1_ = 1;
      uStack_1c = *param_2;
      uStack_18 = param_2[1];
      puVar2 = (undefined4 *)FUN_009ee550(aiStack_34,&uStack_1c);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (0xf < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      FUN_0087c450(&DAT_018c5f98,"HttpService",puVar2,0,0,0);
      if (0xf < uStack_20) {
        uVar3 = uStack_20 + 1;
        iVar1 = aiStack_34[0];
        if (0xfff < uVar3) {
          iVar1 = *(int *)(aiStack_34[0] + -4);
          uVar3 = uStack_20 + 0x24;
          if (0x1f < (aiStack_34[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar1,uVar3);
      }
      FUN_0057b500(param_1,&iStack_8c);
      goto LAB_009e2236;
    }
    if (cStack_84 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_84 = '\x01';
      if (*param_1 == iStack_8c) goto LAB_009e2236;
      if (iStack_80 != 0) goto LAB_009e22b3;
      if (acStack_7c[0] == '\0') {
        FUN_005881c0(acStack_7c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_7c);
      if ((iStack_80 != 0) && (iStack_80 != -1)) {
        CloseHandle(iStack_80);
      }
    }
    else {
LAB_009e22b3:
      WaitForSingleObjectEx(iStack_80,0xffffffff,0);
      iVar1 = iStack_80;
    }
  } while( true );
}



/* FUNCTION 19347 ; VA 0x009e22c8 ; Catch_All@009e22c8 */

void Catch_All_009e22c8(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x88);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 19348 ; VA 0x009e22f0 ; FUN_009e22f0 */

int * __fastcall FUN_009e22f0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_009eb4b0();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_009e238b:
    thunk_FUN_009eb4b0();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_009eb4b0();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_009e238b;
    FUN_009e1af0(&piStack_8);
    iVar3 = FUN_009eb4b0();
    *param_1 = iVar3;
    iVar2 = FUN_009eb4b0();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 19349 ; VA 0x009e23c0 ; thunk_FUN_009eb4b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_009eb4b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8076;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee5714) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee5714);
    if (DAT_01ee5714 == -1) {
      uStack_8 = 0;
      FUN_009ca470("HttpContentType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee56b0 = RBX::Reflection::EnumDesc<enum_RBX::HttpService::HttpContentType>::vftable;
      FUN_009caf20(&DAT_01d65638,5);
      FUN_016f3654(&LAB_018881c0);
      FUN_016f37bf(&DAT_01ee5714);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee56b0;
}



/* FUNCTION 19350 ; VA 0x009e23d0 ; FUN_009e23d0 */

void FUN_009e23d0(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7265;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x74);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<class_RBX::Http>::vftable;
    puVar1[3] = *param_2;
    puVar1[4] = param_2[1];
    puVar1[5] = param_2[2];
    puVar1[6] = param_2[3];
    *(undefined *)(puVar1 + 7) = *(undefined *)(param_2 + 4);
    *(undefined *)((int)puVar1 + 0x1d) = *(undefined *)((int)param_2 + 0x11);
    *(undefined *)((int)puVar1 + 0x1e) = *(undefined *)((int)param_2 + 0x12);
    puVar1[8] = param_2[5];
    FUN_0054ef60(param_2 + 6);
    *(undefined *)(puVar1 + 0xf) = *(undefined *)(param_2 + 0xc);
    uStack_8._0_1_ = 1;
    FUN_0060e660(param_2 + 0xd);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_0054ef60(param_2 + 0x13);
    *(undefined *)(puVar1 + 0x1c) = *(undefined *)(param_2 + 0x19);
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19351 ; VA 0x009e24c0 ; FUN_009e24c0 */

int * FUN_009e24c0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d727f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_01674e20(0x70);
  uStack_8 = 0;
  if (piVar5 == (int *)0x0) {
    piVar5 = (int *)0x0;
  }
  else {
    piVar5[1] = 1;
    piVar5[2] = 1;
    *piVar5 = (int)std::_Ref_count_obj<class_RBX::HttpRequestWrapper>::vftable;
    uVar2 = *param_3;
    uVar3 = param_3[1];
    *param_3 = 0;
    param_3[1] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00e0cf20(*param_2,param_2[1],uVar2,uVar3);
  }
  piVar1 = piVar5 + 3;
  *param_1 = (int)piVar1;
  param_1[1] = (int)piVar5;
  if ((piVar1 != (int *)0x0) && ((piVar5[5] == 0 || (*(int *)(piVar5[5] + 4) == 0)))) {
    piVar6 = piVar5;
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar6 = (int *)param_1[1];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[2] = piVar6[2] + 1;
        UNLOCK();
      }
    }
    piVar5[4] = (int)piVar1;
    piVar1 = (int *)piVar5[5];
    piVar5[5] = (int)piVar6;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar4 = piVar6[1] + -1;
      piVar6[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        piVar5 = piVar6 + 2;
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19352 ; VA 0x009e25f0 ; FUN_009e25f0 */

code * FUN_009e25f0(code *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_1bc;
  undefined4 *puStack_1b8;
  undefined auStack_1b4 [184];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined *puStack_f4;
  undefined4 *puStack_f0;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd61b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_f0 = (undefined4 *)0x9e261c;
  ExceptionList = &pvStack_10;
  uStack_1bc = FUN_008881d0();
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_dc = in_stack_00000024;
  piStack_d8 = in_stack_00000028;
  puStack_f0 = (undefined4 *)0x9e2662;
  puVar5 = (undefined4 *)FUN_0058c000();
  puStack_14 = (undefined *)&uStack_1bc;
  uStack_8._0_1_ = 2;
  puStack_1b8 = (undefined4 *)0x0;
  puVar4 = &uStack_1bc;
  if (puVar5 != (undefined4 *)0x0) {
    (*(code *)*puVar5)(&uStack_dc,auStack_1b4);
    puVar4 = (undefined4 *)puStack_14;
  }
  puStack_14 = (undefined *)puVar4;
  puStack_1b8 = puVar5;
  FUN_008c6ce0();
  uStack_8._0_1_ = 3;
  if (puVar5 != (undefined4 *)0x0) {
    puStack_f0 = &uStack_dc;
    puStack_f4 = (undefined *)0x9e26cd;
    (*(code *)puVar5[2])();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    puStack_f8 = &stack0x0000000c;
    puStack_f0 = (undefined4 *)0x2;
    uStack_fc = 0x9e26f1;
    puStack_f4 = puStack_f8;
    param_1 = (code *)(*param_1)();
  }
  piVar3 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_f0 = (undefined4 *)0x9e2714;
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_f0 = (undefined4 *)0x9e2723;
        param_1 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19353 ; VA 0x009e2740 ; FUN_009e2740 */

uint * __thiscall FUN_009e2740(uint *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b108;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar2 = *param_2;
  if (uVar2 != 0) {
    *param_1 = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar2 = param_2[3];
      uVar3 = param_2[4];
      uVar4 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar2;
      param_1[4] = uVar3;
      param_1[5] = uVar4;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uVar2 = param_2[8];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[8] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
    }
    else {
      uVar2 = param_2[0xb];
      uVar3 = param_2[0xc];
      uVar4 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar2;
      param_1[0xc] = uVar3;
      param_1[0xd] = uVar4;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
    }
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  if (param_2[0x11] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x11] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19354 ; VA 0x009e2820 ; FUN_009e2820 */

undefined4 * __thiscall FUN_009e2820(undefined4 *param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d72a6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  *(undefined *)(param_1 + 4) = *(undefined *)(param_2 + 4);
  *(undefined *)((int)param_1 + 0x11) = *(undefined *)((int)param_2 + 0x11);
  *(undefined *)((int)param_1 + 0x12) = *(undefined *)((int)param_2 + 0x12);
  param_1[5] = param_2[5];
  FUN_0054ef60(param_2 + 6);
  *(undefined *)(param_1 + 0xc) = *(undefined *)(param_2 + 0xc);
  uStack_8 = 0;
  FUN_0060e660(param_2 + 0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2 + 0x13);
  *(undefined *)(param_1 + 0x19) = *(undefined *)(param_2 + 0x19);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19355 ; VA 0x009e28d0 ; FUN_009e28d0 */

undefined4 * __fastcall FUN_009e28d0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d732a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::HttpService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_009e1b40();
  param_1[3] = uVar1;
  *param_1 = RBX::HttpService::vftable;
  uStack_8 = 1;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = &DAT_01d65420;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  FUN_016830f0(param_1 + 0x1c);
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = &DAT_01d65420;
  param_1[0x21] = &DAT_01ee53c8;
  param_1[0x22] = &DAT_01d6542c;
  FUN_016830f0(param_1 + 0x24);
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = &DAT_01d65484;
  param_1[0x29] = &DAT_01ee53d8;
  param_1[0x2a] = &DAT_01d65490;
  FUN_016830f0(param_1 + 0x2c);
  *(undefined8 *)(param_1 + 0x2e) = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  *(undefined2 *)(param_1 + 0x38) = 0;
  *(undefined *)((int)param_1 + 0xe2) = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  *(undefined *)(param_1 + 0x3c) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x3d] = uVar1;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0x3f800000;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0xf;
  *(undefined *)(param_1 + 0x45) = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0xf;
  *(undefined *)(param_1 + 0x4d) = 0;
  param_1[0x53] = 0;
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  uStack_8._0_1_ = 8;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("HttpService",0xb);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19356 ; VA 0x009e2b90 ; FUN_009e2b90 */

code * __fastcall FUN_009e2b90(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x60);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x68,param_1 + 0x68,2);
      }
    }
    *(undefined4 *)(param_1 + 0x60) = 0;
  }
  pcVar6 = *(code **)(param_1 + 0x40);
  uStack_8 = 1;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x48,param_1 + 0x48,2);
      }
    }
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  uVar3 = *(uint *)(param_1 + 0x34);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x20);
    uVar8 = uVar3 + 1;
    iVar7 = iVar4;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar4 + -4);
      uVar8 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar7) - 4U) goto LAB_009e2cc8;
    }
    pcVar6 = (code *)FUN_01674ea0(iVar7,uVar8);
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  uVar3 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 8);
    uVar8 = uVar3 + 1;
    iVar7 = iVar4;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar4 + -4);
      uVar8 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar7) - 4U) {
LAB_009e2cc8:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pcVar6 = (code *)FUN_01674ea0(iVar7,uVar8);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 19357 ; VA 0x009e2cd0 ; FUN_009e2cd0 */

code * __fastcall FUN_009e2cd0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar4 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  pcVar6 = *(code **)(param_1 + 8);
  uStack_8 = 1;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 19358 ; VA 0x009e2d80 ; FUN_009e2d80 */

void __fastcall FUN_009e2d80(uint *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[0x11];
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[8];
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 10,param_1 + 10,2);
      }
    }
    param_1[8] = 0;
  }
  uVar3 = *param_1;
  uStack_8 = 1;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19359 ; VA 0x009e2e30 ; FUN_009e2e30 */

void __fastcall FUN_009e2e30(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x50);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar1 + 4) != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    FUN_01674ea0(iVar1,0xd0);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),1);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  FUN_005c4ac0();
  FUN_005c4ac0();
  FUN_009cb8d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19360 ; VA 0x009e2ed0 ; FUN_009e2ed0 */

void __fastcall FUN_009e2ed0(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x48);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar1 + 4) != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    FUN_01674ea0(iVar1,0xd0);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),1);
  }
  FUN_005c4ac0();
  FUN_009cb8d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19361 ; VA 0x009e2f50 ; FUN_009e2f50 */

void __fastcall FUN_009e2f50(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::HttpService>::vftable;
  uVar1 = FUN_009e1b40(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19362 ; VA 0x009e2f90 ; FUN_009e2f90 */

void __fastcall FUN_009e2f90(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  bool bVar10;
  undefined4 uVar11;
  undefined4 ***apppuStack_90 [5];
  uint uStack_7c;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d73ba;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01679ce0();
  bVar10 = uVar4 == (uVar4 / 100) * 100;
  uStack_11 = !bVar10;
  if (bVar10) {
    uVar5 = FUN_0151b520();
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("PCDesktopClient",0xf);
    uStack_8 = 2;
    uStack_18 = 4;
    uVar5 = FUN_00891760(auStack_60,auStack_30,uVar5);
    uStack_8 = 3;
    uVar4 = 0xc;
  }
  else {
    uVar5 = FUN_0151b520();
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    FUN_005542c0("PCDesktopClient",0xf);
    uStack_8 = 0;
    uStack_18 = 1;
    uVar5 = FUN_00891110(auStack_78,auStack_48,uVar5);
    uStack_8 = 1;
    uVar4 = 3;
  }
  uStack_18 = uVar4;
  FUN_0054ef60(uVar5);
  uStack_8 = 5;
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    if (0xf < uStack_4c) {
      uVar7 = uStack_4c + 1;
      uVar8 = auStack_60[0];
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(auStack_60[0] - 4);
        uVar7 = uStack_4c + 0x24;
        if (0x1f < (auStack_60[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
  }
  uStack_8._0_1_ = 6;
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    if (0xf < uStack_1c) {
      uVar7 = uStack_1c + 1;
      uVar8 = auStack_30[0];
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(auStack_30[0] - 4);
        uVar7 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
  }
  uStack_8._0_1_ = 7;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    if (0xf < uStack_64) {
      uVar7 = uStack_64 + 1;
      uVar8 = auStack_78[0];
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(auStack_78[0] - 4);
        uVar7 = uStack_64 + 0x24;
        if (0x1f < (auStack_78[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
    uStack_68 = 0;
    uStack_64 = 0xf;
    auStack_78[0] = auStack_78[0] & 0xffffff00;
  }
  uStack_8._0_1_ = 8;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if ((uVar4 & 1) != 0) {
    if (0xf < uStack_34) {
      uVar8 = uStack_34 + 1;
      uVar4 = auStack_48[0];
      if (0xfff < uVar8) {
        uVar4 = *(uint *)(auStack_48[0] - 4);
        uVar8 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar4) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar8);
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
  }
  ppppuVar6 = apppuStack_90;
  if (0xf < uStack_7c) {
    ppppuVar6 = (undefined4 ****)apppuStack_90[0];
  }
  FUN_014cc0c0(ppppuVar6,0,0);
  piVar9 = (int *)param_1[1];
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[2] = piVar9[2] + 1;
    UNLOCK();
    piVar9 = (int *)param_1[1];
  }
  uVar5 = *param_1;
  piVar1 = piVar9 + 2;
  if (piVar9 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar11 = 0;
  if (piVar9 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_009e1fd0(uVar5,piVar9,uStack_11);
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piVar9 + 4))(uVar11);
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*piVar9 + 4))();
    }
  }
  FUN_014cdd60(&DAT_01d655d8,0,&DAT_01d65620,0,uVar11);
  FUN_0056db40();
  if (0xf < uStack_7c) {
    uVar4 = uStack_7c + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_90[0];
    if (0xfff < uVar4) {
      ppppuVar6 = (undefined4 ****)apppuStack_90[0][-1];
      uVar4 = uStack_7c + 0x24;
      if (0x1f < (uint)((int)apppuStack_90[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19363 ; VA 0x009e3300 ; FUN_009e3300 */

void __fastcall FUN_009e3300(int *param_1)

{
  uint uVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined **ppuVar5;
  undefined4 auStack_1fc [8];
  undefined4 uStack_1dc;
  undefined auStack_1d0 [72];
  undefined auStack_188 [72];
  undefined auStack_140 [72];
  undefined auStack_f8 [72];
  undefined auStack_b0 [72];
  uint auStack_68 [2];
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  undefined8 uStack_50;
  uint uStack_48;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  undefined8 uStack_30;
  int iStack_28;
  int iStack_24;
  uint *puStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7426;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    uStack_1c = CONCAT31((int3)((uint)ExceptionList >> 8),*(undefined *)(param_1 + 0xe));
    uVar1 = param_1[0x10];
    uStack_1dc = 1;
    puStack_18 = auStack_1fc;
    puStack_20 = auStack_68;
    auStack_68[0] = 0;
    ExceptionList = &pvStack_10;
    puVar2 = auStack_1fc;
    if (uVar1 != 0) {
      auStack_68[0] = uVar1;
      if ((uVar1 & 1) == 0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x12,&iStack_60,0);
        puVar2 = puStack_18;
      }
      else {
        iStack_60 = param_1[0x12];
        iStack_5c = param_1[0x13];
        iStack_58 = param_1[0x14];
        iStack_54 = param_1[0x15];
        uStack_50 = *(undefined8 *)(param_1 + 0x16);
        ExceptionList = &pvStack_10;
        puVar2 = auStack_1fc;
      }
    }
    puStack_18 = puVar2;
    uVar1 = param_1[0x18];
    uStack_8 = 0;
    uStack_48 = 0;
    if (uVar1 != 0) {
      uStack_48 = uVar1;
      if ((uVar1 & 1) == 0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x1a,&iStack_40,0);
      }
      else {
        iStack_40 = param_1[0x1a];
        iStack_3c = param_1[0x1b];
        iStack_38 = param_1[0x1c];
        iStack_34 = param_1[0x1d];
        uStack_30 = *(undefined8 *)(param_1 + 0x1e);
      }
    }
    iStack_24 = param_1[1];
    if (iStack_24 != 0) {
      LOCK();
      *(int *)(iStack_24 + 4) = *(int *)(iStack_24 + 4) + 1;
      UNLOCK();
      iStack_24 = param_1[1];
    }
    iStack_28 = *param_1;
    uStack_8 = 1;
    FUN_009e2740(auStack_68);
    uStack_8._0_1_ = 2;
    *puStack_18 = 0;
    FUN_009e2740(auStack_1d0);
    uStack_8._0_1_ = 3;
    FUN_009e2740(auStack_188);
    uStack_8._0_1_ = 4;
    FUN_009e2740(auStack_140);
    uStack_8._0_1_ = 5;
    cVar3 = FUN_00585a40(auStack_b0);
    if (cVar3 == '\0') {
      FUN_009e2740(auStack_b0);
      uStack_8._0_1_ = 6;
      puStack_20 = (uint *)FUN_01674e20(0x48);
      uStack_8._0_1_ = 7;
      if (puStack_20 == (uint *)0x0) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_009e2740(auStack_f8);
      }
      puStack_18[2] = uVar4;
      FUN_009e2d80();
      FUN_009e2d80();
      cStack_11 = '\x01';
    }
    else {
      FUN_009e2d80();
      cStack_11 = '\0';
    }
    FUN_009e2d80();
    ppuVar5 = &PTR_FUN_0193c8dc;
    if (cStack_11 == '\0') {
      ppuVar5 = (undefined **)0x0;
    }
    *puStack_18 = ppuVar5;
    FUN_009e2d80();
    FUN_009e2d80();
    uStack_8 = 0xffffffff;
    FUN_009e2d80();
    FUN_014cd990(param_1 + 2,param_1 + 8,uStack_1c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19364 ; VA 0x009e3540 ; FUN_009e3540 */

void __fastcall FUN_009e3540(int *param_1)

{
  uint uVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined **ppuVar5;
  undefined4 auStack_1f8 [8];
  undefined4 uStack_1d8;
  undefined auStack_1cc [72];
  undefined auStack_184 [72];
  undefined auStack_13c [72];
  undefined auStack_f4 [72];
  undefined auStack_ac [72];
  uint auStack_64 [2];
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  undefined8 uStack_4c;
  uint uStack_44;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined8 uStack_2c;
  int iStack_24;
  int iStack_20;
  uint *puStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7486;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    uVar1 = param_1[2];
    puStack_1c = auStack_64;
    uStack_1d8 = 1;
    puStack_18 = auStack_1f8;
    auStack_64[0] = 0;
    ExceptionList = &pvStack_10;
    puVar2 = auStack_1f8;
    if (uVar1 != 0) {
      auStack_64[0] = uVar1;
      if ((uVar1 & 1) == 0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 4,&iStack_5c,0);
        puVar2 = puStack_18;
      }
      else {
        iStack_5c = param_1[4];
        iStack_58 = param_1[5];
        iStack_54 = param_1[6];
        iStack_50 = param_1[7];
        uStack_4c = *(undefined8 *)(param_1 + 8);
        ExceptionList = &pvStack_10;
        puVar2 = auStack_1f8;
      }
    }
    puStack_18 = puVar2;
    uVar1 = param_1[10];
    uStack_8 = 0;
    uStack_44 = 0;
    if (uVar1 != 0) {
      uStack_44 = uVar1;
      if ((uVar1 & 1) == 0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0xc,&iStack_3c,0);
      }
      else {
        iStack_3c = param_1[0xc];
        iStack_38 = param_1[0xd];
        iStack_34 = param_1[0xe];
        iStack_30 = param_1[0xf];
        uStack_2c = *(undefined8 *)(param_1 + 0x10);
      }
    }
    iStack_20 = param_1[1];
    if (iStack_20 != 0) {
      LOCK();
      *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 1;
      UNLOCK();
      iStack_20 = param_1[1];
    }
    iStack_24 = *param_1;
    uStack_8 = 1;
    FUN_009e2740(auStack_64);
    puVar2 = puStack_18;
    uStack_8._0_1_ = 2;
    *puStack_18 = 0;
    FUN_009e2740(auStack_1cc);
    uStack_8._0_1_ = 3;
    FUN_009e2740(auStack_184);
    uStack_8._0_1_ = 4;
    FUN_009e2740(auStack_13c);
    uStack_8._0_1_ = 5;
    cVar3 = FUN_00585a40(auStack_ac);
    if (cVar3 == '\0') {
      FUN_009e2740(auStack_ac);
      uStack_8._0_1_ = 6;
      puStack_1c = (uint *)FUN_01674e20(0x48);
      uStack_8._0_1_ = 7;
      if (puStack_1c == (uint *)0x0) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_009e2740(auStack_f4);
      }
      puVar2[2] = uVar4;
      FUN_009e2d80();
      FUN_009e2d80();
      cStack_11 = '\x01';
    }
    else {
      FUN_009e2d80();
      cStack_11 = '\0';
    }
    FUN_009e2d80();
    ppuVar5 = &PTR_FUN_0193c8e4;
    if (cStack_11 == '\0') {
      ppuVar5 = (undefined **)0x0;
    }
    *puVar2 = ppuVar5;
    FUN_009e2d80();
    FUN_009e2d80();
    uStack_8 = 0xffffffff;
    FUN_009e2d80();
    FUN_014ccc70();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19365 ; VA 0x009e3760 ; FUN_009e3760 */

void FUN_009e3760(void)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0(&DAT_018bd25c,uVar1);
}



/* FUNCTION 19366 ; VA 0x009e37a0 ; FUN_009e37a0 */

int __thiscall FUN_009e37a0(int param_1,byte param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x40);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar1 + 4) != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    FUN_01674ea0(iVar1,0xd0);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19367 ; VA 0x009e3820 ; FUN_009e3820 */

undefined4 __thiscall FUN_009e3820(undefined4 param_1,byte param_2)

{
  FUN_009e2e30();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 19368 ; VA 0x009e3850 ; FUN_009e3850 */

undefined4 __thiscall FUN_009e3850(undefined4 param_1,byte param_2)

{
  FUN_009e2ed0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 19369 ; VA 0x009e3880 ; FUN_009e3880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009e3880(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::HttpService::HttpContentType>::vftable;
  _DAT_01ee56a8 = _DAT_01ee56a8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 19370 ; VA 0x009e38b0 ; FUN_009e38b0 */

undefined4 __thiscall FUN_009e38b0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x70);
  }
  return param_1;
}



/* FUNCTION 19371 ; VA 0x009e38d0 ; FUN_009e38d0 */

undefined4 * __thiscall FUN_009e38d0(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::HttpService::vftable;
  FUN_00577a40();
  uVar1 = param_1[0x52];
  if (0xf < uVar1) {
    iVar2 = param_1[0x4d];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_009e39e5;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x51] = 0;
  param_1[0x52] = 0xf;
  *(undefined *)(param_1 + 0x4d) = 0;
  LOCK();
  iVar2 = param_1[0x4c];
  param_1[0x4c] = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  uVar1 = param_1[0x4a];
  if (0xf < uVar1) {
    iVar2 = param_1[0x45];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_009e39e5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x49] = 0;
  param_1[0x4a] = 0xf;
  *(undefined *)(param_1 + 0x45) = 0;
  FUN_00577a40();
  FUN_00612580();
  FUN_00577a40();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x158);
  }
  return param_1;
}



/* FUNCTION 19372 ; VA 0x009e3a00 ; FUN_009e3a00 */

void __fastcall FUN_009e3a00(int param_1)

{
  FUN_009e1c60(param_1 + 8);
  return;
}



/* FUNCTION 19373 ; VA 0x009e3a10 ; FUN_009e3a10 */

void __thiscall FUN_009e3a10(undefined4 param_1,char param_2)

{
  FUN_008c3510();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x48);
  }
  return;
}



/* FUNCTION 19374 ; VA 0x009e3a40 ; FUN_009e3a40 */

void FUN_009e3a40(void)

{
  FUN_0056db40();
  return;
}



/* FUNCTION 19375 ; VA 0x009e3a50 ; FUN_009e3a50 */

void __thiscall FUN_009e3a50(int param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  uint uVar2;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c47f8;
  pvStack_10 = ExceptionList;
  uVar1 = *param_2;
  uStack_3c = 0;
  uVar2 = *(uint *)(param_1 + 0x28);
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_3c = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      iStack_48 = param_1 + 0x30;
      uStack_4c = 0x9e3ab6;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_34 = *(undefined4 *)(param_1 + 0x30);
      uStack_30 = *(undefined4 *)(param_1 + 0x34);
      uStack_2c = *(undefined4 *)(param_1 + 0x38);
      uStack_28 = *(undefined4 *)(param_1 + 0x3c);
      uStack_24 = *(undefined8 *)(param_1 + 0x40);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar2 = *(uint *)(param_1 + 8);
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x10,&uStack_54,0);
    }
    else {
      uStack_54 = *(undefined4 *)(param_1 + 0x10);
      uStack_50 = *(undefined4 *)(param_1 + 0x14);
      uStack_4c = *(undefined4 *)(param_1 + 0x18);
      iStack_48 = *(int *)(param_1 + 0x1c);
      uStack_44 = *(ulonglong *)(param_1 + 0x20);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_009e9620(uVar1,param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19376 ; VA 0x009e3b30 ; FUN_009e3b30 */

undefined4 * __thiscall FUN_009e3b30(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7908;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_06fff998a638d1023b269b0aa641b7a8>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[2] = 0;
  FUN_005880d0(param_1 + 8);
  uStack_8 = 0;
  param_2[10] = 0;
  FUN_005880d0(param_1 + 0x28);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19377 ; VA 0x009e3ba0 ; FUN_009e3ba0 */

TypeDescriptor * FUN_009e3ba0(void)

{
  return &<lambda_06fff998a638d1023b269b0aa641b7a8>::RTTI_Type_Descriptor;
}



/* FUNCTION 19378 ; VA 0x009e3bb0 ; FUN_009e3bb0 */

void __fastcall FUN_009e3bb0(undefined4 param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_48 [5];
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0b40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_008f7870(param_1);
  piVar1 = *(int **)(iVar5 + 0x43c);
  iStack_18 = *piVar1 - (int)piVar1;
  iStack_14 = piVar1[1] - (int)piVar1;
  puVar6 = (undefined4 *)FUN_009ee550(aiStack_48,&iStack_18);
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Roblox-Id",9);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar5 = FUN_005d15d0(auStack_30);
  if ((undefined4 *)(iVar5 + 0x18) != puVar6) {
    FUN_005507b0();
    uVar2 = puVar6[1];
    uVar3 = puVar6[2];
    uVar4 = puVar6[3];
    *(undefined4 *)(iVar5 + 0x18) = *puVar6;
    *(undefined4 *)(iVar5 + 0x1c) = uVar2;
    *(undefined4 *)(iVar5 + 0x20) = uVar3;
    *(undefined4 *)(iVar5 + 0x24) = uVar4;
    *(undefined8 *)(iVar5 + 0x28) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
  }
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    uVar8 = auStack_30[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_30[0] - 4);
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  if (0xf < uStack_34) {
    uVar8 = uStack_34 + 1;
    iVar5 = aiStack_48[0];
    if (0xfff < uVar8) {
      iVar5 = *(int *)(aiStack_48[0] + -4);
      uVar8 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19379 ; VA 0x009e3d00 ; FUN_009e3d00 */

void FUN_009e3d00(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  int *piVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7930;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee5482);
  auStack_6c[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_6c;
  puVar4 = auStack_6c;
  if (uVar2 != 0) {
    auStack_6c[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_6 + 2;
      uStack_7c = 0x9e3d77;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_1c;
      puVar4 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_6[2];
      uStack_60 = param_6[3];
      uStack_5c = param_6[4];
      uStack_58 = param_6[5];
      uStack_54 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_6c;
      puVar4 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar4;
  puStack_1c = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_a8 = param_5[2];
      uStack_a4 = param_5[3];
      uStack_a0 = param_5[4];
      uStack_9c = param_5[5];
      uStack_98 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_009602e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0x9e3e59;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_90 = param_4[1];
  uStack_8 = 0xffffffff;
  uStack_98 = CONCAT44(*param_4,0x9e3e9d);
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19380 ; VA 0x009e3eb0 ; FUN_009e3eb0 */

void FUN_009e3eb0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,int param_6,uint *param_7,uint *param_8)

{
  uint uVar1;
  undefined auStack_130 [104];
  undefined4 uStack_c8;
  uint *puStack_c4;
  uint *puStack_c0;
  code *pcStack_bc;
  uint uStack_b8;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [40];
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7958;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee5482);
  uStack_48 = 0;
  uVar1 = *param_8;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_48 = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_8 + 2;
      uStack_58 = 0x9e3f34;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_8[2];
      uStack_3c = param_8[3];
      uStack_38 = param_8[4];
      uStack_34 = param_8[5];
      uStack_30 = *(undefined8 *)(param_8 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uStack_b8 = 0;
  uVar1 = *param_7;
  if (uVar1 != 0) {
    uStack_b8 = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_c0 = &uStack_b0;
      pcStack_bc = (code *)0x0;
      puStack_c4 = param_7 + 2;
      uStack_c8 = 0x9e3f93;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      uStack_b0 = param_7[2];
      uStack_ac = param_7[3];
      uStack_a8 = param_7[4];
      uStack_a4 = param_7[5];
      uStack_a0 = *(undefined8 *)(param_7 + 6);
    }
  }
  pcStack_bc = FUN_008e5f10;
  puStack_c4 = (uint *)0x9e3fa1;
  puStack_c0 = (uint *)auStack_94;
  FUN_008bfbf0();
  uStack_98 = 0x9e3fab;
  FUN_008dc050();
  uStack_8._0_1_ = 1;
  if (*(undefined4 **)(param_6 + 4) != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)(param_6 + 4))(param_6 + 8,auStack_130);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_4);
  uStack_8 = 0xffffffff;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19381 ; VA 0x009e4020 ; FUN_009e4020 */

void FUN_009e4020(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,int param_8,uint *param_9,
                 uint *param_10)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7990;
  pvStack_10 = ExceptionList;
  uVar1 = *param_10;
  ExceptionList = &pvStack_10;
  if ((uVar1 != 0) && (ExceptionList = &pvStack_10, (uVar1 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar1 & 0xfffffffe))();
  }
  uStack_8 = 0;
  uVar1 = *param_9;
  if ((uVar1 != 0) && ((uVar1 & 1) == 0)) {
    (**(code **)(uVar1 & 0xfffffffe))();
  }
  FUN_008bfbf0();
  FUN_008dc050();
  uStack_8._0_1_ = 1;
  if (*(undefined4 **)(param_8 + 4) != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)(param_8 + 4))();
  }
  uStack_8._0_1_ = 2;
  FUN_0054ef60(param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_4);
  uStack_8 = 0xffffffff;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19382 ; VA 0x009e41b0 ; FUN_009e41b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined __thiscall FUN_009e41b0(int param_1,undefined *param_2,uint param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  double *pdVar7;
  int iVar8;
  char *pcVar9;
  undefined4 uVar10;
  undefined uVar11;
  undefined4 in_stack_ffffff54;
  undefined4 in_stack_ffffff58;
  undefined *in_stack_ffffff5c;
  undefined8 uVar12;
  undefined auStack_54 [24];
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  int iStack_1c;
  int *piStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d79cb;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if (*(int *)(param_2 + 0x10) == 0) {
    uVar10 = 9;
    pcVar9 = "Empty URL";
    ExceptionList = &pvStack_10;
  }
  else {
    in_stack_ffffff5c = (undefined *)0x9e41f9;
    ExceptionList = &pvStack_10;
    cVar2 = FUN_00973950(param_1,1);
    if ((cVar2 == '\0') || (cVar2 = FUN_00983210(), cVar2 != '\0')) {
      if (*(char *)(param_1 + 0xe2) == '\0') {
        if (*(char *)(param_1 + 0xe1) == '\0') {
          *(undefined *)(param_1 + 0xe1) = 1;
          FUN_00d105d0();
          iStack_8._0_1_ = 1;
          uStack_2c = 0;
          uStack_28 = 0xf;
          auStack_3c[0] = 0;
          FUN_005542c0("Go to Game Settings and turn on Allow HTTP requests.",0x34);
          iStack_8._0_1_ = 2;
          in_stack_ffffff5c = auStack_3c;
          in_stack_ffffff58 = 1;
          in_stack_ffffff54 = 0x9e427d;
          FUN_0086f010(1,in_stack_ffffff5c,auStack_54,6);
          FUN_005507b0();
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_005507b0();
        }
        uVar10 = 0x37;
        pcVar9 = "Http requests are not enabled. Enable via game settings";
      }
      else {
        iVar8 = *(int *)(param_1 + 0x34);
        if (((iVar8 == 0) ||
            (iVar4 = *(int *)(iVar8 + 0xc), iVar3 = FUN_008dcf60(),
            (uint)*(ushort *)(iVar3 + 0x1da) <
            (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) || (iVar8 == 0xc))
        {
          uVar10 = 0x18;
          pcVar9 = "Unrecognized HttpService";
        }
        else {
          iVar8 = *(int *)(param_1 + 0x34);
          iVar4 = param_1;
          if ((iVar8 != 0) && (iVar4 = iVar8, *(int *)(iVar8 + 0x34) != 0)) {
            iVar4 = FUN_005c8ac0();
          }
          if ((iVar4 == 0) ||
             (iVar8 = *(int *)(iVar4 + 0xc), iVar4 = FUN_008a8c30(),
             (uint)*(ushort *)(iVar4 + 0x1da) <
             (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
LAB_009e4415:
            iVar8 = 1;
          }
          else {
            in_stack_ffffff5c = (undefined *)0x9e4339;
            FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
            FUN_00560c40();
            piStack_18 = (int *)FUN_008aa140();
            if (*piStack_18 == 0) {
              uVar10 = FUN_00961660();
              in_stack_ffffff5c = (undefined *)0x9e4362;
              piVar5 = (int *)FUN_008a9ba0(&uStack_24,uVar10);
              iVar8 = *piVar5;
              iVar4 = piVar5[1];
              *piVar5 = 0;
              piVar5[1] = 0;
              *piStack_18 = iVar8;
              piVar5 = (int *)piStack_18[1];
              piStack_18[1] = iVar4;
              if (piVar5 != (int *)0x0) {
                LOCK();
                iVar8 = piVar5[1] + -1;
                piVar5[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar5)();
                  LOCK();
                  iVar8 = piVar5[2] + -1;
                  piVar5[2] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)(*piVar5 + 4))();
                  }
                }
              }
              piVar5 = uStack_24._4_4_;
              if (uStack_24._4_4_ != (int *)0x0) {
                LOCK();
                iVar8 = uStack_24._4_4_[1] + -1;
                uStack_24._4_4_[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*uStack_24._4_4_)();
                  LOCK();
                  piVar1 = piVar5 + 2;
                  iVar8 = *piVar1;
                  *piVar1 = *piVar1 + -1;
                  UNLOCK();
                  if (iVar8 == 1) {
                    (**(code **)(*piVar5 + 4))();
                  }
                }
              }
            }
            iVar8 = *piStack_18;
            if (iVar8 == 0) goto LAB_009e4415;
            if (DAT_01d65510 == '\0') {
              iVar8 = (*(int **)(iVar8 + 0xb8))[1] - **(int **)(iVar8 + 0xb8) >> 3;
            }
            else {
              cVar2 = FUN_00980340();
              if (cVar2 == '\0') {
                iVar8 = 0;
              }
              else {
                iVar4 = (*(int **)(iVar8 + 0xb8))[1] - **(int **)(iVar8 + 0xb8) >> 3;
                iVar8 = 1;
                if (1 < iVar4) {
                  iVar8 = iVar4;
                }
              }
            }
          }
          cStack_11 = FUN_008ef420();
          cStack_12 = FUN_008ef420();
          if (cStack_12 == '\0') {
            if (cStack_11 == '\0') {
              if (iVar8 == 0) {
                *(int *)(param_1 + 0xd4) = *(int *)(param_1 + 0xd4) + 1;
              }
              else {
                LOCK();
                *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + 1;
                UNLOCK();
              }
            }
            else if (iVar8 == 0) {
              *(int *)(param_1 + 0xdc) = *(int *)(param_1 + 0xdc) + 1;
            }
            else {
              LOCK();
              *(int *)(param_1 + 0xcc) = *(int *)(param_1 + 0xcc) + 1;
              UNLOCK();
            }
          }
          else if (cStack_11 == '\0') {
            if (iVar8 == 0) {
              *(int *)(param_1 + 0xd8) = *(int *)(param_1 + 0xd8) + 1;
            }
            else {
              LOCK();
              *(int *)(param_1 + 200) = *(int *)(param_1 + 200) + 1;
              UNLOCK();
            }
          }
          else if (iVar8 == 0) {
            *(int *)(param_1 + 0xd0) = *(int *)(param_1 + 0xd0) + 1;
          }
          else {
            LOCK();
            *(int *)(param_1 + 0xc0) = *(int *)(param_1 + 0xc0) + 1;
            UNLOCK();
          }
          if ((NAN(*(double *)(param_1 + 0xb8)) || NAN(_PTR_018c6f48)) !=
              (*(double *)(param_1 + 0xb8) == _PTR_018c6f48)) {
            puVar6 = (undefined4 *)FUN_016830f0();
            *(undefined4 *)(param_1 + 0xb8) = *puVar6;
            *(undefined4 *)(param_1 + 0xbc) = puVar6[1];
          }
          if ((*(char *)(param_1 + 0xe0) == '\0') && (0 < iVar8)) {
            if (0 < DAT_01d6544c) {
              pdVar7 = (double *)FUN_016830f0();
              uStack_24 = *pdVar7 - *(double *)(param_1 + 0xb8);
              FUN_0151f6f0(0xffffffff,0,0);
              iStack_8._0_1_ = 3;
              FUN_0151fb00("totalDuration",uStack_24);
              FUN_0151f9c0("numPlayers",iVar8);
              FUN_0151f9c0(&DAT_0193bf98,*(undefined4 *)(param_1 + 0xd0));
              FUN_0151f9c0(&DAT_0193bfa0,*(undefined4 *)(param_1 + 0xd4));
              FUN_0151f9c0(&DAT_0193bfa8,*(undefined4 *)(param_1 + 0xd8));
              FUN_0151f9c0(&DAT_0193bfb0,*(undefined4 *)(param_1 + 0xdc));
              iVar8 = DAT_01d6544c;
              uStack_2c = 0;
              uStack_28 = 0xf;
              auStack_3c[0] = 0;
              FUN_005542c0("HttpServiceZeroPlayers",0x16);
              in_stack_ffffff5c = auStack_3c;
              iStack_8._0_1_ = 4;
              in_stack_ffffff58 = 0x9e45e1;
              FUN_01520d20(in_stack_ffffff5c,iVar8,0);
              FUN_005507b0();
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_0151f7f0();
            }
            *(undefined *)(param_1 + 0xe0) = 1;
            puVar6 = (undefined4 *)FUN_016830f0();
            *(undefined4 *)(param_1 + 0xb8) = *puVar6;
            *(undefined4 *)(param_1 + 0xbc) = puVar6[1];
          }
          if (cStack_12 == '\0') {
            uVar10 = 0x21;
            pcVar9 = "Number of requests exceeded limit";
          }
          else {
            if ((DAT_01d654f0 == '\0') || (cVar2 = FUN_009e7e90(), cVar2 == '\0')) {
              FUN_009e8cf0(param_2,"HttpServiceReportUrl-ok",DAT_01ee53cc);
              iVar8 = FUN_008f7870();
              piStack_18 = *(int **)(iVar8 + 0x43c);
              iStack_1c = *piStack_18 - (int)piStack_18;
              piStack_18 = (int *)(piStack_18[1] - (int)piStack_18);
              FUN_009e20e0(&DAT_01ee5484,&iStack_1c);
              uVar11 = 1;
              goto LAB_009e46db;
            }
            in_stack_ffffff58 = 0x9e465e;
            FUN_009e8cf0(param_2,"HttpServiceReportUrl-blacklist",DAT_01ee53d0);
            uVar10 = 0xe;
            pcVar9 = "Request denied";
            in_stack_ffffff5c = param_2;
          }
        }
      }
    }
    else {
      uVar10 = 0x31;
      pcVar9 = "Http requests can only be executed by game server";
    }
  }
  uVar12 = 0xf00000000;
  uVar11 = 0;
  FUN_005542c0(pcVar9,uVar10);
  FUN_005e65e0(uVar11,in_stack_ffffff54,in_stack_ffffff58,in_stack_ffffff5c,uVar12);
  uVar11 = 0;
LAB_009e46db:
  iStack_8 = 5;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000010,&stack0x00000010,2);
  }
  ExceptionList = pvStack_10;
  return uVar11;
}



/* FUNCTION 19383 ; VA 0x009e4720 ; FUN_009e4720 */

void __fastcall FUN_009e4720(int param_1)

{
  undefined4 *puVar1;
  uint *puVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 uStack_64;
  undefined *puStack_60;
  uint *puStack_5c;
  uint *puStack_58;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  undefined *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7af8;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)(param_1 + 0xe4);
  puStack_5c = *(uint **)(param_1 + 0xe8);
  puStack_60 = (undefined *)*puVar1;
  uStack_64 = 0x9e4753;
  ExceptionList = &pvStack_10;
  puStack_58 = puVar1;
  iStack_14 = param_1;
  FUN_00559570();
  *(undefined4 *)(param_1 + 0xe8) = *puVar1;
  if (*(int *)(param_1 + 0xf8) != 0) {
    puStack_58 = (uint *)0x0;
    puStack_5c = (uint *)(*(int *)(param_1 + 0x104) + *(int *)(param_1 + 0xf4) * 4);
    puStack_60 = (undefined *)0x9e477a;
    FUN_0061adc0();
    puVar4 = *(undefined4 **)(param_1 + 0x104);
    puVar7 = puVar4 + *(int *)(param_1 + 0xf4);
    for (; puVar4 != puVar7; puVar4 = puVar4 + 1) {
      *puVar4 = 0;
    }
  }
  iVar3 = iStack_14;
  puVar7 = (undefined4 *)(iStack_14 + 0x108);
  puStack_5c = *(uint **)(iStack_14 + 0x10c);
  puStack_60 = (undefined *)*puVar7;
  uStack_64 = 0x9e47b1;
  puStack_58 = puVar7;
  FUN_00559570();
  *(undefined4 *)(iVar3 + 0x10c) = *puVar7;
  if (iStack_14 != 0x1d653c4) {
    puStack_58 = (uint *)DAT_01d654e8;
    puStack_5c = (uint *)&DAT_01d654d8;
    if (0xf < DAT_01d654ec) {
      puStack_5c = DAT_01d654d8;
    }
    puStack_60 = (undefined *)0x9e47e9;
    FUN_005542c0();
  }
  puStack_58 = (uint *)0x0;
  puStack_18 = (undefined *)&uStack_64;
  uStack_64 = 0;
  puStack_5c = (uint *)0x2;
  FUN_0170cc70(&uStack_64,&DAT_018cecfc,2);
  FUN_0063e660(&uStack_64,(int)&uStack_64 + (int)puStack_5c,puStack_5c,puStack_18);
  FUN_0063fd80(puVar1,&DAT_01d654d8);
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_58 = (uint *)0xd;
  puStack_5c = (uint *)0x193c0b8;
  puStack_60 = (undefined *)0x9e4850;
  FUN_005542c0();
  uVar6 = uStack_34;
  puVar2 = *(uint **)(param_1 + 0xe8);
  uStack_8 = 0;
  if (*(uint **)(param_1 + 0xec) == puVar2) {
    puStack_58 = &uStack_34;
    puStack_60 = (undefined *)0x9e488b;
    puStack_5c = puVar2;
    FUN_0058d0a0();
    uVar6 = uStack_20;
  }
  else {
    uStack_34 = uStack_34 & 0xffffff00;
    *puVar2 = uVar6;
    puVar2[1] = uStack_30;
    puVar2[2] = uStack_2c;
    puVar2[3] = uStack_28;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_20,uStack_24);
    *(int *)(param_1 + 0xe8) = *(int *)(param_1 + 0xe8) + 0x18;
    uVar6 = 0xf;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uVar6) {
    puStack_58 = (uint *)(uVar6 + 1);
    uVar5 = uStack_34;
    if (0xfff < puStack_58) {
      uVar5 = *(uint *)(uStack_34 - 4);
      puStack_58 = (uint *)(uVar6 + 0x24);
      if (0x1f < (uStack_34 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (uint *)0x9e52f0;
        FUN_017167a3();
      }
    }
    puStack_60 = (undefined *)0x9e48c3;
    puStack_5c = (uint *)uVar5;
    FUN_01674ea0();
  }
  puStack_58 = (uint *)0x6;
  puStack_5c = (uint *)0x193c0c8;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e48e7;
  FUN_005542c0();
  uVar6 = uStack_34;
  puVar2 = *(uint **)(param_1 + 0xe8);
  uStack_8 = 1;
  if (*(uint **)(param_1 + 0xec) == puVar2) {
    puStack_58 = &uStack_34;
    puStack_60 = (undefined *)0x9e4922;
    puStack_5c = puVar2;
    FUN_0058d0a0();
    uVar6 = uStack_20;
  }
  else {
    uStack_34 = uStack_34 & 0xffffff00;
    *puVar2 = uVar6;
    puVar2[1] = uStack_30;
    puVar2[2] = uStack_2c;
    puVar2[3] = uStack_28;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_20,uStack_24);
    *(int *)(param_1 + 0xe8) = *(int *)(param_1 + 0xe8) + 0x18;
    uVar6 = 0xf;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uVar6) {
    puStack_58 = (uint *)(uVar6 + 1);
    uVar5 = uStack_34;
    if (0xfff < puStack_58) {
      uVar5 = *(uint *)(uStack_34 - 4);
      puStack_58 = (uint *)(uVar6 + 0x24);
      if (0x1f < (uStack_34 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (uint *)0x9e52f5;
        FUN_017167a3();
      }
    }
    puStack_60 = (undefined *)0x9e495a;
    puStack_5c = (uint *)uVar5;
    FUN_01674ea0();
  }
  puStack_58 = (uint *)0x7;
  puStack_5c = (uint *)0x1936140;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e497e;
  FUN_005542c0();
  uVar6 = uStack_34;
  puVar2 = *(uint **)(param_1 + 0xe8);
  uStack_8 = 2;
  if (*(uint **)(param_1 + 0xec) == puVar2) {
    puStack_58 = &uStack_34;
    puStack_60 = (undefined *)0x9e49b9;
    puStack_5c = puVar2;
    FUN_0058d0a0();
    uVar6 = uStack_20;
  }
  else {
    uStack_34 = uStack_34 & 0xffffff00;
    *puVar2 = uVar6;
    puVar2[1] = uStack_30;
    puVar2[2] = uStack_2c;
    puVar2[3] = uStack_28;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_20,uStack_24);
    *(int *)(param_1 + 0xe8) = *(int *)(param_1 + 0xe8) + 0x18;
    uVar6 = 0xf;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uVar6) {
    puStack_58 = (uint *)(uVar6 + 1);
    uVar5 = uStack_34;
    if (0xfff < puStack_58) {
      uVar5 = *(uint *)(uStack_34 - 4);
      puStack_58 = (uint *)(uVar6 + 0x24);
      if (0x1f < (uStack_34 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (uint *)0x9e52fa;
        FUN_017167a3();
      }
    }
    puStack_60 = (undefined *)0x9e49f1;
    puStack_5c = (uint *)uVar5;
    FUN_01674ea0();
  }
  puStack_58 = (uint *)0xc;
  puStack_5c = (uint *)0x193c0d0;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e4a15;
  FUN_005542c0();
  uVar6 = uStack_34;
  puVar2 = *(uint **)(param_1 + 0xe8);
  uStack_8 = 3;
  if (*(uint **)(param_1 + 0xec) == puVar2) {
    puStack_58 = &uStack_34;
    puStack_60 = (undefined *)0x9e4a50;
    puStack_5c = puVar2;
    FUN_0058d0a0();
    uVar6 = uStack_20;
  }
  else {
    uStack_34 = uStack_34 & 0xffffff00;
    *puVar2 = uVar6;
    puVar2[1] = uStack_30;
    puVar2[2] = uStack_2c;
    puVar2[3] = uStack_28;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_20,uStack_24);
    *(int *)(param_1 + 0xe8) = *(int *)(param_1 + 0xe8) + 0x18;
    uVar6 = 0xf;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uVar6) {
    puStack_58 = (uint *)(uVar6 + 1);
    uVar5 = uStack_34;
    if (0xfff < puStack_58) {
      uVar5 = *(uint *)(uStack_34 - 4);
      puStack_58 = (uint *)(uVar6 + 0x24);
      if (0x1f < (uStack_34 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (uint *)0x9e52ff;
        FUN_017167a3();
      }
    }
    puStack_60 = (undefined *)0x9e4a88;
    puStack_5c = (uint *)uVar5;
    FUN_01674ea0();
  }
  puStack_58 = (uint *)0x11;
  puStack_5c = (uint *)0x193c0e0;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e4aac;
  FUN_005542c0();
  uVar6 = uStack_34;
  puVar2 = *(uint **)(param_1 + 0xe8);
  uStack_8 = 4;
  if (*(uint **)(param_1 + 0xec) == puVar2) {
    puStack_58 = &uStack_34;
    puStack_60 = (undefined *)0x9e4ae7;
    puStack_5c = puVar2;
    FUN_0058d0a0();
    uVar6 = uStack_20;
  }
  else {
    uStack_34 = uStack_34 & 0xffffff00;
    *puVar2 = uVar6;
    puVar2[1] = uStack_30;
    puVar2[2] = uStack_2c;
    puVar2[3] = uStack_28;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_20,uStack_24);
    *(int *)(param_1 + 0xe8) = *(int *)(param_1 + 0xe8) + 0x18;
    uVar6 = 0xf;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uVar6) {
    puStack_58 = (uint *)(uVar6 + 1);
    uVar5 = uStack_34;
    if (0xfff < puStack_58) {
      uVar5 = *(uint *)(uStack_34 - 4);
      puStack_58 = (uint *)(uVar6 + 0x24);
      if (0x1f < (uStack_34 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (uint *)0x9e5304;
        FUN_017167a3();
      }
    }
    puStack_60 = (undefined *)0x9e4b1f;
    puStack_5c = (uint *)uVar5;
    FUN_01674ea0();
  }
  puStack_58 = (uint *)0xe;
  puStack_5c = (uint *)0x193c0f4;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e4b43;
  FUN_005542c0();
  uVar6 = uStack_34;
  puVar2 = *(uint **)(param_1 + 0xe8);
  uStack_8 = 5;
  if (*(uint **)(param_1 + 0xec) == puVar2) {
    puStack_58 = &uStack_34;
    puStack_60 = (undefined *)0x9e4b7e;
    puStack_5c = puVar2;
    FUN_0058d0a0();
    uVar6 = uStack_20;
  }
  else {
    uStack_34 = uStack_34 & 0xffffff00;
    *puVar2 = uVar6;
    puVar2[1] = uStack_30;
    puVar2[2] = uStack_2c;
    puVar2[3] = uStack_28;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_20,uStack_24);
    *(int *)(param_1 + 0xe8) = *(int *)(param_1 + 0xe8) + 0x18;
    uVar6 = 0xf;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uVar6) {
    puStack_58 = (uint *)(uVar6 + 1);
    uVar5 = uStack_34;
    if (0xfff < puStack_58) {
      uVar5 = *(uint *)(uStack_34 - 4);
      puStack_58 = (uint *)(uVar6 + 0x24);
      if (0x1f < (uStack_34 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (uint *)&UNK_009e5309;
        FUN_017167a3();
      }
    }
    puStack_60 = (undefined *)0x9e4bb6;
    puStack_5c = (uint *)uVar5;
    FUN_01674ea0();
  }
  puStack_58 = (uint *)0xf;
  puStack_5c = (uint *)0x193c104;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  puStack_60 = (undefined *)0x9e4bda;
  FUN_005542c0();
  puStack_58 = (uint *)auStack_4c;
  uStack_8 = 6;
  puStack_5c = (uint *)0x9e4bec;
  FUN_0058d640();
  uStack_8 = 0xffffffff;
  puStack_58 = (uint *)0x9e4bfb;
  FUN_005507b0();
  puStack_58 = (uint *)0x11;
  puStack_5c = (uint *)0x193c114;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  puStack_60 = (undefined *)0x9e4c1c;
  FUN_005542c0();
  puStack_58 = (uint *)auStack_4c;
  uStack_8 = 7;
  puStack_5c = (uint *)0x9e4c2e;
  FUN_00590440();
  uStack_8 = 0xffffffff;
  puStack_58 = (uint *)0x9e4c3d;
  FUN_005507b0();
  puStack_58 = (uint *)0x14;
  puStack_5c = (uint *)0x193c128;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  puStack_60 = (undefined *)0x9e4c5e;
  FUN_005542c0();
  puStack_58 = (uint *)auStack_4c;
  uStack_8 = 8;
  puStack_5c = (uint *)0x9e4c70;
  FUN_00590440();
  uStack_8 = 0xffffffff;
  puStack_58 = (uint *)0x9e4c7f;
  FUN_005507b0();
  puStack_58 = (uint *)0x9;
  puStack_5c = (uint *)0x193c140;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  puStack_60 = (undefined *)0x9e4ca0;
  FUN_005542c0();
  puStack_58 = (uint *)auStack_4c;
  uStack_8 = 9;
  puStack_5c = (uint *)0x9e4cb2;
  FUN_00590440();
  uStack_8 = 0xffffffff;
  puStack_58 = (uint *)0x9e4cc1;
  FUN_005507b0();
  puStack_58 = (uint *)0xb;
  puStack_5c = (uint *)0x18cdbf8;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  puStack_60 = (undefined *)0x9e4ce2;
  FUN_005542c0();
  puStack_58 = (uint *)auStack_4c;
  uStack_8 = 10;
  puStack_5c = (uint *)0x9e4cf4;
  FUN_00590440();
  uStack_8 = 0xffffffff;
  puStack_58 = (uint *)0x9e4d03;
  FUN_005507b0();
  uStack_3c = 0;
  puStack_58 = (uint *)0x9;
  puStack_5c = (uint *)0x193c14c;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  puStack_60 = (undefined *)0x9e4d24;
  FUN_005542c0();
  puStack_58 = (uint *)auStack_4c;
  uStack_8 = 0xb;
  puStack_5c = (uint *)0x9e4d36;
  FUN_00590440();
  uStack_8 = 0xffffffff;
  puStack_58 = (uint *)0x9e4d45;
  FUN_005507b0();
  puStack_58 = (uint *)0x9;
  puStack_5c = (uint *)0x193c158;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  puStack_60 = (undefined *)0x9e4d66;
  FUN_005542c0();
  puStack_58 = (uint *)auStack_4c;
  uStack_8 = 0xc;
  puStack_5c = (uint *)0x9e4d78;
  FUN_00590440();
  uStack_8 = 0xffffffff;
  puStack_58 = (uint *)0x9e4d87;
  FUN_005507b0();
  puStack_58 = (uint *)0x1c;
  puStack_5c = (uint *)0x193c164;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  puStack_60 = (undefined *)0x9e4da8;
  FUN_005542c0();
  puStack_58 = (uint *)auStack_4c;
  uStack_8 = 0xd;
  puStack_5c = (uint *)0x9e4dba;
  FUN_00590440();
  uStack_8 = 0xffffffff;
  puStack_58 = (uint *)0x9e4dc9;
  FUN_005507b0();
  puStack_58 = (uint *)0xe;
  puStack_5c = (uint *)0x193c184;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  puStack_60 = (undefined *)0x9e4dea;
  FUN_005542c0();
  puStack_58 = (uint *)0xc;
  puStack_5c = (uint *)0x193c194;
  uStack_8 = 0xe;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e4e12;
  FUN_005542c0();
  puStack_5c = &uStack_34;
  puStack_60 = auStack_1c;
  uStack_8._0_1_ = 0xf;
  uStack_64 = 0x9e4e2d;
  puStack_58 = puStack_5c;
  FUN_0064e3a0();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e4e39;
  FUN_005507b0();
  puStack_58 = (uint *)0x10;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_5c = (uint *)0x193c1a4;
  puStack_60 = (undefined *)0x9e4e5a;
  FUN_005542c0();
  puStack_5c = &uStack_34;
  uStack_8._0_1_ = 0x10;
  puStack_60 = auStack_1c;
  uStack_64 = 0x9e4e72;
  puStack_58 = puStack_5c;
  FUN_0064e3a0();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e4e7e;
  FUN_005507b0();
  puStack_58 = (uint *)0xa;
  puStack_5c = (uint *)0x193c1b8;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e4e9f;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x11;
  puStack_5c = (uint *)0x9e4eae;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e4eba;
  FUN_005507b0();
  puStack_58 = (uint *)0x6;
  puStack_5c = (uint *)0x193c1c4;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e4edb;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x12;
  puStack_5c = (uint *)0x9e4eea;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e4ef6;
  FUN_005507b0();
  puStack_58 = (uint *)0x9;
  puStack_5c = (uint *)0x193c1cc;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e4f17;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x13;
  puStack_5c = (uint *)0x9e4f26;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e4f32;
  FUN_005507b0();
  puStack_58 = (uint *)0x10;
  puStack_5c = (uint *)0x193c1d8;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e4f53;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x14;
  puStack_5c = (uint *)0x9e4f62;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e4f6e;
  FUN_005507b0();
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_58 = (uint *)0x3;
  puStack_5c = (uint *)&DAT_0193c1ec;
  puStack_60 = (undefined *)0x9e4f8f;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x15;
  puStack_5c = (uint *)0x9e4f9e;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e4faa;
  FUN_005507b0();
  puStack_58 = (uint *)0xf;
  puStack_5c = (uint *)0x193c1f0;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e4fcb;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x16;
  puStack_5c = (uint *)0x9e4fda;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e4fe6;
  FUN_005507b0();
  puStack_58 = (uint *)0x10;
  puStack_5c = (uint *)0x193c200;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e5007;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x17;
  puStack_5c = (uint *)0x9e5016;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e5022;
  FUN_005507b0();
  puStack_58 = (uint *)0x11;
  puStack_5c = (uint *)0x193c214;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e5043;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x18;
  puStack_5c = (uint *)0x9e5052;
  FUN_00590440();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  puStack_58 = (uint *)0x9e505e;
  FUN_005507b0();
  puStack_5c = *(uint **)(param_1 + 0xe8);
  puStack_58 = (uint *)auStack_4c;
  if ((uint *)*(int *)(param_1 + 0xec) == puStack_5c) {
    puStack_60 = (undefined *)0x9e507f;
    FUN_00559960();
  }
  else {
    puStack_5c = (uint *)0x9e5071;
    FUN_0054ef60();
    *(int *)(param_1 + 0xe8) = *(int *)(param_1 + 0xe8) + 0x18;
  }
  puStack_58 = (uint *)0xd;
  puStack_5c = (uint *)0x193c228;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e50a0;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x19;
  puStack_5c = (uint *)0x9e50af;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e50bb;
  FUN_005507b0();
  puStack_58 = (uint *)0xe;
  puStack_5c = (uint *)0x18c39f8;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e50dc;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x1a;
  puStack_5c = (uint *)0x9e50eb;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e50f7;
  FUN_005507b0();
  puStack_58 = (uint *)0xf;
  puStack_5c = (uint *)0x193c238;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e5118;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x1b;
  puStack_5c = (uint *)0x9e5127;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e5133;
  FUN_005507b0();
  puStack_58 = (uint *)0x4;
  puStack_5c = (uint *)&DAT_018c39a4;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e5154;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x1c;
  puStack_5c = (uint *)0x9e5163;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e516f;
  FUN_005507b0();
  puStack_58 = (uint *)0x9;
  puStack_5c = (uint *)0x18c3af4;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e5190;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x1d;
  puStack_5c = (uint *)0x9e519f;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e51ab;
  FUN_005507b0();
  uStack_24 = 0;
  puStack_58 = (uint *)0xa;
  puStack_5c = (uint *)0x18c3ce4;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e51cc;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x1e;
  puStack_5c = (uint *)0x9e51db;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e51e7;
  FUN_005507b0();
  puStack_58 = (uint *)0xc;
  puStack_5c = (uint *)0x193c248;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e5208;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x1f;
  puStack_5c = (uint *)0x9e5217;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e5223;
  FUN_005507b0();
  puStack_58 = (uint *)0xa;
  puStack_5c = (uint *)0x193c258;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e5244;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x20;
  puStack_5c = (uint *)0x9e5253;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e525f;
  FUN_005507b0();
  puStack_58 = (uint *)0x9;
  puStack_5c = (uint *)0x193c264;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e5280;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8._0_1_ = 0x21;
  puStack_5c = (uint *)0x9e528f;
  FUN_00590440();
  uStack_8._0_1_ = 0xe;
  puStack_58 = (uint *)0x9e529b;
  FUN_005507b0();
  puStack_58 = (uint *)0xa;
  puStack_5c = (uint *)0x18c3acc;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  puStack_60 = (undefined *)0x9e52bc;
  FUN_005542c0();
  puStack_58 = &uStack_34;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x22);
  puStack_5c = (uint *)0x9e52cb;
  FUN_00590440();
  puStack_58 = (uint *)0x9e52d3;
  FUN_005507b0();
  puStack_58 = (uint *)0x9e52db;
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19384 ; VA 0x009e5310 ; FUN_009e5310 */

void FUN_009e5310(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_009eb4b0();
    *param_2 = uVar3;
    iVar4 = FUN_009eb560();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 19385 ; VA 0x009e5370 ; FUN_009e5370 */

void FUN_009e5370(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009eb4b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 19386 ; VA 0x009e53b0 ; FUN_009e53b0 */

undefined4 * FUN_009e53b0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_005c2950(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 19387 ; VA 0x009e5420 ; FUN_009e5420 */

void __thiscall
FUN_009e5420(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  undefined4 *puStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf757;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar7 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar7 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar7;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar7 & 2) != 0) {
    uVar7 = uVar7 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 1) != 0) {
    uVar7 = uVar7 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar7;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar7 = uVar7 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar7 = uVar7 | 4;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar7 & 8) != 0) {
    uVar7 = uVar7 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 4) != 0) {
    uVar7 = uVar7 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar7;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 9;
    uVar7 = uVar7 | 0x20;
  }
  else {
    uStack_ec = FUN_009eb4b0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_009eb560();
    puVar5 = &uStack_ec;
    uStack_8 = 8;
    uVar7 = uVar7 | 0x10;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_009eb4b0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar7 & 0x20) != 0) {
    uVar7 = uVar7 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x10) != 0) {
    uVar7 = uVar7 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar7;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x4c);
  if (puVar2 == (undefined *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar7 = uVar7 | 0x80;
  }
  else {
    uStack_ec = FUN_0088daf0();
    iStack_e8 = 0;
    auStack_e4[0] = CONCAT31(auStack_e4[0]._1_3_,*puVar2);
    iStack_e8 = FUN_005c9ef0();
    puVar5 = &uStack_ec;
    uStack_8 = 0xc;
    uVar7 = uVar7 | 0x40;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((char)uVar7 < '\0') {
    uVar7 = uVar7 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x40) != 0) {
    uVar7 = uVar7 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar7;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x50);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 0x11;
    uVar7 = uVar7 | 0x200;
  }
  else {
    uStack_28c = *puVar5;
    puStack_288 = (undefined4 *)0x0;
    puVar6 = (undefined4 *)puVar5[1];
    if (puVar6 != (undefined4 *)0x0) {
      (*(code *)*puVar6)(puVar5 + 2,auStack_284);
      puVar6 = (undefined4 *)puVar5[1];
    }
    puVar5 = &uStack_28c;
    uStack_8 = 0x10;
    uVar7 = uVar7 | 0x100;
    puStack_288 = puVar6;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_00888410();
  uVar4 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar7 & 0x200) != 0) {
    uVar7 = uVar7 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar7;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar7 & 0x100) != 0) && (uStack_8 = 0x13, puStack_288 != (undefined4 *)0x0)) {
    (*(code *)puStack_288[2])(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19388 ; VA 0x009e5930 ; FUN_009e5930 */

void __thiscall FUN_009e5930(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  undefined4 *puStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar7 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar7 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar7;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar7 & 2) != 0) {
    uVar7 = uVar7 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 1) != 0) {
    uVar7 = uVar7 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar7;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x44);
  if (puVar2 == (undefined *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar7 = uVar7 | 8;
  }
  else {
    uStack_ec = FUN_0088daf0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar2;
    iStack_e8 = FUN_005c9ef0();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar7 = uVar7 | 4;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar7 & 8) != 0) {
    uVar7 = uVar7 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 4) != 0) {
    uVar7 = uVar7 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar7;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 9;
    uVar7 = uVar7 | 0x20;
  }
  else {
    uStack_28c = *puVar5;
    puStack_288 = (undefined4 *)0x0;
    puVar6 = (undefined4 *)puVar5[1];
    if (puVar6 != (undefined4 *)0x0) {
      (*(code *)*puVar6)(puVar5 + 2,auStack_284);
      puVar6 = (undefined4 *)puVar5[1];
    }
    puVar5 = &uStack_28c;
    uStack_8 = 8;
    uVar7 = uVar7 | 0x10;
    puStack_288 = puVar6;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_00888410();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar7 & 0x20) != 0) {
    uVar7 = uVar7 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar7;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar7 & 0x10) != 0) && (uStack_8 = 0xb, puStack_288 != (undefined4 *)0x0)) {
    (*(code *)puStack_288[2])(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19389 ; VA 0x009e5c50 ; FUN_009e5c50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_009e5c50(undefined4 *param_1)

{
  int iVar1;
  void *pvVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int iStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7b2b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8._0_1_ = 1;
  cVar3 = FUN_0098ef90(&stack0x00000008,&iStack_ec,0);
  iVar1 = iStack_ec;
  if (cVar3 != '\0') {
    iVar4 = FUN_00888530();
    if (iVar1 == iVar4) {
      uStack_18 = 0;
      uStack_14 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      uVar5 = FUN_0088cdc0();
      iVar1 = _tls_index;
      *param_1 = uVar5;
      pvVar2 = ThreadLocalStoragePointer;
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      if (*(int *)(*(int *)((int)pvVar2 + iVar1 * 4) + 0x34) < DAT_01ead288) {
        FUN_016f3809(&DAT_01ead288);
        if (DAT_01ead288 == -1) {
          DAT_01ead27c = FUN_0057bbb0;
          _DAT_01ead280 = FUN_005880a0;
          DAT_01ead284 = FUN_0057d5e0;
          FUN_016f37bf(&DAT_01ead288);
        }
      }
      param_1[1] = &DAT_01ead27c;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
    }
    else {
      FUN_005caf00(&iStack_ec);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
    }
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00550130("Can\'t parse JSON");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 19390 ; VA 0x009e5dd0 ; FUN_009e5dd0 */

void FUN_009e5dd0(void)

{
  FUN_009eb5d0(DAT_018cf108);
  return;
}



/* FUNCTION 19391 ; VA 0x009e5df0 ; FUN_009e5df0 */

undefined * FUN_009e5df0(undefined *param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  undefined auStack_20 [12];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7b61;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_14 = 1;
  cVar1 = FUN_0098fc00(&param_2,param_1,1);
  if (cVar1 != '\0') {
    uStack_8 = 2;
    if (param_3 != 0) {
      (**(code **)(param_3 + 8))(&stack0x00000010);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00550130("Can\'t convert to JSON");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 19392 ; VA 0x009e5ea0 ; FUN_009e5ea0 */

undefined __thiscall FUN_009e5ea0(int param_1,int *param_2,uint param_3)

{
  byte bVar1;
  bool bVar2;
  undefined4 *puVar3;
  char cVar4;
  char cVar5;
  undefined uVar6;
  uint uVar7;
  int *****pppppiVar8;
  int iVar9;
  int *piVar10;
  int iVar11;
  uint uVar12;
  int *****pppppiVar13;
  int *piVar14;
  undefined4 *puVar15;
  byte *pbVar16;
  int ******ppppppiVar17;
  char in_stack_00000028;
  undefined uStack0000002b;
  char *pcVar18;
  undefined auStack_8c [4];
  undefined4 uStack_88;
  int *piStack_84;
  int *****pppppiStack_80;
  int *****pppppiStack_7c;
  int *****pppppiStack_78;
  int *****pppppiStack_6c;
  int ****ppppiStack_68;
  int ****ppppiStack_64;
  int ****ppppiStack_60;
  int ****ppppiStack_5c;
  undefined4 *puStack_58;
  int *****pppppiStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  uint uStack_40;
  int *piStack_38;
  int ****ppppiStack_34;
  int *piStack_30;
  int iStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  byte *pbStack_20;
  byte *pbStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017d7b98;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (*(int *)(param_1 + 0xe4) != *(int *)(param_1 + 0xe8)) {
    piStack_84 = (int *)(param_1 + 0x114);
    pppppiStack_80 = *(int ******)(param_1 + 0x124);
    pppppiStack_7c = (int *****)&DAT_01d654d8;
    if (0xf < DAT_01d654ec) {
      pppppiStack_7c = (int *****)DAT_01d654d8;
    }
    if (0xf < *(uint *)(param_1 + 0x128)) {
      piStack_84 = (int *)*piStack_84;
    }
    pppppiStack_78 = (int *****)DAT_01d654e8;
    uStack_88 = 0x9e5f09;
    ExceptionList = &pvStack_10;
    cVar4 = FUN_0055c360();
    if (cVar4 != '\0') goto LAB_009e5f17;
  }
  pppppiStack_78 = (int *****)0x9e5f17;
  FUN_009e4720();
LAB_009e5f17:
  iVar9 = *param_2;
  if (*(int *)(iVar9 + 8) == 0) {
    puStack_18 = (undefined4 *)0x0;
  }
  else {
    puStack_18 = *(undefined4 **)(*(int *)(iVar9 + 0x14) + *(int *)(iVar9 + 4) * 4);
  }
  do {
    if (puStack_18 == (undefined4 *)0x0) {
      uStack0000002b = 1;
LAB_009e65fb:
      uStack_8 = 10;
      if (((param_3 != 0) && ((param_3 & 1) == 0)) &&
         (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
        pppppiStack_80 = (int *****)&stack0x00000010;
        pppppiStack_78 = (int *****)0x2;
        piStack_84 = (int *)0x9e661f;
        pppppiStack_7c = pppppiStack_80;
        (**(code **)(param_3 & 0xfffffffe))();
      }
      ExceptionList = pvStack_10;
      return uStack0000002b;
    }
    puVar15 = *(undefined4 **)(param_1 + 0xe4);
    puStack_24 = puVar15;
    if (puVar15 != *(undefined4 **)(iStack_14 + 0xe8)) {
      pbStack_1c = (byte *)(puStack_18 + 2);
      do {
        pppppiStack_78 = (int *****)0x1;
        uStack_8._0_1_ = 1;
        pppppiStack_7c = (int *****)0x9e5f6b;
        puStack_24 = puVar15;
        piStack_38 = (int *)FUN_016de181();
        uStack_8._0_1_ = 3;
        pppppiStack_78 = (int *****)0x9e5f7f;
        piStack_30 = piStack_38;
        (**(code **)(*piStack_38 + 4))();
        uStack_8._0_1_ = 4;
        puStack_28 = puVar15;
        if (0xf < (uint)puVar15[5]) {
          puStack_28 = (undefined4 *)*puVar15;
        }
        puStack_28 = (undefined4 *)(puVar15[4] + (int)puStack_28);
        if (0xf < (uint)puVar15[5]) {
          puVar15 = (undefined4 *)*puVar15;
        }
        pbStack_20 = pbStack_1c;
        if (0xf < *(uint *)(pbStack_1c + 0x14)) {
          pbStack_20 = *(byte **)pbStack_1c;
        }
        pbStack_20 = pbStack_20 + *(int *)(pbStack_1c + 0x10);
        pbVar16 = pbStack_1c;
        if (0xf < *(uint *)(pbStack_1c + 0x14)) {
          pbVar16 = *(byte **)pbStack_1c;
        }
        if (puVar15 != puStack_28) {
          do {
            if (pbVar16 == pbStack_20) goto LAB_009e6000;
            pppppiStack_7c =
                 (int *****)CONCAT31((int3)((uint)pbStack_20 >> 8),*(undefined *)puVar15);
            pppppiStack_78 = &ppppiStack_34;
            pppppiStack_80 = (int *****)0x9e5fd4;
            cVar4 = FUN_00564a80();
            piStack_84 = (int *)(uint)*pbVar16;
            pppppiStack_80 = &ppppiStack_34;
            uStack_88 = 0x9e5fe4;
            cVar5 = FUN_00564a80();
            piVar14 = piStack_38;
            if (cVar4 != cVar5) {
              uStack_8 = CONCAT31(uStack_8._1_3_,5);
              pppppiStack_78 = (int *****)0x9e60c8;
              puVar15 = (undefined4 *)(**(code **)(*piStack_38 + 8))();
              if (puVar15 != (undefined4 *)0x0) {
                pppppiStack_78 = (int *****)0x1;
                pppppiStack_7c = (int *****)0x9e60d6;
                (**(code **)*puVar15)();
              }
              bVar2 = false;
              goto LAB_009e602a;
            }
            puVar15 = (undefined4 *)((int)puVar15 + 1);
            pbVar16 = pbVar16 + 1;
          } while (puVar15 != puStack_28);
        }
        if (pbVar16 == pbStack_20) {
LAB_009e6000:
          bVar2 = true;
          if (puVar15 != puStack_28) goto LAB_009e6008;
        }
        else {
LAB_009e6008:
          bVar2 = false;
        }
        piVar14 = piStack_38;
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        pppppiStack_78 = (int *****)0x9e601c;
        puVar15 = (undefined4 *)(**(code **)(*piStack_38 + 8))();
        if (puVar15 != (undefined4 *)0x0) {
          pppppiStack_78 = (int *****)0x1;
          pppppiStack_7c = (int *****)0x9e602a;
          (**(code **)*puVar15)();
        }
LAB_009e602a:
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        pppppiStack_78 = (int *****)0x9e6037;
        puVar15 = (undefined4 *)(**(code **)(*piVar14 + 8))();
        if (puVar15 != (undefined4 *)0x0) {
          pppppiStack_78 = (int *****)0x1;
          pppppiStack_7c = (int *****)0x9e6045;
          (**(code **)*puVar15)();
        }
        uStack_8._0_1_ = 0;
        if (bVar2) {
          puVar15 = puStack_18 + 2;
          if (0xf < (uint)puStack_18[7]) {
            puVar15 = (undefined4 *)*puVar15;
          }
          pcVar18 = "Header \"%s\" is not allowed!";
          goto LAB_009e65e0;
        }
        puVar15 = puStack_24 + 6;
        puStack_24 = puVar15;
      } while (puVar15 != *(undefined4 **)(iStack_14 + 0xe8));
    }
    puVar3 = puStack_18;
    if (in_stack_00000028 == '\0') {
      puVar15 = puStack_18 + 2;
      puStack_24 = (undefined4 *)puStack_18[6];
      puStack_44 = (undefined4 *)0x0;
      uStack_40 = 0;
      if (0xf < (uint)puStack_18[7]) {
        puVar15 = (undefined4 *)*puVar15;
      }
      if (&DAT_0000000f < puStack_24) {
        param_2 = (int *)((uint)puStack_24 | 0xf);
        if (0x7fffffff < param_2) {
          param_2 = (int *)0x7fffffff;
        }
        pppppiStack_78 = (int *****)((int)param_2 + 1);
        if (pppppiStack_78 < 0x1000) {
          if (pppppiStack_78 == (int *****)0x0) {
            pppppiStack_80 = (int *****)0x0;
          }
          else {
            pppppiStack_7c = (int *****)0x9e6126;
            pppppiStack_80 = (int *****)FUN_01674e20();
          }
        }
        else {
          uVar7 = (int)param_2 + 0x24;
          if (uVar7 <= pppppiStack_78) {
            uVar7 = 0xffffffff;
          }
          pppppiStack_7c = (int *****)0x9e6106;
          pppppiStack_78 = (int *****)uVar7;
          pppppiVar8 = (int *****)FUN_01674e20();
          if (pppppiVar8 == (int *****)0x0) goto LAB_009e6637;
          pppppiStack_80 = (int *****)((int)pppppiVar8 + 0x23U & 0xffffffe0);
          ((int ******)pppppiStack_80)[-1] = pppppiVar8;
        }
        pppppiStack_78 = (int *****)((int)puStack_24 + 1);
        piStack_84 = (int *)0x9e613e;
        pppppiStack_7c = (int *****)puVar15;
        pppppiStack_54 = pppppiStack_80;
        FUN_0170c6f0();
      }
      else {
        param_2 = (int *)0xf;
        pppppiStack_54 = (int *****)*puVar15;
        uStack_50 = puVar15[1];
        uStack_4c = puVar15[2];
        uStack_48 = puVar15[3];
      }
      uStack_40 = (uint)param_2;
      puStack_44 = puStack_24;
      puVar15 = (undefined4 *)0x0;
      uStack_8._0_1_ = 8;
      if (puStack_24 != (undefined4 *)0x0) {
        do {
          ppppppiVar17 = &pppppiStack_54;
          if (0xf < uStack_40) {
            ppppppiVar17 = (int ******)pppppiStack_54;
          }
          pppppiStack_78 = (int *****)(uint)*(byte *)((int)ppppppiVar17 + (int)puVar15);
          pppppiStack_7c = (int *****)0x9e6174;
          iVar9 = FUN_0171dc5a();
          if (iVar9 != 0) {
            ppppppiVar17 = &pppppiStack_54;
            if (0xf < uStack_40) {
              ppppppiVar17 = (int ******)pppppiStack_54;
            }
            pppppiStack_78 = (int *****)(uint)*(byte *)((int)ppppppiVar17 + (int)puVar15);
            pppppiStack_7c = (int *****)0x9e6190;
            uVar6 = FUN_01725677();
            ppppppiVar17 = &pppppiStack_54;
            if (0xf < uStack_40) {
              ppppppiVar17 = (int ******)pppppiStack_54;
            }
            *(undefined *)((int)ppppppiVar17 + (int)puVar15) = uVar6;
          }
          puVar15 = (undefined4 *)((int)puVar15 + 1);
        } while (puVar15 < puStack_44);
      }
      uVar7 = uStack_40;
      iVar9 = iStack_14 + 0xf1 + (uint)*(byte *)(iStack_14 + 0xf0);
      pppppiStack_78 = (int *****)&pppppiStack_54;
      pppppiStack_80 = (int *****)0x9e61ce;
      pppppiStack_7c = (int *****)iVar9;
      pppppiStack_80 = (int *****)FUN_0055c740();
      pppppiStack_7c = (int *****)&pppppiStack_54;
      pppppiStack_78 = (int *****)(-(uint)(iVar9 != 0) & iVar9 + 1U);
      piStack_84 = &iStack_2c;
      uStack_88 = 0x9e61f2;
      FUN_00562fc0();
      if (iStack_2c == 0) {
        uStack_8._0_1_ = 0;
        if (0xf < uVar7) {
          pppppiStack_78 = (int *****)(uVar7 + 1);
          ppppppiVar17 = (int ******)pppppiStack_54;
          if ((undefined4 *)0xfff < pppppiStack_78) {
            ppppppiVar17 = (int ******)pppppiStack_54[-1];
            pppppiStack_78 = (int *****)(uVar7 + 0x24);
            if (0x1f < (uint)((int)pppppiStack_54 + (-4 - (int)ppppppiVar17))) goto LAB_009e6637;
          }
          pppppiStack_80 = (int *****)0x9e6233;
          pppppiStack_7c = (int *****)ppppppiVar17;
          FUN_01674ea0();
        }
        goto LAB_009e6236;
      }
      puVar15 = puVar3 + 2;
      if (0xf < (uint)puVar3[7]) {
        puVar15 = (undefined4 *)*puVar15;
      }
      FUN_01675640(auStack_8c,"Header \"%s\" is not allowed!",puVar15);
      FUN_005e65e0();
      uStack_8._0_1_ = 0;
      if (uStack_40 < 0x10) {
LAB_009e65f1:
        uStack0000002b = 0;
      }
      else {
        pppppiStack_78 = (int *****)(uStack_40 + 1);
        ppppppiVar17 = (int ******)pppppiStack_54;
        if (0xfff < pppppiStack_78) {
          ppppppiVar17 = (int ******)pppppiStack_54[-1];
          pppppiStack_78 = (int *****)(uStack_40 + 0x24);
          if (0x1f < (uint)((int)pppppiStack_54 + (-4 - (int)ppppppiVar17))) goto LAB_009e6637;
        }
        pppppiStack_80 = (int *****)0x9e64d0;
        pppppiStack_7c = (int *****)ppppppiVar17;
        FUN_01674ea0();
        uStack0000002b = 0;
      }
      goto LAB_009e65fb;
    }
LAB_009e6236:
    uVar7 = puVar3[6];
    if (0x1180 < uVar7) {
      puVar15 = (undefined4 *)0x1180;
      pcVar18 = "Length of supplied header is too long. Maximum length is %d characters.";
LAB_009e65e0:
      FUN_01675640(auStack_8c,pcVar18,puVar15);
      FUN_005e65e0();
      goto LAB_009e65f1;
    }
    uVar12 = 0;
    if (uVar7 != 0) {
      piVar14 = puVar3 + 2;
      do {
        piVar10 = piVar14;
        if (0xf < (uint)puVar3[7]) {
          piVar10 = (int *)*piVar14;
        }
        bVar1 = *(byte *)((int)piVar10 + uVar12);
        if ((((bVar1 < 0x41) || (0x5a < bVar1)) && ((bVar1 < 0x61 || (0x7a < bVar1)))) &&
           (((bVar1 < 0x30 || (0x39 < bVar1)) && (bVar1 != 0x2d)))) {
          if (0xf < (uint)puVar3[7]) {
            piVar14 = (int *)*piVar14;
          }
          FUN_01675640(auStack_8c,"Header \"%s\" has unallowed character \"%c\"",piVar14,bVar1);
          FUN_005e65e0();
          uStack0000002b = 0;
          goto LAB_009e65fb;
        }
        uVar12 = uVar12 + 1;
      } while (uVar12 < uVar7);
    }
    iVar9 = puVar3[8];
    pppppiStack_78 = (int *****)0x9e628a;
    iVar11 = FUN_0088cb40();
    if (iVar9 != iVar11) {
      puVar15 = puVar3 + 2;
      if (0xf < (uint)puVar3[7]) {
        puVar15 = (undefined4 *)*puVar15;
      }
      pcVar18 = "Header \"%s\" must have its value be a string!";
      goto LAB_009e65e0;
    }
    iVar9 = puVar3[8];
    pppppiStack_78 = (int *****)0x9e629a;
    iVar11 = FUN_0088cb40();
    if (iVar9 != iVar11) {
      pppppiStack_78 = (int *****)0x18c072c;
                    /* WARNING: Subroutine does not return */
      pppppiStack_7c = (int *****)&UNK_009e664b;
      FUN_016757c0();
    }
    ppppiStack_5c = (int ****)0x0;
    ppppppiVar17 = (int ******)(puVar3 + 10);
    puStack_58 = (undefined4 *)0x0;
    if (puVar3[9] == 0) {
      ppppppiVar17 = (int ******)0x0;
    }
    pppppiVar8 = ppppppiVar17[4];
    if ((int *****)0xf < ppppppiVar17[5]) {
      ppppppiVar17 = (int ******)*ppppppiVar17;
    }
    if (pppppiVar8 < (int *****)0x10) {
      pppppiStack_6c = *ppppppiVar17;
      ppppiStack_68 = (int ****)ppppppiVar17[1];
      ppppiStack_64 = (int ****)ppppppiVar17[2];
      ppppiStack_60 = (int ****)ppppppiVar17[3];
      puStack_58 = (undefined4 *)&DAT_0000000f;
    }
    else {
      puStack_28 = (undefined4 *)((uint)pppppiVar8 | 0xf);
      if ((undefined4 *)0x7fffffff < puStack_28) {
        puStack_28 = (undefined4 *)0x7fffffff;
      }
      pppppiStack_78 = (int *****)((int)puStack_28 + 1);
      if (pppppiStack_78 < &DAT_00001000) {
        if (pppppiStack_78 == (int *****)0x0) {
          pppppiStack_80 = (int *****)0x0;
        }
        else {
          pppppiStack_7c = (int *****)0x9e6331;
          pppppiStack_80 = (int *****)FUN_01674e20();
        }
      }
      else {
        puVar15 = puStack_28 + 9;
        if (puVar15 <= pppppiStack_78) {
          puVar15 = (undefined4 *)0xffffffff;
        }
        pppppiStack_7c = (int *****)0x9e630e;
        pppppiStack_78 = (int *****)puVar15;
        pppppiVar13 = (int *****)FUN_01674e20();
        if (pppppiVar13 == (int *****)0x0) goto LAB_009e6637;
        pppppiStack_80 = (int *****)((int)pppppiVar13 + 0x23U & 0xffffffe0);
        ((int ******)pppppiStack_80)[-1] = pppppiVar13;
      }
      pppppiStack_78 = (int *****)((int)pppppiVar8 + 1);
      piStack_84 = (int *)0x9e634b;
      pppppiStack_7c = (int *****)ppppppiVar17;
      pppppiStack_6c = pppppiStack_80;
      FUN_0170c6f0();
      puStack_58 = puStack_28;
    }
    ppppiStack_5c = (int ****)pppppiVar8;
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if ((int *****)0x1180 < pppppiVar8) {
      puVar15 = puVar3 + 2;
      if (0xf < (uint)puVar3[7]) {
        puVar15 = (undefined4 *)*puVar15;
      }
      FUN_01675640(auStack_8c,"Header \"%s\" has a value too long. Maximum length is %d characters."
                   ,puVar15,0x1180);
LAB_009e6561:
      FUN_005e65e0();
      uStack_8 = uStack_8 & 0xffffff00;
      if (&DAT_0000000f < puStack_58) {
        pppppiStack_78 = (int *****)((int)puStack_58 + 1);
        ppppppiVar17 = (int ******)pppppiStack_6c;
        if ((undefined4 *)0xfff < pppppiStack_78) {
          ppppppiVar17 = (int ******)pppppiStack_6c[-1];
          pppppiStack_78 = (int *****)(puStack_58 + 9);
          if (0x1f < (uint)((int)pppppiStack_6c + (-4 - (int)ppppppiVar17))) {
                    /* WARNING: Subroutine does not return */
            pppppiStack_78 = (int *****)0x9e6641;
            FUN_017167a3();
          }
        }
        pppppiStack_80 = (int *****)0x9e659e;
        pppppiStack_7c = (int *****)ppppppiVar17;
        FUN_01674ea0();
      }
      ppppiStack_5c = (int ****)0x0;
      puStack_58 = (undefined4 *)&DAT_0000000f;
      pppppiStack_6c = (int *****)((uint)pppppiStack_6c & 0xffffff00);
      uStack0000002b = 0;
      goto LAB_009e65fb;
    }
    pppppiVar13 = (int *****)0x0;
    if (pppppiVar8 != (int *****)0x0) {
      do {
        ppppppiVar17 = &pppppiStack_6c;
        if (&DAT_0000000f < puStack_58) {
          ppppppiVar17 = (int ******)pppppiStack_6c;
        }
        bVar1 = *(byte *)((int)pppppiVar13 + (int)ppppppiVar17);
        if (((((bVar1 < 0x41) || (0x5a < bVar1)) &&
             ((((bVar1 < 0x61 || (0x7a < bVar1)) &&
               (((bVar1 < 0x30 || (0x39 < bVar1)) && (bVar1 != 0x2d)))) &&
              ((((bVar1 != 0x21 && (bVar1 != 0x40)) && (bVar1 != 0x23)) &&
               ((bVar1 != 0x24 && (bVar1 != 0x5e)))))))) &&
            (((bVar1 != 0x26 && ((bVar1 != 0x2a && (bVar1 != 0x28)))) &&
             ((bVar1 != 0x29 &&
              ((((bVar1 != 0x22 && (bVar1 != 0x27)) && (bVar1 != 0x2e)) &&
               ((bVar1 != 0x2c && (bVar1 != 0x3a)))))))))) &&
           ((((bVar1 != 0x3b && ((bVar1 != 0x2f && (bVar1 != 0x3d)))) && (bVar1 != 0x2b)) &&
            ((bVar1 != 0x20 && (bVar1 != 0x5f)))))) {
          ppppppiVar17 = &pppppiStack_6c;
          if (&DAT_0000000f < puStack_58) {
            ppppppiVar17 = (int ******)pppppiStack_6c;
          }
          puVar15 = puVar3 + 2;
          if (0xf < (uint)puVar3[7]) {
            puVar15 = (undefined4 *)*puVar15;
          }
          FUN_01675640(auStack_8c,"Header \"%s\" has unallowed character \"%c\" in value \"%s\"",
                       puVar15,bVar1,ppppppiVar17);
          goto LAB_009e6561;
        }
        pppppiVar13 = (int *****)((int)pppppiVar13 + 1);
      } while (pppppiVar13 < pppppiVar8);
    }
    uStack_8._0_1_ = 0;
    if (&DAT_0000000f < puStack_58) {
      pppppiStack_78 = (int *****)((int)puStack_58 + 1);
      ppppppiVar17 = (int ******)pppppiStack_6c;
      if ((undefined4 *)0xfff < pppppiStack_78) {
        ppppppiVar17 = (int ******)pppppiStack_6c[-1];
        pppppiStack_78 = (int *****)(puStack_58 + 9);
        if (0x1f < (uint)((int)pppppiStack_6c + (-4 - (int)ppppppiVar17))) {
LAB_009e6637:
                    /* WARNING: Subroutine does not return */
          pppppiStack_78 = (int *****)0x9e663c;
          FUN_017167a3();
        }
      }
      pppppiStack_80 = (int *****)0x9e643a;
      pppppiStack_7c = (int *****)ppppppiVar17;
      FUN_01674ea0();
    }
    puStack_18 = (undefined4 *)*puVar3;
    param_1 = iStack_14;
  } while( true );
}



/* FUNCTION 19393 ; VA 0x009e6650 ; FUN_009e6650 */

/* WARNING: Removing unreachable block (ram,0x009e671e) */
/* WARNING: Removing unreachable block (ram,0x009e675d) */

void __thiscall FUN_009e6650(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined *puVar7;
  undefined uVar8;
  int iVar9;
  uint uVar10;
  uint in_stack_0000002c;
  undefined4 uStack_2cc;
  undefined4 *puStack_2c8;
  undefined auStack_2c4 [200];
  undefined4 uStack_1fc;
  int iStack_1f8;
  undefined auStack_1f4 [200];
  undefined4 uStack_12c;
  int iStack_128;
  undefined auStack_124 [200];
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined uStack_44;
  undefined auStack_38 [4];
  undefined4 uStack_34;
  undefined4 uStack_30;
  int aiStack_2c [3];
  undefined auStack_20 [8];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_3;
  puStack_c = &LAB_017d7c0f;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar5 = (**(code **)*param_3)();
  if (uVar5 < 5) {
LAB_009e6770:
    puVar1 = *(undefined4 **)(param_1 + 0x50);
    if (puVar1 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_38,"Argument %d missing or nil",5);
      puVar7 = auStack_38;
      goto LAB_009e6ac7;
    }
    uStack_2cc = *puVar1;
    puStack_2c8 = (undefined4 *)0x0;
    puVar2 = (undefined4 *)puVar1[1];
    param_1 = iStack_14;
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)(puVar1 + 2,auStack_2c4);
      param_1 = iStack_14;
      puVar2 = (undefined4 *)puVar1[1];
    }
  }
  else {
    FUN_00888530();
    uStack_8._0_1_ = 2;
    uStack_1fc = FUN_00888530();
    iStack_1f8 = 0;
    uStack_8._0_1_ = 4;
    cVar4 = (**(code **)(*piVar3 + 4))(5,&uStack_1fc);
    if (cVar4 == '\0') {
      uStack_8._0_1_ = 7;
      if (iStack_1f8 != 0) {
        (**(code **)(iStack_1f8 + 8))(auStack_1f4);
      }
      uStack_8._0_1_ = 1;
      goto LAB_009e6770;
    }
    uVar6 = FUN_0054eb90();
    FUN_0056a440(uVar6);
    uStack_8._0_1_ = 5;
    puVar2 = puStack_2c8;
    if (iStack_1f8 != 0) {
      (**(code **)(iStack_1f8 + 8))(auStack_1f4);
      puVar2 = puStack_2c8;
    }
  }
  puStack_2c8 = puVar2;
  uStack_8._0_1_ = 9;
  uVar5 = (**(code **)*piVar3)();
  if (uVar5 < 4) {
LAB_009e684d:
    if (*(undefined **)(param_1 + 0x4c) != (undefined *)0x0) {
      uVar8 = **(undefined **)(param_1 + 0x4c);
      goto LAB_009e685a;
    }
    uVar6 = 4;
  }
  else {
    uStack_12c = FUN_00888530();
    iStack_128 = 0;
    uStack_8._0_1_ = 10;
    cVar4 = (**(code **)(*piVar3 + 4))(4,&uStack_12c);
    if (cVar4 == '\0') {
      uStack_8._0_1_ = 0xc;
      if (iStack_128 != 0) {
        (**(code **)(iStack_128 + 8))(auStack_124);
      }
      uStack_8._0_1_ = 9;
      goto LAB_009e684d;
    }
    puVar7 = (undefined *)FUN_0088bcc0();
    param_3 = (int *)CONCAT13(*puVar7,param_3._0_3_);
    uStack_8._0_1_ = 0xb;
    uVar8 = *puVar7;
    if (iStack_128 != 0) {
      (**(code **)(iStack_128 + 8))(auStack_124);
      uVar8 = param_3._3_1_;
    }
    uStack_8._0_1_ = 9;
LAB_009e685a:
    param_3 = (int *)CONCAT13(uVar8,param_3._0_3_);
    iStack_14 = FUN_009e77b0(piVar3,param_1 + 0x48);
    uVar5 = (**(code **)*piVar3)();
    if (1 < uVar5) {
      uStack_34 = 0;
      uStack_30 = 0xf;
      uStack_44 = 0;
      uStack_8._0_1_ = 0xd;
      uStack_12c = FUN_00888530();
      iStack_128 = 0;
      uStack_8._0_1_ = 0xe;
      cVar4 = (**(code **)(*piVar3 + 4))(2,&uStack_12c);
      if (cVar4 != '\0') {
        uVar6 = FUN_008898b0();
        FUN_0054ef60(uVar6);
        uStack_8._0_1_ = 0xf;
        if (iStack_128 != 0) {
          (**(code **)(iStack_128 + 8))(auStack_124);
        }
        FUN_005507b0();
        goto LAB_009e693b;
      }
      uStack_8._0_1_ = 0x10;
      if (iStack_128 != 0) {
        (**(code **)(iStack_128 + 8))(auStack_124);
      }
      uStack_8._0_1_ = 9;
      FUN_005507b0();
    }
    if (*(int *)(param_1 + 0x44) != 0) {
      FUN_0054ef60(*(int *)(param_1 + 0x44));
LAB_009e693b:
      uStack_8._0_1_ = 0x11;
      uVar6 = FUN_008cca80(auStack_5c,piVar3,param_1 + 0x40);
      uStack_8._0_1_ = 0x12;
      FUN_009e4020(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),uVar6,
                   aiStack_2c,&iStack_14,(int)&param_3 + 3,&uStack_2cc,&param_4,&stack0x0000002c);
      uStack_8._0_1_ = 0x11;
      uVar8 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x11;
      if (0xf < uStack_48) {
        uVar10 = uStack_48 + 1;
        uVar5 = auStack_5c[0];
        if (0xfff < uVar10) {
          uVar5 = *(uint *)(auStack_5c[0] - 4);
          uVar10 = uStack_48 + 0x24;
          if (0x1f < (auStack_5c[0] - uVar5) - 4) {
            uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar5,uVar10);
      }
      uStack_4c = 0;
      uStack_48 = 0xf;
      auStack_5c[0] = auStack_5c[0] & 0xffffff00;
      uStack_8._0_1_ = 9;
      uVar8 = (undefined)uStack_8;
      uStack_8._0_1_ = 9;
      if (0xf < uStack_18) {
        uVar5 = uStack_18 + 1;
        iVar9 = aiStack_2c[0];
        if (0xfff < uVar5) {
          iVar9 = *(int *)(aiStack_2c[0] + -4);
          uVar5 = uStack_18 + 0x24;
          if (0x1f < (aiStack_2c[0] - iVar9) - 4U) {
            uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar9,uVar5);
      }
      uStack_8._0_1_ = 0x13;
      if (puStack_2c8 != (undefined4 *)0x0) {
        (*(code *)puStack_2c8[2])(auStack_2c4);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
      if (param_4 != 0) {
        if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
        }
        param_4 = 0;
      }
      uStack_8 = 0x15;
      if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
         (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
      }
      ExceptionList = pvStack_10;
      return;
    }
    uVar6 = 2;
  }
  FUN_016756b0(auStack_20,"Argument %d missing or nil",uVar6);
  puVar7 = auStack_20;
LAB_009e6ac7:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(puVar7,&DAT_01c17198);
}



/* FUNCTION 19394 ; VA 0x009e6ad0 ; FUN_009e6ad0 */

/* WARNING: Removing unreachable block (ram,0x009e6b9e) */
/* WARNING: Removing unreachable block (ram,0x009e6bdd) */

void __thiscall FUN_009e6ad0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined *puVar7;
  undefined uVar8;
  uint uVar9;
  uint in_stack_0000002c;
  undefined4 uStack_2b4;
  undefined4 *puStack_2b0;
  undefined auStack_2ac [200];
  undefined4 uStack_1e4;
  int iStack_1e0;
  undefined auStack_1dc [200];
  undefined4 uStack_114;
  int iStack_110;
  undefined auStack_10c [200];
  undefined auStack_44 [12];
  undefined auStack_38 [12];
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_3;
  puStack_c = &LAB_017d7c64;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar5 = (**(code **)*param_3)();
  if (uVar5 < 3) {
LAB_009e6bf0:
    puVar1 = *(undefined4 **)(param_1 + 0x48);
    if (puVar1 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_44,"Argument %d missing or nil",3);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_44,&DAT_01c17198);
    }
    uStack_2b4 = *puVar1;
    puStack_2b0 = (undefined4 *)0x0;
    puVar2 = (undefined4 *)puVar1[1];
    param_1 = iStack_14;
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)(puVar1 + 2,auStack_2ac);
      param_1 = iStack_14;
      puVar2 = (undefined4 *)puVar1[1];
    }
  }
  else {
    FUN_00888530();
    uStack_8._0_1_ = 2;
    uStack_114 = FUN_00888530();
    iStack_110 = 0;
    uStack_8._0_1_ = 4;
    cVar4 = (**(code **)(*piVar3 + 4))(3,&uStack_114);
    if (cVar4 == '\0') {
      uStack_8._0_1_ = 7;
      if (iStack_110 != 0) {
        (**(code **)(iStack_110 + 8))(auStack_10c);
      }
      uStack_8._0_1_ = 1;
      goto LAB_009e6bf0;
    }
    uVar6 = FUN_0054eb90();
    FUN_0056a440(uVar6);
    uStack_8._0_1_ = 5;
    puVar2 = puStack_2b0;
    if (iStack_110 != 0) {
      (**(code **)(iStack_110 + 8))(auStack_10c);
      puVar2 = puStack_2b0;
    }
  }
  puStack_2b0 = puVar2;
  uStack_8._0_1_ = 9;
  uVar5 = (**(code **)*piVar3)();
  if (1 < uVar5) {
    uStack_1e4 = FUN_00888530();
    iStack_1e0 = 0;
    uStack_8._0_1_ = 10;
    cVar4 = (**(code **)(*piVar3 + 4))(2,&uStack_1e4);
    if (cVar4 != '\0') {
      puVar7 = (undefined *)FUN_0088bcc0();
      param_3 = (int *)CONCAT13(*puVar7,param_3._0_3_);
      uStack_8._0_1_ = 0xb;
      uVar8 = *puVar7;
      if (iStack_1e0 != 0) {
        (**(code **)(iStack_1e0 + 8))(auStack_1dc);
        uVar8 = param_3._3_1_;
      }
      uStack_8._0_1_ = 9;
      goto LAB_009e6cda;
    }
    uStack_8._0_1_ = 0xc;
    if (iStack_1e0 != 0) {
      (**(code **)(iStack_1e0 + 8))(auStack_1dc);
    }
    uStack_8._0_1_ = 9;
  }
  if (*(undefined **)(param_1 + 0x44) == (undefined *)0x0) {
    FUN_016756b0(auStack_38,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_38,&DAT_01c17198);
  }
  uVar8 = **(undefined **)(param_1 + 0x44);
LAB_009e6cda:
  param_3 = (int *)CONCAT13(uVar8,param_3._0_3_);
  uVar6 = FUN_008cca80(auStack_2c,piVar3,param_1 + 0x40);
  uStack_8._0_1_ = 0xd;
  FUN_009e3eb0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),uVar6,
               (int)&param_3 + 3,&uStack_2b4,&param_4,&stack0x0000002c);
  uStack_8._0_1_ = 9;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_18) {
    uVar9 = uStack_18 + 1;
    uVar5 = auStack_2c[0];
    if (0xfff < uVar9) {
      uVar5 = *(uint *)(auStack_2c[0] - 4);
      uVar9 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar5) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar9);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8._0_1_ = 0xe;
  if (puStack_2b0 != (undefined4 *)0x0) {
    (*(code *)puStack_2b0[2])(auStack_2ac);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 0x10;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19395 ; VA 0x009e6e30 ; FUN_009e6e30 */

void __thiscall FUN_009e6e30(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint in_stack_0000002c;
  undefined4 uStack_f4;
  int iStack_f0;
  undefined auStack_ec [200];
  undefined auStack_24 [4];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7c9b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_3)();
  if (iVar3 != 0) {
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8._0_1_ = 2;
    uStack_f4 = FUN_00888530();
    iStack_f0 = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*param_3 + 4))(1,&uStack_f4);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_00887bf0();
      piVar5 = (int *)puVar4[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)puVar4[1];
      }
      uStack_18 = *puVar4;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      piStack_14 = piVar5;
      if (iStack_f0 != 0) {
        (**(code **)(iStack_f0 + 8))(auStack_ec);
      }
      FUN_00550b30();
      goto LAB_009e6f40;
    }
    uStack_8._0_1_ = 5;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(auStack_ec);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00550b30();
  }
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_24,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  piVar5 = (int *)puVar4[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)puVar4[1];
  }
  uStack_18 = *puVar4;
  piStack_14 = piVar5;
LAB_009e6f40:
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_009e3d00(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19396 ; VA 0x009e7010 ; FUN_009e7010 */

undefined4 __thiscall FUN_009e7010(int param_1,int param_2,undefined4 param_3,int param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  undefined4 uStack_1f8;
  undefined4 *puStack_1f4;
  undefined auStack_1f0 [168];
  undefined4 uStack_148;
  undefined *puStack_144;
  undefined4 uStack_140;
  int iStack_13c;
  undefined4 uStack_138;
  int iStack_134;
  int iStack_130;
  undefined4 uStack_12c;
  undefined auStack_11c [4];
  int iStack_118;
  undefined auStack_114 [200];
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined *puStack_34;
  code *pcStack_30;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017d7cc3;
  pvStack_1c = ExceptionList;
  uStack_12c = param_3;
  iStack_130 = 0x9e704f;
  ExceptionList = &pvStack_1c;
  iStack_134 = FUN_01256300();
  iStack_130 = param_1 + 0x40;
  iStack_134 = iStack_134 - param_4;
  uStack_138 = 1;
  iStack_13c = param_4;
  puStack_144 = auStack_11c;
  uStack_140 = param_3;
  uStack_148 = 0x9e7069;
  puVar2 = (undefined4 *)FUN_009d1540();
  pcStack_30 = *(code **)(param_1 + 0x38);
  puStack_34 = (undefined *)&uStack_1f8;
  iStack_24 = *(int *)(param_1 + 0x3c) + param_2;
  uStack_1f8 = *puVar2;
  puStack_1f4 = (undefined4 *)0x0;
  puVar3 = (undefined4 *)puVar2[1];
  iStack_14 = 0;
  puVar1 = &uStack_1f8;
  if (puVar3 != (undefined4 *)0x0) {
    (*(code *)*puVar3)(puVar2 + 2,auStack_1f0);
    puVar3 = (undefined4 *)puVar2[1];
    puVar1 = (undefined4 *)puStack_34;
  }
  puStack_34 = (undefined *)puVar1;
  puStack_1f4 = puVar3;
  uVar4 = (*pcStack_30)(auStack_4c);
  iStack_14._0_1_ = 1;
  uVar4 = FUN_009d5710(param_3,uVar4);
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  if (0xf < uStack_38) {
    uVar6 = uStack_38 + 1;
    uVar5 = auStack_4c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_4c[0] - 4);
      uVar6 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  iStack_14 = 2;
  if (iStack_118 != 0) {
    (**(code **)(iStack_118 + 8))(auStack_114);
  }
  ExceptionList = pvStack_1c;
  return uVar4;
}



/* FUNCTION 19397 ; VA 0x009e7160 ; FUN_009e7160 */

undefined4 __thiscall FUN_009e7160(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar1 = FUN_009d1aa0(param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uVar3 = (**(code **)(param_1 + 0x38))(aiStack_28,uVar1);
  uStack_8 = 0;
  uVar3 = FUN_009d5710(param_3,uVar3);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 19398 ; VA 0x009e7210 ; FUN_009e7210 */

code * __thiscall FUN_009e7210(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017d7ce0;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined4 *)FUN_009d0ef0(auStack_38,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcStack_28 = *(code **)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = (*pcStack_28)(auStack_30,*puVar3,puVar3[1]);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  pcStack_28 = (code *)FUN_009d5980(param_3,uVar4);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return pcStack_28;
}



/* FUNCTION 19399 ; VA 0x009e7330 ; FUN_009e7330 */

undefined4 __thiscall FUN_009e7330(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined auStack_f8 [4];
  int iStack_f4;
  undefined auStack_f0 [200];
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbeb3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_28,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar3);
  uVar3 = (*pcVar1)(auStack_f8);
  uStack_8._0_1_ = 1;
  uVar3 = FUN_009d5a20(param_3,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_f4 != 0) {
    (**(code **)(iStack_f4 + 8))(auStack_f0);
  }
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 19400 ; VA 0x009e7420 ; FUN_009e7420 */

void FUN_009e7420(undefined4 param_1,int param_2,uint param_3)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 ***pppuVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  undefined auStack_54 [24];
  undefined4 **appuStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1ba0;
  pvStack_10 = ExceptionList;
  if (param_3 != 0) {
    uVar8 = 0;
    uVar7 = 1;
    ExceptionList = &pvStack_10;
    if (1 < param_3) {
      do {
        if ((*(char *)(param_2 + uVar7) == '\n') && (*(char *)(param_2 + -1 + uVar7) == '\r')) {
          uVar2 = (uVar7 - uVar8) - 1;
          uVar9 = param_3;
          if (uVar8 <= param_3) {
            uVar9 = uVar8;
          }
          uVar8 = param_3 - uVar9;
          if (uVar2 <= param_3 - uVar9) {
            uVar8 = uVar2;
          }
          iStack_14 = param_2 + uVar9;
          if ((((uVar8 != 0) && (iVar3 = FUN_0170db20(iStack_14,0x3a,uVar8), iVar3 != 0)) &&
              (uVar9 = iVar3 - iStack_14, uVar9 != 0xffffffff)) &&
             ((uVar9 != 0 && (uVar9 + 2 < uVar8)))) {
            iStack_1c = iStack_14;
            uStack_18 = uVar8;
            if (uVar9 <= uVar8) {
              uStack_18 = uVar9;
            }
            FUN_0058c4f0(auStack_54);
            uStack_8 = 0;
            for (; (cVar1 = *(char *)(iStack_14 + 1 + uVar9), cVar1 == ' ' || (cVar1 == '\t'));
                uVar9 = uVar9 + 1) {
            }
            uVar2 = uVar8;
            if (uVar9 + 1 <= uVar8) {
              uVar2 = uVar9 + 1;
            }
            iStack_20 = -1;
            if (uVar8 - uVar2 != -1) {
              iStack_20 = uVar8 - uVar2;
            }
            iStack_24 = uVar2 + iStack_14;
            FUN_0058c4f0(appuStack_3c);
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            FUN_005cd7e0(auStack_54);
            iVar4 = FUN_005c4c00(auStack_54);
            uVar5 = FUN_0088cb40();
            *(undefined4 *)(iVar4 + 0x18) = uVar5;
            iStack_14 = FUN_005c9d30();
            iVar3 = *(int *)(iVar4 + 0x1c);
            if (iVar3 == iStack_14) {
              if ((undefined4 ***)(iVar4 + 0x20) != appuStack_3c) {
                pppuVar6 = appuStack_3c;
                if (0xf < uStack_28) {
                  pppuVar6 = (undefined4 ***)appuStack_3c[0];
                }
                FUN_005542c0(pppuVar6,uStack_2c);
              }
            }
            else {
              if (iVar3 != 0) {
                (**(code **)(iVar3 + 8))(iVar4 + 0x20);
                *(undefined4 *)(iVar4 + 0x1c) = 0;
              }
              FUN_0054ef60(appuStack_3c);
              *(int *)(iVar4 + 0x1c) = iStack_14;
            }
            FUN_005507b0();
            uStack_8 = 0xffffffff;
            FUN_005507b0();
          }
          uVar8 = uVar7 + 1;
        }
        uVar7 = uVar7 + 1;
      } while (uVar7 < param_3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19401 ; VA 0x009e75f0 ; FUN_009e75f0 */

uint * FUN_009e75f0(uint *param_1,char param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  FUN_01531f50(param_1);
  if (param_2 == '\0') {
    uVar2 = param_1[4];
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = uStack_2c & 0xffffff00;
    if (uVar2 == 0) {
      FUN_00554050();
LAB_009e7704:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    puVar1 = param_1;
    if (0xf < param_1[5]) {
      puVar1 = (uint *)*param_1;
    }
    FUN_005542c0((undefined *)((int)puVar1 + 1),uVar2 - (2 - (uint)(uVar2 - 1 < uVar2 - 2)));
    if (param_1 != &uStack_2c) {
      FUN_005507b0();
      *param_1 = uStack_2c;
      param_1[1] = uStack_28;
      param_1[2] = uStack_24;
      param_1[3] = uStack_20;
      *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_18,uStack_1c);
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (0xf < uStack_18) {
      uVar3 = uStack_18 + 1;
      uVar2 = uStack_2c;
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(uStack_2c - 4);
        uVar3 = uStack_18 + 0x24;
        if (0x1f < (uStack_2c - uVar2) - 4) goto LAB_009e7704;
      }
      FUN_01674ea0(uVar2,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19402 ; VA 0x009e7710 ; FUN_009e7710 */

void __thiscall
FUN_009e7710(int param_1,double *param_2,double *param_3,double *param_4,double *param_5)

{
  *param_2 = 0.0;
  *param_3 = 0.0;
  *param_4 = 0.0;
  *param_5 = 0.0;
  if (*(char *)(param_1 + 0xe0) != '\0') {
    *param_2 = (double)*(int *)(param_1 + 0xc0);
    *param_3 = (double)*(int *)(param_1 + 0xc4);
    *param_4 = (double)*(int *)(param_1 + 200);
    *param_5 = (double)*(int *)(param_1 + 0xcc);
    *(undefined4 *)(param_1 + 0xc0) = 0;
    *(undefined4 *)(param_1 + 0xc4) = 0;
    *(undefined4 *)(param_1 + 200) = 0;
    *(undefined4 *)(param_1 + 0xcc) = 0;
  }
  return;
}



/* FUNCTION 19403 ; VA 0x009e77b0 ; FUN_009e77b0 */

int * FUN_009e77b0(int *param_1,int *param_2)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)*param_1)();
  if (uVar4 < 3) {
LAB_009e7957:
    if ((undefined4 *)*param_2 != (undefined4 *)0x0) {
      ExceptionList = pvStack_10;
      return *(int **)*param_2;
    }
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  pcVar1 = *(code **)(*piVar2 + 0x38);
  uVar5 = FUN_009eb4b0();
  cVar3 = (*pcVar1)(3,uVar5,&param_1);
  if (cVar3 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar3 = (**(code **)(*piVar2 + 4))(3,&iStack_ec);
  iVar9 = iStack_ec;
  if (cVar3 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    goto LAB_009e7957;
  }
  iVar6 = FUN_009eb4b0();
  iVar8 = iStack_ec;
  if (iVar9 == iVar6) {
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    if (puVar7 != (undefined4 *)0x0) goto LAB_009e7902;
  }
  iVar6 = FUN_0088cb40();
  iVar9 = iStack_ec;
  if (iVar8 == iVar6) {
    iVar8 = FUN_0088cb40();
    if (iVar9 != iVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    FUN_009eb4b0();
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    cVar3 = FUN_009cb180(puVar7,&param_1);
    if (cVar3 != '\0') {
      FUN_009e1af0(&param_1);
      iVar9 = FUN_009eb4b0();
      iStack_ec = iVar9;
      iVar8 = FUN_009eb4b0();
      if (iVar9 != iVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar7 = (undefined4 *)0x0;
      }
LAB_009e7902:
      piVar2 = (int *)*puVar7;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  thunk_FUN_009eb4b0();
  uVar5 = FUN_005543f0();
  uVar10 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar10,uVar5);
}



/* FUNCTION 19404 ; VA 0x009e79f0 ; FUN_009e79f0 */

undefined4 FUN_009e79f0(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_014cd1a0();
  FUN_0054ef60(uVar1);
  return param_1;
}



/* FUNCTION 19405 ; VA 0x009e7a10 ; FUN_009e7a10 */

void FUN_009e7a10(int param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 *param_8,ulonglong param_9,
                 uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined *param_15,undefined8 param_16,int param_17)

{
  undefined4 uVar1;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 *puStack_84;
  ulonglong uStack_80;
  uint uStack_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 *puStack_64;
  undefined8 uStack_60;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7d18;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (DAT_01d65550 == '\0') {
    puStack_64 = (undefined4 *)&DAT_01d655c0;
    if (param_1 != 0) {
      puStack_64 = (undefined4 *)&DAT_01d655a8;
    }
    uStack_60 = 1;
    uStack_68 = 0x9e7a5d;
    ExceptionList = &pvStack_10;
    FUN_008783f0();
    uStack_78 = 0;
    if (param_10 != 0) {
      uStack_78 = param_10;
      if ((param_10 & 1) == 0) {
        uStack_80 = ZEXT48(&uStack_70);
        puStack_84 = &param_12;
        uStack_88 = 0x9e7aa1;
        (**(code **)(param_10 & 0xfffffffe))();
      }
      else {
        uStack_70 = param_12;
        uStack_6c = param_13;
        uStack_68 = param_14;
        puStack_64 = (undefined4 *)param_15;
        uStack_60 = param_16;
      }
    }
    uStack_8._0_1_ = 2;
    if (param_3 != 0) {
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_90,0);
      }
      else {
        uStack_90 = param_5;
        uStack_8c = param_6;
        uStack_88 = param_7;
        puStack_84 = param_8;
        uStack_80 = param_9;
      }
    }
  }
  else {
    if (param_1 == 0) {
      uStack_60 = 0;
      puStack_64 = (undefined4 *)0xffffffff;
      uStack_68 = 0x9e7b0d;
      ExceptionList = &pvStack_10;
      FUN_0151f6f0();
      uStack_8._0_1_ = 3;
      uStack_60 = CONCAT44(param_17 + 0x18,&DAT_018e4848);
      puStack_64 = (undefined4 *)0x9e7b25;
      FUN_0151f950();
      uStack_60 = CONCAT44(0x9e7b2e,(undefined4)uStack_60);
      uVar1 = (**(code **)(*param_2 + 4))();
      uStack_60 = CONCAT44(uVar1,"exception");
      puStack_64 = (undefined4 *)0x9e7b3c;
      FUN_0151f850();
      uStack_60 = (ulonglong)DAT_01ee53e4;
      puStack_64 = (undefined4 *)&DAT_01d655f0;
      uStack_68 = 0x9e7b51;
      FUN_01520d20();
      uStack_60 = 1;
      puStack_64 = (undefined4 *)&DAT_01d655c0;
      uStack_68 = 0x9e7b5f;
      FUN_008783f0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_60 = CONCAT44(0x9e7b6e,(undefined4)uStack_60);
      FUN_0151f7f0();
    }
    else {
      uStack_60 = 1;
      puStack_64 = (undefined4 *)&DAT_01d655a8;
      uStack_68 = 0x9e7b7c;
      ExceptionList = &pvStack_10;
      FUN_008783f0();
    }
    uStack_78 = 0;
    if (param_10 != 0) {
      uStack_78 = param_10;
      if ((param_10 & 1) == 0) {
        uStack_80 = ZEXT48(&uStack_70);
        puStack_84 = &param_12;
        uStack_88 = 0x9e7bc3;
        (**(code **)(param_10 & 0xfffffffe))();
      }
      else {
        uStack_70 = param_12;
        uStack_6c = param_13;
        uStack_68 = param_14;
        puStack_64 = (undefined4 *)param_15;
        uStack_60 = param_16;
      }
    }
    uStack_8._0_1_ = 4;
    if (param_3 != 0) {
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_90,0);
      }
      else {
        uStack_90 = param_5;
        uStack_8c = param_6;
        uStack_88 = param_7;
        puStack_84 = param_8;
        uStack_80 = param_9;
      }
    }
  }
  uStack_8._0_1_ = 1;
  FUN_008ed2f0(param_1,param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_64 = &param_5;
    uStack_60 = CONCAT44(2,puStack_64);
    uStack_68 = 0x9e7c3d;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_64 = &param_12;
    uStack_60 = CONCAT44(2,puStack_64);
    uStack_68 = 0x9e7c6b;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19406 ; VA 0x009e7c80 ; FUN_009e7c80 */

void FUN_009e7c80(void)

{
  FUN_009e2f90();
  return;
}



/* FUNCTION 19407 ; VA 0x009e7c90 ; FUN_009e7c90 */

void FUN_009e7c90(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0054db60(&stack0x00000008);
  FUN_0054ef20(uVar2);
  FUN_009e3760();
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 19408 ; VA 0x009e7ce0 ; FUN_009e7ce0 */

void FUN_009e7ce0(undefined4 *param_1,undefined4 param_2)

{
  undefined uVar1;
  undefined uVar2;
  undefined *puVar3;
  undefined4 uVar4;
  
  puVar3 = (undefined *)*param_1;
  uVar1 = *puVar3;
  uVar2 = puVar3[8];
  uVar4 = *(undefined4 *)(puVar3 + 4);
  FUN_0054ef60(puVar3 + 0xc);
  FUN_009e8800(param_2,uVar1,uVar4,uVar2);
  return;
}



/* FUNCTION 19409 ; VA 0x009e7d20 ; FUN_009e7d20 */

void FUN_009e7d20(int *param_1,undefined4 param_2,undefined4 param_3)

{
  uint *puVar1;
  uint uVar2;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c47f8;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)*param_1;
  uStack_1c = puVar1[0x10];
  uStack_3c = 0;
  uVar2 = puVar1[8];
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_3c = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = puVar1 + 10;
      uStack_4c = 0x9e7d86;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_34 = puVar1[10];
      uStack_30 = puVar1[0xb];
      uStack_2c = puVar1[0xc];
      uStack_28 = puVar1[0xd];
      uStack_24 = *(undefined8 *)(puVar1 + 0xe);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar2 = *puVar1;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,&uStack_54,0);
    }
    else {
      uStack_54 = puVar1[2];
      uStack_50 = puVar1[3];
      uStack_4c = puVar1[4];
      puStack_48 = (uint *)puVar1[5];
      uStack_44 = *(ulonglong *)(puVar1 + 6);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_009e7a10(param_2,param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19410 ; VA 0x009e7e00 ; FUN_009e7e00 */

void FUN_009e7e00(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined uVar2;
  
  uVar2 = *(undefined *)(param_1 + 2);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_009eb280(param_2,param_3,*param_1,param_1[1],uVar2);
  return;
}



/* FUNCTION 19411 ; VA 0x009e7e50 ; FUN_009e7e50 */

uint FUN_009e7e50(void)

{
  int iVar1;
  
  iVar1 = FUN_009e1b40();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 19412 ; VA 0x009e7e70 ; FUN_009e7e70 */

uint FUN_009e7e70(void)

{
  int iVar1;
  
  iVar1 = FUN_009e1b40();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 19413 ; VA 0x009e7e90 ; FUN_009e7e90 */

undefined __thiscall FUN_009e7e90(int param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  char cVar4;
  undefined uVar5;
  undefined4 *puVar6;
  undefined4 *puStack_ac;
  undefined *puStack_a8;
  undefined4 *puStack_a4;
  undefined4 *puStack_a0;
  undefined auStack_90 [120];
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7d43;
  pvStack_10 = ExceptionList;
  puStack_a0 = (undefined4 *)param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puStack_a8 = auStack_90;
  puStack_ac = (undefined4 *)0x9e7ed7;
  ExceptionList = &pvStack_10;
  puStack_a4 = param_2;
  FUN_0151bda0();
  puStack_18 = (uint *)(param_1 + 300);
  uStack_8 = 0;
  cStack_14 = '\0';
  puStack_a0 = (undefined4 *)0x9e7ef6;
  FUN_00587410();
  uVar3 = DAT_01d65508;
  puVar6 = (undefined4 *)(param_1 + 0x134);
  puStack_a4 = &DAT_01d654f8;
  if (0xf < DAT_01d6550c) {
    puStack_a4 = DAT_01d654f8;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puStack_ac = puVar6;
  if (0xf < *(uint *)(param_1 + 0x148)) {
    puStack_ac = (undefined4 *)*puVar6;
  }
  puStack_a0 = (undefined4 *)DAT_01d65508;
  puStack_a8 = *(undefined **)(param_1 + 0x144);
  cVar4 = FUN_0055c360();
  if (cVar4 == '\0') {
    if ((undefined4 **)puVar6 != &DAT_01d654f8) {
      puStack_a0 = (undefined4 *)uVar3;
      puStack_a4 = &DAT_01d654f8;
      if (0xf < DAT_01d6550c) {
        puStack_a4 = DAT_01d654f8;
      }
      puStack_a8 = (undefined *)0x9e7f59;
      FUN_005542c0();
    }
    puStack_a0 = (undefined4 *)0x0;
    puStack_ac = (undefined4 *)0x0;
    puStack_a4 = (undefined4 *)0x2;
    FUN_0170cc70(&puStack_ac,&DAT_018cecfc,2);
    FUN_0063e660(&puStack_ac,(int)&puStack_ac + (int)puStack_a4,puStack_a4,&puStack_ac);
    FUN_0063fd80(param_1 + 0x14c,puVar6);
  }
  puVar6 = *(undefined4 **)(param_1 + 0x14c);
  puVar2 = *(undefined4 **)(param_1 + 0x150);
  do {
    if (puVar6 == puVar2) {
      uVar5 = 0;
LAB_009e7fd4:
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (cStack_14 != '\0') {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 + 0x80000000;
        UNLOCK();
        if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
          LOCK();
          uVar1 = *puStack_18;
          *puStack_18 = *puStack_18 | 0x40000000;
          UNLOCK();
          if ((uVar1 >> 0x1e & 1) == 0) {
            puStack_a0 = (undefined4 *)0x9e8004;
            puStack_a0 = (undefined4 *)FUN_00554e40();
            puStack_a4 = (undefined4 *)0x9e800b;
            SetEvent();
          }
        }
      }
      puStack_a0 = (undefined4 *)0x9e8016;
      FUN_0056d9d0();
      ExceptionList = pvStack_10;
      return uVar5;
    }
    puStack_a0 = puVar6;
    if (0xf < (uint)puVar6[5]) {
      puStack_a0 = (undefined4 *)*puVar6;
    }
    puStack_a4 = (undefined4 *)0x9e7fc7;
    cVar4 = FUN_0151c660();
    if (cVar4 != '\0') {
      uVar5 = 1;
      goto LAB_009e7fd4;
    }
    puVar6 = puVar6 + 6;
  } while( true );
}



/* FUNCTION 19414 ; VA 0x009e8030 ; FUN_009e8030 */

void FUN_009e8030(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009eb4b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 19415 ; VA 0x009e8070 ; FUN_009e8070 */

int * FUN_009e8070(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009e811b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009e80ae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc4248);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_038237a3088ed6c43636f9d0e961f0fe>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19416 ; VA 0x009e8130 ; FUN_009e8130 */

void FUN_009e8130(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_009e2740(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_009e2d80();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc4328);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_624e86236b626c04b67f116fb8360555>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 19417 ; VA 0x009e8280 ; FUN_009e8280 */

void FUN_009e8280(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dc42b8);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_923e1ed2441ed1d98b044514cf78e387>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 19418 ; VA 0x009e82e0 ; FUN_009e82e0 */

void FUN_009e82e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_009e2740(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_009e2d80();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc42f0);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_924fb9a51440535a10707ba60489b48f>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 19419 ; VA 0x009e8430 ; FUN_009e8430 */

void FUN_009e8430(int *param_1,int *param_2,int param_3)

{
  undefined *puVar1;
  uint uVar2;
  int iVar3;
  undefined *puVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4a6f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined *)*param_1;
      ExceptionList = &pvStack_10;
      puVar4 = (undefined *)FUN_01674e20(0x24);
      uStack_8 = 0;
      if (puVar4 == (undefined *)0x0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *puVar4 = *puVar1;
      *(undefined4 *)(puVar4 + 4) = *(undefined4 *)(puVar1 + 4);
      puVar4[8] = puVar1[8];
      FUN_0054ef60(puVar1 + 0xc);
      *param_2 = (int)puVar4;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        uVar2 = *(uint *)(iVar6 + 0x20);
        ExceptionList = &pvStack_10;
        if (0xf < uVar2) {
          iVar3 = *(int *)(iVar6 + 0xc);
          uVar7 = uVar2 + 1;
          iVar5 = iVar3;
          if (0xfff < uVar7) {
            iVar5 = *(int *)(iVar3 + -4);
            uVar7 = uVar2 + 0x24;
            if (0x1f < (iVar3 - iVar5) - 4U) {
              ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          ExceptionList = &pvStack_10;
          FUN_01674ea0(iVar5,uVar7);
        }
        *(undefined4 *)(iVar6 + 0x1c) = 0;
        *(undefined4 *)(iVar6 + 0x20) = 0xf;
        *(undefined *)(iVar6 + 0xc) = 0;
        FUN_01674ea0(iVar6,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1dc4210);
      if (iVar6 != 0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = *param_1;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_a53edf78a008e4c8bd8cb455efc09fe0>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 19420 ; VA 0x009e85d0 ; FUN_009e85d0 */

int * FUN_009e85d0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      iVar1 = param_1[1];
      param_2[1] = iVar1;
      piVar3 = (int *)CONCAT31((int3)((uint)iVar1 >> 8),*(undefined *)(param_1 + 2));
      *(undefined *)(param_2 + 2) = *(undefined *)(param_1 + 2);
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009e8683. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009e860e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc4280);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_df7fbc96c39ab36fda1b701978599292>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 19421 ; VA 0x009e86a0 ; FUN_009e86a0 */

void __thiscall FUN_009e86a0(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined8 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7d71;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a4210();
  if ((((DAT_01d65538 != '\0') && (param_3 != 0)) && (iVar2 = FUN_008f7870(), iVar2 != 0)) &&
     (cVar1 = FUN_008ff0d0(), cVar1 == '\0')) {
    if (*(int *)(iVar2 + 0x4a0) == 1) {
      uStack_8 = 0;
      FUN_01675290();
      uStack_8._0_1_ = 1;
      puVar3 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar3 == (undefined4 *)0x0) {
        puVar3 = (undefined4 *)0x0;
      }
      else {
        *puVar3 = 0;
        puVar3[1] = 1;
        puVar3[2] = FUN_009e5dd0;
        puVar3[3] = _guard_check_icall;
        puVar3[4] = 0;
        puVar3[5] = iVar2 + 0xac;
        puVar3[6] = param_1;
      }
      FUN_016797d0();
      if (puVar3 != (undefined4 *)0x0) {
        LOCK();
        puVar3[1] = puVar3[1] + 1;
        UNLOCK();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_01675290();
      uStack_8 = 0xffffffff;
      FUN_0056e750();
      uVar4 = DAT_018cf108;
      if (*(char *)(iVar2 + 0x240) == '\0') {
        ExceptionList = pvStack_10;
        return;
      }
    }
    else {
      uVar4 = DAT_018c0d60;
      if (*(int *)(iVar2 + 0x4a0) != 2) {
        ExceptionList = pvStack_10;
        return;
      }
    }
    FUN_009eb5d0(uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19422 ; VA 0x009e8800 ; FUN_009e8800 */

void FUN_009e8800(int param_1,undefined4 param_2,undefined4 param_3,char param_4,undefined4 *param_5
                 )

{
  undefined uVar1;
  char *pcVar2;
  undefined4 uVar3;
  undefined *puVar4;
  undefined1 *puVar5;
  undefined4 *puVar6;
  undefined4 *****pppppuVar7;
  char *pcVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  uint in_stack_00000024;
  uint in_stack_00000028;
  undefined4 auStack_80 [2];
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  undefined4 ****appppuStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined4 ****appppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7ddb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00912100(auStack_78);
  uStack_8._0_1_ = 1;
  FUN_01530500(appppuStack_48);
  uStack_8._0_1_ = 2;
  FUN_01530530(auStack_60);
  uStack_8._0_1_ = 3;
  iVar12 = *(int *)(param_1 + 0x4a0);
  if (iVar12 == 1) {
    pcVar8 = "CurlProbe2Fail-%s";
    pcVar2 = "CurlProbe2Pass-%s";
  }
  else {
    pcVar8 = "CurlProbe2Fail-%s-Rcc";
    pcVar2 = "CurlProbe2Pass-%s-Rcc";
  }
  if ((char)param_2 == '\0') {
    pcVar8 = pcVar2;
  }
  pppppuVar7 = appppuStack_48;
  if (0xf < uStack_34) {
    pppppuVar7 = (undefined4 *****)appppuStack_48[0];
  }
  uVar3 = FUN_01675640(appppuStack_28,pcVar8,pppppuVar7);
  uStack_8._0_1_ = 4;
  FUN_008783f0(uVar3,1,0);
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_14) {
    uVar10 = uStack_14 + 1;
    ppppuVar9 = appppuStack_28[0];
    if (0xfff < uVar10) {
      ppppuVar9 = (undefined4 ****)appppuStack_28[0][-1];
      uVar10 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)ppppuVar9))) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar10);
  }
  if ((char)param_2 != '\0') {
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8._0_1_ = 5;
    FUN_0151f950("rbxVer",auStack_78);
    FUN_0151f950(&DAT_018d3efc,appppuStack_48);
    FUN_0151f950("osVer",auStack_60);
    FUN_0151f9c0("curlError",param_3);
    FUN_0151fcf0(&DAT_018d4684,param_2);
    puVar4 = &DAT_0193c824;
    if (param_4 == '\0') {
      puVar4 = &DAT_0193c828;
    }
    FUN_0151f850(&DAT_0193c824,puVar4);
    puVar5 = &DAT_018bdf50;
    if (iVar12 != 1) {
      puVar5 = &DAT_018bdf48;
    }
    FUN_0151f850("client",puVar5);
    uStack_18 = 0;
    uStack_14 = 0xf;
    uVar10 = 0x100;
    if (in_stack_00000024 < 0x100) {
      uVar10 = in_stack_00000024;
    }
    puVar6 = &param_5;
    if (0xf < in_stack_00000028) {
      puVar6 = param_5;
    }
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    FUN_005542c0(puVar6,uVar10);
    uStack_8._0_1_ = 6;
    pppppuVar7 = appppuStack_28;
    if (0xf < uStack_14) {
      pppppuVar7 = (undefined4 *****)appppuStack_28[0];
    }
    FUN_0151f850("ewhat",pppppuVar7);
    uStack_8._0_1_ = 5;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      pppppuVar7 = (undefined4 *****)appppuStack_28[0];
      if (0xfff < uVar10) {
        pppppuVar7 = (undefined4 *****)appppuStack_28[0][-1];
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)pppppuVar7))) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar7,uVar10);
    }
    if (DAT_01d65540 != '\0') {
      puVar6 = &DAT_01d79d10;
      if (0xf < DAT_01d79d24) {
        puVar6 = DAT_01d79d10;
      }
      FUN_0151f850("certPath",puVar6);
      iStack_30 = 0;
      piStack_2c = (int *)FUN_01685730();
      uStack_18 = 0;
      uStack_14 = 7;
      appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffff0000);
      uStack_8._0_1_ = 7;
      if (DAT_01d79d20 != 0) {
        puVar6 = &DAT_01d79d10;
        if (0xf < DAT_01d79d24) {
          puVar6 = DAT_01d79d10;
        }
        iVar12 = DAT_01d79d20 + (int)puVar6;
        puVar6 = &DAT_01d79d10;
        if (0xf < DAT_01d79d24) {
          puVar6 = DAT_01d79d10;
        }
        uVar3 = FUN_01686580();
        FUN_01685950(puVar6,iVar12,appppuStack_28,uVar3);
      }
      uStack_8._0_1_ = 8;
      FUN_0168e1c0(auStack_80,appppuStack_28,&iStack_30);
      uStack_8._0_1_ = 5;
      FUN_00550800();
      if (iStack_30 == 0) {
        FUN_0151f9c0("certPathStatus",auStack_80[0]);
      }
      else {
        (**(code **)(*piStack_2c + 8))(appppuStack_28,iStack_30);
        uStack_8._0_1_ = 9;
        pppppuVar7 = appppuStack_28;
        if (0xf < uStack_14) {
          pppppuVar7 = (undefined4 *****)appppuStack_28[0];
        }
        FUN_0151f850("certPathError",pppppuVar7);
        uStack_8._0_1_ = 5;
        FUN_005507b0();
      }
    }
    uVar3 = DAT_01ee53dc;
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    FUN_005542c0("CurlError",9);
    uStack_8._0_1_ = 10;
    FUN_01520d20(appppuStack_28,uVar3,0);
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      ppppuVar9 = appppuStack_28[0];
      if (0xfff < uVar10) {
        ppppuVar9 = (undefined4 ****)appppuStack_28[0][-1];
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar9,uVar10);
    }
    FUN_0151f7f0();
  }
  if (0xf < uStack_4c) {
    uVar11 = uStack_4c + 1;
    uVar10 = auStack_60[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_60[0] - 4);
      uVar11 = uStack_4c + 0x24;
      if (0x1f < (auStack_60[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  if (0xf < uStack_34) {
    uVar10 = uStack_34 + 1;
    pppppuVar7 = (undefined4 *****)appppuStack_48[0];
    if (0xfff < uVar10) {
      pppppuVar7 = (undefined4 *****)appppuStack_48[0][-1];
      uVar10 = uStack_34 + 0x24;
      if (0x1f < (uint)((int)appppuStack_48[0] + (-4 - (int)pppppuVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar7,uVar10);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  appppuStack_48[0] = (undefined4 ****)((uint)appppuStack_48[0] & 0xffffff00);
  if (0xf < uStack_64) {
    uVar11 = uStack_64 + 1;
    uVar10 = auStack_78[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_78[0] - 4);
      uVar11 = uStack_64 + 0x24;
      if (0x1f < (auStack_78[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  uStack_68 = 0;
  uStack_64 = 0xf;
  auStack_78[0] = auStack_78[0] & 0xffffff00;
  if (0xf < in_stack_00000028) {
    uVar10 = in_stack_00000028 + 1;
    puVar6 = param_5;
    if (0xfff < uVar10) {
      puVar6 = (undefined4 *)param_5[-1];
      uVar10 = in_stack_00000028 + 0x24;
      if (0x1f < (uint)((int)param_5 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19423 ; VA 0x009e8cf0 ; FUN_009e8cf0 */

void FUN_009e8cf0(undefined4 *param_1,char *param_2,int param_3)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_d8 [176];
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7e0b;
  pvStack_10 = ExceptionList;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(param_3,0,0);
    uStack_8 = 0;
    FUN_0151f950(&DAT_018e4848,param_1);
    puVar1 = param_1 + 4;
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    iVar3 = FUN_0151bda0(auStack_d8,param_1,*puVar1);
    uStack_8._0_1_ = 1;
    FUN_0151f950("domain",iVar3 + 0x18);
    uStack_8._0_1_ = 0;
    FUN_0056d9d0();
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    pcVar4 = param_2;
    do {
      cVar2 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(param_2,(int)pcVar4 - (int)(param_2 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_01520d20(auStack_28,param_3,0);
    if (0xf < uStack_14) {
      uVar6 = uStack_14 + 1;
      uVar5 = auStack_28[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_28[0] - 4);
        uVar6 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19424 ; VA 0x009e8e20 ; FUN_009e8e20 */

void FUN_009e8e20(byte *param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 *param_8,ulonglong param_9,
                 uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  uint *puVar4;
  char cVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  byte *pbVar8;
  uint auStack_88 [2];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  ulonglong uStack_70;
  uint auStack_68 [2];
  undefined4 uStack_60;
  undefined *puStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  byte *pbStack_48;
  undefined4 *puStack_44;
  undefined auStack_38 [24];
  undefined *puStack_20;
  undefined *puStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7e40;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  puStack_44 = (undefined4 *)0x0;
  pbStack_48 = (byte *)0x1;
  uStack_8 = 2;
  uStack_50 = 0x1d65590009e8e5e;
  ExceptionList = &pvStack_10;
  FUN_008783f0();
  if ((DAT_01d65558 == '\0') && (DAT_01f2ddc0 != 0)) {
    puStack_44 = &DAT_01d65608;
    pbVar8 = param_1 + *param_1 + 1;
    uStack_50 = CONCAT44(0x9e8e91,(undefined4)uStack_50);
    pbStack_48 = pbVar8;
    uVar6 = FUN_0055c740();
    puStack_44 = (undefined4 *)(-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
    pbStack_48 = (byte *)&DAT_01d65608;
    uStack_50 = CONCAT44(uVar6,&puStack_1c);
    uStack_54 = 0x9e8eaf;
    FUN_00562fc0();
    if (puStack_1c == (undefined *)0x0) {
LAB_009e8f00:
      cStack_11 = '\0';
    }
    else {
      puStack_44 = (undefined4 *)auStack_38;
      pbStack_48 = (byte *)0x9e8ec2;
      puVar7 = (undefined4 *)FUN_00563690();
      uStack_18 = 1;
      pbStack_48 = (byte *)&DAT_01d655d8;
      if (0xf < DAT_01d655ec) {
        pbStack_48 = (byte *)DAT_01d655d8;
      }
      puVar1 = puVar7 + 4;
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      puStack_44 = (undefined4 *)DAT_01d655e8;
      uStack_50 = CONCAT44(*puVar1,puVar7);
      uStack_54 = 0x9e8ef5;
      cVar5 = FUN_0055c360();
      cStack_11 = '\x01';
      if (cVar5 != '\0') goto LAB_009e8f00;
    }
    if ((uStack_18 & 1) != 0) {
      puStack_44 = (undefined4 *)0x9e8f12;
      FUN_005507b0();
    }
    if (cStack_11 != '\0') {
      puStack_5c = &DAT_01d654c0;
      uStack_60 = 0x9e8f27;
      FUN_0054ef60();
      puStack_5c = (undefined *)0x9e8f2f;
      FUN_005e65e0();
      goto LAB_009e8ffd;
    }
  }
  puStack_44 = (undefined4 *)0x0;
  pbStack_48 = (byte *)0x1;
  puStack_20 = (undefined *)auStack_68;
  puStack_1c = (undefined *)auStack_68;
  auStack_68[0] = 0;
  puVar4 = auStack_68;
  if (param_10 != 0) {
    auStack_68[0] = param_10;
    if ((param_10 & 1) == 0) {
      uStack_70 = ZEXT48(&uStack_60);
      puStack_74 = &param_12;
      uStack_78 = 0x9e8f7f;
      (**(code **)(param_10 & 0xfffffffe))();
      puVar4 = (uint *)puStack_20;
    }
    else {
      uStack_60 = param_12;
      puStack_5c = (undefined *)param_13;
      uStack_58 = param_14;
      uStack_54 = param_15;
      uStack_50 = param_16;
      puVar4 = auStack_68;
    }
  }
  puStack_20 = (undefined *)puVar4;
  puStack_1c = (undefined *)auStack_88;
  uStack_8._0_1_ = 3;
  auStack_88[0] = 0;
  puVar4 = auStack_88;
  if (param_3 != 0) {
    auStack_88[0] = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_80,0);
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_80 = param_5;
      uStack_7c = param_6;
      uStack_78 = param_7;
      puStack_74 = param_8;
      uStack_70 = param_9;
      puVar4 = auStack_88;
    }
  }
  puStack_1c = (undefined *)puVar4;
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_009e9090(param_1,param_2);
LAB_009e8ffd:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_44 = (undefined4 *)0x9e9016;
      (**(code **)*param_2)();
      LOCK();
      piVar2 = param_2 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_44 = (undefined4 *)0x9e9025;
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    pbStack_48 = (byte *)&param_5;
    puStack_44 = (undefined4 *)0x2;
    uStack_50 = CONCAT44(pbStack_48,0x9e9046);
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    pbStack_48 = (byte *)&param_12;
    puStack_44 = (undefined4 *)0x2;
    uStack_50 = CONCAT44(pbStack_48,0x9e9074);
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19425 ; VA 0x009e9090 ; FUN_009e9090 */

void __thiscall
FUN_009e9090(int param_1,int param_2,int *param_3,uint param_4,undefined4 param_5,int param_6,
            undefined4 param_7,undefined4 param_8,undefined4 param_9,undefined8 param_10,
            char *param_11,undefined4 param_12,int *param_13,int *param_14,int *param_15,
            int *param_16,undefined8 param_17,undefined4 param_18,char **param_19)

{
  undefined4 *puVar1;
  int *piVar2;
  char **ppcVar3;
  char cVar4;
  char *pcVar5;
  int iVar6;
  char *pcStack_fc;
  char *pcStack_f8;
  int *piStack_f4;
  int *piStack_f0;
  int *piStack_ec;
  int *piStack_e8;
  int *piStack_e4;
  int **ppiStack_e0;
  uint *puStack_dc;
  int aiStack_d0 [4];
  undefined auStack_c0 [20];
  int *piStack_ac;
  uint auStack_a8 [2];
  int iStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  char *pcStack_88;
  int *piStack_80;
  int *piStack_7c;
  int *piStack_78;
  int *piStack_74;
  undefined8 uStack_70;
  int iStack_68;
  int *piStack_64;
  uint uStack_60;
  int iStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  char *pcStack_40;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7ebc;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  iStack_1c = param_1;
  if ((param_2 == 0) || (*(int *)(param_2 + 8) == 0)) {
    piStack_f4 = (int *)0x17;
    ppiStack_e0 = (int **)0x0;
    puStack_dc = (uint *)0xf;
    pcStack_f8 = "Invalid request options";
    piStack_f0 = (int *)((uint)piStack_f0 & 0xffffff00);
    pcStack_fc = (char *)0x9e958a;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
LAB_009e958a:
    piStack_f4 = (int *)0x9e9592;
    FUN_005e65e0();
  }
  else {
    ExceptionList = &pvStack_10;
    for (puVar1 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
        puVar1 != (undefined4 *)0x0; puVar1 = (undefined4 *)*puVar1) {
      piVar2 = puVar1 + 2;
      ppiStack_e0 = (int **)&DAT_01d65608;
      if (0xf < DAT_01d6561c) {
        ppiStack_e0 = (int **)DAT_01d65608;
      }
      piStack_e8 = piVar2;
      if (0xf < (uint)puVar1[7]) {
        piStack_e8 = (int *)*piVar2;
      }
      piStack_e4 = (int *)puVar1[6];
      piStack_ec = (int *)0x9e9120;
      puStack_dc = (uint *)DAT_01d65618;
      cVar4 = FUN_0055c360();
      if (cVar4 == '\0') {
        piStack_e8 = piVar2;
        if (0xf < (uint)puVar1[7]) {
          piStack_e8 = (int *)*piVar2;
        }
        puStack_dc = (uint *)0x3;
        ppiStack_e0 = (int **)&DAT_018c8720;
        piStack_e4 = (int *)puVar1[6];
        piStack_ec = (int *)0x9e9141;
        cVar4 = FUN_0055c360();
        if (cVar4 == '\0') {
          piStack_e8 = piVar2;
          if (0xf < (uint)puVar1[7]) {
            piStack_e8 = (int *)*piVar2;
          }
          puStack_dc = (uint *)0x4;
          ppiStack_e0 = (int **)&DAT_018c3bf4;
          piStack_e4 = (int *)puVar1[6];
          piStack_ec = (int *)0x9e9162;
          cVar4 = FUN_0055c360();
          if (cVar4 == '\0') {
            piStack_e8 = piVar2;
            if (0xf < (uint)puVar1[7]) {
              piStack_e8 = (int *)*piVar2;
            }
            puStack_dc = (uint *)0x7;
            ppiStack_e0 = (int **)0x193be90;
            piStack_e4 = (int *)puVar1[6];
            piStack_ec = (int *)0x9e9183;
            cVar4 = FUN_0055c360();
            if (cVar4 == '\0') {
              pcStack_fc = (char *)&piStack_f0;
              pcStack_f8 = "Unrecognized request option ";
              piStack_f4 = piVar2;
              FUN_00558df0();
              goto LAB_009e958a;
            }
          }
        }
      }
    }
    pcStack_fc = (char *)0x0;
    ppcVar3 = &pcStack_fc;
    puStack_dc = (uint *)param_19;
    if (param_11 != (char *)0x0) {
      pcStack_fc = param_11;
      if (((uint)param_11 & 1) == 0) {
        param_19 = &pcStack_fc;
        (**(code **)((uint)param_11 & 0xfffffffe))(&param_13,&piStack_f4,0);
        ppcVar3 = param_19;
      }
      else {
        piStack_e4 = (int *)param_17;
        ppiStack_e0 = (int **)((ulonglong)param_17 >> 0x20);
        ppcVar3 = &pcStack_fc;
        piStack_f4 = param_13;
        piStack_f0 = param_14;
        piStack_ec = param_15;
        piStack_e8 = param_16;
      }
    }
    param_19 = ppcVar3;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    FUN_009e9eb0(&iStack_18,param_2,param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_18 != 0) {
      puStack_dc = (uint *)0x9e923f;
      pcVar5 = (char *)FUN_014ca0a0();
      param_19 = &pcStack_f8;
      pcStack_f8 = (char *)0x0;
      ppcVar3 = &pcStack_f8;
      if (param_11 != (char *)0x0) {
        pcStack_f8 = param_11;
        if (((uint)param_11 & 1) == 0) {
          pcStack_fc = (char *)0x0;
          (**(code **)((uint)param_11 & 0xfffffffe))(&param_13,&piStack_f0);
          ppcVar3 = param_19;
        }
        else {
          piStack_f0 = param_13;
          piStack_ec = param_14;
          piStack_e8 = param_15;
          piStack_e4 = param_16;
          ppiStack_e0 = (int **)param_17;
          puStack_dc = (uint *)((ulonglong)param_17 >> 0x20);
          ppcVar3 = &pcStack_f8;
        }
      }
      param_19 = ppcVar3;
      iVar6 = iStack_1c;
      pcStack_fc = pcVar5;
      cVar4 = FUN_009e41b0();
      if (cVar4 != '\0') {
        puStack_dc = (uint *)0x9e929c;
        puStack_dc = (uint *)FUN_014ca0a0();
        ppiStack_e0 = (int **)0x9e92a2;
        cVar4 = FUN_014cd2d0();
        if (cVar4 != '\0') {
          puStack_dc = (uint *)iVar6;
          ppiStack_e0 = (int **)0x9e930f;
          iVar6 = FUN_008f7870();
          if (iVar6 != 0) {
            piVar2 = *(int **)(iVar6 + 0x43c);
            iStack_20 = *piVar2 - (int)piVar2;
            iStack_1c = piVar2[1] - (int)piVar2;
            puStack_dc = (uint *)&iStack_20;
            ppiStack_e0 = (int **)auStack_c0;
            piStack_e4 = (int *)0x9e933e;
            ppiStack_e0 = (int **)FUN_009ee550();
            puStack_dc = (uint *)ppiStack_e0[4];
            uStack_8 = CONCAT31(uStack_8._1_3_,4);
            if (0xf < ppiStack_e0[5]) {
              ppiStack_e0 = (int **)*ppiStack_e0;
            }
            piStack_e8 = (int *)0x18c3af4;
            piStack_e4 = (int *)&DAT_00000009;
            piStack_ec = (int *)0x9e936d;
            FUN_014cb8a0();
            puStack_dc = (uint *)0x9e9378;
            FUN_005507b0();
          }
          if (DAT_01d7a058 != '\0') {
            *(undefined *)(iStack_18 + 0xa4) = 1;
          }
          *(undefined *)(iStack_18 + 0xaa) = 1;
          *(undefined *)(iStack_18 + 0xa9) = 1;
          if (piStack_14 != (int *)0x0) {
            LOCK();
            piStack_14[1] = piStack_14[1] + 1;
            UNLOCK();
          }
          iStack_68 = iStack_18;
          piStack_64 = piStack_14;
          uStack_8._0_1_ = 5;
          uStack_60 = 0;
          if (param_4 != 0) {
            uStack_60 = param_4;
            if ((param_4 & 1) == 0) {
              puStack_dc = (uint *)0x0;
              ppiStack_e0 = (int **)&iStack_58;
              piStack_e4 = &param_6;
              piStack_e8 = (int *)0x9e9403;
              (**(code **)(param_4 & 0xfffffffe))();
            }
            else {
              iStack_58 = param_6;
              uStack_54 = param_7;
              uStack_50 = param_8;
              uStack_4c = param_9;
              uStack_48 = param_10;
            }
          }
          uStack_8._0_1_ = 6;
          pcStack_40 = (char *)0x0;
          if (param_11 != (char *)0x0) {
            pcStack_40 = param_11;
            if (((uint)param_11 & 1) == 0) {
              ppiStack_e0 = &piStack_38;
              puStack_dc = (uint *)0x0;
              piStack_e4 = (int *)&param_13;
              piStack_e8 = (int *)0x9e9447;
              (**(code **)((uint)param_11 & 0xfffffffe))();
            }
            else {
              piStack_38 = param_13;
              piStack_34 = param_14;
              piStack_30 = param_15;
              piStack_2c = param_16;
              uStack_28 = param_17;
            }
          }
          uStack_8._0_1_ = 7;
          param_19 = (char **)auStack_a8;
          auStack_a8[0] = 0;
          if (param_4 != 0) {
            auStack_a8[0] = param_4;
            if ((param_4 & 1) == 0) {
              puStack_dc = (uint *)0x0;
              ppiStack_e0 = (int **)&iStack_a0;
              piStack_e4 = &param_6;
              piStack_e8 = (int *)0x9e94a4;
              (**(code **)(param_4 & 0xfffffffe))();
            }
            else {
              iStack_a0 = param_6;
              uStack_9c = param_7;
              uStack_98 = param_8;
              uStack_94 = param_9;
              uStack_90 = param_10;
            }
          }
          uStack_8._0_1_ = 0x10;
          pcStack_88 = (char *)0x0;
          if (param_11 != (char *)0x0) {
            pcStack_88 = param_11;
            if (((uint)param_11 & 1) == 0) {
              ppiStack_e0 = &piStack_80;
              puStack_dc = (uint *)0x0;
              piStack_e4 = (int *)&param_13;
              piStack_e8 = (int *)0x9e94eb;
              (**(code **)((uint)param_11 & 0xfffffffe))();
            }
            else {
              piStack_80 = param_13;
              piStack_7c = param_14;
              piStack_78 = param_15;
              piStack_74 = param_16;
              uStack_70 = param_17;
            }
          }
          piStack_ac = (int *)0x0;
          puStack_dc = auStack_a8;
          uStack_8._0_1_ = 0x12;
          ppiStack_e0 = (int **)0x9e9508;
          piStack_ac = (int *)FUN_009e1d60();
          puStack_dc = (uint *)0x9e951c;
          FUN_008c3510();
          puStack_dc = (uint *)aiStack_d0;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
          ppiStack_e0 = (int **)0x9e952f;
          FUN_014cb530();
          if (piStack_ac != (int *)0x0) {
            puStack_dc = (uint *)CONCAT31((int3)((uint)aiStack_d0 >> 8),piStack_ac != aiStack_d0);
            ppiStack_e0 = (int **)0x9e954c;
            (**(code **)(*piStack_ac + 0x10))();
            piStack_ac = (int *)0x0;
          }
          puStack_dc = (uint *)0x9e955e;
          FUN_009e2cd0();
          puStack_dc = (uint *)0x9e9566;
          FUN_00550b30();
          goto LAB_009e9592;
        }
        piStack_f4 = (int *)0x35;
        ppiStack_e0 = (int **)0x0;
        puStack_dc = (uint *)0xf;
        pcStack_f8 = "HttpService is not allowed to access ROBLOX resources";
        piStack_f0 = (int *)((uint)piStack_f0 & 0xffffff00);
        pcStack_fc = (char *)0x9e92ca;
        FUN_005542c0();
        piStack_f4 = (int *)0x9e92d2;
        FUN_005e65e0();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_14[1] + -1;
      piStack_14[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_dc = (uint *)0x9e92f0;
        (**(code **)*piStack_14)();
        LOCK();
        iVar6 = piStack_14[2] + -1;
        piStack_14[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          puStack_dc = (uint *)0x9e9304;
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
LAB_009e9592:
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar6 = param_3[1] + -1;
    param_3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      puStack_dc = (uint *)0x9e95ab;
      (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar6 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        puStack_dc = (uint *)0x9e95ba;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    piStack_e4 = &param_6;
    puStack_dc = (uint *)0x2;
    piStack_e8 = (int *)0x9e95db;
    ppiStack_e0 = (int **)piStack_e4;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 0x15;
  if (((param_11 != (char *)0x0) && (((uint)param_11 & 1) == 0)) &&
     (*(code **)((uint)param_11 & 0xfffffffe) != (code *)0x0)) {
    piStack_e4 = (int *)&param_13;
    puStack_dc = (uint *)0x2;
    piStack_e8 = (int *)0x9e9609;
    ppiStack_e0 = (int **)piStack_e4;
    (**(code **)((uint)param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19426 ; VA 0x009e9620 ; FUN_009e9620 */

void FUN_009e9620(int param_1,int param_2,uint param_3)

{
  int iVar1;
  int *piVar2;
  bool bVar3;
  undefined uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint uVar10;
  uint in_stack_0000002c;
  undefined4 uStack_160;
  undefined4 *puStack_15c;
  undefined4 auStack_158 [64];
  undefined4 uStack_58;
  int *piStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_1;
  puStack_c = &LAB_017d7f82;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (param_1 == 0) {
    ExceptionList = &pvStack_10;
    FUN_00888650(&uStack_58);
    uStack_8._0_1_ = 6;
    FUN_00888650(&uStack_50);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    uStack_160 = FUN_0088c8c0();
    puStack_15c = (undefined4 *)0x0;
    auStack_158[0] = *(undefined4 *)(param_2 + 0xc);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c18)
       && (FUN_016f3809(&DAT_01ea8c18), DAT_01ea8c18 == -1)) {
      DAT_01ea8c0c = FUN_005c65e0;
      DAT_01ea8c10 = FUN_005c65e0;
      DAT_01ea8c14 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c18);
    }
    puStack_15c = &DAT_01ea8c0c;
    uStack_8._0_1_ = 8;
    uStack_18 = 0;
    piStack_14 = (int *)0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("StatusCode",10);
    puVar8 = &uStack_160;
    uStack_8._0_1_ = 9;
    FUN_005c4c00(auStack_28);
    FUN_00947a40(puVar8);
    uStack_8._0_1_ = 8;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < piStack_14) {
      uVar10 = (int)piStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = (int)piStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    piStack_14 = (int *)0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    uStack_8._0_1_ = 10;
    if (puStack_15c != (undefined4 *)0x0) {
      (*(code *)puStack_15c[2])(auStack_158);
    }
    uStack_8._0_1_ = 7;
    uStack_160 = FUN_0088cb40();
    puStack_15c = (undefined4 *)0x0;
    FUN_0054ef60(param_2 + 0x10);
    puStack_15c = (undefined4 *)FUN_005c9d30();
    uStack_8._0_1_ = 0xb;
    uStack_18 = 0;
    piStack_14 = (int *)0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("StatusMessage",0xd);
    puVar8 = &uStack_160;
    uStack_8._0_1_ = 0xc;
    FUN_005c4c00(auStack_28);
    FUN_00947a40(puVar8);
    uStack_8._0_1_ = 0xb;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xb;
    if (0xf < piStack_14) {
      uVar10 = (int)piStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = (int)piStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    piStack_14 = (int *)0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    uStack_8._0_1_ = 0xd;
    if (puStack_15c != (undefined4 *)0x0) {
      (**(code **)((int)puStack_15c + 8))(auStack_158);
    }
    uStack_8._0_1_ = 7;
    uStack_160 = FUN_0088cb40();
    puStack_15c = (undefined4 *)0x0;
    FUN_0054ef60(param_2 + 0x40);
    puStack_15c = (undefined4 *)FUN_005c9d30();
    uStack_8._0_1_ = 0xe;
    uStack_18 = 0;
    piStack_14 = (int *)0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c3bf4,4);
    puVar8 = &uStack_160;
    uStack_8._0_1_ = 0xf;
    FUN_005c4c00(auStack_28);
    FUN_00947a40(puVar8);
    uStack_8._0_1_ = 0xe;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xe;
    if (0xf < piStack_14) {
      uVar10 = (int)piStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = (int)piStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    piStack_14 = (int *)0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    uStack_8._0_1_ = 0x10;
    if (puStack_15c != (undefined4 *)0x0) {
      (**(code **)((int)puStack_15c + 8))(auStack_158);
    }
    if (piStack_4c != (int *)0x0) {
      LOCK();
      piStack_4c[1] = piStack_4c[1] + 1;
      UNLOCK();
    }
    uStack_18 = uStack_50;
    piStack_14 = piStack_4c;
    uStack_8._0_1_ = 0x11;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0("Headers",7);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    iVar6 = FUN_005c4c00(auStack_40);
    uVar5 = FUN_008881d0();
    *(undefined4 *)(iVar6 + 0x18) = uVar5;
    piStack_44 = (int *)FUN_0058c000();
    iVar1 = *(int *)(iVar6 + 0x1c);
    if ((int *)iVar1 == piStack_44) {
      *(undefined4 *)(iVar6 + 0x20) = uStack_50;
      piVar2 = *(int **)(iVar6 + 0x24);
      *(int **)(iVar6 + 0x24) = piStack_4c;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = piVar2[1] + -1;
        piVar2[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar1 = piVar2[2] + -1;
          piVar2[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    else {
      if (iVar1 != 0) {
        (**(code **)(iVar1 + 8))(iVar6 + 0x20);
      }
      *(undefined4 *)(iVar6 + 0x20) = uStack_50;
      *(int **)(iVar6 + 0x24) = piStack_4c;
      *(int **)(iVar6 + 0x1c) = piStack_44;
    }
    uStack_8._0_1_ = 0x11;
    if (0xf < uStack_2c) {
      uVar10 = uStack_2c + 1;
      uVar9 = auStack_40[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_40[0] - 4);
        uVar10 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_8._0_1_ = 7;
    bVar3 = 99 < *(int *)(param_2 + 0xc) - 200U;
    param_1._3_1_ = !bVar3;
    puVar7 = &DAT_01d655a8;
    if (bVar3) {
      puVar7 = &DAT_01d655c0;
    }
    FUN_008783f0(puVar7,1,0);
    uStack_160 = FUN_0088daf0();
    puStack_15c = (undefined4 *)0x0;
    auStack_158[0] = CONCAT31(auStack_158[0]._1_3_,param_1._3_1_);
    puStack_15c = (undefined4 *)FUN_005c9ef0();
    uStack_8._0_1_ = 0x13;
    uStack_18 = 0;
    piStack_14 = (int *)0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("Success",7);
    puVar8 = &uStack_160;
    uStack_8._0_1_ = 0x14;
    FUN_005c4c00(auStack_28);
    FUN_00947a40(puVar8);
    uStack_8._0_1_ = 0x13;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x13;
    if (0xf < piStack_14) {
      uVar10 = (int)piStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar10 = (int)piStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_18 = 0;
    piStack_14 = (int *)0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    uStack_8._0_1_ = 0x15;
    if (puStack_15c != (undefined4 *)0x0) {
      (**(code **)((int)puStack_15c + 8))(auStack_158);
    }
    uStack_8._0_1_ = 7;
    puVar8 = (undefined4 *)FUN_014caa60(&uStack_18);
    FUN_009e7420(&uStack_50,*puVar8,puVar8[1]);
    if (piStack_54 != (int *)0x0) {
      LOCK();
      piStack_54[1] = piStack_54[1] + 1;
      UNLOCK();
    }
    uStack_48 = uStack_58;
    piStack_44 = piStack_54;
    uStack_8._0_1_ = 0x16;
    if (param_3 == 0) {
      uVar5 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar5);
    }
    uStack_48 = 0;
    piStack_44 = (int *)0x0;
    (**(code **)((param_3 & 0xfffffffe) + 4))(&stack0x00000014,uStack_58,piStack_54);
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_4c[1] + -1;
      piStack_4c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_4c)();
        LOCK();
        iVar1 = piStack_4c[2] + -1;
        piStack_4c[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_4c + 4))();
        }
      }
    }
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_54[1] + -1;
      piStack_54[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        piVar2 = piStack_54 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_54 + 4))();
        }
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_008783f0(&DAT_01d655c0,1,0);
    if (DAT_01ee53e4 != 0) {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8._0_1_ = 2;
      uVar5 = FUN_014ca0a0();
      FUN_0151f950(&DAT_018e4848,uVar5);
      FUN_0151f9c0("errorcode",param_1);
      FUN_0151f950("errormessage",param_2 + 0x74);
      if ((*(char *)(*(int *)(param_2 + 0x90) + 0xa9) == '\0') ||
         (param_1 = 1, *(char *)(*(int *)(param_2 + 0x90) + 0xaa) == '\0')) {
        param_1 = 0;
      }
      FUN_0151fcf0("peerandhostverification",param_1);
      iVar6 = DAT_01ee53e4;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = auStack_40[0] & 0xffffff00;
      FUN_005542c0("HttpServiceTransportError",0x19);
      uStack_8._0_1_ = 3;
      FUN_01520d20(auStack_40,iVar6,0);
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_0151f7f0();
    }
    if ((((*(char *)(*(int *)(param_2 + 0x90) + 0xa9) != '\0') &&
         (*(char *)(*(int *)(param_2 + 0x90) + 0xaa) != '\0')) && ((iVar1 == 0xb || (0xb < iVar1))))
       && (DAT_01ee53e0 != 0)) {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8._0_1_ = 4;
      uVar5 = FUN_014ca0a0();
      FUN_0151f950(&DAT_018e4848,uVar5);
      FUN_0151f9c0("errorcode",iVar1);
      FUN_0151f950("errormessage",param_2 + 0x74);
      iVar1 = DAT_01ee53e0;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = auStack_40[0] & 0xffffff00;
      FUN_005542c0("HttpServiceTlsProbe",0x13);
      uStack_8._0_1_ = 5;
      FUN_01520d20(auStack_40,iVar1,0);
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_0151f7f0();
    }
    FUN_0054ef60(param_2 + 0x74);
    FUN_005e65e0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  uStack_8 = 0x19;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19427 ; VA 0x009e9eb0 ; FUN_009e9eb0 */

int * FUN_009e9eb0(int *param_1,byte *param_2,int *param_3,uint param_4)

{
  byte bVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  byte ****ppppbVar6;
  byte ****ppppbVar7;
  byte ****ppppbVar8;
  undefined4 ******ppppppuVar9;
  byte ******ppppppbVar10;
  byte *****pppppbVar11;
  byte *pbVar12;
  byte ******ppppppbVar13;
  undefined4 in_stack_00000030;
  undefined4 in_stack_fffffec0;
  undefined4 in_stack_fffffec4;
  char *pcVar14;
  undefined4 in_stack_fffffec8;
  undefined4 uVar15;
  undefined auStack_134 [4];
  undefined4 uStack_130;
  byte *****pppppbStack_12c;
  undefined *puStack_128;
  byte *****pppppbStack_124;
  undefined4 *****pppppuStack_120;
  undefined auStack_110 [24];
  undefined auStack_f8 [24];
  undefined auStack_e0 [4];
  int *piStack_dc;
  undefined auStack_d8 [4];
  int *piStack_d4;
  int aiStack_d0 [4];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined auStack_b8 [16];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined auStack_a0 [16];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 *****apppppuStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  int *piStack_70;
  byte ****ppppbStack_6c;
  byte ****ppppbStack_68;
  byte ****ppppbStack_64;
  int iStack_60;
  undefined4 *****apppppuStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined auStack_44 [4];
  int *piStack_40;
  byte ****ppppbStack_3c;
  undefined4 uStack_38;
  byte *****apppppbStack_34 [4];
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d7fcb;
  pvStack_10 = ExceptionList;
  pppppuStack_120 = (undefined4 *****)0x3;
  pppppbStack_124 = (byte *****)&DAT_018c8720;
  uStack_8 = 1;
  uStack_78 = 0;
  uStack_74 = 0xf;
  apppppuStack_88[0] = (undefined4 *****)((uint)apppppuStack_88[0] & 0xffffff00);
  puStack_128 = (undefined *)0x9e9f05;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  pbVar12 = param_2 + *param_2 + 1;
  pppppuStack_120 = apppppuStack_88;
  puStack_128 = (undefined *)0x9e9f1a;
  pppppbStack_124 = (byte *****)pbVar12;
  puStack_128 = (undefined *)FUN_0055c740();
  pppppbStack_124 = (byte *****)apppppuStack_88;
  pppppuStack_120 = (undefined4 *****)(-(uint)(pbVar12 != (byte *)0x0) & (uint)(pbVar12 + 1));
  pppppbStack_12c = (byte *****)&iStack_60;
  uStack_130 = 0x9e9f3a;
  FUN_00562fc0();
  if (0xf < uStack_74) {
    pppppuStack_120 = (undefined4 *****)(uStack_74 + 1);
    ppppppuVar9 = (undefined4 ******)apppppuStack_88[0];
    if (0xfff < pppppuStack_120) {
      ppppppuVar9 = (undefined4 ******)apppppuStack_88[0][-1];
      pppppuStack_120 = (undefined4 *****)(uStack_74 + 0x24);
      if (0x1f < (uint)((int)apppppuStack_88[0] + (-4 - (int)ppppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        pppppuStack_120 = (undefined4 *****)0x9ea7e9;
        FUN_017167a3();
      }
    }
    puStack_128 = (undefined *)0x9e9f6e;
    pppppbStack_124 = (byte *****)ppppppuVar9;
    FUN_01674ea0();
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  apppppuStack_88[0] = (undefined4 *****)((uint)apppppuStack_88[0] & 0xffffff00);
  if (iStack_60 == 0) {
    pppppbStack_124 = (byte *****)iStack_60;
    pppppuStack_120 = (undefined4 *****)0xf;
    auStack_134[0] = 0;
    FUN_005542c0("Invalid request options, Url is empty",0x25);
    FUN_005e65e0();
    *param_1 = 0;
    param_1[1] = 0;
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar3 = param_3[1] + -1;
      param_3[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        pppppuStack_120 = (undefined4 *****)0x9e9fdb;
        (**(code **)*param_3)();
        LOCK();
        piVar2 = param_3 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pppppuStack_120 = (undefined4 *****)0x9e9fea;
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    uStack_8 = 2;
    goto LAB_009ea7af;
  }
  iVar3 = *(int *)(iStack_60 + 0x20);
  pppppuStack_120 = (undefined4 *****)0x9ea001;
  iVar5 = FUN_0088cb40();
  if (iVar3 != iVar5) {
    pppppbStack_124 = (byte *****)0x0;
    pppppuStack_120 = (undefined4 *****)0xf;
    auStack_134[0] = 0;
    FUN_005542c0("Invalid request options, Url should be a string",0x2f);
    FUN_005e65e0();
    *param_1 = 0;
    param_1[1] = 0;
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar3 = param_3[1] + -1;
      param_3[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        pppppuStack_120 = (undefined4 *****)0x9ea058;
        (**(code **)*param_3)();
        LOCK();
        piVar2 = param_3 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pppppuStack_120 = (undefined4 *****)0x9ea067;
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    uStack_8 = 3;
    goto LAB_009ea7af;
  }
  pppppuStack_120 = apppppuStack_5c;
  pppppbStack_124 = (byte *****)0x9ea07e;
  FUN_00563690();
  pppppuStack_120 = (undefined4 *****)&DAT_01d65608;
  uStack_8._0_1_ = 4;
  pbVar12 = param_2 + *param_2 + 1;
  puStack_128 = (undefined *)0x9ea098;
  pppppbStack_124 = (byte *****)pbVar12;
  puStack_128 = (undefined *)FUN_0055c740();
  pppppuStack_120 = (undefined4 *****)(-(uint)(pbVar12 != (byte *)0x0) & (uint)(pbVar12 + 1));
  pppppbStack_124 = (byte *****)&DAT_01d65608;
  pppppbStack_12c = &ppppbStack_64;
  uStack_130 = 0x9ea0b6;
  FUN_00562fc0();
  pppppuStack_120 = (undefined4 *****)&DAT_01d655d8;
  pppppbStack_124 = (byte *****)0x9ea0c3;
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  if ((byte *****)ppppbStack_64 != (byte *****)0x0) {
    ppppbVar8 = (byte ****)ppppbStack_64[8];
    pppppuStack_120 = (undefined4 *****)0x9ea0dd;
    ppppbVar6 = (byte ****)FUN_0088cb40();
    if (ppppbVar8 != ppppbVar6) {
      pppppbStack_124 = (byte *****)0x0;
      pppppuStack_120 = (undefined4 *****)0xf;
      auStack_134[0] = 0;
      FUN_005542c0("Invalid request options, Method should be a string",0x32);
      FUN_005e65e0();
      *param_1 = 0;
      param_1[1] = 0;
      goto LAB_009ea11b;
    }
    pppppuStack_120 = (undefined4 *****)auStack_f8;
    pppppbStack_124 = (byte *****)0x9ea15e;
    pppppuStack_120 = (undefined4 *****)FUN_00563690();
    pppppbStack_124 = (byte *****)0x9ea167;
    FUN_005511f0();
    pppppuStack_120 = (undefined4 *****)0x9ea172;
    FUN_005507b0();
    ppppppbVar13 = apppppbStack_34;
    if (0xf < uStack_20) {
      ppppppbVar13 = (byte ******)apppppbStack_34[0];
    }
    ppppppbVar10 = (byte ******)((int)ppppppbVar13 + iStack_24);
    for (; ppppppbVar13 != ppppppbVar10; ppppppbVar13 = (byte ******)((int)ppppppbVar13 + 1)) {
      bVar1 = *(byte *)ppppppbVar13;
      if ((((bVar1 < 0x41) || (0x5a < bVar1)) && ((bVar1 < 0x61 || (0x7a < bVar1)))) &&
         (((bVar1 < 0x30 || (0x39 < bVar1)) && (bVar1 != 0x2d)))) {
        FUN_00558df0(auStack_134,"Invalid Http Method ",apppppbStack_34);
        FUN_005e65e0();
        *param_1 = 0;
        param_1[1] = 0;
        pppppuStack_120 = (undefined4 *****)0x9ea2b4;
        FUN_005507b0();
        pppppuStack_120 = (undefined4 *****)0x9ea2bc;
        FUN_005507b0();
        if (param_3 != (int *)0x0) {
          LOCK();
          iVar3 = param_3[1] + -1;
          param_3[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            pppppuStack_120 = (undefined4 *****)0x9ea2d5;
            (**(code **)*param_3)();
            LOCK();
            piVar2 = param_3 + 2;
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
              pppppuStack_120 = (undefined4 *****)0x9ea2e4;
              (**(code **)(*param_3 + 4))();
            }
          }
        }
        uStack_8 = 6;
        goto LAB_009ea7af;
      }
    }
  }
  iStack_1c = 0;
  iStack_18 = 0;
  uStack_8._0_1_ = 7;
  if (DAT_01d65548 == '\0') {
    pppppuStack_120 = (undefined4 *****)uStack_38;
    pppppbStack_124 = (byte *****)0x9ea348;
    FUN_008f7870();
    pppppuStack_120 = (undefined4 *****)0x9ea352;
    pppppuStack_120 = (undefined4 *****)FUN_008f7f00();
    pppppbStack_124 = (byte *****)auStack_e0;
    puStack_128 = (undefined *)0x9ea35f;
    pppppuStack_120 = (undefined4 *****)FUN_014c9d60();
    pppppbStack_124 = (byte *****)0x9ea36b;
    FUN_005587e0();
  }
  else {
    cStack_11 = '\0';
    uStack_90 = 0;
    uStack_8c = 0xf;
    auStack_a0[0] = 0;
    pcVar14 = "AllowSandboxing";
    do {
      pppppuStack_120 = (undefined4 *****)pcVar14;
      pcVar14 = (char *)((int)pppppuStack_120 + 1);
    } while (*(char *)pppppuStack_120 != '\0');
    pppppuStack_120 = (undefined4 *****)((int)pppppuStack_120 + -0x193bb40);
    pppppbStack_124 = (byte *****)&DAT_0193bb40;
    puStack_128 = (undefined *)0x9ea21d;
    FUN_005542c0();
    pbVar12 = param_2 + *param_2 + 1;
    pppppuStack_120 = (undefined4 *****)auStack_a0;
    puStack_128 = (undefined *)0x9ea232;
    pppppbStack_124 = (byte *****)pbVar12;
    puStack_128 = (undefined *)FUN_0055c740();
    pppppbStack_124 = (byte *****)auStack_a0;
    pppppuStack_120 = (undefined4 *****)(-(uint)(pbVar12 != (byte *)0x0) & (uint)(pbVar12 + 1));
    pppppbStack_12c = &ppppbStack_3c;
    uStack_130 = 0x9ea252;
    FUN_00562fc0();
    pppppuStack_120 = (undefined4 *****)0x9ea25d;
    FUN_005507b0();
    cVar4 = cStack_11;
    if ((byte *****)ppppbStack_3c != (byte *****)0x0) {
      ppppbVar8 = (byte ****)ppppbStack_3c[8];
      pppppuStack_120 = (undefined4 *****)0x9ea273;
      ppppbVar6 = (byte ****)FUN_0088daf0();
      if (ppppbVar8 != ppppbVar6) {
        pppppuStack_120 = (undefined4 *****)0x193c4d8;
                    /* WARNING: Subroutine does not return */
        pppppbStack_124 = (byte *****)0x9ea7f3;
        FUN_016757c0();
      }
      pppppuStack_120 = (undefined4 *****)0x9ea2f7;
      cVar4 = FUN_00636260();
    }
    pppppuStack_120 = (undefined4 *****)0x0;
    if ((cVar4 != '\0') && (DAT_01ee5480 != '\0')) {
      pppppuStack_120 = (undefined4 *****)uStack_38;
      pppppbStack_124 = (byte *****)0x9ea313;
      FUN_008f7870();
      pppppuStack_120 = (undefined4 *****)0x9ea31d;
      pppppuStack_120 = (undefined4 *****)FUN_008f7f00();
    }
    pppppbStack_124 = (byte *****)auStack_d8;
    puStack_128 = (undefined *)0x9ea32c;
    pppppuStack_120 = (undefined4 *****)FUN_014c9d60();
    pppppbStack_124 = (byte *****)0x9ea338;
    FUN_005587e0();
    piStack_dc = piStack_d4;
  }
  if (piStack_dc != (int *)0x0) {
    LOCK();
    iVar3 = piStack_dc[1] + -1;
    piStack_dc[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      pppppuStack_120 = (undefined4 *****)0x9ea384;
      (**(code **)*piStack_dc)();
      LOCK();
      iVar3 = piStack_dc[2] + -1;
      piStack_dc[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        pppppuStack_120 = (undefined4 *****)0x9ea394;
        (**(code **)(*piStack_dc + 4))();
      }
    }
  }
  iVar3 = iStack_1c;
  pppppbStack_124 = (byte *****)apppppuStack_5c;
  if (0xf < uStack_48) {
    pppppbStack_124 = (byte *****)apppppuStack_5c[0];
  }
  pppppuStack_120 = (undefined4 *****)uStack_4c;
  puStack_128 = (undefined *)0x9ea3b6;
  FUN_014cbbc0();
  pppppbStack_124 = (byte *****)apppppbStack_34;
  if (0xf < uStack_20) {
    pppppbStack_124 = apppppbStack_34[0];
  }
  pppppuStack_120 = (undefined4 *****)iStack_24;
  puStack_128 = (undefined *)0x9ea3d5;
  FUN_014cba10();
  pppppuStack_120 = (undefined4 *****)0x9ea3da;
  cVar4 = FUN_00585a40();
  if (cVar4 == '\0') {
    *(undefined *)(iVar3 + 0xab) = 1;
  }
  pppppuStack_120 = (undefined4 *****)0x4;
  pppppbStack_124 = (byte *****)&DAT_018c3bf4;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  auStack_b8[0] = 0;
  puStack_128 = (undefined *)0x9ea415;
  FUN_005542c0();
  pbVar12 = param_2 + *param_2 + 1;
  pppppuStack_120 = (undefined4 *****)auStack_b8;
  puStack_128 = (undefined *)0x9ea42a;
  pppppbStack_124 = (byte *****)pbVar12;
  puStack_128 = (undefined *)FUN_0055c740();
  pppppbStack_124 = (byte *****)auStack_b8;
  pppppuStack_120 = (undefined4 *****)(-(uint)(pbVar12 != (byte *)0x0) & (uint)(pbVar12 + 1));
  pppppbStack_12c = &ppppbStack_68;
  uStack_130 = 0x9ea44a;
  FUN_00562fc0();
  pppppuStack_120 = (undefined4 *****)0x9ea455;
  FUN_005507b0();
  if ((byte *****)ppppbStack_68 == (byte *****)0x0) {
LAB_009ea529:
    pppppuStack_120 = (undefined4 *****)0x7;
    pppppbStack_124 = (byte *****)0x193be90;
    uStack_c0 = 0;
    uStack_bc = 0xf;
    aiStack_d0[0]._0_1_ = 0;
    puStack_128 = (undefined *)0x9ea559;
    FUN_005542c0();
    param_2 = param_2 + *param_2 + 1;
    pppppuStack_120 = (undefined4 *****)aiStack_d0;
    puStack_128 = (undefined *)0x9ea56e;
    pppppbStack_124 = (byte *****)param_2;
    puStack_128 = (undefined *)FUN_0055c740();
    pppppbStack_124 = (byte *****)aiStack_d0;
    pppppuStack_120 = (undefined4 *****)(-(uint)(param_2 != (byte *)0x0) & (uint)(param_2 + 1));
    pppppbStack_12c = &ppppbStack_6c;
    uStack_130 = 0x9ea58e;
    FUN_00562fc0();
    pppppuStack_120 = (undefined4 *****)0x9ea599;
    FUN_005507b0();
    if ((byte *****)ppppbStack_6c != (byte *****)0x0) {
      ppppbVar8 = (byte ****)ppppbStack_6c[8];
      pppppuStack_120 = (undefined4 *****)0x9ea5ac;
      ppppbVar7 = (byte ****)FUN_008881d0();
      ppppbVar6 = (byte ****)ppppbStack_6c[8];
      if (ppppbVar8 != ppppbVar7) {
        pppppuStack_120 = (undefined4 *****)0x9ea5bc;
        ppppbVar8 = (byte ****)FUN_008882f0();
        if (ppppbVar6 == ppppbVar8) {
          ppppbVar8 = (byte ****)ppppbStack_6c[8];
          pppppuStack_120 = (undefined4 *****)0x9ea5cc;
          ppppbVar6 = (byte ****)FUN_008882f0();
          if (ppppbVar8 != ppppbVar6) {
            pppppuStack_120 = (undefined4 *****)0x18c072c;
                    /* WARNING: Subroutine does not return */
            pppppbStack_124 = (byte *****)0x9ea7fd;
            FUN_016757c0();
          }
          pppppbVar11 = (byte *****)(ppppbStack_6c + 10);
          if ((byte ****)ppppbStack_6c[9] == (byte ****)0x0) {
            pppppbVar11 = (byte *****)0x0;
          }
          if (**pppppbVar11 == (*pppppbVar11)[1]) {
            pppppuStack_120 = (undefined4 *****)&iStack_1c;
            pppppbStack_124 = (byte *****)0x9ea607;
            FUN_00557f90();
            pppppuStack_120 = (undefined4 *****)0x9ea60f;
            FUN_00550b30();
            pppppuStack_120 = (undefined4 *****)0x9ea617;
            FUN_005507b0();
            pppppuStack_120 = (undefined4 *****)0x9ea61f;
            FUN_005507b0();
            pppppuStack_120 = (undefined4 *****)0x9ea627;
            FUN_00550b30();
            pppppuStack_120 = (undefined4 *****)0x9ea62f;
            FUN_00550990();
            ExceptionList = pvStack_10;
            return param_1;
          }
        }
        uVar15 = 0x32;
        pcVar14 = "Invalid request options, Headers should be a table";
        goto LAB_009ea47b;
      }
      pppppuStack_120 = (undefined4 *****)0x9ea65b;
      ppppbVar8 = (byte ****)FUN_008881d0();
      if (ppppbVar6 != ppppbVar8) {
        pppppuStack_120 = (undefined4 *****)0x18c072c;
                    /* WARNING: Subroutine does not return */
        pppppbStack_124 = (byte *****)&UNK_009ea807;
        FUN_016757c0();
      }
      pppppuStack_120 = (undefined4 *****)(ppppbStack_6c + 10);
      if ((byte ****)ppppbStack_6c[9] == (byte ****)0x0) {
        pppppuStack_120 = (undefined4 *****)0x0;
      }
      pppppbStack_124 = (byte *****)0x9ea677;
      FUN_00557fc0();
      pppppuStack_120 = (undefined4 *****)0x1;
      uStack_8._0_1_ = 8;
      FUN_0054f510(&param_4);
      cVar4 = FUN_009e5ea0(auStack_44,in_stack_fffffec0,in_stack_fffffec4,in_stack_fffffec8);
      if (cVar4 == '\0') {
        *param_1 = 0;
        param_1[1] = 0;
        pppppuStack_120 = (undefined4 *****)0x9ea6b3;
        FUN_00550b30();
        pppppuStack_120 = (undefined4 *****)0x9ea6bb;
        FUN_00550b30();
        goto LAB_009ea11b;
      }
      pppppuStack_120 = (undefined4 *****)&piStack_70;
      pppppbStack_124 = (byte *****)0x9ea6cc;
      FUN_00618a80();
      for (piVar2 = piStack_70; piVar2 != (int *)0x0; piVar2 = (int *)*piVar2) {
        pppppuStack_120 = (undefined4 *****)auStack_110;
        ppppppbVar13 = (byte ******)(piVar2 + 2);
        pppppbStack_124 = (byte *****)0x9ea6f2;
        pppppbStack_124 = (byte *****)FUN_00563690();
        pppppuStack_120 = (undefined4 *****)((int *)pppppbStack_124)[4];
        uStack_8._0_1_ = 9;
        if (0xf < (uint)((int *)pppppbStack_124)[5]) {
          pppppbStack_124 = (byte *****)*pppppbStack_124;
        }
        puStack_128 = (undefined *)piVar2[6];
        if (0xf < (uint)piVar2[7]) {
          ppppppbVar13 = (byte ******)*ppppppbVar13;
        }
        uStack_130 = 0x9ea727;
        pppppbStack_12c = (byte *****)ppppppbVar13;
        FUN_014cb8a0();
        uStack_8._0_1_ = 8;
        pppppuStack_120 = (undefined4 *****)0x9ea736;
        FUN_005507b0();
      }
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_40[1] + -1;
        piStack_40[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          pppppuStack_120 = (undefined4 *****)0x9ea755;
          (**(code **)*piStack_40)();
          LOCK();
          iVar3 = piStack_40[2] + -1;
          piStack_40[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            pppppuStack_120 = (undefined4 *****)0x9ea765;
            (**(code **)(*piStack_40 + 4))();
          }
        }
      }
    }
    *param_1 = iStack_1c;
    param_1[1] = iStack_18;
    pppppuStack_120 = (undefined4 *****)0x9ea77b;
    FUN_005507b0();
    pppppuStack_120 = (undefined4 *****)0x9ea783;
    FUN_005507b0();
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar3 = param_3[1] + -1;
      param_3[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        pppppuStack_120 = (undefined4 *****)0x9ea799;
        (**(code **)*param_3)();
        LOCK();
        piVar2 = param_3 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pppppuStack_120 = (undefined4 *****)0x9ea7a8;
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    uStack_8 = 10;
LAB_009ea7af:
    if (((param_4 != 0) && ((param_4 & 1) == 0)) &&
       (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      puStack_128 = &stack0x00000018;
      pppppuStack_120 = (undefined4 *****)0x2;
      pppppbStack_12c = (byte *****)0x9ea7cc;
      pppppbStack_124 = (byte *****)puStack_128;
      (**(code **)(param_4 & 0xfffffffe))();
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ppppbVar8 = (byte ****)ppppbStack_68[8];
  pppppuStack_120 = (undefined4 *****)0x9ea46b;
  ppppbVar6 = (byte ****)FUN_0088cb40();
  if (ppppbVar8 == ppppbVar6) {
    pppppuStack_120 = (undefined4 *****)DAT_01d655e8;
    pppppbStack_124 = (byte *****)&DAT_01d655d8;
    if (0xf < DAT_01d655ec) {
      pppppbStack_124 = (byte *****)DAT_01d655d8;
    }
    pppppbStack_12c = (byte *****)apppppbStack_34;
    if (0xf < uStack_20) {
      pppppbStack_12c = apppppbStack_34[0];
    }
    puStack_128 = (undefined *)iStack_24;
    uStack_130 = 0x9ea4e6;
    cVar4 = FUN_0055c360();
    if (cVar4 == '\0') {
      pppppuStack_120 = (undefined4 *****)0x4;
      pppppbStack_124 = (byte *****)&DAT_0193c538;
      puStack_128 = (undefined *)iStack_24;
      pppppbStack_12c = (byte *****)apppppbStack_34;
      if (0xf < uStack_20) {
        pppppbStack_12c = apppppbStack_34[0];
      }
      uStack_130 = 0x9ea50b;
      cVar4 = FUN_0055c360();
      if (cVar4 == '\0') {
        pppppuStack_120 = (undefined4 *****)0x9ea51d;
        pppppbStack_124 = (byte *****)FUN_0055d610();
        pppppuStack_120 = (undefined4 *****)in_stack_00000030;
        puStack_128 = (undefined *)0x9ea529;
        FUN_014cb780();
        goto LAB_009ea529;
      }
    }
    uVar15 = 0x48;
    pcVar14 = "Invalid request options, Body should be empty for \'GET\' or \'HEAD\' method";
  }
  else {
    uVar15 = 0x30;
    pcVar14 = "Invalid request options, Body should be a string";
  }
LAB_009ea47b:
  pppppbStack_124 = (byte *****)0x0;
  pppppuStack_120 = (undefined4 *****)0xf;
  auStack_134[0] = 0;
  FUN_005542c0(pcVar14,uVar15);
  FUN_005e65e0();
  *param_1 = 0;
  param_1[1] = 0;
  pppppuStack_120 = (undefined4 *****)0x9ea4b1;
  FUN_00550b30();
LAB_009ea11b:
  pppppuStack_120 = (undefined4 *****)0x9ea123;
  FUN_005507b0();
  pppppuStack_120 = (undefined4 *****)0x9ea12b;
  FUN_005507b0();
  pppppuStack_120 = (undefined4 *****)0x9ea133;
  FUN_00550b30();
  pppppuStack_120 = (undefined4 *****)0x9ea13b;
  FUN_00550990();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19428 ; VA 0x009ea645 ; FUN_009ea645 */

undefined4 * FUN_009ea645(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  undefined uVar2;
  
  uVar2 = 0;
  FUN_005542c0("Invalid request options, Headers should be a table",0x32);
  FUN_005e65e0(uVar2);
  puVar1 = *(undefined4 **)(unaff_EBP + 8);
  *puVar1 = 0;
  puVar1[1] = 0;
  FUN_00550b30();
  FUN_005507b0();
  FUN_005507b0();
  FUN_00550b30();
  FUN_00550990();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return puVar1;
}



/* FUNCTION 19429 ; VA 0x009ea810 ; FUN_009ea810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009ea810(int *param_1,undefined4 *param_2,byte *param_3,int *param_4)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  undefined4 *puVar12;
  byte *pbVar13;
  undefined *puVar14;
  undefined auStack_118 [200];
  undefined auStack_50 [4];
  int *piStack_4c;
  undefined auStack_48 [4];
  int *piStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8024;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if ((param_3 == (byte *)0x0) || (*(int *)(param_3 + 8) == 0)) {
    ExceptionList = &pvStack_10;
    piStack_14 = param_1;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid request options");
  }
  puVar10 = *(undefined4 **)(*(int *)(param_3 + 0x14) + *(int *)(param_3 + 4) * 4);
  ExceptionList = &pvStack_10;
  do {
    piStack_14 = param_1;
    if (puVar10 == (undefined4 *)0x0) {
      auStack_1c[0] = 0;
      cVar2 = FUN_00585a40(auStack_1c);
      if (cVar2 == '\0') {
        puVar14 = &DAT_0193c8ed;
      }
      else {
        puVar14 = (undefined *)0x0;
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      FUN_009e9eb0(&iStack_24,param_3,param_4,puVar14);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (iStack_24 == 0) {
        *param_2 = 0;
        param_2[1] = 0;
      }
      else {
        iVar4 = FUN_008f7870(param_1);
        uStack_28 = iVar4;
        if ((iVar4 != 0) && (*(int *)(iVar4 + 0x4a0) != 3)) {
          uVar5 = FUN_014ca0a0();
          cVar2 = FUN_014cd2d0(uVar5);
          if ((cVar2 == '\0') && (iVar4 != -0xc)) {
            FUN_005789c0(&DAT_01eadc4c,&LAB_0064e290);
            uVar5 = FUN_0064e320();
            piVar6 = (int *)FUN_008aa140(uVar5);
            if (*piVar6 == 0) {
              uVar5 = FUN_00bc47d0();
              piVar7 = (int *)FUN_008a9ba0(auStack_18,uVar5);
              iVar4 = *piVar7;
              iVar8 = piVar7[1];
              *piVar7 = 0;
              piVar7[1] = 0;
              *piVar6 = iVar4;
              piVar7 = (int *)piVar6[1];
              piVar6[1] = iVar8;
              if (piVar7 != (int *)0x0) {
                LOCK();
                iVar4 = piVar7[1] + -1;
                piVar7[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)*piVar7)();
                  LOCK();
                  iVar4 = piVar7[2] + -1;
                  piVar7[2] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar7 + 4))();
                  }
                }
              }
              piVar7 = piStack_14;
              if (piStack_14 != (int *)0x0) {
                LOCK();
                iVar4 = piStack_14[1] + -1;
                piStack_14[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)*piStack_14)();
                  LOCK();
                  piVar1 = piVar7 + 2;
                  iVar4 = *piVar1 + -1;
                  *piVar1 = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar7 + 4))();
                  }
                }
              }
            }
            if (*piVar6 != 0) {
              uVar5 = FUN_014ca0a0();
              cVar2 = FUN_00bcc980(uVar5);
              if (cVar2 == '\0') {
                    /* WARNING: Subroutine does not return */
                FUN_016757c0("HttpRequest.Url is not trusted");
              }
            }
          }
        }
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        FUN_005542c0("Priority",8);
        pbVar13 = param_3 + *param_3 + 1;
        uVar5 = FUN_0055c740(pbVar13,auStack_40);
        FUN_00562fc0(&piStack_14,uVar5,auStack_40,
                     -(uint)(pbVar13 != (byte *)0x0) & (uint)(pbVar13 + 1));
        if (0xf < uStack_2c) {
          uVar11 = uStack_2c + 1;
          uVar3 = auStack_40[0];
          if (0xfff < uVar11) {
            uVar3 = *(uint *)(auStack_40[0] - 4);
            uVar11 = uStack_2c + 0x24;
            if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar3,uVar11);
        }
        piVar6 = piStack_14;
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        if (piStack_14 != (int *)0x0) {
          iVar4 = piStack_14[8];
          if (*(char *)(iVar4 + 0x20) == '\0') {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("HttpRequest.Priority must be a float");
          }
          iVar8 = FUN_0088c960();
          if (iVar4 == iVar8) {
            iVar4 = piVar6[8];
            iVar8 = FUN_0088c960();
            if (iVar4 != iVar8) {
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("Variant cast failed");
            }
            piVar7 = piVar6 + 10;
            if (piVar6[9] == 0) {
              piVar7 = (int *)0x0;
            }
            piVar6 = (int *)*piVar7;
          }
          else {
            puVar10 = (undefined4 *)piVar6[9];
            if (puVar10 != (undefined4 *)0x0) {
              (*(code *)*puVar10)(piVar6 + 10,auStack_118);
              puVar10 = (undefined4 *)piVar6[9];
            }
            uStack_8._0_1_ = 2;
            puVar9 = (undefined4 *)FUN_008894a0();
            piStack_14 = (int *)*puVar9;
            uStack_8._0_1_ = 3;
            if (puVar10 != (undefined4 *)0x0) {
              (*(code *)puVar10[2])(auStack_118);
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            piVar6 = piStack_14;
          }
          FUN_014cba70(piVar6);
        }
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        FUN_005542c0("Timeout",7);
        pbVar13 = param_3 + *param_3 + 1;
        uVar5 = FUN_0055c740(pbVar13,auStack_40);
        FUN_00562fc0(&piStack_14,uVar5,auStack_40,
                     -(uint)(pbVar13 != (byte *)0x0) & (uint)(pbVar13 + 1));
        if (0xf < uStack_2c) {
          uVar11 = uStack_2c + 1;
          uVar3 = auStack_40[0];
          if (0xfff < uVar11) {
            uVar3 = *(uint *)(auStack_40[0] - 4);
            uVar11 = uStack_2c + 0x24;
            if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar3,uVar11);
        }
        piVar6 = piStack_14;
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        if (piStack_14 != (int *)0x0) {
          iVar4 = piStack_14[8];
          if (*(char *)(iVar4 + 0x21) == '\0') {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("HttpRequest.Timeout must be a number");
          }
          iVar8 = FUN_0088c8c0();
          if (iVar4 == iVar8) {
            iVar4 = piVar6[8];
            iVar8 = FUN_0088c8c0();
            if (iVar4 != iVar8) {
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("Variant cast failed");
            }
            piVar7 = piVar6 + 10;
            if (piVar6[9] == 0) {
              piVar7 = (int *)0x0;
            }
            iVar4 = *piVar7;
          }
          else {
            puVar10 = (undefined4 *)piVar6[9];
            if (puVar10 != (undefined4 *)0x0) {
              (*(code *)*puVar10)(piVar6 + 10,auStack_118);
              puVar10 = (undefined4 *)piVar6[9];
            }
            uStack_8._0_1_ = 4;
            piVar6 = (int *)FUN_00889220();
            iVar4 = *piVar6;
            uStack_8._0_1_ = 5;
            if (puVar10 != (undefined4 *)0x0) {
              (*(code *)puVar10[2])(auStack_118);
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
          }
          FUN_0146d260(iVar4);
        }
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        FUN_005542c0("CachePolicy",0xb);
        pbVar13 = param_3 + *param_3 + 1;
        uVar5 = FUN_0055c740(pbVar13,auStack_40);
        FUN_00562fc0(&piStack_14,uVar5,auStack_40,
                     -(uint)(pbVar13 != (byte *)0x0) & (uint)(pbVar13 + 1));
        FUN_005507b0();
        piVar6 = piStack_14;
        if (piStack_14 != (int *)0x0) {
          iVar4 = piStack_14[8];
          iVar8 = thunk_FUN_00e0eaa0();
          if (iVar4 != iVar8) {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("HttpRequest.CachePolicy must be an Enum.HttpCachePolicy");
          }
          iVar4 = piVar6[8];
          iVar8 = thunk_FUN_00e0eaa0();
          if (iVar4 == iVar8) {
            iVar4 = piVar6[8];
            iVar8 = thunk_FUN_00e0eaa0();
            if (iVar4 != iVar8) {
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("Variant cast failed");
            }
            piVar7 = piVar6 + 10;
            if (piVar6[9] == 0) {
              piVar7 = (int *)0x0;
            }
            iVar4 = *piVar7;
          }
          else {
            puVar10 = (undefined4 *)piVar6[9];
            if (puVar10 != (undefined4 *)0x0) {
              (*(code *)*puVar10)(piVar6 + 10,auStack_118);
              puVar10 = (undefined4 *)piVar6[9];
            }
            uStack_8._0_1_ = 6;
            piVar6 = (int *)FUN_00e0ce40();
            iVar4 = *piVar6;
            uStack_8._0_1_ = 7;
            if (puVar10 != (undefined4 *)0x0) {
              (*(code *)puVar10[2])(auStack_118);
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
          }
          FUN_014cb890(iVar4);
        }
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        FUN_005542c0(&DAT_0193beb0,0xb);
        param_3 = param_3 + *param_3 + 1;
        uVar5 = FUN_0055c740(param_3,auStack_40);
        FUN_00562fc0(&piStack_14,uVar5,auStack_40,
                     -(uint)(param_3 != (byte *)0x0) & (uint)(param_3 + 1));
        FUN_005507b0();
        piVar6 = piStack_14;
        if (piStack_14 != (int *)0x0) {
          iVar4 = piStack_14[8];
          iVar8 = thunk_FUN_0090c030();
          if (iVar4 != iVar8) {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("HttpRequest.RequestType must be an Enum.HttpRequestType");
          }
          iVar4 = piVar6[8];
          iVar8 = thunk_FUN_0090c030();
          if (iVar4 == iVar8) {
            iVar4 = piVar6[8];
            iVar8 = thunk_FUN_0090c030();
            if (iVar4 != iVar8) {
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("Variant cast failed");
            }
            piVar7 = piVar6 + 10;
            if (piVar6[9] == 0) {
              piVar7 = (int *)0x0;
            }
            iVar4 = *piVar7;
          }
          else {
            puVar10 = (undefined4 *)piVar6[9];
            if (puVar10 != (undefined4 *)0x0) {
              (*(code *)*puVar10)(piVar6 + 10,auStack_118);
              puVar10 = (undefined4 *)piVar6[9];
            }
            uStack_8._0_1_ = 8;
            piVar6 = (int *)FUN_00bc51f0();
            iVar4 = *piVar6;
            uStack_8._0_1_ = 9;
            if (puVar10 != (undefined4 *)0x0) {
              (*(code *)puVar10[2])(auStack_118);
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
          }
          iVar8 = 0;
          if (iVar4 < 0x1d) {
            iVar8 = iVar4;
          }
          *(int *)(iStack_24 + 0xb0) = iVar8;
        }
        uVar5 = FUN_005e5de0(auStack_48,uStack_28);
        uStack_8 = CONCAT31(uStack_8._1_3_,10);
        puVar10 = (undefined4 *)FUN_009e24c0(auStack_50,&iStack_24,uVar5);
        piVar6 = piStack_4c;
        piStack_14 = (int *)*puVar10;
        uStack_28 = puVar10[1];
        *puVar10 = 0;
        puVar10[1] = 0;
        if (piStack_4c != (int *)0x0) {
          LOCK();
          iVar4 = piStack_4c[1] + -1;
          piStack_4c[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_4c)();
            LOCK();
            piVar7 = piVar6 + 2;
            iVar4 = *piVar7 + -1;
            *piVar7 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        if (piStack_44 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_44[2] + -1;
          piStack_44[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_44 + 4))();
          }
        }
        *param_2 = piStack_14;
        param_2[1] = uStack_28;
      }
      piVar6 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_20[1] + -1;
        piStack_20[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar7 = piVar6 + 2;
          iVar4 = *piVar7 + -1;
          *piVar7 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar4 = param_4[1] + -1;
        param_4[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*param_4)();
          LOCK();
          piVar6 = param_4 + 2;
          iVar4 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*param_4 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_2;
    }
    piVar6 = puVar10 + 2;
    if (DAT_01d65548 == '\0') {
      uVar3 = puVar10[7];
      puVar9 = &DAT_01d65608;
      if (0xf < DAT_01d6561c) {
        puVar9 = DAT_01d65608;
      }
      piVar7 = piVar6;
      if (0xf < uVar3) {
        piVar7 = (int *)*piVar6;
      }
      cVar2 = FUN_0055c360(piVar7,puVar10[6],puVar9,DAT_01d65618);
      if (cVar2 == '\0') {
        piVar7 = piVar6;
        if (0xf < uVar3) {
          piVar7 = (int *)*piVar6;
        }
        cVar2 = FUN_0055c360(piVar7,puVar10[6],&DAT_018c8720,3);
        if (cVar2 == '\0') {
          piVar7 = piVar6;
          if (0xf < uVar3) {
            piVar7 = (int *)*piVar6;
          }
          cVar2 = FUN_0055c360(piVar7,puVar10[6],&DAT_018c3bf4,4);
          if (cVar2 == '\0') {
            piVar7 = piVar6;
            if (0xf < uVar3) {
              piVar7 = (int *)*piVar6;
            }
            cVar2 = FUN_0055c360(piVar7,puVar10[6],"Headers",7);
            if (cVar2 == '\0') {
              piVar7 = piVar6;
              if (0xf < uVar3) {
                piVar7 = (int *)*piVar6;
              }
              cVar2 = FUN_0055c360(piVar7,puVar10[6],"Timeout",7);
              if (cVar2 == '\0') {
                piVar7 = piVar6;
                if (0xf < uVar3) {
                  piVar7 = (int *)*piVar6;
                }
                cVar2 = FUN_0055c360(piVar7,puVar10[6],"Priority",8);
                if (cVar2 == '\0') {
                  piVar7 = piVar6;
                  if (0xf < uVar3) {
                    piVar7 = (int *)*piVar6;
                  }
                  cVar2 = FUN_0055c360(piVar7,puVar10[6],"CachePolicy",0xb);
                  if (cVar2 == '\0') {
                    if (0xf < uVar3) {
                      piVar6 = (int *)*piVar6;
                    }
                    cVar2 = FUN_0055c360(piVar6,puVar10[6],&DAT_0193beb0,0xb);
                    if (cVar2 == '\0') {
                      uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
                      FUN_016757c0("Unrecognized request option %s",uVar5);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    else {
      if (0xf < (uint)puVar10[7]) {
        piVar6 = (int *)*piVar6;
      }
      uVar11 = 0;
      uVar3 = 0x811c9dc5;
      if (puVar10[6] != 0) {
        uVar3 = 0x811c9dc5;
        do {
          pbVar13 = (byte *)(uVar11 + (int)piVar6);
          uVar11 = uVar11 + 1;
          uVar3 = (*pbVar13 ^ uVar3) * 0x1000193;
        } while (uVar11 < (uint)puVar10[6]);
      }
      puVar9 = puVar10 + 2;
      piStack_44 = (int *)(uVar3 & _DAT_01ee5478);
      piVar6 = *(int **)(DAT_01ee546c + (int)piStack_44 * 8);
      piStack_20 = piVar6;
      while( true ) {
        piVar7 = DAT_01ee5464;
        if (piStack_20 != DAT_01ee5464) {
          piVar7 = (int *)**(undefined4 **)(DAT_01ee546c + 4 + (int)piStack_44 * 8);
        }
        if (piVar6 == piVar7) goto LAB_009eb1ec;
        piVar7 = piVar6 + 2;
        puVar12 = puVar9;
        if (0xf < (uint)puVar10[7]) {
          puVar12 = (undefined4 *)*puVar9;
        }
        piStack_4c = (int *)piVar6[6];
        uStack_28 = piVar6[7];
        if (0xf < uStack_28) {
          piVar7 = (int *)*piVar7;
        }
        cVar2 = FUN_0055c360(piVar7,piStack_4c,puVar12,puVar10[6]);
        if (cVar2 != '\0') break;
        piVar6 = (int *)*piVar6;
      }
      piVar7 = piVar6 + 2;
      if (0xf < uStack_28) {
        piVar7 = (int *)*piVar7;
      }
      if (0xf < (uint)puVar10[7]) {
        puVar9 = (undefined4 *)*puVar9;
      }
      cVar2 = FUN_0055c360(puVar9,puVar10[6],piVar7,piStack_4c);
      if (cVar2 == '\0') {
        piVar6 = DAT_01ee5464;
      }
      if (piVar6 == DAT_01ee5464) {
LAB_009eb1ec:
        uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Unrecognized request option \'%s\'",uVar5);
      }
    }
    puVar10 = (undefined4 *)*puVar10;
    param_1 = piStack_14;
  } while( true );
}



/* FUNCTION 19430 ; VA 0x009eb280 ; FUN_009eb280 */

uint FUN_009eb280(undefined4 param_1,int *param_2,uint param_3,int *param_4,undefined param_5)

{
  uint *puVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  char *pcVar7;
  char *pcVar8;
  int *piVar9;
  undefined4 uVar10;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint uStack_24;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8048;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0xffffffff;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*param_2 + 4))();
    iVar4 = FUN_01723e00();
    if (iVar4 == 0) {
      (**(code **)(*param_2 + 4))();
      uVar5 = FUN_01717cb5();
      if (0x11 < uVar5) {
        (**(code **)(*param_2 + 4))();
        uStack_18 = FUN_01717832();
      }
    }
  }
  uStack_24 = 0;
  piVar9 = (int *)0x0;
  if (param_4 != (int *)0x0) {
    piVar9 = param_4 + 1;
    iVar4 = param_4[1];
    while (iVar4 != 0) {
      LOCK();
      iVar6 = *piVar9;
      if (iVar4 == iVar6) {
        *piVar9 = iVar4 + 1;
        iVar6 = iVar4;
      }
      UNLOCK();
      if (iVar6 == iVar4) {
        uStack_24 = param_3;
        piVar9 = param_4;
        goto LAB_009eb33a;
      }
      iVar4 = *piVar9;
    }
    piVar9 = (int *)0x0;
  }
LAB_009eb33a:
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar5 = uStack_24;
  if (uStack_24 != 0) {
    iVar4 = *(int *)(uStack_24 + 0xc);
    iVar6 = FUN_008dcf60();
    uVar5 = (uint)*(ushort *)(iVar6 + 0x1da);
    if (((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <= uVar5) &&
       (uStack_24 != 0xc)) {
      if (param_2 == (int *)0x0) {
        pcVar7 = "";
      }
      else {
        pcVar7 = (char *)(**(code **)(*param_2 + 4))();
      }
      uStack_3c = uStack_3c & 0xffffff00;
      uVar10 = 0;
      pcVar8 = pcVar7;
      do {
        cVar3 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar3 != '\0');
      FUN_005542c0(pcVar7,(int)pcVar8 - (int)(pcVar7 + 1));
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_009e1980(param_2 != (int *)0x0,uStack_18,param_5,uStack_3c,uStack_38,uStack_34,uStack_30,
                   0xf00000000,uVar10);
      uVar5 = FUN_0090ca30();
    }
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar9 + 1);
    uVar2 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      puVar1 = (uint *)(piVar9 + 2);
      uVar2 = *puVar1;
      uVar5 = *puVar1;
      *puVar1 = uVar2 - 1;
      UNLOCK();
      if (uVar2 - 1 == 0) {
        uVar5 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar9 = param_4 + 2;
    iVar4 = *piVar9;
    *piVar9 = *piVar9 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      uVar5 = (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 19431 ; VA 0x009eb480 ; FUN_009eb480 */

void __thiscall FUN_009eb480(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0xe2)) {
    *(char *)(param_1 + 0xe2) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 19432 ; VA 0x009eb4b0 ; FUN_009eb4b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009eb4b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8076;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee5714) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee5714);
    if (DAT_01ee5714 == -1) {
      uStack_8 = 0;
      FUN_009ca470("HttpContentType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee56b0 = RBX::Reflection::EnumDesc<enum_RBX::HttpService::HttpContentType>::vftable;
      FUN_009caf20(&DAT_01d65638,5);
      FUN_016f3654(&LAB_018881c0);
      FUN_016f37bf(&DAT_01ee5714);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee56b0;
}



/* FUNCTION 19433 ; VA 0x009eb560 ; FUN_009eb560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009eb560(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee5724) {
    FUN_016f3809(&DAT_01ee5724);
    if (DAT_01ee5724 == -1) {
      _DAT_01ee5718 = FUN_005c65e0;
      _DAT_01ee571c = FUN_005c65e0;
      _DAT_01ee5720 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee5724);
    }
  }
  return &DAT_01ee5718;
}



/* FUNCTION 19434 ; VA 0x009eb5d0 ; FUN_009eb5d0 */

int FUN_009eb5d0(void)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8090;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008f7870();
  iVar2 = iVar1;
  if ((iVar1 != 0) && (iVar2 = FUN_005cf2a0(), iVar2 != 0)) {
    iStack_14 = iVar2;
    piVar3 = (int *)FUN_005e5de0(auStack_24,iVar1);
    piVar4 = (int *)0x0;
    iVar2 = piVar3[1];
    if (iVar2 != 0) {
      piVar5 = (int *)(iVar2 + 4);
      iVar2 = *(int *)(iVar2 + 4);
      while (iVar2 != 0) {
        LOCK();
        iVar1 = *piVar5;
        if (iVar2 == iVar1) {
          *piVar5 = iVar2 + 1;
          iVar1 = iVar2;
        }
        UNLOCK();
        if (iVar1 == iVar2) {
          piVar4 = (int *)piVar3[1];
          iStack_1c = *piVar3;
          if (piVar4 != (int *)0x0) {
            LOCK();
            piVar4[2] = piVar4[2] + 1;
            UNLOCK();
          }
          if (iStack_1c != 0) {
            iStack_1c = iStack_1c + 0xc;
            goto LAB_009eb654;
          }
          break;
        }
        iVar2 = *piVar5;
      }
    }
    iStack_1c = 0;
LAB_009eb654:
    piStack_18 = piVar4;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar2 = piVar4[1] + -1;
      piVar4[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar2 = piVar4[2] + -1;
        piVar4[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    *piVar3 = 0;
    piVar5 = (int *)piVar3[1];
    piVar3[1] = 0;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    uStack_8 = 0;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[2] + -1;
      piStack_20[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
    piVar3 = piVar4 + 2;
    if (piVar4 != (int *)0x0) {
      LOCK();
      *piVar3 = *piVar3 + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piVar4 != (int *)0x0) {
      LOCK();
      *piVar3 = *piVar3 + 1;
      UNLOCK();
      LOCK();
      *piVar3 = *piVar3 + 1;
      UNLOCK();
    }
    FUN_009e1850(iStack_1c,piVar4,0);
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
    iVar2 = FUN_009eef30();
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar3;
      iVar2 = *piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar2 = (**(code **)(*piVar4 + 4))();
      }
      LOCK();
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar2 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 19435 ; VA 0x009eb780 ; FUN_009eb780 */

undefined4 __thiscall FUN_009eb780(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar1 = &param_3;
  if (0xf < in_stack_0000001c) {
    puVar1 = param_3;
  }
  ExceptionList = &pvStack_10;
  FUN_0151d700(param_2,puVar1,in_stack_00000018,param_1);
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    puVar1 = param_3;
    if (0xfff < uVar2) {
      puVar1 = (undefined4 *)param_3[-1];
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19436 ; VA 0x009eb810 ; FUN_009eb810 */

void FUN_009eb810(uint param_1)

{
  int *piVar1;
  undefined uVar2;
  char **ppcVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  uint *puVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  char cStack0000001c;
  int in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_000000f0;
  uint in_stack_000000f8;
  undefined4 in_stack_000000fc;
  undefined4 in_stack_00000100;
  undefined4 in_stack_00000104;
  undefined8 in_stack_00000108;
  char *in_stack_00000110;
  uint in_stack_00000118;
  undefined4 in_stack_0000011c;
  undefined4 in_stack_00000120;
  undefined4 *in_stack_00000124;
  uint *in_stack_00000128;
  undefined4 in_stack_0000012c;
  undefined4 *puVar11;
  char *pcStack_110;
  undefined4 uStack_10c;
  uint uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 *puStack_fc;
  uint *puStack_f8;
  int **ppiStack_f4;
  undefined auStack_e8 [16];
  undefined2 uStack_d8;
  undefined uStack_d6;
  uint uStack_80;
  int *piStack_7c;
  uint uStack_78;
  uint uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  char *pcStack_58;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  undefined8 uStack_40;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8101;
  pvStack_10 = ExceptionList;
  ppiStack_f4 = (int **)0x0;
  puStack_f8 = (uint *)0x1;
  puStack_fc = (undefined4 *)&DAT_01d65560;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  uStack_100 = 0x9eb84a;
  ExceptionList = &pvStack_10;
  FUN_008783f0();
  puStack_20 = (undefined *)&pcStack_110;
  pcStack_110 = (char *)0x0;
  ppcVar3 = &pcStack_110;
  if (in_stack_00000110 != (char *)0x0) {
    pcStack_110 = in_stack_00000110;
    if (((uint)in_stack_00000110 & 1) == 0) {
      (**(code **)((uint)in_stack_00000110 & 0xfffffffe))(&stack0x00000118,&uStack_108,0);
      ppcVar3 = (char **)puStack_20;
    }
    else {
      uStack_108 = in_stack_00000118;
      uStack_104 = in_stack_0000011c;
      uStack_100 = in_stack_00000120;
      puStack_fc = in_stack_00000124;
      puStack_f8 = in_stack_00000128;
      ppiStack_f4 = (int **)in_stack_0000012c;
      ppcVar3 = &pcStack_110;
    }
  }
  puStack_20 = (undefined *)ppcVar3;
  puVar11 = &param_1;
  cVar4 = FUN_009e41b0(puVar11);
  if (cVar4 == '\0') goto LAB_009ebba9;
  ppiStack_f4 = (int **)0x0;
  puStack_f8 = (uint *)0x3;
  puStack_fc = &param_1;
  uStack_100 = 0x9eb8c0;
  FUN_014cc090();
  uStack_8._0_1_ = 4;
  ppiStack_f4 = (int **)0x9eb8c9;
  cVar4 = FUN_00585a40();
  if (cVar4 == '\0') {
    uStack_d6 = 1;
  }
  if (cStack0000001c != '\0') {
    ppiStack_f4 = (int **)0xd;
    puStack_f8 = (uint *)0x193c084;
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = 0;
    puStack_fc = (undefined4 *)0x9eb907;
    FUN_005542c0();
    ppiStack_f4 = (int **)auStack_38;
    uStack_8._0_1_ = 5;
    puStack_f8 = (uint *)0x9eb91a;
    FUN_005d15d0();
    ppiStack_f4 = (int **)0x8;
    puStack_f8 = (uint *)0x193c094;
    puStack_fc = (undefined4 *)0x9eb929;
    FUN_005542c0();
    uStack_8._0_1_ = 4;
    ppiStack_f4 = (int **)0x9eb935;
    FUN_005507b0();
  }
  ppiStack_f4 = (int **)auStack_e8;
  puStack_f8 = (uint *)0x9eb943;
  FUN_009e3bb0();
  iVar8 = in_stack_00000020;
  ppiStack_f4 = (int **)0x9eb94b;
  iVar5 = FUN_00888530();
  iVar6 = in_stack_00000020;
  if (iVar8 == iVar5) {
LAB_009eba5e:
    ppiStack_f4 = (int **)auStack_e8;
    uStack_d8 = 0x101;
    puStack_f8 = &uStack_1c;
    puStack_fc = (undefined4 *)0x9eba77;
    FUN_009e23d0();
    piVar10 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    uStack_80 = uStack_1c;
    piStack_7c = piStack_18;
    uStack_8._0_1_ = 8;
    uStack_78 = 0;
    if (in_stack_000000f0 != 0) {
      uStack_78 = in_stack_000000f0;
      if ((in_stack_000000f0 & 1) == 0) {
        puStack_f8 = &uStack_70;
        ppiStack_f4 = (int **)0x0;
        puStack_fc = &stack0x000000f8;
        uStack_100 = 0x9ebb18;
        (**(code **)(in_stack_000000f0 & 0xfffffffe))();
      }
      else {
        uStack_70 = in_stack_000000f8;
        uStack_6c = in_stack_000000fc;
        uStack_68 = in_stack_00000100;
        uStack_64 = in_stack_00000104;
        uStack_60 = in_stack_00000108;
      }
    }
    uStack_8._0_1_ = 9;
    pcStack_58 = (char *)0x0;
    if (in_stack_00000110 != (char *)0x0) {
      pcStack_58 = in_stack_00000110;
      if (((uint)in_stack_00000110 & 1) == 0) {
        puStack_f8 = &uStack_50;
        ppiStack_f4 = (int **)0x0;
        puStack_fc = &stack0x00000118;
        uStack_100 = 0x9ebb65;
        (**(code **)((uint)in_stack_00000110 & 0xfffffffe))();
      }
      else {
        uStack_50 = in_stack_00000118;
        uStack_4c = in_stack_0000011c;
        uStack_48 = in_stack_00000120;
        puStack_44 = in_stack_00000124;
        uStack_40 = CONCAT44(in_stack_0000012c,in_stack_00000128);
      }
    }
    uStack_8._0_1_ = 10;
    ppiStack_f4 = (int **)0x9ebb74;
    FUN_009e3540();
    ppiStack_f4 = (int **)0x9ebb7c;
    FUN_009e2cd0();
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar8 = piVar10[1] + -1;
      piVar10[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        ppiStack_f4 = (int **)0x9ebb8f;
        (**(code **)*piVar10)();
        LOCK();
        piVar1 = piVar10 + 2;
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          ppiStack_f4 = (int **)0x9ebb9e;
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
  }
  else {
    ppiStack_f4 = (int **)0x9eb95e;
    iVar5 = FUN_008881d0();
    iVar8 = in_stack_00000020;
    if (iVar6 == iVar5) {
      ppiStack_f4 = (int **)0x9eb96e;
      iVar6 = FUN_008881d0();
      if (iVar8 != iVar6) {
LAB_009ebc7d:
        ppiStack_f4 = (int **)0x18c072c;
                    /* WARNING: Subroutine does not return */
        puStack_f8 = (uint *)0x9ebc87;
        FUN_016757c0();
      }
      puVar7 = (uint *)&stack0x00000028;
      if (in_stack_00000024 == 0) {
        puVar7 = (uint *)0x0;
      }
      piVar10 = (int *)puVar7[1];
      _cStack0000001c = piVar10;
      if (piVar10 != (int *)0x0) {
        LOCK();
        piVar10[1] = piVar10[1] + 1;
        UNLOCK();
        piVar10 = (int *)puVar7[1];
        _cStack0000001c = piVar10;
      }
      uStack_1c = *puVar7;
      ppiStack_f4 = (int **)0x0;
      uStack_8._0_1_ = 6;
      _cStack0000001c = piVar10;
      piStack_18 = piVar10;
      FUN_0054f510(&stack0x00000110);
      cVar4 = FUN_009e5ea0(&uStack_1c,puVar11);
      if (cVar4 != '\0') {
        ppiStack_f4 = &piStack_14;
        puStack_f8 = (uint *)0x9eb9dc;
        FUN_00618a80();
        for (piVar1 = piStack_14; piVar1 != (int *)0x0; piVar1 = (int *)*piVar1) {
          iVar8 = piVar1[8];
          ppiStack_f4 = (int **)0x9eb9eb;
          iVar6 = FUN_0088cb40();
          if (iVar8 != iVar6) goto LAB_009ebc7d;
          ppiStack_f4 = (int **)(piVar1 + 2);
          piVar10 = piVar1 + 10;
          if (piVar1[9] == 0) {
            piVar10 = (int *)0x0;
          }
          puStack_f8 = (uint *)0x9eba0d;
          iVar8 = FUN_005d15d0();
          if ((int *)(iVar8 + 0x18) != piVar10) {
            ppiStack_f4 = (int **)piVar10[4];
            if (0xf < (uint)piVar10[5]) {
              piVar10 = (int *)*piVar10;
            }
            puStack_fc = (undefined4 *)0x9eba28;
            puStack_f8 = (uint *)piVar10;
            FUN_005542c0();
          }
          piVar10 = _cStack0000001c;
        }
        uStack_8._0_1_ = 4;
        if (piVar10 != (int *)0x0) {
          LOCK();
          iVar8 = piVar10[1] + -1;
          piVar10[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            ppiStack_f4 = (int **)0x9eba4b;
            (**(code **)*piVar10)();
            LOCK();
            iVar8 = piVar10[2] + -1;
            piVar10[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              ppiStack_f4 = (int **)0x9eba5b;
              (**(code **)(*piVar10 + 4))();
            }
          }
        }
        goto LAB_009eba5e;
      }
      ppiStack_f4 = (int **)0x9eb9cc;
      FUN_00550b30();
    }
    else {
      uStack_10c = 0x23;
      puStack_f8 = (uint *)0x0;
      ppiStack_f4 = (int **)0xf;
      pcStack_110 = "headers value must be a dictionary!";
      uStack_108 = uStack_108 & 0xffffff00;
      FUN_005542c0();
      uStack_10c = 0x9ebaff;
      FUN_005e65e0();
    }
  }
  ppiStack_f4 = (int **)0x9ebba9;
  FUN_0056db40();
LAB_009ebba9:
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000018) {
    ppiStack_f4 = (int **)(in_stack_00000018 + 1);
    uVar9 = param_1;
    if (0xfff < ppiStack_f4) {
      uVar9 = *(uint *)(param_1 - 4);
      ppiStack_f4 = (int **)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        ppiStack_f4 = (int **)&UNK_009ebc8c;
        uStack_8._0_1_ = uVar2;
        FUN_017167a3();
      }
    }
    puStack_fc = (undefined4 *)0x9ebbde;
    puStack_f8 = (uint *)uVar9;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  uStack_8._0_1_ = 0x13;
  if (in_stack_00000024 != 0) {
    ppiStack_f4 = (int **)&stack0x00000028;
    puStack_f8 = (uint *)0x9ebc07;
    (**(code **)(in_stack_00000024 + 8))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  if (in_stack_000000f0 != 0) {
    if (((in_stack_000000f0 & 1) == 0) &&
       (*(code **)(in_stack_000000f0 & 0xfffffffe) != (code *)0x0)) {
      puStack_fc = &stack0x000000f8;
      ppiStack_f4 = (int **)0x2;
      uStack_100 = 0x9ebc31;
      puStack_f8 = puStack_fc;
      (**(code **)(in_stack_000000f0 & 0xfffffffe))();
    }
    in_stack_000000f0 = 0;
  }
  uStack_8 = 0x15;
  if (((in_stack_00000110 != (char *)0x0) && (((uint)in_stack_00000110 & 1) == 0)) &&
     (*(code **)((uint)in_stack_00000110 & 0xfffffffe) != (code *)0x0)) {
    puStack_fc = &stack0x00000118;
    ppiStack_f4 = (int **)0x2;
    uStack_100 = 0x9ebc68;
    puStack_f8 = puStack_fc;
    (**(code **)((uint)in_stack_00000110 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19437 ; VA 0x009ebc90 ; FUN_009ebc90 */

void FUN_009ebc90(uint *param_1)

{
  int iVar1;
  undefined uVar2;
  char **ppcVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  uint *puVar7;
  uint uVar8;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  int in_stack_0000002c;
  uint in_stack_00000030;
  undefined4 *in_stack_00000034;
  undefined in_stack_00000038;
  int in_stack_0000003c;
  int in_stack_00000040;
  uint in_stack_0000010c;
  uint in_stack_00000114;
  undefined4 in_stack_00000118;
  undefined4 in_stack_0000011c;
  undefined4 in_stack_00000120;
  undefined8 in_stack_00000124;
  char *in_stack_0000012c;
  uint in_stack_00000134;
  undefined4 in_stack_00000138;
  undefined4 in_stack_0000013c;
  undefined4 *in_stack_00000140;
  uint *in_stack_00000144;
  undefined4 in_stack_00000148;
  undefined4 *puVar9;
  char *pcStack_140;
  undefined *puStack_13c;
  uint uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 *puStack_12c;
  uint *puStack_128;
  undefined4 *puStack_124;
  undefined auStack_118 [16];
  undefined2 uStack_108;
  undefined uStack_106;
  undefined4 uStack_b0;
  undefined *puStack_ac;
  undefined uStack_78;
  uint uStack_70;
  uint uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  char *pcStack_50;
  uint uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  undefined8 uStack_38;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8195;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  if ((DAT_01d65558 == '\0') && (DAT_01f2ddc0 != 0)) {
    puStack_13c = &DAT_01d654c0;
    pcStack_140 = (char *)0x9ebcda;
    ExceptionList = &pvStack_10;
    FUN_0054ef60();
    puStack_13c = (undefined *)0x9ebce5;
    FUN_005e65e0();
    goto LAB_009ec04d;
  }
  puStack_124 = (undefined4 *)0x0;
  puStack_128 = (uint *)0x1;
  puStack_12c = (undefined4 *)&DAT_01d65578;
  uStack_130 = 0x9ebcf8;
  ExceptionList = &pvStack_10;
  FUN_008783f0();
  puStack_14 = (undefined *)&pcStack_140;
  pcStack_140 = (char *)0x0;
  ppcVar3 = &pcStack_140;
  if (in_stack_0000012c != (char *)0x0) {
    pcStack_140 = in_stack_0000012c;
    if (((uint)in_stack_0000012c & 1) == 0) {
      (**(code **)((uint)in_stack_0000012c & 0xfffffffe))(&stack0x00000134,&uStack_138,0);
      ppcVar3 = (char **)puStack_14;
    }
    else {
      uStack_138 = in_stack_00000134;
      uStack_134 = in_stack_00000138;
      uStack_130 = in_stack_0000013c;
      puStack_12c = in_stack_00000140;
      puStack_128 = in_stack_00000144;
      puStack_124 = (undefined4 *)in_stack_00000148;
      ppcVar3 = &pcStack_140;
    }
  }
  puStack_14 = (undefined *)ppcVar3;
  puVar9 = &param_1;
  cVar4 = FUN_009e41b0(puVar9);
  if (cVar4 == '\0') goto LAB_009ec04d;
  puStack_124 = (undefined4 *)0x0;
  puStack_128 = (uint *)0x3;
  puStack_12c = &param_1;
  uStack_130 = 0x9ebd6e;
  FUN_014cc090();
  uStack_8._0_1_ = 5;
  puStack_124 = (undefined4 *)0x9ebd77;
  cVar4 = FUN_00585a40();
  uStack_20 = 0;
  if (cVar4 == '\0') {
    uStack_106 = 1;
  }
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  switch(in_stack_00000034) {
  case (undefined4 *)0x0:
    puStack_124 = &DAT_01d79f98;
    break;
  case (undefined4 *)0x1:
    puStack_124 = &DAT_01d79fb0;
    break;
  case (undefined4 *)0x2:
    puStack_124 = &DAT_01d79f80;
    break;
  case (undefined4 *)0x3:
    puStack_124 = &DAT_01d79fc8;
    break;
  case (undefined4 *)0x4:
    puStack_124 = &DAT_01d79fe0;
    break;
  default:
    puStack_13c = (undefined *)0x18;
    pcStack_140 = "Unsupported content type";
    goto LAB_009ec019;
  }
  puStack_128 = (uint *)0x9ebde0;
  FUN_00551230();
  if (in_stack_0000002c == 0) {
    puStack_124 = (undefined4 *)0x1;
    puStack_128 = (uint *)&DAT_018c0cc8;
    puStack_12c = (undefined4 *)0x9ebdf5;
    FUN_005542c0();
  }
  puStack_124 = (undefined4 *)auStack_118;
  puStack_128 = (uint *)0x9ebe03;
  FUN_009e3bb0();
  iVar6 = in_stack_0000003c;
  puStack_124 = (undefined4 *)0x9ebe0b;
  iVar5 = FUN_00888530();
  iVar1 = in_stack_0000003c;
  if (iVar6 == iVar5) {
LAB_009ebec8:
    puStack_124 = (undefined4 *)auStack_118;
    uStack_108 = 0x101;
    puStack_128 = &uStack_18;
    puStack_12c = (undefined4 *)0x9ebee1;
    FUN_009e23d0();
    puStack_ac = puStack_14;
    if (puStack_14 != (undefined *)0x0) {
      LOCK();
      *(int *)(puStack_14 + 4) = *(int *)(puStack_14 + 4) + 1;
      UNLOCK();
    }
    uStack_b0 = uStack_18;
    puStack_124 = &stack0x0000001c;
    uStack_8._0_1_ = 9;
    puStack_128 = (uint *)0x9ebf25;
    FUN_0054ef60();
    puStack_124 = (undefined4 *)auStack_30;
    uStack_8._0_1_ = 10;
    puStack_128 = (uint *)0x9ebf38;
    FUN_0054ef60();
    uStack_78 = in_stack_00000038;
    uStack_8._0_1_ = 0xb;
    uStack_70 = 0;
    if (in_stack_0000010c != 0) {
      uStack_70 = in_stack_0000010c;
      if ((in_stack_0000010c & 1) == 0) {
        puStack_128 = &uStack_68;
        puStack_124 = (undefined4 *)0x0;
        puStack_12c = &stack0x00000114;
        uStack_130 = 0x9ebf99;
        (**(code **)(in_stack_0000010c & 0xfffffffe))();
      }
      else {
        uStack_68 = in_stack_00000114;
        uStack_64 = in_stack_00000118;
        uStack_60 = in_stack_0000011c;
        uStack_5c = in_stack_00000120;
        uStack_58 = in_stack_00000124;
      }
    }
    uStack_8._0_1_ = 0xc;
    pcStack_50 = (char *)0x0;
    if (in_stack_0000012c != (char *)0x0) {
      pcStack_50 = in_stack_0000012c;
      if (((uint)in_stack_0000012c & 1) == 0) {
        puStack_128 = &uStack_48;
        puStack_124 = (undefined4 *)0x0;
        puStack_12c = &stack0x00000134;
        uStack_130 = 0x9ebfe6;
        (**(code **)((uint)in_stack_0000012c & 0xfffffffe))();
      }
      else {
        uStack_48 = in_stack_00000134;
        uStack_44 = in_stack_00000138;
        uStack_40 = in_stack_0000013c;
        puStack_3c = in_stack_00000140;
        uStack_38 = CONCAT44(in_stack_00000148,in_stack_00000144);
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    puStack_124 = (undefined4 *)0x9ebff8;
    FUN_009e3300();
    puStack_124 = (undefined4 *)0x9ec003;
    FUN_009e2b90();
    puStack_124 = (undefined4 *)0x9ec00b;
    FUN_00550b30();
  }
  else {
    puStack_124 = (undefined4 *)0x9ebe1b;
    iVar6 = FUN_008881d0();
    if (iVar1 == iVar6) {
      puStack_124 = (undefined4 *)0x9ebe2b;
      puStack_124 = (undefined4 *)FUN_0055d640();
      puStack_128 = (uint *)0x9ebe34;
      FUN_00557fc0();
      puStack_124 = (undefined4 *)0x0;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_0054f510(&stack0x0000012c);
      cVar4 = FUN_009e5ea0(&uStack_18,puVar9);
      if (cVar4 != '\0') {
        puStack_124 = &stack0x00000034;
        puStack_128 = (undefined4 *)0x9ebe73;
        FUN_00618a80();
        for (puVar9 = in_stack_00000034; puVar9 != (undefined4 *)0x0; puVar9 = (undefined4 *)*puVar9
            ) {
          puStack_124 = (undefined4 *)0x9ebe8b;
          in_stack_00000034 = (undefined4 *)FUN_0055d610();
          puStack_128 = (undefined4 *)0x9ebe9a;
          puStack_124 = puVar9 + 2;
          iVar6 = FUN_005d15d0();
          if ((undefined4 *)(iVar6 + 0x18) != in_stack_00000034) {
            puStack_124 = (undefined4 *)in_stack_00000034[4];
            puStack_128 = in_stack_00000034;
            if (0xf < (uint)in_stack_00000034[5]) {
              puStack_128 = (uint *)*in_stack_00000034;
            }
            puStack_12c = (undefined4 *)0x9ebeb6;
            FUN_005542c0();
          }
        }
        uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        puStack_124 = (undefined4 *)0x9ebec8;
        FUN_00550b30();
        goto LAB_009ebec8;
      }
      puStack_124 = (undefined4 *)0x9ebe62;
      FUN_00550b30();
    }
    else {
      puStack_13c = (undefined *)0x23;
      pcStack_140 = "headers value must be a dictionary!";
LAB_009ec019:
      puStack_128 = (uint *)0x0;
      puStack_124 = (undefined4 *)0xf;
      uStack_138 = uStack_138 & 0xffffff00;
      FUN_005542c0();
      puStack_13c = (undefined *)0x9ec03a;
      FUN_005e65e0();
    }
  }
  puStack_124 = (undefined4 *)0x9ec042;
  FUN_005507b0();
  puStack_124 = (undefined4 *)0x9ec04d;
  FUN_0056db40();
LAB_009ec04d:
  uStack_8._0_1_ = 3;
  if (0xf < in_stack_00000018) {
    puStack_124 = (undefined4 *)(in_stack_00000018 + 1);
    puVar7 = param_1;
    if (0xfff < puStack_124) {
      puVar7 = (uint *)param_1[-1];
      puStack_124 = (undefined4 *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        puStack_124 = (undefined4 *)0x9ec170;
        FUN_017167a3();
      }
    }
    puStack_12c = (undefined4 *)0x9ec082;
    puStack_128 = puVar7;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (uint *)((uint)param_1 & 0xffffff00);
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000030) {
    puStack_124 = (undefined4 *)(in_stack_00000030 + 1);
    uVar8 = in_stack_0000001c;
    if (0xfff < puStack_124) {
      uVar8 = *(uint *)(in_stack_0000001c - 4);
      puStack_124 = (undefined4 *)(in_stack_00000030 + 0x24);
      if (0x1f < (in_stack_0000001c - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_124 = (undefined4 *)&UNK_009ec175;
        uStack_8._0_1_ = uVar2;
        FUN_017167a3();
      }
    }
    puStack_12c = (undefined4 *)0x9ec0cc;
    puStack_128 = (uint *)uVar8;
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  uStack_8._0_1_ = 0x16;
  if (in_stack_00000040 != 0) {
    puStack_124 = (undefined4 *)&stack0x00000044;
    puStack_128 = (uint *)0x9ec0f5;
    (**(code **)(in_stack_00000040 + 8))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
  if (in_stack_0000010c != 0) {
    if (((in_stack_0000010c & 1) == 0) &&
       (*(code **)(in_stack_0000010c & 0xfffffffe) != (code *)0x0)) {
      puStack_12c = &stack0x00000114;
      puStack_124 = (undefined4 *)0x2;
      uStack_130 = 0x9ec11f;
      puStack_128 = puStack_12c;
      (**(code **)(in_stack_0000010c & 0xfffffffe))();
    }
    in_stack_0000010c = 0;
  }
  uStack_8 = 0x18;
  if (((in_stack_0000012c != (char *)0x0) && (((uint)in_stack_0000012c & 1) == 0)) &&
     (*(code **)((uint)in_stack_0000012c & 0xfffffffe) != (code *)0x0)) {
    puStack_12c = &stack0x00000134;
    puStack_124 = (undefined4 *)0x2;
    uStack_130 = 0x9ec156;
    puStack_128 = puStack_12c;
    (**(code **)((uint)in_stack_0000012c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19438 ; VA 0x009ec190 ; FUN_009ec190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009ec190(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d81c0;
  pvStack_10 = ExceptionList;
  if (DAT_01ee57d4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee59e8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee59e8);
      if (DAT_01ee59e8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00ae2430();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ModuleScript",0,uStack_20,0,0,0x1b,0,&DAT_01ef0a34);
        _DAT_01ee59e0 = RBX::Creator<class_RBX::ModuleScript>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee57d8,&DAT_01ee59e0);
        FUN_016f3654(FUN_01888380);
        FUN_016f37bf(&DAT_01ee59e8);
      }
    }
    DAT_01ee57d4 = &DAT_01ee57d8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee57d4;
}



/* FUNCTION 19439 ; VA 0x009ec290 ; FUN_009ec290 */

undefined4 __thiscall FUN_009ec290(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00886600();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    uVar5 = FUN_00886360();
    FUN_008866a0(uVar5);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = FUN_00886600();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_008866a0(piVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 19440 ; VA 0x009ec390 ; FUN_009ec390 */

/* WARNING: Removing unreachable block (ram,0x009ec423) */

int * __thiscall
FUN_009ec390(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d81eb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088d190();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::ContentId>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19441 ; VA 0x009ec440 ; FUN_009ec440 */

undefined4 * __fastcall FUN_009ec440(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined **ppuVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined **ppuVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_30 [3];
  undefined uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8250;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_00ae3ac0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ModuleScript,class_RBX::LuaSourceContainer>::vftable
  ;
  uVar3 = FUN_009ec190();
  param_1[3] = uVar3;
  *param_1 = RBX::ModuleScript::vftable;
  param_1[0x32] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  FUN_008866d0();
  param_1[0x39] = 0;
  param_1[0x3a] = 0xf;
  *(undefined *)(param_1 + 0x35) = 0;
  *(undefined2 *)(param_1 + 0x3b) = 0;
  *(undefined *)((int)param_1 + 0xee) = 0;
  *(undefined *)(param_1 + 0x3c) = 0;
  uStack_14 = 0xb;
  ppuVar4 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar7 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar4;
  }
  param_1[0x3d] = *ppuVar7;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0x3f800000;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_20 = 0xc;
  FUN_0170cc70(auStack_30,"ModuleScript",0xc);
  uStack_24 = 0;
  uStack_8._0_1_ = 6;
  FUN_008a6520(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < uStack_1c) {
    uVar9 = uStack_1c + 1;
    uVar8 = auStack_30[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_30[0] - 4);
      uVar9 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  puVar5 = (undefined4 *)FUN_00a33fa0();
  puVar6 = puVar5 + 4;
  if (0xf < (uint)puVar5[5]) {
    puVar5 = (undefined4 *)*puVar5;
  }
  puVar6 = (undefined4 *)FUN_01531190(auStack_30,puVar5,*puVar6);
  if (param_1 + 0x35 != puVar6) {
    FUN_005507b0();
    uVar3 = puVar6[1];
    uVar1 = puVar6[2];
    uVar2 = puVar6[3];
    param_1[0x35] = *puVar6;
    param_1[0x36] = uVar3;
    param_1[0x37] = uVar1;
    param_1[0x38] = uVar2;
    *(undefined8 *)(param_1 + 0x39) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
  }
  if (0xf < uStack_1c) {
    uVar9 = uStack_1c + 1;
    uVar8 = auStack_30[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_30[0] - 4);
      uVar9 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19442 ; VA 0x009ec650 ; FUN_009ec650 */

void __fastcall FUN_009ec650(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ModuleScript>::vftable;
  uVar1 = FUN_009ec190(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19443 ; VA 0x009ec690 ; thunk_FUN_009ec770 */

void __fastcall thunk_FUN_009ec770(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0xc0);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  piVar1 = *(int **)(param_1 + 0xbc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_0056e380();
  FUN_0056e380();
  uVar4 = *(uint *)(param_1 + 0xa8);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x94);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_009ec8fc;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0xa4) = 0;
  *(undefined4 *)(param_1 + 0xa8) = 0xf;
  *(undefined *)(param_1 + 0x94) = 0;
  uVar4 = *(uint *)(param_1 + 0x90);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x7c);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_009ec8fc:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x8c) = 0;
  *(undefined4 *)(param_1 + 0x90) = 0xf;
  *(undefined *)(param_1 + 0x7c) = 0;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19444 ; VA 0x009ec6a0 ; FUN_009ec6a0 */

void __fastcall FUN_009ec6a0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_009ec910();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x34);
  }
  return;
}



/* FUNCTION 19445 ; VA 0x009ec6d0 ; FUN_009ec6d0 */

void __fastcall FUN_009ec6d0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_009ec910();
        FUN_01674ea0(puVar6,0x34);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 19446 ; VA 0x009ec760 ; FUN_009ec760 */

void __fastcall FUN_009ec760(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_009ec910();
        FUN_01674ea0(puVar6,0x34);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 19447 ; VA 0x009ec770 ; FUN_009ec770 */

void __fastcall FUN_009ec770(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0xc0);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  piVar1 = *(int **)(param_1 + 0xbc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_0056e380();
  FUN_0056e380();
  uVar4 = *(uint *)(param_1 + 0xa8);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x94);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_009ec8fc;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0xa4) = 0;
  *(undefined4 *)(param_1 + 0xa8) = 0xf;
  *(undefined *)(param_1 + 0x94) = 0;
  uVar4 = *(uint *)(param_1 + 0x90);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x7c);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_009ec8fc:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x8c) = 0;
  *(undefined4 *)(param_1 + 0x90) = 0xf;
  *(undefined *)(param_1 + 0x7c) = 0;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19448 ; VA 0x009ec910 ; FUN_009ec910 */

void __fastcall FUN_009ec910(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::ModuleScript::PerVMState::vftable;
  if (param_1[3] == 3) {
    if ((param_1[5] != 0) && (param_1[6] != -2)) {
      FUN_01258350(param_1[5],0xffffd8f0,param_1[6]);
    }
    param_1[5] = 0;
    param_1[6] = 0xfffffffe;
  }
  if (param_1[4] != 0) {
    FUN_00d89170();
    piVar2 = (int *)param_1[4];
    param_1[4] = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        FUN_00d889a0();
        FUN_01674ea0(piVar2,8);
      }
    }
  }
  FUN_00946e40();
  piVar2 = (int *)param_1[4];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar2 != (int *)0x0)) {
      FUN_00d889a0();
      FUN_01674ea0(piVar2,8);
    }
  }
  FUN_009abb30();
  FUN_01674ea0(param_1[1],0x14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19449 ; VA 0x009eca00 ; FUN_009eca00 */

uint * __thiscall FUN_009eca00(int param_1,uint *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8268;
  pvStack_10 = ExceptionList;
  uVar5 = *param_2;
  uVar10 = (uVar5 >> 3) + uVar5;
  uVar9 = uVar10 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)*puVar6;
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      if (uVar10 == puVar6[1]) {
        if (uVar5 == puVar6[2]) {
          if (puVar6 != (undefined4 *)0x0) {
            return puVar6 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar6[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_01674e20(0x34);
  *piVar3 = 0;
  piVar3[1] = 0;
  piVar3[3] = 0;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[9] = 0;
  piVar3[10] = 0;
  piVar3[0xb] = 0;
  piVar3[0xc] = 0;
  piVar3[2] = uVar5;
  piVar3[3] = (int)RBX::ModuleScript::PerVMState::vftable;
  piVar3[4] = 0;
  piVar3[5] = 0;
  iVar4 = FUN_0089c660();
  piVar3[4] = iVar4;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[9] = -2;
  piVar3[10] = 0;
  piVar3[0xb] = 0;
  piVar3[0xc] = 0;
  uVar9 = *(uint *)(param_1 + 8);
  uVar5 = uVar9 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar5 = FUN_005c9310(uVar5);
    if (uVar5 <= *(uint *)(param_1 + 4)) {
      uVar5 = *(uint *)(param_1 + 4);
    }
    FUN_00780ee0(uVar5);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar5) {
    uVar7 = uVar9 >> 1;
    if (uVar9 + (uVar9 >> 1) <= uVar5) {
      uVar7 = 1;
    }
    iVar4 = FUN_005c9310(uVar7 + uVar9);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_00780ee0(iVar4);
      puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar6;
      while (puVar2 != (undefined4 *)0x0) {
        uVar5 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar5 * 4) == 0) {
          *piVar1 = (int)puVar6;
          puVar6 = puVar2;
        }
        else {
          *puVar6 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar6;
      }
    }
  }
  piVar3[1] = uVar10;
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar10 % *(uint *)(param_1 + 4)) * 4);
  if ((int *)*piVar1 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar3;
    }
    *piVar1 = (int)piVar8;
    *piVar3 = *piVar8;
  }
  else {
    *piVar3 = *(int *)*piVar1;
    piVar8 = (int *)*piVar1;
  }
  *piVar8 = (int)piVar3;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (uint *)(piVar3 + 2);
}



/* FUNCTION 19450 ; VA 0x009ecc70 ; FUN_009ecc70 */

undefined4 __thiscall FUN_009ecc70(undefined4 param_1,byte param_2)

{
  FUN_009ec770();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,200);
  }
  return param_1;
}



/* FUNCTION 19451 ; VA 0x009ecca0 ; FUN_009ecca0 */

undefined4 * __thiscall FUN_009ecca0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ContentId>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 19452 ; VA 0x009eccd0 ; FUN_009eccd0 */

undefined4 * __thiscall FUN_009eccd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ProtectedString>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 19453 ; VA 0x009ecd00 ; FUN_009ecd00 */

undefined4 * __thiscall FUN_009ecd00(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ContentId>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 19454 ; VA 0x009ecd30 ; FUN_009ecd30 */

undefined4 * __thiscall FUN_009ecd30(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ProtectedString>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 19455 ; VA 0x009ecd60 ; FUN_009ecd60 */

int __thiscall FUN_009ecd60(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_009ec6d0();
  uVar1 = *(uint *)(param_1 + 0xe8);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xd4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xe4) = 0;
  *(undefined4 *)(param_1 + 0xe8) = 0xf;
  *(undefined *)(param_1 + 0xd4) = 0;
  FUN_0056e380();
  FUN_0056e380();
  FUN_016790b0();
  FUN_009ec770();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x108);
  }
  return param_1;
}



/* FUNCTION 19456 ; VA 0x009ece10 ; FUN_009ece10 */

undefined4 __thiscall FUN_009ece10(undefined4 param_1,byte param_2)

{
  FUN_009ec910();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 19457 ; VA 0x009ece40 ; FUN_009ece40 */

void __fastcall FUN_009ece40(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8318;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int *)(param_1 + 0x24) == *(int *)(param_1 + 0x20)) {
    ExceptionList = &pvStack_10;
    FUN_0093fe00(*(int *)(param_1 + 0x20),&stack0x00000004);
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_00d88710(&stack0x00000004);
    *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + 0x1c;
  }
  FUN_00d88aa0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19458 ; VA 0x009ecea0 ; FUN_009ecea0 */

int * FUN_009ecea0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017d8340;
  piVar2 = (int *)0x0;
  piStack_14 = (int *)0x0;
  iVar3 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    piVar5 = param_2 + 1;
    piVar1 = (int *)param_2[1];
    ExceptionList = &pvStack_10;
    while (piVar1 != (int *)0x0) {
      LOCK();
      piVar2 = (int *)*piVar5;
      if (piVar1 == piVar2) {
        *piVar5 = (int)piVar1 + 1;
        piVar2 = piVar1;
      }
      UNLOCK();
      if (piVar2 == piVar1) {
        piStack_14 = param_2;
        piVar2 = param_2;
        iVar3 = param_1;
        goto LAB_009ecef6;
      }
      piVar1 = (int *)*piVar5;
    }
    iVar3 = 0;
  }
LAB_009ecef6:
  uStack_8 = 1;
  if (iVar3 != 0) {
    if (*(int *)(iVar3 + 0xf8) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      piVar2 = *(int **)(iVar3 + 0xf4);
      puVar4 = *(undefined4 **)(*(int *)(iVar3 + 0x104) + (int)piVar2 * 4);
    }
    for (; puVar4 != (undefined4 *)0x0; puVar4 = (undefined4 *)*puVar4) {
      if (puVar4[6] == 3) {
        if ((puVar4[8] != 0) && (puVar4[9] != -2)) {
          FUN_01258350(puVar4[8],0xffffd8f0,puVar4[9]);
        }
        puVar4[8] = 0;
        puVar4[9] = 0xfffffffe;
      }
      if (puVar4[7] != 0) {
        FUN_00d89170();
        piVar2 = (int *)puVar4[7];
        puVar4[7] = 0;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            FUN_00d889a0();
            FUN_01674ea0(piVar2,8);
          }
        }
      }
      piVar2 = (int *)puVar4[0xb];
      piVar5 = (int *)puVar4[10];
      if (piVar5 != piVar2) {
        do {
          (**(code **)(*piVar5 + 4))(0);
          piVar5 = piVar5 + 7;
        } while (piVar5 != piVar2);
        piVar5 = (int *)puVar4[10];
      }
      puVar4[0xb] = piVar5;
      piVar2 = (int *)FUN_009abb30();
      puVar4[6] = 0;
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_14 + 1;
    iVar3 = *piVar5;
    piVar2 = (int *)*piVar5;
    *piVar5 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar5 = piStack_14 + 2;
      iVar3 = *piVar5;
      piVar2 = (int *)*piVar5;
      *piVar5 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar2 = (int *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar5 = param_2 + 2;
    iVar3 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      piVar2 = (int *)(**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 19459 ; VA 0x009ed030 ; FUN_009ed030 */

void __thiscall FUN_009ed030(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba938;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19460 ; VA 0x009ed0c0 ; FUN_009ed0c0 */

void __thiscall FUN_009ed0c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_18,param_2);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,auStack_18);
  FUN_0056e380();
  FUN_0056e380();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19461 ; VA 0x009ed130 ; FUN_009ed130 */

undefined4 * FUN_009ed130(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_005c30b0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 19462 ; VA 0x009ed1a0 ; FUN_009ed1a0 */

void __fastcall FUN_009ed1a0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = (**(code **)(param_1 + 8))();
  uVar2 = (**(code **)(param_1 + 8))();
  FUN_009cbaa0(uVar2,uVar1);
  return;
}



/* FUNCTION 19463 ; VA 0x009ed1d0 ; FUN_009ed1d0 */

undefined __fastcall FUN_009ed1d0(int param_1)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d8360;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(param_1 + 8))(auStack_20);
  uStack_8 = 0;
  uVar2 = (**(code **)(param_1 + 8))(auStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar1 = FUN_00886890(uVar2);
  FUN_0056e380();
  FUN_0056e380();
  FUN_0056e380();
  FUN_0056e380();
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19464 ; VA 0x009ed260 ; FUN_009ed260 */

void FUN_009ed260(void)

{
  FUN_008a4940(&DAT_01ee5728);
  return;
}



/* FUNCTION 19465 ; VA 0x009ed270 ; FUN_009ed270 */

void __thiscall FUN_009ed270(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  piVar1 = (int *)(param_1 + 0x1c);
  if (param_2 != piVar1) {
    iVar2 = *param_2;
    *param_2 = *piVar1;
    *piVar1 = iVar2;
    iVar2 = param_2[1];
    param_2[1] = *(int *)(param_1 + 0x20);
    *(int *)(param_1 + 0x20) = iVar2;
    iVar2 = param_2[2];
    param_2[2] = *(int *)(param_1 + 0x24);
    *(int *)(param_1 + 0x24) = iVar2;
  }
  piVar3 = *(int **)(param_1 + 0x20);
  piVar4 = (int *)*piVar1;
  if (piVar4 != piVar3) {
    do {
      (**(code **)(*piVar4 + 4))(0);
      piVar4 = piVar4 + 7;
    } while (piVar4 != piVar3);
    *(int *)(param_1 + 0x20) = *piVar1;
    return;
  }
  *(int **)(param_1 + 0x20) = piVar4;
  return;
}



/* FUNCTION 19466 ; VA 0x009ed2e0 ; FUN_009ed2e0 */

void FUN_009ed2e0(void)

{
  int iVar1;
  
  if (DAT_01ee59ec == 0) {
    iVar1 = FUN_009ec190();
    DAT_01ee59ec = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 19467 ; VA 0x009ed300 ; FUN_009ed300 */

undefined4 __thiscall FUN_009ed300(int param_1,undefined4 param_2)

{
  FUN_008866a0(param_1 + 0xcc);
  return param_2;
}



/* FUNCTION 19468 ; VA 0x009ed320 ; FUN_009ed320 */

undefined4 __thiscall FUN_009ed320(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(param_1 + 8))();
  FUN_005cae50(uVar1);
  return param_2;
}



/* FUNCTION 19469 ; VA 0x009ed340 ; FUN_009ed340 */

undefined4 __thiscall FUN_009ed340(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)(param_1 + 8))(auStack_18);
  uStack_8 = 0;
  FUN_008866a0(uVar1);
  FUN_0056e380();
  FUN_0056e380();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 19470 ; VA 0x009ed3a0 ; FUN_009ed3a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_009ed3a0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba938;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  uVar5 = FUN_0088d190();
  iVar6 = _tls_index;
  *param_3 = uVar5;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar6 * 4) + 0x34) < DAT_01ead298) {
    FUN_016f3809(&DAT_01ead298);
    if (DAT_01ead298 == -1) {
      _DAT_01ead28c = FUN_005c65f0;
      _DAT_01ead290 = FUN_005c93a0;
      _DAT_01ead294 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ead298);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01ead28c) {
    if (param_3 + 2 != puVar4) {
      FUN_005507b0();
      uVar5 = puVar4[1];
      uVar2 = puVar4[2];
      uVar3 = puVar4[3];
      param_3[2] = *puVar4;
      param_3[3] = uVar5;
      param_3[4] = uVar2;
      param_3[5] = uVar3;
      *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
    }
  }
  else {
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_3 + 2);
      param_3[1] = 0;
    }
    param_3[6] = 0;
    param_3[7] = 0;
    uVar5 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    param_3[2] = *puVar4;
    param_3[3] = uVar5;
    param_3[4] = uVar2;
    param_3[5] = uVar3;
    *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    param_3[1] = &DAT_01ead28c;
  }
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    iVar6 = aiStack_28[0];
    if (0xfff < uVar7) {
      iVar6 = *(int *)(aiStack_28[0] + -4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19471 ; VA 0x009ed520 ; FUN_009ed520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_009ed520(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  int iVar2;
  void *pvVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_18,param_2);
  uStack_8 = 0;
  uVar5 = FUN_00886600();
  pvVar3 = ThreadLocalStoragePointer;
  iVar2 = _tls_index;
  *param_3 = uVar5;
  if (*(int *)(*(int *)((int)pvVar3 + iVar2 * 4) + 0x34) < DAT_01ead2b8) {
    FUN_016f3809(&DAT_01ead2b8);
    if (DAT_01ead2b8 == -1) {
      _DAT_01ead2ac = FUN_00619fa0;
      _DAT_01ead2b0 = FUN_00619fa0;
      _DAT_01ead2b4 = FUN_0061bd30;
      FUN_016f37bf(&DAT_01ead2b8);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01ead2ac) {
    FUN_00886840(uVar4);
  }
  else {
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_3 + 2);
      param_3[1] = 0;
    }
    FUN_008866a0(uVar4);
    param_3[1] = &DAT_01ead2ac;
  }
  FUN_0056e380();
  FUN_0056e380();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19472 ; VA 0x009ed630 ; FUN_009ed630 */

uint FUN_009ed630(void)

{
  int iVar1;
  
  iVar1 = FUN_009ec190();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 19473 ; VA 0x009ed650 ; FUN_009ed650 */

uint FUN_009ed650(void)

{
  int iVar1;
  
  iVar1 = FUN_009ec190();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 19474 ; VA 0x009ed670 ; FUN_009ed670 */

void FUN_009ed670(void)

{
  FUN_008a4940(&DAT_01ee5760);
  return;
}



/* FUNCTION 19475 ; VA 0x009ed680 ; FUN_009ed680 */

void __thiscall FUN_009ed680(int param_1,undefined4 param_2)

{
  if ((*(int *)(param_1 + 0x14) != 0) && (*(int *)(param_1 + 0x18) != -2)) {
    FUN_01258350(*(int *)(param_1 + 0x14),0xffffd8f0,*(int *)(param_1 + 0x18));
  }
  *(undefined4 *)(param_1 + 0x18) = param_2;
  return;
}



/* FUNCTION 19476 ; VA 0x009ed6b0 ; FUN_009ed6b0 */

void __fastcall FUN_009ed6b0(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  
  if (*(int *)(param_1 + 0xf8) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puVar3 = *(undefined4 **)(*(int *)(param_1 + 0x104) + *(int *)(param_1 + 0xf4) * 4);
  }
  for (; puVar3 != (undefined4 *)0x0; puVar3 = (undefined4 *)*puVar3) {
    puVar3[9] = 0xfffffffe;
    if (puVar3[7] != 0) {
      FUN_00d89170();
      piVar2 = (int *)puVar3[7];
      puVar3[7] = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          FUN_00d889a0();
          FUN_01674ea0(piVar2,8);
        }
      }
    }
    puVar3[6] = 0;
  }
  return;
}



/* FUNCTION 19477 ; VA 0x009ed730 ; FUN_009ed730 */

void __fastcall FUN_009ed730(int param_1)

{
  int iVar1;
  int *piVar2;
  
  *(undefined4 *)(param_1 + 0xc) = 2;
  if (*(int *)(param_1 + 0x10) != 0) {
    FUN_00d89170();
    piVar2 = *(int **)(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x10) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        FUN_00d889a0();
        FUN_01674ea0(piVar2,8);
      }
    }
  }
  FUN_009abb30();
  return;
}



/* FUNCTION 19478 ; VA 0x009ed780 ; FUN_009ed780 */

void __thiscall FUN_009ed780(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0xc) = 3;
  if (*(int *)(param_1 + 0x14) == 0) {
    *(undefined4 *)(param_1 + 0x14) = param_2;
  }
  *(undefined4 *)(param_1 + 0x18) = param_3;
  FUN_009abb30();
  return;
}



/* FUNCTION 19479 ; VA 0x009ed7b0 ; FUN_009ed7b0 */

void __thiscall FUN_009ed7b0(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  
  *(undefined4 *)(param_1 + 0xc) = 1;
  if (param_2 != (int *)0x0) {
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
  }
  piVar2 = *(int **)(param_1 + 0x10);
  *(int **)(param_1 + 0x10) = param_2;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d889a0();
      FUN_01674ea0(piVar2,8);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (param_2 != (int *)0x0)) {
      FUN_00d889a0();
      FUN_01674ea0(param_2,8);
    }
  }
  return;
}



/* FUNCTION 19480 ; VA 0x009ed830 ; FUN_009ed830 */

void __thiscall FUN_009ed830(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  int aiStack_68 [5];
  uint uStack_54;
  undefined4 uStack_50;
  char cStack_4c;
  int aiStack_48 [5];
  uint uStack_34;
  undefined auStack_30 [16];
  undefined auStack_20 [8];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d83ba;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  puVar4 = (undefined4 *)FUN_00a33fa0();
  puVar6 = puVar4 + 4;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_00886ff0(aiStack_68,puVar4,*puVar6);
  uStack_8 = 0;
  if (cStack_4c != '\0') {
    FUN_008874a0(param_1,uStack_50,1);
    if (cStack_4c != '\0') {
      uVar5 = FUN_00886c00(auStack_30,aiStack_68);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uVar7 = 1;
      goto LAB_009ed8d5;
    }
  }
  uVar5 = FUN_008866a0(param_2);
  uStack_8 = 2;
  uVar7 = 2;
LAB_009ed8d5:
  uStack_14 = uVar7;
  FUN_008866a0(uVar5);
  uStack_8 = 3;
  if ((uVar7 & 2) != 0) {
    uVar7 = uVar7 & 0xfffffffd;
    FUN_0056e380();
    FUN_0056e380();
  }
  uStack_8._0_1_ = 5;
  if ((uVar7 & 1) != 0) {
    FUN_0056e380();
    FUN_0056e380();
  }
  cVar3 = FUN_008868d0(auStack_20);
  if (cVar3 != '\0') {
    uVar7 = FUN_01675290(DAT_01ef0a34);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    uStack_14 = uVar7;
    FUN_00886840(auStack_20);
    puVar4 = (undefined4 *)FUN_00a33fa0();
    puVar6 = puVar4 + 4;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    puVar6 = (undefined4 *)FUN_01531190(aiStack_48,puVar4,*puVar6);
    iVar8 = iStack_18;
    puVar4 = (undefined4 *)(iStack_18 + 0xd4);
    if (puVar4 != puVar6) {
      FUN_005507b0();
      uVar5 = puVar6[1];
      uVar1 = puVar6[2];
      uVar2 = puVar6[3];
      *puVar4 = *puVar6;
      *(undefined4 *)(iVar8 + 0xd8) = uVar5;
      *(undefined4 *)(iVar8 + 0xdc) = uVar1;
      *(undefined4 *)(iVar8 + 0xe0) = uVar2;
      *(undefined8 *)(iVar8 + 0xe4) = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
    }
    if (0xf < uStack_34) {
      uVar9 = uStack_34 + 1;
      iVar8 = aiStack_48[0];
      if (0xfff < uVar9) {
        iVar8 = *(int *)(aiStack_48[0] + -4);
        uVar9 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar9);
    }
    FUN_008a4940(&DAT_01ee5728);
    uStack_8._0_1_ = 7;
    FUN_01675290(uVar7);
  }
  FUN_0056e380();
  FUN_0056e380();
  if ((cStack_4c != '\0') && (0xf < uStack_54)) {
    uVar7 = uStack_54 + 1;
    iVar8 = aiStack_68[0];
    if (0xfff < uVar7) {
      iVar8 = *(int *)(aiStack_68[0] + -4);
      uVar7 = uStack_54 + 0x24;
      if (0x1f < (aiStack_68[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19481 ; VA 0x009eda70 ; FUN_009eda70 */

void __thiscall FUN_009eda70(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  
  if (*(char *)(param_1 + 0xec) != '\0') {
    uVar2 = FUN_01255560();
    cVar1 = FUN_01255580(uVar2,5);
    if (cVar1 == '\0') {
      return;
    }
  }
  FUN_00ae4190(param_1);
  FUN_009ed830(param_2);
  return;
}



/* FUNCTION 19482 ; VA 0x009edab0 ; FUN_009edab0 */

void __thiscall FUN_009edab0(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba938;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008c04f0(aiStack_28);
  uStack_8 = 0;
  (*pcVar1)(param_2,uVar2);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19483 ; VA 0x009edb40 ; FUN_009edb40 */

void __thiscall FUN_009edb40(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ca8;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009ec290(auStack_18);
  uStack_8 = 0;
  (*pcVar1)(param_2,uVar2);
  FUN_0056e380();
  FUN_0056e380();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 19484 ; VA 0x009edbb0 ; FUN_009edbb0 */

int FUN_009edbb0(void)

{
  int iVar1;
  
  iVar1 = FUN_009eca00(&stack0x00000004);
  return iVar1 + 4;
}



/* FUNCTION 19485 ; VA 0x009edbd0 ; FUN_009edbd0 */

undefined4 * __thiscall FUN_009edbd0(undefined4 *param_1,byte param_2)

{
  *param_1 = Luau::BytecodeEncoder::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 19486 ; VA 0x009edc00 ; FUN_009edc00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_009edc00(undefined4 *param_1,undefined4 param_2,int param_3,undefined4 *param_4)

{
  undefined4 ***pppuVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 ****ppppuVar6;
  int iVar7;
  undefined4 ***pppuStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int iStack_28;
  int aiStack_24 [3];
  undefined4 *puStack_18;
  undefined2 auStack_14 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar7 = param_3;
  puStack_c = &LAB_017d8401;
  pvStack_10 = ExceptionList;
  aiStack_24[1] = 0;
  uStack_40 = _DAT_0193cdb0;
  uStack_3c = _UNK_0193cdb4;
  auStack_14[0] = 0x101;
  uStack_38 = _UNK_0193cdb8;
  if (((uint)param_4 & 2) != 0) {
    uStack_38 = 2;
  }
  uStack_34 = _UNK_0193cdbc;
  if (((uint)param_4 & 4) != 0) {
    uStack_34 = 2;
  }
  puStack_18 = (undefined4 *)0x0;
  uStack_8 = 0;
  if ((param_3 == 0) || (param_4 = (undefined4 *)0x0, ExceptionList = &pvStack_10, param_3 == 1)) {
    ExceptionList = &pvStack_10;
    puStack_18 = (undefined4 *)FUN_01674e20(4);
    if (puStack_18 == (undefined4 *)0x0) {
      puStack_18 = (undefined4 *)0x0;
    }
    else {
      *puStack_18 = LuaVM::BytecodeEncoderClient::vftable;
    }
  }
  puVar2 = puStack_18;
  param_4 = puStack_18;
  FUN_01458db0(&pppuStack_58,param_2,&uStack_40,auStack_14,puStack_18);
  pppuVar1 = pppuStack_58;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((iVar7 == 0) || (iVar7 == 1)) {
    param_3 = (uint)(iVar7 == 1) * 8 + 1;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    aiStack_24[2] = iStack_48;
    aiStack_24[0] = iStack_48;
    uVar3 = FUN_00abce10(iStack_48);
    FUN_007158e0(uVar3,(int)&param_4 + 3);
    ppppuVar6 = &pppuStack_58;
    if (0xf < uStack_44) {
      ppppuVar6 = (undefined4 ****)pppuStack_58;
    }
    uStack_8 = 3;
    uVar3 = FUN_00ab2ec0(iStack_30,uVar3,ppppuVar6,aiStack_24[2],param_3);
    param_1[4] = 0;
    param_1[5] = 0xf;
    *(undefined *)param_1 = 0;
    FUN_005542c0(&DAT_0193cd48,4);
    aiStack_24[1] = 2;
    FUN_00554150(aiStack_24,4);
    FUN_00554150(iStack_30,uVar3);
    puVar4 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar4 = (undefined4 *)*param_1;
    }
    param_3 = FUN_014ebd40(puVar4,param_1[4],0x2a);
    uVar5 = 0;
    if (param_1[4] != 0) {
      param_4 = (undefined4 *)0x0;
      do {
        aiStack_24[0] = (uint)*(byte *)((int)&param_3 + (uVar5 & 3)) + (int)param_4;
        puVar4 = param_1;
        if (0xf < (uint)param_1[5]) {
          puVar4 = (undefined4 *)*param_1;
        }
        *(byte *)((int)puVar4 + uVar5) = *(byte *)((int)puVar4 + uVar5) ^ (byte)aiStack_24[0];
        uVar5 = uVar5 + 1;
        param_4 = (undefined4 *)((int)param_4 + 0x29);
      } while (uVar5 < (uint)param_1[4]);
    }
    if (iStack_30 != 0) {
      uVar5 = iStack_28 - iStack_30;
      iVar7 = iStack_30;
      if (0xfff < uVar5) {
        iVar7 = *(int *)(iStack_30 + -4);
        uVar5 = uVar5 + 0x23;
        if (0x1f < (iStack_30 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar5);
    }
    if (0xf < uStack_44) {
      uVar5 = uStack_44 + 1;
      ppppuVar6 = (undefined4 ****)pppuStack_58;
      if (0xfff < uVar5) {
        ppppuVar6 = (undefined4 ****)pppuStack_58[-1];
        uVar5 = uStack_44 + 0x24;
        if (0x1f < (uint)((int)pppuStack_58 + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar6,uVar5);
    }
    iStack_48 = 0;
    uStack_44 = 0xf;
    pppuStack_58 = (undefined4 ***)((uint)pppuStack_58 & 0xffffff00);
    puVar4 = puVar2;
  }
  else {
    pppuStack_58 = (undefined4 ***)((uint)pppuStack_58 & 0xffffff00);
    param_1[4] = 0;
    param_1[5] = 0;
    *param_1 = pppuVar1;
    param_1[1] = uStack_54;
    param_1[2] = uStack_50;
    param_1[3] = uStack_4c;
    *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_44,iStack_48);
    iStack_48 = 0;
    uStack_44 = 0xf;
    FUN_005507b0();
    puVar4 = param_4;
  }
  if (puVar4 != (undefined4 *)0x0) {
    (**(code **)*puVar2)(1);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 19487 ; VA 0x009ede90 ; FUN_009ede90 */

int FUN_009ede90(byte param_1)

{
  return (uint)param_1 * 0xe3;
}



/* FUNCTION 19488 ; VA 0x009edeb0 ; FUN_009edeb0 */

undefined4 FUN_009edeb0(undefined4 param_1)

{
  FUN_00fb77e0();
  return param_1;
}



/* FUNCTION 19489 ; VA 0x009edec0 ; FUN_009edec0 */

undefined * FUN_009edec0(undefined *param_1)

{
  undefined4 uVar1;
  
  *param_1 = 0;
  uVar1 = FUN_00588320(0xb);
  *(undefined4 *)(param_1 + 4) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  return param_1;
}



/* FUNCTION 19490 ; VA 0x009edf00 ; FUN_009edf00 */

undefined4 FUN_009edf00(void)

{
  return DAT_01ee59fc;
}



/* FUNCTION 19491 ; VA 0x009edf10 ; FUN_009edf10 */

int FUN_009edf10(int param_1)

{
  uint uVar1;
  
  uVar1 = FUN_009ee030(param_1 * 0x34356111);
  return (uVar1 | 1) * DAT_01ee59f8 * 0x663d81;
}



/* FUNCTION 19492 ; VA 0x009edf40 ; FUN_009edf40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_009edf40(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799148;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a33fa0();
  uStack_20 = _DAT_0193cdb0;
  uStack_1c = _UNK_0193cdb4;
  param_2._2_2_ = 0x101;
  uStack_18 = _UNK_0193cdb8;
  if (DAT_01d6566c != '\0') {
    uStack_18 = 2;
  }
  uStack_14 = _UNK_0193cdbc;
  if (DAT_01d644b8 != '\0') {
    uStack_14 = 2;
  }
  FUN_01458db0(apppuStack_38,uVar1,&uStack_20,(undefined *)((int)register0x00000010 + 10),0);
  ppppuVar2 = apppuStack_38;
  if (0xf < uStack_24) {
    ppppuVar2 = (undefined4 ****)apppuStack_38[0];
  }
  uStack_8 = 0;
  uVar1 = FUN_01267530(param_1,param_3,ppppuVar2,uStack_28);
  if (0xf < uStack_24) {
    uVar3 = uStack_24 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_38[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_38[0][-1];
      uVar3 = uStack_24 + 0x24;
      if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 19493 ; VA 0x009ee030 ; FUN_009ee030 */

uint FUN_009ee030(uint param_1)

{
  return (param_1 >> 0xe & 1) * 0xe320f15 ^
         (param_1 >> 0xb & 1) * -0x4effb02d ^ (param_1 >> 0x1c & 1) * -0x6d359393 ^
         (param_1 >> 0x16 & 1) * -0x2f075249 ^ (param_1 >> 0x12 & 1) * -0x74ea8e10 ^
         (param_1 >> 0x14 & 1) * -0x24d551d6 ^ (param_1 >> 7 & 1) * -0x31e64227 ^
         (param_1 >> 0x18 & 1) * -0x19637587 ^ (param_1 >> 0x1a & 1) * -0x7f539489 ^
         (param_1 >> 0x11 & 1) * -0x4a0ec1f ^ (param_1 >> 4 & 1) * -0x41e9a6d7 ^
         (param_1 >> 0x17 & 1) * 0x53d0b56e ^ (param_1 >> 10 & 1) * -0x3f405f52 ^
         (param_1 >> 9 & 1) * 0xb2bd610 ^ (param_1 >> 0xc & 1) * 0x79d6a004 ^
         (param_1 >> 2 & 1) * 0x3c297366 ^ (param_1 >> 1 & 1) * -0x4ef7092e ^
         (param_1 >> 0x10 & 1) * 0x685e2dc1 ^ (param_1 >> 0xf & 1) * -0x24a91e2a ^
         (param_1 >> 0x19 & 1) * -0x29031107 ^ (param_1 >> 0x15 & 1) * -0x5b60f58c ^
         (param_1 >> 3 & 1) * 0x76efd2bb ^ (param_1 >> 0xd & 1) * 0x78925bb3 ^
         (param_1 >> 8 & 1) * -0x2e19fbc ^ (param_1 >> 6 & 1) * 0x69a0fe16 ^
         (param_1 >> 0x1b & 1) * 0x68a47ccf ^ (param_1 >> 0x1d & 1) * 0x7170e034 ^
         (param_1 >> 5 & 1) * -0x23d7b34c ^ (param_1 >> 0x13 & 1) * 0x1e83936a ^
         (param_1 >> 0x1e & 1) * 0x4ce64f7d ^ ((int)param_1 >> 0x1f) * 0x2473447d ^
         (param_1 & 1) * 0x455f4314;
}



/* FUNCTION 19494 ; VA 0x009ee230 ; FUN_009ee230 */

void FUN_009ee230(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6228;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00637490(&std::
                        basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                        ::RTTI_Type_Descriptor,&TypeDescriptor_01dc54b8);
  uStack_8 = 0;
  FUN_00636dc0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 19495 ; VA 0x009ee270 ; FUN_009ee270 */

undefined * FUN_009ee270(undefined *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  char acStack_14 [16];
  
  FUN_005e4ba0(acStack_14,0x10,&DAT_018bed68,*param_2);
  pcVar2 = acStack_14;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(acStack_14,(int)pcVar2 - (int)(acStack_14 + 1));
  return param_1;
}



/* FUNCTION 19496 ; VA 0x009ee2d0 ; FUN_009ee2d0 */

undefined * FUN_009ee2d0(undefined *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  char acStack_14 [16];
  
  FUN_005e4ba0(acStack_14,0x10,&DAT_0193cde0,*param_2);
  pcVar2 = acStack_14;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(acStack_14,(int)pcVar2 - (int)(acStack_14 + 1));
  return param_1;
}



/* FUNCTION 19497 ; VA 0x009ee330 ; FUN_009ee330 */

undefined * FUN_009ee330(undefined *param_1,float *param_2)

{
  float fVar1;
  char cVar2;
  char *pcVar3;
  char acStack_24 [32];
  
  fVar1 = *param_2;
  if ((NAN(fVar1) || NAN(DAT_018e0028)) != (fVar1 == DAT_018e0028)) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_018c37a8,3);
    return param_1;
  }
  if ((NAN(fVar1) || NAN(DAT_0193ce08)) != (fVar1 == DAT_0193ce08)) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_018c37ac,4);
    return param_1;
  }
  if ((0.0 <= fVar1) && (fVar1 < 0.0)) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_0193cde4,3);
    return param_1;
  }
  FUN_005e4ba0(acStack_24,0x20,&DAT_0193cdf0,(double)fVar1);
  pcVar3 = acStack_24;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(acStack_24,(int)pcVar3 - (int)(acStack_24 + 1));
  return param_1;
}



/* FUNCTION 19498 ; VA 0x009ee440 ; FUN_009ee440 */

undefined * FUN_009ee440(undefined *param_1,double *param_2)

{
  double dVar1;
  char cVar2;
  char *pcVar3;
  char acStack_44 [64];
  
  dVar1 = *param_2;
  if ((NAN(dVar1) || NAN(DAT_0193cdf8)) != (dVar1 == DAT_0193cdf8)) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_018c37a8,3);
    return param_1;
  }
  if ((NAN(dVar1) || NAN(DAT_0193ce10)) != (dVar1 == DAT_0193ce10)) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_018c37ac,4);
    return param_1;
  }
  if ((0.0 <= dVar1) && (dVar1 < 0.0)) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_0193cde4,3);
    return param_1;
  }
  FUN_005e4ba0(acStack_44,0x40,"%.20g",dVar1);
  pcVar3 = acStack_44;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(acStack_44,(int)pcVar3 - (int)(acStack_44 + 1));
  return param_1;
}



/* FUNCTION 19499 ; VA 0x009ee550 ; FUN_009ee550 */

undefined4 FUN_009ee550(undefined4 param_1,undefined4 *param_2)

{
  FUN_01675640(param_1,&DAT_018bed48,*param_2,param_2[1]);
  return param_1;
}


