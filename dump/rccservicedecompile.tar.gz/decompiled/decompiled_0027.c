/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 6750 ; VA 0x0061e3e0 ; FUN_0061e3e0 */

void FUN_0061e3e0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  uint *puVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined8 in_stack_00000024;
  char cStack0000002c;
  char in_stack_00000030;
  int in_stack_00000034;
  char in_stack_00000038;
  char in_stack_0000003c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined8 uStack_50;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  undefined8 uStack_38;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0179e277;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uVar9 = uStack_68;
  uVar10 = 1;
  uStack_50 = in_stack_00000024;
  iStack_8._0_1_ = 1;
  puVar1 = *(uint **)(param_1 + 4);
  if (*(uint **)(param_1 + 8) == puVar1) {
    FUN_00603540(puVar1,&uStack_68);
    uVar9 = uStack_54;
  }
  else {
    uStack_68 = uStack_68 & 0xffffff00;
    *puVar1 = uVar9;
    puVar1[1] = uStack_64;
    puVar1[2] = uStack_60;
    puVar1[3] = uStack_5c;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_54,uStack_58);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
    *(undefined8 *)(puVar1 + 6) = in_stack_00000024;
    uVar9 = 0xf;
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uVar9) {
    uVar8 = uVar9 + 1;
    uVar6 = uStack_68;
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(uStack_68 - 4);
      uVar8 = uVar9 + 0x24;
      if (0x1f < (uStack_68 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  if (DAT_01d5a008 != '\0') {
    puVar4 = &param_3;
    if (0xf < in_stack_00000020) {
      puVar4 = param_3;
    }
    FUN_0151fb00(puVar4,in_stack_00000024);
  }
  if ((*(char *)(iStack_18 + 0x37f8) != '\0') && (cStack0000002c != '\0')) {
    iStack_8._0_1_ = 2;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    uStack_14 = 3;
    FUN_0058a190();
    puVar4 = &param_3;
    if (0xf < in_stack_00000020) {
      puVar4 = param_3;
    }
    FUN_00554150(puVar4,in_stack_0000001c);
    FUN_00554150("_StreamingEnabled",0x11);
    FUN_0054ef60();
    uStack_50 = in_stack_00000024;
    uStack_14 = 7;
    iStack_8._0_1_ = 3;
    FUN_00625cd0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
    uVar10 = 5;
  }
  if ((in_stack_00000030 != '\0') && (in_stack_00000034 != 0)) {
    _cStack0000002c = uVar10;
    uVar3 = FUN_01675640(&uStack_60,&DAT_018bed68,in_stack_00000034);
    uStack_14 = uVar10 | 8;
    iStack_8._0_1_ = 5;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_0058a190();
    puVar4 = &param_3;
    if (0xf < in_stack_00000020) {
      puVar4 = param_3;
    }
    FUN_00554150(puVar4,in_stack_0000001c);
    FUN_00554150("_Datacenter_",0xc);
    FUN_00558ba0(&iStack_48,auStack_30,uVar3);
    uVar10 = _cStack0000002c;
    FUN_005507b0();
    iStack_8._0_1_ = 8;
    FUN_005507b0();
    FUN_0054ef60();
    uVar10 = uVar10 | 0x10;
    iStack_8._0_1_ = 9;
    FUN_00625cd0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  _cStack0000002c = uVar10;
  if ((in_stack_00000038 != '\0') && (*(int *)(iStack_18 + 0x1dc0) != 0)) {
    piVar5 = *(int **)(*(int *)(iStack_18 + 0x1dc0) + 0xb8);
    uVar3 = FUN_01675640(&uStack_60,&DAT_018bed68,((piVar5[1] - *piVar5 >> 3) / 0x19) * 0x19);
    uStack_14 = uVar10 | 0x20;
    iStack_8._0_1_ = 0xb;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_0058a190();
    puVar4 = &param_3;
    if (0xf < in_stack_00000020) {
      puVar4 = param_3;
    }
    FUN_00554150(puVar4,in_stack_0000001c);
    FUN_00554150("_PlayerTier_",0xc);
    FUN_00558ba0(&iStack_48,auStack_30,uVar3);
    uVar10 = _cStack0000002c;
    FUN_005507b0();
    iStack_8._0_1_ = 0xe;
    FUN_005507b0();
    FUN_0054ef60();
    uVar10 = uVar10 | 0x40;
    iStack_8._0_1_ = 0xf;
    FUN_00625cd0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  if (in_stack_0000003c != '\0') {
    iStack_8._0_1_ = 0x10;
    uStack_14 = uVar10 | 0x80;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_0058a190();
    puVar4 = &param_3;
    if (0xf < in_stack_00000020) {
      puVar4 = param_3;
    }
    FUN_00554150(puVar4,in_stack_0000001c);
    FUN_00554150(&DAT_018c6ae4,1);
    puVar4 = &DAT_01d7a8e8;
    if (0xf < DAT_01d7a8fc) {
      puVar4 = DAT_01d7a8e8;
    }
    piVar5 = (int *)FUN_00554150(puVar4,DAT_01d7a8f8);
    iStack_48 = *piVar5;
    iStack_44 = piVar5[1];
    iStack_40 = piVar5[2];
    iStack_3c = piVar5[3];
    uStack_38 = *(undefined8 *)(piVar5 + 4);
    piVar5[4] = 0;
    piVar5[5] = 0xf;
    *(undefined *)piVar5 = 0;
    iStack_8._0_1_ = 0x12;
    uVar2 = (undefined)iStack_8;
    iStack_8._0_1_ = 0x12;
    if (0xf < uStack_1c) {
      uVar9 = uStack_1c + 1;
      uVar10 = auStack_30[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_30[0] - 4);
        uVar9 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar10) - 4) {
          iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_0054ef60();
    uStack_50 = in_stack_00000024;
    iStack_8 = CONCAT31(iStack_8._1_3_,0x13);
    FUN_00625cd0();
    if (0xf < uStack_54) {
      uVar9 = uStack_54 + 1;
      uVar10 = uStack_68;
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(uStack_68 - 4);
        uVar9 = uStack_54 + 0x24;
        if (0x1f < (uStack_68 - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    if (0xf < uStack_38._4_4_) {
      uVar10 = uStack_38._4_4_ + 1;
      iVar7 = iStack_48;
      if (0xfff < uVar10) {
        iVar7 = *(int *)(iStack_48 + -4);
        uVar10 = uStack_38._4_4_ + 0x24;
        if (0x1f < (iStack_48 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar10);
    }
  }
  if (0xf < in_stack_00000020) {
    uVar10 = in_stack_00000020 + 1;
    puVar4 = param_3;
    if (0xfff < uVar10) {
      puVar4 = (undefined4 *)param_3[-1];
      uVar10 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar4,uVar10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6751 ; VA 0x0061e950 ; FUN_0061e950 */

undefined4 * FUN_0061e950(void)

{
  code *pcVar1;
  int iVar2;
  undefined4 *puVar3;
  int unaff_EBP;
  
  iVar2 = FUN_016de3db(&DAT_01ead02c,FUN_00603d10,&DAT_01ead030);
  if (iVar2 != 0) {
    return &DAT_01ead030;
  }
  FUN_016f4b80(&DAT_01d51160,8);
  iVar2 = FUN_01733dcb();
  pcVar1 = *(code **)(iVar2 + 0xc);
  if (pcVar1 != (code *)0x0) {
    *(undefined4 *)(unaff_EBP + -4) = 0;
    (*(code *)PTR__guard_check_icall_018b37b4)();
    (*pcVar1)();
    *(undefined4 *)(unaff_EBP + -4) = 0xfffffffe;
  }
  FUN_0171d6f3();
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 6752 ; VA 0x0061e980 ; FUN_0061e980 */

int __fastcall FUN_0061e980(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xe28) + -200;
  if (iVar1 < 1) {
    iVar1 = 0;
  }
  return iVar1;
}



/* FUNCTION 6753 ; VA 0x0061e9a0 ; FUN_0061e9a0 */

void __thiscall FUN_0061e9a0(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    *param_2 = *(undefined4 *)(iVar1 + 0x18);
    param_2[1] = *(undefined4 *)(iVar1 + 0x1c);
    return;
  }
  *param_2 = 0xffffffff;
  param_2[1] = 0;
  return;
}



/* FUNCTION 6754 ; VA 0x0061e9d0 ; FUN_0061e9d0 */

undefined4 __thiscall FUN_0061e9d0(double *param_1,double *param_2)

{
  if (*(int *)(param_1 + 1) == 0) {
    return 0;
  }
  *param_2 = *param_1 / (double)*(int *)(param_1 + 1);
  *param_1 = 0.0;
  *(undefined4 *)(param_1 + 1) = 0;
  return 1;
}



/* FUNCTION 6755 ; VA 0x0061ea10 ; FUN_0061ea10 */

int __thiscall FUN_0061ea10(int param_1,int param_2,int param_3,char param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined8 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dce8;
  pvStack_10 = ExceptionList;
  iVar3 = param_1 + 0xf10;
  if (*(int *)(param_1 + 0x6c) == 0) {
    iVar3 = 0;
  }
  if (iVar3 == 0) {
    return 0;
  }
  if (param_4 != '\0') {
    iVar2 = (int)((double)param_2 - *(double *)(iVar3 + 0xa8 + param_3 * 8));
    if ((DAT_01d5b598 != '\0') && (iVar2 < 0)) {
      iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
      ExceptionList = &pvStack_10;
      if (*(int *)(iVar1 + 0x34) < DAT_01ead0f0) {
        ExceptionList = &pvStack_10;
        FUN_016f3809();
        if (DAT_01ead0f0 == -1) {
          uStack_8 = 0;
          uVar4 = FUN_0152da50();
          DAT_01ead0ec = (undefined4)((ulonglong)uVar4 >> 0x20);
          DAT_01ead0e8 = (undefined4)uVar4;
          uStack_8 = 0xffffffff;
          FUN_016f37bf(&DAT_01ead0f0);
        }
      }
      FUN_0152d740(DAT_01ead0e8,DAT_01ead0ec,"Insufficient buffer to serialize data");
      if (*(int *)(iVar1 + 0x34) < DAT_01ead100) {
        FUN_016f3809();
        if (DAT_01ead100 == -1) {
          uStack_8 = 1;
          uVar4 = FUN_0152da50();
          DAT_01ead0fc = (undefined4)((ulonglong)uVar4 >> 0x20);
          DAT_01ead0f8 = (undefined4)uVar4;
          uStack_8 = 0xffffffff;
          FUN_016f37bf(&DAT_01ead100);
        }
      }
      FUN_0152d760(DAT_01ead0f8,DAT_01ead0fc,
                   "Buffer Requested : %d bytes - Data already in buffers : %f bytes",param_2,
                   *(undefined8 *)(iVar3 + 0xa8 + param_3 * 8));
    }
    if (iVar2 < 1) {
      iVar2 = 0;
    }
    ExceptionList = pvStack_10;
    return iVar2;
  }
  param_2 = param_2 - *(int *)(iVar3 + 0x98 + param_3 * 4);
  iVar3 = 0;
  if (-1 < param_2) {
    iVar3 = param_2;
  }
  return iVar3;
}



/* FUNCTION 6756 ; VA 0x0061ebf0 ; thunk_FUN_005ee4f0 */

void thunk_FUN_005ee4f0(void)

{
  int iVar1;
  
  if (DAT_01eaa16c == 0) {
    iVar1 = FUN_005ee170();
    DAT_01eaa16c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 6757 ; VA 0x0061ec00 ; thunk_FUN_0086e640 */

int thunk_FUN_0086e640(void)

{
  int iVar1;
  
  iVar1 = DAT_01ede3c8;
  if (DAT_01ede3c8 == 0) {
    iVar1 = FUN_0086e660();
  }
  return iVar1 + 0x48;
}



/* FUNCTION 6758 ; VA 0x0061ec10 ; FUN_0061ec10 */

undefined4 __fastcall FUN_0061ec10(int param_1)

{
  if (((*(uint *)(param_1 + 0x3808) & 0x2000000) != 0) &&
     ((*(uint *)(param_1 + 0x3808) & 0x20000000) != 0)) {
    return *(undefined4 *)(param_1 + 0x1a24);
  }
  return *(undefined4 *)(param_1 + 0x1a54);
}



/* FUNCTION 6759 ; VA 0x0061ec50 ; FUN_0061ec50 */

int * __fastcall FUN_0061ec50(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_1 = (int *)*param_1;
  iVar1 = *param_1;
  iVar2 = FUN_0088d190();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 6760 ; VA 0x0061ec80 ; FUN_0061ec80 */

int __thiscall FUN_0061ec80(int param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  undefined auStack_34 [4];
  int *piStack_30;
  uint *puStack_2c;
  char cStack_28;
  uint *puStack_24;
  uint uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_0179e2a8;
  pvStack_10 = ExceptionList;
  puStack_2c = (uint *)0x0;
  cStack_28 = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((*(uint *)(param_1 + 0x3808) & 0x20000) != 0) {
    puStack_24 = (uint *)(param_1 + 0x1f04);
    uStack_20 = uStack_20 & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_00587410();
    puStack_2c = puStack_24;
    cStack_28 = (char)uStack_20;
    uStack_8 = uStack_8 & 0xffffff00;
  }
  piVar7 = param_2;
  uStack_20 = param_1 + 0x1eec;
  piStack_14 = param_2;
  iVar6 = param_1 + 0x1eed + (uint)*(byte *)(param_1 + 0x1eec);
  FUN_00606ea0(&piStack_1c,((uint)param_2 >> 3) + (int)param_2,&piStack_14,
               -(uint)(iVar6 != 0) & iVar6 + 1U);
  if (piStack_1c == (int *)0x0) {
    FUN_01255470(9,0,0,0);
    FUN_01255490();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puVar2 = (undefined4 *)FUN_00892e40(piVar7);
    if (puVar2 == (undefined4 *)0x0) {
      iVar6 = 0;
      piVar7 = (int *)0x0;
      iStack_18 = 0;
      piStack_14 = (int *)0x0;
    }
    else {
      piVar3 = (int *)(**(code **)*puVar2)(auStack_34,0);
      piVar7 = (int *)piVar3[1];
      iVar6 = *piVar3;
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        piVar7 = (int *)piVar3[1];
      }
      piStack_1c = piStack_30;
      iStack_18 = iVar6;
      piStack_14 = piVar7;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_30[1] + -1;
        piStack_30[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_30)();
          LOCK();
          iVar4 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    iVar4 = FUN_00614da0(&param_2);
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
    }
    *(int *)(iVar4 + 4) = iVar6;
    piVar3 = *(int **)(iVar4 + 8);
    *(int **)(iVar4 + 8) = piVar7;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar4 = piVar7[1] + -1;
      piVar7[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        piVar3 = piVar7 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    FUN_01255500();
  }
  else {
    iVar6 = piStack_1c[3];
  }
  uStack_8 = 5;
  if (cStack_28 != '\0') {
    LOCK();
    uVar1 = *puStack_2c;
    *puStack_2c = *puStack_2c + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_2c;
      *puStack_2c = *puStack_2c | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 6761 ; VA 0x0061ee90 ; FUN_0061ee90 */

void __thiscall FUN_0061ee90(int param_1,undefined4 *param_2,undefined4 param_3)

{
  *param_2 = *(undefined4 *)(param_1 + 4);
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = param_3;
  return;
}



/* FUNCTION 6762 ; VA 0x0061eec0 ; FUN_0061eec0 */

undefined4 __thiscall FUN_0061eec0(int param_1,undefined4 param_2)

{
  FUN_006b1620(param_2,param_1 + 0x74,0,0x7c);
  return param_2;
}



/* FUNCTION 6763 ; VA 0x0061eee0 ; FUN_0061eee0 */

undefined __fastcall FUN_0061eee0(int param_1)

{
  if ((*(char *)(param_1 + 0x3c32) == '\0') && (*(char *)(param_1 + 0x3c31) == '\0')) {
    return 0;
  }
  return 1;
}



/* FUNCTION 6764 ; VA 0x0061ef00 ; FUN_0061ef00 */

undefined4 __fastcall FUN_0061ef00(int param_1)

{
  if ((*(uint *)(param_1 + 0x3808) & 0x40) != 0) {
    return 1;
  }
  return 0;
}



/* FUNCTION 6765 ; VA 0x0061ef20 ; FUN_0061ef20 */

undefined4 __fastcall FUN_0061ef20(int *param_1)

{
  char cVar1;
  uint uVar2;
  
  cVar1 = (**(code **)(*param_1 + 0x11c))();
  if (cVar1 == '\0') {
    uVar2 = param_1[0xe02] & 0x10;
  }
  else {
    uVar2 = param_1[0xe02] & 0x20;
  }
  if (uVar2 != 0) {
    return 1;
  }
  return 0;
}



/* FUNCTION 6766 ; VA 0x0061ef60 ; FUN_0061ef60 */

/* WARNING: Removing unreachable block (ram,0x0061f10f) */
/* WARNING: Removing unreachable block (ram,0x0061f11d) */
/* WARNING: Removing unreachable block (ram,0x0061f154) */
/* WARNING: Removing unreachable block (ram,0x0061f12d) */

int * FUN_0061ef60(int *param_1,byte *param_2,int *param_3,char *param_4,int param_5,int param_6,
                  int param_7,int param_8,undefined4 param_9,uint param_10)

{
  int *piVar1;
  char cVar2;
  byte bVar3;
  undefined4 uVar4;
  char *pcVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179e2d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  pcVar5 = param_4;
  do {
    cVar2 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar2 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_4,(int)pcVar5 - (int)(param_4 + 1));
  bVar3 = *param_2;
  uVar4 = FUN_005702d0(auStack_2c);
  FUN_00562fc0(&iStack_14,uVar4,auStack_2c,
               -(uint)(param_2 + bVar3 + 1 != (byte *)0x0) & (uint)(param_2 + bVar3 + 1 + 1));
  if (0xf < uStack_18) {
    uVar7 = uStack_18 + 1;
    uVar8 = auStack_2c[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_2c[0] - 4);
      uVar7 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  if (iStack_14 != 0) {
    FUN_00563690(param_1);
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar6 = param_3[1] + -1;
      param_3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    if (0xf < param_10) {
      uVar8 = param_10 + 1;
      iVar6 = param_5;
      if (0xfff < uVar8) {
        iVar6 = *(int *)(param_5 + -4);
        uVar8 = param_10 + 0x24;
        if (0x1f < (param_5 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar8);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = param_5;
  param_1[1] = param_6;
  param_1[2] = param_7;
  param_1[3] = param_8;
  *(ulonglong *)(param_1 + 4) = CONCAT44(param_10,param_9);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar6 = param_3[1] + -1;
    param_3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6767 ; VA 0x0061f160 ; FUN_0061f160 */

float10 __fastcall FUN_0061f160(double *param_1)

{
  undefined4 *puVar1;
  undefined auStack_18 [8];
  double dStack_10;
  float fStack_8;
  
  if ((NAN(*(float *)(param_1 + 2)) == (*(float *)(param_1 + 2) == 0.0)) &&
     (NAN(*(float *)((int)param_1 + 0xc)) == (*(float *)((int)param_1 + 0xc) == 0.0))) {
    FUN_016830f0(&dStack_10);
    fStack_8 = *(float *)(param_1 + 1) -
               (float)(dStack_10 - *param_1) *
               (*(float *)((int)param_1 + 0xc) / *(float *)(param_1 + 2));
    if (fStack_8 <= 0.0) {
      fStack_8 = 0.0;
      *(undefined4 *)(param_1 + 1) = 0;
      puVar1 = (undefined4 *)FUN_016830f0(auStack_18);
      *(undefined4 *)param_1 = *puVar1;
      *(undefined4 *)((int)param_1 + 4) = puVar1[1];
    }
    return (float10)fStack_8;
  }
  return (float10)0;
}



/* FUNCTION 6768 ; VA 0x0061f200 ; FUN_0061f200 */

undefined * __thiscall FUN_0061f200(int param_1,undefined *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  
  uVar2 = param_3[4];
  puVar4 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar4 = (undefined4 *)*param_3;
  }
  cVar3 = FUN_0055c360(puVar4,uVar2,"Network Send",0xc);
  if (cVar3 != '\0') {
    if (*(int *)(param_1 + 0x1d6c) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0x1d6c) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_0061e0c0(param_2,*(undefined4 *)(param_1 + 0x1d68),*(undefined4 *)(param_1 + 0x1d6c));
    return param_2;
  }
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  cVar3 = FUN_0055c360(param_3,uVar2,"Network Receive",0xf);
  if (cVar3 != '\0') {
    if (*(int *)(param_1 + 0x1d7c) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0x1d7c) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_0061e0c0(param_2,*(undefined4 *)(param_1 + 0x1d78),*(undefined4 *)(param_1 + 0x1d7c));
    return param_2;
  }
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  return param_2;
}



/* FUNCTION 6769 ; VA 0x0061f310 ; FUN_0061f310 */

float10 __thiscall FUN_0061f310(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  float10 fVar4;
  double in_XMM0_Qa;
  
  uVar1 = param_2[4];
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(puVar3,uVar1,"Network Receive CPU",0x13);
  if (cVar2 != '\0') {
    fVar4 = (float10)FUN_01523050();
    return fVar4 * (float10)DAT_018ce318;
  }
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(puVar3,uVar1,"Network Receive Time",0x14);
  if (cVar2 != '\0') {
    fVar4 = (float10)FUN_015230f0();
    return fVar4 * (float10)DAT_018c0d70;
  }
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(param_2,uVar1,"Total Bytes Received",0x14);
  if (cVar2 != '\0') {
    if (DAT_01eace3a != '\0') {
      puVar3 = (undefined4 *)(param_1 + 0xf14);
      if (*(int *)(param_1 + 8) == 0) {
        puVar3 = (undefined4 *)0x68;
      }
      FUN_016774b0(DAT_01eace3a,"Reporting ACTUAL_BYTES_RECEIVED: %d",*puVar3);
    }
    FUN_016f3fe0();
    return (float10)in_XMM0_Qa;
  }
  return (float10)0;
}



/* FUNCTION 6770 ; VA 0x0061f420 ; FUN_0061f420 */

undefined4 * __thiscall FUN_0061f420(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  uVar3 = (**(code **)(*param_1 + 0xb4))();
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_c,uVar3);
  *param_2 = *puVar4;
  uVar3 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_2[1] = uVar3;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_2;
  }
  return param_2;
}



/* FUNCTION 6771 ; VA 0x0061f4a0 ; FUN_0061f4a0 */

int __fastcall FUN_0061f4a0(int param_1)

{
  int iVar1;
  
  iVar1 = param_1 + 0xf10;
  if (*(int *)(param_1 + 0x6c) == 0) {
    iVar1 = 0;
  }
  return iVar1;
}



/* FUNCTION 6772 ; VA 0x0061f4b0 ; FUN_0061f4b0 */

int __fastcall FUN_0061f4b0(int param_1)

{
  uint uVar1;
  uint3 uVar2;
  
  uVar1 = *(uint *)(param_1 + 0x3808) & 0x80000000;
  uVar2 = (uint3)(uVar1 >> 8);
  if (uVar1 != 0) {
    return CONCAT31(uVar2,1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 6773 ; VA 0x0061f4d0 ; FUN_0061f4d0 */

undefined4 __fastcall FUN_0061f4d0(int param_1)

{
  if ((*(uint *)(param_1 + 0x380c) & 2) != 0) {
    return 1;
  }
  return 0;
}



/* FUNCTION 6774 ; VA 0x0061f4f0 ; FUN_0061f4f0 */

int __fastcall FUN_0061f4f0(int param_1)

{
  uint uVar1;
  uint3 uVar2;
  
  uVar1 = *(uint *)(param_1 + 0x3808) & 0x2000000;
  uVar2 = (uint3)(uVar1 >> 8);
  if ((uVar1 != 0) && ((*(uint *)(param_1 + 0x3808) & 0x20000000) != 0)) {
    return CONCAT31(uVar2,1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 6775 ; VA 0x0061f540 ; FUN_0061f540 */

int __fastcall FUN_0061f540(int param_1)

{
  uint uVar1;
  uint3 uVar2;
  
  uVar1 = *(uint *)(param_1 + 0x3808) & 0x20000;
  uVar2 = (uint3)(uVar1 >> 8);
  if (uVar1 != 0) {
    return CONCAT31(uVar2,1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 6776 ; VA 0x0061f560 ; FUN_0061f560 */

undefined4 FUN_0061f560(undefined4 param_1,undefined4 param_2,char param_3,undefined4 param_4)

{
  undefined8 uVar1;
  
  uVar1 = FUN_0152dab0(param_1,param_2,param_4);
  if ((param_3 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532a30(uVar1);
  }
  return (int)uVar1;
}



/* FUNCTION 6777 ; VA 0x0061f5a0 ; FUN_0061f5a0 */

int __fastcall FUN_0061f5a0(int param_1)

{
  uint uVar1;
  uint3 uVar2;
  
  uVar1 = *(uint *)(param_1 + 0x3808) & 0x2000000;
  uVar2 = (uint3)(uVar1 >> 8);
  if (uVar1 != 0) {
    return CONCAT31(uVar2,1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 6778 ; VA 0x0061f5c0 ; FUN_0061f5c0 */

undefined4 FUN_0061f5c0(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined2 extraout_var;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_24 [16];
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  switch(param_2) {
  case 0:
    uStack_2c = (undefined4 *)0x0;
    uStack_c = 0xfffffffe;
    uStack_8 = 0x7fffffff;
    uStack_30 = (undefined4 *)0x61f5f2;
    uStack_30 = (undefined4 *)FUN_0056a9c0();
    uStack_2c = &uStack_c;
    FUN_005672c0();
    return param_1;
  case 1:
    uStack_2c = (undefined4 *)0x1;
    uStack_c = 0;
    uStack_8 = 0x80000000;
    uStack_30 = (undefined4 *)0x61f64c;
    uStack_30 = (undefined4 *)FUN_0056a9c0();
    uStack_2c = &uStack_c;
    FUN_005672c0();
    return param_1;
  case 2:
    uStack_2c = &uStack_c;
    uStack_30 = &param_2;
    uStack_c = 0xffffffff;
    uStack_8 = 0x7fffffff;
    param_2 = 0xffffffff;
    FUN_005672c0();
    return param_1;
  case 3:
    uStack_2c = (undefined4 *)0x0;
    uStack_30 = (undefined4 *)0x0;
    uVar2 = FUN_005ef640(0,0,0);
    uStack_2c = (undefined4 *)CONCAT22(extraout_var,1);
    uStack_30 = (undefined4 *)CONCAT22((short)((uint)&uStack_2c >> 0x10),1);
    puVar1 = (undefined4 *)FUN_0056a920(CONCAT22((short)((uint)&uStack_30 >> 0x10),0x578));
    param_2 = *puVar1;
    uStack_30 = &param_2;
    uStack_2c = (undefined4 *)uVar2;
    FUN_005672c0();
    return param_1;
  case 4:
    uStack_2c = (undefined4 *)0x0;
    uStack_30 = (undefined4 *)0x0;
    FUN_005ef640(0x18,0,0);
    uStack_2c = (undefined4 *)0x0;
    uStack_30 = (undefined4 *)0x1;
    uStack_2c = (undefined4 *)FUN_005ef640(0,0,0);
    uStack_30 = (undefined4 *)auStack_24;
    puVar1 = (undefined4 *)FUN_00602640();
    uStack_14 = *puVar1;
    uStack_10 = puVar1[1];
    uStack_2c = (undefined4 *)CONCAT22((short)((uint)uStack_14 >> 0x10),0x1f);
    uStack_30 = (undefined4 *)0xc;
    puVar1 = (undefined4 *)FUN_0056a920(9999);
    param_2 = *puVar1;
    uStack_2c = &uStack_14;
    uStack_30 = &param_2;
    FUN_005672c0();
    return param_1;
  default:
    uStack_2c = (undefined4 *)0x0;
    uStack_14 = 0xfffffffe;
    uStack_10 = 0x7fffffff;
    uStack_30 = (undefined4 *)0x61f74e;
    uStack_30 = (undefined4 *)FUN_0056a9c0();
    uStack_2c = &uStack_14;
    FUN_005672c0();
    return param_1;
  }
}



/* FUNCTION 6779 ; VA 0x0061f780 ; FUN_0061f780 */

void __thiscall FUN_0061f780(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  bool bVar7;
  undefined auStack_30 [4];
  int *piStack_2c;
  uint uStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e32b;
  pvStack_10 = ExceptionList;
  iStack_18 = 0;
  iStack_14 = param_1;
  if (DAT_01d5b810 == '\0') {
    puVar2 = *(undefined4 **)(param_1 + 0x1958);
    puVar3 = (undefined4 *)*puVar2;
    puStack_1c = (undefined4 *)*puVar3;
    if (puStack_1c == (undefined4 *)0x0) {
      ExceptionList = &pvStack_10;
      puStack_1c = (undefined4 *)FUN_00621d50();
    }
    else {
      ExceptionList = &pvStack_10;
      *puVar3 = *puStack_1c;
    }
    *puStack_1c = puVar2;
    puStack_1c = puStack_1c + 1;
    uStack_8 = 0;
    bVar7 = puStack_1c == (undefined4 *)0x0;
    if (bVar7) {
      uVar6 = 0;
    }
    else {
      piVar5 = (int *)FUN_0060dcd0(auStack_30,param_2);
      iStack_24 = *piVar5;
      uStack_20 = (int *)piVar5[1];
      *piVar5 = 0;
      piVar5[1] = 0;
      uStack_8 = 2;
      iStack_18 = 3;
      uVar6 = FUN_006f60c0(iStack_14,param_3,&iStack_24);
    }
    uStack_8 = 4;
    FUN_006b1f50(uVar6);
    piVar5 = uStack_20;
    if (!bVar7) {
      if (uStack_20 != (int *)0x0) {
        LOCK();
        iVar4 = uStack_20[1] + -1;
        uStack_20[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*uStack_20)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar4 = *piVar1 + -1;
          *piVar1 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    if ((!bVar7) && (piStack_2c != (int *)0x0)) {
      LOCK();
      iVar4 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar5 = piStack_2c + 2;
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    iStack_18 = param_1;
    if ((uint)((param_4[1] - *param_4 >> 2) * 3) >> 2 <= (uint)param_4[3]) {
      ExceptionList = &pvStack_10;
      FUN_006286d0();
    }
    FUN_00620c30(&iStack_18);
  }
  iStack_24 = 0;
  uStack_20 = (int *)((uint)uStack_20 & 0xffff0000);
  uStack_28 = -(uint)(iStack_14 != -0x1e3b) & iStack_14 + 0x1e3cU;
  uStack_8 = 5;
  FUN_00619e20();
  iVar4 = iStack_24;
  FUN_0054ef60(param_3);
  *(undefined4 *)(iVar4 + 0x20) = param_2;
  uStack_20._0_2_ = CONCAT11(1,(undefined)uStack_20);
  FUN_0061c4c0(auStack_30,&uStack_28);
  FUN_00611af0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6780 ; VA 0x0061f960 ; FUN_0061f960 */

void __thiscall
FUN_0061f960(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,char param_9
            )

{
  char cVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  if ((param_1[0xe02] & 0x40U) == 0) {
    if ((DAT_01d5b840 == '\0') || (param_9 == '\0')) {
      uVar2 = 0;
    }
    else {
      uVar2 = 1;
    }
    uStack_8 = 0;
  }
  else {
    iVar3 = (**(code **)(*param_1 + 0xb8))();
    cVar1 = (**(code **)(*param_1 + 0xd4))();
    if ((cVar1 != '\0') && (iVar3 != 0)) {
      iVar3 = thunk_FUN_00676db0();
      if (iVar3 != 0) {
        uVar4 = thunk_FUN_00676db0();
        cVar1 = FUN_00620ec0(uVar4);
        if (cVar1 != '\0') {
          if ((DAT_01d5b840 == '\0') || (param_9 == '\0')) {
            uVar2 = 0;
            uStack_8 = 1;
          }
          else {
            uVar2 = 1;
            uStack_8 = 1;
          }
          goto LAB_0061fa1c;
        }
      }
    }
    if ((DAT_01d5b840 == '\0') || (param_9 == '\0')) {
      uVar2 = 0;
      uStack_8 = 0;
    }
    else {
      uVar2 = 1;
      uStack_8 = 0;
    }
  }
LAB_0061fa1c:
  FUN_0061fa50(param_2,param_3,param_4,uStack_8,param_5,param_6,param_7,param_8,uVar2);
  return;
}



/* FUNCTION 6781 ; VA 0x0061fa50 ; FUN_0061fa50 */

void __thiscall
FUN_0061fa50(int *param_1,int *param_2,int param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,char param_8,undefined4 param_9,char param_10)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  ushort *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  uint3 uVar10;
  undefined4 uVar8;
  int iVar9;
  char *pcVar11;
  undefined4 in_stack_ffffff84;
  undefined4 in_stack_ffffff88;
  char *pcVar12;
  undefined4 uVar13;
  undefined auStack_50 [24];
  int aiStack_38 [5];
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e371;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (ushort *)FUN_006193f0(*(undefined4 *)(*param_2 + 0xc));
  if (puVar4 == (ushort *)0x0) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar9 = *(int *)(param_1[0x67d] + 0x58);
  if ((uint)*puVar4 < (uint)((*(int *)(param_1[0x67d] + 0x5c) - iVar9) / 0x3c)) {
    puStack_14 = (undefined4 *)(iVar9 + (uint)*puVar4 * 0x3c);
  }
  else {
    puStack_14 = (undefined4 *)0x0;
  }
  uVar5 = (**(code **)(*param_1 + 0x17c))(*param_2);
  if ((char)uVar5 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  if (DAT_01ee420d != 0) {
    iVar9 = *param_2;
    puVar6 = (undefined4 *)FUN_008a2380(aiStack_38);
    uStack_8 = 0;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    in_stack_ffffff88 = 0x61fb22;
    uVar5 = FUN_01677490(DAT_01ee420d,"Child instance added to replication: %s[%p]",puVar6,iVar9,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_24) {
      uVar5 = uStack_24 + 1;
      iVar9 = aiStack_38[0];
      if (0xfff < uVar5) {
        iVar9 = *(int *)(aiStack_38[0] + -4);
        uVar5 = uStack_24 + 0x24;
        if (0x1f < (aiStack_38[0] - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uVar5 = FUN_01674ea0(iVar9,uVar5);
    }
  }
  if (((DAT_01d5b840 == '\0') && (param_3 != 0)) &&
     (uVar5 = FUN_00621090(*param_2), (char)uVar5 != '\0')) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar9 = *param_2;
  if (param_1[0x686] == iVar9) {
    ExceptionList = pvStack_10;
    return;
  }
  if ((param_1[0x779] != 0) && (iVar9 != 0)) {
    iVar9 = *(int *)(iVar9 + 0xc);
    iVar7 = FUN_00aff8c0();
    uVar5 = (uint)*(ushort *)(iVar7 + 0x1da);
    if (((uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <= uVar5) &&
       ((char)param_6 != '\0')) {
      if (*param_2 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      iVar9 = *(int *)(*param_2 + 0xc);
      iVar7 = FUN_00af0010();
      uVar5 = (uint)*(ushort *)(iVar7 + 0x1da);
      if (uVar5 < (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8)) {
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 1;
  if (((DAT_01d5b840 == '\0') || (param_10 == '\0')) ||
     ((uVar5 = (**(code **)(*param_1 + 0xd4))(), (char)uVar5 == '\0' ||
      (uVar5 = FUN_006de120(*param_2,param_6,param_1[0x779] != 0), (char)uVar5 == '\0')))) {
    uVar5 = uVar5 & 0xffffff00;
    bVar2 = false;
  }
  else {
    uVar5 = CONCAT31((int3)(uVar5 >> 8),1);
    bVar2 = true;
  }
  uVar10 = (uint3)(uVar5 >> 8);
  if ((DAT_01d5b840 == '\0') || (!bVar2)) {
    iVar9 = (uint)uVar10 << 8;
  }
  else {
    iVar9 = CONCAT31(uVar10,1);
  }
  puVar6 = &uStack_20;
  pcVar12 = (char *)0x1;
  uVar5 = 1;
  iVar7 = param_3;
  FUN_00557fc0(param_2);
  FUN_00617d00(puStack_14,in_stack_ffffff84,in_stack_ffffff88,uVar5,pcVar12,iVar7,puVar6,iVar9);
  if ((DAT_01d5b820 != '\0') && (cVar3 = (**(code **)(*param_1 + 0xd4))(), cVar3 != '\0')) {
    if (param_8 != '\0') {
      pcVar12 = (char *)0x61fcc7;
      cVar3 = FUN_006de120(*param_2,param_6,param_1[0x779] != 0);
      if (cVar3 != '\0') {
        param_8 = '\x01';
        if (DAT_01ee420d != 0) {
          puVar6 = (undefined4 *)FUN_008a2380(aiStack_38);
          uStack_8._0_1_ = 2;
          if (0xf < (uint)puVar6[5]) {
            puVar6 = (undefined4 *)*puVar6;
          }
          pcVar12 = "JoinDataItem";
          if (param_3 != 0) {
            pcVar12 = "NewInstanceItem";
          }
          FUN_01677490(DAT_01ee420d,
                       "handleChildAddedHelper()::Adding MRD for instance %s to BlobCacheMRPMap where mode=%s"
                       ,puVar6,pcVar12,0);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_005507b0();
        }
        FUN_006d9060();
        uVar8 = FUN_006d9e30(*param_2);
        uVar5 = 0x61fd52;
        pcVar12 = (char *)param_2;
        FUN_006c9080(param_2,1,1,uVar8);
        goto LAB_0061fd5d;
      }
    }
    param_8 = '\0';
  }
LAB_0061fd5d:
  pcVar11 = "JoinDataItem";
  cVar3 = FUN_0061f540();
  if (((cVar3 == '\0') || ((char)param_7 == '\0')) ||
     (cVar3 = (**(code **)(*param_1 + 0xd4))(), cVar3 == '\0')) {
    if (DAT_01ee420d != 0) {
      puVar6 = (undefined4 *)FUN_008a2380(auStack_50);
      uStack_8._0_1_ = 3;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      if (param_3 != 0) {
        pcVar11 = "NewInstanceItem";
      }
      uVar5 = (uint)DAT_01ee420d;
      pcVar12 = "handleChildAddedHelper()::Adding instance %s to DataItem where mode=%s";
      FUN_01677490(uVar5,"handleChildAddedHelper()::Adding instance %s to DataItem where mode=%s",
                   puVar6,pcVar11,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_005507b0();
    }
    if ((DAT_01d5b810 == '\0') || (param_3 != 1)) {
      FUN_00615010(param_2,puStack_14,&uStack_20,param_5);
    }
    else {
      puVar6 = &uStack_20;
      uVar8 = param_5;
      uVar13 = param_9;
      FUN_00557fc0(param_2);
      FUN_006d4f40(param_1,uVar5,pcVar12,puVar6,uVar8,uVar13);
    }
  }
  cVar3 = (**(code **)(*param_1 + 0xd4))();
  if (((cVar3 != '\0') && (cVar3 = FUN_0061ef00(), cVar3 != '\0')) &&
     ((iVar9 = (**(code **)(*param_1 + 0xb8))(), iVar9 != 0 &&
      ((*(int *)(iVar9 + 100) != 0 && (*param_2 == *(int *)(iVar9 + 100))))))) {
    FUN_009301b0();
  }
  piVar1 = *(int **)(*param_2 + 0x2c);
  if (piVar1 != (int *)0x0) {
    puStack_14 = (undefined4 *)piVar1[1];
    puVar6 = (undefined4 *)*piVar1;
    if (puVar6 != puStack_14) {
      do {
        if (DAT_01d5b840 == '\0') {
LAB_0061fea7:
          uVar8 = 0;
LAB_0061fea9:
          FUN_0061fa50(puVar6,param_3,param_4,0,param_6,param_7,param_8,param_9,uVar8);
        }
        else {
          cVar3 = (**(code **)(*param_1 + 0xd4))();
          if ((cVar3 != '\0') || (cVar3 = FUN_00621090(*puVar6), cVar3 == '\0')) {
            if ((DAT_01d5b840 == '\0') || (!bVar2)) goto LAB_0061fea7;
            uVar8 = 1;
            goto LAB_0061fea9;
          }
        }
        puVar6 = puVar6 + 2;
      } while (puVar6 != puStack_14);
    }
  }
  if (((param_1[0xe02] & 0x40U) != 0) && ((char)param_5 != '\0')) {
    iVar9 = param_1[0x653];
    uVar8 = 0x40;
    iVar7 = FUN_00613cb0(0x40,iVar9);
    uStack_8._0_1_ = 4;
    if (iVar7 == 0) {
      uVar8 = 0;
    }
    else {
      FUN_00557fc0(param_2);
      uVar8 = FUN_006bf520(param_1,uVar8,iVar9);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_006b1f50(uVar8);
  }
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6782 ; VA 0x0061ff50 ; FUN_0061ff50 */

/* WARNING: Removing unreachable block (ram,0x0062007e) */

void FUN_0061ff50(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  undefined8 uVar8;
  undefined auStack_94 [16];
  undefined4 uStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_60;
  int iStack_5c;
  undefined8 uStack_54;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  undefined8 uStack_24;
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  uint uStack_10;
  uint uStack_c;
  undefined4 uStack_8;
  
  iStack_34 = *param_2;
  iStack_30 = param_2[1];
  iStack_2c = param_2[2];
  iStack_28 = param_2[3];
  uStack_24 = *(undefined8 *)(param_2 + 4);
  while( true ) {
    lVar7 = CONCAT44(uStack_14,uStack_8);
    uStack_18 = (param_1[1] - *param_1) / 0x18;
    if (uStack_18 == 0) break;
    uStack_84 = 0;
    iStack_7c = 0;
    iStack_78 = 0;
    iStack_74 = 0;
    iStack_70 = 0;
    uStack_80 = 0;
    uStack_3c = 0;
    uStack_c = 0xffffffff;
    lVar7 = 0x1000;
    uStack_10 = 0;
    iStack_1c = 0;
    do {
      uStack_14 = (undefined4)((ulonglong)lVar7 >> 0x20);
      uStack_8 = (undefined4)lVar7;
      piVar3 = (int *)(*param_1 + iStack_1c);
      iStack_60 = *piVar3;
      if (iStack_34 <= *piVar3) {
        iStack_60 = iStack_34;
      }
      iStack_5c = piVar3[1];
      if (iStack_30 <= piVar3[1]) {
        iStack_5c = iStack_30;
      }
      iStack_4c = piVar3[2];
      if (iStack_2c <= piVar3[2]) {
        iStack_4c = iStack_2c;
      }
      iStack_6c = piVar3[3];
      if (piVar3[3] <= iStack_28) {
        iStack_6c = iStack_28;
      }
      uStack_54 = CONCAT44(iStack_5c,iStack_60);
      iStack_68 = piVar3[4];
      if (piVar3[4] <= (int)uStack_24) {
        iStack_68 = (int)uStack_24;
      }
      iStack_40 = piVar3[5];
      if (piVar3[5] <= uStack_24._4_4_) {
        iStack_40 = uStack_24._4_4_;
      }
      iStack_48 = iStack_6c;
      iStack_44 = iStack_68;
      FUN_00a71450(auStack_94,&iStack_34);
      lVar4 = FUN_00a70d30();
      lVar5 = FUN_00a70d30();
      lVar6 = FUN_00a70d30();
      lVar7 = FUN_00a70d30();
      lVar7 = ((lVar4 - lVar5) - lVar6) + lVar7;
      lVar4 = CONCAT44(uStack_14,uStack_8);
      if (lVar7 < CONCAT44(uStack_14,uStack_8)) {
        uStack_c = uStack_10;
        iStack_7c = (int)uStack_54;
        iStack_78 = uStack_54._4_4_;
        iStack_74 = iStack_4c;
        iStack_70 = iStack_48;
        uStack_3c = CONCAT44(iStack_40,iStack_44);
        lVar4 = lVar7;
        if (lVar7 == 0) goto LAB_006200dc;
      }
      lVar7 = lVar4;
      uStack_10 = uStack_10 + 1;
      iStack_1c = iStack_1c + 0x18;
    } while (uStack_10 < uStack_18);
    if ((lVar7 != 0) && (uStack_18 < DAT_01d59f70)) break;
LAB_006200dc:
    uStack_14 = (undefined4)((ulonglong)lVar7 >> 0x20);
    uStack_8 = (undefined4)lVar7;
    iVar2 = *param_1 + uStack_c * 0x18;
    iVar1 = iVar2 + 0x18;
    FUN_0055b6b0((int)&param_2 + 3,&uStack_18,&uStack_18);
    FUN_0170cc70(iVar2,iVar1,param_1[1] - iVar1);
    param_1[1] = param_1[1] + -0x18;
    iStack_34 = iStack_7c;
    iStack_30 = iStack_78;
    iStack_2c = iStack_74;
    iStack_28 = iStack_70;
    uStack_24 = uStack_3c;
  }
  uStack_14 = (undefined4)((ulonglong)lVar7 >> 0x20);
  uStack_8 = (undefined4)lVar7;
  uVar8 = FUN_00a70d30();
  if (((int)((ulonglong)uVar8 >> 0x20) == 0) && ((uint)uVar8 < 0x1000)) {
    piVar3 = (int *)param_1[1];
    if ((int *)param_1[2] != piVar3) {
      *piVar3 = iStack_34;
      piVar3[1] = iStack_30;
      piVar3[2] = iStack_2c;
      piVar3[3] = iStack_28;
      *(undefined8 *)(piVar3 + 4) = uStack_24;
      param_1[1] = param_1[1] + 0x18;
      return;
    }
    FUN_00603350(piVar3,&iStack_34);
    return;
  }
  param_1[1] = *param_1;
  return;
}



/* FUNCTION 6783 ; VA 0x00620180 ; FUN_00620180 */

uint __thiscall FUN_00620180(int *param_1,int param_2,undefined4 *param_3,int *param_4,int *param_5)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  uint *puVar9;
  undefined4 **ppuVar10;
  uint extraout_ECX;
  int iVar11;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  int iStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 *puStack_5c;
  int iStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined auStack_38 [8];
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e491;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_14 = 0;
  iStack_18 = *(int *)(param_1[0x67d] + 100);
  if (((uint)param_4 & 0xffff) < (uint)((*(int *)(param_1[0x67d] + 0x68) - iStack_18) / 0x14)) {
    iStack_18 = iStack_18 + ((uint)param_4 & 0xffff) * 0x14;
  }
  else {
    iStack_18 = 0;
  }
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00620ff0(param_3);
  if (cVar4 == '\0') {
    iVar5 = (**(code **)(*param_1 + 0xb4))();
    if ((((iVar5 == 0) || (iVar11 = *(int *)(iVar5 + 100), iVar11 == 0)) ||
        ((iVar11 != *(int *)(param_2 + 0x34) &&
         ((*(int *)(param_2 + 0x34) == 0 || (cVar4 = FUN_00620ec0(iVar11), cVar4 == '\0')))))) &&
       (iVar5 != param_2)) {
      if (DAT_01d5b810 == '\0') {
        piVar3 = (int *)param_1[0x655];
        puVar7 = *(undefined4 **)*piVar3;
        param_4 = piVar3;
        if (puVar7 == (undefined4 *)0x0) {
          puVar7 = (undefined4 *)FUN_00621d50();
        }
        else {
          *(undefined4 *)*piVar3 = *puVar7;
        }
        *puVar7 = piVar3;
        param_5 = puVar7 + 1;
        uStack_8 = 0xf;
        if (param_5 == (int *)0x0) {
          uVar8 = 0;
        }
        else {
          uVar8 = FUN_0060dcd0(auStack_38,param_2);
          FUN_00557f90(uVar8);
          uStack_8 = 0x11;
          uStack_14 = 0xc0;
          uStack_28 = 0xc0;
          uVar8 = FUN_006f57e0(param_1,param_3,iStack_18,&uStack_30);
        }
        uStack_8 = 0x13;
        FUN_006b1f50(uVar8);
        if ((char)uStack_14 < '\0') {
          uStack_14 = uStack_14 & 0xffffff7f;
          FUN_00550b30();
        }
        uStack_8 = 0xffffffff;
        if ((uStack_14 & 0x40) != 0) {
          FUN_00550b30();
        }
      }
      else {
        if (DAT_01eaf007 != '\0') {
          FUN_01677520(DAT_01eaf007,"adding peer(%d) for property Change",param_1[0xe10]);
        }
        param_4 = param_1;
        if ((uint)((param_5[1] - *param_5 >> 2) * 3) >> 2 <= (uint)param_5[3]) {
          FUN_006286d0();
        }
        FUN_00620c30(&param_4);
      }
      FUN_01682800(&uStack_94);
      uStack_8c = CONCAT31(uStack_8c._1_3_,*(undefined *)(iStack_18 + 4));
      if (DAT_01d5a080 != '\0') {
        FUN_006b8860(*(undefined *)(iStack_18 + 4));
      }
      puStack_74 = param_3;
      iStack_70 = param_2;
      ppuVar10 = &puStack_74;
      uStack_6c = uStack_94;
      uStack_68 = uStack_90;
      uStack_64 = uStack_8c;
      uStack_60 = uStack_88;
    }
    else {
      FUN_006b1ea0(&uStack_30);
      piVar3 = (int *)param_1[0x655];
      if (DAT_01d5b810 == '\0') {
        puVar7 = *(undefined4 **)*piVar3;
        param_4 = piVar3;
        if (puVar7 == (undefined4 *)0x0) {
          puVar7 = (undefined4 *)FUN_00621d50();
        }
        else {
          *(undefined4 *)*piVar3 = *puVar7;
        }
        *puVar7 = piVar3;
        param_5 = puVar7 + 1;
        uStack_8 = 10;
        if (param_5 == (int *)0x0) {
          uVar8 = 0;
        }
        else {
          puVar7 = (undefined4 *)FUN_0060dcd0(auStack_38,param_2);
          uStack_24 = *puVar7;
          uStack_20 = puVar7[1];
          *puVar7 = 0;
          puVar7[1] = 0;
          uStack_8 = 0xc;
          uStack_14 = 0x30;
          uStack_28 = 0x30;
          uVar8 = FUN_006f57e0(param_1,param_3,iStack_18,&uStack_24);
        }
        uStack_8 = 0xe;
        FUN_006b1fb0(uVar8);
        if ((uStack_14 & 0x20) != 0) {
          uStack_14 = uStack_14 & 0xffffffdf;
          FUN_00550b30();
        }
        uVar6 = uStack_14 & 0x10;
      }
      else {
        puVar7 = *(undefined4 **)*piVar3;
        piStack_44 = piVar3;
        if (puVar7 == (undefined4 *)0x0) {
          puVar7 = (undefined4 *)FUN_00621d50();
        }
        else {
          *(undefined4 *)*piVar3 = *puVar7;
        }
        *puVar7 = piVar3;
        piStack_3c = puVar7 + 1;
        uStack_8 = 5;
        if (piStack_3c == (int *)0x0) {
          uVar8 = 0;
        }
        else {
          if (param_1[0x77c] == 0) {
            puVar9 = (uint *)&DAT_00000018;
          }
          else {
            puVar9 = (uint *)(param_1[0x77c] + 0x10);
          }
          param_4 = (int *)puVar9[1];
          param_5 = (int *)param_1[0xe05];
          piStack_1c = (int *)param_1[0xe04];
          if ((param_4 < param_5) || ((param_4 <= param_5 && ((int *)*puVar9 <= piStack_1c)))) {
            param_5 = param_4;
            piStack_1c = (int *)*puVar9;
          }
          puVar7 = (undefined4 *)FUN_0060dcd0(auStack_38,param_2);
          uStack_24 = *puVar7;
          uStack_20 = puVar7[1];
          *puVar7 = 0;
          puVar7[1] = 0;
          uStack_8 = 7;
          uStack_14 = 0xc;
          uStack_28 = 0xc;
          uVar8 = FUN_006f5840(param_1,param_3,iStack_18,&uStack_24,piStack_1c,param_5);
        }
        uStack_8 = 9;
        FUN_006b1fb0(uVar8);
        if ((uStack_14 & 8) != 0) {
          uStack_14 = uStack_14 & 0xfffffff7;
          FUN_00550b30();
        }
        uVar6 = uStack_14 & 4;
      }
      uStack_8 = 0xffffffff;
      if (uVar6 != 0) {
        FUN_00550b30();
      }
      if (param_1[0x77c] == 0) {
        puVar7 = (undefined4 *)0x28;
      }
      else {
        puVar7 = (undefined4 *)(param_1[0x77c] + 0x20);
      }
      *puVar7 = uStack_30;
      puVar7[1] = piStack_2c;
      FUN_01682800(&uStack_84);
      uStack_7c = CONCAT31(uStack_7c._1_3_,*(undefined *)(iStack_18 + 4));
      if (DAT_01d5a080 != '\0') {
        FUN_006b8860(*(undefined *)(iStack_18 + 4));
      }
      puStack_5c = param_3;
      iStack_58 = param_2;
      ppuVar10 = &puStack_5c;
      uStack_54 = uStack_84;
      uStack_50 = uStack_80;
      uStack_4c = uStack_7c;
      uStack_48 = uStack_78;
    }
    uVar6 = FUN_00606880(auStack_38,ppuVar10,ppuVar10);
    ExceptionList = pvStack_10;
    return uVar6;
  }
  param_4 = (int *)(extraout_ECX & 0xffffff00);
  if (DAT_01d5b810 != '\0') {
    if ((param_1[0xe02] & 0x40U) != 0) {
      iVar5 = (**(code **)(*param_1 + 0xb4))();
      if (iVar5 == 0) {
        iVar11 = 0;
      }
      else {
        iVar11 = *(int *)(iVar5 + 100);
      }
      if ((((param_3 == &DAT_0211e300) && (iVar5 != 0)) && (iVar11 != 0)) && (param_2 == iVar5)) {
        cVar4 = FUN_00621090(iVar11);
        param_4 = (int *)((uint)param_4 & 0xff);
        if (cVar4 != '\0') {
          param_4 = (int *)0x1;
        }
      }
    }
    if ((DAT_01d5b810 != '\0') && ((char)param_4 == '\0')) {
      if (DAT_01eaf007 != '\0') {
        FUN_01677520(DAT_01eaf007,"adding peer(%d) for property Change",param_1[0xe10]);
      }
      piStack_1c = param_1;
      if ((uint)((param_5[1] - *param_5 >> 2) * 3) >> 2 <= (uint)param_5[3]) {
        FUN_006286d0();
      }
      uVar6 = FUN_00620c30(&piStack_1c);
      goto LAB_006203d2;
    }
  }
  piVar3 = (int *)param_1[0x65a];
  puVar7 = *(undefined4 **)*piVar3;
  param_5 = piVar3;
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)FUN_00621d50();
  }
  else {
    *(undefined4 *)*piVar3 = *puVar7;
  }
  *puVar7 = piVar3;
  piStack_1c = puVar7 + 1;
  uStack_8 = 0;
  if (piStack_1c == (int *)0x0) {
    uVar8 = 0;
  }
  else {
    puVar7 = (undefined4 *)FUN_0060dcd0(&uStack_30,param_2);
    uStack_40 = *puVar7;
    piStack_3c = (int *)puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    uStack_8 = 2;
    uStack_14 = 3;
    uStack_28 = 3;
    uVar8 = FUN_006fc760(param_1,param_3,iStack_18,&uStack_40);
  }
  uStack_8 = 4;
  FUN_006b1f50(uVar8);
  piVar3 = piStack_3c;
  if (((uStack_14 & 2) != 0) && (uStack_14 = uStack_14 & 0xfffffffd, piStack_3c != (int *)0x0)) {
    LOCK();
    iVar5 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uVar6 = 0xffffffff;
  uStack_8 = 0xffffffff;
  if (((uStack_14 & 1) != 0) && (piStack_2c != (int *)0x0)) {
    LOCK();
    puVar9 = (uint *)(piStack_2c + 1);
    uVar2 = *puVar9;
    uVar6 = *puVar9;
    *puVar9 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar6 = (**(code **)*piStack_2c)();
      LOCK();
      piVar3 = piStack_2c + 2;
      iVar5 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uVar6 = (**(code **)(*piStack_2c + 4))();
      }
    }
  }
LAB_006203d2:
  if (DAT_01d5b810 == '\0') {
    uVar6 = param_1[0xe02] & 0x40;
    if (uVar6 != 0) {
      iVar5 = (**(code **)(*param_1 + 0xb4))();
      if (iVar5 == 0) {
        uVar6 = 0;
      }
      else {
        uVar6 = *(uint *)(iVar5 + 100);
      }
      if ((((param_3 == &DAT_0211e300) && (iVar5 != 0)) && (uVar6 != 0)) &&
         ((param_2 == iVar5 && (uVar6 = FUN_00621090(uVar6), (char)uVar6 != '\0')))) {
        uVar6 = FUN_009301b0();
        ExceptionList = pvStack_10;
        return uVar6;
      }
    }
  }
  else if ((char)param_4 != '\0') {
    (**(code **)(*param_1 + 0xb4))();
    uVar6 = FUN_009301b0();
    ExceptionList = pvStack_10;
    return uVar6;
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 6784 ; VA 0x00620890 ; FUN_00620890 */

undefined4 __fastcall FUN_00620890(int param_1)

{
  if ((*(int *)(param_1 + 0x38f0) == 0) && (*(int *)(param_1 + 0x38f8) == 0)) {
    return *(undefined4 *)(param_1 + 0x1f20);
  }
  return *(undefined4 *)(param_1 + 0x38e0);
}



/* FUNCTION 6785 ; VA 0x006208b0 ; FUN_006208b0 */

float10 __thiscall FUN_006208b0(int param_1,double *param_2)

{
  double dVar1;
  double dVar2;
  
  if ((*(int *)(param_1 + 0x38f0) == 0) && (*(int *)(param_1 + 0x38f8) == 0)) {
    dVar2 = *(double *)(param_1 + 0x1f28);
  }
  else {
    dVar2 = *(double *)(param_1 + 0x38e8);
  }
  dVar1 = 0.0;
  if (0.0 < dVar2) {
    dVar1 = *param_2 - dVar2;
  }
  return (float10)dVar1;
}



/* FUNCTION 6786 ; VA 0x00620900 ; FUN_00620900 */

void __thiscall FUN_00620900(double *param_1,int param_2)

{
  double *pdVar1;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  pdVar1 = (double *)FUN_016827a0(&uStack_c);
  if (param_1[1] <= *pdVar1 - *param_1) {
    *(undefined4 *)(param_1 + 2) = *(undefined4 *)((int)param_1 + 0x14);
    *(undefined4 *)((int)param_1 + 0x14) = 0;
    FUN_016827a0(&uStack_c);
    *(undefined4 *)param_1 = uStack_c;
    *(undefined4 *)((int)param_1 + 4) = uStack_8;
  }
  *(int *)((int)param_1 + 0x14) = *(int *)((int)param_1 + 0x14) + param_2;
  return;
}



/* FUNCTION 6787 ; VA 0x00620960 ; FUN_00620960 */

void __thiscall FUN_00620960(int param_1,int param_2,int param_3)

{
  int *piVar1;
  
  if ((((param_2 != 5) && (param_2 != 6)) && (param_2 != 9)) && (param_2 != 0x12)) {
    piVar1 = (int *)(*(int *)(param_1 + 0x3888) + param_2 * 4);
    *piVar1 = *piVar1 + param_3;
  }
  return;
}



/* FUNCTION 6788 ; VA 0x00620990 ; FUN_00620990 */

void __thiscall FUN_00620990(int param_1,int param_2)

{
  int *piVar1;
  
  if ((((param_2 != 5) && (param_2 != 6)) && (param_2 != 9)) && (param_2 != 0x12)) {
    piVar1 = (int *)(*(int *)(param_1 + 0x3870) + param_2 * 4);
    *piVar1 = *piVar1 + 1;
  }
  return;
}



/* FUNCTION 6789 ; VA 0x006209c0 ; FUN_006209c0 */

void __thiscall FUN_006209c0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179de58;
  pvStack_10 = ExceptionList;
  iVar2 = param_1 + 0x1e50;
  ExceptionList = &pvStack_10;
  iVar3 = iVar2;
  iVar1 = FUN_016dee6d(iVar2);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x1db8) == '\0') {
    FUN_006d9230(param_1,param_2);
  }
  uStack_8 = 1;
  iVar2 = FUN_016deec8(iVar2);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2,iVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6790 ; VA 0x00620a50 ; FUN_00620a50 */

void __fastcall FUN_00620a50(int *param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined auStack_58 [72];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e4a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008f7870(param_1);
  if ((((iVar3 != 0) && (*(int *)(iVar3 + 0x1b8) != 0)) && (iVar3 = FUN_00a9d3e0(), iVar3 != 0)) &&
     (iVar1 = *(int *)(iVar3 + 0xc), iVar4 = FUN_00af0010(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
     (uint)*(ushort *)(iVar4 + 0x1da))) {
    if (DAT_01eace39 != '\0') {
      FUN_01677520(DAT_01eace39,"Adding replication data for mega cluster instance %p",iVar3);
    }
    if (DAT_01d65191 != '\0') {
      FUN_016774b0(DAT_01d65191,"Adding MegaCluster replication data :%p",iVar3);
    }
    FUN_0170d1f0(auStack_58,0,0x48);
    uVar5 = FUN_0060ee60();
    uStack_8 = 0;
    FUN_00613da0(uVar5);
    uStack_8 = 0xffffffff;
    FUN_00612ec0();
    cVar2 = (**(code **)(*param_1 + 0xd4))();
    if (cVar2 != '\0') {
      FUN_00708420(iVar3);
      FUN_00707180(param_1,iVar3);
    }
    param_1[0x686] = iVar3;
    FUN_00a6e300(param_1 + 0x1a);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6791 ; VA 0x00620b90 ; FUN_00620b90 */

void FUN_00620b90(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_c;
  undefined uStack_8;
  
  FUN_00606670(&uStack_c,param_2,param_2);
  *param_1 = uStack_c;
  *(undefined *)(param_1 + 1) = uStack_8;
  return;
}



/* FUNCTION 6792 ; VA 0x00620bc0 ; FUN_00620bc0 */

uint * __thiscall FUN_00620bc0(int *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar2 = *param_2;
  uVar3 = (uVar2 >> 3) + uVar2;
  uVar5 = (param_1[1] - *param_1 >> 3) - 1;
  uVar4 = 0;
  while( true ) {
    uVar3 = uVar3 & uVar5;
    puVar1 = (uint *)(*param_1 + uVar3 * 8);
    if (*puVar1 == param_1[4]) {
      *puVar1 = uVar2;
      param_1[3] = param_1[3] + 1;
      return puVar1;
    }
    if (*puVar1 == uVar2) break;
    uVar3 = uVar3 + 1 + uVar4;
    uVar4 = uVar4 + 1;
    if (uVar5 < uVar4) {
      return (uint *)0x0;
    }
  }
  return puVar1;
}



/* FUNCTION 6793 ; VA 0x00620c30 ; FUN_00620c30 */

uint * __thiscall FUN_00620c30(int *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar2 = *param_2;
  uVar3 = (uVar2 >> 3) + uVar2;
  uVar5 = (param_1[1] - *param_1 >> 2) - 1;
  uVar4 = 0;
  while( true ) {
    uVar3 = uVar3 & uVar5;
    puVar1 = (uint *)(*param_1 + uVar3 * 4);
    if (*puVar1 == param_1[4]) {
      *puVar1 = uVar2;
      param_1[3] = param_1[3] + 1;
      return puVar1;
    }
    if (*puVar1 == uVar2) break;
    uVar3 = uVar3 + 1 + uVar4;
    uVar4 = uVar4 + 1;
    if (uVar5 < uVar4) {
      return (uint *)0x0;
    }
  }
  return puVar1;
}



/* FUNCTION 6794 ; VA 0x00620ca0 ; FUN_00620ca0 */

void FUN_00620ca0(undefined4 *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00620caf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)*param_1)();
  return;
}



/* FUNCTION 6795 ; VA 0x00620cc0 ; FUN_00620cc0 */

int FUN_00620cc0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int aiStack_30 [5];
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e4d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00587490(&piStack_18);
  iStack_8 = 0;
  if (piStack_18 != (int *)0x0) {
    iVar2 = *(int *)(param_1 + 8);
    if (iVar2 != -1) {
      if (DAT_01ee420a != '\0') {
        puVar3 = (undefined4 *)FUN_0061be30(aiStack_30,iVar2);
        iStack_8._0_1_ = 1;
        if (0xf < (uint)puVar3[5]) {
          puVar3 = (undefined4 *)*puVar3;
        }
        FUN_01677650(DAT_01ee420a,"Lost connection with reason : %s",puVar3);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (0xf < uStack_1c) {
          uVar5 = uStack_1c + 1;
          iVar2 = aiStack_30[0];
          if (0xfff < uVar5) {
            iVar2 = *(int *)(aiStack_30[0] + -4);
            uVar5 = uStack_1c + 0x24;
            if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar2,uVar5);
        }
        iVar2 = *(int *)(param_1 + 8);
      }
      if (piStack_18[0x1b] != 0) {
        piVar4 = (int *)FUN_0054db20();
        if (piVar4 != (int *)0x0) {
          (**(code **)(*piVar4 + 0x148))(iVar2);
        }
      }
    }
    *(undefined *)((int)piStack_18 + 0x22) = 0;
    iVar2 = (**(code **)(*piStack_18 + 0x2c))();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_14 + 1;
    iVar1 = *piVar4;
    iVar2 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar2 = (**(code **)*piStack_14)();
      LOCK();
      piVar4 = piStack_14 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar2 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 6796 ; VA 0x00620de0 ; FUN_00620de0 */

void FUN_00620de0(undefined4 *param_1,undefined4 param_2)

{
  (*(code *)*param_1)(param_2);
  return;
}



/* FUNCTION 6797 ; VA 0x00620e00 ; FUN_00620e00 */

int FUN_00620e00(int *param_1)

{
  int *piVar1;
  float fVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  code *pcVar6;
  int iVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179e4e8;
  pvStack_10 = ExceptionList;
  puVar4 = (undefined4 *)*param_1;
  fVar2 = (float)puVar4[6];
  piVar8 = (int *)puVar4[5];
  ExceptionList = &pvStack_10;
  if (piVar8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar8[2] = piVar8[2] + 1;
    UNLOCK();
    piVar8 = (int *)puVar4[5];
  }
  uVar5 = puVar4[4];
  piVar1 = piVar8 + 2;
  pcVar6 = (code *)*puVar4;
  uStack_8 = 0;
  if (piVar8 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar7 = (*pcVar6)(uVar5,piVar8,(double)fVar2);
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar7 = (**(code **)(*piVar8 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 6798 ; VA 0x00620ea0 ; FUN_00620ea0 */

undefined __fastcall FUN_00620ea0(int param_1)

{
  undefined uVar1;
  
  if (*(char *)(param_1 + 0x1db8) == '\0') {
    uVar1 = FUN_006d9bc0();
    return uVar1;
  }
  return 0;
}



/* FUNCTION 6799 ; VA 0x00620ec0 ; FUN_00620ec0 */

undefined4 __thiscall FUN_00620ec0(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x34);
  while( true ) {
    if (param_2 == iVar1) {
      return CONCAT31((int3)((uint)iVar1 >> 8),1);
    }
    if (iVar1 == 0) break;
    iVar1 = *(int *)(iVar1 + 0x34);
  }
  return 0;
}



/* FUNCTION 6800 ; VA 0x00620ef0 ; FUN_00620ef0 */

undefined __fastcall FUN_00620ef0(int param_1)

{
  undefined uVar1;
  
  uVar1 = 1;
  if (*(int *)(param_1 + 0x1a18) != 0) {
    uVar1 = *(undefined *)(param_1 + 0x18fc);
  }
  return uVar1;
}



/* FUNCTION 6801 ; VA 0x00620f10 ; FUN_00620f10 */

undefined4 __thiscall FUN_00620f10(int *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  
  iVar2 = (**(code **)(*param_1 + 0xb4))();
  if ((iVar2 != 0) && (iVar2 = *(int *)(iVar2 + 100), iVar2 != 0)) {
    if (iVar2 == *(int *)(param_2 + 0x34)) {
      return 1;
    }
    if ((*(int *)(param_2 + 0x34) != 0) && (cVar1 = FUN_00620ec0(iVar2), cVar1 != '\0')) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 6802 ; VA 0x00620f50 ; FUN_00620f50 */

undefined FUN_00620f50(void)

{
  return 1;
}



/* FUNCTION 6803 ; VA 0x00620f60 ; FUN_00620f60 */

undefined FUN_00620f60(void)

{
  return 1;
}



/* FUNCTION 6804 ; VA 0x00620f70 ; FUN_00620f70 */

undefined FUN_00620f70(void)

{
  return 1;
}



/* FUNCTION 6805 ; VA 0x00620f80 ; FUN_00620f80 */

undefined FUN_00620f80(undefined4 param_1,undefined *param_2)

{
  if ((DAT_01d5af38 != '\0') && (param_2 == &DAT_0212c10c)) {
    return 0;
  }
  return 1;
}



/* FUNCTION 6806 ; VA 0x00620fb0 ; FUN_00620fb0 */

undefined4 __thiscall FUN_00620fb0(int param_1,int param_2)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x1a18) >> 8),
                  *(int *)(param_1 + 0x1a18) == param_2);
}



/* FUNCTION 6807 ; VA 0x00620ff0 ; FUN_00620ff0 */

undefined4 FUN_00620ff0(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e50c;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x28);
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead028) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead028);
    if (DAT_01ead028 == -1) {
      uStack_8 = 0;
      DAT_01ead024 = FUN_0086e8f0("Object");
      FUN_016f37bf(&DAT_01ead028);
    }
  }
  iVar1 = *(int *)(iVar1 + 4);
  ExceptionList = pvStack_10;
  return CONCAT31((int3)((uint)iVar1 >> 8),iVar1 == DAT_01ead024);
}



/* FUNCTION 6808 ; VA 0x00621090 ; FUN_00621090 */

undefined __thiscall FUN_00621090(int param_1,undefined4 param_2)

{
  undefined uVar1;
  
  if (*(char *)(param_1 + 0x1db8) == '\0') {
    uVar1 = FUN_006da1c0(param_1,param_2);
    return uVar1;
  }
  return 0;
}



/* FUNCTION 6809 ; VA 0x006210c0 ; FUN_006210c0 */

undefined __thiscall FUN_006210c0(int param_1,undefined4 param_2)

{
  undefined uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179de58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_016dee6d(param_1 + 0x1e50);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x1db8) == '\0') {
    uVar1 = FUN_006d9f40(param_1,param_2);
  }
  else {
    uVar1 = 0;
  }
  uStack_8 = 1;
  iVar2 = FUN_016deec8(param_1 + 0x1e50);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 6810 ; VA 0x00621160 ; FUN_00621160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_00621160(uint param_1)

{
  uint uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  bool bVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01ead26b == '\0') {
    DAT_01ead26b = '\x01';
    DAT_01ead244 = 0;
    uRam01ead248 = 0;
    DAT_01ead24c = 0;
    DAT_01ead250 = 0;
    _DAT_01ead264 = 0;
    DAT_01ead254 = _DAT_018ce340;
    uRam01ead258 = _UNK_018ce344;
    uRam01ead25c = _UNK_018ce348;
    uRam01ead260 = _UNK_018ce34c;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  bVar5 = DAT_01ead250 == 0;
  uVar3 = DAT_01ead250;
  iVar4 = DAT_01ead254;
  if (!bVar5) {
    do {
      if ((uVar3 <= param_1) && (param_1 < (uVar3 - 8) + iVar4)) break;
      iVar4 = iVar4 + uVar3;
      uVar3 = *(uint *)(iVar4 + -8);
      iVar4 = *(int *)(iVar4 + -4);
    } while (uVar3 != 0);
    bVar5 = uVar3 == 0;
  }
  uStack_8 = 0;
  LOCK();
  uVar3 = DAT_01ead244 + 0x80000000;
  UNLOCK();
  uVar1 = uVar3;
  if (((DAT_01ead244 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead244)) {
    LOCK();
    DAT_01ead244 = uVar3 | 0x40000000;
    UNLOCK();
    uVar1 = DAT_01ead244;
    if ((uVar3 >> 0x1e & 1) == 0) {
      uVar2 = FUN_00554e40();
      SetEvent(uVar2);
      uVar1 = DAT_01ead244;
    }
  }
  DAT_01ead244 = uVar1;
  ExceptionList = pvStack_10;
  return !bVar5;
}



/* FUNCTION 6811 ; VA 0x00621240 ; FUN_00621240 */

undefined FUN_00621240(void)

{
  undefined4 ****ppppuVar1;
  undefined4 ***pppuVar2;
  char cVar3;
  undefined4 ****ppppuVar4;
  uint ***pppuVar5;
  uint uVar6;
  uint ****ppppuVar7;
  uint ****ppppuVar8;
  undefined4 ****ppppuVar9;
  bool bVar10;
  undefined auStack_18c [16];
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined uStack_174;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined uStack_15c;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined uStack_144;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined uStack_12c;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined uStack_114;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined uStack_fc;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined uStack_e4;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined uStack_cc;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined uStack_b4;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined uStack_9c;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined uStack_84;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 ***apppuStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  uint ***pppuStack_54;
  uint **ppuStack_50;
  uint **ppuStack_4c;
  uint **ppuStack_48;
  uint **ppuStack_44;
  undefined4 ***pppuStack_40;
  uint ***pppuStack_3c;
  uint ***pppuStack_38;
  undefined4 uStack_34;
  uint ***pppuStack_30;
  uint ***pppuStack_2c;
  undefined4 ***pppuStack_28;
  undefined4 ***pppuStack_24;
  undefined4 ***pppuStack_20;
  uint **ppuStack_1c;
  uint ***pppuStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e5bf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0152fd20(apppuStack_6c);
  uStack_8 = 0;
  uStack_17c = 0;
  uStack_178 = 0xf;
  auStack_18c[0] = 0;
  FUN_005542c0("iPod Touch 5",0xc);
  uStack_8._0_1_ = 1;
  uStack_164 = 0;
  uStack_160 = 0xf;
  uStack_174 = 0;
  FUN_005542c0("iPod Touch 6",0xc);
  uStack_8._0_1_ = 2;
  uStack_14c = 0;
  uStack_148 = 0xf;
  uStack_15c = 0;
  FUN_005542c0("iPhone 4",8);
  uStack_8._0_1_ = 3;
  uStack_134 = 0;
  uStack_130 = 0xf;
  uStack_144 = 0;
  FUN_005542c0("iPhone 4s",9);
  uStack_8._0_1_ = 4;
  uStack_11c = 0;
  uStack_118 = 0xf;
  uStack_12c = 0;
  FUN_005542c0("iPhone 5",8);
  uStack_8._0_1_ = 5;
  uStack_104 = 0;
  uStack_100 = 0xf;
  uStack_114 = 0;
  FUN_005542c0("iPhone 5s",9);
  uStack_8._0_1_ = 6;
  uStack_ec = 0;
  uStack_e8 = 0xf;
  uStack_fc = 0;
  FUN_005542c0("iPhone 5c",9);
  uStack_8._0_1_ = 7;
  uStack_d4 = 0;
  uStack_d0 = 0xf;
  uStack_e4 = 0;
  FUN_005542c0("iPad 2",6);
  uStack_8._0_1_ = 8;
  uStack_bc = 0;
  uStack_b8 = 0xf;
  uStack_cc = 0;
  FUN_005542c0("iPad 3",6);
  uStack_8._0_1_ = 9;
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  uStack_b4 = 0;
  FUN_005542c0("iPad 4",6);
  uStack_8._0_1_ = 10;
  uStack_8c = 0;
  uStack_88 = 0xf;
  uStack_9c = 0;
  FUN_005542c0("iPad Mini",9);
  uStack_8._0_1_ = 0xb;
  uStack_74 = 0;
  uStack_70 = 0xf;
  uStack_84 = 0;
  FUN_005542c0("iPad Mini 2",0xb);
  uStack_8._0_1_ = 0xc;
  pppuStack_3c = (uint ***)0x0;
  pppuStack_38 = (uint ***)0x0;
  uStack_34 = 0;
  FUN_00604490(auStack_18c,apppuStack_6c,pppuStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  FUN_016f32d1(auStack_18c,0x18,0xc,FUN_005507b0);
  bVar10 = pppuStack_3c == pppuStack_38;
  pppuStack_30 = pppuStack_38;
  pppuStack_2c = pppuStack_3c;
  do {
    if (bVar10) {
      uStack_11 = 0;
LAB_0062168f:
      FUN_00577a40();
      if (0xf < uStack_58) {
        uVar6 = uStack_58 + 1;
        ppppuVar9 = (undefined4 ****)apppuStack_6c[0];
        if (0xfff < uVar6) {
          ppppuVar9 = (undefined4 ****)apppuStack_6c[0][-1];
          uVar6 = uStack_58 + 0x24;
          if ((undefined *)0x1f < (undefined *)((int)apppuStack_6c[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar9,uVar6);
      }
      ExceptionList = pvStack_10;
      return uStack_11;
    }
    ppuStack_1c = (uint **)((uint ****)pppuStack_2c)[4];
    pppuStack_18 = pppuStack_2c;
    if ((uint ***)0xf < ((uint ****)pppuStack_2c)[5]) {
      pppuStack_18 = (uint ***)*pppuStack_2c;
    }
    if (ppuStack_1c < (uint ***)0x10) {
      ppppuVar7 = (uint ****)*pppuStack_18;
      ppuStack_50 = (uint **)((uint ****)pppuStack_18)[1];
      ppuStack_4c = (uint **)((uint ****)pppuStack_18)[2];
      ppuStack_48 = (uint **)((uint ****)pppuStack_18)[3];
      pppuStack_40 = (undefined4 ***)&DAT_0000000f;
      pppuStack_20 = (undefined4 ***)&DAT_0000000f;
      pppuStack_54 = (uint ***)ppppuVar7;
      pppuStack_18 = (uint ***)&pppuStack_54;
    }
    else {
      ppppuVar9 = (undefined4 ****)((uint)ppuStack_1c | 0xf);
      if ((undefined4 ****)0x7fffffff < ppppuVar9) {
        ppppuVar9 = (undefined4 ****)0x7fffffff;
      }
      ppppuVar1 = (undefined4 ****)((int)ppppuVar9 + 1);
      pppuStack_28 = ppppuVar9;
      if (ppppuVar1 < &DAT_00001000) {
        if (ppppuVar1 == (undefined4 ****)0x0) {
          ppppuVar7 = (uint ****)0x0;
        }
        else {
          ppppuVar7 = (uint ****)FUN_01674e20(ppppuVar1);
        }
      }
      else {
        ppppuVar4 = ppppuVar9 + 9;
        if (ppppuVar4 <= ppppuVar1) {
          ppppuVar4 = (undefined4 ****)0xffffffff;
        }
        pppuVar5 = (uint ***)FUN_01674e20(ppppuVar4);
        if (pppuVar5 == (uint ***)0x0) goto LAB_006216da;
        ppppuVar7 = (uint ****)((int)pppuVar5 + 0x23U & 0xffffffe0);
        ppppuVar7[-1] = pppuVar5;
      }
      pppuStack_54 = (uint ***)ppppuVar7;
      FUN_0170c6f0(ppppuVar7,pppuStack_18,(int)ppuStack_1c + 1);
      pppuStack_20 = pppuStack_28;
      pppuStack_40 = ppppuVar9;
      pppuStack_18 = (uint ***)&pppuStack_54;
      if (&DAT_0000000f < ppppuVar9) {
        pppuStack_18 = (uint ***)ppppuVar7;
      }
    }
    pppuVar2 = pppuStack_40;
    pppuStack_28 = apppuStack_6c;
    if (0xf < uStack_58) {
      pppuStack_28 = apppuStack_6c[0];
    }
    ppuStack_44 = ppuStack_1c;
    pppuStack_24 = pppuStack_20;
    cVar3 = FUN_0055c360(pppuStack_28,uStack_5c,pppuStack_18,ppuStack_1c);
    if (cVar3 != '\0') {
      if (&DAT_0000000f < pppuStack_24) {
        ppppuVar9 = (undefined4 ****)((int)pppuVar2 + 1);
        ppppuVar8 = ppppuVar7;
        if ((undefined4 ****)0xfff < ppppuVar9) {
          ppppuVar8 = (uint ****)ppppuVar7[-1];
          ppppuVar9 = (undefined4 ****)(pppuVar2 + 9);
          if (0x1f < (uint)((int)ppppuVar7 + (-4 - (int)ppppuVar8))) goto LAB_006216da;
        }
        FUN_01674ea0(ppppuVar8,ppppuVar9);
      }
      uStack_11 = 1;
      goto LAB_0062168f;
    }
    if (&DAT_0000000f < pppuStack_20) {
      ppppuVar9 = (undefined4 ****)((int)pppuVar2 + 1);
      ppppuVar8 = ppppuVar7;
      if ((undefined4 ****)0xfff < ppppuVar9) {
        ppppuVar8 = (uint ****)ppppuVar7[-1];
        ppppuVar9 = (undefined4 ****)(pppuVar2 + 9);
        if (0x1f < (uint)((int)ppppuVar7 + (-4 - (int)ppppuVar8))) {
LAB_006216da:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar8,ppppuVar9);
    }
    pppuStack_2c = pppuStack_2c + 6;
    bVar10 = pppuStack_2c == pppuStack_30;
  } while( true );
}



/* FUNCTION 6812 ; VA 0x006216f0 ; FUN_006216f0 */

undefined FUN_006216f0(void)

{
  if ((DAT_01d5b808 != '\0') && (DAT_01d5b7f8 != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 6813 ; VA 0x00621710 ; FUN_00621710 */

undefined FUN_00621710(void)

{
  if (((DAT_01d5b808 == '\0') || (DAT_01d5b7f8 == '\0')) && (DAT_01d5b800 == '\0')) {
    return 0;
  }
  return 1;
}



/* FUNCTION 6814 ; VA 0x00621740 ; FUN_00621740 */

void __fastcall FUN_00621740(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined auStack_20 [20];
  undefined auStack_c [8];
  
  if (*param_1 == 0) {
    puVar2 = (undefined4 *)FUN_00621c50(auStack_c,1);
    FUN_00610cc0(*puVar2,puVar2[1]);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c2a4ec);
  }
  if (*(char *)(param_1 + 1) == '\0') {
    iVar1 = FUN_016dee6d(*param_1);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    *(undefined *)(param_1 + 1) = 1;
    return;
  }
  puVar2 = (undefined4 *)FUN_00621c50(auStack_c,0x24);
  FUN_00610cc0(*puVar2,puVar2[1]);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c2a4ec);
}



/* FUNCTION 6815 ; VA 0x006217d0 ; FUN_006217d0 */

void FUN_006217d0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  int iStack_44;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e5f3;
  pvStack_10 = ExceptionList;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  ExceptionList = &pvStack_10;
  FUN_01675640(apppuStack_40,"Error while processing packet: %s (packet id: %d, packet length: %d)",
               param_3,**(undefined **)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x30));
  uStack_8 = 0;
  FUN_0086edd0(3,"Error while processing packet.",6);
  ppppuVar4 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar4 = (undefined4 ****)apppuStack_40[0];
  }
  FUN_0086edd0(4,ppppuVar4,6);
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8._0_1_ = 1;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_0151f850(&DAT_018bf030,param_2);
  ppppuVar4 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar4 = (undefined4 ****)apppuStack_40[0];
  }
  FUN_0151f850("Message",ppppuVar4);
  FUN_0151fa60("PacketId",**(undefined **)(param_1 + 0x38));
  FUN_0151fa60("Length",*(undefined4 *)(param_1 + 0x30));
  uVar5 = DAT_01d59db8;
  if (*(uint *)(param_1 + 0x30) < DAT_01d59db8) {
    uVar5 = *(uint *)(param_1 + 0x30);
  }
  FUN_00565660(uVar5 * 2 + 1,0);
  uVar6 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (uVar5 != 0) {
    do {
      ppppuVar4 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar4 = (undefined4 ****)apppuStack_28[0];
      }
      FUN_005e4ba0((int)ppppuVar4 + uVar6 * 2,3,&DAT_018cbb24,
                   *(undefined *)(*(int *)(param_1 + 0x38) + uVar6));
      uVar6 = uVar6 + 1;
    } while (uVar6 < uVar5);
  }
  ppppuVar4 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar4 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0151f850("PacketContents",ppppuVar4);
  if (DAT_01ee420a != '\0') {
    ppppuVar4 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar4 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_01677520(DAT_01ee420a,"Bad packet contents: %s",ppppuVar4);
  }
  uVar2 = DAT_01d59dac;
  uStack_4c = 0;
  uStack_48 = 0xf;
  auStack_5c[0] = auStack_5c[0] & 0xffffff00;
  FUN_005542c0("PacketError",0xb);
  uStack_8._0_1_ = 3;
  FUN_01520d20(auStack_5c,uVar2,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < uStack_48) {
    uVar6 = uStack_48 + 1;
    uVar5 = auStack_5c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_5c[0] - 4);
      uVar6 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  if ((*(int *)(iStack_44 + 0x34) != 0) &&
     (iVar1 = *(int *)(*(int *)(iStack_44 + 0x34) + 0xc), iVar3 = FUN_005ee090(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
     (uint)*(ushort *)(iVar3 + 0x1da))) {
    ppppuVar4 = apppuStack_40;
    if (0xf < uStack_2c) {
      ppppuVar4 = (undefined4 ****)apppuStack_40[0];
    }
    FUN_006c4d20(ppppuVar4,uStack_30);
  }
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)apppuStack_28[0][-1];
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar5);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  FUN_0151f7f0();
  if (0xf < uStack_2c) {
    uVar5 = uStack_2c + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)apppuStack_40[0][-1];
      uVar5 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6816 ; VA 0x00621ac0 ; FUN_00621ac0 */

bool __thiscall FUN_00621ac0(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179de58;
  pvStack_10 = ExceptionList;
  if (*param_2 == -1) {
    ExceptionList = &pvStack_10;
    *param_3 = 0;
    piVar2 = (int *)param_3[1];
    param_3[1] = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar6 = piVar2 + 2;
        iVar3 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return true;
  }
  iStack_14 = param_1 + 0x1c;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d(iStack_14);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  uStack_8 = 0;
  iVar3 = param_1 + 5 + (uint)*(byte *)(param_1 + 4);
  uVar4 = FUN_009c91f0(piVar2);
  FUN_00607110(&param_2,uVar4,piVar2,-(uint)(iVar3 != 0) & iVar3 + 1U);
  piVar2 = param_3;
  if (param_2 == (int *)0x0) {
    *param_3 = 0;
    piVar6 = (int *)param_3[1];
    param_3[1] = 0;
  }
  else {
    iVar3 = param_2[5];
    iStack_1c = 0;
    piStack_18 = (int *)0x0;
    if (iVar3 != 0) {
      piVar6 = (int *)(iVar3 + 4);
      iVar3 = *(int *)(iVar3 + 4);
      while (iVar3 != 0) {
        LOCK();
        iVar5 = *piVar6;
        if (iVar3 == iVar5) {
          *piVar6 = iVar3 + 1;
          iVar5 = iVar3;
        }
        UNLOCK();
        if (iVar5 == iVar3) {
          iStack_1c = param_2[4];
          piStack_18 = (int *)param_2[5];
          break;
        }
        iVar3 = *piVar6;
      }
    }
    FUN_005587e0(&iStack_1c);
    piVar6 = piStack_18;
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar3 = piVar6[1] + -1;
    piVar6[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  iVar3 = *piVar2;
  uStack_8 = 1;
  iVar5 = FUN_016deec8(iStack_14);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  ExceptionList = pvStack_10;
  return iVar3 != 0;
}



/* FUNCTION 6817 ; VA 0x00621c50 ; FUN_00621c50 */

void FUN_00621c50(undefined4 *param_1,undefined4 param_2)

{
  code *pcVar1;
  int iVar2;
  undefined *puVar3;
  undefined4 uVar4;
  
  iVar2 = FUN_016de3db(&DAT_01ead02c,FUN_00603d10,&DAT_01ead030);
  if (iVar2 != 0) {
    *param_1 = param_2;
    param_1[1] = &DAT_01ead030;
    return;
  }
  uVar4 = 8;
  puVar3 = &DAT_01d51160;
  FUN_016f4b80(&DAT_01d51160,8);
  iVar2 = FUN_01733dcb();
  pcVar1 = *(code **)(iVar2 + 0xc);
  if (pcVar1 != (code *)0x0) {
    (*(code *)PTR__guard_check_icall_018b37b4)(puVar3,0);
    (*pcVar1)();
    uVar4 = 0xfffffffe;
  }
  FUN_0171d6f3(puVar3,uVar4);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 6818 ; VA 0x00621c90 ; FUN_00621c90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00621c90(void)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01ead26b == '\0') {
    DAT_01ead26b = '\x01';
    DAT_01ead244 = 0;
    uRam01ead248 = 0;
    DAT_01ead24c = (undefined4 *)0x0;
    DAT_01ead250 = 0;
    _DAT_01ead264 = 0;
    DAT_01ead254 = _DAT_018ce340;
    uRam01ead258 = _UNK_018ce344;
    uRam01ead25c = _UNK_018ce348;
    uRam01ead260 = _UNK_018ce34c;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  if (DAT_01ead24c == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)FUN_00621e70();
  }
  else {
    puVar3 = DAT_01ead24c;
    DAT_01ead24c = (undefined4 *)*DAT_01ead24c;
  }
  uStack_8 = 0;
  LOCK();
  uVar1 = DAT_01ead244 + 0x80000000;
  UNLOCK();
  uVar2 = uVar1;
  if (((DAT_01ead244 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead244)) {
    LOCK();
    DAT_01ead244 = uVar1 | 0x40000000;
    UNLOCK();
    uVar2 = DAT_01ead244;
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar4 = FUN_00554e40();
      SetEvent(uVar4);
      uVar2 = DAT_01ead244;
    }
  }
  DAT_01ead244 = uVar2;
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 6819 ; VA 0x00621d50 ; FUN_00621d50 */

undefined4 * __fastcall FUN_00621d50(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  
  uVar5 = param_1[3];
  if (uVar5 < 4) {
    uVar5 = 4;
  }
  if ((uVar5 & 3) != 0) {
    uVar5 = (uVar5 - (uVar5 & 3)) + 4;
  }
  iVar6 = param_1[4] * uVar5 + 8;
  puVar3 = (undefined4 *)FUN_01674f30(iVar6);
  if (puVar3 == (undefined4 *)0x0) {
    if ((uint)param_1[4] < 5) {
      return (undefined4 *)0x0;
    }
    uVar7 = (uint)param_1[4] >> 1;
    param_1[4] = uVar7;
    uVar5 = param_1[3];
    if (uVar5 < 4) {
      uVar5 = 4;
    }
    if ((uVar5 & 3) != 0) {
      uVar5 = (uVar5 - (uVar5 & 3)) + 4;
    }
    iVar6 = uVar7 * uVar5 + 8;
    puVar3 = (undefined4 *)FUN_01674f30(iVar6);
    if (puVar3 == (undefined4 *)0x0) {
      return (undefined4 *)0x0;
    }
  }
  iVar1 = param_1[4];
  if (param_1[6] == 0) {
    uVar7 = iVar1 * 2;
  }
  else {
    if ((uint)param_1[6] <= (iVar1 * uVar5) / (uint)param_1[3]) goto LAB_00621e1e;
    uVar7 = (uint)(param_1[3] * param_1[6]) / uVar5;
    if ((uint)(iVar1 * 2) <= uVar7) {
      uVar7 = iVar1 * 2;
    }
  }
  param_1[4] = uVar7;
LAB_00621e1e:
  puVar4 = (undefined4 *)((((iVar6 - uVar5) - 8) / uVar5) * uVar5 + (int)puVar3);
  *puVar4 = *param_1;
  if (puVar4 != puVar3) {
    for (puVar2 = (undefined4 *)((int)puVar4 - uVar5); puVar2 != puVar3;
        puVar2 = (undefined4 *)((int)puVar2 - uVar5)) {
      *puVar2 = puVar4;
      puVar4 = puVar2;
    }
    *puVar3 = puVar4;
  }
  *param_1 = puVar3;
  *(undefined4 *)((int)puVar3 + iVar6 + -8) = param_1[1];
  *(undefined4 *)((int)puVar3 + iVar6 + -4) = param_1[2];
  puVar4 = (undefined4 *)*param_1;
  param_1[2] = iVar6;
  param_1[1] = puVar3;
  *param_1 = *puVar4;
  return puVar4;
}



/* FUNCTION 6820 ; VA 0x00621e70 ; FUN_00621e70 */

undefined4 * __fastcall FUN_00621e70(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  
  uVar5 = param_1[3];
  if (uVar5 < 4) {
    uVar5 = 4;
  }
  if ((uVar5 & 3) != 0) {
    uVar5 = (uVar5 - (uVar5 & 3)) + 4;
  }
  iVar6 = param_1[4] * uVar5 + 8;
  puVar3 = (undefined4 *)FUN_01674e50(iVar6,&DAT_021133ac);
  if (puVar3 == (undefined4 *)0x0) {
    if ((uint)param_1[4] < 5) {
      return (undefined4 *)0x0;
    }
    uVar7 = (uint)param_1[4] >> 1;
    param_1[4] = uVar7;
    uVar5 = param_1[3];
    if (uVar5 < 4) {
      uVar5 = 4;
    }
    if ((uVar5 & 3) != 0) {
      uVar5 = (uVar5 - (uVar5 & 3)) + 4;
    }
    iVar6 = uVar7 * uVar5 + 8;
    puVar3 = (undefined4 *)FUN_01674e50(iVar6,&DAT_021133ac);
    if (puVar3 == (undefined4 *)0x0) {
      return (undefined4 *)0x0;
    }
  }
  iVar1 = param_1[4];
  if (param_1[6] == 0) {
    uVar7 = iVar1 * 2;
  }
  else {
    if ((uint)param_1[6] <= (iVar1 * uVar5) / (uint)param_1[3]) goto LAB_00621f48;
    uVar7 = (uint)(param_1[3] * param_1[6]) / uVar5;
    if ((uint)(iVar1 * 2) <= uVar7) {
      uVar7 = iVar1 * 2;
    }
  }
  param_1[4] = uVar7;
LAB_00621f48:
  puVar4 = (undefined4 *)((((iVar6 - uVar5) - 8) / uVar5) * uVar5 + (int)puVar3);
  *puVar4 = *param_1;
  if (puVar4 != puVar3) {
    for (puVar2 = (undefined4 *)((int)puVar4 - uVar5); puVar2 != puVar3;
        puVar2 = (undefined4 *)((int)puVar2 - uVar5)) {
      *puVar2 = puVar4;
      puVar4 = puVar2;
    }
    *puVar3 = puVar4;
  }
  *param_1 = puVar3;
  *(undefined4 *)((int)puVar3 + iVar6 + -8) = param_1[1];
  *(undefined4 *)((int)puVar3 + iVar6 + -4) = param_1[2];
  puVar4 = (undefined4 *)*param_1;
  param_1[2] = iVar6;
  param_1[1] = puVar3;
  *param_1 = *puVar4;
  return puVar4;
}



/* FUNCTION 6821 ; VA 0x00621fa0 ; FUN_00621fa0 */

int * FUN_00621fa0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00622051. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00621fde. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d96588);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_6a51a7d3aac91a3324021555b9e33d77>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 6822 ; VA 0x00622070 ; FUN_00622070 */

int * FUN_00622070(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[3];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00622158. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x006220c6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d964e4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf0<void,class_RBX::Network::Replicator>,class_boost::_bi::list1<class_boost::_bi::value<class_std::shared_ptr<class_RBX::Network::Replicator>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 6823 ; VA 0x00622170 ; FUN_00622170 */

void FUN_00622170(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d965c4);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::Network::Replicator,struct_RBX::Network::ConnectionStats_const&>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::Network::Replicator*>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 6824 ; VA 0x006221e0 ; FUN_006221e0 */

void FUN_006221e0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      iVar3 = FUN_01674e20(0x20);
      if (iVar3 != 0) {
        iVar4 = FUN_0060e1d0(iVar4);
        *param_2 = iVar4;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        piVar2 = *(int **)(iVar4 + 0x14);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        piVar2 = *(int **)(iVar4 + 0xc);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[1] + -1;
          piVar2[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        FUN_01674ea0(iVar4,0x20);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1d963dc);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::Network::Replicator,class_std::weak_ptr<class_RBX::DataModel>,double>,class_boost::_bi::list3<class_boost::_bi::value<class_std::shared_ptr<class_RBX::Network::Replicator>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<float>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 6825 ; VA 0x006222f0 ; FUN_006222f0 */

void __thiscall FUN_006222f0(int *param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  
  iVar1 = (**(code **)(*param_1 + 0x158))(*param_2,param_3 + 4);
  if (iVar1 == 0) {
    (**(code **)(*param_1 + 0x15c))(*param_2,param_3 + 4,param_4);
  }
  return;
}



/* FUNCTION 6826 ; VA 0x00622330 ; FUN_00622330 */

void __thiscall
FUN_00622330(int *param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,char param_7,char param_8)

{
  char cVar1;
  undefined4 uVar2;
  undefined **ppuStack_38;
  int *piStack_34;
  undefined ***pppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e608;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = (**(code **)(*param_1 + 0x114))(*(undefined4 *)(param_3 + 4));
  if (cVar1 == '\0') goto LAB_006223d7;
  if (DAT_01d5b840 == '\0') {
LAB_0062237f:
    uVar2 = 0;
  }
  else {
    if (param_7 == '\0') goto LAB_006223d7;
    if (param_8 == '\0') goto LAB_0062237f;
    uVar2 = 1;
  }
  pppuStack_14 = &ppuStack_38;
  ppuStack_38 = std::
                _Func_impl_no_alloc<class_<lambda_f82bc6ee5d89765a5ff306a4a47ee448>,void,class_std::shared_ptr<class_RBX::Instance>_const&,struct_RBX::Network::NetworkSchema::ClassInfo_const&,class_std::shared_ptr<struct_RBX::Network::CachedBitstream>&&,bool>
                ::vftable;
  uStack_8 = 0;
  piStack_34 = param_1;
  FUN_0061f960(param_3 + 4,1,pppuStack_14,param_4,0,param_5,param_6,uVar2);
  uStack_8 = 0xffffffff;
  if (pppuStack_14 != (undefined ***)0x0) {
    (*(code *)(*pppuStack_14)[4])(pppuStack_14 != &ppuStack_38);
    pppuStack_14 = (undefined ***)0x0;
  }
LAB_006223d7:
  if (DAT_01d5bf20 != '\0') {
    (**(code **)(*param_1 + 0x178))(param_3 + 4,param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6827 ; VA 0x00622400 ; FUN_00622400 */

void __thiscall
FUN_00622400(int *param_1,undefined4 *param_2,int param_3,char *param_4,undefined4 param_5,
            undefined4 param_6)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  int *piVar4;
  
  piVar4 = (int *)(param_3 + 4);
  if (param_1[0x685] != 0) {
    FUN_006941e0(*piVar4,*param_2);
  }
  if ((DAT_01d5bf20 != '\0') || (DAT_01d5b9c0 != '\0')) {
    (**(code **)(*param_1 + 0x174))(piVar4,param_2);
  }
  if ((*param_4 != '\0') && (iVar1 = *piVar4, iVar1 != param_1[0x26])) {
    puVar2 = (undefined4 *)param_1[0x7b9];
    if ((puVar2 != (undefined4 *)0x0) &&
       (((undefined4 *)*puVar2 == &DAT_0211a3d8 && (iVar1 == puVar2[1])))) {
      param_1[0x7b9] = 0;
      return;
    }
    cVar3 = (**(code **)(*param_1 + 0x110))(iVar1,&DAT_0211a3d8);
    if (cVar3 != '\0') {
      FUN_00622730(piVar4,*(undefined4 *)(param_4 + 4),param_5,param_6);
    }
  }
  return;
}



/* FUNCTION 6828 ; VA 0x006224b0 ; FUN_006224b0 */

void __thiscall FUN_006224b0(int *param_1,int *param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  char cVar5;
  ushort *puVar6;
  int *piVar7;
  undefined4 uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar4 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e631;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar5 = (**(code **)(*param_1 + 0x118))(*param_2,*(undefined4 *)(param_4 + 4));
  if (cVar5 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  uVar8 = *(undefined4 *)(param_4 + 4);
  if (*param_2 == param_1[0x26]) {
    ExceptionList = pvStack_10;
    return;
  }
  if (*(int *)(param_4 + 0x10) != 0) {
    if (*(int *)(param_4 + 0x14) == 0) {
      cVar5 = FUN_005e0cd0(param_1 + 0x25);
    }
    else {
      if (*(int *)(param_4 + 0x14) != 1) goto LAB_0062253d;
      cVar5 = FUN_00a33d60(param_1 + 0x25);
    }
    if (cVar5 != '\0') {
      ExceptionList = pvStack_10;
      return;
    }
  }
LAB_0062253d:
  cVar5 = (**(code **)(*param_1 + 0xd4))();
  if (((cVar5 != '\0') ||
      (cVar5 = FUN_00619630(*param_2,uVar8,*(undefined4 *)(param_4 + 8)), cVar5 != '\0')) &&
     (puVar6 = (ushort *)FUN_0061d780(uVar8), puVar6 != (ushort *)0x0)) {
    iVar1 = *(int *)(param_1[0x67d] + 0x70);
    if ((uint)*puVar6 < (uint)((*(int *)(param_1[0x67d] + 0x74) - iVar1) / 0x14)) {
      param_2 = (int *)(iVar1 + (uint)*puVar6 * 0x14);
    }
    else {
      param_2 = (int *)0x0;
    }
    puVar2 = (undefined4 *)param_1[0x657];
    piVar3 = (int *)*puVar2;
    piVar7 = (int *)*piVar3;
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)FUN_00621d50();
    }
    else {
      *piVar3 = *piVar7;
    }
    *piVar7 = (int)puVar2;
    uStack_8 = 0;
    if (piVar7 == (int *)0xfffffffc) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_006f71c0(param_1,piVar4,uVar8,param_2,param_4 + 8);
    }
    uStack_8 = 0xffffffff;
    FUN_006b1f50(uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6829 ; VA 0x00622630 ; FUN_00622630 */

void __thiscall
FUN_00622630(int *param_1,undefined4 *param_2,int param_3,int param_4,undefined4 param_5)

{
  uint uVar1;
  uint uVar2;
  char cVar3;
  undefined **ppuVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined2 *puVar8;
  uint uVar9;
  uint uVar10;
  
  if (DAT_01d5a030 != '\0') {
    cVar3 = FUN_016779a0();
    if ((cVar3 == '\0') || (DAT_01eace3d == '\0')) {
      ppuVar4 = &PTR_DAT_01d5a0f8;
      do {
        if (*(undefined **)(param_4 + 4) == *ppuVar4) {
          return;
        }
        ppuVar4 = ppuVar4 + 1;
      } while (ppuVar4 != &PTR_DAT_01d5a110);
    }
    else {
      ppuVar4 = &PTR_DAT_01d5a0e0;
      do {
        if (*(undefined **)(param_4 + 4) == *ppuVar4) {
          return;
        }
        ppuVar4 = ppuVar4 + 1;
      } while (ppuVar4 != &PTR_DAT_01d5a0f8);
    }
  }
  iVar5 = (**(code **)(*param_1 + 0x150))(*param_2,*(undefined4 *)(param_4 + 4));
  if (iVar5 == 0) {
    uVar1 = *(uint *)(param_4 + 4);
    iVar5 = *(int *)(param_3 + 0xc);
    if (iVar5 == *(int *)(param_3 + 0x10)) {
      iVar7 = 0;
    }
    else if (uVar1 == *(uint *)(param_3 + 0x1c)) {
      iVar7 = 0;
    }
    else {
      uVar6 = (uVar1 >> 3) + uVar1;
      uVar10 = (*(int *)(param_3 + 0x10) - iVar5 >> 3) - 1;
      uVar9 = 0;
      do {
        uVar6 = uVar6 & uVar10;
        uVar2 = *(uint *)(iVar5 + uVar6 * 8);
        iVar7 = iVar5 + uVar6 * 8;
        if (uVar2 == uVar1) goto LAB_00622704;
        if (uVar2 == *(uint *)(param_3 + 0x1c)) break;
        uVar6 = uVar6 + 1 + uVar9;
        uVar9 = uVar9 + 1;
      } while (uVar9 <= uVar10);
      iVar7 = 0;
    }
LAB_00622704:
    puVar8 = (undefined2 *)(-(uint)(iVar7 != 0) & iVar7 + 4U);
    if (puVar8 != (undefined2 *)0x0) {
      (**(code **)(*param_1 + 0x154))(*param_2,uVar1,*puVar8,param_5);
    }
  }
  return;
}



/* FUNCTION 6830 ; VA 0x00622730 ; FUN_00622730 */

void __thiscall FUN_00622730(int param_1,int *param_2,undefined4 *param_3,int *param_4,int *param_5)

{
  void **ppvVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  bool bVar6;
  undefined auStack_24 [8];
  int iStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar5 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e694;
  pvStack_10 = ExceptionList;
  bVar6 = false;
  uStack_14 = 0;
  ppvVar1 = &pvStack_10;
  if (param_3 != (undefined4 *)0x0) {
    if (param_3 == (undefined4 *)0x1) {
      ExceptionList = &pvStack_10;
      if (DAT_01ee420d != '\0') {
        ExceptionList = &pvStack_10;
        FUN_016774b0(DAT_01ee420d,"Parent changed to NULL on instance %p",*param_2);
      }
      if ((((*piVar5 != 0) && (*(char *)(param_1 + 0x1db8) == '\0')) &&
          (cVar2 = FUN_006d7910(param_1,piVar5), cVar2 != '\0')) &&
         (*piVar5 == *(int *)(param_1 + 0x1a18))) {
        FUN_0061bd60();
      }
      if (DAT_01d5b810 != '\0') {
        FUN_00628420(*piVar5);
        piVar5 = param_4;
        if (DAT_01eaf007 != '\0') {
          FUN_01677520(DAT_01eaf007,"adding peer(%d) for delete instance",
                       *(undefined4 *)(param_1 + 0x3840));
          piVar5 = param_4;
        }
        goto LAB_006227a8;
      }
      param_2 = *(int **)(param_1 + 0x1950);
      puVar3 = *(undefined4 **)*param_2;
      param_3 = param_2;
      if (puVar3 == (undefined4 *)0x0) {
        puVar3 = (undefined4 *)FUN_00621d50();
      }
      else {
        *(undefined4 *)*param_2 = *puVar3;
      }
      *puVar3 = param_2;
      param_2 = puVar3 + 1;
      uStack_8 = 3;
      bVar6 = param_2 == (undefined4 *)0x0;
      if (bVar6) {
        uVar4 = 0;
      }
      else {
        FUN_00557fc0(piVar5);
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        uStack_14 = 2;
        uVar4 = FUN_006f6cb0(param_1,auStack_24);
      }
      uStack_8 = 5;
      FUN_006b1f50(uVar4);
      if (bVar6) {
        ExceptionList = pvStack_10;
        return;
      }
      goto LAB_00622998;
    }
    if (param_3 != (undefined4 *)0x2) {
      return;
    }
    ExceptionList = &pvStack_10;
    FUN_006e3d10(param_2);
    ppvVar1 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar1;
  if (DAT_01d5b810 != '\0') {
    piVar5 = param_5;
    if (DAT_01eaf007 != '\0') {
      FUN_01677520(DAT_01eaf007,"adding peer(%d) for ref property Change",
                   *(undefined4 *)(param_1 + 0x3840));
      piVar5 = param_5;
    }
LAB_006227a8:
    param_2 = (int *)param_1;
    if ((uint)((piVar5[1] - *piVar5 >> 2) * 3) >> 2 <= (uint)piVar5[3]) {
      FUN_006286d0();
    }
    FUN_00620c30(&param_2);
    ExceptionList = pvStack_10;
    return;
  }
  param_2 = *(int **)(param_1 + 0x1968);
  puVar3 = *(undefined4 **)*param_2;
  param_3 = param_2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)FUN_00621d50();
  }
  else {
    *(undefined4 *)*param_2 = *puVar3;
  }
  *puVar3 = param_2;
  param_2 = puVar3 + 1;
  if (param_2 == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    iStack_18 = piVar5[1];
    if (iStack_18 != 0) {
      LOCK();
      *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
      UNLOCK();
      iStack_18 = piVar5[1];
    }
    iStack_1c = *piVar5;
    bVar6 = true;
    uStack_8 = 1;
    uStack_14 = 1;
    uVar4 = FUN_006fc760(param_1,&DAT_0211a3d8,
                         *(int *)(*(int *)(param_1 + 0x19f4) + 100) +
                         (uint)*(ushort *)(*(int *)(param_1 + 0x19f4) + 0x7c) * 0x14,&iStack_1c);
  }
  uStack_8 = 2;
  FUN_006b1f50(uVar4);
  if (!bVar6) {
    ExceptionList = pvStack_10;
    return;
  }
LAB_00622998:
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6831 ; VA 0x006229b0 ; FUN_006229b0 */

/* WARNING: Removing unreachable block (ram,0x00623744) */

uint __thiscall FUN_006229b0(int *param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  char cVar4;
  double *pdVar5;
  int *piVar6;
  undefined4 *puVar7;
  uint *puVar8;
  undefined4 uVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  undefined4 uVar13;
  longlong lVar14;
  undefined8 uVar15;
  char *pcStack_110;
  char *pcStack_10c;
  int *piStack_108;
  int *piStack_104;
  undefined8 uStack_100;
  undefined auStack_f0 [12];
  int *piStack_e4;
  undefined auStack_e0 [8];
  undefined4 uStack_d8;
  undefined8 uStack_d4;
  undefined auStack_c4 [4];
  int *piStack_c0;
  undefined auStack_bc [4];
  int *piStack_b8;
  undefined auStack_b4 [4];
  int *piStack_b0;
  double dStack_ac;
  int iStack_a4;
  int *piStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  int iStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int *piStack_58;
  int *piStack_54;
  undefined8 uStack_50;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e754;
  pvStack_10 = ExceptionList;
  piStack_24 = (int *)0x0;
  iVar12 = param_1[0xe3c];
  piStack_20 = param_1;
  if (iVar12 == 0) {
    ExceptionList = &pvStack_10;
    if (param_1[0xe3e] != 0) {
      ExceptionList = &pvStack_10;
      *(undefined *)(param_1 + 0xe2e) = 0;
      uStack_100._4_4_ = (int **)0x622af7;
      FUN_0151f3f0();
      uStack_100._4_4_ = (int **)0x622b02;
      FUN_00586350();
      uStack_100._4_4_ = (int **)0x0;
      uStack_100._0_4_ = (char *)0x622b0f;
      FUN_0058a2f0();
    }
  }
  else {
    piStack_a0 = (int *)param_1[0xe3d];
    ExceptionList = &pvStack_10;
    if (piStack_a0 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piStack_a0[1] = piStack_a0[1] + 1;
      UNLOCK();
      piStack_a0 = (int *)param_1[0xe3d];
      iVar12 = param_1[0xe3c];
    }
    uStack_8 = 0;
    if (piStack_a0 != (int *)0x0) {
      LOCK();
      piStack_a0[1] = piStack_a0[1] + 1;
      UNLOCK();
    }
    iStack_a4 = iVar12;
    piStack_18 = piStack_a0;
    FUN_0151dac0(iVar12,piStack_a0,1,0);
    uStack_8 = 0xffffffff;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar12 = piStack_18[1] + -1;
      piStack_18[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x622a76;
        (**(code **)*piStack_18)();
        LOCK();
        iVar12 = piStack_18[2] + -1;
        piStack_18[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x622a87;
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    param_1[0xe3c] = 0;
    piStack_18 = (int *)param_1[0xe3d];
    uStack_88 = 0;
    uStack_90 = 0;
    param_1[0xe3d] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar12 = piStack_18[1] + -1;
      piStack_18[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x622ac9;
        (**(code **)*piStack_18)();
        LOCK();
        iVar12 = piStack_18[2] + -1;
        piStack_18[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x622ada;
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  uStack_100._4_4_ = (int **)&dStack_ac;
  uStack_100._0_4_ = (char *)0x622b1b;
  FUN_016827e0();
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead110) {
    uStack_100._4_4_ = (int **)&DAT_01ead110;
    uStack_100._0_4_ = (char *)0x623923;
    FUN_016f3809();
    if (DAT_01ead110 == -1) {
      uStack_100._4_4_ = (int **)0xffffffff;
      uStack_100._0_4_ = "Disconnect Cleanup";
      piStack_104 = (int *)&DAT_018c5904;
      uStack_8 = 1;
      piStack_108 = (int *)0x62394b;
      uVar15 = FUN_0152dab0();
      DAT_01ead10c = (int *)((ulonglong)uVar15 >> 0x20);
      DAT_01ead108 = (int *)uVar15;
      piStack_108 = &DAT_01ead110;
      uStack_8 = 0xffffffff;
      pcStack_10c = (char *)0x623967;
      FUN_016f37bf();
    }
  }
  uStack_100._4_4_ = (int **)DAT_01ead10c;
  uStack_100._0_4_ = (char *)DAT_01ead108;
  piStack_14 = DAT_01ead108;
  piStack_58 = DAT_01ead108;
  piStack_18 = DAT_01ead10c;
  piStack_54 = DAT_01ead10c;
  piStack_104 = (int *)0x622b5c;
  uStack_50 = FUN_0152d930();
  uStack_8 = 2;
  if ((param_2 != (int *)0x0) && (param_3 == 0)) {
    if (*(char *)(param_1 + 0x76e) == '\0') {
      uStack_100._0_4_ = (char *)0x622b91;
      uStack_100._4_4_ = (int **)param_1;
      FUN_006d74f0();
    }
    *(undefined *)(param_1 + 0x76e) = 1;
    if (DAT_01ee420a != 0) {
      uStack_100._4_4_ = (int **)auStack_e0;
      uStack_100._0_4_ = (char *)0x622bad;
      pdVar5 = (double *)FUN_016827e0();
      uStack_100._4_4_ = (int **)0x0;
      pcStack_110 = (char *)(uint)DAT_01ee420a;
      uStack_100._0_4_ = (char *)0x0;
      piStack_104 = (int *)0x0;
      piStack_108 = (int *)(float)((*pdVar5 - dStack_ac) * DAT_018c0d70);
      pcStack_10c = "Time to disconnect replication data: %f";
      FUN_016774d0();
    }
  }
  uStack_100._4_4_ = (int **)0x622c00;
  FUN_0061bd60();
  uStack_8 = 3;
  piStack_104 = piStack_18;
  piStack_108 = piStack_14;
  pcStack_10c = (char *)0x622c18;
  uStack_100 = uStack_50;
  FUN_0152dda0();
  uStack_8 = 0xffffffff;
  if (param_1[0x641] != 0) {
    param_1[0x641] = 0;
    piStack_14 = (int *)param_1[0x642];
    uStack_94 = 0;
    uStack_98 = 0;
    param_1[0x642] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar12 = piStack_14[1] + -1;
      piStack_14[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x622c6d;
        (**(code **)*piStack_14)();
        LOCK();
        iVar12 = piStack_14[2] + -1;
        piStack_14[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x622c7e;
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  uStack_100._4_4_ = (int **)0x622c89;
  FUN_006b1dd0();
  uStack_100._4_4_ = (int **)0x622c94;
  FUN_006b1dd0();
  if (param_3 == 0) {
    uStack_100._4_4_ = (int **)0x622caa;
    cVar4 = (**(code **)(*param_1 + 0x11c))();
    if (cVar4 == '\0') {
      param_1[0xe12] = 0;
      piStack_14 = (int *)param_1[0xe13];
      uStack_9c = 0;
      uStack_d8 = 0;
      param_1[0xe13] = 0;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_14[1] + -1;
        piStack_14[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x622cf4;
          (**(code **)*piStack_14)();
          LOCK();
          iVar12 = piStack_14[2] + -1;
          piStack_14[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            uStack_100._4_4_ = (int **)0x622d05;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      param_1[0xe16] = 0;
      piStack_14 = (int *)param_1[0xe17];
      uStack_5c = 0;
      uStack_60 = 0;
      param_1[0xe17] = 0;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_14[1] + -1;
        piStack_14[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x622d41;
          (**(code **)*piStack_14)();
          LOCK();
          iVar12 = piStack_14[2] + -1;
          piStack_14[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            uStack_100._4_4_ = (int **)0x622d52;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      param_1[0xe14] = 0;
      piStack_14 = (int *)param_1[0xe15];
      uStack_64 = 0;
      uStack_68 = 0;
      param_1[0xe15] = 0;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_14[1] + -1;
        piStack_14[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x622d8e;
          (**(code **)*piStack_14)();
          LOCK();
          iVar12 = piStack_14[2] + -1;
          piStack_14[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            uStack_100._4_4_ = (int **)0x622d9f;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
    }
  }
  if (param_1[0x774] != 0) {
    LOCK();
    piVar6 = (int *)(param_1[0x774] + 4);
    *piVar6 = *piVar6 + 1;
    UNLOCK();
  }
  uStack_100._0_4_ = (char *)param_1[0x773];
  uStack_100._4_4_ = (int **)param_1[0x774];
  piStack_104 = (int *)0x622dd5;
  FUN_00628870();
  param_1[0x773] = 0;
  piStack_14 = (int *)param_1[0x774];
  uStack_6c = 0;
  uStack_70 = 0;
  param_1[0x774] = 0;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar12 = piStack_14[1] + -1;
    piStack_14[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      uStack_100._4_4_ = (int **)0x622e14;
      (**(code **)*piStack_14)();
      LOCK();
      iVar12 = piStack_14[2] + -1;
      piStack_14[2] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x622e25;
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_1[0x778] != 0) {
    LOCK();
    piVar6 = (int *)(param_1[0x778] + 4);
    *piVar6 = *piVar6 + 1;
    UNLOCK();
  }
  uStack_100._0_4_ = (char *)param_1[0x777];
  uStack_100._4_4_ = (int **)param_1[0x778];
  piStack_104 = (int *)0x622e5b;
  FUN_00628870();
  param_1[0x777] = 0;
  piStack_14 = (int *)param_1[0x778];
  uStack_74 = 0;
  uStack_78 = 0;
  param_1[0x778] = 0;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar12 = piStack_14[1] + -1;
    piStack_14[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      uStack_100._4_4_ = (int **)0x622e9a;
      (**(code **)*piStack_14)();
      LOCK();
      iVar12 = piStack_14[2] + -1;
      piStack_14[2] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x622eab;
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_1[0x776] != 0) {
    LOCK();
    piVar6 = (int *)(param_1[0x776] + 4);
    *piVar6 = *piVar6 + 1;
    UNLOCK();
  }
  uStack_100._0_4_ = (char *)param_1[0x775];
  uStack_100._4_4_ = (int **)param_1[0x776];
  piStack_104 = (int *)0x622ee1;
  FUN_00628870();
  param_1[0x775] = 0;
  piStack_14 = (int *)param_1[0x776];
  uStack_7c = 0;
  uStack_80 = 0;
  param_1[0x776] = 0;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar12 = piStack_14[1] + -1;
    piStack_14[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      uStack_100._4_4_ = (int **)0x622f20;
      (**(code **)*piStack_14)();
      LOCK();
      iVar12 = piStack_14[2] + -1;
      piStack_14[2] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x622f31;
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  uStack_100._4_4_ = (int **)param_3;
  uStack_100._0_4_ = (char *)param_2;
  piStack_104 = (int *)0x622f3e;
  FUN_006b9220();
  if (param_3 == 0) {
    uStack_100._4_4_ = (int **)0x0;
  }
  else {
    uStack_100._4_4_ = (int **)&LAB_005cf1b0;
    uStack_100._0_4_ = &DAT_01ea8dec;
    piStack_104 = (int *)0x622f57;
    FUN_005789c0();
    uStack_100._4_4_ = (int **)0x622f5f;
    uStack_100._4_4_ = (int **)FUN_005cf480();
    uStack_100._0_4_ = (char *)0x622f68;
    piStack_18 = (int *)FUN_008aa140();
    if (*piStack_18 == 0) {
      uStack_100._4_4_ = (int **)0x622f79;
      uStack_100._4_4_ = (int **)FUN_009fb760();
      uStack_100._0_4_ = auStack_b4;
      piStack_104 = (int *)0x622f89;
      piVar6 = (int *)FUN_008a9ba0();
      iStack_84 = *piVar6;
      iStack_28 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      *piStack_18 = iStack_84;
      piStack_14 = (int *)piStack_18[1];
      piStack_18[1] = iStack_28;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_14[1] + -1;
        piStack_14[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x622fc0;
          (**(code **)*piStack_14)();
          LOCK();
          iVar12 = piStack_14[2] + -1;
          piStack_14[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            uStack_100._4_4_ = (int **)0x622fd1;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      piStack_14 = piStack_b0;
      if (piStack_b0 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_b0[1] + -1;
        piStack_b0[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x622fee;
          (**(code **)*piStack_b0)();
          LOCK();
          iVar12 = piStack_14[2] + -1;
          piStack_14[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            uStack_100._4_4_ = (int **)0x622fff;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
    }
    uStack_100._4_4_ = (int **)*piStack_18;
  }
  uStack_100._0_4_ = (char *)0x623010;
  FUN_00631f90();
  if (param_2 != (int *)0x0) {
    uStack_100._4_4_ = (int **)0x0;
    uStack_100._0_4_ = (char *)0x623021;
    FUN_0090afd0();
  }
  if (param_3 == 0) {
    uStack_100._4_4_ = (int **)0x623770;
    uVar10 = FUN_01679490();
    if (param_1[0x1b] != 0) {
      uVar9 = 0;
      uVar13 = 0;
      puVar8 = (uint *)(param_1 + 0x7c9);
      uStack_d4 = 0;
      while( true ) {
        do {
          piVar6 = param_1 + 0x7c4;
          LOCK();
          uVar10 = *puVar8;
          *puVar8 = *puVar8 | 1;
          UNLOCK();
        } while ((uVar10 & 1) != 0);
        if (param_1[0x7c8] == 0) break;
        if ((piVar6 == (int *)0x0) || ((int *)*piVar6 == (int *)0x0)) {
          iVar12 = 0;
        }
        else {
          iVar12 = *(int *)*piVar6;
        }
        uStack_100._4_4_ =
             (int **)**(undefined4 **)
                       (*(int *)(iVar12 + 4) + (*(int *)(iVar12 + 8) - 1U & param_1[0x7c7]) * 4);
        piVar1 = param_1 + 0x7c8;
        *piVar1 = *piVar1 + -1;
        if (*piVar1 == 0) {
          param_1[0x7c7] = 0;
          param_3 = 0;
        }
        else {
          param_1[0x7c7] = param_1[0x7c7] + 1;
          param_3 = param_1[0x7c7];
        }
        if (param_1[0x7c8] != 0) {
          puVar7 = (undefined4 *)*piVar6;
          if (puVar7 != (undefined4 *)0x0) {
            puVar7 = (undefined4 *)*puVar7;
          }
          uVar15 = *(undefined8 *)(*(int *)(puVar7[1] + (puVar7[2] - 1 & param_3) * 4) + 8);
          uVar9 = (undefined4)uVar15;
          uVar13 = (undefined4)((ulonglong)uVar15 >> 0x20);
        }
        *(ulonglong *)(param_1 + 0x7ca) = CONCAT44(uVar13,uVar9);
        *puVar8 = 0;
        uStack_100._0_4_ = (char *)0x623821;
        piStack_14 = (int *)uStack_100._4_4_;
        (**(code **)(**(int **)param_1[0x1b] + 0x60))();
        uVar9 = (undefined4)uStack_d4;
        uVar13 = (undefined4)((ulonglong)uStack_d4 >> 0x20);
      }
      *puVar8 = 0;
      param_1[0x7ce] = 0;
      iStack_44 = param_1[0x1c];
      if (iStack_44 != 0) {
        LOCK();
        *(int *)(iStack_44 + 4) = *(int *)(iStack_44 + 4) + 1;
        UNLOCK();
        iStack_44 = param_1[0x1c];
      }
      param_3 = param_1[0x1b];
      param_1[0x1b] = 0;
      param_2 = (int *)param_1[0x1c];
      uStack_8 = 0x10;
      param_1[0x1c] = 0;
      iStack_48 = param_3;
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar12 = param_2[1] + -1;
        param_2[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x62388d;
          (**(code **)*param_2)();
          LOCK();
          piVar6 = param_2 + 2;
          iVar12 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar12 == 1) {
            uStack_100._4_4_ = (int **)0x62389d;
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      pcStack_110 = (char *)param_1[0x1f];
      pcStack_10c = (char *)param_1[0x20];
      piStack_108 = (int *)param_1[0x21];
      piStack_104 = (int *)param_1[0x22];
      uStack_100._0_4_ = (char *)param_1[0x23];
      uStack_100._4_4_ = (int **)param_1[0x24];
      FUN_006b0840(param_1[0x1d],param_1[0x1e]);
      uStack_100._4_4_ = (int **)0x6238c4;
      piVar6 = (int *)FUN_0054db20();
      uStack_100._4_4_ = (int **)0x3;
      uStack_100._0_4_ = (char *)0x0;
      piStack_104 = (int *)0x1;
      pcVar3 = *(code **)(*piVar6 + 0x68);
      FUN_0060ed10(piStack_20 + 0x1d);
      (*pcVar3)();
      piVar6 = (int *)FUN_0054db20();
      (**(code **)(*piVar6 + 0x100))(piStack_20 + 0x17);
      uVar10 = FUN_00550b30();
    }
  }
  else {
    uStack_100._4_4_ = (int **)0x148;
    uStack_100._0_4_ = (char *)0x623035;
    param_2 = (int *)FUN_01674e20();
    uStack_8 = 4;
    if (param_2 == (undefined4 *)0x0) {
      uStack_100._0_4_ = (char *)0x0;
    }
    else {
      uStack_100._4_4_ = (int **)0x8;
      pcStack_10c = (char *)0x623057;
      piStack_108 = param_1;
      pcStack_10c = (char *)FUN_008f7870();
      pcStack_110 = (char *)&piStack_104;
      FUN_005c4330();
      puVar7 = param_2;
      piStack_108 = (int *)0x1;
      pcStack_10c = (char *)0x4;
      pcStack_110 = "Replicator SendData";
      FUN_00a360a0();
      uStack_100._0_4_ = (char *)(puVar7 + 0x4a);
      uStack_8._0_1_ = 5;
      *puVar7 = RBX::Network::ReplicatorJob::vftable;
      piStack_104 = (int *)0x62308b;
      uStack_100._4_4_ = (int **)param_1;
      FUN_0060dcd0();
      *puVar7 = RBX::Network::Replicator::SendDataJob::vftable;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      *(undefined8 *)(puVar7 + 0x4c) = 0;
      puVar7[0x4e] = puVar7 + 0x107c004e;
      puVar7[0x4f] = 2;
      puVar7[0x50] = 0;
      uStack_100._4_4_ = (int **)0x6230ca;
      FUN_00a361f0();
      uStack_100._0_4_ = (char *)param_2;
    }
    uStack_100._4_4_ = (int **)param_3;
    uStack_8 = 0xffffffff;
    iStack_30 = 0;
    iStack_2c = 0;
    piStack_104 = (int *)0x6230f5;
    FUN_00604cf0();
    param_1[0x773] = iStack_30;
    param_2 = (int *)param_1[0x774];
    param_1[0x774] = iStack_2c;
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar12 = param_2[1] + -1;
      param_2[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x623121;
        (**(code **)*param_2)();
        LOCK();
        iVar12 = param_2[2] + -1;
        param_2[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x623132;
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    uStack_100._4_4_ = (int **)0x158;
    uStack_100._0_4_ = (char *)0x62313c;
    param_2 = (int *)FUN_01674e20();
    uStack_8 = 7;
    if (param_2 == (int *)0x0) {
      uStack_100._0_4_ = (char *)0x0;
    }
    else {
      uStack_100._0_4_ = (char *)0x623155;
      uStack_100._4_4_ = (int **)param_1;
      uStack_100._0_4_ = (char *)FUN_006fbf50();
    }
    uStack_100._4_4_ = (int **)param_3;
    uStack_8 = 0xffffffff;
    iStack_38 = 0;
    iStack_34 = 0;
    piStack_104 = (int *)0x62317a;
    FUN_00604c00();
    param_1[0x777] = iStack_38;
    param_2 = (int *)param_1[0x778];
    param_1[0x778] = iStack_34;
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar12 = param_2[1] + -1;
      param_2[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x6231a6;
        (**(code **)*param_2)();
        LOCK();
        iVar12 = param_2[2] + -1;
        param_2[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x6231b7;
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    if (param_1[0x778] != 0) {
      LOCK();
      piVar6 = (int *)(param_1[0x778] + 4);
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    uStack_100._0_4_ = (char *)param_1[0x777];
    uStack_100._4_4_ = (int **)param_1[0x778];
    piStack_104 = (int *)0x6231ed;
    FUN_0151d950();
    piStack_104 = (int *)0x130;
    piStack_108 = (int *)0x6231f7;
    param_2 = (int *)FUN_01674e20();
    uStack_8 = 8;
    if (param_2 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      uStack_100._4_4_ = (int **)0x4;
      pcStack_10c = (char *)0x623215;
      piStack_108 = param_1;
      pcStack_10c = (char *)FUN_008f7870();
      pcStack_110 = (char *)&piStack_104;
      FUN_005c4330();
      puVar7 = param_2;
      piStack_108 = (int *)0x1;
      pcStack_10c = (char *)0x7;
      pcStack_110 = "Replicator DataPing";
      FUN_00a360a0();
      uStack_100._0_4_ = (char *)(puVar7 + 0x4a);
      uStack_8._0_1_ = 9;
      *puVar7 = RBX::Network::ReplicatorJob::vftable;
      piStack_104 = (int *)0x623249;
      uStack_100._4_4_ = (int **)param_1;
      FUN_0060dcd0();
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      *puVar7 = RBX::Network::Replicator::PingJob::vftable;
      uStack_100._4_4_ = (int **)0x62325d;
      FUN_00a361f0();
    }
    uStack_100._4_4_ = (int **)param_3;
    uStack_8 = 0xffffffff;
    iStack_40 = 0;
    iStack_3c = 0;
    piStack_104 = (int *)0x623282;
    uStack_100._0_4_ = (char *)puVar7;
    FUN_00604b10();
    param_1[0x775] = iStack_40;
    param_2 = (int *)param_1[0x776];
    param_1[0x776] = iStack_3c;
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar12 = param_2[1] + -1;
      param_2[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x6232b1;
        (**(code **)*param_2)();
        LOCK();
        iVar12 = param_2[2] + -1;
        param_2[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x6232c2;
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    if (param_1[0x776] != 0) {
      LOCK();
      piVar6 = (int *)(param_1[0x776] + 4);
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    uStack_100._0_4_ = (char *)param_1[0x775];
    uStack_100._4_4_ = (int **)param_1[0x776];
    piStack_104 = (int *)0x6232f8;
    FUN_0151d950();
    piStack_104 = (int *)&LAB_00605b50;
    piStack_108 = (int *)&DAT_01ead2dc;
    pcStack_10c = (char *)0x623307;
    FUN_005789c0();
    uStack_100._4_4_ = (int **)0x62330f;
    uStack_100._4_4_ = (int **)FUN_00605fa0();
    uStack_100._0_4_ = (char *)0x623318;
    param_2 = (int *)FUN_008aa140();
    if (*param_2 == 0) {
      uStack_100._4_4_ = (int **)0x623329;
      uStack_100._4_4_ = (int **)FUN_007060a0();
      uStack_100._0_4_ = auStack_bc;
      piStack_104 = (int *)0x623339;
      piVar6 = (int *)FUN_008a9ba0();
      iVar12 = *piVar6;
      iVar2 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      *param_2 = iVar12;
      piStack_14 = (int *)param_2[1];
      param_2[1] = iVar2;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_14[1] + -1;
        piStack_14[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x62336a;
          (**(code **)*piStack_14)();
          LOCK();
          iVar12 = piStack_14[2] + -1;
          piStack_14[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            uStack_100._4_4_ = (int **)0x62337b;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      piStack_14 = piStack_b8;
      if (piStack_b8 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_b8[1] + -1;
        piStack_b8[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x623398;
          (**(code **)*piStack_b8)();
          LOCK();
          iVar12 = piStack_14[2] + -1;
          piStack_14[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            uStack_100._4_4_ = (int **)0x6233a9;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
    }
    uStack_100._4_4_ = (int **)*param_2;
    uStack_100._0_4_ = auStack_c4;
    piStack_104 = (int *)0x6233ba;
    piVar6 = (int *)FUN_0060dcd0();
    iVar12 = *piVar6;
    iVar2 = piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    param_1[0x641] = iVar12;
    param_2 = (int *)param_1[0x642];
    param_1[0x642] = iVar2;
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar12 = param_2[1] + -1;
      param_2[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x6233f5;
        (**(code **)*param_2)();
        LOCK();
        iVar12 = param_2[2] + -1;
        param_2[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x623406;
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    param_2 = piStack_c0;
    if (piStack_c0 != (int *)0x0) {
      LOCK();
      iVar12 = piStack_c0[1] + -1;
      piStack_c0[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        uStack_100._4_4_ = (int **)0x623420;
        (**(code **)*piStack_c0)();
        LOCK();
        iVar12 = param_2[2] + -1;
        param_2[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x623431;
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    uStack_100._4_4_ = (int **)0x623439;
    puVar7 = (undefined4 *)FUN_00564080();
    piVar6 = (int *)*puVar7;
    if ((int *)*puVar7 == (int *)0x0) {
      uStack_100._4_4_ = &piStack_1c;
      uStack_100._0_4_ = (char *)0x62344c;
      FUN_0055e4a0();
      uStack_100._4_4_ = (int **)param_3;
      uStack_8 = 0xb;
      uStack_100._0_4_ = (char *)0x623461;
      FUN_008a5700();
      uStack_100._4_4_ = (int **)&LAB_0055d570;
      uStack_100._0_4_ = &DAT_01ea8a70;
      piStack_104 = (int *)0x623470;
      FUN_005789c0();
      uStack_100._4_4_ = (int **)0x623478;
      uStack_100._4_4_ = (int **)FUN_00560c40();
      uStack_100._0_4_ = (char *)0x623481;
      param_2 = (int *)FUN_008aa140();
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *param_2 = (int)piStack_1c;
      piStack_14 = (int *)param_2[1];
      param_2[1] = (int)piStack_18;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_14[1] + -1;
        piStack_14[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x6234b6;
          (**(code **)*piStack_14)();
          LOCK();
          iVar12 = piStack_14[2] + -1;
          piStack_14[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            uStack_100._4_4_ = (int **)0x6234c7;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      param_2 = piStack_1c;
      uStack_8 = 0xffffffff;
      piStack_14 = piStack_18;
      piVar6 = piStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_18[1] + -1;
        piStack_18[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          uStack_100._4_4_ = (int **)0x6234eb;
          (**(code **)*piStack_18)();
          LOCK();
          iVar12 = piStack_14[2] + -1;
          piStack_14[2] = iVar12;
          UNLOCK();
          piVar6 = param_2;
          if (iVar12 == 0) {
            uStack_100._4_4_ = (int **)0x6234fc;
            (**(code **)(*piStack_14 + 4))();
            piVar6 = param_2;
          }
        }
      }
    }
    param_1[0x770] = (int)piVar6;
    uStack_100._4_4_ = (int **)(param_1 + 0x19);
    uStack_100._0_4_ = (char *)0x623514;
    FUN_0090afd0();
    uStack_100._4_4_ = (int **)0x62351b;
    puVar8 = (uint *)FUN_00564080();
    uVar10 = *puVar8;
    if (uVar10 != 0) {
      piStack_20 = (int *)(uVar10 + 700);
      uStack_100._4_4_ = (int **)(uint)DAT_01ead01d;
      uStack_100._0_4_ = (char *)(uint)DAT_01ead01e;
      piStack_104 = (int *)(uint)DAT_01ead01f;
      piStack_108 = (int *)(uint)DAT_01ead01c;
      FUN_0060dcd0(&pcStack_110,param_1);
      piStack_14 = (int *)FUN_00605630(auStack_f0,FUN_0062dd20,0);
      uStack_8 = 0xd;
      uVar9 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 0xe;
      uStack_8c = uVar9;
      piStack_18 = (int *)FUN_01674e20(0x28);
      if (piStack_18 == (int *)0x0) {
        piStack_18 = (int *)0x0;
      }
      else {
        *piStack_18 = 0;
        piStack_18[1] = 1;
        piStack_18[2] = (int)FUN_0061c3f0;
        piStack_18[3] = (int)FUN_0057e0b0;
        piStack_18[4] = 0;
        piStack_18[5] = (int)piStack_20;
        piStack_18[6] = *piStack_14;
        piStack_18[7] = piStack_14[1];
        piStack_18[8] = 0;
        piStack_18[9] = 0;
        if (piStack_14[3] != 0) {
          LOCK();
          piVar6 = (int *)(piStack_14[3] + 4);
          *piVar6 = *piVar6 + 1;
          UNLOCK();
        }
        piStack_18[8] = piStack_14[2];
        piStack_18[9] = piStack_14[3];
      }
      uStack_100._0_4_ = (char *)0x62360e;
      uStack_100._4_4_ = (int **)piStack_18;
      FUN_016797d0();
      param_2 = piStack_18;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      piStack_24 = (int *)0x1;
      uStack_8._0_1_ = 0xf;
      uStack_100._0_4_ = (char *)0x623635;
      uStack_100._4_4_ = (int **)uVar9;
      FUN_01675290();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      uStack_100._4_4_ = &param_2;
      uStack_100._0_4_ = (char *)0x62364b;
      uVar10 = FUN_01679300();
      if ((char)uVar10 != '\0') {
        uStack_100._4_4_ = (int **)0x62365a;
        FUN_01679490();
        uStack_100._4_4_ = &param_2;
        uStack_100._0_4_ = (char *)0x623669;
        uVar10 = FUN_016791c0();
      }
      if (param_2 != (int *)0x0) {
        piVar6 = param_2 + 1;
        LOCK();
        iVar12 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        uVar10 = iVar12 - 1;
        if (uVar10 == 0) {
          uStack_100._4_4_ = (int **)param_2;
          uStack_100._0_4_ = (char *)0x623689;
          uVar10 = FUN_01674ea0();
        }
      }
      uStack_8 = 0xffffffff;
      piStack_24 = piStack_e4;
      if (piStack_e4 != (int *)0x0) {
        LOCK();
        puVar8 = (uint *)(piStack_e4 + 1);
        uVar11 = *puVar8;
        uVar10 = *puVar8;
        *puVar8 = uVar11 - 1;
        UNLOCK();
        if (uVar11 - 1 == 0) {
          uStack_100._4_4_ = (int **)0x6236ad;
          uVar10 = (**(code **)*piStack_e4)();
          LOCK();
          piVar6 = piStack_24 + 2;
          iVar12 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar12 == 1) {
            uStack_100._4_4_ = (int **)0x6236bd;
            uVar10 = (**(code **)(*piStack_24 + 4))();
          }
        }
      }
    }
    if (0 < (int)DAT_01d59e20) {
      uStack_100._4_4_ = (int **)0x6236d9;
      uVar10 = (**(code **)(*param_1 + 0xd4))();
      if ((char)uVar10 != '\0') {
        uStack_100._4_4_ = (int **)0x6236e8;
        uVar11 = FUN_00562f00();
        uVar10 = uVar11;
        if ((uVar11 != 0) &&
           (uVar10 = (uint)*(byte *)(uVar11 + 0x300), *(byte *)(uVar11 + 0x300) != 0)) {
          uStack_100._4_4_ = (int **)0x62370a;
          uVar10 = (**(code **)(*param_1 + 0x11c))();
          if ((char)uVar10 == '\0') {
            uStack_100._4_4_ = (int **)0x62371d;
            FUN_016799d0();
            uStack_100._4_4_ = (int **)0x0;
            uStack_100._0_4_ = (char *)0x64;
            piStack_104 = (int *)0x0;
            piStack_108 = (int *)0x0;
            pcStack_10c = (char *)0x623730;
            lVar14 = FUN_01679e20();
            uVar10 = DAT_01d59e20;
            if (lVar14 < (int)DAT_01d59e20) {
              *(undefined *)(param_1 + 0xe48) = 1;
              ExceptionList = pvStack_10;
              return uVar10;
            }
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar10;
}



/* FUNCTION 6832 ; VA 0x00623970 ; FUN_00623970 */

void __thiscall FUN_00623970(int param_1,undefined4 *param_2)

{
  float fVar1;
  double dVar2;
  short sVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  double dVar7;
  double dVar8;
  double dVar9;
  double dStack_14;
  double dStack_c;
  
  if (DAT_01eace3a != '\0') {
    FUN_016774b0(DAT_01eace3a,"Updating stats Replicator::onStatisticsChanged",0);
  }
  *(undefined4 *)(param_1 + 0xe28) = *param_2;
  *(undefined4 *)(param_1 + 0xe30) = param_2[2];
  *(undefined4 *)(param_1 + 0xe34) = param_2[3];
  *(undefined4 *)(param_1 + 0xe2c) = param_2[1];
  puVar5 = param_2 + 0x3a;
  puVar6 = (undefined4 *)(param_1 + 0xf10);
  for (iVar4 = 0x58; iVar4 != 0; iVar4 = iVar4 + -1) {
    *puVar6 = *puVar5;
    puVar5 = puVar5 + 1;
    puVar6 = puVar6 + 1;
  }
  *(undefined8 *)(param_1 + 0x620) = *(undefined8 *)(param_2 + 0x34);
  *(undefined8 *)(param_1 + 0x808) = *(undefined8 *)(param_2 + 0x2a);
  dStack_14 = *(double *)(param_2 + 10);
  *(double *)(param_1 + 0x810) = dStack_14;
  fVar1 = (float)param_2[0x70];
  if ((float)param_2[0x70] <= *(float *)(param_1 + 0xe38)) {
    fVar1 = *(float *)(param_1 + 0xe38);
  }
  *(float *)(param_1 + 0xe38) = fVar1;
  dStack_c = dStack_14;
  sVar3 = FUN_017265ed(&dStack_14);
  if (sVar3 < 1) {
    dVar2 = *(double *)(param_1 + 0x39a8);
    dVar8 = DAT_018c0d60 - dVar2;
    dVar7 = dStack_c;
    if (*(char *)(param_1 + 0x39c8) == '\0') {
      dVar7 = *(double *)(param_1 + 0x39b8) * dVar8 + dVar2 * dStack_c;
    }
    *(double *)(param_1 + 0x39b0) = dStack_c;
    *(undefined *)(param_1 + 0x39c8) = 0;
    *(double *)(param_1 + 0x39b8) = dVar7;
    *(double *)(param_1 + 0x39c0) =
         (dStack_c - dVar7) * (dStack_c - dVar7) * dVar2 + *(double *)(param_1 + 0x39c0) * dVar8;
  }
  if (*(char *)(param_1 + 0x3860) != '\0') {
    iVar4 = *(int *)(param_1 + 0xe30);
    if (*(int *)(param_1 + 0x9c8) < iVar4) {
      *(int *)(param_1 + 0x9c8) = iVar4;
    }
    if (iVar4 < *(int *)(param_1 + 0x9cc)) {
      *(int *)(param_1 + 0x9cc) = iVar4;
    }
    dStack_14 = (double)iVar4;
    sVar3 = FUN_017265ed(&dStack_14);
    if (sVar3 < 1) {
      dVar2 = *(double *)(param_1 + 0x9a0);
      dVar9 = DAT_018c0d60 - dVar2;
      dVar8 = (double)iVar4;
      dVar7 = dVar8;
      if (*(char *)(param_1 + 0x9c0) == '\0') {
        dVar7 = *(double *)(param_1 + 0x9b0) * dVar9 + dVar8 * dVar2;
      }
      *(int *)(param_1 + 0x9a8) = iVar4;
      *(double *)(param_1 + 0x9b0) = dVar7;
      *(undefined *)(param_1 + 0x9c0) = 0;
      *(double *)(param_1 + 0x9b8) =
           (dVar8 - dVar7) * (dVar8 - dVar7) * dVar2 + *(double *)(param_1 + 0x9b8) * dVar9;
    }
  }
  return;
}



/* FUNCTION 6833 ; VA 0x00623b90 ; FUN_00623b90 */

void __thiscall FUN_00623b90(int param_1,undefined4 param_2,int param_3)

{
  undefined8 *puVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  byte bVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined auStack_100 [24];
  undefined auStack_e8 [24];
  undefined auStack_d0 [12];
  undefined8 uStack_c4;
  undefined8 uStack_b8;
  int iStack_b0;
  undefined8 uStack_ac;
  int iStack_a4;
  int iStack_a0;
  int iStack_9c;
  undefined auStack_94 [4];
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  undefined8 uStack_84;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  undefined8 uStack_6c;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int *piStack_54;
  undefined uStack_50;
  int iStack_4c;
  int iStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  int iStack_38;
  int iStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined8 *puStack_28;
  undefined8 uStack_24;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if ((param_3 == 0) && (*(char *)(param_1 + 0x1d49) == '\0')) {
    uStack_2c = 4;
    if ((*(uint *)(param_1 + 0x37a0) & 0x2000000) == 0) {
      uStack_2c = *(undefined4 *)(param_1 + 0x1898);
    }
    ExceptionList = &pvStack_10;
    FUN_00a70da0(&uStack_b8,uStack_2c);
    iStack_38 = *(int *)(param_1 + 0x37a4);
    if (((*(uint *)(param_1 + 0x37a0) & 0x2000000) == 0) ||
       ((*(uint *)(param_1 + 0x37a0) & 0x20000000) == 0)) {
      iStack_34 = *(int *)(param_1 + 0x19ec);
    }
    else {
      iStack_34 = *(int *)(param_1 + 0x19bc);
    }
    puStack_28 = &uStack_b8;
    uStack_24 = uStack_b8;
    iStack_18 = 0;
    iStack_1c = iStack_b0;
    uStack_c4 = uStack_ac;
    iStack_4c = iStack_a4;
    while( true ) {
      if ((((int)uStack_24 == (int)uStack_c4) && (uStack_24._4_4_ == uStack_c4._4_4_)) &&
         (iStack_1c == iStack_4c)) break;
      if ((*(char *)(param_1 + 0x3790) == '\0') || (*(int *)(param_1 + 0x1d7c) == 0)) {
LAB_00623cc9:
        iStack_38 = *(int *)(param_1 + 0x37a4);
        iStack_18 = iStack_18 + 1;
        if (((*(uint *)(param_1 + 0x37a0) & 0x2000000) == 0) ||
           ((*(uint *)(param_1 + 0x37a0) & 0x20000000) == 0)) {
          FUN_00606670(auStack_d0,&uStack_24,&uStack_24);
        }
        else {
          piVar3 = (int *)FUN_0061ddc0(auStack_94,&uStack_24);
          iStack_38 = *(int *)(param_1 + 0x19c8);
          iStack_48 = *piVar3;
          if (iStack_48 == iStack_38) {
            iVar6 = *(int *)(param_1 + 0x19bc);
            puVar9 = *(undefined4 **)(param_1 + 0x19b4);
            iStack_7c = iStack_1c;
            uStack_84 = uStack_24;
            if (puVar9 < (undefined4 *)(iVar6 + 1U)) {
              uStack_8 = 0;
              do {
                puVar9 = (undefined4 *)((uint)((int)puVar9 * 3) >> 1);
              } while (puVar9 < (undefined4 *)(iVar6 + 1U));
              puStack_30 = puVar9;
              piStack_14 = (int *)FUN_01674f30((int)puVar9 * 0xc);
              uStack_40 = 0;
              if (*(int *)(param_1 + 0x19bc) != 0) {
                uVar10 = 0;
                piVar3 = piStack_14;
                do {
                  uVar8 = (*(int *)(param_1 + 0x19b8) + uVar10) % *(uint *)(param_1 + 0x19b4);
                  iVar6 = *(int *)(param_1 + 0x19c0);
                  uVar10 = uVar10 + 1;
                  *(undefined8 *)piVar3 = *(undefined8 *)(iVar6 + uVar8 * 0xc);
                  piVar3[2] = *(int *)(iVar6 + 8 + uVar8 * 0xc);
                  piVar3 = piVar3 + 3;
                  puVar9 = puStack_30;
                } while (uVar10 < *(uint *)(param_1 + 0x19bc));
              }
              FUN_01674ea0(*(undefined4 *)(param_1 + 0x19c0));
              iVar6 = *(int *)(param_1 + 0x19bc);
              *(int **)(param_1 + 0x19c0) = piStack_14;
              iVar4 = 0;
              *(undefined4 *)(param_1 + 0x19b8) = 0;
              *(undefined4 **)(param_1 + 0x19b4) = puVar9;
              uStack_8 = 0xffffffff;
            }
            else {
              iVar4 = *(int *)(param_1 + 0x19b8);
            }
            puVar1 = (undefined8 *)
                     (*(int *)(param_1 + 0x19c0) + ((uint)(iVar4 + iVar6) % (uint)puVar9) * 0xc);
            *puVar1 = uStack_84;
            *(int *)(puVar1 + 1) = iStack_7c;
            *(int *)(param_1 + 0x19bc) = *(int *)(param_1 + 0x19bc) + 1;
          }
          FUN_0061ddc0(&piStack_44,&uStack_24);
          if (piStack_44 == *(int **)(param_1 + 0x19c8)) {
            iVar6 = **(int **)(param_1 + 0x19c8);
            piStack_14 = (int *)&uStack_24;
            puStack_30 = *(undefined4 **)(iVar6 + 4);
            uVar5 = FUN_00602ca0(iVar6,puStack_30,&DAT_018bdeda,&piStack_14,(int)&param_3 + 3);
            if (*(int *)(param_1 + 0x19cc) == 0x7fffffe) {
                    /* WARNING: Subroutine does not return */
              FUN_016ddcd9("list<T> too long");
            }
            *(int *)(param_1 + 0x19cc) = *(int *)(param_1 + 0x19cc) + 1;
            *(undefined4 *)(iVar6 + 4) = uVar5;
            *puStack_30 = uVar5;
            FUN_00603d30(&piStack_54,**(int **)(param_1 + 0x19c8) + 8,**(int **)(param_1 + 0x19c8));
          }
          else {
            piStack_54 = piStack_44;
            uStack_50 = 0;
          }
          piStack_14 = piStack_54 + 5;
          if (DAT_01d59f70 == 0) {
            piStack_54[6] = *piStack_14;
          }
          else if ((iStack_48 == iStack_38) ||
                  (iVar6 = piStack_54[6] - *piStack_14 >> 0x1f,
                  (piStack_54[6] - *piStack_14) / 0x18 + iVar6 != iVar6)) {
            bVar7 = (byte)uStack_2c;
            iStack_a0 = (int)uStack_24 << (bVar7 & 0x1f);
            iStack_58 = 1 << (bVar7 & 0x1f);
            iStack_9c = uStack_24._4_4_ << (bVar7 & 0x1f);
            iStack_60 = iStack_a0 + iStack_58;
            iStack_64 = iStack_1c << (bVar7 & 0x1f);
            iStack_5c = iStack_58 + iStack_9c;
            uStack_6c = CONCAT44(iStack_9c,iStack_a0);
            iStack_58 = iStack_58 + iStack_64;
            FUN_00a71450(auStack_100,&uStack_6c);
            iStack_90 = -(int)uStack_6c;
            iStack_8c = -uStack_6c._4_4_;
            iStack_88 = -iStack_64;
            FUN_00a716f0(auStack_e8,&iStack_90);
            FUN_0061ff50(piStack_14,auStack_e8);
          }
        }
      }
      else {
        bVar7 = (byte)uStack_2c;
        iStack_70 = iStack_1c << (bVar7 & 0x1f);
        iStack_74 = uStack_24._4_4_ << (bVar7 & 0x1f);
        iStack_78 = (int)uStack_24 << (bVar7 & 0x1f);
        cVar2 = FUN_006e8640(&iStack_78);
        if (cVar2 != '\0') goto LAB_00623cc9;
      }
      FUN_00a6e100();
    }
    if (DAT_01eace39 != '\0') {
      iStack_38 = *(undefined4 *)(param_1 + 0x37a4);
      if (((*(uint *)(param_1 + 0x37a0) & 0x2000000) == 0) ||
         ((*(uint *)(param_1 + 0x37a0) & 0x20000000) == 0)) {
        iVar6 = *(int *)(param_1 + 0x19ec);
      }
      else {
        iVar6 = *(int *)(param_1 + 0x19bc);
      }
      FUN_01677520(DAT_01eace39,"Added %d regions to cluster buffer, %d of them are new",iStack_18,
                   iVar6 - iStack_34);
    }
    if (((*(uint *)(param_1 + 0x37a0) & 0x2000000) == 0) ||
       ((*(uint *)(param_1 + 0x37a0) & 0x20000000) == 0)) {
      iVar6 = *(int *)(param_1 + 0x19ec);
    }
    else {
      iVar6 = *(int *)(param_1 + 0x19bc);
    }
    *(int *)(param_1 + 0x1d54) = iVar6 << 4;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6834 ; VA 0x00624080 ; FUN_00624080 */

uint __thiscall FUN_00624080(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint *puVar2;
  uint uVar3;
  uint *puVar4;
  uint *puVar5;
  uint uVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  uint *puVar10;
  uint uVar11;
  uint uVar12;
  
  uVar3 = param_1[3];
  uVar12 = uVar3;
  if (uVar3 < 4) {
    uVar12 = 4;
  }
  if ((uVar12 & 3) != 0) {
    uVar12 = (uVar12 - (uVar12 & 3)) + 4;
  }
  uVar3 = (uint)((uVar3 * (int)param_2) % uVar12 != 0) + (uVar3 * (int)param_2) / uVar12;
  puVar2 = param_1;
  if (uVar3 != 0) {
    do {
      puVar10 = puVar2;
      puVar5 = (uint *)*puVar10;
      uVar9 = uVar3;
      if ((uint *)*puVar10 == (uint *)0x0) break;
      do {
        uVar9 = uVar9 - 1;
        if (uVar9 == 0) {
          puVar2 = puVar10;
          if (puVar5 != (uint *)0x0) {
            uVar9 = *puVar10;
            *puVar10 = *puVar5;
            if (uVar9 != 0) {
              return uVar9;
            }
            goto LAB_00624107;
          }
          break;
        }
        puVar4 = (uint *)*puVar5;
        puVar1 = (uint *)((int)puVar5 + uVar12);
        puVar2 = puVar5;
        puVar5 = puVar4;
      } while (puVar4 == puVar1);
    } while( true );
  }
  uVar9 = 0;
LAB_00624107:
  if (param_2 == (uint *)0x0) {
    return uVar9;
  }
  uVar9 = param_1[4];
  if (param_1[4] < uVar3) {
    uVar9 = uVar3;
  }
  param_1[4] = uVar9;
  uVar11 = uVar9 * uVar12 + 8;
  uVar9 = FUN_01674e50(uVar11,&DAT_021133ac);
  if (uVar9 == 0) {
    if (param_1[4] <= uVar3) {
      return 0;
    }
    uVar9 = param_1[4] >> 1;
    if (uVar9 < uVar3) {
      uVar9 = uVar3;
    }
    param_1[4] = uVar9;
    uVar11 = uVar9 * uVar12 + 8;
    uVar9 = FUN_01674e50(uVar11,&DAT_021133ac);
    if (uVar9 == 0) {
      return 0;
    }
  }
  if (uVar3 < param_1[4]) {
    puVar2 = (uint *)(uVar12 * uVar3 + uVar9);
    puVar5 = (uint *)*param_1;
    if ((puVar5 == (uint *)0x0) || (puVar2 < puVar5)) {
      param_2 = (uint *)0x0;
    }
    else {
      param_2 = puVar5;
      for (puVar10 = (uint *)*puVar5; (puVar10 != (uint *)0x0 && (puVar10 <= puVar2));
          puVar10 = (uint *)*puVar10) {
        param_2 = puVar10;
      }
    }
    puVar10 = (uint *)(((((uVar11 - uVar12 * uVar3) + -8) - uVar12) / uVar12) * uVar12 + (int)puVar2
                      );
    if (param_2 == (uint *)0x0) {
      *puVar10 = (uint)puVar5;
      if (puVar10 != puVar2) {
        for (puVar5 = (uint *)((int)puVar10 - uVar12); puVar5 != puVar2;
            puVar5 = (uint *)((int)puVar5 - uVar12)) {
          *puVar5 = (uint)puVar10;
          puVar10 = puVar5;
        }
        *puVar2 = (uint)puVar10;
      }
      *param_1 = (uint)puVar2;
    }
    else {
      *puVar10 = *param_2;
      if (puVar10 != puVar2) {
        for (puVar5 = (uint *)((int)puVar10 - uVar12); puVar5 != puVar2;
            puVar5 = (uint *)((int)puVar5 - uVar12)) {
          *puVar5 = (uint)puVar10;
          puVar10 = puVar5;
        }
        *puVar2 = (uint)puVar10;
      }
      *param_2 = (uint)puVar2;
    }
  }
  uVar3 = param_1[4];
  if (param_1[6] == 0) {
    uVar12 = uVar3 * 2;
  }
  else {
    if (param_1[6] <= (uVar3 * uVar12) / param_1[3]) goto LAB_00624259;
    uVar12 = (param_1[3] * param_1[6]) / uVar12;
    if (uVar3 * 2 <= uVar12) {
      uVar12 = uVar3 * 2;
    }
  }
  param_1[4] = uVar12;
LAB_00624259:
  uVar3 = param_1[1];
  if ((uVar3 == 0) || (uVar9 < uVar3)) {
    *(uint *)((uVar9 - 8) + uVar11) = uVar3;
    *(uint *)((uVar9 - 4) + uVar11) = param_1[2];
    param_1[1] = uVar9;
    param_1[2] = uVar11;
    return uVar9;
  }
  uVar12 = param_1[2];
  iVar8 = *(int *)((uVar3 - 8) + uVar12);
  while (iVar8 != 0) {
    uVar6 = *(uint *)((uVar3 - 8) + uVar12);
    if (uVar9 < uVar6) break;
    uVar12 = *(uint *)(uVar3 + uVar12 + -4);
    uVar3 = uVar6;
    iVar8 = *(int *)((uVar12 - 8) + uVar6);
  }
  uVar7 = *(undefined4 *)((uVar3 - 8) + uVar12);
  *(undefined4 *)((uVar9 - 4) + uVar11) = *(undefined4 *)((uVar3 - 4) + uVar12);
  *(undefined4 *)((uVar9 - 8) + uVar11) = uVar7;
  *(uint *)((uVar3 - 8) + uVar12) = uVar9;
  *(uint *)((uVar3 - 4) + uVar12) = uVar11;
  return uVar9;
}



/* FUNCTION 6835 ; VA 0x006242e0 ; FUN_006242e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_006242e0(undefined4 param_1)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01ead26b == '\0') {
    DAT_01ead26b = '\x01';
    DAT_01ead244 = 0;
    uRam01ead248 = 0;
    DAT_01ead24c = 0;
    DAT_01ead250 = 0;
    _DAT_01ead264 = 0;
    DAT_01ead254 = _DAT_018ce340;
    uRam01ead258 = _UNK_018ce344;
    uRam01ead25c = _UNK_018ce348;
    uRam01ead260 = _UNK_018ce34c;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  uVar3 = FUN_00624080(param_1);
  uStack_8 = 0;
  LOCK();
  uVar1 = DAT_01ead244 + 0x80000000;
  UNLOCK();
  uVar2 = uVar1;
  if (((DAT_01ead244 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead244)) {
    LOCK();
    DAT_01ead244 = uVar1 | 0x40000000;
    UNLOCK();
    uVar2 = DAT_01ead244;
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar4 = FUN_00554e40();
      SetEvent(uVar4);
      uVar2 = DAT_01ead244;
    }
  }
  DAT_01ead244 = uVar2;
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 6836 ; VA 0x00624390 ; FUN_00624390 */

int __fastcall FUN_00624390(int param_1)

{
  return param_1 + 0xc98;
}



/* FUNCTION 6837 ; VA 0x006243a0 ; FUN_006243a0 */

int __fastcall FUN_006243a0(int param_1)

{
  return param_1 + 0x9d0;
}



/* FUNCTION 6838 ; VA 0x006243b0 ; FUN_006243b0 */

undefined8 * __thiscall FUN_006243b0(uint *param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  uint uVar3;
  
  uVar3 = param_1[1];
  param_1[1] = (uVar3 + 1) % *param_1;
  uVar3 = uVar3 % *param_1;
  uVar1 = *(undefined8 *)(param_1[3] + uVar3 * 0xc);
  uVar2 = *(undefined4 *)(param_1[3] + 8 + uVar3 * 0xc);
  param_1[2] = param_1[2] - 1;
  *param_2 = uVar1;
  *(undefined4 *)(param_2 + 1) = uVar2;
  return param_2;
}



/* FUNCTION 6839 ; VA 0x006243f0 ; FUN_006243f0 */

undefined4 __thiscall FUN_006243f0(int *param_1,undefined4 *param_2)

{
  uint *puVar1;
  int *piVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  puVar1 = (uint *)(param_1 + 5);
  do {
    LOCK();
    uVar5 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar5 & 1) != 0);
  if (param_1[4] == 0) {
    uVar3 = 0;
  }
  else {
    puVar4 = (undefined4 *)*param_1;
    if (puVar4 != (undefined4 *)0x0) {
      puVar4 = (undefined4 *)*puVar4;
    }
    *param_2 = **(undefined4 **)(puVar4[1] + (puVar4[2] - 1 & param_1[3]) * 4);
    piVar2 = param_1 + 4;
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      param_1[3] = 0;
      uVar5 = 0;
    }
    else {
      param_1[3] = param_1[3] + 1;
      uVar5 = param_1[3];
    }
    if (param_1[4] == 0) {
      uVar3 = 1;
      param_1[6] = 0;
      param_1[7] = 0;
    }
    else {
      puVar4 = (undefined4 *)*param_1;
      if (puVar4 != (undefined4 *)0x0) {
        puVar4 = (undefined4 *)*puVar4;
      }
      uVar3 = 1;
      *(undefined8 *)(param_1 + 6) =
           *(undefined8 *)(*(int *)(puVar4[1] + (puVar4[2] - 1 & uVar5) * 4) + 8);
    }
  }
  *puVar1 = 0;
  return CONCAT31((int3)((uint)puVar1 >> 8),uVar3);
}



/* FUNCTION 6840 ; VA 0x00624490 ; FUN_00624490 */

undefined4 __thiscall FUN_00624490(int *param_1,double param_2,undefined4 *param_3)

{
  uint *puVar1;
  int *piVar2;
  double *pdVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined auStack_20 [8];
  uint *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_0179e768;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)(param_1 + 5);
  ExceptionList = &pvStack_10;
  do {
    LOCK();
    uVar7 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
    uStack_8 = (uint)((uVar7 & 1) != 0);
  } while (uStack_8 != 0);
  if (param_1[4] != 0) {
    puStack_18 = puVar1;
    pdVar3 = (double *)FUN_01682800(auStack_20);
    piVar2 = (int *)*param_1;
    if (piVar2 == (int *)0x0) {
      iVar4 = 0;
    }
    else {
      iVar4 = *piVar2;
    }
    param_2 = *(double *)
               (*(int *)(*(int *)(iVar4 + 4) + (*(int *)(iVar4 + 8) - 1U & param_1[3]) * 4) + 8) +
              param_2;
    if (param_2 < *pdVar3 || param_2 == *pdVar3) {
      if (piVar2 == (int *)0x0) {
        iVar4 = 0;
      }
      else {
        iVar4 = *piVar2;
      }
      *param_3 = **(undefined4 **)
                   (*(int *)(iVar4 + 4) + (*(int *)(iVar4 + 8) - 1U & param_1[3]) * 4);
      piVar2 = param_1 + 4;
      *piVar2 = *piVar2 + -1;
      if (*piVar2 == 0) {
        param_1[3] = 0;
        uVar7 = 0;
      }
      else {
        param_1[3] = param_1[3] + 1;
        uVar7 = param_1[3];
      }
      if (param_1[4] == 0) {
        uVar6 = 1;
        param_1[6] = 0;
        param_1[7] = 0;
      }
      else {
        puVar5 = (undefined4 *)*param_1;
        if (puVar5 != (undefined4 *)0x0) {
          puVar5 = (undefined4 *)*puVar5;
        }
        uVar6 = 1;
        *(undefined8 *)(param_1 + 6) =
             *(undefined8 *)(*(int *)(puVar5[1] + (puVar5[2] - 1 & uVar7) * 4) + 8);
      }
      goto LAB_00624576;
    }
  }
  uVar6 = 0;
LAB_00624576:
  *puVar1 = 0;
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 6841 ; VA 0x00624590 ; FUN_00624590 */

void __thiscall FUN_00624590(int *param_1,int param_2)

{
  undefined4 *puVar1;
  short sVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  double dVar7;
  double dVar8;
  double dVar9;
  double dVar10;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e791;
  pvStack_10 = ExceptionList;
  iVar6 = *(int *)(param_2 + 0x18);
  uVar5 = *(undefined4 *)(param_2 + 0x1c);
  if ((*(byte *)(param_2 + 0x10) & 1) == 0) {
    puVar1 = (undefined4 *)param_1[0x659];
    uStack_18 = (double)CONCAT44(puVar1,(undefined4)uStack_18);
    puVar4 = *(undefined4 **)*puVar1;
    if (puVar4 == (undefined4 *)0x0) {
      ExceptionList = &pvStack_10;
      puVar4 = (undefined4 *)FUN_00621d50();
    }
    else {
      ExceptionList = &pvStack_10;
      *(undefined4 *)*puVar1 = *puVar4;
    }
    *puVar4 = puVar1;
    uStack_8 = 0;
    if (puVar4 == (undefined4 *)0xfffffffc) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_006fb070(param_1,iVar6,uVar5,0);
    }
    uStack_8 = 0xffffffff;
    FUN_006b1f50(uVar5);
  }
  else {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_006a6900();
    iVar3 = iVar3 - iVar6;
    if (DAT_01eace38 != '\0') {
      FUN_016774b0(DAT_01eace38,"Ping Elapsed Time: %d",iVar3);
    }
    dVar7 = (double)iVar3;
    uStack_18 = dVar7;
    sVar2 = FUN_017265ed(&uStack_18);
    dVar9 = DAT_018c0d60;
    if (sVar2 < 1) {
      dVar10 = *(double *)(param_1 + 0x25c);
      dVar8 = dVar7;
      if (*(char *)(param_1 + 0x264) == '\0') {
        dVar8 = (DAT_018c0d60 - dVar10) * *(double *)(param_1 + 0x260) + dVar10 * dVar7;
      }
      *(double *)(param_1 + 0x260) = dVar8;
      param_1[0x25e] = iVar3;
      *(undefined *)(param_1 + 0x264) = 0;
      *(double *)(param_1 + 0x262) =
           (dVar7 - dVar8) * (dVar7 - dVar8) * dVar10 +
           (dVar9 - dVar10) * *(double *)(param_1 + 0x262);
    }
    uStack_18 = dVar7;
    sVar2 = FUN_017265ed(&uStack_18);
    if (sVar2 < 1) {
      dVar9 = *(double *)(param_1 + 0xe60);
      dVar10 = dVar7;
      if (*(char *)(param_1 + 0xe68) == '\0') {
        dVar10 = (DAT_018c0d60 - dVar9) * *(double *)(param_1 + 0xe64) + dVar9 * dVar7;
      }
      dVar8 = DAT_018c0d60 - dVar9;
      *(double *)(param_1 + 0xe64) = dVar10;
      param_1[0xe62] = iVar3;
      *(undefined *)(param_1 + 0xe68) = 0;
      *(double *)(param_1 + 0xe66) =
           (dVar7 - dVar10) * (dVar7 - dVar10) * dVar9 + dVar8 * *(double *)(param_1 + 0xe66);
    }
    if (*(char *)(param_1 + 0xe18) != '\0') {
      if (param_1[0x266] < iVar3) {
        param_1[0x266] = iVar3;
      }
      if (iVar3 < param_1[0x267]) {
        param_1[0x267] = iVar3;
      }
    }
  }
  (**(code **)(*param_1 + 0x1a8))();
  if (DAT_01d5a060 != '\0') {
    iVar6 = FUN_006a6900();
    iVar6 = iVar6 - param_1[0x41c];
    dVar9 = (double)iVar6;
    uStack_18 = dVar9;
    sVar2 = FUN_017265ed(&uStack_18);
    if (sVar2 < 1) {
      dVar7 = *(double *)(param_1 + 0x448);
      dVar10 = dVar9;
      if (*(char *)(param_1 + 0x450) == '\0') {
        dVar10 = (DAT_018c0d60 - dVar7) * *(double *)(param_1 + 0x44c) + dVar7 * dVar9;
      }
      *(double *)(param_1 + 0x44c) = dVar10;
      dVar8 = DAT_018c0d60 - dVar7;
      param_1[0x44a] = iVar6;
      *(undefined *)(param_1 + 0x450) = 0;
      *(double *)(param_1 + 0x44e) =
           (dVar9 - dVar10) * (dVar9 - dVar10) * dVar7 + dVar8 * *(double *)(param_1 + 0x44e);
    }
    if (param_1[0x452] < iVar6) {
      param_1[0x452] = iVar6;
    }
    if (iVar6 < param_1[0x453]) {
      param_1[0x453] = iVar6;
    }
  }
  iVar6 = FUN_006a6900();
  param_1[0x41c] = iVar6;
  param_1[0x41d] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6842 ; VA 0x006248b0 ; FUN_006248b0 */

int __thiscall FUN_006248b0(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  char *pcVar9;
  undefined4 uVar10;
  undefined **appuStack_9c [9];
  undefined auStack_78 [8];
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  int *piStack_60;
  int iStack_5c;
  int *piStack_58;
  char cStack_53;
  int aiStack_44 [5];
  uint uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar7 = param_2;
  puStack_c = &LAB_0179e7d6;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_20 = 8;
  uStack_1c = 0;
  iStack_18 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = FUN_01674f30(0x2c0);
  uStack_8 = 1;
  FUN_0060f060(param_2);
  uStack_8._0_1_ = 2;
  FUN_006078f0(appuStack_9c,aiStack_44);
  uStack_8._0_1_ = 1;
  FUN_00613010();
  iStack_28 = 0;
  uVar5 = uStack_1c;
  param_2 = iStack_18;
  do {
    if (param_2 == 0) {
      uStack_8 = 8;
      iVar7 = 0;
      while (iVar7 != 0) {
        uVar6 = uVar5 % uStack_20;
        uVar5 = (uVar5 + 1) % uStack_20;
        puVar8 = (undefined4 *)(uVar6 * 0x58 + iStack_14);
        FUN_0060f060(puVar8);
        (**(code **)*puVar8)(0);
        appuStack_9c[0] = RBX::Network::DeserializedNewInstanceItem::vftable;
        iVar7 = iVar7 + -1;
        FUN_00617ad0();
        piVar2 = piStack_58;
        if (piStack_58 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_58[1] + -1;
          piStack_58[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_58)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar4 = *piVar1 + -1;
            *piVar1 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = piStack_60;
        if (piStack_60 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_60[1] + -1;
          piStack_60[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_60)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar4 = *piVar1 + -1;
            *piVar1 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        uStack_8._0_1_ = 9;
        FUN_00617b40();
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
      }
      FUN_01674ea0(iStack_14);
      ExceptionList = pvStack_10;
      return iStack_28;
    }
    uStack_24 = (uVar5 + 1) % uStack_20;
    puVar8 = (undefined4 *)((uVar5 % uStack_20) * 0x58 + iStack_14);
    uStack_1c = uStack_24;
    FUN_0060f060(puVar8);
    (**(code **)*puVar8)(0);
    param_2 = param_2 + -1;
    uStack_8._0_1_ = 3;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    iStack_18 = param_2;
    if (*(int *)(iStack_70 + 8) == 0) {
      uStack_8._0_1_ = uVar3;
      if (DAT_01ee420f != '\0') {
        uStack_2c = *(undefined4 *)(iVar7 + 0x34);
        uVar10 = *(undefined4 *)(iVar7 + 0x30);
        puVar8 = (undefined4 *)FUN_009c9510(aiStack_44);
        uStack_8._0_1_ = 6;
        if (0xf < (uint)puVar8[5]) {
          puVar8 = (undefined4 *)*puVar8;
        }
        pcVar9 = 
        "Replicator::processDeserializedItemChildren() : Dropping newInstanceItem [%s], indexInParent=%d, numOfChildren=%d : localDescriptor is null resolve parent"
        ;
LAB_00624aef:
        FUN_01677490(DAT_01ee420f,pcVar9,puVar8,uStack_2c,uVar10);
        uStack_8._0_1_ = 3;
        if (0xf < uStack_30) {
          uVar5 = uStack_30 + 1;
          iVar4 = aiStack_44[0];
          if (0xfff < uVar5) {
            iVar4 = *(int *)(aiStack_44[0] + -4);
            uVar5 = uStack_30 + 0x24;
            if (0x1f < (aiStack_44[0] - iVar4) - 4U) {
LAB_00624cef:
              uStack_8._0_1_ = 3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar4,uVar5);
        }
      }
    }
    else if (((((*(uint *)(*(int *)(iStack_70 + 8) + 0x1d4) >> 4 & 1) == 0) &&
              (uVar3 = (undefined)uStack_8, cStack_53 == '\0')) && (iStack_5c == 0)) &&
            (FUN_00621ac0(auStack_78,&iStack_5c), uVar3 = (undefined)uStack_8, iStack_5c == 0)) {
      if (DAT_01ee420f != '\0') {
        uStack_2c = *(undefined4 *)(iVar7 + 0x34);
        uVar10 = *(undefined4 *)(iVar7 + 0x30);
        puVar8 = (undefined4 *)FUN_009c9510(aiStack_44);
        uStack_8._0_1_ = 4;
        if (0xf < (uint)puVar8[5]) {
          puVar8 = (undefined4 *)*puVar8;
        }
        pcVar9 = 
        "Replicator::processDeserializedItemChildren() : Dropping newInstanceItem [%s], indexInParent=%d, numOfChildren=%d : cannot resolve parent"
        ;
        goto LAB_00624aef;
      }
    }
    else {
      uStack_8._0_1_ = uVar3;
      iStack_28 = iStack_28 + 1;
      if (DAT_01ee420f != '\0') {
        uVar10 = *(undefined4 *)(iVar7 + 0x30);
        puVar8 = (undefined4 *)FUN_009c9510(aiStack_44);
        uStack_8._0_1_ = 5;
        if (0xf < (uint)puVar8[5]) {
          puVar8 = (undefined4 *)*puVar8;
        }
        FUN_01677490(DAT_01ee420f,
                     "Replicator::processDeserializedItemChildren() : processing newInstanceItem [%s], indexInParent=%d, numOfChildren=%d"
                     ,puVar8,iStack_68,uVar10);
        uStack_8._0_1_ = 3;
        if (0xf < uStack_30) {
          uVar5 = uStack_30 + 1;
          iVar4 = aiStack_44[0];
          if (0xfff < uVar5) {
            iVar4 = *(int *)(aiStack_44[0] + -4);
            uVar5 = uStack_30 + 0x24;
            if (0x1f < (aiStack_44[0] - iVar4) - 4U) goto LAB_00624cef;
          }
          FUN_01674ea0(iVar4,uVar5);
        }
      }
      FUN_006bfed0(param_1);
      if (*(char *)(*(int *)(param_1 + 0x1f70) + 0x5a) != '\0') {
        FUN_006281f0(iVar7 + 0x38,*(undefined4 *)(iVar7 + 0xc));
      }
    }
    if (iStack_68 != 0) {
      FUN_0061cf70(appuStack_9c,&uStack_20);
      param_2 = iStack_18;
      uStack_24 = uStack_1c;
    }
    if ((DAT_01d5a098 != '\0') || (iStack_6c != 0)) {
      FUN_0061cda0(appuStack_9c,&uStack_20);
      param_2 = iStack_18;
      uStack_24 = uStack_1c;
    }
    appuStack_9c[0] = RBX::Network::DeserializedNewInstanceItem::vftable;
    FUN_00617ad0();
    piVar2 = piStack_58;
    if (piStack_58 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_58[1] + -1;
      piStack_58[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_58)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_60;
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_60[1] + -1;
      piStack_60[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_60)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 7;
    FUN_00617b40();
    uStack_8._0_1_ = 1;
    uVar5 = uStack_24;
  } while( true );
}



/* FUNCTION 6843 ; VA 0x00624d00 ; FUN_00624d00 */

void __thiscall FUN_00624d00(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e7f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01255470(9,0,0,0);
  FUN_01255490();
  iStack_8 = 0;
  piVar2 = (int *)param_2[2];
  piVar6 = (int *)param_2[1];
  if (piVar6 == piVar2) {
    (**(code **)(*param_1 + 0x16c))(*param_2,0);
  }
  else {
    do {
      piVar5 = (int *)piVar6[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)piVar6[1];
      }
      piVar3 = (int *)*piVar6;
      iStack_8._0_1_ = 1;
      if (DAT_01d5a058 != '\0') {
        iVar4 = piVar3[1];
        if ((((iVar4 != 5) && (iVar4 != 6)) && (iVar4 != 9)) && (iVar4 != 0x12)) {
          piVar1 = (int *)(param_1[0xe22] + iVar4 * 4);
          *piVar1 = *piVar1 + piVar3[2];
        }
      }
      (**(code **)(*piVar3 + 4))(param_1);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar4 = piVar5[2] + -1;
          piVar5[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      piVar6 = piVar6 + 2;
    } while (piVar6 != piVar2);
  }
  FUN_01255500();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6844 ; VA 0x00624e10 ; FUN_00624e10 */

void FUN_00624e10(void)

{
  return;
}



/* FUNCTION 6845 ; VA 0x00624e20 ; FUN_00624e20 */

uint __fastcall FUN_00624e20(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  double *pdVar5;
  undefined *puVar6;
  char cVar7;
  double *pdVar8;
  undefined4 *puVar9;
  int iVar10;
  uint uVar11;
  double dVar12;
  undefined8 uVar13;
  undefined auStack_d0 [8];
  undefined auStack_c8 [8];
  undefined auStack_c0 [124];
  undefined8 uStack_44;
  uint *puStack_3c;
  undefined8 uStack_38;
  double *pdStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined uStack_1a;
  undefined uStack_19;
  double *pdStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_0179e86d;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffec4;
  if (param_1[0x1b] == 0) goto LAB_00624fbf;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_8 = 0;
  uStack_44 = *(double *)(param_1[0x7dc] + 0x60);
  uStack_19 = 1;
  uStack_1a = 1;
  piStack_20 = param_1;
  if (uStack_44 <= 0.0) {
    if ((param_1[0xe3c] != 0) || (param_1[0xe3e] != 0)) {
      puStack_3c = (uint *)(param_1 + 0xe39);
      ExceptionList = &pvStack_10;
      do {
        LOCK();
        uVar11 = *puStack_3c;
        *puStack_3c = *puStack_3c | 1;
        UNLOCK();
      } while ((uVar11 & 1) != 0);
      uStack_8 = 1;
      puVar6 = &stack0xfffffec4;
      if (param_1[0xe38] != 0) {
        if ((param_1 + 0xe34 == (int *)0x0) ||
           (piVar2 = (int *)param_1[0xe34], piVar2 == (int *)0x0)) {
          iVar10 = 0;
        }
        else {
          iVar10 = *piVar2;
        }
        puStack_14 = &stack0xfffffec4;
        FUN_00613ee0(*(undefined4 *)
                      (*(int *)(iVar10 + 4) + (*(int *)(iVar10 + 8) - 1U & param_1[0xe37]) * 4));
        FUN_00577ac0();
        piVar2 = param_1 + 0xe38;
        *piVar2 = *piVar2 + -1;
        if (*piVar2 == 0) {
          param_1[0xe37] = 0;
          pdStack_18 = (double *)0x0;
        }
        else {
          param_1[0xe37] = param_1[0xe37] + 1;
          pdStack_18 = (double *)param_1[0xe37];
        }
        if (param_1[0xe38] == 0) {
          param_1[0xe3a] = 0;
          param_1[0xe3b] = 0;
        }
        else {
          puVar9 = (undefined4 *)param_1[0xe34];
          if (puVar9 != (undefined4 *)0x0) {
            puVar9 = (undefined4 *)*puVar9;
          }
          *(undefined8 *)(param_1 + 0xe3a) =
               *(undefined8 *)(*(int *)(puVar9[1] + (puVar9[2] - 1 & (uint)pdStack_18) * 4) + 0x10);
        }
LAB_00625131:
        uStack_8 = uStack_8 & 0xffffff00;
        param_1[0xe39] = 0;
        pdVar5 = pdStack_30;
LAB_00625141:
        pdStack_18 = pdVar5;
        pdVar5 = pdStack_18;
        pdVar8 = (double *)FUN_016827a0(auStack_c8);
        if (*(double *)(param_1 + 0x7d2) <= *pdVar8 - *(double *)(param_1 + 2000)) {
          param_1[0x7d4] = param_1[0x7d5];
          param_1[0x7d5] = 0;
          FUN_016827a0(&uStack_44);
          param_1[2000] = (int)uStack_44;
          param_1[0x7d1] = uStack_44._4_4_;
        }
        param_1[0x7d5] = param_1[0x7d5] + 1;
        puStack_3c = (uint *)param_1[0xe16];
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        if (puStack_3c != (uint *)0x0) {
          puVar9 = (undefined4 *)FUN_016830f0(auStack_d0);
          FUN_00705e30(*puVar9,puVar9[1]);
        }
        if ((param_1[0xe3c] == 0) && (param_1[0xe3e] == 0)) {
          iVar10 = (**(code **)(*param_1 + 0x16c))(pdVar5,param_1[0x7cd]);
          param_1[0x7cd] = iVar10;
          if ((param_1[0x67c] != 0) && (iVar10 != *(int *)((int)pdVar5 + 0x34))) {
            uStack_19 = 0;
            param_1[0x7cc] = (int)pdVar5;
            uVar11 = FUN_006253cf();
            return uVar11;
          }
          param_1[0x7cc] = 0;
          param_1[0x7cd] = 0;
          uVar11 = FUN_006253cf();
          return uVar11;
        }
        (**(code **)(*param_1 + 0x170))(&pdStack_30);
        uVar11 = FUN_006253cf();
        return uVar11;
      }
      goto LAB_00624fb1;
    }
    if ((param_1[0x67c] != 0) &&
       (ExceptionList = &pvStack_10, pdVar5 = (double *)param_1[0x7cc],
       puStack_14 = &stack0xfffffec4, (double *)param_1[0x7cc] != (double *)0x0)) goto LAB_00625141;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xfffffec4;
    cVar7 = FUN_006243f0(&pdStack_18);
    if (cVar7 != '\0') {
      param_1[0x7ce] = param_1[0x7ce] - *(int *)(pdStack_18 + 6);
      pdVar5 = pdStack_18;
      goto LAB_00625141;
    }
  }
  else if ((param_1[0xe3c] == 0) && (param_1[0xe3e] == 0)) {
    if ((param_1[0x67c] != 0) &&
       (ExceptionList = &pvStack_10, pdVar5 = (double *)param_1[0x7cc],
       puStack_14 = &stack0xfffffec4, (double *)param_1[0x7cc] != (double *)0x0)) goto LAB_00625141;
    uStack_38._4_4_ = (undefined4)((ulonglong)uStack_44 >> 0x20);
    uVar3 = uStack_38._4_4_;
    uStack_38._0_4_ = SUB84(uStack_44,0);
    ExceptionList = &pvStack_10;
    uVar4 = (undefined4)uStack_38;
    uStack_38 = uStack_44;
    puStack_14 = &stack0xfffffec4;
    cVar7 = FUN_00624490(uVar4,uVar3,&pdStack_18);
    if (cVar7 != '\0') {
      param_1[0x7ce] = param_1[0x7ce] - *(int *)(pdStack_18 + 6);
      pdVar5 = pdStack_18;
      goto LAB_00625141;
    }
  }
  else {
    puVar1 = (uint *)(param_1 + 0xe39);
    uStack_38 = (double)CONCAT44(puVar1,(undefined4)uStack_38);
    ExceptionList = &pvStack_10;
    do {
      LOCK();
      uVar11 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar11 & 1) != 0);
    uStack_8 = 2;
    puVar6 = &stack0xfffffec4;
    if (param_1[0xe38] != 0) {
      pdStack_18 = (double *)FUN_01682800(auStack_c0);
      piVar2 = (int *)param_1[0xe34];
      if (piVar2 == (int *)0x0) {
        iVar10 = 0;
      }
      else {
        iVar10 = *piVar2;
      }
      dVar12 = uStack_44 +
               *(double *)
                (*(int *)(*(int *)(iVar10 + 4) + (*(int *)(iVar10 + 8) - 1U & param_1[0xe37]) * 4) +
                0x10);
      puVar6 = puStack_14;
      if (dVar12 < *pdStack_18 || dVar12 == *pdStack_18) {
        if (piVar2 == (int *)0x0) {
          iVar10 = 0;
        }
        else {
          iVar10 = *piVar2;
        }
        FUN_00613ee0(*(undefined4 *)
                      (*(int *)(iVar10 + 4) + (*(int *)(iVar10 + 8) - 1U & param_1[0xe37]) * 4));
        FUN_00577ac0();
        piVar2 = param_1 + 0xe38;
        *piVar2 = *piVar2 + -1;
        if (*piVar2 == 0) {
          param_1[0xe37] = 0;
          uVar11 = 0;
        }
        else {
          param_1[0xe37] = param_1[0xe37] + 1;
          uVar11 = param_1[0xe37];
        }
        if (param_1[0xe38] == 0) {
          uVar13 = 0;
        }
        else {
          puVar9 = (undefined4 *)param_1[0xe34];
          if (puVar9 != (undefined4 *)0x0) {
            puVar9 = (undefined4 *)*puVar9;
          }
          uVar13 = *(undefined8 *)(*(int *)(puVar9[1] + (puVar9[2] - 1 & uVar11) * 4) + 0x10);
        }
        *(undefined8 *)(param_1 + 0xe3a) = uVar13;
        goto LAB_00625131;
      }
    }
LAB_00624fb1:
    puStack_14 = puVar6;
    param_1[0xe39] = 0;
  }
  ExceptionList = (void *)FUN_00577ac0();
LAB_00624fbf:
  uVar11 = (uint)ExceptionList & 0xffffff00;
  ExceptionList = pvStack_10;
  return uVar11;
}



/* FUNCTION 6846 ; VA 0x00625241 ; Catch@00625241 */

undefined * Catch_00625241(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  uVar2 = (**(code **)(**(int **)(unaff_EBP + -0x44) + 4))();
  FUN_0054eff0(uVar2);
  *(undefined *)(unaff_EBP + -4) = 5;
  *(undefined4 *)(unaff_EBP + -0x5c) = 0;
  *(undefined4 *)(unaff_EBP + -0x58) = 0xf;
  *(undefined *)(unaff_EBP + -0x6c) = 0;
  FUN_005542c0("OutOfRange",10);
  uVar2 = *(undefined4 *)(unaff_EBP + -0x14);
  iVar1 = *(int *)(unaff_EBP + -0x1c);
  *(undefined *)(unaff_EBP + -4) = 6;
  FUN_006217d0(uVar2,unaff_EBP + -0x6c,unaff_EBP + -0xe4);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_005507b0();
  (**(code **)(*(int *)**(undefined4 **)(iVar1 + 0x6c) + 0x60))(uVar2);
  FUN_0062b590(0x104);
  return &DAT_006252cd;
}



/* FUNCTION 6847 ; VA 0x006252d2 ; Catch@006252d2 */

undefined * Catch_006252d2(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  uVar2 = (**(code **)(**(int **)(unaff_EBP + -0x48) + 4))();
  FUN_0054eff0(uVar2);
  *(undefined *)(unaff_EBP + -4) = 7;
  *(undefined4 *)(unaff_EBP + -0x74) = 0;
  *(undefined4 *)(unaff_EBP + -0x70) = 0xf;
  *(undefined *)(unaff_EBP + -0x84) = 0;
  FUN_005542c0("BadCast",7);
  uVar2 = *(undefined4 *)(unaff_EBP + -0x14);
  iVar1 = *(int *)(unaff_EBP + -0x1c);
  *(undefined *)(unaff_EBP + -4) = 8;
  FUN_006217d0(uVar2,unaff_EBP + -0x84,unaff_EBP + -0xfc);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_005507b0();
  (**(code **)(*(int *)**(undefined4 **)(iVar1 + 0x6c) + 0x60))(uVar2);
  FUN_0062b590(0x104);
  return &DAT_0062536a;
}



/* FUNCTION 6848 ; VA 0x0062536f ; Catch@0062536f */

undefined * Catch_0062536f(void)

{
  undefined uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  int unaff_EBP;
  
  if (DAT_01ee420a != '\0') {
    uVar2 = *(undefined4 *)(*(int *)(unaff_EBP + -0x14) + 0x34);
    uVar1 = **(undefined **)(*(int *)(unaff_EBP + -0x14) + 0x38);
    uVar4 = (**(code **)(**(int **)(unaff_EBP + -0x4c) + 4))();
    FUN_01677520(DAT_01ee420a,
                 "Error while processing physics packet (ignored): %s (Packet size: %d, packet type: %d)\n"
                 ,uVar4,uVar2,uVar1);
  }
  iVar3 = *(int *)(unaff_EBP + -0x1c);
  *(undefined4 *)(iVar3 + 0x1f30) = 0;
  *(undefined4 *)(iVar3 + 0x1f34) = 0;
  return &DAT_006253c3;
}



/* FUNCTION 6849 ; VA 0x006253cf ; FUN_006253cf */

undefined FUN_006253cf(void)

{
  int iVar1;
  char cVar2;
  int unaff_EBP;
  int unaff_ESI;
  int *unaff_EDI;
  
  iVar1 = unaff_EDI[0x1b];
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if (iVar1 != 0) {
    if ((DAT_01d5b828 != '\0') && (**(char **)(unaff_ESI + 0x38) == '\x1b')) {
      cVar2 = (**(code **)(*unaff_EDI + 0xd4))();
      if (cVar2 != '\0') goto LAB_0062541a;
    }
    if ((unaff_EDI[0x7cc] == 0) || (unaff_EDI[0x67c] == 0)) {
      (**(code **)(**(int **)unaff_EDI[0x1b] + 0x60))();
    }
  }
LAB_0062541a:
  FUN_00577ac0();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return *(undefined *)(unaff_EBP + -0x15);
}



/* FUNCTION 6850 ; VA 0x00625436 ; Catch@00625436 */

undefined * Catch_00625436(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  uVar2 = (**(code **)(**(int **)(unaff_EBP + -0x50) + 4))();
  FUN_0054eff0(uVar2);
  *(undefined *)(unaff_EBP + -4) = 9;
  *(undefined4 *)(unaff_EBP + -0x8c) = 0;
  *(undefined4 *)(unaff_EBP + -0x88) = 0xf;
  *(undefined *)(unaff_EBP + -0x9c) = 0;
  FUN_005542c0("Stream",6);
  uVar2 = *(undefined4 *)(unaff_EBP + -0x14);
  iVar1 = *(int *)(unaff_EBP + -0x1c);
  *(undefined *)(unaff_EBP + -4) = 10;
  FUN_006217d0(uVar2,unaff_EBP + -0x9c,unaff_EBP + -0x114);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_005507b0();
  (**(code **)(*(int *)**(undefined4 **)(iVar1 + 0x6c) + 0x60))(uVar2);
  FUN_0062b590(0x105);
  return &DAT_006254d4;
}



/* FUNCTION 6851 ; VA 0x006254d9 ; Catch@006254d9 */

undefined4 Catch_006254d9(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  uVar2 = (**(code **)(**(int **)(unaff_EBP + -0x54) + 4))();
  FUN_0054eff0(uVar2);
  *(undefined *)(unaff_EBP + -4) = 0xb;
  *(undefined4 *)(unaff_EBP + -0xa4) = 0;
  *(undefined4 *)(unaff_EBP + -0xa0) = 0xf;
  *(undefined *)(unaff_EBP + -0xb4) = 0;
  FUN_005542c0("Other",5);
  uVar2 = *(undefined4 *)(unaff_EBP + -0x14);
  iVar1 = *(int *)(unaff_EBP + -0x1c);
  *(undefined *)(unaff_EBP + -4) = 0xc;
  FUN_006217d0(uVar2,unaff_EBP + -0xb4,unaff_EBP + -300);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_005507b0();
  (**(code **)(*(int *)**(undefined4 **)(iVar1 + 0x6c) + 0x60))(uVar2);
  FUN_0062b590(0x104);
  return 0x624fb7;
}



/* FUNCTION 6852 ; VA 0x00625580 ; FUN_00625580 */

int __thiscall FUN_00625580(int *param_1,int param_2,uint param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined8 uVar4;
  undefined auStack_84 [32];
  int iStack_64;
  int *apiStack_20 [3];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e898;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff70;
  ExceptionList = &pvStack_10;
  FUN_006ab380(*(undefined4 *)(param_2 + 0x38),*(undefined4 *)(param_2 + 0x30),0);
  iVar2 = iStack_64;
  iStack_8 = 0;
  param_1[0x42d] = (uint)**(byte **)(param_2 + 0x38);
  if (DAT_01eace3c != '\0') {
    FUN_016774b0(DAT_01eace3c,"ProcessPacket %d start",**(undefined **)(param_2 + 0x38));
  }
  switch(**(undefined **)(param_2 + 0x38)) {
  case 0x1b:
    if (param_1[0xe16] != 0) {
      FUN_006ab660();
      uVar4 = FUN_006ace60();
      FUN_006ace60();
      *(undefined8 *)(param_1 + 0x650) = uVar4;
      FUN_006abe40();
      iStack_8 = CONCAT31(iStack_8._1_3_,2);
      if (DAT_01d5be00 != '\0') {
        *(undefined *)(param_1[0xe16] + 0x24) = *(undefined *)(param_1[0x7dc] + 0x5c);
      }
      if ((DAT_01d5b828 == '\0') || (cVar1 = (**(code **)(*param_1 + 0xd4))(), cVar1 == '\0')) {
        FUN_00705990(auStack_84,uVar4);
      }
      else {
        FUN_006d4570(param_2,uVar4,param_1);
      }
      iStack_8 = 0;
      FUN_0062ba20();
      FUN_0062b990((double)(iStack_64 - iVar2) +
                   (double)(&DAT_018c0d90)[-(iStack_64 - iVar2 >> 0x1f)]);
      if (DAT_01d59fb8 != '\0') {
        param_1[0x61c] = param_1[0x61c] + (iStack_64 - iVar2);
      }
    }
    break;
  case 0x83:
    FUN_006ab660();
    if (param_1[0x67c] != 0) {
      if (param_3 == 0) {
        FUN_0062ba20();
        param_3 = 0;
      }
      else {
        param_3 = param_3 >> 3;
        FUN_006ab690();
      }
      FUN_006280b0();
      iVar2 = (iStack_64 - param_3) - iVar2;
      FUN_0062b990((double)iVar2 + (double)(&DAT_018c0d90)[-(iVar2 >> 0x1f)]);
      FUN_00613200();
      ExceptionList = pvStack_10;
      return iStack_64 * 8;
    }
    FUN_006280b0();
    FUN_0062ba20();
    FUN_0062b990((double)(iStack_64 - iVar2) + (double)(&DAT_018c0d90)[-(iStack_64 - iVar2 >> 0x1f)]
                );
    goto LAB_006258ea;
  case 0x86:
    if (param_1[0xe16] != 0) {
      FUN_006ab660();
      iVar3 = FUN_00705490(auStack_84,param_2);
      *(int *)(param_1[0xe22] + 0x70) = *(int *)(param_1[0xe22] + 0x70) + iVar3;
      FUN_0062ba20();
      FUN_0062b990((double)(iStack_64 - iVar2) +
                   (double)(&DAT_018c0d90)[-(iStack_64 - iVar2 >> 0x1f)]);
      if (DAT_01d59fb8 != '\0') {
        param_1[0x61d] = param_1[0x61d] + (iStack_64 - iVar2);
      }
    }
    break;
  case 0x8d:
    FUN_006ab660();
    FUN_006bdf00(apiStack_20,param_1,auStack_84);
    iStack_8._0_1_ = 1;
    if (((param_1[0xe03] & 2U) == 0) || (apiStack_20[0] != (int *)0x0)) {
      (**(code **)(*apiStack_20[0] + 4))();
      FUN_00620960(apiStack_20[0][1],apiStack_20[0][2]);
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_00550b30();
  }
  if (DAT_01eace3c != '\0') {
    FUN_01677490(DAT_01eace3c,"ProcessPacket %d end, bytes read %d",**(undefined **)(param_2 + 0x38)
                 ,iStack_64 - iVar2,0);
  }
LAB_006258ea:
  iVar2 = *(int *)(param_2 + 0x34);
  FUN_00613200();
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 6853 ; VA 0x0062590a ; Catch@0062590a */

void Catch_0062590a(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_00610c20(unaff_EBP + -0x34);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x58,&DAT_01c2a510);
}



/* FUNCTION 6854 ; VA 0x006259d0 ; FUN_006259d0 */

void __thiscall FUN_006259d0(int param_1,undefined4 **param_2)

{
  int iVar1;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a9e8;
  pvStack_10 = ExceptionList;
  puStack_28 = (undefined4 *)0x6259fe;
  ExceptionList = &pvStack_10;
  puStack_24 = (undefined4 *)(param_1 + 0xfc);
  puStack_24 = (undefined4 *)FUN_016dee6d();
  if (puStack_24 != (undefined4 *)0x0) {
    puStack_28 = (undefined4 *)0x625a0b;
    FUN_016df3c9();
  }
  puStack_28 = *(undefined4 **)(param_1 + 0x130);
  uStack_8 = 0;
  if (*(undefined4 **)(param_1 + 0x134) == puStack_28) {
    puStack_24 = &param_2;
    FUN_006030d0();
  }
  else {
    *puStack_28 = param_2;
    *(int *)(param_1 + 0x130) = *(int *)(param_1 + 0x130) + 4;
  }
  uStack_8 = 1;
  puStack_28 = (undefined4 *)0x625a4c;
  puStack_24 = (undefined4 *)(param_1 + 0xfc);
  iVar1 = FUN_016deec8();
  if (iVar1 != 0) {
    puStack_28 = (undefined4 *)0x625a59;
    puStack_24 = (undefined4 *)iVar1;
    FUN_016df3c9();
  }
  param_2 = &puStack_28;
  uStack_8 = 0xffffffff;
  FUN_006022f0(param_1 + 8);
  FUN_0151dbc0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6855 ; VA 0x00625a90 ; FUN_00625a90 */

void __thiscall FUN_00625a90(int *param_1,int param_2)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  uint *puStack_24;
  char cStack_20;
  uint *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e8c0;
  pvStack_10 = ExceptionList;
  if (param_1[0xe3c] != 0) {
    ExceptionList = &pvStack_10;
    FUN_006259d0(param_2);
    ExceptionList = pvStack_10;
    return;
  }
  if (param_1[0xe3e] != 0) {
    puStack_24 = (uint *)(param_1 + 0xe2c);
    cStack_20 = '\0';
    ExceptionList = &pvStack_10;
    FUN_00587410();
    uStack_14 = param_1[0xe2f];
    uStack_8 = 0;
    puStack_18 = *(undefined4 **)(uStack_14 + 4);
    uVar5 = FUN_00602bf0(uStack_14,puStack_18,&param_2);
    if (param_1[0xe30] != 0x15555554) {
      param_1[0xe30] = param_1[0xe30] + 1;
      *(undefined4 *)(uStack_14 + 4) = uVar5;
      *puStack_18 = uVar5;
      uStack_8 = 1;
      if (cStack_20 != '\0') {
        LOCK();
        uVar7 = *puStack_24;
        *puStack_24 = *puStack_24 + 0x80000000;
        UNLOCK();
        if (((uVar7 & 0x40000000) == 0) && (-0x80000000 < (int)uVar7)) {
          LOCK();
          uVar7 = *puStack_24;
          *puStack_24 = *puStack_24 | 0x40000000;
          UNLOCK();
          if ((uVar7 >> 0x1e & 1) == 0) {
            uVar5 = FUN_00554e40();
            SetEvent(uVar5);
          }
        }
      }
      FUN_0151f3f0();
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  puStack_18 = (undefined4 *)param_2;
  ExceptionList = &pvStack_10;
  FUN_01682800(&iStack_2c);
  puVar1 = (uint *)(param_1 + 0x7c9);
  do {
    LOCK();
    uVar7 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar7 & 1) != 0);
  uStack_8 = 2;
  if (param_1[0x7c8] == 0) {
    *(ulonglong *)(param_1 + 0x7ca) = CONCAT44(iStack_28,iStack_2c);
  }
  uVar7 = param_1[0x7c6];
  puStack_1c = puVar1;
  if (uVar7 <= param_1[0x7c8] + 1U) {
    FUN_00617300(1);
    uVar7 = param_1[0x7c6];
  }
  uVar7 = uVar7 - 1 & param_1[0x7c7];
  param_1[0x7c7] = uVar7;
  uStack_14 = param_1[0x7c6] - 1U & param_1[0x7c8] + uVar7;
  iVar6 = param_1[0x7c5];
  if (*(int *)(iVar6 + uStack_14 * 4) == 0) {
    uVar5 = FUN_01674e20(0x10);
    *(undefined4 *)(param_1[0x7c5] + uStack_14 * 4) = uVar5;
    iVar6 = param_1[0x7c5];
  }
  piVar2 = *(int **)(iVar6 + uStack_14 * 4);
  uStack_8 = 0xffffffff;
  *piVar2 = iVar3;
  piVar2[1] = iStack_30;
  piVar2[2] = iStack_2c;
  piVar2[3] = iStack_28;
  param_1[0x7c8] = param_1[0x7c8] + 1;
  *puVar1 = 0;
  param_1[0x7ce] = param_1[0x7ce] + *(int *)((int)puStack_18 + 0x30);
  cVar4 = (**(code **)(*param_1 + 0x124))();
  if ((cVar4 == '\0') && ((uint)(DAT_01d59ed0 * 0x100000) < (uint)param_1[0x7ce])) {
    FUN_0062b030(8);
    if ((uint)(DAT_01d59ed8 * 0x100000) < (uint)param_1[0x7ce]) {
      (**(code **)(*param_1 + 0xdc))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6856 ; VA 0x00625cd0 ; FUN_00625cd0 */

void __thiscall FUN_00625cd0(int param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  puVar2 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar2) {
    puVar2[4] = 0;
    puVar2[5] = 0;
    uVar3 = param_2[1];
    uVar4 = param_2[2];
    uVar5 = param_2[3];
    *puVar2 = *param_2;
    puVar2[1] = uVar3;
    puVar2[2] = uVar4;
    puVar2[3] = uVar5;
    *(undefined8 *)(puVar2 + 4) = *(undefined8 *)(param_2 + 4);
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
    uVar1 = *(undefined8 *)(param_2 + 6);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
    *(undefined8 *)(puVar2 + 6) = uVar1;
    return;
  }
  FUN_00603540(puVar2,param_2);
  return;
}



/* FUNCTION 6857 ; VA 0x00625d30 ; FUN_00625d30 */

void __thiscall FUN_00625d30(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar2) {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *puVar2 = *param_2;
    puVar2[1] = param_2[1];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
    return;
  }
  FUN_00603260(puVar2,param_2);
  return;
}



/* FUNCTION 6858 ; VA 0x00625d80 ; FUN_00625d80 */

void __fastcall FUN_00625d80(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  void **ppvVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  ushort *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  int *piVar12;
  undefined4 *puVar13;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  undefined4 *puStack_48;
  int *piStack_44;
  int *piStack_40;
  int iStack_3c;
  int *piStack_38;
  int iStack_34;
  int iStack_30;
  undefined uStack_29;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e92a;
  pvStack_10 = ExceptionList;
  if ((*(char *)(param_1 + 0x1ec8) == '\0') && (*(int *)(param_1 + 0x1eb8) != 0)) {
    ppvVar4 = &pvStack_10;
    iStack_18 = param_1;
    for (puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x1ec4) + *(int *)(param_1 + 0x1eb4) * 4);
        ExceptionList = ppvVar4, puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2) {
      iVar11 = puVar2[2];
      if ((iVar11 == 0) ||
         (iVar3 = *(int *)(iVar11 + 0xc), iVar6 = FUN_00ae6b40(), param_1 = iStack_18,
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        iVar11 = 0;
      }
      if ((*(char *)(param_1 + 0x1db8) == '\0') &&
         (cVar5 = FUN_006da1c0(param_1,iVar11), cVar5 != '\0')) {
        iVar11 = puVar2[7];
        if ((DAT_01ead114 == '\0') && (DAT_01d59e04 < iVar11)) {
          if (DAT_01ee420a != '\0') {
            FUN_01677520(DAT_01ee420a,"Limiting Animation Track, total tracks attempted %zu",iVar11)
            ;
          }
          FUN_0151f6f0(0xffffffff,0,0);
          uStack_8 = 0;
          FUN_0151f9c0("AnimationTracks",iVar11);
          uVar7 = DAT_01eace4c;
          uStack_54 = 0;
          uStack_50 = 0xf;
          auStack_64[0] = 0;
          FUN_005542c0("AnimationSpamSender",0x13);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_01520d20(auStack_64,uVar7,0);
          FUN_005507b0();
          DAT_01ead114 = '\x01';
          uStack_8 = 0xffffffff;
          FUN_0151f7f0();
        }
        iStack_30 = 0;
        if (puVar2[7] == 0) {
          puVar13 = (undefined4 *)0x0;
        }
        else {
          puVar13 = *(undefined4 **)(puVar2[10] + puVar2[6] * 4);
        }
        for (; param_1 = iStack_18, puVar13 != (undefined4 *)0x0; puVar13 = (undefined4 *)*puVar13)
        {
          piVar12 = puVar13 + 2;
          puStack_1c = puVar13 + 8;
          iStack_34 = FUN_01674e20(0xc);
          uStack_8 = 2;
          if (iStack_34 == 0) {
            uVar7 = 0;
          }
          else {
            uVar7 = FUN_00569550(7,&uStack_29);
          }
          uStack_8 = 0xffffffff;
          piStack_28 = (int *)0x0;
          piStack_24 = (int *)0x0;
          FUN_006047e0(uVar7,iStack_34);
          uStack_8 = 3;
          piStack_20 = (int *)*piStack_28;
          uVar7 = FUN_0088d190();
          *piStack_20 = uVar7;
          puStack_14 = (undefined4 *)FUN_00630cf0();
          iVar11 = piStack_20[1];
          puVar10 = piStack_20 + 2;
          if ((undefined4 *)iVar11 == puStack_14) {
            if (puVar10 != piVar12) {
              if (0xf < (uint)puVar13[7]) {
                piVar12 = (int *)*piVar12;
              }
              FUN_005542c0(piVar12,puVar13[6]);
            }
          }
          else {
            if (iVar11 != 0) {
              puStack_48 = puVar10;
              (**(code **)(iVar11 + 8))(puVar10);
              piStack_20[1] = 0;
            }
            FUN_0054ef60(piVar12);
            piStack_20[1] = (int)puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088daf0();
          *(undefined4 *)(iVar11 + 0xd0) = uVar7;
          puStack_14 = (undefined4 *)FUN_005c9ef0();
          iVar3 = *(int *)(iVar11 + 0xd4);
          if ((undefined4 *)iVar3 == puStack_14) {
            *(undefined *)(iVar11 + 0xd8) = *(undefined *)puStack_1c;
          }
          else {
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(iVar11 + 0xd8);
              *(undefined4 *)(iVar11 + 0xd4) = 0;
            }
            *(undefined *)(iVar11 + 0xd8) = *(undefined *)puStack_1c;
            *(undefined4 **)(iVar11 + 0xd4) = puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088c960();
          *(undefined4 *)(iVar11 + 0x1a0) = uVar7;
          puStack_14 = (undefined4 *)FUN_00630820();
          iVar3 = *(int *)(iVar11 + 0x1a4);
          if ((undefined4 *)iVar3 == puStack_14) {
            *(undefined4 *)(iVar11 + 0x1a8) = puStack_1c[1];
          }
          else {
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(iVar11 + 0x1a8);
              *(undefined4 *)(iVar11 + 0x1a4) = 0;
            }
            *(undefined4 *)(iVar11 + 0x1a8) = puStack_1c[1];
            *(undefined4 **)(iVar11 + 0x1a4) = puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088c960();
          *(undefined4 *)(iVar11 + 0x270) = uVar7;
          puStack_14 = (undefined4 *)FUN_00630820();
          iVar3 = *(int *)(iVar11 + 0x274);
          if ((undefined4 *)iVar3 == puStack_14) {
            *(undefined4 *)(iVar11 + 0x278) = puStack_1c[2];
          }
          else {
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(iVar11 + 0x278);
              *(undefined4 *)(iVar11 + 0x274) = 0;
            }
            *(undefined4 *)(iVar11 + 0x278) = puStack_1c[2];
            *(undefined4 **)(iVar11 + 0x274) = puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088c960();
          *(undefined4 *)(iVar11 + 0x340) = uVar7;
          puStack_14 = (undefined4 *)FUN_00630820();
          iVar3 = *(int *)(iVar11 + 0x344);
          if ((undefined4 *)iVar3 == puStack_14) {
            *(undefined4 *)(iVar11 + 0x348) = puStack_1c[3];
          }
          else {
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(iVar11 + 0x348);
              *(undefined4 *)(iVar11 + 0x344) = 0;
            }
            *(undefined4 *)(iVar11 + 0x348) = puStack_1c[3];
            *(undefined4 **)(iVar11 + 0x344) = puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088c960();
          *(undefined4 *)(iVar11 + 0x410) = uVar7;
          puStack_14 = (undefined4 *)FUN_00630820();
          iVar3 = *(int *)(iVar11 + 0x414);
          if ((undefined4 *)iVar3 == puStack_14) {
            *(undefined4 *)(iVar11 + 0x418) = puStack_1c[4];
          }
          else {
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(iVar11 + 0x418);
              *(undefined4 *)(iVar11 + 0x414) = 0;
            }
            *(undefined4 *)(iVar11 + 0x418) = puStack_1c[4];
            *(undefined4 **)(iVar11 + 0x414) = puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088c8c0();
          *(undefined4 *)(iVar11 + 0x4e0) = uVar7;
          puStack_14 = (undefined4 *)FUN_005c9cc0();
          puVar10 = *(undefined4 **)(iVar11 + 0x4e4);
          if (puVar10 == puStack_14) {
            *(undefined4 *)(iVar11 + 0x4e8) = puStack_1c[5];
          }
          else {
            if (puVar10 != (undefined4 *)0x0) {
              (*(code *)puVar10[2])(iVar11 + 0x4e8);
              *(undefined4 *)(iVar11 + 0x4e4) = 0;
            }
            *(undefined4 *)(iVar11 + 0x4e8) = puStack_1c[5];
            *(undefined4 **)(iVar11 + 0x4e4) = puStack_14;
          }
          if (piStack_24 != (int *)0x0) {
            LOCK();
            piStack_24[1] = piStack_24[1] + 1;
            UNLOCK();
          }
          piStack_44 = piStack_28;
          piStack_40 = piStack_24;
          piVar12 = (int *)puVar2[4];
          if (piVar12 != (int *)0x0) {
            LOCK();
            piVar12[1] = piVar12[1] + 1;
            UNLOCK();
            piVar12 = (int *)puVar2[4];
          }
          iStack_3c = puVar2[3];
          uStack_8 = CONCAT31(uStack_8._1_3_,5);
          piStack_38 = piVar12;
          piStack_20 = piVar12;
          iVar11 = FUN_006193f0(*(undefined4 *)(iStack_3c + 0xc));
          if (iVar11 != 0) {
            puStack_14 = *(undefined4 **)(*(int *)(iStack_18 + 0x19f4) + 0x58);
            puVar8 = (ushort *)FUN_0061d780(&DAT_021291e0);
            piVar12 = piStack_20;
            if (puVar8 != (ushort *)0x0) {
              puStack_14 = *(undefined4 **)(*(int *)(iStack_18 + 0x19f4) + 0x70);
              if ((uint)*puVar8 <
                  (uint)((*(int *)(*(int *)(iStack_18 + 0x19f4) + 0x74) - (int)puStack_14) / 0x14))
              {
                piStack_20 = (int *)((int)puStack_14 + (uint)*puVar8 * 0x14);
              }
              else {
                piStack_20 = (int *)0x0;
              }
              puVar10 = *(undefined4 **)(iStack_18 + 0x195c);
              puVar9 = *(undefined4 **)*puVar10;
              puStack_4c = puVar10;
              if (puVar9 == (undefined4 *)0x0) {
                puVar9 = (undefined4 *)FUN_00621d50();
              }
              else {
                *(undefined4 *)*puVar10 = *puVar9;
              }
              *puVar9 = puVar10;
              puStack_14 = puVar9 + 1;
              uStack_8._0_1_ = 6;
              if (puStack_14 == (undefined4 *)0x0) {
                uVar7 = 0;
              }
              else {
                uVar7 = FUN_006f71c0(iStack_18,&iStack_3c,&DAT_021291e0,piStack_20,&piStack_44);
              }
              uStack_8 = CONCAT31(uStack_8._1_3_,5);
              FUN_006b1f50(uVar7);
              piVar12 = piStack_38;
            }
          }
          if (piVar12 != (int *)0x0) {
            LOCK();
            iVar11 = piVar12[1] + -1;
            piVar12[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piVar12)();
              LOCK();
              iVar11 = piVar12[2] + -1;
              piVar12[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piVar12 + 4))();
              }
            }
          }
          piVar12 = piStack_40;
          if (piStack_40 != (int *)0x0) {
            LOCK();
            iVar11 = piStack_40[1] + -1;
            piStack_40[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piStack_40)();
              LOCK();
              piVar1 = piVar12 + 2;
              iVar11 = *piVar1 + -1;
              *piVar1 = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piVar12 + 4))();
              }
            }
          }
          piVar12 = piStack_24;
          iStack_30 = iStack_30 + 1;
          uStack_8 = 0xffffffff;
          if (DAT_01d59e04 <= iStack_30) {
            param_1 = iStack_18;
            if (piStack_24 != (int *)0x0) {
              LOCK();
              iVar11 = piStack_24[1] + -1;
              piStack_24[1] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)*piStack_24)();
                LOCK();
                iVar11 = piVar12[2] + -1;
                piVar12[2] = iVar11;
                UNLOCK();
                param_1 = iStack_18;
                if (iVar11 == 0) {
                  (**(code **)(*piVar12 + 4))();
                  param_1 = iStack_18;
                }
              }
            }
            break;
          }
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar11 = piStack_24[1] + -1;
            piStack_24[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piStack_24)();
              LOCK();
              iVar11 = piVar12[2] + -1;
              piVar12[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piVar12 + 4))();
              }
            }
          }
        }
      }
      ppvVar4 = (void **)ExceptionList;
    }
    puStack_4c = (undefined4 *)FUN_01674e20(0x58);
    uStack_8 = 7;
    if (puStack_4c == (undefined4 *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_00703220(param_1,0xe,0);
    }
    uStack_8 = 0xffffffff;
    FUN_006b1f50(uVar7);
    if (*(int *)(param_1 + 0x1eb8) != 0) {
      FUN_0061ad50(*(int *)(param_1 + 0x1ec4) + *(int *)(param_1 + 0x1eb4) * 4,0);
      puVar13 = *(undefined4 **)(param_1 + 0x1ec4);
      puVar2 = puVar13 + *(int *)(param_1 + 0x1eb4);
      for (; puVar13 != puVar2; puVar13 = puVar13 + 1) {
        *puVar13 = 0;
      }
    }
    *(undefined *)(iStack_18 + 0x1ec8) = 1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6859 ; VA 0x00626490 ; FUN_00626490 */

void FUN_00626490(void)

{
  return;
}



/* FUNCTION 6860 ; VA 0x006264a0 ; FUN_006264a0 */

bool FUN_006264a0(int param_1,int param_2,char param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined8 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dce8;
  pvStack_10 = ExceptionList;
  if (param_3 == '\0') {
    iVar4 = 1;
  }
  else {
    iVar4 = *(int *)(param_1 + 0xe28) + -200;
    if (iVar4 < 1) {
      iVar4 = 0;
    }
  }
  iVar2 = param_1 + 0xf10;
  if (*(int *)(param_1 + 0x6c) == 0) {
    iVar2 = 0;
  }
  if (iVar2 == 0) {
    iVar3 = 0;
  }
  else if (param_3 == '\0') {
    iVar4 = iVar4 - *(int *)(iVar2 + 0x98 + param_2 * 4);
    iVar3 = 0;
    if (-1 < iVar4) {
      iVar3 = iVar4;
    }
  }
  else {
    iVar3 = (int)((double)iVar4 - *(double *)(iVar2 + 0xa8 + param_2 * 8));
    if ((DAT_01d5b598 != '\0') && (iVar3 < 0)) {
      iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
      ExceptionList = &pvStack_10;
      if ((*(int *)(iVar1 + 0x34) < DAT_01ead0f0) &&
         (ExceptionList = &pvStack_10, FUN_016f3809(), DAT_01ead0f0 == -1)) {
        uStack_8 = 0;
        uVar5 = FUN_0152da50();
        DAT_01ead0ec = (undefined4)((ulonglong)uVar5 >> 0x20);
        DAT_01ead0e8 = (undefined4)uVar5;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01ead0f0);
      }
      FUN_0152d740(DAT_01ead0e8,DAT_01ead0ec,"Insufficient buffer to serialize data");
      if ((*(int *)(iVar1 + 0x34) < DAT_01ead100) && (FUN_016f3809(), DAT_01ead100 == -1)) {
        uStack_8 = 1;
        uVar5 = FUN_0152da50();
        DAT_01ead0fc = (undefined4)((ulonglong)uVar5 >> 0x20);
        DAT_01ead0f8 = (undefined4)uVar5;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01ead100);
      }
      FUN_0152d760(DAT_01ead0f8,DAT_01ead0fc,
                   "Buffer Requested : %d bytes - Data already in buffers : %f bytes",iVar4,
                   *(undefined8 *)(iVar2 + 0xa8 + param_2 * 8));
    }
    if (iVar3 < 1) {
      iVar3 = 0;
    }
  }
  ExceptionList = pvStack_10;
  return 0 < iVar3;
}



/* FUNCTION 6861 ; VA 0x00626680 ; FUN_00626680 */

void __thiscall FUN_00626680(int param_1,double *param_2)

{
  double in_XMM0_Qa;
  
  FUN_016f3fe0();
  *param_2 = in_XMM0_Qa / DAT_018c0d70 - *(double *)(param_1 + 0x38a0);
  return;
}



/* FUNCTION 6862 ; VA 0x006266b0 ; FUN_006266b0 */

uint __thiscall FUN_006266b0(int param_1,int param_2,byte *param_3,undefined *param_4)

{
  float fVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  byte bVar7;
  uint uVar8;
  float10 fVar9;
  undefined auStack_c [4];
  int iStack_8;
  
  uVar8 = 0;
  *param_4 = 0;
  iStack_8 = param_1;
  if (param_2 != 0) {
    iVar2 = *(int *)(param_2 + 0xc);
    iVar4 = FUN_00add460();
    param_1 = iStack_8;
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) {
      iVar2 = *(int *)(param_2 + 0xc);
      iVar4 = FUN_00b12040();
      param_1 = iStack_8;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        cVar3 = FUN_00618e60(0x3f800000);
        uVar8 = 2;
        *param_4 = cVar3 == '\0';
      }
    }
    else {
      puVar6 = (undefined4 *)(iStack_8 + 0x1988);
      if ((NAN(*(float *)(iStack_8 + 0x1998)) == (*(float *)(iStack_8 + 0x1998) == 0.0)) &&
         (NAN(*(float *)(iStack_8 + 0x1994)) == (*(float *)(iStack_8 + 0x1994) == 0.0))) {
        fVar9 = (float10)FUN_0061f160();
        fVar1 = (float)((float10)1 + fVar9);
        if (*(float *)(param_1 + 0x1994) <= fVar1 && fVar1 != *(float *)(param_1 + 0x1994)) {
          uVar8 = 1;
          *param_4 = 1;
          goto LAB_006267b9;
        }
        *(float *)(param_1 + 0x1990) = fVar1;
        puVar5 = (undefined4 *)FUN_016830f0(auStack_c);
        *puVar6 = *puVar5;
        *(undefined4 *)(param_1 + 0x198c) = puVar5[1];
      }
      uVar8 = 1;
      *param_4 = 0;
    }
  }
LAB_006267b9:
  if ((NAN(*(float *)(param_1 + 0x1980)) == (*(float *)(param_1 + 0x1980) == 0.0)) &&
     (NAN(*(float *)(param_1 + 0x197c)) == (*(float *)(param_1 + 0x197c) == 0.0))) {
    fVar9 = (float10)FUN_0061f160();
    fVar1 = (float)((float10)1 + fVar9);
    if (*(float *)(param_1 + 0x197c) <= fVar1 && fVar1 != *(float *)(param_1 + 0x197c)) {
      bVar7 = 1;
      goto LAB_0062681b;
    }
    *(float *)(param_1 + 0x1978) = fVar1;
    puVar6 = (undefined4 *)FUN_016830f0(auStack_c);
    *(undefined4 *)(param_1 + 0x1970) = *puVar6;
    *(undefined4 *)(param_1 + 0x1974) = puVar6[1];
  }
  bVar7 = 0;
LAB_0062681b:
  *param_3 = bVar7;
  return (uint)bVar7 << 2 | uVar8;
}



/* FUNCTION 6863 ; VA 0x00626840 ; FUN_00626840 */

void FUN_00626840(void)

{
  FUN_016f3ec0();
  return;
}



/* FUNCTION 6864 ; VA 0x00626870 ; FUN_00626870 */

/* WARNING: Type propagation algorithm not settling */

void __thiscall FUN_00626870(int *param_1,int param_2,int *param_3,int *param_4,char *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  undefined4 uVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  bool bVar9;
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int aiStack_24 [3];
  undefined2 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_4;
  iVar8 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e950;
  pvStack_10 = ExceptionList;
  uStack_14 = *(undefined4 *)(param_2 + 0x20);
  piVar4 = param_4;
  if (0xf < (uint)param_4[5]) {
    piVar4 = (int *)*param_4;
  }
  ExceptionList = &pvStack_10;
  cVar3 = FUN_006abe60(piVar4,0x10);
  if (cVar3 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("malformed shared string dictionary, md5 ended early, entry starts at %u",uStack_14
                );
  }
  cVar3 = FUN_006abe60((int)&param_2 + 3,1);
  if (cVar3 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("malformed shared string dictionary, marker ended early, entry starts at %u",
                 uStack_14);
  }
  if (param_2._3_1_ == '\x01') {
    FUN_0061de50(&param_4,piVar1);
    if (param_4 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("New string with sender id used unknown echo sender id");
    }
    iVar8 = param_4[8];
    LOCK();
    piVar4 = (int *)(iVar8 + 0x28);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
    param_4 = (int *)*param_3;
    *param_3 = iVar8;
    FUN_0056cd30();
  }
  else {
    if (param_2._3_1_ != '\0') {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Unknown new shared string format marker %d",param_2._3_1_);
    }
    if (*param_5 == '\0') {
      *param_5 = '\x01';
      cVar3 = (**(code **)(*param_1 + 0xd4))();
      if (cVar3 != '\0') {
        cVar3 = (**(code **)(*param_1 + 0x11c))();
        if (cVar3 == '\0') {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Game server cannot accept new shared strings from clients");
        }
      }
    }
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = 0;
    uStack_8 = 0;
    FUN_006ab8e0(auStack_3c,iVar8);
    uVar5 = FUN_00a33be0(auStack_3c);
    FUN_00613ff0(uVar5);
    FUN_0056cd30();
    FUN_00a33fb0(aiStack_24);
    piVar4 = piVar1;
    if (0xf < (uint)piVar1[5]) {
      piVar4 = (int *)*piVar1;
    }
    piVar6 = aiStack_24;
    uVar7 = 0xc;
    do {
      if (*piVar6 != *piVar4) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Invalid shared string data");
      }
      piVar6 = piVar6 + 1;
      piVar4 = piVar4 + 1;
      bVar9 = 3 < uVar7;
      uVar7 = uVar7 - 4;
    } while (bVar9);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  iVar8 = (int)param_1 + *(byte *)(param_1 + 0xdec) + 0x37b1;
  param_5 = (char *)FUN_005702d0(piVar1);
  FUN_00562fc0(&param_4,param_5,piVar1,-(uint)(iVar8 != 0) & iVar8 + 1U);
  if (param_4 == (int *)0x0) {
    aiStack_24[2] = 0;
    uStack_18 = 0;
    aiStack_24[1] = -(uint)(param_1 != (int *)0xffffc84d) & (uint)(param_1 + 0xded);
    uStack_8 = 1;
    FUN_00619cd0();
    iVar2 = aiStack_24[2];
    FUN_0054ef60(piVar1);
    iVar8 = *param_3;
    *(int *)(iVar2 + 0x20) = iVar8;
    LOCK();
    piVar4 = (int *)(iVar8 + 0x28);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
    uStack_18._1_1_ = '\x01';
    FUN_0062b610(param_1[0xdee] + 1);
    FUN_005c5550(&param_3,aiStack_24 + 1,param_5);
    iVar8 = aiStack_24[2];
    if (aiStack_24[2] != 0) {
      if (uStack_18._1_1_ != '\0') {
        FUN_00605eb0(aiStack_24[1],aiStack_24[2] + 8);
      }
      FUN_01674ea0(iVar8,0x24);
    }
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Shared string receiver dictionary got duplicate entry");
}



/* FUNCTION 6865 ; VA 0x00626b10 ; FUN_00626b10 */

void __thiscall FUN_00626b10(int *param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined auStack_38 [24];
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e970;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_2 + 0x18);
  if ((iVar1 != 0) &&
     (ExceptionList = &pvStack_10, cVar2 = (**(code **)(*param_1 + 0x108))(), cVar2 != '\0')) {
    if (((param_1[0xe02] & 2U) != 0) &&
       (iVar3 = (**(code **)(*param_1 + 0x168))(iVar1,param_2 + 0x20,param_2 + 0x108), iVar3 == 1))
    {
      ExceptionList = pvStack_10;
      return;
    }
    FUN_0054ef60(param_2 + 0x20);
    iVar3 = param_1[0x7ba];
    param_1 = param_1 + 0x7ba;
    *param_1 = (int)auStack_38;
    uStack_8 = 1;
    iStack_20 = iVar1;
    piStack_1c = param_1;
    iStack_18 = iVar3;
    FUN_0056a440(param_2 + 0x38);
    FUN_008a5b60(param_2 + 0x20);
    *param_1 = iVar3;
    FUN_005507b0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6866 ; VA 0x00626bf0 ; FUN_00626bf0 */

void __thiscall FUN_00626bf0(int *param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_2 + 0x18);
  if (iVar1 != 0) {
    iVar3 = (**(code **)(*param_1 + 0x144))
                      (iVar1,*(undefined4 *)(param_2 + 0x20),*(undefined2 *)(param_2 + 0x24),
                       param_2 + 0x100);
    if (iVar3 != 1) {
      cVar2 = (**(code **)(*param_1 + 0x104))(iVar1,*(undefined4 *)(param_2 + 0x20));
      if (cVar2 != '\0') {
        (**(code **)(*param_1 + 0x130))(param_2,*(undefined4 *)(param_2 + 0x20),iVar1);
      }
    }
  }
  return;
}



/* FUNCTION 6867 ; VA 0x00626c60 ; FUN_00626c60 */

void FUN_00626c60(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  undefined uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  undefined4 *puStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e9a8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x18) != 0) {
    puVar2 = *(undefined4 **)(*(int *)(*(int *)(param_1 + 0x18) + 0xc) + 0x1dc);
    uVar6 = DAT_01edf5b0;
    if (puVar2 != (undefined4 *)0x0) {
      uVar6 = *puVar2;
    }
    ExceptionList = &pvStack_10;
    uVar6 = FUN_01675290(uVar6);
    iStack_8 = 0;
    if (*(undefined4 **)(param_1 + 0x20) == &DAT_0211a3d8) {
      piVar7 = *(int **)(param_1 + 0x1c);
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        piVar7 = *(int **)(param_1 + 0x1c);
      }
      iStack_18 = *(int *)(param_1 + 0x18);
      iVar3 = *(int *)(param_1 + 0x28);
      iStack_8._0_1_ = 1;
      iStack_8._1_3_ = 0;
      iVar8 = FUN_00888530();
      if (iVar3 == iVar8) {
        FUN_006f6d10();
        iStack_8._0_1_ = 2;
        FUN_006f6dc0(piStack_14);
      }
      else {
        iVar3 = *(int *)(param_1 + 0x28);
        iVar8 = FUN_0088cdc0();
        piVar4 = piStack_14;
        if (iVar3 != iVar8) {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Variant cast failed");
        }
        piVar9 = (int *)(param_1 + 0x30);
        if (*(int *)(param_1 + 0x2c) == 0) {
          piVar9 = (int *)0x0;
        }
        if (piVar9[1] != 0) {
          LOCK();
          piVar1 = (int *)(piVar9[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        iVar3 = *piVar9;
        iStack_8._0_1_ = 3;
        uVar5 = (undefined)iStack_8;
        iStack_8._0_1_ = 3;
        if (((iVar3 != *(int *)(iStack_18 + 0x34)) &&
            (iVar8 = (**(code **)(*piStack_14 + 0x148))(iStack_18,iVar3),
            uVar5 = (undefined)iStack_8, iVar8 != 1)) && (*(char *)(iStack_18 + 0x22) == '\0')) {
          puStack_1c = &DAT_0211a3d8;
          iVar8 = piVar4[0x7b9];
          piVar4[0x7b9] = (int)&puStack_1c;
          iStack_8._0_1_ = 4;
          FUN_008a65e0(iVar3,0);
          piStack_14[0x7b9] = iVar8;
          uVar5 = (undefined)iStack_8;
        }
        iStack_8._0_1_ = uVar5;
        FUN_00550b30();
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar3 = piVar7[1] + -1;
        piVar7[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar3 = piVar7[2] + -1;
          piVar7[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
    else {
      iVar3 = *(int *)(param_1 + 0x28);
      iVar8 = FUN_00888530();
      if (((iVar3 == iVar8) && (*(int *)(param_1 + 0xf8) != -1)) &&
         (*(char *)(piStack_14 + 0x76e) == '\0')) {
        FUN_006e0360(*(undefined4 *)(*(int *)(param_1 + 0x18) + 0x18),
                     *(undefined4 *)(*(int *)(param_1 + 0x18) + 0x1c),
                     *(undefined4 *)(param_1 + 0xf8),*(undefined4 *)(param_1 + 0xfc),
                     *(undefined4 *)(param_1 + 0x20));
      }
      FUN_0062bbf0(*(undefined4 *)(param_1 + 0x20),param_1 + 0x28,0,*(undefined4 *)(param_1 + 0x18))
      ;
    }
    if ((((piStack_14[0xe03] & 1U) != 0) && (*(undefined **)(param_1 + 0x20) == &DAT_0211a44c)) &&
       (*(int *)(piStack_14[0x76d] + 0x1c) == 0)) {
      FUN_006d8410(param_1 + 0x18);
    }
    iStack_8 = 5;
    FUN_01675290(uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6868 ; VA 0x00626ec0 ; FUN_00626ec0 */

void __thiscall FUN_00626ec0(int *param_1,int param_2)

{
  (**(code **)(*param_1 + 0x19c))(*(undefined4 *)(param_2 + 0x2c),*(undefined4 *)(param_2 + 0x30));
  (**(code **)(*param_1 + 0x1a4))(param_2);
  return;
}



/* FUNCTION 6869 ; VA 0x00626f00 ; FUN_00626f00 */

bool __thiscall FUN_00626f00(int *param_1,int param_2)

{
  int *piVar1;
  undefined *puVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  
  iVar3 = param_2;
  if (DAT_01d59fb8 != '\0') {
    iVar5 = FUN_016f3cd0();
    iVar6 = *(int *)(iVar3 + 0x1c);
    if (iVar6 != 0) {
      param_2 = iVar6;
      if ((uint)((param_1[0x613] - param_1[0x612] >> 3) * 3) >> 2 <= (uint)param_1[0x615]) {
        FUN_006285a0();
      }
      iVar6 = FUN_00620bc0(&param_2);
      *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + iVar5;
      param_1[0x61a] = param_1[0x61a] + iVar5;
    }
  }
  piVar1 = *(int **)(iVar3 + 0x14);
  cVar4 = (**(code **)(*param_1 + 0x100))(piVar1,*(undefined4 *)(iVar3 + 0x1c));
  if ((cVar4 != '\0') && (piVar1 != (int *)0x0)) {
    if (((DAT_01d5a0b0 != '\0') || (DAT_01d5a0b8 != '\0')) &&
       (cVar4 = FUN_00618ed0(iVar3), cVar4 != '\0')) {
      return true;
    }
    puVar2 = *(undefined **)(iVar3 + 0x1c);
    if (((param_1[0xe03] & 1U) == 0) || ((puVar2 != &DAT_0212d228 && (puVar2 != &DAT_0212d270)))) {
      (**(code **)(*piVar1 + 4))(puVar2,iVar3 + 0x20,param_1 + 0x25);
    }
    cVar4 = (**(code **)(**(int **)(iVar3 + 0x1c) + 0xc))();
    if (cVar4 != '\0') {
      (**(code **)(*param_1 + 0x128))(iVar3);
    }
    if (((param_1[0x67c] != 0) || (0 < DAT_01eace58)) &&
       (cVar4 = (**(code **)(*param_1 + 300))(piVar1,*(undefined4 *)(iVar3 + 0x1c),iVar3 + 0x20),
       param_1[0x67c] != 0)) {
      return cVar4 == '\0';
    }
  }
  return true;
}



/* FUNCTION 6870 ; VA 0x00627050 ; FUN_00627050 */

undefined __thiscall FUN_00627050(int *param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e9c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ee420f != '\0') {
    iVar2 = param_2[8];
    ExceptionList = &pvStack_10;
    uVar4 = (**(code **)(*param_2 + 4))();
    FUN_01677490(DAT_01ee420f,"readItem %d, bitStream %p, offset %d bytes",param_3,uVar4,iVar2);
  }
  (**(code **)(*param_1 + 0x194))(&piStack_18,param_2,param_3);
  uStack_8 = 0;
  if (piStack_18 == (int *)0x0) {
    uVar3 = 1;
  }
  else {
    if ((((DAT_01d5a058 != '\0') && (iVar2 = piStack_18[1], iVar2 != 5)) && (iVar2 != 6)) &&
       ((iVar2 != 9 && (iVar2 != 0x12)))) {
      piVar1 = (int *)(param_1[0xe22] + iVar2 * 4);
      *piVar1 = *piVar1 + piStack_18[2];
    }
    uVar3 = (**(code **)(*piStack_18 + 4))(param_1);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 6871 ; VA 0x00627150 ; FUN_00627150 */

int __thiscall FUN_00627150(int *param_1,int param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  double *pdVar8;
  int *piVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int *piVar13;
  undefined auStack_178 [24];
  undefined auStack_160 [24];
  undefined auStack_148 [24];
  undefined auStack_130 [24];
  undefined auStack_118 [24];
  undefined auStack_100 [24];
  int aiStack_e8 [5];
  uint uStack_d4;
  int aiStack_d0 [5];
  uint uStack_bc;
  int aiStack_b8 [5];
  uint uStack_a4;
  undefined auStack_a0 [8];
  undefined auStack_98 [8];
  undefined auStack_90 [8];
  undefined auStack_88 [8];
  uint auStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  double dStack_60;
  int *piStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  int aiStack_48 [2];
  int *piStack_40;
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  int iStack_2c;
  uint uStack_28;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = -1;
  puStack_c = &LAB_0179ea5b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  if (DAT_01ee420f != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee420f,"Replicator::readJoinDataItem() : Procsssing JoinDataItem",0);
  }
  FUN_016827e0(&dStack_60);
  iVar11 = 0;
  iStack_14 = 0;
  piVar9 = *(int **)(param_2 + 0x10);
  piStack_58 = *(int **)(param_2 + 0x14);
  piStack_1c = piVar9;
  if (piVar9 == piStack_58) {
LAB_00627b29:
    if (*(char *)(param_1[0x7dc] + 0x5a) != '\0') {
      iVar11 = FUN_016f3cd0();
      param_1[0x603] = param_1[0x603] + iVar11;
    }
    if (DAT_01eace54 != 0) {
      pdVar8 = (double *)FUN_016827e0(auStack_98);
      param_1[0xe0b] = (int)((float)((*pdVar8 - dStack_60) * DAT_018c0d70) + (float)param_1[0xe0b]);
    }
    if (DAT_01ee420f != '\0') {
      iVar11 = param_1[0xdf4];
      pdVar8 = (double *)FUN_016827e0(auStack_a0);
      FUN_01677520(DAT_01ee420f,
                   "Replicator::readJoinDataItem() took %fms : orderedChildrenWaitingForTheirTurn size=%d"
                   ,(double)(float)((*pdVar8 - dStack_60) * DAT_018c0d70),iVar11);
    }
    ExceptionList = pvStack_10;
    return iStack_14;
  }
LAB_006271c0:
  piStack_1c = piVar9;
  if (DAT_01ee420f != '\0') {
    puVar2 = (undefined4 *)FUN_009c9510(aiStack_b8);
    iStack_8 = 0;
    if (0xf < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    puVar3 = (undefined4 *)FUN_009c9510(auStack_80);
    iStack_8._0_1_ = 1;
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    FUN_01677490(DAT_01ee420f,
                 "Replicator::readJoinDataItem() :  will process newInstanceItem [%s->%s]",puVar3,
                 puVar2,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_6c) {
      if ((0xfff < uStack_6c + 1) && (0x1f < (auStack_80[0] - *(int *)(auStack_80[0] - 4)) - 4))
      goto LAB_00627c34;
      FUN_01674ea0();
    }
    uStack_70 = 0;
    uStack_6c = 0xf;
    auStack_80[0] = auStack_80[0] & 0xffffff00;
    iStack_8 = -1;
    iVar11 = iStack_14;
    if (0xf < uStack_a4) {
      if ((0xfff < uStack_a4 + 1) && (0x1f < (aiStack_b8[0] - *(int *)(aiStack_b8[0] + -4)) - 4U))
      goto LAB_00627c34;
      FUN_01674ea0();
      iVar11 = iStack_14;
    }
  }
  cVar1 = FUN_0061f540();
  piVar13 = piVar9;
  if (cVar1 != '\0') {
    if (DAT_01d5a090 == '\0') {
      cVar1 = (**(code **)(*param_1 + 0x11c))();
      if (cVar1 == '\0') {
        uVar4 = param_1[0xe02] & 0x10;
      }
      else {
        uVar4 = param_1[0xe02] & 0x20;
      }
      if (uVar4 == 0) {
        if (DAT_01d5a098 == '\0') {
          FUN_0061de90();
          param_1 = piStack_18;
          piVar13 = piStack_1c;
          if ((piVar9[0xd] == 0) ||
             ((iStack_50 != 0 && ((uint)piVar9[0xd] <= *(uint *)(iStack_50 + 0x14))))) {
            iStack_14 = FUN_006248b0(piStack_1c);
            iStack_14 = iVar11 + iStack_14;
            iVar11 = iStack_14;
          }
          else {
            if (DAT_01ee420f != '\0') {
              puVar2 = (undefined4 *)FUN_009c9510(auStack_148);
              iStack_8 = 0xb;
              if (0xf < (uint)puVar2[5]) {
                puVar2 = (undefined4 *)*puVar2;
              }
              puVar3 = (undefined4 *)FUN_009c9510(auStack_130);
              iStack_8 = CONCAT31(iStack_8._1_3_,0xc);
              if (0xf < (uint)puVar3[5]) {
                puVar3 = (undefined4 *)*puVar3;
              }
              FUN_01677490(DAT_01ee420f,
                           "Replicator::readJoinDataItem() :  pushing child [%s] to parent orderedChildrenWaitingForTheirTurn[%s]"
                           ,puVar3,puVar2,0);
              FUN_005507b0();
              iStack_8 = -1;
              FUN_005507b0();
            }
            piVar13 = piStack_1c;
            FUN_006c1d20(piStack_18);
            param_1 = piStack_18;
            FUN_00614570(piVar9 + 9);
            FUN_006062a0(auStack_90,piVar9 + 0xd,piVar9 + 0xd,piVar13);
            iVar11 = iStack_14;
          }
        }
        else {
          iVar11 = FUN_00614570(piVar9 + 9);
          piVar5 = piStack_1c + 0x10;
          if (piStack_1c[0x10] == 0) {
            FUN_00621ac0();
          }
          param_1 = piStack_18;
          piVar13 = piStack_1c;
          if ((piStack_1c[0xd] == 0) ||
             ((*piVar5 != 0 && (*(int *)(iVar11 + 0xc) == piStack_1c[0xd])))) {
            iVar11 = FUN_006248b0(piStack_1c);
            iStack_14 = iStack_14 + iVar11;
            iVar11 = iStack_14;
          }
          else {
            if (DAT_01ee420f != '\0') {
              puVar2 = (undefined4 *)FUN_009c9510(auStack_118);
              piVar13 = piStack_1c;
              iStack_8 = 9;
              if (0xf < (uint)puVar2[5]) {
                puVar2 = (undefined4 *)*puVar2;
              }
              puVar3 = (undefined4 *)FUN_009c9510(auStack_100);
              iStack_8 = CONCAT31(iStack_8._1_3_,10);
              if (0xf < (uint)puVar3[5]) {
                puVar3 = (undefined4 *)*puVar3;
              }
              FUN_01677490(DAT_01ee420f,
                           "Replicator::readJoinDataItem() :  pushing child [%s] to parent orderedChildrenWaitingForTheirTurn[%s]"
                           ,puVar3,puVar2,0);
              FUN_005507b0();
              iStack_8 = -1;
              FUN_005507b0();
            }
            FUN_006c1d20(piStack_18);
            param_1 = piStack_18;
            FUN_00614570(piVar9 + 9);
            FUN_006062a0(auStack_88,piVar13 + 0xd,piVar13 + 0xd,piVar13);
            iVar11 = iStack_14;
          }
        }
        goto LAB_00627b17;
      }
    }
    if (*(int *)(piVar9[0xb] + 8) == 0) goto LAB_00627b17;
    uVar4 = *(uint *)(*(int *)(piVar9[0xb] + 8) + 0x1d4) >> 4;
    if ((((uVar4 & 1) == 0) && (*(byte *)((int)piVar9 + 0x49) == ((byte)uVar4 & 1))) &&
       ((piVar9[0x10] == 0 || (cVar1 = FUN_006d91e0(piVar9 + 0x10), cVar1 == '\0')))) {
      if (DAT_01ee420f != '\0') {
        puVar2 = (undefined4 *)FUN_009c9510(auStack_178);
        iStack_8 = 7;
        if (0xf < (uint)puVar2[5]) {
          puVar2 = (undefined4 *)*puVar2;
        }
        puVar3 = (undefined4 *)FUN_009c9510(auStack_160);
        iStack_8 = CONCAT31(iStack_8._1_3_,8);
        if (0xf < (uint)puVar3[5]) {
          puVar3 = (undefined4 *)*puVar3;
        }
        piVar5 = *(int **)(piVar9[0xe] + 0x28);
        if (0xf < (uint)piVar5[5]) {
          piVar5 = (int *)*piVar5;
        }
        FUN_01677490(DAT_01ee420f,
                     "Replicator::readJoinDataItem() : pushing child %s[%s] to parent childrenWaitingForTheirTurn[%s]"
                     ,piVar5,puVar3,puVar2);
        FUN_005507b0();
        iStack_8 = -1;
        FUN_005507b0();
      }
      FUN_006c1d20(param_1);
      iVar11 = FUN_006147d0(piVar9 + 9);
      if (*(int *)(iVar11 + 0x10) == *(int *)(iVar11 + 0xc)) {
        FUN_00603b20();
        iVar11 = iStack_14;
      }
      else {
        FUN_0060f060(piVar9);
        *(int *)(iVar11 + 0xc) = *(int *)(iVar11 + 0xc) + 0x58;
        iVar11 = iStack_14;
      }
      goto LAB_00627b17;
    }
    iStack_14 = iVar11 + 1;
    (**(code **)(*piVar9 + 4))(param_1);
    if (*(char *)(param_1[0x7dc] + 0x5a) != '\0') {
      FUN_006281f0();
    }
    piStack_40 = param_1 + 0xdf8;
    piVar9 = piVar9 + 7;
    iVar11 = (int)param_1 + *(byte *)(param_1 + 0xdf8) + 0x37e1;
    piStack_38 = piVar9;
    uVar6 = FUN_009c91f0(piVar9);
    FUN_00607110(aiStack_48,uVar6,piVar9,-(uint)(iVar11 != 0) & iVar11 + 1U);
    iVar7 = aiStack_48[0];
    iVar11 = iStack_14;
    param_1 = piStack_18;
    if (aiStack_48[0] == 0) goto LAB_00627b17;
    piStack_30 = (int *)0x0;
    iStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    iStack_20 = 0;
    piStack_30 = (int *)FUN_01674e20(8);
    *piStack_30 = 0;
    piStack_30[1] = 0;
    *piStack_30 = (int)&piStack_30;
    iVar11 = *(int *)(iVar7 + 0x10);
    iVar7 = *(int *)(iVar7 + 0x14);
    iStack_8 = 2;
    for (; iVar11 != iVar7; iVar11 = iVar11 + 0x58) {
      if (uStack_28 <= iStack_20 + 1U) {
        FUN_006178c0(1);
      }
      uStack_24 = uStack_24 & uStack_28 - 1;
      uVar4 = iStack_20 + uStack_24 & uStack_28 - 1;
      if (*(int *)(iStack_2c + uVar4 * 4) == 0) {
        uVar6 = FUN_01674e20(0x58);
        *(undefined4 *)(iStack_2c + uVar4 * 4) = uVar6;
      }
      FUN_0060f060(iVar11);
      iStack_20 = iStack_20 + 1;
    }
    if (DAT_01ee420f != '\0') {
      puVar2 = (undefined4 *)FUN_009c9510(aiStack_d0);
      iStack_8._0_1_ = 3;
      if (0xf < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      FUN_016774b0(DAT_01ee420f,
                   "Replicator::readJoinDataItem() : erasing parent childrenWaitingForTheirTurn[%s]"
                   ,puVar2);
      iStack_8 = CONCAT31(iStack_8._1_3_,2);
      if (0xf < uStack_bc) {
        if ((0xfff < uStack_bc + 1) && (0x1f < (aiStack_d0[0] - *(int *)(aiStack_d0[0] + -4)) - 4U))
        {
LAB_00627c34:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        FUN_01674ea0();
      }
    }
    FUN_0061d6c0();
    if (iStack_20 != 0) {
      do {
        piVar9 = piStack_30;
        if (piStack_30 != (int *)0x0) {
          piVar9 = (int *)*piStack_30;
        }
        piVar9 = *(int **)(piVar9[1] + (piVar9[2] - 1U & uStack_24) * 4);
        iVar11 = piStack_18[0x15];
        if (piVar9[9] == -1) {
          piVar9[0x10] = 0;
          piVar13 = (int *)piVar9[0x11];
          piVar9[0x11] = 0;
          if (piVar13 != (int *)0x0) {
            LOCK();
            iVar11 = piVar13[1] + -1;
            piVar13[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piVar13)();
              LOCK();
              iVar11 = piVar13[2] + -1;
              piVar13[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piVar13 + 4))();
              }
            }
          }
        }
        else {
          iStack_34 = iVar11 + 0x1c;
          iVar7 = FUN_016dee6d(iStack_34);
          if (iVar7 != 0) {
            FUN_016df3c9(iVar7);
          }
          iVar11 = iVar11 + 5 + (uint)*(byte *)(iVar11 + 4);
          iStack_8 = CONCAT31(iStack_8._1_3_,4);
          uVar6 = FUN_009c91f0(piVar9 + 9);
          FUN_00607110(&iStack_54,uVar6,piVar9 + 9,-(uint)(iVar11 != 0) & iVar11 + 1U);
          if (iStack_54 == 0) {
            piVar9[0x10] = 0;
            piVar13 = (int *)piVar9[0x11];
            piVar9[0x11] = 0;
          }
          else {
            iVar11 = *(int *)(iStack_54 + 0x14);
            iVar7 = 0;
            iVar10 = 0;
            piStack_38 = (int *)0x0;
            if (iVar11 != 0) {
              iVar12 = *(int *)(iVar11 + 4);
              piVar13 = (int *)(iVar11 + 4);
              if (iVar12 != 0) {
                do {
                  LOCK();
                  iVar11 = *piVar13;
                  if (iVar12 == iVar11) {
                    *piVar13 = iVar12 + 1;
                    iVar11 = iVar12;
                  }
                  UNLOCK();
                  if (iVar11 == iVar12) {
                    iVar7 = *(int *)(iStack_54 + 0x10);
                    iVar10 = *(int *)(iStack_54 + 0x14);
                    goto LAB_006278fa;
                  }
                  iVar12 = *piVar13;
                } while (iVar12 != 0);
                piVar9[0x10] = 0;
                piVar13 = (int *)piVar9[0x11];
                piVar9[0x11] = 0;
                goto LAB_00627916;
              }
            }
LAB_006278fa:
            piVar9[0x10] = iVar7;
            piVar13 = (int *)piVar9[0x11];
            piVar9[0x11] = iVar10;
          }
LAB_00627916:
          if (piVar13 != (int *)0x0) {
            LOCK();
            iVar11 = piVar13[1] + -1;
            piVar13[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piVar13)();
              LOCK();
              iVar11 = piVar13[2] + -1;
              piVar13[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piVar13 + 4))();
              }
            }
          }
          iStack_8 = CONCAT31(iStack_8._1_3_,5);
          iVar11 = FUN_016deec8(iStack_34);
          if (iVar11 != 0) {
            FUN_016df3c9(iVar11);
          }
          iStack_8 = CONCAT31(iStack_8._1_3_,2);
        }
        piVar13 = piStack_18;
        iStack_14 = iStack_14 + 1;
        (**(code **)(*piVar9 + 4))(piStack_18);
        if (*(char *)(piVar13[0x7dc] + 0x5a) != '\0') {
          FUN_006281f0();
        }
        piVar9 = piVar9 + 7;
        iVar11 = (int)piVar13 + *(byte *)(piVar13 + 0xdf8) + 0x37e1;
        piStack_38 = piVar9;
        uVar6 = FUN_009c91f0(piVar9);
        FUN_00607110(&iStack_4c,uVar6,piVar9,-(uint)(iVar11 != 0) & iVar11 + 1U);
        if (iStack_4c != 0) {
          iVar7 = *(int *)(iStack_4c + 0x14);
          for (iVar11 = *(int *)(iStack_4c + 0x10); iVar11 != iVar7; iVar11 = iVar11 + 0x58) {
            if (uStack_28 <= iStack_20 + 1U) {
              FUN_006178c0(1);
            }
            uStack_24 = uStack_24 & uStack_28 - 1;
            uVar4 = iStack_20 + uStack_24 & uStack_28 - 1;
            if (*(int *)(iStack_2c + uVar4 * 4) == 0) {
              uVar6 = FUN_01674e20(0x58);
              *(undefined4 *)(iStack_2c + uVar4 * 4) = uVar6;
            }
            FUN_0060f060(iVar11);
            iStack_20 = iStack_20 + 1;
          }
          if (DAT_01ee420f != '\0') {
            puVar2 = (undefined4 *)FUN_009c9510(aiStack_e8);
            iStack_8._0_1_ = 6;
            if (0xf < (uint)puVar2[5]) {
              puVar2 = (undefined4 *)*puVar2;
            }
            FUN_016774b0(DAT_01ee420f,
                         "Replicator::readJoinDataItem() : erasing parent childrenWaitingForTheirTurn[%s]"
                         ,puVar2);
            iStack_8 = CONCAT31(iStack_8._1_3_,2);
            if (0xf < uStack_d4) {
              if ((0xfff < uStack_d4 + 1) &&
                 (0x1f < (aiStack_e8[0] - *(int *)(aiStack_e8[0] + -4)) - 4U)) goto LAB_00627c34;
              FUN_01674ea0();
            }
          }
          FUN_0061d6c0();
        }
        (**(code **)**(undefined4 **)(iStack_2c + (uStack_28 - 1 & uStack_24) * 4))(0);
        iStack_20 = iStack_20 + -1;
        if (iStack_20 == 0) goto code_r0x00627aec;
        uStack_24 = uStack_24 + 1;
      } while( true );
    }
    goto LAB_00627aff;
  }
  if (*(int *)(piVar9[0xb] + 8) != 0) {
    iVar11 = iVar11 + 1;
    iStack_14 = iVar11;
    (**(code **)(*piVar9 + 4))(param_1);
    if (*(char *)(param_1[0x7dc] + 0x5a) != '\0') {
      FUN_006281f0();
    }
  }
  goto LAB_00627b17;
code_r0x00627aec:
  uStack_24 = 0;
LAB_00627aff:
  iStack_8 = -1;
  FUN_00611560();
  piVar13 = piStack_1c;
  iVar11 = iStack_14;
  param_1 = piStack_18;
LAB_00627b17:
  piVar9 = piVar13 + 0x16;
  piStack_1c = piVar9;
  if (piVar9 == piStack_58) goto LAB_00627b29;
  goto LAB_006271c0;
}



/* FUNCTION 6872 ; VA 0x00627c40 ; FUN_00627c40 */

int __thiscall FUN_00627c40(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int in_EAX;
  
  if (DAT_01ee420a != '\0') {
    in_EAX = FUN_016774b0(DAT_01ee420a,"Replicator:ReadMarker id(%d)",
                          *(undefined4 *)(param_2 + 0x10));
  }
  if (*(int *)(param_1 + 0x1f6c) != 0) {
    FUN_00703900();
    in_EAX = *(int *)(*(int *)(param_1 + 0x1f60) +
                     (*(uint *)(param_1 + 0x1f68) >> 1 & *(int *)(param_1 + 0x1f64) - 1U) * 4);
    piVar3 = *(int **)(in_EAX + 4 + (*(uint *)(param_1 + 0x1f68) & 1) * 8);
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar2 = *piVar1;
      in_EAX = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        in_EAX = (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          in_EAX = (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = (int *)(param_1 + 0x1f6c);
    *piVar3 = *piVar3 + -1;
    if (*piVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1f68) = 0;
      return in_EAX;
    }
    *(int *)(param_1 + 0x1f68) = *(int *)(param_1 + 0x1f68) + 1;
  }
  return in_EAX;
}



/* FUNCTION 6873 ; VA 0x00627d20 ; FUN_00627d20 */

void FUN_00627d20(undefined4 param_1,byte *param_2)

{
  byte bVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int *piVar8;
  int aiStack_44 [5];
  uint uStack_30;
  uint uStack_28;
  int *piStack_24;
  int *piStack_20;
  uint uStack_1c;
  undefined auStack_18 [7];
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ea80;
  pvStack_10 = ExceptionList;
  uStack_11 = 0;
  ExceptionList = &pvStack_10;
  FUN_00565660(0x10,0);
  uStack_8 = 0;
  iVar5 = *(int *)(param_2 + 8);
  do {
    if (iVar5 == 0) {
      if (0xf < uStack_30) {
        uVar6 = uStack_30 + 1;
        iVar5 = aiStack_44[0];
        if (0xfff < uVar6) {
          iVar5 = *(int *)(aiStack_44[0] + -4);
          uVar6 = uStack_30 + 0x24;
          if (0x1f < (aiStack_44[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar5,uVar6);
      }
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00a33c70();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00626870(param_1,auStack_18,aiStack_44,&uStack_11);
    bVar1 = *param_2;
    uVar4 = FUN_005702d0(aiStack_44);
    FUN_00562fc0(&piStack_20,uVar4,aiStack_44,
                 -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) & (uint)(param_2 + bVar1 + 1 + 1));
    piVar3 = piStack_20;
    if (piStack_20 == (int *)0x0) {
      FUN_00a33fa0();
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Received new shared string %s that does not match deferred dictionary",uVar4);
    }
    iVar5 = piStack_20[9];
    for (iVar7 = piStack_20[8]; iVar7 != iVar5; iVar7 = iVar7 + 0x10) {
      FUN_006b74d0(auStack_18);
    }
    piStack_24 = (int *)*piVar3;
    piVar2 = *(int **)(*(int *)(param_2 + 0x14) + ((uint)piVar3[1] % *(uint *)(param_2 + 4)) * 4);
    for (piVar8 = (int *)*piVar2; piVar8 != piVar3; piVar8 = (int *)*piVar8) {
      piVar2 = piVar8;
    }
    uStack_28 = -(uint)(param_2 != (byte *)0xfffffffd) & (uint)(param_2 + 4);
    uStack_1c = (uint)piVar3[1] % *(uint *)(param_2 + 4);
    do {
      *piVar2 = *piVar8;
      FUN_00605e10(uStack_28,piVar8 + 2);
      FUN_01674ea0(piVar8,0x2c);
      *(int *)(param_2 + 8) = *(int *)(param_2 + 8) + -1;
      uVar6 = uStack_1c;
      if (*piVar2 == 0) {
LAB_00627e59:
        if (*(int **)(*(int *)(param_2 + 0x14) + uStack_1c * 4) == piVar2) {
          *(undefined4 *)(*(int *)(param_2 + 0x14) + uStack_1c * 4) = 0;
        }
      }
      else {
        uVar6 = *(uint *)(*piVar2 + 4) % *(uint *)(param_2 + 4);
        if (uStack_1c != uVar6) {
          *(int **)(*(int *)(param_2 + 0x14) + uVar6 * 4) = piVar2;
          goto LAB_00627e59;
        }
      }
      piVar8 = (int *)*piVar2;
      uStack_1c = uVar6;
    } while (piVar8 != piStack_24);
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_0056cd30();
    iVar5 = *(int *)(param_2 + 8);
  } while( true );
}



/* FUNCTION 6874 ; VA 0x00627f10 ; FUN_00627f10 */

void __thiscall FUN_00627f10(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  byte bVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined auStack_24 [24];
  undefined8 uStack_c;
  
  iVar1 = *(int *)(param_1 + 0x19f4);
  bVar4 = FUN_006abe40();
  uVar7 = (uint)(bVar4 >> 1);
  if ((uint)((*(int *)(iVar1 + 0x84) - *(int *)(iVar1 + 0x80)) / 0x18) <= uVar7) {
    uVar6 = FUN_0058c070();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("KnownPrefixIndex %d larger than preshared prefix count %zu",uVar7,uVar6);
  }
  if ((bVar4 & 1) != 0) {
    uStack_c = 0;
    FUN_006ab860(&uStack_c);
    puVar5 = (undefined4 *)(*(int *)(iVar1 + 0x80) + uVar7 * 0x18);
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    puVar5 = (undefined4 *)
             FUN_01675640(auStack_24,"%s%lld",puVar5,(undefined4)uStack_c,uStack_c._4_4_);
    if (param_3 != puVar5) {
      FUN_005507b0();
      uVar6 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *param_3 = *puVar5;
      param_3[1] = uVar6;
      param_3[2] = uVar2;
      param_3[3] = uVar3;
      *(undefined8 *)(param_3 + 4) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    FUN_005507b0();
    return;
  }
  FUN_006ab9d0(param_3,*(int *)(iVar1 + 0x80) + uVar7 * 0x18,param_2);
  return;
}



/* FUNCTION 6875 ; VA 0x00628020 ; FUN_00628020 */

undefined4 __thiscall FUN_00628020(int param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  
  puVar2 = param_3;
  puVar3 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar3 = (undefined4 *)*param_3;
  }
  FUN_006abe60(puVar3,0x10);
  iVar5 = param_1 + 0x37b1 + (uint)*(byte *)(param_1 + 0x37b0);
  uVar4 = FUN_005702d0(puVar2);
  FUN_00562fc0(&param_3,uVar4,puVar2,-(uint)(iVar5 != 0) & iVar5 + 1U);
  if (param_3 != (undefined4 *)0x0) {
    iVar5 = param_3[8];
    LOCK();
    piVar1 = (int *)(iVar5 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    param_3 = (undefined4 *)*param_4;
    *param_4 = iVar5;
    FUN_0056cd30();
    return 1;
  }
  return 0;
}



/* FUNCTION 6876 ; VA 0x00628029 ; FUN_00628029 */

undefined4 __fastcall FUN_00628029(int param_1)

{
  int *piVar1;
  undefined4 in_EAX;
  undefined4 uVar2;
  undefined4 *unaff_EBX;
  int unaff_EBP;
  int iVar3;
  
  if (0xf < (uint)unaff_EBX[5]) {
    in_EAX = *unaff_EBX;
  }
  FUN_006abe60(in_EAX,0x10);
  iVar3 = param_1 + 0x37b1 + (uint)*(byte *)(param_1 + 0x37b0);
  uVar2 = FUN_005702d0(unaff_EBX);
  FUN_00562fc0(unaff_EBP + 0xc,uVar2,unaff_EBX,-(uint)(iVar3 != 0) & iVar3 + 1U);
  if (*(int *)(unaff_EBP + 0xc) != 0) {
    iVar3 = *(int *)(*(int *)(unaff_EBP + 0xc) + 0x20);
    *(int *)(unaff_EBP + 0xc) = iVar3;
    LOCK();
    piVar1 = (int *)(iVar3 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    uVar2 = **(undefined4 **)(unaff_EBP + 0x10);
    **(undefined4 **)(unaff_EBP + 0x10) = *(undefined4 *)(unaff_EBP + 0xc);
    *(undefined4 *)(unaff_EBP + 0xc) = uVar2;
    FUN_0056cd30();
    return 1;
  }
  return 0;
}



/* FUNCTION 6877 ; VA 0x006280b0 ; FUN_006280b0 */

void __thiscall FUN_006280b0(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 in_stack_ffffffb0;
  undefined4 in_stack_ffffffb4;
  undefined4 in_stack_ffffffb8;
  undefined4 in_stack_ffffffbc;
  undefined4 in_stack_ffffffc0;
  undefined4 in_stack_ffffffc4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ea98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01255470(9,0,0,0);
  FUN_01255490(in_stack_ffffffb0,in_stack_ffffffb4,in_stack_ffffffb8,in_stack_ffffffbc,
               in_stack_ffffffc0,in_stack_ffffffc4);
  piVar2 = param_2;
  uStack_8 = 0;
  if (DAT_01ee420f != '\0') {
    iVar1 = param_2[8];
    uVar4 = (**(code **)(*param_2 + 4))();
    FUN_01677490(DAT_01ee420f,"receiveData bitstream %p, read offset %d bytes",uVar4,iVar1,0);
  }
  FUN_006b2050(piVar2,&param_2);
  while (param_2 != (int *)0x0) {
    param_1[0x42c] = (int)param_2;
    cVar3 = (**(code **)(*param_1 + 400))(piVar2,param_2);
    if (cVar3 == '\0') goto LAB_00628178;
    FUN_006b2050(piVar2,&param_2);
  }
  if (param_1[0x67c] != 0) {
    uVar4 = (**(code **)(*piVar2 + 8))();
    FUN_006ab690(uVar4);
  }
LAB_00628178:
  FUN_01255500();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6878 ; VA 0x006281a0 ; FUN_006281a0 */

void __thiscall FUN_006281a0(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    if ((uint)((*(int *)(param_1 + 0x34) - *(int *)(param_1 + 0x30) >> 3) * 3) >> 2 <=
        *(uint *)(param_1 + 0x3c)) {
      FUN_006285a0();
    }
    iVar1 = FUN_00620bc0(&param_2);
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + param_3;
    *(int *)(param_1 + 0x50) = *(int *)(param_1 + 0x50) + param_3;
  }
  return;
}



/* FUNCTION 6879 ; VA 0x006281f0 ; FUN_006281f0 */

uint __thiscall FUN_006281f0(int *param_1,uint *param_2,float param_3)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  float fStack_20;
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179eab8;
  pvStack_10 = ExceptionList;
  uVar7 = *param_2;
  if (uVar7 != 0) {
    param_2 = *(uint **)(uVar7 + 0xc);
    ExceptionList = &pvStack_10;
    piStack_14 = param_1;
    if ((uint)((param_1[4] - param_1[3] >> 3) * 3) >> 2 <= (uint)param_1[6]) {
      ExceptionList = &pvStack_10;
      FUN_006285a0();
    }
    iVar6 = FUN_00620bc0(&param_2);
    piVar2 = piStack_14;
    *(float *)(iVar6 + 4) = *(float *)(iVar6 + 4) + param_3;
    piStack_18 = (int *)puVar1[1];
    uStack_8 = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
      piStack_18 = (int *)puVar1[1];
    }
    uStack_1c = *puVar1;
    iVar6 = *param_1;
    iVar3 = param_1[1];
    fStack_20 = param_3;
    uVar7 = (iVar3 - iVar6) / 0xc;
    uVar8 = uVar7;
    while (uVar5 = uVar8, 0 < (int)uVar5) {
      uVar8 = (int)uVar5 >> 1;
      if (param_3 < *(float *)(iVar6 + uVar8 * 0xc)) {
        iVar6 = iVar6 + uVar8 * 0xc + 0xc;
        uVar8 = uVar5 + (-1 - uVar8);
      }
    }
    param_2 = (uint *)uVar7;
    param_3 = (float)iVar3;
    if (uVar7 < DAT_01d59f38) {
      uVar7 = FUN_006060a0(&param_2,iVar6,&fStack_20);
    }
    else if (iVar6 != iVar3) {
      FUN_006060a0(&param_2,iVar6,&fStack_20);
      uVar7 = piVar2[1];
      piVar4 = *(int **)(uVar7 - 4);
      if (piVar4 != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piVar4 + 1);
        uVar8 = *puVar1;
        uVar7 = *puVar1;
        *puVar1 = uVar8 - 1;
        UNLOCK();
        if (uVar8 - 1 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          puVar1 = (uint *)(piVar4 + 2);
          uVar8 = *puVar1;
          uVar7 = *puVar1;
          *puVar1 = uVar8 - 1;
          UNLOCK();
          if (uVar8 - 1 == 0) {
            uVar7 = (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar2 = piVar2 + 1;
      *piVar2 = *piVar2 + -0xc;
    }
    piVar2 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      puVar1 = (uint *)(piStack_18 + 1);
      uVar8 = *puVar1;
      uVar7 = *puVar1;
      *puVar1 = uVar8 - 1;
      UNLOCK();
      if (uVar8 - 1 == 0) {
        uVar7 = (**(code **)*piStack_18)();
        LOCK();
        piVar4 = piVar2 + 2;
        iVar6 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          uVar7 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 6880 ; VA 0x00628370 ; FUN_00628370 */

void __thiscall FUN_00628370(int *param_1,int param_2,float param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    if ((uint)((param_1[1] - *param_1 >> 3) * 3) >> 2 <= (uint)param_1[3]) {
      FUN_006285a0();
    }
    iVar1 = FUN_00620bc0(&param_2);
    *(float *)(iVar1 + 4) = *(float *)(iVar1 + 4) + param_3;
    param_1[0x12] = (int)((float)param_1[0x12] + param_3);
  }
  return;
}



/* FUNCTION 6881 ; VA 0x006283d0 ; FUN_006283d0 */

void __thiscall FUN_006283d0(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    if ((uint)((*(int *)(param_1 + 0x1c) - *(int *)(param_1 + 0x18) >> 3) * 3) >> 2 <=
        *(uint *)(param_1 + 0x24)) {
      FUN_006285a0();
    }
    iVar1 = FUN_00620bc0(&param_2);
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + param_3;
    *(int *)(param_1 + 0x4c) = *(int *)(param_1 + 0x4c) + param_3;
  }
  return;
}



/* FUNCTION 6882 ; VA 0x00628420 ; FUN_00628420 */

void __thiscall FUN_00628420(int *param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_1c [4];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179eae0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_2 + 0x14) == 0) {
    ExceptionList = &pvStack_10;
    piStack_14 = param_1;
    iVar4 = FUN_016dee6d(param_1 + 7);
    if (iVar4 != 0) {
      FUN_016df3c9(iVar4);
    }
    uStack_8 = 0;
    if (*(int *)(param_2 + 0x14) == 0) {
      puVar5 = (undefined4 *)FUN_0060e0c0(auStack_1c,param_2);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iVar4 = FUN_006149c0(param_2 + 0x18);
      uVar1 = *puVar5;
      uVar2 = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      *(undefined4 *)(iVar4 + 8) = uVar1;
      piVar3 = *(int **)(iVar4 + 0xc);
      *(undefined4 *)(iVar4 + 0xc) = uVar2;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piVar3 = piStack_18 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      if (piStack_14 != (int *)0x0) {
        LOCK();
        *piStack_14 = *piStack_14 + 1;
        UNLOCK();
      }
      *(int **)(param_2 + 0x14) = piStack_14;
      FUN_00611620();
    }
    uStack_8 = 2;
    iVar4 = FUN_016deec8(param_1 + 7);
    if (iVar4 != 0) {
      FUN_016df3c9(iVar4);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6883 ; VA 0x00628540 ; FUN_00628540 */

void FUN_00628540(undefined8 *param_1,short *param_2)

{
  short sVar1;
  byte bVar2;
  
  sVar1 = param_2[2];
  bVar2 = DAT_01d59f88 & 0x1f;
  *param_1 = CONCAT44((int)param_2[1] >> (DAT_01d59f84 & 0x1f),
                      (int)*param_2 >> (DAT_01d59f80 & 0x1f));
  *(int *)(param_1 + 1) = (int)sVar1 >> bVar2;
  return;
}



/* FUNCTION 6884 ; VA 0x00628590 ; FUN_00628590 */

void FUN_00628590(void)

{
  FUN_00628420();
  return;
}



/* FUNCTION 6885 ; VA 0x006285a0 ; FUN_006285a0 */

void __fastcall FUN_006285a0(int *param_1)

{
  int iVar1;
  uint uVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  uint uStack_10;
  uint *puStack_c;
  undefined uStack_5;
  
  if (*param_1 == param_1[1]) {
    iVar5 = 0x10;
  }
  else {
    iVar5 = (param_1[1] - *param_1 >> 3) * 2;
  }
  iStack_18 = param_1[4];
  uStack_14 = 0;
  piStack_1c = param_1;
  FUN_0060e8c0(iVar5,&iStack_18,&uStack_5);
  uStack_14 = param_1[4];
  iVar5 = *param_1;
  uStack_10 = 0;
  if (param_1[1] - iVar5 >> 3 != 0) {
    do {
      uVar4 = *(uint *)(iVar5 + uStack_10 * 8);
      puStack_c = (uint *)(iVar5 + uStack_10 * 8);
      if (uVar4 != param_1[4]) {
        uVar2 = (uVar4 >> 3) + uVar4;
        uVar7 = (iStack_30 - iStack_34 >> 3) - 1;
        uVar6 = 0;
        do {
          uVar2 = uVar2 & uVar7;
          puVar3 = (uint *)(iStack_34 + uVar2 * 8);
          if (*puVar3 == uStack_14) {
            *puVar3 = uVar4;
            uVar4 = *puStack_c;
            goto LAB_0062864b;
          }
          if (*puVar3 == uVar4) goto LAB_0062864b;
          uVar2 = uVar2 + 1 + uVar6;
          uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar7);
        puVar3 = (uint *)0x0;
LAB_0062864b:
        *puVar3 = uVar4;
        puVar3[1] = puStack_c[1];
        iVar5 = *piStack_1c;
        param_1 = piStack_1c;
      }
      uStack_10 = uStack_10 + 1;
    } while (uStack_10 < (uint)(param_1[1] - iVar5 >> 3));
  }
  if (param_1 != &iStack_34) {
    *param_1 = iStack_34;
    param_1[1] = iStack_30;
    iVar1 = param_1[2];
    param_1[2] = iStack_2c;
    iStack_2c = iVar1;
    iStack_34 = iVar5;
  }
  if (iStack_34 != 0) {
    uVar4 = iStack_2c - iStack_34 & 0xfffffff8;
    iVar5 = iStack_34;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_34 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_34 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  return;
}



/* FUNCTION 6886 ; VA 0x006286d0 ; FUN_006286d0 */

void __fastcall FUN_006286d0(int *param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint *puVar7;
  uint uVar8;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int *piStack_14;
  uint uStack_10;
  uint uStack_c;
  undefined uStack_5;
  
  if (*param_1 == param_1[1]) {
    iVar6 = 0x10;
  }
  else {
    iVar6 = (param_1[1] - *param_1 >> 2) * 2;
  }
  uStack_c = param_1[4];
  piStack_14 = param_1;
  FUN_0060e810(iVar6,&uStack_c,&uStack_5);
  uStack_10 = param_1[4];
  iVar6 = *param_1;
  uStack_c = 0;
  if (param_1[1] - iVar6 >> 2 != 0) {
    do {
      uVar5 = *(uint *)(iVar6 + uStack_c * 4);
      if (uVar5 != param_1[4]) {
        uVar3 = (uVar5 >> 3) + uVar5;
        uVar8 = (iStack_28 - iStack_2c >> 2) - 1;
        uVar4 = 0;
        do {
          uVar3 = uVar3 & uVar8;
          uVar1 = *(uint *)(iStack_2c + uVar3 * 4);
          puVar7 = (uint *)(iStack_2c + uVar3 * 4);
          if (uVar1 == uStack_10) {
            *puVar7 = uVar5;
            goto LAB_00628766;
          }
          if (uVar1 == uVar5) goto LAB_00628766;
          uVar3 = uVar3 + 1 + uVar4;
          uVar4 = uVar4 + 1;
        } while (uVar4 <= uVar8);
        puVar7 = (uint *)0x0;
LAB_00628766:
        *puVar7 = uVar5;
        iVar6 = *piStack_14;
        param_1 = piStack_14;
      }
      uStack_c = uStack_c + 1;
    } while (uStack_c < (uint)(param_1[1] - iVar6 >> 2));
  }
  if (param_1 != &iStack_2c) {
    *param_1 = iStack_2c;
    param_1[1] = iStack_28;
    iVar2 = param_1[2];
    param_1[2] = iStack_24;
    iStack_24 = iVar2;
    iStack_2c = iVar6;
  }
  if (iStack_2c != 0) {
    uVar5 = iStack_24 - iStack_2c & 0xfffffffc;
    iVar6 = iStack_2c;
    if (0xfff < uVar5) {
      iVar6 = *(int *)(iStack_2c + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iStack_2c - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar5);
  }
  return;
}



/* FUNCTION 6887 ; VA 0x006287e0 ; FUN_006287e0 */

undefined4 __thiscall FUN_006287e0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (((param_2 != 0) &&
      (iVar2 = *(int *)(param_2 + 0xc), iVar1 = FUN_00913630(),
      (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
      (uint)*(ushort *)(iVar1 + 0x1da))) && (*(int *)(param_1 + 0x1dc0) == *(int *)(param_2 + 0x34))
     ) {
    return 1;
  }
  iVar2 = FUN_0097bf90(param_2);
  if (param_2 == iVar2) {
    return 1;
  }
  if ((param_2 != 0) &&
     (iVar2 = *(int *)(param_2 + 0xc), iVar1 = FUN_00aeecb0(),
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
     (uint)*(ushort *)(iVar1 + 0x1da))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 6888 ; VA 0x00628870 ; FUN_00628870 */

int FUN_00628870(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179eaf8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_0151dac0(param_1,param_2,0,0);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 6889 ; VA 0x00628910 ; FUN_00628910 */

int FUN_00628910(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179eaf8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_0151dac0(param_1,param_2,1,0);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 6890 ; VA 0x006289b0 ; FUN_006289b0 */

void __thiscall FUN_006289b0(int param_1,uint *param_2,char *param_3)

{
  char cVar1;
  bool bVar2;
  undefined4 uVar3;
  void *pvVar4;
  char *pcVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar4 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  uVar6 = *param_2;
  bVar2 = uVar6 <= *(uint *)(param_1 + 0x3ae0);
  ExceptionList = &pvStack_10;
  if (!bVar2) {
    ExceptionList = &pvStack_10;
    *(uint *)(param_1 + 0x3ae0) = uVar6;
  }
  if (*(uint *)(param_1 + 0x3adc) < param_2[1]) {
    *(uint *)(param_1 + 0x3adc) = param_2[1];
  }
  else if (bVar2) {
    ExceptionList = pvVar4;
    return;
  }
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  FUN_0151fa60("VariantCount",param_2[1]);
  FUN_0151fa60("TotalStringDataSize",*param_2);
  uVar3 = DAT_01eace70;
  if (0xf < *(uint *)(param_3 + 0x14)) {
    param_3 = *(char **)param_3;
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar5 = param_3;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_3,(int)pcVar5 - (int)(param_3 + 1));
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01520d20(auStack_28,uVar3,0);
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    uVar6 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6891 ; VA 0x00628ae0 ; FUN_00628ae0 */

int __thiscall FUN_00628ae0(int *param_1,undefined4 param_2,int *param_3,undefined8 param_4)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  float10 fVar6;
  undefined uVar7;
  undefined auStack_d4 [112];
  undefined auStack_64 [4];
  int *piStack_60;
  double dStack_5c;
  double dStack_54;
  double dStack_4c;
  int iStack_44;
  int *piStack_40;
  int iStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179eb5e;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00587490();
  iVar5 = iStack_44;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_44 != 0) {
    fVar6 = (float10)FUN_0151daa0();
    iStack_18 = iVar5 + 0xc;
    dStack_4c = (double)fVar6;
    dStack_54 = DAT_018ce330;
    dStack_5c = DAT_018ce330;
    FUN_005789c0(&DAT_01ea8a80,&LAB_0055d5a0);
    FUN_00560dc0();
    piStack_14 = (int *)FUN_008aa140();
    if (*piStack_14 == 0) {
      uVar3 = FUN_0093f210();
      piVar4 = (int *)FUN_008a9ba0(auStack_64,uVar3);
      iVar2 = *piVar4;
      iVar5 = piVar4[1];
      *piVar4 = 0;
      piVar4[1] = 0;
      *piStack_14 = iVar2;
      piVar4 = (int *)piStack_14[1];
      piStack_14[1] = iVar5;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar2 = piVar4[1] + -1;
        piVar4[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar2 = piVar4[2] + -1;
          piVar4[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_44;
      if (piStack_60 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_60[1] + -1;
        piStack_60[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_60)();
          LOCK();
          iVar2 = piStack_60[2] + -1;
          piStack_60[2] = iVar2;
          UNLOCK();
          iVar5 = iStack_44;
          if (iVar2 == 0) {
            (**(code **)(*piStack_60 + 4))();
            iVar5 = iStack_44;
          }
        }
      }
    }
    iVar2 = *piStack_14;
    if (iVar2 != 0) {
      dStack_54 = *(double *)(iVar2 + 0x270) + *(double *)(iVar2 + 0x278);
      dStack_5c = dStack_4c - dStack_54;
    }
    iStack_3c = 0;
    iStack_38 = 0;
    uStack_34 = 0;
    uStack_8._0_1_ = 2;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uVar7 = 0;
    FUN_005542c0("NetworkJoin_SnapShotTime",0x18);
    FUN_0061e3e0(&iStack_3c,auStack_d4,uVar7);
    uVar7 = 0;
    FUN_005542c0("NetworkJoin_FrameTime",0x15);
    FUN_0061e3e0(&iStack_3c,auStack_d4,uVar7);
    uVar7 = 0;
    FUN_005542c0("NetworkJoin_LuaTime",0x13);
    FUN_0061e3e0(&iStack_3c,auStack_d4,uVar7);
    uVar7 = 0;
    FUN_005542c0("NetworkJoin_CppTime",0x13);
    FUN_0061e3e0(&iStack_3c,auStack_d4,uVar7);
    if (iStack_3c != iStack_38) {
      FUN_00874d70(&iStack_3c,0);
    }
    if (DAT_01d5a008 == '\0') {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8._0_1_ = 6;
      if (param_1[0x770] == 0) {
        iVar2 = -1;
      }
      else {
        piVar4 = *(int **)(param_1[0x770] + 0xb8);
        iVar2 = piVar4[1] - *piVar4 >> 3;
      }
      FUN_0151f9c0("PlayerCount",iVar2);
      piVar4 = *(int **)(iVar5 + 0x43c);
      FUN_0151fbb0("PlaceId",*piVar4 - (int)piVar4,piVar4[1] - (int)piVar4);
      FUN_0151f9c0("DataCenterId",*(undefined4 *)(iVar5 + 0x44c));
      FUN_0151fcf0("StreamingEnabled",*(undefined *)(param_1 + 0xdfe));
      FUN_0151fb00("JoinTimeSnapShotTime",param_4);
      FUN_0151fb00("JoinTimeFrameTime",dStack_4c);
      FUN_0151fb00("JoinTimeLuaTime",dStack_54);
      FUN_0151fb00("JoinTimeCppTime",dStack_5c);
      FUN_0151f950("GameId",&DAT_01d79c68);
      cVar1 = (**(code **)(*param_1 + 0x11c))();
      uVar3 = DAT_01eace50;
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      if (cVar1 == '\0') {
        FUN_005542c0("ReplicatorJoinTimeSnapShotTime",0x1e);
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
      }
      else {
        FUN_005542c0("ReplicatorJoinTimeSnapShotTimeTeamCreate",0x28);
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
      }
      FUN_01520d20(auStack_30,uVar3,0);
      FUN_005507b0();
      FUN_0151f7f0();
    }
    else {
      if (param_1[0x770] == 0) {
        iVar2 = -1;
      }
      else {
        piVar4 = *(int **)(param_1[0x770] + 0xb8);
        iVar2 = piVar4[1] - *piVar4 >> 3;
      }
      FUN_0151f9c0("PlayerCount",iVar2);
      piVar4 = *(int **)(iVar5 + 0x43c);
      FUN_0151fbb0("PlaceId",*piVar4 - (int)piVar4,piVar4[1] - (int)piVar4);
      FUN_0151f9c0("DataCenterId",*(undefined4 *)(iVar5 + 0x44c));
      FUN_0151fcf0("StreamingEnabled",*(undefined *)(param_1 + 0xdfe));
      FUN_0151f950("GameId",&DAT_01d79c68);
      cVar1 = (**(code **)(*param_1 + 0x11c))();
      uVar3 = DAT_01eace50;
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      if (cVar1 == '\0') {
        FUN_005542c0("ReplicatorJoinTimeSnapShotTime",0x1e);
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
      }
      else {
        FUN_005542c0("ReplicatorJoinTimeSnapShotTimeTeamCreate",0x28);
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
      }
      FUN_01520d20(auStack_30,uVar3,0);
      FUN_005507b0();
    }
    FUN_0151f7f0();
    iVar2 = FUN_0056d3e0();
  }
  if (piStack_40 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_40 + 1;
    iVar5 = *piVar4;
    iVar2 = *piVar4;
    *piVar4 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      piVar4 = piStack_40 + 2;
      iVar5 = *piVar4;
      iVar2 = *piVar4;
      *piVar4 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar2 = (**(code **)(*piStack_40 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar4 = param_3 + 2;
    iVar5 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      iVar2 = (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 6892 ; VA 0x006290b0 ; FUN_006290b0 */

void FUN_006290b0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  undefined8 in_stack_00000020;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179eb80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  uStack_18 = in_stack_00000020;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piVar1 = *(int **)(param_1 + 4);
  if (*(int **)(param_1 + 8) == piVar1) {
    FUN_00603540(piVar1,&iStack_30);
    if (0xf < uStack_1c) {
      uVar3 = uStack_1c + 1;
      iVar2 = iStack_30;
      if (0xfff < uVar3) {
        iVar2 = *(int *)(iStack_30 + -4);
        uVar3 = uStack_1c + 0x24;
        if (0x1f < (iStack_30 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
  }
  else {
    *piVar1 = iStack_30;
    piVar1[1] = iStack_2c;
    piVar1[2] = iStack_28;
    piVar1[3] = iStack_24;
    *(ulonglong *)(piVar1 + 4) = CONCAT44(uStack_1c,uStack_20);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
    *(undefined8 *)(piVar1 + 6) = in_stack_00000020;
  }
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6893 ; VA 0x006291a0 ; FUN_006291a0 */

/* WARNING: Type propagation algorithm not settling */

void __fastcall FUN_006291a0(int *param_1)

{
  undefined uVar1;
  char cVar2;
  short sVar3;
  int iVar4;
  undefined4 *******pppppppuVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint *puVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  undefined8 uVar12;
  double dVar13;
  char *pcVar14;
  undefined *puStack_1e0;
  char *pcStack_1dc;
  undefined4 *******pppppppuStack_1d8;
  undefined4 *******pppppppuStack_1d4;
  undefined4 *******pppppppuStack_1d0;
  undefined *puStack_1cc;
  undefined8 uStack_1c8;
  undefined4 *******pppppppuStack_1c0;
  undefined8 uStack_1bc;
  undefined8 uStack_1b4;
  undefined auStack_1a4 [56];
  undefined auStack_16c [24];
  undefined auStack_154 [24];
  undefined auStack_13c [24];
  undefined4 ******ppppppuStack_124;
  uint uStack_120;
  uint uStack_11c;
  uint uStack_118;
  undefined8 uStack_114;
  ulonglong uStack_10c;
  undefined auStack_104 [56];
  undefined auStack_cc [24];
  undefined auStack_b4 [24];
  undefined8 uStack_9c;
  undefined8 uStack_94;
  undefined auStack_8c [16];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 *******pppppppuStack_74;
  undefined4 ******ppppppuStack_70;
  undefined4 ******ppppppuStack_6c;
  undefined4 ******ppppppuStack_68;
  undefined8 uStack_64;
  undefined4 *******pppppppuStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  undefined8 uStack_4c;
  char cStack_41;
  uint uStack_40;
  undefined4 *******apppppppuStack_3c [4];
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee2b;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uStack_1b4 = (double)CONCAT44(0x6291d3,(undefined4)uStack_1b4);
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)(*param_1 + 0xb4))();
  if (iVar4 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  iStack_24 = 0;
  iStack_20 = 0;
  uStack_1c = 0;
  uStack_1b4 = 0.0;
  uStack_8 = 0;
  uStack_1bc = 0xffffffff00629208;
  FUN_0151f6f0();
  uStack_1b4 = 1.28152525854628e-316;
  uStack_8._0_1_ = 1;
  iStack_2c = 0;
  uStack_28 = 0xf;
  apppppppuStack_3c[0] = (undefined4 *******)((uint)apppppppuStack_3c[0] & 0xffffff00);
  uStack_1bc = CONCAT44(0x62922d,(undefined4)uStack_1bc);
  FUN_005542c0();
  uStack_64 = 0xf00000000;
  pppppppuStack_74 = (undefined4 *******)((uint)pppppppuStack_74 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_1b4 = (double)CONCAT44(0x62924f,(undefined4)uStack_1b4);
  cVar2 = (**(code **)(*param_1 + 0xd4))();
  if (cVar2 == '\0') {
    uStack_1b4 = 2.75987852562027e-313;
    uStack_1bc = CONCAT44(0x629288,(undefined4)uStack_1bc);
    FUN_005542c0();
    uStack_1b4 = (double)CONCAT44(auStack_cc,0x629294);
    pppppppuVar5 = (undefined4 *******)FUN_01530500();
  }
  else {
    uStack_1b4 = 2.75987852720128e-313;
    uStack_1bc = CONCAT44(0x629262,(undefined4)uStack_1bc);
    FUN_005542c0();
    uStack_1b4 = (double)CONCAT44(0x62926e,(undefined4)uStack_1b4);
    (**(code **)(*param_1 + 0xb4))();
    uStack_1b4 = (double)CONCAT44(auStack_cc,0x62927c);
    pppppppuVar5 = (undefined4 *******)FUN_00927520();
  }
  if (&pppppppuStack_74 != (undefined4 ********)pppppppuVar5) {
    uStack_1b4 = (double)CONCAT44(0x6292a7,(undefined4)uStack_1b4);
    FUN_005507b0();
    pppppppuStack_74 = (undefined4 *******)*pppppppuVar5;
    ppppppuStack_70 = pppppppuVar5[1];
    ppppppuStack_6c = pppppppuVar5[2];
    ppppppuStack_68 = pppppppuVar5[3];
    uStack_64 = *(undefined8 *)(pppppppuVar5 + 4);
    pppppppuVar5[4] = (undefined4 ******)0x0;
    pppppppuVar5[5] = (undefined4 ******)0xf;
    *(undefined *)pppppppuVar5 = 0;
  }
  uStack_1b4 = (double)CONCAT44(0x6292d4,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4 = (double)param_1[0x38a];
  uStack_8._0_1_ = 4;
  uStack_4c._0_4_ = 0;
  uStack_4c._4_4_ = 0xf;
  pppppppuStack_5c = (undefined4 *******)((uint)pppppppuStack_5c & 0xffffff00);
  uStack_40 = 2;
  uStack_1bc = CONCAT44(iStack_2c + 0xe,0x629314);
  FUN_0058a190();
  pppppppuVar5 = apppppppuStack_3c;
  if (0xf < uStack_28) {
    pppppppuVar5 = apppppppuStack_3c[0];
  }
  uStack_1bc = CONCAT44(iStack_2c,pppppppuVar5);
  pppppppuStack_1c0 = (undefined4 *******)0x62932b;
  FUN_00554150();
  uStack_1bc = 0xe018cd3cc;
  pppppppuStack_1c0 = (undefined4 *******)0x62933a;
  FUN_00554150();
  uStack_18 = CONCAT44(&puStack_1cc,(undefined4)uStack_18);
  pppppppuStack_1d0 = (undefined4 *******)(int)uStack_64;
  pppppppuStack_1d4 = &pppppppuStack_74;
  if (0xf < uStack_64._4_4_) {
    pppppppuStack_1d4 = pppppppuStack_74;
  }
  pppppppuStack_1d8 = (undefined4 *******)0x629359;
  puVar6 = (undefined4 *)FUN_00554150();
  uStack_40 = 6;
  puStack_1cc = (undefined *)*puVar6;
  uStack_1c8 = *(double *)(puVar6 + 1);
  pppppppuStack_1c0 = (undefined4 *******)puVar6[3];
  uStack_1bc = *(undefined8 *)(puVar6 + 4);
  puVar6[4] = 0;
  puVar6[5] = 0xf;
  *(undefined *)puVar6 = 0;
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62939a;
  FUN_006290b0();
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_4c._4_4_) {
    uVar10 = uStack_4c._4_4_ + 1;
    pppppppuVar5 = pppppppuStack_5c;
    if (0xfff < uVar10) {
      pppppppuVar5 = (undefined4 *******)pppppppuStack_5c[-1];
      uVar10 = uStack_4c._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppppppuStack_5c + (-4 - (int)pppppppuVar5))) {
        uStack_1b4 = (double)CONCAT44(0x62b01b,(undefined4)uStack_1b4);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_1b4 = (double)CONCAT44(uVar10,pppppppuVar5);
    uStack_1bc = CONCAT44(0x6293cf,(undefined4)uStack_1bc);
    FUN_01674ea0();
  }
  uStack_1b4 = (double)param_1[0x38a];
  uStack_8._0_1_ = 5;
  uStack_4c._0_4_ = 0;
  uStack_4c._4_4_ = 0xf;
  pppppppuStack_5c = (undefined4 *******)((uint)pppppppuStack_5c & 0xffffff00);
  uStack_40 = 0xc;
  uStack_1bc = CONCAT44(iStack_2c + 0xd,0x629412);
  FUN_0058a190();
  pppppppuVar5 = apppppppuStack_3c;
  if (0xf < uStack_28) {
    pppppppuVar5 = apppppppuStack_3c[0];
  }
  uStack_1bc = CONCAT44(iStack_2c,pppppppuVar5);
  pppppppuStack_1c0 = (undefined4 *******)0x629429;
  FUN_00554150();
  uStack_1bc = 0xd018cd3dc;
  pppppppuStack_1c0 = (undefined4 *******)0x629438;
  FUN_00554150();
  uStack_18 = CONCAT44(&puStack_1cc,(undefined4)uStack_18);
  pppppppuStack_1d0 = (undefined4 *******)DAT_01d7a8c8;
  pppppppuStack_1d4 = (undefined4 *******)&DAT_01d7a8b8;
  if (0xf < DAT_01d7a8cc) {
    pppppppuStack_1d4 = (undefined4 *******)DAT_01d7a8b8;
  }
  pppppppuStack_1d8 = (undefined4 *******)0x629462;
  puVar6 = (undefined4 *)FUN_00554150();
  uStack_40 = 0x1c;
  puStack_1cc = (undefined *)*puVar6;
  uStack_1c8 = *(double *)(puVar6 + 1);
  pppppppuStack_1c0 = (undefined4 *******)puVar6[3];
  uStack_1bc = *(undefined8 *)(puVar6 + 4);
  puVar6[4] = 0;
  puVar6[5] = 0xf;
  *(undefined *)puVar6 = 0;
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x6294a3;
  FUN_006290b0();
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_4c._4_4_) {
    uVar10 = uStack_4c._4_4_ + 1;
    pppppppuVar5 = pppppppuStack_5c;
    if (0xfff < uVar10) {
      pppppppuVar5 = (undefined4 *******)pppppppuStack_5c[-1];
      uVar10 = uStack_4c._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppppppuStack_5c + (-4 - (int)pppppppuVar5))) {
        uStack_1b4 = (double)CONCAT44(0x62b020,(undefined4)uStack_1b4);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_1b4 = (double)CONCAT44(uVar10,pppppppuVar5);
    uStack_1bc = CONCAT44(0x6294d8,(undefined4)uStack_1bc);
    FUN_01674ea0();
  }
  uStack_1b4 = *(double *)(param_1 + 0xe64);
  uStack_8._0_1_ = 6;
  uStack_4c._0_4_ = 0;
  uStack_4c._4_4_ = 0xf;
  pppppppuStack_5c = (undefined4 *******)((uint)pppppppuStack_5c & 0xffffff00);
  uStack_40 = 0x34;
  uStack_1bc = CONCAT44(iStack_2c + 0x13,0x629517);
  FUN_0058a190();
  pppppppuVar5 = apppppppuStack_3c;
  if (0xf < uStack_28) {
    pppppppuVar5 = apppppppuStack_3c[0];
  }
  uStack_1bc = CONCAT44(iStack_2c,pppppppuVar5);
  pppppppuStack_1c0 = (undefined4 *******)0x62952e;
  FUN_00554150();
  uStack_1bc = 0x13018cd3ec;
  pppppppuStack_1c0 = (undefined4 *******)0x62953d;
  FUN_00554150();
  uStack_18 = CONCAT44(&puStack_1cc,(undefined4)uStack_18);
  pppppppuStack_1d0 = (undefined4 *******)(int)uStack_64;
  pppppppuStack_1d4 = &pppppppuStack_74;
  if (0xf < uStack_64._4_4_) {
    pppppppuStack_1d4 = pppppppuStack_74;
  }
  pppppppuStack_1d8 = (undefined4 *******)0x62955c;
  puVar6 = (undefined4 *)FUN_00554150();
  uStack_40 = 0x74;
  puStack_1cc = (undefined *)*puVar6;
  uStack_1c8 = *(double *)(puVar6 + 1);
  pppppppuStack_1c0 = (undefined4 *******)puVar6[3];
  uStack_1bc = *(undefined8 *)(puVar6 + 4);
  puVar6[4] = 0;
  puVar6[5] = 0xf;
  *(undefined *)puVar6 = 0;
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62959d;
  FUN_006290b0();
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_4c._4_4_) {
    uVar10 = uStack_4c._4_4_ + 1;
    pppppppuVar5 = pppppppuStack_5c;
    if (0xfff < uVar10) {
      pppppppuVar5 = (undefined4 *******)pppppppuStack_5c[-1];
      uVar10 = uStack_4c._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppppppuStack_5c + (-4 - (int)pppppppuVar5))) {
        uStack_1b4 = (double)CONCAT44(0x62b025,(undefined4)uStack_1b4);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_1b4 = (double)CONCAT44(uVar10,pppppppuVar5);
    uStack_1bc = CONCAT44(0x6295d2,(undefined4)uStack_1bc);
    FUN_01674ea0();
  }
  uStack_1b4 = (double)CONCAT44(0x6295e1,(undefined4)uStack_1b4);
  cVar2 = (**(code **)(*param_1 + 0xd4))();
  if (cVar2 == '\0') {
    uStack_1b4 = (double)CONCAT44(auStack_cc,0x6295f5);
    iVar4 = FUN_015301f0();
    iVar4 = *(int *)(iVar4 + 0x10);
    uStack_1b4 = (double)CONCAT44(0x629606,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_9c._4_4_ = 0x54;
    if (iVar4 != 0) {
      uStack_18 = *(ulonglong *)(param_1 + 0xe64);
      uStack_1b4 = (double)CONCAT44(auStack_b4,0x62962c);
      uVar7 = FUN_015301f0();
      uStack_8._0_1_ = 8;
      uStack_7c = 0;
      uStack_78 = 0xf;
      auStack_8c[0] = 0;
      uStack_40 = 0xd4;
      uStack_1b4 = (double)CONCAT44(iStack_2c + 9,0x629663);
      FUN_0058a190();
      pppppppuVar5 = apppppppuStack_3c;
      if (0xf < uStack_28) {
        pppppppuVar5 = apppppppuStack_3c[0];
      }
      uStack_1b4 = (double)CONCAT44(iStack_2c,pppppppuVar5);
      uStack_1bc = CONCAT44(0x62967d,(undefined4)uStack_1bc);
      FUN_00554150();
      uStack_1b4 = 1.91108110507399e-313;
      uStack_1bc = CONCAT44(0x62968f,(undefined4)uStack_1bc);
      FUN_00554150();
      uStack_1b4 = (double)CONCAT44(&pppppppuStack_74,auStack_8c);
      uStack_1bc = CONCAT44(auStack_cc,0x6296a6);
      FUN_00558c20();
      uStack_1b4 = 2.13483142869928e-314;
      uStack_8._0_1_ = 9;
      uStack_1bc = CONCAT44(0x6296bb,(undefined4)uStack_1bc);
      puVar8 = (uint *)FUN_00554150();
      uStack_40 = 0x1d4;
      pppppppuStack_5c = (undefined4 *******)*puVar8;
      uStack_58 = puVar8[1];
      uStack_54 = puVar8[2];
      uStack_50 = puVar8[3];
      uStack_4c = *(undefined8 *)(puVar8 + 4);
      puVar8[4] = 0;
      puVar8[5] = 0xf;
      *(undefined *)puVar8 = 0;
      pppppppuStack_1d4 = &pppppppuStack_5c;
      pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
      uStack_8._0_1_ = 10;
      uStack_1b4 = (double)uStack_18;
      pcStack_1dc = (char *)0x629711;
      pppppppuStack_1d0 = (undefined4 *******)uVar7;
      FUN_00558ba0();
      pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
      pppppppuStack_1d4 = (undefined4 *******)0x62971f;
      FUN_006290b0();
      uStack_1b4 = (double)CONCAT44(0x629727,(undefined4)uStack_1b4);
      FUN_005507b0();
      uStack_1b4 = (double)CONCAT44(0x629732,(undefined4)uStack_1b4);
      FUN_005507b0();
      uStack_1b4 = (double)CONCAT44(0x62973d,(undefined4)uStack_1b4);
      FUN_005507b0();
      uStack_1b4 = (double)CONCAT44(0x629748,(undefined4)uStack_1b4);
      FUN_005507b0();
      uStack_9c._4_4_ = 0x154;
    }
  }
  else {
    uStack_9c._4_4_ = 0x54;
  }
  uStack_1b4 = *(double *)(param_1 + 0xe64);
  uStack_40 = uStack_9c._4_4_ | 0x200;
  uStack_8._0_1_ = 0xb;
  uStack_4c._0_4_ = 0;
  uStack_4c._4_4_ = 0xf;
  pppppppuStack_5c = (undefined4 *******)((uint)pppppppuStack_5c & 0xffffff00);
  uStack_1bc = CONCAT44(iStack_2c + 0x12,0x629797);
  FUN_0058a190();
  pppppppuVar5 = apppppppuStack_3c;
  if (0xf < uStack_28) {
    pppppppuVar5 = apppppppuStack_3c[0];
  }
  uStack_1bc = CONCAT44(iStack_2c,pppppppuVar5);
  pppppppuStack_1c0 = (undefined4 *******)0x6297ae;
  FUN_00554150();
  uStack_1bc = 0x12018cd40c;
  pppppppuStack_1c0 = (undefined4 *******)0x6297bd;
  FUN_00554150();
  uStack_18 = CONCAT44(&puStack_1cc,(undefined4)uStack_18);
  pppppppuStack_1d0 = (undefined4 *******)DAT_01d7a8c8;
  pppppppuStack_1d4 = (undefined4 *******)&DAT_01d7a8b8;
  if (0xf < DAT_01d7a8cc) {
    pppppppuStack_1d4 = (undefined4 *******)DAT_01d7a8b8;
  }
  pppppppuStack_1d8 = (undefined4 *******)0x6297e7;
  puVar6 = (undefined4 *)FUN_00554150();
  uVar10 = uStack_9c._4_4_;
  puStack_1cc = (undefined *)*puVar6;
  uStack_1c8 = *(double *)(puVar6 + 1);
  pppppppuStack_1c0 = (undefined4 *******)puVar6[3];
  uStack_1bc = *(undefined8 *)(puVar6 + 4);
  puVar6[4] = 0;
  uVar11 = uStack_9c._4_4_ | 0x600;
  puVar6[5] = 0xf;
  *(undefined *)puVar6 = 0;
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x629830;
  uStack_40 = uVar11;
  FUN_006290b0();
  uVar11 = uVar11 & 0xfffffdff;
  uStack_9c = (double)((CONCAT44(uVar10,(undefined4)uStack_9c) | 0x60000000000) & 0xfffffdffffffffff
                      );
  uStack_94 = (double)((CONCAT44(uVar10,(undefined4)uStack_94) | 0x60000000000) & 0xfffffdffffffffff
                      );
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_4c._4_4_) {
    uVar10 = uStack_4c._4_4_ + 1;
    pppppppuVar5 = pppppppuStack_5c;
    if (0xfff < uVar10) {
      pppppppuVar5 = (undefined4 *******)pppppppuStack_5c[-1];
      uVar10 = uStack_4c._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppppppuStack_5c + (-4 - (int)pppppppuVar5))) {
        uStack_1b4 = (double)CONCAT44(&UNK_0062b02a,(undefined4)uStack_1b4);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_1b4 = (double)CONCAT44(uVar10,pppppppuVar5);
    uStack_1bc = CONCAT44(0x629877,(undefined4)uStack_1bc);
    FUN_01674ea0();
  }
  if (DAT_01d5a028 != '\0') {
    uStack_1b4 = (double)CONCAT44(0x629893,(undefined4)uStack_1b4);
    cVar2 = (**(code **)(*param_1 + 0xd4))();
    if (cVar2 != '\0') {
      uStack_1b4 = 0.0;
      uStack_1bc = 0xffffffff006298ac;
      FUN_0151f6f0();
      uStack_1c8 = *(double *)(param_1 + 0x334);
      uStack_1b4._4_4_ = (uint)DAT_01d5a048;
      uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
      uStack_8._0_1_ = 0xc;
      uStack_1bc = CONCAT44(DAT_01d7a884,1);
      pppppppuStack_1c0 = (undefined4 *******)0x1;
      pppppppuStack_1d0 = (undefined4 *******)0x0;
      puStack_1cc = &DAT_0000000f;
      puStack_1e0 = (undefined *)((uint)puStack_1e0 & 0xffffff00);
      FUN_005542c0("ServerSimulationToFBAvgLatency_Ms",0x21);
      FUN_0061e3e0(&iStack_24,auStack_1a4);
      uStack_18 = *(ulonglong *)(param_1 + 0x334);
      uStack_8._0_1_ = 0xd;
      uStack_40 = uVar11 | 0x800;
      uStack_4c = 0xf00000000;
      pppppppuStack_5c = (undefined4 *******)((uint)pppppppuStack_5c & 0xffffff00);
      uStack_1b4 = (double)CONCAT44((int)uStack_64 + 0x22,0x629941);
      FUN_0058a190();
      uStack_1b4 = 7.21607058584681e-313;
      uStack_1bc = CONCAT44(0x629950,(undefined4)uStack_1bc);
      FUN_00554150();
      pppppppuVar5 = &pppppppuStack_74;
      if (0xf < uStack_64._4_4_) {
        pppppppuVar5 = pppppppuStack_74;
      }
      uStack_1b4 = (double)CONCAT44((int)uStack_64,pppppppuVar5);
      uStack_1bc = CONCAT44(0x629967,(undefined4)uStack_1bc);
      FUN_00554150();
      ppppppuStack_124 = pppppppuStack_5c;
      pppppppuStack_5c = (undefined4 *******)((uint)pppppppuStack_5c & 0xffffff00);
      uStack_120 = uStack_58;
      uStack_11c = uStack_54;
      uStack_118 = uStack_50;
      uStack_114 = uStack_4c;
      uStack_4c._0_4_ = 0;
      uStack_4c._4_4_ = 0xf;
      uStack_10c = uStack_18;
      uStack_8._0_1_ = 0xe;
      uStack_1b4 = (double)CONCAT44(&ppppppuStack_124,0x6299b1);
      FUN_00625cd0();
      uStack_1b4 = (double)CONCAT44(0x6299bc,(undefined4)uStack_1b4);
      FUN_005507b0();
      uStack_8._0_1_ = 0xc;
      uStack_9c = (double)(CONCAT44(uStack_94._4_4_,(undefined4)uStack_9c) & 0xfffff7ffffffffff);
      uStack_1b4 = (double)CONCAT44(0x6299d9,(undefined4)uStack_1b4);
      FUN_005507b0();
      uStack_1b4 = (double)CONCAT44(&pppppppuStack_74,"playerOS");
      uStack_1bc = CONCAT44(0x6299ed,(undefined4)uStack_1bc);
      FUN_0151f950();
      uVar10 = DAT_01eace48;
      uStack_1b4 = 7.00387100497165e-313;
      uStack_7c = 0;
      uStack_78 = 0xf;
      auStack_8c[0] = 0;
      uStack_1bc = CONCAT44(0x629a1a,(undefined4)uStack_1bc);
      FUN_005542c0();
      uStack_1b4 = (double)(ulonglong)uVar10;
      uStack_8._0_1_ = 0xf;
      uStack_1bc = CONCAT44(auStack_8c,0x629a33);
      FUN_01520d20();
      uStack_1b4 = (double)CONCAT44(0x629a3e,(undefined4)uStack_1b4);
      FUN_005507b0();
      uStack_8._0_1_ = 3;
      uStack_1b4 = (double)CONCAT44(0x629a4d,(undefined4)uStack_1b4);
      FUN_0151f7f0();
      uVar11 = uStack_9c._4_4_;
    }
  }
  uStack_1c8 = *(double *)(param_1 + 0xe64);
  uStack_1b4._4_4_ = (uint)DAT_01d5a048;
  uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
  uStack_1bc = 0;
  pppppppuStack_1c0 = (undefined4 *******)0x1;
  FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_DataPing");
  FUN_0061e3e0(&iStack_24,auStack_104);
  uStack_1b4 = (double)CONCAT44(param_1,0x629aa0);
  iVar4 = FUN_008f7870();
  uStack_94 = (double)CONCAT44(iVar4,(undefined4)uStack_94);
  if (iVar4 != 0) {
    uStack_1b4 = *(double *)(param_1 + 0xe64);
    pppppppuStack_1d8 = apppppppuStack_3c;
    if (0xf < uStack_28) {
      pppppppuStack_1d8 = apppppppuStack_3c[0];
    }
    puStack_1e0 = (undefined *)&puStack_1cc;
    pppppppuStack_1d0 = *(undefined4 ********)(iVar4 + 0x44c);
    pppppppuStack_1d4 = (undefined4 *******)0x18cd480;
    pcStack_1dc = "%s%s%d";
    FUN_01675640();
    pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
    pppppppuStack_1d4 = (undefined4 *******)0x629af6;
    FUN_006290b0();
    uStack_1b4 = (double)CONCAT44(0x629b02,(undefined4)uStack_1b4);
    cVar2 = (**(code **)(*param_1 + 0xd4))();
    if (cVar2 == '\0') {
      puVar6 = &DAT_01d7a8b8;
      if (0xf < DAT_01d7a8cc) {
        puVar6 = DAT_01d7a8b8;
      }
      uStack_1b4 = 4.25684059303346e-314;
      uStack_1bc = CONCAT44(DAT_01d7a8c8,puVar6);
      pppppppuStack_1c0 = (undefined4 *******)0x629b30;
      cVar2 = FUN_0055c360();
      if (cVar2 == '\0') {
        iVar4 = uStack_94._4_4_;
LAB_00629ba5:
        cStack_41 = '\0';
      }
      else {
        uStack_1b4 = 2.13481632412436e-314;
        uStack_7c = 0;
        uStack_78 = 0xf;
        auStack_8c[0] = 0;
        uStack_1bc = CONCAT44(0x629b5e,(undefined4)uStack_1bc);
        FUN_005542c0();
        uStack_40 = uVar11 | 1;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
        uStack_9c = (double)(CONCAT44(uVar11,(undefined4)uStack_9c) | 0x100000000);
        iVar4 = uStack_94._4_4_;
        uStack_18 = CONCAT44(*(undefined4 *)(uStack_94._4_4_ + 0x44c),(undefined4)uStack_18);
        uStack_1b4 = (double)CONCAT44(auStack_8c,&DAT_01d59ff0);
        uStack_1bc = CONCAT44((int)&uStack_18 + 4,0x629b92);
        cVar2 = FUN_006b1840();
        if (cVar2 == '\0') goto LAB_00629ba5;
        cStack_41 = '\x01';
      }
      uStack_8._0_1_ = 3;
      uStack_8._1_3_ = 0;
      if (((ulonglong)uStack_9c & 0x100000000) != 0) {
        uStack_9c = (double)((ulonglong)uStack_9c & 0xfffffffeffffffff);
        uStack_1b4 = (double)CONCAT44(0x629bce,(undefined4)uStack_1b4);
        FUN_005507b0();
      }
      if (cStack_41 != '\0') {
        uStack_1b4 = *(double *)(param_1 + 0xe64);
        pppppppuStack_1d8 = apppppppuStack_3c;
        if (0xf < uStack_28) {
          pppppppuStack_1d8 = apppppppuStack_3c[0];
        }
        puStack_1e0 = (undefined *)&puStack_1cc;
        pppppppuStack_1d0 = *(undefined4 ********)(iVar4 + 0x44c);
        pppppppuStack_1d4 = (undefined4 *******)0x18cd4a4;
        pcStack_1dc = "%s%s%d";
        FUN_01675640();
        pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
        pppppppuStack_1d4 = (undefined4 *******)0x629c17;
        FUN_006290b0();
      }
    }
  }
  uStack_1b4 = *(double *)(param_1 + 0xe6e);
  uStack_40 = uStack_9c._4_4_ | 0x2000;
  uStack_8._0_1_ = 0x11;
  uStack_7c = 0;
  uStack_78 = 0xf;
  auStack_8c[0] = 0;
  uStack_1bc = CONCAT44(iStack_2c + 0x17,0x629c60);
  FUN_0058a190();
  pppppppuVar5 = apppppppuStack_3c;
  if (0xf < uStack_28) {
    pppppppuVar5 = apppppppuStack_3c[0];
  }
  uStack_1bc = CONCAT44(iStack_2c,pppppppuVar5);
  pppppppuStack_1c0 = (undefined4 *******)0x629c7a;
  FUN_00554150();
  uStack_1bc = 0x17018cd4b8;
  pppppppuStack_1c0 = (undefined4 *******)0x629c8c;
  FUN_00554150();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  pppppppuStack_1d0 = &pppppppuStack_74;
  pppppppuStack_1d4 = (undefined4 *******)auStack_8c;
  pcStack_1dc = (char *)0x629ca2;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x629cb0;
  FUN_006290b0();
  uStack_8._0_1_ = 3;
  uStack_1b4 = (double)CONCAT44(0x629cbf,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1c8 = *(double *)(param_1 + 0xe6e);
  uStack_1b4._4_4_ = (uint)DAT_01d5a048;
  uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
  uStack_1bc = 0;
  pppppppuStack_1c0 = (undefined4 *******)0x1;
  FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_BufferHealth");
  FUN_0061e3e0(&iStack_24,auStack_104);
  uStack_1b4 = *(double *)(param_1 + 0x22e);
  pppppppuStack_1d4 = apppppppuStack_3c;
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  pppppppuStack_1d0 = (undefined4 *******)0x18cd4e0;
  pcStack_1dc = (char *)0x629d28;
  FUN_00558ce0();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x629d36;
  FUN_006290b0();
  uStack_1b4 = *(double *)(param_1 + 0x22e);
  uStack_1bc = CONCAT44("_ItemAvgTimeInQueue_",apppppppuStack_3c);
  pppppppuStack_1c0 = (undefined4 *******)auStack_b4;
  uStack_1c8 = (double)CONCAT44(0x629d5b,(undefined4)uStack_1c8);
  pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  uStack_8._0_1_ = 0x12;
  pppppppuStack_1d0 = &pppppppuStack_74;
  pcStack_1dc = (char *)0x629d6f;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x629d7d;
  FUN_006290b0();
  uStack_8._0_1_ = 3;
  uStack_1b4 = (double)CONCAT44(0x629d8c,(undefined4)uStack_1b4);
  FUN_005507b0();
  pppppppuVar5 = apppppppuStack_3c;
  if (0xf < uStack_28) {
    pppppppuVar5 = apppppppuStack_3c[0];
  }
  uStack_1b4 = (double)CONCAT44((((*(int **)(param_1[0x770] + 0xb8))[1] -
                                  **(int **)(param_1[0x770] + 0xb8) >> 3) / 0x19) * 0x19,
                                pppppppuVar5);
  uStack_1bc = CONCAT44("%s_ItemAvgTimeInQueueByPlayer_Tier_%d",auStack_16c);
  pppppppuStack_1c0 = (undefined4 *******)0x629dd2;
  FUN_01675640();
  uStack_1b4 = *(double *)(param_1 + 0x22e);
  pppppppuStack_1d0 = (undefined4 *******)auStack_16c;
  uStack_8._0_1_ = 0x13;
  pppppppuStack_1d4 = (undefined4 *******)0x629df5;
  FUN_0054ef60();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x629e00;
  FUN_006290b0();
  uStack_1b4 = *(double *)(param_1 + 0xe50);
  uStack_1bc = CONCAT44("_RakNetIgnoredPercent_Platform_",apppppppuStack_3c);
  pppppppuStack_1c0 = (undefined4 *******)auStack_b4;
  uStack_1c8 = (double)CONCAT44(0x629e25,(undefined4)uStack_1c8);
  pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  uStack_8._0_1_ = 0x14;
  pppppppuStack_1d0 = &pppppppuStack_74;
  pcStack_1dc = (char *)0x629e39;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x629e47;
  FUN_006290b0();
  uStack_8._0_1_ = 0x13;
  uStack_1b4 = (double)CONCAT44(0x629e56,(undefined4)uStack_1b4);
  FUN_005507b0();
  uVar12 = *(undefined8 *)(param_1 + 0xe5a);
  uStack_1bc = CONCAT44("_RakNetResentPercent_Platform_",apppppppuStack_3c);
  pppppppuStack_1c0 = (undefined4 *******)auStack_b4;
  uStack_1c8 = (double)CONCAT44(0x629e7b,(undefined4)uStack_1c8);
  uStack_1b4 = (double)uVar12;
  pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  uStack_8._0_1_ = 0x15;
  pppppppuStack_1d0 = &pppppppuStack_74;
  pcStack_1dc = (char *)0x629e8f;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x629e9d;
  FUN_006290b0();
  uStack_8._0_1_ = 0x13;
  uStack_1b4 = (double)CONCAT44(0x629eac,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4 = (double)CONCAT44(0x629ebd,(undefined4)uStack_1b4);
  FUN_016f3fe0();
  uStack_1bc = CONCAT44("_RakNetResendMsgLen_Platform_",apppppppuStack_3c);
  pppppppuStack_1c0 = (undefined4 *******)auStack_b4;
  uStack_1c8 = (double)CONCAT44(0x629eda,(undefined4)uStack_1c8);
  uStack_1b4 = (double)uVar12;
  pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  uStack_8._0_1_ = 0x16;
  pppppppuStack_1d0 = &pppppppuStack_74;
  pcStack_1dc = (char *)0x629eee;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x629efc;
  FUN_006290b0();
  uStack_8._0_1_ = 0x13;
  uStack_1b4 = (double)CONCAT44(0x629f0b,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4 = (double)CONCAT44(&pppppppuStack_74,0x629f1a);
  FUN_0054ef60();
  pppppppuVar5 = &pppppppuStack_74;
  if (0xf < uStack_64._4_4_) {
    pppppppuVar5 = pppppppuStack_74;
  }
  uStack_1b4 = 6.37883650455075e-314;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
  uStack_1bc = CONCAT44((int)uStack_64,pppppppuVar5);
  pppppppuStack_1c0 = (undefined4 *******)0x629f39;
  cVar2 = FUN_0055c360();
  if (cVar2 != '\0') {
    uStack_1b4 = (double)CONCAT44(0x629f45,(undefined4)uStack_1b4);
    cVar2 = FUN_00621240();
    if (cVar2 == '\0') {
      uStack_1b4 = 1.06228280924101e-313;
    }
    else {
      uStack_1b4 = 8.50083229749228e-314;
    }
    uStack_1bc = CONCAT44(0x629f64,(undefined4)uStack_1bc);
    FUN_00554150();
  }
  if (*(char *)(param_1 + 0xdfe) != '\0') {
    uStack_1b4 = 2.1232807051189e-313;
    uStack_1bc = CONCAT44(0x629f7f,(undefined4)uStack_1bc);
    FUN_00554150();
  }
  uStack_1b4 = *(double *)(param_1 + 0xe80);
  uStack_1bc = CONCAT44("_PhysicsPacketsLossPercentage_",apppppppuStack_3c);
  pppppppuStack_1c0 = (undefined4 *******)auStack_b4;
  uStack_1c8 = (double)CONCAT44(0x629fa4,(undefined4)uStack_1c8);
  pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  uStack_8._0_1_ = 0x18;
  pppppppuStack_1d0 = (undefined4 *******)auStack_8c;
  pcStack_1dc = (char *)0x629fbb;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x629fc9;
  FUN_006290b0();
  uStack_8._0_1_ = 0x17;
  uStack_1b4 = (double)CONCAT44(0x629fd8,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4 = *(double *)(param_1 + 0xe82);
  uStack_1bc = CONCAT44("_PhysicsPacketsLossPerSecond_",apppppppuStack_3c);
  pppppppuStack_1c0 = (undefined4 *******)auStack_b4;
  uStack_1c8 = (double)CONCAT44(0x629ffd,(undefined4)uStack_1c8);
  pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  uStack_8._0_1_ = 0x19;
  pppppppuStack_1d0 = (undefined4 *******)auStack_8c;
  pcStack_1dc = (char *)0x62a014;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62a022;
  FUN_006290b0();
  uStack_8._0_1_ = 0x17;
  uStack_1b4 = (double)CONCAT44(0x62a031,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4 = *(double *)(param_1 + 0xe80);
  pppppppuStack_1d4 = apppppppuStack_3c;
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  pppppppuStack_1d0 = (undefined4 *******)0x18cd5f4;
  pcStack_1dc = (char *)0x62a053;
  FUN_00558ce0();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62a061;
  FUN_006290b0();
  uStack_1b4 = *(double *)(param_1 + 0xe82);
  pppppppuStack_1d4 = apppppppuStack_3c;
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  pppppppuStack_1d0 = (undefined4 *******)0x18cd614;
  pcStack_1dc = (char *)0x62a083;
  FUN_00558ce0();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62a091;
  FUN_006290b0();
  if (DAT_01d5a010 != '\0') {
    uStack_1b4 = *(double *)(param_1 + 0xe80);
    uStack_1bc = CONCAT44("_PhysicsPacketsLossPercentage_",apppppppuStack_3c);
    pppppppuStack_1c0 = &pppppppuStack_5c;
    uStack_1c8 = (double)CONCAT44(0x62a0c0,(undefined4)uStack_1c8);
    uVar7 = FUN_00558ce0();
    uStack_8._0_1_ = 0x1a;
    uStack_1c8 = (double)CONCAT44(auStack_8c,uVar7);
    puStack_1cc = auStack_cc;
    pppppppuStack_1d0 = (undefined4 *******)0x62a0d8;
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&DAT_018c6ae4;
    pppppppuStack_1d8 = (undefined4 *******)auStack_b4;
    uStack_8._0_1_ = 0x1b;
    pcStack_1dc = (char *)0x62a0ee;
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558c80();
    uStack_8._0_1_ = 0x1c;
    pppppppuStack_1d0 = (undefined4 *******)&DAT_01d7a8e8;
    pcStack_1dc = (char *)0x62a103;
    pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
    FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
    pppppppuStack_1d4 = (undefined4 *******)0x62a111;
    FUN_006290b0();
    uStack_1b4 = (double)CONCAT44(0x62a11c,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = (double)CONCAT44(0x62a127,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_8._0_1_ = 0x17;
    uStack_1b4 = (double)CONCAT44(0x62a133,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = *(double *)(param_1 + 0xe82);
    uStack_1bc = CONCAT44("_PhysicsPacketsLossPerSecond_",apppppppuStack_3c);
    pppppppuStack_1c0 = &pppppppuStack_5c;
    uStack_1c8 = (double)CONCAT44(0x62a155,(undefined4)uStack_1c8);
    uVar7 = FUN_00558ce0();
    uStack_8._0_1_ = 0x1d;
    uStack_1c8 = (double)CONCAT44(auStack_8c,uVar7);
    puStack_1cc = auStack_cc;
    pppppppuStack_1d0 = (undefined4 *******)0x62a16d;
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&DAT_018c6ae4;
    pppppppuStack_1d8 = (undefined4 *******)auStack_b4;
    uStack_8._0_1_ = 0x1e;
    pcStack_1dc = (char *)0x62a183;
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558c80();
    uStack_8._0_1_ = 0x1f;
    pppppppuStack_1d0 = (undefined4 *******)&DAT_01d7a8e8;
    pcStack_1dc = (char *)0x62a198;
    pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
    FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
    pppppppuStack_1d4 = (undefined4 *******)0x62a1a6;
    FUN_006290b0();
    uStack_1b4 = (double)CONCAT44(0x62a1b1,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = (double)CONCAT44(0x62a1bc,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_8._0_1_ = 0x17;
    uStack_1b4 = (double)CONCAT44(0x62a1c8,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = *(double *)(param_1 + 0xe80);
    uStack_1bc = CONCAT44("_PhysicsPacketsLossPercentage_",apppppppuStack_3c);
    pppppppuStack_1c0 = (undefined4 *******)auStack_b4;
    uStack_1c8 = (double)CONCAT44(0x62a1ed,(undefined4)uStack_1c8);
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
    pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
    uStack_8._0_1_ = 0x20;
    pppppppuStack_1d0 = (undefined4 *******)&DAT_01d7a8e8;
    pcStack_1dc = (char *)0x62a202;
    FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
    pppppppuStack_1d4 = (undefined4 *******)0x62a210;
    FUN_006290b0();
    uStack_8._0_1_ = 0x17;
    uStack_1b4 = (double)CONCAT44(0x62a21f,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = *(double *)(param_1 + 0xe82);
    uStack_1bc = CONCAT44("_PhysicsPacketsLossPerSecond_",apppppppuStack_3c);
    pppppppuStack_1c0 = (undefined4 *******)auStack_b4;
    uStack_1c8 = (double)CONCAT44(0x62a244,(undefined4)uStack_1c8);
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
    pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
    uStack_8._0_1_ = 0x21;
    pppppppuStack_1d0 = (undefined4 *******)&DAT_01d7a8e8;
    pcStack_1dc = (char *)0x62a259;
    FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
    pppppppuStack_1d4 = (undefined4 *******)0x62a267;
    FUN_006290b0();
    uStack_8._0_1_ = 0x17;
    uStack_1b4 = (double)CONCAT44(0x62a276,(undefined4)uStack_1b4);
    FUN_005507b0();
  }
  uStack_1b4 = (double)(float)param_1[0xe74];
  uStack_1bc = CONCAT44("_PhysicsFBInstaneousMaxDelta",apppppppuStack_3c);
  pppppppuStack_1c0 = (undefined4 *******)auStack_b4;
  uStack_1c8 = (double)CONCAT44(0x62a29e,(undefined4)uStack_1c8);
  pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  uStack_8._0_1_ = 0x22;
  pppppppuStack_1d0 = &pppppppuStack_74;
  pcStack_1dc = (char *)0x62a2b2;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62a2c0;
  FUN_006290b0();
  uStack_8._0_1_ = 0x17;
  uStack_1b4 = (double)CONCAT44(0x62a2cf,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4 = *(double *)(param_1 + 0xe7a);
  uStack_1bc = CONCAT44("_PhysicsFBInstaneousStepAvgDelta",apppppppuStack_3c);
  pppppppuStack_1c0 = (undefined4 *******)auStack_b4;
  uStack_1c8 = (double)CONCAT44(0x62a2f4,(undefined4)uStack_1c8);
  pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  uStack_8._0_1_ = 0x23;
  pppppppuStack_1d0 = &pppppppuStack_74;
  pcStack_1dc = (char *)0x62a308;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62a316;
  FUN_006290b0();
  uStack_8._0_1_ = 0x17;
  uStack_1b4 = (double)CONCAT44(0x62a325,(undefined4)uStack_1b4);
  FUN_005507b0();
  pppppppuStack_1d4 = apppppppuStack_3c;
  uStack_1b4 = (double)(float)param_1[0xe74];
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  pppppppuStack_1d0 = (undefined4 *******)0x18cd634;
  pcStack_1dc = (char *)0x62a34a;
  FUN_00558ce0();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62a358;
  FUN_006290b0();
  uStack_1b4 = *(double *)(param_1 + 0xe7a);
  pppppppuStack_1d4 = apppppppuStack_3c;
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  pppppppuStack_1d0 = (undefined4 *******)0x18cd654;
  pcStack_1dc = (char *)0x62a37a;
  FUN_00558ce0();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62a388;
  FUN_006290b0();
  if (DAT_01d5a018 != '\0') {
    uStack_1b4 = (double)(float)param_1[0xe74];
    uStack_1bc = CONCAT44("_PhysicsFBInstaneousMaxDelta",apppppppuStack_3c);
    pppppppuStack_1c0 = &pppppppuStack_5c;
    uStack_1c8 = (double)CONCAT44(0x62a3ba,(undefined4)uStack_1c8);
    uVar7 = FUN_00558ce0();
    uStack_8._0_1_ = 0x24;
    uStack_1c8 = (double)CONCAT44(&pppppppuStack_74,uVar7);
    puStack_1cc = auStack_cc;
    pppppppuStack_1d0 = (undefined4 *******)0x62a3cf;
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&DAT_018c6ae4;
    pppppppuStack_1d8 = (undefined4 *******)auStack_b4;
    uStack_8._0_1_ = 0x25;
    pcStack_1dc = (char *)0x62a3e5;
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558c80();
    uStack_8._0_1_ = 0x26;
    pppppppuStack_1d0 = (undefined4 *******)&DAT_01d7a8e8;
    pcStack_1dc = (char *)0x62a3fa;
    pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
    FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
    pppppppuStack_1d4 = (undefined4 *******)0x62a408;
    FUN_006290b0();
    uStack_1b4 = (double)CONCAT44(0x62a413,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = (double)CONCAT44(0x62a41e,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_8._0_1_ = 0x17;
    uStack_1b4 = (double)CONCAT44(0x62a42a,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = *(double *)(param_1 + 0xe7a);
    uStack_1bc = CONCAT44("_PhysicsFBInstaneousStepAvgDelta",apppppppuStack_3c);
    pppppppuStack_1c0 = (undefined4 *******)auStack_154;
    uStack_1c8 = (double)CONCAT44(0x62a44f,(undefined4)uStack_1c8);
    uVar7 = FUN_00558ce0();
    uStack_8._0_1_ = 0x27;
    uStack_1c8 = (double)CONCAT44(&pppppppuStack_74,uVar7);
    puStack_1cc = auStack_cc;
    pppppppuStack_1d0 = (undefined4 *******)0x62a464;
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&DAT_018c6ae4;
    pppppppuStack_1d8 = (undefined4 *******)auStack_b4;
    uStack_8._0_1_ = 0x28;
    pcStack_1dc = (char *)0x62a47a;
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558c80();
    uStack_8._0_1_ = 0x29;
    pppppppuStack_1d0 = (undefined4 *******)&DAT_01d7a8e8;
    pcStack_1dc = (char *)0x62a48f;
    pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
    FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
    pppppppuStack_1d4 = (undefined4 *******)0x62a49d;
    FUN_006290b0();
    uStack_1b4 = (double)CONCAT44(0x62a4a8,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = (double)CONCAT44(0x62a4b3,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_8._0_1_ = 0x17;
    uStack_1b4 = (double)CONCAT44(0x62a4c2,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = (double)(float)param_1[0xe74];
    uStack_1bc = CONCAT44("_PhysicsFBInstaneousMaxDelta",apppppppuStack_3c);
    pppppppuStack_1c0 = (undefined4 *******)auStack_13c;
    uStack_1c8 = (double)CONCAT44(0x62a4ea,(undefined4)uStack_1c8);
    uVar7 = FUN_00558ce0();
    uStack_1c8 = (double)CONCAT44(&DAT_018c6ae4,uVar7);
    puStack_1cc = auStack_154;
    uStack_8._0_1_ = 0x2a;
    pppppppuStack_1d0 = (undefined4 *******)0x62a500;
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558c80();
    uStack_8._0_1_ = 0x2b;
    pppppppuStack_1d0 = (undefined4 *******)&DAT_01d7a8e8;
    pcStack_1dc = (char *)0x62a512;
    pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
    FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
    pppppppuStack_1d4 = (undefined4 *******)0x62a520;
    FUN_006290b0();
    uStack_1b4 = (double)CONCAT44(0x62a52b,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_8._0_1_ = 0x17;
    uStack_1b4 = (double)CONCAT44(0x62a53a,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = *(double *)(param_1 + 0xe7a);
    uStack_1bc = CONCAT44("_PhysicsFBInstaneousStepAvgDelta",apppppppuStack_3c);
    pppppppuStack_1c0 = (undefined4 *******)&uStack_11c;
    uStack_1c8 = (double)CONCAT44(0x62a55f,(undefined4)uStack_1c8);
    uVar7 = FUN_00558ce0();
    uStack_1c8 = (double)CONCAT44(&DAT_018c6ae4,uVar7);
    puStack_1cc = auStack_13c;
    uStack_8._0_1_ = 0x2c;
    pppppppuStack_1d0 = (undefined4 *******)0x62a575;
    pppppppuStack_1d4 = (undefined4 *******)FUN_00558c80();
    uStack_8._0_1_ = 0x2d;
    pppppppuStack_1d0 = (undefined4 *******)&DAT_01d7a8e8;
    pcStack_1dc = (char *)0x62a587;
    pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
    FUN_00558c20();
    pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
    pppppppuStack_1d4 = (undefined4 *******)0x62a595;
    FUN_006290b0();
    uStack_1b4 = (double)CONCAT44(0x62a5a0,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_8._0_1_ = 0x17;
    uStack_1b4 = (double)CONCAT44(0x62a5af,(undefined4)uStack_1b4);
    FUN_005507b0();
  }
  uStack_1c8 = *(double *)(param_1 + 0xe88);
  uStack_1b4._4_4_ = (uint)DAT_01d5a048;
  uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
  uStack_1bc = 0;
  pppppppuStack_1c0 = (undefined4 *******)0x1;
  FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_highPriorityPendingItemsQueueLength");
  FUN_0061e3e0(&iStack_24,auStack_104);
  uStack_1c8 = *(double *)(param_1 + 0xe92);
  uStack_1b4._4_4_ = (uint)DAT_01d5a048;
  uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
  uStack_1bc = 0;
  pppppppuStack_1c0 = (undefined4 *******)0x1;
  FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_pendingItemsQueueLength");
  FUN_0061e3e0(&iStack_24,auStack_104);
  uStack_1c8 = *(double *)(param_1 + 0xe9c);
  uStack_1b4._4_4_ = (uint)DAT_01d5a048;
  uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
  uStack_1bc = 0;
  pppppppuStack_1c0 = (undefined4 *******)0x1;
  FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_pendingItemsLeftoverLength");
  FUN_0061e3e0(&iStack_24,auStack_104);
  uStack_1c8 = *(double *)(param_1 + 0xea6);
  uStack_1b4._4_4_ = (uint)DAT_01d5a048;
  uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
  uStack_1bc = 0;
  pppppppuStack_1c0 = (undefined4 *******)0x1;
  FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_dataItemSendCount");
  FUN_0061e3e0(&iStack_24,auStack_104);
  if (DAT_01d5a088 != '\0') {
    uStack_1b4._4_4_ = (uint)DAT_01d5a4f8;
    uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
    uStack_1bc = 0;
    pppppppuStack_1c0 = (undefined4 *******)0x0;
    uStack_1c8 = (double)(float)param_1[0xeb3];
    FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_instantPhysicsReplicationRatio");
    FUN_0061e3e0(&iStack_24,auStack_104);
    uStack_1b4._4_4_ = (uint)DAT_01d5a4f8;
    uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
    uStack_1bc = 0;
    pppppppuStack_1c0 = (undefined4 *******)0x0;
    uStack_1c8 = (double)param_1[0xeb4];
    FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_lastMechanismSendByteSize");
    FUN_0061e3e0(&iStack_24,auStack_104);
  }
  uStack_1b4._4_4_ = (uint)DAT_01d5a4f8;
  uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
  uStack_1bc = 0;
  pppppppuStack_1c0 = (undefined4 *******)0x0;
  uStack_1c8 = (double)param_1[0xeb5];
  FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_lastTotalMechanismForReplication");
  FUN_0061e3e0(&iStack_24,auStack_104);
  uStack_1b4 = (double)param_1[0xeb5];
  uStack_1bc = CONCAT44("_lastTotalMechanismForReplication",apppppppuStack_3c);
  pppppppuStack_1c0 = (undefined4 *******)&uStack_11c;
  uStack_1c8 = (double)CONCAT44(0x62a7e1,(undefined4)uStack_1c8);
  pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  uStack_8._0_1_ = 0x2e;
  pppppppuStack_1d0 = &pppppppuStack_74;
  pcStack_1dc = (char *)0x62a7f5;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62a803;
  FUN_006290b0();
  uStack_8._0_1_ = 0x17;
  uStack_1b4 = (double)CONCAT44(0x62a812,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4._4_4_ = (uint)DAT_01d5a4f8;
  uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
  uStack_1bc = 0;
  pppppppuStack_1c0 = (undefined4 *******)0x0;
  uStack_1c8 = (double)param_1[0xeb6];
  FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_lastMechanismInBufferZone");
  FUN_0061e3e0(&iStack_24,auStack_104);
  uStack_1b4 = (double)param_1[0xeb5];
  uStack_1bc = CONCAT44("_lastMechanismInBufferZone",apppppppuStack_3c);
  pppppppuStack_1c0 = (undefined4 *******)auStack_13c;
  uStack_1c8 = (double)CONCAT44(0x62a886,(undefined4)uStack_1c8);
  pppppppuStack_1d4 = (undefined4 *******)FUN_00558ce0();
  pppppppuStack_1d8 = (undefined4 *******)&puStack_1cc;
  uStack_8._0_1_ = 0x2f;
  pppppppuStack_1d0 = &pppppppuStack_74;
  pcStack_1dc = (char *)0x62a89a;
  FUN_00558c20();
  pppppppuStack_1d0 = (undefined4 *******)&iStack_24;
  pppppppuStack_1d4 = (undefined4 *******)0x62a8a8;
  FUN_006290b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
  uStack_1b4 = (double)CONCAT44(0x62a8b7,(undefined4)uStack_1b4);
  FUN_005507b0();
  if (*(char *)(param_1 + 0xdfe) == '\0') goto LAB_0062ae9d;
  uStack_1b4 = (double)CONCAT44(0x62a8d0,(undefined4)uStack_1b4);
  cVar2 = (**(code **)(*param_1 + 0xd4))();
  if (cVar2 == '\0') {
    iVar4 = param_1[3];
    uStack_1b4 = (double)CONCAT44(0x62abd3,(undefined4)uStack_1b4);
    iVar9 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
        (uint)*(ushort *)(iVar9 + 0x1da)) {
      uStack_18 = (ulonglong)
                  CONCAT24(CONCAT11((char)(*(ushort *)(iVar9 + 0x1da) >> 8),DAT_01d5a048),
                           (undefined4)uStack_18);
      uStack_1b4 = (double)CONCAT44(0x62ac01,(undefined4)uStack_1b4);
      sVar3 = FUN_006efb50();
      uStack_1b4 = (double)(uStack_18 & 0xffffffff00000000);
      uStack_1bc = 0;
      pppppppuStack_1c0 = (undefined4 *******)0x1;
      uStack_1c8 = (double)(int)sVar3;
      FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_clientStreamingGcDistance");
      FUN_0061e3e0(&iStack_24,auStack_104);
      uStack_1b4 = (double)CONCAT44(0x62ac4b,(undefined4)uStack_1b4);
      uVar7 = FUN_006efb70();
      if ((char)uVar7 != '\0') {
        iVar4 = param_1[0xeb2];
        uStack_1c8 = DAT_018c0d60;
        if (iVar4 < 1) {
          uStack_1c8 = 0.0;
        }
        uStack_1b4 = (double)((ulonglong)CONCAT31((int3)((uint)uVar7 >> 8),DAT_01d5a048) << 0x20);
        uStack_1bc = 0;
        pppppppuStack_1c0 = (undefined4 *******)0x0;
        FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_clientStreamingPauseExitOccurred");
        FUN_0061e3e0(&iStack_24,auStack_104);
        if (0 < iVar4) {
          uStack_1b4 = (double)((ulonglong)DAT_01d5a048 << 0x20);
          uStack_1bc = 0;
          pppppppuStack_1c0 = (undefined4 *******)0x0;
          uStack_1c8 = *(double *)(param_1 + 0xeb0) / (double)param_1[0xeb2];
          FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_clientStreamingAvgPauseDuration");
          FUN_0061e3e0(&iStack_24,auStack_104);
          uStack_1b4 = (double)((ulonglong)DAT_01d5a048 << 0x20);
          uStack_1bc = 0;
          pppppppuStack_1c0 = (undefined4 *******)0x0;
          uStack_1c8 = (double)((float)param_1[0xeb2] / (float)DAT_01d59dc0);
          FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_clientStreamingPauseEventsPerSecond");
          FUN_0061e3e0(&iStack_24,auStack_104);
        }
      }
    }
    if (param_1[0xeac] < 1) goto LAB_0062ae9d;
    uStack_1b4 = (double)((ulonglong)DAT_01d5a048 << 0x20);
    uStack_1bc = 0;
    pppppppuStack_1c0 = (undefined4 *******)0x1;
    uStack_1c8 = ((double)param_1[0xead] * DAT_018ce318) / (double)param_1[0xeac];
    FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_clientStreamingPercentStepsOutside");
    FUN_0061e3e0(&iStack_24,auStack_104);
    uStack_1b4._4_4_ = (uint)DAT_01d5a048;
    uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
    uStack_1bc = 0;
    pppppppuStack_1c0 = (undefined4 *******)0x1;
    uStack_1c8 = ((double)param_1[0xeae] * DAT_018ce318) / (double)param_1[0xeac];
    FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_clientStreamPercentSmallerThanMin");
    FUN_0061e3e0(&iStack_24,auStack_104);
    uStack_1b4._4_4_ = (uint)DAT_01d5a048;
    uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
    pppppppuStack_1c0 = (undefined4 *******)0x1;
    uStack_1c8 = ((double)param_1[0xeaf] * DAT_018ce318) / (double)param_1[0xeac];
    pcVar14 = "_clientStreamPercentRanGarbageCollect";
  }
  else {
    if (param_1[0x779] == 0) goto LAB_0062ae9d;
    uStack_1b4._4_4_ = (uint)DAT_01d5a048;
    uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
    uStack_1bc = 0;
    pppppppuStack_1c0 = (undefined4 *******)0x1;
    uStack_1c8 = (double)*(int *)(param_1[0x779] + 0x160);
    FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_serverMaxClientQuota");
    uVar7 = FUN_0061e3e0(&iStack_24,auStack_104);
    uStack_1b4 = (double)CONCAT44(0x62a94a,(undefined4)uStack_1b4);
    uStack_18._4_4_ = CONCAT31((int3)((uint)uVar7 >> 8),DAT_01d5a048);
    iVar4 = FUN_006e61e0();
    uStack_1b4 = (double)CONCAT44(uStack_18._4_4_,1);
    uStack_1bc = 0;
    pppppppuStack_1c0 = (undefined4 *******)0x1;
    dVar13 = (double)iVar4;
    uStack_1c8 = dVar13;
    FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_serverTargetStreamingRadius");
    uVar7 = FUN_0061e3e0(&iStack_24,auStack_104);
    uVar7 = CONCAT31((int3)((uint)uVar7 >> 8),DAT_01d5a050);
    iVar4 = *(int *)(param_1[0x779] + 0x354);
    uStack_18 = CONCAT44(iVar4,(undefined4)uStack_18);
    uStack_94._4_4_ = uVar7;
    if ((iVar4 == 0) && (*(int *)(param_1[0x779] + 0x350) == 0)) {
      uStack_1c8 = 0.0;
    }
    else {
      uStack_1b4 = (double)CONCAT44(0x62a9ca,(undefined4)uStack_1b4);
      FUN_016f3fe0();
      dVar13 = dVar13 * DAT_018ce318;
      uStack_1b4 = (double)CONCAT44(0x62a9e4,(undefined4)uStack_1b4);
      uStack_9c = dVar13;
      FUN_016f3fe0();
      uStack_1c8 = uStack_9c / dVar13;
    }
    uStack_1b4 = (double)CONCAT44(uStack_94._4_4_,1);
    uStack_1bc = 0;
    pppppppuStack_1c0 = (undefined4 *******)0x1;
    FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_serverStreamingOrphanSkipPercentage");
    FUN_0061e3e0(&iStack_24,auStack_104);
    if (DAT_01d5a070 != '\0') {
      uStack_1b4 = (double)CONCAT44(param_1,0x62aa3c);
      iVar4 = FUN_008f7870();
      if ((iVar4 != 0) && (*(int *)(iVar4 + 0x1b8) != 0)) {
        uStack_1b4 = (double)((ulonglong)DAT_01d5a050 << 0x20);
        uStack_1bc = 0;
        pppppppuStack_1c0 = (undefined4 *******)0x0;
        uStack_1c8 = (double)*(int *)(*(int *)(iVar4 + 0x1b8) + 0x308);
        FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_serverStreamingMinRadius");
        FUN_0061e3e0(&iStack_24,auStack_104);
      }
    }
    if (DAT_01d5a078 != '\0') {
      uStack_1c8 = (double)*(int *)(param_1[0x779] + 0x214) +
                   (double)(&DAT_018c0d90)[-(*(int *)(param_1[0x779] + 0x214) >> 0x1f)];
      uStack_1b4._4_4_ = (uint)DAT_01d5a048;
      uStack_1b4 = (double)CONCAT44(uStack_1b4._4_4_,1);
      uStack_1bc = 0;
      pppppppuStack_1c0 = (undefined4 *******)0x1;
      FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_serverAncestorsSentWithoutAllDescendants");
      FUN_0061e3e0(&iStack_24,auStack_104);
    }
    uStack_94 = 0.0;
    uStack_1b4 = (double)CONCAT44(&uStack_94,0x62ab23);
    cVar2 = FUN_0061e9d0();
    if (cVar2 != '\0') {
      uStack_1c8 = uStack_94 * DAT_018c0d70;
      uStack_1b4 = (double)((ulonglong)DAT_01d5a048 << 0x20);
      uStack_1bc = 0;
      pppppppuStack_1c0 = (undefined4 *******)0x0;
      FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,"_MinRadiusAvgQueueWaitTimeMs");
      FUN_0061e3e0(&iStack_24,auStack_104);
    }
    uStack_1b4 = (double)CONCAT44(&uStack_94,0x62ab8e);
    cVar2 = FUN_0061e9d0();
    if (cVar2 == '\0') goto LAB_0062ae9d;
    uStack_1c8 = uStack_94 * DAT_018c0d70;
    uStack_1b4 = (double)((ulonglong)DAT_01d5a048 << 0x20);
    pppppppuStack_1c0 = (undefined4 *******)0x0;
    pcVar14 = "_NonMinRadiusAvgQueueWaitTimeMs";
  }
  uStack_1bc = 0;
  FUN_00558ce0(&puStack_1e0,apppppppuStack_3c,pcVar14);
  FUN_0061e3e0(&iStack_24,auStack_104);
LAB_0062ae9d:
  if (iStack_24 != iStack_20) {
    uStack_1b4 = (double)ZEXT48(&iStack_24);
    uStack_1bc = CONCAT44(0x62aeb0,(undefined4)uStack_1bc);
    FUN_00874d70();
  }
  if (DAT_01d5a008 != '\0') {
    uStack_18._0_5_ = CONCAT14(*(undefined *)(param_1 + 0xdfe),(undefined4)uStack_18);
    uStack_1b4 = (double)CONCAT44((int)(uStack_18 >> 0x20),"StreamingEnabled");
    uStack_1bc = CONCAT44(0x62aedc,(undefined4)uStack_1bc);
    FUN_0151fcf0();
    uStack_1b4 = 8.814100735318666e-300;
    uStack_1bc = CONCAT44(0x62aef1,(undefined4)uStack_1bc);
    FUN_0151f950();
    uStack_1b4 = (double)CONCAT44((*(int **)(param_1[0x770] + 0xb8))[1] -
                                  **(int **)(param_1[0x770] + 0xb8) >> 3,"NumPlayers");
    uStack_1bc = CONCAT44(0x62af16,(undefined4)uStack_1bc);
    FUN_0151f9c0();
    uStack_1b4 = (double)CONCAT44(&pppppppuStack_74,&DAT_018cd96c);
    uStack_1bc = CONCAT44(0x62af2a,(undefined4)uStack_1bc);
    FUN_0151f950();
    uStack_4c._0_4_ = 0;
    uStack_4c._4_4_ = 0xf;
    pppppppuStack_5c = (undefined4 *******)((uint)pppppppuStack_5c & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x30);
    uStack_1b4 = (double)CONCAT44(0x62af4c,(undefined4)uStack_1b4);
    cVar2 = (**(code **)(*param_1 + 0xd4))();
    if (cVar2 == '\0') {
      uStack_1b4 = 4.45747612577302e-313;
    }
    else {
      uStack_1b4 = (double)CONCAT44(0x62af5c,(undefined4)uStack_1b4);
      cVar2 = (**(code **)(*param_1 + 0x11c))();
      if (cVar2 == '\0') {
        uStack_1b4 = 4.45747612458726e-313;
      }
      else {
        uStack_1b4 = 6.367272334875e-313;
      }
    }
    uStack_1bc = CONCAT44(0x62af84,(undefined4)uStack_1bc);
    FUN_005542c0();
    uVar10 = DAT_01eace44;
    pppppppuVar5 = &pppppppuStack_5c;
    if (0xf < uStack_4c._4_4_) {
      pppppppuVar5 = pppppppuStack_5c;
    }
    uStack_1b4 = (double)CONCAT44(pppppppuVar5,0x62afa1);
    FUN_0054eff0();
    uStack_1b4 = (double)(ulonglong)uVar10;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x31);
    uStack_1bc = CONCAT44(auStack_cc,0x62afba);
    FUN_01520d20();
    uStack_1b4 = (double)CONCAT44(0x62afc5,(undefined4)uStack_1b4);
    FUN_005507b0();
    uStack_1b4 = (double)CONCAT44(0x62afcd,(undefined4)uStack_1b4);
    FUN_005507b0();
  }
  uStack_1b4 = (double)CONCAT44(0x62afd8,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4 = (double)CONCAT44(0x62afe3,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4 = (double)CONCAT44(0x62afeb,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4 = (double)CONCAT44(0x62aff3,(undefined4)uStack_1b4);
  FUN_005507b0();
  uStack_1b4 = (double)CONCAT44(0x62affe,(undefined4)uStack_1b4);
  FUN_0151f7f0();
  uStack_1b4 = (double)CONCAT44(0x62b006,(undefined4)uStack_1b4);
  FUN_0056d3e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6894 ; VA 0x0062b030 ; FUN_0062b030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0062b030(int *param_1,uint param_2)

{
  int iVar1;
  float10 fVar2;
  double dVar3;
  undefined8 uVar4;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  double dStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee50;
  pvStack_10 = ExceptionList;
  if (((param_2 & (param_1[0x67c] | _DAT_01d59ee4) & ~param_1[0x67b]) == 0) && (0 < DAT_01eace58)) {
    ExceptionList = &pvStack_10;
    if (param_2 == 8) {
      ExceptionList = &pvStack_10;
      FUN_0087c450(&DAT_018c5f98,"SecurityException","QueueLimit",0,0,0);
    }
    FUN_016830f0();
    dStack_20 = dStack_18 - *(double *)(param_1 + 0x42e);
    iVar1 = (**(code **)(*param_1 + 0xb4))();
    if (iVar1 == 0) {
      uVar4 = 0xffffffffffffffff;
    }
    else {
      uVar4 = FUN_00928340();
    }
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0;
    FUN_0151fb00("duration",dStack_20);
    FUN_0151fb00("QSize",(double)param_1[0x7ce] + (double)(&DAT_018c0d90)[-(param_1[0x7ce] >> 0x1f)]
                );
    FUN_0151fb00("QCount",(double)param_1[0x7c8] +
                          (double)(&DAT_018c0d90)[-(param_1[0x7c8] >> 0x1f)]);
    FUN_0151fb00(&DAT_018c5ca8,*(undefined8 *)(param_1 + 0x260));
    FUN_0151fb00("BuffHealth",*(undefined8 *)(param_1 + 0x204));
    FUN_0151fb00("TxKbps",*(undefined8 *)(param_1 + 0x188));
    FUN_0151fb00("RxKbps",*(undefined8 *)(param_1 + 0x202));
    dVar3 = 0.0;
    if (0.0 < *(double *)(param_1 + 0x7ca)) {
      dVar3 = dStack_18 - *(double *)(param_1 + 0x7ca);
    }
    FUN_0151fb00("HeadWait",dVar3);
    fVar2 = (float10)FUN_0061f160();
    FUN_0151fb00("GlobalLevel",(double)fVar2);
    fVar2 = (float10)FUN_0061f160();
    FUN_0151fb00("SoundLevel",(double)fVar2);
    fVar2 = (float10)FUN_0061f160();
    FUN_0151fb00("MarketLevel",(double)fVar2);
    fVar2 = (float10)FUN_0061f160();
    FUN_0151fb00("ReportLevel",(double)fVar2);
    FUN_0151fbb0("chsrid",uVar4);
    FUN_0151f9c0("SoundMax",DAT_01d59e78);
    FUN_0151f9c0("GlobalMax",DAT_01d59e84);
    FUN_0151f9c0("MarketMax",DAT_01eace5c);
    FUN_0151f9c0("SoundMs",DAT_01d59e94);
    FUN_0151f9c0("GlobalMs",DAT_01d59ea4);
    FUN_0151f9c0("MarketMs",DAT_01d59e9c);
    iVar1 = DAT_01eace58;
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = 0;
    FUN_005542c0("Rate2",5);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_38,iVar1,0);
    FUN_005507b0();
    param_1[0x67b] = param_1[0x67b] | param_2;
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6895 ; VA 0x0062b370 ; FUN_0062b370 */

void __thiscall FUN_0062b370(int *param_1,int param_2)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  undefined4 *puVar5;
  char *pcVar6;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0061bfc0(apppuStack_40,param_2);
  iStack_8 = 0;
  cVar1 = (**(code **)(*param_1 + 0x11c))();
  if (cVar1 == '\0') {
    ppppuVar3 = apppuStack_40;
    if (0xf < uStack_2c) {
      ppppuVar3 = (undefined4 ****)apppuStack_40[0];
    }
    cVar1 = (**(code **)(*param_1 + 0xd4))();
    pcVar6 = "ServerDisconnectReason";
    if (cVar1 == '\0') {
      pcVar6 = "ClientDisconnectReason";
    }
    FUN_0087c450(&DAT_018c5f98,pcVar6,ppppuVar3,0,0,0);
  }
  else {
    uStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
    FUN_005542c0("Connection Closed",0x11);
    iStack_8._0_1_ = 1;
    cVar1 = (**(code **)(*param_1 + 0xd4))();
    if (cVar1 == '\0') {
      pcVar6 = "ClientReplicatorDisconnect";
    }
    else {
      pcVar6 = "ServerReplicatorDisconnect";
    }
    FUN_00554150(pcVar6,0x1a);
    ppppuVar3 = apppuStack_40;
    if (0xf < uStack_2c) {
      ppppuVar3 = (undefined4 ****)apppuStack_40[0];
    }
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0087c450("Studio",ppppuVar2,ppppuVar3,0,0,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      ppppuVar3 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar4) {
        ppppuVar3 = (undefined4 ****)apppuStack_28[0][-1];
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar3,uVar4);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  }
  (**(code **)(*param_1 + 0x1fc))(param_2,apppuStack_40);
  if (param_2 == 0x10b) {
    puVar5 = &DAT_01d7a8e8;
    if (0xf < DAT_01d7a8fc) {
      puVar5 = DAT_01d7a8e8;
    }
    cVar1 = (**(code **)(*param_1 + 0xd4))();
    pcVar6 = "ServerLuaKick";
    if (cVar1 == '\0') {
      pcVar6 = "LocalLuaKick";
    }
    FUN_0087c450(&DAT_018c5f98,pcVar6,puVar5,0,0,0);
  }
  iStack_8 = 0xffffffff;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < uVar4) {
      ppppuVar3 = (undefined4 ****)apppuStack_40[0][-1];
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
  FUN_0062baf0(param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6896 ; VA 0x0062b590 ; FUN_0062b590 */

void __thiscall FUN_0062b590(int param_1,undefined4 param_2)

{
  undefined auStack_54 [16];
  undefined4 uStack_44;
  undefined *puStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [20];
  undefined4 uStack_24;
  undefined4 uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee88;
  pvStack_10 = ExceptionList;
  uStack_20 = param_2;
  puStack_40 = auStack_38;
  uStack_3c = param_2;
  uStack_44 = 0x62b5c0;
  ExceptionList = &pvStack_10;
  FUN_0061be30();
  uStack_3c = 1;
  uStack_8 = 0;
  FUN_006b1620(auStack_54,param_1 + 0x74,1,0x7c);
  uStack_8 = 0xffffffff;
  FUN_0062db20();
  uStack_20 = param_2;
  uStack_24 = 0x62b5f8;
  FUN_0062b370();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6897 ; VA 0x0062b610 ; FUN_0062b610 */

void __thiscall FUN_0062b610(int param_1,uint param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005c9310(param_2);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar3);
    return;
  }
  if (*(uint *)(param_1 + 0x10) < param_2) {
    uVar3 = (*(uint *)(param_1 + 8) >> 1) + *(int *)(param_1 + 8);
    if (param_2 < uVar3) {
      param_2 = uVar3;
    }
    iVar4 = FUN_005c9310(param_2);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar5;
      while (puVar2 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar1 = (int)puVar5;
          puVar5 = puVar2;
        }
        else {
          *puVar5 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar5;
      }
    }
  }
  return;
}



/* FUNCTION 6898 ; VA 0x0062b6b0 ; FUN_0062b6b0 */

void __thiscall FUN_0062b6b0(double *param_1,double *param_2)

{
  double dVar1;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_01682800(&uStack_c);
  dVar1 = *param_1;
  *(undefined4 *)param_1 = uStack_c;
  *(undefined4 *)((int)param_1 + 4) = uStack_8;
  *param_2 = (double)CONCAT44(uStack_8,uStack_c) - dVar1;
  return;
}



/* FUNCTION 6899 ; VA 0x0062b6f0 ; FUN_0062b6f0 */

void __fastcall FUN_0062b6f0(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined auStack_c [8];
  
  param_1[1] = *param_1;
  param_1[3] = 0;
  param_1[7] = param_1[6];
  param_1[9] = 0;
  param_1[0xd] = param_1[0xc];
  param_1[0xf] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  puVar1 = (undefined4 *)FUN_016830f0(auStack_c);
  param_1[0x18] = *puVar1;
  param_1[0x19] = puVar1[1];
  return;
}



/* FUNCTION 6900 ; VA 0x0062b770 ; FUN_0062b770 */

void __fastcall FUN_0062b770(int param_1)

{
  *(undefined4 *)(param_1 + 0x3938) = 0;
  *(undefined4 *)(param_1 + 0x3940) = 0;
  *(undefined4 *)(param_1 + 0x3944) = 0;
  *(undefined4 *)(param_1 + 0x3948) = 0;
  *(undefined4 *)(param_1 + 0x394c) = 0;
  *(undefined *)(param_1 + 0x3950) = 1;
  *(undefined4 *)(param_1 + 0x3960) = 0;
  *(undefined4 *)(param_1 + 0x3968) = 0;
  *(undefined4 *)(param_1 + 0x396c) = 0;
  *(undefined4 *)(param_1 + 0x3970) = 0;
  *(undefined4 *)(param_1 + 0x3974) = 0;
  *(undefined *)(param_1 + 0x3978) = 1;
  *(undefined4 *)(param_1 + 0x3988) = 0;
  *(undefined4 *)(param_1 + 0x3990) = 0;
  *(undefined4 *)(param_1 + 0x3994) = 0;
  *(undefined4 *)(param_1 + 0x3998) = 0;
  *(undefined4 *)(param_1 + 0x399c) = 0;
  *(undefined *)(param_1 + 0x39a0) = 1;
  *(undefined4 *)(param_1 + 0x39b0) = 0;
  *(undefined4 *)(param_1 + 0x39b4) = 0;
  *(undefined4 *)(param_1 + 0x39b8) = 0;
  *(undefined4 *)(param_1 + 0x39bc) = 0;
  *(undefined *)(param_1 + 0x39c8) = 1;
  *(undefined8 *)(param_1 + 0x39c0) = 0;
  *(undefined4 *)(param_1 + 0x39e0) = 0;
  *(undefined4 *)(param_1 + 0x39e8) = 0;
  *(undefined4 *)(param_1 + 0x39ec) = 0;
  *(undefined4 *)(param_1 + 0x39f0) = 0;
  *(undefined4 *)(param_1 + 0x39f4) = 0;
  *(undefined *)(param_1 + 0x39f8) = 1;
  *(undefined4 *)(param_1 + 0x39d0) = 0;
  *(undefined4 *)(param_1 + 0x3a00) = 0;
  *(undefined4 *)(param_1 + 0x3a04) = 0;
  *(undefined4 *)(param_1 + 0x3a08) = 0;
  *(undefined4 *)(param_1 + 0x3a0c) = 0;
  *(undefined4 *)(param_1 + 0x3a18) = 0;
  *(undefined4 *)(param_1 + 0x3a20) = 0;
  *(undefined4 *)(param_1 + 0x3a24) = 0;
  *(undefined4 *)(param_1 + 0x3a28) = 0;
  *(undefined4 *)(param_1 + 0x3a2c) = 0;
  *(undefined *)(param_1 + 0x3a30) = 1;
  *(undefined4 *)(param_1 + 0x3a40) = 0;
  *(undefined4 *)(param_1 + 0x3a48) = 0;
  *(undefined4 *)(param_1 + 0x3a4c) = 0;
  *(undefined4 *)(param_1 + 0x3a50) = 0;
  *(undefined4 *)(param_1 + 0x3a54) = 0;
  *(undefined *)(param_1 + 0x3a58) = 1;
  *(undefined4 *)(param_1 + 0x3a68) = 0;
  *(undefined4 *)(param_1 + 0x3a70) = 0;
  *(undefined4 *)(param_1 + 0x3a74) = 0;
  *(undefined4 *)(param_1 + 0x3a78) = 0;
  *(undefined4 *)(param_1 + 0x3a7c) = 0;
  *(undefined *)(param_1 + 0x3a80) = 1;
  *(undefined4 *)(param_1 + 0x3a90) = 0;
  *(undefined4 *)(param_1 + 15000) = 0;
  *(undefined4 *)(param_1 + 0x3a9c) = 0;
  *(undefined4 *)(param_1 + 0x3aa0) = 0;
  *(undefined4 *)(param_1 + 0x3aa4) = 0;
  *(undefined *)(param_1 + 0x3aa8) = 1;
  *(undefined4 *)(param_1 + 0x3ab0) = 0;
  *(undefined4 *)(param_1 + 0x3ab4) = 0;
  *(undefined4 *)(param_1 + 0x3ab8) = 0;
  *(undefined4 *)(param_1 + 0x3abc) = 0;
  *(undefined8 *)(param_1 + 0x3ac0) = 0;
  *(undefined4 *)(param_1 + 0x3ac8) = 0;
  *(undefined4 *)(param_1 + 0x3acc) = 0;
  *(undefined4 *)(param_1 + 0x3ad0) = 0;
  *(undefined4 *)(param_1 + 0x3ad4) = 0;
  *(undefined4 *)(param_1 + 0x3ad8) = 0;
  return;
}



/* FUNCTION 6901 ; VA 0x0062b8c0 ; FUN_0062b8c0 */

undefined4 __thiscall FUN_0062b8c0(int param_1,undefined4 param_2)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0x6c) != 0) {
    piVar1 = (int *)FUN_0054db20();
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x148))(param_2);
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 6902 ; VA 0x0062b8f0 ; FUN_0062b8f0 */

void __thiscall FUN_0062b8f0(double *param_1,int param_2)

{
  double dVar1;
  short sVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  double dStack_c;
  
  dStack_c = (double)param_2;
  sVar2 = FUN_017265ed(&dStack_c);
  if (sVar2 < 1) {
    dVar1 = *param_1;
    dVar5 = DAT_018c0d60 - dVar1;
    dVar3 = (double)param_2;
    dVar4 = dVar3;
    if (*(char *)(param_1 + 4) == '\0') {
      dVar4 = param_1[2] * dVar5 + dVar3 * dVar1;
    }
    *(int *)(param_1 + 1) = param_2;
    param_1[2] = dVar4;
    *(undefined *)(param_1 + 4) = 0;
    param_1[3] = (dVar3 - dVar4) * (dVar3 - dVar4) * dVar1 + param_1[3] * dVar5;
  }
  return;
}



/* FUNCTION 6903 ; VA 0x0062b990 ; FUN_0062b990 */

void __thiscall FUN_0062b990(double *param_1,double param_2)

{
  double dVar1;
  short sVar2;
  double dVar3;
  double dVar4;
  double dStack_c;
  
  dStack_c = param_2;
  sVar2 = FUN_017265ed(&dStack_c);
  if (sVar2 < 1) {
    dVar1 = *param_1;
    dVar3 = DAT_018c0d60 - dVar1;
    dVar4 = param_2;
    if (*(char *)(param_1 + 4) == '\0') {
      dVar4 = param_1[2] * dVar3 + dVar1 * param_2;
    }
    *(undefined *)(param_1 + 4) = 0;
    param_1[1] = param_2;
    param_1[2] = dVar4;
    param_1[3] = (param_2 - dVar4) * (param_2 - dVar4) * dVar1 + dVar3 * param_1[3];
  }
  return;
}



/* FUNCTION 6904 ; VA 0x0062ba20 ; FUN_0062ba20 */

void __fastcall FUN_0062ba20(double *param_1)

{
  double dVar1;
  short sVar2;
  double dVar3;
  double dVar4;
  double dStack_1c;
  double dStack_14;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (*(char *)(param_1 + 1) == '\0') {
    FUN_016827a0(&uStack_c);
    dStack_1c = (double)CONCAT44(uStack_8,uStack_c) - *param_1;
    *(undefined4 *)param_1 = uStack_c;
    *(undefined4 *)((int)param_1 + 4) = uStack_8;
    dStack_14 = dStack_1c;
    sVar2 = FUN_017265ed(&dStack_1c);
    if (sVar2 < 1) {
      dVar1 = param_1[2];
      dVar4 = DAT_018c0d60 - dVar1;
      dVar3 = dStack_14;
      if (*(char *)(param_1 + 6) == '\0') {
        dVar3 = param_1[4] * dVar4 + dVar1 * dStack_14;
      }
      param_1[3] = dStack_14;
      *(undefined *)(param_1 + 6) = 0;
      param_1[4] = dVar3;
      param_1[5] = (dStack_14 - dVar3) * (dStack_14 - dVar3) * dVar1 + param_1[5] * dVar4;
    }
    return;
  }
  FUN_016827a0(&uStack_c);
  *(undefined4 *)param_1 = uStack_c;
  *(undefined4 *)((int)param_1 + 4) = uStack_8;
  *(undefined *)(param_1 + 1) = 0;
  return;
}



/* FUNCTION 6905 ; VA 0x0062baf0 ; FUN_0062baf0 */

void __thiscall FUN_0062baf0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179eea8;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x1db9) == '\0') {
    ExceptionList = &pvStack_10;
    *(undefined *)(param_1 + 0x1db9) = 1;
    FUN_0060e0c0(&uStack_20,param_1);
    uStack_8 = 0;
    iStack_14 = FUN_008f7870(param_1);
    if (iStack_14 != 0) {
      if (piStack_1c != (int *)0x0) {
        piVar1 = piStack_1c + 2;
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uVar3 = 0;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[2] = piStack_1c[2] + 1;
        UNLOCK();
      }
      FUN_00605260(uStack_20,piStack_1c,param_2);
      if (piStack_1c != (int *)0x0) {
        piVar1 = piStack_1c + 2;
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)(*piStack_1c + 4))(uVar3);
        }
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
      FUN_0090ca30(uVar3);
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6906 ; VA 0x0062bbf0 ; FUN_0062bbf0 */

void __thiscall FUN_0062bbf0(int *param_1,int *param_2,int *param_3,char param_4,int *param_5)

{
  int iVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 ******ppppppuVar7;
  undefined8 uVar8;
  undefined4 *****apppppuStack_38 [3];
  undefined auStack_2c [8];
  uint uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179eed0;
  pvStack_10 = ExceptionList;
  if (param_2 != (int *)0x0) {
    iVar1 = param_1[0x7b9];
    piStack_18 = param_1 + 0x7b9;
    piStack_20 = param_2;
    piStack_1c = param_5;
    ExceptionList = &pvStack_10;
    *piStack_18 = (int)&piStack_20;
    uStack_8 = 0;
    iStack_14 = iVar1;
    if (param_4 == '\0') {
      cVar3 = FUN_00620ff0(param_2);
      if (cVar3 == '\0') {
        iVar4 = *param_3;
        iVar5 = FUN_00888530();
        if (iVar4 != iVar5) {
          (**(code **)(*param_2 + 0x20))(param_5,param_3);
          if (((DAT_01eace3b == '\0') || (cVar3 = (**(code **)(*param_1 + 0x11c))(), cVar3 == '\0'))
             || ((param_2 != &DAT_01ef0a50 && (param_2 != &DAT_01ee5728)))) {
            if (piStack_18 == (int *)0x0) {
              ExceptionList = pvStack_10;
              return;
            }
          }
          else {
            iVar4 = (**(code **)(*param_1 + 0xb8))();
            if (iVar4 == 0) {
              if (DAT_01eace3b != '\0') {
                FUN_016774b0(DAT_01eace3b,"RemotePlayer not found in Replicator - Non default",0);
              }
              param_1[0x7b9] = iVar1;
              ExceptionList = pvStack_10;
              return;
            }
            if (DAT_01d5a020 == '\0') {
              if (((param_5 != (int *)0x0) &&
                  (iVar4 = param_5[3], iVar5 = FUN_00ae2430(),
                  (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
                  (uint)*(ushort *)(iVar5 + 0x1da))) && (DAT_01eace3b != '\0')) {
                puVar6 = (undefined4 *)(**(code **)(*param_5 + 0xac))();
                if (0xf < (uint)puVar6[5]) {
                  puVar6 = (undefined4 *)*puVar6;
                }
                uVar8 = FUN_00928340();
                FUN_01677520(DAT_01eace3b,"UID: %lld ESH: %s",uVar8,puVar6);
              }
            }
            else {
              (**(code **)(*param_2 + 0x30))(apppppuStack_38,param_5);
              uStack_8 = CONCAT31(uStack_8._1_3_,1);
              if (DAT_01eace3b != '\0') {
                ppppppuVar7 = apppppuStack_38;
                if (0xf < uStack_24) {
                  ppppppuVar7 = (undefined4 ******)apppppuStack_38[0];
                }
                uVar8 = FUN_00928340();
                FUN_01677520(DAT_01eace3b,"UID: %lld ES:\n%s",uVar8,ppppppuVar7);
              }
              FUN_005507b0();
            }
          }
        }
      }
      else {
        iVar4 = *param_3;
        iVar5 = FUN_00888530();
        if (iVar4 != iVar5) {
          pcVar2 = *(code **)(*param_2 + 0x48);
          puVar6 = (undefined4 *)FUN_00605c00();
          (*pcVar2)(param_5,*puVar6);
        }
      }
    }
    else {
      iVar4 = FUN_0061ec80(*(undefined4 *)(param_5[3] + 4));
      if (iVar4 == 0) {
        FUN_016756b0(auStack_2c,
                     "Unable to read default value, default instance does not exist locally");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_2c,&DAT_01c17198);
      }
      (**(code **)(*param_2 + 0x24))(iVar4,param_5);
      if (((DAT_01eace3b != '\0') && (cVar3 = (**(code **)(*param_1 + 0x11c))(), cVar3 != '\0')) &&
         ((param_2 == &DAT_01ef0a50 || (param_2 == &DAT_01ee5728)))) {
        iVar4 = (**(code **)(*param_1 + 0xb8))();
        if (iVar4 == 0) {
          if (DAT_01eace3b != '\0') {
            FUN_016774b0(DAT_01eace3b,"RemotePlayer not found in Replicator - Default value",0);
          }
        }
        else if (DAT_01eace3b != '\0') {
          uVar8 = FUN_00928340();
          FUN_01677520(DAT_01eace3b,"UID: %lld Script being set to default value.",uVar8);
        }
      }
    }
    *piStack_18 = iVar1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6907 ; VA 0x0062bef0 ; FUN_0062bef0 */

void __thiscall FUN_0062bef0(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined uVar4;
  uint uVar5;
  int ***pppiVar6;
  int iVar7;
  double *pdVar8;
  undefined4 *puVar9;
  int ****ppppiVar10;
  int ****ppppiVar11;
  char *pcVar12;
  undefined8 uVar13;
  undefined *puStack_1a8;
  undefined4 *puStack_1a4;
  undefined auStack_1a0 [8];
  char *pcStack_198;
  undefined *puStack_194;
  code *pcStack_190;
  undefined4 uStack_18c;
  int *piStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined ***pppuStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined *puStack_170;
  int ***pppiStack_16c;
  int ***pppiStack_168;
  int *piStack_164;
  int ***pppiStack_160;
  int ***pppiStack_15c;
  int ***pppiStack_158;
  undefined8 uStack_154;
  undefined auStack_144 [28];
  undefined auStack_128 [36];
  undefined **ppuStack_104;
  int *piStack_100;
  undefined4 *puStack_fc;
  undefined ***pppuStack_e0;
  undefined auStack_dc [8];
  double dStack_d4;
  uint uStack_cc;
  undefined4 uStack_c8;
  undefined8 uStack_c4;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined auStack_b4 [4];
  int **ppiStack_b0;
  int ***pppiStack_ac;
  int ***pppiStack_a8;
  int ***pppiStack_a4;
  int ***pppiStack_a0;
  undefined4 uStack_9c;
  uint uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined auStack_88 [12];
  int ***pppiStack_7c;
  int ***pppiStack_78;
  char *pcStack_70;
  undefined *puStack_6c;
  undefined8 uStack_68;
  int **ppiStack_60;
  int *piStack_5c;
  uint uStack_58;
  int iStack_54;
  uint uStack_50;
  char *pcStack_4c;
  undefined *puStack_48;
  int iStack_44;
  uint uStack_40;
  undefined uStack_39;
  int ***pppiStack_38;
  int ***pppiStack_34;
  int ***pppiStack_30;
  int *piStack_2c;
  int ***pppiStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  char acStack_1c [4];
  undefined4 *puStack_18;
  int ***pppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179efd1;
  pvStack_10 = ExceptionList;
  iStack_44 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_2c = param_1;
  if (*(int *)(iStack_44 + 0x34) < DAT_01ead170) {
    uStack_154._4_4_ = (char *)&DAT_01ead170;
    uStack_154._0_4_ = (char *)0x62c87b;
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    if (DAT_01ead170 == -1) {
      uStack_154._4_4_ = (char *)0xffffffff;
      uStack_154._0_4_ = "Join Snapshot";
      pppiStack_158 = (int ***)&DAT_018c5904;
      uStack_8 = 0;
      pppiStack_15c = (int ***)0x62c8a3;
      uVar13 = FUN_0152dab0();
      DAT_01ead16c = (undefined4)((ulonglong)uVar13 >> 0x20);
      DAT_01ead168 = (uint)uVar13;
      pppiStack_15c = (int ***)&DAT_01ead170;
      uStack_8 = 0xffffffff;
      pppiStack_160 = (int ***)0x62c8bf;
      FUN_016f37bf();
    }
  }
  uStack_154._4_4_ = (char *)DAT_01ead16c;
  uStack_154._0_4_ = (char *)DAT_01ead168;
  uStack_98 = DAT_01ead168;
  uStack_cc = DAT_01ead168;
  uStack_94 = DAT_01ead16c;
  uStack_c8 = DAT_01ead16c;
  pppiStack_158 = (int ***)0x62bf62;
  uStack_c4 = FUN_0152d930();
  pppiStack_158 = (int ***)&dStack_d4;
  uStack_8 = 1;
  pppiStack_15c = (int ***)0x62bf81;
  FUN_016827e0();
  puVar9 = (undefined4 *)0x0;
  puStack_20 = (undefined4 *)0x0;
  if (DAT_01ee420d != 0) {
    uStack_154._4_4_ = (char *)0x62bf99;
    uVar5 = FUN_0061f540();
    uStack_154._0_4_ = (char *)(uVar5 & 0xff);
    pppiStack_158 = (int ***)(uint)DAT_01d5b820;
    uStack_154._4_4_ = (char *)0x0;
    pppiStack_160 = (int ***)(uint)DAT_01ee420d;
    pppiStack_15c = (int ***)0x18cd9d0;
    piStack_164 = (int *)0x62bfb8;
    FUN_01677490();
  }
  if ((param_1[0xe02] & 0x20000U) == 0) {
    uStack_154._4_4_ = (char *)0x62bfdb;
    cVar3 = (**(code **)(*param_1 + 0xd4))();
    if (cVar3 != '\0') {
      uStack_154._4_4_ = (char *)0xb0;
      uStack_154._0_4_ = (char *)0x62bfed;
      puVar9 = (undefined4 *)FUN_01674e20();
      uStack_8._0_1_ = 2;
      puStack_18 = puVar9;
      if (puVar9 == (undefined4 *)0x0) {
        puVar9 = (undefined4 *)0x0;
        puStack_20 = (undefined4 *)0x0;
      }
      else {
        uStack_154._0_4_ = (char *)0x62c00c;
        uStack_154._4_4_ = (char *)param_1;
        puStack_20 = puVar9;
        FUN_006b1a30();
        *puVar9 = RBX::Network::Replicator::JoinDataItem::vftable;
        ppppiVar10 = (int ****)(puVar9 + 0xc);
        uStack_154._4_4_ = (char *)0x0;
        uStack_154._0_4_ = (char *)0x0;
        uStack_8._0_1_ = 3;
        *ppppiVar10 = (int ***)0x0;
        puVar9[0xd] = 0;
        pppiStack_158 = (int ***)0x62c034;
        pppiStack_30 = (int ***)ppppiVar10;
        pppiVar6 = (int ***)FUN_00616d10();
        puVar9 = puStack_20;
        *ppppiVar10 = pppiVar6;
        uStack_8._0_1_ = 4;
        puStack_20[0xe] = 0xffffffff;
        puStack_20[0xf] = 0;
        puStack_20[0x10] = 0;
        puStack_20[0x11] = 0;
        puStack_20[0x12] = 0;
        puStack_20[0x13] = 0;
        puStack_20[0x14] = 0;
        puStack_20[0x15] = 0;
        puStack_20[0x16] = 0;
        uStack_154._4_4_ = (char *)0x62c084;
        FUN_006ab530();
        puVar9[0x21] = 0;
        puVar9[0x22] = 0;
        puVar9[0x23] = 0;
        uStack_8._0_1_ = 6;
        puVar9[0x28] = 0;
        uStack_154._4_4_ = (char *)0xc;
        puVar9[0x29] = 0xf;
        uStack_154._0_4_ = "JoinDataItem";
        *(undefined *)(puVar9 + 0x24) = 0;
        pppiStack_158 = (int ***)0x62c0c9;
        FUN_005542c0();
        *(undefined *)(puVar9 + 0x2a) = 1;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      puVar9[0xe] = (uint)DAT_01d6520c * 1000;
      uStack_154._0_4_ = (char *)0x62c0f7;
      uStack_154._4_4_ = (char *)puVar9;
      FUN_006b1f50();
    }
  }
  pppuStack_e0 = &ppuStack_104;
  ppuStack_104 = std::
                 _Func_impl_no_alloc<class_<lambda_f98ccb6a5bed2139072d681c8827c301>,void,class_std::shared_ptr<class_RBX::Instance>_const&,struct_RBX::Network::NetworkSchema::ClassInfo_const&,class_std::shared_ptr<struct_RBX::Network::CachedBitstream>&&,bool>
                 ::vftable;
  uStack_154._4_4_ = (char *)param_2;
  uStack_154._0_4_ = (char *)&uStack_50;
  uStack_8._0_1_ = 7;
  pppiStack_158 = (int ***)0x62c129;
  piStack_100 = param_1;
  puStack_fc = puVar9;
  FUN_006abc60();
  if (DAT_01d59eec <= uStack_50) {
    if (DAT_01eace68 != 0) {
      uStack_154._4_4_ = (char *)0x0;
      uStack_154._0_4_ = (char *)0x0;
      pppiStack_158 = (int ***)0xffffffff;
      pppiStack_15c = (int ***)0x62c8e5;
      FUN_0151f6f0();
      uStack_154._4_4_ = (char *)uStack_50;
      uStack_8._0_1_ = 8;
      uStack_154._0_4_ = "Count";
      pppiStack_158 = (int ***)0x62c8fc;
      FUN_0151fa60();
      uStack_154._4_4_ = "TopReplicationContainer (read)";
      uStack_154._0_4_ = &DAT_018bf030;
      pppiStack_158 = (int ***)0x62c911;
      FUN_0151f850();
      iVar7 = DAT_01eace68;
      uStack_154._4_4_ = "ReplicatorTopContainerCountLimit";
      uStack_154._0_4_ = "j";
      FUN_0054eff0();
      uStack_154._4_4_ = (char *)0x0;
      uStack_154._0_4_ = (char *)iVar7;
      pppiStack_158 = (int ***)auStack_88;
      uStack_8._0_1_ = 9;
      pppiStack_15c = (int ***)0x62c940;
      FUN_01520d20();
      uStack_154._4_4_ = (char *)0x62c94b;
      FUN_005507b0();
      uStack_8._0_1_ = 7;
      uStack_154._4_4_ = (char *)0x62c95a;
      FUN_0151f7f0();
    }
    uStack_154._4_4_ = "Too many top replication containers";
                    /* WARNING: Subroutine does not return */
    uStack_154._0_4_ = (char *)0x62c964;
    FUN_016757c0();
  }
  uStack_58 = 0;
  if (uStack_50 != 0) {
    do {
      if (puVar9 == (undefined4 *)0x0) {
        iStack_54 = 0;
      }
      else {
        iStack_54 = puVar9[0xd];
      }
      if (*(int *)(iStack_44 + 0x34) < DAT_01ead180) {
        uStack_154._4_4_ = (char *)&DAT_01ead180;
        uStack_154._0_4_ = (char *)0x62c96e;
        FUN_016f3809();
        if (DAT_01ead180 == -1) {
          uStack_154._4_4_ = (char *)0xffffffff;
          uStack_154._0_4_ = "Container Queue";
          pppiStack_158 = (int ***)&DAT_018c5904;
          uStack_8._0_1_ = 10;
          pppiStack_15c = (int ***)0x62c993;
          uVar13 = FUN_0152dab0();
          DAT_01ead17c = (undefined *)((ulonglong)uVar13 >> 0x20);
          DAT_01ead178 = (char *)uVar13;
          pppiStack_15c = (int ***)&DAT_01ead180;
          uStack_8._0_1_ = 7;
          pppiStack_160 = (int ***)0x62c9ac;
          FUN_016f37bf();
        }
      }
      uStack_154._4_4_ = DAT_01ead17c;
      uStack_154._0_4_ = DAT_01ead178;
      pcStack_4c = DAT_01ead178;
      pcStack_70 = DAT_01ead178;
      puStack_48 = DAT_01ead17c;
      puStack_6c = DAT_01ead17c;
      pppiStack_158 = (int ***)0x62c195;
      uVar13 = FUN_0152d930();
      uStack_154._4_4_ = (char *)param_2;
      uStack_154._0_4_ = auStack_dc;
      uStack_8._0_1_ = 0xb;
      pppiStack_158 = (int ***)0x62c1b3;
      uStack_68 = uVar13;
      FUN_006b8fd0();
      uStack_154._0_4_ = (char *)&uStack_40;
      uStack_154._4_4_ = (char *)0x2;
      pppiStack_158 = (int ***)0x62c1c1;
      cVar3 = FUN_006abe60();
      if (cVar3 == '\0') {
        uStack_154._4_4_ = "readFast past end for uint16_t";
        uStack_154._0_4_ = (char *)0x62c84a;
        FUN_0054eff0();
        uStack_154._4_4_ = auStack_88;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
        uStack_154._0_4_ = (char *)0x62c860;
        FUN_005f8ef0();
        uStack_154._4_4_ = &DAT_01c27108;
        uStack_154._0_4_ = auStack_128;
                    /* WARNING: Subroutine does not return */
        pppiStack_158 = (int ***)0x62c871;
        FUN_0170c2a8();
      }
      uStack_40 = (uint)(ushort)((ushort)uStack_40 << 8 | (ushort)uStack_40 >> 8);
      uStack_154._4_4_ = (char *)0x62c1df;
      uVar4 = FUN_006abd90();
      pppiStack_34 = (int ***)CONCAT31(pppiStack_34._1_3_,uVar4);
      uStack_154._4_4_ = (char *)0x62c1ea;
      uVar4 = FUN_006abd90();
      pppiStack_38 = (int ***)CONCAT31(pppiStack_38._1_3_,uVar4);
      pppiStack_14 = *(int ****)(param_1[0x67d] + 0x58);
      if (((uint)((*(int *)(param_1[0x67d] + 0x5c) - (int)pppiStack_14) / 0x3c) <=
           (uStack_40 & 0xffff)) ||
         (pppiStack_14 = (int ***)((int ****)pppiStack_14 + (uStack_40 & 0xffff) * 0xf),
         (int ****)pppiStack_14 == (int ****)0x0)) {
        uStack_154._0_4_ = auStack_b4;
        uStack_154._4_4_ = "Top replication container definition included invalid class network id";
        pppiStack_158 = (int ***)0x62ca5c;
        FUN_016756b0();
        uStack_154._0_4_ = auStack_b4;
        uStack_154._4_4_ = &DAT_01c17198;
                    /* WARNING: Subroutine does not return */
        pppiStack_158 = (int ***)&UNK_0062ca70;
        FUN_0170c2a8();
      }
      if (((int ****)pppiStack_14)[2] == (int ***)0x0) {
        uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
        pppiStack_158 = (int ***)puStack_48;
        pppiStack_15c = (int ***)pcStack_4c;
        pppiStack_160 = (int ***)0x62c251;
        uStack_154 = uStack_68;
        FUN_0152dda0();
      }
      else {
        uStack_154._4_4_ = (char *)((int ****)pppiStack_14)[2][1];
        pppiStack_158 = (int ***)&pppiStack_28;
        pppiStack_15c = (int ***)0x62c263;
        uStack_154._0_4_ = (char *)param_1;
        FUN_008a98b0();
        piVar2 = piStack_24;
        uStack_8._0_1_ = 0xe;
        uVar4 = (undefined)uStack_8;
        uStack_8._0_1_ = 0xe;
        if ((int ****)pppiStack_28 == (int ****)0x0) {
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar7 = piStack_24[1] + -1;
            piStack_24[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              uStack_154._4_4_ = (char *)0x62c287;
              (**(code **)*piStack_24)();
              LOCK();
              piVar1 = piVar2 + 2;
              iVar7 = *piVar1 + -1;
              *piVar1 = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                uStack_154._4_4_ = (char *)0x62c298;
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
        }
        else {
          uStack_8._0_1_ = uVar4;
          if (*(int *)(iStack_44 + 0x34) < DAT_01ead190) {
            uStack_154._4_4_ = (char *)&DAT_01ead190;
            uStack_154._0_4_ = (char *)0x62c9be;
            FUN_016f3809();
            if (DAT_01ead190 == -1) {
              uStack_154._4_4_ = &DAT_018c5904;
              uStack_8._0_1_ = 0x10;
              uStack_154._0_4_ = (char *)0x62c9dc;
              uVar13 = FUN_0152da50();
              DAT_01ead18c = (undefined4)((ulonglong)uVar13 >> 0x20);
              DAT_01ead188 = (undefined4)uVar13;
              uStack_154._0_4_ = (char *)&DAT_01ead190;
              uStack_8._0_1_ = 0xe;
              pppiStack_158 = (int ***)0x62c9f5;
              FUN_016f37bf();
            }
          }
          ppppiVar10 = (int ****)pppiStack_14;
          uStack_154._4_4_ = (char *)pppiStack_14[2][1];
          if ((int *)0xf < *(int **)((int)uStack_154._4_4_ + 0x14)) {
            uStack_154._4_4_ = *(char **)uStack_154._4_4_;
          }
          uStack_154._0_4_ = (char *)DAT_01ead18c;
          pppiStack_158 = (int ***)DAT_01ead188;
          pppiStack_15c = (int ***)0x62c2d8;
          FUN_0152d740();
          uStack_154._4_4_ = auStack_dc;
          uStack_154._0_4_ = (char *)pppiStack_28;
          pppiStack_158 = (int ***)0x62c2ed;
          uVar5 = FUN_006188a0();
          ppiStack_60 = (int **)0x0;
          piStack_5c = (int *)0x0;
          uStack_8._0_1_ = 0x11;
          if (((char)pppiStack_38 != '\0') || ((char)pppiStack_34 != '\0')) {
            if (DAT_01d5b840 == '\0') {
LAB_0062c328:
              uStack_154._4_4_ = (char *)(uVar5 & 0xffffff00);
            }
            else {
              uStack_154._4_4_ = (char *)0x62c320;
              uVar5 = (**(code **)(*param_1 + 0xd4))();
              if ((char)uVar5 == '\0') goto LAB_0062c328;
              uStack_154._4_4_ = (char *)CONCAT31((int3)(uVar5 >> 8),1);
            }
            uStack_154._0_4_ = (char *)&ppiStack_60;
            pppiStack_158 = (int ***)0x0;
            pppiStack_15c = pppiStack_38;
            pppiStack_160 = pppiStack_34;
            if (piStack_24 != (int *)0x0) {
              LOCK();
              piStack_24[1] = piStack_24[1] + 1;
              UNLOCK();
            }
            pppiStack_168 = pppiStack_28;
            piStack_164 = piStack_24;
            pppiStack_16c = (int ***)ppppiVar10;
            puStack_170 = (undefined *)0x62c367;
            FUN_00617d00();
          }
          uStack_154._4_4_ = (char *)0x62c373;
          cVar3 = (**(code **)(*param_1 + 0xd4))();
          if ((cVar3 != '\0') && ((char)pppiStack_34 != '\0')) {
            if ((DAT_01d5b820 != 0) && (((byte)pppiStack_28[3][0x75] & 3) != 2)) {
              if (DAT_01ee420d != 0) {
                uStack_154._4_4_ = auStack_88;
                uStack_154._0_4_ = (char *)0x62c3b9;
                pppiStack_158 = (int ***)FUN_008a2380();
                uStack_8._0_1_ = 0x12;
                if ((int ***)0xf < ((int ****)pppiStack_158)[5]) {
                  pppiStack_158 = (int ***)*pppiStack_158;
                }
                uStack_154._4_4_ = (char *)0x0;
                uStack_154._0_4_ = "JoinDataItem";
                pppiStack_160 = (int ***)(uint)DAT_01ee420d;
                pppiStack_15c = (int ***)0x18cdaf0;
                piStack_164 = (int *)0x62c3df;
                FUN_01677490();
                uStack_8._0_1_ = 0x11;
                uStack_154._4_4_ = (char *)0x62c3f1;
                FUN_005507b0();
              }
              uStack_154._4_4_ = (char *)0x62c3fc;
              FUN_006d9060();
              uStack_154._4_4_ = (char *)pppiStack_28;
              uStack_154._0_4_ = (char *)0x62c40c;
              uStack_154._4_4_ = (char *)FUN_006d9e30();
              uStack_154._0_4_ = (char *)pppiStack_38;
              pppiStack_15c = (int ***)&pppiStack_28;
              pppiStack_158 = pppiStack_34;
              pppiStack_160 = (int ***)0x62c41e;
              FUN_006c9080();
              ppppiVar10 = (int ****)pppiStack_14;
            }
            uStack_154._4_4_ = (char *)0x62c428;
            cVar3 = FUN_0061f540();
            if (cVar3 == '\0') {
              acStack_1c[0] = cVar3;
              if (pppuStack_e0 == (undefined ***)0x0) {
                    /* WARNING: Subroutine does not return */
                uStack_154._4_4_ = (char *)0x62ca4b;
                FUN_016ddc9c();
              }
              uStack_154._4_4_ = acStack_1c;
              uStack_154._0_4_ = (char *)&ppiStack_60;
              pppiStack_15c = (int ***)&pppiStack_28;
              pppiStack_160 = (int ***)0x62c44f;
              pppiStack_158 = (int ***)ppppiVar10;
              (*(code *)(*pppuStack_e0)[2])();
            }
          }
          if ((char)pppiStack_38 != '\0') {
            uStack_154._4_4_ = (char *)0x62c465;
            cVar3 = (**(code **)(*param_1 + 0xd4))();
            if (cVar3 != '\0') {
              uStack_154._4_4_ = &uStack_39;
              uStack_bc = 0;
              uStack_154._0_4_ = (char *)&uStack_bc;
              uStack_b8 = 0;
              pppiStack_158 = (int ***)0x0;
              pppiStack_15c = (int ***)0x62c499;
              FUN_0060e9d0();
              pppiStack_7c = (int ***)0x0;
              pppiStack_78 = (int ***)0x0;
              pppiStack_14 = pppiStack_28;
              uStack_8._0_1_ = 0x13;
              pppiVar6 = (int ***)pppiStack_28[3];
              uStack_154._4_4_ = (char *)0x62c4b9;
              iVar7 = FUN_008aa870();
              uStack_8c = CONCAT31(uStack_8c._1_3_,
                                   (uint)*(ushort *)(pppiVar6 + 0x76) -
                                   (uint)*(ushort *)(iVar7 + 0x1d8) <=
                                   (uint)*(ushort *)(iVar7 + 0x1da));
              puStack_18 = &pppiStack_16c;
              uStack_90 = CONCAT31(uStack_90._1_3_,DAT_01ead01c);
              uStack_154._0_4_ = (char *)CONCAT31(uStack_154._1_3_,DAT_01d5b840);
              uStack_154._4_4_ = PTR_s_MegaReplicatorSetIsAliveForAllRe_01d5b844;
              puStack_170 = auStack_88;
              uStack_174 = 0x62c510;
              FUN_0060e970();
              puStack_170 = (undefined *)0x1;
              uStack_174 = 1;
              uStack_178 = uStack_8c;
              pppiStack_160 = pppiStack_7c;
              pppiStack_15c = pppiStack_78;
              pppuStack_17c = &ppuStack_104;
              uStack_180 = 0;
              uStack_184 = uStack_90;
              puStack_194 = auStack_144;
              uStack_18c = 0;
              pcStack_190 = FUN_0061f960;
              pcStack_198 = (char *)0x62c549;
              piStack_188 = param_1;
              puStack_18 = (undefined4 *)FUN_00605730();
              pppiVar6 = (int ***)pppiStack_14[0xb];
              if (pppiVar6 != (int ***)0x0) {
                pppiStack_ac = (int ***)pppiStack_14[0xc];
                if ((int ****)pppiStack_ac != (int ****)0x0) {
                  LOCK();
                  ((int ****)pppiStack_ac)[1] = (int ***)((int)((int ****)pppiStack_ac)[1] + 1);
                  UNLOCK();
                  pppiStack_ac = (int ***)pppiStack_14[0xc];
                  pppiVar6 = (int ***)pppiStack_14[0xb];
                }
                ppppiVar10 = (int ****)pppiVar6[1];
                ppppiVar11 = (int ****)*pppiVar6;
                uStack_8._0_1_ = 0x15;
                ppiStack_b0 = (int **)pppiVar6;
                pppiStack_14 = pppiStack_ac;
                if (ppppiVar11 != ppppiVar10) {
                  pppiStack_a0 = (int ***)(puStack_18 + 8);
                  do {
                    uStack_9c = CONCAT31(uStack_9c._1_3_,*(undefined *)(puStack_18 + 0xe));
                    uStack_154._4_4_ = (char *)uStack_9c;
                    uStack_154._0_4_ = (char *)pppiStack_a0;
                    pppiStack_a4 = (int ***)CONCAT31(pppiStack_a4._1_3_,
                                                     *(undefined *)(puStack_18 + 7));
                    pppiStack_158 = pppiStack_a4;
                    pppiStack_a8 = (int ***)CONCAT31(pppiStack_a8._1_3_,
                                                     *(undefined *)(puStack_18 + 6));
                    pppiStack_15c = pppiStack_a8;
                    pppiStack_30 = (int ***)CONCAT31(pppiStack_30._1_3_,
                                                     *(undefined *)(puStack_18 + 5));
                    pppiStack_160 = pppiStack_30;
                    piStack_164 = (int *)puStack_18[4];
                    pppiStack_168 = (int ***)puStack_18[3];
                    puStack_170 = (undefined *)0x62c5ed;
                    pppiStack_16c = (int ***)ppppiVar11;
                    (*(code *)*puStack_18)();
                    ppppiVar11 = ppppiVar11 + 2;
                  } while (ppppiVar11 != ppppiVar10);
                }
                param_1 = piStack_2c;
                if ((int ****)pppiStack_14 != (int ****)0x0) {
                  LOCK();
                  pppiVar6 = (int ***)((int)pppiStack_14[1] + -1);
                  pppiStack_14[1] = (int **)pppiVar6;
                  UNLOCK();
                  if (pppiVar6 == (int ***)0x0) {
                    uStack_154._4_4_ = (char *)0x62c60c;
                    (*(code *)**pppiStack_14)();
                    LOCK();
                    pppiVar6 = (int ***)((int)pppiStack_14[2] + -1);
                    pppiStack_14[2] = (int **)pppiVar6;
                    UNLOCK();
                    param_1 = piStack_2c;
                    if (pppiVar6 == (int ***)0x0) {
                      uStack_154._4_4_ = (char *)0x62c61e;
                      (*(code *)(*pppiStack_14)[1])();
                      param_1 = piStack_2c;
                    }
                  }
                }
              }
              uStack_154._4_4_ = (char *)0x62c62c;
              FUN_00611270();
              uStack_8._0_1_ = 0x11;
              uStack_154._4_4_ = (char *)0x62c63b;
              FUN_0056d380();
            }
          }
          puVar9 = puStack_20;
          if (puStack_20 != (undefined4 *)0x0) {
            if (*(int *)(iStack_44 + 0x34) < DAT_01ead1a0) {
              uStack_154._4_4_ = (char *)&DAT_01ead1a0;
              uStack_154._0_4_ = (char *)0x62ca07;
              FUN_016f3809();
              if (DAT_01ead1a0 == -1) {
                uStack_154._4_4_ = &DAT_018c5904;
                uStack_8._0_1_ = 0x16;
                uStack_154._0_4_ = (char *)0x62ca25;
                uVar13 = FUN_0152da50();
                DAT_01ead19c = (int ****)((ulonglong)uVar13 >> 0x20);
                DAT_01ead198 = (int ****)uVar13;
                uStack_154._0_4_ = (char *)&DAT_01ead1a0;
                uStack_8._0_1_ = 0x11;
                pppiStack_158 = (int ***)0x62ca3e;
                FUN_016f37bf();
              }
            }
            uStack_154._4_4_ = (char *)(puVar9[0xd] - iStack_54);
            uStack_154._0_4_ = "Items queued: %zu";
            pppiStack_158 = (int ***)DAT_01ead19c;
            pppiStack_15c = (int ***)DAT_01ead198;
            pppiStack_160 = (int ***)0x62c673;
            FUN_0152d760();
          }
          piVar2 = piStack_5c;
          if (piStack_5c != (int *)0x0) {
            LOCK();
            iVar7 = piStack_5c[1] + -1;
            piStack_5c[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              uStack_154._4_4_ = (char *)0x62c68d;
              (**(code **)*piStack_5c)();
              LOCK();
              piVar1 = piVar2 + 2;
              iVar7 = *piVar1 + -1;
              *piVar1 = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                uStack_154._4_4_ = (char *)0x62c69e;
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
          piVar2 = piStack_24;
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar7 = piStack_24[1] + -1;
            piStack_24[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              uStack_154._4_4_ = (char *)0x62c6b5;
              (**(code **)*piStack_24)();
              LOCK();
              piVar1 = piVar2 + 2;
              iVar7 = *piVar1 + -1;
              *piVar1 = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                uStack_154._4_4_ = (char *)0x62c6c6;
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
        }
        pppiStack_158 = (int ***)puStack_48;
        pppiStack_15c = (int ***)pcStack_4c;
        pppiStack_160 = (int ***)0x62c6db;
        uStack_154 = uStack_68;
        FUN_0152dda0();
        puVar9 = puStack_20;
      }
      uStack_58 = uStack_58 + 1;
      uStack_8._0_1_ = 7;
    } while (uStack_58 < uStack_50);
  }
  uStack_154._4_4_ = (char *)&ppiStack_b0;
  uStack_154._0_4_ = (char *)0x62c701;
  pdVar8 = (double *)FUN_016827e0();
  pcVar12 = (char *)(float)((*pdVar8 - dStack_d4) * DAT_018c0d70);
  if (DAT_01ee420a != 0) {
    piStack_164 = (int *)(uint)DAT_01ee420a;
    uStack_154._4_4_ = (char *)0x0;
    uStack_154._0_4_ = (char *)0x0;
    pppiStack_158 = (int ***)0x0;
    pppiStack_160 = (int ***)0x18cdb84;
    pppiStack_168 = (int ***)0x62c758;
    pppiStack_15c = (int ***)pcVar12;
    FUN_016774d0();
  }
  uStack_154._4_4_ = (char *)0x62c767;
  cVar3 = (**(code **)(*param_1 + 0xd4))();
  if (cVar3 != '\0') {
    uStack_154._0_4_ = (char *)0x62c771;
    uStack_154._4_4_ = (char *)param_1;
    puStack_18 = (undefined4 *)FUN_008f7870();
    if (puStack_18 != (undefined4 *)0x0) {
      uStack_154._4_4_ = (char *)0xa;
      uStack_174 = 0;
      puStack_1a8 = auStack_1a0;
      puStack_1a4 = puStack_18;
      pcStack_198 = pcVar12;
      FUN_005e5de0();
      uStack_8._0_1_ = 0x18;
      FUN_0060dcd0(&puStack_1a8,piStack_2c);
      uStack_8._0_1_ = 7;
      FUN_006059b0(&puStack_194,FUN_00628ae0,0);
      pcStack_198 = (char *)0x62c7d2;
      FUN_00602150();
      uStack_174 = 0x62c7da;
      FUN_0090ca30();
    }
  }
  if (pppuStack_e0 != (undefined ***)0x0) {
    uStack_154._4_4_ =
         (char *)CONCAT31((int3)((uint)&ppuStack_104 >> 8),pppuStack_e0 != &ppuStack_104);
    uStack_154._0_4_ = (char *)0x62c7f7;
    (*(code *)(*pppuStack_e0)[4])();
    pppuStack_e0 = (undefined ***)0x0;
  }
  uStack_8 = 0x19;
  pppiStack_158 = (int ***)uStack_94;
  pppiStack_15c = (int ***)uStack_98;
  pppiStack_160 = (int ***)0x62c825;
  uStack_154 = uStack_c4;
  FUN_0152dda0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6908 ; VA 0x0062ca80 ; FUN_0062ca80 */

void FUN_0062ca80(uint param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5
                 ,int param_6)

{
  undefined4 uVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  undefined auStack_88 [36];
  undefined auStack_64 [36];
  undefined *puStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined2 uStack_2c;
  undefined auStack_28 [2];
  ushort uStack_26;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_6;
  uVar1 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179eff0;
  pvStack_10 = ExceptionList;
  if (DAT_01d59f00 < param_4) {
    ExceptionList = &pvStack_10;
    FUN_016756b0(&uStack_34,"Cannot read value: too deeply nested.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_34,&DAT_01c17198);
  }
  ExceptionList = &pvStack_10;
  *(int *)(param_6 + 4) = *(int *)(param_6 + 4) + 1;
  cVar3 = FUN_006abe60(&cStack_11,1);
  if (cVar3 == '\0') {
    FUN_0054eff0("readFast past end for uint8_t");
    uStack_8 = 0;
    FUN_005f8ef0(&puStack_40);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_64,&DAT_01c27108);
  }
  if (cStack_11 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  param_1 = (uint)DAT_018db184;
  if (cStack_11 == '\a') {
    FUN_00607c10(uVar1,&param_1);
  }
  uVar2 = param_4;
  uStack_26 = (ushort)param_1;
  iStack_1c = *(int *)(iStack_18 + 0x19f4);
  if (uStack_26 != DAT_018db184) {
    param_4 = *(uint *)(iStack_1c + 0x4c);
    iVar4 = param_6;
    if ((param_1 & 0xffff) < (uint)((int)(*(int *)(iStack_1c + 0x50) - param_4) >> 2)) {
      uStack_24 = *(undefined4 *)(param_4 + (param_1 & 0xffff) * 4);
      goto LAB_0062cb43;
    }
  }
  uStack_24 = 0;
LAB_0062cb43:
  uStack_20 = 0;
  if (cStack_11 != '\x03') {
    puStack_40 = auStack_28;
    uStack_3c = param_3;
    uStack_2c = 0xffff;
    uStack_38 = 0;
    uStack_30 = 0;
    uStack_34 = 0;
    FUN_00609060(uVar1,auStack_28,param_2,&puStack_40,uVar2 + 1,param_5,iVar4);
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0054eff0("Invalid variant type");
  uStack_8 = 1;
  FUN_005f8ef0(&puStack_40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_88,&DAT_01c27108);
}



/* FUNCTION 6909 ; VA 0x0062cc40 ; FUN_0062cc40 */

void FUN_0062cc40(uint param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5
                 ,int param_6)

{
  uint uVar1;
  uint uVar2;
  undefined auStack_1c [12];
  char acStack_10 [2];
  ushort uStack_e;
  
  uVar2 = param_4;
  if (param_4 <= DAT_01d59f00) {
    *(int *)(param_6 + 4) = *(int *)(param_6 + 4) + 1;
    FUN_006b77f0(acStack_10,param_3);
    uVar1 = param_1;
    param_4 = CONCAT31(param_4._1_3_,acStack_10[0]);
    FUN_006ad5e0(&param_4,1);
    if (acStack_10[0] != '\0') {
      if (acStack_10[0] == '\a') {
        param_1 = (uint)uStack_e;
        FUN_006a5c10(&param_1,&param_4,2);
        FUN_006ad5e0(&param_4,2);
      }
      FUN_0060c670(uVar1,acStack_10,param_2,&param_3,uVar2 + 1,param_5,param_6);
    }
    return;
  }
  FUN_016756b0(auStack_1c,"Cannot write value: too deeply nested.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 6910 ; VA 0x0062cd10 ; FUN_0062cd10 */

int __thiscall FUN_0062cd10(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  double *pdVar12;
  int iVar13;
  uint uVar14;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_8 = 0;
  if (((*(int *)(param_1 + 0x1904) != 0) && (iVar13 = *(int *)(param_1 + 0x18f0), iVar13 != 0)) &&
     ((*(int *)(iVar13 + 0x20) == 2 ||
      ((uint)(*(int *)(iVar13 + 0x18) - *(int *)(iVar13 + 0x14)) < 8)))) {
    pdVar12 = (double *)FUN_01682800(&uStack_1c);
    iVar13 = *(int *)(param_1 + 0x1918) << 10;
    iStack_c = (int)(((double)iVar13 + (double)(&DAT_018c0d90)[-(iVar13 >> 0x1f)]) *
                    (*pdVar12 - *(double *)(param_1 + 0x1910))) + *(int *)(param_1 + 0x190c);
    if ((DAT_01eace6c != 0) && (DAT_01eace6c < iStack_c)) {
      iStack_c = DAT_01eace6c;
    }
    iVar13 = *(int *)(param_1 + 0x18f0);
    uVar14 = *(uint *)(param_1 + 0x18f8);
    if (uVar14 < (uint)(*(int *)(iVar13 + 0x18) - *(int *)(iVar13 + 0x14) >> 3)) {
      do {
        iVar13 = (**(code **)(**(int **)(*(int *)(iVar13 + 0x14) + uVar14 * 8) + 8))();
        iStack_8 = iStack_8 + iVar13;
        FUN_01682800(&uStack_1c);
        *(undefined4 *)(param_1 + 0x1910) = uStack_1c;
        *(undefined4 *)(param_1 + 0x1914) = uStack_18;
        uStack_10 = *(undefined4 *)(param_1 + 0x6c);
        uVar4 = *(undefined4 *)(param_1 + 0x74);
        uVar5 = *(undefined4 *)(param_1 + 0x78);
        uVar6 = *(undefined4 *)(param_1 + 0x7c);
        uVar7 = *(undefined4 *)(param_1 + 0x80);
        iVar13 = *(int *)(param_1 + 0x18f8);
        iVar2 = *(int *)(*(int *)(param_1 + 0x18f0) + 0x14);
        uVar8 = *(undefined4 *)(param_1 + 0x84);
        uVar9 = *(undefined4 *)(param_1 + 0x88);
        uVar10 = *(undefined4 *)(param_1 + 0x8c);
        uVar11 = *(undefined4 *)(param_1 + 0x90);
        iVar3 = *(int *)(iVar2 + 4 + iVar13 * 8);
        if (iVar3 != 0) {
          LOCK();
          piVar1 = (int *)(iVar3 + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_006afb30(*(undefined4 *)(iVar2 + iVar13 * 8),*(undefined4 *)(iVar2 + 4 + iVar13 * 8),2,3
                     ,0,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,uVar10,uVar11,0,param_1 + 0x17b8);
        uVar14 = *(int *)(param_1 + 0x18f8) + 1;
        *(uint *)(param_1 + 0x18f8) = uVar14;
      } while ((iStack_8 <= param_2) &&
              (iVar13 = *(int *)(param_1 + 0x18f0),
              uVar14 < (uint)(*(int *)(iVar13 + 0x18) - *(int *)(iVar13 + 0x14) >> 3)));
    }
    *(int *)(param_1 + 0x190c) = iStack_c - iStack_8;
    if ((uint)(*(int *)(*(int *)(param_1 + 0x18f0) + 0x18) -
               *(int *)(*(int *)(param_1 + 0x18f0) + 0x14) >> 3) <= uVar14) {
      *(undefined4 *)(param_1 + 0x18f0) = 0;
      piVar1 = *(int **)(param_1 + 0x18f4);
      *(undefined4 *)(param_1 + 0x18f4) = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar13 = piVar1[1] + -1;
        piVar1[1] = iVar13;
        UNLOCK();
        if (iVar13 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar13 = piVar1[2] + -1;
          piVar1[2] = iVar13;
          UNLOCK();
          if (iVar13 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      *(undefined *)(param_1 + 0x18fc) = 1;
    }
    return iStack_8;
  }
  return 0;
}



/* FUNCTION 6911 ; VA 0x0062cf10 ; FUN_0062cf10 */

void __thiscall FUN_0062cf10(int param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  char cVar9;
  undefined4 uVar10;
  int iVar11;
  int *piVar12;
  undefined auStack_a8 [16];
  int iStack_98;
  undefined auStack_90 [40];
  undefined8 uStack_68;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  char cStack_38;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  char acStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f035;
  pvStack_10 = ExceptionList;
  if ((*(int *)(param_1 + 0x1a18) != 0) && (*(char *)(param_1 + 0x3802) != '\0')) {
    ExceptionList = &pvStack_10;
    iStack_20 = FUN_01674e20(0x28);
    uStack_8 = 0;
    if (iStack_20 == 0) {
      uVar10 = 0;
    }
    else {
      uVar10 = FUN_006ab530();
    }
    uStack_8 = 0xffffffff;
    piStack_1c = (int *)0x0;
    iStack_18 = 0;
    FUN_00604a80(uVar10,param_3);
    piVar12 = piStack_1c;
    uStack_8 = 1;
    acStack_14[0] = -0x73;
    FUN_006ad5e0(acStack_14,1);
    iStack_20 = piVar12[6];
    FUN_006b9320(piVar12,*(undefined4 *)(param_1 + 0x1a18));
    if (((*(uint *)(param_1 + 0x380c) & 2) != 0) && (*(char *)(param_1 + 0x37f8) != '\0')) {
      acStack_14[0] = (char)param_3;
      FUN_006ad5e0(acStack_14,1);
      if ((char)param_3 == '\x05') {
        FUN_006323c0(param_4);
      }
    }
    iVar1 = piVar12[6];
    cVar9 = FUN_00707cb0(param_1,param_2,piVar12,1);
    if (cVar9 == '\0') {
      uStack_44 = 0;
      uStack_40 = 0;
      uStack_3c = 0;
      uStack_28 = 0;
      uStack_24 = 0xf;
      uStack_8._0_1_ = 2;
      cStack_38 = cVar9;
      FUN_006ab530();
      uStack_8._0_1_ = 3;
      FUN_006bd680(4,0,param_2,auStack_90);
      iStack_4c = param_2[1] * 0x10;
      iStack_58 = iStack_4c + 0x10;
      iStack_50 = *param_2 * 0x10;
      iStack_5c = iStack_50 + 0x10;
      uStack_68 = CONCAT44(iStack_4c,iStack_50);
      iStack_60 = param_2[2] * 0x10;
      iStack_54 = iStack_60 + 0x10;
      FUN_00a71760(auStack_a8,&uStack_68,0,1);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (iStack_98 == 0) {
        FUN_007084d0(param_1,param_2,auStack_90,0,1);
      }
      else {
        FUN_006bd630(4,auStack_a8,auStack_90);
        cVar9 = FUN_0061f4f0();
        if (cVar9 != '\0') {
          FUN_006bd8f0(0,auStack_90);
        }
        FUN_00619a10(auStack_90,piVar12,DAT_01d59e64);
        FUN_006ab690(iVar1);
        iVar11 = (**(code **)(*piStack_1c + 8))();
        FUN_007084d0(param_1,param_2,piStack_1c,iVar11 - iVar1,1);
        piVar12 = piStack_1c;
      }
      FUN_00612e90();
      FUN_00613200();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00576070();
    }
    if (piVar12[6] != iVar1) {
      if (DAT_01d59fb8 != '\0') {
        *(int *)(param_1 + 0x18d4) = *(int *)(param_1 + 0x18d4) + (piVar12[6] - iStack_20);
      }
      uVar10 = *(undefined4 *)(param_1 + 0x74);
      uVar2 = *(undefined4 *)(param_1 + 0x78);
      uVar3 = *(undefined4 *)(param_1 + 0x7c);
      uVar4 = *(undefined4 *)(param_1 + 0x80);
      uVar5 = *(undefined4 *)(param_1 + 0x84);
      uVar6 = *(undefined4 *)(param_1 + 0x88);
      uVar7 = *(undefined4 *)(param_1 + 0x8c);
      uVar8 = *(undefined4 *)(param_1 + 0x90);
      if (iStack_18 != 0) {
        LOCK();
        *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
        UNLOCK();
      }
      FUN_006afb30(piVar12,iStack_18,2,3,0,uVar10,uVar2,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,0,
                   param_1 + 0x17b8);
    }
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Attempt to stream terrain before terrain was ready to be sent");
}



/* FUNCTION 6912 ; VA 0x0062d220 ; FUN_0062d220 */

undefined4 __thiscall FUN_0062d220(int *param_1,int param_2)

{
  double dVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  double dVar9;
  char cVar10;
  short sVar11;
  undefined4 uVar12;
  int iVar13;
  int *piVar14;
  int *piVar15;
  byte bVar16;
  undefined2 uVar17;
  uint uVar18;
  uint uVar19;
  undefined2 uVar20;
  int *piVar21;
  double dVar22;
  undefined auStack_110 [12];
  undefined auStack_104 [24];
  undefined auStack_ec [12];
  undefined auStack_e0 [12];
  undefined8 uStack_d4;
  undefined4 uStack_cc;
  undefined auStack_c8 [4];
  undefined auStack_c4 [4];
  undefined auStack_c0 [24];
  uint uStack_a8;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined uStack_8c;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined auStack_74 [16];
  int iStack_64;
  int iStack_5c;
  int iStack_58;
  undefined8 uStack_54;
  int iStack_4c;
  uint uStack_48;
  int *piStack_44;
  uint *puStack_40;
  int *piStack_3c;
  undefined8 uStack_38;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f085;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_44 = param_1;
  if (DAT_01d65190 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01d65190,"sendClusterPacket job run",0);
  }
  cVar10 = (**(code **)(*param_1 + 0x1ac))();
  if (((cVar10 == '\0') || (piStack_3c = param_1 + 0x687, param_1[0x686] == 0)) ||
     (*(char *)((int)param_1 + 0x3802) == '\0')) {
    ExceptionList = pvStack_10;
    return 0;
  }
  if (((*(char *)(param_1 + 0x63f) != '\0') || (param_1[0x63c] == 0)) ||
     (*(int *)(param_1[0x63c] + 0x20) != 2)) {
    uStack_38 = (double)CONCAT44(param_1[0xe03],(undefined4)uStack_38);
    if (((param_1[0xe02] & 0x2000000U) == 0) || ((param_1[0xe02] & 0x20000000U) == 0)) {
      iVar13 = param_1[0x695];
    }
    else {
      iVar13 = param_1[0x689];
    }
    if (iVar13 == 0) {
      ExceptionList = pvStack_10;
      return 0;
    }
  }
  iStack_4c = FUN_01674e20(0x28);
  uStack_8 = 0;
  if (iStack_4c == 0) {
    uVar12 = 0;
  }
  else {
    uVar12 = FUN_006ab530();
  }
  uStack_8 = 0xffffffff;
  piStack_2c = (int *)0x0;
  piStack_28 = (int *)0x0;
  FUN_00604a80(uVar12,param_2);
  uStack_8 = 1;
  auStack_14[0] = 0x8d;
  FUN_006ad5e0(auStack_14,1);
  iStack_5c = piStack_2c[6];
  FUN_006b9320(piStack_2c,param_1[0x686]);
  if (((param_1[0xe03] & 2U) != 0) && (*(char *)(param_1 + 0xdfe) != '\0')) {
    auStack_14[0] = 2;
    FUN_006ad5e0(auStack_14,1);
  }
  uStack_98 = 0;
  uStack_94 = 0;
  uStack_90 = 0;
  uStack_7c = 0;
  uStack_78 = 0xf;
  uStack_8c = 0;
  uStack_8._0_1_ = 2;
  FUN_006ab530();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if ((param_1[0xe02] & 0x2000000U) == 0) {
    iStack_18 = param_1[0x640];
  }
  else {
    iStack_18 = 4;
  }
  uStack_48 = FUN_016f3cd0();
  uVar12 = FUN_0062cd10(uStack_48);
  if (*(char *)(param_1 + 0x63f) == '\x01') {
    iStack_4c = FUN_0061ec10();
    if (uStack_a8 < uStack_48) {
      do {
        iVar13 = FUN_0061ec10();
        if (iVar13 == 0) break;
        cVar10 = FUN_0061f4f0();
        if (cVar10 == '\0') {
          piVar15 = (int *)FUN_00618a80(auStack_c4);
          uStack_cc = *(undefined4 *)(*piVar15 + 0x10);
          piVar14 = (int *)&uStack_d4;
          uStack_d4 = *(undefined8 *)(*piVar15 + 8);
        }
        else {
          piVar14 = (int *)FUN_006243b0(auStack_110);
        }
        iStack_24 = *piVar14;
        iStack_20 = piVar14[1];
        iStack_1c = piVar14[2];
        FUN_0061e380(auStack_104,&iStack_24,iStack_18);
        cVar10 = FUN_0061f4f0();
        bVar16 = (byte)iStack_18;
        uVar17 = (undefined2)(iStack_20 << (bVar16 & 0x1f));
        uVar20 = (undefined2)(iStack_1c << (bVar16 & 0x1f));
        if (cVar10 == '\0') {
          uStack_38._0_4_ = CONCAT22((short)(iStack_24 << (bVar16 & 0x1f)),(undefined2)uStack_38);
          uStack_38 = (double)CONCAT26(uVar20,CONCAT24(uVar17,(undefined4)uStack_38));
          FUN_00628540(auStack_ec,(int)&uStack_38 + 2);
          if ((param_1[0x779] == 0) || (cVar10 = FUN_006e6300(auStack_ec), cVar10 != '\0')) {
            FUN_00a71760(auStack_74,auStack_104,0,1);
            uStack_8 = CONCAT31(uStack_8._1_3_,6);
            if (DAT_01eace39 != '\0') {
              FUN_01677520(DAT_01eace39,"Cluster update sent for (%d,%d,%d) isEmpty=%d",iStack_24,
                           iStack_20,iStack_1c,iStack_64 == 0);
            }
            uVar12 = 0;
            iVar13 = iStack_18;
          }
          else {
            FUN_00a71760(auStack_74,auStack_104,3,1);
            uStack_8 = CONCAT31(uStack_8._1_3_,5);
            if (DAT_01eace39 != '\0') {
              FUN_01677520(DAT_01eace39,"Cluster update sent for (%d,%d,%d) isEmpty=%d",iStack_24,
                           iStack_20,iStack_1c,iStack_64 == 0);
            }
            uVar12 = 3;
            iVar13 = iStack_18 + -3;
          }
          FUN_006bd680(iVar13,uVar12,&iStack_24,auStack_c0);
          FUN_006bd630(iVar13,auStack_74,auStack_c0);
          uStack_8 = CONCAT31(uStack_8._1_3_,3);
          FUN_00612e90();
          piVar15 = piStack_3c;
          piVar14 = (int *)FUN_00618a80(auStack_c8);
          puStack_40 = (uint *)(piVar15 + 0xd);
          piVar14 = (int *)*piVar14;
          piStack_30 = (int *)*piVar14;
          uVar18 = (uint)piVar14[1] % *puStack_40;
          piVar15 = *(int **)(piVar15[0x11] + uVar18 * 4);
          for (piVar21 = (int *)*piVar15; piVar21 != piVar14; piVar21 = (int *)*piVar21) {
            piVar15 = piVar21;
          }
          do {
            *piVar15 = *piVar21;
            FUN_01674ea0(piVar21,0x14);
            piStack_3c[0xe] = piStack_3c[0xe] + -1;
            uVar19 = uVar18;
            if (*piVar15 == 0) {
LAB_0062d84a:
              if (*(int **)(piStack_3c[0x11] + uVar18 * 4) == piVar15) {
                *(undefined4 *)(piStack_3c[0x11] + uVar18 * 4) = 0;
              }
            }
            else {
              uVar19 = *(uint *)(*piVar15 + 4) % *puStack_40;
              if (uVar18 != uVar19) {
                *(int **)(piStack_3c[0x11] + uVar19 * 4) = piVar15;
                goto LAB_0062d84a;
              }
            }
            piVar21 = (int *)*piVar15;
            param_1 = piStack_44;
            uVar18 = uVar19;
          } while (piVar21 != piStack_30);
        }
        else {
          param_2 = 0;
          uStack_54 = (double)CONCAT26(uVar20,CONCAT24(uVar17,CONCAT22((short)(iStack_24 <<
                                                                              (bVar16 & 0x1f)),
                                                                       (undefined2)uStack_54)));
          FUN_00628540(auStack_e0,(int)&uStack_54 + 2);
          if (param_1[0x779] != 0) {
            cVar10 = FUN_006e6300(auStack_e0);
            param_2 = 0;
            if (cVar10 == '\0') {
              param_2 = 3;
            }
          }
          FUN_00a71760(auStack_74,auStack_104,param_2,1);
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          iVar13 = iStack_18 - param_2;
          FUN_006bd680(iVar13,param_2,&iStack_24,auStack_c0);
          FUN_006bd630(iVar13,auStack_74,auStack_c0);
          piStack_30 = (int *)0x0;
          if (param_2 == 0) {
            FUN_0061ddc0(&iStack_58,&iStack_24);
            iVar13 = iStack_58;
            if (iStack_58 == param_1[0x68c]) {
              FUN_006bd8f0(0,auStack_c0);
            }
            else {
              piStack_30 = (int *)((*(int *)(iStack_58 + 0x18) - *(int *)(iStack_58 + 0x14)) / 0x18)
              ;
              FUN_006bd8f0(piStack_30,auStack_c0);
              iVar2 = *(int *)(iVar13 + 0x18);
              for (iVar13 = *(int *)(iVar13 + 0x14); iVar13 != iVar2; iVar13 = iVar13 + 0x18) {
                FUN_006bd870(iVar13,auStack_c0);
                param_1 = piStack_44;
              }
            }
          }
          else {
            FUN_006bd8f0(0,auStack_c0);
          }
          if (DAT_01eace39 != '\0') {
            FUN_01677520(DAT_01eace39,
                         "Cluster update sent for (%d,%d,%d) isEmpty=%d lod=%d maskCount=%zd",
                         iStack_24,iStack_20,iStack_1c,iStack_64 == 0,param_2,piStack_30);
          }
          FUN_0061d390(&iStack_24);
          uStack_8 = CONCAT31(uStack_8._1_3_,3);
          FUN_00612e90();
        }
      } while (uStack_a8 < uStack_48);
    }
    piVar14 = piStack_2c;
    FUN_00619a10(auStack_c0,piStack_2c,DAT_01d59e64);
    uStack_38 = (double)CONCAT44(param_1[0xe03],(undefined4)uStack_38);
    if (((param_1[0xe02] & 0x2000000U) == 0) || ((param_1[0xe02] & 0x20000000U) == 0)) {
      iVar13 = param_1[0x695];
    }
    else {
      iVar13 = param_1[0x689];
    }
    iVar2 = param_1[0x1d];
    iVar3 = param_1[0x1e];
    iVar4 = param_1[0x1f];
    iVar5 = param_1[0x20];
    param_1[0x76f] = iVar13 << 4;
    iVar13 = param_1[0x21];
    iVar6 = param_1[0x22];
    iVar7 = param_1[0x23];
    iVar8 = param_1[0x24];
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
    }
    FUN_006afb30(piVar14,piStack_28,2,3,0,iVar2,iVar3,iVar4,iVar5,iVar13,iVar6,iVar7,iVar8,0,
                 param_1 + 0x5ee);
    if (DAT_01eace39 != '\0') {
      uVar12 = (**(code **)(*piVar14 + 8))();
      FUN_01677520(DAT_01eace39,"Cluster packet send, %u bytes",uVar12);
    }
    FUN_0062ba20();
    iVar13 = (**(code **)(*piVar14 + 8))();
    uStack_54 = (double)iVar13;
    uStack_38 = uStack_54;
    sVar11 = FUN_017265ed(&uStack_54);
    dVar9 = DAT_018c0d60;
    if (sVar11 < 1) {
      dVar1 = *(double *)(param_1 + 0x250);
      dVar22 = uStack_38;
      if (*(char *)(param_1 + 600) == '\0') {
        dVar22 = (DAT_018c0d60 - dVar1) * *(double *)(param_1 + 0x254) + uStack_38 * dVar1;
      }
      *(double *)(param_1 + 0x254) = dVar22;
      param_1[0x252] = iVar13;
      *(undefined *)(param_1 + 600) = 0;
      *(double *)(param_1 + 0x256) =
           (uStack_38 - dVar22) * (uStack_38 - dVar22) * dVar1 +
           (dVar9 - dVar1) * *(double *)(param_1 + 0x256);
    }
    if (DAT_01d59fb8 != '\0') {
      param_1[0x635] = param_1[0x635] + (piStack_2c[6] - iStack_5c);
    }
    if (((DAT_01d5a0d8 != '\0') && (cVar10 = (**(code **)(*param_1 + 0xd4))(), cVar10 == '\0')) &&
       (param_1[0x64f] != 0)) {
      uVar12 = FUN_0061ec10();
      iVar13 = FUN_0061ec10();
      FUN_006150c0(iStack_4c - iVar13,uVar12);
    }
    uVar12 = (**(code **)(*piStack_2c + 8))();
  }
  FUN_00613200();
  FUN_00576070();
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar13 = piStack_28[1] + -1;
    piStack_28[1] = iVar13;
    UNLOCK();
    if (iVar13 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar14 = piStack_28 + 2;
      iVar13 = *piVar14;
      *piVar14 = *piVar14 + -1;
      UNLOCK();
      if (iVar13 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar12;
}



/* FUNCTION 6913 ; VA 0x0062dad0 ; FUN_0062dad0 */

int __thiscall FUN_0062dad0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = 0;
  if (0 < param_2) {
    do {
      iVar1 = *(int *)(param_1 + 0xe28) + -200;
      if (iVar1 < 1) {
        iVar1 = 0;
      }
      iVar2 = param_2 - iVar3;
      if (iVar1 <= param_2 - iVar3) {
        iVar2 = iVar1;
      }
      iVar1 = FUN_00619540(iVar2);
    } while ((iVar1 != 0) && (iVar3 = iVar3 + iVar1, iVar3 < param_2));
  }
  return iVar3;
}



/* FUNCTION 6914 ; VA 0x0062db20 ; FUN_0062db20 */

void __thiscall FUN_0062db20(int param_1,undefined *param_2)

{
  int iVar1;
  int *piVar2;
  undefined *puVar3;
  int iVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int in_stack_00000020;
  uint in_stack_00000034;
  undefined *in_stack_00000038;
  undefined auStack_44 [16];
  undefined4 uStack_34;
  undefined *puStack_30;
  undefined *puStack_2c;
  undefined auStack_1c [4];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f0a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0x37fd) != '\0') {
    iVar4 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    *(undefined *)(param_1 + 0x37fd) = 0;
    if ((iVar4 != 0) && (param_1 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
      puStack_2c = (undefined *)0x62db6e;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar4 = *(int *)(param_1 + 0xc);
      puStack_2c = (undefined *)0x62db84;
      iVar1 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
          (uint)*(ushort *)(iVar1 + 0x1da)) {
        puStack_2c = &LAB_0055d590;
        puStack_30 = &DAT_01ea8af8;
        uStack_34 = 0x62dbb2;
        FUN_005789c0();
        puStack_2c = (undefined *)0x62dbba;
        puStack_2c = (undefined *)FUN_00560d40();
        puStack_30 = (undefined *)0x62dbc2;
        piStack_14 = (int *)FUN_008aa140();
        if (*piStack_14 == 0) {
          puStack_2c = (undefined *)0x62dbcf;
          puStack_2c = (undefined *)FUN_00995770();
          puStack_30 = auStack_1c;
          uStack_34 = 0x62dbdb;
          piVar2 = (int *)FUN_008a9ba0();
          iVar4 = *piVar2;
          iVar1 = piVar2[1];
          *piVar2 = 0;
          piVar2[1] = 0;
          *piStack_14 = iVar4;
          piVar2 = (int *)piStack_14[1];
          piStack_14[1] = iVar1;
          if (piVar2 != (int *)0x0) {
            LOCK();
            iVar4 = piVar2[1] + -1;
            piVar2[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              puStack_2c = (undefined *)0x62dc0e;
              (**(code **)*piVar2)();
              LOCK();
              iVar4 = piVar2[2] + -1;
              piVar2[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                puStack_2c = (undefined *)0x62dc1e;
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar4 = piStack_18[1] + -1;
            piStack_18[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              puStack_2c = (undefined *)0x62dc34;
              (**(code **)*piStack_18)();
              LOCK();
              piVar2 = piStack_18 + 2;
              iVar4 = *piVar2;
              *piVar2 = *piVar2 + -1;
              UNLOCK();
              if (iVar4 == 1) {
                puStack_2c = (undefined *)0x62dc43;
                (**(code **)(*piStack_18 + 4))();
              }
            }
          }
        }
        if (*piStack_14 != 0) {
          puStack_2c = (undefined *)0x62dc51;
          FUN_00999b30();
        }
      }
    }
    puStack_2c = in_stack_00000038;
    in_stack_00000038 = auStack_44;
    FUN_0054ef60(&stack0x00000020);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00615190();
  }
  if (0xf < in_stack_00000018) {
    puStack_2c = (undefined *)(in_stack_00000018 + 1);
    puVar3 = param_2;
    if (0xfff < puStack_2c) {
      puVar3 = *(undefined **)(param_2 + -4);
      puStack_2c = (undefined *)(in_stack_00000018 + 0x24);
      if ((undefined *)0x1f < param_2 + (-4 - (int)puVar3)) {
                    /* WARNING: Subroutine does not return */
        puStack_2c = (undefined *)0x62dd13;
        FUN_017167a3();
      }
    }
    uStack_34 = 0x62dcb6;
    puStack_30 = puVar3;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (undefined *)((uint)param_2 & 0xffffff00);
  if (0xf < in_stack_00000034) {
    puStack_2c = (undefined *)(in_stack_00000034 + 1);
    iVar4 = in_stack_00000020;
    if (0xfff < puStack_2c) {
      iVar4 = *(int *)(in_stack_00000020 + -4);
      puStack_2c = (undefined *)(in_stack_00000034 + 0x24);
      if (0x1f < (in_stack_00000020 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_2c = &UNK_0062dd18;
        FUN_017167a3();
      }
    }
    uStack_34 = 0x62dcf8;
    puStack_30 = (undefined *)iVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6915 ; VA 0x0062dd20 ; FUN_0062dd20 */

int __thiscall
FUN_0062dd20(int *param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_48;
  int iStack_44;
  undefined auStack_38 [24];
  undefined4 uStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f0e7;
  pvStack_10 = ExceptionList;
  iStack_44 = param_2;
  piStack_18 = param_1 + 0x1d;
  uStack_8 = 0;
  uStack_48 = 0x62dd59;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  iVar3 = FUN_005f71d0();
  if ((char)iVar3 == '\0') {
    iStack_44 = 0x62dd6d;
    iVar3 = (**(code **)(*param_1 + 0xb4))();
    if ((iVar3 != 0) && (*(int *)(iVar3 + 0xec) != 1)) {
      iStack_44 = 0x28;
      uStack_48 = 0x62dd8c;
      iStack_1c = FUN_01674e20();
      uStack_8._0_1_ = 1;
      if (iStack_1c == 0) {
        uStack_48 = 0;
      }
      else {
        iStack_44 = 0x62dda1;
        uStack_48 = FUN_006ab530();
      }
      uStack_8._0_1_ = 0;
      uStack_20 = 0;
      iStack_1c = 0;
      iStack_44 = iVar3;
      FUN_00604a80();
      uStack_8._0_1_ = 2;
      iStack_44 = 0x62ddd3;
      uVar4 = (**(code **)(*(int *)*param_3 + 8))();
      iStack_44 = 0x62ddde;
      uStack_48 = (**(code **)(*(int *)*param_3 + 4))();
      iStack_44 = uVar4;
      FUN_006ad5e0();
      FUN_0060dcd0(&uStack_48,iVar3);
      iStack_44 = FUN_00a7ebd0(auStack_38,param_6);
      uStack_8._0_1_ = 3;
      uStack_48 = 0x62de15;
      FUN_006ae570();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      iStack_44 = 0x62de21;
      FUN_005507b0();
      if (piStack_14[0x1b] != 0) {
        iStack_44 = 0;
        uStack_48 = 0;
        FUN_00557fc0(&uStack_20);
        FUN_006afb30();
      }
      iStack_44 = 0x62de68;
      iVar3 = FUN_00550b30();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_44 = 0x62de81;
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_44 = 0x62de90;
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 6916 ; VA 0x0062deb0 ; FUN_0062deb0 */

undefined4 __thiscall
FUN_0062deb0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,int *param_5)

{
  double dVar1;
  char cVar2;
  short sVar3;
  int iVar4;
  double *pdVar5;
  double dVar6;
  double dVar7;
  undefined auStack_1c [8];
  double dStack_14;
  double dStack_c;
  
  iVar4 = FUN_006f7ee0(param_4);
  if (iVar4 == 0) {
    FUN_006b2010(param_4);
    return 0;
  }
  pdVar5 = (double *)FUN_01682800(auStack_1c);
  dStack_14 = (*pdVar5 - *(double *)(param_4 + 10)) * DAT_018c0d70;
  dStack_c = dStack_14;
  sVar3 = FUN_017265ed(&dStack_14);
  if (sVar3 < 1) {
    dVar1 = *(double *)(param_1 + 0x8a8);
    dVar7 = DAT_018c0d60 - dVar1;
    dVar6 = dStack_c;
    if (*(char *)(param_1 + 0x8c8) == '\0') {
      dVar6 = *(double *)(param_1 + 0x8b8) * dVar7 + dVar1 * dStack_c;
    }
    *(double *)(param_1 + 0x8b0) = dStack_c;
    *(undefined *)(param_1 + 0x8c8) = 0;
    *(double *)(param_1 + 0x8b8) = dVar6;
    *(double *)(param_1 + 0x8c0) =
         (dStack_c - dVar6) * (dStack_c - dVar6) * dVar1 + *(double *)(param_1 + 0x8c0) * dVar7;
  }
  *param_5 = *param_5 + 1;
  if ((((DAT_01d5ba6c != '\0') || (0 < DAT_01eace58)) &&
      (cVar2 = (**(code **)(*param_4 + 0xc))(), DAT_01d5ba6c != '\0')) && (cVar2 != '\0')) {
    (**(code **)*param_4)(1);
    return 0;
  }
  (**(code **)*param_4)(1);
  return 1;
}



/* FUNCTION 6917 ; VA 0x0062dfe0 ; FUN_0062dfe0 */

int __thiscall FUN_0062dfe0(int *param_1,undefined4 param_2,undefined4 param_3,char param_4)

{
  int iVar1;
  char cVar2;
  int iVar3;
  uint *puVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  undefined4 uStack_10;
  uint uStack_c;
  int iStack_8;
  
  iStack_8 = 0;
  iVar7 = 0;
  if (param_4 == '\0') {
    do {
      while( true ) {
        iVar5 = param_1[0x76d];
        uVar8 = param_1[0xe04] - *(int *)(iVar5 + 0x200);
        if (uVar8 < (uint)(*(int *)(iVar5 + 0x1ec) - *(int *)(iVar5 + 0x1e8) >> 2)) {
          piVar9 = *(int **)(*(int *)(iVar5 + 0x1e8) + uVar8 * 4);
        }
        else {
          piVar9 = (int *)0x0;
        }
        cVar2 = FUN_006b1e70();
        if (cVar2 == '\0') {
          if (param_1[0x77c] == 0) {
            puVar4 = (uint *)&DAT_00000018;
          }
          else {
            puVar4 = (uint *)(param_1[0x77c] + 0x10);
          }
          uStack_c = *puVar4;
          _param_4 = puVar4[1];
        }
        else {
          if (piVar9 == (int *)0x0) goto LAB_0062e037;
          uStack_c = 0xffffffff;
          _param_4 = 0xffffffff;
        }
        if (piVar9 == (int *)0x0) {
          uVar8 = 0xffffffff;
          uVar6 = 0xffffffff;
        }
        else {
          uVar8 = piVar9[8];
          uVar6 = piVar9[9];
        }
        if (DAT_01eaf007 != '\0') {
          FUN_01677520(DAT_01eaf007,
                       "Replicator : %p (peerId=%d) : Next: Per-replicator queue item id : %llu , Shared rebroadcast queue id : %llu (send lowest)"
                       ,param_1,param_1[0xe10],uStack_c,_param_4,uVar8,uVar6);
        }
        if ((_param_4 <= uVar6) && ((_param_4 < uVar6 || (uStack_c <= uVar8)))) break;
        if (DAT_01eaf007 != '\0') {
          FUN_01677520(DAT_01eaf007,
                       "Replicator : %p : Sending from shared rebroadcast queue (Requires Common Id : %llu)"
                       ,param_1,uVar8,uVar6);
        }
        cVar2 = FUN_006cdaf0(param_1);
        if ((cVar2 != '\0') &&
           ((iVar5 = FUN_006f80b0(param_1,piVar9), iVar5 == 0 ||
            ((((iVar7 = iVar7 + 1, iStack_8 = iVar7, DAT_01d5ba6c != '\0' || (0 < DAT_01eace58)) &&
              (cVar2 = (**(code **)(*piVar9 + 4))(param_1), DAT_01d5ba6c != '\0')) &&
             (cVar2 != '\0')))))) goto LAB_0062e037;
        puVar4 = (uint *)(param_1 + 0xe04);
        uVar8 = *puVar4;
        *puVar4 = *puVar4 + 1;
        param_1[0xe05] = param_1[0xe05] + (uint)(0xfffffffe < uVar8);
      }
      if (DAT_01eaf007 != '\0') {
        FUN_01677520(DAT_01eaf007,
                     "Replicator : %p : Sending from per-replicator queue (Common Id Marker : %llu)"
                     ,param_1,uStack_c,_param_4);
      }
      cVar2 = FUN_006b1ee0(&uStack_10);
    } while ((cVar2 == '\0') ||
            (cVar2 = FUN_0062deb0(param_2,param_1 + 0x77b,uStack_10,&iStack_8), iVar7 = iStack_8,
            cVar2 != '\0'));
  }
  else {
    cVar2 = FUN_006b1ee0(&uStack_10);
    while ((cVar2 != '\0' &&
           (cVar2 = FUN_0062deb0(param_2,param_1 + 0x781,uStack_10,&iStack_8), iVar7 = iStack_8,
           cVar2 != '\0'))) {
      cVar2 = FUN_006b1ee0(&uStack_10);
      iVar7 = iStack_8;
    }
  }
LAB_0062e037:
  if (((DAT_01d5a0d8 != '\0') && (cVar2 = (**(code **)(*param_1 + 0xd4))(), cVar2 == '\0')) &&
     (param_1[0x64e] != 0)) {
    iVar5 = *(int *)(param_1[0x76d] + 0x1ec);
    iVar1 = *(int *)(param_1[0x76d] + 0x1e8);
    iVar3 = FUN_0054db20();
    FUN_006150c0(iVar7,iVar3 + (iVar5 - iVar1 >> 2));
  }
  return iVar7;
}



/* FUNCTION 6918 ; VA 0x0062e250 ; FUN_0062e250 */

undefined __thiscall FUN_0062e250(int *param_1,int param_2)

{
  double dVar1;
  uint uVar2;
  char cVar3;
  short sVar4;
  int iVar5;
  double *pdVar6;
  int iVar7;
  int iVar8;
  double dVar9;
  double dVar10;
  double dVar11;
  undefined auStack_44 [25];
  char cStack_2b;
  double dStack_28;
  undefined8 uStack_20;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f110;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar3 = (**(code **)(*param_1 + 0x1ac))();
  if (cVar3 == '\0') {
    ExceptionList = pvStack_10;
    return 0;
  }
  iVar8 = DAT_01d59da4;
  if ((DAT_01d59fc0 == '\0') && (DAT_01d59da4 < 1)) {
    iVar8 = 1;
  }
  uStack_20 = 0.0;
  sVar4 = FUN_017265ed(&uStack_20);
  dVar1 = DAT_018c0d60;
  if (sVar4 < 1) {
    dVar11 = *(double *)(param_1 + 0x216);
    if (*(char *)(param_1 + 0x21e) == '\0') {
      dVar10 = (DAT_018c0d60 - dVar11) * *(double *)(param_1 + 0x21a) + dVar11 * 0.0;
    }
    else {
      dVar10 = 0.0;
    }
    param_1[0x218] = 0;
    param_1[0x219] = 0;
    *(double *)(param_1 + 0x21a) = dVar10;
    *(undefined *)(param_1 + 0x21e) = 0;
    *(double *)(param_1 + 0x21c) =
         (dVar1 - dVar11) * *(double *)(param_1 + 0x21c) + dVar11 * (0.0 - dVar10) * (0.0 - dVar10);
  }
  iVar5 = FUN_0054db20();
  iVar7 = param_1[0x787];
  pdVar6 = (double *)FUN_016827a0(&dStack_28);
  if (*(double *)(param_1 + 0x236) <= *pdVar6 - *(double *)(param_1 + 0x234)) {
    param_1[0x238] = param_1[0x239];
    param_1[0x239] = 0;
    FUN_016827a0(&uStack_20);
    param_1[0x234] = (int)uStack_20;
    param_1[0x235] = uStack_20._4_4_;
  }
  param_1[0x239] = param_1[0x239] + (iVar5 - iVar7);
  iStack_14 = 0;
  if (*(char *)(param_1 + 0xe48) != '\0') {
    iVar7 = FUN_0054db20();
    dStack_28 = (double)iVar7;
    uStack_20._4_4_ = iVar7;
    sVar4 = FUN_017265ed(&dStack_28);
    if (sVar4 < 1) {
      dVar1 = *(double *)(param_1 + 0xe84);
      dVar10 = (double)uStack_20._4_4_;
      dVar11 = dVar10;
      if (*(char *)(param_1 + 0xe8c) == '\0') {
        dVar11 = (DAT_018c0d60 - dVar1) * *(double *)(param_1 + 0xe88) + dVar10 * dVar1;
      }
      dVar9 = DAT_018c0d60 - dVar1;
      *(double *)(param_1 + 0xe88) = dVar11;
      param_1[0xe86] = uStack_20._4_4_;
      *(undefined *)(param_1 + 0xe8c) = 0;
      *(double *)(param_1 + 0xe8a) =
           dVar9 * *(double *)(param_1 + 0xe8a) + (dVar10 - dVar11) * (dVar10 - dVar11) * dVar1;
    }
    iVar7 = FUN_0054db20();
    uStack_20 = (double)CONCAT44(iVar7,(int)uStack_20);
    dStack_28 = (double)iVar7;
    sVar4 = FUN_017265ed(&dStack_28);
    if (sVar4 < 1) {
      dVar1 = *(double *)(param_1 + 0xe8e);
      dVar10 = (double)uStack_20._4_4_;
      dVar11 = dVar10;
      if (*(char *)(param_1 + 0xe96) == '\0') {
        dVar11 = (DAT_018c0d60 - dVar1) * *(double *)(param_1 + 0xe92) + dVar10 * dVar1;
      }
      dVar9 = DAT_018c0d60 - dVar1;
      *(double *)(param_1 + 0xe92) = dVar11;
      param_1[0xe90] = uStack_20._4_4_;
      *(undefined *)(param_1 + 0xe96) = 0;
      *(double *)(param_1 + 0xe94) =
           dVar9 * *(double *)(param_1 + 0xe94) + (dVar10 - dVar11) * (dVar10 - dVar11) * dVar1;
    }
  }
  if (DAT_01d59fc0 == '\0') {
    iVar7 = 0;
    if (iVar8 < 1) {
      iVar5 = 0;
    }
    else {
      do {
        iVar5 = param_1[0x38a] + -200;
        if (iVar5 < 1) {
          iVar5 = 0;
        }
        FUN_006f7a50(param_1,param_1[0x1b],iVar5);
        uStack_8 = 1;
        iVar5 = FUN_0062dfe0(auStack_44,param_1 + 0x781,1);
        iStack_14 = iStack_14 + iVar5;
        iVar5 = FUN_0062dfe0(auStack_44,param_1 + 0x77b,0);
        iStack_14 = iStack_14 + iVar5;
        if (cStack_2b == '\0') goto LAB_0062e6b3;
        uStack_8 = 0xffffffff;
        FUN_006f7a90();
        iVar7 = iVar7 + 1;
        iVar5 = iStack_14;
      } while (iVar7 < iVar8);
    }
  }
  else {
    iVar5 = 0;
    if (0 < param_2) {
      do {
        iVar8 = FUN_0054db20();
        if (((iVar8 == 0) && (iVar8 = FUN_0054db20(), iVar8 == 0)) &&
           (uVar2 = *(uint *)(param_1[0x76d] + 0x1f8), iVar5 = iStack_14,
           uVar2 == param_1[0xe04] &&
           *(int *)(param_1[0x76d] + 0x1fc) - param_1[0xe05] == (uint)(uVar2 < (uint)param_1[0xe04])
           )) break;
        iVar8 = param_1[0x38a] + -200;
        if (iVar8 < 1) {
          iVar8 = 0;
        }
        if (param_2 < iVar8) {
          iVar8 = param_2;
        }
        FUN_006f7a50(param_1,param_1[0x1b],iVar8);
        uStack_8 = 0;
        iVar7 = FUN_0062dfe0(auStack_44,param_1 + 0x781,1);
        iStack_14 = iStack_14 + iVar7;
        iVar7 = FUN_0062dfe0(auStack_44,param_1 + 0x77b,0);
        iStack_14 = iStack_14 + iVar7;
        cVar3 = (**(code **)(*param_1 + 200))();
        if ((cVar3 == '\0') || (DAT_01d5a0a0 != '\0')) {
          iVar8 = FUN_006f7e00();
        }
        param_2 = param_2 - iVar8;
        iVar8 = FUN_006f7e00();
        if (iVar8 == 1) {
LAB_0062e6b3:
          FUN_006f7a90();
          ExceptionList = pvStack_10;
          return 0;
        }
        uStack_8 = 0xffffffff;
        FUN_006f7a90();
        iVar5 = iStack_14;
      } while (0 < param_2);
    }
  }
  if (*(char *)(param_1 + 0xe48) != '\0') {
    iVar8 = FUN_0054db20();
    dStack_28 = (double)iVar8;
    sVar4 = FUN_017265ed(&dStack_28);
    if (sVar4 < 1) {
      dVar1 = *(double *)(param_1 + 0xe98);
      dVar10 = (double)iVar8;
      dVar11 = dVar10;
      if (*(char *)(param_1 + 0xea0) == '\0') {
        dVar11 = (DAT_018c0d60 - dVar1) * *(double *)(param_1 + 0xe9c) + dVar10 * dVar1;
      }
      dVar9 = DAT_018c0d60 - dVar1;
      *(double *)(param_1 + 0xe9c) = dVar11;
      param_1[0xe9a] = iVar8;
      *(undefined *)(param_1 + 0xea0) = 0;
      *(double *)(param_1 + 0xe9e) =
           (dVar10 - dVar11) * (dVar10 - dVar11) * dVar1 + dVar9 * *(double *)(param_1 + 0xe9e);
    }
    dStack_28 = (double)iVar5;
    uStack_20 = dStack_28;
    sVar4 = FUN_017265ed(&dStack_28);
    if (sVar4 < 1) {
      dVar1 = *(double *)(param_1 + 0xea2);
      dVar11 = uStack_20;
      if (*(char *)(param_1 + 0xeaa) == '\0') {
        dVar11 = (DAT_018c0d60 - dVar1) * *(double *)(param_1 + 0xea6) + uStack_20 * dVar1;
      }
      *(double *)(param_1 + 0xea6) = dVar11;
      dVar10 = DAT_018c0d60 - dVar1;
      param_1[0xea4] = iVar5;
      *(undefined *)(param_1 + 0xeaa) = 0;
      *(double *)(param_1 + 0xea8) =
           (uStack_20 - dVar11) * (uStack_20 - dVar11) * dVar1 +
           dVar10 * *(double *)(param_1 + 0xea8);
    }
  }
  pdVar6 = (double *)FUN_016827a0(&dStack_28);
  if (*(double *)(param_1 + 0x23c) <= *pdVar6 - *(double *)(param_1 + 0x23a)) {
    param_1[0x23e] = param_1[0x23f];
    param_1[0x23f] = 0;
    FUN_016827a0(&iStack_18);
    param_1[0x23a] = iStack_18;
    param_1[0x23b] = iStack_14;
  }
  param_1[0x23f] = param_1[0x23f] + iVar5;
  iVar8 = FUN_0054db20();
  param_1[0x787] = iVar8;
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 6919 ; VA 0x0062e8b0 ; FUN_0062e8b0 */

int * FUN_0062e8b0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int *piVar10;
  uint uVar11;
  undefined4 uVar12;
  int iVar13;
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  int iStack_1c;
  int iStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f13f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00605d50(&iStack_2c);
  uStack_8 = 0;
  piVar10 = (int *)FUN_01674e20(0x34);
  uStack_8._0_1_ = 1;
  piStack_24 = piVar10;
  if (piVar10 == (int *)0x0) {
    piVar10 = (int *)0x0;
  }
  else {
    piVar10[1] = 1;
    piVar10[2] = 1;
    *piVar10 = (int)std::_Ref_count_obj<class_RBX::Network::NetworkStream>::vftable;
    FUN_006ab530();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  auStack_14[0] = 0x84;
  FUN_006ad5e0(auStack_14,1);
  piStack_24 = *(int **)(iStack_2c + 0x54);
  iStack_18 = (int)piStack_24;
  FUN_006a5c10(&iStack_18,auStack_20,4);
  FUN_006ad5e0(auStack_20,4);
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"Replicator:SendMarker id(%d)",piStack_24);
  }
  iVar2 = iStack_1c;
  if (((*(int *)(iStack_1c + 0x1f68) + *(int *)(iStack_1c + 0x1f6c) & 1U) == 0) &&
     (*(uint *)(iStack_1c + 0x1f64) <= *(int *)(iStack_1c + 0x1f6c) + 2U >> 1)) {
    FUN_006176e0(1);
  }
  uVar11 = *(int *)(iVar2 + 0x1f64) * 2 - 1U & *(uint *)(iVar2 + 0x1f68);
  *(uint *)(iVar2 + 0x1f68) = uVar11;
  piStack_24 = (int *)(*(int *)(iVar2 + 0x1f6c) + uVar11);
  iStack_18 = (*(int *)(iVar2 + 0x1f64) - 1U & (uint)piStack_24 >> 1) * 4;
  iVar13 = *(int *)(iVar2 + 0x1f60);
  if (*(int *)(iStack_18 + iVar13) == 0) {
    uVar12 = FUN_01674e20(0x10);
    *(undefined4 *)(iStack_18 + *(int *)(iVar2 + 0x1f60)) = uVar12;
    iVar13 = *(int *)(iVar2 + 0x1f60);
  }
  iVar13 = *(int *)(iStack_18 + iVar13);
  uVar11 = (uint)piStack_24 & 1;
  *(undefined4 *)(iVar13 + uVar11 * 8) = 0;
  *(undefined4 *)(iVar13 + 4 + uVar11 * 8) = 0;
  piVar1 = (int *)(iVar13 + uVar11 * 8);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    *(int *)((int)piStack_28 + 4) = *(int *)((int)piStack_28 + 4) + 1;
    UNLOCK();
  }
  *piVar1 = iStack_2c;
  piVar1[1] = (int)piStack_28;
  *(int *)(iVar2 + 0x1f6c) = *(int *)(iVar2 + 0x1f6c) + 1;
  uVar12 = *(undefined4 *)(iStack_1c + 0x74);
  uVar3 = *(undefined4 *)(iStack_1c + 0x78);
  uVar4 = *(undefined4 *)(iStack_1c + 0x7c);
  uVar5 = *(undefined4 *)(iStack_1c + 0x80);
  uVar6 = *(undefined4 *)(iStack_1c + 0x84);
  uVar7 = *(undefined4 *)(iStack_1c + 0x88);
  uVar8 = *(undefined4 *)(iStack_1c + 0x8c);
  uVar9 = *(undefined4 *)(iStack_1c + 0x90);
  if (piVar10 != (int *)0x0) {
    LOCK();
    piVar10[1] = piVar10[1] + 1;
    UNLOCK();
  }
  FUN_006afb30(piVar10 + 3,piVar10,2,2,0,uVar12,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,0,0);
  iVar2 = iStack_2c;
  iStack_2c = 0;
  *param_1 = iVar2;
  param_1[1] = (int)piStack_28;
  piStack_28 = (int *)0x0;
  if (piVar10 != (int *)0x0) {
    LOCK();
    iVar2 = piVar10[1] + -1;
    piVar10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar10)();
      LOCK();
      iVar2 = piVar10[2] + -1;
      piVar10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
    piVar10 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[1] + -1;
      piStack_28[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar10 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6920 ; VA 0x0062eb00 ; FUN_0062eb00 */

void __thiscall FUN_0062eb00(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f15f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x38);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    FUN_006b1a30(param_1);
    *puVar1 = RBX::Network::Replicator::StatsItem::vftable;
    puVar1[0xc] = param_2;
  }
  uStack_8 = 0xffffffff;
  FUN_006b1f50(puVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6921 ; VA 0x0062eb80 ; FUN_0062eb80 */

int __fastcall FUN_0062eb80(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  undefined **ppuVar9;
  undefined4 *puVar10;
  uint *puVar11;
  undefined **ppuVar12;
  uint uVar13;
  uint uVar14;
  undefined8 uVar15;
  undefined uVar16;
  undefined auStack_f0 [12];
  undefined4 uStack_e4;
  char *pcStack_e0;
  undefined4 uStack_dc;
  uint uStack_d8;
  char *pcStack_d4;
  undefined *puStack_d0;
  char *pcStack_cc;
  int *piStack_c8;
  char *pcStack_c4;
  char *pcStack_c0;
  int iStack_bc;
  uint *puStack_b8;
  uint *puStack_b4;
  undefined8 uStack_b0;
  undefined auStack_9c [24];
  uint auStack_84 [4];
  undefined4 uStack_74;
  uint uStack_70;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined auStack_54 [4];
  undefined *puStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  char *pcStack_3c;
  int *piStack_38;
  undefined *puStack_30;
  uint *puStack_2c;
  undefined4 *puStack_28;
  char cStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_0179f283;
  pvStack_1c = ExceptionList;
  puStack_2c = (uint *)0x0;
  uStack_b0 = CONCAT44(0x62ebc7,(undefined4)uStack_b0);
  ExceptionList = &pvStack_1c;
  iVar8 = (**(code **)(*param_1 + 0xb8))();
  if (iVar8 != 0) {
    pcStack_3c = (char *)0x0;
    piStack_38 = (int *)0x0;
    iStack_14 = 0;
    uStack_b0 = CONCAT44(0x62ebf0,(undefined4)uStack_b0);
    iVar8 = (**(code **)(*param_1 + 0xb8))();
    uStack_b0 = CONCAT44(iVar8 + 0x2a8,0x62ebfe);
    FUN_0054ef60();
    puStack_2c = (uint *)0x4;
    iStack_14._0_1_ = 1;
    uStack_b0 = ZEXT48(&pcStack_3c);
    puStack_b4 = auStack_84;
    puStack_b8 = (uint *)0x62ec18;
    cStack_21 = FUN_0098f070();
    iStack_14 = (uint)iStack_14._1_3_ << 8;
    if (0xf < uStack_70) {
      uVar14 = uStack_70 + 1;
      uVar13 = auStack_84[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_84[0] - 4);
        uVar14 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9b9,(undefined4)uStack_b0);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62ec53;
      FUN_01674ea0();
    }
    if (DAT_01d5a040 != '\0') {
      uStack_b0 = 0x18cc07c00000001;
      puStack_b4 = (uint *)0x62ec6f;
      FUN_0086f2f0();
      uStack_b0 = *(ulonglong *)(param_1 + 0xe1a);
      puStack_b4 = (uint *)0x18cc09c;
      puStack_b8 = (uint *)0x1;
      iStack_bc = 0x62ec88;
      FUN_0086f2f0();
      uStack_b0 = *(ulonglong *)(param_1 + 0x260);
      puStack_b4 = (uint *)0x18cc0bc;
      puStack_b8 = (uint *)0x1;
      iStack_bc = 0x62eca4;
      FUN_0086f2f0();
      uVar15 = *(undefined8 *)(param_1 + 0x262);
      iStack_bc = 0x62ecb1;
      FUN_017267a0();
      puStack_b4 = (uint *)0x18cc0dc;
      puStack_b8 = (uint *)0x1;
      iStack_bc = 0x62ecc5;
      uStack_b0 = uVar15;
      FUN_0086f2f0();
      iStack_bc = param_1[0x266];
      pcStack_c0 = "Max DataPing (ms)         : %d";
      pcStack_c4 = (char *)0x1;
      piStack_c8 = (int *)0x62ecd7;
      FUN_0086f2f0();
      piStack_c8 = (int *)param_1[0x267];
      pcStack_cc = "Min DataPing (ms)         : %d";
      puStack_d0 = (undefined *)0x1;
      pcStack_d4 = (char *)0x62ece9;
      FUN_0086f2f0();
      uStack_b0 = *(ulonglong *)(param_1 + 0x26c);
      puStack_b4 = (uint *)0x18cc13c;
      puStack_b8 = (uint *)0x1;
      iStack_bc = 0x62ed05;
      FUN_0086f2f0();
      uVar15 = *(undefined8 *)(param_1 + 0x26e);
      iStack_bc = 0x62ed12;
      FUN_017267a0();
      puStack_b4 = (uint *)0x18cc15c;
      puStack_b8 = (uint *)0x1;
      iStack_bc = 0x62ed26;
      uStack_b0 = uVar15;
      FUN_0086f2f0();
      iStack_bc = param_1[0x272];
      pcStack_c0 = "Max RakPing (ms)          : %d";
      pcStack_c4 = (char *)0x1;
      piStack_c8 = (int *)0x62ed38;
      FUN_0086f2f0();
      piStack_c8 = (int *)param_1[0x273];
      pcStack_cc = "Min RakPing (ms)          : %d";
      puStack_d0 = (undefined *)0x1;
      pcStack_d4 = (char *)0x62ed4a;
      FUN_0086f2f0();
      pcStack_d4 = "-------------------------------";
      uStack_d8 = 1;
      uStack_dc = 0x62ed56;
      FUN_0086f2f0();
    }
    auStack_54[0] = 0;
    uStack_b0 = CONCAT44(&puStack_28,&boost::lock_error::vftable_meta_ptr);
    puStack_b4 = (uint *)&DAT_018be100;
    puStack_28 = (undefined4 *)0xb;
    puStack_b8 = (uint *)0x62ed77;
    ppuVar9 = (undefined **)FUN_00563d40();
    ppuVar12 = ppuVar9 + -1;
    if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar12 = ppuVar9;
    }
    puStack_50 = *ppuVar12;
    uStack_4c = 0;
    uStack_48 = 0x3f800000;
    uStack_44 = 0;
    uStack_40 = 0;
    iStack_14._0_1_ = 2;
    uStack_b0 = CONCAT44(0x62edb6,(undefined4)uStack_b0);
    (**(code **)(*param_1 + 0xb8))();
    uStack_b0 = CONCAT44(0x62edbd,(undefined4)uStack_b0);
    uStack_b0 = FUN_00928340();
    puStack_b8 = auStack_84;
    puStack_b4 = (uint *)&DAT_018bed48;
    iStack_bc = 0x62edcd;
    puVar10 = (undefined4 *)FUN_01675640();
    uStack_b0 = 0x6018c6c60;
    iStack_14._0_1_ = 3;
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62edf7;
    FUN_005542c0();
    iStack_14 = CONCAT31(iStack_14._1_3_,4);
    uStack_b0 = CONCAT44(auStack_6c,0x62ee07);
    iVar8 = FUN_005d15d0();
    puStack_28 = (undefined4 *)(iVar8 + 0x18);
    if (puStack_28 != puVar10) {
      uStack_b0 = CONCAT44(0x62ee18,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puStack_28 = *puVar10;
      puStack_28[1] = uVar3;
      puStack_28[2] = uVar4;
      puStack_28[3] = uVar5;
      *(undefined8 *)(puStack_28 + 4) = *(undefined8 *)(puVar10 + 4);
      puVar10[4] = 0;
      puVar10[5] = 0xf;
      *(undefined *)puVar10 = 0;
    }
    iStack_14._0_1_ = 3;
    if (0xf < uStack_58) {
      uVar14 = uStack_58 + 1;
      uVar13 = auStack_6c[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_6c[0] - 4);
        uVar14 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9be,(undefined4)uStack_b0);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62ee71;
      FUN_01674ea0();
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    iStack_14._0_1_ = 2;
    uVar16 = (undefined)iStack_14;
    iStack_14._0_1_ = 2;
    if (0xf < uStack_70) {
      uVar14 = uStack_70 + 1;
      uVar13 = auStack_84[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_84[0] - 4);
        uVar14 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9c3,(undefined4)uStack_b0);
          iStack_14._0_1_ = uVar16;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62eebb;
      FUN_01674ea0();
    }
    if (cStack_21 == '\0') {
      uStack_b0 = 0x7018bf33c;
      uStack_74 = 0;
      uStack_70 = 0xf;
      auStack_84[0] = auStack_84[0] & 0xffffff00;
      puStack_b4 = (uint *)0x62ef50;
      FUN_005542c0();
      puVar11 = auStack_84;
      iStack_14 = 6;
      puStack_2c = (undefined4 *)0x6;
    }
    else {
      pcStack_c4 = (char *)0x7;
      uStack_b0 = 0xf00000000;
      piStack_c8 = (int *)0x18bf33c;
      pcStack_c0 = (char *)((uint)pcStack_c0 & 0xffffff00);
      pcStack_cc = (char *)0x62eee6;
      FUN_005542c0();
      pcStack_c4 = "SessionId";
      if (piStack_38 != (int *)0x0) {
        LOCK();
        piStack_38[1] = piStack_38[1] + 1;
        UNLOCK();
      }
      pcStack_cc = pcStack_3c;
      piStack_c8 = piStack_38;
      puStack_d0 = auStack_9c;
      pcStack_d4 = (char *)0x62ef1f;
      puVar11 = (uint *)FUN_0061ef60();
      iStack_14 = CONCAT31(iStack_14._1_3_,5);
      puStack_2c = (undefined4 *)0x5;
    }
    uStack_b0 = 0x9018cc1bc;
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62ef86;
    puStack_28 = puStack_2c;
    FUN_005542c0();
    iStack_14 = 7;
    uStack_b0 = CONCAT44(auStack_6c,0x62ef99);
    iVar8 = FUN_005d15d0();
    puStack_2c = (uint *)(iVar8 + 0x18);
    if (puStack_2c != puVar11) {
      uStack_b0 = CONCAT44(0x62efaa,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar13 = puVar11[1];
      uVar14 = puVar11[2];
      uVar6 = puVar11[3];
      *puStack_2c = *puVar11;
      puStack_2c[1] = uVar13;
      puStack_2c[2] = uVar14;
      puStack_2c[3] = uVar6;
      *(undefined8 *)(puStack_2c + 4) = *(undefined8 *)(puVar11 + 4);
      puVar11[4] = 0;
      puVar11[5] = 0xf;
      *(undefined *)puVar11 = 0;
    }
    iStack_14 = CONCAT31(iStack_14._1_3_,6);
    if (0xf < uStack_58) {
      uVar14 = uStack_58 + 1;
      uVar13 = auStack_6c[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_6c[0] - 4);
        uVar14 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9c8,(undefined4)uStack_b0);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f003;
      FUN_01674ea0();
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    if (((uint)puStack_28 & 2) != 0) {
      puStack_28 = (undefined4 *)((uint)puStack_28 & 0xfffffffd);
      uStack_b0 = CONCAT44(0x62f02d,(undefined4)uStack_b0);
      FUN_005507b0();
    }
    iStack_14 = 2;
    if (((uint)puStack_28 & 1) != 0) {
      uStack_b0 = CONCAT44(0x62f046,(undefined4)uStack_b0);
      FUN_005507b0();
    }
    uStack_b0 = *(ulonglong *)(param_1 + 0xe1a);
    puStack_b8 = auStack_84;
    puStack_b4 = (uint *)&DAT_018c5880;
    iStack_bc = 0x62f064;
    puVar10 = (undefined4 *)FUN_01675640();
    uStack_b0 = 0x8018cc1d4;
    iStack_14._0_1_ = 8;
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62f08e;
    FUN_005542c0();
    iStack_14 = CONCAT31(iStack_14._1_3_,9);
    uStack_b0 = CONCAT44(auStack_6c,0x62f09e);
    iVar8 = FUN_005d15d0();
    puStack_2c = (uint *)(iVar8 + 0x18);
    if (puStack_2c != puVar10) {
      uStack_b0 = CONCAT44(0x62f0af,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puStack_2c = *puVar10;
      puStack_2c[1] = uVar3;
      puStack_2c[2] = uVar4;
      puStack_2c[3] = uVar5;
      *(undefined8 *)(puStack_2c + 4) = *(undefined8 *)(puVar10 + 4);
      puVar10[4] = 0;
      puVar10[5] = 0xf;
      *(undefined *)puVar10 = 0;
    }
    iStack_14._0_1_ = 8;
    if (0xf < uStack_58) {
      uVar14 = uStack_58 + 1;
      uVar13 = auStack_6c[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_6c[0] - 4);
        uVar14 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9cd,(undefined4)uStack_b0);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f108;
      FUN_01674ea0();
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    iStack_14._0_1_ = 2;
    uVar16 = (undefined)iStack_14;
    iStack_14._0_1_ = 2;
    if (0xf < uStack_70) {
      uVar14 = uStack_70 + 1;
      uVar13 = auStack_84[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_84[0] - 4);
        uVar14 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9d2,(undefined4)uStack_b0);
          iStack_14._0_1_ = uVar16;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f152;
      FUN_01674ea0();
    }
    uStack_b0 = *(ulonglong *)(param_1 + 0x260);
    puStack_b8 = auStack_84;
    puStack_b4 = (uint *)&DAT_018c5880;
    iStack_bc = 0x62f173;
    puVar10 = (undefined4 *)FUN_01675640();
    uStack_b0 = 0x13018cc1e0;
    iStack_14._0_1_ = 10;
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62f19d;
    FUN_005542c0();
    iStack_14 = CONCAT31(iStack_14._1_3_,0xb);
    uStack_b0 = CONCAT44(auStack_6c,0x62f1ad);
    iVar8 = FUN_005d15d0();
    puStack_2c = (uint *)(iVar8 + 0x18);
    if (puStack_2c != puVar10) {
      uStack_b0 = CONCAT44(0x62f1be,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puStack_2c = *puVar10;
      puStack_2c[1] = uVar3;
      puStack_2c[2] = uVar4;
      puStack_2c[3] = uVar5;
      *(undefined8 *)(puStack_2c + 4) = *(undefined8 *)(puVar10 + 4);
      puVar10[4] = 0;
      puVar10[5] = 0xf;
      *(undefined *)puVar10 = 0;
    }
    iStack_14._0_1_ = 10;
    if (0xf < uStack_58) {
      uVar14 = uStack_58 + 1;
      uVar13 = auStack_6c[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_6c[0] - 4);
        uVar14 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9d7,(undefined4)uStack_b0);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f217;
      FUN_01674ea0();
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    iStack_14._0_1_ = 2;
    uVar16 = (undefined)iStack_14;
    iStack_14._0_1_ = 2;
    if (0xf < uStack_70) {
      uVar14 = uStack_70 + 1;
      uVar13 = auStack_84[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_84[0] - 4);
        uVar14 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9dc,(undefined4)uStack_b0);
          iStack_14._0_1_ = uVar16;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f261;
      FUN_01674ea0();
    }
    uVar15 = *(undefined8 *)(param_1 + 0x262);
    uStack_b0 = CONCAT44(0x62f271,(undefined4)uStack_b0);
    FUN_017267a0();
    puStack_b8 = auStack_84;
    puStack_b4 = (uint *)&DAT_018c5880;
    iStack_bc = 0x62f287;
    uStack_b0 = uVar15;
    puVar10 = (undefined4 *)FUN_01675640();
    uStack_b0 = 0x12018cc1f4;
    iStack_14._0_1_ = 0xc;
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62f2b1;
    FUN_005542c0();
    iStack_14 = CONCAT31(iStack_14._1_3_,0xd);
    uStack_b0 = CONCAT44(auStack_6c,0x62f2c1);
    iVar8 = FUN_005d15d0();
    puStack_2c = (uint *)(iVar8 + 0x18);
    if (puStack_2c != puVar10) {
      uStack_b0 = CONCAT44(0x62f2d2,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puStack_2c = *puVar10;
      puStack_2c[1] = uVar3;
      puStack_2c[2] = uVar4;
      puStack_2c[3] = uVar5;
      *(undefined8 *)(puStack_2c + 4) = *(undefined8 *)(puVar10 + 4);
      puVar10[4] = 0;
      puVar10[5] = 0xf;
      *(undefined *)puVar10 = 0;
    }
    iStack_14._0_1_ = 0xc;
    if (0xf < uStack_58) {
      uVar14 = uStack_58 + 1;
      uVar13 = auStack_6c[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_6c[0] - 4);
        uVar14 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9e1,(undefined4)uStack_b0);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f32b;
      FUN_01674ea0();
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    iStack_14._0_1_ = 2;
    uVar16 = (undefined)iStack_14;
    iStack_14._0_1_ = 2;
    if (0xf < uStack_70) {
      uVar14 = uStack_70 + 1;
      uVar13 = auStack_84[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_84[0] - 4);
        uVar14 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9e6,(undefined4)uStack_b0);
          iStack_14._0_1_ = uVar16;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f375;
      FUN_01674ea0();
    }
    puStack_b4 = auStack_84;
    uStack_b0 = CONCAT44(param_1[0x266],&DAT_018bed68);
    puStack_b8 = (uint *)0x62f38c;
    puVar10 = (undefined4 *)FUN_01675640();
    uStack_b0 = 0x13018cc208;
    iStack_14._0_1_ = 0xe;
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62f3b6;
    FUN_005542c0();
    iStack_14 = CONCAT31(iStack_14._1_3_,0xf);
    uStack_b0 = CONCAT44(auStack_6c,0x62f3c6);
    iVar8 = FUN_005d15d0();
    puStack_2c = (uint *)(iVar8 + 0x18);
    if (puStack_2c != puVar10) {
      uStack_b0 = CONCAT44(0x62f3d7,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puStack_2c = *puVar10;
      puStack_2c[1] = uVar3;
      puStack_2c[2] = uVar4;
      puStack_2c[3] = uVar5;
      *(undefined8 *)(puStack_2c + 4) = *(undefined8 *)(puVar10 + 4);
      puVar10[4] = 0;
      puVar10[5] = 0xf;
      *(undefined *)puVar10 = 0;
    }
    iStack_14._0_1_ = 0xe;
    if (0xf < uStack_58) {
      uVar14 = uStack_58 + 1;
      uVar13 = auStack_6c[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_6c[0] - 4);
        uVar14 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9eb,(undefined4)uStack_b0);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f430;
      FUN_01674ea0();
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    iStack_14._0_1_ = 2;
    uVar16 = (undefined)iStack_14;
    iStack_14._0_1_ = 2;
    if (0xf < uStack_70) {
      uVar14 = uStack_70 + 1;
      uVar13 = auStack_84[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_84[0] - 4);
        uVar14 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9f0,(undefined4)uStack_b0);
          iStack_14._0_1_ = uVar16;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f47a;
      FUN_01674ea0();
    }
    puStack_b4 = auStack_84;
    uStack_b0 = CONCAT44(param_1[0x267],&DAT_018bed68);
    puStack_b8 = (uint *)0x62f491;
    puVar10 = (undefined4 *)FUN_01675640();
    uStack_b0 = 0x13018cc21c;
    iStack_14._0_1_ = 0x10;
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62f4bb;
    FUN_005542c0();
    iStack_14 = CONCAT31(iStack_14._1_3_,0x11);
    uStack_b0 = CONCAT44(auStack_6c,0x62f4cb);
    iVar8 = FUN_005d15d0();
    puStack_2c = (uint *)(iVar8 + 0x18);
    if (puStack_2c != puVar10) {
      uStack_b0 = CONCAT44(0x62f4dc,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puStack_2c = *puVar10;
      puStack_2c[1] = uVar3;
      puStack_2c[2] = uVar4;
      puStack_2c[3] = uVar5;
      *(undefined8 *)(puStack_2c + 4) = *(undefined8 *)(puVar10 + 4);
      puVar10[4] = 0;
      puVar10[5] = 0xf;
      *(undefined *)puVar10 = 0;
    }
    iStack_14._0_1_ = 0x10;
    if (0xf < uStack_58) {
      uVar14 = uStack_58 + 1;
      uVar13 = auStack_6c[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_6c[0] - 4);
        uVar14 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9f5,(undefined4)uStack_b0);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f535;
      FUN_01674ea0();
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    iStack_14._0_1_ = 2;
    uVar16 = (undefined)iStack_14;
    iStack_14._0_1_ = 2;
    if (0xf < uStack_70) {
      uVar14 = uStack_70 + 1;
      uVar13 = auStack_84[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_84[0] - 4);
        uVar14 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9fa,(undefined4)uStack_b0);
          iStack_14._0_1_ = uVar16;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f57f;
      FUN_01674ea0();
    }
    uStack_b0 = *(ulonglong *)(param_1 + 0x26c);
    puStack_b8 = auStack_84;
    puStack_b4 = (uint *)&DAT_018c5880;
    iStack_bc = 0x62f5a0;
    puVar10 = (undefined4 *)FUN_01675640();
    uStack_b0 = 0xf018cc230;
    iStack_14._0_1_ = 0x12;
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62f5ca;
    FUN_005542c0();
    iStack_14 = CONCAT31(iStack_14._1_3_,0x13);
    uStack_b0 = CONCAT44(auStack_6c,0x62f5da);
    iVar8 = FUN_005d15d0();
    puStack_2c = (uint *)(iVar8 + 0x18);
    if (puStack_2c != puVar10) {
      uStack_b0 = CONCAT44(0x62f5eb,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puStack_2c = *puVar10;
      puStack_2c[1] = uVar3;
      puStack_2c[2] = uVar4;
      puStack_2c[3] = uVar5;
      *(undefined8 *)(puStack_2c + 4) = *(undefined8 *)(puVar10 + 4);
      puVar10[4] = 0;
      puVar10[5] = 0xf;
      *(undefined *)puVar10 = 0;
    }
    iStack_14._0_1_ = 0x12;
    if (0xf < uStack_58) {
      uVar14 = uStack_58 + 1;
      uVar13 = auStack_6c[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_6c[0] - 4);
        uVar14 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62f9ff,(undefined4)uStack_b0);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f644;
      FUN_01674ea0();
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    iStack_14._0_1_ = 2;
    uVar16 = (undefined)iStack_14;
    iStack_14._0_1_ = 2;
    if (0xf < uStack_70) {
      uVar14 = uStack_70 + 1;
      uVar13 = auStack_84[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_84[0] - 4);
        uVar14 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62fa04,(undefined4)uStack_b0);
          iStack_14._0_1_ = uVar16;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f68e;
      FUN_01674ea0();
    }
    uVar15 = *(undefined8 *)(param_1 + 0x26e);
    uStack_b0 = CONCAT44(0x62f69e,(undefined4)uStack_b0);
    FUN_017267a0();
    puStack_b8 = auStack_84;
    puStack_b4 = (uint *)&DAT_018c5880;
    iStack_bc = 0x62f6b4;
    uStack_b0 = uVar15;
    puVar10 = (undefined4 *)FUN_01675640();
    uStack_b0 = 0xe018cc240;
    iStack_14._0_1_ = 0x14;
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62f6de;
    FUN_005542c0();
    iStack_14 = CONCAT31(iStack_14._1_3_,0x15);
    uStack_b0 = CONCAT44(auStack_6c,0x62f6ee);
    iVar8 = FUN_005d15d0();
    puStack_2c = (uint *)(iVar8 + 0x18);
    if (puStack_2c != puVar10) {
      uStack_b0 = CONCAT44(0x62f6ff,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puStack_2c = *puVar10;
      puStack_2c[1] = uVar3;
      puStack_2c[2] = uVar4;
      puStack_2c[3] = uVar5;
      *(undefined8 *)(puStack_2c + 4) = *(undefined8 *)(puVar10 + 4);
      puVar10[4] = 0;
      puVar10[5] = 0xf;
      *(undefined *)puVar10 = 0;
    }
    iStack_14._0_1_ = 0x14;
    if (0xf < uStack_58) {
      uVar14 = uStack_58 + 1;
      uVar13 = auStack_6c[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_6c[0] - 4);
        uVar14 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(0x62fa09,(undefined4)uStack_b0);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f758;
      FUN_01674ea0();
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    iStack_14._0_1_ = 2;
    uVar16 = (undefined)iStack_14;
    iStack_14._0_1_ = 2;
    if (0xf < uStack_70) {
      uVar14 = uStack_70 + 1;
      uVar13 = auStack_84[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_84[0] - 4);
        uVar14 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar13) - 4) {
          uStack_b0 = CONCAT44(&UNK_0062fa0e,(undefined4)uStack_b0);
          iStack_14._0_1_ = uVar16;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_b0 = CONCAT44(uVar14,uVar13);
      puStack_b4 = (uint *)0x62f7a2;
      FUN_01674ea0();
    }
    puStack_b4 = (uint *)auStack_9c;
    uStack_b0 = CONCAT44(param_1[0x272],&DAT_018bed68);
    puStack_b8 = (uint *)0x62f7bc;
    puVar10 = (undefined4 *)FUN_01675640();
    uStack_b0 = 0xf018cc250;
    iStack_14._0_1_ = 0x16;
    uStack_74 = 0;
    uStack_70 = 0xf;
    auStack_84[0] = auStack_84[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62f7e6;
    FUN_005542c0();
    iStack_14 = CONCAT31(iStack_14._1_3_,0x17);
    uStack_b0 = CONCAT44(auStack_84,0x62f7f6);
    iVar8 = FUN_005d15d0();
    puStack_2c = (uint *)(iVar8 + 0x18);
    if (puStack_2c != puVar10) {
      uStack_b0 = CONCAT44(0x62f807,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puStack_2c = *puVar10;
      puStack_2c[1] = uVar3;
      puStack_2c[2] = uVar4;
      puStack_2c[3] = uVar5;
      *(undefined8 *)(puStack_2c + 4) = *(undefined8 *)(puVar10 + 4);
      puVar10[4] = 0;
      puVar10[5] = 0xf;
      *(undefined *)puVar10 = 0;
    }
    uStack_b0 = CONCAT44(0x62f833,(undefined4)uStack_b0);
    FUN_005507b0();
    iStack_14._0_1_ = 2;
    uStack_b0 = CONCAT44(0x62f842,(undefined4)uStack_b0);
    FUN_005507b0();
    puStack_b4 = (uint *)auStack_9c;
    uStack_b0 = CONCAT44(param_1[0x273],&DAT_018bed68);
    puStack_b8 = (uint *)0x62f859;
    puVar10 = (undefined4 *)FUN_01675640();
    uStack_b0 = 0xf018cc260;
    iStack_14._0_1_ = 0x18;
    uStack_74 = 0;
    uStack_70 = 0xf;
    auStack_84[0] = auStack_84[0] & 0xffffff00;
    puStack_b4 = (uint *)0x62f883;
    FUN_005542c0();
    iStack_14 = CONCAT31(iStack_14._1_3_,0x19);
    uStack_b0 = CONCAT44(auStack_84,0x62f893);
    iVar8 = FUN_005d15d0();
    if ((undefined4 *)(iVar8 + 0x18) != puVar10) {
      uStack_b0 = CONCAT44(0x62f8a1,(undefined4)uStack_b0);
      FUN_005507b0();
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *(undefined4 *)(iVar8 + 0x18) = *puVar10;
      *(undefined4 *)(iVar8 + 0x1c) = uVar3;
      *(undefined4 *)(iVar8 + 0x20) = uVar4;
      *(undefined4 *)(iVar8 + 0x24) = uVar5;
      *(undefined8 *)(iVar8 + 0x28) = *(undefined8 *)(puVar10 + 4);
      puVar10[4] = 0;
      puVar10[5] = 0xf;
      *(undefined *)puVar10 = 0;
    }
    uStack_b0 = CONCAT44(0x62f8ca,(undefined4)uStack_b0);
    FUN_005507b0();
    iStack_14._0_1_ = 2;
    uStack_b0 = CONCAT44(0x62f8d9,(undefined4)uStack_b0);
    FUN_005507b0();
    puStack_2c = (uint *)&pcStack_c0;
    puStack_28 = &pcStack_c0;
    pcStack_c4 = auStack_54;
    piStack_c8 = (int *)0x62f8ed;
    FUN_0060e660();
    puStack_28 = &uStack_d8;
    iStack_14._0_1_ = 0x1a;
    uStack_dc = 0xc;
    piStack_c8 = (int *)0x0;
    pcStack_c4 = (char *)0xf;
    pcStack_e0 = "LatencyStats";
    uStack_d8 = uStack_d8 & 0xffffff00;
    uStack_e4 = 0x62f916;
    FUN_005542c0();
    puStack_30 = auStack_f0;
    iStack_14._0_1_ = 0x1b;
    pcStack_e0 = (char *)0x0;
    uStack_dc = 0xf;
    auStack_f0[0] = 0;
    FUN_005542c0("report",6);
    iStack_14._0_1_ = 0x1c;
    uVar16 = 0;
    FUN_005542c0("client",6);
    iStack_14 = CONCAT31(iStack_14._1_3_,2);
    FUN_0087a540(uVar16);
    uStack_b0 = CONCAT44(0x62f979,(undefined4)uStack_b0);
    iVar8 = FUN_0056cfd0();
    piVar7 = piStack_38;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_38 + 1;
      iVar2 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        uStack_b0 = CONCAT44(0x62f992,(undefined4)uStack_b0);
        iVar8 = (**(code **)*piStack_38)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          uStack_b0 = CONCAT44(0x62f9a1,(undefined4)uStack_b0);
          iVar8 = (**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iVar8;
}



/* FUNCTION 6922 ; VA 0x0062fa10 ; FUN_0062fa10 */

undefined4 __thiscall
FUN_0062fa10(int param_1,undefined8 param_2,undefined4 param_3,undefined4 *param_4)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char *pcVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  void *pvVar8;
  float10 fVar9;
  float fVar10;
  undefined8 uVar11;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f2fc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d59fc8 != '\0') {
    iVar6 = *(int *)(param_1 + 0x140) + 1;
    ExceptionList = &pvStack_10;
    *(int *)(param_1 + 0x140) = iVar6;
    if ((float)(*(int *)(param_1 + 0x138) - (param_1 + 0x138)) <
        (float)((double)iVar6 + (double)(&DAT_018c0d90)[-(iVar6 >> 0x1f)])) {
      *(undefined4 *)(param_1 + 0x140) = 0;
      if (*(int **)(param_1 + 0x128) != (int *)0x0) {
        (**(code **)(**(int **)(param_1 + 0x128) + 0x200))();
      }
    }
  }
  if ((DAT_01d5b818 != '\0') && (cVar1 = FUN_00618c40(), cVar1 == '\0')) {
    *param_4 = 1;
    ExceptionList = pvStack_10;
    return 0;
  }
  uStack_18 = 0;
  *param_4 = 0;
  if (*(int *)(param_1 + 0x128) != 0) {
    iStack_8 = 0;
    (**(code **)(**(int **)(param_1 + 0x128) + 0xc4))();
    pvVar8 = ThreadLocalStoragePointer;
    if (DAT_01d59fc0 == '\0') {
      fVar9 = (float10)FUN_00a36320(param_2,DAT_018ce310,(float)DAT_01d59d70,(float)DAT_01d59d74);
      fVar10 = (float)fVar9;
      if ((float)fVar9 <= DAT_018ce2f8) {
        fVar10 = DAT_018ce2f8;
      }
      iVar7 = FUN_0054db20();
      iVar6 = FUN_0054db20();
      iVar6 = iVar6 + iVar7;
      if (DAT_01d5b810 != '\0') {
        iVar6 = iVar6 + (*(int *)(*(int *)(*(int *)(param_1 + 0x128) + 0x1db4) + 0x1f8) -
                        *(int *)(*(int *)(param_1 + 0x128) + 0x3810));
      }
      iVar7 = 10;
      if (iVar6 + 1 < 10) {
        iVar7 = iVar6 + 1;
      }
      iVar6 = 0;
      fVar10 = fVar10 * (float)iVar7 * DAT_018ce2f4;
      if ((float)DAT_01d59d80 <= fVar10) {
        fVar10 = (float)DAT_01d59d80;
      }
      for (; iVar7 = (int)fVar10, iVar6 < iVar7; iVar6 = iVar6 + 1) {
        (**(code **)(**(int **)(param_1 + 0x128) + 0x198))(0xffffffff);
      }
      if (DAT_01d5b3d8 == '\0') {
        if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
             DAT_01ead0b0) && (FUN_016f3809(&DAT_01ead0b0), DAT_01ead0b0 == -1)) {
          iStack_8._0_1_ = 6;
          uVar11 = FUN_0152da50(&DAT_018c5904);
          DAT_01ead0ac = (undefined4)((ulonglong)uVar11 >> 0x20);
          DAT_01ead0a8 = (undefined4)uVar11;
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_016f37bf(&DAT_01ead0b0);
        }
        FUN_0152d760(DAT_01ead0a8,DAT_01ead0ac,"Job Scale: %d",iVar7);
        for (iVar6 = 0; iVar6 < 0x1b; iVar6 = iVar6 + 1) {
          if (*(int *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar6 * 4) != 0) {
            if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                 DAT_01ead0c0) && (FUN_016f3809(&DAT_01ead0c0), DAT_01ead0c0 == -1)) {
              iStack_8._0_1_ = 7;
              uVar11 = FUN_0152da50(&DAT_018c5904);
              DAT_01ead0bc = (undefined4)((ulonglong)uVar11 >> 0x20);
              DAT_01ead0b8 = (undefined4)uVar11;
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_016f37bf(&DAT_01ead0c0);
            }
            switch(iVar6) {
            case 0:
              break;
            case 1:
              break;
            case 2:
              break;
            case 3:
              break;
            case 4:
              break;
            case 5:
            case 6:
            case 9:
            case 0x12:
              break;
            case 7:
              break;
            case 8:
              break;
            case 10:
              break;
            case 0xb:
              break;
            case 0xc:
              break;
            case 0xd:
              break;
            case 0xe:
              break;
            case 0xf:
              break;
            case 0x10:
              break;
            case 0x11:
              break;
            case 0x13:
              break;
            case 0x14:
              break;
            default:
              break;
            case 0x16:
              break;
            case 0x17:
              break;
            case 0x18:
            }
            FUN_0152d760();
            *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar6 * 4) = 0;
          }
        }
      }
      else {
        iVar6 = *(int *)(param_1 + 0x128);
        if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
             DAT_01ead090) && (FUN_016f3809(&DAT_01ead090), DAT_01ead090 == -1)) {
          iStack_8._0_1_ = 4;
          uVar11 = FUN_0152da50(&DAT_018c5904);
          DAT_01ead08c = (undefined4)((ulonglong)uVar11 >> 0x20);
          DAT_01ead088 = (undefined4)uVar11;
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_016f37bf(&DAT_01ead090);
        }
        FUN_0152d760(DAT_01ead088,DAT_01ead08c,"Job Scale: %d",iVar7);
        for (iVar7 = 0; iVar7 < 0x1b; iVar7 = iVar7 + 1) {
          if ((*(int *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar7 * 4) != 0) ||
             (*(int *)(*(int *)(iVar6 + 0x1df8) + iVar7 * 4) != 0)) {
            if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                 DAT_01ead0a0) && (FUN_016f3809(&DAT_01ead0a0), DAT_01ead0a0 == -1)) {
              iStack_8._0_1_ = 5;
              uVar11 = FUN_0152da50(&DAT_018c5904);
              DAT_01ead09c = (undefined4)((ulonglong)uVar11 >> 0x20);
              DAT_01ead098 = (undefined4)uVar11;
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_016f37bf(&DAT_01ead0a0);
            }
            switch(iVar7) {
            case 0:
              pcVar4 = "End Item";
              break;
            case 1:
              pcVar4 = "Delete Items";
              break;
            case 2:
              pcVar4 = "New Items";
              break;
            case 3:
              pcVar4 = "Change Property Items";
              break;
            case 4:
              pcVar4 = "Marker Items";
              break;
            case 5:
            case 6:
            case 9:
            case 0x12:
              pcVar4 = "Other Items";
              break;
            case 7:
              pcVar4 = "Event Invocation Items";
              break;
            case 8:
              pcVar4 = "Request Character Items";
              break;
            case 10:
              pcVar4 = "CFrame Ack Items";
              break;
            case 0xb:
              pcVar4 = "Join Data Items";
              break;
            case 0xc:
              pcVar4 = "Client Quota Update Items";
              break;
            case 0xd:
              pcVar4 = "Stream Data Items";
              break;
            case 0xe:
              pcVar4 = "Region Removal Items";
              break;
            case 0xf:
              pcVar4 = "Instance Removal Items";
              break;
            case 0x10:
              pcVar4 = "Tag Items";
              break;
            case 0x11:
              pcVar4 = "Stats Items";
              break;
            case 0x13:
              pcVar4 = "Resolve Atomic Tree Items";
              break;
            case 0x14:
              pcVar4 = "Streaming Info Items";
              break;
            default:
              pcVar4 = "Unknown Items";
              break;
            case 0x16:
              pcVar4 = "Join Data Items V2";
              break;
            case 0x17:
              pcVar4 = "Stream Terrain Item";
              break;
            case 0x18:
              pcVar4 = "Stream Prefetch Info Items";
            }
            FUN_0152d760(DAT_01ead098,DAT_01ead09c,"%s (Left) : %d (%d)",pcVar4,
                         *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar7 * 4),
                         *(undefined4 *)(*(int *)(iVar6 + 0x1df8) + iVar7 * 4));
            *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar7 * 4) = 0;
          }
        }
      }
    }
    else {
      if (DAT_01d5b598 == '\0') {
        if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
             DAT_01ead060) && (FUN_016f3809(&DAT_01ead060), DAT_01ead060 == -1)) {
          iStack_8._0_1_ = 1;
          uVar11 = FUN_0152da50(&DAT_018c5904);
          DAT_01ead05c = (undefined4)((ulonglong)uVar11 >> 0x20);
          DAT_01ead058 = (undefined4)uVar11;
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_016f37bf(&DAT_01ead060);
        }
        FUN_0152d760(DAT_01ead058,DAT_01ead05c,"Data Bytes To Produce: %d",param_3);
      }
      uStack_18 = (**(code **)(**(int **)(param_1 + 0x128) + 0x198))(param_3);
      if (DAT_01d5b3d8 == '\0') {
        for (iVar6 = 0; iVar6 < 0x1b; iVar6 = iVar6 + 1) {
          if (*(int *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar6 * 4) != 0) {
            if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                 DAT_01ead080) && (FUN_016f3809(&DAT_01ead080), DAT_01ead080 == -1)) {
              iStack_8._0_1_ = 3;
              uVar11 = FUN_0152da50(&DAT_018c5904);
              DAT_01ead07c = (undefined4)((ulonglong)uVar11 >> 0x20);
              DAT_01ead078 = (undefined4)uVar11;
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_016f37bf(&DAT_01ead080);
            }
            uVar5 = *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar6 * 4);
            uVar3 = FUN_0061a050(iVar6);
            FUN_0152d760(DAT_01ead078,DAT_01ead07c,"%s : %d",uVar3,uVar5);
            *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar6 * 4) = 0;
          }
        }
      }
      else {
        iVar6 = *(int *)(param_1 + 0x128);
        for (iVar7 = 0; iVar7 < 0x1b; iVar7 = iVar7 + 1) {
          if ((*(int *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar7 * 4) != 0) ||
             (*(int *)(*(int *)(iVar6 + 0x1df8) + iVar7 * 4) != 0)) {
            if ((*(int *)(*(int *)((int)pvVar8 + _tls_index * 4) + 0x34) < DAT_01ead070) &&
               (FUN_016f3809(&DAT_01ead070), DAT_01ead070 == -1)) {
              iStack_8._0_1_ = 2;
              uVar11 = FUN_0152da50(&DAT_018c5904);
              DAT_01ead06c = (undefined4)((ulonglong)uVar11 >> 0x20);
              DAT_01ead068 = (undefined4)uVar11;
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_016f37bf(&DAT_01ead070);
            }
            uVar5 = *(undefined4 *)(*(int *)(iVar6 + 0x1df8) + iVar7 * 4);
            uVar3 = *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar7 * 4);
            uVar2 = FUN_0061a050(iVar7);
            FUN_0152d760(DAT_01ead068,DAT_01ead06c,"%s (Left) : %d (%d)",uVar2,uVar3,uVar5);
            *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x128) + 0x3870) + iVar7 * 4) = 0;
          }
          pvVar8 = ThreadLocalStoragePointer;
        }
      }
    }
    iVar7 = FUN_0054db20();
    pvVar8 = ThreadLocalStoragePointer;
    iVar6 = _tls_index;
    if (iVar7 != 0) {
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead0d0
          ) && (FUN_016f3809(&DAT_01ead0d0), DAT_01ead0d0 == -1)) {
        iStack_8._0_1_ = 8;
        uVar11 = FUN_0152da50(&DAT_018c5904);
        DAT_01ead0cc = (undefined4)((ulonglong)uVar11 >> 0x20);
        DAT_01ead0c8 = (undefined4)uVar11;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_016f37bf(&DAT_01ead0d0);
      }
      uVar5 = FUN_0054db20();
      FUN_0152d760(DAT_01ead0c8,DAT_01ead0cc,"Leftover HighPriority Items: %zu",uVar5);
    }
    if ((DAT_01d5b3d8 == '\0') && (iVar7 = FUN_0054db20(), iVar7 != 0)) {
      if ((*(int *)(*(int *)((int)pvVar8 + iVar6 * 4) + 0x34) < DAT_01ead0e0) &&
         (FUN_016f3809(&DAT_01ead0e0), DAT_01ead0e0 == -1)) {
        iStack_8._0_1_ = 9;
        uVar11 = FUN_0152da50(&DAT_018c5904);
        DAT_01ead0dc = (undefined4)((ulonglong)uVar11 >> 0x20);
        DAT_01ead0d8 = (undefined4)uVar11;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_016f37bf(&DAT_01ead0e0);
      }
      uVar5 = FUN_0054db20();
      FUN_0152d760(DAT_01ead0d8,DAT_01ead0dc,"Leftover Items: %zu",uVar5);
    }
    (**(code **)(**(int **)(param_1 + 0x128) + 0xbc))();
    if (DAT_01d59fb8 != '\0') {
      FUN_006185d0();
    }
    *param_4 = 1;
    ExceptionList = pvStack_10;
    return uStack_18;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 6923 ; VA 0x006301bc ; Catch@006301bc */

undefined * Catch_006301bc(void)

{
  char *pcVar1;
  char *pcVar2;
  int unaff_EBP;
  
  pcVar1 = (char *)(**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  pcVar2 = "empty error string";
  if (pcVar1 != (char *)0x0) {
    pcVar2 = pcVar1;
  }
  FUN_0086f2f0(3,"SendData: %s",pcVar2);
  **(undefined4 **)(unaff_EBP + 0x14) = 0;
  return &DAT_006301ed;
}



/* FUNCTION 6924 ; VA 0x00630580 ; FUN_00630580 */

undefined4 * __thiscall FUN_00630580(int param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  char acStack_60 [4];
  undefined auStack_5c [48];
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f318;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (*(int *)(param_1 + 0x1dc4) != 0) {
    ExceptionList = &pvStack_10;
    FUN_006865f0(acStack_60,param_3);
    uStack_8 = 0;
    if (acStack_60[0] == '\0') {
      uStack_1c = 0;
      puVar4 = (undefined4 *)auStack_2c;
      uStack_18 = 0xf;
      auStack_2c[0] = 0;
    }
    else {
      puVar4 = (undefined4 *)FUN_0054ef60(auStack_5c);
    }
    param_2[4] = 0;
    param_2[5] = 0;
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *param_2 = *puVar4;
    param_2[1] = uVar1;
    param_2[2] = uVar2;
    param_2[3] = uVar3;
    *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    if (acStack_60[0] == '\0') {
      FUN_005507b0();
    }
    else {
      FUN_005507b0();
    }
    thunk_FUN_0056ca60();
    ExceptionList = pvStack_10;
    return param_2;
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return param_2;
}



/* FUNCTION 6925 ; VA 0x00630690 ; FUN_00630690 */

undefined4 * __thiscall FUN_00630690(int param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  char acStack_60 [4];
  undefined auStack_5c [48];
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f318;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (*(int *)(param_1 + 0x1dc4) != 0) {
    ExceptionList = &pvStack_10;
    FUN_00686a90(acStack_60,param_3);
    uStack_8 = 0;
    if (acStack_60[0] == '\0') {
      uStack_1c = 0;
      puVar4 = (undefined4 *)auStack_2c;
      uStack_18 = 0xf;
      auStack_2c[0] = 0;
    }
    else {
      puVar4 = (undefined4 *)FUN_0054ef60(auStack_5c);
    }
    param_2[4] = 0;
    param_2[5] = 0;
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *param_2 = *puVar4;
    param_2[1] = uVar1;
    param_2[2] = uVar2;
    param_2[3] = uVar3;
    *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    if (acStack_60[0] == '\0') {
      FUN_005507b0();
    }
    else {
      FUN_005507b0();
    }
    thunk_FUN_0056ca60();
    ExceptionList = pvStack_10;
    return param_2;
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return param_2;
}



/* FUNCTION 6926 ; VA 0x006307a0 ; FUN_006307a0 */

int __thiscall FUN_006307a0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(int *)(param_1 + 0x1dc4) = param_2;
  piVar3 = *(int **)(param_1 + 0x1dc8);
  *(int **)(param_1 + 0x1dc8) = param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar2 = *piVar3;
    param_2 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 6927 ; VA 0x00630820 ; FUN_00630820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630820(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead278) {
    FUN_016f3809(&DAT_01ead278);
    if (DAT_01ead278 == -1) {
      _DAT_01ead26c = FUN_005c65e0;
      _DAT_01ead270 = FUN_005c65e0;
      DAT_01ead274 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead278);
    }
  }
  return &DAT_01ead26c;
}



/* FUNCTION 6928 ; VA 0x00630890 ; FUN_00630890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630890(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead488) {
    FUN_016f3809(&DAT_01ead488);
    if (DAT_01ead488 == -1) {
      _DAT_01ead47c = FUN_00619e80;
      _DAT_01ead480 = FUN_00619e80;
      DAT_01ead484 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead488);
    }
  }
  return &DAT_01ead47c;
}



/* FUNCTION 6929 ; VA 0x00630900 ; FUN_00630900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00630900(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3c8) {
    FUN_016f3809(&DAT_01ead3c8);
    if (DAT_01ead3c8 == -1) {
      DAT_01ead3bc = FUN_0057bbb0;
      _DAT_01ead3c0 = FUN_005880a0;
      DAT_01ead3c4 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead3c8);
    }
  }
  return &DAT_01ead3bc;
}



/* FUNCTION 6930 ; VA 0x00630970 ; FUN_00630970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630970(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3b8) {
    FUN_016f3809(&DAT_01ead3b8);
    if (DAT_01ead3b8 == -1) {
      _DAT_01ead3ac = FUN_0057bbb0;
      _DAT_01ead3b0 = FUN_005880a0;
      DAT_01ead3b4 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead3b8);
    }
  }
  return &DAT_01ead3ac;
}



/* FUNCTION 6931 ; VA 0x006309e0 ; FUN_006309e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_006309e0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead288) {
    FUN_016f3809(&DAT_01ead288);
    if (DAT_01ead288 == -1) {
      DAT_01ead27c = FUN_0057bbb0;
      _DAT_01ead280 = FUN_005880a0;
      DAT_01ead284 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead288);
    }
  }
  return &DAT_01ead27c;
}



/* FUNCTION 6932 ; VA 0x00630a50 ; FUN_00630a50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630a50(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead438) {
    FUN_016f3809(&DAT_01ead438);
    if (DAT_01ead438 == -1) {
      _DAT_01ead42c = FUN_005c65e0;
      _DAT_01ead430 = FUN_005c65e0;
      _DAT_01ead434 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead438);
    }
  }
  return &DAT_01ead42c;
}



/* FUNCTION 6933 ; VA 0x00630ac0 ; FUN_00630ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630ac0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead2d8) {
    FUN_016f3809(&DAT_01ead2d8);
    if (DAT_01ead2d8 == -1) {
      _DAT_01ead2cc = FUN_005c65f0;
      _DAT_01ead2d0 = FUN_005c93a0;
      _DAT_01ead2d4 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ead2d8);
    }
  }
  return &DAT_01ead2cc;
}



/* FUNCTION 6934 ; VA 0x00630b30 ; FUN_00630b30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630b30(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead2a8) {
    FUN_016f3809(&DAT_01ead2a8);
    if (DAT_01ead2a8 == -1) {
      _DAT_01ead29c = FUN_005c65e0;
      _DAT_01ead2a0 = FUN_005c65e0;
      _DAT_01ead2a4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead2a8);
    }
  }
  return &DAT_01ead29c;
}



/* FUNCTION 6935 ; VA 0x00630ba0 ; FUN_00630ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630ba0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead428) {
    FUN_016f3809(&DAT_01ead428);
    if (DAT_01ead428 == -1) {
      _DAT_01ead41c = FUN_00619ea0;
      _DAT_01ead420 = FUN_00619ea0;
      _DAT_01ead424 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead428);
    }
  }
  return &DAT_01ead41c;
}



/* FUNCTION 6936 ; VA 0x00630c10 ; FUN_00630c10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630c10(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead378) {
    FUN_016f3809(&DAT_01ead378);
    if (DAT_01ead378 == -1) {
      _DAT_01ead36c = FUN_00619ec0;
      _DAT_01ead370 = FUN_00619ec0;
      _DAT_01ead374 = FUN_0061bd10;
      FUN_016f37bf(&DAT_01ead378);
    }
  }
  return &DAT_01ead36c;
}



/* FUNCTION 6937 ; VA 0x00630c80 ; FUN_00630c80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630c80(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead358) {
    FUN_016f3809(&DAT_01ead358);
    if (DAT_01ead358 == -1) {
      _DAT_01ead34c = FUN_00619ed0;
      _DAT_01ead350 = FUN_00619ed0;
      _DAT_01ead354 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead358);
    }
  }
  return &DAT_01ead34c;
}



/* FUNCTION 6938 ; VA 0x00630cf0 ; FUN_00630cf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630cf0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead298) {
    FUN_016f3809(&DAT_01ead298);
    if (DAT_01ead298 == -1) {
      _DAT_01ead28c = FUN_005c65f0;
      _DAT_01ead290 = FUN_005c93a0;
      _DAT_01ead294 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ead298);
    }
  }
  return &DAT_01ead28c;
}



/* FUNCTION 6939 ; VA 0x00630d60 ; FUN_00630d60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630d60(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3d8) {
    FUN_016f3809(&DAT_01ead3d8);
    if (DAT_01ead3d8 == -1) {
      _DAT_01ead3cc = FUN_00619ef0;
      _DAT_01ead3d0 = FUN_00619ef0;
      DAT_01ead3d4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3d8);
    }
  }
  return &DAT_01ead3cc;
}



/* FUNCTION 6940 ; VA 0x00630dd0 ; FUN_00630dd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630dd0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead2f8) {
    FUN_016f3809(&DAT_01ead2f8);
    if (DAT_01ead2f8 == -1) {
      _DAT_01ead2ec = FUN_00619f20;
      _DAT_01ead2f0 = FUN_00619f20;
      _DAT_01ead2f4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead2f8);
    }
  }
  return &DAT_01ead2ec;
}



/* FUNCTION 6941 ; VA 0x00630e40 ; FUN_00630e40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630e40(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead448) {
    FUN_016f3809(&DAT_01ead448);
    if (DAT_01ead448 == -1) {
      _DAT_01ead43c = FUN_005c65e0;
      _DAT_01ead440 = FUN_005c65e0;
      _DAT_01ead444 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead448);
    }
  }
  return &DAT_01ead43c;
}



/* FUNCTION 6942 ; VA 0x00630eb0 ; FUN_00630eb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630eb0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead388) {
    FUN_016f3809(&DAT_01ead388);
    if (DAT_01ead388 == -1) {
      _DAT_01ead37c = FUN_005c6620;
      _DAT_01ead380 = FUN_005c6620;
      _DAT_01ead384 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead388);
    }
  }
  return &DAT_01ead37c;
}



/* FUNCTION 6943 ; VA 0x00630f20 ; FUN_00630f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630f20(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead398) {
    FUN_016f3809(&DAT_01ead398);
    if (DAT_01ead398 == -1) {
      _DAT_01ead38c = FUN_00619f50;
      _DAT_01ead390 = FUN_00619f50;
      _DAT_01ead394 = FUN_0061bd20;
      FUN_016f37bf(&DAT_01ead398);
    }
  }
  return &DAT_01ead38c;
}



/* FUNCTION 6944 ; VA 0x00630f90 ; FUN_00630f90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00630f90(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead368) {
    FUN_016f3809(&DAT_01ead368);
    if (DAT_01ead368 == -1) {
      _DAT_01ead35c = FUN_005c6600;
      _DAT_01ead360 = FUN_005c6600;
      _DAT_01ead364 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead368);
    }
  }
  return &DAT_01ead35c;
}



/* FUNCTION 6945 ; VA 0x00631000 ; FUN_00631000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00631000(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead308) {
    FUN_016f3809(&DAT_01ead308);
    if (DAT_01ead308 == -1) {
      _DAT_01ead2fc = FUN_00619f80;
      _DAT_01ead300 = FUN_00619f80;
      _DAT_01ead304 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead308);
    }
  }
  return &DAT_01ead2fc;
}



/* FUNCTION 6946 ; VA 0x00631070 ; FUN_00631070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00631070(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead338) {
    FUN_016f3809(&DAT_01ead338);
    if (DAT_01ead338 == -1) {
      _DAT_01ead32c = FUN_00619f80;
      _DAT_01ead330 = FUN_00619f80;
      _DAT_01ead334 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead338);
    }
  }
  return &DAT_01ead32c;
}



/* FUNCTION 6947 ; VA 0x006310e0 ; FUN_006310e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_006310e0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead2b8) {
    FUN_016f3809(&DAT_01ead2b8);
    if (DAT_01ead2b8 == -1) {
      _DAT_01ead2ac = FUN_00619fa0;
      _DAT_01ead2b0 = FUN_00619fa0;
      _DAT_01ead2b4 = FUN_0061bd30;
      FUN_016f37bf(&DAT_01ead2b8);
    }
  }
  return &DAT_01ead2ac;
}



/* FUNCTION 6948 ; VA 0x00631150 ; FUN_00631150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00631150(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead458) {
    FUN_016f3809(&DAT_01ead458);
    if (DAT_01ead458 == -1) {
      _DAT_01ead44c = FUN_00619f80;
      _DAT_01ead450 = FUN_00619f80;
      DAT_01ead454 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead458);
    }
  }
  return &DAT_01ead44c;
}



/* FUNCTION 6949 ; VA 0x006311c0 ; FUN_006311c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_006311c0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead348) {
    FUN_016f3809(&DAT_01ead348);
    if (DAT_01ead348 == -1) {
      _DAT_01ead33c = FUN_00619fb0;
      _DAT_01ead340 = FUN_00619fb0;
      _DAT_01ead344 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead348);
    }
  }
  return &DAT_01ead33c;
}



/* FUNCTION 6950 ; VA 0x00631230 ; FUN_00631230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00631230(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead328) {
    FUN_016f3809(&DAT_01ead328);
    if (DAT_01ead328 == -1) {
      _DAT_01ead31c = FUN_00619fd0;
      _DAT_01ead320 = FUN_00619fd0;
      DAT_01ead324 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead328);
    }
  }
  return &DAT_01ead31c;
}



/* FUNCTION 6951 ; VA 0x006312a0 ; FUN_006312a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_006312a0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead318) {
    FUN_016f3809(&DAT_01ead318);
    if (DAT_01ead318 == -1) {
      _DAT_01ead30c = FUN_005c6600;
      _DAT_01ead310 = FUN_005c6600;
      _DAT_01ead314 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead318);
    }
  }
  return &DAT_01ead30c;
}



/* FUNCTION 6952 ; VA 0x00631310 ; FUN_00631310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00631310(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead2c8) {
    FUN_016f3809(&DAT_01ead2c8);
    if (DAT_01ead2c8 == -1) {
      _DAT_01ead2bc = FUN_0061a010;
      _DAT_01ead2c0 = FUN_0061a010;
      _DAT_01ead2c4 = FUN_0061bd50;
      FUN_016f37bf(&DAT_01ead2c8);
    }
  }
  return &DAT_01ead2bc;
}



/* FUNCTION 6953 ; VA 0x00631380 ; FUN_00631380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00631380(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3a8) {
    FUN_016f3809(&DAT_01ead3a8);
    if (DAT_01ead3a8 == -1) {
      _DAT_01ead39c = FUN_005c65e0;
      _DAT_01ead3a0 = FUN_005c65e0;
      _DAT_01ead3a4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3a8);
    }
  }
  return &DAT_01ead39c;
}



/* FUNCTION 6954 ; VA 0x006313f0 ; FUN_006313f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_006313f0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead468) {
    FUN_016f3809(&DAT_01ead468);
    if (DAT_01ead468 == -1) {
      _DAT_01ead45c = FUN_00619fb0;
      _DAT_01ead460 = FUN_00619fb0;
      DAT_01ead464 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead468);
    }
  }
  return &DAT_01ead45c;
}



/* FUNCTION 6955 ; VA 0x00631460 ; FUN_00631460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00631460(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead478) {
    FUN_016f3809(&DAT_01ead478);
    if (DAT_01ead478 == -1) {
      _DAT_01ead46c = FUN_005c6620;
      _DAT_01ead470 = FUN_005c6620;
      _DAT_01ead474 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead478);
    }
  }
  return &DAT_01ead46c;
}



/* FUNCTION 6956 ; VA 0x006314d0 ; FUN_006314d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_006314d0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead418) {
    FUN_016f3809(&DAT_01ead418);
    if (DAT_01ead418 == -1) {
      DAT_01ead40c = FUN_005c6620;
      _DAT_01ead410 = FUN_005c6620;
      DAT_01ead414 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead418);
    }
  }
  return &DAT_01ead40c;
}



/* FUNCTION 6957 ; VA 0x00631540 ; FUN_00631540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00631540(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3f8) {
    FUN_016f3809(&DAT_01ead3f8);
    if (DAT_01ead3f8 == -1) {
      _DAT_01ead3ec = FUN_005c65e0;
      _DAT_01ead3f0 = FUN_005c65e0;
      _DAT_01ead3f4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3f8);
    }
  }
  return &DAT_01ead3ec;
}



/* FUNCTION 6958 ; VA 0x006315b0 ; FUN_006315b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_006315b0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead408) {
    FUN_016f3809(&DAT_01ead408);
    if (DAT_01ead408 == -1) {
      _DAT_01ead3fc = FUN_005c6600;
      _DAT_01ead400 = FUN_005c6600;
      DAT_01ead404 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead408);
    }
  }
  return &DAT_01ead3fc;
}



/* FUNCTION 6959 ; VA 0x00631620 ; FUN_00631620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00631620(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3e8) {
    FUN_016f3809(&DAT_01ead3e8);
    if (DAT_01ead3e8 == -1) {
      _DAT_01ead3dc = FUN_0061a030;
      _DAT_01ead3e0 = FUN_0061a030;
      DAT_01ead3e4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3e8);
    }
  }
  return &DAT_01ead3dc;
}



/* FUNCTION 6960 ; VA 0x00631690 ; FUN_00631690 */

undefined4 __thiscall FUN_00631690(undefined4 *param_1,byte *param_2,uint param_3)

{
  byte *pbVar1;
  uint uVar2;
  bool bVar3;
  
  if ((uint)param_1[1] < param_3) {
    return 0;
  }
  if (param_3 == 0) {
    return 1;
  }
  pbVar1 = (byte *)*param_1;
  uVar2 = param_3 - 4;
  if (3 < param_3) {
    do {
      if (*(int *)pbVar1 != *(int *)param_2) goto LAB_006316c6;
      pbVar1 = pbVar1 + 4;
      param_2 = param_2 + 4;
      bVar3 = 3 < uVar2;
      uVar2 = uVar2 - 4;
    } while (bVar3);
  }
  if (uVar2 != 0xfffffffc) {
LAB_006316c6:
    bVar3 = *pbVar1 < *param_2;
    if ((*pbVar1 != *param_2) ||
       ((uVar2 != 0xfffffffd &&
        ((bVar3 = pbVar1[1] < param_2[1], pbVar1[1] != param_2[1] ||
         ((uVar2 != 0xfffffffe &&
          ((bVar3 = pbVar1[2] < param_2[2], pbVar1[2] != param_2[2] ||
           ((uVar2 != 0xffffffff && (bVar3 = pbVar1[3] < param_2[3], pbVar1[3] != param_2[3]))))))))
        )))) {
      uVar2 = -(uint)bVar3 | 1;
      goto LAB_006316fc;
    }
  }
  uVar2 = 0;
LAB_006316fc:
  if (uVar2 != 0) {
    return 0;
  }
  return 1;
}



/* FUNCTION 6961 ; VA 0x00631710 ; FUN_00631710 */

undefined4 __fastcall FUN_00631710(int param_1)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined auStack_34 [20];
  undefined auStack_20 [8];
  int iStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a9e8;
  pvStack_10 = ExceptionList;
  iVar4 = param_1 + 0xfc;
  ExceptionList = &pvStack_10;
  iStack_18 = iVar4;
  iVar3 = FUN_016dee6d(iVar4);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  puVar5 = *(undefined4 **)(param_1 + 300);
  puVar6 = *(undefined4 **)(param_1 + 0x130);
  uStack_8 = 0;
  if (puVar5 != puVar6) {
    do {
      uStack_14 = 1;
      uVar7 = *puVar5;
      FUN_0170cc70(puVar5,puVar5 + 1,(int)puVar6 - (int)(puVar5 + 1));
      *(int *)(param_1 + 0x130) = *(int *)(param_1 + 0x130) + -4;
      if (iVar4 == 0) {
        puVar5 = (undefined4 *)FUN_00621c50(auStack_20,1);
        FUN_00610cc0(*puVar5,puVar5[1]);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_34,&DAT_01c2a4ec);
      }
      iVar3 = FUN_016deec8(iVar4);
      if (iVar3 != 0) {
        FUN_016df3c9(iVar3);
      }
      uStack_14 = 0;
      cVar2 = FUN_0061b1d0(uVar7);
      if (cVar2 == '\0') {
        uVar7 = 0;
        bVar1 = false;
        goto LAB_006317ec;
      }
      iVar3 = FUN_016dee6d(iVar4);
      if (iVar3 != 0) {
        FUN_016df3c9(iVar3);
      }
      puVar5 = *(undefined4 **)(param_1 + 300);
      puVar6 = *(undefined4 **)(param_1 + 0x130);
    } while (puVar5 != puVar6);
  }
  uStack_14 = 1;
  uVar7 = 1;
  bVar1 = true;
LAB_006317ec:
  uStack_8 = 1;
  if ((bVar1) && (iVar4 = FUN_016deec8(iVar4), iVar4 != 0)) {
    FUN_016df3c9(iVar4);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 6962 ; VA 0x00631860 ; FUN_00631860 */

undefined4 FUN_00631860(int param_1)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  int *piVar9;
  float10 fVar10;
  int iStack_34;
  int iStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_20;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f351;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eadc98);
  uStack_8 = 0;
  uStack_20 = uVar3;
  fVar10 = (float10)FUN_00a36320(*(undefined8 *)(param_1 + 8),DAT_018ce308,0x40a00000,0x40a00000);
  iVar5 = iStack_14;
  uStack_2c = (double)fVar10;
  iVar7 = (int)fVar10;
  if (iVar7 < 1) {
    uVar8 = 1;
    goto LAB_00631b17;
  }
  if (*(int **)(iStack_14 + 0x128) == (int *)0x0) {
    uVar8 = 0;
    goto LAB_00631b17;
  }
  cVar2 = (**(code **)(**(int **)(iStack_14 + 0x128) + 0x124))();
  if (cVar2 == '\0') {
    (**(code **)(**(int **)(iVar5 + 0x128) + 0x208))();
    (**(code **)(**(int **)(iVar5 + 0x128) + 0x20c))();
  }
  if (iVar7 < 3) {
    piVar6 = *(int **)(iVar5 + 0x128);
    iVar5 = piVar6[3];
    iVar7 = FUN_005ee350();
    piVar9 = (int *)0x0;
    if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
        (uint)*(ushort *)(iVar7 + 0x1da)) {
      piVar9 = piVar6;
    }
    if (piVar9 != (int *)0x0) {
      uVar4 = FUN_006a6900();
      iStack_18 = -(uint)(uVar4 < (uint)piVar9[0x422]) - piVar9[0x423];
      if ((iStack_18 != 0) || (0x44c < uVar4 - piVar9[0x422])) {
        FUN_00683df0();
        iVar5 = FUN_006a6900();
        piVar9[0x422] = iVar5;
        piVar9[0x423] = 0;
      }
      FUN_016830f0(&iStack_34);
      if (((*(char *)((int)piVar9 + 0x3c32) == '\0') && (*(char *)((int)piVar9 + 0x3c31) == '\0'))
         && (cVar2 = (**(code **)(*piVar9 + 0x218))(), cVar2 != '\0')) {
        *(undefined *)((int)piVar9 + 0x3c32) = 1;
        piVar9[0x424] = iStack_34;
        piVar9[0x425] = iStack_30;
      }
      else {
        cVar2 = FUN_0061eee0();
        if (cVar2 != '\0') {
          cVar2 = (**(code **)(*piVar9 + 0x21c))();
          iVar7 = (int)uStack_2c;
          if (cVar2 != '\0') {
            *(undefined *)((int)piVar9 + 0x3c32) = 0;
            *(double *)(piVar9 + 0x426) =
                 ((double)CONCAT44(iStack_30,iStack_34) - *(double *)(piVar9 + 0x424)) +
                 *(double *)(piVar9 + 0x426);
            piVar9[0x424] = iStack_34;
            piVar9[0x425] = iStack_30;
          }
          goto LAB_006319ec;
        }
      }
    }
    iVar7 = (int)uStack_2c;
  }
LAB_006319ec:
  FUN_008e9840(*(undefined4 *)(iStack_14 + 0x128));
  iVar5 = iStack_14;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0 < iVar7) {
    do {
      piVar6 = *(int **)(iVar5 + 0x128);
      iStack_18 = FUN_006a6900();
      (**(code **)(*piVar6 + 0x210))();
      puVar1 = (undefined4 *)piVar6[0x658];
      uStack_2c = (double)CONCAT44(puVar1,(undefined4)uStack_2c);
      piVar6 = *(int **)*puVar1;
      if (piVar6 == (int *)0x0) {
        piVar6 = (int *)FUN_00621d50();
      }
      else {
        *(int *)*puVar1 = *piVar6;
      }
      *piVar6 = (int)puVar1;
      uStack_8._0_1_ = 3;
      if (piVar6 == (int *)0xfffffffc) {
        uVar3 = 0;
      }
      else {
        uVar3 = FUN_006fb5a0();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_006b1f50(uVar3);
      iVar7 = iVar7 + -1;
      uVar3 = uStack_20;
    } while (iVar7 != 0);
  }
  uVar8 = 1;
  iVar5 = (**(code **)(**(int **)(iStack_14 + 0x128) + 0xb4))();
  if (iVar5 != 0) {
    FUN_00922170();
  }
  FUN_008eb130();
LAB_00631b17:
  uStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 6963 ; VA 0x00631b40 ; FUN_00631b40 */

float __thiscall FUN_00631b40(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  double dVar7;
  double dVar8;
  float fStack_8;
  
  piVar1 = (int *)(param_1 + 0x128);
  if (*(int *)(param_1 + 0x128) == 0) {
    return (float)1;
  }
  cVar3 = FUN_00618c40();
  if (cVar3 == '\0') {
    return (float)1;
  }
  cVar3 = FUN_006b1e70();
  if ((cVar3 != '\0') && (cVar3 = FUN_006b1e70(), cVar3 != '\0')) {
    if (DAT_01d5b810 == '\0') {
      return (float)1;
    }
    iVar5 = *piVar1;
    uVar2 = *(uint *)(*(int *)(iVar5 + 0x1db4) + 0x1fc);
    if (uVar2 < *(uint *)(iVar5 + 0x3814)) {
      return (float)1;
    }
    if ((uVar2 <= *(uint *)(iVar5 + 0x3814)) &&
       (*(uint *)(*(int *)(iVar5 + 0x1db4) + 0x1f8) <= *(uint *)(iVar5 + 0x3810))) {
      return (float)1;
    }
  }
  if (DAT_01d59fc8 == '\0') {
    iVar5 = *(int *)(param_1 + 0x140) + 1;
    *(int *)(param_1 + 0x140) = iVar5;
    fStack_8 = (float)(*(int *)(param_1 + 0x138) - (param_1 + 0x138));
    if (fStack_8 < (float)((double)iVar5 + (double)(&DAT_018c0d90)[-(iVar5 >> 0x1f)])) {
      *(undefined4 *)(param_1 + 0x140) = 0;
      if ((int *)*piVar1 != (int *)0x0) {
        (**(code **)(*(int *)*piVar1 + 0x200))();
      }
    }
  }
  iVar5 = 0;
  fStack_8 = 0.0;
  dVar8 = *(double *)(param_2 + 8);
  dVar7 = dVar8;
  if (DAT_01d59fc0 != '\0') {
    dVar7 = DAT_018c0d60 / (double)DAT_01d5b4b8;
    if (DAT_018c0d60 / (double)DAT_01d5b4b8 <= dVar8) {
      dVar7 = dVar8;
    }
    cVar3 = (**(code **)(*(int *)*piVar1 + 200))();
    iVar6 = DAT_01d5b4c8;
    if (cVar3 == '\0') {
      iVar6 = DAT_01d5b4c4;
    }
    cVar3 = (**(code **)(*(int *)*piVar1 + 200))();
    iVar5 = DAT_01d5b4c0;
    if (cVar3 == '\0') {
      iVar5 = DAT_01d5b4bc;
    }
    if (DAT_01d5b590 == '\0') {
      iVar4 = (int)(dVar7 / (DAT_018c0d60 / (double)DAT_01d5b4b8));
      if ((iVar4 <= iVar5) && (iVar5 = iVar4, iVar4 < 1)) {
        iVar5 = 1;
      }
      iVar5 = (iVar6 / DAT_01d5b4b8) * iVar5;
    }
    else {
      dVar8 = DAT_018c0d60 / (double)DAT_01d5b4b8;
      if (DAT_018c0d60 / (double)DAT_01d5b4b8 <= dVar7) {
        dVar8 = dVar7;
      }
      iVar5 = (iVar6 / DAT_01d5b4b8) * iVar5;
      if ((int)((double)iVar6 * dVar8) <= iVar5) {
        iVar5 = (int)((double)iVar6 * dVar8);
      }
    }
    if (iVar5 == 0) {
      return (float)1;
    }
  }
  FUN_0062fa10(dVar7,iVar5,&fStack_8);
  return fStack_8;
}



/* FUNCTION 6964 ; VA 0x00631d70 ; FUN_00631d70 */

void __fastcall FUN_00631d70(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined auStack_20 [20];
  undefined auStack_c [8];
  
  if ((*param_1 != 0) && (*(char *)(param_1 + 1) != '\0')) {
    iVar1 = FUN_016deec8(*param_1);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    *(undefined *)(param_1 + 1) = 0;
    return;
  }
  puVar2 = (undefined4 *)FUN_00621c50(auStack_c,1);
  FUN_00610cc0(*puVar2,puVar2[1]);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c2a4ec);
}



/* FUNCTION 6965 ; VA 0x00631dd0 ; FUN_00631dd0 */

void __fastcall FUN_00631dd0(int param_1)

{
  *(undefined *)(param_1 + 0x22) = 0;
  return;
}



/* FUNCTION 6966 ; VA 0x00631de0 ; FUN_00631de0 */

void __thiscall FUN_00631de0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f368;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d(param_1 + 0x1c);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  uStack_8 = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    uVar4 = FUN_009c91f0(param_2 + 1);
    uVar6 = uVar4 % *(uint *)(param_1 + 8);
    piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x18));
    if (piVar1 != (int *)0x0) {
      iVar3 = *piVar1;
      while( true ) {
        if ((iVar3 == 0) || (*(uint *)(iVar3 + 4) % *(uint *)(param_1 + 8) != uVar6))
        goto LAB_00631e94;
        if ((*(uint *)(iVar3 + 4) == uVar4) && (cVar2 = FUN_009c8f50(iVar3 + 8), cVar2 != '\0'))
        break;
        piVar1 = (int *)*piVar1;
        iVar3 = *piVar1;
      }
      FUN_0061ad00(piVar1,*(undefined4 *)*piVar1);
      if (*piVar1 != 0) {
        uVar4 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 8);
        if (uVar6 == uVar4) goto LAB_00631e94;
        *(int **)(*(int *)(param_1 + 0x18) + uVar4 * 4) = piVar1;
      }
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x18) + uVar6 * 4);
      if ((int *)*puVar5 == piVar1) {
        *puVar5 = 0;
      }
    }
  }
LAB_00631e94:
  uStack_8 = 1;
  iVar3 = FUN_016deec8(param_1 + 0x1c);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  *param_2 = 0;
  FUN_00611620();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6967 ; VA 0x00631f20 ; FUN_00631f20 */

void __thiscall FUN_00631f20(int param_1,double param_2)

{
  param_2 = param_2 * DAT_018c0d70;
  *(int *)(param_1 + 0x3ac8) = *(int *)(param_1 + 0x3ac8) + 1;
  *(double *)(param_1 + 0x3ac0) = param_2 + *(double *)(param_1 + 0x3ac0);
  return;
}



/* FUNCTION 6968 ; VA 0x00631f50 ; FUN_00631f50 */

void __thiscall FUN_00631f50(int param_1,char param_2,char param_3,char param_4)

{
  *(int *)(param_1 + 0x3ab0) = *(int *)(param_1 + 0x3ab0) + 1;
  if (param_2 != '\0') {
    *(int *)(param_1 + 0x3ab4) = *(int *)(param_1 + 0x3ab4) + 1;
  }
  if (param_3 != '\0') {
    *(int *)(param_1 + 0x3ab8) = *(int *)(param_1 + 0x3ab8) + 1;
  }
  if (param_4 != '\0') {
    *(int *)(param_1 + 0x3abc) = *(int *)(param_1 + 0x3abc) + 1;
  }
  return;
}



/* FUNCTION 6969 ; VA 0x00631f90 ; FUN_00631f90 */

void * __thiscall FUN_00631f90(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  void *pvVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  undefined auStack_54 [16];
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f3a0;
  pvStack_10 = ExceptionList;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if (param_1[0xe26] != 0) {
    ExceptionList = &pvStack_10;
    pvVar4 = (void *)FUN_008a65e0(0,0);
    param_1[0xe26] = 0;
    piVar6 = (int *)param_1[0xe27];
    param_1[0xe27] = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar5 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1;
        pvVar4 = (void *)*piVar1;
        *piVar1 = iVar5 + -1;
        UNLOCK();
        if (iVar5 + -1 == 0) {
          pvVar4 = (void *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  if (param_2 != 0) {
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c5904,7);
    uStack_8 = 0;
    iVar5 = FUN_008a1240(auStack_3c);
    if (iVar5 == 0) {
      iVar5 = 0;
    }
    else {
      iVar5 = iVar5 + 4;
    }
    pvVar4 = (void *)FUN_0060ddd0(&iStack_1c,iVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_28) {
      uVar8 = uStack_28 + 1;
      uVar7 = auStack_3c[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_3c[0] - 4);
        uVar8 = uStack_28 + 0x24;
        if (0x1f < (auStack_3c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      pvVar4 = (void *)FUN_01674ea0(uVar7,uVar8);
    }
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    if (iStack_1c != 0) {
      piVar6 = (int *)(**(code **)(*param_1 + 0x164))(&iStack_24);
      iVar5 = *piVar6;
      iVar2 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      param_1[0xe26] = iVar5;
      piVar6 = (int *)param_1[0xe27];
      param_1[0xe27] = iVar2;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar5 = piVar6[1] + -1;
        piVar6[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar5 = piVar6[2] + -1;
          piVar6[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_20[1] + -1;
        piStack_20[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar5 = piStack_20[2] + -1;
          piStack_20[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
      iVar5 = (**(code **)(*param_1 + 0xb8))();
      if (iVar5 == 0) {
        uStack_44 = 0;
        uStack_40 = 0xf;
        auStack_54[0] = 0;
        pcVar3 = *(code **)(*(int *)param_1[0xe26] + 0x38);
        FUN_005542c0("ServerStatsItem",0xf);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        (*pcVar3)(auStack_54);
        FUN_005507b0();
      }
      else {
        (**(code **)(*(int *)param_1[0xe26] + 0x38))(*(undefined4 *)(iVar5 + 0x28));
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      iStack_24 = iStack_1c;
      piStack_20 = piStack_18;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      pvVar4 = (void *)FUN_008a65e0(iStack_1c,0);
      if (piStack_18 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return pvVar4;
      }
      LOCK();
      piVar6 = piStack_18 + 1;
      iVar5 = *piVar6;
      pvVar4 = (void *)*piVar6;
      *piVar6 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar6 = piStack_18 + 2;
        iVar5 = *piVar6;
        pvVar4 = (void *)*piVar6;
        *piVar6 = iVar5 + -1;
        UNLOCK();
        if (iVar5 + -1 == 0) {
          pvVar4 = (void *)(**(code **)(*piStack_18 + 4))();
        }
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar6 = piStack_18 + 1;
      iVar5 = *piVar6;
      pvVar4 = (void *)*piVar6;
      *piVar6 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piStack_18)();
        LOCK();
        piVar6 = piStack_18 + 2;
        iVar5 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          pvVar4 = (void *)(**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 6970 ; VA 0x00632220 ; FUN_00632220 */

uint __thiscall FUN_00632220(int *param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  longlong lVar5;
  longlong lVar6;
  
  uVar2 = *(uint *)(*(int *)(param_2 + 0xc) + 0x1d4) & 3;
  if (uVar2 != 0) {
    uVar4 = uVar2 - 1;
    if ((uVar2 - 1 == 0) || (uVar4 = uVar2 - 2, uVar2 - 2 != 0)) {
LAB_0063229a:
      return CONCAT31((int3)(uVar4 >> 8),1);
    }
    uVar2 = 0;
    if (*(int *)(param_2 + 0x34) != 0) {
      iVar1 = *(int *)(*(int *)(param_2 + 0x34) + 0xc);
      iVar3 = FUN_00913630();
      uVar2 = (uint)*(ushort *)(iVar3 + 0x1da);
      if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <= uVar2) &&
         (uVar2 = (**(code **)(*param_1 + 0xb4))(), uVar2 != 0)) {
        lVar5 = FUN_00928340();
        lVar6 = FUN_00928340();
        uVar2 = (uint)lVar6;
        uVar4 = uVar2;
        if (lVar5 == lVar6) goto LAB_0063229a;
      }
    }
  }
  return uVar2 & 0xffffff00;
}



/* FUNCTION 6971 ; VA 0x006322b0 ; FUN_006322b0 */

void FUN_006322b0(undefined4 param_1,undefined4 param_2)

{
  undefined4 ****ppppuVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 ***apppuStack_2c [5];
  uint uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00565660(0x10,0);
  ppppuVar1 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar1 = (undefined4 ****)apppuStack_2c[0];
  }
  uStack_8 = 0;
  FUN_00a33fb0(ppppuVar1);
  ppppuVar1 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar1 = (undefined4 ****)apppuStack_2c[0];
  }
  FUN_006ad5e0(ppppuVar1,0x10);
  uStack_11 = 0;
  FUN_006ad5e0(&uStack_11,1);
  uVar2 = FUN_00a33fa0(param_2);
  FUN_006ad360(uVar2);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar3) {
      ppppuVar1 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6972 ; VA 0x00632380 ; FUN_00632380 */

void FUN_00632380(undefined param_1)

{
  FUN_006ad5e0(&param_1,1);
  return;
}



/* FUNCTION 6973 ; VA 0x006323a0 ; FUN_006323a0 */

void FUN_006323a0(void)

{
  FUN_006ad5e0(&stack0x00000004,1);
  return;
}



/* FUNCTION 6974 ; VA 0x006323c0 ; FUN_006323c0 */

void FUN_006323c0(undefined4 param_1)

{
  undefined auStack_8 [4];
  
  FUN_006a5c10(&param_1,auStack_8,4);
  FUN_006ad5e0(auStack_8,4);
  return;
}



/* FUNCTION 6975 ; VA 0x00632400 ; FUN_00632400 */

void __thiscall FUN_00632400(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 ****ppppuVar4;
  undefined4 uVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  bool bVar9;
  undefined4 ***apppuStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined4 *puStack_3c;
  undefined2 uStack_38;
  undefined auStack_34 [4];
  char cStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined uStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f3c0;
  pvStack_10 = ExceptionList;
  cStack_11 = '\0';
  piVar7 = (int *)*param_3;
  piStack_28 = (int *)param_3[1];
  bVar9 = piVar7 == piStack_28;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  do {
    if (bVar9) {
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00606470(auStack_34,piVar7,piVar7);
    if (cStack_30 != '\0') {
      uStack_48 = 0;
      uStack_44 = 0xf;
      apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
      apppuStack_58[0] = (undefined4 ***)FUN_00554060(0x20);
      uStack_48 = 0x10;
      uStack_44 = 0x1f;
      *apppuStack_58[0] = (undefined4 ***)0x0;
      ((undefined4 ****)apppuStack_58[0])[1] = (undefined4 ***)0x0;
      ((undefined4 ****)apppuStack_58[0])[2] = (undefined4 ***)0x0;
      ((undefined4 ****)apppuStack_58[0])[3] = (undefined4 ***)0x0;
      *(undefined *)((undefined4 ****)apppuStack_58[0] + 4) = 0;
      iStack_8 = 0;
      FUN_00a33fb0(apppuStack_58[0]);
      param_3 = param_1 + 0xde6;
      iVar8 = (int)param_1 + *(byte *)(param_1 + 0xde6) + 0x3799;
      uStack_20 = FUN_005702d0(apppuStack_58);
      piVar1 = param_3;
      FUN_00562fc0(&iStack_1c,uStack_20,apppuStack_58,-(uint)(iVar8 != 0) & iVar8 + 1U);
      if (iStack_1c == 0) {
        puStack_3c = (undefined4 *)0x0;
        uStack_40 = -(uint)(piVar1 != (int *)0xfffffffd) & (uint)(piVar1 + 1);
        iStack_8._0_1_ = 1;
        uStack_38 = 0;
        puVar3 = (undefined4 *)FUN_01674e20(0x24);
        uStack_38 = CONCAT11(uStack_38._1_1_,1);
        *puVar3 = 0;
        puVar3[1] = 0;
        puVar3[2] = 0;
        puVar3[3] = 0;
        puVar3[4] = 0;
        puVar3[5] = 0;
        *(undefined8 *)(puVar3 + 6) = 0;
        puVar3[8] = 0;
        puStack_3c = puVar3;
        FUN_0054ef60(apppuStack_58);
        iVar8 = *piVar7;
        puVar3[8] = iVar8;
        LOCK();
        piVar1 = (int *)(iVar8 + 0x28);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        uStack_38 = CONCAT11(1,(undefined)uStack_38);
        FUN_0062b610(param_3[2] + 1);
        FUN_005c5550(auStack_2c,&uStack_40,uStack_20);
        puVar3 = puStack_3c;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (puStack_3c != (undefined4 *)0x0) {
          if (uStack_38._1_1_ != '\0') {
            FUN_00605eb0(uStack_40,puStack_3c + 2);
          }
          FUN_01674ea0(puVar3,0x24);
        }
      }
      ppppuVar4 = apppuStack_58;
      if (0xf < uStack_44) {
        ppppuVar4 = (undefined4 ****)apppuStack_58[0];
      }
      FUN_006ad5e0(ppppuVar4,0x10);
      iVar8 = (int)piStack_18 + *(byte *)(piStack_18 + 0xdec) + 0x37b1;
      uVar5 = FUN_005702d0(apppuStack_58);
      param_1 = piStack_18;
      FUN_00562fc0(&iStack_24,uVar5,apppuStack_58,-(uint)(iVar8 != 0) & iVar8 + 1U);
      if (iStack_24 == 0) {
        if (cStack_11 == '\0') {
          cStack_11 = '\x01';
          cVar2 = (**(code **)(*param_1 + 0xd4))();
          if ((cVar2 == '\0') && (cVar2 = (**(code **)(*param_1 + 0x11c))(), cVar2 == '\0')) {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Client cannot send new shared string values");
          }
        }
        uStack_12 = 0;
        FUN_006ad5e0(&uStack_12,1);
        uVar5 = FUN_00a33fa0(param_2);
        FUN_006ad360(uVar5);
      }
      else {
        param_3 = (int *)CONCAT13(1,param_3._0_3_);
        FUN_006ad5e0((int)&param_3 + 3,1);
      }
      iStack_8 = 0xffffffff;
      if (0xf < uStack_44) {
        uVar6 = uStack_44 + 1;
        ppppuVar4 = (undefined4 ****)apppuStack_58[0];
        if (0xfff < uVar6) {
          ppppuVar4 = (undefined4 ****)apppuStack_58[0][-1];
          uVar6 = uStack_44 + 0x24;
          if (0x1f < (uint)((int)apppuStack_58[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar4,uVar6);
      }
      uStack_48 = 0;
      uStack_44 = 0xf;
      apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
    }
    piVar7 = piVar7 + 1;
    bVar9 = piVar7 == piStack_28;
  } while( true );
}



/* FUNCTION 6976 ; VA 0x006326e0 ; FUN_006326e0 */

void __thiscall FUN_006326e0(int param_1,undefined4 param_2,byte *param_3)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  byte *pbVar4;
  char cVar5;
  byte *pbVar6;
  uint uVar7;
  int iVar8;
  byte *pbVar9;
  bool bVar10;
  byte *pbStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  uint uStack_10;
  byte *pbStack_c;
  undefined auStack_8 [4];
  
  pbStack_c = param_3;
  iStack_18 = *(int *)(param_3 + 0x10);
  if (0xf < *(uint *)(param_3 + 0x14)) {
    pbStack_c = *(byte **)param_3;
  }
  iVar1 = *(int *)(*(int *)(param_1 + 0x19f4) + 0x80);
  iVar8 = (*(int *)(*(int *)(param_1 + 0x19f4) + 0x84) - iVar1) / 0x18 + -1;
  if (0 < iVar8) {
    pbVar9 = (byte *)(iVar1 + iVar8 * 0x18);
    do {
      uStack_10 = *(uint *)(pbVar9 + 0x10);
      pbVar6 = pbVar9;
      if (0xf < *(uint *)(pbVar9 + 0x14)) {
        pbVar6 = *(byte **)pbVar9;
      }
      if (uStack_10 <= *(uint *)(param_3 + 0x10)) {
        pbVar4 = pbStack_c;
        uVar7 = uStack_10;
        if (uStack_10 == 0) goto LAB_006327fb;
        while (uVar3 = uVar7 - 4, 3 < uVar7) {
          if (*(int *)pbVar4 != *(int *)pbVar6) goto LAB_00632786;
          pbVar6 = pbVar6 + 4;
          pbVar4 = pbVar4 + 4;
          uVar7 = uVar3;
        }
        if (uVar3 == 0xfffffffc) {
LAB_006327ba:
          uVar7 = 0;
        }
        else {
LAB_00632786:
          bVar10 = *pbVar4 < *pbVar6;
          if ((*pbVar4 == *pbVar6) &&
             ((uVar3 == 0xfffffffd ||
              ((bVar10 = pbVar4[1] < pbVar6[1], pbVar4[1] == pbVar6[1] &&
               ((uVar3 == 0xfffffffe ||
                ((bVar10 = pbVar4[2] < pbVar6[2], pbVar4[2] == pbVar6[2] &&
                 ((uVar3 == 0xffffffff || (bVar10 = pbVar4[3] < pbVar6[3], pbVar4[3] == pbVar6[3])))
                 ))))))))) goto LAB_006327ba;
          uVar7 = -(uint)bVar10 | 1;
        }
        if (uVar7 == 0) {
LAB_006327fb:
          iStack_18 = -1;
          if (*(int *)(param_3 + 0x10) - uStack_10 != -1) {
            iStack_18 = *(int *)(param_3 + 0x10) - uStack_10;
          }
          pbStack_1c = pbStack_c + uStack_10;
          cVar2 = (char)iVar8 * '\x02';
          cVar5 = FUN_01683990(pbStack_1c,iStack_18,10,&uStack_14);
          if (cVar5 == '\0') {
            param_3 = (byte *)CONCAT31(param_3._1_3_,cVar2);
            FUN_006ad5e0(&param_3,1);
            FUN_006ad240(&pbStack_1c,param_2);
            return;
          }
          param_3 = (byte *)(CONCAT31(param_3._1_3_,cVar2) | 1);
          FUN_006ad5e0(&param_3,1);
          FUN_006ad310(uStack_14,uStack_10,param_2);
          return;
        }
      }
      iVar8 = iVar8 + -1;
      pbVar9 = pbVar9 + -0x18;
    } while (0 < iVar8);
  }
  auStack_8[0] = 0;
  pbStack_1c = pbStack_c;
  FUN_006ad5e0(auStack_8,1);
  FUN_006ad360(param_3,param_2);
  return;
}



/* FUNCTION 6977 ; VA 0x00632880 ; FUN_00632880 */

void __thiscall
FUN_00632880(int param_1,undefined4 param_2,uint param_3,undefined4 param_4,ushort param_5)

{
  undefined auStack_6c [8];
  undefined4 uStack_64;
  undefined4 uStack_54;
  char acStack_44 [4];
  undefined auStack_40 [24];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f3e8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x1dc4) != 0) {
    ExceptionList = &pvStack_10;
    FUN_006ab530();
    uStack_8 = 0;
    FUN_006ae570(param_3);
    FUN_006b92d0(auStack_6c,param_4);
    param_3 = (uint)param_5;
    FUN_006a5c10(&param_3,&param_5,2);
    FUN_006ad5e0(&param_5,2);
    FUN_00686ed0(acStack_44,uStack_64,uStack_54);
    uStack_8._0_1_ = 1;
    if (acStack_44[0] == '\0') {
      if (DAT_01eae4ae != '\0') {
        FUN_016774b0(DAT_01eae4ae,"SessionCrypto could not create tag for protected hash",0);
      }
      FUN_0054eff0("SessionCrypto-NoProHashTag");
      uStack_8._0_1_ = 2;
      FUN_008783f0(auStack_28,1,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_005507b0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("SessionCrypto could not create tag for protected hash");
    }
    FUN_006ad360(auStack_40,param_2);
    thunk_FUN_0056ca60();
    FUN_00613200();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6978 ; VA 0x006329a0 ; FUN_006329a0 */

void FUN_006329a0(undefined4 param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined auStack_14 [16];
  
  FUN_00a33fb0(auStack_14);
  FUN_006ad5e0(auStack_14,0x10);
  piVar1 = *(int **)(param_3 + 4);
  if (*(int **)(param_3 + 8) != piVar1) {
    iVar2 = *param_2;
    *piVar1 = iVar2;
    LOCK();
    piVar1 = (int *)(iVar2 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 4;
    return;
  }
  FUN_00602fc0(piVar1,param_2);
  return;
}



/* FUNCTION 6979 ; VA 0x006329f0 ; FUN_006329f0 */

void FUN_006329f0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}



/* FUNCTION 6980 ; VA 0x00632a10 ; FUN_00632a10 */

undefined * __thiscall FUN_00632a10(undefined *param_1,char *param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char *pcVar5;
  
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar5 = param_2;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_2,(int)pcVar5 - (int)(param_2 + 1));
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  uVar2 = param_3[1];
  uVar3 = param_3[2];
  uVar4 = param_3[3];
  *(undefined4 *)(param_1 + 0x18) = *param_3;
  *(undefined4 *)(param_1 + 0x1c) = uVar2;
  *(undefined4 *)(param_1 + 0x20) = uVar3;
  *(undefined4 *)(param_1 + 0x24) = uVar4;
  *(undefined8 *)(param_1 + 0x28) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  return param_1;
}



/* FUNCTION 6981 ; VA 0x00632a90 ; FUN_00632a90 */

undefined4 * __thiscall FUN_00632a90(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017924bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  uStack_8 = 0;
  puVar4 = (undefined4 *)FUN_00632b30(param_2);
  uVar2 = param_1[1];
  param_1[1] = *puVar4;
  *puVar4 = uVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  _guard_check_icall(param_1,param_2,param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6982 ; VA 0x00632b30 ; FUN_00632b30 */

undefined4 * __thiscall FUN_00632b30(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f400;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::sp_counted_impl_p<struct_boost::filesystem::detail::dir_itr_imp>::
              vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6983 ; VA 0x00632ba5 ; Catch_All@00632ba5 */

void Catch_All_00632ba5(void)

{
  int unaff_EBP;
  
  FUN_00634120(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6984 ; VA 0x00632bc0 ; FUN_00632bc0 */

undefined4 * __thiscall FUN_00632bc0(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = FUN_0088da50();
  *param_1 = uVar2;
  iVar3 = FUN_005c9e80();
  iVar1 = param_1[1];
  if (iVar1 == iVar3) {
    param_1[2] = *param_2;
    param_1[3] = param_2[1];
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  param_1[1] = iVar3;
  return param_1;
}



/* FUNCTION 6985 ; VA 0x00632c30 ; FUN_00632c30 */

int * __thiscall FUN_00632c30(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = FUN_005c9d30();
  iVar1 = *param_1;
  if (iVar1 == iVar4) {
    if (param_1 + 1 != param_2) {
      FUN_005507b0();
      iVar1 = param_2[1];
      iVar4 = param_2[2];
      iVar2 = param_2[3];
      param_1[1] = *param_2;
      param_1[2] = iVar1;
      param_1[3] = iVar4;
      param_1[4] = iVar2;
      *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 4);
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
    }
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[5] = 0;
  param_1[6] = 0;
  iVar1 = param_2[1];
  iVar2 = param_2[2];
  iVar3 = param_2[3];
  param_1[1] = *param_2;
  param_1[2] = iVar1;
  param_1[3] = iVar2;
  param_1[4] = iVar3;
  *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  *param_1 = iVar4;
  return param_1;
}



/* FUNCTION 6986 ; VA 0x00632ce0 ; FUN_00632ce0 */

undefined4 * __thiscall FUN_00632ce0(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  
  uVar4 = FUN_0088cb40();
  *param_1 = uVar4;
  iVar5 = FUN_005c9d30();
  iVar1 = param_1[1];
  if (iVar1 == iVar5) {
    if (param_1 + 2 != param_2) {
      FUN_005507b0();
      uVar4 = param_2[1];
      uVar2 = param_2[2];
      uVar3 = param_2[3];
      param_1[2] = *param_2;
      param_1[3] = uVar4;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 4);
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
    }
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[6] = 0;
  param_1[7] = 0;
  uVar4 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  param_1[2] = *param_2;
  param_1[3] = uVar4;
  param_1[4] = uVar2;
  param_1[5] = uVar3;
  *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  param_1[1] = iVar5;
  return param_1;
}



/* FUNCTION 6987 ; VA 0x00632d90 ; FUN_00632d90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00632d90(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  
  uVar5 = FUN_0088cf00();
  iVar4 = _tls_index;
  *param_1 = uVar5;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar4 * 4) + 0x34) < DAT_01ead2d8) {
    FUN_016f3809(&DAT_01ead2d8);
    if (DAT_01ead2d8 == -1) {
      _DAT_01ead2cc = FUN_005c65f0;
      _DAT_01ead2d0 = FUN_005c93a0;
      _DAT_01ead2d4 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ead2d8);
    }
  }
  puVar1 = (undefined *)param_1[1];
  if (puVar1 == &DAT_01ead2cc) {
    if (param_1 + 2 != param_2) {
      FUN_005507b0();
      uVar5 = param_2[1];
      uVar2 = param_2[2];
      uVar3 = param_2[3];
      param_1[2] = *param_2;
      param_1[3] = uVar5;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 4);
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
    }
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[6] = 0;
  param_1[7] = 0;
  uVar5 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  param_1[2] = *param_2;
  param_1[3] = uVar5;
  param_1[4] = uVar2;
  param_1[5] = uVar3;
  *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  param_1[1] = &DAT_01ead2cc;
  return param_1;
}



/* FUNCTION 6988 ; VA 0x00632eb0 ; FUN_00632eb0 */

int * __thiscall FUN_00632eb0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_005c9e80();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    param_1[2] = param_2[1];
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  param_1[2] = param_2[1];
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 6989 ; VA 0x00632f10 ; FUN_00632f10 */

uint FUN_00632f10(int param_1,int param_2)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x18);
  if ((uVar1 == *(uint *)(param_2 + 0x18)) &&
     (uVar1 = *(uint *)(param_1 + 0x1c), uVar1 == *(uint *)(param_2 + 0x1c))) {
    return uVar1 & 0xffffff00;
  }
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 6990 ; VA 0x00632f40 ; FUN_00632f40 */

undefined4 * __thiscall
FUN_00632f40(undefined4 *param_1,undefined4 *param_2,char *param_3,char *param_4)

{
  char *pcVar1;
  char *pcVar2;
  char *pcVar3;
  
  if (param_3 != param_4) {
    pcVar1 = (char *)param_1[1];
    do {
      pcVar2 = (char *)*param_1;
      pcVar3 = param_3;
      if ((char *)*param_1 == pcVar1) break;
      for (; pcVar3 != param_4; pcVar3 = pcVar3 + 1) {
        if (pcVar2 == pcVar1) goto LAB_00632f9d;
        if (*pcVar3 != *pcVar2) break;
        pcVar2 = pcVar2 + 1;
      }
      if (pcVar2 == pcVar1) {
LAB_00632f9d:
        *param_2 = param_3;
        param_2[1] = pcVar3;
        return param_2;
      }
      param_3 = param_3 + 1;
    } while (param_3 != param_4);
  }
  *param_2 = param_4;
  param_2[1] = param_4;
  return param_2;
}



/* FUNCTION 6991 ; VA 0x00632fb0 ; FUN_00632fb0 */

void FUN_00632fb0(int *param_1,int param_2,undefined4 param_3,undefined *param_4,undefined *param_5,
                 undefined *param_6)

{
  int *piVar1;
  int iVar2;
  undefined *puVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined *puVar6;
  int iVar7;
  undefined *puVar8;
  
  puVar6 = param_5;
  iVar2 = param_2;
  iVar7 = *(int *)(param_2 + 0x10);
  puVar8 = param_4;
  if (iVar7 != 0) {
    do {
      if (puVar8 == puVar6) break;
      puVar3 = (undefined *)FUN_0063adb0();
      *puVar8 = *puVar3;
      piVar1 = (int *)(iVar2 + 0x10);
      *piVar1 = *piVar1 + -1;
      if (*piVar1 == 0) {
        *(undefined4 *)(iVar2 + 0xc) = 0;
      }
      else {
        *(int *)(iVar2 + 0xc) = *(int *)(iVar2 + 0xc) + 1;
      }
      iVar7 = *(int *)(iVar2 + 0x10);
      puVar8 = puVar8 + 1;
    } while (iVar7 != 0);
    if (iVar7 != 0) {
      if (puVar8 != param_6) {
        uVar4 = *(uint *)(iVar2 + 0xc);
        do {
          if (((*(int *)(iVar2 + 0x10) + uVar4 & 0xf) == 0) &&
             (*(uint *)(iVar2 + 8) <= *(int *)(iVar2 + 0x10) + 0x10U >> 4)) {
            FUN_00638430(1);
            uVar4 = *(uint *)(iVar2 + 0xc);
          }
          uVar4 = *(int *)(iVar2 + 8) * 0x10 - 1U & uVar4;
          *(uint *)(iVar2 + 0xc) = uVar4;
          uVar4 = *(int *)(iVar2 + 0x10) + uVar4;
          param_2 = (*(int *)(iVar2 + 8) - 1U & uVar4 >> 4) * 4;
          iVar7 = *(int *)(iVar2 + 4);
          if (*(int *)(iVar7 + param_2) == 0) {
            uVar5 = FUN_01674e20(0x10);
            *(undefined4 *)(param_2 + *(int *)(iVar2 + 4)) = uVar5;
            iVar7 = *(int *)(iVar2 + 4);
          }
          *(undefined *)((uVar4 & 0xf) + *(int *)(param_2 + iVar7)) = *puVar8;
          *(int *)(iVar2 + 0x10) = *(int *)(iVar2 + 0x10) + 1;
          puVar6 = (undefined *)FUN_0063adb0();
          *puVar8 = *puVar6;
          piVar1 = (int *)(iVar2 + 0x10);
          *piVar1 = *piVar1 + -1;
          if (*piVar1 == 0) {
            *(undefined4 *)(iVar2 + 0xc) = 0;
            uVar4 = 0;
          }
          else {
            *(int *)(iVar2 + 0xc) = *(int *)(iVar2 + 0xc) + 1;
            uVar4 = *(uint *)(iVar2 + 0xc);
          }
          puVar8 = puVar8 + 1;
        } while (puVar8 != param_6);
      }
      *param_1 = (int)puVar8;
      return;
    }
  }
  puVar6 = param_5;
  if (puVar8 == param_5) {
    *param_1 = (int)param_6;
    return;
  }
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar7 = (int)param_6 - (int)puVar6;
  FUN_0170cc70(puVar8,puVar6,iVar7);
  *param_1 = (int)(puVar8 + iVar7);
  return;
}



/* FUNCTION 6992 ; VA 0x00633130 ; thunk_FUN_00b9e640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b9e640(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb600;
  pvStack_10 = ExceptionList;
  if (DAT_01ef2774 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2988) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef2988);
      if (DAT_01ef2988 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Folder",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ef2980 = RBX::Creator<class_RBX::Folder>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef2778,&DAT_01ef2980);
        FUN_016f3654(FUN_018913c0);
        FUN_016f37bf(&DAT_01ef2988);
      }
    }
    DAT_01ef2774 = &DAT_01ef2778;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef2774;
}



/* FUNCTION 6993 ; VA 0x00633180 ; FUN_00633180 */

void __thiscall FUN_00633180(uint *param_1,int param_2,uint param_3,undefined4 param_4,uint param_5)

{
  undefined uVar1;
  uint uVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f410;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  while( true ) {
    while( true ) {
      if (param_3 == param_5) {
        ExceptionList = pvStack_10;
        return;
      }
      uVar7 = param_1[4];
      uVar2 = param_1[5];
      uVar1 = *(undefined *)
               ((param_3 & 0xf) +
               *(int *)(*(int *)(param_2 + 4) + (*(int *)(param_2 + 8) - 1U & param_3 >> 4) * 4));
      if (uVar2 <= uVar7) break;
      param_1[4] = uVar7 + 1;
      puVar3 = param_1;
      if (0xf < uVar2) {
        puVar3 = (uint *)*param_1;
      }
      *(undefined *)((int)puVar3 + uVar7) = uVar1;
      *(undefined *)((int)puVar3 + uVar7 + 1) = 0;
      param_3 = param_3 + 1;
    }
    if (uVar7 == 0x7fffffff) break;
    uVar6 = uVar7 + 1 | 0xf;
    if (uVar6 < 0x80000000) {
      if (0x7fffffff - (uVar2 >> 1) < uVar2) {
        uVar6 = 0x7fffffff;
      }
      else {
        uVar8 = (uVar2 >> 1) + uVar2;
        if (uVar6 < uVar8) {
          uVar6 = uVar8;
        }
      }
    }
    else {
      uVar6 = 0x7fffffff;
    }
    uVar8 = uVar6 + 1;
    if (uVar8 < 0x1000) {
      if (uVar8 == 0) {
        uVar8 = 0;
      }
      else {
        uVar8 = FUN_01674e20(uVar8);
      }
    }
    else {
      uVar4 = uVar6 + 0x24;
      if (uVar4 <= uVar8) {
        uVar4 = 0xffffffff;
      }
      iVar5 = FUN_01674e20(uVar4);
      if (iVar5 == 0) goto LAB_00633334;
      uVar8 = iVar5 + 0x23U & 0xffffffe0;
      *(int *)(uVar8 - 4) = iVar5;
    }
    param_1[4] = uVar7 + 1;
    param_1[5] = uVar6;
    if (uVar2 < 0x10) {
      FUN_0170c6f0(uVar8,param_1,uVar7);
      *(undefined *)(uVar8 + uVar7) = uVar1;
      *(undefined *)(uVar8 + 1 + uVar7) = 0;
      *param_1 = uVar8;
      param_3 = param_3 + 1;
    }
    else {
      uVar6 = *param_1;
      FUN_0170c6f0(uVar8,uVar6,uVar7);
      *(undefined *)(uVar8 + uVar7) = uVar1;
      uVar4 = uVar2 + 1;
      *(undefined *)(uVar8 + 1 + uVar7) = 0;
      uVar7 = uVar6;
      if (0xfff < uVar4) {
        uVar7 = *(uint *)(uVar6 - 4);
        uVar4 = uVar2 + 0x24;
        if (0x1f < (uVar6 - uVar7) - 4) goto LAB_00633334;
      }
      FUN_01674ea0(uVar7,uVar4);
      *param_1 = uVar8;
      param_3 = param_3 + 1;
    }
  }
  FUN_00554040();
LAB_00633334:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 6994 ; VA 0x00633339 ; Catch_All@00633339 */

void Catch_All_00633339(void)

{
  FUN_005507b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6995 ; VA 0x00633350 ; FUN_00633350 */

void FUN_00633350(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_1 != param_2) {
    do {
      iVar3 = *param_1;
      if (iVar3 != 0) {
        piVar1 = (int *)(iVar3 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(iVar3);
        }
      }
      param_1 = param_1 + 1;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 6996 ; VA 0x00633390 ; FUN_00633390 */

int __thiscall FUN_00633390(int *param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f420;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0x18;
  if (iVar2 == 0xaaaaaaa) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0x18;
  uVar6 = uVar1;
  if ((uVar3 <= 0xaaaaaaa - (uVar3 >> 1)) && (uVar6 = (uVar3 >> 1) + uVar3, uVar6 < uVar1)) {
    uVar6 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00577fb0(uVar6);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0x18) * 0x18;
  FUN_0054f050(param_3);
  if (param_2 == param_1[1]) {
    FUN_0058ec90(*param_1,param_1[1],iVar4);
  }
  else {
    FUN_0058d5c0(*param_1,param_2,iVar4);
    FUN_0058d5c0(param_2,param_1[1],iVar5 + iVar4 + 0x18);
  }
  FUN_0058ea60(iVar4,iVar2 + 1,uVar6);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 6997 ; VA 0x006334c7 ; Catch_All@006334c7 */

void Catch_All_006334c7(void)

{
  int unaff_EBP;
  
  FUN_0058eb20(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_0057d2f0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6998 ; VA 0x00633500 ; FUN_00633500 */

int __thiscall FUN_00633500(int *param_1,int param_2,undefined4 *param_3,undefined8 *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  
  iVar9 = *param_1;
  iVar6 = param_1[1] - iVar9 >> 5;
  if (iVar6 == 0x7ffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar8 = param_1[2] - iVar9 >> 5;
  uVar10 = uVar1;
  if ((uVar8 <= 0x7ffffff - (uVar8 >> 1)) && (uVar10 = (uVar8 >> 1) + uVar8, uVar10 < uVar1)) {
    uVar10 = uVar1;
  }
  iVar7 = FUN_00577f40(uVar10);
  uVar8 = param_2 - iVar9 & 0xffffffe0;
  *(undefined4 *)(uVar8 + 0x10 + iVar7) = 0;
  *(undefined4 *)(uVar8 + 0x14 + iVar7) = 0;
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  puVar2 = (undefined4 *)(uVar8 + iVar7);
  *puVar2 = *param_3;
  puVar2[1] = uVar3;
  puVar2[2] = uVar4;
  puVar2[3] = uVar5;
  *(undefined8 *)(uVar8 + 0x10 + iVar7) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  iVar9 = *param_1;
  *(undefined8 *)(uVar8 + 0x18 + iVar7) = *param_4;
  iVar6 = iVar7;
  if (param_2 != param_1[1]) {
    FUN_0055c650(iVar9,param_2,iVar7,param_1);
    iVar6 = iVar7 + 0x20 + uVar8;
    iVar9 = param_2;
  }
  FUN_0055c650(iVar9,param_1[1],iVar6,param_1);
  FUN_00575c60(iVar7,uVar1,uVar10);
  return *param_1 + uVar8;
}



/* FUNCTION 6999 ; VA 0x006335f0 ; FUN_006335f0 */

int __thiscall FUN_006335f0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  
  iVar7 = *param_1;
  iVar3 = (int)param_2 - iVar7 >> 2;
  iVar4 = param_1[1] - iVar7 >> 2;
  if (iVar4 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar8 = param_1[2] - iVar7 >> 2;
  uVar5 = uVar1;
  if ((uVar8 <= 0x3fffffff - (uVar8 >> 1)) && (uVar5 = (uVar8 >> 1) + uVar8, uVar5 < uVar1)) {
    uVar5 = uVar1;
  }
  uVar8 = uVar5 * 4;
  if (uVar5 < 0x40000000) {
    if (0xfff < uVar8) goto LAB_00633664;
    if (uVar8 == 0) {
      puVar11 = (undefined4 *)0x0;
    }
    else {
      puVar11 = (undefined4 *)FUN_01674e20(uVar8);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_00633664:
    uVar6 = uVar8 + 0x23;
    if (uVar6 <= uVar8) {
      uVar6 = 0xffffffff;
    }
    iVar7 = FUN_01674e20(uVar6);
    if (iVar7 == 0) goto LAB_006337b1;
    puVar11 = (undefined4 *)(iVar7 + 0x23U & 0xffffffe0);
    puVar11[-1] = iVar7;
  }
  puVar11[iVar3] = *param_3;
  *param_3 = 0;
  puVar2 = (undefined4 *)param_1[1];
  puVar9 = (undefined4 *)*param_1;
  puVar10 = puVar11;
  if (param_2 == puVar2) {
    for (; puVar9 != puVar2; puVar9 = puVar9 + 1) {
      *puVar10 = *puVar9;
      *puVar9 = 0;
      puVar10 = puVar10 + 1;
    }
  }
  else {
    for (; puVar9 != param_2; puVar9 = puVar9 + 1) {
      *puVar10 = *puVar9;
      *puVar9 = 0;
      puVar10 = puVar10 + 1;
    }
    FUN_00633350(puVar10,puVar10,param_1);
    puVar2 = (undefined4 *)param_1[1];
    puVar10 = puVar11 + iVar3 + 1;
    if (param_2 != puVar2) {
      param_2 = (undefined4 *)((int)param_2 + (int)puVar10 + (iVar3 * -4 - (int)puVar11) + -4);
      do {
        *puVar10 = *param_2;
        puVar10 = puVar10 + 1;
        *param_2 = 0;
        param_2 = param_2 + 1;
      } while (param_2 != puVar2);
    }
  }
  FUN_00633350(puVar10,puVar10,param_1);
  if (*param_1 != 0) {
    FUN_00633350(*param_1,param_1[1],param_1);
    iVar7 = *param_1;
    uVar8 = param_1[2] - iVar7 & 0xfffffffc;
    iVar4 = iVar7;
    if (0xfff < uVar8) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar7 - iVar4) - 4U) {
LAB_006337b1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar8);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1);
  param_1[2] = (int)(puVar11 + uVar5);
  return *param_1 + iVar3 * 4;
}


