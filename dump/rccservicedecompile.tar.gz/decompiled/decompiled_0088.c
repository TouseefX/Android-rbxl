/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 22000 ; VA 0x00aab530 ; FUN_00aab530 */

uint FUN_00aab530(int param_1,int *param_2,uint param_3,int param_4,uint param_5,uint param_6)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  int *piStack_8;
  
  piStack_8 = param_2;
  uVar8 = *(uint *)(param_1 + 0xf4);
  iVar2 = 1 << ((byte)*(undefined4 *)(param_1 + 0x90) & 0x1f);
  if (*(int *)(param_1 + 0xb0) != 0) {
    if (param_5 == 0) goto LAB_00aab7e8;
    FUN_00ab2bb0(param_1 + 0x108,param_4,param_5);
  }
  if (param_5 != 0) {
    do {
      uVar3 = param_5 <= uVar8 & param_6;
      if (param_3 < 6) {
        return 0xffffffba;
      }
      uVar6 = *(uint *)(param_1 + 0x10);
      uVar4 = param_5;
      if (uVar8 <= param_5) {
        uVar4 = uVar8;
      }
      if (0x60000000 < uVar6) {
        uVar8 = param_4 - *(int *)(param_1 + 4);
        uVar7 = 0;
        uVar8 = ((-1 << ((byte)*(undefined4 *)(param_1 + 0x90) & 0x1f)) -
                ((1 << ((char)*(undefined4 *)(param_1 + 0x94) -
                        ('\x01' - (*(uint *)(param_1 + 0xa8) < 6)) & 0x1fU)) - 1U & uVar8)) + uVar8;
        uVar6 = 1 << ((byte)*(undefined4 *)(param_1 + 0x98) & 0x1f);
        iVar9 = *(int *)(param_1 + 0x210);
        if (uVar6 != 0) {
          do {
            uVar1 = *(uint *)(iVar9 + uVar7 * 4);
            iVar5 = 0;
            if (uVar8 <= uVar1) {
              iVar5 = uVar1 - uVar8;
            }
            *(int *)(iVar9 + uVar7 * 4) = iVar5;
            uVar7 = uVar7 + 1;
          } while (uVar7 < uVar6);
        }
        if (*(int *)(param_1 + 0xa8) == 1) {
          uVar6 = 0;
        }
        else {
          uVar6 = 1 << ((byte)*(undefined4 *)(param_1 + 0x94) & 0x1f);
        }
        iVar9 = *(int *)(param_1 + 0x218);
        uVar7 = 0;
        if (uVar6 != 0) {
          do {
            uVar1 = *(uint *)(iVar9 + uVar7 * 4);
            iVar5 = 0;
            if (uVar8 <= uVar1) {
              iVar5 = uVar1 - uVar8;
            }
            *(int *)(iVar9 + uVar7 * 4) = iVar5;
            uVar7 = uVar7 + 1;
          } while (uVar7 < uVar6);
        }
        uVar7 = 0;
        uVar6 = -(uint)(*(int *)(param_1 + 0x1c) != 0) &
                1 << ((byte)*(int *)(param_1 + 0x1c) & 0x1f);
        iVar9 = *(int *)(param_1 + 0x214);
        if (uVar6 != 0) {
          do {
            uVar1 = *(uint *)(iVar9 + uVar7 * 4);
            iVar5 = 0;
            if (uVar8 <= uVar1) {
              iVar5 = uVar1 - uVar8;
            }
            *(int *)(iVar9 + uVar7 * 4) = iVar5;
            uVar7 = uVar7 + 1;
          } while (uVar7 < uVar6);
        }
        if (*(int *)(param_1 + 0xcc) != 0) {
          uVar6 = 1 << ((byte)*(undefined4 *)(param_1 + 0xd0) & 0x1f);
          uVar7 = 0;
          iVar9 = *(int *)(param_1 + 0x200);
          if (uVar6 != 0) {
            do {
              uVar1 = *(uint *)(iVar9 + uVar7 * 8);
              iVar5 = 0;
              if (uVar8 <= uVar1) {
                iVar5 = uVar1 - uVar8;
              }
              *(int *)(iVar9 + uVar7 * 8) = iVar5;
              uVar7 = uVar7 + 1;
            } while (uVar7 < uVar6);
          }
        }
        *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + uVar8;
        uVar6 = *(int *)(param_1 + 0x10) - uVar8;
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar8;
        *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) - uVar8;
        *(uint *)(param_1 + 0x10) = uVar6;
        if (*(uint *)(param_1 + 0x14) < uVar8) {
          *(undefined4 *)(param_1 + 0x14) = 0;
        }
        else {
          *(uint *)(param_1 + 0x14) = *(uint *)(param_1 + 0x14) - uVar8;
        }
      }
      iVar9 = param_4 - *(int *)(param_1 + 4);
      if ((uint)(*(int *)(param_1 + 0x20) + iVar2) < iVar9 + uVar4) {
        uVar8 = (iVar9 - iVar2) + uVar4;
        if (uVar6 < uVar8) {
          *(uint *)(param_1 + 0x10) = uVar8;
          uVar6 = uVar8;
        }
        if (*(uint *)(param_1 + 0xc) < uVar6) {
          *(uint *)(param_1 + 0xc) = uVar6;
        }
      }
      uVar8 = FUN_00aaa440(param_1,(int)piStack_8 + 3,param_3 - 3,param_4,uVar4);
      if (0xffffff88 < uVar8) {
        return uVar8;
      }
      if (uVar8 == 0) {
        uVar8 = uVar4 + 3;
        if (param_3 < uVar8) {
          return 0xffffffba;
        }
        *piStack_8 = uVar3 + uVar4 * 8;
        FUN_0170c6f0((int)piStack_8 + 3,param_4,uVar4);
      }
      else {
        iVar9 = uVar3 + uVar8 * 8 + 4;
        *(short *)piStack_8 = (short)iVar9;
        uVar8 = uVar8 + 3;
        *(char *)((int)piStack_8 + 2) = (char)((uint)iVar9 >> 0x10);
      }
      piStack_8 = (int *)((int)piStack_8 + uVar8);
      param_3 = param_3 - uVar8;
      param_5 = param_5 - uVar4;
      param_4 = param_4 + uVar4;
      uVar8 = uVar4;
    } while (param_5 != 0);
  }
LAB_00aab7e8:
  if ((param_6 != 0) && (param_2 < piStack_8)) {
    *(undefined4 *)(param_1 + 0x24) = 3;
  }
  return (int)piStack_8 - (int)param_2;
}



/* FUNCTION 22001 ; VA 0x00aab820 ; FUN_00aab820 */

void FUN_00aab820(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,int *param_6,uint param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined auStack_64 [96];
  
  puVar1 = (undefined4 *)
           FUN_00aa9320(auStack_64,*(undefined4 *)(param_1 + 0x2c),*(undefined4 *)(param_1 + 0x30),
                        *(undefined4 *)(param_1 + 0x34),*(undefined4 *)(param_1 + 0x38),
                        *(undefined4 *)(param_1 + 0x3c),*(undefined4 *)(param_1 + 0x40),
                        *(undefined4 *)(param_1 + 0x44),*(undefined4 *)(param_1 + 0x48),
                        *(undefined4 *)(param_1 + 0x4c),*(undefined4 *)(param_1 + 0x50),
                        *(undefined4 *)(param_1 + 0x54),*(undefined4 *)(param_1 + 0x58),
                        *(undefined4 *)(param_1 + 0x5c),*(undefined4 *)(param_1 + 0x60),
                        *(undefined4 *)(param_1 + 100),*(undefined4 *)(param_1 + 0x68),
                        *(undefined4 *)(param_1 + 0x6c),*(undefined4 *)(param_1 + 0x70),
                        *(undefined4 *)(param_1 + 0x74),*(undefined4 *)(param_1 + 0x78),
                        *(undefined4 *)(param_1 + 0x7c),*(undefined4 *)(param_1 + 0x80),
                        *(undefined4 *)(param_1 + 0x84),*(undefined4 *)(param_1 + 0x88),param_8,
                        param_9,param_10,param_11,param_12,param_13,param_14,param_15,param_16);
  uVar2 = FUN_00aaf580(param_1,*puVar1,puVar1[1],puVar1[2],puVar1[3],puVar1[4],puVar1[5],puVar1[6],
                       puVar1[7],puVar1[8],puVar1[9],puVar1[10],puVar1[0xb],puVar1[0xc],puVar1[0xd],
                       puVar1[0xe],puVar1[0xf],puVar1[0x10],puVar1[0x11],puVar1[0x12],puVar1[0x13],
                       puVar1[0x14],puVar1[0x15],puVar1[0x16],puVar1[0x17],param_5,0,0,0);
  if (uVar2 < 0xffffff89) {
    if ((param_6 == (int *)0x0) || (param_7 < 9)) {
      uVar2 = 0;
    }
    else if (*param_6 == -0x13cf5bc9) {
      uVar2 = FUN_00aaedd0(param_1,param_6,param_7);
    }
    else {
      uVar2 = FUN_00aaeb10();
    }
    if (uVar2 < 0xffffff89) {
      FUN_00abce40(param_1,param_2,param_3,param_4,param_5);
    }
  }
  return;
}



/* FUNCTION 22002 ; VA 0x00aab930 ; FUN_00aab930 */

uint FUN_00aab930(int param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  
  uVar1 = FUN_00aade90(param_1 + 0x5c40,param_2,param_3,*(undefined4 *)(param_1 + 0x5ce0));
  if (uVar1 < 0xffffff89) {
    if (uVar1 != 0) {
      return 0xffffffb8;
    }
    if ((*(int *)(param_1 + 0x5c5c) != 0) &&
       (*(int *)(param_1 + 0x5cdc) != *(int *)(param_1 + 0x5c5c))) {
      return 0xffffffe0;
    }
    if (*(int *)(param_1 + 0x5c60) != 0) {
      FUN_00ab2b00(param_1 + 0x5c80,0,0);
    }
    uVar1 = 0;
  }
  return uVar1;
}



/* FUNCTION 22003 ; VA 0x00aab9a0 ; FUN_00aab9a0 */

uint FUN_00aab9a0(int param_1,uint *param_2,uint param_3)

{
  int iVar1;
  byte bVar2;
  char cVar3;
  byte bVar4;
  uint uVar5;
  uint uVar6;
  byte bVar7;
  int iVar8;
  bool bVar9;
  uint uStack_8;
  
  uVar5 = param_3;
  if (param_3 < 3) {
    return 0xffffffec;
  }
  bVar2 = *(byte *)param_2;
  bVar4 = bVar2 & 3;
  switch(bVar4) {
  case 1:
    bVar4 = bVar2 >> 2 & 3;
    if (bVar4 == 1) {
      iVar8 = 2;
      param_3 = 2;
      uVar6 = (uint)(*(ushort *)param_2 >> 4);
    }
    else if (bVar4 == 3) {
      param_3 = 3;
      uVar6 = (uint)(*(uint3 *)param_2 >> 4);
      if (uVar5 < 4) {
        return 0xffffffec;
      }
      iVar8 = 3;
    }
    else {
      iVar8 = 1;
      uVar6 = (uint)(bVar2 >> 3);
      param_3 = 1;
    }
    if (uVar6 < 0x20001) {
      FUN_0170d1f0(param_1 + 0x5d40,*(byte *)(iVar8 + (int)param_2),uVar6 + 8);
      *(int *)(param_1 + 0x5ce4) = param_1 + 0x5d40;
      *(uint *)(param_1 + 0x5cf4) = uVar6;
      return param_3 + 1;
    }
    return 0xffffffec;
  case 3:
    if (*(int *)(param_1 + 0x5c78) == 0) {
      return 0xffffffe2;
    }
  case 2:
    if (param_3 < 5) {
      return 0xffffffec;
    }
    uVar5 = *param_2;
    bVar7 = bVar2 >> 2 & 3;
    bVar9 = false;
    if (bVar7 == 2) {
      iVar8 = 4;
      uVar6 = uVar5 >> 0x12;
      uStack_8 = 0x3fff;
    }
    else if (bVar7 == 3) {
      iVar8 = 5;
      uVar6 = (uVar5 >> 0x16) + (uint)*(byte *)(param_2 + 1) * 0x400;
      uStack_8 = 0x3ffff;
    }
    else {
      uStack_8 = 0x3ff;
      bVar9 = (bVar2 >> 2 & 3) == 0;
      iVar8 = 3;
      uVar6 = uVar5 >> 0xe & 0x3ff;
    }
    uStack_8 = uVar5 >> 4 & uStack_8;
    if (0x20000 < uStack_8) {
      return 0xffffffec;
    }
    if (param_3 < uVar6 + iVar8) {
      return 0xffffffec;
    }
    iVar1 = param_1 + 0x5d40;
    if (bVar4 == 3) {
      cVar3 = (char)((uint)**(undefined4 **)(param_1 + 0xc) >> 8);
      if (bVar9) {
        if (cVar3 == '\0') {
          uVar5 = FUN_00aa68a0();
        }
        else {
          uVar5 = FUN_00aa6a90();
        }
      }
      else if (cVar3 == '\0') {
        uVar5 = FUN_00aa6d00(iVar1,uStack_8,(byte *)((int)param_2 + iVar8),uVar6,
                             *(undefined4 **)(param_1 + 0xc));
      }
      else {
        uVar5 = FUN_00aa76b0();
      }
    }
    else if (bVar9) {
      uVar5 = FUN_00ab1df0();
    }
    else {
      uVar5 = FUN_00ab1ee0(param_1 + 0x141c,iVar1,uStack_8,(byte *)((int)param_2 + iVar8),uVar6,
                           param_1 + 0x5420,0x800);
    }
    if (0xffffff88 < uVar5) {
      return 0xffffffec;
    }
    *(int *)(param_1 + 0x5ce4) = iVar1;
    *(uint *)(param_1 + 0x5cf4) = uStack_8;
    *(undefined4 *)(param_1 + 0x5c78) = 1;
    if (bVar4 == 2) {
      *(int *)(param_1 + 0xc) = param_1 + 0x141c;
    }
    *(undefined8 *)(uStack_8 + 0x5d40 + param_1) = 0;
    return uVar6 + iVar8;
  }
  bVar4 = bVar2 >> 2 & 3;
  if (bVar4 == 1) {
    uVar5 = (uint)*(ushort *)param_2;
    iVar8 = 2;
  }
  else {
    if (bVar4 != 3) {
      iVar8 = 1;
      uVar5 = (uint)(bVar2 >> 3);
      goto LAB_00aabb7e;
    }
    iVar8 = 3;
    uVar5 = (uint)*(uint3 *)param_2;
  }
  uVar5 = uVar5 >> 4;
LAB_00aabb7e:
  uVar6 = uVar5 + iVar8;
  if (uVar6 + 8 <= param_3) {
    *(byte **)(param_1 + 0x5ce4) = (byte *)(iVar8 + (int)param_2);
    *(uint *)(param_1 + 0x5cf4) = uVar5;
    return uVar6;
  }
  if (param_3 < uVar6) {
    return 0xffffffec;
  }
  FUN_0170c6f0(param_1 + 0x5d40,(byte *)(iVar8 + (int)param_2),uVar5);
  *(int *)(param_1 + 0x5ce4) = param_1 + 0x5d40;
  *(uint *)(param_1 + 0x5cf4) = uVar5;
  *(undefined8 *)(uVar5 + 0x5d40 + param_1) = 0;
  return uVar6;
}



/* FUNCTION 22004 ; VA 0x00aabc90 ; FUN_00aabc90 */

byte * FUN_00aabc90(int param_1,uint *param_2,byte *param_3,int param_4)

{
  ushort *puVar1;
  ushort *puVar2;
  byte bVar3;
  uint uVar4;
  ushort *puVar5;
  byte *pbVar6;
  
  puVar2 = (ushort *)(param_3 + param_4);
  if (param_4 == 0) {
    return (byte *)0xffffffb8;
  }
  uVar4 = (uint)*param_3;
  puVar1 = (ushort *)(param_3 + 1);
  if (uVar4 == 0) {
    *param_2 = 0;
    return (byte *)0x1;
  }
  puVar5 = puVar1;
  if (0x7f < uVar4) {
    if (uVar4 == 0xff) {
      puVar5 = (ushort *)(param_3 + 3);
      if (puVar2 < puVar5) {
        return (byte *)0xffffffb8;
      }
      uVar4 = *puVar1 + 0x7f00;
    }
    else {
      if (puVar2 <= puVar1) {
        return (byte *)0xffffffb8;
      }
      uVar4 = (uVar4 - 0x80) * 0x100 + (uint)*(byte *)puVar1;
      puVar5 = (ushort *)(param_3 + 2);
    }
  }
  *param_2 = uVar4;
  if (puVar2 < puVar5 + 2) {
    return (byte *)0xffffffb8;
  }
  bVar3 = *(byte *)puVar5;
  pbVar6 = (byte *)((int)puVar5 + 1);
  uVar4 = FUN_00aa94c0(param_1 + 0x10,param_1,bVar3 >> 6,0x23,9,pbVar6,(int)puVar2 - (int)pbVar6,
                       &DAT_019483d8,*(undefined4 *)(param_1 + 0x5c7c));
  if (uVar4 < 0xffffff89) {
    pbVar6 = pbVar6 + uVar4;
    uVar4 = FUN_00aa94c0(param_1 + 0x814,param_1 + 8,bVar3 >> 4 & 3,0x1f,8,pbVar6,
                         (int)puVar2 - (int)pbVar6,&DAT_019485e8,*(undefined4 *)(param_1 + 0x5c7c));
    if (uVar4 < 0xffffff89) {
      pbVar6 = pbVar6 + uVar4;
      uVar4 = FUN_00aa94c0(param_1 + 0xc18,param_1 + 4,bVar3 >> 2 & 3,0x34,9,pbVar6,
                           (int)puVar2 - (int)pbVar6,&DAT_019484e0,*(undefined4 *)(param_1 + 0x5c7c)
                          );
      if (uVar4 < 0xffffff89) {
        return pbVar6 + (uVar4 - (int)param_3);
      }
    }
  }
  return (byte *)0xffffffec;
}



/* FUNCTION 22005 ; VA 0x00aabde0 ; FUN_00aabde0 */

int * FUN_00aabde0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  
  uVar4 = *(uint *)(param_2[6] + param_2[5] * 4) >> 0x10 & 0xff;
  uVar6 = *(uint *)(param_2[10] + param_2[9] * 4) >> 0x10 & 0xff;
  uVar5 = *(uint *)(param_2[8] + param_2[7] * 4);
  iVar1 = *(int *)(&DAT_019476b0 + uVar4 * 4);
  uVar3 = uVar5 >> 0x10 & 0xff;
  iVar2 = *(int *)(&DAT_01947788 + uVar6 * 4);
  if (uVar3 == 0) {
    iVar7 = 0;
LAB_00aabeaf:
    iVar8 = iVar7 + (uint)(uVar4 == 0);
    if (iVar8 == 0) {
      iVar7 = param_2[0xb];
      goto LAB_00aabf1d;
    }
    if (iVar8 == 3) {
      iVar7 = param_2[0xb] + -1;
    }
    else {
      iVar7 = param_2[iVar8 + 0xb];
    }
    iVar7 = iVar7 + (uint)(iVar7 == 0);
    if (iVar8 != 1) {
      param_2[0xd] = param_2[0xc];
    }
    iVar8 = param_2[0xb];
    param_2[0xb] = iVar7;
  }
  else {
    iVar7 = *(int *)(&DAT_01948bd0 + uVar3 * 4);
    iVar8 = param_2[1];
    if (param_3 == 0) {
      param_2[1] = uVar3 + iVar8;
      iVar7 = ((uint)(*param_2 << ((byte)iVar8 & 0x1f)) >> (-(char)(uVar5 >> 0x10) & 0x1fU)) + iVar7
      ;
      FUN_00ab0260(param_2);
    }
    else {
      uVar5 = 0x18;
      if (uVar3 < 0x18) {
        uVar5 = uVar3;
      }
      iVar9 = uVar3 - uVar5;
      param_2[1] = iVar8 + uVar5;
      iVar7 = (((uint)(*param_2 << ((byte)iVar8 & 0x1f)) >> (-(char)uVar5 & 0x1fU)) <<
              ((byte)iVar9 & 0x1f)) + iVar7;
      FUN_00ab0260(param_2);
      if (iVar9 != 0) {
        iVar8 = param_2[1];
        param_2[1] = iVar8 + iVar9;
        iVar7 = iVar7 + ((uint)(*param_2 << ((byte)iVar8 & 0x1f)) >> (-(byte)iVar9 & 0x1f));
      }
    }
    if (uVar3 < 2) goto LAB_00aabeaf;
    param_2[0xd] = param_2[0xc];
    iVar8 = param_2[0xb];
    param_2[0xb] = iVar7;
  }
  param_2[0xc] = iVar8;
LAB_00aabf1d:
  param_1[2] = iVar7;
  if (uVar6 < 0x20) {
    uVar5 = 0;
  }
  else {
    iVar8 = param_2[1];
    param_2[1] = iVar8 + iVar2;
    uVar5 = (uint)(*param_2 << ((byte)iVar8 & 0x1f)) >> (-(char)iVar2 & 0x1fU);
  }
  param_1[1] = *(int *)(&DAT_01948af8 + uVar6 * 4) + uVar5;
  if (0x13 < (uint)(iVar2 + iVar1)) {
    FUN_00ab0260(param_2);
  }
  if (uVar4 < 0x10) {
    uVar5 = 0;
  }
  else {
    iVar2 = param_2[1];
    param_2[1] = iVar2 + iVar1;
    uVar5 = (uint)(*param_2 << ((byte)iVar2 & 0x1f)) >> (-(char)iVar1 & 0x1fU);
  }
  *param_1 = *(int *)(&DAT_01948a68 + uVar4 * 4) + uVar5;
  FUN_00ab0260(param_2);
  uVar5 = *(uint *)(param_2[6] + param_2[5] * 4);
  iVar1 = param_2[1];
  param_2[1] = (uVar5 >> 0x18) + iVar1;
  param_2[5] = (((uint)(*param_2 << ((byte)iVar1 & 0x1f)) >> 1) >> (~(byte)(uVar5 >> 0x18) & 0x1f))
               + (uVar5 & 0xffff);
  uVar5 = *(uint *)(param_2[10] + param_2[9] * 4);
  iVar1 = param_2[1];
  param_2[1] = (uVar5 >> 0x18) + iVar1;
  param_2[9] = (((uint)(*param_2 << ((byte)iVar1 & 0x1f)) >> 1) >> (~(byte)(uVar5 >> 0x18) & 0x1f))
               + (uVar5 & 0xffff);
  FUN_00ab0260(param_2);
  uVar5 = *(uint *)(param_2[8] + param_2[7] * 4);
  iVar1 = param_2[1];
  param_2[1] = (uVar5 >> 0x18) + iVar1;
  param_2[7] = (((uint)(*param_2 << ((byte)iVar1 & 0x1f)) >> 1) >> (~(byte)(uVar5 >> 0x18) & 0x1f))
               + (uVar5 & 0xffff);
  return param_1;
}



/* FUNCTION 22006 ; VA 0x00aac050 ; FUN_00aac050 */

uint FUN_00aac050(int param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 int param_6)

{
  uint uVar1;
  undefined4 uVar2;
  
  if (((param_6 == 0) || (*(int *)(param_1 + 0x5c4c) != 0)) ||
     (0x2000000 < *(uint *)(param_1 + 0x5c48))) {
    uVar2 = 1;
  }
  else {
    uVar2 = 0;
  }
  if (param_5 < 0x20000) {
    uVar1 = FUN_00aab9a0(param_1,param_4,param_5);
    if (uVar1 < 0xffffff89) {
      if ((param_6 != 0) &&
         ((*(int *)(param_1 + 0x5c4c) != 0 || (0x800000 < *(uint *)(param_1 + 0x5c48))))) {
        uVar1 = FUN_00aac9e0(param_1,param_2,param_3,param_4 + uVar1,param_5 - uVar1,uVar2);
        return uVar1;
      }
      uVar1 = FUN_00aac530(param_1,param_2,param_3,param_4 + uVar1,param_5 - uVar1,uVar2);
    }
    return uVar1;
  }
  return 0xffffffb8;
}



/* FUNCTION 22007 ; VA 0x00aac100 ; FUN_00aac100 */

uint FUN_00aac100(int param_1,int param_2,int param_3,int *param_4,uint *param_5)

{
  byte bVar1;
  uint3 uVar2;
  int iVar3;
  uint uVar4;
  uint3 uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint3 *puVar9;
  undefined *puVar10;
  
  iVar3 = param_3 + param_2;
  uVar8 = *param_5;
  iVar7 = *param_4;
  if (8 < uVar8) {
    bVar1 = *(byte *)(iVar7 + 4);
    if (((bVar1 & 0x20) == 0) || (param_3 = 6, bVar1 >> 6 != 0)) {
      param_3 = 5;
    }
    uVar6 = (uint)((bVar1 & 0x20) == 0) +
            *(int *)(&DAT_01947690 + (uint)(bVar1 >> 6) * 4) +
            *(int *)(&DAT_019476a0 + (bVar1 & 3) * 4) + param_3;
    if (0xffffff88 < uVar6) {
      return uVar6;
    }
    if (uVar6 + 3 <= uVar8) {
      uVar4 = FUN_00aab930(param_1,iVar7,uVar6);
      if (0xffffff88 < uVar4) {
        return uVar4;
      }
      puVar9 = (uint3 *)(iVar7 + uVar6);
      uVar8 = uVar8 - uVar6;
      iVar7 = param_2;
      while (2 < uVar8) {
        uVar2 = *puVar9;
        uVar5 = uVar2 >> 1 & 3;
        uVar6 = (uint)(uVar2 >> 3);
        if (uVar5 == 1) {
          uVar4 = 1;
        }
        else {
          uVar4 = uVar6;
          if (uVar5 == 3) {
            return 0xffffffec;
          }
        }
        puVar10 = (undefined *)((int)puVar9 + 3);
        if (uVar8 - 3 < uVar4) {
          return 0xffffffb8;
        }
        if ((uVar2 >> 1 & 3) == 0) {
          if ((uint)(iVar3 - iVar7) < uVar4) {
            return 0xffffffba;
          }
          FUN_0170c6f0(iVar7,puVar10,uVar4);
          uVar6 = uVar4;
        }
        else if (uVar5 == 1) {
          if ((uint)(iVar3 - iVar7) < uVar6) {
            return 0xffffffba;
          }
          FUN_0170d1f0(iVar7,*puVar10,uVar6);
        }
        else {
          if (uVar5 != 2) {
            return 0xffffffec;
          }
          uVar6 = FUN_00aac050(param_1,iVar7,iVar3 - iVar7,puVar10,uVar4,1);
        }
        if (0xffffff88 < uVar6) {
          return uVar6;
        }
        if (*(int *)(param_1 + 0x5c60) != 0) {
          FUN_00ab2bb0(param_1 + 0x5c80,iVar7,uVar6);
        }
        puVar9 = (uint3 *)(puVar10 + uVar4);
        iVar7 = iVar7 + uVar6;
        uVar8 = (uVar8 - 3) - uVar4;
        if ((uVar2 & 1) != 0) {
          if (((*(uint *)(param_1 + 0x5c40) & *(uint *)(param_1 + 0x5c44)) != 0xffffffff) &&
             ((iVar7 - param_2 != *(int *)(param_1 + 0x5c40) ||
              (iVar7 - param_2 >> 0x1f != *(int *)(param_1 + 0x5c44))))) {
            return 0xffffffec;
          }
          if (*(int *)(param_1 + 0x5c60) != 0) {
            iVar3 = FUN_00ab2750(param_1 + 0x5c80);
            if ((uVar8 < 4) || (*(int *)puVar9 != iVar3)) {
              return 0xffffffea;
            }
            puVar9 = puVar9 + 1;
            uVar8 = uVar8 - 4;
          }
          *param_4 = (int)puVar9;
          *param_5 = uVar8;
          return iVar7 - param_2;
        }
      }
    }
  }
  return 0xffffffb8;
}



/* FUNCTION 22008 ; VA 0x00aac340 ; FUN_00aac340 */

uint FUN_00aac340(int param_1,int param_2,int param_3,uint *param_4,uint param_5,int *param_6,
                 uint param_7,int param_8)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  
  uVar1 = param_7;
  piVar5 = param_6;
  if (param_8 != 0) {
    uVar1 = *(uint *)(param_8 + 8);
    piVar5 = *(int **)(param_8 + 4);
  }
  iVar4 = param_2;
  if (4 < param_5) {
    do {
      if (*param_4 == 0xfd2fb528) {
        if (param_8 == 0) {
          uVar2 = FUN_00abd150(param_1);
          if (0xffffff88 < uVar2) {
            return uVar2;
          }
          if ((piVar5 != (int *)0x0) && (uVar1 != 0)) {
            if ((uVar1 < 8) || (*piVar5 != -0x13cf5bc9)) {
              iVar3 = *(int *)(param_1 + 0x5c2c);
              *(int *)(param_1 + 0x5c34) = (int)piVar5 + (*(int *)(param_1 + 0x5c30) - iVar3);
              *(int **)(param_1 + 0x5c30) = piVar5;
            }
            else {
              *(int *)(param_1 + 0x5cdc) = piVar5[1];
              uVar2 = FUN_00aaec30(param_1 + 0x10,piVar5,uVar1);
              if (0xffffff88 < uVar2) {
                return 0xffffffe2;
              }
              iVar3 = *(int *)(param_1 + 0x5c2c);
              *(undefined4 *)(param_1 + 0x5c7c) = 1;
              *(undefined4 *)(param_1 + 0x5c78) = 1;
              *(uint *)(param_1 + 0x5c34) =
                   ((uVar2 + (int)piVar5) - iVar3) + *(int *)(param_1 + 0x5c30);
              *(uint *)(param_1 + 0x5c30) = uVar2 + (int)piVar5;
            }
            *(int *)(param_1 + 0x5c38) = iVar3;
            *(uint *)(param_1 + 0x5c2c) = (int)piVar5 + uVar1;
          }
        }
        else {
          uVar2 = FUN_00abd220(param_1,param_8);
          if (0xffffff88 < uVar2) {
            return uVar2;
          }
        }
        iVar3 = *(int *)(param_1 + 0x5c2c);
        if (iVar4 != iVar3) {
          *(int *)(param_1 + 0x5c38) = iVar3;
          *(int *)(param_1 + 0x5c2c) = iVar4;
          *(int *)(param_1 + 0x5c34) = (iVar4 - iVar3) + *(int *)(param_1 + 0x5c30);
          *(int *)(param_1 + 0x5c30) = iVar4;
        }
        uVar2 = FUN_00aac100(param_1,iVar4,param_3,&param_4,&param_5);
        if (0xffffff88 < uVar2) {
          return uVar2;
        }
        iVar4 = iVar4 + uVar2;
        param_3 = param_3 - uVar2;
      }
      else {
        if ((*param_4 & 0xfffffff0) != 0x184d2a50) {
          return 0xfffffff6;
        }
        if (param_5 < 8) {
          return 0xffffffb8;
        }
        uVar2 = param_4[1] + 8;
        if (param_5 < uVar2) {
          return 0xffffffb8;
        }
        param_4 = (uint *)((int)param_4 + uVar2);
        param_5 = param_5 - uVar2;
      }
    } while (4 < param_5);
  }
  if (param_5 == 0) {
    return iVar4 - param_2;
  }
  return 0xffffffb8;
}



/* FUNCTION 22009 ; VA 0x00aac530 ; FUN_00aac530 */

uint FUN_00aac530(undefined4 *param_1,uint *param_2,uint *param_3,int param_4,uint *param_5,
                 undefined4 param_6)

{
  undefined uVar1;
  ushort uVar2;
  ushort *puVar3;
  byte bVar4;
  int iVar5;
  uint uVar6;
  uint *puVar7;
  uint uVar8;
  uint uVar9;
  undefined *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  int iVar13;
  undefined auStack_90 [16];
  int iStack_80;
  uint uStack_7c;
  int *piStack_78;
  int *piStack_74;
  int *piStack_70;
  uint uStack_6c;
  ushort *puStack_68;
  uint uStack_64;
  ushort *puStack_60;
  uint uStack_5c;
  ushort *puStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint *puStack_3c;
  undefined *puStack_38;
  int iStack_34;
  uint *puStack_30;
  uint uStack_2c;
  undefined4 *puStack_28;
  uint uStack_24;
  uint *puStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint *puStack_14;
  undefined4 *puStack_10;
  undefined4 *puStack_c;
  undefined4 *puStack_8;
  
  iVar5 = (int)param_5;
  puStack_14 = (uint *)(param_4 + (int)param_5);
  param_5 = param_2;
  puStack_8 = (undefined4 *)((int)param_3 + (int)param_2);
  param_3 = (uint *)param_1[0x1739];
  iVar13 = param_1[0x173d];
  puStack_c = (undefined4 *)param_1[0x170c];
  iStack_34 = param_1[0x170d];
  puStack_38 = (undefined *)param_1[0x170e];
  puStack_3c = (uint *)(iVar13 + (int)param_3);
  puStack_20 = param_3;
  uVar6 = FUN_00aabc90(param_1,&uStack_18,param_4,iVar5);
  if (uVar6 < 0xffffff89) {
    uStack_2c = uStack_18;
    puVar7 = (uint *)(iVar13 + (int)param_3);
    if (uStack_18 != 0) {
      param_1[0x171f] = 1;
      uStack_54 = param_1[0x1708];
      uStack_50 = param_1[0x1709];
      uStack_4c = param_1[0x170a];
      uVar6 = FUN_00ab0130(&iStack_80,param_4 + uVar6,(int)puStack_14 - (param_4 + uVar6));
      if (0xffffff88 < uVar6) {
        return 0xffffffec;
      }
      puVar3 = (ushort *)*param_1;
      bVar4 = (byte)uStack_7c;
      uVar2 = *puVar3;
      uStack_7c = uStack_7c + uVar2;
      uStack_6c = ((uint)(iStack_80 << (bVar4 & 0x1f)) >> 1) >> (~(byte)uVar2 & 0x1f);
      FUN_00ab0260(&iStack_80);
      puStack_68 = puVar3 + 2;
      bVar4 = (byte)uStack_7c;
      puVar3 = (ushort *)param_1[2];
      uVar2 = *puVar3;
      uStack_7c = uStack_7c + uVar2;
      uStack_64 = ((uint)(iStack_80 << (bVar4 & 0x1f)) >> 1) >> (~(byte)uVar2 & 0x1f);
      FUN_00ab0260(&iStack_80);
      puStack_60 = puVar3 + 2;
      bVar4 = (byte)uStack_7c;
      puVar3 = (ushort *)param_1[1];
      uVar2 = *puVar3;
      uStack_7c = uStack_7c + uVar2;
      uStack_5c = ((uint)(iStack_80 << (bVar4 & 0x1f)) >> 1) >> (~(byte)uVar2 & 0x1f);
      FUN_00ab0260(&iStack_80);
      puStack_58 = puVar3 + 2;
      while (uStack_7c < 0x21) {
        if (piStack_78 < piStack_70) {
          if (piStack_78 != piStack_74) {
            uVar6 = uStack_7c >> 3;
            if ((int *)((int)piStack_78 - uVar6) < piStack_74) {
              uVar6 = (int)piStack_78 - (int)piStack_74;
            }
            uStack_7c = uStack_7c + uVar6 * -8;
            goto LAB_00aac6ef;
          }
        }
        else {
          uVar6 = uStack_7c >> 3;
          uStack_7c = uStack_7c & 7;
LAB_00aac6ef:
          piStack_78 = (int *)((int)piStack_78 - uVar6);
          iStack_80 = *piStack_78;
        }
        if (uStack_2c == 0) goto LAB_00aac973;
        uStack_2c = uStack_2c - 1;
        puStack_30 = (uint *)FUN_00aabde0(auStack_90,&iStack_80,param_6);
        puStack_10 = puStack_8 + -2;
        uStack_1c = *puStack_30;
        uVar8 = puStack_30[1];
        uVar9 = puStack_30[2];
        puVar12 = (undefined4 *)(uStack_1c + (int)param_5);
        uVar6 = uVar8 + uStack_1c;
        puStack_28 = (undefined4 *)(uVar6 + (int)param_5);
        puStack_14 = (uint *)((int)param_3 + uStack_1c);
        if (puStack_8 < puStack_28) {
          return 0xffffffba;
        }
        if (puStack_3c < puStack_14) {
          return 0xffffffec;
        }
        uStack_24 = uVar6;
        uStack_18 = uVar8;
        if (puStack_10 < puVar12) {
          uVar6 = FUN_00aadce0(param_5,puStack_8,*puStack_30,puStack_30[1],puStack_30[2],
                               puStack_30[3],&puStack_20,puStack_3c,puStack_c,iStack_34,puStack_38);
          param_3 = puStack_20;
        }
        else {
          *param_5 = *param_3;
          param_5[1] = param_3[1];
          if (8 < uStack_1c) {
            puVar7 = param_5 + 2;
            puStack_30 = (uint *)((uStack_1c - 8) + (int)puVar7);
            do {
              *puVar7 = param_3[2];
              puVar7[1] = param_3[3];
              puVar7 = puVar7 + 2;
              param_3 = param_3 + 2;
            } while (puVar7 < puStack_30);
          }
          puVar11 = (undefined4 *)((int)puVar12 - uVar9);
          puStack_20 = puStack_14;
          param_3 = puStack_14;
          if ((uint)((int)puVar12 - (int)puStack_c) < uVar9) {
            if ((uint)((int)puVar12 - iStack_34) < uVar9) {
              return 0xffffffec;
            }
            puVar10 = (undefined *)
                      ((int)((int)puVar12 - uVar9) + ((int)puStack_38 - (int)puStack_c));
            if (puStack_38 < puVar10 + uVar8) {
              iVar13 = (int)puStack_38 - (int)puVar10;
              FUN_0170cc70(puVar12,puVar10,iVar13);
              puVar12 = (undefined4 *)((int)puVar12 + iVar13);
              uVar8 = uStack_18 - iVar13;
              if ((puVar12 <= puStack_10) && (puVar11 = puStack_c, 2 < uVar8)) goto LAB_00aac899;
              uVar6 = uStack_24;
              if (uVar8 != 0) {
                puVar11 = puVar12;
                do {
                  *(undefined *)puVar11 =
                       *(undefined *)(((int)puStack_c - (int)puVar12) + (int)puVar11);
                  uVar8 = uVar8 - 1;
                  puVar11 = (undefined4 *)((int)puVar11 + 1);
                } while (uVar8 != 0);
              }
            }
            else {
              FUN_0170cc70(puVar12,puVar10,uVar8);
            }
          }
          else {
LAB_00aac899:
            uVar6 = uStack_24;
            if (uVar9 < 8) {
              *(undefined *)puVar12 = *(undefined *)puVar11;
              *(undefined *)((int)puVar12 + 1) = *(undefined *)((int)puVar11 + 1);
              *(undefined *)((int)puVar12 + 2) = *(undefined *)((int)puVar11 + 2);
              *(undefined *)((int)puVar12 + 3) = *(undefined *)((int)puVar11 + 3);
              iVar13 = *(int *)(&DAT_01948c50 + uVar9 * 4);
              puVar12[1] = *(undefined4 *)((int)puVar11 + iVar13);
              puVar11 = (undefined4 *)
                        (((int)puVar11 + iVar13) - *(int *)(&DAT_01948c70 + uVar9 * 4));
            }
            else {
              *puVar12 = *puVar11;
              puVar12[1] = puVar11[1];
            }
            puVar12 = puVar12 + 2;
            puVar11 = puVar11 + 2;
            if ((undefined4 *)((int)puStack_8 + -0xd) < puStack_28) {
              if (puVar12 < puStack_10) {
                FUN_00abdf70(puVar12,puVar11,(int)puStack_10 - (int)puVar12);
                puVar11 = (undefined4 *)((int)puVar11 + ((int)puStack_10 - (int)puVar12));
                puVar12 = puStack_10;
              }
              uVar8 = 0;
              uVar9 = (int)puStack_28 - (int)puVar12;
              if (puStack_28 < puVar12) {
                uVar9 = 0;
              }
              if (uVar9 != 0) {
                do {
                  uVar1 = *(undefined *)puVar11;
                  puVar11 = (undefined4 *)((int)puVar11 + 1);
                  uVar8 = uVar8 + 1;
                  *(undefined *)puVar12 = uVar1;
                  puVar12 = (undefined4 *)((int)puVar12 + 1);
                } while (uVar8 < uVar9);
              }
            }
            else {
              FUN_00abdf70(puVar12,puVar11,uVar8 - 8);
            }
          }
        }
        if (0xffffff88 < uVar6) {
          return uVar6;
        }
        param_5 = (uint *)((int)param_5 + uVar6);
      }
      if (uStack_2c != 0) {
        return 0xffffffec;
      }
LAB_00aac973:
      param_1[0x1708] = uStack_54;
      param_1[0x1709] = uStack_50;
      param_1[0x170a] = uStack_4c;
      puVar7 = puStack_3c;
    }
    uVar6 = (int)puVar7 - (int)param_3;
    if ((uint)((int)puStack_8 - (int)param_5) < uVar6) {
      return 0xffffffba;
    }
    FUN_0170c6f0(param_5,param_3,uVar6);
    uVar6 = (int)param_5 + (uVar6 - (int)param_2);
  }
  return uVar6;
}



/* FUNCTION 22010 ; VA 0x00aac9e0 ; FUN_00aac9e0 */

undefined *
FUN_00aac9e0(undefined4 *param_1,uint *param_2,uint param_3,uint *param_4,uint *param_5,int param_6)

{
  undefined uVar1;
  ushort uVar2;
  ushort *puVar3;
  byte bVar4;
  undefined *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 uVar8;
  uint *puVar9;
  uint *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined *puVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined4 *puVar16;
  uint auStack_ec [16];
  uint uStack_ac;
  undefined4 *puStack_a8;
  undefined4 *puStack_a4;
  undefined4 *puStack_a0;
  uint *puStack_9c;
  uint *puStack_98;
  undefined4 *puStack_94;
  undefined4 *puStack_90;
  undefined4 *puStack_8c;
  int iStack_88;
  uint *puStack_84;
  undefined *puStack_80;
  uint uStack_7c;
  uint *puStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  uint *puStack_6c;
  undefined4 *puStack_68;
  undefined4 *puStack_64;
  undefined *puStack_60;
  undefined4 *puStack_5c;
  undefined4 *puStack_58;
  undefined4 *puStack_54;
  uint uStack_50;
  ushort *puStack_4c;
  uint uStack_48;
  ushort *puStack_44;
  uint uStack_40;
  ushort *puStack_3c;
  undefined4 *apuStack_38 [4];
  undefined *puStack_28;
  int iStack_24;
  undefined4 *puStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  undefined4 *puStack_14;
  undefined *puStack_10;
  uint *puStack_c;
  undefined4 *puStack_8;
  
  iVar15 = (int)param_4;
  puVar10 = (uint *)param_1[0x1739];
  puStack_c = (uint *)((int)param_4 + (int)param_5);
  param_4 = param_2;
  puStack_20 = (undefined4 *)(param_3 + (int)param_2);
  puStack_84 = (uint *)(param_1[0x173d] + (int)puVar10);
  puStack_70 = (undefined4 *)param_1[0x170c];
  iStack_88 = param_1[0x170d];
  puStack_80 = (undefined *)param_1[0x170e];
  puStack_78 = puVar10;
  puVar5 = (undefined *)FUN_00aabc90(param_1,&puStack_8c,iVar15,param_5);
  if ((undefined *)0xffffff88 < puVar5) {
    return puVar5;
  }
  param_5 = puVar10;
  if (puStack_8c != (undefined4 *)0x0) {
    puStack_74 = (undefined4 *)&DAT_00000004;
    if ((int)puStack_8c < 4) {
      puStack_74 = puStack_8c;
    }
    param_1[0x171f] = 1;
    apuStack_38[0] = (undefined4 *)param_1[0x1708];
    apuStack_38[1] = (undefined4 *)param_1[0x1709];
    apuStack_38[2] = (undefined4 *)param_1[0x170a];
    puStack_28 = (undefined *)((int)param_2 - (int)puStack_70);
    apuStack_38[3] = puStack_70;
    iStack_24 = (int)puStack_80 - (int)puStack_70;
    uVar6 = FUN_00ab0130(&puStack_64,puVar5 + iVar15,(int)puStack_c - (int)(puVar5 + iVar15));
    if (0xffffff88 < uVar6) {
      return (undefined *)0xffffffec;
    }
    puVar3 = (ushort *)*param_1;
    bVar4 = (byte)puStack_60;
    uVar2 = *puVar3;
    puStack_60 = puStack_60 + uVar2;
    uStack_50 = ((uint)((int)puStack_64 << (bVar4 & 0x1f)) >> 1) >> (~(byte)uVar2 & 0x1f);
    FUN_00ab0260(&puStack_64);
    puStack_4c = puVar3 + 2;
    puVar3 = (ushort *)param_1[2];
    bVar4 = (byte)puStack_60;
    uVar2 = *puVar3;
    puStack_60 = puStack_60 + uVar2;
    uStack_48 = ((uint)((int)puStack_64 << (bVar4 & 0x1f)) >> 1) >> (~(byte)uVar2 & 0x1f);
    FUN_00ab0260(&puStack_64);
    puStack_44 = puVar3 + 2;
    puVar3 = (ushort *)param_1[1];
    bVar4 = (byte)puStack_60;
    uVar2 = *puVar3;
    puStack_60 = puStack_60 + uVar2;
    uStack_40 = ((uint)((int)puStack_64 << (bVar4 & 0x1f)) >> 1) >> (~(byte)uVar2 & 0x1f);
    FUN_00ab0260(&puStack_64);
    puStack_3c = puVar3 + 2;
    param_3 = 0;
    puStack_18 = auStack_ec;
    uStack_7c = uStack_48;
    puVar5 = puStack_60;
    puVar14 = puStack_64;
    while (puStack_8 = puVar14, puVar5 <= &DAT_00000020) {
      if (puStack_5c < puStack_54) {
        if (puStack_5c != puStack_58) {
          uVar6 = (uint)puVar5 >> 3;
          if ((undefined4 *)((int)puStack_5c - uVar6) < puStack_58) {
            uVar6 = (int)puStack_5c - (int)puStack_58;
          }
          puVar5 = puVar5 + uVar6 * -8;
          goto LAB_00aacbce;
        }
      }
      else {
        uVar6 = (uint)puVar5 >> 3;
        puVar5 = (undefined *)((uint)puVar5 & 7);
LAB_00aacbce:
        puVar14 = *(undefined4 **)((int)puStack_5c - uVar6);
        puStack_64 = puVar14;
        puStack_8 = puVar14;
        puStack_60 = puVar5;
        puStack_5c = (undefined4 *)((int)puStack_5c - uVar6);
      }
      puStack_8 = puVar14;
      if ((int)puStack_74 <= (int)param_3) goto LAB_00aaced0;
      puStack_14 = (undefined4 *)(*(uint *)(puStack_4c + uStack_50 * 2) >> 0x10 & 0xff);
      puStack_68 = (undefined4 *)(*(uint *)(puStack_3c + uStack_40 * 2) >> 0x10 & 0xff);
      iVar15 = uStack_7c * 2;
      puStack_6c = (uint *)(*(uint *)(puStack_44 + iVar15) >> 0x10);
      uVar6 = (uint)puStack_6c & 0xff;
      uStack_7c = *(int *)(&DAT_019476b0 + (int)puStack_14 * 4);
      puStack_10 = *(undefined **)(&DAT_01947788 + (int)puStack_68 * 4);
      if (uVar6 == 0) {
        puVar12 = (undefined4 *)0x0;
LAB_00aacce8:
        puVar13 = (undefined *)((int)puVar12 + (uint)(puStack_14 == (undefined4 *)0x0));
        if (puVar13 == (undefined *)0x0) {
          puStack_8 = apuStack_38[0];
        }
        else {
          puStack_8 = (undefined4 *)((int)apuStack_38[0] + -1);
          if (puVar13 != (undefined *)0x3) {
            puStack_8 = apuStack_38[(int)puVar13];
          }
          puStack_8 = (undefined4 *)((int)puStack_8 + (uint)(puStack_8 == (undefined4 *)0x0));
          if (puVar13 != (undefined *)0x1) {
            apuStack_38[2] = apuStack_38[1];
          }
          apuStack_38[1] = apuStack_38[0];
          apuStack_38[0] = puStack_8;
        }
      }
      else {
        puStack_c = *(uint **)(&DAT_01948df8 + uVar6 * 4);
        if (param_6 == 0) {
          puStack_60 = puVar5 + uVar6;
          puVar12 = (undefined4 *)
                    (((uint)((int)puVar14 << ((byte)puVar5 & 0x1f)) >>
                     (-(char)(*(uint *)(puStack_44 + iVar15) >> 0x10) & 0x1fU)) + (int)puStack_c);
          puStack_8 = puVar12;
          FUN_00ab0260(&puStack_64);
        }
        else {
          uVar7 = 0x18;
          if (uVar6 < 0x18) {
            uVar7 = uVar6;
          }
          puStack_1c = (uint *)(uVar6 - uVar7);
          puStack_60 = puVar5 + uVar7;
          puVar12 = (undefined4 *)
                    ((((uint)((int)puVar14 << ((byte)puVar5 & 0x1f)) >> (-(char)uVar7 & 0x1fU)) <<
                     ((byte)puStack_1c & 0x1f)) + (int)puStack_c);
          puStack_8 = puVar12;
          FUN_00ab0260(&puStack_64);
          if (puStack_1c != (uint *)0x0) {
            bVar4 = (byte)puStack_60;
            puStack_60 = puStack_60 + (int)puStack_1c;
            puVar12 = (undefined4 *)
                      ((int)puVar12 +
                      ((uint)((int)puStack_64 << (bVar4 & 0x1f)) >> (-(char)puStack_1c & 0x1fU)));
            puStack_8 = puVar12;
          }
        }
        puVar5 = puStack_60;
        puVar14 = puStack_64;
        if ((byte)puStack_6c < 2) goto LAB_00aacce8;
        apuStack_38[2] = apuStack_38[1];
        apuStack_38[1] = apuStack_38[0];
        apuStack_38[0] = puVar12;
      }
      uVar6 = uStack_7c;
      if (puStack_68 < &DAT_00000020) {
        uVar7 = 0;
      }
      else {
        uVar7 = (uint)((int)puVar14 << ((byte)puVar5 & 0x1f)) >> (-(char)puStack_10 & 0x1fU);
        puVar5 = puVar5 + (int)puStack_10;
        puStack_60 = puVar5;
      }
      puStack_98 = (uint *)(*(int *)(&DAT_01948d20 + (int)puStack_68 * 4) + uVar7);
      puStack_94 = apuStack_38[0];
      puStack_c = puStack_98;
      if (&DAT_00000013 < puStack_10 + uStack_7c) {
        FUN_00ab0260(&puStack_64);
        puVar5 = puStack_60;
        puVar14 = puStack_64;
      }
      if (puStack_14 < &DAT_00000010) {
        uVar7 = 0;
      }
      else {
        uVar7 = (uint)((int)puVar14 << ((byte)puVar5 & 0x1f)) >> (-(char)uVar6 & 0x1fU);
        puStack_60 = puVar5 + uVar6;
      }
      iVar15 = *(int *)(&DAT_01948c90 + (int)puStack_14 * 4);
      puStack_9c = (uint *)(iVar15 + uVar7);
      FUN_00ab0260(&puStack_64);
      puVar14 = (undefined4 *)((int)(iVar15 + uVar7) + (int)puStack_28);
      puStack_90 = (undefined4 *)(((int)puVar14 - (int)puStack_8) + (int)apuStack_38[3]);
      if (puVar14 < puStack_8) {
        puStack_90 = (undefined4 *)(iStack_24 + (int)puStack_90);
      }
      puStack_28 = (undefined *)((int)puStack_c + (int)puVar14);
      uVar6 = *(uint *)(puStack_4c + uStack_50 * 2);
      puVar5 = puStack_60 + (uVar6 >> 0x18);
      uStack_50 = (((uint)((int)puStack_64 << ((byte)puStack_60 & 0x1f)) >> 1) >>
                  (~(byte)(uVar6 >> 0x18) & 0x1f)) + (uVar6 & 0xffff);
      uVar6 = *(uint *)(puStack_3c + uStack_40 * 2);
      puStack_60 = puVar5 + (uVar6 >> 0x18);
      uStack_40 = (((uint)((int)puStack_64 << ((byte)puVar5 & 0x1f)) >> 1) >>
                  (~(byte)(uVar6 >> 0x18) & 0x1f)) + (uVar6 & 0xffff);
      FUN_00ab0260(&puStack_64);
      puVar14 = puStack_64;
      puVar11 = puStack_90;
      puVar12 = puStack_94;
      puVar10 = puStack_98;
      uVar6 = *(uint *)(puStack_44 + uStack_48 * 2);
      bVar4 = (byte)puStack_60;
      puVar5 = puStack_60 + (uVar6 >> 0x18);
      puStack_60 = puVar5;
      uStack_7c = (uVar6 & 0xffff) +
                  (((uint)((int)puStack_64 << (bVar4 & 0x1f)) >> 1) >>
                  (~(byte)(uVar6 >> 0x18) & 0x1f));
      param_3 = param_3 + 1;
      uStack_48 = uStack_7c;
      *puStack_18 = (uint)puStack_9c;
      puStack_18[1] = (uint)puVar10;
      puStack_18[2] = (uint)puVar12;
      puStack_18[3] = (uint)puVar11;
      puStack_18 = puStack_18 + 4;
    }
    if ((int)param_3 < (int)puStack_74) {
      return (undefined *)0xffffffec;
    }
LAB_00aaced0:
    do {
      if (&DAT_00000020 < puVar5) goto LAB_00aad482;
      if (puStack_5c < puStack_54) {
        if (puStack_5c != puStack_58) {
          uVar6 = (uint)puVar5 >> 3;
          if ((undefined4 *)((int)puStack_5c - uVar6) < puStack_58) {
            uVar6 = (int)puStack_5c - (int)puStack_58;
          }
          puStack_5c = (undefined4 *)((int)puStack_5c - uVar6);
          puStack_8 = (undefined4 *)*puStack_5c;
          puVar5 = puVar5 + uVar6 * -8;
          puStack_60 = puVar5;
          puStack_64 = puStack_8;
        }
      }
      else {
        puStack_5c = (undefined4 *)((int)puStack_5c - ((uint)puVar5 >> 3));
        puVar5 = (undefined *)((uint)puVar5 & 7);
        puStack_60 = puVar5;
        puStack_8 = (undefined4 *)*puStack_5c;
        puStack_64 = puStack_8;
      }
      if ((int)puStack_8c <= (int)param_3) goto LAB_00aad490;
      puStack_14 = (undefined4 *)(*(uint *)(puStack_4c + uStack_50 * 2) >> 0x10 & 0xff);
      puStack_6c = (uint *)(*(uint *)(puStack_3c + uStack_40 * 2) >> 0x10 & 0xff);
      puStack_18 = (uint *)(*(uint *)(puStack_44 + uStack_7c * 2) >> 0x10);
      uVar6 = (uint)puStack_18 & 0xff;
      puStack_68 = (undefined4 *)*(int *)(&DAT_019476b0 + (int)puStack_14 * 4);
      puStack_10 = (undefined *)*(int *)(&DAT_01947788 + (int)puStack_6c * 4);
      if (uVar6 == 0) {
        puVar14 = (undefined4 *)0x0;
        puVar12 = puStack_8;
LAB_00aad03a:
        puVar13 = (undefined *)((int)puVar14 + (uint)(puStack_14 == (undefined4 *)0x0));
        if (puVar13 == (undefined *)0x0) {
          puStack_8 = apuStack_38[0];
        }
        else {
          puStack_8 = (undefined4 *)((int)apuStack_38[0] + -1);
          if (puVar13 != (undefined *)0x3) {
            puStack_8 = apuStack_38[(int)puVar13];
          }
          puStack_8 = (undefined4 *)((int)puStack_8 + (uint)(puStack_8 == (undefined4 *)0x0));
          if (puVar13 != (undefined *)0x1) {
            apuStack_38[2] = apuStack_38[1];
          }
          apuStack_38[1] = apuStack_38[0];
          apuStack_38[0] = puStack_8;
        }
      }
      else {
        puStack_c = *(uint **)(&DAT_01948df8 + uVar6 * 4);
        if (param_6 == 0) {
          puStack_60 = puVar5 + uVar6;
          puVar14 = (undefined4 *)
                    (((uint)((int)puStack_8 << ((byte)puVar5 & 0x1f)) >>
                     (-(char)(*(uint *)(puStack_44 + uStack_7c * 2) >> 0x10) & 0x1fU)) +
                    (int)puStack_c);
          puStack_8 = puVar14;
          FUN_00ab0260(&puStack_64);
        }
        else {
          uVar7 = 0x18;
          if (uVar6 < 0x18) {
            uVar7 = uVar6;
          }
          puVar10 = (uint *)(uVar6 - uVar7);
          puStack_60 = puVar5 + uVar7;
          puVar14 = (undefined4 *)
                    ((((uint)((int)puStack_8 << ((byte)puVar5 & 0x1f)) >> (-(char)uVar7 & 0x1fU)) <<
                     ((byte)puVar10 & 0x1f)) + (int)puStack_c);
          puStack_1c = puVar10;
          puStack_8 = puVar14;
          FUN_00ab0260(&puStack_64);
          if (puVar10 != (uint *)0x0) {
            bVar4 = (byte)puStack_60;
            puStack_60 = puStack_60 + (int)puStack_1c;
            puVar14 = (undefined4 *)
                      ((int)puVar14 +
                      ((uint)((int)puStack_64 << (bVar4 & 0x1f)) >> (-(char)puStack_1c & 0x1fU)));
            puStack_8 = puVar14;
          }
        }
        puVar5 = puStack_60;
        puVar12 = puStack_64;
        if ((byte)puStack_18 < 2) goto LAB_00aad03a;
        apuStack_38[2] = apuStack_38[1];
        apuStack_38[1] = apuStack_38[0];
        apuStack_38[0] = puVar14;
      }
      puVar14 = puStack_68;
      if (puStack_6c < 0x20) {
        uVar6 = 0;
      }
      else {
        uVar6 = (uint)((int)puVar12 << ((byte)puVar5 & 0x1f)) >> (-(char)puStack_10 & 0x1fU);
        puVar5 = puVar5 + (int)puStack_10;
        puStack_60 = puVar5;
      }
      puStack_a8 = (undefined4 *)(*(int *)(&DAT_01948d20 + (int)puStack_6c * 4) + uVar6);
      puStack_a4 = apuStack_38[0];
      puStack_c = puStack_a8;
      if (0x13 < (uint)((int)puStack_10 + (int)puStack_68)) {
        FUN_00ab0260(&puStack_64);
        puVar5 = puStack_60;
        puVar12 = puStack_64;
      }
      if (puStack_14 < 0x10) {
        uVar6 = 0;
      }
      else {
        uVar6 = (uint)((int)puVar12 << ((byte)puVar5 & 0x1f)) >> (-(char)puVar14 & 0x1fU);
        puStack_60 = puVar5 + (int)puVar14;
      }
      iVar15 = *(int *)(&DAT_01948c90 + (int)puStack_14 * 4);
      uStack_ac = iVar15 + uVar6;
      FUN_00ab0260(&puStack_64);
      puVar14 = (undefined4 *)(puStack_28 + iVar15 + uVar6);
      puStack_a0 = (undefined4 *)(((int)puVar14 - (int)puStack_8) + (int)apuStack_38[3]);
      if (puVar14 < puStack_8) {
        puStack_a0 = (undefined4 *)(iStack_24 + (int)puStack_a0);
      }
      puStack_28 = (undefined *)((int)puStack_c + (int)puVar14);
      uVar6 = *(uint *)(puStack_4c + uStack_50 * 2);
      puVar5 = puStack_60 + (uVar6 >> 0x18);
      uStack_50 = (((uint)((int)puStack_64 << ((byte)puStack_60 & 0x1f)) >> 1) >>
                  (~(byte)(uVar6 >> 0x18) & 0x1f)) + (uVar6 & 0xffff);
      uVar6 = *(uint *)(puStack_3c + uStack_40 * 2);
      puStack_60 = puVar5 + (uVar6 >> 0x18);
      uStack_40 = (((uint)((int)puStack_64 << ((byte)puVar5 & 0x1f)) >> 1) >>
                  (~(byte)(uVar6 >> 0x18) & 0x1f)) + (uVar6 & 0xffff);
      FUN_00ab0260(&puStack_64);
      puStack_8 = puStack_64;
      uVar6 = *(uint *)(puStack_44 + uStack_48 * 2);
      bVar4 = (byte)puStack_60;
      puVar5 = puStack_60 + (uVar6 >> 0x18);
      puStack_60 = puVar5;
      uStack_7c = (uVar6 & 0xffff) +
                  (((uint)((int)puStack_64 << (bVar4 & 0x1f)) >> 1) >>
                  (~(byte)(uVar6 >> 0x18) & 0x1f));
      uVar6 = param_3 & 3;
      uStack_48 = uStack_7c;
      puVar9 = auStack_ec + uVar6 * 4;
      puStack_6c = puVar9;
      puStack_9c = (uint *)*puVar9;
      puVar10 = (uint *)auStack_ec[uVar6 * 4 + 1];
      puStack_94 = (undefined4 *)auStack_ec[uVar6 * 4 + 2];
      puStack_90 = (undefined4 *)auStack_ec[uVar6 * 4 + 3];
      puStack_98 = puVar10;
      puStack_18 = puStack_9c;
      puVar14 = (undefined4 *)((int)puStack_9c + (int)param_4);
      puStack_68 = puStack_20 + -2;
      puStack_10 = (undefined *)((int)puStack_9c + (int)puVar10);
      puStack_14 = (undefined4 *)((undefined *)((int)puStack_9c + (int)puVar10) + (int)param_4);
      puStack_1c = (uint *)((int)puStack_9c + (int)param_5);
      puStack_c = puVar10;
      if (puStack_20 < puStack_14) {
        return (undefined *)0xffffffba;
      }
      if (puStack_84 < puStack_1c) {
        return (undefined *)0xffffffec;
      }
      if (puStack_20 + -2 < puVar14) {
        puVar13 = (undefined *)
                  FUN_00aadce0(param_4,puStack_20,*puVar9,auStack_ec[uVar6 * 4 + 1],
                               auStack_ec[uVar6 * 4 + 2],auStack_ec[uVar6 * 4 + 3],&puStack_78,
                               puStack_84,puStack_70,iStack_88,puStack_80);
        param_5 = puStack_78;
      }
      else {
        *param_4 = *param_5;
        param_4[1] = param_5[1];
        if (&DAT_00000008 < puStack_9c) {
          puVar9 = param_4 + 2;
          puStack_18 = (uint *)((int)(puStack_9c + -2) + (int)puVar9);
          do {
            *puVar9 = param_5[2];
            puVar9[1] = param_5[3];
            puVar9 = puVar9 + 2;
            param_5 = param_5 + 2;
          } while (puVar9 < puStack_18);
        }
        puStack_78 = puStack_1c;
        puVar12 = puStack_90;
        param_5 = puStack_1c;
        if ((undefined4 *)((int)puVar14 - (int)puStack_70) < puStack_94) {
          if ((undefined4 *)((int)puVar14 - iStack_88) < puStack_94) {
            return (undefined *)0xffffffec;
          }
          if (puStack_80 < (undefined *)((int)puStack_90 + (int)puVar10)) {
            iVar15 = (int)puStack_80 - (int)puStack_90;
            FUN_0170cc70(puVar14,puStack_90,iVar15);
            puVar14 = (undefined4 *)((int)puVar14 + iVar15);
            puVar10 = (uint *)((int)puStack_c - iVar15);
            if ((puVar14 <= puStack_68) && (puVar12 = puStack_70, (uint *)0x2 < puVar10))
            goto LAB_00aad384;
            puVar13 = puStack_10;
            puVar9 = puStack_6c;
            if (puVar10 != (uint *)0x0) {
              puVar12 = puVar14;
              do {
                *(undefined *)puVar12 =
                     *(undefined *)((int)puVar12 + ((int)puStack_70 - (int)puVar14));
                puVar10 = (uint *)((int)puVar10 + -1);
                puVar12 = (undefined4 *)((int)puVar12 + 1);
              } while (puVar10 != (uint *)0x0);
            }
          }
          else {
            FUN_0170cc70(puVar14,puStack_90,puVar10);
            puVar13 = puStack_10;
            puVar9 = puStack_6c;
          }
        }
        else {
LAB_00aad384:
          if (&DAT_00000007 < puStack_94) {
            *puVar14 = *puVar12;
            puVar14[1] = puVar12[1];
          }
          else {
            *(undefined *)puVar14 = *(undefined *)puVar12;
            *(undefined *)((int)puVar14 + 1) = *(undefined *)((int)puVar12 + 1);
            *(undefined *)((int)puVar14 + 2) = *(undefined *)((int)puVar12 + 2);
            *(undefined *)((int)puVar14 + 3) = *(undefined *)((int)puVar12 + 3);
            iVar15 = *(int *)(&DAT_01948e78 + (int)puStack_94 * 4);
            puVar14[1] = *(undefined4 *)((int)puVar12 + iVar15);
            puVar12 = (undefined4 *)
                      (((int)puVar12 + iVar15) - *(int *)(&DAT_01948e98 + (int)puStack_94 * 4));
          }
          puVar14 = puVar14 + 2;
          puVar12 = puVar12 + 2;
          puVar13 = puStack_10;
          puVar9 = puStack_6c;
          if ((undefined4 *)((int)puStack_20 + -0xd) < puStack_14) {
            if (puVar14 < puStack_68) {
              iVar15 = (int)puVar12 - (int)puVar14;
              do {
                *puVar14 = *(undefined4 *)((int)puVar14 + iVar15);
                puVar14[1] = *(undefined4 *)((int)puVar14 + iVar15 + 4);
                puVar14 = puVar14 + 2;
              } while (puVar14 < puStack_68);
              puVar12 = (undefined4 *)(iVar15 + (int)puStack_68);
              puVar14 = puStack_68;
            }
            uVar6 = 0;
            uVar7 = (int)puStack_14 - (int)puVar14;
            if (puStack_14 < puVar14) {
              uVar7 = 0;
            }
            if (uVar7 != 0) {
              do {
                uVar1 = *(undefined *)puVar12;
                puVar12 = (undefined4 *)((int)puVar12 + 1);
                uVar6 = uVar6 + 1;
                *(undefined *)puVar14 = uVar1;
                puVar14 = (undefined4 *)((int)puVar14 + 1);
              } while (uVar6 < uVar7);
            }
          }
          else {
            puVar11 = (undefined4 *)((int)(puVar10 + -2) + (int)puVar14);
            iVar15 = (int)puVar12 - (int)puVar14;
            do {
              *puVar14 = *(undefined4 *)((int)puVar14 + iVar15);
              puVar14[1] = *(undefined4 *)((int)puVar14 + iVar15 + 4);
              puVar14 = puVar14 + 2;
            } while (puVar14 < puVar11);
          }
        }
      }
      if ((undefined *)0xffffff88 < puVar13) {
        return puVar13;
      }
      param_4 = (uint *)((int)param_4 + (int)puVar13);
      param_3 = param_3 + 1;
      *puVar9 = uStack_ac;
      puVar9[1] = (uint)puStack_a8;
      puVar9[2] = (uint)puStack_a4;
      puVar9[3] = (uint)puStack_a0;
    } while( true );
  }
  goto LAB_00aad727;
LAB_00aad482:
  if ((int)param_3 < (int)puStack_8c) {
    return (undefined *)0xffffffec;
  }
LAB_00aad490:
  param_3 = param_3 - (int)puStack_74;
  if ((int)param_3 < (int)puStack_8c) {
    puStack_8 = puStack_20 + -2;
    do {
      uVar6 = param_3 & 3;
      puStack_1c = auStack_ec + uVar6 * 4;
      uStack_ac = *puStack_1c;
      puVar12 = (undefined4 *)auStack_ec[uVar6 * 4 + 1];
      puStack_a4 = (undefined4 *)auStack_ec[uVar6 * 4 + 2];
      puStack_a0 = (undefined4 *)auStack_ec[uVar6 * 4 + 3];
      puStack_a8 = puVar12;
      puVar14 = (undefined4 *)(uStack_ac + (int)param_4);
      puStack_14 = puVar12;
      puStack_10 = (undefined *)((int)puVar12 + uStack_ac);
      puStack_74 = (undefined4 *)((undefined *)((int)puVar12 + uStack_ac) + (int)param_4);
      puStack_c = (uint *)(uStack_ac + (int)param_5);
      if (puStack_20 < puStack_74) {
        return (undefined *)0xffffffba;
      }
      if (puStack_84 < puStack_c) {
        return (undefined *)0xffffffec;
      }
      if (puStack_8 < puVar14) {
        puVar5 = (undefined *)
                 FUN_00aadce0(param_4,puStack_20,*puStack_1c,auStack_ec[uVar6 * 4 + 1],
                              auStack_ec[uVar6 * 4 + 2],auStack_ec[uVar6 * 4 + 3],&puStack_78,
                              puStack_84,puStack_70,iStack_88,puStack_80);
        param_5 = puStack_78;
      }
      else {
        *param_4 = *param_5;
        param_4[1] = param_5[1];
        if (8 < uStack_ac) {
          puVar10 = param_4 + 2;
          puStack_1c = (uint *)((int)param_4 + uStack_ac);
          do {
            *puVar10 = param_5[2];
            puVar10[1] = param_5[3];
            puVar10 = puVar10 + 2;
            param_5 = param_5 + 2;
          } while (puVar10 < puStack_1c);
        }
        puStack_78 = puStack_c;
        puVar11 = puStack_a0;
        param_5 = puStack_c;
        if ((undefined4 *)((int)puVar14 - (int)puStack_70) < puStack_a4) {
          if ((undefined4 *)((int)puVar14 - iStack_88) < puStack_a4) {
            return (undefined *)0xffffffec;
          }
          if (puStack_80 < (undefined *)((int)puStack_a0 + (int)puVar12)) {
            iVar15 = (int)puStack_80 - (int)puStack_a0;
            FUN_0170cc70(puVar14,puStack_a0,iVar15);
            puVar14 = (undefined4 *)((int)puVar14 + iVar15);
            puVar12 = (undefined4 *)((int)puVar12 - iVar15);
            if ((puVar14 <= puStack_8) && (puVar11 = puStack_70, (undefined4 *)0x2 < puVar12))
            goto LAB_00aad629;
            puVar5 = puStack_10;
            if (puVar12 != (undefined4 *)0x0) {
              puVar11 = puVar14;
              do {
                *(undefined *)puVar11 =
                     *(undefined *)((int)puVar11 + ((int)puStack_70 - (int)puVar14));
                puVar12 = (undefined4 *)((int)puVar12 + -1);
                puVar11 = (undefined4 *)((int)puVar11 + 1);
              } while (puVar12 != (undefined4 *)0x0);
            }
          }
          else {
            FUN_0170cc70(puVar14,puStack_a0,puVar12);
            puVar5 = puStack_10;
          }
        }
        else {
LAB_00aad629:
          if (&DAT_00000007 < puStack_a4) {
            *puVar14 = *puVar11;
            uVar8 = puVar11[1];
          }
          else {
            *(undefined *)puVar14 = *(undefined *)puVar11;
            *(undefined *)((int)puVar14 + 1) = *(undefined *)((int)puVar11 + 1);
            *(undefined *)((int)puVar14 + 2) = *(undefined *)((int)puVar11 + 2);
            iVar15 = *(int *)(&DAT_01948e78 + (int)puStack_a4 * 4);
            *(undefined *)((int)puVar14 + 3) = *(undefined *)((int)puVar11 + 3);
            uVar8 = *(undefined4 *)((int)puVar11 + iVar15);
            puVar11 = (undefined4 *)
                      (((int)puVar11 + iVar15) - *(int *)(&DAT_01948e98 + (int)puStack_a4 * 4));
          }
          puVar14[1] = uVar8;
          puVar11 = puVar11 + 2;
          puVar16 = puVar14 + 2;
          puVar5 = puStack_10;
          if ((undefined4 *)((int)puStack_20 + -0xd) < puStack_74) {
            if (puVar16 < puStack_8) {
              iVar15 = (int)puVar11 - (int)puVar16;
              do {
                *puVar16 = *(undefined4 *)((int)puVar16 + iVar15);
                puVar16[1] = *(undefined4 *)((int)puVar16 + iVar15 + 4);
                puVar16 = puVar16 + 2;
              } while (puVar16 < puStack_8);
              puVar11 = (undefined4 *)(iVar15 + (int)puStack_8);
              puVar16 = puStack_8;
            }
            uVar7 = (int)puStack_74 - (int)puVar16;
            uVar6 = 0;
            if (puStack_74 < puVar16) {
              uVar7 = 0;
            }
            if (uVar7 != 0) {
              do {
                uVar1 = *(undefined *)puVar11;
                puVar11 = (undefined4 *)((int)puVar11 + 1);
                uVar6 = uVar6 + 1;
                *(undefined *)puVar16 = uVar1;
                puVar16 = (undefined4 *)((int)puVar16 + 1);
              } while (uVar6 < uVar7);
            }
          }
          else {
            iVar15 = (int)puVar11 - (int)puVar16;
            do {
              *puVar16 = *(undefined4 *)((int)puVar16 + iVar15);
              puVar16[1] = *(undefined4 *)((int)puVar16 + iVar15 + 4);
              puVar16 = puVar16 + 2;
            } while (puVar16 < (undefined4 *)((int)puVar14 + (int)puVar12));
          }
        }
      }
      if ((undefined *)0xffffff88 < puVar5) {
        return puVar5;
      }
      param_4 = (uint *)((int)param_4 + (int)puVar5);
      param_3 = param_3 + 1;
    } while ((int)param_3 < (int)puStack_8c);
  }
  param_1[0x1708] = apuStack_38[0];
  param_1[0x1709] = apuStack_38[1];
  param_1[0x170a] = apuStack_38[2];
LAB_00aad727:
  uVar6 = (int)puStack_84 - (int)param_5;
  if (uVar6 <= (uint)((int)puStack_20 - (int)param_4)) {
    FUN_0170c6f0(param_4,param_5,uVar6);
    return (undefined *)((int)param_4 + (uVar6 - (int)param_2));
  }
  return (undefined *)0xffffffba;
}



/* FUNCTION 22011 ; VA 0x00aad760 ; FUN_00aad760 */

int FUN_00aad760(uint *param_1,uint param_2,undefined4 param_3,int param_4,undefined4 param_5,
                int param_6,undefined4 param_7,int param_8,int param_9,uint param_10,int param_11)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint *puVar8;
  uint uVar9;
  int iVar10;
  uint uStack_74;
  uint uStack_70;
  uint *puStack_6c;
  uint *puStack_68;
  uint *puStack_64;
  uint uStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  uint uStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  uint uStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  uint uStack_30;
  ushort *puStack_2c;
  byte *pbStack_28;
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uStack_74 = 0;
  uStack_70 = 0;
  puVar8 = (uint *)((param_2 - 4) + (int)param_1);
  puStack_6c = param_1;
  puStack_68 = param_1;
  if (4 < param_2) {
    puStack_64 = puVar8;
    FUN_00ab1270(&uStack_40,param_3,*(undefined *)(param_4 + -1 + param_10));
    FUN_00ab1270(&uStack_50,param_5,*(undefined *)(param_6 + -1 + param_10));
    FUN_00ab1270(&uStack_60,param_7,*(undefined *)(param_8 + -1 + param_10));
    uVar2 = *(uint *)(&DAT_019476b0 + (uint)*(byte *)(param_8 + -1 + param_10) * 4);
    uStack_14 = param_9 + param_10 * 8;
    uVar5 = *(uint *)(&DAT_01948670 + uVar2 * 4) & (uint)*(ushort *)(uStack_14 - 4);
    *param_1 = uVar5;
    param_1 = (uint *)((int)param_1 + (uVar2 >> 3));
    if (puVar8 < param_1) {
      param_1 = puVar8;
    }
    uVar1 = (uVar2 & 7) + *(int *)(&DAT_01947788 + (uint)*(byte *)(param_4 + -1 + param_10) * 4);
    uVar9 = uVar1 >> 3;
    uStack_24 = (*(uint *)(&DAT_01948670 +
                          *(int *)(&DAT_01947788 + (uint)*(byte *)(param_4 + -1 + param_10) * 4) * 4
                          ) & (uint)*(ushort *)(uStack_14 - 2)) << (sbyte)(uVar2 & 7) |
                uVar5 >> ((char)(uVar2 >> 3) * '\b' & 0x1fU);
    *param_1 = uStack_24;
    param_1 = (uint *)((int)param_1 + uVar9);
    if (puStack_64 < param_1) {
      param_1 = puStack_64;
    }
    uVar1 = uVar1 & 7;
    uStack_24 = uStack_24 >> ((char)uVar9 * '\b' & 0x1fU);
    uVar2 = (uint)*(byte *)(param_6 + -1 + param_10);
    if (param_11 == 0) {
      uStack_24 = (*(uint *)(&DAT_01948670 + uVar2 * 4) & *(uint *)(uStack_14 - 8)) << (sbyte)uVar1
                  | uStack_24;
      uVar1 = uVar1 + uVar2;
    }
    else {
      uVar5 = 0x18;
      if (uVar2 < 0x18) {
        uVar5 = uVar2;
      }
      iVar3 = uVar2 - uVar5;
      if (iVar3 != 0) {
        uVar2 = uVar1 + iVar3 >> 3;
        uStack_24 = (*(uint *)(&DAT_01948670 + iVar3 * 4) & *(uint *)(uStack_14 - 8)) <<
                    (sbyte)uVar1 | uStack_24;
        *param_1 = uStack_24;
        param_1 = (uint *)((int)param_1 + uVar2);
        if (puStack_64 < param_1) {
          param_1 = puStack_64;
        }
        uStack_24 = uStack_24 >> ((char)uVar2 * '\b' & 0x1fU);
        uVar1 = uVar1 + iVar3 & 7;
      }
      uStack_24 = (*(uint *)(uStack_14 - 8) >> ((byte)iVar3 & 0x1f) &
                  *(uint *)(&DAT_01948670 + uVar5 * 4)) << (sbyte)uVar1 | uStack_24;
      uVar1 = uVar1 + uVar5;
    }
    *param_1 = uStack_24;
    param_1 = (uint *)((int)param_1 + (uVar1 >> 3));
    if (puStack_64 < param_1) {
      param_1 = puStack_64;
    }
    uStack_18 = uVar1 & 7;
    uStack_20 = param_10 - 2;
    uStack_24 = uStack_24 >> ((byte)((uVar1 >> 3) << 3) & 0x1f);
    if (uStack_20 < param_10) {
      pbStack_28 = (byte *)(uStack_20 + param_8);
      uStack_c = uStack_40;
      uStack_10 = uStack_60;
      do {
        uVar6 = (uint)*pbStack_28;
        iVar3 = *(int *)(&DAT_019476b0 + uVar6 * 4);
        uVar5 = (uint)pbStack_28[param_6 - param_8];
        uVar4 = (uint)pbStack_28[param_4 - param_8];
        iStack_1c = *(int *)(&DAT_01947788 + uVar4 * 4);
        uVar2 = uStack_50 + *(int *)(iStack_48 + 4 + uVar5 * 8);
        uVar1 = uVar2 >> 0x10;
        uVar7 = *(uint *)(&DAT_01948670 + uVar1 * 4) & uStack_50;
        iVar10 = uStack_18 + uVar1;
        uStack_50 = (uint)*(ushort *)
                           (iStack_4c +
                           (((int)uStack_50 >> ((byte)(uVar2 >> 0x10) & 0x1f)) +
                           *(int *)(iStack_48 + uVar5 * 8)) * 2);
        uVar1 = *(int *)(iStack_38 + 4 + uVar4 * 8) + uStack_c;
        uVar9 = uVar1 >> 0x10;
        uVar2 = iVar10 + uVar9;
        uStack_24 = (*(uint *)(&DAT_01948670 + uVar9 * 4) & uStack_c) << ((byte)iVar10 & 0x1f) |
                    uVar7 << (sbyte)uStack_18 | uStack_24;
        uStack_c = (uint)*(ushort *)
                          (iStack_3c +
                          (((int)uStack_c >> ((byte)(uVar1 >> 0x10) & 0x1f)) +
                          *(int *)(iStack_38 + uVar4 * 8)) * 2);
        uVar1 = uVar2 >> 3;
        *param_1 = uStack_24;
        param_1 = (uint *)((int)param_1 + uVar1);
        if (puStack_64 < param_1) {
          param_1 = puStack_64;
        }
        uVar2 = uVar2 & 7;
        uVar9 = uStack_10 + *(int *)(iStack_58 + 4 + uVar6 * 8);
        uVar4 = uVar9 >> 0x10;
        uVar7 = uVar2 + uVar4;
        uVar1 = uStack_24 >> ((byte)(uVar1 << 3) & 0x1f) |
                (*(uint *)(&DAT_01948670 + uVar4 * 4) & uStack_10) << (sbyte)uVar2;
        uStack_10 = (uint)*(ushort *)
                           (iStack_5c +
                           (((int)uStack_10 >> ((byte)(uVar9 >> 0x10) & 0x1f)) +
                           *(int *)(iStack_58 + uVar6 * 8)) * 2);
        uVar2 = uVar7 >> 3;
        *param_1 = uVar1;
        param_1 = (uint *)((int)param_1 + uVar2);
        if (puStack_64 < param_1) {
          param_1 = puStack_64;
        }
        uVar7 = uVar7 & 7;
        iVar10 = uStack_20 * 8;
        puStack_2c = (ushort *)(param_9 + 6 + iVar10);
        uVar9 = uVar7 + iVar3;
        uStack_14 = (*(uint *)(&DAT_01948670 + iVar3 * 4) & (uint)puStack_2c[-1]) << (sbyte)uVar7 |
                    uVar1 >> ((char)uVar2 * '\b' & 0x1fU);
        uStack_24 = uStack_14;
        if (0x18 < (uint)(iStack_1c + iVar3)) {
          *param_1 = uStack_14;
          uVar2 = uVar9 >> 3;
          param_1 = (uint *)((int)param_1 + uVar2);
          if (puStack_64 < param_1) {
            param_1 = puStack_64;
          }
          uVar9 = uVar9 & 7;
          uStack_24 = uStack_14 >> ((byte)(uVar2 << 3) & 0x1f);
        }
        uStack_24 = (*(uint *)(&DAT_01948670 + iStack_1c * 4) & (uint)*puStack_2c) <<
                    ((byte)uVar9 & 0x1f) | uStack_24;
        *param_1 = uStack_24;
        uVar2 = iStack_1c + uVar9 >> 3;
        param_1 = (uint *)((int)param_1 + uVar2);
        if (puStack_64 < param_1) {
          param_1 = puStack_64;
        }
        uStack_30 = iStack_1c + uVar9 & 7;
        uStack_24 = uStack_24 >> ((byte)(uVar2 << 3) & 0x1f);
        uVar2 = uStack_30;
        if (param_11 == 0) {
          uStack_24 = (*(uint *)(&DAT_01948670 + uVar5 * 4) & *(uint *)(iVar10 + param_9)) <<
                      (sbyte)uStack_30 | uStack_24;
          uStack_8 = uVar5;
        }
        else {
          uVar1 = 0x18;
          if (uVar5 < 0x18) {
            uVar1 = uVar5;
          }
          uStack_8 = uVar5 - uVar1;
          if (uStack_8 != 0) {
            puStack_2c = (ushort *)(uStack_30 + uStack_8);
            uStack_24 = uStack_24 |
                        (*(uint *)(&DAT_01948670 + uStack_8 * 4) & *(uint *)(iVar10 + param_9)) <<
                        (sbyte)uStack_30;
            *param_1 = uStack_24;
            param_1 = (uint *)((int)param_1 + ((uint)puStack_2c >> 3));
            if (puStack_64 < param_1) {
              param_1 = puStack_64;
            }
            uStack_24 = uStack_24 >> ((char)((uint)puStack_2c >> 3) * '\b' & 0x1fU);
            uVar2 = (uint)puStack_2c & 7;
          }
          uStack_24 = (*(uint *)(iVar10 + param_9) >> ((byte)uStack_8 & 0x1f) &
                      *(uint *)(&DAT_01948670 + uVar1 * 4)) << (sbyte)uVar2 | uStack_24;
          uVar5 = uVar1;
        }
        uVar1 = uVar5 + uVar2 >> 3;
        *param_1 = uStack_24;
        param_1 = (uint *)((int)param_1 + uVar1);
        if (puStack_64 < param_1) {
          param_1 = puStack_64;
        }
        uStack_18 = uVar5 + uVar2 & 7;
        pbStack_28 = pbStack_28 + -1;
        uStack_20 = uStack_20 - 1;
        uStack_24 = uStack_24 >> ((byte)(uVar1 << 3) & 0x1f);
        param_2 = uStack_50;
      } while (uStack_20 < param_10);
    }
    else {
      uStack_c = uStack_40;
      param_2 = uStack_50;
      uStack_10 = uStack_60;
    }
    uVar5 = (*(uint *)(&DAT_01948670 + iStack_34 * 4) & uStack_c) << (sbyte)uStack_18 | uStack_24;
    uVar2 = iStack_34 + uStack_18 >> 3;
    *param_1 = uVar5;
    param_1 = (uint *)((int)param_1 + uVar2);
    if (puStack_64 < param_1) {
      param_1 = puStack_64;
    }
    uVar9 = iStack_34 + uStack_18 & 7;
    uVar1 = iStack_44 + uVar9;
    uVar2 = uVar5 >> ((byte)(uVar2 << 3) & 0x1f) |
            (*(uint *)(&DAT_01948670 + iStack_44 * 4) & param_2) << (sbyte)uVar9;
    uVar5 = uVar1 >> 3;
    *param_1 = uVar2;
    param_1 = (uint *)((int)param_1 + uVar5);
    if (puStack_64 < param_1) {
      param_1 = puStack_64;
    }
    uVar1 = uVar1 & 7;
    uStack_70 = iStack_54 + uVar1;
    uStack_74 = uVar2 >> ((char)uVar5 * '\b' & 0x1fU) |
                (*(uint *)(&DAT_01948670 + iStack_54 * 4) & uStack_10) << (sbyte)uVar1;
    uVar2 = uStack_70 >> 3;
    *param_1 = uStack_74;
    puStack_68 = (uint *)((int)param_1 + uVar2);
    if (puStack_64 < puStack_68) {
      puStack_68 = puStack_64;
    }
    uStack_70 = uStack_70 & 7;
    uStack_74 = uStack_74 >> ((char)uVar2 * '\b' & 0x1fU);
    iVar3 = FUN_00ab0060(&uStack_74);
    if (iVar3 != 0) {
      return iVar3;
    }
  }
  return -0x46;
}



/* FUNCTION 22012 ; VA 0x00aadce0 ; FUN_00aadce0 */

int FUN_00aadce0(undefined *param_1,undefined *param_2,int param_3,int param_4,uint param_5,
                undefined4 param_6,int *param_7,uint param_8,int param_9,int param_10,uint param_11)

{
  undefined *puVar1;
  undefined *puVar2;
  undefined uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined *puVar7;
  int iVar8;
  
  puVar1 = param_1 + param_3;
  iVar4 = param_3 + param_4;
  puVar2 = param_1 + iVar4;
  puVar7 = param_2 + -8;
  if (param_2 < puVar2) {
    return -0x46;
  }
  if (param_8 < (uint)(param_3 + *param_7)) {
    return -0x14;
  }
  if (puVar1 <= puVar7) {
    return -1;
  }
  if (param_1 < puVar7) {
    FUN_00abdf70(param_1,*param_7,(int)puVar7 - (int)param_1);
    *param_7 = (int)(puVar7 + (*param_7 - (int)param_1));
    param_1 = puVar7;
  }
  uVar6 = 0;
  uVar5 = (int)puVar1 - (int)param_1;
  if (puVar1 < param_1) {
    uVar5 = 0;
  }
  if (uVar5 != 0) {
    do {
      uVar6 = uVar6 + 1;
      uVar3 = *(undefined *)*param_7;
      *param_7 = (int)((undefined *)*param_7 + 1);
      *param_1 = uVar3;
      param_1 = param_1 + 1;
    } while (uVar6 < uVar5);
  }
  iVar8 = (int)puVar1 - param_5;
  if ((uint)((int)puVar1 - param_9) < param_5) {
    if ((uint)((int)puVar1 - param_10) < param_5) {
      return -0x14;
    }
    iVar8 = ((int)puVar1 - param_5) + (param_11 - param_9);
    if ((uint)(iVar8 + param_4) <= param_11) {
      FUN_0170cc70(puVar1,iVar8,param_4);
      return iVar4;
    }
    FUN_0170cc70(puVar1,iVar8,param_11 - iVar8);
    param_1 = puVar1 + (param_11 - iVar8);
    iVar8 = param_9;
  }
  uVar6 = (int)puVar2 - (int)param_1;
  uVar5 = 0;
  if (puVar2 < param_1) {
    uVar6 = 0;
  }
  if (uVar6 != 0) {
    puVar7 = param_1;
    do {
      uVar5 = uVar5 + 1;
      *puVar7 = puVar7[iVar8 - (int)param_1];
      puVar7 = puVar7 + 1;
    } while (uVar5 < uVar6);
  }
  return iVar4;
}



/* FUNCTION 22013 ; VA 0x00aade20 ; FUN_00aade20 */

int FUN_00aade20(int param_1,uint param_2,int param_3)

{
  uint uVar1;
  byte bVar2;
  int iVar3;
  
  iVar3 = (uint)(param_3 != 1) * 4;
  uVar1 = iVar3 + 1;
  if (param_2 < uVar1) {
    return -0x48;
  }
  bVar2 = *(byte *)(iVar3 + param_1);
  if (((bVar2 & 0x20) == 0) || (bVar2 >> 6 != 0)) {
    iVar3 = 0;
  }
  else {
    iVar3 = 1;
  }
  return (uint)((bVar2 & 0x20) == 0) +
         *(int *)(&DAT_01947690 + (uint)(bVar2 >> 6) * 4) +
         *(int *)(&DAT_019476a0 + (bVar2 & 3) * 4) + iVar3 + uVar1;
}



/* FUNCTION 22014 ; VA 0x00aade90 ; FUN_00aade90 */

uint FUN_00aade90(uint *param_1,uint *param_2,uint param_3,int param_4)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar5 = (uint)(param_4 != 1);
  uVar4 = uVar5 * 4 + 1;
  if (param_3 < uVar4) {
    return uVar4;
  }
  if ((param_4 != 1) && (*param_2 != 0xfd2fb528)) {
    if ((*param_2 & 0xfffffff0) != 0x184d2a50) {
      return 0xfffffff6;
    }
    if (param_3 < 8) {
      return 8;
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0;
    param_1[9] = 0;
    *param_1 = param_2[1];
    param_1[1] = 0;
    param_1[5] = 1;
    return 0;
  }
  uVar2 = FUN_00aade20(param_2,param_3,param_4);
  if (param_3 < uVar2) {
    return uVar2;
  }
  param_1[6] = uVar2;
  bVar1 = *(byte *)(param_2 + uVar5);
  if ((*(byte *)(param_2 + uVar5) & 8) != 0) {
    return 0xfffffff2;
  }
  if ((bVar1 & 0x20) == 0) {
    uVar5 = (*(byte *)(uVar4 + (int)param_2) >> 3) + 10;
    if (0x1e < uVar5) {
      return 0xfffffff0;
    }
    uVar2 = 1 << (uVar5 & 0x1f);
    uVar3 = 0;
    if (0x1f < uVar5) {
      uVar3 = uVar2;
    }
    uVar2 = uVar2 ^ uVar3;
    if (0x3f < uVar5) {
      uVar3 = uVar2;
    }
    FUN_016f39b0(*(byte *)(uVar4 + (int)param_2) & 7,0,uVar2 >> 3 | uVar3 << 0x1d,uVar3 >> 3);
  }
                    /* WARNING: Could not recover jumptable at 0x00aae020. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar4 = (**(code **)(&DAT_00aae0b4 + (uint)(bVar1 >> 6) * 4))();
  return uVar4;
}



/* FUNCTION 22015 ; VA 0x00aae0d0 ; FUN_00aae0d0 */

int FUN_00aae0d0(int *param_1,uint param_2,int param_3)

{
  byte *pbVar1;
  int iVar2;
  byte bVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  
  if (param_1[0x11] != 0) {
    iVar7 = 0x1f;
    if (param_2 + 1 != 0) {
      for (; param_2 + 1 >> iVar7 == 0; iVar7 = iVar7 + -1) {
      }
    }
    return iVar7 + param_2 * 6;
  }
  if (param_2 == 0) {
    iVar7 = 0x1f;
    if (*(int *)param_1[1] + 1U != 0) {
      for (; *(int *)param_1[1] + 1U >> iVar7 == 0; iVar7 = iVar7 + -1) {
      }
    }
    return param_1[0xd] - iVar7;
  }
  if (param_1[0x14] == param_3) {
    uVar6 = param_2 - param_1[0x13];
    uVar5 = 0;
    iVar7 = param_1[0xe] * uVar6 + param_1[0x12];
    if (uVar6 != 0) {
      do {
        pbVar1 = (byte *)(uVar5 + param_1[0x13] + param_1[0x14]);
        uVar5 = uVar5 + 1;
        uVar4 = *(int *)(*param_1 + (uint)*pbVar1 * 4) + 1;
        iVar2 = 0x1f;
        if (uVar4 != 0) {
          for (; uVar4 >> iVar2 == 0; iVar2 = iVar2 + -1) {
          }
        }
        iVar7 = iVar7 - iVar2;
      } while (uVar5 < uVar6);
    }
  }
  else {
    iVar7 = param_1[0xe] * param_2;
    uVar5 = 0;
    if (param_2 != 0) {
      do {
        pbVar1 = (byte *)(uVar5 + param_3);
        uVar5 = uVar5 + 1;
        uVar6 = *(int *)(*param_1 + (uint)*pbVar1 * 4) + 1;
        iVar2 = 0x1f;
        if (uVar6 != 0) {
          for (; uVar6 >> iVar2 == 0; iVar2 = iVar2 + -1) {
          }
        }
        iVar7 = iVar7 - iVar2;
      } while (uVar5 < param_2);
    }
    if (param_2 < 0xc) goto LAB_00aae1aa;
    param_1[0x14] = param_3;
  }
  param_1[0x13] = param_2;
  param_1[0x12] = iVar7;
LAB_00aae1aa:
  if (param_2 < 0x40) {
    bVar3 = (&DAT_01947908)[param_2];
  }
  else {
    iVar2 = 0x1f;
    if (param_2 != 0) {
      for (; param_2 >> iVar2 == 0; iVar2 = iVar2 + -1) {
      }
    }
    bVar3 = (char)iVar2 + 0x13;
  }
  uVar5 = *(int *)(param_1[1] + (uint)bVar3 * 4) + 1;
  iVar2 = 0x1f;
  if (uVar5 != 0) {
    for (; uVar5 >> iVar2 == 0; iVar2 = iVar2 + -1) {
    }
  }
  return ((*(int *)(&DAT_019476b0 + (uint)bVar3 * 4) + param_1[0xd]) - iVar2) + iVar7;
}



/* FUNCTION 22016 ; VA 0x00aae1f0 ; FUN_00aae1f0 */

void FUN_00aae1f0(int param_1)

{
  *(undefined4 *)(param_1 + 0x5ce0) = 0;
  *(undefined4 *)(param_1 + 0x5cfc) = 0;
  *(undefined4 *)(param_1 + 0x5d18) = 0x8000001;
  *(undefined4 *)(param_1 + 0x5d04) = 0;
  *(undefined4 *)(param_1 + 0x5d00) = 0;
  *(undefined4 *)(param_1 + 0x5d0c) = 0;
  *(undefined4 *)(param_1 + 0x5d10) = 0;
  *(undefined4 *)(param_1 + 0x5d20) = 0;
  *(undefined4 *)(param_1 + 0x5d08) = 0;
  return;
}



/* FUNCTION 22017 ; VA 0x00aae260 ; FUN_00aae260 */

/* WARNING: Type propagation algorithm not settling */

char * FUN_00aae260(int param_1,uint param_2,uint *param_3,int *param_4,int param_5,
                   undefined4 param_6,int param_7)

{
  uint *puVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  char *pcVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  uint *puVar12;
  uint *puVar13;
  uint *puVar14;
  uint uVar15;
  char *pcVar16;
  uint uVar17;
  char *pcVar18;
  uint *puVar19;
  char *pcVar20;
  uint uVar21;
  uint *puVar22;
  char *pcVar23;
  char *pcStack_3c;
  char *pcStack_24;
  int iStack_20;
  char *pcStack_18;
  char *pcStack_14;
  
  iVar11 = *(int *)(param_1 + 0x210);
  iVar9 = FUN_00abd760(param_2,*(undefined4 *)(param_1 + 0x98),param_6);
  iVar2 = *(int *)(param_1 + 0x218);
  uVar3 = *(uint *)(iVar11 + iVar9 * 4);
  uVar17 = (1 << ((char)*(undefined4 *)(param_1 + 0x94) - 1U & 0x1f)) - 1;
  pcStack_24 = (char *)0x0;
  pcStack_3c = (char *)0x0;
  iVar4 = *(int *)(param_1 + 4);
  iVar5 = *(int *)(param_1 + 8);
  pcVar20 = *(char **)(param_1 + 0xc);
  pcVar18 = pcVar20 + iVar5;
  uVar10 = param_2 - iVar4;
  pcStack_18 = (char *)0x0;
  uVar21 = -(uint)(uVar17 < uVar10) & uVar10 - uVar17;
  uVar6 = *(uint *)(param_1 + 0x10);
  puVar14 = (uint *)(iVar2 + (uVar10 & uVar17) * 8);
  *(uint *)(iVar11 + iVar9 * 4) = uVar10;
  puVar22 = puVar14 + 1;
  pcVar8 = (char *)(uVar10 + 8);
  uVar15 = param_2;
joined_r0x00aae32a:
  do {
    pcStack_14 = pcVar8;
    if ((param_5 == 0) || (param_5 = param_5 + -1, uVar3 <= uVar6)) goto LAB_00aae50b;
    puVar1 = (uint *)(iVar2 + (uVar3 & uVar17) * 8);
    pcVar23 = pcStack_24;
    if (pcStack_3c < pcStack_24) {
      pcVar23 = pcStack_3c;
    }
    if ((param_7 == 0) || (pcVar20 <= pcVar23 + uVar3)) {
      iStack_20 = iVar4 + uVar3;
      if (pcVar23[iStack_20] == pcVar23[uVar15]) {
        puVar12 = (uint *)(pcVar23 + param_2 + 1);
        puVar19 = (uint *)(pcVar23 + iStack_20 + 1);
        puVar13 = puVar12;
        if (puVar12 < (uint *)((int)param_3 + -3)) {
LAB_00aae3f0:
          uVar15 = *puVar13 ^ *puVar19;
          if (uVar15 == 0) break;
          uVar7 = 0;
          if (uVar15 != 0) {
            for (; (uVar15 >> uVar7 & 1) == 0; uVar7 = uVar7 + 1) {
            }
          }
          pcVar16 = (char *)(((uVar7 >> 3) - (int)puVar12) + (int)puVar13);
          goto LAB_00aae42c;
        }
LAB_00aae404:
        if ((puVar13 < (uint *)((int)param_3 - 1U)) && (*(short *)puVar19 == *(short *)puVar13)) {
          puVar13 = (uint *)((int)puVar13 + 2);
          puVar19 = (uint *)((int)puVar19 + 2);
        }
        if ((puVar13 < param_3) && (*(char *)puVar19 == *(char *)puVar13)) {
          puVar13 = (uint *)((int)puVar13 + 1);
        }
        pcVar16 = (char *)((int)puVar13 - (int)puVar12);
LAB_00aae42c:
        pcVar23 = pcVar23 + 1 + (int)pcVar16;
        uVar15 = param_2;
      }
    }
    else {
      iStack_20 = iVar5 + uVar3;
      pcVar16 = pcVar23 + iStack_20;
      puVar13 = param_3;
      if (pcVar18 + ((int)(pcVar23 + uVar15) - (int)pcVar16) < param_3) {
        puVar13 = (uint *)(pcVar18 + ((int)(pcVar23 + uVar15) - (int)pcVar16));
      }
      iVar11 = FUN_00abcfb0(pcVar23 + uVar15,pcVar16,puVar13);
      if (pcVar16 + iVar11 == pcVar18) {
        iVar9 = FUN_00abcfb0(pcVar23 + iVar11 + param_2,pcVar20 + iVar4,param_3);
        iVar11 = iVar9 + iVar11;
      }
      pcVar23 = pcVar23 + iVar11;
      uVar15 = param_2;
      if (pcVar20 <= pcVar23 + uVar3) {
        iStack_20 = iVar4 + uVar3;
      }
    }
    if (pcStack_18 < pcVar23) {
      pcStack_14 = pcVar23 + uVar3;
      if (pcVar23 <= pcVar8 + -uVar3) {
        pcStack_14 = pcVar8;
      }
      uVar15 = (uVar10 - uVar3) + 1;
      iVar11 = 0x1f;
      if (uVar15 != 0) {
        for (; uVar15 >> iVar11 == 0; iVar11 = iVar11 + -1) {
        }
      }
      iVar9 = 0x1f;
      if (*param_4 + 1U != 0) {
        for (; *param_4 + 1U >> iVar9 == 0; iVar9 = iVar9 + -1) {
        }
      }
      if (iVar11 - iVar9 < ((int)pcVar23 - (int)pcStack_18) * 4) {
        *param_4 = (uVar10 - uVar3) + 2;
        pcStack_18 = pcVar23;
      }
      uVar15 = param_2;
      if ((uint *)(pcVar23 + param_2) == param_3) goto LAB_00aae50b;
    }
    pcVar8 = pcStack_14;
    if ((byte)pcVar23[iStack_20] < (byte)pcVar23[uVar15]) {
      *puVar14 = uVar3;
      if (uVar3 <= uVar21) {
        puVar14 = &param_2;
LAB_00aae50b:
        *puVar22 = 0;
        *puVar14 = 0;
        pcVar20 = pcStack_14 + -8;
        if (pcStack_14 <= (char *)(uVar10 + 8)) {
          pcVar20 = (char *)(uVar10 + 1);
        }
        *(char **)(param_1 + 0x14) = pcVar20;
        return pcStack_18;
      }
      puVar14 = puVar1 + 1;
      uVar3 = *puVar14;
      pcStack_3c = pcVar23;
      goto joined_r0x00aae32a;
    }
    *puVar22 = uVar3;
    if (uVar3 <= uVar21) {
      puVar22 = &param_2;
      goto LAB_00aae50b;
    }
    uVar3 = *puVar1;
    puVar22 = puVar1;
    pcStack_24 = pcVar23;
  } while( true );
  puVar13 = puVar13 + 1;
  puVar19 = puVar19 + 1;
  if ((uint *)((int)param_3 + -3) <= puVar13) goto LAB_00aae404;
  goto LAB_00aae3f0;
}



/* FUNCTION 22018 ; VA 0x00aae540 ; FUN_00aae540 */

int FUN_00aae540(int param_1,int *param_2,uint *param_3,int param_4,undefined4 *param_5,int param_6,
                int *param_7,undefined *param_8)

{
  undefined *puVar1;
  undefined4 *puVar2;
  undefined *puVar3;
  int iVar4;
  undefined *puVar5;
  int iVar6;
  int iVar7;
  undefined *puVar8;
  undefined *puVar9;
  int iVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  int iVar14;
  undefined *puVar15;
  int iVar16;
  uint *puVar17;
  uint *puVar18;
  undefined4 *puVar19;
  byte bVar20;
  uint uVar21;
  undefined *puVar22;
  undefined *puVar23;
  char *pcVar24;
  uint uVar25;
  uint *puVar26;
  undefined *puVar27;
  undefined *puVar28;
  undefined *puStack_48;
  undefined *puStack_30;
  undefined4 *puStack_20;
  int iStack_18;
  undefined *puStack_8;
  
  iVar14 = (int)param_5;
  iVar4 = *(int *)(param_1 + 4);
  uVar21 = (int)param_2 - iVar4;
  iVar12 = FUN_00abd760(param_2,*(undefined4 *)(param_1 + 0x98),param_5);
  puStack_48 = (undefined *)0x0;
  puStack_30 = (undefined *)0x0;
  iStack_18 = 0;
  iVar16 = *(int *)(param_1 + 0x210);
  puVar5 = *(undefined **)(iVar16 + iVar12 * 4);
  iVar6 = *(int *)(param_1 + 0x218);
  iVar7 = *(int *)(param_1 + 8);
  uVar13 = (1 << ((char)*(undefined4 *)(param_1 + 0x94) - 1U & 0x1f)) - 1;
  puVar8 = *(undefined **)(param_1 + 0xc);
  puVar22 = puVar8 + iVar7;
  puVar27 = (undefined *)((int)param_8 + -1);
  puVar23 = (undefined *)(-(uint)(uVar13 < uVar21) & uVar21 - uVar13);
  puVar9 = *(undefined **)(param_1 + 0x10);
  param_5 = (undefined4 *)(iVar6 + (uVar13 & uVar21) * 8);
  puStack_20 = param_5 + 1;
  puVar1 = (undefined *)(uVar21 + 8);
  param_8 = puVar27;
  if (iVar14 == 3) {
    uVar25 = *(uint *)(param_1 + 0x18);
    iVar14 = *(int *)(param_1 + 0x214);
    *(int *)(param_1 + 0x18) = (int)param_2 - iVar4;
    iVar10 = *param_2;
    bVar20 = 0x20 - (char)*(undefined4 *)(param_1 + 0x1c);
    for (; uVar25 < (uint)((int)param_2 - iVar4); uVar25 = uVar25 + 1) {
      *(uint *)(iVar14 + ((uint)(*(int *)(uVar25 + iVar4) * 0x35a7bd00) >> (bVar20 & 0x1f)) * 4) =
           uVar25;
    }
    puVar28 = *(undefined **)(iVar14 + ((uint)(iVar10 * 0x35a7bd00) >> (bVar20 & 0x1f)) * 4);
    if ((puVar9 < puVar28) && (uVar21 - (int)puVar28 < 0x40000)) {
      if ((param_6 == 0) || (puVar8 <= puVar28)) {
        if ((puVar28 + iVar4)[(int)puVar27] != puVar27[(int)param_2]) goto LAB_00aae71f;
        puVar15 = (undefined *)FUN_00abcfb0(param_2,puVar28 + iVar4,param_3);
      }
      else {
        if (*(int *)(puVar28 + iVar7) << 8 != *param_2 << 8) goto LAB_00aae71f;
        iVar14 = FUN_00abd020((int)param_2 + 3,(undefined *)((int)(puVar28 + iVar7) + 3),param_3,
                              puVar22,puVar8 + iVar4);
        puVar15 = (undefined *)(iVar14 + 3);
        puVar27 = param_8;
      }
      if (puVar27 < puVar15) {
        iStack_18 = 1;
        *param_7 = (uVar21 - (int)puVar28) + 3;
        param_7[1] = (int)puVar15;
        puStack_8 = puVar1;
        if ((&DAT_00001000 < puVar15) ||
           (param_8 = puVar15, (uint *)(puVar15 + (int)param_2) == param_3)) goto LAB_00aae907;
      }
    }
  }
LAB_00aae71f:
  *(uint *)(iVar16 + iVar12 * 4) = uVar21;
  puVar27 = puVar1;
joined_r0x00aae72c:
  do {
    puVar19 = param_5;
    puStack_8 = puVar27;
    if ((param_4 == 0) || (param_4 = param_4 + -1, puVar5 <= puVar9)) goto LAB_00aae8f8;
    puVar2 = (undefined4 *)(iVar6 + (uVar13 & (uint)puVar5) * 8);
    puVar28 = puStack_30;
    if (puStack_48 < puStack_30) {
      puVar28 = puStack_48;
    }
    if ((param_6 == 0) || (puVar8 <= puVar28 + (int)puVar5)) {
      puVar15 = puVar5 + iVar4;
      if (puVar15[(int)puVar28] == puVar28[(int)param_2]) {
        puVar17 = (uint *)(puVar28 + (int)param_2 + 1);
        puVar26 = (uint *)(puVar15 + 1 + (int)puVar28);
        puVar18 = puVar17;
        if (puVar17 < (uint *)((int)param_3 + -3)) {
LAB_00aae7f0:
          uVar25 = *puVar26 ^ *puVar18;
          if (uVar25 == 0) break;
          uVar11 = 0;
          if (uVar25 != 0) {
            for (; (uVar25 >> uVar11 & 1) == 0; uVar11 = uVar11 + 1) {
            }
          }
          pcVar24 = (char *)(((uVar11 >> 3) - (int)puVar17) + (int)puVar18);
          goto LAB_00aae82b;
        }
LAB_00aae807:
        if ((puVar18 < (uint *)((int)param_3 + -1)) && (*(short *)puVar26 == *(short *)puVar18)) {
          puVar18 = (uint *)((int)puVar18 + 2);
          puVar26 = (uint *)((int)puVar26 + 2);
        }
        if ((puVar18 < param_3) && (*(char *)puVar26 == *(char *)puVar18)) {
          puVar18 = (uint *)((int)puVar18 + 1);
        }
        pcVar24 = (char *)((int)puVar18 - (int)puVar17);
LAB_00aae82b:
        puVar28 = puVar28 + 1 + (int)pcVar24;
      }
    }
    else {
      puVar15 = puVar5 + iVar7;
      puVar3 = puVar15 + (int)puVar28;
      puVar18 = param_3;
      if (puVar22 + (((int)param_2 + (int)puVar28) - (int)puVar3) < param_3) {
        puVar18 = (uint *)(puVar22 + (((int)param_2 + (int)puVar28) - (int)puVar3));
      }
      iVar16 = FUN_00abcfb0((undefined *)((int)param_2 + (int)puVar28),puVar3,puVar18);
      if (puVar3 + iVar16 == puVar22) {
        iVar14 = FUN_00abcfb0((undefined *)((int)param_2 + (int)puVar28) + iVar16,puVar8 + iVar4,
                              param_3);
        iVar16 = iVar14 + iVar16;
      }
      puVar28 = puVar28 + iVar16;
      if (puVar8 <= puVar28 + (int)puVar5) {
        puVar15 = puVar5 + iVar4;
      }
    }
    puVar19 = param_5;
    if (param_8 < puVar28) {
      puStack_8 = puVar28 + (int)puVar5;
      if (puVar28 <= puVar27 + -(int)puVar5) {
        puStack_8 = puVar27;
      }
      param_7[iStack_18 * 2] = (uVar21 - (int)puVar5) + 3;
      param_7[iStack_18 * 2 + 1] = (int)puVar28;
      iStack_18 = iStack_18 + 1;
      if ((&DAT_00001000 < puVar28) ||
         (param_8 = puVar28, (uint *)((int)param_2 + (int)puVar28) == param_3)) goto LAB_00aae8f8;
    }
    puVar27 = puStack_8;
    if ((byte)puVar15[(int)puVar28] < (byte)puVar28[(int)param_2]) goto code_r0x00aae88d;
    *puStack_20 = puVar5;
    if (puVar5 <= puVar23) {
      puStack_20 = &param_2;
      goto LAB_00aae8f8;
    }
    puVar5 = (undefined *)*puVar2;
    puStack_20 = puVar2;
    puStack_30 = puVar28;
  } while( true );
  puVar18 = puVar18 + 1;
  puVar26 = puVar26 + 1;
  if ((uint *)((int)param_3 + -3) <= puVar18) goto LAB_00aae807;
  goto LAB_00aae7f0;
code_r0x00aae88d:
  *param_5 = puVar5;
  if (puVar23 < puVar5) {
    puVar5 = (undefined *)puVar2[1];
    param_5 = puVar2 + 1;
    puStack_48 = puVar28;
    goto joined_r0x00aae72c;
  }
  puVar19 = &param_2;
LAB_00aae8f8:
  *puStack_20 = 0;
  *puVar19 = 0;
LAB_00aae907:
  puVar27 = puStack_8 + -8;
  if (puStack_8 <= puVar1) {
    puVar27 = (undefined *)(uVar21 + 1);
  }
  *(undefined **)(param_1 + 0x14) = puVar27;
  return iStack_18;
}



/* FUNCTION 22019 ; VA 0x00aae930 ; FUN_00aae930 */

undefined8
FUN_00aae930(int param_1,uint param_2,int param_3,int param_4,uint param_5,int param_6,
            undefined4 param_7,undefined4 param_8,undefined4 param_9,undefined4 param_10,
            int param_11,undefined4 param_12)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined8 uVar5;
  
  uVar3 = param_4 + 1;
  if (uVar3 < param_5) {
    iVar2 = uVar3 - param_6;
    do {
      uVar1 = (uint)*(byte *)(param_6 + -1 + iVar2);
      uVar5 = FUN_016f39b0(uVar1 + 10,0xfffffff5 < uVar1,*(undefined4 *)(param_1 + 8),
                           *(undefined4 *)(param_1 + 0xc));
      uVar5 = FUN_016f39b0(param_2 - (uint)uVar5,
                           (param_3 - (int)((ulonglong)uVar5 >> 0x20)) -
                           (uint)(param_2 < (uint)uVar5),0xb7a56463,0xcf1bbcdc);
      uVar1 = (uint)*(byte *)(param_11 + -1 + uVar3);
      uVar4 = (uint)uVar5 + uVar1;
      param_2 = uVar4 + 10;
      param_3 = (int)((ulonglong)uVar5 >> 0x20) + (uint)CARRY4((uint)uVar5,uVar1) +
                (uint)(0xfffffff5 < uVar4);
      FUN_00aaea60(param_1,param_2,param_3,param_7,iVar2,param_8,param_9,param_10,param_11,param_12)
      ;
      uVar3 = uVar3 + 1;
      iVar2 = iVar2 + 1;
    } while (uVar3 < param_5);
  }
  return CONCAT44(param_3,param_2);
}



/* FUNCTION 22020 ; VA 0x00aae9f0 ; FUN_00aae9f0 */

void FUN_00aae9f0(int param_1,uint param_2)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  undefined8 uVar5;
  undefined4 uStack_8;
  
  uVar3 = 0;
  if (param_2 != 0) {
    uStack_8 = 0;
    iVar4 = uStack_8;
    uStack_8 = 0;
    do {
      bVar1 = *(byte *)(uVar3 + param_1);
      uVar5 = FUN_016f39b0(uStack_8,iVar4,0xb7a56463,0xcf1bbcdc);
      uVar2 = (uint)uVar5 + (uint)bVar1;
      uStack_8 = uVar2 + 10;
      iVar4 = (int)((ulonglong)uVar5 >> 0x20) + (uint)CARRY4((uint)uVar5,(uint)bVar1) +
              (uint)(0xfffffff5 < uVar2);
      uVar3 = uVar3 + 1;
    } while (uVar3 < param_2);
    return;
  }
  return;
}



/* FUNCTION 22021 ; VA 0x00aaea60 ; FUN_00aaea60 */

void FUN_00aaea60(int *param_1,uint param_2,undefined4 param_3,int param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,byte param_8,undefined4 param_9,uint param_10
                 )

{
  int iVar1;
  uint uVar2;
  int iVar3;
  byte *pbVar4;
  uint uVar5;
  
  uVar5 = (1 << ((byte)param_10 & 0x1f)) - 1;
  uVar2 = param_2;
  if (param_10 <= 0x20U - param_4) {
    uVar2 = (uint)(CONCAT44(param_3,param_2) >> (ulonglong)((0x20 - param_10) - param_4));
  }
  if ((uVar5 & uVar2) == uVar5) {
    if (param_4 == 0) {
      iVar3 = 0;
    }
    else {
      iVar3 = (int)(CONCAT44(param_3,param_2) >> (ulonglong)(0x40 - param_4));
    }
    pbVar4 = (byte *)(param_1[1] + iVar3);
    iVar3 = (iVar3 << (param_8 & 0x1f)) + (uint)*pbVar4;
    iVar1 = *param_1;
    *(undefined4 *)(iVar1 + iVar3 * 8) = param_5;
    *(int *)(iVar1 + 4 + iVar3 * 8) =
         (int)(CONCAT44(param_3,param_2) >> (ulonglong)(0x20U - param_4));
    *pbVar4 = ('\x01' << (param_8 & 0x1f)) - 1U & *pbVar4 + 1;
  }
  return;
}



/* FUNCTION 22022 ; VA 0x00aaeb10 ; FUN_00aaeb10 */

undefined4 FUN_00aaeb10(int *param_1,int param_2,uint param_3)

{
  int iVar1;
  int iVar2;
  
  iVar2 = param_1[1];
  param_1[2] = iVar2;
  iVar1 = param_2 + param_3;
  param_1[4] = param_1[3];
  param_2 = (iVar2 - *param_1) + param_2;
  param_1[3] = *param_1 - iVar2;
  param_1[1] = param_2;
  param_1[5] = *param_1 - iVar2;
  *param_1 = iVar1;
  iVar2 = 0;
  if (param_1[0x2f] == 0) {
    iVar2 = iVar1 - param_2;
  }
  param_1[8] = iVar2;
  if (8 < param_3) {
    switch(param_1[0x2a]) {
    case 1:
      FUN_00abd420(param_1,iVar1,param_1[0x28]);
      param_1[5] = iVar1 - param_1[1];
      return 0;
    case 2:
      FUN_00abd300(param_1,iVar1,param_1[0x28]);
      param_1[5] = iVar1 - param_1[1];
      return 0;
    case 3:
    case 4:
    case 5:
      FUN_00abd7f0(param_1,iVar1 + -8,param_1[0x28]);
      param_1[5] = iVar1 - param_1[1];
      return 0;
    case 6:
    case 7:
    case 8:
      FUN_00abda10(param_1,iVar1 + -8,iVar1,1 << ((byte)param_1[0x27] & 0x1f),param_1[0x28]);
    }
    param_1[5] = iVar1 - param_1[1];
  }
  return 0;
}



/* FUNCTION 22023 ; VA 0x00aaec30 ; FUN_00aaec30 */

int FUN_00aaec30(int param_1,int param_2,uint param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint *puVar5;
  uint *puVar6;
  undefined auStack_78 [32];
  undefined auStack_58 [8];
  undefined auStack_50 [68];
  uint uStack_c;
  uint uStack_8;
  
  puVar1 = (uint *)(param_2 + param_3);
  if (8 < param_3) {
    iVar4 = param_2 + 8;
    uVar2 = FUN_00ab2060(param_1 + 0x140c,iVar4,(int)puVar1 - iVar4,param_1 + 0x5410,0x800);
    if (uVar2 < 0xffffff89) {
      iVar4 = iVar4 + uVar2;
      param_3 = 0x1f;
      uStack_c = FUN_00ab1560(auStack_50,&param_3,&uStack_8,iVar4,(int)puVar1 - iVar4);
      if ((uStack_c < 0xffffff89) && (uStack_8 < 9)) {
        uVar2 = FUN_00ab0680(param_1 + 0x804,auStack_50,param_3,uStack_8);
        if (uVar2 < 0xffffff89) {
          iVar4 = iVar4 + uStack_c;
          param_3 = 0x34;
          uStack_8 = FUN_00ab1560(auStack_78,&param_3,&uStack_c,iVar4,(int)puVar1 - iVar4);
          if ((uStack_8 < 0xffffff89) && (uStack_c < 10)) {
            uVar2 = FUN_00ab0680(param_1 + 0xc08,auStack_78,param_3,uStack_c);
            if (uVar2 < 0xffffff89) {
              iVar4 = iVar4 + uStack_8;
              param_3 = 0x23;
              uStack_8 = FUN_00ab1560(auStack_58,&param_3,&uStack_c,iVar4,(int)puVar1 - iVar4);
              if ((uStack_8 < 0xffffff89) && (uStack_c < 10)) {
                uVar2 = FUN_00ab0680(param_1,auStack_58,param_3,uStack_c);
                if ((uVar2 < 0xffffff89) &&
                   (puVar5 = (uint *)(iVar4 + uStack_8), puVar5 + 3 <= puVar1)) {
                  iVar3 = 0;
                  iVar4 = -0xc - (int)puVar5;
                  puVar6 = (uint *)(param_1 + 0x5c10);
                  while( true ) {
                    uVar2 = *puVar5;
                    puVar5 = puVar5 + 1;
                    if ((uVar2 == 0) || ((uint)((int)puVar1 + iVar4) <= uVar2)) break;
                    *puVar6 = uVar2;
                    iVar3 = iVar3 + 1;
                    puVar6 = puVar6 + 1;
                    if (2 < iVar3) {
                      return (int)puVar5 - param_2;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return -0x1e;
}



/* FUNCTION 22024 ; VA 0x00aaedd0 ; FUN_00aaedd0 */

uint FUN_00aaedd0(int param_1,uint *param_2,uint param_3)

{
  short *psVar1;
  char *pcVar2;
  byte bVar3;
  short sVar4;
  uint *puVar5;
  ushort uVar6;
  uint uVar7;
  undefined4 uVar8;
  byte *pbVar9;
  char *pcVar10;
  uint uVar11;
  uint uVar12;
  uint *puVar13;
  int iVar14;
  int iVar15;
  uint *puVar16;
  char acStack_1fc [256];
  undefined auStack_fc [32];
  undefined auStack_dc [76];
  int aiStack_90 [16];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  uint uStack_10;
  undefined4 uStack_c;
  uint *puStack_8;
  
  puStack_8 = (uint *)(param_3 + (int)param_2);
  uStack_c = 0x1f;
  if (*(int *)(param_1 + 0xb4) == 0) {
    uVar8 = *(undefined4 *)((int)param_2 + 4);
  }
  else {
    uVar8 = 0;
  }
  iVar14 = (int)param_2 + 8;
  *(undefined4 *)(param_1 + 0x28) = uVar8;
  param_3 = *(int *)(param_1 + 0x21c);
  uStack_10 = 0;
  param_2 = (uint *)0x0;
  iStack_14 = iVar14;
  uStack_18 = FUN_00ab2360(acStack_1fc,0x100,aiStack_90,&param_2,&uStack_10,iVar14,
                           (int)puStack_8 - iVar14);
  uVar11 = uStack_10;
  if (((uStack_18 < 0xffffff89) && (uStack_10 < 0xd)) && (param_2 < 0x101)) {
    uVar12 = 1;
    if (uStack_10 != 0) {
      iVar15 = 0;
      do {
        iVar14 = aiStack_90[uVar12];
        aiStack_90[uVar12] = iVar15;
        iVar15 = iVar15 + (iVar14 << ((char)uVar12 - 1U & 0x1f));
        uVar12 = uVar12 + 1;
        iVar14 = iStack_14;
      } while (uVar12 <= uVar11);
    }
    uVar12 = 0;
    if (param_2 != (uint *)0x0) {
      pcVar10 = (char *)(param_3 + 2);
      do {
        pcVar2 = acStack_1fc + uVar12;
        uVar12 = uVar12 + 1;
        *pcVar10 = ((char)uVar11 - *pcVar2) + '\x01';
        pcVar10 = pcVar10 + 4;
      } while (uVar12 < param_2);
    }
    uStack_1c = 0;
    uStack_24 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    uStack_34 = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_50 = 0;
    uStack_4c = 0;
    uStack_48 = 0;
    uStack_44 = 0;
    if (param_2 != (uint *)0x0) {
      pbVar9 = (byte *)(param_3 + 2);
      uVar12 = (uint)param_2;
      do {
        bVar3 = *pbVar9;
        pbVar9 = pbVar9 + 4;
        psVar1 = (short *)((int)&uStack_34 + (uint)bVar3 * 2);
        *psVar1 = *psVar1 + 1;
        uVar12 = uVar12 - 1;
      } while (uVar12 != 0);
    }
    uVar6 = 0;
    *(undefined2 *)((int)&uStack_50 + uVar11 * 2 + 2) = 0;
    for (; uVar11 != 0; uVar11 = uVar11 - 1) {
      *(ushort *)((int)&uStack_50 + uVar11 * 2) = uVar6;
      uVar6 = (ushort)(*(short *)((int)&uStack_34 + uVar11 * 2) + uVar6) >> 1;
    }
    uVar11 = 0;
    if (param_2 != (uint *)0x0) {
      do {
        uVar12 = (uint)*(byte *)(param_3 + 2 + uVar11 * 4);
        sVar4 = *(short *)((int)&uStack_50 + uVar12 * 2);
        *(short *)(param_3 + uVar11 * 4) = sVar4;
        uVar11 = uVar11 + 1;
        *(short *)((int)&uStack_50 + uVar12 * 2) = sVar4 + 1;
        iVar14 = iStack_14;
      } while (uVar11 < param_2);
    }
    puVar5 = puStack_8;
    if (0xfe < (int)param_2 - 1U) {
      iVar14 = iVar14 + uStack_18;
      param_3 = FUN_00ab1560(aiStack_90,&uStack_c,&param_2,iVar14,(int)puStack_8 - iVar14);
      if (((param_3 < 0xffffff89) && (param_2 < 9)) &&
         (uVar11 = FUN_00ab0480(*(int *)(param_1 + 0x21c) + 0x400,aiStack_90,uStack_c,param_2,
                                *(int *)(param_1 + 0x21c) + 0x11d4,0x1800), uVar11 < 0xffffff89)) {
        iVar14 = iVar14 + param_3;
        param_2 = (uint *)0x34;
        puStack_8 = (uint *)FUN_00ab1560(auStack_fc,&param_2,&param_3,iVar14,(int)puVar5 - iVar14);
        if ((puStack_8 < 0xffffff89) && (param_3 < 10)) {
          uVar11 = FUN_00aa9590(auStack_fc,param_2,0x34);
          if (0xffffff88 < uVar11) {
            return uVar11;
          }
          uVar11 = FUN_00ab0480(*(int *)(param_1 + 0x21c) + 0x704,auStack_fc,param_2,param_3,
                                *(int *)(param_1 + 0x21c) + 0x11d4,0x1800);
          if (uVar11 < 0xffffff89) {
            iVar14 = iVar14 + (int)puStack_8;
            param_2 = (uint *)0x23;
            puStack_8 = (uint *)FUN_00ab1560(auStack_dc,&param_2,&param_3,iVar14,
                                             (int)puVar5 - iVar14);
            if ((puStack_8 < 0xffffff89) && (param_3 < 10)) {
              uVar11 = FUN_00aa9590(auStack_dc,param_2,0x23);
              if (0xffffff88 < uVar11) {
                return uVar11;
              }
              uVar11 = FUN_00ab0480(*(int *)(param_1 + 0x21c) + 0xcb0,auStack_dc,param_2,param_3,
                                    *(int *)(param_1 + 0x21c) + 0x11d4,0x1800);
              if (uVar11 < 0xffffff89) {
                puVar16 = (uint *)(iVar14 + (int)puStack_8);
                param_2 = puVar16 + 3;
                if (param_2 <= puVar5) {
                  puVar13 = (uint *)(param_1 + 0x194);
                  uVar12 = (int)puVar5 - (int)param_2;
                  uVar11 = 0x1f;
                  *puVar13 = *puVar16;
                  *(uint *)(param_1 + 0x198) = puVar16[1];
                  *(uint *)(param_1 + 0x19c) = puVar16[2];
                  if (uVar12 < 0xfffe0000) {
                    uVar11 = 0x1f;
                    if (uVar12 + 0x20000 != 0) {
                      for (; uVar12 + 0x20000 >> uVar11 == 0; uVar11 = uVar11 - 1) {
                      }
                    }
                  }
                  uVar7 = 0x1f;
                  if (uVar11 < 0x1f) {
                    uVar7 = uVar11;
                  }
                  uVar11 = FUN_00aa9590(aiStack_90,uStack_c,uVar7);
                  if (0xffffff88 < uVar11) {
                    return uVar11;
                  }
                  uVar11 = 0;
                  while ((*puVar13 != 0 && (*puVar13 <= uVar12))) {
                    uVar11 = uVar11 + 1;
                    puVar13 = puVar13 + 1;
                    if (2 < uVar11) {
                      *(undefined4 *)(*(int *)(param_1 + 0x21c) + 0x29d4) = 2;
                      *(undefined4 *)(*(int *)(param_1 + 0x21c) + 0x29d8) = 2;
                      *(undefined4 *)(*(int *)(param_1 + 0x21c) + 0x29dc) = 2;
                      *(undefined4 *)(*(int *)(param_1 + 0x21c) + 0x29e0) = 2;
                      uVar11 = FUN_00aaeb10(param_1,param_2,uVar12);
                      return uVar11;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return 0xffffffe2;
}



/* FUNCTION 22025 ; VA 0x00aaf1f0 ; FUN_00aaf1f0 */

uint FUN_00aaf1f0(int *param_1,uint param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  
  iVar1 = (uint)(0xfff < param_4) + (0x1f < param_4) + 1;
  if (param_2 < iVar1 + param_4) {
    return 0xffffffba;
  }
  if (iVar1 == 1) {
    *(char *)param_1 = (char)param_4 << 3;
  }
  else if (iVar1 == 2) {
    *(short *)param_1 = (short)(param_4 << 4) + 4;
  }
  else if (iVar1 == 3) {
    *param_1 = param_4 * 0x10 + 0xc;
  }
  FUN_0170c6f0((char *)(iVar1 + (int)param_1),param_3,param_4);
  return iVar1 + param_4;
}



/* FUNCTION 22026 ; VA 0x00aaf270 ; FUN_00aaf270 */

int FUN_00aaf270(int *param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (param_2 == 3) {
    iVar1 = iVar1 << 8;
  }
  return iVar1;
}



/* FUNCTION 22027 ; VA 0x00aaf290 ; FUN_00aaf290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00aaf290(int *param_1,int param_2,uint param_3)

{
  int iVar1;
  byte *pbVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  
  param_1[0x14] = 0;
  param_1[0x13] = 0;
  param_1[0x12] = 0;
  param_1[0x11] = 0;
  if (param_1[8] == 0) {
    if (param_3 < 0x401) {
      param_1[0x11] = 1;
    }
    piVar9 = (int *)*param_1;
    if ((param_1 < piVar9) || (piVar9 + 0xff < param_1)) {
      for (iVar8 = 0x100; iVar8 != 0; iVar8 = iVar8 + -1) {
        *piVar9 = 0;
        piVar9 = piVar9 + 1;
      }
    }
    else {
      uVar7 = 0;
      do {
        *(undefined4 *)(uVar7 + *param_1) = 0;
        uVar7 = uVar7 + 4;
      } while (uVar7 < 0x3fd);
    }
    uVar7 = 0;
    if (param_3 != 0) {
      do {
        pbVar2 = (byte *)(uVar7 + param_2);
        uVar7 = uVar7 + 1;
        piVar9 = (int *)(*param_1 + (uint)*pbVar2 * 4);
        *piVar9 = *piVar9 + 1;
      } while (uVar7 < param_3);
    }
    iVar8 = *param_1;
    uVar7 = 0;
    param_1[9] = 0;
    param_1[8] = 0x24;
    param_1[6] = 0x35;
    param_1[10] = 0x20;
    param_1[7] = 0x200;
    do {
      *(uint *)(iVar8 + uVar7) = (*(uint *)(iVar8 + uVar7) >> 4) + 1;
      iVar8 = *param_1;
      piVar9 = (int *)(iVar8 + uVar7);
      uVar7 = uVar7 + 4;
      param_1[9] = param_1[9] + *piVar9;
      iVar5 = _UNK_018e003c;
      iVar4 = _UNK_018e0038;
      iVar1 = _UNK_018e0034;
      iVar6 = _DAT_018e0030;
    } while (uVar7 < 0x3fd);
    piVar10 = (int *)param_1[1];
    piVar9 = param_1 + 1;
    if ((piVar9 < piVar10) || (piVar10 + 0x23 < piVar9)) {
      *piVar10 = _DAT_018e0030;
      piVar10[1] = iVar1;
      piVar10[2] = iVar4;
      piVar10[3] = iVar5;
      piVar10[4] = iVar6;
      piVar10[5] = iVar1;
      piVar10[6] = iVar4;
      piVar10[7] = iVar5;
      piVar10[8] = iVar6;
      piVar10[9] = iVar1;
      piVar10[10] = iVar4;
      piVar10[0xb] = iVar5;
      piVar10[0xc] = iVar6;
      piVar10[0xd] = iVar1;
      piVar10[0xe] = iVar4;
      piVar10[0xf] = iVar5;
      piVar10[0x10] = iVar6;
      piVar10[0x11] = iVar1;
      piVar10[0x12] = iVar4;
      piVar10[0x13] = iVar5;
      piVar10[0x14] = iVar6;
      piVar10[0x15] = iVar1;
      piVar10[0x16] = iVar4;
      piVar10[0x17] = iVar5;
      piVar10[0x18] = iVar6;
      piVar10[0x19] = iVar1;
      piVar10[0x1a] = iVar4;
      piVar10[0x1b] = iVar5;
      piVar10[0x1c] = iVar6;
      piVar10[0x1d] = iVar1;
      piVar10[0x1e] = iVar4;
      piVar10[0x1f] = iVar5;
      piVar10[0x20] = iVar6;
      piVar10[0x21] = iVar1;
      piVar10[0x22] = iVar4;
      piVar10[0x23] = iVar5;
    }
    else {
      uVar7 = 0;
      do {
        *(undefined4 *)(uVar7 + *piVar9) = 1;
        uVar7 = uVar7 + 4;
      } while (uVar7 < 0x8d);
    }
    piVar10 = (int *)param_1[2];
    piVar9 = param_1 + 2;
    uVar7 = 0;
    if ((piVar9 < piVar10) || (piVar10 + 0x34 < piVar9)) {
      uVar7 = 0x34;
      for (iVar8 = 0x34; iVar8 != 0; iVar8 = iVar8 + -1) {
        *piVar10 = 1;
        piVar10 = piVar10 + 1;
      }
    }
    do {
      *(undefined4 *)(*piVar9 + uVar7 * 4) = 1;
      iVar5 = _UNK_018e003c;
      iVar4 = _UNK_018e0038;
      iVar1 = _UNK_018e0034;
      iVar8 = _DAT_018e0030;
      uVar7 = uVar7 + 1;
    } while (uVar7 < 0x35);
    piVar10 = (int *)param_1[3];
    piVar9 = param_1 + 3;
    if ((piVar9 < piVar10) || (piVar10 + 0x1f < piVar9)) {
      iVar6 = param_1[10];
      *piVar10 = _DAT_018e0030;
      piVar10[1] = iVar1;
      piVar10[2] = iVar4;
      piVar10[3] = iVar5;
      piVar10[4] = iVar8;
      piVar10[5] = iVar1;
      piVar10[6] = iVar4;
      piVar10[7] = iVar5;
      piVar10[8] = iVar8;
      piVar10[9] = iVar1;
      piVar10[10] = iVar4;
      piVar10[0xb] = iVar5;
      piVar10[0xc] = iVar8;
      piVar10[0xd] = iVar1;
      piVar10[0xe] = iVar4;
      piVar10[0xf] = iVar5;
      piVar10[0x10] = iVar8;
      piVar10[0x11] = iVar1;
      piVar10[0x12] = iVar4;
      piVar10[0x13] = iVar5;
      piVar10[0x14] = iVar8;
      piVar10[0x15] = iVar1;
      piVar10[0x16] = iVar4;
      piVar10[0x17] = iVar5;
      piVar10[0x18] = iVar8;
      piVar10[0x19] = iVar1;
      piVar10[0x1a] = iVar4;
      piVar10[0x1b] = iVar5;
      piVar10[0x1c] = iVar8;
      piVar10[0x1d] = iVar1;
      piVar10[0x1e] = iVar4;
      piVar10[0x1f] = iVar5;
    }
    else {
      uVar7 = 0;
      do {
        *(undefined4 *)(uVar7 + *piVar9) = 1;
        uVar7 = uVar7 + 4;
      } while (uVar7 < 0x7d);
      iVar6 = param_1[10];
    }
  }
  else {
    iVar8 = *param_1;
    uVar7 = 0;
    param_1[6] = 0;
    param_1[8] = 0;
    param_1[10] = 0;
    param_1[7] = 0;
    param_1[9] = 0;
    do {
      *(uint *)(iVar8 + uVar7) = (*(uint *)(iVar8 + uVar7) >> 5) + 1;
      iVar8 = *param_1;
      piVar9 = (int *)(iVar8 + uVar7);
      uVar7 = uVar7 + 4;
      param_1[9] = param_1[9] + *piVar9;
    } while (uVar7 < 0x3fd);
    iVar8 = param_1[1];
    uVar7 = 0;
    do {
      *(uint *)(iVar8 + uVar7) = (*(uint *)(iVar8 + uVar7) >> 5) + 1;
      iVar8 = param_1[1];
      piVar9 = (int *)(iVar8 + uVar7);
      uVar7 = uVar7 + 4;
      param_1[8] = param_1[8] + *piVar9;
    } while (uVar7 < 0x8d);
    iVar8 = param_1[2];
    uVar7 = 0;
    do {
      *(uint *)(iVar8 + uVar7 * 4) = (*(uint *)(iVar8 + uVar7 * 4) >> 4) + 1;
      iVar8 = param_1[2];
      param_1[6] = param_1[6] + *(int *)(iVar8 + uVar7 * 4);
      iVar6 = uVar7 + 3;
      iVar1 = uVar7 * 4;
      uVar7 = uVar7 + 1;
      iVar6 = iVar6 * *(int *)(iVar8 + iVar1) + param_1[7];
      param_1[7] = iVar6;
    } while (uVar7 < 0x35);
    iVar8 = param_1[3];
    param_1[7] = iVar6 * 2;
    uVar7 = 0;
    do {
      *(uint *)(iVar8 + uVar7) = (*(uint *)(iVar8 + uVar7) >> 4) + 1;
      iVar8 = param_1[3];
      piVar9 = (int *)(iVar8 + uVar7);
      uVar7 = uVar7 + 4;
      iVar6 = *piVar9 + param_1[10];
      param_1[10] = iVar6;
    } while (uVar7 < 0x7d);
  }
  iVar8 = 0x1f;
  if (param_1[6] + 1U != 0) {
    for (; param_1[6] + 1U >> iVar8 == 0; iVar8 = iVar8 + -1) {
    }
  }
  uVar3 = param_1[9];
  param_1[0xb] = iVar8;
  uVar7 = param_1[8] + 1;
  iVar8 = 0x1f;
  if (uVar7 != 0) {
    for (; uVar7 >> iVar8 == 0; iVar8 = iVar8 + -1) {
    }
  }
  param_1[0xd] = iVar8;
  iVar8 = 0x1f;
  if (uVar3 + 1 != 0) {
    for (; uVar3 + 1 >> iVar8 == 0; iVar8 = iVar8 + -1) {
    }
  }
  param_1[0xe] = iVar8;
  iVar8 = 0x1f;
  if (iVar6 + 1U != 0) {
    for (; iVar6 + 1U >> iVar8 == 0; iVar8 = iVar8 + -1) {
    }
  }
  param_1[0xf] = iVar8;
  param_1[0x10] = (uVar3 >> 5) / (uint)param_1[8] + 1 + (uVar3 * 2) / (param_1[7] + uVar3);
  return;
}



/* FUNCTION 22028 ; VA 0x00aaf580 ; FUN_00aaf580 */

undefined4
FUN_00aaf580(int *param_1,int param_2,uint param_3,int param_4,int param_5,int param_6,uint param_7,
            int param_8,int param_9,int param_10,int param_11,int param_12,int param_13,int param_14
            ,int param_15,int param_16,int param_17,int param_18,uint param_19,uint param_20,
            int param_21,int param_22,int param_23,int param_24,int param_25,uint param_26,
            uint param_27,int param_28,int param_29)

{
  undefined8 uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  byte bVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  bool bVar14;
  undefined8 uVar15;
  undefined8 uVar16;
  code *pcStack_44;
  code *pcStack_40;
  int iStack_20;
  uint uStack_10;
  uint uStack_c;
  int iStack_8;
  
  uStack_10 = param_20;
  uStack_c = param_19;
  if (param_28 == 0) {
    uVar2 = 0x11;
    if ((uint)param_1[0x24] < 0x11) {
      uVar2 = param_1[0x24];
    }
    uVar13 = 0x11;
    if (param_3 < 0x11) {
      uVar13 = param_3;
    }
    if (param_5 != param_1[0x26] ||
        (param_4 != param_1[0x25] ||
        ((uVar13 != uVar2 || (param_1[0x28] != 3) == (param_7 == 3)) || param_9 != param_1[0x2a])))
    goto LAB_00aaf7f5;
    if (param_18 != 0) {
      if ((((param_18 == param_1[0x33]) && (param_19 == param_1[0x34])) &&
          (param_20 == param_1[0x35])) &&
         ((param_21 == param_1[0x36] && (param_22 == param_1[0x37])))) goto LAB_00aaf6ba;
      goto LAB_00aaf7f5;
    }
    if (param_1[0x33] == 0) {
LAB_00aaf6ba:
      *(undefined4 *)(param_1[0x87] + 0x29d4) = 0;
      *(undefined4 *)(param_1[0x87] + 0x29d8) = 0;
      *(undefined4 *)(param_1[0x87] + 0x29dc) = 0;
      *(undefined4 *)(param_1[0x87] + 0x29e0) = 0;
      iVar4 = *param_1 - param_1[1];
      param_1[0x23] = param_2;
      param_1[0x24] = param_3;
      param_1[0x25] = param_4;
      param_1[0x26] = param_5;
      param_1[0x3e] = param_26 + 1;
      param_1[0x3f] = param_27 + (0xfffffffe < param_26);
      param_1[0x40] = 0;
      param_1[0x41] = 0;
      param_1[0x27] = param_6;
      param_1[0x28] = param_7;
      param_1[0x29] = param_8;
      param_1[0x2a] = param_9;
      param_1[0x2b] = param_10;
      param_1[0x2c] = param_11;
      param_1[0x2d] = param_12;
      param_1[0x2e] = param_13;
      param_1[0x2f] = param_14;
      param_1[0x30] = param_15;
      param_1[0x31] = param_16;
      param_1[0x32] = param_17;
      param_1[0x33] = param_18;
      param_1[0x34] = param_19;
      param_1[0x35] = param_20;
      param_1[0x36] = param_21;
      param_1[0x37] = param_22;
      param_1[0x38] = param_23;
      param_1[0x39] = param_24;
      param_1[0x3a] = param_25;
      if ((param_26 & param_27) == 0xffffffff) {
        param_1[0x2b] = 0;
      }
      param_1[4] = iVar4;
      param_1[3] = iVar4;
      param_1[5] = iVar4 + 1;
      param_1[9] = 1;
      param_1[10] = 0;
      param_1[8] = 0;
      param_1[0x65] = 1;
      param_1[0x66] = 4;
      param_1[0x67] = 8;
      param_1[0x73] = 0;
      FUN_00ab2b00(param_1 + 0x42,0,0);
      return 0;
    }
  }
  else {
LAB_00aaf7f5:
    if (param_18 != 0) {
      if (param_19 == 0) {
        uStack_c = param_3 - 7;
        if (param_3 - 7 < 6) {
          uStack_c = 6;
        }
      }
      if (param_22 == 9999) {
        if (param_3 < uStack_c) {
          param_22 = 0;
        }
        else {
          param_22 = param_3 - uStack_c;
        }
      }
      if (uStack_c <= param_20) {
        param_20 = uStack_c;
      }
      uVar15 = 1;
      uVar1 = 1;
      if (param_21 - 1U != 0) {
        uVar16 = 0xcf1bbcdcb7a56463;
        uVar2 = param_21 - 1U;
        do {
          if ((uVar2 & 1) != 0) {
            uVar15 = FUN_016f39b0(uVar16,uVar15);
          }
          uVar16 = FUN_016f39b0(uVar16,uVar16);
          bVar14 = 1 < uVar2;
          uVar2 = uVar2 >> 1;
          uVar1 = uVar15;
        } while (bVar14);
      }
      *(undefined8 *)(param_1 + 0x82) = uVar1;
      param_19 = uStack_c;
      uStack_10 = param_20;
    }
  }
  uVar13 = 1 << ((byte)param_3 & 0x1f);
  uVar2 = uVar13;
  if (0x20000 < uVar13) {
    uVar2 = 0x20000;
  }
  uVar3 = uVar2 / ((param_7 != 3) + 3);
  if (param_9 == 1) {
    uStack_c = 0;
  }
  else {
    uStack_c = 1 << ((byte)param_4 & 0x1f);
  }
  iVar4 = 1 << ((byte)param_5 & 0x1f);
  if (param_7 < 4) {
    uVar5 = param_3;
    if (0x11 < param_3) {
      uVar5 = 0x11;
    }
  }
  else {
    uVar5 = 0;
  }
  iVar6 = 1 << ((byte)uVar5 & 0x1f);
  iVar7 = (iVar6 + iVar4 + uStack_c) * 4;
  if (param_29 == 1) {
    if (uVar2 < 0x20000) {
      uVar11 = 0x20000 - uVar2 >> 0xb;
    }
    else {
      uVar11 = 0;
    }
    iVar12 = uVar2 + 1 + (uVar2 >> 8) + uVar11;
    iVar8 = uVar13 + uVar2;
  }
  else {
    iVar12 = 0;
    iVar8 = 0;
  }
  if ((param_9 == 7) || (iStack_20 = 0x29e4, param_9 == 8)) {
    iStack_20 = 0x26fec;
  }
  bVar10 = (byte)param_19;
  if (param_18 == 0) {
    iVar9 = 0;
  }
  else {
    uVar13 = param_19;
    if (uStack_10 < param_19) {
      uVar13 = uStack_10;
    }
    iVar9 = (1 << (bVar10 - (char)uVar13 & 0x1f)) + (1 << (bVar10 & 0x1f)) * 8;
  }
  uVar13 = uVar3 * 0xb + uVar2 + iStack_20 + iVar9 + iVar8 + iVar12 + iVar7;
  if ((uint)param_1[0x3c] < uVar13) {
    if (param_1[0x5b] == 0) {
      param_1[0x3c] = 0;
      if (param_1[0x3b] != 0) {
        pcStack_40 = (code *)((ulonglong)*(undefined8 *)(param_1 + 0x58) >> 0x20);
        if (pcStack_40 == (code *)0x0) {
          FUN_017168b0(param_1[0x3b]);
        }
        else {
          (*pcStack_40)(param_1[0x5a]);
        }
      }
      pcStack_44 = (code *)*(undefined8 *)(param_1 + 0x58);
      if (pcStack_44 == (code *)0x0) {
        iVar9 = FUN_0171e1f2(uVar13);
      }
      else {
        iVar9 = (*pcStack_44)(param_1[0x5a]);
      }
      param_1[0x3b] = iVar9;
      if (iVar9 != 0) {
        param_1[0x3c] = uVar13;
        param_1[0x87] = iVar9;
        goto LAB_00aafa89;
      }
    }
    return 0xffffffc0;
  }
LAB_00aafa89:
  param_1[0x23] = param_2;
  param_1[0x24] = param_3;
  param_1[0x25] = param_4;
  param_1[0x26] = param_5;
  param_1[0x3e] = param_26 + 1;
  param_1[0x3f] = param_27 + (0xfffffffe < param_26);
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x27] = param_6;
  param_1[0x28] = param_7;
  param_1[0x29] = param_8;
  param_1[0x2a] = param_9;
  param_1[0x2b] = param_10;
  param_1[0x2c] = param_11;
  param_1[0x2d] = param_12;
  param_1[0x2e] = param_13;
  param_1[0x2f] = param_14;
  param_1[0x30] = param_15;
  param_1[0x31] = param_16;
  param_1[0x32] = param_17;
  param_1[0x33] = param_18;
  param_1[0x34] = param_19;
  param_1[0x35] = uStack_10;
  param_1[0x36] = param_21;
  param_1[0x37] = param_22;
  param_1[0x38] = param_23;
  param_1[0x39] = param_24;
  param_1[0x3a] = param_25;
  if ((param_26 & param_27) == 0xffffffff) {
    param_1[0x2b] = 0;
  }
  param_1[0x3d] = uVar2;
  FUN_00ab2b00(param_1 + 0x42,0,0);
  param_1[9] = 1;
  param_1[10] = 0;
  param_1[8] = 0;
  *(undefined4 *)(param_1[0x87] + 0x29d4) = 0;
  *(undefined4 *)(param_1[0x87] + 0x29d8) = 0;
  *(undefined4 *)(param_1[0x87] + 0x29dc) = 0;
  *(undefined4 *)(param_1[0x87] + 0x29e0) = 0;
  param_1[5] = 1;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[0x65] = 1;
  param_1[0x66] = 4;
  param_1[0x67] = 8;
  iVar9 = param_1[0x87];
  param_1[7] = uVar5;
  iStack_8 = iVar9 + 0x29e4;
  param_1[0x73] = 0;
  if ((param_9 == 7) || (param_9 == 8)) {
    param_1[0x6b] = iStack_8;
    param_1[0x6c] = iVar9 + 0x2de4;
    param_1[0x6d] = iVar9 + 0x2e74;
    param_1[0x6e] = iVar9 + 0x2f48;
    param_1[0x6f] = iVar9 + 0x2fc8;
    param_1[0x70] = iVar9 + 0xafd0;
    iStack_8 = iVar9 + 0x26fec;
  }
  if (param_18 != 0) {
    iVar9 = (1 << (bVar10 & 0x1f)) * 8;
    FUN_0170d1f0(iStack_8,0,iVar9);
    param_1[0x80] = iStack_8;
    iStack_8 = iStack_8 + iVar9;
  }
  if (param_28 != 1) {
    FUN_0170d1f0(iStack_8,0,iVar7);
  }
  param_1[0x84] = iStack_8;
  iStack_8 = iStack_8 + iVar4 * 4;
  param_1[0x86] = iStack_8;
  iStack_8 = iStack_8 + uStack_c * 4;
  param_1[0x85] = iStack_8;
  iStack_8 = iStack_8 + iVar6 * 4;
  param_1[0x5c] = iStack_8;
  iStack_8 = iStack_8 + uVar3 * 8;
  param_1[0x60] = iStack_8;
  iStack_8 = iStack_8 + uVar3;
  param_1[0x61] = iStack_8;
  iStack_8 = iStack_8 + uVar3;
  param_1[0x62] = iStack_8;
  iStack_8 = iStack_8 + uVar3;
  iVar4 = uVar2 + iStack_8;
  param_1[0x5e] = iStack_8;
  if (param_18 != 0) {
    iVar6 = 1 << (bVar10 - (char)uStack_10 & 0x1f);
    FUN_0170d1f0(iVar4,0,iVar6);
    param_1[0x81] = iVar4;
    iVar4 = iVar4 + iVar6;
  }
  param_1[0x89] = iVar8;
  param_1[0x88] = iVar4;
  param_1[0x8d] = iVar8 + iVar4;
  param_1[0x8e] = iVar12;
  return 0;
}



/* FUNCTION 22029 ; VA 0x00aafd30 ; FUN_00aafd30 */

undefined4 FUN_00aafd30(int *param_1,uint param_2,uint param_3,char param_4,int param_5)

{
  if ((param_2 == param_3) && ((param_5 == 0 || (2 < param_3)))) {
    *param_1 = 1;
    return 1;
  }
  if (param_5 != 0) {
    if ((*param_1 == 2) && (param_3 < 1000)) {
      return 3;
    }
    if ((param_3 < 0x40) || (param_2 < param_3 >> (param_4 - 1U & 0x1f))) {
      *param_1 = 2;
      return 0;
    }
  }
  *param_1 = 1;
  return 2;
}



/* FUNCTION 22030 ; VA 0x00aafda0 ; FUN_00aafda0 */

void FUN_00aafda0(int *param_1,uint param_2,int param_3,int param_4,uint param_5)

{
  byte *pbVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  byte bVar5;
  uint uVar6;
  
  param_1[9] = param_1[9] + param_2 * 2;
  uVar6 = 0;
  if (param_2 != 0) {
    do {
      pbVar1 = (byte *)(uVar6 + param_3);
      uVar6 = uVar6 + 1;
      piVar2 = (int *)(*param_1 + (uint)*pbVar1 * 4);
      *piVar2 = *piVar2 + 2;
    } while (uVar6 < param_2);
  }
  if (param_2 < 0x40) {
    bVar5 = (&DAT_01947908)[param_2];
  }
  else {
    iVar4 = 0x1f;
    if (param_2 != 0) {
      for (; param_2 >> iVar4 == 0; iVar4 = iVar4 + -1) {
      }
    }
    bVar5 = (char)iVar4 + 0x13;
  }
  piVar2 = (int *)(param_1[1] + (uint)bVar5 * 4);
  *piVar2 = *piVar2 + 1;
  param_1[8] = param_1[8] + 1;
  param_1[10] = param_1[10] + 1;
  uVar6 = 0x1f;
  if (param_4 + 1U != 0) {
    for (; param_4 + 1U >> uVar6 == 0; uVar6 = uVar6 - 1) {
    }
  }
  piVar2 = (int *)(param_1[3] + (uVar6 & 0xff) * 4);
  *piVar2 = *piVar2 + 1;
  if (param_5 < 0x80) {
    bVar5 = (&DAT_01947948)[param_5];
  }
  else {
    iVar4 = 0x1f;
    if (param_5 != 0) {
      for (; param_5 >> iVar4 == 0; iVar4 = iVar4 + -1) {
      }
    }
    bVar5 = (char)iVar4 + 0x24;
  }
  piVar2 = (int *)(param_1[2] + (uint)bVar5 * 4);
  *piVar2 = *piVar2 + 1;
  param_1[6] = param_1[6] + 1;
  iVar4 = 0x1f;
  if (param_1[6] + 1U != 0) {
    for (; param_1[6] + 1U >> iVar4 == 0; iVar4 = iVar4 + -1) {
    }
  }
  uVar3 = param_1[9];
  param_1[0xb] = iVar4;
  uVar6 = param_1[8] + 1;
  iVar4 = 0x1f;
  if (uVar6 != 0) {
    for (; uVar6 >> iVar4 == 0; iVar4 = iVar4 + -1) {
    }
  }
  param_1[0xd] = iVar4;
  iVar4 = 0x1f;
  if (uVar3 + 1 != 0) {
    for (; uVar3 + 1 >> iVar4 == 0; iVar4 = iVar4 + -1) {
    }
  }
  param_1[0xe] = iVar4;
  iVar4 = 0x1f;
  if (param_1[10] + 1U != 0) {
    for (; param_1[10] + 1U >> iVar4 == 0; iVar4 = iVar4 + -1) {
    }
  }
  param_1[0xf] = iVar4;
  param_1[0x10] = (uVar3 >> 5) / (uint)param_1[8] + 1 + (uVar3 * 2) / (param_1[7] + uVar3);
  return;
}



/* FUNCTION 22031 ; VA 0x00aafea0 ; FUN_00aafea0 */

int FUN_00aafea0(undefined4 *param_1,uint param_2,int param_3,byte param_4)

{
  bool bVar1;
  char cVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int in_stack_0000002c;
  int in_stack_00000030;
  int in_stack_00000034;
  uint in_stack_0000006c;
  int in_stack_00000070;
  uint in_stack_00000074;
  
  iVar6 = ((2 - (uint)(in_stack_00000074 < 0x10000)) - (uint)(in_stack_00000074 < 0x100)) +
          (uint)(in_stack_00000074 != 0);
  if (in_stack_00000034 != 0) {
    iVar6 = 0;
  }
  if (((in_stack_0000002c == 0) || (in_stack_00000070 != 0)) ||
     ((uint)(1 << (param_4 & 0x1f)) < in_stack_0000006c)) {
    bVar1 = false;
  }
  else {
    bVar1 = true;
  }
  if (in_stack_0000002c == 0) {
    cVar2 = '\0';
  }
  else {
    if ((in_stack_00000070 == 0) && (in_stack_0000006c < 0x100)) {
      cVar2 = '\0';
    }
    else {
      cVar2 = '\x01';
    }
    if ((in_stack_00000070 == 0) && (in_stack_0000006c < 0x10100)) {
      cVar3 = '\0';
    }
    else {
      cVar3 = '\x01';
    }
    if ((in_stack_00000070 == 0) && (in_stack_0000006c != 0xffffffff)) {
      cVar2 = cVar3 + cVar2;
    }
    else {
      cVar2 = cVar3 + '\x01' + cVar2;
    }
  }
  iVar4 = 0;
  if (0x11 < param_2) {
    if (param_3 == 0) {
      *param_1 = 0xfd2fb528;
      iVar4 = 4;
    }
    *(char *)(iVar4 + (int)param_1) =
         ((cVar2 * '\x02' + bVar1) * '\b' + (in_stack_00000030 != 0)) * '\x04' + (char)iVar6;
    iVar5 = iVar4 + 1;
    if (!bVar1) {
      *(byte *)(iVar5 + (int)param_1) = (param_4 - 10) * '\b';
      iVar5 = iVar4 + 2;
    }
    if (iVar6 == 1) {
      *(char *)(iVar5 + (int)param_1) = (char)in_stack_00000074;
      iVar5 = iVar5 + 1;
    }
    else if (iVar6 == 2) {
      *(short *)(iVar5 + (int)param_1) = (short)in_stack_00000074;
      iVar5 = iVar5 + 2;
    }
    else if (iVar6 == 3) {
      *(uint *)(iVar5 + (int)param_1) = in_stack_00000074;
      iVar5 = iVar5 + 4;
    }
    switch(cVar2) {
    default:
      if (bVar1) {
        *(char *)(iVar5 + (int)param_1) = (char)in_stack_0000006c;
        iVar5 = iVar5 + 1;
      }
      return iVar5;
    case '\x01':
      *(short *)(iVar5 + (int)param_1) = (short)in_stack_0000006c + -0x100;
      return iVar5 + 2;
    case '\x02':
      *(uint *)(iVar5 + (int)param_1) = in_stack_0000006c;
      return iVar5 + 4;
    case '\x03':
      *(int *)(iVar5 + 4 + (int)param_1) = in_stack_00000070;
      *(uint *)(iVar5 + (int)param_1) = in_stack_0000006c;
      return iVar5 + 8;
    }
  }
  return -0x46;
}



/* FUNCTION 22032 ; VA 0x00ab0060 ; FUN_00ab0060 */

int FUN_00ab0060(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar2 = *param_1 | 1 << (param_1[1] & 0x1f);
  *param_1 = uVar2;
  uVar3 = param_1[1] + 1;
  param_1[1] = uVar3;
  uVar3 = uVar3 >> 3;
  *(uint *)param_1[3] = uVar2;
  param_1[3] = param_1[3] + uVar3;
  uVar2 = param_1[4];
  uVar4 = param_1[3];
  if (uVar2 < param_1[3]) {
    param_1[3] = uVar2;
    uVar4 = uVar2;
  }
  uVar1 = param_1[1];
  *param_1 = *param_1 >> ((char)uVar3 * '\b' & 0x1fU);
  param_1[1] = uVar1 & 7;
  if (uVar2 <= uVar4) {
    return 0;
  }
  return ((uint)((uVar1 & 7) != 0) - param_1[2]) + uVar4;
}



/* FUNCTION 22033 ; VA 0x00ab00d0 ; FUN_00ab00d0 */

undefined4 FUN_00ab00d0(int param_1)

{
  if ((*(int *)(param_1 + 8) == *(int *)(param_1 + 0xc)) && (*(int *)(param_1 + 4) == 0x20)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 22034 ; VA 0x00ab00f0 ; FUN_00ab00f0 */

void FUN_00ab00f0(uint *param_1)

{
  uint uVar1;
  
  uVar1 = param_1[1];
  *(uint *)param_1[3] = *param_1;
  param_1[3] = param_1[3] + (uVar1 >> 3);
  if (param_1[4] < param_1[3]) {
    param_1[3] = param_1[4];
  }
  param_1[1] = param_1[1] & 7;
  *param_1 = *param_1 >> ((char)(uVar1 >> 3) * '\b' & 0x1fU);
  return;
}



/* FUNCTION 22035 ; VA 0x00ab0130 ; FUN_00ab0130 */

uint FUN_00ab0130(uint *param_1,byte *param_2,uint param_3)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  
  if (param_3 == 0) {
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    return 0xffffffb8;
  }
  param_1[3] = (uint)param_2;
  param_1[4] = (uint)(param_2 + 4);
  if (param_3 < 4) {
    param_1[2] = (uint)param_2;
    uVar3 = (uint)*param_2;
    *param_1 = uVar3;
    switch(param_3) {
    case 3:
      uVar3 = uVar3 + (uint)param_2[2] * 0x10000;
      *param_1 = uVar3;
    case 2:
      *param_1 = (uint)param_2[1] * 0x100 + uVar3;
    }
    bVar1 = param_2[param_3 - 1];
    if (bVar1 == 0) {
      uVar3 = 0;
    }
    else {
      iVar2 = 0x1f;
      if (bVar1 != 0) {
        for (; bVar1 >> iVar2 == 0; iVar2 = iVar2 + -1) {
        }
      }
      uVar3 = 8 - iVar2;
    }
    param_1[1] = uVar3;
    if (bVar1 == 0) {
      return 0xffffffec;
    }
    param_1[1] = uVar3 + (4 - param_3) * 8;
  }
  else {
    param_1[2] = (uint)(param_2 + (param_3 - 4));
    *param_1 = *(uint *)(param_2 + (param_3 - 4));
    bVar1 = param_2[param_3 - 1];
    if (bVar1 == 0) {
      uVar3 = 0;
    }
    else {
      iVar2 = 0x1f;
      if (bVar1 != 0) {
        for (; bVar1 >> iVar2 == 0; iVar2 = iVar2 + -1) {
        }
      }
      uVar3 = 8 - iVar2;
    }
    param_1[1] = uVar3;
    if (bVar1 == 0) {
      return 0xffffffff;
    }
  }
  return param_3;
}



/* FUNCTION 22036 ; VA 0x00ab0260 ; FUN_00ab0260 */

uint FUN_00ab0260(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  uVar1 = param_1[1];
  if (0x20 < uVar1) {
    return 3;
  }
  uVar5 = param_1[2];
  if ((uint)param_1[4] <= uVar5) {
    puVar4 = (undefined4 *)(uVar5 - (uVar1 >> 3));
    param_1[1] = uVar1 & 7;
    param_1[2] = puVar4;
    *param_1 = *puVar4;
    return 0;
  }
  if (uVar5 == param_1[3]) {
    return 2 - (uVar1 < 0x20);
  }
  uVar3 = uVar5 - (uVar1 >> 3);
  iVar2 = param_1[2];
  uVar5 = uVar5 - param_1[3];
  if ((uint)param_1[3] <= uVar3) {
    uVar5 = uVar1 >> 3;
  }
  param_1[2] = (undefined4 *)(iVar2 - uVar5);
  param_1[1] = uVar1 + uVar5 * -8;
  *param_1 = *(undefined4 *)(iVar2 - uVar5);
  return (uint)(uVar3 < (uint)param_1[3]);
}



/* FUNCTION 22037 ; VA 0x00ab02f0 ; FUN_00ab02f0 */

char * FUN_00ab02f0(undefined4 param_1)

{
  switch(param_1) {
  case 0:
    return "No error detected";
  case 1:
    return "Error (generic)";
  default:
    return "Unspecified error code";
  case 10:
    return "Unknown frame descriptor";
  case 0xc:
    return "Version not supported";
  case 0xe:
    return "Unsupported frame parameter";
  case 0x10:
    return "Frame requires too much memory for decoding";
  case 0x14:
    return "Corrupted block detected";
  case 0x16:
    return "Restored data doesn\'t match checksum";
  case 0x1e:
    return "Dictionary is corrupted";
  case 0x20:
    return "Dictionary mismatch";
  case 0x22:
    return "Cannot create Dictionary from provided samples";
  case 0x28:
    return "Unsupported parameter";
  case 0x2a:
    return "Parameter is out of bound";
  case 0x2c:
    return "tableLog requires too much memory : unsupported";
  case 0x2e:
    return "Unsupported max Symbol Value : too large";
  case 0x30:
    return "Specified maxSymbolValue is too small";
  case 0x3c:
    return "Operation not authorized at current processing stage";
  case 0x3e:
    return "Context should be init first";
  case 0x40:
    return "Allocation error : not enough memory";
  case 0x46:
    return "Destination buffer is too small";
  case 0x48:
    return "Src size is incorrect";
  case 100:
    return "Frame index is too large";
  case 0x66:
    return "An I/O error occurred when reading/seeking";
  }
}



/* FUNCTION 22038 ; VA 0x00ab0480 ; FUN_00ab0480 */

undefined4
FUN_00ab0480(short *param_1,short *param_2,uint param_3,int param_4,int param_5,uint param_6)

{
  byte bVar1;
  int iVar2;
  short sVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  short *psVar9;
  int aiStack_420 [257];
  undefined2 *puStack_1c;
  undefined2 *puStack_18;
  uint uStack_14;
  uint uStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_8 = param_4;
  uStack_14 = 1 << ((byte)param_4 & 0x1f);
  puStack_18 = param_1 + 2;
  uVar7 = uStack_14 - 1;
  uStack_10 = uVar7;
  uVar4 = uStack_14 >> 1;
  if (param_4 == 0) {
    uVar4 = 1;
  }
  puStack_1c = param_1 + uVar4 * 2 + 2;
  iStack_c = (uStack_14 >> 1) + 3 + (uStack_14 >> 3);
  if (param_6 < uStack_14) {
    return 0xffffffd4;
  }
  uVar4 = 1;
  aiStack_420[0] = 0;
  *param_1 = (short)param_4;
  param_1[1] = (short)param_3;
  if (param_3 != 0xffffffff) {
    piVar6 = aiStack_420;
    psVar9 = param_2;
    do {
      iVar8 = *piVar6;
      if (*psVar9 == -1) {
        *(char *)(uVar7 + param_5) = (char)uVar4 + -1;
        uVar7 = uVar7 - 1;
        iVar8 = *piVar6;
        iVar5 = 1;
      }
      else {
        iVar5 = (int)*psVar9;
      }
      uVar4 = uVar4 + 1;
      piVar6[1] = iVar5 + iVar8;
      psVar9 = psVar9 + 1;
      piVar6 = piVar6 + 1;
    } while (uVar4 <= param_3 + 1);
  }
  aiStack_420[param_3 + 1] = uStack_14 + 1;
  uVar4 = 0;
  param_6 = 0;
  param_1 = param_2;
  do {
    iVar8 = 0;
    if (0 < *param_1) {
      do {
        *(char *)(uVar4 + param_5) = (char)param_6;
        do {
          uVar4 = uVar4 + iStack_c & uStack_10;
        } while (uVar7 < uVar4);
        iVar8 = iVar8 + 1;
      } while (iVar8 < *param_1);
    }
    param_1 = param_1 + 1;
    param_6 = param_6 + 1;
  } while (param_6 <= param_3);
  if (uVar4 != 0) {
    return 0xffffffff;
  }
  uVar7 = 0;
  if (uStack_14 != 0) {
    do {
      bVar1 = *(byte *)(uVar7 + param_5);
      sVar3 = (short)uVar7;
      uVar7 = uVar7 + 1;
      iVar8 = aiStack_420[bVar1];
      puStack_18[iVar8] = sVar3 + (short)uStack_14;
      aiStack_420[bVar1] = iVar8 + 1;
    } while (uVar7 < uStack_14);
  }
  iVar8 = 0;
  uVar7 = 0;
  do {
    iVar5 = (int)param_2[uVar7];
    if (iVar5 == -1) {
LAB_00ab064f:
      *(uint *)(puStack_1c + uVar7 * 4 + 2) = iStack_8 * 0x10000 - uStack_14;
      *(int *)(puStack_1c + uVar7 * 4) = iVar8 + -1;
      iVar8 = iVar8 + 1;
    }
    else if (iVar5 != 0) {
      if (iVar5 == 1) goto LAB_00ab064f;
      iVar2 = 0x1f;
      if (iVar5 - 1U != 0) {
        for (; iVar5 - 1U >> iVar2 == 0; iVar2 = iVar2 + -1) {
        }
      }
      *(int *)(puStack_1c + uVar7 * 4 + 2) =
           (iStack_8 - iVar2) * 0x10000 - (iVar5 << ((byte)(iStack_8 - iVar2) & 0x1f));
      *(int *)(puStack_1c + uVar7 * 4) = iVar8 - param_2[uVar7];
      iVar8 = iVar8 + param_2[uVar7];
    }
    uVar7 = uVar7 + 1;
    if (param_3 < uVar7) {
      return 0;
    }
  } while( true );
}



/* FUNCTION 22039 ; VA 0x00ab0680 ; FUN_00ab0680 */

undefined4 FUN_00ab0680(uint *param_1,short *param_2,uint param_3,uint param_4)

{
  uint uVar1;
  byte bVar2;
  ushort uVar3;
  int iVar4;
  undefined *puVar5;
  byte *pbVar6;
  uint uVar7;
  ushort auStack_21c [256];
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  uint *puStack_10;
  uint uStack_c;
  short *psStack_8;
  
  puStack_10 = param_1 + 1;
  psStack_8 = param_2;
  bVar2 = (byte)param_4;
  uStack_14 = 1 << (bVar2 & 0x1f);
  uVar7 = uStack_14 - 1;
  uStack_1c = param_4;
  uStack_c = uVar7;
  if (0xff < param_3) {
    return 0xffffffd2;
  }
  if (0xc < param_4) {
    return 0xffffffd4;
  }
  param_4 = CONCAT22(1,(short)param_4);
  uStack_18 = (uint)(ushort)(1 << (bVar2 - 1 & 0x1f));
  uVar1 = 0;
  if (param_3 != 0xffffffff) {
    puVar5 = (undefined *)((int)param_1 + uVar7 * 4 + 6);
    do {
      uVar3 = param_2[uVar1];
      if (uVar3 == 0xffff) {
        *puVar5 = (char)uVar1;
        uVar7 = uVar7 - 1;
        puVar5 = puVar5 + -4;
        uVar3 = 1;
      }
      else if ((short)uStack_18 <= (short)uVar3) {
        param_4 = param_4 & 0xffff;
      }
      auStack_21c[uVar1] = uVar3;
      uVar1 = uVar1 + 1;
    } while (uVar1 < param_3 + 1);
  }
  *param_1 = param_4;
  uVar1 = 0;
  param_1 = (uint *)0x0;
  if (param_3 != 0xffffffff) {
    do {
      iVar4 = 0;
      if (0 < *psStack_8) {
        do {
          *(char *)((int)puStack_10 + uVar1 * 4 + 2) = (char)param_1;
          do {
            uVar1 = uVar1 + (uStack_14 >> 1) + (uStack_14 >> 3) + 3 & uStack_c;
          } while (uVar7 < uVar1);
          iVar4 = iVar4 + 1;
        } while (iVar4 < *psStack_8);
      }
      psStack_8 = psStack_8 + 1;
      param_1 = (uint *)((int)param_1 + 1);
    } while (param_1 < param_3 + 1);
    if (uVar1 != 0) {
      return 0xffffffff;
    }
  }
  if (uStack_14 != 0) {
    pbVar6 = (byte *)((int)puStack_10 + 3);
    uVar7 = uStack_14;
    do {
      uVar3 = auStack_21c[pbVar6[-1]];
      auStack_21c[pbVar6[-1]] = uVar3 + 1;
      iVar4 = 0x1f;
      if (uVar3 != 0) {
        for (; uVar3 >> iVar4 == 0; iVar4 = iVar4 + -1) {
        }
      }
      bVar2 = (char)uStack_1c - (char)iVar4;
      *pbVar6 = bVar2;
      *(ushort *)(pbVar6 + -3) = (uVar3 << (bVar2 & 0x1f)) - (short)uStack_14;
      uVar7 = uVar7 - 1;
      pbVar6 = pbVar6 + 4;
    } while (uVar7 != 0);
  }
  return 0;
}



/* FUNCTION 22040 ; VA 0x00ab0810 ; FUN_00ab0810 */

void FUN_00ab0810(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
                 undefined4 param_5)

{
  if (param_4 < 0x5dc) {
    FUN_00ab0850(param_1,param_2,param_3,param_4);
    return;
  }
  FUN_00aa5b20(param_1,param_2,param_3,param_4,0,param_5);
  return;
}



/* FUNCTION 22041 ; VA 0x00ab0850 ; FUN_00ab0850 */

uint FUN_00ab0850(int param_1,uint *param_2,byte *param_3,uint param_4)

{
  int *piVar1;
  uint *puVar2;
  byte bVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  
  uVar11 = *param_2;
  FUN_0170d1f0(param_1,0,uVar11 * 4 + 4);
  if (param_4 == 0) {
    *param_2 = 0;
    return 0;
  }
  uVar10 = 0;
  if (param_3 + param_4 < param_3) {
    param_4 = 0;
  }
  if (param_4 != 0) {
    do {
      bVar3 = *param_3;
      param_3 = param_3 + 1;
      uVar10 = uVar10 + 1;
      piVar1 = (int *)(param_1 + (uint)bVar3 * 4);
      *piVar1 = *piVar1 + 1;
    } while (uVar10 < param_4);
  }
  iVar4 = *(int *)(param_1 + uVar11 * 4);
  while (iVar4 == 0) {
    uVar11 = uVar11 - 1;
    iVar4 = *(int *)(param_1 + uVar11 * 4);
  }
  uVar9 = 0;
  *param_2 = uVar11;
  uVar10 = 0;
  if ((7 < uVar11 + 1) && (1 < DAT_021137e0)) {
    uVar10 = 0;
    uVar12 = 0;
    uVar13 = 0;
    uVar14 = 0;
    uVar15 = 0;
    uVar16 = 0;
    uVar17 = 0;
    uVar18 = 0;
    do {
      puVar2 = (uint *)(param_1 + uVar9 * 4);
      uVar5 = *puVar2;
      uVar6 = puVar2[1];
      uVar7 = puVar2[2];
      uVar8 = puVar2[3];
      uVar10 = (uVar10 < uVar5) * uVar5 | (uVar10 >= uVar5) * uVar10;
      uVar12 = (uVar12 < uVar6) * uVar6 | (uVar12 >= uVar6) * uVar12;
      uVar13 = (uVar13 < uVar7) * uVar7 | (uVar13 >= uVar7) * uVar13;
      uVar14 = (uVar14 < uVar8) * uVar8 | (uVar14 >= uVar8) * uVar14;
      puVar2 = (uint *)(param_1 + 0x10 + uVar9 * 4);
      uVar5 = *puVar2;
      uVar6 = puVar2[1];
      uVar7 = puVar2[2];
      uVar8 = puVar2[3];
      uVar9 = uVar9 + 8;
      uVar15 = (uVar15 < uVar5) * uVar5 | (uVar15 >= uVar5) * uVar15;
      uVar16 = (uVar16 < uVar6) * uVar6 | (uVar16 >= uVar6) * uVar16;
      uVar17 = (uVar17 < uVar7) * uVar7 | (uVar17 >= uVar7) * uVar17;
      uVar18 = (uVar18 < uVar8) * uVar8 | (uVar18 >= uVar8) * uVar18;
    } while (uVar9 <= uVar11 - (uVar11 + 1 & 7));
    uVar10 = (uVar10 < uVar15) * uVar15 | (uVar10 >= uVar15) * uVar10;
    uVar12 = (uVar12 < uVar16) * uVar16 | (uVar12 >= uVar16) * uVar12;
    uVar13 = (uVar13 < uVar17) * uVar17 | (uVar13 >= uVar17) * uVar13;
    uVar14 = (uVar14 < uVar18) * uVar18 | (uVar14 >= uVar18) * uVar14;
    uVar10 = (uVar10 < uVar13) * uVar13 | (uVar10 >= uVar13) * uVar10;
    uVar12 = (uVar12 < uVar14) * uVar14 | (uVar12 >= uVar14) * uVar12;
    uVar10 = (uVar10 < uVar12) * uVar12 | (uVar10 >= uVar12) * uVar10;
    if (uVar11 < uVar9) {
      return uVar10;
    }
  }
  do {
    uVar12 = *(uint *)(param_1 + uVar9 * 4);
    if (uVar12 <= uVar10) {
      uVar12 = uVar10;
    }
    uVar9 = uVar9 + 1;
    uVar10 = uVar12;
  } while (uVar9 <= uVar11);
  return uVar12;
}



/* FUNCTION 22042 ; VA 0x00ab0940 ; FUN_00ab0940 */

void FUN_00ab0940(undefined4 param_1,uint *param_2,undefined4 param_3,uint param_4,
                 undefined4 param_5)

{
  if (*param_2 < 0xff) {
    FUN_00aa5b20(param_1,param_2,param_3,param_4,1,param_5);
    return;
  }
  *param_2 = 0xff;
  if (param_4 < 0x5dc) {
    FUN_00ab0850(param_1,param_2,param_3,param_4);
    return;
  }
  FUN_00aa5b20(param_1,param_2,param_3,param_4,0,param_5);
  return;
}



/* FUNCTION 22043 ; VA 0x00ab09b0 ; FUN_00ab09b0 */

undefined *
FUN_00ab09b0(undefined *param_1,int param_2,undefined4 param_3,undefined4 param_4,ushort *param_5)

{
  ushort uVar1;
  byte bVar2;
  undefined *puVar3;
  byte bVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  bool bVar9;
  int iStack_34;
  uint uStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined *puStack_18;
  ushort *puStack_14;
  undefined *puStack_10;
  uint uStack_c;
  undefined *puStack_8;
  
  puStack_18 = param_1 + param_2;
  if (param_5[1] == 0) {
    puStack_10 = param_1;
    puVar3 = (undefined *)FUN_00ab0130(&iStack_34,param_3,param_4);
    if ((undefined *)0xffffff88 < puVar3) {
      return puVar3;
    }
    uVar1 = *param_5;
    bVar2 = (byte)uStack_30;
    uStack_30 = uStack_30 + uVar1;
    bVar4 = ~(byte)uVar1 & 0x1f;
    puStack_8 = (undefined *)(((uint)(iStack_34 << (bVar2 & 0x1f)) >> 1) >> bVar4);
    FUN_00ab0260(&iStack_34);
    puStack_14 = param_5 + 2;
    bVar2 = (byte)uStack_30;
    uStack_30 = uStack_30 + uVar1;
    uStack_c = ((uint)(iStack_34 << (bVar2 & 0x1f)) >> 1) >> bVar4;
    FUN_00ab0260(&iStack_34);
    param_5 = (ushort *)iStack_34;
    puVar3 = param_1;
    do {
      if (uStack_30 < 0x21) {
        if (piStack_2c < piStack_24) {
          if (piStack_2c == piStack_28) {
            uVar6 = 2 - (uStack_30 < 0x20);
          }
          else {
            uVar5 = uStack_30 >> 3;
            bVar9 = (int *)((int)piStack_2c - uVar5) < piStack_28;
            if (bVar9) {
              uVar5 = (int)piStack_2c - (int)piStack_28;
            }
            uVar6 = (uint)bVar9;
            piStack_2c = (int *)((int)piStack_2c - uVar5);
            uStack_30 = uStack_30 + uVar5 * -8;
            param_5 = (ushort *)*piStack_2c;
          }
        }
        else {
          piStack_2c = (int *)((int)piStack_2c - (uStack_30 >> 3));
          param_5 = (ushort *)*piStack_2c;
          uVar6 = 0;
          uStack_30 = uStack_30 & 7;
        }
      }
      else {
        uVar6 = 3;
      }
      if (uVar6 != 0 || puStack_18 + -3 <= puVar3) goto LAB_00ab0fd6;
      uVar5 = *(uint *)(puStack_14 + (int)puStack_8 * 2);
      iVar7 = uStack_30 + (uVar5 >> 0x18);
      puStack_8 = (undefined *)
                  ((uVar5 & 0xffff) +
                  (((uint)((int)param_5 << ((byte)uStack_30 & 0x1f)) >> 1) >>
                  (~(byte)(uVar5 >> 0x18) & 0x1f)));
      *puStack_10 = (char)(uVar5 >> 0x10);
      uVar5 = *(uint *)(puStack_14 + uStack_c * 2);
      uStack_30 = (uVar5 >> 0x18) + iVar7;
      uStack_c = (((uint)((int)param_5 << ((byte)iVar7 & 0x1f)) >> 1) >>
                 (~(byte)(uVar5 >> 0x18) & 0x1f)) + (uVar5 & 0xffff);
      puStack_10[1] = (char)(uVar5 >> 0x10);
      if (0x20 < uStack_30) goto LAB_00ab0fd0;
      if (piStack_2c < piStack_24) {
        if (piStack_2c == piStack_28) goto LAB_00ab0fd0;
        uVar5 = uStack_30 >> 3;
        bVar9 = (int *)((int)piStack_2c - uVar5) < piStack_28;
        if (bVar9) {
          uVar5 = (int)piStack_2c - (int)piStack_28;
        }
        piStack_2c = (int *)((int)piStack_2c - uVar5);
        uStack_30 = uStack_30 + uVar5 * -8;
        param_5 = (ushort *)*piStack_2c;
        if (bVar9) goto LAB_00ab0fd0;
      }
      else {
        piStack_2c = (int *)((int)piStack_2c - (uStack_30 >> 3));
        uStack_30 = uStack_30 & 7;
        param_5 = (ushort *)*piStack_2c;
      }
      uVar5 = *(uint *)(puStack_14 + (int)puStack_8 * 2);
      iVar7 = uStack_30 + (uVar5 >> 0x18);
      puStack_8 = (undefined *)
                  ((((uint)((int)param_5 << ((byte)uStack_30 & 0x1f)) >> 1) >>
                   (~(byte)(uVar5 >> 0x18) & 0x1f)) + (uVar5 & 0xffff));
      puStack_10[2] = (char)(uVar5 >> 0x10);
      uVar5 = *(uint *)(puStack_14 + uStack_c * 2);
      uStack_30 = (uVar5 >> 0x18) + iVar7;
      uStack_c = (((uint)((int)param_5 << ((byte)iVar7 & 0x1f)) >> 1) >>
                 (~(byte)(uVar5 >> 0x18) & 0x1f)) + (uVar5 & 0xffff);
      puStack_10[3] = (char)(uVar5 >> 0x10);
      puVar3 = puStack_10 + 4;
      puStack_10 = puVar3;
    } while( true );
  }
  puStack_8 = param_1;
  puVar3 = (undefined *)FUN_00ab0130(&iStack_34,param_3,param_4);
  if ((undefined *)0xffffff88 < puVar3) {
    return puVar3;
  }
  uVar1 = *param_5;
  bVar2 = (byte)uStack_30;
  uStack_30 = uStack_30 + uVar1;
  bVar4 = ~(byte)uVar1 & 0x1f;
  uStack_c = ((uint)(iStack_34 << (bVar2 & 0x1f)) >> 1) >> bVar4;
  FUN_00ab0260(&iStack_34);
  puStack_14 = param_5 + 2;
  bVar2 = (byte)uStack_30;
  uStack_30 = uStack_30 + uVar1;
  puStack_10 = (undefined *)(((uint)(iStack_34 << (bVar2 & 0x1f)) >> 1) >> bVar4);
  FUN_00ab0260(&iStack_34);
  param_5 = (ushort *)iStack_34;
  puVar3 = param_1;
  do {
    if (uStack_30 < 0x21) {
      if (piStack_2c < piStack_24) {
        if (piStack_2c == piStack_28) {
          uVar6 = 2 - (uStack_30 < 0x20);
        }
        else {
          uVar5 = uStack_30 >> 3;
          bVar9 = (int *)((int)piStack_2c - uVar5) < piStack_28;
          if (bVar9) {
            uVar5 = (int)piStack_2c - (int)piStack_28;
          }
          uVar6 = (uint)bVar9;
          piStack_2c = (int *)((int)piStack_2c - uVar5);
          uStack_30 = uStack_30 + uVar5 * -8;
          param_5 = (ushort *)*piStack_2c;
        }
      }
      else {
        piStack_2c = (int *)((int)piStack_2c - (uStack_30 >> 3));
        param_5 = (ushort *)*piStack_2c;
        uVar6 = 0;
        uStack_30 = uStack_30 & 7;
      }
    }
    else {
      uVar6 = 3;
    }
    if (uVar6 != 0 || puStack_18 + -3 <= puVar3) goto LAB_00ab0c28;
    uVar5 = *(uint *)(puStack_14 + uStack_c * 2);
    iVar7 = (uVar5 >> 0x18) + uStack_30;
    uStack_c = (uVar5 & 0xffff) +
               ((uint)((int)param_5 << ((byte)uStack_30 & 0x1f)) >> (-(char)(uVar5 >> 0x18) & 0x1fU)
               );
    *puStack_8 = (char)(uVar5 >> 0x10);
    uVar5 = *(uint *)(puStack_14 + (int)puStack_10 * 2);
    uStack_30 = (uVar5 >> 0x18) + iVar7;
    puStack_10 = (undefined *)
                 (((uint)((int)param_5 << ((byte)iVar7 & 0x1f)) >> (-(char)(uVar5 >> 0x18) & 0x1fU))
                 + (uVar5 & 0xffff));
    puStack_8[1] = (char)(uVar5 >> 0x10);
    if (0x20 < uStack_30) goto LAB_00ab0c22;
    if (piStack_2c < piStack_24) {
      if (piStack_2c == piStack_28) goto LAB_00ab0c22;
      uVar5 = uStack_30 >> 3;
      bVar9 = (int *)((int)piStack_2c - uVar5) < piStack_28;
      if (bVar9) {
        uVar5 = (int)piStack_2c - (int)piStack_28;
      }
      piStack_2c = (int *)((int)piStack_2c - uVar5);
      uStack_30 = uStack_30 + uVar5 * -8;
      param_5 = (ushort *)*piStack_2c;
      if (bVar9) goto LAB_00ab0c22;
    }
    else {
      piStack_2c = (int *)((int)piStack_2c - (uStack_30 >> 3));
      uStack_30 = uStack_30 & 7;
      param_5 = (ushort *)*piStack_2c;
    }
    uVar5 = *(uint *)(puStack_14 + uStack_c * 2);
    iVar7 = uStack_30 + (uVar5 >> 0x18);
    uStack_c = ((uint)((int)param_5 << ((byte)uStack_30 & 0x1f)) >> (-(char)(uVar5 >> 0x18) & 0x1fU)
               ) + (uVar5 & 0xffff);
    puStack_8[2] = (char)(uVar5 >> 0x10);
    uVar5 = *(uint *)(puStack_14 + (int)puStack_10 * 2);
    uStack_30 = (uVar5 >> 0x18) + iVar7;
    puStack_10 = (undefined *)
                 (((uint)((int)param_5 << ((byte)iVar7 & 0x1f)) >> (-(char)(uVar5 >> 0x18) & 0x1fU))
                 + (uVar5 & 0xffff));
    puStack_8[3] = (char)(uVar5 >> 0x10);
    puVar3 = puStack_8 + 4;
    puStack_8 = puVar3;
  } while( true );
LAB_00ab0fd0:
  puVar3 = puStack_10 + 2;
  puStack_10 = puVar3;
LAB_00ab0fd6:
  if (puStack_18 + -2 < puVar3) {
    return (undefined *)0xffffffba;
  }
  while( true ) {
    uVar5 = *(uint *)(puStack_14 + (int)puStack_8 * 2);
    uVar8 = uStack_30 + (uVar5 >> 0x18);
    uVar6 = (uVar5 & 0xffff) +
            (((uint)((int)param_5 << ((byte)uStack_30 & 0x1f)) >> 1) >>
            (~(byte)(uVar5 >> 0x18) & 0x1f));
    *puStack_10 = (char)(uVar5 >> 0x10);
    puStack_8 = puStack_10 + 1;
    if (0x20 < uVar8) break;
    if (piStack_2c < piStack_24) {
      if (piStack_2c != piStack_28) {
        uVar5 = uVar8 >> 3;
        if ((int *)((int)piStack_2c - uVar5) < piStack_28) {
          uVar5 = (int)piStack_2c - (int)piStack_28;
        }
        uVar8 = uVar8 + uVar5 * -8;
        goto LAB_00ab105a;
      }
    }
    else {
      uVar5 = uVar8 >> 3;
      uVar8 = uVar8 & 7;
LAB_00ab105a:
      piStack_2c = (int *)((int)piStack_2c - uVar5);
      param_5 = (ushort *)*piStack_2c;
    }
    if (puStack_18 + -2 < puStack_8) {
      return (undefined *)0xffffffba;
    }
    uVar5 = *(uint *)(puStack_14 + uStack_c * 2);
    uStack_30 = uVar8 + (uVar5 >> 0x18);
    uStack_c = (uVar5 & 0xffff) +
               (((uint)((int)param_5 << ((byte)uVar8 & 0x1f)) >> 1) >>
               (~(byte)(uVar5 >> 0x18) & 0x1f));
    *puStack_8 = (char)(uVar5 >> 0x10);
    puStack_10 = puStack_10 + 2;
    if (0x20 < uStack_30) {
      *puStack_10 = *(undefined *)(puStack_14 + uVar6 * 2 + 1);
      return puStack_10 + (1 - (int)param_1);
    }
    if (piStack_2c < piStack_24) {
      if (piStack_2c != piStack_28) {
        uVar5 = uStack_30 >> 3;
        if ((int *)((int)piStack_2c - uVar5) < piStack_28) {
          uVar5 = (int)piStack_2c - (int)piStack_28;
        }
        uStack_30 = uStack_30 + uVar5 * -8;
        goto LAB_00ab10df;
      }
    }
    else {
      uVar5 = uStack_30 >> 3;
      uStack_30 = uStack_30 & 7;
LAB_00ab10df:
      piStack_2c = (int *)((int)piStack_2c - uVar5);
      param_5 = (ushort *)*piStack_2c;
    }
    puStack_8 = (undefined *)uVar6;
    if (puStack_18 + -2 < puStack_10) {
      return (undefined *)0xffffffba;
    }
  }
LAB_00ab1117:
  *puStack_8 = *(undefined *)(puStack_14 + uStack_c * 2 + 1);
  return puStack_8 + (1 - (int)param_1);
LAB_00ab0c22:
  puVar3 = puStack_8 + 2;
  puStack_8 = puVar3;
LAB_00ab0c28:
  if (puVar3 <= puStack_18 + -2) {
    do {
      uVar5 = *(uint *)(puStack_14 + uStack_c * 2);
      uVar6 = uStack_30 + (uVar5 >> 0x18);
      uStack_c = (uVar5 & 0xffff) +
                 ((uint)((int)param_5 << ((byte)uStack_30 & 0x1f)) >>
                 (-(char)(uVar5 >> 0x18) & 0x1fU));
      *puStack_8 = (char)(uVar5 >> 0x10);
      puVar3 = puStack_8 + 1;
      if (0x20 < uVar6) {
        *puVar3 = *(undefined *)(puStack_14 + (int)puStack_10 * 2 + 1);
        return puVar3 + (1 - (int)param_1);
      }
      if (piStack_2c < piStack_24) {
        if (piStack_2c != piStack_28) {
          uVar5 = uVar6 >> 3;
          if ((int *)((int)piStack_2c - uVar5) < piStack_28) {
            uVar5 = (int)piStack_2c - (int)piStack_28;
          }
          piStack_2c = (int *)((int)piStack_2c - uVar5);
          uVar6 = uVar6 + uVar5 * -8;
          param_5 = (ushort *)*piStack_2c;
        }
      }
      else {
        piStack_2c = (int *)((int)piStack_2c - (uVar6 >> 3));
        uVar6 = uVar6 & 7;
        param_5 = (ushort *)*piStack_2c;
      }
      if (puStack_18 + -2 < puVar3) {
        return (undefined *)0xffffffba;
      }
      uVar5 = *(uint *)(puStack_14 + (int)puStack_10 * 2);
      uStack_30 = uVar6 + (uVar5 >> 0x18);
      puStack_10 = (undefined *)
                   ((uVar5 & 0xffff) +
                   ((uint)((int)param_5 << ((byte)uVar6 & 0x1f)) >> (-(char)(uVar5 >> 0x18) & 0x1fU)
                   ));
      *puVar3 = (char)(uVar5 >> 0x10);
      puStack_8 = puStack_8 + 2;
      if (0x20 < uStack_30) goto LAB_00ab1117;
      if (piStack_2c < piStack_24) {
        if (piStack_2c != piStack_28) {
          uVar5 = uStack_30 >> 3;
          if ((int *)((int)piStack_2c - uVar5) < piStack_28) {
            uVar5 = (int)piStack_2c - (int)piStack_28;
          }
          piStack_2c = (int *)((int)piStack_2c - uVar5);
          uStack_30 = uStack_30 + uVar5 * -8;
          param_5 = (ushort *)*piStack_2c;
        }
      }
      else {
        piStack_2c = (int *)((int)piStack_2c - (uStack_30 >> 3));
        uStack_30 = uStack_30 & 7;
        param_5 = (ushort *)*piStack_2c;
      }
    } while (puStack_8 <= puStack_18 + -2);
  }
  return (undefined *)0xffffffba;
}



/* FUNCTION 22044 ; VA 0x00ab1130 ; FUN_00ab1130 */

uint FUN_00ab1130(undefined4 param_1,undefined4 param_2,uint param_3,int param_4,undefined4 param_5,
                 uint param_6)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_208 [512];
  undefined4 uStack_8;
  
  iVar2 = param_4;
  uVar1 = param_3;
  uStack_8 = 0xff;
  uVar3 = FUN_00ab1560(auStack_208,&uStack_8,&param_3,param_3,param_4);
  uVar4 = uVar3;
  if (uVar3 < 0xffffff89) {
    if (param_6 < param_3) {
      return 0xffffffd4;
    }
    uVar4 = FUN_00ab0680(param_5,auStack_208,uStack_8,param_3);
    if (uVar4 < 0xffffff89) {
      uVar4 = FUN_00ab09b0(param_1,param_2,uVar3 + uVar1,iVar2 - uVar3,param_5);
    }
  }
  return uVar4;
}



/* FUNCTION 22045 ; VA 0x00ab11c0 ; FUN_00ab11c0 */

void FUN_00ab11c0(uint *param_1,uint *param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  uVar2 = param_2[1];
  iVar3 = *(int *)(param_2[2] + param_3 * 8);
  uVar1 = *param_2 + *(int *)(param_2[2] + 4 + param_3 * 8);
  uVar4 = uVar1 >> 0x10;
  *param_1 = *param_1 |
             (*(uint *)(&DAT_01948670 + uVar4 * 4) & *param_2) << ((byte)param_1[1] & 0x1f);
  param_1[1] = param_1[1] + uVar4;
  *param_2 = (uint)*(ushort *)
                    (uVar2 + (((int)*param_2 >> ((byte)(uVar1 >> 0x10) & 0x1f)) + iVar3) * 2);
  return;
}



/* FUNCTION 22046 ; VA 0x00ab1220 ; FUN_00ab1220 */

void FUN_00ab1220(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = param_1[1] + param_2[3];
  *param_1 = *param_1 |
             (*(uint *)(&DAT_01948670 + param_2[3] * 4) & *param_2) << ((byte)param_1[1] & 0x1f);
  param_1[1] = uVar1;
  uVar1 = uVar1 >> 3;
  *(uint *)param_1[3] = *param_1;
  param_1[3] = param_1[3] + uVar1;
  if (param_1[4] < param_1[3]) {
    param_1[3] = param_1[4];
  }
  param_1[1] = param_1[1] & 7;
  *param_1 = *param_1 >> ((char)uVar1 * '\b' & 0x1fU);
  return;
}



/* FUNCTION 22047 ; VA 0x00ab1270 ; FUN_00ab1270 */

void FUN_00ab1270(uint *param_1,ushort *param_2,int param_3)

{
  ushort uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  
  uVar1 = *param_2;
  *param_1 = 1 << ((byte)uVar1 & 0x1f);
  iVar3 = 4;
  param_1[1] = (uint)(param_2 + 2);
  if (uVar1 != 0) {
    iVar3 = 4 << ((byte)uVar1 - 1 & 0x1f);
  }
  param_1[3] = (uint)uVar1;
  uVar4 = (int)param_2 + iVar3 + 4;
  param_1[2] = uVar4;
  iVar3 = *(int *)(uVar4 + param_3 * 8);
  iVar2 = *(int *)(uVar4 + 4 + param_3 * 8);
  uVar4 = iVar2 + 0x8000;
  uVar5 = (uVar4 & 0xffff0000) - iVar2;
  *param_1 = uVar5;
  *param_1 = (uint)(param_2 + 2)[((int)uVar5 >> ((byte)(uVar4 >> 0x10) & 0x1f)) + iVar3];
  return;
}



/* FUNCTION 22048 ; VA 0x00ab12e0 ; FUN_00ab12e0 */

uint FUN_00ab12e0(int param_1,uint param_2,int param_3,uint param_4,uint param_5)

{
  short sVar1;
  uint uVar2;
  int iVar3;
  longlong lVar4;
  short sVar5;
  short sVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  ulonglong uVar14;
  undefined8 uVar15;
  uint uStack_14;
  int iStack_10;
  
  uVar10 = 0xb;
  if (param_2 != 0) {
    uVar10 = param_2;
  }
  if (4 < uVar10) {
    if (0xc < uVar10) {
      return 0xffffffd4;
    }
    iVar12 = 0x1f;
    if (param_4 - 1 != 0) {
      for (; param_4 - 1 >> iVar12 == 0; iVar12 = iVar12 + -1) {
      }
    }
    iVar3 = 0x1f;
    if (param_5 != 0) {
      for (; param_5 >> iVar3 == 0; iVar3 = iVar3 + -1) {
      }
    }
    uVar11 = iVar3 + 2U;
    if (iVar12 + 1U < iVar3 + 2U) {
      uVar11 = iVar12 + 1U;
    }
    if (uVar11 <= uVar10) {
      uVar14 = FUN_016f3c60(0,0x40000000,param_4,0);
      uVar11 = 0x2a - uVar10;
      uStack_14 = 0;
      uVar8 = 1 << (uVar11 & 0x1f);
      uVar9 = 0;
      if (0x1f < uVar11) {
        uVar9 = uVar8;
      }
      uVar8 = uVar8 ^ uVar9;
      if (0x3f < uVar11) {
        uVar9 = uVar8;
      }
      iVar12 = 1 << ((byte)uVar10 & 0x1f);
      uVar11 = 0;
      iStack_10 = iVar12;
      sVar1 = 0;
      do {
        uVar2 = *(uint *)(param_3 + uVar11 * 4);
        if (uVar2 == param_4) {
          return 0;
        }
        uVar7 = uStack_14;
        sVar6 = sVar1;
        if (uVar2 == 0) {
          sVar5 = 0;
        }
        else if (param_4 >> ((byte)uVar10 & 0x1f) < uVar2) {
          lVar4 = (uVar14 & 0xffffffff) * (ulonglong)uVar2;
          uVar7 = (uint)lVar4;
          sVar5 = FUN_016f4650();
          if (sVar5 < 8) {
            uVar15 = FUN_016f4490();
            uVar2 = (((int)(uVar14 >> 0x20) * uVar2 + (int)((ulonglong)lVar4 >> 0x20)) -
                    (int)((ulonglong)uVar15 >> 0x20)) - (uint)(uVar7 < (uint)uVar15);
            lVar4 = (ulonglong)uVar8 * (ulonglong)*(uint *)(&DAT_01948a00 + sVar5 * 4);
            uVar13 = uVar9 * *(uint *)(&DAT_01948a00 + sVar5 * 4) + (int)((ulonglong)lVar4 >> 0x20);
            if ((uVar2 < uVar13) || ((uVar2 <= uVar13 && (uVar7 - (uint)uVar15 <= (uint)lVar4)))) {
              sVar6 = 0;
            }
            else {
              sVar6 = 1;
            }
            sVar5 = sVar5 + sVar6;
            iVar12 = iStack_10;
          }
          iVar12 = iVar12 - sVar5;
          uVar7 = uVar11;
          iStack_10 = iVar12;
          sVar6 = sVar5;
          if (sVar5 <= sVar1) {
            uVar7 = uStack_14;
            sVar6 = sVar1;
          }
        }
        else {
          iVar12 = iVar12 + -1;
          sVar5 = -1;
          iStack_10 = iVar12;
        }
        uStack_14 = uVar7;
        *(short *)(param_1 + uVar11 * 2) = sVar5;
        uVar11 = uVar11 + 1;
        sVar1 = sVar6;
      } while (uVar11 <= param_5);
      sVar1 = *(short *)(param_1 + uStack_14 * 2);
      if (-iVar12 < (int)sVar1 >> 1) {
        *(short *)(param_1 + uStack_14 * 2) = sVar1 + (short)iVar12;
      }
      else {
        uVar11 = FUN_00aa5f10(param_1,uVar10,param_3,param_4,param_5);
        if (0xffffff88 < uVar11) {
          return uVar11;
        }
      }
      return uVar10;
    }
  }
  return 0xffffffff;
}



/* FUNCTION 22049 ; VA 0x00ab14f0 ; FUN_00ab14f0 */

uint FUN_00ab14f0(uint param_1,int param_2,uint param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  uVar4 = param_2 - 1;
  iVar1 = 0x1f;
  if (uVar4 != 0) {
    for (; uVar4 >> iVar1 == 0; iVar1 = iVar1 + -1) {
    }
  }
  iVar2 = 0x1f;
  if (uVar4 != 0) {
    for (; uVar4 >> iVar2 == 0; iVar2 = iVar2 + -1) {
    }
  }
  iVar3 = 0x1f;
  if (param_3 != 0) {
    for (; param_3 >> iVar3 == 0; iVar3 = iVar3 + -1) {
    }
  }
  uVar4 = iVar3 + 2U;
  if (iVar2 + 1U < iVar3 + 2U) {
    uVar4 = iVar2 + 1U;
  }
  uVar5 = 0xb;
  if (param_1 != 0) {
    uVar5 = param_1;
  }
  uVar6 = iVar1 - 2U;
  if (uVar5 <= iVar1 - 2U) {
    uVar6 = uVar5;
  }
  if (uVar4 <= uVar6) {
    uVar4 = uVar6;
  }
  if (uVar4 < 5) {
    return 5;
  }
  if (0xc < uVar4) {
    uVar4 = 0xc;
  }
  return uVar4;
}



/* FUNCTION 22050 ; VA 0x00ab1560 ; FUN_00ab1560 */

int FUN_00ab1560(int param_1,uint *param_2,uint *param_3,uint *param_4,uint param_5)

{
  uint *puVar1;
  int iVar2;
  byte bVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iVar9;
  bool bVar10;
  uint *puStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  
  uVar4 = param_5;
  param_5 = 0;
  bVar10 = false;
  iVar2 = (int)param_4 + uVar4;
  puStack_18 = param_4;
  if (uVar4 < 4) {
    return -0x48;
  }
  uVar4 = *param_4 & 0xf;
  uVar5 = uVar4 + 5;
  if (uVar5 < 0x10) {
    uVar6 = *param_4 >> 4;
    iStack_14 = 1 << (sbyte)uVar5;
    uVar7 = 4;
    *param_3 = uVar5;
    iStack_c = uVar4 + 6;
    iStack_10 = iStack_14 + 1;
    if (1 < iStack_10) {
      do {
        if (bVar10) {
          uVar4 = param_5;
          if ((short)uVar6 == -1) {
            do {
              uVar4 = uVar4 + 0x18;
              if (puStack_18 < (uint *)(iVar2 + -5)) {
                puVar1 = (uint *)((int)puStack_18 + 2);
                puStack_18 = (uint *)((int)puStack_18 + 2);
                uVar6 = *puVar1 >> ((byte)uVar7 & 0x1f);
              }
              else {
                uVar6 = uVar6 >> 0x10;
                uVar7 = uVar7 + 0x10;
              }
            } while ((short)uVar6 == -1);
          }
          bVar3 = (byte)uVar6;
          while ((bVar3 & 3) == 3) {
            uVar6 = uVar6 >> 2;
            uVar4 = uVar4 + 3;
            uVar7 = uVar7 + 2;
            bVar3 = (byte)uVar6;
          }
          uVar7 = uVar7 + 2;
          uVar4 = uVar4 + (uVar6 & 3);
          if (*param_2 < uVar4) {
            return -0x30;
          }
          if (param_5 < uVar4) {
            puVar8 = (undefined4 *)(param_1 + param_5 * 2);
            for (uVar5 = uVar4 - param_5 >> 1; uVar5 != 0; uVar5 = uVar5 - 1) {
              *puVar8 = 0;
              puVar8 = puVar8 + 1;
            }
            for (uVar5 = (uint)((uVar4 - param_5 & 1) != 0); param_5 = uVar4, uVar5 != 0;
                uVar5 = uVar5 - 1) {
              *(undefined2 *)puVar8 = 0;
              puVar8 = (undefined4 *)((int)puVar8 + 2);
            }
          }
          iVar9 = (int)uVar7 >> 3;
          if (((uint *)(iVar2 + -7) < puStack_18) && (iVar2 - 4U < (uint)(iVar9 + (int)puStack_18)))
          {
            uVar6 = uVar6 >> 2;
          }
          else {
            puVar1 = (uint *)((int)puStack_18 + iVar9);
            puStack_18 = (uint *)((int)puStack_18 + iVar9);
            uVar7 = uVar7 & 7;
            uVar6 = *puVar1 >> (sbyte)uVar7;
          }
        }
        uVar4 = (iStack_14 * 2 - iStack_10) - 1;
        if ((iStack_14 - 1U & uVar6) < uVar4) {
          uVar7 = uVar7 + iStack_c + -1;
          uVar4 = iStack_14 - 1U & uVar6;
        }
        else {
          uVar7 = uVar7 + iStack_c;
          uVar6 = iStack_14 * 2 - 1U & uVar6;
          uVar4 = uVar6 - uVar4;
          if ((int)uVar6 < iStack_14) {
            uVar4 = uVar6;
          }
        }
        uVar4 = uVar4 - 1;
        iStack_10 = iStack_10 - ((uVar4 ^ (int)uVar4 >> 0x1f) - ((int)uVar4 >> 0x1f));
        *(short *)(param_1 + param_5 * 2) = (short)uVar4;
        param_5 = param_5 + 1;
        bVar10 = uVar4 == 0;
        for (; iStack_10 < iStack_14; iStack_14 = iStack_14 >> 1) {
          iStack_c = iStack_c + -1;
        }
        if (((uint *)(iVar2 + -7) < puStack_18) &&
           (iVar2 - 4U < (uint)(((int)uVar7 >> 3) + (int)puStack_18))) {
          uVar7 = uVar7 + ((int)puStack_18 - iVar2) * 8 + 0x20;
          puStack_18 = (uint *)(iVar2 + -4);
        }
        else {
          puStack_18 = (uint *)((int)puStack_18 + ((int)uVar7 >> 3));
          uVar7 = uVar7 & 7;
        }
        uVar6 = *puStack_18 >> ((byte)uVar7 & 0x1f);
      } while (1 < iStack_10 && param_5 <= *param_2);
    }
    if ((iStack_10 == 1) && ((int)uVar7 < 0x21)) {
      *param_2 = param_5 - 1;
      return (((int)(uVar7 + 7) >> 3) - (int)param_4) + (int)puStack_18;
    }
    return -0x14;
  }
  return -0x2c;
}



/* FUNCTION 22051 ; VA 0x00ab17c0 ; FUN_00ab17c0 */

undefined4 FUN_00ab17c0(undefined4 param_1,uint param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  undefined4 uVar2;
  
  if (0xc < param_5) {
    return 0xffffffd4;
  }
  if (param_5 < 5) {
    return 0xffffffff;
  }
  uVar1 = 0x200;
  if (param_4 != 0) {
    uVar1 = ((param_4 + 1) * param_5 >> 3) + 3;
  }
  if (param_2 < uVar1) {
    uVar2 = FUN_00aa6170(param_1,param_2,param_3,param_4,param_5,0);
    return uVar2;
  }
  uVar2 = FUN_00aa6170(param_1,param_2,param_3,param_4,param_5,1);
  return uVar2;
}



/* FUNCTION 22052 ; VA 0x00ab1830 ; FUN_00ab1830 */

uint FUN_00ab1830(int param_1,int param_2,uint param_3,int param_4,undefined4 *param_5,uint param_6)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  ushort uVar4;
  uint uVar5;
  uint *puVar6;
  uint uVar7;
  char *pcVar8;
  byte *pbVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  byte *pbVar13;
  undefined4 *puVar14;
  uint auStack_15c [64];
  ushort auStack_5c [14];
  short asStack_40 [14];
  int iStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  int iStack_10;
  uint uStack_c;
  uint uStack_8;
  
  puVar14 = param_5 + 2;
  if (0xfff < param_6) {
    iStack_24 = 0xb;
    if (param_4 != 0) {
      iStack_24 = param_4;
    }
    if (param_3 < 0x100) {
      puStack_14 = puVar14;
      FUN_0170d1f0(param_5,0,0x1000);
      FUN_0170d1f0(auStack_15c,0,0x100);
      uVar7 = 0;
      do {
        iVar10 = uVar7 * 4;
        uVar7 = uVar7 + 1;
        uVar5 = *(int *)(param_2 + iVar10) + 1;
        iVar10 = 0x1f;
        if (uVar5 != 0) {
          for (; uVar5 >> iVar10 == 0; iVar10 = iVar10 + -1) {
          }
        }
        auStack_15c[iVar10 * 2] = auStack_15c[iVar10 * 2] + 1;
      } while (uVar7 <= param_3);
      iVar10 = 0x1e;
      puVar6 = auStack_15c + 0x3a;
      do {
        *puVar6 = *puVar6 + puVar6[2];
        iVar10 = iVar10 + -1;
        puVar6 = puVar6 + -2;
      } while (iVar10 != 0);
      uVar7 = 0;
      do {
        auStack_15c[uVar7 * 2 + 1] = auStack_15c[uVar7 * 2];
        uVar7 = uVar7 + 1;
      } while (uVar7 < 0x20);
      param_6 = 0;
      do {
        uVar7 = *(uint *)(param_2 + param_6 * 4);
        uStack_1c = 0;
        iVar10 = 0x1f;
        if (uVar7 + 1 != 0) {
          for (; uVar7 + 1 >> iVar10 == 0; iVar10 = iVar10 + -1) {
          }
        }
        uVar5 = auStack_15c[iVar10 * 2 + 3];
        uVar2 = auStack_15c[iVar10 * 2 + 2];
        auStack_15c[iVar10 * 2 + 3] = uVar5 + 1;
        if (uVar2 < uVar5) {
          puVar6 = param_5 + uVar5 * 2;
          do {
            if (uVar7 <= *puVar6) break;
            uVar5 = uVar5 - 1;
            puVar6[2] = *puVar6;
            puVar6[3] = puVar6[1];
            puVar6 = puVar6 + -2;
          } while (uVar2 < uVar5);
        }
        *(char *)((int)param_5 + uVar5 * 8 + 0xe) = (char)param_6;
        param_6 = param_6 + 1;
        puVar14[uVar5 * 2] = uVar7;
      } while (param_6 <= param_3);
      iVar10 = puVar14[param_3 * 2];
      uStack_18 = param_3;
      while (iVar10 == 0) {
        uStack_18 = uStack_18 - 1;
        iVar10 = puVar14[uStack_18 * 2];
      }
      uStack_1c = uStack_18 + 0xff;
      iVar11 = 0x100;
      param_5[0x202] = param_5[uStack_18 * 2] + puVar14[uStack_18 * 2];
      *(undefined2 *)(param_5 + uStack_18 * 2 + 1) = 0x100;
      *(undefined2 *)(param_5 + uStack_18 * 2 + 3) = 0x100;
      iVar10 = uStack_18 - 2;
      uVar7 = 0x101;
      uStack_c = 0x101;
      if (0x100 < uStack_1c) {
        do {
          puVar14[uVar7 * 2] = 0x40000000;
          uVar7 = uVar7 + 1;
        } while (uVar7 <= uStack_1c);
      }
      *param_5 = 0x80000000;
      if (0x100 < uStack_1c) {
        uStack_8 = 0x101;
        do {
          iStack_10 = iVar11;
          iVar3 = iVar10;
          if ((uint)puVar14[iVar11 * 2] <= (uint)puVar14[iVar10 * 2]) {
            iStack_10 = iVar11 + 1;
            iVar3 = iVar11;
          }
          iVar12 = iVar10 + -1;
          if ((uint)puVar14[iVar11 * 2] <= (uint)puVar14[iVar10 * 2]) {
            iVar12 = iVar10;
          }
          uVar7 = param_5[iVar12 * 2 + 2];
          uStack_20 = puVar14[iStack_10 * 2];
          iVar10 = iVar12;
          if (uStack_20 <= uVar7) {
            iVar10 = iStack_10;
          }
          param_5[uStack_8 * 2 + 2] = param_5[iVar10 * 2 + 2] + param_5[iVar3 * 2 + 2];
          *(short *)(param_5 + iVar10 * 2 + 3) = (short)uStack_c;
          *(short *)(param_5 + iVar3 * 2 + 3) = (short)uStack_c;
          uStack_c = uStack_c + 1;
          uStack_8 = uStack_c & 0xffff;
          iVar10 = iVar12 + -1;
          if (uStack_20 <= uVar7) {
            iVar10 = iVar12;
          }
          iVar11 = iStack_10;
          if (uStack_20 <= uVar7) {
            iVar11 = iStack_10 + 1;
          }
          puVar14 = puStack_14;
        } while (uStack_8 <= uStack_1c);
      }
      *(undefined *)((int)puVar14 + uStack_1c * 8 + 7) = 0;
      if (0xff < uStack_18 + 0xfe) {
        iVar10 = uStack_18 - 1;
        pcVar8 = (char *)((uStack_18 + 0xfe) * 8 + 7 + (int)puVar14);
        do {
          *pcVar8 = *(char *)((int)puVar14 + (uint)*(ushort *)(pcVar8 + -3) * 8 + 7) + '\x01';
          iVar10 = iVar10 + -1;
          pcVar8 = pcVar8 + -8;
        } while (iVar10 != 0);
      }
      iVar10 = uStack_18 + 1;
      pbVar13 = (byte *)((int)puVar14 + 7);
      pbVar9 = pbVar13;
      iVar11 = iVar10;
      do {
        *pbVar9 = *(char *)((int)puVar14 + (uint)*(ushort *)(pbVar9 + -3) * 8 + 7) + 1;
        iVar11 = iVar11 + -1;
        pbVar9 = pbVar9 + 8;
      } while (iVar11 != 0);
      uVar7 = FUN_00aa8440(puVar14,uStack_18,iStack_24);
      asStack_40[0xc] = 0;
      asStack_40[8] = 0;
      asStack_40[9] = 0;
      asStack_40[10] = 0;
      asStack_40[0xb] = 0;
      auStack_5c[8] = 0;
      auStack_5c[9] = 0;
      auStack_5c[10] = 0;
      auStack_5c[0xb] = 0;
      auStack_5c[0xc] = 0;
      asStack_40[0] = 0;
      asStack_40[1] = 0;
      asStack_40[2] = 0;
      asStack_40[3] = 0;
      asStack_40[4] = 0;
      asStack_40[5] = 0;
      asStack_40[6] = 0;
      asStack_40[7] = 0;
      auStack_5c[0] = 0;
      auStack_5c[1] = 0;
      auStack_5c[2] = 0;
      auStack_5c[3] = 0;
      auStack_5c[4] = 0;
      auStack_5c[5] = 0;
      auStack_5c[6] = 0;
      auStack_5c[7] = 0;
      if (uVar7 < 0xd) {
        do {
          bVar1 = *pbVar13;
          pbVar13 = pbVar13 + 8;
          asStack_40[bVar1] = asStack_40[bVar1] + 1;
          iVar10 = iVar10 + -1;
        } while (iVar10 != 0);
        uVar4 = 0;
        for (uVar5 = uVar7; uVar5 != 0; uVar5 = uVar5 - 1) {
          auStack_5c[uVar5] = uVar4;
          uVar4 = (ushort)(asStack_40[uVar5] + uVar4) >> 1;
        }
        iVar10 = param_3 + 1;
        pbVar13 = (byte *)((int)puVar14 + 6);
        do {
          *(byte *)(param_1 + 2 + (uint)*pbVar13 * 4) = pbVar13[1];
          iVar10 = iVar10 + -1;
          pbVar13 = pbVar13 + 8;
        } while (iVar10 != 0);
        uVar5 = 0;
        do {
          bVar1 = *(byte *)(param_1 + 2 + uVar5 * 4);
          uVar4 = auStack_5c[bVar1];
          *(ushort *)(param_1 + uVar5 * 4) = uVar4;
          uVar5 = uVar5 + 1;
          auStack_5c[bVar1] = uVar4 + 1;
        } while (uVar5 <= param_3);
        return uVar7;
      }
    }
  }
  return 0xffffffff;
}



/* FUNCTION 22053 ; VA 0x00ab1bc0 ; FUN_00ab1bc0 */

undefined4 FUN_00ab1bc0(uint *param_1,uint param_2,int param_3,uint param_4,int param_5)

{
  ushort *puVar1;
  ushort *puVar2;
  undefined4 uVar3;
  uint uVar4;
  uint *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uStack_28;
  uint uStack_24;
  uint *puStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  uint uStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  if (param_2 < 8) {
    return 0;
  }
  uStack_8 = 0;
  uStack_24 = 0;
  uStack_28 = 0;
  puStack_18 = (uint *)((param_2 - 4) + (int)param_1);
  uStack_14 = 0;
  puStack_20 = param_1;
  puStack_1c = param_1;
  if (param_2 < 5) {
    return 0;
  }
  uVar7 = param_4 & 0xfffffffc;
  uStack_10 = 0;
  param_4 = param_4 & 3;
  uStack_c = uVar7;
  if (param_4 != 1) {
    if (param_4 != 2) {
      if (param_4 != 3) goto LAB_00ab1cc8;
      puVar1 = (ushort *)(param_5 + (uint)*(byte *)(uVar7 + 2 + param_3) * 4);
      uStack_28 = (uint)*puVar1;
      uStack_24 = (uint)*(byte *)(puVar1 + 1);
      FUN_00ab00f0(&uStack_28);
      uStack_8 = uStack_28;
      param_1 = puStack_1c;
    }
    puVar1 = (ushort *)(param_5 + (uint)*(byte *)(uVar7 + 1 + param_3) * 4);
    uStack_8 = uStack_8 | (uint)*puVar1 << ((byte)uStack_24 & 0x1f);
    uStack_14 = uStack_24 + *(byte *)(puVar1 + 1);
  }
  uStack_28 = (uint)*(ushort *)(param_5 + (uint)*(byte *)(uVar7 + param_3) * 4) <<
              ((byte)uStack_14 & 0x1f) | uStack_8;
  uStack_10 = *(byte *)(param_5 + 2 + (uint)*(byte *)(uVar7 + param_3) * 4) + uStack_14;
  *param_1 = uStack_28;
  uVar4 = uStack_10 >> 3;
  puStack_1c = (uint *)((int)param_1 + uVar4);
  if (puStack_18 < puStack_1c) {
    puStack_1c = puStack_18;
  }
  uStack_10 = uStack_10 & 7;
  uStack_28 = uStack_28 >> ((byte)(uVar4 << 3) & 0x1f);
LAB_00ab1cc8:
  if (uVar7 != 0) {
    param_1 = puStack_1c;
    param_2 = uStack_28;
    do {
      uVar4 = (uint)*(byte *)(param_3 + -1 + uVar7);
      iVar6 = *(byte *)(param_5 + 2 + uVar4 * 4) + uStack_10;
      uVar7 = (uint)*(byte *)(param_3 + -2 + uVar7);
      uVar8 = (uint)*(byte *)(param_5 + 2 + uVar7 * 4) + iVar6;
      param_2 = (uint)*(ushort *)(param_5 + uVar4 * 4) << (sbyte)uStack_10 |
                (uint)*(ushort *)(param_5 + uVar7 * 4) << ((byte)iVar6 & 0x1f) | param_2;
      uStack_14 = uVar8 >> 3;
      *param_1 = param_2;
      puVar5 = (uint *)((int)param_1 + uStack_14);
      if (puStack_18 < (uint *)((int)param_1 + uStack_14)) {
        puVar5 = puStack_18;
      }
      uVar8 = uVar8 & 7;
      puVar1 = (ushort *)(param_5 + (uint)*(byte *)(param_3 + -3 + uStack_c) * 4);
      iVar6 = uVar8 + *(byte *)(puVar1 + 1);
      puVar2 = (ushort *)(param_5 + (uint)*(byte *)(param_3 + -4 + uStack_c) * 4);
      uStack_10 = (uint)*(byte *)(puVar2 + 1) + iVar6;
      param_2 = param_2 >> ((byte)(uStack_14 << 3) & 0x1f) | (uint)*puVar1 << (sbyte)uVar8 |
                (uint)*puVar2 << ((byte)iVar6 & 0x1f);
      uVar7 = uStack_10 >> 3;
      *puVar5 = param_2;
      param_1 = (uint *)((int)puVar5 + uVar7);
      if (puStack_18 < param_1) {
        param_1 = puStack_18;
      }
      uStack_10 = uStack_10 & 7;
      param_2 = param_2 >> ((char)uVar7 * '\b' & 0x1fU);
      uVar7 = uStack_c - 4;
      uStack_28 = param_2;
      puStack_1c = param_1;
      uStack_c = uVar7;
      uStack_8 = uStack_10;
    } while (uVar7 != 0);
  }
  uStack_24 = uStack_10;
  uVar3 = FUN_00ab0060(&uStack_28);
  return uVar3;
}



/* FUNCTION 22054 ; VA 0x00ab1df0 ; FUN_00ab1df0 */

uint FUN_00ab1df0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  
  uVar1 = FUN_00ab1f40(param_1,param_4,param_5,param_6,param_7);
  if (uVar1 < 0xffffff89) {
    if (param_5 <= uVar1) {
      return 0xffffffb8;
    }
    uVar1 = FUN_00aa68a0(param_2,param_3,uVar1 + param_4,param_5 - uVar1,param_1);
  }
  return uVar1;
}



/* FUNCTION 22055 ; VA 0x00ab1e40 ; FUN_00ab1e40 */

uint FUN_00ab1e40(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  
  uVar1 = FUN_00ab1f40(param_1,param_4,param_5,param_6,param_7);
  if (uVar1 < 0xffffff89) {
    if (param_5 <= uVar1) {
      return 0xffffffb8;
    }
    uVar1 = FUN_00aa6d00(param_2,param_3,uVar1 + param_4,param_5 - uVar1,param_1);
  }
  return uVar1;
}



/* FUNCTION 22056 ; VA 0x00ab1e90 ; FUN_00ab1e90 */

uint FUN_00ab1e90(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  
  uVar1 = FUN_00ab2060(param_1,param_4,param_5,param_6,param_7);
  if (uVar1 < 0xffffff89) {
    if (param_5 <= uVar1) {
      return 0xffffffb8;
    }
    uVar1 = FUN_00aa76b0(param_2,param_3,uVar1 + param_4,param_5 - uVar1,param_1);
  }
  return uVar1;
}



/* FUNCTION 22057 ; VA 0x00ab1ee0 ; FUN_00ab1ee0 */

undefined4
FUN_00ab1ee0(undefined4 param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_3 == 0) {
    return 0xffffffba;
  }
  if (param_5 == 0) {
    return 0xffffffec;
  }
  iVar1 = FUN_00ab24d0(param_3,param_5);
  if (iVar1 != 0) {
    uVar2 = FUN_00ab1e90();
    return uVar2;
  }
  uVar2 = FUN_00ab1e40(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  return uVar2;
}



/* FUNCTION 22058 ; VA 0x00ab1f40 ; FUN_00ab1f40 */

uint FUN_00ab1f40(uint *param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint *puVar1;
  byte bVar2;
  int iVar3;
  char cVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uStack_8 = 0;
  uStack_c = 0;
  if (0x13f < param_5) {
    uVar5 = FUN_00ab2360(param_4 + 0x40,0x100,param_4,&uStack_c,&uStack_8,param_2,param_3);
    if (0xffffff88 < uVar5) {
      return uVar5;
    }
    uVar7 = *param_1;
    if (uStack_8 <= (uVar7 & 0xff) + 1) {
      iVar8 = 0;
      param_5._3_1_ = (undefined)(uVar7 >> 0x18);
      param_5._0_2_ = (undefined2)uVar7;
      param_5._0_3_ = CONCAT12((char)uStack_8,(undefined2)param_5);
      param_5 = CONCAT22(param_5._2_2_,(undefined2)param_5) & 0xffff00ff;
      *param_1 = param_5;
      uVar7 = 1;
      if (1 < uStack_8 + 1) {
        do {
          iVar3 = *(int *)(param_4 + uVar7 * 4);
          cVar4 = (char)uVar7;
          *(int *)(param_4 + uVar7 * 4) = iVar8;
          uVar7 = uVar7 + 1;
          iVar8 = iVar8 + (iVar3 << (cVar4 - 1U & 0x1f));
        } while (uVar7 < uStack_8 + 1);
      }
      uStack_10 = 0;
      if (uStack_c != 0) {
        do {
          bVar2 = *(byte *)(uStack_10 + param_4 + 0x40);
          iVar8 = (1 << (bVar2 & 0x1f)) >> 1;
          puVar1 = (uint *)(param_4 + (uint)bVar2 * 4);
          uVar7 = *puVar1;
          uVar6 = uVar7;
          if (uVar7 < uVar7 + iVar8) {
            do {
              *(ushort *)((int)param_1 + uVar6 * 2 + 4) =
                   CONCAT11(((char)uStack_8 - bVar2) + '\x01',(char)uStack_10);
              uVar6 = uVar6 + 1;
              uVar7 = *puVar1;
            } while (uVar6 < uVar7 + iVar8);
          }
          *puVar1 = uVar7 + iVar8;
          uStack_10 = uStack_10 + 1;
        } while (uStack_10 < uStack_c);
      }
      return uVar5;
    }
  }
  return 0xffffffd4;
}



/* FUNCTION 22059 ; VA 0x00ab2060 ; FUN_00ab2060 */

uint FUN_00ab2060(uint *param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint *puVar9;
  byte bVar10;
  int *piVar11;
  int iVar12;
  uint uVar13;
  uint *puVar14;
  int *piVar15;
  uint uVar16;
  uint uVar17;
  int iVar18;
  uint uVar19;
  ulonglong uVar20;
  uint uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int *piStack_18;
  uint uStack_14;
  uint uStack_10;
  int *piStack_c;
  int *piStack_8;
  
  uVar3 = *param_1;
  uStack_10 = uVar3 & 0xff;
  piVar1 = param_4 + 0x9c;
  if (0x5db < param_5) {
    piStack_c = param_4 + 0xaa;
    FUN_0170d1f0(piVar1,0,0x6c);
    if (uStack_10 < 0xd) {
      uVar8 = FUN_00ab2360(param_4 + 0x137,0x100,piVar1,&piStack_8,&uStack_14,param_2,param_3);
      if (0xffffff88 < uVar8) {
        return uVar8;
      }
      if (uStack_14 <= uStack_10) {
        iVar18 = piVar1[uStack_14];
        uVar17 = uStack_14;
        while (iVar18 == 0) {
          uVar17 = uVar17 - 1;
          iVar18 = piVar1[uVar17];
        }
        iStack_1c = 0;
        piVar15 = param_4 + 0xaa;
        if (1 < uVar17 + 1) {
          piVar11 = param_4 + 0xab;
          uVar13 = uVar17;
          iVar18 = 0;
          do {
            iStack_1c = iVar18 + *(int *)((int)piVar1 + (-4 - (int)piStack_c) + (int)(piVar11 + 1));
            *piVar11 = iVar18;
            uVar13 = uVar13 - 1;
            piVar11 = piVar11 + 1;
            piVar15 = piStack_c;
            iVar18 = iStack_1c;
          } while (uVar13 != 0);
        }
        *piVar15 = iStack_1c;
        piStack_18 = (int *)0x0;
        if (piStack_8 != (int *)0x0) {
          do {
            bVar10 = *(byte *)((int)(piStack_18 + 0x137) + (int)param_4);
            iVar18 = piStack_c[bVar10];
            piStack_c[bVar10] = iVar18 + 1;
            *(char *)((int)param_4 + iVar18 * 2 + 0x2dc) = (char)piStack_18;
            piStack_18 = (int *)((int)piStack_18 + 1);
            *(byte *)((int)param_4 + iVar18 * 2 + 0x2dd) = bVar10;
            piVar15 = piStack_c;
          } while (piStack_18 < piStack_8);
        }
        *piVar15 = 0;
        if (1 < uVar17 + 1) {
          iVar12 = uStack_10 - uStack_14;
          iVar18 = 0;
          piVar15 = param_4;
          uStack_24 = uVar17;
          do {
            piVar15 = piVar15 + 1;
            iVar4 = *(int *)(((int)piVar1 - (int)param_4) + (int)piVar15);
            bVar10 = (byte)iVar12;
            *piVar15 = iVar18;
            iVar12 = iVar12 + 1;
            uStack_24 = uStack_24 - 1;
            iVar18 = iVar18 + (iVar4 << (bVar10 & 0x1f));
          } while (uStack_24 != 0);
        }
        uVar19 = (uStack_14 - uVar17) + 1;
        uVar13 = (uStack_10 - uVar19) + 1;
        if (uVar19 < uVar13) {
          piStack_8 = param_4 + uVar19 * 0xd;
          piStack_c = (int *)(uVar19 * -0x34);
          do {
            uVar16 = 1;
            if (1 < uVar17 + 1) {
              if ((0xf < uVar17) &&
                 ((param_4 + uVar17 < piStack_8 + 1 || (piStack_8 + uVar17 < param_4 + 1)))) {
                puVar9 = (uint *)(param_4 + 0xd);
                puVar14 = (uint *)(piStack_8 + 5);
                do {
                  uVar5 = puVar9[-0xb];
                  uVar6 = puVar9[-10];
                  uVar7 = puVar9[-9];
                  uVar16 = uVar16 + 0x10;
                  uVar20 = (ulonglong)uVar19;
                  puVar14[-4] = puVar9[-0xc] >> uVar20;
                  puVar14[-3] = uVar5 >> uVar20;
                  puVar14[-2] = uVar6 >> uVar20;
                  puVar14[-1] = uVar7 >> uVar20;
                  puVar2 = (uint *)((int)(piStack_c + -0x10) + (int)(puVar14 + 0x10));
                  uVar5 = puVar2[1];
                  uVar6 = puVar2[2];
                  uVar7 = puVar2[3];
                  *puVar14 = *puVar2 >> uVar20;
                  puVar14[1] = uVar5 >> uVar20;
                  puVar14[2] = uVar6 >> uVar20;
                  puVar14[3] = uVar7 >> uVar20;
                  uVar5 = puVar9[-3];
                  uVar6 = puVar9[-2];
                  uVar7 = puVar9[-1];
                  uVar20 = (ulonglong)uVar19;
                  puVar14[4] = puVar9[-4] >> uVar20;
                  puVar14[5] = uVar5 >> uVar20;
                  puVar14[6] = uVar6 >> uVar20;
                  puVar14[7] = uVar7 >> uVar20;
                  uVar5 = puVar9[1];
                  uVar6 = puVar9[2];
                  uVar7 = puVar9[3];
                  puVar14[8] = *puVar9 >> uVar20;
                  puVar14[9] = uVar5 >> uVar20;
                  puVar14[10] = uVar6 >> uVar20;
                  puVar14[0xb] = uVar7 >> uVar20;
                  puVar9 = puVar9 + 0x10;
                  puVar14 = puVar14 + 0x10;
                } while (uVar16 < (uVar17 + 1) - (uVar17 & 0xf));
              }
              if (uVar16 < uVar17 + 1) {
                iVar18 = (uVar17 + 1) - uVar16;
                puVar9 = (uint *)(piStack_8 + uVar16);
                do {
                  *puVar9 = *(uint *)(((int)param_4 - (int)piStack_8) + (int)puVar9) >>
                            ((byte)uVar19 & 0x1f);
                  iVar18 = iVar18 + -1;
                  puVar9 = puVar9 + 1;
                } while (iVar18 != 0);
              }
            }
            uVar19 = uVar19 + 1;
            piStack_8 = piStack_8 + 0xd;
            piStack_c = piStack_c + -0xd;
          } while (uVar19 < uVar13);
        }
        FUN_00aa8250(param_1 + 1,uStack_10,param_4 + 0xb7,iStack_1c,param_4 + 0xa9,param_4,uVar17,
                     uStack_14 + 1);
        uStack_20._3_1_ = (undefined)(uVar3 >> 0x18);
        uStack_20 = CONCAT22(CONCAT11(uStack_20._3_1_,(char)uVar3),CONCAT11(1,(char)uVar3));
        *param_1 = uStack_20;
        return uVar8;
      }
    }
  }
  return 0xffffffd4;
}



/* FUNCTION 22060 ; VA 0x00ab2360 ; FUN_00ab2360 */

uint FUN_00ab2360(int param_1,uint param_2,int param_3,int *param_4,uint *param_5,byte *param_6,
                 uint param_7)

{
  int *piVar1;
  byte *pbVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_108 [260];
  
  if (param_7 != 0) {
    uVar5 = (uint)*param_6;
    if (uVar5 < 0x80) {
      if (uVar5 + 1 <= param_7) {
        uVar6 = FUN_00ab1130(param_1,param_2 - 1,param_6 + 1,uVar5,auStack_108,6);
        param_7 = uVar5 + 1;
        if (0xffffff88 < uVar6) {
          return uVar6;
        }
        goto LAB_00ab2406;
      }
    }
    else {
      uVar6 = uVar5 - 0x7f;
      uVar5 = (uVar5 - 0x7e >> 1) + 1;
      if (uVar5 <= param_7) {
        if (param_2 <= uVar6) {
          return 0xffffffec;
        }
        uVar7 = 0;
        param_7 = uVar5;
        if (uVar6 != 0) {
          do {
            *(byte *)(param_1 + uVar7) = param_6[(uVar7 >> 1) + 1] >> 4;
            *(byte *)(param_1 + 1 + uVar7) = param_6[(uVar7 >> 1) + 1] & 0xf;
            uVar7 = uVar7 + 2;
          } while (uVar7 < uVar6);
        }
LAB_00ab2406:
        FUN_0170d1f0(param_3,0,0x34);
        uVar7 = 0;
        uVar5 = 0;
        if (uVar6 != 0) {
          do {
            if (0xb < *(byte *)(uVar5 + param_1)) {
              return 0xffffffec;
            }
            piVar1 = (int *)(param_3 + (uint)*(byte *)(uVar5 + param_1) * 4);
            *piVar1 = *piVar1 + 1;
            pbVar2 = (byte *)(uVar5 + param_1);
            uVar5 = uVar5 + 1;
            uVar7 = uVar7 + ((1 << (*pbVar2 & 0x1f)) >> 1);
          } while (uVar5 < uVar6);
          if (uVar7 != 0) {
            iVar3 = 0x1f;
            if (uVar7 != 0) {
              for (; uVar7 >> iVar3 == 0; iVar3 = iVar3 + -1) {
              }
            }
            uVar5 = iVar3 + 1;
            if (uVar5 < 0xd) {
              uVar7 = (1 << ((byte)uVar5 & 0x1f)) - uVar7;
              *param_5 = uVar5;
              iVar3 = 0x1f;
              if (uVar7 != 0) {
                for (; uVar7 >> iVar3 == 0; iVar3 = iVar3 + -1) {
                }
              }
              iVar4 = 0x1f;
              if (uVar7 != 0) {
                for (; uVar7 >> iVar4 == 0; iVar4 = iVar4 + -1) {
                }
              }
              if (1 << ((byte)iVar4 & 0x1f) == uVar7) {
                *(char *)(uVar6 + param_1) = (char)(iVar3 + 1);
                piVar1 = (int *)(param_3 + (iVar3 + 1) * 4);
                *piVar1 = *piVar1 + 1;
                if ((1 < *(uint *)(param_3 + 4)) && ((*(uint *)(param_3 + 4) & 1) == 0)) {
                  *param_4 = uVar6 + 1;
                  return param_7;
                }
              }
            }
          }
        }
        return 0xffffffec;
      }
    }
  }
  return 0xffffffb8;
}



/* FUNCTION 22061 ; VA 0x00ab24d0 ; FUN_00ab24d0 */

bool FUN_00ab24d0(uint param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  
  if (param_2 < param_1) {
    uVar1 = (param_2 << 4) / param_1;
  }
  else {
    uVar1 = 0xf;
  }
  uVar2 = *(int *)(&DAT_01947504 + uVar1 * 0x18) * (param_1 >> 8) +
          *(int *)(&DAT_01947500 + uVar1 * 0x18);
  return (uVar2 >> 3) + uVar2 <
         *(int *)(&DAT_019474fc + uVar1 * 0x18) * (param_1 >> 8) +
         *(int *)(&DAT_019474f8 + uVar1 * 0x18);
}



/* FUNCTION 22062 ; VA 0x00ab2530 ; FUN_00ab2530 */

/* WARNING: Type propagation algorithm not settling */

char * FUN_00ab2530(char *param_1,char *param_2,int param_3,char *param_4,int param_5)

{
  byte bVar1;
  char *pcVar2;
  char *pcVar3;
  undefined4 uVar4;
  uint uVar5;
  char *pcVar6;
  byte *pbVar7;
  char *pcVar8;
  undefined auStack_250 [236];
  char acStack_164 [256];
  undefined auStack_64 [12];
  undefined auStack_58 [52];
  undefined auStack_24 [12];
  char acStack_18 [16];
  char *pcStack_8;
  
  pcVar2 = param_4;
  if ((char *)0xff < param_4) {
    return (char *)0xffffffd2;
  }
  uVar5 = 1;
  acStack_18[0] = '\0';
  if (1 < param_5 + 1U) {
    do {
      acStack_18[uVar5] = ((char)param_5 - (char)uVar5) + '\x01';
      uVar5 = uVar5 + 1;
    } while (uVar5 < param_5 + 1U);
  }
  pcVar6 = (char *)0x0;
  if (param_4 != (char *)0x0) {
    pbVar7 = (byte *)(param_3 + 2);
    do {
      bVar1 = *pbVar7;
      pbVar7 = pbVar7 + 4;
      acStack_164[(int)pcVar6] = acStack_18[bVar1];
      pcVar6 = pcVar6 + 1;
    } while (pcVar6 < param_4);
  }
  param_4 = (char *)0xc;
  pcVar6 = param_1 + 1;
  if ((char *)0x1 < pcVar2) {
    pcVar3 = (char *)FUN_00ab0850(auStack_58,&param_4,acStack_164,pcVar2);
    if ((char *)0xffffff88 < pcVar3) {
      return pcVar3;
    }
    if (pcVar3 == pcVar2) {
      pcStack_8 = (char *)0x1;
      goto LAB_00ab26b5;
    }
    if (pcVar3 != (char *)0x1) {
      uVar4 = FUN_00ab14f0(6,pcVar2,param_4);
      pcVar3 = (char *)FUN_00ab12e0(auStack_24,uVar4,auStack_58,pcVar2,param_4);
      if ((char *)0xffffff88 < pcVar3) {
        return pcVar3;
      }
      pcStack_8 = (char *)FUN_00ab17c0(pcVar6,param_2 + 0xffffffff,auStack_24,param_4,uVar4);
      if ((char *)0xffffff88 < pcStack_8) {
        return pcStack_8;
      }
      pcStack_8 = pcStack_8 + (int)pcVar6;
      pcVar3 = (char *)FUN_00ab0480(auStack_250,auStack_24,param_4,uVar4,auStack_64,0x40);
      if ((char *)0xffffff88 < pcVar3) {
        return pcVar3;
      }
      pcVar3 = (char *)FUN_00aa5900(pcStack_8,pcVar6 + (int)(param_2 + (-1 - (int)pcStack_8)),
                                    acStack_164,pcVar2,auStack_250,
                                    pcVar2 + ((uint)pcVar2 >> 7) <=
                                    pcVar6 + (int)(param_2 + (-1 - (int)pcStack_8)));
      if ((char *)0xffffff88 < pcVar3) {
        return pcVar3;
      }
      if (pcVar3 != (char *)0x0) {
        pcStack_8 = pcStack_8 + ((int)pcVar3 - (int)pcVar6);
        if ((char *)0xffffff88 < pcStack_8) {
          return pcStack_8;
        }
        goto LAB_00ab26b5;
      }
    }
  }
  pcStack_8 = (char *)0x0;
LAB_00ab26b5:
  if ((char *)0x1 < pcStack_8 && pcStack_8 < (char *)((uint)pcVar2 >> 1)) {
    *param_1 = (char)pcStack_8;
    return pcStack_8 + 1;
  }
  if (pcVar2 < (char *)0x81) {
    pcVar6 = (char *)(((uint)(pcVar2 + 1) >> 1) + 1);
    if (pcVar6 <= param_2) {
      acStack_164[(int)pcVar2] = '\0';
      *param_1 = (char)pcVar2 + '\x7f';
      pcVar3 = (char *)0x0;
      if (pcVar2 != (char *)0x0) {
        do {
          pcVar8 = pcVar3 + 2;
          param_1[((uint)pcVar3 >> 1) + 1] =
               acStack_164[(int)pcVar3] * '\x10' + (acStack_164 + 1)[(int)pcVar3];
          pcVar3 = pcVar8;
        } while (pcVar8 < pcVar2);
      }
      return pcVar6;
    }
    return (char *)0xffffffba;
  }
  return (char *)0xffffffff;
}



/* FUNCTION 22063 ; VA 0x00ab2750 ; FUN_00ab2750 */

undefined8 FUN_00ab2750(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint *puVar11;
  uint uVar12;
  uint *puVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  int iVar17;
  uint uVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  longlong lVar21;
  ulonglong uVar22;
  undefined8 uVar23;
  uint uStack_10;
  
  puVar11 = (uint *)((int)param_1 + param_1[0x12] + 0x28);
  puVar13 = param_1 + 10;
  uVar10 = *param_1;
  if ((param_1[1] == 0) && (uVar10 < 0x20)) {
    uVar16 = param_1[6] + uVar10;
    iVar17 = uVar16 + 0x165667c5;
    iVar14 = param_1[7] + (uint)CARRY4(param_1[6],uVar10) + 0x27d4eb2f + (uint)(0xe9a9983a < uVar16)
    ;
  }
  else {
    uVar16 = param_1[3];
    uVar1 = param_1[2];
    uVar2 = param_1[5];
    uVar15 = param_1[4] << 7 | uVar2 >> 0x19;
    uVar8 = uVar1 << 1 | uVar16 >> 0x1f;
    uVar3 = param_1[6];
    uVar4 = param_1[4];
    uVar5 = param_1[7];
    uVar12 = uVar3 << 0xc | uVar5 >> 0x14;
    uVar18 = param_1[8] << 0x12 | param_1[9] >> 0xe;
    uVar6 = param_1[9];
    uVar7 = param_1[8];
    uVar10 = uVar18 + uVar12;
    uVar9 = uVar10 + uVar15;
    uVar22 = FUN_016f39b0(param_1[2],param_1[3],0x27d4eb4f,0xc2b2ae3d);
    uVar23 = FUN_016f39b0((int)uVar22 << 0x1f | (uint)((uVar22 >> 1) >> 0x20),(int)(uVar22 >> 1),
                          0x85ebca87,0x9e3779b1);
    lVar21 = FUN_016f39b0((uint)uVar23 ^ uVar9 + uVar8,
                          (uint)((ulonglong)uVar23 >> 0x20) ^
                          (uVar6 << 0x12 | uVar7 >> 0xe) + (uVar5 << 0xc | uVar3 >> 0x14) +
                          (uint)CARRY4(uVar18,uVar12) + (uVar2 << 7 | uVar4 >> 0x19) +
                          (uint)CARRY4(uVar10,uVar15) + (uVar16 << 1 | uVar1 >> 0x1f) +
                          (uint)CARRY4(uVar9,uVar8),0x85ebca87,0x9e3779b1);
    uVar22 = FUN_016f39b0(param_1[4],param_1[5],0x27d4eb4f,0xc2b2ae3d);
    uVar22 = FUN_016f39b0((int)uVar22 << 0x1f | (uint)((uVar22 >> 1) >> 0x20),(int)(uVar22 >> 1),
                          0x85ebca87,0x9e3779b1);
    lVar21 = FUN_016f39b0(lVar21 + 0x85ebca77c2b2ae63U ^ uVar22,0x85ebca87,0x9e3779b1);
    uVar22 = FUN_016f39b0(param_1[6],param_1[7],0x27d4eb4f,0xc2b2ae3d);
    uVar22 = FUN_016f39b0((int)uVar22 << 0x1f | (uint)((uVar22 >> 1) >> 0x20),(int)(uVar22 >> 1),
                          0x85ebca87,0x9e3779b1);
    lVar21 = FUN_016f39b0(lVar21 + 0x85ebca77c2b2ae63U ^ uVar22,0x85ebca87,0x9e3779b1);
    uVar22 = FUN_016f39b0(param_1[8],param_1[9],0x27d4eb4f,0xc2b2ae3d);
    uVar22 = FUN_016f39b0((int)uVar22 << 0x1f | (uint)((uVar22 >> 1) >> 0x20),(int)(uVar22 >> 1),
                          0x85ebca87,0x9e3779b1);
    uVar23 = FUN_016f39b0(lVar21 + 0x85ebca77c2b2ae63U ^ uVar22,0x85ebca87,0x9e3779b1);
    uVar10 = (uint)uVar23 + *param_1;
    iVar17 = uVar10 + 0xc2b2ae63;
    iVar14 = (int)((ulonglong)uVar23 >> 0x20) + param_1[1] + (uint)CARRY4((uint)uVar23,*param_1) +
             -0x7a143589 + (uint)(0x3d4d519c < uVar10);
  }
  uVar22 = CONCAT44(iVar14,iVar17);
  for (param_1 = param_1 + 0xc; param_1 <= puVar11; param_1 = param_1 + 2) {
    uVar19 = FUN_016f39b0(*puVar13,puVar13[1],0x27d4eb4f,0xc2b2ae3d);
    uVar20 = FUN_016f39b0((int)uVar19 << 0x1f | (uint)((uVar19 >> 1) >> 0x20),(int)(uVar19 >> 1),
                          0x85ebca87,0x9e3779b1);
    uVar19 = (uVar22 ^ uVar20) >> 5;
    lVar21 = FUN_016f39b0((int)(uVar22 ^ uVar20) << 0x1b | (uint)(uVar19 >> 0x20),(int)uVar19,
                          0x85ebca87,0x9e3779b1);
    uVar22 = lVar21 + 0x85ebca77c2b2ae63;
    puVar13 = puVar13 + 2;
  }
  if (puVar13 + 1 <= puVar11) {
    uVar10 = (uint)((ulonglong)*puVar13 * 0x85ebca87) ^ (uint)uVar22;
    uVar16 = *puVar13 * -0x61c8864f + (int)((ulonglong)*puVar13 * 0x85ebca87 >> 0x20) ^
             (uint)(uVar22 >> 0x20);
    lVar21 = FUN_016f39b0(uVar10 << 0x17 | uVar16 >> 9,uVar16 << 0x17 | uVar10 >> 9,0x27d4eb4f,
                          0xc2b2ae3d);
    uVar22 = lVar21 + 0x165667b19e3779f9;
    puVar13 = puVar13 + 1;
  }
  uStack_10 = 0;
  uVar10 = (int)puVar11 - (int)puVar13;
  if (puVar11 < puVar13) {
    uVar10 = 0;
  }
  if (uVar10 != 0) {
    do {
      uVar20 = FUN_016f39b0(*(undefined *)puVar13,0,0x165667c5,0x27d4eb2f);
      uVar19 = (uVar22 ^ uVar20) >> 0x15;
      uVar22 = FUN_016f39b0((int)(uVar22 ^ uVar20) << 0xb | (uint)(uVar19 >> 0x20),(int)uVar19,
                            0x85ebca87,0x9e3779b1);
      puVar13 = (uint *)((int)puVar13 + 1);
      uStack_10 = uStack_10 + 1;
    } while (uStack_10 < uVar10);
  }
  uVar10 = (uint)(uVar22 >> 0x20);
  uVar22 = FUN_016f39b0(uVar10 >> 1 ^ (uint)uVar22,uVar10,0x27d4eb4f,0xc2b2ae3d);
  uVar23 = FUN_016f39b0(uVar22 >> 0x1d ^ uVar22,0x9e3779f9,0x165667b1);
  uVar10 = (uint)((ulonglong)uVar23 >> 0x20);
  return CONCAT44(uVar10,(uint)uVar23 ^ uVar10);
}



/* FUNCTION 22064 ; VA 0x00ab2b00 ; FUN_00ab2b00 */

undefined4 FUN_00ab2b00(undefined4 *param_1,uint param_2,int param_3)

{
  undefined8 uStack_c;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = param_2 + 0xadc0b5d6;
  param_1[3] = param_3 + 0x60ea27ee + (uint)(0x523f4a29 < param_2);
  param_1[4] = param_2 + 0x27d4eb4f;
  param_1[5] = param_3 + -0x3d4d51c3 + (uint)(0xd82b14b0 < param_2);
  param_1[6] = param_2;
  param_1[7] = param_3;
  param_1[8] = param_2 + 0x7a143579;
  param_1[9] = param_3 + 0x61c8864e + (uint)(0x85ebca86 < param_2);
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  *(undefined8 *)(param_1 + 0x14) = uStack_c;
  return 0;
}



/* FUNCTION 22065 ; VA 0x00ab2bb0 ; FUN_00ab2bb0 */

undefined4 FUN_00ab2bb0(uint *param_1,undefined4 *param_2,uint param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  undefined8 uVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  
  uVar3 = param_1[0x12];
  uVar2 = *param_1;
  *param_1 = *param_1 + param_3;
  puVar1 = (undefined4 *)((int)param_2 + param_3);
  param_1[1] = param_1[1] + (uint)CARRY4(uVar2,param_3);
  if (uVar3 + param_3 < 0x20) {
    FUN_0170c6f0((int)param_1 + uVar3 + 0x28,param_2,param_3);
    param_1[0x12] = param_1[0x12] + param_3;
    return 0;
  }
  if (uVar3 != 0) {
    FUN_0170c6f0((int)param_1 + uVar3 + 0x28,param_2,0x20 - uVar3);
    uVar4 = FUN_016f39b0(param_1[10],param_1[0xb],0x27d4eb4f,0xc2b2ae3d);
    uVar2 = (uint)uVar4 + param_1[2];
    uVar3 = (int)((ulonglong)uVar4 >> 0x20) + param_1[3] + (uint)CARRY4((uint)uVar4,param_1[2]);
    uVar4 = FUN_016f39b0(uVar2 * -0x80000000 | uVar3 >> 1,uVar3 * -0x80000000 | uVar2 >> 1,
                         0x85ebca87,0x9e3779b1);
    *(undefined8 *)(param_1 + 2) = uVar4;
    uVar4 = FUN_016f39b0(param_1[0xc],param_1[0xd],0x27d4eb4f,0xc2b2ae3d);
    uVar2 = (uint)uVar4 + param_1[4];
    uVar3 = (int)((ulonglong)uVar4 >> 0x20) + param_1[5] + (uint)CARRY4((uint)uVar4,param_1[4]);
    uVar4 = FUN_016f39b0(uVar2 * -0x80000000 | uVar3 >> 1,uVar3 * -0x80000000 | uVar2 >> 1,
                         0x85ebca87,0x9e3779b1);
    *(undefined8 *)(param_1 + 4) = uVar4;
    uVar4 = FUN_016f39b0(param_1[0xe],param_1[0xf],0x27d4eb4f,0xc2b2ae3d);
    uVar2 = (uint)uVar4 + param_1[6];
    uVar3 = (int)((ulonglong)uVar4 >> 0x20) + param_1[7] + (uint)CARRY4((uint)uVar4,param_1[6]);
    uVar4 = FUN_016f39b0(uVar2 * -0x80000000 | uVar3 >> 1,uVar3 * -0x80000000 | uVar2 >> 1,
                         0x85ebca87,0x9e3779b1);
    *(undefined8 *)(param_1 + 6) = uVar4;
    uVar4 = FUN_016f39b0(param_1[0x10],param_1[0x11],0x27d4eb4f,0xc2b2ae3d);
    uVar2 = (uint)uVar4 + param_1[8];
    uVar3 = (int)((ulonglong)uVar4 >> 0x20) + param_1[9] + (uint)CARRY4((uint)uVar4,param_1[8]);
    uVar4 = FUN_016f39b0(uVar2 * -0x80000000 | uVar3 >> 1,uVar3 * -0x80000000 | uVar2 >> 1,
                         0x85ebca87,0x9e3779b1);
    *(undefined8 *)(param_1 + 8) = uVar4;
    param_2 = (undefined4 *)((int)param_2 + (0x20 - param_1[0x12]));
    param_1[0x12] = 0;
  }
  if (param_2 + 8 <= puVar1) {
    lVar6 = *(longlong *)(param_1 + 2);
    lVar7 = *(longlong *)(param_1 + 4);
    lVar8 = *(longlong *)(param_1 + 6);
    lVar9 = *(longlong *)(param_1 + 8);
    do {
      lVar5 = FUN_016f39b0(*param_2,param_2[1],0x27d4eb4f,0xc2b2ae3d);
      uVar2 = (uint)(lVar5 + lVar6);
      uVar3 = (uint)((ulonglong)(lVar5 + lVar6) >> 0x20);
      lVar6 = FUN_016f39b0(uVar2 * -0x80000000 | uVar3 >> 1,uVar3 * -0x80000000 | uVar2 >> 1,
                           0x85ebca87,0x9e3779b1);
      lVar5 = FUN_016f39b0(param_2[2],param_2[3],0x27d4eb4f,0xc2b2ae3d);
      uVar2 = (uint)(lVar5 + lVar7);
      uVar3 = (uint)((ulonglong)(lVar5 + lVar7) >> 0x20);
      lVar7 = FUN_016f39b0(uVar2 * -0x80000000 | uVar3 >> 1,uVar3 * -0x80000000 | uVar2 >> 1,
                           0x85ebca87,0x9e3779b1);
      lVar5 = FUN_016f39b0(param_2[4],param_2[5],0x27d4eb4f,0xc2b2ae3d);
      uVar2 = (uint)(lVar5 + lVar8);
      uVar3 = (uint)((ulonglong)(lVar5 + lVar8) >> 0x20);
      lVar8 = FUN_016f39b0(uVar2 * -0x80000000 | uVar3 >> 1,uVar3 * -0x80000000 | uVar2 >> 1,
                           0x85ebca87,0x9e3779b1);
      lVar5 = FUN_016f39b0(param_2[6],param_2[7],0x27d4eb4f,0xc2b2ae3d);
      uVar2 = (uint)(lVar5 + lVar9);
      uVar3 = (uint)((ulonglong)(lVar5 + lVar9) >> 0x20);
      lVar9 = FUN_016f39b0(uVar2 * -0x80000000 | uVar3 >> 1,uVar3 * -0x80000000 | uVar2 >> 1,
                           0x85ebca87,0x9e3779b1);
      param_2 = param_2 + 8;
    } while (param_2 <= puVar1 + -8);
    param_1[2] = (uint)lVar6;
    *(longlong *)(param_1 + 4) = lVar7;
    param_1[6] = (uint)lVar8;
    param_1[3] = (uint)((ulonglong)lVar6 >> 0x20);
    param_1[7] = (uint)((ulonglong)lVar8 >> 0x20);
    *(longlong *)(param_1 + 8) = lVar9;
  }
  if (param_2 < puVar1) {
    FUN_0170c6f0(param_1 + 10,param_2,(int)puVar1 - (int)param_2);
    param_1[0x12] = (int)puVar1 - (int)param_2;
  }
  return 0;
}



/* FUNCTION 22066 ; VA 0x00ab2ec0 ; FUN_00ab2ec0 */

undefined4
FUN_00ab2ec0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_2d0 [236];
  int iStack_1e4;
  undefined8 uStack_170;
  undefined4 uStack_168;
  undefined auStack_164 [244];
  undefined auStack_70 [44];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_0170d1f0(auStack_2d0,0,0x160);
  FUN_0170d1f0(auStack_164,0,0xf4);
  uStack_168 = DAT_01947680;
  uStack_170 = DAT_01947678;
  puVar3 = (undefined4 *)FUN_00abd620(auStack_70,param_5,param_4,0,0);
  uStack_8 = 0;
  uStack_10 = 0;
  uStack_c = 0;
  uVar1 = *(undefined8 *)(puVar3 + 4);
  uStack_3c = puVar3[6];
  uStack_1c._0_4_ = (undefined4)uVar1;
  uStack_1c._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
  uVar4 = uStack_1c._4_4_;
  uStack_44 = (undefined4)uStack_1c;
  uStack_40 = uStack_1c._4_4_;
  uStack_38 = 1;
  uVar2 = (undefined4)uStack_1c;
  uStack_1c = uVar1;
  uStack_14 = uStack_3c;
  uVar4 = FUN_00aab820(auStack_2d0,param_1,param_2,param_3,param_4,0,0,*puVar3,puVar3[1],puVar3[2],
                       puVar3[3],uVar2,uVar4,uStack_3c,1,0);
  if (iStack_1e4 != 0) {
    FUN_017168b0();
  }
  return uVar4;
}



/* FUNCTION 22067 ; VA 0x00ab2fb0 ; FUN_00ab2fb0 */

int FUN_00ab2fb0(int param_1,uint *param_2,int param_3)

{
  char *pcVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  char *pcVar5;
  int iVar6;
  uint uVar7;
  uint *puVar8;
  uint *puVar9;
  uint uVar10;
  uint *puVar11;
  char *pcVar12;
  int iVar13;
  int iVar14;
  int iStack_3c;
  uint *puStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  int iStack_24;
  uint *puStack_20;
  uint *puStack_1c;
  uint uStack_18;
  uint uStack_14;
  uint *puStack_10;
  uint *puStack_c;
  uint *puStack_8;
  
  puVar3 = (uint *)(param_3 + (int)param_2);
  uVar10 = *(uint *)(param_1 + 0x194);
  puStack_10 = puVar3 + -2;
  uVar4 = *(uint *)(param_1 + 0x198);
  puStack_38 = (uint *)(*(int *)(param_1 + 0xc) + *(int *)(param_1 + 4));
  iStack_30 = 1 << ((byte)*(undefined4 *)(param_1 + 0x9c) & 0x1f);
  uStack_2c = *(undefined4 *)(param_1 + 0xa0);
  puVar11 = (uint *)((uint)(param_2 == puStack_38) + (int)param_2);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  uVar7 = (int)puVar11 - (int)puStack_38;
  uStack_18 = 0;
  if (uVar4 <= uVar7) {
    uStack_18 = uVar4;
  }
  uStack_14 = 0;
  if (uVar10 <= uVar7) {
    uStack_14 = uVar10;
    uVar10 = -(uint)(uVar7 < uVar4) & uVar4;
  }
  if (puVar11 < puStack_10) {
    do {
      pcVar12 = (char *)0x0;
      puStack_8 = (uint *)((int)puVar11 + 1);
      iVar13 = 0;
      puStack_1c = (uint *)((int)puVar11 - uStack_14);
      puStack_c = (uint *)0x0;
      uStack_28 = (uint)(uStack_14 != 0);
      if (uStack_14 != 0 && *puStack_8 == *(uint *)((int)puStack_1c + 1)) {
        puStack_20 = (uint *)((int)puVar11 + 5);
        puVar9 = (uint *)((int)puStack_1c + 5);
        puVar8 = puStack_20;
        if (puStack_20 < (uint *)((int)puVar3 + -3)) {
LAB_00ab3092:
          uVar4 = *puVar8 ^ *puVar9;
          if (uVar4 == 0) goto code_r0x00ab3098;
          uVar7 = 0;
          if (uVar4 != 0) {
            for (; (uVar4 >> uVar7 & 1) == 0; uVar7 = uVar7 + 1) {
            }
          }
          pcVar12 = (char *)(((uVar7 >> 3) - (int)puStack_20) + (int)puVar8);
          goto LAB_00ab30ca;
        }
LAB_00ab30a2:
        if ((puVar8 < (uint *)((int)puVar3 + -1)) && (*(short *)puVar9 == *(short *)puVar8)) {
          puVar8 = (uint *)((int)puVar8 + 2);
          puVar9 = (uint *)((int)puVar9 + 2);
        }
        if ((puVar8 < puVar3) && (*(char *)puVar9 == *(char *)puVar8)) {
          puVar8 = (uint *)((int)puVar8 + 1);
        }
        pcVar12 = (char *)((int)puVar8 - (int)puStack_20);
LAB_00ab30ca:
        pcVar12 = pcVar12 + 4;
      }
      iStack_3c = 99999999;
      pcVar5 = (char *)FUN_00aa86b0(param_1,puVar11,puVar3,&iStack_3c,iStack_30,uStack_2c);
      if (pcVar12 < pcVar5) {
        puStack_c = (uint *)iStack_3c;
        pcVar12 = pcVar5;
        iVar13 = iStack_3c;
        puStack_8 = puVar11;
      }
      if (pcVar12 < (char *)0x4) {
        puVar11 = (uint *)((int)puVar11 + ((int)puVar11 - (int)param_2 >> 8) + 1);
      }
      else {
        pcVar5 = pcVar12;
        puVar8 = puStack_c;
        if (puVar11 < puStack_10) {
          puStack_20 = puVar11 + 1;
          puStack_c = puStack_1c + 1;
          do {
            puStack_1c = (uint *)((int)puStack_1c + 1);
            puStack_c = (uint *)((int)puStack_c + 1);
            puStack_20 = (uint *)((int)puStack_20 + 1);
            puVar9 = (uint *)((int)puVar11 + 1);
            pcVar5 = pcVar12;
            if ((iVar13 != 0) && ((uStack_28 & *puVar9 == *puStack_1c) != 0)) {
              iVar6 = FUN_00abcfb0(puStack_20,puStack_c,puVar3);
              pcVar1 = (char *)(iVar6 + 4);
              iVar6 = 0x1f;
              if (iVar13 + 1U != 0) {
                for (; iVar13 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                }
              }
              if (((char *)0x3 < pcVar1) && (((int)pcVar12 * 3 - iVar6) + 1 < (int)pcVar1 * 3)) {
                iVar13 = 0;
                pcVar5 = pcVar1;
                puStack_8 = puVar9;
              }
            }
            iStack_24 = 99999999;
            pcVar12 = (char *)FUN_00aa86b0(param_1,puVar9,puVar3,&iStack_24,iStack_30,uStack_2c);
            iVar6 = 0x1f;
            if (iStack_24 + 1U != 0) {
              for (; iStack_24 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
              }
            }
            iVar2 = 0x1f;
            if (iVar13 + 1U != 0) {
              for (; iVar13 + 1U >> iVar2 == 0; iVar2 = iVar2 + -1) {
              }
            }
            if ((pcVar12 < &DAT_00000004) ||
               (iVar14 = iStack_24, (int)pcVar12 * 4 - iVar6 <= ((int)pcVar5 * 4 - iVar2) + 4)) {
              puVar8 = (uint *)iVar13;
              if (puStack_10 <= puVar9) break;
              puVar9 = (uint *)((int)puVar11 + 2);
              puStack_c = (uint *)((int)puStack_c + 1);
              puStack_1c = (uint *)((int)puStack_1c + 1);
              puStack_20 = (uint *)((int)puStack_20 + 1);
              if ((iVar13 != 0) && ((uStack_28 & *puVar9 == *puStack_1c) != 0)) {
                iVar6 = FUN_00abcfb0(puStack_20,puStack_c,puVar3);
                pcVar12 = (char *)(iVar6 + 4);
                iVar6 = 0x1f;
                if (iVar13 + 1U != 0) {
                  for (; iVar13 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                  }
                }
                if (((char *)0x3 < pcVar12) &&
                   (iVar6 = ((int)pcVar5 * 4 - iVar6) + 1,
                   (int)pcVar12 * 4 - iVar6 != 0 && iVar6 <= (int)pcVar12 * 4)) {
                  iVar13 = 0;
                  pcVar5 = pcVar12;
                  puStack_8 = puVar9;
                }
              }
              iStack_34 = 99999999;
              pcVar12 = (char *)FUN_00aa86b0(param_1,puVar9,puVar3,&iStack_34,iStack_30,uStack_2c);
              iVar6 = 0x1f;
              if (iStack_34 + 1U != 0) {
                for (; iStack_34 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                }
              }
              iVar2 = 0x1f;
              if (iVar13 + 1U != 0) {
                for (; iVar13 + 1U >> iVar2 == 0; iVar2 = iVar2 + -1) {
                }
              }
              puVar8 = (uint *)iVar13;
              if ((pcVar12 < &DAT_00000004) ||
                 (iVar14 = iStack_34, (int)pcVar12 * 4 - iVar6 <= ((int)pcVar5 * 4 - iVar2) + 7))
              break;
            }
            puVar11 = puVar9;
            pcVar5 = pcVar12;
            iVar13 = iVar14;
            puVar8 = (uint *)iVar14;
            puStack_8 = puVar9;
          } while (puVar9 < puStack_10);
        }
        puStack_c = puVar8;
        puVar11 = puStack_8;
        if (iVar13 != 0) {
          puVar8 = (uint *)iVar13;
          if (param_2 < puStack_8) {
            do {
              puVar8 = puStack_c;
              if ((puVar11 <= (uint *)((int)puStack_38 + iVar13 + -2)) ||
                 (*(char *)((int)puVar11 + -1) != *(char *)((int)puVar11 + (1 - iVar13)))) break;
              puVar11 = (uint *)((int)puVar11 + -1);
              pcVar5 = pcVar5 + 1;
            } while (param_2 < puVar11);
          }
          uStack_18 = uStack_14;
          uStack_14 = (int)puVar8 - 2;
        }
        uVar4 = (int)puVar11 - (int)param_2;
        puVar8 = *(uint **)(param_1 + 0x17c);
        puVar9 = (uint *)(uVar4 + (int)puVar8);
        do {
          *puVar8 = *param_2;
          puVar8[1] = param_2[1];
          puVar8 = puVar8 + 2;
          param_2 = param_2 + 2;
        } while (puVar8 < puVar9);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar4;
        if (0xffff < uVar4) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar4;
        **(int **)(param_1 + 0x174) = (int)puStack_c + 1;
        if ((char *)0xffff < pcVar5 + -3) {
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)(pcVar5 + -3);
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        puVar11 = (uint *)((int)puVar11 + (int)pcVar5);
        param_2 = puVar11;
        if (puStack_10 < puVar11) break;
        do {
          param_2 = puVar11;
          if (uStack_18 == 0 || *puVar11 != *(uint *)((int)puVar11 - uStack_18)) break;
          iVar13 = FUN_00abcfb0(puVar11 + 1,(uint *)((int)puVar11 - uStack_18) + 1,puVar3);
          uVar4 = uStack_14;
          uStack_14 = uStack_18;
          uStack_18 = uVar4;
          FUN_00abd980(param_1 + 0x170,0,puVar11,0,iVar13 + 1);
          puVar11 = (uint *)((int)puVar11 + iVar13 + 4);
          param_2 = puVar11;
        } while (puVar11 <= puStack_10);
      }
    } while (puVar11 < puStack_10);
  }
  uVar4 = uVar10;
  if (uStack_14 != 0) {
    uVar4 = uStack_14;
  }
  *(uint *)(param_1 + 0x1a0) = uVar4;
  if (uStack_18 != 0) {
    uVar10 = uStack_18;
  }
  *(uint *)(param_1 + 0x1a4) = uVar10;
  return (int)puVar3 - (int)param_2;
code_r0x00ab3098:
  puVar8 = puVar8 + 1;
  puVar9 = puVar9 + 1;
  if ((uint *)((int)puVar3 + -3) <= puVar8) goto LAB_00ab30a2;
  goto LAB_00ab3092;
}



/* FUNCTION 22068 ; VA 0x00ab34a0 ; FUN_00ab34a0 */

int FUN_00ab34a0(int param_1,int *param_2,int param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  char *pcVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  int *piVar11;
  int *piVar12;
  uint uStack_50;
  int iStack_4c;
  int *piStack_48;
  int iStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  char *pcStack_34;
  int *piStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  int *piStack_10;
  char *pcStack_c;
  int *piStack_8;
  
  pcStack_c = (char *)(param_3 + (int)param_2);
  iStack_18 = *(int *)(param_1 + 4);
  piStack_14 = (int *)(pcStack_c + -8);
  piStack_48 = (int *)(param_1 + 0x170);
  piStack_10 = *(int **)(param_1 + 0xc);
  piStack_1c = (int *)(iStack_18 + (int)piStack_10);
  piStack_30 = *(int **)(param_1 + 0x10);
  iStack_28 = *(int *)(param_1 + 8);
  pcStack_34 = (char *)((int)piStack_10 + iStack_28);
  piVar2 = (int *)((int)piStack_30 + iStack_28);
  iStack_40 = 1 << ((byte)*(undefined4 *)(param_1 + 0x9c) & 0x1f);
  uStack_3c = *(undefined4 *)(param_1 + 0xa0);
  iStack_20 = *(int *)(param_1 + 0x194);
  iStack_2c = *(int *)(param_1 + 0x198);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  piVar9 = (int *)((uint)(param_2 == piStack_1c) + (int)param_2);
  if (piVar9 < pcStack_c + -8) {
    do {
      piVar11 = (int *)((int)piVar9 + (-iStack_20 - iStack_18));
      uStack_50 = 0;
      param_3 = 0;
      piStack_8 = (int *)((int)piVar9 + 1);
      piStack_24 = (int *)((int)piVar11 + 1);
      iVar3 = iStack_18;
      if (piStack_24 < piStack_10) {
        iVar3 = iStack_28;
      }
      if ((piStack_30 < (int *)((int)piVar11 + 1U) &&
           (char *)0x2 < (char *)((int)piStack_10 + (-1 - (int)((int)piVar11 + 1)))) &&
         (*piStack_8 == *(int *)(iVar3 + (int)piStack_24))) {
        piVar10 = (int *)(iVar3 + (int)piStack_24) + 1;
        pcVar6 = pcStack_c;
        if (piStack_24 < piStack_10) {
          pcVar6 = pcStack_34;
        }
        pcVar7 = pcStack_c;
        if (pcVar6 + (((int)piVar9 + 5) - (int)piVar10) < pcStack_c) {
          pcVar7 = pcVar6 + (((int)piVar9 + 5) - (int)piVar10);
        }
        iVar3 = FUN_00abcfb0((char *)((int)piVar9 + 5),piVar10,pcVar7);
        if ((char *)(iVar3 + (int)piVar10) == pcVar6) {
          iVar4 = FUN_00abcfb0((char *)(iVar3 + 5 + (int)piVar9),piStack_1c,pcStack_c);
          iVar3 = iVar3 + iVar4;
        }
        uStack_50 = iVar3 + 4;
      }
      iStack_4c = 99999999;
      uVar5 = FUN_00aa8740(param_1,piVar9,pcStack_c,&iStack_4c,iStack_40,uStack_3c);
      if (uStack_50 < uVar5) {
        param_3 = iStack_4c;
        uStack_50 = uVar5;
        piStack_8 = piVar9;
      }
      if (uStack_50 < 4) {
        piVar9 = (int *)((int)piVar9 + ((int)piVar9 - (int)param_2 >> 8) + 1);
      }
      else {
        if (piVar9 < piStack_14) {
          piStack_24 = piVar9 + 1;
          do {
            piStack_24 = (int *)((int)piStack_24 + 1);
            piVar10 = (int *)((int)piVar9 + 1);
            piVar12 = (int *)((int)piVar11 + 1);
            if (param_3 != 0) {
              iVar3 = iStack_18;
              if (piVar12 < piStack_10) {
                iVar3 = iStack_28;
              }
              if ((piStack_30 < piVar12 &&
                   (char *)0x2 < (char *)((int)piStack_10 + (-1 - (int)piVar12))) &&
                 (*piVar10 == *(int *)(iVar3 + (int)piVar12))) {
                pcVar6 = pcStack_c;
                if (piVar12 < piStack_10) {
                  pcVar6 = pcStack_34;
                }
                iVar3 = FUN_00abd020(piStack_24,(char *)(iVar3 + 4 + (int)piVar12),pcStack_c,pcVar6,
                                     piStack_1c);
                uVar5 = iVar3 + 4;
                iVar3 = 0x1f;
                if (param_3 + 1U != 0) {
                  for (; param_3 + 1U >> iVar3 == 0; iVar3 = iVar3 + -1) {
                  }
                }
                if ((3 < uVar5) && ((int)((uStack_50 * 3 - iVar3) + 1) < (int)(uVar5 * 3))) {
                  param_3 = 0;
                  uStack_50 = uVar5;
                  piStack_8 = piVar10;
                }
              }
            }
            iStack_38 = 99999999;
            uVar5 = FUN_00aa8740(param_1,piVar10,pcStack_c,&iStack_38,iStack_40,uStack_3c);
            iVar3 = 0x1f;
            if (iStack_38 + 1U != 0) {
              for (; iStack_38 + 1U >> iVar3 == 0; iVar3 = iVar3 + -1) {
              }
            }
            uVar1 = param_3 + 1;
            iVar4 = 0x1f;
            if (uVar1 != 0) {
              for (; uVar1 >> iVar4 == 0; iVar4 = iVar4 + -1) {
              }
            }
            if ((uVar5 < 4) ||
               (iVar8 = iStack_38, (int)(uVar5 * 4 - iVar3) <= (int)((uStack_50 * 4 - iVar4) + 4)))
            {
              if (piStack_14 <= piVar10) break;
              piStack_24 = (int *)((int)piStack_24 + 1);
              piVar10 = (int *)((int)piVar9 + 2);
              piVar12 = (int *)((int)piVar11 + 2);
              if (param_3 != 0) {
                iVar3 = iStack_18;
                if (piVar12 < piStack_10) {
                  iVar3 = iStack_28;
                }
                if ((piStack_30 < piVar12 &&
                     (char *)0x2 < (char *)((int)piStack_10 + (-1 - (int)piVar12))) &&
                   (*piVar10 == *(int *)(iVar3 + (int)piVar12))) {
                  pcVar6 = pcStack_c;
                  if (piVar12 < piStack_10) {
                    pcVar6 = pcStack_34;
                  }
                  iVar3 = FUN_00abd020(piStack_24,(char *)(iVar3 + 4 + (int)piVar12),pcStack_c,
                                       pcVar6,piStack_1c);
                  uVar5 = iVar3 + 4;
                  iVar3 = 0x1f;
                  if (uVar1 != 0) {
                    for (; uVar1 >> iVar3 == 0; iVar3 = iVar3 + -1) {
                    }
                  }
                  if ((3 < uVar5) &&
                     (iVar3 = (uStack_50 * 4 - iVar3) + 1,
                     uVar5 * 4 - iVar3 != 0 && iVar3 <= (int)(uVar5 * 4))) {
                    param_3 = 0;
                    uStack_50 = uVar5;
                    piStack_8 = piVar10;
                  }
                }
              }
              iStack_44 = 99999999;
              uVar5 = FUN_00aa8740(param_1,piVar10,pcStack_c,&iStack_44,iStack_40,uStack_3c);
              iVar3 = 0x1f;
              if (iStack_44 + 1U != 0) {
                for (; iStack_44 + 1U >> iVar3 == 0; iVar3 = iVar3 + -1) {
                }
              }
              iVar4 = 0x1f;
              if (param_3 + 1U != 0) {
                for (; param_3 + 1U >> iVar4 == 0; iVar4 = iVar4 + -1) {
                }
              }
              if ((uVar5 < 4) ||
                 (iVar8 = iStack_44, (int)(uVar5 * 4 - iVar3) <= (int)((uStack_50 * 4 - iVar4) + 7))
                 ) break;
            }
            uStack_50 = uVar5;
            piVar9 = piVar10;
            piVar11 = piVar12;
            param_3 = iVar8;
            piStack_8 = piVar10;
          } while (piVar10 < piStack_14);
        }
        piVar11 = piStack_10;
        if (param_3 != 0) {
          piVar10 = (int *)((int)piStack_8 + (-iStack_18 - param_3) + 2);
          piVar9 = piStack_1c;
          if (piVar10 < piStack_10) {
            piVar9 = piVar2;
          }
          if (param_2 < piStack_8) {
            iVar3 = iStack_28;
            if (piStack_10 <= piVar10) {
              iVar3 = iStack_18;
            }
            piVar10 = (int *)(iVar3 + (int)piVar10);
            do {
              if ((piVar10 <= piVar9) ||
                 (piVar12 = (int *)((int)piStack_8 - 1),
                 *(char *)piVar12 != *(char *)((int)piVar10 + -1))) break;
              piVar10 = (int *)((int)piVar10 + -1);
              uStack_50 = uStack_50 + 1;
              piStack_8 = piVar12;
            } while (param_2 < piVar12);
          }
          iStack_2c = iStack_20;
          iStack_20 = param_3 + -2;
        }
        uVar5 = (int)piStack_8 - (int)param_2;
        piVar10 = *(int **)(param_1 + 0x17c);
        piVar9 = (int *)((int)piVar10 + uVar5);
        do {
          *piVar10 = *param_2;
          piVar10[1] = param_2[1];
          piVar10 = piVar10 + 2;
          param_2 = param_2 + 2;
        } while (piVar10 < piVar9);
        piStack_48[3] = piStack_48[3] + uVar5;
        if (0xffff < uVar5) {
          piStack_48[7] = 1;
          piStack_48[8] = piStack_48[1] - *piStack_48 >> 3;
        }
        *(short *)(piStack_48[1] + 4) = (short)uVar5;
        *(int *)piStack_48[1] = param_3 + 1;
        if (0xffff < uStack_50 - 3) {
          piStack_48[7] = 2;
          piStack_48[8] = piStack_48[1] - *piStack_48 >> 3;
        }
        *(short *)(piStack_48[1] + 6) = (short)(uStack_50 - 3);
        piStack_48[1] = piStack_48[1] + 8;
        param_2 = (int *)((int)piStack_8 + uStack_50);
        if (piStack_14 < param_2) break;
        do {
          piVar10 = (int *)((int)param_2 + (-iStack_18 - iStack_2c));
          iVar3 = iStack_18;
          if (piVar10 < piVar11) {
            iVar3 = iStack_28;
          }
          piVar9 = param_2;
          if ((piVar10 <= piStack_30 || (char *)((int)piVar11 + (-1 - (int)piVar10)) < (char *)0x3)
             || (*param_2 != *(int *)(iVar3 + (int)piVar10))) break;
          pcVar6 = pcStack_c;
          if (piVar10 < piVar11) {
            pcVar6 = pcStack_34;
          }
          iVar4 = FUN_00abd020(param_2 + 1,(char *)((int)piVar10 + iVar3 + 4),pcStack_c,pcVar6,
                               piStack_1c);
          iVar3 = iStack_20;
          iStack_20 = iStack_2c;
          iStack_2c = iVar3;
          FUN_00abd980(piStack_48,0,param_2,0,iVar4 + 1);
          param_2 = (int *)((int)param_2 + iVar4 + 4);
          piVar9 = param_2;
        } while (param_2 <= piStack_14);
      }
    } while (piVar9 < piStack_14);
  }
  piStack_48[0xc] = iStack_20;
  piStack_48[0xd] = iStack_2c;
  return (int)pcStack_c - (int)param_2;
}



/* FUNCTION 22069 ; VA 0x00ab3a00 ; FUN_00ab3a00 */

int FUN_00ab3a00(int param_1,uint *param_2,uint *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  byte bVar4;
  uint uVar5;
  uint uVar6;
  char *pcVar7;
  undefined4 *puVar8;
  char *pcVar9;
  undefined4 *puVar10;
  uint *puVar11;
  uint *puVar12;
  int iVar13;
  int iVar14;
  undefined4 uVar15;
  int iVar16;
  uint *puVar17;
  undefined8 uVar18;
  int aiStack_84 [4];
  uint uStack_74;
  int iStack_70;
  uint *puStack_6c;
  uint uStack_68;
  uint *puStack_64;
  uint *puStack_60;
  char *pcStack_5c;
  uint *puStack_58;
  int iStack_54;
  uint *puStack_50;
  int iStack_4c;
  uint *puStack_48;
  uint *puStack_44;
  int iStack_40;
  uint *puStack_3c;
  uint *puStack_38;
  uint *puStack_34;
  uint *puStack_30;
  int iStack_2c;
  uint *puStack_28;
  uint *puStack_24;
  uint *puStack_20;
  int iStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  int iStack_10;
  uint *puStack_c;
  uint *puStack_8;
  
  iStack_10 = param_1 + 0x1ac;
  puStack_34 = (uint *)((int)param_2 + (int)param_3);
  puStack_14 = param_2;
  puStack_64 = puStack_34 + -2;
  puStack_58 = (uint *)(*(int *)(param_1 + 0xc) + *(int *)(param_1 + 4));
  iStack_70 = 1 << ((byte)*(undefined4 *)(param_1 + 0x9c) & 0x1f);
  puStack_50 = *(uint **)(param_1 + 0xa4);
  iStack_4c = *(int *)(param_1 + 0xa0);
  puVar1 = *(undefined4 **)(param_1 + 0x1c0);
  puStack_28 = (uint *)((iStack_4c != 3) + 3);
  iStack_1c = *(int *)(param_1 + 0x1bc);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  FUN_00aaf290(iStack_10,param_2,param_3);
  iStack_2c = *(int *)(param_1 + 0x194);
  puStack_c = (uint *)((uint)(param_2 == puStack_58) + (int)param_2);
  iStack_40 = *(int *)(param_1 + 0x198);
  aiStack_84[1] = *(int *)(param_1 + 0x198);
  iStack_54 = *(int *)(param_1 + 0x19c);
  aiStack_84[2] = *(int *)(param_1 + 0x19c);
  iVar16 = param_1 + 0x1ac;
  aiStack_84[0] = iStack_2c;
  if (puStack_c < puStack_64) {
    do {
      puVar17 = (uint *)0x0;
      uVar5 = (int)puStack_c - (int)param_2;
      puStack_8 = (uint *)0x0;
      *puVar1 = 0;
      puVar1[1] = 0;
      puVar1[2] = 0;
      puVar1[3] = 0;
      puStack_20 = (uint *)(uint)(puStack_c == param_2);
      *(undefined8 *)(puVar1 + 4) = 0;
      puVar1[6] = 0;
      puStack_6c = puStack_20;
      puStack_44 = (uint *)((int)puStack_20 + 3);
      puVar11 = puStack_c;
      do {
        if (puStack_20 == (uint *)0x3) {
          iVar14 = iStack_2c + -1;
        }
        else {
          iVar14 = aiStack_84[(int)puStack_20];
        }
        if ((0 < iVar14) && (iVar14 < (int)puVar11 - (int)puStack_58)) {
          uVar18 = FUN_00aaf270(puStack_c,puStack_28);
          iVar13 = (int)((ulonglong)uVar18 >> 0x20);
          if (iStack_4c == 3) {
            iVar13 = iVar13 << 8;
          }
          puVar11 = puStack_c;
          if ((int)uVar18 == iVar13) {
            puVar12 = (uint *)(((int)puStack_28 - iVar14) + (int)puStack_c);
            puStack_60 = (uint *)((int)puStack_c + (int)puStack_28);
            puVar11 = puStack_60;
            if (puStack_60 < (uint *)((int)puStack_34 + -3)) {
LAB_00ab3b70:
              uVar6 = *puVar11 ^ *puVar12;
              if (uVar6 == 0) goto code_r0x00ab3b7a;
              uVar3 = 0;
              if (uVar6 != 0) {
                for (; (uVar6 >> uVar3 & 1) == 0; uVar3 = uVar3 + 1) {
                }
              }
              aiStack_84[3] = 0;
              pcVar7 = (char *)(((uVar3 >> 3) - (int)puStack_60) + (int)puVar11);
              goto LAB_00ab3bac;
            }
LAB_00ab3b84:
            if ((puVar11 < (uint *)((int)puStack_34 + -1)) &&
               (*(short *)puVar12 == *(short *)puVar11)) {
              puVar11 = (uint *)((int)puVar11 + 2);
              puVar12 = (uint *)((int)puVar12 + 2);
            }
            if ((puVar11 < puStack_34) && (*(char *)puVar12 == *(char *)puVar11)) {
              puVar11 = (uint *)((int)puVar11 + 1);
            }
            pcVar7 = (char *)((int)puVar11 - (int)puStack_60);
LAB_00ab3bac:
            puVar11 = (uint *)((int)puStack_28 + (int)pcVar7);
            puStack_24 = puVar11;
            if ((puStack_50 < puVar11) || ((uint *)0xfff < puVar11)) {
              puVar17 = (uint *)0x1;
              param_3 = (uint *)0x0;
              puStack_8 = (uint *)0x1;
              goto LAB_00ab49b4;
            }
            puStack_48 = (uint *)((int)puVar11 + -3);
            pcStack_5c = (char *)((int)puStack_20 + (1 - (int)puStack_6c));
            puVar10 = puVar1 + (int)puVar11 * 7 + 1;
            do {
              puStack_60 = (uint *)0x1f;
              if (pcStack_5c != (char *)0x0) {
                for (; (uint)pcStack_5c >> (int)puStack_60 == 0;
                    puStack_60 = (uint *)((int)puStack_60 + -1)) {
                }
              }
              uStack_68 = (uint)puStack_60 & 0xff;
              aiStack_84[3] = 0;
              if (*(int *)(iVar16 + 0x44) == 0) {
                uVar6 = *(int *)(*(int *)(iVar16 + 0xc) + uStack_68 * 4) + 1;
                iVar14 = 0x1f;
                if (uVar6 != 0) {
                  for (; uVar6 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                  }
                }
                puStack_3c = (uint *)((*(int *)(iVar16 + 0x3c) - iVar14) + uStack_68);
                if (0x13 < (byte)puStack_60) {
                  puStack_3c = (uint *)((int)puStack_3c + uStack_68 * 2 + -0x26);
                }
                if (puStack_48 < (uint *)0x80) {
                  bVar4 = *(byte *)(puStack_48 + 0x651e52);
                }
                else {
                  iVar14 = 0x1f;
                  if (puStack_48 != (uint *)0x0) {
                    for (; (uint)puStack_48 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                    }
                  }
                  bVar4 = (char)iVar14 + 0x24;
                }
                aiStack_84[3] = 0;
                uVar6 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                iVar14 = 0x1f;
                if (uVar6 != 0) {
                  for (; uVar6 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                  }
                }
                puStack_3c = (uint *)((int)puStack_3c +
                                     ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) +
                                      *(int *)(iVar16 + 0x2c)) - iVar14));
                iVar14 = FUN_00aae0d0(iVar16,uVar5,puStack_14);
                pcVar7 = (char *)(iVar14 + *(int *)(iVar16 + 0x40) + (int)puStack_3c);
              }
              else {
                iVar16 = 0x1f;
                if ((char *)((int)puStack_48 + 1U) != (char *)0x0) {
                  for (; (int)puStack_48 + 1U >> iVar16 == 0; iVar16 = iVar16 + -1) {
                  }
                }
                iVar14 = FUN_00aae0d0(iStack_10,uVar5,puStack_14);
                pcVar7 = (char *)(uStack_68 + 0x10 + iVar14 + iVar16);
                iVar16 = iStack_10;
              }
              if (puVar17 < puStack_24) {
LAB_00ab3cd9:
                puVar8 = puVar1 + (int)((int)puVar17 + 1) * 7;
                iVar14 = (int)puStack_24 - (int)puVar17;
                do {
                  *puVar8 = 0x40000000;
                  puVar8 = puVar8 + 7;
                  iVar14 = iVar14 + -1;
                  puVar17 = puStack_24;
                } while (iVar14 != 0);
LAB_00ab3d04:
                puVar10[1] = puStack_24;
                *puVar10 = puStack_20;
                puVar10[2] = uVar5;
                puVar10[-1] = pcVar7;
              }
              else if (pcVar7 < (char *)puVar10[-1]) {
                if (puVar17 < puStack_24) goto LAB_00ab3cd9;
                goto LAB_00ab3d04;
              }
              puStack_24 = (uint *)((int)puStack_24 + -1);
              puStack_48 = (uint *)((int)puStack_48 + -1);
              puVar10 = puVar10 + -7;
            } while (puStack_28 <= puStack_24);
            puStack_8 = puVar17;
            puVar11 = puStack_c;
          }
        }
        puVar12 = puStack_28;
        puStack_20 = (uint *)((int)puStack_20 + 1);
      } while (puStack_20 < puStack_44);
      puStack_24 = (uint *)FUN_00aa8870(param_1,puVar11,puStack_34,iStack_70,iStack_4c,iStack_1c,
                                        puStack_28);
      if (puVar17 == (uint *)0x0) {
        if (puStack_24 != (uint *)0x0) {
LAB_00ab3d90:
          puVar11 = *(uint **)(iStack_1c + -4 + (int)puStack_24 * 8);
          if ((puVar11 <= puStack_50) && (puVar11 < &DAT_00001000)) goto LAB_00ab3db7;
          puStack_20 = *(uint **)(iStack_1c + -8 + (int)puStack_24 * 8);
          puVar17 = (uint *)0x1;
          param_3 = (uint *)0x0;
          puStack_8 = (uint *)0x1;
          goto LAB_00ab49ae;
        }
        puStack_c = (uint *)((int)puStack_c + 1);
      }
      else {
        if (puStack_24 != (uint *)0x0) goto LAB_00ab3d90;
LAB_00ab3db7:
        puVar11 = puVar12;
        if (puVar17 != (uint *)0x0) {
          puVar11 = puVar17;
        }
        puStack_38 = (uint *)0x0;
        if (puStack_24 != (uint *)0x0) {
          do {
            if (puStack_38 != (uint *)0x0) {
              puVar11 = (uint *)(*(int *)(iStack_1c + -4 + (int)puStack_38 * 8) + 1);
            }
            puStack_30 = *(uint **)((char *)((int)puStack_38 * 8) + iStack_1c + 4);
            pcStack_5c = (char *)((int)puStack_38 * 8);
            if (puVar11 <= puStack_30) {
              puStack_48 = (uint *)((int)puVar11 + -3);
              puStack_44 = puVar1 + (int)puVar11 * 7 + 1;
              puVar17 = puStack_8;
              do {
                aiStack_84[3] = 0;
                uStack_68 = 0x1f;
                if (*(uint *)(pcStack_5c + iStack_1c) != 0) {
                  for (; *(uint *)(pcStack_5c + iStack_1c) >> uStack_68 == 0;
                      uStack_68 = uStack_68 - 1) {
                  }
                }
                puStack_6c = (uint *)(uStack_68 & 0xff);
                if (*(int *)(iVar16 + 0x44) == 0) {
                  uVar6 = *(int *)(*(int *)(iVar16 + 0xc) + (int)puStack_6c * 4) + 1;
                  iVar14 = 0x1f;
                  if (uVar6 != 0) {
                    for (; uVar6 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                    }
                  }
                  puStack_3c = (uint *)((*(int *)(iVar16 + 0x3c) - iVar14) + (int)puStack_6c);
                  if (0x13 < (byte)uStack_68) {
                    puStack_3c = (uint *)((int)puStack_3c + (int)puStack_6c * 2 + -0x26);
                  }
                  if (puStack_48 < (uint *)0x80) {
                    bVar4 = *(byte *)(puStack_48 + 0x651e52);
                  }
                  else {
                    iVar14 = 0x1f;
                    if (puStack_48 != (uint *)0x0) {
                      for (; (uint)puStack_48 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                      }
                    }
                    bVar4 = (char)iVar14 + 0x24;
                  }
                  aiStack_84[3] = 0;
                  uVar6 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                  iVar14 = 0x1f;
                  if (uVar6 != 0) {
                    for (; uVar6 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                    }
                  }
                  puStack_3c = (uint *)((int)puStack_3c +
                                       ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) +
                                        *(int *)(iVar16 + 0x2c)) - iVar14));
                  iVar14 = FUN_00aae0d0(iVar16,uVar5,puStack_14);
                  puStack_60 = (uint *)(iVar14 + *(int *)(iVar16 + 0x40) + (int)puStack_3c);
                }
                else {
                  iVar16 = 0x1f;
                  if ((char *)((int)puStack_48 + 1U) != (char *)0x0) {
                    for (; (int)puStack_48 + 1U >> iVar16 == 0; iVar16 = iVar16 + -1) {
                    }
                  }
                  iVar14 = FUN_00aae0d0(iStack_10,uVar5,puStack_14);
                  puStack_60 = (uint *)((int)puStack_6c + iVar14 + iVar16 + 0x10);
                  iVar16 = iStack_10;
                }
                if (puVar17 < puVar11) {
LAB_00ab3ef7:
                  puVar10 = puVar1 + (int)((int)puVar17 + 1) * 7;
                  iVar14 = (int)puVar11 - (int)puVar17;
                  do {
                    *puVar10 = 0x40000000;
                    puVar10 = puVar10 + 7;
                    iVar14 = iVar14 + -1;
                    puVar17 = puVar11;
                  } while (iVar14 != 0);
LAB_00ab3f1e:
                  puStack_44[1] = (uint)puVar11;
                  *puStack_44 = *(uint *)(pcStack_5c + iStack_1c);
                  puStack_44[2] = uVar5;
                  puStack_44[-1] = (uint)puStack_60;
                }
                else if (puStack_60 < (uint *)puStack_44[-1]) {
                  if (puVar17 < puVar11) goto LAB_00ab3ef7;
                  goto LAB_00ab3f1e;
                }
                puVar11 = (uint *)((int)puVar11 + 1);
                puStack_48 = (uint *)((int)puStack_48 + 1);
                puStack_44 = puStack_44 + 7;
              } while (puVar11 <= puStack_30);
              puStack_8 = puVar17;
            }
            puStack_38 = (uint *)((int)puStack_38 + 1);
            puVar11 = puStack_30;
            puVar12 = puStack_28;
          } while (puStack_38 < puStack_24);
        }
        if (puVar17 < puVar12) {
          puStack_c = (uint *)((int)puStack_c + 1);
        }
        else {
          puVar1[4] = iStack_2c;
          puVar1[5] = iStack_40;
          puVar1[6] = iStack_54;
          puVar1[2] = 1;
          puVar1[3] = uVar5;
          param_3 = (uint *)0x1;
          if (puVar17 != (uint *)0x0) {
            do {
              puStack_30 = (uint *)((int)puStack_c + (int)param_3);
              puStack_6c = (uint *)((int)param_3 * 0x1c);
              puStack_18 = (uint *)((int)puStack_6c + (int)puVar1);
              if (puStack_18[-5] == 1) {
                puVar11 = (uint *)(puStack_18[-4] + 1);
                if (puVar11 < param_3) {
                  iVar14 = FUN_00aae0d0(iVar16,puVar11,(int)puStack_30 - (int)puVar11);
                  uVar5 = iVar14 + puVar1[((int)param_3 - (int)puVar11) * 7];
                }
                else {
                  uVar5 = FUN_00aae0d0(iVar16,puVar11,puStack_14);
                }
              }
              else {
                puVar11 = (uint *)0x1;
                iVar14 = FUN_00aae0d0(iVar16,1,(char *)((int)puStack_30 + -1));
                uVar5 = iVar14 + puStack_18[-7];
              }
              if (puVar17 < param_3) {
LAB_00ab4040:
                puVar10 = puVar1 + (int)((int)puVar17 + 1) * 7;
                iVar14 = (int)param_3 - (int)puVar17;
                puStack_8 = param_3;
                do {
                  *puVar10 = 0x40000000;
                  puVar10 = puVar10 + 7;
                  iVar14 = iVar14 + -1;
                  puVar17 = param_3;
                } while (iVar14 != 0);
LAB_00ab4071:
                puStack_18[2] = 1;
                puStack_18[1] = 0;
                puStack_18[3] = (uint)puVar11;
                *puStack_18 = uVar5;
              }
              else if (uVar5 <= *puStack_18) {
                if (puVar17 < param_3) goto LAB_00ab4040;
                goto LAB_00ab4071;
              }
              if (param_3 == puVar17) break;
              if (puStack_30 <= puStack_64) {
                uStack_68 = puStack_18[2];
                iVar14 = (int)param_3 - uStack_68;
                if (puStack_18[1] < 4) {
                  if (puStack_18[1] < 2) {
                    uVar5 = puVar1[iVar14 * 7 + 6];
                  }
                  else {
                    uVar5 = puVar1[iVar14 * 7 + 5];
                  }
                  puStack_18[6] = uVar5;
                  if (puStack_18[1] == 0) {
                    uVar5 = puVar1[iVar14 * 7 + 5];
                  }
                  else {
                    uVar5 = puVar1[iVar14 * 7 + 4];
                  }
                  puStack_18[5] = uVar5;
                  if (puStack_18[1] == 3) {
                    iVar14 = puVar1[iVar14 * 7 + 4] + -1;
                  }
                  else {
                    iVar14 = puVar1[iVar14 * 7 + puStack_18[1] + 4];
                  }
                }
                else {
                  puStack_18[6] = puVar1[iVar14 * 7 + 5];
                  puStack_18[5] = puVar1[iVar14 * 7 + 4];
                  iVar14 = puStack_18[1] - 3;
                }
                *(int *)((int)(puVar1 + 4) + (int)puStack_6c) = iVar14;
                puStack_3c = puStack_28;
                puVar11 = (uint *)((uStack_68 != 1) + 3);
                puStack_20 = (uint *)(uint)(puStack_18[2] != 1);
                puVar12 = puStack_18;
                puVar17 = puStack_8;
                puStack_48 = puVar11;
                do {
                  if (puStack_20 == (uint *)0x3) {
                    iVar14 = puVar12[4] - 1;
                  }
                  else {
                    iVar14 = puVar1[(int)((int)puStack_20 + (int)param_3 * 7 + 4)];
                    puVar11 = puStack_48;
                  }
                  if ((0 < iVar14) &&
                     (puVar11 = puStack_48, iVar14 < (int)puStack_30 - (int)puStack_58)) {
                    iVar14 = (int)puStack_30 - iVar14;
                    uVar18 = FUN_00aaf270(puStack_30,puStack_28);
                    iVar13 = (int)((ulonglong)uVar18 >> 0x20);
                    if (iStack_4c == 3) {
                      iVar13 = iVar13 << 8;
                    }
                    puVar11 = puStack_48;
                    puVar12 = puStack_18;
                    if ((int)uVar18 == iVar13) {
                      puVar11 = (uint *)(iVar14 + (int)puStack_28);
                      puStack_60 = (uint *)((int)puStack_28 + (int)puStack_30);
                      puVar12 = puStack_60;
                      if (puStack_60 < (uint *)((int)puStack_34 + -3)) {
LAB_00ab41d4:
                        uVar5 = *puVar12 ^ *puVar11;
                        if (uVar5 == 0) goto code_r0x00ab41de;
                        uVar6 = 0;
                        if (uVar5 != 0) {
                          for (; (uVar5 >> uVar6 & 1) == 0; uVar6 = uVar6 + 1) {
                          }
                        }
                        aiStack_84[3] = 0;
                        pcVar7 = (char *)(((uVar6 >> 3) - (int)puStack_60) + (int)puVar12);
                        goto LAB_00ab4210;
                      }
LAB_00ab41e8:
                      if ((puVar12 < (uint *)((int)puStack_34 + -1)) &&
                         (*(short *)puVar11 == *(short *)puVar12)) {
                        puVar12 = (uint *)((int)puVar12 + 2);
                        puVar11 = (uint *)((int)puVar11 + 2);
                      }
                      if ((puVar12 < puStack_34) && (*(char *)puVar11 == *(char *)puVar12)) {
                        puVar12 = (uint *)((int)puVar12 + 1);
                      }
                      pcVar7 = (char *)((int)puVar12 - (int)puStack_60);
LAB_00ab4210:
                      puVar11 = (uint *)((int)puStack_28 + (int)pcVar7);
                      puStack_24 = puVar11;
                      if (puVar11 <= puStack_50) {
                        puStack_6c = (uint *)((int)param_3 + (int)puVar11);
                        if (puStack_6c < &DAT_00001000) {
                          puVar12 = puVar11;
                          if (puVar11 <= puStack_3c) {
                            puVar12 = puStack_3c;
                          }
                          pcStack_5c = (char *)((int)puStack_20 + (uint)(puStack_18[2] == 1));
                          pcVar7 = (char *)((int)puVar11 + -3);
                          puStack_60 = puVar1 + (int)puStack_6c * 7 + 1;
                          puStack_3c = puVar12;
                          do {
                            if (puStack_18[2] == 1) {
                              puStack_38 = (uint *)puStack_18[3];
                              if (puStack_38 < param_3) {
                                aiStack_84[3] = -(int)puStack_38;
                                uStack_68 = aiStack_84[3] + (int)puStack_30;
                                uVar5 = 0x1f;
                                if (pcStack_5c != (char *)0x0) {
                                  for (; (uint)pcStack_5c >> uVar5 == 0; uVar5 = uVar5 - 1) {
                                  }
                                }
                                puStack_44 = (uint *)(uVar5 & 0xff);
                                if (*(int *)(iVar16 + 0x44) == 0) {
                                  uVar6 = *(int *)(*(int *)(iVar16 + 0xc) + (int)puStack_44 * 4) + 1
                                  ;
                                  iVar14 = 0x1f;
                                  if (uVar6 != 0) {
                                    for (; uVar6 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                    }
                                  }
                                  puVar11 = (uint *)((*(int *)(iVar16 + 0x3c) - iVar14) +
                                                    (int)puStack_44);
                                  uStack_74._0_1_ = (byte)uVar5;
                                  if (0x13 < (byte)uStack_74) {
                                    puVar11 = (uint *)((int)puVar11 + (int)puStack_44 * 2 + -0x26);
                                  }
                                  puStack_44 = puVar11;
                                  if (pcVar7 < (char *)0x80) {
                                    bVar4 = pcVar7[0x1947948];
                                  }
                                  else {
                                    iVar14 = 0x1f;
                                    if (pcVar7 != (char *)0x0) {
                                      for (; (uint)pcVar7 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                      }
                                    }
                                    bVar4 = (char)iVar14 + 0x24;
                                  }
                                  uStack_74 = 0;
                                  uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                                  iVar14 = 0x1f;
                                  if (uVar5 != 0) {
                                    for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                    }
                                  }
                                  puStack_44 = (uint *)((int)puStack_44 +
                                                       ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) +
                                                        *(int *)(iVar16 + 0x2c)) - iVar14));
                                  iVar14 = FUN_00aae0d0(iVar16,puStack_38,uStack_68);
                                  pcVar9 = (char *)(iVar14 + *(int *)(iVar16 + 0x40) +
                                                   (int)puStack_44);
                                }
                                else {
                                  uStack_74 = 0;
                                  iVar16 = 0x1f;
                                  if (pcVar7 + 1 != (char *)0x0) {
                                    for (; (uint)(pcVar7 + 1) >> iVar16 == 0; iVar16 = iVar16 + -1)
                                    {
                                    }
                                  }
                                  iVar14 = FUN_00aae0d0(iStack_10,puStack_38,uStack_68);
                                  pcVar9 = (char *)((int)puStack_44 + iVar14 + iVar16 + 0x10);
                                }
                                uVar5 = puVar1[(int)((int)param_3 + aiStack_84[3]) * 7];
                                goto LAB_00ab451f;
                              }
                              uStack_74 = 0x1f;
                              if (pcStack_5c != (char *)0x0) {
                                for (; (uint)pcStack_5c >> uStack_74 == 0; uStack_74 = uStack_74 - 1
                                    ) {
                                }
                              }
                              aiStack_84[3] = uStack_74 & 0xff;
                              if (*(int *)(iVar16 + 0x44) != 0) {
                                uStack_74 = 0;
                                iVar16 = 0x1f;
                                if (pcVar7 + 1 != (char *)0x0) {
                                  for (; (uint)(pcVar7 + 1) >> iVar16 == 0; iVar16 = iVar16 + -1) {
                                  }
                                }
                                iVar14 = FUN_00aae0d0(iStack_10,puStack_38,puStack_14);
                                pcVar9 = (char *)(iVar14 + iVar16);
                                uVar5 = aiStack_84[3] + 0x10;
                                goto LAB_00ab451f;
                              }
                              uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + aiStack_84[3] * 4) + 1;
                              iVar14 = 0x1f;
                              if (uVar5 != 0) {
                                for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                }
                              }
                              puStack_44 = (uint *)((*(int *)(iVar16 + 0x3c) - iVar14) +
                                                   aiStack_84[3]);
                              if (0x13 < (byte)uStack_74) {
                                puStack_44 = (uint *)((int)puStack_44 + aiStack_84[3] * 2 + -0x26);
                              }
                              if (pcVar7 < (char *)0x80) {
                                bVar4 = pcVar7[0x1947948];
                              }
                              else {
                                iVar14 = 0x1f;
                                if (pcVar7 != (char *)0x0) {
                                  for (; (uint)pcVar7 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                  }
                                }
                                bVar4 = (char)iVar14 + 0x24;
                              }
                              aiStack_84[3] = 0;
                              uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                              iVar14 = 0x1f;
                              if (uVar5 != 0) {
                                for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                }
                              }
                              puStack_44 = (uint *)((int)puStack_44 +
                                                   ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) +
                                                    *(int *)(iVar16 + 0x2c)) - iVar14));
                              iVar14 = FUN_00aae0d0(iVar16,puStack_38,puStack_14);
                              pcVar9 = (char *)(iVar14 + *(int *)(iVar16 + 0x40) + (int)puStack_44);
                            }
                            else {
                              uStack_68 = 0x1f;
                              if (pcStack_5c != (char *)0x0) {
                                for (; (uint)pcStack_5c >> uStack_68 == 0; uStack_68 = uStack_68 - 1
                                    ) {
                                }
                              }
                              puStack_38 = (uint *)0x0;
                              if (*(int *)(iVar16 + 0x44) == 0) {
                                uVar6 = uStack_68 & 0xff;
                                uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + uVar6 * 4) + 1;
                                iVar14 = 0x1f;
                                if (uVar5 != 0) {
                                  for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                  }
                                }
                                puStack_44 = (uint *)((*(int *)(iVar16 + 0x3c) - iVar14) + uVar6);
                                if (0x13 < (byte)uStack_68) {
                                  puStack_44 = (uint *)((int)puStack_44 + uVar6 * 2 + -0x26);
                                }
                                if (pcVar7 < (char *)0x80) {
                                  bVar4 = pcVar7[0x1947948];
                                }
                                else {
                                  iVar14 = 0x1f;
                                  if (pcVar7 != (char *)0x0) {
                                    for (; (uint)pcVar7 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                    }
                                  }
                                  bVar4 = (char)iVar14 + 0x24;
                                }
                                uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                                iVar14 = 0x1f;
                                if (uVar5 != 0) {
                                  for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                  }
                                }
                                uVar5 = **(int **)(iVar16 + 4) + 1;
                                iVar13 = 0x1f;
                                if (uVar5 != 0) {
                                  for (; uVar5 >> iVar13 == 0; iVar13 = iVar13 + -1) {
                                  }
                                }
                                pcVar9 = (char *)((int)puStack_44 +
                                                 *(int *)(iVar16 + 0x40) +
                                                 (*(int *)(iVar16 + 0x34) - iVar13) +
                                                 ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) +
                                                  *(int *)(iVar16 + 0x2c)) - iVar14));
                              }
                              else {
                                for (iVar16 = 0x1f; 1U >> iVar16 == 0; iVar16 = iVar16 + -1) {
                                }
                                iVar14 = 0x1f;
                                if (pcVar7 + 1 != (char *)0x0) {
                                  for (; (uint)(pcVar7 + 1) >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                  }
                                }
                                pcVar9 = (char *)((uStack_68 & 0xff) + 0x10 + iVar16 + iVar14);
                              }
                              aiStack_84[3] = 0;
                              uVar5 = *puStack_18;
LAB_00ab451f:
                              pcVar9 = pcVar9 + uVar5;
                            }
                            if (puVar17 < puStack_6c) {
LAB_00ab4534:
                              puVar10 = puVar1 + (int)((int)puVar17 + 1) * 7;
                              do {
                                puVar17 = (uint *)((int)puVar17 + 1);
                                *puVar10 = 0x40000000;
                                puVar10 = puVar10 + 7;
                                puStack_8 = puVar17;
                              } while (puVar17 < puStack_6c);
LAB_00ab455a:
                              puStack_60[1] = (uint)puStack_24;
                              *puStack_60 = (uint)puStack_20;
                              puStack_60[2] = (uint)puStack_38;
                              puStack_60[-1] = (uint)pcVar9;
                            }
                            else if (pcVar9 <= (char *)puStack_60[-1]) {
                              if (puVar17 < puStack_6c) goto LAB_00ab4534;
                              goto LAB_00ab455a;
                            }
                            puStack_6c = (uint *)((int)puStack_6c + -1);
                            puStack_24 = (uint *)((int)puStack_24 + -1);
                            puStack_60 = puStack_60 + -7;
                            pcVar7 = pcVar7 + -1;
                            puVar11 = puStack_48;
                            puVar12 = puStack_18;
                            iVar16 = iStack_10;
                          } while (puStack_28 <= puStack_24);
                          goto LAB_00ab4592;
                        }
                      }
                      puVar17 = (uint *)((int)param_3 + 1);
                      puStack_8 = puVar17;
                      goto LAB_00ab49b4;
                    }
                  }
LAB_00ab4592:
                  iVar14 = iStack_1c;
                  puStack_20 = (uint *)((int)puStack_20 + 1);
                } while (puStack_20 < puVar11);
                puStack_20 = (uint *)FUN_00aa8870(param_1,puStack_30,puStack_34,iStack_70,iStack_4c,
                                                  iStack_1c,puStack_3c);
                if ((puStack_20 != (uint *)0x0) &&
                   ((puVar11 = *(uint **)(iVar14 + -4 + (int)puStack_20 * 8), puStack_50 < puVar11
                    || ((char *)0xfff < (char *)((int)puVar11 + (int)param_3))))) {
                  puVar17 = (uint *)((int)param_3 + 1);
                  puStack_8 = puVar17;
                  puStack_20 = *(uint **)(iStack_1c + -8 + (int)puStack_20 * 8);
                  goto LAB_00ab49b4;
                }
                puStack_24 = (uint *)0x0;
                if (puStack_20 != (uint *)0x0) {
                  do {
                    puStack_44 = puStack_3c;
                    if (puStack_24 != (uint *)0x0) {
                      puStack_44 = (uint *)(*(int *)(iStack_1c + -4 + (int)puStack_24 * 8) + 1);
                    }
                    puStack_60 = (uint *)((int)puStack_24 * 8);
                    puStack_3c = *(uint **)((int)puStack_24 * 8 + iStack_1c + 4);
                    puVar17 = puStack_8;
                    if (puStack_44 <= puStack_3c) {
                      puStack_38 = (uint *)((int)param_3 + (int)puStack_44);
                      pcVar7 = (char *)((int)puStack_44 + -3);
                      pcStack_5c = (char *)(puVar1 + (int)puStack_38 * 7 + 1);
                      do {
                        if (puStack_18[2] == 1) {
                          puStack_30 = (uint *)puStack_18[3];
                          uStack_74 = 0x1f;
                          if (*(uint *)(iStack_1c + (int)puStack_60) != 0) {
                            for (; *(uint *)(iStack_1c + (int)puStack_60) >> uStack_74 == 0;
                                uStack_74 = uStack_74 - 1) {
                            }
                          }
                          if (puStack_30 < param_3) {
                            uStack_68 = (int)param_3 - (int)puStack_30;
                            puStack_6c = (uint *)(uStack_68 + (int)puStack_c);
                            aiStack_84[3] = uStack_74 & 0xff;
                            if (*(int *)(iVar16 + 0x44) == 0) {
                              uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + aiStack_84[3] * 4) + 1;
                              iVar14 = 0x1f;
                              if (uVar5 != 0) {
                                for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                }
                              }
                              puStack_48 = (uint *)((*(int *)(iVar16 + 0x3c) - iVar14) +
                                                   aiStack_84[3]);
                              if (0x13 < (byte)uStack_74) {
                                puStack_48 = (uint *)((int)puStack_48 + aiStack_84[3] * 2 + -0x26);
                              }
                              if (pcVar7 < (char *)0x80) {
                                bVar4 = pcVar7[0x1947948];
                              }
                              else {
                                iVar14 = 0x1f;
                                if (pcVar7 != (char *)0x0) {
                                  for (; (uint)pcVar7 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                  }
                                }
                                bVar4 = (char)iVar14 + 0x24;
                              }
                              aiStack_84[3] = 0;
                              uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                              iVar14 = 0x1f;
                              if (uVar5 != 0) {
                                for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                }
                              }
                              puStack_48 = (uint *)((int)puStack_48 +
                                                   ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) +
                                                    *(int *)(iVar16 + 0x2c)) - iVar14));
                              iVar14 = FUN_00aae0d0(iVar16,puStack_30,puStack_6c);
                              pcVar9 = (char *)(iVar14 + *(int *)(iVar16 + 0x40) + (int)puStack_48);
                            }
                            else {
                              uStack_74 = 0;
                              iVar16 = 0x1f;
                              if (pcVar7 + 1 != (char *)0x0) {
                                for (; (uint)(pcVar7 + 1) >> iVar16 == 0; iVar16 = iVar16 + -1) {
                                }
                              }
                              iVar14 = FUN_00aae0d0(iStack_10,puStack_30,puStack_6c);
                              pcVar9 = (char *)(iVar14 + iVar16 + aiStack_84[3] + 0x10U);
                            }
                            uVar5 = puVar1[uStack_68 * 7];
                            puVar17 = puStack_8;
                            goto LAB_00ab48ef;
                          }
                          aiStack_84[3] = uStack_74 & 0xff;
                          if (*(int *)(iVar16 + 0x44) != 0) {
                            uStack_74 = 0;
                            iVar16 = 0x1f;
                            if (pcVar7 + 1 != (char *)0x0) {
                              for (; (uint)(pcVar7 + 1) >> iVar16 == 0; iVar16 = iVar16 + -1) {
                              }
                            }
                            iVar14 = FUN_00aae0d0(iStack_10,puStack_30,puStack_14);
                            pcVar9 = (char *)(iVar14 + iVar16);
                            uVar5 = aiStack_84[3] + 0x10;
                            goto LAB_00ab48ef;
                          }
                          uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + aiStack_84[3] * 4) + 1;
                          iVar14 = 0x1f;
                          if (uVar5 != 0) {
                            for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                            }
                          }
                          puStack_48 = (uint *)((*(int *)(iVar16 + 0x3c) - iVar14) + aiStack_84[3]);
                          if (0x13 < (byte)uStack_74) {
                            puStack_48 = (uint *)((int)puStack_48 + aiStack_84[3] * 2 + -0x26);
                          }
                          if (pcVar7 < (char *)0x80) {
                            bVar4 = pcVar7[0x1947948];
                          }
                          else {
                            iVar14 = 0x1f;
                            if (pcVar7 != (char *)0x0) {
                              for (; (uint)pcVar7 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                              }
                            }
                            bVar4 = (char)iVar14 + 0x24;
                          }
                          aiStack_84[3] = 0;
                          uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                          iVar14 = 0x1f;
                          if (uVar5 != 0) {
                            for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                            }
                          }
                          puStack_48 = (uint *)((int)puStack_48 +
                                               ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) +
                                                *(int *)(iVar16 + 0x2c)) - iVar14));
                          iVar14 = FUN_00aae0d0(iVar16,puStack_30,puStack_14);
                          pcVar9 = (char *)(iVar14 + *(int *)(iVar16 + 0x40) + (int)puStack_48);
                        }
                        else {
                          puStack_30 = (uint *)0x0;
                          puStack_6c = (uint *)0x1f;
                          if (*(uint *)(iStack_1c + (int)puStack_60) != 0) {
                            for (; *(uint *)(iStack_1c + (int)puStack_60) >> (int)puStack_6c == 0;
                                puStack_6c = (uint *)((int)puStack_6c + -1)) {
                            }
                          }
                          if (*(int *)(iVar16 + 0x44) == 0) {
                            uVar6 = (uint)puStack_6c & 0xff;
                            uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + uVar6 * 4) + 1;
                            iVar14 = 0x1f;
                            if (uVar5 != 0) {
                              for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                              }
                            }
                            uStack_68 = (*(int *)(iVar16 + 0x3c) - iVar14) + uVar6;
                            if (0x13 < (byte)puStack_6c) {
                              uStack_68 = (uStack_68 + uVar6 * 2) - 0x26;
                            }
                            if (pcVar7 < (char *)0x80) {
                              bVar4 = pcVar7[0x1947948];
                            }
                            else {
                              iVar14 = 0x1f;
                              if (pcVar7 != (char *)0x0) {
                                for (; (uint)pcVar7 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                                }
                              }
                              bVar4 = (char)iVar14 + 0x24;
                            }
                            uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                            iVar14 = 0x1f;
                            if (uVar5 != 0) {
                              for (; uVar5 >> iVar14 == 0; iVar14 = iVar14 + -1) {
                              }
                            }
                            uVar5 = **(int **)(iVar16 + 4) + 1;
                            iVar13 = 0x1f;
                            if (uVar5 != 0) {
                              for (; uVar5 >> iVar13 == 0; iVar13 = iVar13 + -1) {
                              }
                            }
                            pcVar9 = (char *)(*(int *)(iVar16 + 0x40) +
                                              (*(int *)(iVar16 + 0x34) - iVar13) +
                                             uStack_68 +
                                             ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) +
                                              *(int *)(iVar16 + 0x2c)) - iVar14));
                          }
                          else {
                            for (iVar16 = 0x1f; 1U >> iVar16 == 0; iVar16 = iVar16 + -1) {
                            }
                            iVar14 = 0x1f;
                            if (pcVar7 + 1 != (char *)0x0) {
                              for (; (uint)(pcVar7 + 1) >> iVar14 == 0; iVar14 = iVar14 + -1) {
                              }
                            }
                            pcVar9 = (char *)(((uint)puStack_6c & 0xff) + 0x10 + iVar16 + iVar14);
                          }
                          aiStack_84[3] = 0;
                          uVar5 = *puStack_18;
LAB_00ab48ef:
                          pcVar9 = pcVar9 + uVar5;
                        }
                        if (puVar17 < puStack_38) {
LAB_00ab4904:
                          puVar10 = puVar1 + (int)((int)puVar17 + 1) * 7;
                          do {
                            puVar17 = (uint *)((int)puVar17 + 1);
                            *puVar10 = 0x40000000;
                            puVar10 = puVar10 + 7;
                          } while (puVar17 < puStack_38);
                          puStack_8 = puVar17;
LAB_00ab492a:
                          *(uint **)(pcStack_5c + 4) = puStack_44;
                          *(undefined4 *)pcStack_5c = *(undefined4 *)(iStack_1c + (int)puStack_60);
                          *(uint **)(pcStack_5c + 8) = puStack_30;
                          *(char **)(pcStack_5c + -4) = pcVar9;
                          puVar17 = puStack_8;
                        }
                        else if (pcVar9 < *(char **)(pcStack_5c + -4)) {
                          if (puVar17 < puStack_38) goto LAB_00ab4904;
                          goto LAB_00ab492a;
                        }
                        puStack_44 = (uint *)((int)puStack_44 + 1);
                        pcStack_5c = pcStack_5c + 0x1c;
                        pcVar7 = pcVar7 + 1;
                        puStack_38 = (uint *)((int)puStack_38 + 1);
                        iVar16 = iStack_10;
                      } while (puStack_44 <= puStack_3c);
                    }
                    puStack_24 = (uint *)((int)puStack_24 + 1);
                    iVar16 = iStack_10;
                  } while (puStack_24 < puStack_20);
                }
              }
              param_3 = (uint *)((int)param_3 + 1);
              iVar16 = iStack_10;
            } while (param_3 <= puVar17);
          }
          puVar11 = (uint *)puVar1[(int)puVar17 * 7 + 2];
          puStack_20 = (uint *)puVar1[(int)puVar17 * 7 + 1];
          param_3 = (uint *)((int)puVar17 - (int)puVar11);
LAB_00ab49ae:
LAB_00ab49b4:
          puVar1[2] = 1;
          puVar12 = (uint *)puVar1[(int)param_3 * 7 + 2];
          uVar15 = puVar1[(int)param_3 * 7 + 1];
          puVar1[(int)param_3 * 7 + 2] = puVar11;
          puVar1[(int)param_3 * 7 + 1] = puStack_20;
          if (puVar12 <= param_3) {
            do {
              param_3 = (uint *)((int)param_3 - (int)puVar12);
              puVar11 = (uint *)puVar1[(int)param_3 * 7 + 2];
              uVar2 = puVar1[(int)param_3 * 7 + 1];
              puVar1[(int)param_3 * 7 + 2] = puVar12;
              puVar1[(int)param_3 * 7 + 1] = uVar15;
              puVar12 = puVar11;
              uVar15 = uVar2;
              puVar17 = puStack_8;
            } while (puVar11 <= param_3);
          }
          puVar11 = (uint *)0x0;
          do {
            puVar11 = (uint *)((int)puVar11 + puVar1[(int)puVar11 * 7 + 2]);
          } while (puVar11 <= puVar17);
          param_3 = (uint *)0x0;
          if (puVar17 != (uint *)0x0) {
            do {
              puVar11 = puStack_14;
              uStack_74 = puVar1[(int)param_3 * 7 + 2];
              if (uStack_74 == 1) {
                puStack_c = (uint *)((int)puStack_c + 1);
              }
              else {
                uVar5 = puVar1[(int)param_3 * 7 + 1];
                uVar6 = (int)puStack_c - (int)puStack_14;
                if (uVar5 < 4) {
                  if (uVar5 != 0) {
                    if (uVar5 == 3) {
                      aiStack_84[0] = iStack_2c + -1;
LAB_00ab4a94:
                      iStack_54 = iStack_40;
                      aiStack_84[2] = iStack_40;
                    }
                    else {
                      aiStack_84[0] = aiStack_84[uVar5];
                      if (uVar5 != 1) goto LAB_00ab4a94;
                    }
                    iStack_40 = iStack_2c;
                    aiStack_84[1] = iStack_2c;
                    iStack_2c = aiStack_84[0];
                  }
                  if (uVar6 == 0) goto LAB_00ab4aad;
                }
                else {
                  iStack_54 = iStack_40;
                  aiStack_84[2] = iStack_40;
                  iStack_40 = iStack_2c;
                  aiStack_84[1] = iStack_2c;
                  aiStack_84[0] = uVar5 - 3;
                  iStack_2c = aiStack_84[0];
LAB_00ab4aad:
                  uVar5 = uVar5 - 1;
                }
                aiStack_84[3] = uStack_74 - 3;
                FUN_00aafda0(iStack_10,uVar6,puStack_14,uVar5,aiStack_84[3]);
                puVar12 = *(uint **)(param_1 + 0x17c);
                puVar17 = (uint *)(uVar6 + (int)puVar12);
                do {
                  *puVar12 = *puVar11;
                  puVar12[1] = puVar11[1];
                  puVar12 = puVar12 + 2;
                  puVar11 = puVar11 + 2;
                } while (puVar12 < puVar17);
                *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar6;
                if (0xffff < uVar6) {
                  *(undefined4 *)(param_1 + 0x18c) = 1;
                  *(int *)(param_1 + 400) =
                       *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
                }
                *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar6;
                **(int **)(param_1 + 0x174) = uVar5 + 1;
                if (0xffff < (uint)aiStack_84[3]) {
                  *(undefined4 *)(param_1 + 0x18c) = 2;
                  *(int *)(param_1 + 400) =
                       *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
                }
                *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)aiStack_84[3];
                *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
                puStack_c = (uint *)((int)puStack_c + uStack_74);
                puStack_14 = puStack_c;
                puVar17 = puStack_8;
              }
              param_3 = (uint *)((int)param_3 + uStack_74);
            } while (param_3 < puVar17);
          }
        }
      }
      param_2 = puStack_14;
      iVar16 = iStack_10;
    } while (puStack_c < puStack_64);
  }
  *(int *)(param_1 + 0x1a0) = iStack_2c;
  *(int *)(param_1 + 0x1a4) = iStack_40;
  *(int *)(param_1 + 0x1a8) = iStack_54;
  return (int)puStack_34 - (int)param_2;
code_r0x00ab3b7a:
  puVar11 = puVar11 + 1;
  puVar12 = puVar12 + 1;
  if ((uint *)((int)puStack_34 + -3) <= puVar11) goto LAB_00ab3b84;
  goto LAB_00ab3b70;
code_r0x00ab41de:
  puVar12 = puVar12 + 1;
  puVar11 = puVar11 + 1;
  if ((uint *)((int)puStack_34 + -3) <= puVar12) goto LAB_00ab41e8;
  goto LAB_00ab41d4;
}



/* FUNCTION 22070 ; VA 0x00ab4bd0 ; FUN_00ab4bd0 */

int FUN_00ab4bd0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  byte bVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  undefined4 *puVar15;
  undefined4 *puVar16;
  int iVar17;
  uint uVar18;
  uint uVar19;
  undefined4 uVar20;
  undefined8 uVar21;
  int aiStack_8c [3];
  undefined4 *puStack_80;
  undefined4 *puStack_7c;
  int iStack_78;
  undefined4 *puStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  uint uStack_60;
  int iStack_5c;
  int iStack_58;
  uint uStack_54;
  undefined4 *puStack_50;
  undefined4 *puStack_4c;
  uint uStack_48;
  undefined4 *puStack_44;
  undefined4 *puStack_40;
  uint *puStack_3c;
  undefined4 *puStack_38;
  undefined4 *puStack_34;
  int iStack_30;
  uint uStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  undefined4 *puStack_10;
  undefined4 *puStack_c;
  undefined4 uStack_8;
  
  iStack_78 = *(int *)(param_1 + 4);
  uStack_48 = (int)param_2 + (int)param_3;
  puStack_34 = param_2;
  puStack_80 = (undefined4 *)(uStack_48 - 8);
  uVar1 = *(uint *)(param_1 + 0x10);
  uStack_60 = *(uint *)(param_1 + 0xc);
  puStack_7c = (undefined4 *)(iStack_78 + uStack_60);
  iVar2 = *(int *)(param_1 + 8);
  uVar12 = uStack_60 + iVar2;
  iVar17 = 1 << ((byte)*(undefined4 *)(param_1 + 0x9c) & 0x1f);
  puStack_74 = *(undefined4 **)(param_1 + 0xa4);
  iStack_70 = *(int *)(param_1 + 0xa0);
  puVar3 = *(undefined4 **)(param_1 + 0x1c0);
  puStack_18 = (undefined4 *)((iStack_70 != 3) + 3);
  iStack_30 = *(int *)(param_1 + 0x1bc);
  aiStack_8c[0] = *(int *)(param_1 + 0x194);
  aiStack_8c[1] = *(int *)(param_1 + 0x198);
  aiStack_8c[2] = *(int *)(param_1 + 0x19c);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  iStack_64 = aiStack_8c[2];
  iStack_5c = aiStack_8c[1];
  iStack_58 = aiStack_8c[0];
  FUN_00aaf290(param_1 + 0x1ac,param_2,param_3);
  puStack_14 = (undefined4 *)((uint)(param_2 == puStack_7c) + (int)param_2);
  if (puStack_14 < puStack_80) {
    do {
      *puVar3 = 0;
      puVar3[1] = 0;
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar15 = (undefined4 *)0x0;
      iStack_68 = (int)puStack_14 - iStack_78;
      *(undefined8 *)(puVar3 + 4) = 0;
      puVar3[6] = 0;
      puVar3[3] = (int)puStack_14 - (int)param_2;
      puStack_10 = (undefined4 *)0x0;
      puStack_20 = (undefined4 *)(uint)(puStack_14 == param_2);
      puStack_c = puStack_20;
      puStack_1c = (undefined4 *)((int)puStack_20 + 3);
      do {
        puVar14 = puStack_18;
        if (puStack_20 == (undefined4 *)0x3) {
          iVar7 = iStack_58 + -1;
        }
        else {
          iVar7 = aiStack_8c[(int)puStack_20];
        }
        uVar18 = iStack_68 - iVar7;
        iVar9 = iStack_78;
        if (uVar18 < uStack_60) {
          iVar9 = iVar2;
        }
        if (((0 < iVar7) && (iVar7 <= iStack_68)) &&
           (uVar1 < uVar18 && 2 < (uStack_60 - uVar18) - 1)) {
          uVar21 = FUN_00aaf270(puStack_14,puStack_18);
          iVar7 = (int)((ulonglong)uVar21 >> 0x20);
          if (iStack_70 == 3) {
            iVar7 = iVar7 << 8;
          }
          if ((int)uVar21 == iVar7) {
            uVar19 = uStack_48;
            if (uVar18 < uStack_60) {
              uVar19 = uVar12;
            }
            iVar7 = iVar9 + uVar18 + (int)puStack_18;
            uVar8 = (((int)puStack_14 + (int)puStack_18) - iVar7) + uVar19;
            uVar18 = uStack_48;
            if (uVar8 < uStack_48) {
              uVar18 = uVar8;
            }
            iVar9 = FUN_00abcfb0((int)puStack_14 + (int)puStack_18,iVar7,uVar18);
            puVar13 = puStack_18;
            if (iVar9 + iVar7 == uVar19) {
              iVar7 = FUN_00abcfb0((int)puStack_14 + (int)puStack_18 + iVar9,puStack_7c,uStack_48);
              iVar9 = iVar9 + iVar7;
            }
            puVar13 = (undefined4 *)(iVar9 + (int)puVar13);
            puStack_4c = puVar13;
            if ((puStack_74 < puVar13) || (&DAT_00001000 <= puVar13)) {
              puVar15 = (undefined4 *)0x1;
              param_3 = (undefined4 *)0x0;
              puStack_10 = (undefined4 *)0x1;
              goto LAB_00ab5c8a;
            }
            uStack_54 = (int)puStack_20 + (1 - (int)puStack_c);
            uVar20 = puVar3[3];
            puStack_40 = (undefined4 *)((int)puVar13 + -3);
            puVar13 = puVar3 + (int)puVar13 * 7 + 1;
            do {
              uVar18 = 0x1f;
              if (uStack_54 != 0) {
                for (; uStack_54 >> uVar18 == 0; uVar18 = uVar18 - 1) {
                }
              }
              uVar19 = uVar18 & 0xff;
              uStack_2c = 0;
              if (*(int *)(param_1 + 0x1f0) == 0) {
                uVar8 = *(int *)(*(int *)(param_1 + 0x1b8) + uVar19 * 4) + 1;
                iVar7 = 0x1f;
                if (uVar8 != 0) {
                  for (; uVar8 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                  }
                }
                puStack_28 = (undefined4 *)((*(int *)(param_1 + 0x1e8) - iVar7) + uVar19);
                if (0x13 < (byte)uVar18) {
                  puStack_28 = (undefined4 *)((int)puStack_28 + uVar19 * 2 + -0x26);
                }
                if (puStack_40 < (undefined4 *)0x80) {
                  bVar6 = *(byte *)(puStack_40 + 0x651e52);
                }
                else {
                  iVar7 = 0x1f;
                  if (puStack_40 != (undefined4 *)0x0) {
                    for (; (uint)puStack_40 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                    }
                  }
                  bVar6 = (char)iVar7 + 0x24;
                }
                uStack_2c = 0;
                uVar18 = *(int *)(*(int *)(param_1 + 0x1b4) + (uint)bVar6 * 4) + 1;
                iVar7 = 0x1f;
                if (uVar18 != 0) {
                  for (; uVar18 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                  }
                }
                iVar9 = (int)puStack_28 +
                        ((*(int *)(&DAT_01947788 + (uint)bVar6 * 4) + *(int *)(param_1 + 0x1d8)) -
                        iVar7);
                iVar7 = FUN_00aae0d0(param_1 + 0x1ac,uVar20,puStack_34);
                uVar18 = iVar7 + *(int *)(param_1 + 0x1ec) + iVar9;
              }
              else {
                iVar7 = 0x1f;
                if ((int)puStack_40 + 1U != 0) {
                  for (; (int)puStack_40 + 1U >> iVar7 == 0; iVar7 = iVar7 + -1) {
                  }
                }
                puStack_28 = puVar13;
                iVar9 = FUN_00aae0d0(param_1 + 0x1ac,uVar20,puStack_34);
                uVar18 = uVar19 + 0x10 + iVar9 + iVar7;
                puVar13 = puStack_28;
              }
              if (puStack_10 < puStack_4c) {
LAB_00ab4efe:
                puVar15 = puVar3 + ((int)puStack_10 + 1) * 7;
                iVar7 = (int)puStack_4c - (int)puStack_10;
                puStack_10 = puStack_4c;
                do {
                  *puVar15 = 0x40000000;
                  puVar15 = puVar15 + 7;
                  iVar7 = iVar7 + -1;
                } while (iVar7 != 0);
LAB_00ab4f2e:
                *puVar13 = puStack_20;
                puVar13[1] = puStack_4c;
                puVar13[2] = uVar20;
                puVar13[-1] = uVar18;
              }
              else if (uVar18 < (uint)puVar13[-1]) {
                if (puStack_10 < puStack_4c) goto LAB_00ab4efe;
                goto LAB_00ab4f2e;
              }
              puStack_4c = (undefined4 *)((int)puStack_4c + -1);
              puStack_40 = (undefined4 *)((int)puStack_40 + -1);
              puVar13 = puVar13 + -7;
              puStack_28 = puVar13;
              puVar15 = puStack_10;
              puVar14 = puStack_18;
            } while (puStack_18 <= puStack_4c);
          }
        }
        puStack_20 = (undefined4 *)((int)puStack_20 + 1);
      } while (puStack_20 < puStack_1c);
      puStack_1c = (undefined4 *)
                   FUN_00aa8910(param_1,puStack_14,uStack_48,iVar17,iStack_70,iStack_30,puVar14);
      if ((puVar15 == (undefined4 *)0x0) && (puStack_1c == (undefined4 *)0x0)) {
        puStack_14 = (undefined4 *)((int)puStack_14 + 1);
      }
      else {
        puVar3[4] = iStack_58;
        puVar3[5] = iStack_5c;
        puVar3[6] = iStack_64;
        puVar3[2] = 1;
        if ((puStack_1c == (undefined4 *)0x0) ||
           ((puVar13 = *(undefined4 **)(iStack_30 + -4 + (int)puStack_1c * 8), puVar13 <= puStack_74
            && (puVar13 < &DAT_00001000)))) {
          puVar13 = puVar14;
          if (puVar15 != (undefined4 *)0x0) {
            puVar13 = puVar15;
          }
          puStack_24 = (undefined4 *)0x0;
          if (puStack_1c != (undefined4 *)0x0) {
            do {
              if (puStack_24 != (undefined4 *)0x0) {
                puVar13 = (undefined4 *)(*(int *)(iStack_30 + -4 + (int)puStack_24 * 8) + 1);
              }
              puStack_28 = (undefined4 *)((int)puStack_24 * 8);
              puStack_50 = *(undefined4 **)((int)puStack_24 * 8 + iStack_30 + 4);
              uVar20 = puVar3[3];
              if (puVar13 <= puStack_50) {
                puStack_40 = (undefined4 *)((int)puVar13 + -3);
                puStack_38 = puVar3 + (int)puVar13 * 7 + 1;
                do {
                  uStack_2c = 0;
                  uStack_54 = 0x1f;
                  if (*(uint *)((int)puStack_28 + iStack_30) != 0) {
                    for (; *(uint *)((int)puStack_28 + iStack_30) >> uStack_54 == 0;
                        uStack_54 = uStack_54 - 1) {
                    }
                  }
                  puStack_c = (undefined4 *)(uStack_54 & 0xff);
                  if (*(int *)(param_1 + 0x1f0) == 0) {
                    uVar18 = *(int *)(*(int *)(param_1 + 0x1b8) + (int)puStack_c * 4) + 1;
                    iVar7 = 0x1f;
                    if (uVar18 != 0) {
                      for (; uVar18 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                      }
                    }
                    iVar7 = (*(int *)(param_1 + 0x1e8) - iVar7) + (int)puStack_c;
                    if (0x13 < (byte)uStack_54) {
                      iVar7 = iVar7 + (int)puStack_c * 2 + -0x26;
                    }
                    if (puStack_40 < (undefined4 *)0x80) {
                      bVar6 = *(byte *)(puStack_40 + 0x651e52);
                    }
                    else {
                      iVar9 = 0x1f;
                      if (puStack_40 != (undefined4 *)0x0) {
                        for (; (uint)puStack_40 >> iVar9 == 0; iVar9 = iVar9 + -1) {
                        }
                      }
                      bVar6 = (char)iVar9 + 0x24;
                    }
                    uStack_2c = 0;
                    uVar18 = *(int *)(*(int *)(param_1 + 0x1b4) + (uint)bVar6 * 4) + 1;
                    iVar9 = 0x1f;
                    if (uVar18 != 0) {
                      for (; uVar18 >> iVar9 == 0; iVar9 = iVar9 + -1) {
                      }
                    }
                    iVar4 = *(int *)(&DAT_01947788 + (uint)bVar6 * 4);
                    iVar11 = *(int *)(param_1 + 0x1d8);
                    iVar10 = FUN_00aae0d0(param_1 + 0x1ac,uVar20,puStack_34);
                    uVar18 = iVar10 + *(int *)(param_1 + 0x1ec) + iVar7 + ((iVar4 + iVar11) - iVar9)
                    ;
                    puVar15 = puStack_10;
                  }
                  else {
                    iVar7 = 0x1f;
                    if ((int)puStack_40 + 1U != 0) {
                      for (; (int)puStack_40 + 1U >> iVar7 == 0; iVar7 = iVar7 + -1) {
                      }
                    }
                    iVar9 = FUN_00aae0d0(param_1 + 0x1ac,uVar20,puStack_34);
                    uVar18 = (int)puStack_c + iVar9 + iVar7 + 0x10;
                  }
                  if (puVar15 < puVar13) {
LAB_00ab5155:
                    puVar14 = puVar3 + ((int)puVar15 + 1) * 7;
                    iVar7 = (int)puVar13 - (int)puVar15;
                    puStack_10 = puVar13;
                    do {
                      *puVar14 = 0x40000000;
                      puVar14 = puVar14 + 7;
                      iVar7 = iVar7 + -1;
                      puVar15 = puVar13;
                    } while (iVar7 != 0);
LAB_00ab517e:
                    puStack_38[1] = puVar13;
                    *puStack_38 = *(undefined4 *)((int)puStack_28 + iStack_30);
                    puStack_38[2] = uVar20;
                    puStack_38[-1] = uVar18;
                  }
                  else if (uVar18 < (uint)puStack_38[-1]) {
                    if (puVar15 < puVar13) goto LAB_00ab5155;
                    goto LAB_00ab517e;
                  }
                  puVar13 = (undefined4 *)((int)puVar13 + 1);
                  puStack_40 = (undefined4 *)((int)puStack_40 + 1);
                  puStack_38 = puStack_38 + 7;
                } while (puVar13 <= puStack_50);
              }
              puStack_24 = (undefined4 *)((int)puStack_24 + 1);
              puVar13 = puStack_50;
              puVar14 = puStack_18;
            } while (puStack_24 < puStack_1c);
          }
          if (puVar15 < puVar14) {
            puStack_14 = (undefined4 *)((int)puStack_14 + 1);
            goto LAB_00ab5e87;
          }
          param_3 = (undefined4 *)0x1;
          if (puVar15 != (undefined4 *)0x0) {
            do {
              puStack_44 = (undefined4 *)((int)puStack_14 + (int)param_3);
              puStack_3c = puVar3 + (int)param_3 * 7;
              if (puVar3[(int)param_3 * 7 + -5] == 1) {
                puVar14 = (undefined4 *)(puStack_3c[-4] + 1);
                if (puVar14 < param_3) {
                  iVar7 = FUN_00aae0d0(param_1 + 0x1ac,puVar14,(int)puStack_44 - (int)puVar14);
                  uVar18 = iVar7 + puVar3[((int)param_3 - (int)puVar14) * 7];
                }
                else {
                  uVar18 = FUN_00aae0d0(param_1 + 0x1ac,puVar14,puStack_34);
                }
              }
              else {
                puVar14 = (undefined4 *)0x1;
                iVar7 = FUN_00aae0d0(param_1 + 0x1ac,1,(int)puStack_44 + -1);
                uVar18 = iVar7 + puStack_3c[-7];
              }
              if (puVar15 < param_3) {
LAB_00ab5292:
                puVar13 = puVar3 + ((int)puVar15 + 1) * 7;
                iVar7 = (int)param_3 - (int)puVar15;
                puStack_10 = param_3;
                do {
                  *puVar13 = 0x40000000;
                  puVar13 = puVar13 + 7;
                  iVar7 = iVar7 + -1;
                  puVar15 = param_3;
                } while (iVar7 != 0);
LAB_00ab52c4:
                puStack_3c[3] = (uint)puVar14;
                puStack_3c[2] = 1;
                puStack_3c[1] = 0;
                *puStack_3c = uVar18;
              }
              else if (uVar18 <= *puStack_3c) {
                if (puVar15 < param_3) goto LAB_00ab5292;
                goto LAB_00ab52c4;
              }
              if (param_3 == puVar15) break;
              if (puStack_44 <= puStack_80) {
                uVar18 = puStack_3c[2];
                iVar7 = (int)param_3 - uVar18;
                if (puStack_3c[1] < 4) {
                  if (puStack_3c[1] < 2) {
                    uVar19 = puVar3[iVar7 * 7 + 6];
                  }
                  else {
                    uVar19 = puVar3[iVar7 * 7 + 5];
                  }
                  puStack_3c[6] = uVar19;
                  if (puStack_3c[1] == 0) {
                    uVar19 = puVar3[iVar7 * 7 + 5];
                  }
                  else {
                    uVar19 = puVar3[iVar7 * 7 + 4];
                  }
                  puStack_3c[5] = uVar19;
                  if (puStack_3c[1] == 3) {
                    iVar7 = puVar3[iVar7 * 7 + 4] + -1;
                  }
                  else {
                    iVar7 = puVar3[iVar7 * 7 + puStack_3c[1] + 4];
                  }
                }
                else {
                  puStack_3c[6] = puVar3[iVar7 * 7 + 5];
                  puStack_3c[5] = puVar3[iVar7 * 7 + 4];
                  iVar7 = puStack_3c[1] - 3;
                }
                puVar3[(int)param_3 * 7 + 4] = iVar7;
                puStack_20 = (undefined4 *)(uint)(uVar18 != 1);
                puStack_40 = puStack_18;
                puVar14 = (undefined4 *)((int)puStack_20 + 3);
                puStack_38 = puVar14;
                do {
                  puVar13 = puStack_44;
                  if (puStack_20 == (undefined4 *)0x3) {
                    iVar7 = puStack_3c[4] - 1;
                  }
                  else {
                    iVar7 = puVar3[(int)puStack_20 + (int)param_3 * 7 + 4];
                    puVar14 = puStack_38;
                  }
                  uVar18 = (int)param_3 + (iStack_68 - iVar7);
                  iVar9 = iStack_78;
                  if (uVar18 < uStack_60) {
                    iVar9 = iVar2;
                  }
                  puStack_c = (undefined4 *)(iVar9 + uVar18);
                  if (((0 < iVar7) && (puVar14 = puStack_38, iVar7 <= iStack_68 + (int)param_3)) &&
                     (uVar1 < uVar18 && 2 < (uStack_60 - uVar18) - 1)) {
                    uVar21 = FUN_00aaf270(puStack_44,puStack_18);
                    iVar7 = (int)((ulonglong)uVar21 >> 0x20);
                    if (iStack_70 == 3) {
                      iVar7 = iVar7 << 8;
                    }
                    puVar14 = puStack_38;
                    if ((int)uVar21 == iVar7) {
                      uVar19 = uStack_48;
                      if (uVar18 < uStack_60) {
                        uVar19 = uVar12;
                      }
                      iVar7 = (int)puStack_c + (int)puStack_18;
                      uVar8 = (((int)puStack_44 + (int)puStack_18) - iVar7) + uVar19;
                      uVar18 = uStack_48;
                      if (uVar8 < uStack_48) {
                        uVar18 = uVar8;
                      }
                      puVar13 = (undefined4 *)
                                FUN_00abcfb0((int)puStack_44 + (int)puStack_18,iVar7,uVar18);
                      puStack_c = puVar13;
                      if ((int)puVar13 + iVar7 == uVar19) {
                        iVar7 = FUN_00abcfb0((int)puStack_44 + (int)puStack_18 + (int)puVar13,
                                             puStack_7c,uStack_48);
                        puVar13 = (undefined4 *)((int)puStack_c + iVar7);
                      }
                      puVar13 = (undefined4 *)((int)puVar13 + (int)puStack_18);
                      puStack_4c = puVar13;
                      if (puStack_74 < puVar13) goto LAB_00ab5c64;
                      puStack_c = (undefined4 *)((int)param_3 + (int)puVar13);
                      if (&DAT_00001000 <= puStack_c) goto LAB_00ab5c64;
                      uStack_54 = (int)puVar13 - 3;
                      if (puVar13 <= puStack_40) {
                        puVar13 = puStack_40;
                      }
                      puStack_28 = (undefined4 *)((int)puStack_20 + (uint)(puStack_3c[2] == 1));
                      puStack_50 = puVar3 + (int)puStack_c * 7 + 1;
                      puVar16 = puVar15;
                      puStack_40 = puVar13;
                      do {
                        puVar15 = puStack_10;
                        if (puStack_3c[2] == 1) {
                          puStack_24 = (undefined4 *)puStack_3c[3];
                          if (puStack_24 < param_3) {
                            puStack_1c = (undefined4 *)0x0;
                            uStack_2c = -(int)puStack_24;
                            uVar18 = 0x1f;
                            if (puStack_28 != (undefined4 *)0x0) {
                              for (; (uint)puStack_28 >> uVar18 == 0; uVar18 = uVar18 - 1) {
                              }
                            }
                            iVar7 = uStack_2c + (int)puStack_44;
                            uVar19 = uVar18 & 0xff;
                            if (*(int *)(param_1 + 0x1f0) == 0) {
                              uVar8 = *(int *)(*(int *)(param_1 + 0x1b8) + uVar19 * 4) + 1;
                              iVar9 = 0x1f;
                              if (uVar8 != 0) {
                                for (; uVar8 >> iVar9 == 0; iVar9 = iVar9 + -1) {
                                }
                              }
                              puStack_1c = (undefined4 *)
                                           ((*(int *)(param_1 + 0x1e8) - iVar9) + uVar19);
                              if (0x13 < (byte)uVar18) {
                                puStack_1c = (undefined4 *)((int)puStack_1c + uVar19 * 2 + -0x26);
                              }
                              puVar14 = puStack_1c;
                              if (uStack_54 < 0x80) {
                                bVar6 = (&DAT_01947948)[uStack_54];
                              }
                              else {
                                iVar9 = 0x1f;
                                if (uStack_54 != 0) {
                                  for (; uStack_54 >> iVar9 == 0; iVar9 = iVar9 + -1) {
                                  }
                                }
                                bVar6 = (char)iVar9 + 0x24;
                              }
                              uStack_8 = 0;
                              uVar18 = *(int *)(*(int *)(param_1 + 0x1b4) + (uint)bVar6 * 4) + 1;
                              iVar9 = 0x1f;
                              if (uVar18 != 0) {
                                for (; uVar18 >> iVar9 == 0; iVar9 = iVar9 + -1) {
                                }
                              }
                              iVar4 = *(int *)(&DAT_01947788 + (uint)bVar6 * 4);
                              iVar11 = *(int *)(param_1 + 0x1d8);
                              iStack_6c = iVar7;
                              iVar7 = FUN_00aae0d0(param_1 + 0x1ac,puStack_24,iVar7);
                              iVar7 = (int)puVar14 +
                                      iVar7 + *(int *)(param_1 + 0x1ec) + ((iVar4 + iVar11) - iVar9)
                              ;
                            }
                            else {
                              iStack_6c = 0;
                              iVar9 = 0x1f;
                              if (uStack_54 + 1 != 0) {
                                for (; uStack_54 + 1 >> iVar9 == 0; iVar9 = iVar9 + -1) {
                                }
                              }
                              iVar7 = FUN_00aae0d0(param_1 + 0x1ac,puStack_24,iVar7);
                              iVar7 = uVar19 + 0x10 + iVar7 + iVar9;
                              puVar15 = puVar16;
                            }
                            uVar18 = puVar3[((int)param_3 + uStack_2c) * 7] + iVar7;
                          }
                          else {
                            uVar19 = 0x1f;
                            if (puStack_28 != (undefined4 *)0x0) {
                              for (; (uint)puStack_28 >> uVar19 == 0; uVar19 = uVar19 - 1) {
                              }
                            }
                            uVar18 = uVar19 & 0xff;
                            uStack_8 = 0;
                            if (*(int *)(param_1 + 0x1f0) != 0) {
                              iVar9 = 0x1f;
                              if (uStack_54 + 1 != 0) {
                                for (; uStack_54 + 1 >> iVar9 == 0; iVar9 = iVar9 + -1) {
                                }
                              }
                              iVar7 = FUN_00aae0d0(param_1 + 0x1ac,puStack_24,puStack_34);
                              uVar18 = uVar18 + 0x10;
                              iVar7 = iVar7 + iVar9;
                              goto LAB_00ab57c1;
                            }
                            uVar8 = *(int *)(*(int *)(param_1 + 0x1b8) + uVar18 * 4) + 1;
                            iVar7 = 0x1f;
                            if (uVar8 != 0) {
                              for (; uVar8 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                              }
                            }
                            puStack_1c = (undefined4 *)
                                         ((*(int *)(param_1 + 0x1e8) - iVar7) + uVar18);
                            if (0x13 < (byte)uVar19) {
                              puStack_1c = (undefined4 *)((int)puStack_1c + uVar18 * 2 + -0x26);
                            }
                            puVar14 = puStack_1c;
                            if (uStack_54 < 0x80) {
                              bVar6 = (&DAT_01947948)[uStack_54];
                            }
                            else {
                              iVar7 = 0x1f;
                              if (uStack_54 != 0) {
                                for (; uStack_54 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                                }
                              }
                              bVar6 = (char)iVar7 + 0x24;
                            }
                            uStack_8 = 0;
                            uVar18 = *(int *)(*(int *)(param_1 + 0x1b4) + (uint)bVar6 * 4) + 1;
                            iVar7 = 0x1f;
                            if (uVar18 != 0) {
                              for (; uVar18 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                              }
                            }
                            iVar9 = *(int *)(&DAT_01947788 + (uint)bVar6 * 4);
                            iVar4 = *(int *)(param_1 + 0x1d8);
                            iVar11 = FUN_00aae0d0(param_1 + 0x1ac,puStack_24,puStack_34);
                            uVar18 = (int)puVar14 +
                                     iVar11 + *(int *)(param_1 + 0x1ec) + ((iVar9 + iVar4) - iVar7);
                          }
                        }
                        else {
                          puStack_1c = (undefined4 *)0x1f;
                          if (puStack_28 != (undefined4 *)0x0) {
                            for (; (uint)puStack_28 >> (int)puStack_1c == 0;
                                puStack_1c = (undefined4 *)((int)puStack_1c + -1)) {
                            }
                          }
                          puStack_24 = (undefined4 *)0x0;
                          if (*(int *)(param_1 + 0x1f0) == 0) {
                            uVar19 = (uint)puStack_1c & 0xff;
                            uVar18 = *(int *)(*(int *)(param_1 + 0x1b8) + uVar19 * 4) + 1;
                            iVar7 = 0x1f;
                            if (uVar18 != 0) {
                              for (; uVar18 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                              }
                            }
                            iVar7 = (*(int *)(param_1 + 0x1e8) - iVar7) + uVar19;
                            if (0x13 < (byte)puStack_1c) {
                              iVar7 = iVar7 + uVar19 * 2 + -0x26;
                            }
                            if (uStack_54 < 0x80) {
                              bVar6 = (&DAT_01947948)[uStack_54];
                            }
                            else {
                              iVar9 = 0x1f;
                              if (uStack_54 != 0) {
                                for (; uStack_54 >> iVar9 == 0; iVar9 = iVar9 + -1) {
                                }
                              }
                              bVar6 = (char)iVar9 + 0x24;
                            }
                            uVar18 = *(int *)(*(int *)(param_1 + 0x1b4) + (uint)bVar6 * 4) + 1;
                            iVar9 = 0x1f;
                            if (uVar18 != 0) {
                              for (; uVar18 >> iVar9 == 0; iVar9 = iVar9 + -1) {
                              }
                            }
                            uVar18 = **(int **)(param_1 + 0x1b0) + 1;
                            iVar4 = 0x1f;
                            if (uVar18 != 0) {
                              for (; uVar18 >> iVar4 == 0; iVar4 = iVar4 + -1) {
                              }
                            }
                            iVar7 = *(int *)(param_1 + 0x1ec) + (*(int *)(param_1 + 0x1e0) - iVar4)
                                    + iVar7 + ((*(int *)(&DAT_01947788 + (uint)bVar6 * 4) +
                                               *(int *)(param_1 + 0x1d8)) - iVar9);
                          }
                          else {
                            for (iVar9 = 0x1f; 1U >> iVar9 == 0; iVar9 = iVar9 + -1) {
                            }
                            iVar7 = 0x1f;
                            if (uStack_54 + 1 != 0) {
                              for (; uStack_54 + 1 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                              }
                            }
                            iVar7 = ((uint)puStack_1c & 0xff) + 0x10 + iVar9 + iVar7;
                          }
                          uStack_8 = 0;
                          uVar18 = *puStack_3c;
LAB_00ab57c1:
                          uVar18 = uVar18 + iVar7;
                          puVar15 = puVar16;
                        }
                        if (puVar15 < puStack_c) {
LAB_00ab57d6:
                          puVar14 = puVar3 + ((int)puVar15 + 1) * 7;
                          do {
                            puVar15 = (undefined4 *)((int)puVar15 + 1);
                            *puVar14 = 0x40000000;
                            puVar14 = puVar14 + 7;
                            puStack_10 = puVar15;
                          } while (puVar15 < puStack_c);
LAB_00ab5801:
                          *puStack_50 = puStack_20;
                          puStack_50[1] = puStack_4c;
                          puStack_50[2] = puStack_24;
                          puStack_50[-1] = uVar18;
                        }
                        else if (uVar18 <= (uint)puStack_50[-1]) {
                          if (puVar15 < puStack_c) goto LAB_00ab57d6;
                          goto LAB_00ab5801;
                        }
                        puStack_50 = puStack_50 + -7;
                        puStack_4c = (undefined4 *)((int)puStack_4c + -1);
                        puStack_c = (undefined4 *)((int)puStack_c + -1);
                        uStack_54 = uStack_54 - 1;
                        puVar14 = puStack_38;
                        puVar16 = puVar15;
                        puVar13 = puStack_44;
                      } while (puStack_18 <= puStack_4c);
                    }
                  }
                  puStack_20 = (undefined4 *)((int)puStack_20 + 1);
                } while (puStack_20 < puVar14);
                puVar14 = (undefined4 *)
                          FUN_00aa8910(param_1,puVar13,uStack_48,iVar17,iStack_70,iStack_30,
                                       puStack_18);
                puStack_44 = puVar14;
                if ((puVar14 != (undefined4 *)0x0) &&
                   ((puVar13 = *(undefined4 **)(iStack_30 + -4 + (int)puVar14 * 8),
                    puStack_74 < puVar13 || (0xfff < (uint)((int)puVar13 + (int)param_3))))) {
                  puStack_20 = *(undefined4 **)(iStack_30 + -8 + (int)puVar14 * 8);
LAB_00ab5c64:
                  puVar15 = (undefined4 *)((int)param_3 + 1);
                  puStack_10 = puVar15;
                  goto LAB_00ab5c8a;
                }
                puStack_20 = (undefined4 *)0x0;
                if (puVar14 != (undefined4 *)0x0) {
                  do {
                    puStack_38 = puStack_40;
                    if (puStack_20 != (undefined4 *)0x0) {
                      puStack_38 = (undefined4 *)
                                   (*(int *)(iStack_30 + -4 + (int)puStack_20 * 8) + 1);
                    }
                    puStack_50 = (undefined4 *)((int)puStack_20 * 8);
                    puStack_40 = *(undefined4 **)((int)puStack_20 * 8 + iStack_30 + 4);
                    puVar15 = puStack_10;
                    if (puStack_38 <= puStack_40) {
                      puStack_4c = (undefined4 *)((int)param_3 + (int)puStack_38);
                      puStack_1c = (undefined4 *)((int)puStack_38 + -3);
                      puStack_28 = puVar3 + (int)puStack_4c * 7 + 1;
                      puVar13 = puStack_10;
                      do {
                        puVar15 = puStack_10;
                        uStack_8 = 0;
                        if (puStack_3c[2] == 1) {
                          puStack_24 = (undefined4 *)puStack_3c[3];
                          uVar18 = *(uint *)(iStack_30 + (int)puStack_50);
                          if (puStack_24 < param_3) {
                            uStack_2c = (int)param_3 - (int)puStack_24;
                            uStack_54 = uStack_2c + (int)puStack_14;
                            uVar19 = 0x1f;
                            if (uVar18 != 0) {
                              for (; uVar18 >> uVar19 == 0; uVar19 = uVar19 - 1) {
                              }
                            }
                            uVar18 = uVar19 & 0xff;
                            if (*(int *)(param_1 + 0x1f0) == 0) {
                              uVar8 = *(int *)(*(int *)(param_1 + 0x1b8) + uVar18 * 4) + 1;
                              iVar7 = 0x1f;
                              if (uVar8 != 0) {
                                for (; uVar8 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                                }
                              }
                              puStack_c = (undefined4 *)
                                          ((*(int *)(param_1 + 0x1e8) - iVar7) + uVar18);
                              if (0x13 < (byte)uVar19) {
                                puStack_c = (undefined4 *)((int)puStack_c + uVar18 * 2 + -0x26);
                              }
                              puVar14 = puStack_c;
                              if (puStack_1c < (undefined4 *)0x80) {
                                bVar6 = *(byte *)(puStack_1c + 0x651e52);
                              }
                              else {
                                iVar7 = 0x1f;
                                if (puStack_1c != (undefined4 *)0x0) {
                                  for (; (uint)puStack_1c >> iVar7 == 0; iVar7 = iVar7 + -1) {
                                  }
                                }
                                bVar6 = (char)iVar7 + 0x24;
                              }
                              uStack_8 = 0;
                              uVar18 = *(int *)(*(int *)(param_1 + 0x1b4) + (uint)bVar6 * 4) + 1;
                              iVar7 = 0x1f;
                              if (uVar18 != 0) {
                                for (; uVar18 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                                }
                              }
                              iVar9 = *(int *)(&DAT_01947788 + (uint)bVar6 * 4);
                              iVar4 = *(int *)(param_1 + 0x1d8);
                              iVar11 = FUN_00aae0d0(param_1 + 0x1ac,puStack_24,uStack_54);
                              iVar7 = (int)puVar14 +
                                      iVar11 + *(int *)(param_1 + 0x1ec) + ((iVar9 + iVar4) - iVar7)
                              ;
                            }
                            else {
                              iVar7 = 0x1f;
                              if ((int)puStack_1c + 1U != 0) {
                                for (; (int)puStack_1c + 1U >> iVar7 == 0; iVar7 = iVar7 + -1) {
                                }
                              }
                              iVar9 = FUN_00aae0d0(param_1 + 0x1ac,puStack_24,uStack_54);
                              iVar7 = uVar18 + 0x10 + iVar9 + iVar7;
                              puVar15 = puVar13;
                            }
                            uVar18 = puVar3[uStack_2c * 7] + iVar7;
                          }
                          else {
                            uVar19 = 0x1f;
                            if (uVar18 != 0) {
                              for (; uVar18 >> uVar19 == 0; uVar19 = uVar19 - 1) {
                              }
                            }
                            uVar18 = uVar19 & 0xff;
                            if (*(int *)(param_1 + 0x1f0) != 0) {
                              iVar9 = 0x1f;
                              if ((int)puStack_1c + 1U != 0) {
                                for (; (int)puStack_1c + 1U >> iVar9 == 0; iVar9 = iVar9 + -1) {
                                }
                              }
                              iVar7 = FUN_00aae0d0(param_1 + 0x1ac,puStack_24,puStack_34);
                              uVar18 = uVar18 + 0x10;
                              iVar7 = iVar7 + iVar9;
                              goto LAB_00ab5bbf;
                            }
                            uVar8 = *(int *)(*(int *)(param_1 + 0x1b8) + uVar18 * 4) + 1;
                            iVar7 = 0x1f;
                            if (uVar8 != 0) {
                              for (; uVar8 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                              }
                            }
                            puStack_c = (undefined4 *)((*(int *)(param_1 + 0x1e8) - iVar7) + uVar18)
                            ;
                            if (0x13 < (byte)uVar19) {
                              puStack_c = (undefined4 *)((int)puStack_c + uVar18 * 2 + -0x26);
                            }
                            puVar14 = puStack_c;
                            if (puStack_1c < (undefined4 *)0x80) {
                              bVar6 = *(byte *)(puStack_1c + 0x651e52);
                            }
                            else {
                              iVar7 = 0x1f;
                              if (puStack_1c != (undefined4 *)0x0) {
                                for (; (uint)puStack_1c >> iVar7 == 0; iVar7 = iVar7 + -1) {
                                }
                              }
                              bVar6 = (char)iVar7 + 0x24;
                            }
                            uStack_8 = 0;
                            uVar18 = *(int *)(*(int *)(param_1 + 0x1b4) + (uint)bVar6 * 4) + 1;
                            iVar7 = 0x1f;
                            if (uVar18 != 0) {
                              for (; uVar18 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                              }
                            }
                            iVar9 = *(int *)(&DAT_01947788 + (uint)bVar6 * 4);
                            iVar4 = *(int *)(param_1 + 0x1d8);
                            iVar11 = FUN_00aae0d0(param_1 + 0x1ac,puStack_24,puStack_34);
                            uVar18 = (int)puVar14 +
                                     iVar11 + *(int *)(param_1 + 0x1ec) + ((iVar9 + iVar4) - iVar7);
                          }
                        }
                        else {
                          puStack_24 = (undefined4 *)0x0;
                          puStack_c = (undefined4 *)0x1f;
                          if (*(uint *)(iStack_30 + (int)puStack_50) != 0) {
                            for (; *(uint *)(iStack_30 + (int)puStack_50) >> (int)puStack_c == 0;
                                puStack_c = (undefined4 *)((int)puStack_c + -1)) {
                            }
                          }
                          if (*(int *)(param_1 + 0x1f0) == 0) {
                            uVar19 = (uint)puStack_c & 0xff;
                            uVar18 = *(int *)(*(int *)(param_1 + 0x1b8) + uVar19 * 4) + 1;
                            iVar7 = 0x1f;
                            if (uVar18 != 0) {
                              for (; uVar18 >> iVar7 == 0; iVar7 = iVar7 + -1) {
                              }
                            }
                            iVar7 = (*(int *)(param_1 + 0x1e8) - iVar7) + uVar19;
                            if (0x13 < (byte)puStack_c) {
                              iVar7 = iVar7 + uVar19 * 2 + -0x26;
                            }
                            if (puStack_1c < (undefined4 *)0x80) {
                              bVar6 = *(byte *)(puStack_1c + 0x651e52);
                            }
                            else {
                              iVar9 = 0x1f;
                              if (puStack_1c != (undefined4 *)0x0) {
                                for (; (uint)puStack_1c >> iVar9 == 0; iVar9 = iVar9 + -1) {
                                }
                              }
                              bVar6 = (char)iVar9 + 0x24;
                            }
                            uVar18 = *(int *)(*(int *)(param_1 + 0x1b4) + (uint)bVar6 * 4) + 1;
                            iVar9 = 0x1f;
                            if (uVar18 != 0) {
                              for (; uVar18 >> iVar9 == 0; iVar9 = iVar9 + -1) {
                              }
                            }
                            uVar18 = **(int **)(param_1 + 0x1b0) + 1;
                            iVar4 = 0x1f;
                            if (uVar18 != 0) {
                              for (; uVar18 >> iVar4 == 0; iVar4 = iVar4 + -1) {
                              }
                            }
                            iVar7 = *(int *)(param_1 + 0x1ec) + (*(int *)(param_1 + 0x1e0) - iVar4)
                                    + iVar7 + ((*(int *)(&DAT_01947788 + (uint)bVar6 * 4) +
                                               *(int *)(param_1 + 0x1d8)) - iVar9);
                          }
                          else {
                            for (iVar9 = 0x1f; 1U >> iVar9 == 0; iVar9 = iVar9 + -1) {
                            }
                            iVar7 = 0x1f;
                            if ((int)puStack_1c + 1U != 0) {
                              for (; (int)puStack_1c + 1U >> iVar7 == 0; iVar7 = iVar7 + -1) {
                              }
                            }
                            iVar7 = ((uint)puStack_c & 0xff) + 0x10 + iVar9 + iVar7;
                          }
                          uStack_8 = 0;
                          uVar18 = *puStack_3c;
LAB_00ab5bbf:
                          uVar18 = uVar18 + iVar7;
                          puVar15 = puVar13;
                        }
                        if (puVar15 < puStack_4c) {
LAB_00ab5bd4:
                          puVar14 = puVar3 + ((int)puVar15 + 1) * 7;
                          do {
                            puVar15 = (undefined4 *)((int)puVar15 + 1);
                            *puVar14 = 0x40000000;
                            puVar14 = puVar14 + 7;
                          } while (puVar15 < puStack_4c);
                          puStack_10 = puVar15;
LAB_00ab5bf7:
                          puStack_28[1] = puStack_38;
                          *puStack_28 = *(undefined4 *)(iStack_30 + (int)puStack_50);
                          puStack_28[2] = puStack_24;
                          puStack_28[-1] = uVar18;
                        }
                        else if (uVar18 < (uint)puStack_28[-1]) {
                          if (puVar15 < puStack_4c) goto LAB_00ab5bd4;
                          goto LAB_00ab5bf7;
                        }
                        puStack_28 = puStack_28 + 7;
                        puStack_38 = (undefined4 *)((int)puStack_38 + 1);
                        puStack_1c = (undefined4 *)((int)puStack_1c + 1);
                        puStack_4c = (undefined4 *)((int)puStack_4c + 1);
                        puVar14 = puStack_44;
                        puVar13 = puVar15;
                      } while (puStack_38 <= puStack_40);
                    }
                    puStack_20 = (undefined4 *)((int)puStack_20 + 1);
                  } while (puStack_20 < puVar14);
                }
              }
              param_3 = (undefined4 *)((int)param_3 + 1);
            } while (param_3 <= puVar15);
          }
          puVar13 = (undefined4 *)puVar3[(int)puVar15 * 7 + 2];
          puStack_20 = (undefined4 *)puVar3[(int)puVar15 * 7 + 1];
          param_3 = (undefined4 *)((int)puVar15 - (int)puVar13);
        }
        else {
          puStack_20 = *(undefined4 **)(iStack_30 + -8 + (int)puStack_1c * 8);
          puVar15 = (undefined4 *)0x1;
          param_3 = (undefined4 *)0x0;
          puStack_10 = (undefined4 *)0x1;
        }
LAB_00ab5c8a:
        puVar3[2] = 1;
        puVar14 = (undefined4 *)puVar3[(int)param_3 * 7 + 2];
        uVar20 = puVar3[(int)param_3 * 7 + 1];
        puVar3[(int)param_3 * 7 + 2] = puVar13;
        puVar3[(int)param_3 * 7 + 1] = puStack_20;
        if (puVar14 <= param_3) {
          do {
            param_3 = (undefined4 *)((int)param_3 - (int)puVar14);
            puVar13 = (undefined4 *)puVar3[(int)param_3 * 7 + 2];
            uVar5 = puVar3[(int)param_3 * 7 + 1];
            puVar3[(int)param_3 * 7 + 2] = puVar14;
            puVar3[(int)param_3 * 7 + 1] = uVar20;
            puVar14 = puVar13;
            puVar15 = puStack_10;
            uVar20 = uVar5;
          } while (puVar13 <= param_3);
        }
        puVar14 = (undefined4 *)0x0;
        do {
          puVar14 = (undefined4 *)((int)puVar14 + puVar3[(int)puVar14 * 7 + 2]);
        } while (puVar14 <= puVar15);
        param_3 = (undefined4 *)0x0;
        if (puVar15 != (undefined4 *)0x0) {
          do {
            puVar14 = puStack_34;
            iStack_6c = puVar3[(int)param_3 * 7 + 2];
            if (iStack_6c == 1) {
              puStack_14 = (undefined4 *)((int)puStack_14 + 1);
            }
            else {
              uVar18 = puVar3[(int)param_3 * 7 + 1];
              uVar19 = (int)puStack_14 - (int)puStack_34;
              if (uVar18 < 4) {
                if (uVar18 != 0) {
                  if (uVar18 == 3) {
                    aiStack_8c[0] = iStack_58 + -1;
LAB_00ab5d7d:
                    iStack_64 = iStack_5c;
                    aiStack_8c[2] = iStack_5c;
                  }
                  else {
                    aiStack_8c[0] = aiStack_8c[uVar18];
                    if (uVar18 != 1) goto LAB_00ab5d7d;
                  }
                  iStack_5c = iStack_58;
                  aiStack_8c[1] = iStack_58;
                  iStack_58 = aiStack_8c[0];
                }
                if (uVar19 == 0) goto LAB_00ab5d9f;
              }
              else {
                iStack_64 = iStack_5c;
                aiStack_8c[2] = iStack_5c;
                iStack_5c = iStack_58;
                aiStack_8c[1] = iStack_58;
                aiStack_8c[0] = uVar18 - 3;
                iStack_58 = aiStack_8c[0];
LAB_00ab5d9f:
                uVar18 = uVar18 - 1;
              }
              uStack_2c = iStack_6c - 3;
              FUN_00aafda0(param_1 + 0x1ac,uVar19,puStack_34,uVar18,uStack_2c);
              puVar13 = *(undefined4 **)(param_1 + 0x17c);
              puVar15 = (undefined4 *)(uVar19 + (int)puVar13);
              do {
                *puVar13 = *puVar14;
                puVar13[1] = puVar14[1];
                puVar13 = puVar13 + 2;
                puVar14 = puVar14 + 2;
              } while (puVar13 < puVar15);
              *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar19;
              if (0xffff < uVar19) {
                *(undefined4 *)(param_1 + 0x18c) = 1;
                *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3
                ;
              }
              *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar19;
              **(int **)(param_1 + 0x174) = uVar18 + 1;
              if (0xffff < uStack_2c) {
                *(undefined4 *)(param_1 + 0x18c) = 2;
                *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3
                ;
              }
              *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)uStack_2c;
              *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
              puStack_14 = (undefined4 *)((int)puStack_14 + iStack_6c);
              puStack_34 = puStack_14;
              puVar15 = puStack_10;
            }
            param_3 = (undefined4 *)((int)param_3 + iStack_6c);
          } while (param_3 < puVar15);
        }
      }
LAB_00ab5e87:
      param_2 = puStack_34;
    } while (puStack_14 < puStack_80);
  }
  *(int *)(param_1 + 0x1a0) = iStack_58;
  *(int *)(param_1 + 0x1a4) = iStack_5c;
  *(int *)(param_1 + 0x1a8) = iStack_64;
  return uStack_48 - (int)param_2;
}



/* FUNCTION 22071 ; VA 0x00ab5ec0 ; FUN_00ab5ec0 */

int FUN_00ab5ec0(int param_1,uint *param_2,uint *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  byte bVar4;
  uint uVar5;
  uint uVar6;
  char *pcVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  int iVar11;
  uint *puVar12;
  uint *puVar13;
  char *pcVar14;
  uint *puVar15;
  int iVar16;
  int iVar17;
  int iVar18;
  uint *puVar19;
  undefined8 uVar20;
  int aiStack_84 [3];
  uint *puStack_78;
  int iStack_74;
  uint *puStack_70;
  int iStack_6c;
  uint *puStack_68;
  int iStack_64;
  int iStack_60;
  uint *puStack_5c;
  uint *puStack_58;
  int iStack_54;
  uint *puStack_50;
  uint *puStack_4c;
  uint *puStack_48;
  char *pcStack_44;
  char *pcStack_40;
  uint *puStack_3c;
  uint *puStack_38;
  uint *puStack_34;
  uint *puStack_30;
  uint *puStack_2c;
  uint *puStack_28;
  uint *puStack_24;
  int iStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  uint *puStack_10;
  char *pcStack_c;
  undefined4 uStack_8;
  
  iStack_74 = param_1 + 0x1ac;
  puStack_5c = (uint *)((int)param_2 + (int)param_3);
  puStack_24 = param_2;
  puStack_78 = puStack_5c + -2;
  puStack_70 = (uint *)(*(int *)(param_1 + 0xc) + *(int *)(param_1 + 4));
  iVar17 = 1 << ((byte)*(undefined4 *)(param_1 + 0x9c) & 0x1f);
  puStack_68 = *(uint **)(param_1 + 0xa4);
  iStack_64 = *(int *)(param_1 + 0xa0);
  puVar1 = *(undefined4 **)(param_1 + 0x1c0);
  puStack_2c = (uint *)((iStack_64 != 3) + 3);
  iStack_20 = *(int *)(param_1 + 0x1bc);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  FUN_00aaf290(iStack_74,param_2,param_3);
  iStack_54 = *(int *)(param_1 + 0x194);
  puStack_1c = (uint *)((uint)(param_2 == puStack_70) + (int)param_2);
  iStack_60 = *(int *)(param_1 + 0x198);
  aiStack_84[1] = *(int *)(param_1 + 0x198);
  iStack_6c = *(int *)(param_1 + 0x19c);
  aiStack_84[2] = *(int *)(param_1 + 0x19c);
  iVar16 = param_1 + 0x1ac;
  aiStack_84[0] = iStack_54;
  if (puStack_1c < puStack_78) {
    do {
      puVar19 = (uint *)0x0;
      uVar5 = (int)puStack_1c - (int)param_2;
      puStack_3c = (uint *)0x0;
      *puVar1 = 0;
      puVar1[1] = 0;
      puVar1[2] = 0;
      puVar1[3] = 0;
      puStack_38 = (uint *)(uint)(puStack_1c == param_2);
      *(undefined8 *)(puVar1 + 4) = 0;
      puVar1[6] = 0;
      puStack_34 = puStack_38;
      puStack_28 = (uint *)((int)puStack_38 + 3);
      puVar12 = puStack_1c;
      do {
        if (puStack_38 == (uint *)0x3) {
          iVar18 = iStack_54 + -1;
        }
        else {
          iVar18 = aiStack_84[(int)puStack_38];
        }
        if ((0 < iVar18) && (iVar18 < (int)puVar12 - (int)puStack_70)) {
          uVar20 = FUN_00aaf270(puStack_1c,puStack_2c);
          iVar8 = (int)((ulonglong)uVar20 >> 0x20);
          if (iStack_64 == 3) {
            iVar8 = iVar8 << 8;
          }
          puVar12 = puStack_1c;
          if ((int)uVar20 == iVar8) {
            puVar13 = (uint *)(((int)puStack_2c - iVar18) + (int)puStack_1c);
            puStack_10 = (uint *)((int)puStack_1c + (int)puStack_2c);
            puVar12 = puStack_10;
            if (puStack_10 < (uint *)((int)puStack_5c + -3)) {
LAB_00ab6030:
              uVar6 = *puVar12 ^ *puVar13;
              if (uVar6 == 0) goto code_r0x00ab603a;
              uVar3 = 0;
              if (uVar6 != 0) {
                for (; (uVar6 >> uVar3 & 1) == 0; uVar3 = uVar3 + 1) {
                }
              }
              pcVar7 = (char *)(((uVar3 >> 3) - (int)puStack_10) + (int)puVar12);
              goto LAB_00ab606c;
            }
LAB_00ab6044:
            if ((puVar12 < (uint *)((int)puStack_5c + -1)) &&
               (*(short *)puVar13 == *(short *)puVar12)) {
              puVar12 = (uint *)((int)puVar12 + 2);
              puVar13 = (uint *)((int)puVar13 + 2);
            }
            if ((puVar12 < puStack_5c) && (*(char *)puVar13 == *(char *)puVar12)) {
              puVar12 = (uint *)((int)puVar12 + 1);
            }
            pcVar7 = (char *)((int)puVar12 - (int)puStack_10);
LAB_00ab606c:
            puVar12 = (uint *)((int)puStack_2c + (int)pcVar7);
            puStack_14 = puVar12;
            if ((puStack_68 < puVar12) || ((uint *)0xfff < puVar12)) {
              puVar19 = (uint *)0x1;
              param_3 = (uint *)0x0;
              puStack_3c = (uint *)0x1;
              goto LAB_00ab6da7;
            }
            pcStack_40 = (char *)((int)puVar12 + -3);
            puStack_4c = (uint *)((int)puStack_38 + (1 - (int)puStack_34));
            puStack_18 = puVar1 + (int)puVar12 * 7 + 1;
            do {
              uVar6 = 0x1f;
              if (puStack_4c != (uint *)0x0) {
                for (; (uint)puStack_4c >> uVar6 == 0; uVar6 = uVar6 - 1) {
                }
              }
              puStack_10 = (uint *)(uVar6 & 0xff);
              pcStack_c = (char *)0x0;
              if (*(int *)(iVar16 + 0x44) == 0) {
                uVar6 = *(int *)(*(int *)(iVar16 + 0xc) + (int)puStack_10 * 4) + 1;
                iVar18 = 0x1f;
                if (uVar6 != 0) {
                  for (; uVar6 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                  }
                }
                if (pcStack_40 < (char *)0x80) {
                  bVar4 = pcStack_40[0x1947948];
                }
                else {
                  iVar8 = 0x1f;
                  if (pcStack_40 != (char *)0x0) {
                    for (; (uint)pcStack_40 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                    }
                  }
                  bVar4 = (char)iVar8 + 0x24;
                }
                pcStack_c = (char *)0x0;
                uVar6 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                iVar8 = 0x1f;
                if (uVar6 != 0) {
                  for (; uVar6 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                  }
                }
                iVar18 = (*(int *)(iVar16 + 0x3c) - iVar18) + (int)puStack_10 +
                         ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) + *(int *)(iVar16 + 0x2c)) -
                         iVar8);
                iVar8 = FUN_00aae0d0(iVar16,uVar5,puStack_24);
                iVar8 = iVar8 + *(int *)(iVar16 + 0x40);
              }
              else {
                iVar18 = 0x1f;
                if (pcStack_40 + 1 != (char *)0x0) {
                  for (; (uint)(pcStack_40 + 1) >> iVar18 == 0; iVar18 = iVar18 + -1) {
                  }
                }
                iVar8 = FUN_00aae0d0(iVar16,uVar5,puStack_24);
                iVar8 = iVar8 + 0x10 + (int)puStack_10;
              }
              puStack_10 = (uint *)(iVar8 + iVar18);
              if (puVar19 < puStack_14) {
LAB_00ab6174:
                puVar10 = puVar1 + (int)((int)puVar19 + 1) * 7;
                iVar18 = (int)puStack_14 - (int)puVar19;
                do {
                  *puVar10 = 0x40000000;
                  puVar10 = puVar10 + 7;
                  iVar18 = iVar18 + -1;
                  puVar19 = puStack_14;
                } while (iVar18 != 0);
LAB_00ab61a1:
                *puStack_18 = (uint)puStack_38;
                puStack_18[1] = (uint)puStack_14;
                puStack_18[2] = uVar5;
                puStack_18[-1] = (uint)puStack_10;
              }
              else if (puStack_10 < (uint *)puStack_18[-1]) {
                if (puVar19 < puStack_14) goto LAB_00ab6174;
                goto LAB_00ab61a1;
              }
              puStack_14 = (uint *)((int)puStack_14 + -1);
              pcStack_40 = pcStack_40 + -1;
              puStack_18 = puStack_18 + -7;
            } while (puStack_2c <= puStack_14);
            puStack_3c = puVar19;
            puVar12 = puStack_1c;
          }
        }
        iVar18 = iStack_20;
        puStack_38 = (uint *)((int)puStack_38 + 1);
      } while (puStack_38 < puStack_28);
      puStack_48 = (uint *)FUN_00aa8870(param_1,puVar12,puStack_5c,iVar17,iStack_64,iStack_20,
                                        puStack_2c);
      if (puVar19 == (uint *)0x0) {
        if (puStack_48 != (uint *)0x0) {
LAB_00ab6238:
          puVar12 = *(uint **)(iVar18 + -4 + (int)puStack_48 * 8);
          if ((puVar12 <= puStack_68) && (iVar18 = iStack_20, puVar12 < &DAT_00001000))
          goto LAB_00ab6262;
          puVar19 = (uint *)0x1;
          puStack_3c = (uint *)0x1;
          puStack_38 = *(uint **)(iStack_20 + -8 + (int)puStack_48 * 8);
          param_3 = (uint *)0x0;
          goto LAB_00ab6da1;
        }
        puStack_1c = (uint *)((int)puStack_1c + 1);
      }
      else {
        if (puStack_48 != (uint *)0x0) goto LAB_00ab6238;
LAB_00ab6262:
        puVar12 = puStack_2c;
        if (puVar19 != (uint *)0x0) {
          puVar12 = puVar19;
        }
        puStack_4c = (uint *)0x0;
        if (puStack_48 != (uint *)0x0) {
          do {
            if (puStack_4c == (uint *)0x0) {
              puStack_18 = puVar12;
            }
            else {
              puVar12 = (uint *)(*(int *)(iVar18 + -4 + (int)puStack_4c * 8) + 1);
              puStack_18 = puVar12;
            }
            puStack_10 = (uint *)((int)puStack_4c * 8);
            puStack_50 = *(uint **)((int)puStack_4c * 8 + iVar18 + 4);
            puStack_18 = puVar12;
            if (puVar12 <= puStack_50) {
              puStack_14 = (uint *)((int)puVar12 + -3);
              puStack_28 = puVar1 + (int)puVar12 * 7 + 1;
              do {
                pcStack_c = (char *)0x0;
                uVar6 = 0x1f;
                if (*(uint *)((int)puStack_10 + iStack_20) != 0) {
                  for (; *(uint *)((int)puStack_10 + iStack_20) >> uVar6 == 0; uVar6 = uVar6 - 1) {
                  }
                }
                puStack_34 = (uint *)(uVar6 & 0xff);
                if (*(int *)(iVar16 + 0x44) == 0) {
                  uVar6 = *(int *)(*(int *)(iVar16 + 0xc) + (int)puStack_34 * 4) + 1;
                  iVar18 = 0x1f;
                  if (uVar6 != 0) {
                    for (; uVar6 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                    }
                  }
                  iVar18 = (*(int *)(iVar16 + 0x3c) - iVar18) + (int)puStack_34;
                  if (puStack_14 < (uint *)0x80) {
                    bVar4 = *(byte *)(puStack_14 + 0x651e52);
                  }
                  else {
                    iVar8 = 0x1f;
                    if (puStack_14 != (uint *)0x0) {
                      for (; (uint)puStack_14 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                      }
                    }
                    bVar4 = (char)iVar8 + 0x24;
                  }
                  pcStack_c = (char *)0x0;
                  uVar6 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                  iVar8 = 0x1f;
                  if (uVar6 != 0) {
                    for (; uVar6 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                    }
                  }
                  iVar2 = *(int *)(&DAT_01947788 + (uint)bVar4 * 4);
                  iVar11 = *(int *)(iVar16 + 0x2c);
                  iVar9 = FUN_00aae0d0(iVar16,uVar5,puStack_24);
                  pcStack_40 = (char *)(iVar9 + *(int *)(iVar16 + 0x40) +
                                       iVar18 + ((iVar2 + iVar11) - iVar8));
                }
                else {
                  iVar18 = 0x1f;
                  if ((char *)((int)puStack_14 + 1U) != (char *)0x0) {
                    for (; (int)puStack_14 + 1U >> iVar18 == 0; iVar18 = iVar18 + -1) {
                    }
                  }
                  iVar8 = FUN_00aae0d0(iVar16,uVar5,puStack_24);
                  pcStack_40 = (char *)(iVar8 + iVar18 + (int)puStack_34 + 0x10U);
                }
                if (puVar19 < puStack_18) {
LAB_00ab637c:
                  puVar10 = puVar1 + (int)((int)puVar19 + 1) * 7;
                  iVar18 = (int)puStack_18 - (int)puVar19;
                  do {
                    *puVar10 = 0x40000000;
                    puVar10 = puVar10 + 7;
                    iVar18 = iVar18 + -1;
                    puVar19 = puStack_18;
                  } while (iVar18 != 0);
LAB_00ab63a2:
                  puStack_28[1] = (uint)puStack_18;
                  *puStack_28 = *(uint *)((int)puStack_10 + iStack_20);
                  puStack_28[2] = uVar5;
                  puStack_28[-1] = (uint)pcStack_40;
                }
                else if (pcStack_40 < (char *)puStack_28[-1]) {
                  if (puVar19 < puStack_18) goto LAB_00ab637c;
                  goto LAB_00ab63a2;
                }
                puStack_14 = (uint *)((int)puStack_14 + 1);
                puStack_18 = (uint *)((int)puStack_18 + 1);
                puStack_28 = puStack_28 + 7;
              } while (puStack_18 <= puStack_50);
              puStack_3c = puVar19;
              iVar18 = iStack_20;
            }
            puStack_4c = (uint *)((int)puStack_4c + 1);
            puVar12 = puStack_50;
          } while (puStack_4c < puStack_48);
        }
        if (puVar19 < puStack_2c) {
          puStack_1c = (uint *)((int)puStack_1c + 1);
        }
        else {
          puVar1[4] = iStack_54;
          puVar1[5] = iStack_60;
          puVar1[6] = iStack_6c;
          puVar1[2] = 1;
          puVar1[3] = uVar5;
          param_3 = (uint *)0x1;
          if (puVar19 != (uint *)0x0) {
            do {
              puStack_48 = (uint *)((int)puStack_1c + (int)param_3);
              puStack_34 = (uint *)((int)param_3 * 0x1c);
              puStack_30 = (uint *)((int)puStack_34 + (int)puVar1);
              if (puStack_30[-5] == 1) {
                puVar12 = (uint *)(puStack_30[-4] + 1);
                if (puVar12 < param_3) {
                  iVar18 = FUN_00aae0d0(iVar16,puVar12,(int)puStack_48 - (int)puVar12);
                  uVar5 = iVar18 + puVar1[((int)param_3 - (int)puVar12) * 7];
                }
                else {
                  uVar5 = FUN_00aae0d0(iVar16,puVar12,puStack_24);
                }
              }
              else {
                puVar12 = (uint *)0x1;
                iVar18 = FUN_00aae0d0(iVar16,1,(char *)((int)puStack_48 + -1));
                uVar5 = iVar18 + puStack_30[-7];
              }
              if (puVar19 < param_3) {
LAB_00ab64d0:
                puVar10 = puVar1 + (int)((int)puVar19 + 1) * 7;
                iVar18 = (int)param_3 - (int)puVar19;
                puStack_3c = param_3;
                do {
                  *puVar10 = 0x40000000;
                  puVar10 = puVar10 + 7;
                  iVar18 = iVar18 + -1;
                  puVar19 = param_3;
                } while (iVar18 != 0);
LAB_00ab6501:
                puStack_30[2] = 1;
                puStack_30[1] = 0;
                puStack_30[3] = (uint)puVar12;
                *puStack_30 = uVar5;
              }
              else if (uVar5 <= *puStack_30) {
                if (puVar19 < param_3) goto LAB_00ab64d0;
                goto LAB_00ab6501;
              }
              if (param_3 == puVar19) break;
              if (puStack_48 <= puStack_78) {
                puStack_10 = (uint *)puStack_30[2];
                iVar18 = (int)param_3 - (int)puStack_10;
                if (puStack_30[1] < 4) {
                  if (puStack_30[1] < 2) {
                    uVar5 = puVar1[iVar18 * 7 + 6];
                  }
                  else {
                    uVar5 = puVar1[iVar18 * 7 + 5];
                  }
                  puStack_30[6] = uVar5;
                  if (puStack_30[1] == 0) {
                    uVar5 = puVar1[iVar18 * 7 + 5];
                  }
                  else {
                    uVar5 = puVar1[iVar18 * 7 + 4];
                  }
                  puStack_30[5] = uVar5;
                  if (puStack_30[1] == 3) {
                    iVar18 = puVar1[iVar18 * 7 + 4] + -1;
                  }
                  else {
                    iVar18 = puVar1[iVar18 * 7 + puStack_30[1] + 4];
                  }
                }
                else {
                  puStack_30[6] = puVar1[iVar18 * 7 + 5];
                  puStack_30[5] = puVar1[iVar18 * 7 + 4];
                  iVar18 = puStack_30[1] - 3;
                }
                *(int *)((char *)((int)puStack_34 + 0x10) + (int)puVar1) = iVar18;
                puStack_50 = puStack_2c;
                puVar12 = (uint *)((puStack_10 != (uint *)0x1) + 3);
                puStack_38 = (uint *)(uint)(puStack_30[2] != 1);
                puVar13 = puStack_30;
                puVar19 = puStack_3c;
                puStack_18 = puVar12;
                do {
                  if (puStack_38 == (uint *)0x3) {
                    iVar18 = puVar13[4] - 1;
                  }
                  else {
                    iVar18 = puVar1[(int)((int)puStack_38 + (int)param_3 * 7 + 4)];
                    puVar12 = puStack_18;
                  }
                  if ((0 < iVar18) &&
                     (puVar12 = puStack_18, iVar18 < (int)puStack_48 - (int)puStack_70)) {
                    iVar18 = (int)puStack_48 - iVar18;
                    uVar20 = FUN_00aaf270(puStack_48,puStack_2c);
                    iVar8 = (int)((ulonglong)uVar20 >> 0x20);
                    if (iStack_64 == 3) {
                      iVar8 = iVar8 << 8;
                    }
                    puVar12 = puStack_18;
                    puVar13 = puStack_30;
                    if ((int)uVar20 == iVar8) {
                      puVar12 = (uint *)(iVar18 + (int)puStack_2c);
                      puStack_10 = (uint *)((int)puStack_2c + (int)puStack_48);
                      puVar13 = puStack_10;
                      if (puStack_10 < (uint *)((int)puStack_5c + -3)) {
LAB_00ab6664:
                        uVar5 = *puVar13 ^ *puVar12;
                        if (uVar5 == 0) goto code_r0x00ab666e;
                        uVar6 = 0;
                        if (uVar5 != 0) {
                          for (; (uVar5 >> uVar6 & 1) == 0; uVar6 = uVar6 + 1) {
                          }
                        }
                        pcVar7 = (char *)(((uVar6 >> 3) - (int)puStack_10) + (int)puVar13);
                        goto LAB_00ab66a0;
                      }
LAB_00ab6678:
                      if ((puVar13 < (uint *)((int)puStack_5c + -1)) &&
                         (*(short *)puVar12 == *(short *)puVar13)) {
                        puVar13 = (uint *)((int)puVar13 + 2);
                        puVar12 = (uint *)((int)puVar12 + 2);
                      }
                      if ((puVar13 < puStack_5c) && (*(char *)puVar12 == *(char *)puVar13)) {
                        puVar13 = (uint *)((int)puVar13 + 1);
                      }
                      pcVar7 = (char *)((int)puVar13 - (int)puStack_10);
LAB_00ab66a0:
                      puVar12 = (uint *)((int)puStack_2c + (int)pcVar7);
                      puStack_14 = puVar12;
                      if (puStack_68 < puVar12) goto LAB_00ab6d7e;
                      puStack_10 = (uint *)((int)param_3 + (int)puVar12);
                      if ((uint *)0xfff < puStack_10) goto LAB_00ab6d7e;
                      puVar13 = puVar12;
                      if (puVar12 <= puStack_50) {
                        puVar13 = puStack_50;
                      }
                      pcStack_40 = (char *)((int)puVar12 + -3);
                      pcStack_c = (char *)((int)puStack_38 + (uint)(puStack_30[2] == 1));
                      puStack_4c = puVar1 + (int)puStack_10 * 7 + 1;
                      puStack_50 = puVar13;
                      do {
                        uStack_8 = 0;
                        if (puStack_30[2] == 1) {
                          puStack_28 = (uint *)puStack_30[3];
                          if (puStack_28 < param_3) {
                            pcStack_44 = (char *)-(int)puStack_28;
                            puStack_34 = (uint *)(pcStack_44 + (int)puStack_48);
                            uVar5 = 0x1f;
                            if (pcStack_c != (char *)0x0) {
                              for (; (uint)pcStack_c >> uVar5 == 0; uVar5 = uVar5 - 1) {
                              }
                            }
                            puStack_58 = (uint *)(uVar5 & 0xff);
                            if (*(int *)(iVar16 + 0x44) == 0) {
                              uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + (int)puStack_58 * 4) + 1;
                              iVar18 = 0x1f;
                              if (uVar5 != 0) {
                                for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                                }
                              }
                              puVar12 = (uint *)((*(int *)(iVar16 + 0x3c) - iVar18) +
                                                (int)puStack_58);
                              if (pcStack_40 < (char *)0x80) {
                                bVar4 = pcStack_40[0x1947948];
                              }
                              else {
                                iVar18 = 0x1f;
                                if (pcStack_40 != (char *)0x0) {
                                  for (; (uint)pcStack_40 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                                  }
                                }
                                bVar4 = (char)iVar18 + 0x24;
                              }
                              uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                              uStack_8 = 0;
                              iVar18 = 0x1f;
                              if (uVar5 != 0) {
                                for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                                }
                              }
                              iVar8 = *(int *)(&DAT_01947788 + (uint)bVar4 * 4);
                              iVar2 = *(int *)(iVar16 + 0x2c);
                              puStack_58 = puVar12;
                              iVar11 = FUN_00aae0d0(iVar16,puStack_28,puStack_34);
                              pcVar7 = (char *)((int)puVar12 +
                                               iVar11 + *(int *)(iVar16 + 0x40) +
                                               ((iVar8 + iVar2) - iVar18));
                            }
                            else {
                              iVar18 = 0x1f;
                              if (pcStack_40 + 1 != (char *)0x0) {
                                for (; (uint)(pcStack_40 + 1) >> iVar18 == 0; iVar18 = iVar18 + -1)
                                {
                                }
                              }
                              iVar8 = FUN_00aae0d0(iVar16,puStack_28,puStack_34);
                              pcVar7 = (char *)((int)puStack_58 + iVar8 + iVar18 + 0x10);
                            }
                            pcVar14 = (char *)puVar1[(int)((int)param_3 + (int)pcStack_44) * 7];
                            goto LAB_00ab6958;
                          }
                          uVar5 = 0x1f;
                          if (pcStack_c != (char *)0x0) {
                            for (; (uint)pcStack_c >> uVar5 == 0; uVar5 = uVar5 - 1) {
                            }
                          }
                          uStack_8 = 0;
                          pcStack_44 = (char *)(uVar5 & 0xff);
                          if (*(int *)(iVar16 + 0x44) != 0) {
                            iVar18 = 0x1f;
                            if (pcStack_40 + 1 != (char *)0x0) {
                              for (; (uint)(pcStack_40 + 1) >> iVar18 == 0; iVar18 = iVar18 + -1) {
                              }
                            }
                            iVar8 = FUN_00aae0d0(iVar16,puStack_28,puStack_24);
                            pcVar7 = (char *)(iVar8 + iVar18);
                            pcVar14 = pcStack_44 + 0x10;
                            goto LAB_00ab6958;
                          }
                          uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + (int)pcStack_44 * 4) + 1;
                          iVar18 = 0x1f;
                          if (uVar5 != 0) {
                            for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                            }
                          }
                          pcVar14 = pcStack_44 + (*(int *)(iVar16 + 0x3c) - iVar18);
                          if (pcStack_40 < (char *)0x80) {
                            bVar4 = pcStack_40[0x1947948];
                          }
                          else {
                            iVar18 = 0x1f;
                            if (pcStack_40 != (char *)0x0) {
                              for (; (uint)pcStack_40 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                              }
                            }
                            bVar4 = (char)iVar18 + 0x24;
                          }
                          uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                          uStack_8 = 0;
                          iVar18 = 0x1f;
                          if (uVar5 != 0) {
                            for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                            }
                          }
                          iVar8 = *(int *)(&DAT_01947788 + (uint)bVar4 * 4);
                          iVar2 = *(int *)(iVar16 + 0x2c);
                          pcStack_44 = pcVar14;
                          iVar11 = FUN_00aae0d0(iVar16,puStack_28,puStack_24);
                          pcVar14 = pcVar14 + iVar11 + *(int *)(iVar16 + 0x40) +
                                              ((iVar8 + iVar2) - iVar18);
                        }
                        else {
                          pcStack_44 = (char *)0x1f;
                          if (pcStack_c != (char *)0x0) {
                            for (; (uint)pcStack_c >> (int)pcStack_44 == 0;
                                pcStack_44 = pcStack_44 + -1) {
                            }
                          }
                          puStack_28 = (uint *)0x0;
                          if (*(int *)(iVar16 + 0x44) == 0) {
                            uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + ((uint)pcStack_44 & 0xff) * 4)
                                    + 1;
                            iVar18 = 0x1f;
                            if (uVar5 != 0) {
                              for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                              }
                            }
                            pcStack_44 = (char *)((*(int *)(iVar16 + 0x3c) - iVar18) +
                                                 ((uint)pcStack_44 & 0xff));
                            if (pcStack_40 < (char *)0x80) {
                              bVar4 = pcStack_40[0x1947948];
                            }
                            else {
                              iVar18 = 0x1f;
                              if (pcStack_40 != (char *)0x0) {
                                for (; (uint)pcStack_40 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                                }
                              }
                              bVar4 = (char)iVar18 + 0x24;
                            }
                            uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                            iVar18 = 0x1f;
                            if (uVar5 != 0) {
                              for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                              }
                            }
                            uVar5 = **(int **)(iVar16 + 4) + 1;
                            iVar8 = 0x1f;
                            if (uVar5 != 0) {
                              for (; uVar5 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                              }
                            }
                            pcVar7 = pcStack_44 +
                                     *(int *)(iVar16 + 0x40) + (*(int *)(iVar16 + 0x34) - iVar8) +
                                     ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) +
                                      *(int *)(iVar16 + 0x2c)) - iVar18);
                          }
                          else {
                            for (iVar18 = 0x1f; 1U >> iVar18 == 0; iVar18 = iVar18 + -1) {
                            }
                            iVar8 = 0x1f;
                            if (pcStack_40 + 1 != (char *)0x0) {
                              for (; (uint)(pcStack_40 + 1) >> iVar8 == 0; iVar8 = iVar8 + -1) {
                              }
                            }
                            pcVar7 = (char *)(((uint)pcStack_44 & 0xff) + 0x10 + iVar18 + iVar8);
                          }
                          uStack_8 = 0;
                          pcVar14 = (char *)*puStack_30;
LAB_00ab6958:
                          pcVar14 = pcVar14 + (int)pcVar7;
                        }
                        if (puVar19 < puStack_10) {
LAB_00ab696d:
                          puVar10 = puVar1 + (int)((int)puVar19 + 1) * 7;
                          do {
                            puVar19 = (uint *)((int)puVar19 + 1);
                            *puVar10 = 0x40000000;
                            puVar10 = puVar10 + 7;
                            puStack_3c = puVar19;
                          } while (puVar19 < puStack_10);
LAB_00ab6994:
                          puStack_4c[1] = (uint)puStack_14;
                          *puStack_4c = (uint)puStack_38;
                          puStack_4c[2] = (uint)puStack_28;
                          puStack_4c[-1] = (uint)pcVar14;
                        }
                        else if (pcVar14 <= (char *)puStack_4c[-1]) {
                          if (puVar19 < puStack_10) goto LAB_00ab696d;
                          goto LAB_00ab6994;
                        }
                        puStack_4c = puStack_4c + -7;
                        puStack_14 = (uint *)((int)puStack_14 + -1);
                        puStack_10 = (uint *)((int)puStack_10 + -1);
                        pcStack_40 = pcStack_40 + -1;
                        puVar12 = puStack_18;
                        puVar13 = puStack_30;
                      } while (puStack_2c <= puStack_14);
                    }
                  }
                  puVar15 = puStack_50;
                  puStack_38 = (uint *)((int)puStack_38 + 1);
                } while (puStack_38 < puVar12);
                puStack_58 = (uint *)FUN_00aa8870(param_1,puStack_48,puStack_5c,iVar17,iStack_64,
                                                  iStack_20,puStack_50);
                if ((puStack_58 != (uint *)0x0) &&
                   ((puVar12 = *(uint **)(iStack_20 + -4 + (int)puStack_58 * 8),
                    puStack_68 < puVar12 ||
                    (puVar15 = puStack_50, &DAT_00001000 <= (char *)((int)puVar12 + (int)param_3))))
                   ) {
                  puStack_38 = *(uint **)(iStack_20 + -8 + (int)puStack_58 * 8);
LAB_00ab6d7e:
                  puVar19 = (uint *)((int)param_3 + 1);
                  puStack_3c = puVar19;
                  goto LAB_00ab6da7;
                }
                puStack_48 = (uint *)0x0;
                if (puStack_58 != (uint *)0x0) {
                  do {
                    if (puStack_48 == (uint *)0x0) {
                      puStack_18 = puVar15;
                    }
                    else {
                      puVar15 = (uint *)(*(int *)(iStack_20 + -4 + (int)puStack_48 * 8) + 1);
                      puStack_18 = puVar15;
                    }
                    puStack_10 = (uint *)((int)puStack_48 * 8);
                    puStack_50 = *(uint **)((int)puStack_48 * 8 + iStack_20 + 4);
                    puStack_18 = puVar15;
                    if (puVar15 <= puStack_50) {
                      puStack_28 = (uint *)((int)puVar15 + -3);
                      puStack_4c = (uint *)((int)param_3 + (int)puVar15);
                      pcStack_40 = (char *)(puVar1 + (int)puStack_4c * 7 + 1);
                      do {
                        uStack_8 = 0;
                        if (puStack_30[2] == 1) {
                          puStack_14 = (uint *)puStack_30[3];
                          uVar5 = *(uint *)(iStack_20 + (int)puStack_10);
                          if (puStack_14 < param_3) {
                            pcStack_44 = (char *)((int)param_3 - (int)puStack_14);
                            puStack_34 = (uint *)(pcStack_44 + (int)puStack_1c);
                            uVar6 = 0x1f;
                            if (uVar5 != 0) {
                              for (; uVar5 >> uVar6 == 0; uVar6 = uVar6 - 1) {
                              }
                            }
                            pcStack_c = (char *)(uVar6 & 0xff);
                            if (*(int *)(iVar16 + 0x44) == 0) {
                              uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + (int)pcStack_c * 4) + 1;
                              iVar18 = 0x1f;
                              if (uVar5 != 0) {
                                for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                                }
                              }
                              pcVar7 = pcStack_c + (*(int *)(iVar16 + 0x3c) - iVar18);
                              if (puStack_28 < (uint *)0x80) {
                                bVar4 = *(byte *)(puStack_28 + 0x651e52);
                              }
                              else {
                                iVar18 = 0x1f;
                                if (puStack_28 != (uint *)0x0) {
                                  for (; (uint)puStack_28 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                                  }
                                }
                                bVar4 = (char)iVar18 + 0x24;
                              }
                              uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                              uStack_8 = 0;
                              iVar18 = 0x1f;
                              if (uVar5 != 0) {
                                for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                                }
                              }
                              iVar8 = *(int *)(&DAT_01947788 + (uint)bVar4 * 4);
                              iVar2 = *(int *)(iVar16 + 0x2c);
                              pcStack_c = pcVar7;
                              iVar11 = FUN_00aae0d0(iVar16,puStack_14,puStack_34);
                              pcVar7 = pcVar7 + iVar11 + *(int *)(iVar16 + 0x40) +
                                                ((iVar8 + iVar2) - iVar18);
                            }
                            else {
                              iVar18 = 0x1f;
                              if ((char *)((int)puStack_28 + 1U) != (char *)0x0) {
                                for (; (int)puStack_28 + 1U >> iVar18 == 0; iVar18 = iVar18 + -1) {
                                }
                              }
                              iVar8 = FUN_00aae0d0(iVar16,puStack_14,puStack_34);
                              pcVar7 = pcStack_c + iVar8 + iVar18 + 0x10;
                            }
                            pcVar14 = (char *)puVar1[(int)pcStack_44 * 7];
                            goto LAB_00ab6cd5;
                          }
                          uVar6 = 0x1f;
                          if (uVar5 != 0) {
                            for (; uVar5 >> uVar6 == 0; uVar6 = uVar6 - 1) {
                            }
                          }
                          pcStack_c = (char *)(uVar6 & 0xff);
                          if (*(int *)(iVar16 + 0x44) != 0) {
                            iVar18 = 0x1f;
                            if ((char *)((int)puStack_28 + 1U) != (char *)0x0) {
                              for (; (int)puStack_28 + 1U >> iVar18 == 0; iVar18 = iVar18 + -1) {
                              }
                            }
                            iVar8 = FUN_00aae0d0(iVar16,puStack_14,puStack_24);
                            pcVar7 = (char *)(iVar8 + iVar18);
                            pcVar14 = pcStack_c + 0x10;
                            goto LAB_00ab6cd5;
                          }
                          uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + (int)pcStack_c * 4) + 1;
                          iVar18 = 0x1f;
                          if (uVar5 != 0) {
                            for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                            }
                          }
                          pcVar14 = pcStack_c + (*(int *)(iVar16 + 0x3c) - iVar18);
                          if (puStack_28 < (uint *)0x80) {
                            bVar4 = *(byte *)(puStack_28 + 0x651e52);
                          }
                          else {
                            iVar18 = 0x1f;
                            if (puStack_28 != (uint *)0x0) {
                              for (; (uint)puStack_28 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                              }
                            }
                            bVar4 = (char)iVar18 + 0x24;
                          }
                          uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                          uStack_8 = 0;
                          iVar18 = 0x1f;
                          if (uVar5 != 0) {
                            for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                            }
                          }
                          iVar8 = *(int *)(&DAT_01947788 + (uint)bVar4 * 4);
                          iVar2 = *(int *)(iVar16 + 0x2c);
                          pcStack_c = pcVar14;
                          iVar11 = FUN_00aae0d0(iVar16,puStack_14,puStack_24);
                          pcVar14 = pcVar14 + iVar11 + *(int *)(iVar16 + 0x40) +
                                              ((iVar8 + iVar2) - iVar18);
                        }
                        else {
                          puStack_14 = (uint *)0x0;
                          pcStack_c = (char *)0x1f;
                          if (*(uint *)(iStack_20 + (int)puStack_10) != 0) {
                            for (; *(uint *)(iStack_20 + (int)puStack_10) >> (int)pcStack_c == 0;
                                pcStack_c = pcStack_c + -1) {
                            }
                          }
                          if (*(int *)(iVar16 + 0x44) == 0) {
                            uVar5 = *(int *)(*(int *)(iVar16 + 0xc) + ((uint)pcStack_c & 0xff) * 4)
                                    + 1;
                            iVar18 = 0x1f;
                            if (uVar5 != 0) {
                              for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                              }
                            }
                            pcStack_c = (char *)((*(int *)(iVar16 + 0x3c) - iVar18) +
                                                ((uint)pcStack_c & 0xff));
                            if (puStack_28 < (uint *)0x80) {
                              bVar4 = *(byte *)(puStack_28 + 0x651e52);
                            }
                            else {
                              iVar18 = 0x1f;
                              if (puStack_28 != (uint *)0x0) {
                                for (; (uint)puStack_28 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                                }
                              }
                              bVar4 = (char)iVar18 + 0x24;
                            }
                            uVar5 = *(int *)(*(int *)(iVar16 + 8) + (uint)bVar4 * 4) + 1;
                            iVar18 = 0x1f;
                            if (uVar5 != 0) {
                              for (; uVar5 >> iVar18 == 0; iVar18 = iVar18 + -1) {
                              }
                            }
                            uVar5 = **(int **)(iVar16 + 4) + 1;
                            iVar8 = 0x1f;
                            if (uVar5 != 0) {
                              for (; uVar5 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                              }
                            }
                            pcVar7 = pcStack_c +
                                     *(int *)(iVar16 + 0x40) + (*(int *)(iVar16 + 0x34) - iVar8) +
                                     ((*(int *)(&DAT_01947788 + (uint)bVar4 * 4) +
                                      *(int *)(iVar16 + 0x2c)) - iVar18);
                          }
                          else {
                            for (iVar18 = 0x1f; 1U >> iVar18 == 0; iVar18 = iVar18 + -1) {
                            }
                            iVar8 = 0x1f;
                            if ((char *)((int)puStack_28 + 1U) != (char *)0x0) {
                              for (; (int)puStack_28 + 1U >> iVar8 == 0; iVar8 = iVar8 + -1) {
                              }
                            }
                            pcVar7 = (char *)(((uint)pcStack_c & 0xff) + 0x10 + iVar18 + iVar8);
                          }
                          uStack_8 = 0;
                          pcVar14 = (char *)*puStack_30;
LAB_00ab6cd5:
                          pcVar14 = pcVar14 + (int)pcVar7;
                        }
                        if (puVar19 < puStack_4c) {
LAB_00ab6cea:
                          puVar10 = puVar1 + (int)((int)puVar19 + 1) * 7;
                          do {
                            puVar19 = (uint *)((int)puVar19 + 1);
                            *puVar10 = 0x40000000;
                            puVar10 = puVar10 + 7;
                          } while (puVar19 < puStack_4c);
                          puStack_3c = puVar19;
LAB_00ab6d14:
                          *(uint **)(pcStack_40 + 4) = puStack_18;
                          *(undefined4 *)pcStack_40 = *(undefined4 *)(iStack_20 + (int)puStack_10);
                          *(uint **)(pcStack_40 + 8) = puStack_14;
                          *(char **)(pcStack_40 + -4) = pcVar14;
                        }
                        else if (pcVar14 < *(char **)(pcStack_40 + -4)) {
                          if (puVar19 < puStack_4c) goto LAB_00ab6cea;
                          goto LAB_00ab6d14;
                        }
                        puStack_18 = (uint *)((int)puStack_18 + 1);
                        puStack_4c = (uint *)((int)puStack_4c + 1);
                        puStack_28 = (uint *)((int)puStack_28 + 1);
                        pcStack_40 = pcStack_40 + 0x1c;
                      } while (puStack_18 <= puStack_50);
                    }
                    puStack_48 = (uint *)((int)puStack_48 + 1);
                    puVar15 = puStack_50;
                  } while (puStack_48 < puStack_58);
                }
              }
              param_3 = (uint *)((int)param_3 + 1);
            } while (param_3 <= puVar19);
          }
          puVar12 = (uint *)puVar1[(int)puVar19 * 7 + 2];
          param_3 = (uint *)((int)puVar19 - (int)puVar12);
          puStack_38 = (uint *)puVar1[(int)puVar19 * 7 + 1];
LAB_00ab6da1:
LAB_00ab6da7:
          puVar1[2] = 1;
          puVar13 = (uint *)puVar1[(int)param_3 * 7 + 2];
          pcVar7 = (char *)puVar1[(int)param_3 * 7 + 1];
          pcStack_c = pcVar7;
          puVar1[(int)param_3 * 7 + 2] = puVar12;
          puVar1[(int)param_3 * 7 + 1] = puStack_38;
          if (puVar13 <= param_3) {
            do {
              param_3 = (uint *)((int)param_3 - (int)puVar13);
              puVar12 = (uint *)puVar1[(int)param_3 * 7 + 2];
              pcVar14 = (char *)puVar1[(int)param_3 * 7 + 1];
              puVar1[(int)param_3 * 7 + 2] = puVar13;
              puVar1[(int)param_3 * 7 + 1] = pcVar7;
              puVar13 = puVar12;
              iVar16 = iStack_74;
              pcVar7 = pcVar14;
              puVar19 = puStack_3c;
            } while (puVar12 <= param_3);
          }
          puVar12 = (uint *)0x0;
          do {
            puVar12 = (uint *)((int)puVar12 + puVar1[(int)puVar12 * 7 + 2]);
          } while (puVar12 <= puVar19);
          puStack_34 = (uint *)0x0;
          if (puVar19 != (uint *)0x0) {
            do {
              puVar12 = puStack_24;
              puStack_58 = (uint *)puVar1[(int)puStack_34 * 7 + 2];
              if (puStack_58 == (uint *)0x1) {
                puStack_1c = (uint *)((int)puStack_1c + 1);
              }
              else {
                uVar6 = (int)puStack_1c - (int)puStack_24;
                uVar5 = puVar1[(int)puStack_34 * 7 + 1];
                if (uVar5 < 4) {
                  if (uVar5 != 0) {
                    if (uVar5 == 3) {
                      aiStack_84[0] = iStack_54 + -1;
LAB_00ab6ea9:
                      iStack_6c = iStack_60;
                      aiStack_84[2] = iStack_60;
                      iVar16 = iStack_74;
                    }
                    else {
                      aiStack_84[0] = aiStack_84[uVar5];
                      if (uVar5 != 1) goto LAB_00ab6ea9;
                    }
                    iStack_60 = iStack_54;
                    aiStack_84[1] = iStack_54;
                    iStack_54 = aiStack_84[0];
                  }
                  if (uVar6 == 0) goto LAB_00ab6ec8;
                }
                else {
                  iStack_6c = iStack_60;
                  aiStack_84[2] = iStack_60;
                  iStack_60 = iStack_54;
                  aiStack_84[1] = iStack_54;
                  aiStack_84[0] = uVar5 - 3;
                  iStack_54 = aiStack_84[0];
LAB_00ab6ec8:
                  uVar5 = uVar5 - 1;
                }
                pcStack_44 = (char *)((int)puStack_58 + -3);
                FUN_00aafda0(iVar16,uVar6,puStack_24,uVar5,pcStack_44);
                puVar19 = *(uint **)(param_1 + 0x17c);
                puVar13 = (uint *)(uVar6 + (int)puVar19);
                do {
                  *puVar19 = *puVar12;
                  puVar19[1] = puVar12[1];
                  puVar19 = puVar19 + 2;
                  puVar12 = puVar12 + 2;
                } while (puVar19 < puVar13);
                *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar6;
                if (0xffff < uVar6) {
                  *(undefined4 *)(param_1 + 0x18c) = 1;
                  *(int *)(param_1 + 400) =
                       *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
                  iVar16 = iStack_74;
                }
                *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar6;
                **(int **)(param_1 + 0x174) = uVar5 + 1;
                if ((char *)0xffff < pcStack_44) {
                  *(undefined4 *)(param_1 + 0x18c) = 2;
                  *(int *)(param_1 + 400) =
                       *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
                }
                *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)pcStack_44;
                *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
                puStack_1c = (uint *)((int)puStack_1c + (int)puStack_58);
                puStack_24 = puStack_1c;
                puVar19 = puStack_3c;
              }
              puStack_34 = (uint *)((int)puStack_34 + (int)puStack_58);
            } while (puStack_34 < puVar19);
          }
        }
      }
      param_2 = puStack_24;
    } while (puStack_1c < puStack_78);
  }
  *(int *)(param_1 + 0x1a0) = iStack_54;
  *(int *)(param_1 + 0x1a4) = iStack_60;
  *(int *)(param_1 + 0x1a8) = iStack_6c;
  return (int)puStack_5c - (int)param_2;
code_r0x00ab603a:
  puVar12 = puVar12 + 1;
  puVar13 = puVar13 + 1;
  if ((uint *)((int)puStack_5c + -3) <= puVar12) goto LAB_00ab6044;
  goto LAB_00ab6030;
code_r0x00ab666e:
  puVar13 = puVar13 + 1;
  puVar12 = puVar12 + 1;
  if ((uint *)((int)puStack_5c + -3) <= puVar13) goto LAB_00ab6678;
  goto LAB_00ab6664;
}



/* FUNCTION 22072 ; VA 0x00ab6ff0 ; FUN_00ab6ff0 */

int FUN_00ab6ff0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  byte bVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  int iVar12;
  uint uVar13;
  int iVar14;
  undefined4 *puVar15;
  uint uVar16;
  undefined4 uVar17;
  undefined8 uVar18;
  int aiStack_90 [3];
  undefined4 *puStack_84;
  undefined4 *puStack_80;
  int iStack_7c;
  int iStack_78;
  undefined4 *puStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  uint uStack_64;
  undefined4 *puStack_60;
  int iStack_5c;
  int iStack_58;
  undefined4 *puStack_54;
  undefined4 *puStack_50;
  uint uStack_4c;
  undefined4 *puStack_48;
  undefined4 *puStack_44;
  undefined4 *puStack_40;
  uint uStack_3c;
  undefined4 *puStack_38;
  undefined4 *puStack_34;
  int iStack_30;
  uint *puStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  undefined4 *puStack_10;
  uint uStack_c;
  undefined4 uStack_8;
  
  iStack_78 = *(int *)(param_1 + 4);
  uStack_4c = (int)param_2 + (int)param_3;
  puStack_28 = param_2;
  puStack_84 = (undefined4 *)(uStack_4c - 8);
  uVar1 = *(uint *)(param_1 + 0x10);
  uStack_64 = *(uint *)(param_1 + 0xc);
  puStack_80 = (undefined4 *)(iStack_78 + uStack_64);
  iVar2 = *(int *)(param_1 + 8);
  uVar9 = uStack_64 + iVar2;
  iVar12 = 1 << ((byte)*(undefined4 *)(param_1 + 0x9c) & 0x1f);
  puStack_74 = *(undefined4 **)(param_1 + 0xa4);
  iVar14 = param_1 + 0x1ac;
  iStack_70 = *(int *)(param_1 + 0xa0);
  puVar3 = *(undefined4 **)(param_1 + 0x1c0);
  puStack_24 = (undefined4 *)((iStack_70 != 3) + 3);
  iStack_30 = *(int *)(param_1 + 0x1bc);
  aiStack_90[0] = *(int *)(param_1 + 0x194);
  aiStack_90[1] = *(int *)(param_1 + 0x198);
  aiStack_90[2] = *(int *)(param_1 + 0x19c);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  iStack_6c = aiStack_90[2];
  iStack_68 = aiStack_90[1];
  iStack_5c = iVar14;
  iStack_58 = aiStack_90[0];
  FUN_00aaf290(iVar14,param_2,param_3);
  puStack_10 = (undefined4 *)((uint)(param_2 == puStack_80) + (int)param_2);
  if (puStack_10 < puStack_84) {
    do {
      *puVar3 = 0;
      puVar3[1] = 0;
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar10 = (undefined4 *)0x0;
      iStack_7c = (int)puStack_10 - iStack_78;
      *(undefined8 *)(puVar3 + 4) = 0;
      puVar3[6] = 0;
      puVar3[3] = (int)puStack_10 - (int)param_2;
      puStack_40 = (undefined4 *)0x0;
      puStack_34 = (undefined4 *)(uint)(puStack_10 == param_2);
      puStack_18 = puStack_34;
      puStack_44 = (undefined4 *)((int)puStack_34 + 3);
      do {
        if (puStack_34 == (undefined4 *)0x3) {
          iVar6 = iStack_58 + -1;
        }
        else {
          iVar6 = aiStack_90[(int)puStack_34];
        }
        uVar13 = iStack_7c - iVar6;
        iVar8 = iStack_78;
        if (uVar13 < uStack_64) {
          iVar8 = iVar2;
        }
        if (((0 < iVar6) && (iVar6 <= iStack_7c)) &&
           (uVar1 < uVar13 && 2 < (uStack_64 - uVar13) - 1)) {
          uVar18 = FUN_00aaf270(puStack_10,puStack_24);
          iVar6 = (int)((ulonglong)uVar18 >> 0x20);
          if (iStack_70 == 3) {
            iVar6 = iVar6 << 8;
          }
          if ((int)uVar18 == iVar6) {
            uVar16 = uStack_4c;
            if (uVar13 < uStack_64) {
              uVar16 = uVar9;
            }
            iVar14 = iVar8 + uVar13 + (int)puStack_24;
            uVar7 = (((int)puStack_10 + (int)puStack_24) - iVar14) + uVar16;
            uVar13 = uStack_4c;
            if (uVar7 < uStack_4c) {
              uVar13 = uVar7;
            }
            iVar6 = FUN_00abcfb0((int)puStack_10 + (int)puStack_24,iVar14,uVar13);
            if (iVar6 + iVar14 == uVar16) {
              iVar14 = FUN_00abcfb0((int)puStack_24 + (int)puStack_10 + iVar6,puStack_80,uStack_4c);
              iVar6 = iVar6 + iVar14;
            }
            iVar14 = iStack_5c;
            puVar15 = (undefined4 *)((int)puStack_24 + iVar6);
            puStack_54 = puVar15;
            if ((puStack_74 < puVar15) || ((undefined4 *)0xfff < puVar15)) {
              puVar10 = (undefined4 *)0x1;
              param_3 = (undefined4 *)0x0;
              puStack_40 = (undefined4 *)0x1;
              goto LAB_00ab7f27;
            }
            puStack_14 = (undefined4 *)((int)puVar15 + -3);
            uVar17 = puVar3[3];
            puStack_48 = (undefined4 *)((int)puStack_34 + (1 - (int)puStack_18));
            puStack_38 = puVar3 + (int)puVar15 * 7 + 1;
            do {
              uVar13 = 0x1f;
              if (puStack_48 != (undefined4 *)0x0) {
                for (; (uint)puStack_48 >> uVar13 == 0; uVar13 = uVar13 - 1) {
                }
              }
              puStack_20 = (undefined4 *)(uVar13 & 0xff);
              uStack_c = 0;
              if (*(int *)(iVar14 + 0x44) == 0) {
                uVar13 = *(int *)(*(int *)(iVar14 + 0xc) + (int)puStack_20 * 4) + 1;
                iVar6 = 0x1f;
                if (uVar13 != 0) {
                  for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                  }
                }
                if (puStack_14 < (undefined4 *)0x80) {
                  bVar5 = *(byte *)(puStack_14 + 0x651e52);
                }
                else {
                  iVar8 = 0x1f;
                  if (puStack_14 != (undefined4 *)0x0) {
                    for (; (uint)puStack_14 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                    }
                  }
                  bVar5 = (char)iVar8 + 0x24;
                }
                uStack_c = 0;
                uVar13 = *(int *)(*(int *)(iVar14 + 8) + (uint)bVar5 * 4) + 1;
                iVar8 = 0x1f;
                if (uVar13 != 0) {
                  for (; uVar13 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                  }
                }
                iVar6 = (*(int *)(iVar14 + 0x3c) - iVar6) + (int)puStack_20 +
                        ((*(int *)(&DAT_01947788 + (uint)bVar5 * 4) + *(int *)(iVar14 + 0x2c)) -
                        iVar8);
                iVar8 = FUN_00aae0d0(iVar14,uVar17,puStack_28);
                iVar8 = iVar8 + *(int *)(iVar14 + 0x40);
              }
              else {
                iVar6 = 0x1f;
                if ((int)puStack_14 + 1U != 0) {
                  for (; (int)puStack_14 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                  }
                }
                iVar8 = FUN_00aae0d0(iVar14,uVar17,puStack_28);
                iVar8 = iVar8 + 0x10 + (int)puStack_20;
              }
              puStack_20 = (undefined4 *)(iVar8 + iVar6);
              if (puVar10 < puStack_54) {
LAB_00ab72ed:
                puVar15 = puVar3 + ((int)puVar10 + 1) * 7;
                iVar6 = (int)puStack_54 - (int)puVar10;
                do {
                  *puVar15 = 0x40000000;
                  puVar15 = puVar15 + 7;
                  iVar6 = iVar6 + -1;
                  puVar10 = puStack_54;
                } while (iVar6 != 0);
LAB_00ab7321:
                *puStack_38 = puStack_34;
                puStack_38[1] = puStack_54;
                puStack_38[2] = uVar17;
                puStack_38[-1] = puStack_20;
              }
              else if (puStack_20 < (undefined4 *)puStack_38[-1]) {
                if (puVar10 < puStack_54) goto LAB_00ab72ed;
                goto LAB_00ab7321;
              }
              puStack_14 = (undefined4 *)((int)puStack_14 + -1);
              puStack_54 = (undefined4 *)((int)puStack_54 + -1);
              puStack_38 = puStack_38 + -7;
            } while (puStack_24 <= puStack_54);
            puStack_40 = puVar10;
          }
        }
        puStack_34 = (undefined4 *)((int)puStack_34 + 1);
      } while (puStack_34 < puStack_44);
      puStack_50 = (undefined4 *)
                   FUN_00aa8910(param_1,puStack_10,uStack_4c,iVar12,iStack_70,iStack_30,puStack_24);
      if ((puVar10 == (undefined4 *)0x0) && (puStack_50 == (undefined4 *)0x0)) {
        puStack_10 = (undefined4 *)((int)puStack_10 + 1);
      }
      else {
        puVar3[4] = iStack_58;
        puVar3[5] = iStack_68;
        puVar3[6] = iStack_6c;
        puVar3[2] = 1;
        if ((puStack_50 == (undefined4 *)0x0) ||
           ((puVar15 = *(undefined4 **)(iStack_30 + -4 + (int)puStack_50 * 8), puVar15 <= puStack_74
            && (puVar15 < &DAT_00001000)))) {
          puVar15 = puStack_24;
          if (puVar10 != (undefined4 *)0x0) {
            puVar15 = puVar10;
          }
          puStack_44 = (undefined4 *)0x0;
          if (puStack_50 != (undefined4 *)0x0) {
            do {
              if (puStack_44 != (undefined4 *)0x0) {
                puVar15 = (undefined4 *)(*(int *)(iStack_30 + -4 + (int)puStack_44 * 8) + 1);
              }
              puStack_20 = (undefined4 *)((int)puStack_44 * 8);
              puStack_14 = puVar15;
              puStack_54 = *(undefined4 **)((int)puStack_44 * 8 + iStack_30 + 4);
              puStack_38 = (undefined4 *)puVar3[3];
              if (puVar15 <= puStack_54) {
                param_3 = (undefined4 *)((int)puVar15 - 3);
                puStack_1c = puVar3 + (int)puVar15 * 7 + 1;
                do {
                  uStack_c = 0;
                  uVar13 = 0x1f;
                  if (*(uint *)((int)puStack_20 + iStack_30) != 0) {
                    for (; *(uint *)((int)puStack_20 + iStack_30) >> uVar13 == 0;
                        uVar13 = uVar13 - 1) {
                    }
                  }
                  puStack_18 = (undefined4 *)(uVar13 & 0xff);
                  if (*(int *)(iVar14 + 0x44) == 0) {
                    uVar13 = *(int *)(*(int *)(iVar14 + 0xc) + (int)puStack_18 * 4) + 1;
                    iVar6 = 0x1f;
                    if (uVar13 != 0) {
                      for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                      }
                    }
                    if (param_3 < 0x80) {
                      bVar5 = (&DAT_01947948)[(int)param_3];
                    }
                    else {
                      iVar8 = 0x1f;
                      if (param_3 != (undefined4 *)0x0) {
                        for (; (uint)param_3 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                        }
                      }
                      bVar5 = (char)iVar8 + 0x24;
                    }
                    uStack_c = 0;
                    uVar13 = *(int *)(*(int *)(iVar14 + 8) + (uint)bVar5 * 4) + 1;
                    iVar8 = 0x1f;
                    if (uVar13 != 0) {
                      for (; uVar13 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                      }
                    }
                    iVar6 = (*(int *)(iVar14 + 0x3c) - iVar6) + (int)puStack_18 +
                            ((*(int *)(&DAT_01947788 + (uint)bVar5 * 4) + *(int *)(iVar14 + 0x2c)) -
                            iVar8);
                    iVar8 = FUN_00aae0d0(iVar14,puStack_38,puStack_28);
                    iVar8 = iVar8 + *(int *)(iVar14 + 0x40);
                  }
                  else {
                    iVar6 = 0x1f;
                    if ((int)param_3 + 1U != 0) {
                      for (; (int)param_3 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                      }
                    }
                    iVar8 = FUN_00aae0d0(iVar14,puStack_38,puStack_28);
                    iVar8 = iVar8 + 0x10 + (int)puStack_18;
                  }
                  puStack_48 = (undefined4 *)(iVar8 + iVar6);
                  if (puVar10 < puStack_14) {
LAB_00ab7517:
                    puVar15 = puVar3 + ((int)puVar10 + 1) * 7;
                    iVar6 = (int)puStack_14 - (int)puVar10;
                    do {
                      *puVar15 = 0x40000000;
                      puVar15 = puVar15 + 7;
                      iVar6 = iVar6 + -1;
                      puVar10 = puStack_14;
                    } while (iVar6 != 0);
LAB_00ab753e:
                    puStack_1c[1] = puStack_14;
                    *puStack_1c = *(undefined4 *)((int)puStack_20 + iStack_30);
                    puStack_1c[2] = puStack_38;
                    puStack_1c[-1] = puStack_48;
                  }
                  else if (puStack_48 < (undefined4 *)puStack_1c[-1]) {
                    if (puVar10 < puStack_14) goto LAB_00ab7517;
                    goto LAB_00ab753e;
                  }
                  param_3 = (undefined4 *)((int)param_3 + 1);
                  puStack_14 = (undefined4 *)((int)puStack_14 + 1);
                  puStack_1c = puStack_1c + 7;
                } while (puStack_14 <= puStack_54);
                puStack_40 = puVar10;
              }
              puStack_44 = (undefined4 *)((int)puStack_44 + 1);
              puVar15 = puStack_54;
            } while (puStack_44 < puStack_50);
          }
          if (puVar10 < puStack_24) {
            puStack_10 = (undefined4 *)((int)puStack_10 + 1);
            goto LAB_00ab8137;
          }
          param_3 = (undefined4 *)0x1;
          if (puVar10 != (undefined4 *)0x0) {
            do {
              puStack_1c = (undefined4 *)((int)puStack_10 + (int)param_3);
              puStack_18 = (undefined4 *)((int)param_3 * 0x1c);
              puStack_2c = puVar3 + (int)param_3 * 7;
              if (puVar3[(int)param_3 * 7 + -5] == 1) {
                puVar15 = (undefined4 *)(puStack_2c[-4] + 1);
                if (puVar15 < param_3) {
                  iVar6 = FUN_00aae0d0(iVar14,puVar15,(int)puStack_1c - (int)puVar15);
                  uVar13 = iVar6 + puVar3[((int)param_3 - (int)puVar15) * 7];
                }
                else {
                  uVar13 = FUN_00aae0d0(iVar14,puVar15,puStack_28);
                }
              }
              else {
                puVar15 = (undefined4 *)0x1;
                iVar6 = FUN_00aae0d0(iVar14,1,(int)puStack_1c + -1);
                uVar13 = iVar6 + puStack_2c[-7];
              }
              if (puVar10 < param_3) {
LAB_00ab7643:
                puVar11 = puVar3 + ((int)puVar10 + 1) * 7;
                iVar6 = (int)param_3 - (int)puVar10;
                puStack_40 = param_3;
                do {
                  *puVar11 = 0x40000000;
                  puVar11 = puVar11 + 7;
                  iVar6 = iVar6 + -1;
                  puVar10 = param_3;
                } while (iVar6 != 0);
LAB_00ab7671:
                puStack_2c[3] = (uint)puVar15;
                puStack_2c[2] = 1;
                puStack_2c[1] = 0;
                *puStack_2c = uVar13;
              }
              else if (uVar13 <= *puStack_2c) {
                if (puVar10 < param_3) goto LAB_00ab7643;
                goto LAB_00ab7671;
              }
              if (param_3 == puVar10) break;
              if (puStack_1c <= puStack_84) {
                puStack_20 = (undefined4 *)puStack_2c[2];
                iVar6 = (int)param_3 - (int)puStack_20;
                if (puStack_2c[1] < 4) {
                  if (puStack_2c[1] < 2) {
                    uVar13 = puVar3[iVar6 * 7 + 6];
                  }
                  else {
                    uVar13 = puVar3[iVar6 * 7 + 5];
                  }
                  puStack_2c[6] = uVar13;
                  if (puStack_2c[1] == 0) {
                    uVar13 = puVar3[iVar6 * 7 + 5];
                  }
                  else {
                    uVar13 = puVar3[iVar6 * 7 + 4];
                  }
                  puStack_2c[5] = uVar13;
                  if (puStack_2c[1] == 3) {
                    iVar6 = puVar3[iVar6 * 7 + 4] + -1;
                  }
                  else {
                    iVar6 = puVar3[iVar6 * 7 + puStack_2c[1] + 4];
                  }
                }
                else {
                  puStack_2c[6] = puVar3[iVar6 * 7 + 5];
                  puStack_2c[5] = puVar3[iVar6 * 7 + 4];
                  iVar6 = puStack_2c[1] - 3;
                }
                *(int *)((int)puStack_18 + 0x10 + (int)puVar3) = iVar6;
                puStack_34 = (undefined4 *)(uint)(puStack_20 != (undefined4 *)0x1);
                puStack_38 = puStack_24;
                puVar15 = (undefined4 *)((int)puStack_34 + 3);
                puStack_14 = puVar15;
                do {
                  puVar11 = puStack_40;
                  if (puStack_34 == (undefined4 *)0x3) {
                    iVar6 = puStack_2c[4] - 1;
                  }
                  else {
                    iVar6 = puVar3[(int)puStack_34 + (int)param_3 * 7 + 4];
                    puVar15 = puStack_14;
                  }
                  uVar13 = (int)param_3 + (iStack_7c - iVar6);
                  iVar8 = iStack_78;
                  if (uVar13 < uStack_64) {
                    iVar8 = iVar2;
                  }
                  puStack_18 = (undefined4 *)(iVar8 + uVar13);
                  if (((0 < iVar6) &&
                      (puVar15 = puStack_14, puVar10 = puVar11, iVar6 <= (int)param_3 + iStack_7c))
                     && (uVar1 < uVar13 && 2 < (uStack_64 - uVar13) - 1)) {
                    uVar18 = FUN_00aaf270(puStack_1c,puStack_24);
                    iVar6 = (int)((ulonglong)uVar18 >> 0x20);
                    if (iStack_70 == 3) {
                      iVar6 = iVar6 << 8;
                    }
                    puVar15 = puStack_14;
                    if ((int)uVar18 == iVar6) {
                      uVar16 = uStack_4c;
                      if (uVar13 < uStack_64) {
                        uVar16 = uVar9;
                      }
                      iVar14 = (int)puStack_18 + (int)puStack_24;
                      uVar7 = (((int)puStack_1c + (int)puStack_24) - iVar14) + uVar16;
                      uVar13 = uStack_4c;
                      if (uVar7 < uStack_4c) {
                        uVar13 = uVar7;
                      }
                      iVar6 = FUN_00abcfb0((int)puStack_1c + (int)puStack_24,iVar14,uVar13);
                      puStack_18 = (undefined4 *)iVar6;
                      if (iVar6 + iVar14 == uVar16) {
                        iVar6 = FUN_00abcfb0((int)puStack_1c + (int)puStack_24 + iVar6,puStack_80,
                                             uStack_4c);
                        iVar6 = (int)puStack_18 + iVar6;
                      }
                      puVar15 = (undefined4 *)((int)puStack_24 + iVar6);
                      puStack_54 = puVar15;
                      if (puStack_74 < puVar15) goto LAB_00ab7efe;
                      puStack_20 = (undefined4 *)((int)param_3 + (int)puVar15);
                      if ((undefined4 *)0xfff < puStack_20) goto LAB_00ab7efe;
                      puVar10 = puVar15;
                      if (puVar15 <= puStack_38) {
                        puVar10 = puStack_38;
                      }
                      puStack_48 = (undefined4 *)((int)puVar15 + -3);
                      uStack_c = (int)puStack_34 + (uint)(puStack_2c[2] == 1);
                      puStack_44 = puVar3 + (int)puStack_20 * 7 + 1;
                      puStack_38 = puVar10;
                      do {
                        iVar14 = iStack_5c;
                        uStack_8 = 0;
                        if (puStack_2c[2] == 1) {
                          puStack_50 = (undefined4 *)puStack_2c[3];
                          if (puStack_50 < param_3) {
                            uStack_3c = -(int)puStack_50;
                            puStack_18 = (undefined4 *)(uStack_3c + (int)puStack_1c);
                            uVar13 = 0x1f;
                            if (uStack_c != 0) {
                              for (; uStack_c >> uVar13 == 0; uVar13 = uVar13 - 1) {
                              }
                            }
                            puStack_60 = (undefined4 *)(uVar13 & 0xff);
                            if (*(int *)(iStack_5c + 0x44) == 0) {
                              uVar13 = *(int *)(*(int *)(iStack_5c + 0xc) + (int)puStack_60 * 4) + 1
                              ;
                              iVar6 = 0x1f;
                              if (uVar13 != 0) {
                                for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                }
                              }
                              puStack_60 = (undefined4 *)
                                           ((*(int *)(iStack_5c + 0x3c) - iVar6) + (int)puStack_60);
                              if (puStack_48 < (undefined4 *)0x80) {
                                bVar5 = *(byte *)(puStack_48 + 0x651e52);
                              }
                              else {
                                iVar6 = 0x1f;
                                if (puStack_48 != (undefined4 *)0x0) {
                                  for (; (uint)puStack_48 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                  }
                                }
                                bVar5 = (char)iVar6 + 0x24;
                              }
                              uVar13 = *(int *)(*(int *)(iStack_5c + 8) + (uint)bVar5 * 4) + 1;
                              uStack_8 = 0;
                              iVar6 = 0x1f;
                              if (uVar13 != 0) {
                                for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                }
                              }
                              iVar8 = (int)puStack_60 +
                                      ((*(int *)(&DAT_01947788 + (uint)bVar5 * 4) +
                                       *(int *)(iStack_5c + 0x2c)) - iVar6);
                              iVar6 = FUN_00aae0d0(iStack_5c,puStack_50,puStack_18);
                              puVar10 = (undefined4 *)(iVar6 + *(int *)(iVar14 + 0x40) + iVar8);
                              puStack_60 = puVar10;
                            }
                            else {
                              iVar6 = 0x1f;
                              if ((int)puStack_48 + 1U != 0) {
                                for (; (int)puStack_48 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                }
                              }
                              iVar8 = FUN_00aae0d0(iStack_5c,puStack_50,puStack_18);
                              puVar10 = (undefined4 *)((int)puStack_60 + iVar8 + iVar6 + 0x10);
                            }
                            uVar13 = puVar3[((int)param_3 + uStack_3c) * 7] + (int)puVar10;
                          }
                          else {
                            uStack_3c = 0x1f;
                            if (uStack_c != 0) {
                              for (; uStack_c >> uStack_3c == 0; uStack_3c = uStack_3c - 1) {
                              }
                            }
                            uStack_8 = 0;
                            uStack_3c = uStack_3c & 0xff;
                            if (*(int *)(iStack_5c + 0x44) != 0) {
                              iVar8 = 0x1f;
                              if ((int)puStack_48 + 1U != 0) {
                                for (; (int)puStack_48 + 1U >> iVar8 == 0; iVar8 = iVar8 + -1) {
                                }
                              }
                              iVar6 = FUN_00aae0d0(iStack_5c,puStack_50,puStack_28);
                              iVar6 = iVar6 + iVar8;
                              uVar13 = uStack_3c + 0x10;
                              goto LAB_00ab7ae3;
                            }
                            uVar13 = *(int *)(*(int *)(iStack_5c + 0xc) + uStack_3c * 4) + 1;
                            iVar6 = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                              }
                            }
                            uStack_3c = (*(int *)(iStack_5c + 0x3c) - iVar6) + uStack_3c;
                            if (puStack_48 < (undefined4 *)0x80) {
                              bVar5 = *(byte *)(puStack_48 + 0x651e52);
                            }
                            else {
                              iVar6 = 0x1f;
                              if (puStack_48 != (undefined4 *)0x0) {
                                for (; (uint)puStack_48 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                }
                              }
                              bVar5 = (char)iVar6 + 0x24;
                            }
                            uVar13 = *(int *)(*(int *)(iStack_5c + 8) + (uint)bVar5 * 4) + 1;
                            uStack_8 = 0;
                            iVar6 = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                              }
                            }
                            iVar8 = uStack_3c +
                                    ((*(int *)(&DAT_01947788 + (uint)bVar5 * 4) +
                                     *(int *)(iStack_5c + 0x2c)) - iVar6);
                            iVar6 = FUN_00aae0d0(iStack_5c,puStack_50,puStack_28);
                            uVar13 = iVar6 + *(int *)(iVar14 + 0x40) + iVar8;
                          }
                        }
                        else {
                          uStack_3c = 0x1f;
                          if (uStack_c != 0) {
                            for (; uStack_c >> uStack_3c == 0; uStack_3c = uStack_3c - 1) {
                            }
                          }
                          puStack_50 = (undefined4 *)0x0;
                          if (*(int *)(iStack_5c + 0x44) == 0) {
                            uVar13 = *(int *)(*(int *)(iStack_5c + 0xc) + (uStack_3c & 0xff) * 4) +
                                     1;
                            iVar6 = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                              }
                            }
                            uStack_3c = (*(int *)(iStack_5c + 0x3c) - iVar6) + (uStack_3c & 0xff);
                            if (puStack_48 < (undefined4 *)0x80) {
                              bVar5 = *(byte *)(puStack_48 + 0x651e52);
                            }
                            else {
                              iVar6 = 0x1f;
                              if (puStack_48 != (undefined4 *)0x0) {
                                for (; (uint)puStack_48 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                }
                              }
                              bVar5 = (char)iVar6 + 0x24;
                            }
                            uVar13 = *(int *)(*(int *)(iStack_5c + 8) + (uint)bVar5 * 4) + 1;
                            iVar6 = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                              }
                            }
                            uVar13 = **(int **)(iStack_5c + 4) + 1;
                            iVar8 = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                              }
                            }
                            iVar6 = *(int *)(iStack_5c + 0x40) +
                                    (*(int *)(iStack_5c + 0x34) - iVar8) +
                                    uStack_3c +
                                    ((*(int *)(&DAT_01947788 + (uint)bVar5 * 4) +
                                     *(int *)(iStack_5c + 0x2c)) - iVar6);
                          }
                          else {
                            for (iVar8 = 0x1f; 1U >> iVar8 == 0; iVar8 = iVar8 + -1) {
                            }
                            iVar6 = 0x1f;
                            if ((int)puStack_48 + 1U != 0) {
                              for (; (int)puStack_48 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                              }
                            }
                            iVar6 = (uStack_3c & 0xff) + 0x10 + iVar8 + iVar6;
                          }
                          uStack_8 = 0;
                          uVar13 = *puStack_2c;
LAB_00ab7ae3:
                          uVar13 = uVar13 + iVar6;
                        }
                        if (puVar11 < puStack_20) {
LAB_00ab7af8:
                          puVar10 = puVar3 + ((int)puVar11 + 1) * 7;
                          do {
                            puVar11 = (undefined4 *)((int)puVar11 + 1);
                            *puVar10 = 0x40000000;
                            puVar10 = puVar10 + 7;
                            puStack_40 = puVar11;
                          } while (puVar11 < puStack_20);
LAB_00ab7b24:
                          puStack_44[1] = puStack_54;
                          *puStack_44 = puStack_34;
                          puStack_44[2] = puStack_50;
                          puStack_44[-1] = uVar13;
                        }
                        else if (uVar13 <= (uint)puStack_44[-1]) {
                          if (puVar11 < puStack_20) goto LAB_00ab7af8;
                          goto LAB_00ab7b24;
                        }
                        puStack_44 = puStack_44 + -7;
                        puStack_54 = (undefined4 *)((int)puStack_54 + -1);
                        puStack_20 = (undefined4 *)((int)puStack_20 + -1);
                        puStack_48 = (undefined4 *)((int)puStack_48 + -1);
                        puVar15 = puStack_14;
                        puVar10 = puVar11;
                      } while (puStack_24 <= puStack_54);
                    }
                  }
                  iVar6 = iStack_30;
                  puStack_34 = (undefined4 *)((int)puStack_34 + 1);
                } while (puStack_34 < puVar15);
                puStack_60 = (undefined4 *)
                             FUN_00aa8910(param_1,puStack_1c,uStack_4c,iVar12,iStack_70,iStack_30,
                                          puStack_24);
                if ((puStack_60 != (undefined4 *)0x0) &&
                   ((puVar15 = *(undefined4 **)(iVar6 + -4 + (int)puStack_60 * 8),
                    puStack_74 < puVar15 ||
                    (iVar6 = iStack_30, 0xfff < (uint)((int)puVar15 + (int)param_3))))) {
                  puStack_34 = *(undefined4 **)(iStack_30 + -8 + (int)puStack_60 * 8);
LAB_00ab7efe:
                  puVar10 = (undefined4 *)((int)param_3 + 1);
                  puStack_40 = puVar10;
                  goto LAB_00ab7f27;
                }
                puStack_50 = (undefined4 *)0x0;
                if (puStack_60 != (undefined4 *)0x0) {
                  do {
                    puStack_14 = puStack_38;
                    if (puStack_50 != (undefined4 *)0x0) {
                      puStack_14 = (undefined4 *)(*(int *)(iVar6 + -4 + (int)puStack_50 * 8) + 1);
                    }
                    puStack_20 = (undefined4 *)((int)puStack_50 * 8);
                    puStack_38 = *(undefined4 **)((int)puStack_50 * 8 + iVar6 + 4);
                    if (puStack_14 <= puStack_38) {
                      puStack_54 = (undefined4 *)((int)puStack_14 + -3);
                      puStack_44 = (undefined4 *)((int)param_3 + (int)puStack_14);
                      puStack_48 = puVar3 + (int)puStack_44 * 7 + 1;
                      do {
                        uStack_8 = 0;
                        if (puStack_2c[2] == 1) {
                          puStack_1c = (undefined4 *)puStack_2c[3];
                          uVar13 = *(uint *)(iStack_30 + (int)puStack_20);
                          if (puStack_1c < param_3) {
                            uStack_3c = (int)param_3 - (int)puStack_1c;
                            puStack_18 = (undefined4 *)(uStack_3c + (int)puStack_10);
                            uStack_c = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> uStack_c == 0; uStack_c = uStack_c - 1) {
                              }
                            }
                            uStack_c = uStack_c & 0xff;
                            if (*(int *)(iVar14 + 0x44) == 0) {
                              uVar13 = *(int *)(*(int *)(iVar14 + 0xc) + uStack_c * 4) + 1;
                              iVar6 = 0x1f;
                              if (uVar13 != 0) {
                                for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                }
                              }
                              uStack_c = (*(int *)(iVar14 + 0x3c) - iVar6) + uStack_c;
                              if (puStack_54 < (undefined4 *)0x80) {
                                bVar5 = *(byte *)(puStack_54 + 0x651e52);
                              }
                              else {
                                iVar6 = 0x1f;
                                if (puStack_54 != (undefined4 *)0x0) {
                                  for (; (uint)puStack_54 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                  }
                                }
                                bVar5 = (char)iVar6 + 0x24;
                              }
                              uVar13 = *(int *)(*(int *)(iVar14 + 8) + (uint)bVar5 * 4) + 1;
                              uStack_8 = 0;
                              iVar6 = 0x1f;
                              if (uVar13 != 0) {
                                for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                }
                              }
                              iVar8 = uStack_c +
                                      ((*(int *)(&DAT_01947788 + (uint)bVar5 * 4) +
                                       *(int *)(iVar14 + 0x2c)) - iVar6);
                              iVar6 = FUN_00aae0d0(iVar14,puStack_1c,puStack_18);
                              iVar8 = iVar6 + *(int *)(iVar14 + 0x40) + iVar8;
                            }
                            else {
                              iVar6 = 0x1f;
                              if ((int)puStack_54 + 1U != 0) {
                                for (; (int)puStack_54 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                }
                              }
                              iVar8 = FUN_00aae0d0(iVar14,puStack_1c,puStack_18);
                              iVar8 = uStack_c + 0x10 + iVar8 + iVar6;
                            }
                            uVar13 = puVar3[uStack_3c * 7] + iVar8;
                          }
                          else {
                            uStack_c = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> uStack_c == 0; uStack_c = uStack_c - 1) {
                              }
                            }
                            uStack_c = uStack_c & 0xff;
                            if (*(int *)(iVar14 + 0x44) != 0) {
                              iVar8 = 0x1f;
                              if ((int)puStack_54 + 1U != 0) {
                                for (; (int)puStack_54 + 1U >> iVar8 == 0; iVar8 = iVar8 + -1) {
                                }
                              }
                              iVar6 = FUN_00aae0d0(iVar14,puStack_1c,puStack_28);
                              iVar6 = iVar6 + iVar8;
                              uVar13 = uStack_c + 0x10;
                              goto LAB_00ab7e59;
                            }
                            uVar13 = *(int *)(*(int *)(iVar14 + 0xc) + uStack_c * 4) + 1;
                            iVar6 = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                              }
                            }
                            uStack_c = (*(int *)(iVar14 + 0x3c) - iVar6) + uStack_c;
                            if (puStack_54 < (undefined4 *)0x80) {
                              bVar5 = *(byte *)(puStack_54 + 0x651e52);
                            }
                            else {
                              iVar6 = 0x1f;
                              if (puStack_54 != (undefined4 *)0x0) {
                                for (; (uint)puStack_54 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                }
                              }
                              bVar5 = (char)iVar6 + 0x24;
                            }
                            uVar13 = *(int *)(*(int *)(iVar14 + 8) + (uint)bVar5 * 4) + 1;
                            uStack_8 = 0;
                            iVar6 = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                              }
                            }
                            iVar8 = uStack_c +
                                    ((*(int *)(&DAT_01947788 + (uint)bVar5 * 4) +
                                     *(int *)(iVar14 + 0x2c)) - iVar6);
                            iVar6 = FUN_00aae0d0(iVar14,puStack_1c,puStack_28);
                            uVar13 = iVar6 + *(int *)(iVar14 + 0x40) + iVar8;
                          }
                        }
                        else {
                          puStack_1c = (undefined4 *)0x0;
                          uStack_c = 0x1f;
                          if (*(uint *)(iStack_30 + (int)puStack_20) != 0) {
                            for (; *(uint *)(iStack_30 + (int)puStack_20) >> uStack_c == 0;
                                uStack_c = uStack_c - 1) {
                            }
                          }
                          if (*(int *)(iVar14 + 0x44) == 0) {
                            uVar13 = *(int *)(*(int *)(iVar14 + 0xc) + (uStack_c & 0xff) * 4) + 1;
                            iVar6 = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                              }
                            }
                            uStack_c = (*(int *)(iVar14 + 0x3c) - iVar6) + (uStack_c & 0xff);
                            if (puStack_54 < (undefined4 *)0x80) {
                              bVar5 = *(byte *)(puStack_54 + 0x651e52);
                            }
                            else {
                              iVar6 = 0x1f;
                              if (puStack_54 != (undefined4 *)0x0) {
                                for (; (uint)puStack_54 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                                }
                              }
                              bVar5 = (char)iVar6 + 0x24;
                            }
                            uVar13 = *(int *)(*(int *)(iVar14 + 8) + (uint)bVar5 * 4) + 1;
                            iVar6 = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> iVar6 == 0; iVar6 = iVar6 + -1) {
                              }
                            }
                            uVar13 = **(int **)(iVar14 + 4) + 1;
                            iVar8 = 0x1f;
                            if (uVar13 != 0) {
                              for (; uVar13 >> iVar8 == 0; iVar8 = iVar8 + -1) {
                              }
                            }
                            iVar6 = *(int *)(iVar14 + 0x40) + (*(int *)(iVar14 + 0x34) - iVar8) +
                                    uStack_c +
                                    ((*(int *)(&DAT_01947788 + (uint)bVar5 * 4) +
                                     *(int *)(iVar14 + 0x2c)) - iVar6);
                          }
                          else {
                            for (iVar8 = 0x1f; 1U >> iVar8 == 0; iVar8 = iVar8 + -1) {
                            }
                            iVar6 = 0x1f;
                            if ((int)puStack_54 + 1U != 0) {
                              for (; (int)puStack_54 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                              }
                            }
                            iVar6 = (uStack_c & 0xff) + 0x10 + iVar8 + iVar6;
                          }
                          uStack_8 = 0;
                          uVar13 = *puStack_2c;
LAB_00ab7e59:
                          uVar13 = uVar13 + iVar6;
                        }
                        if (puVar10 < puStack_44) {
LAB_00ab7e6e:
                          puVar15 = puVar3 + ((int)puVar10 + 1) * 7;
                          do {
                            puVar10 = (undefined4 *)((int)puVar10 + 1);
                            *puVar15 = 0x40000000;
                            puVar15 = puVar15 + 7;
                          } while (puVar10 < puStack_44);
                          puStack_40 = puVar10;
LAB_00ab7e94:
                          puStack_48[1] = puStack_14;
                          *puStack_48 = *(undefined4 *)(iStack_30 + (int)puStack_20);
                          puStack_48[2] = puStack_1c;
                          puStack_48[-1] = uVar13;
                        }
                        else if (uVar13 < (uint)puStack_48[-1]) {
                          if (puVar10 < puStack_44) goto LAB_00ab7e6e;
                          goto LAB_00ab7e94;
                        }
                        puStack_14 = (undefined4 *)((int)puStack_14 + 1);
                        puStack_44 = (undefined4 *)((int)puStack_44 + 1);
                        puStack_54 = (undefined4 *)((int)puStack_54 + 1);
                        puStack_48 = puStack_48 + 7;
                        iVar6 = iStack_30;
                      } while (puStack_14 <= puStack_38);
                    }
                    puStack_50 = (undefined4 *)((int)puStack_50 + 1);
                  } while (puStack_50 < puStack_60);
                }
              }
              param_3 = (undefined4 *)((int)param_3 + 1);
            } while (param_3 <= puVar10);
          }
          puVar15 = (undefined4 *)puVar3[(int)puVar10 * 7 + 2];
          param_3 = (undefined4 *)((int)puVar10 - (int)puVar15);
          puStack_34 = (undefined4 *)puVar3[(int)puVar10 * 7 + 1];
        }
        else {
          puStack_34 = *(undefined4 **)(iStack_30 + -8 + (int)puStack_50 * 8);
          puVar10 = (undefined4 *)0x1;
          param_3 = (undefined4 *)0x0;
          puStack_40 = (undefined4 *)0x1;
        }
LAB_00ab7f27:
        puVar3[2] = 1;
        puVar11 = (undefined4 *)puVar3[(int)param_3 * 7 + 2];
        uVar17 = puVar3[(int)param_3 * 7 + 1];
        puVar3[(int)param_3 * 7 + 2] = puVar15;
        puVar3[(int)param_3 * 7 + 1] = puStack_34;
        if (puVar11 <= param_3) {
          do {
            param_3 = (undefined4 *)((int)param_3 - (int)puVar11);
            puVar15 = (undefined4 *)puVar3[(int)param_3 * 7 + 2];
            uVar4 = puVar3[(int)param_3 * 7 + 1];
            puVar3[(int)param_3 * 7 + 2] = puVar11;
            puVar3[(int)param_3 * 7 + 1] = uVar17;
            puVar11 = puVar15;
            puVar10 = puStack_40;
            uVar17 = uVar4;
          } while (puVar15 <= param_3);
        }
        puVar15 = (undefined4 *)0x0;
        do {
          puVar15 = (undefined4 *)((int)puVar15 + puVar3[(int)puVar15 * 7 + 2]);
        } while (puVar15 <= puVar10);
        puStack_18 = (undefined4 *)0x0;
        iVar14 = iStack_5c;
        if (puVar10 != (undefined4 *)0x0) {
          do {
            puVar15 = puStack_28;
            iVar6 = puVar3[(int)puStack_18 * 7 + 2];
            if (iVar6 == 1) {
              puStack_10 = (undefined4 *)((int)puStack_10 + 1);
            }
            else {
              uVar13 = puVar3[(int)puStack_18 * 7 + 1];
              uStack_c = (int)puStack_10 - (int)puStack_28;
              if (uVar13 < 4) {
                if (uVar13 != 0) {
                  if (uVar13 == 3) {
                    aiStack_90[0] = iStack_58 + -1;
LAB_00ab8026:
                    iStack_6c = iStack_68;
                    aiStack_90[2] = iStack_68;
                    iVar14 = iStack_5c;
                  }
                  else {
                    aiStack_90[0] = aiStack_90[uVar13];
                    if (uVar13 != 1) goto LAB_00ab8026;
                  }
                  iStack_68 = iStack_58;
                  aiStack_90[1] = iStack_58;
                  iStack_58 = aiStack_90[0];
                }
                if (uStack_c == 0) goto LAB_00ab804e;
              }
              else {
                iStack_6c = iStack_68;
                aiStack_90[2] = iStack_68;
                iStack_68 = iStack_58;
                aiStack_90[1] = iStack_58;
                aiStack_90[0] = uVar13 - 3;
                iStack_58 = aiStack_90[0];
LAB_00ab804e:
                uVar13 = uVar13 - 1;
              }
              uStack_3c = iVar6 - 3;
              FUN_00aafda0(iVar14,uStack_c,puStack_28,uVar13,uStack_3c);
              puVar11 = *(undefined4 **)(param_1 + 0x17c);
              puVar10 = (undefined4 *)(uStack_c + (int)puVar11);
              do {
                *puVar11 = *puVar15;
                puVar11[1] = puVar15[1];
                puVar11 = puVar11 + 2;
                puVar15 = puVar15 + 2;
              } while (puVar11 < puVar10);
              *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uStack_c;
              if (0xffff < uStack_c) {
                *(undefined4 *)(param_1 + 0x18c) = 1;
                *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3
                ;
              }
              *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uStack_c;
              **(int **)(param_1 + 0x174) = uVar13 + 1;
              if (0xffff < uStack_3c) {
                *(undefined4 *)(param_1 + 0x18c) = 2;
                *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3
                ;
              }
              *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)uStack_3c;
              *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
              puStack_10 = (undefined4 *)((int)puStack_10 + iVar6);
              puStack_28 = puStack_10;
              puVar10 = puStack_40;
              iVar14 = iStack_5c;
            }
            puStack_18 = (undefined4 *)((int)puStack_18 + iVar6);
          } while (puStack_18 < puVar10);
        }
      }
LAB_00ab8137:
      param_2 = puStack_28;
      iVar14 = iStack_5c;
    } while (puStack_10 < puStack_84);
  }
  *(int *)(param_1 + 0x1a0) = iStack_58;
  *(int *)(param_1 + 0x1a4) = iStack_68;
  *(int *)(param_1 + 0x1a8) = iStack_6c;
  return uStack_4c - (int)param_2;
}



/* FUNCTION 22073 ; VA 0x00ab8180 ; FUN_00ab8180 */

int FUN_00ab8180(int param_1,uint *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  short sVar8;
  uint *puVar9;
  uint *puVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  byte bVar15;
  int iVar16;
  uint *puVar17;
  uint uVar18;
  uint uVar19;
  uint *puVar20;
  uint *puVar21;
  uint *puVar22;
  uint *puVar23;
  int iVar24;
  uint *puVar25;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_28;
  uint uStack_20;
  uint uStack_1c;
  
  iVar2 = *(int *)(param_1 + 0x210);
  piVar1 = (int *)(param_1 + 0x170);
  iVar3 = *(int *)(param_1 + 4);
  uVar4 = *(undefined4 *)(param_1 + 0x98);
  iVar5 = *(int *)(param_1 + 0x218);
  uVar6 = *(undefined4 *)(param_1 + 0x94);
  uVar14 = *(uint *)(param_1 + 0xc);
  puVar9 = (uint *)(param_3 + (int)param_2);
  iVar11 = *(int *)(param_1 + 0xa0);
  if (iVar11 == 5) {
    puVar10 = puVar9 + -2;
    uVar12 = *(uint *)(param_1 + 0x194);
    uVar7 = *(uint *)(param_1 + 0x198);
    puVar20 = (uint *)((uint)(param_2 == (uint *)(uVar14 + iVar3)) + (int)param_2);
    uVar19 = (int)puVar20 - (uVar14 + iVar3);
    uStack_28 = 0;
    if (uVar7 <= uVar19) {
      uStack_28 = uVar7;
    }
    uVar18 = uVar12;
    if (uVar12 <= uVar19) {
      uVar18 = -(uint)(uVar19 < uVar7) & uVar7;
    }
    uStack_20 = 0;
    puVar25 = param_2;
    if (uVar12 <= uVar19) {
      uStack_20 = uVar12;
    }
joined_r0x00ab94bc:
    puVar22 = puVar20;
    if (puVar22 < puVar10) {
      FUN_016f39b0(*puVar22,puVar22[1],0xb7a56463,0xcf1bbcdc);
      iVar11 = FUN_016f4650();
      FUN_016f39b0(*puVar22,puVar22[1],0xbb000000,0xcf1bbcdc);
      iVar16 = FUN_016f4650();
      iVar24 = (int)puVar22 - iVar3;
      uVar12 = *(uint *)(iVar2 + iVar11 * 4);
      puVar23 = (uint *)(uVar12 + iVar3);
      uVar7 = *(uint *)(iVar5 + iVar16 * 4);
      puVar17 = (uint *)(iVar3 + uVar7);
      *(int *)(iVar5 + iVar16 * 4) = iVar24;
      *(int *)(iVar2 + iVar11 * 4) = iVar24;
      puVar20 = (uint *)((int)puVar22 + 1);
      if (uStack_20 == 0 || *(uint *)((int)puVar22 + (1 - uStack_20)) != *puVar20) {
        if (((uVar14 < uVar12) && (*puVar23 == *puVar22)) && (puVar23[1] == puVar22[1])) {
          puVar20 = puVar23 + 2;
          puVar17 = puVar22 + 2;
          puVar21 = puVar17;
          if (puVar17 < (uint *)((int)puVar9 - 3U)) {
LAB_00ab96a2:
            uVar12 = *puVar21 ^ *puVar20;
            if (uVar12 == 0) goto code_r0x00ab96ac;
            uVar7 = 0;
            if (uVar12 != 0) {
              for (; (uVar12 >> uVar7 & 1) == 0; uVar7 = uVar7 + 1) {
              }
            }
            iVar11 = ((uVar7 >> 3) - (int)puVar17) + (int)puVar21;
            goto LAB_00ab96de;
          }
LAB_00ab96b9:
          if ((puVar21 < (uint *)((int)puVar9 - 1U)) && (*(short *)puVar20 == *(short *)puVar21)) {
            puVar21 = (uint *)((int)puVar21 + 2);
            puVar20 = (uint *)((int)puVar20 + 2);
          }
          if ((puVar21 < puVar9) && (*(char *)puVar20 == *(char *)puVar21)) {
            puVar21 = (uint *)((int)puVar21 + 1);
          }
          iVar11 = (int)puVar21 - (int)puVar17;
LAB_00ab96de:
          uStack_40 = (int)puVar22 - (int)puVar23;
          iVar11 = iVar11 + 8;
          puVar20 = puVar22;
          if (puVar25 < puVar22 && (uint *)(uVar14 + iVar3) < puVar23) {
            do {
              puVar23 = (uint *)((int)puVar23 + -1);
              if (*(char *)((int)puVar20 - 1) != *(char *)puVar23) break;
              puVar20 = (uint *)((int)puVar20 - 1);
              iVar11 = iVar11 + 1;
            } while ((uint *)(uVar14 + iVar3) < puVar23 && puVar25 < puVar20);
          }
LAB_00ab987c:
          uVar12 = (int)puVar20 - (int)puVar25;
          puVar17 = *(uint **)(param_1 + 0x17c);
          puVar23 = (uint *)(uVar12 + (int)puVar17);
          do {
            *puVar17 = *puVar25;
            puVar17[1] = puVar25[1];
            puVar17 = puVar17 + 2;
            puVar25 = puVar25 + 2;
          } while (puVar17 < puVar23);
          *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar12;
          iVar16 = *(int *)(param_1 + 0x174);
          if (0xffff < uVar12) {
            *(int *)(param_1 + 400) = iVar16 - *piVar1 >> 3;
            iVar16 = *(int *)(param_1 + 0x174);
            *(undefined4 *)(param_1 + 0x18c) = 1;
          }
          *(short *)(iVar16 + 4) = (short)uVar12;
          **(int **)(param_1 + 0x174) = uStack_40 + 3;
          uVar12 = iVar11 - 3;
          uStack_28 = uStack_20;
          uStack_20 = uStack_40;
          goto joined_r0x00ab98fd;
        }
        if ((uVar14 < uVar7) && (*puVar17 == *puVar22)) {
          FUN_016f39b0(*puVar20,*(undefined4 *)((int)puVar22 + 5),0xb7a56463,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          uVar12 = *(uint *)(iVar2 + iVar11 * 4);
          puVar23 = (uint *)(iVar3 + uVar12);
          *(int *)(iVar2 + iVar11 * 4) = iVar24 + 1;
          if ((uVar14 < uVar12) &&
             ((*puVar23 == *puVar20 && (puVar23[1] == *(uint *)((int)puVar22 + 5))))) {
            iVar11 = FUN_00abcfb0((int)puVar22 + 9,puVar23 + 2,puVar9);
            iVar11 = iVar11 + 8;
            uStack_40 = (int)puVar20 - (int)puVar23;
            if (puVar25 < puVar20 && (uint *)(uVar14 + iVar3) < puVar23) {
              do {
                puVar23 = (uint *)((int)puVar23 + -1);
                if (*(char *)((int)puVar20 - 1) != *(char *)puVar23) break;
                puVar20 = (uint *)((int)puVar20 - 1);
                iVar11 = iVar11 + 1;
              } while (puVar25 < puVar20 && (uint *)(uVar14 + iVar3) < puVar23);
            }
          }
          else {
            iVar11 = FUN_00abcfb0(puVar22 + 1,puVar17 + 1,puVar9);
            iVar11 = iVar11 + 4;
            uStack_40 = (int)puVar22 - (int)puVar17;
            puVar20 = puVar22;
            if (puVar25 < puVar22 && (uint *)(uVar14 + iVar3) < puVar17) {
              do {
                puVar17 = (uint *)((int)puVar17 + -1);
                if (*(char *)((int)puVar20 - 1) != *(char *)puVar17) break;
                puVar20 = (uint *)((int)puVar20 - 1);
                iVar11 = iVar11 + 1;
              } while ((uint *)(uVar14 + iVar3) < puVar17 && puVar25 < puVar20);
            }
          }
          goto LAB_00ab987c;
        }
        puVar20 = (uint *)((int)puVar22 + ((int)puVar22 - (int)param_2 >> 8) + 1);
      }
      else {
        puVar23 = (uint *)((int)puVar22 + 5);
        puVar17 = (uint *)((int)puVar22 + (5 - uStack_20));
        puVar25 = puVar23;
        if (puVar23 < (uint *)((int)puVar9 - 3U)) {
LAB_00ab9596:
          uVar12 = *puVar25 ^ *puVar17;
          if (uVar12 == 0) goto code_r0x00ab95a0;
          uVar7 = 0;
          if (uVar12 != 0) {
            for (; (uVar12 >> uVar7 & 1) == 0; uVar7 = uVar7 + 1) {
            }
          }
          iVar16 = ((uVar7 >> 3) - (int)puVar23) + (int)puVar25;
          goto LAB_00ab95cf;
        }
LAB_00ab95aa:
        if ((puVar25 < (uint *)((int)puVar9 - 1U)) && (*(short *)puVar17 == *(short *)puVar25)) {
          puVar25 = (uint *)((int)puVar25 + 2);
          puVar17 = (uint *)((int)puVar17 + 2);
        }
        if ((puVar25 < puVar9) && (*(char *)puVar17 == *(char *)puVar25)) {
          puVar25 = (uint *)((int)puVar25 + 1);
        }
        iVar16 = (int)puVar25 - (int)puVar23;
LAB_00ab95cf:
        iVar11 = iVar16 + 4;
        uVar12 = (int)puVar20 - (int)param_2;
        puVar25 = *(uint **)(param_1 + 0x17c);
        puVar17 = (uint *)(uVar12 + (int)puVar25);
        do {
          *puVar25 = *param_2;
          puVar25[1] = param_2[1];
          puVar25 = puVar25 + 2;
          param_2 = param_2 + 2;
        } while (puVar25 < puVar17);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar12;
        iVar13 = *(int *)(param_1 + 0x174);
        if (0xffff < uVar12) {
          *(int *)(param_1 + 400) = iVar13 - *piVar1 >> 3;
          iVar13 = *(int *)(param_1 + 0x174);
          *(undefined4 *)(param_1 + 0x18c) = 1;
        }
        *(short *)(iVar13 + 4) = (short)uVar12;
        **(undefined4 **)(param_1 + 0x174) = 1;
        uVar12 = iVar16 + 1;
joined_r0x00ab98fd:
        if (uVar12 < 0x10000) {
          sVar8 = (short)uVar12;
          iVar16 = *(int *)(param_1 + 0x174);
        }
        else {
          iVar16 = *(int *)(param_1 + 0x174);
          *(int *)(param_1 + 400) = iVar16 - *piVar1 >> 3;
          sVar8 = (short)iVar11 + -3;
          *(undefined4 *)(param_1 + 0x18c) = 2;
        }
        *(short *)(iVar16 + 6) = sVar8;
        param_2 = (uint *)((int)puVar20 + iVar11);
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        puVar20 = param_2;
        puVar25 = param_2;
        if (param_2 <= puVar10) {
          FUN_016f39b0(*(undefined4 *)((int)puVar22 + 2),*(undefined4 *)((int)puVar22 + 6),
                       0xbb000000,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar5 + iVar11 * 4) = iVar24 + 2;
          FUN_016f39b0(*(undefined4 *)((int)puVar22 + 2),*(undefined4 *)((int)puVar22 + 6),
                       0xb7a56463,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar2 + iVar11 * 4) = iVar24 + 2;
          iVar16 = (int)param_2 + (-2 - iVar3);
          FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),
                       0xbb000000,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar5 + iVar11 * 4) = iVar16;
          FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),
                       0xb7a56463,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar2 + iVar11 * 4) = iVar16;
          do {
            uVar7 = uStack_20;
            uVar12 = uStack_28;
            puVar20 = param_2;
            puVar25 = param_2;
            if (uStack_28 == 0 || *param_2 != *(uint *)((int)param_2 - uStack_28)) break;
            iVar11 = FUN_00abcfb0(param_2 + 1,(uint *)((int)param_2 - uStack_28) + 1,puVar9);
            uStack_28 = uStack_20;
            uStack_20 = uVar12;
            iVar16 = FUN_00abd760(param_2,uVar6,5);
            *(int *)(iVar5 + iVar16 * 4) = (int)param_2 - iVar3;
            FUN_016f39b0(*param_2,param_2[1],0xb7a56463,0xcf1bbcdc);
            iVar16 = FUN_016f4650();
            *(int *)(iVar2 + iVar16 * 4) = (int)param_2 - iVar3;
            FUN_00abd980(param_1 + 0x170,0,param_2,0,iVar11 + 1);
            param_2 = (uint *)((int)param_2 + iVar11 + 4);
            puVar20 = param_2;
            puVar25 = param_2;
          } while (param_2 <= puVar10);
        }
      }
      goto joined_r0x00ab94bc;
    }
    uVar14 = uVar18;
    if (uStack_20 != 0) {
      uVar14 = uStack_20;
    }
  }
  else if (iVar11 == 6) {
    puVar10 = puVar9 + -2;
    uVar12 = *(uint *)(param_1 + 0x194);
    uVar7 = *(uint *)(param_1 + 0x198);
    puVar20 = (uint *)((uint)(param_2 == (uint *)(uVar14 + iVar3)) + (int)param_2);
    uVar19 = (int)puVar20 - (uVar14 + iVar3);
    uStack_28 = 0;
    if (uVar7 <= uVar19) {
      uStack_28 = uVar7;
    }
    uVar18 = uVar12;
    if (uVar12 <= uVar19) {
      uVar18 = -(uint)(uVar19 < uVar7) & uVar7;
    }
    uVar7 = 0;
    puVar25 = param_2;
    if (uVar12 <= uVar19) {
      uVar7 = uVar12;
    }
joined_r0x00ab8e91:
    puVar22 = puVar20;
    if (puVar22 < puVar10) {
      FUN_016f39b0(*puVar22,puVar22[1],0xb7a56463,0xcf1bbcdc);
      iVar11 = FUN_016f4650();
      FUN_016f39b0(*puVar22,puVar22[1],0xbf9b0000,0xcf1bbcdc);
      iVar16 = FUN_016f4650();
      iVar24 = (int)puVar22 - iVar3;
      uVar12 = *(uint *)(iVar2 + iVar11 * 4);
      puVar23 = (uint *)(uVar12 + iVar3);
      uVar19 = *(uint *)(iVar5 + iVar16 * 4);
      puVar17 = (uint *)(iVar3 + uVar19);
      *(int *)(iVar5 + iVar16 * 4) = iVar24;
      *(int *)(iVar2 + iVar11 * 4) = iVar24;
      puVar20 = (uint *)((int)puVar22 + 1);
      if (uVar7 == 0 || *(uint *)((int)puVar22 + (1 - uVar7)) != *puVar20) {
        if (((uVar14 < uVar12) && (*puVar23 == *puVar22)) && (puVar23[1] == puVar22[1])) {
          puVar20 = puVar23 + 2;
          puVar17 = puVar22 + 2;
          puVar21 = puVar17;
          if (puVar17 < (uint *)((int)puVar9 - 3U)) {
LAB_00ab9070:
            uVar12 = *puVar21 ^ *puVar20;
            if (uVar12 == 0) goto code_r0x00ab907a;
            uVar19 = 0;
            if (uVar12 != 0) {
              for (; (uVar12 >> uVar19 & 1) == 0; uVar19 = uVar19 + 1) {
              }
            }
            iVar11 = ((uVar19 >> 3) - (int)puVar17) + (int)puVar21;
            goto LAB_00ab90ac;
          }
LAB_00ab9087:
          if ((puVar21 < (uint *)((int)puVar9 - 1U)) && (*(short *)puVar20 == *(short *)puVar21)) {
            puVar21 = (uint *)((int)puVar21 + 2);
            puVar20 = (uint *)((int)puVar20 + 2);
          }
          if ((puVar21 < puVar9) && (*(char *)puVar20 == *(char *)puVar21)) {
            puVar21 = (uint *)((int)puVar21 + 1);
          }
          iVar11 = (int)puVar21 - (int)puVar17;
LAB_00ab90ac:
          uStack_3c = (int)puVar22 - (int)puVar23;
          iVar11 = iVar11 + 8;
          puVar20 = puVar22;
          if (puVar25 < puVar22 && (uint *)(uVar14 + iVar3) < puVar23) {
            do {
              puVar23 = (uint *)((int)puVar23 + -1);
              if (*(char *)((int)puVar20 - 1) != *(char *)puVar23) break;
              puVar20 = (uint *)((int)puVar20 - 1);
              iVar11 = iVar11 + 1;
            } while (puVar25 < puVar20 && (uint *)(uVar14 + iVar3) < puVar23);
          }
LAB_00ab9248:
          uStack_20 = uStack_3c;
          uVar12 = (int)puVar20 - (int)puVar25;
          puVar17 = *(uint **)(param_1 + 0x17c);
          puVar23 = (uint *)(uVar12 + (int)puVar17);
          do {
            *puVar17 = *puVar25;
            puVar17[1] = puVar25[1];
            puVar17 = puVar17 + 2;
            puVar25 = puVar25 + 2;
          } while (puVar17 < puVar23);
          *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar12;
          if (0xffff < uVar12) {
            *(undefined4 *)(param_1 + 0x18c) = 1;
            *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
          }
          *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar12;
          **(int **)(param_1 + 0x174) = uStack_3c + 3;
          uStack_28 = uVar7;
          goto LAB_00ab92c7;
        }
        if ((uVar14 < uVar19) && (*puVar17 == *puVar22)) {
          FUN_016f39b0(*puVar20,*(undefined4 *)((int)puVar22 + 5),0xb7a56463,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          uVar12 = *(uint *)(iVar2 + iVar11 * 4);
          puVar23 = (uint *)(iVar3 + uVar12);
          *(int *)(iVar2 + iVar11 * 4) = iVar24 + 1;
          if ((uVar14 < uVar12) &&
             ((*puVar23 == *puVar20 && (puVar23[1] == *(uint *)((int)puVar22 + 5))))) {
            iVar11 = FUN_00abcfb0((int)puVar22 + 9,puVar23 + 2,puVar9);
            iVar11 = iVar11 + 8;
            uStack_3c = (int)puVar20 - (int)puVar23;
            if (puVar25 < puVar20 && (uint *)(uVar14 + iVar3) < puVar23) {
              do {
                puVar23 = (uint *)((int)puVar23 + -1);
                if (*(char *)((int)puVar20 - 1) != *(char *)puVar23) break;
                puVar20 = (uint *)((int)puVar20 - 1);
                iVar11 = iVar11 + 1;
              } while (puVar25 < puVar20 && (uint *)(uVar14 + iVar3) < puVar23);
            }
          }
          else {
            iVar11 = FUN_00abcfb0(puVar22 + 1,puVar17 + 1,puVar9);
            iVar11 = iVar11 + 4;
            uStack_3c = (int)puVar22 - (int)puVar17;
            puVar20 = puVar22;
            if (puVar25 < puVar22 && (uint *)(uVar14 + iVar3) < puVar17) {
              do {
                puVar17 = (uint *)((int)puVar17 + -1);
                if (*(char *)((int)puVar20 - 1) != *(char *)puVar17) break;
                puVar20 = (uint *)((int)puVar20 - 1);
                iVar11 = iVar11 + 1;
              } while (puVar25 < puVar20 && (uint *)(uVar14 + iVar3) < puVar17);
            }
          }
          goto LAB_00ab9248;
        }
        puVar20 = (uint *)((int)puVar22 + ((int)puVar22 - (int)param_2 >> 8) + 1);
      }
      else {
        puVar23 = (uint *)((int)puVar22 + 5);
        puVar17 = (uint *)((int)puVar22 + (5 - uVar7));
        puVar25 = puVar23;
        if (puVar23 < (uint *)((int)puVar9 - 3U)) {
LAB_00ab8f70:
          uVar12 = *puVar17 ^ *puVar25;
          if (uVar12 == 0) goto code_r0x00ab8f7a;
          uVar19 = 0;
          if (uVar12 != 0) {
            for (; (uVar12 >> uVar19 & 1) == 0; uVar19 = uVar19 + 1) {
            }
          }
          iVar11 = ((uVar19 >> 3) - (int)puVar23) + (int)puVar25;
          goto LAB_00ab8fa9;
        }
LAB_00ab8f84:
        if ((puVar25 < (uint *)((int)puVar9 - 1U)) && (*(short *)puVar17 == *(short *)puVar25)) {
          puVar25 = (uint *)((int)puVar25 + 2);
          puVar17 = (uint *)((int)puVar17 + 2);
        }
        if ((puVar25 < puVar9) && (*(char *)puVar17 == *(char *)puVar25)) {
          puVar25 = (uint *)((int)puVar25 + 1);
        }
        iVar11 = (int)puVar25 - (int)puVar23;
LAB_00ab8fa9:
        iVar11 = iVar11 + 4;
        uVar12 = (int)puVar20 - (int)param_2;
        puVar25 = *(uint **)(param_1 + 0x17c);
        puVar17 = (uint *)(uVar12 + (int)puVar25);
        do {
          *puVar25 = *param_2;
          puVar25[1] = param_2[1];
          puVar25 = puVar25 + 2;
          param_2 = param_2 + 2;
        } while (puVar25 < puVar17);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar12;
        iVar16 = *(int *)(param_1 + 0x174);
        if (0xffff < uVar12) {
          *(int *)(param_1 + 400) = iVar16 - *piVar1 >> 3;
          iVar16 = *(int *)(param_1 + 0x174);
          *(undefined4 *)(param_1 + 0x18c) = 1;
        }
        *(short *)(iVar16 + 4) = (short)uVar12;
        **(undefined4 **)(param_1 + 0x174) = 1;
        uStack_20 = uVar7;
LAB_00ab92c7:
        if (iVar11 - 3U < 0x10000) {
          iVar16 = *(int *)(param_1 + 0x174);
        }
        else {
          iVar16 = *(int *)(param_1 + 0x174);
          *(int *)(param_1 + 400) = iVar16 - *piVar1 >> 3;
          *(undefined4 *)(param_1 + 0x18c) = 2;
        }
        *(short *)(iVar16 + 6) = (short)iVar11 + -3;
        param_2 = (uint *)((int)puVar20 + iVar11);
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        puVar20 = param_2;
        uVar7 = uStack_20;
        puVar25 = param_2;
        if (param_2 <= puVar10) {
          FUN_016f39b0(*(undefined4 *)((int)puVar22 + 2),*(undefined4 *)((int)puVar22 + 6),
                       0xbf9b0000,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar5 + iVar11 * 4) = iVar24 + 2;
          FUN_016f39b0(*(undefined4 *)((int)puVar22 + 2),*(undefined4 *)((int)puVar22 + 6),
                       0xb7a56463,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar2 + iVar11 * 4) = iVar24 + 2;
          iVar16 = (int)param_2 + (-2 - iVar3);
          FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),
                       0xbf9b0000,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar5 + iVar11 * 4) = iVar16;
          FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),
                       0xb7a56463,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar2 + iVar11 * 4) = iVar16;
          do {
            uVar19 = uStack_20;
            uVar12 = uStack_28;
            puVar20 = param_2;
            uVar7 = uStack_20;
            puVar25 = param_2;
            if (uStack_28 == 0 || *param_2 != *(uint *)((int)param_2 - uStack_28)) break;
            iVar11 = FUN_00abcfb0(param_2 + 1,(uint *)((int)param_2 - uStack_28) + 1,puVar9);
            uStack_28 = uStack_20;
            uStack_20 = uVar12;
            iVar16 = FUN_00abd760(param_2,uVar6,6);
            *(int *)(iVar5 + iVar16 * 4) = (int)param_2 - iVar3;
            iVar16 = FUN_00abd760(param_2,uVar4,8);
            *(int *)(iVar2 + iVar16 * 4) = (int)param_2 - iVar3;
            FUN_00abd980(param_1 + 0x170,0,param_2,0,iVar11 + 1);
            param_2 = (uint *)((int)param_2 + iVar11 + 4);
            puVar20 = param_2;
            uVar7 = uVar12;
            puVar25 = param_2;
          } while (param_2 <= puVar10);
        }
      }
      goto joined_r0x00ab8e91;
    }
    uVar14 = uVar18;
    if (uVar7 != 0) {
      uVar14 = uVar7;
    }
  }
  else {
    uVar12 = *(uint *)(param_1 + 0x194);
    uVar7 = *(uint *)(param_1 + 0x198);
    if (iVar11 != 7) {
      puVar10 = puVar9 + -2;
      puVar20 = (uint *)((uint)(param_2 == (uint *)(uVar14 + iVar3)) + (int)param_2);
      uVar19 = (int)puVar20 - (uVar14 + iVar3);
      uStack_20 = 0;
      if (uVar7 <= uVar19) {
        uStack_20 = uVar7;
      }
      uVar18 = uVar12;
      if (uVar12 <= uVar19) {
        uVar18 = -(uint)(uVar19 < uVar7) & uVar7;
      }
      uStack_1c = 0;
      if (uVar12 <= uVar19) {
        uStack_1c = uVar12;
      }
      puVar25 = param_2;
      if (puVar20 < puVar10) {
        bVar15 = 0x20 - (char)uVar6;
        do {
          FUN_016f39b0(*puVar20,puVar20[1],0xb7a56463,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          uVar19 = *puVar20 * -0x61c8864f >> (bVar15 & 0x1f);
          iVar16 = (int)puVar20 - iVar3;
          uVar12 = *(uint *)(iVar2 + iVar11 * 4);
          uVar7 = *(uint *)(iVar5 + uVar19 * 4);
          puVar23 = (uint *)(iVar3 + uVar12);
          puVar17 = (uint *)(uVar7 + iVar3);
          *(int *)(iVar5 + uVar19 * 4) = iVar16;
          *(int *)(iVar2 + iVar11 * 4) = iVar16;
          puVar22 = (uint *)((int)puVar20 + 1);
          if (uStack_1c == 0 || *(uint *)((int)puVar20 + (1 - uStack_1c)) != *puVar22) {
            if (((uVar14 < uVar12) && (*puVar23 == *puVar20)) && (puVar23[1] == puVar20[1])) {
              puVar25 = puVar20 + 2;
              puVar17 = puVar23 + 2;
              puVar22 = puVar25;
              if (puVar25 < (uint *)((int)puVar9 - 3U)) {
LAB_00ab8420:
                uVar12 = *puVar22 ^ *puVar17;
                if (uVar12 == 0) goto code_r0x00ab842a;
                uVar7 = 0;
                if (uVar12 != 0) {
                  for (; (uVar12 >> uVar7 & 1) == 0; uVar7 = uVar7 + 1) {
                  }
                }
                iVar11 = ((uVar7 >> 3) - (int)puVar25) + (int)puVar22;
                goto LAB_00ab845c;
              }
LAB_00ab8437:
              if ((puVar22 < (uint *)((int)puVar9 - 1U)) && (*(short *)puVar17 == *(short *)puVar22)
                 ) {
                puVar22 = (uint *)((int)puVar22 + 2);
                puVar17 = (uint *)((int)puVar17 + 2);
              }
              if ((puVar22 < puVar9) && (*(char *)puVar17 == *(char *)puVar22)) {
                puVar22 = (uint *)((int)puVar22 + 1);
              }
              iVar11 = (int)puVar22 - (int)puVar25;
LAB_00ab845c:
              uStack_38 = (int)puVar20 - (int)puVar23;
              iVar11 = iVar11 + 8;
              puVar22 = puVar20;
              if (param_2 < puVar20 && (uint *)(uVar14 + iVar3) < puVar23) {
                do {
                  puVar23 = (uint *)((int)puVar23 + -1);
                  if (*(char *)((int)puVar22 - 1) != *(char *)puVar23) break;
                  puVar22 = (uint *)((int)puVar22 - 1);
                  iVar11 = iVar11 + 1;
                } while (param_2 < puVar22 && (uint *)(uVar14 + iVar3) < puVar23);
              }
LAB_00ab85f3:
              uVar12 = (int)puVar22 - (int)param_2;
              puVar25 = *(uint **)(param_1 + 0x17c);
              puVar17 = (uint *)(uVar12 + (int)puVar25);
              do {
                *puVar25 = *param_2;
                puVar25[1] = param_2[1];
                puVar25 = puVar25 + 2;
                param_2 = param_2 + 2;
              } while (puVar25 < puVar17);
              *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar12;
              iVar24 = *(int *)(param_1 + 0x174);
              if (0xffff < uVar12) {
                *(int *)(param_1 + 400) = iVar24 - *piVar1 >> 3;
                iVar24 = *(int *)(param_1 + 0x174);
                *(undefined4 *)(param_1 + 0x18c) = 1;
              }
              *(short *)(iVar24 + 4) = (short)uVar12;
              **(int **)(param_1 + 0x174) = uStack_38 + 3;
              uVar12 = iVar11 - 3;
              uStack_20 = uStack_1c;
              uStack_1c = uStack_38;
              goto joined_r0x00ab8673;
            }
            if ((uVar14 < uVar7) && (*puVar17 == *puVar20)) {
              FUN_016f39b0(*puVar22,*(undefined4 *)((int)puVar20 + 5),0xb7a56463,0xcf1bbcdc);
              iVar11 = FUN_016f4650();
              uVar12 = *(uint *)(iVar2 + iVar11 * 4);
              puVar25 = (uint *)(iVar3 + uVar12);
              *(int *)(iVar2 + iVar11 * 4) = iVar16 + 1;
              if ((uVar14 < uVar12) &&
                 ((*puVar25 == *puVar22 && (puVar25[1] == *(uint *)((int)puVar20 + 5))))) {
                iVar11 = FUN_00abcfb0((int)puVar20 + 9,puVar25 + 2,puVar9);
                iVar11 = iVar11 + 8;
                uStack_38 = (int)puVar22 - (int)puVar25;
                if (param_2 < puVar22 && (uint *)(uVar14 + iVar3) < puVar25) {
                  do {
                    puVar25 = (uint *)((int)puVar25 + -1);
                    if (*(char *)((int)puVar22 - 1) != *(char *)puVar25) break;
                    puVar22 = (uint *)((int)puVar22 - 1);
                    iVar11 = iVar11 + 1;
                  } while (param_2 < puVar22 && (uint *)(uVar14 + iVar3) < puVar25);
                }
              }
              else {
                iVar11 = FUN_00abcfb0(puVar20 + 1,puVar17 + 1,puVar9);
                iVar11 = iVar11 + 4;
                uStack_38 = (int)puVar20 - (int)puVar17;
                puVar22 = puVar20;
                if (param_2 < puVar20 && (uint *)(uVar14 + iVar3) < puVar17) {
                  do {
                    puVar17 = (uint *)((int)puVar17 + -1);
                    if (*(char *)((int)puVar22 - 1) != *(char *)puVar17) break;
                    puVar22 = (uint *)((int)puVar22 - 1);
                    iVar11 = iVar11 + 1;
                  } while (param_2 < puVar22 && (uint *)(uVar14 + iVar3) < puVar17);
                }
              }
              goto LAB_00ab85f3;
            }
            puVar22 = (uint *)((int)puVar20 + ((int)puVar20 - (int)puVar25 >> 8) + 1);
          }
          else {
            puVar21 = (uint *)((int)puVar20 + 5);
            puVar23 = (uint *)((int)puVar20 + (5 - uStack_1c));
            puVar17 = puVar21;
            if (puVar21 < (uint *)((int)puVar9 - 3U)) {
LAB_00ab8310:
              uVar12 = *puVar17 ^ *puVar23;
              if (uVar12 == 0) goto code_r0x00ab831a;
              uVar7 = 0;
              if (uVar12 != 0) {
                for (; (uVar12 >> uVar7 & 1) == 0; uVar7 = uVar7 + 1) {
                }
              }
              iVar24 = ((uVar7 >> 3) - (int)puVar21) + (int)puVar17;
              goto LAB_00ab8349;
            }
LAB_00ab8324:
            if ((puVar17 < (uint *)((int)puVar9 - 1U)) && (*(short *)puVar23 == *(short *)puVar17))
            {
              puVar17 = (uint *)((int)puVar17 + 2);
              puVar23 = (uint *)((int)puVar23 + 2);
            }
            if ((puVar17 < puVar9) && (*(char *)puVar23 == *(char *)puVar17)) {
              puVar17 = (uint *)((int)puVar17 + 1);
            }
            iVar24 = (int)puVar17 - (int)puVar21;
LAB_00ab8349:
            iVar11 = iVar24 + 4;
            uVar12 = (int)puVar22 - (int)puVar25;
            puVar17 = *(uint **)(param_1 + 0x17c);
            puVar23 = (uint *)(uVar12 + (int)puVar17);
            do {
              *puVar17 = *puVar25;
              puVar17[1] = puVar25[1];
              puVar17 = puVar17 + 2;
              puVar25 = puVar25 + 2;
            } while (puVar17 < puVar23);
            *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar12;
            iVar13 = *(int *)(param_1 + 0x174);
            if (0xffff < uVar12) {
              *(int *)(param_1 + 400) = iVar13 - *piVar1 >> 3;
              iVar13 = *(int *)(param_1 + 0x174);
              *(undefined4 *)(param_1 + 0x18c) = 1;
            }
            *(short *)(iVar13 + 4) = (short)uVar12;
            **(undefined4 **)(param_1 + 0x174) = 1;
            uVar12 = iVar24 + 1;
joined_r0x00ab8673:
            if (uVar12 < 0x10000) {
              sVar8 = (short)uVar12;
              iVar24 = *(int *)(param_1 + 0x174);
            }
            else {
              iVar24 = *(int *)(param_1 + 0x174);
              *(int *)(param_1 + 400) = iVar24 - *piVar1 >> 3;
              sVar8 = (short)iVar11 + -3;
              *(undefined4 *)(param_1 + 0x18c) = 2;
            }
            *(short *)(iVar24 + 6) = sVar8;
            puVar22 = (uint *)((int)puVar22 + iVar11);
            *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
            puVar25 = puVar22;
            param_2 = puVar22;
            if (puVar22 <= puVar10) {
              *(int *)(iVar5 + ((uint)(*(int *)((int)puVar20 + 2) * -0x61c8864f) >> (bVar15 & 0x1f))
                               * 4) = iVar16 + 2;
              FUN_016f39b0(*(undefined4 *)((int)puVar20 + 2),*(undefined4 *)((int)puVar20 + 6),
                           0xb7a56463,0xcf1bbcdc);
              iVar11 = FUN_016f4650();
              *(int *)(iVar2 + iVar11 * 4) = iVar16 + 2;
              iVar16 = (int)puVar22 + (-2 - iVar3);
              *(int *)(iVar5 + ((uint)(*(int *)((int)puVar22 + -2) * -0x61c8864f) >> (bVar15 & 0x1f)
                               ) * 4) = iVar16;
              FUN_016f39b0(*(undefined4 *)((int)puVar22 + -2),*(undefined4 *)((int)puVar22 + 2),
                           0xb7a56463,0xcf1bbcdc);
              iVar11 = FUN_016f4650();
              *(int *)(iVar2 + iVar11 * 4) = iVar16;
              do {
                uVar12 = uStack_1c;
                puVar25 = puVar22;
                param_2 = puVar22;
                if (uStack_20 == 0 || *puVar22 != *(uint *)((int)puVar22 - uStack_20)) break;
                iVar11 = FUN_00abcfb0(puVar22 + 1,(uint *)((int)puVar22 - uStack_20) + 1,puVar9);
                uStack_1c = uStack_20;
                uStack_20 = uVar12;
                *(int *)(iVar5 + (*puVar22 * -0x61c8864f >> (bVar15 & 0x1f)) * 4) =
                     (int)puVar22 - iVar3;
                FUN_016f39b0(*puVar22,puVar22[1],0xb7a56463,0xcf1bbcdc);
                iVar16 = FUN_016f4650();
                *(int *)(iVar2 + iVar16 * 4) = (int)puVar22 - iVar3;
                FUN_00abd980(param_1 + 0x170,0,puVar22,0,iVar11 + 1);
                puVar22 = (uint *)((int)puVar22 + iVar11 + 4);
                puVar25 = puVar22;
                param_2 = puVar22;
              } while (puVar22 <= puVar10);
            }
          }
          puVar20 = puVar22;
        } while (puVar22 < puVar10);
      }
      uVar14 = uVar18;
      if (uStack_1c != 0) {
        uVar14 = uStack_1c;
      }
      *(uint *)(param_1 + 0x1a0) = uVar14;
      if (uStack_20 != 0) {
        uVar18 = uStack_20;
      }
      *(uint *)(param_1 + 0x1a4) = uVar18;
      return (int)puVar9 - (int)puVar25;
    }
    puVar10 = puVar9 + -2;
    puVar20 = (uint *)((uint)(param_2 == (uint *)(uVar14 + iVar3)) + (int)param_2);
    uVar19 = (int)puVar20 - (uVar14 + iVar3);
    uStack_28 = 0;
    if (uVar7 <= uVar19) {
      uStack_28 = uVar7;
    }
    uVar18 = uVar12;
    if (uVar12 <= uVar19) {
      uVar18 = -(uint)(uVar19 < uVar7) & uVar7;
    }
    uVar7 = 0;
    puVar25 = param_2;
    if (uVar12 <= uVar19) {
      uVar7 = uVar12;
    }
joined_r0x00ab8863:
    puVar22 = puVar20;
    if (puVar22 < puVar10) {
      FUN_016f39b0(*puVar22,puVar22[1],0xb7a56463,0xcf1bbcdc);
      iVar11 = FUN_016f4650();
      FUN_016f39b0(*puVar22,puVar22[1],0xbfa56300,0xcf1bbcdc);
      iVar16 = FUN_016f4650();
      iVar24 = (int)puVar22 - iVar3;
      uVar12 = *(uint *)(iVar2 + iVar11 * 4);
      puVar23 = (uint *)(uVar12 + iVar3);
      uVar19 = *(uint *)(iVar5 + iVar16 * 4);
      puVar17 = (uint *)(iVar3 + uVar19);
      *(int *)(iVar5 + iVar16 * 4) = iVar24;
      *(int *)(iVar2 + iVar11 * 4) = iVar24;
      puVar20 = (uint *)((int)puVar22 + 1);
      if (uVar7 == 0 || *(uint *)((int)puVar22 + (1 - uVar7)) != *puVar20) {
        if (((uVar14 < uVar12) && (*puVar23 == *puVar22)) && (puVar23[1] == puVar22[1])) {
          puVar20 = puVar23 + 2;
          puVar17 = puVar22 + 2;
          puVar21 = puVar17;
          if (puVar17 < (uint *)((int)puVar9 - 3U)) {
LAB_00ab8a50:
            uVar12 = *puVar21 ^ *puVar20;
            if (uVar12 == 0) goto code_r0x00ab8a5a;
            uVar19 = 0;
            if (uVar12 != 0) {
              for (; (uVar12 >> uVar19 & 1) == 0; uVar19 = uVar19 + 1) {
              }
            }
            iVar11 = (int)puVar21 + ((uVar19 >> 3) - (int)puVar17);
            goto LAB_00ab8a8a;
          }
LAB_00ab8a67:
          if ((puVar21 < (uint *)((int)puVar9 - 1U)) && (*(short *)puVar20 == *(short *)puVar21)) {
            puVar21 = (uint *)((int)puVar21 + 2);
            puVar20 = (uint *)((int)puVar20 + 2);
          }
          if ((puVar21 < puVar9) && (*(char *)puVar20 == *(char *)puVar21)) {
            puVar21 = (uint *)((int)puVar21 + 1);
          }
          iVar11 = (int)puVar21 - (int)puVar17;
LAB_00ab8a8a:
          iVar11 = iVar11 + 8;
          uStack_34 = (int)puVar22 - (int)puVar23;
          puVar20 = puVar22;
          if (puVar25 < puVar22 && (uint *)(uVar14 + iVar3) < puVar23) {
            do {
              puVar23 = (uint *)((int)puVar23 + -1);
              if (*(char *)((int)puVar20 - 1) != *(char *)puVar23) break;
              puVar20 = (uint *)((int)puVar20 - 1);
              iVar11 = iVar11 + 1;
            } while (puVar25 < puVar20 && (uint *)(uVar14 + iVar3) < puVar23);
          }
LAB_00ab8c23:
          uStack_20 = uStack_34;
          uVar12 = (int)puVar20 - (int)puVar25;
          puVar17 = *(uint **)(param_1 + 0x17c);
          puVar23 = (uint *)(uVar12 + (int)puVar17);
          do {
            *puVar17 = *puVar25;
            puVar17[1] = puVar25[1];
            puVar17 = puVar17 + 2;
            puVar25 = puVar25 + 2;
          } while (puVar17 < puVar23);
          *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar12;
          if (0xffff < uVar12) {
            *(undefined4 *)(param_1 + 0x18c) = 1;
            *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
          }
          *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar12;
          **(int **)(param_1 + 0x174) = uStack_34 + 3;
          uStack_28 = uVar7;
          goto LAB_00ab8c9f;
        }
        if ((uVar14 < uVar19) && (*puVar17 == *puVar22)) {
          FUN_016f39b0(*puVar20,*(undefined4 *)((int)puVar22 + 5),0xb7a56463,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          uVar12 = *(uint *)(iVar2 + iVar11 * 4);
          puVar23 = (uint *)(iVar3 + uVar12);
          *(int *)(iVar2 + iVar11 * 4) = iVar24 + 1;
          if ((uVar14 < uVar12) &&
             ((*puVar23 == *puVar20 && (puVar23[1] == *(uint *)((int)puVar22 + 5))))) {
            iVar11 = FUN_00abcfb0((int)puVar22 + 9,puVar23 + 2,puVar9);
            iVar11 = iVar11 + 8;
            uStack_34 = (int)puVar20 - (int)puVar23;
            if (puVar25 < puVar20 && (uint *)(uVar14 + iVar3) < puVar23) {
              do {
                puVar23 = (uint *)((int)puVar23 + -1);
                if (*(char *)((int)puVar20 - 1) != *(char *)puVar23) break;
                puVar20 = (uint *)((int)puVar20 - 1);
                iVar11 = iVar11 + 1;
              } while (puVar25 < puVar20 && (uint *)(uVar14 + iVar3) < puVar23);
            }
          }
          else {
            iVar11 = FUN_00abcfb0(puVar22 + 1,puVar17 + 1,puVar9);
            iVar11 = iVar11 + 4;
            uStack_34 = (int)puVar22 - (int)puVar17;
            puVar20 = puVar22;
            if (puVar25 < puVar22 && (uint *)(uVar14 + iVar3) < puVar17) {
              do {
                puVar17 = (uint *)((int)puVar17 + -1);
                if (*(char *)((int)puVar20 - 1) != *(char *)puVar17) break;
                puVar20 = (uint *)((int)puVar20 - 1);
                iVar11 = iVar11 + 1;
              } while (puVar25 < puVar20 && (uint *)(uVar14 + iVar3) < puVar17);
            }
          }
          goto LAB_00ab8c23;
        }
        puVar20 = (uint *)((int)puVar22 + ((int)puVar22 - (int)param_2 >> 8) + 1);
      }
      else {
        puVar23 = (uint *)((int)puVar22 + 5);
        puVar17 = (uint *)((int)puVar22 + (5 - uVar7));
        puVar25 = puVar23;
        if (puVar23 < (uint *)((int)puVar9 - 3U)) {
LAB_00ab8950:
          uVar12 = *puVar25 ^ *puVar17;
          if (uVar12 == 0) goto code_r0x00ab895a;
          uVar19 = 0;
          if (uVar12 != 0) {
            for (; (uVar12 >> uVar19 & 1) == 0; uVar19 = uVar19 + 1) {
            }
          }
          iVar11 = ((uVar19 >> 3) - (int)puVar23) + (int)puVar25;
          goto LAB_00ab8989;
        }
LAB_00ab8964:
        if ((puVar25 < (uint *)((int)puVar9 - 1U)) && (*(short *)puVar17 == *(short *)puVar25)) {
          puVar25 = (uint *)((int)puVar25 + 2);
          puVar17 = (uint *)((int)puVar17 + 2);
        }
        if ((puVar25 < puVar9) && (*(char *)puVar17 == *(char *)puVar25)) {
          puVar25 = (uint *)((int)puVar25 + 1);
        }
        iVar11 = (int)puVar25 - (int)puVar23;
LAB_00ab8989:
        iVar11 = iVar11 + 4;
        uVar12 = (int)puVar20 - (int)param_2;
        puVar25 = *(uint **)(param_1 + 0x17c);
        puVar17 = (uint *)(uVar12 + (int)puVar25);
        do {
          *puVar25 = *param_2;
          puVar25[1] = param_2[1];
          puVar25 = puVar25 + 2;
          param_2 = param_2 + 2;
        } while (puVar25 < puVar17);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar12;
        iVar16 = *(int *)(param_1 + 0x174);
        if (0xffff < uVar12) {
          *(int *)(param_1 + 400) = iVar16 - *piVar1 >> 3;
          iVar16 = *(int *)(param_1 + 0x174);
          *(undefined4 *)(param_1 + 0x18c) = 1;
        }
        *(short *)(iVar16 + 4) = (short)uVar12;
        **(undefined4 **)(param_1 + 0x174) = 1;
        uStack_20 = uVar7;
LAB_00ab8c9f:
        if (iVar11 - 3U < 0x10000) {
          iVar16 = *(int *)(param_1 + 0x174);
        }
        else {
          iVar16 = *(int *)(param_1 + 0x174);
          *(int *)(param_1 + 400) = iVar16 - *piVar1 >> 3;
          *(undefined4 *)(param_1 + 0x18c) = 2;
        }
        *(short *)(iVar16 + 6) = (short)iVar11 + -3;
        param_2 = (uint *)((int)puVar20 + iVar11);
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        puVar20 = param_2;
        uVar7 = uStack_20;
        puVar25 = param_2;
        if (param_2 <= puVar10) {
          FUN_016f39b0(*(undefined4 *)((int)puVar22 + 2),*(undefined4 *)((int)puVar22 + 6),
                       0xbfa56300,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar5 + iVar11 * 4) = iVar24 + 2;
          FUN_016f39b0(*(undefined4 *)((int)puVar22 + 2),*(undefined4 *)((int)puVar22 + 6),
                       0xb7a56463,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar2 + iVar11 * 4) = iVar24 + 2;
          iVar16 = (int)param_2 + (-2 - iVar3);
          FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),
                       0xbfa56300,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar5 + iVar11 * 4) = iVar16;
          FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),
                       0xb7a56463,0xcf1bbcdc);
          iVar11 = FUN_016f4650();
          *(int *)(iVar2 + iVar11 * 4) = iVar16;
          do {
            uVar19 = uStack_20;
            uVar12 = uStack_28;
            puVar20 = param_2;
            uVar7 = uStack_20;
            puVar25 = param_2;
            if (uStack_28 == 0 || *param_2 != *(uint *)((int)param_2 - uStack_28)) break;
            iVar11 = FUN_00abcfb0(param_2 + 1,(uint *)((int)param_2 - uStack_28) + 1,puVar9);
            uStack_28 = uStack_20;
            uStack_20 = uVar12;
            iVar16 = FUN_00abd760(param_2,uVar6,7);
            *(int *)(iVar5 + iVar16 * 4) = (int)param_2 - iVar3;
            iVar16 = FUN_00abd760(param_2,uVar4,8);
            *(int *)(iVar2 + iVar16 * 4) = (int)param_2 - iVar3;
            FUN_00abd980(param_1 + 0x170,0,param_2,0,iVar11 + 1);
            param_2 = (uint *)((int)param_2 + iVar11 + 4);
            puVar20 = param_2;
            uVar7 = uVar12;
            puVar25 = param_2;
          } while (param_2 <= puVar10);
        }
      }
      goto joined_r0x00ab8863;
    }
    uVar14 = uVar18;
    if (uVar7 != 0) {
      uVar14 = uVar7;
    }
  }
  *(uint *)(param_1 + 0x1a0) = uVar14;
  if (uStack_28 != 0) {
    uVar18 = uStack_28;
  }
  *(uint *)(param_1 + 0x1a4) = uVar18;
  return (int)puVar9 - (int)param_2;
code_r0x00ab96ac:
  puVar21 = puVar21 + 1;
  puVar20 = puVar20 + 1;
  if ((uint *)((int)puVar9 - 3U) <= puVar21) goto LAB_00ab96b9;
  goto LAB_00ab96a2;
code_r0x00ab95a0:
  puVar25 = puVar25 + 1;
  puVar17 = puVar17 + 1;
  if ((uint *)((int)puVar9 - 3U) <= puVar25) goto LAB_00ab95aa;
  goto LAB_00ab9596;
code_r0x00ab907a:
  puVar21 = puVar21 + 1;
  puVar20 = puVar20 + 1;
  if ((uint *)((int)puVar9 - 3U) <= puVar21) goto LAB_00ab9087;
  goto LAB_00ab9070;
code_r0x00ab8f7a:
  puVar25 = puVar25 + 1;
  puVar17 = puVar17 + 1;
  if ((uint *)((int)puVar9 - 3U) <= puVar25) goto LAB_00ab8f84;
  goto LAB_00ab8f70;
code_r0x00ab842a:
  puVar22 = puVar22 + 1;
  puVar17 = puVar17 + 1;
  if ((uint *)((int)puVar9 - 3U) <= puVar22) goto LAB_00ab8437;
  goto LAB_00ab8420;
code_r0x00ab831a:
  puVar17 = puVar17 + 1;
  puVar23 = puVar23 + 1;
  if ((uint *)((int)puVar9 - 3U) <= puVar17) goto LAB_00ab8324;
  goto LAB_00ab8310;
code_r0x00ab8a5a:
  puVar21 = puVar21 + 1;
  puVar20 = puVar20 + 1;
  if ((uint *)((int)puVar9 - 3U) <= puVar21) goto LAB_00ab8a67;
  goto LAB_00ab8a50;
code_r0x00ab895a:
  puVar25 = puVar25 + 1;
  puVar17 = puVar17 + 1;
  if ((uint *)((int)puVar9 - 3U) <= puVar25) goto LAB_00ab8964;
  goto LAB_00ab8950;
}



/* FUNCTION 22074 ; VA 0x00ab9ae0 ; FUN_00ab9ae0 */

void FUN_00ab9ae0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xa0);
  if (iVar1 == 5) {
    FUN_00aa95c0(param_1,param_2,param_3,5);
    return;
  }
  if (iVar1 != 6) {
    if (iVar1 != 7) {
      FUN_00aa95c0(param_1,param_2,param_3,4);
      return;
    }
    FUN_00aa95c0(param_1,param_2,param_3,7);
    return;
  }
  FUN_00aa95c0(param_1,param_2,param_3,6);
  return;
}



/* FUNCTION 22075 ; VA 0x00ab9b50 ; FUN_00ab9b50 */

int FUN_00ab9b50(int param_1,uint *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  byte bVar13;
  uint *puVar14;
  uint uVar15;
  uint uVar16;
  uint *puVar17;
  uint *puVar18;
  uint *puVar19;
  uint uStack_48;
  uint uStack_40;
  uint uStack_30;
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  
  iVar2 = *(int *)(param_1 + 0x210);
  piVar1 = (int *)(param_1 + 0x170);
  iVar3 = *(int *)(param_1 + 4);
  uVar4 = *(undefined4 *)(param_1 + 0x98);
  uVar12 = *(uint *)(param_1 + 0xc);
  puVar5 = (uint *)(param_3 + (int)param_2);
  iVar10 = *(int *)(param_1 + 0xa0);
  if (iVar10 == 5) {
    uVar9 = *(uint *)(param_1 + 0x198);
    puVar6 = puVar5 + -2;
    uVar8 = *(uint *)(param_1 + 0x194);
    puVar7 = (uint *)((uint)(param_2 == (uint *)(uVar12 + iVar3)) + (int)param_2);
    uVar16 = (int)puVar7 - (int)(uVar12 + iVar3);
    uStack_24 = 0;
    if (uVar9 <= uVar16) {
      uStack_24 = uVar9;
    }
    uVar15 = uVar8;
    if (uVar8 <= uVar16) {
      uVar15 = -(uint)(uVar16 < uVar9) & uVar9;
    }
    uVar9 = 0;
    if (uVar8 <= uVar16) {
      uVar9 = uVar8;
    }
joined_r0x00aba8b8:
    puVar18 = puVar7;
    if (puVar18 < puVar6) {
      FUN_016f39b0(*puVar18,puVar18[1],0xbb000000,0xcf1bbcdc);
      iVar10 = FUN_016f4650();
      uVar8 = *(uint *)(iVar2 + iVar10 * 4);
      puVar19 = (uint *)(iVar3 + uVar8);
      *(int *)(iVar2 + iVar10 * 4) = (int)puVar18 - iVar3;
      puVar7 = (uint *)((int)puVar18 + 1);
      if (uVar9 == 0 || *(uint *)((int)puVar18 + (1 - uVar9)) != *puVar7) {
        if ((uVar12 < uVar8) && (*puVar19 == *puVar18)) {
          puVar7 = puVar18 + 1;
          puVar17 = puVar19 + 1;
          puVar14 = puVar7;
          if (puVar7 < (uint *)((int)puVar5 - 3U)) {
LAB_00abaa47:
            uVar8 = *puVar14 ^ *puVar17;
            if (uVar8 == 0) goto code_r0x00abaa57;
            uVar16 = 0;
            if (uVar8 != 0) {
              for (; (uVar8 >> uVar16 & 1) == 0; uVar16 = uVar16 + 1) {
              }
            }
            iStack_28 = ((uVar16 >> 3) - (int)puVar7) + (int)puVar14;
            goto LAB_00abaa85;
          }
LAB_00abaa61:
          if ((puVar14 < (uint *)((int)puVar5 + -1)) && (*(short *)puVar17 == *(short *)puVar14)) {
            puVar14 = (uint *)((int)puVar14 + 2);
            puVar17 = (uint *)((int)puVar17 + 2);
          }
          if ((puVar14 < puVar5) && (*(char *)puVar17 == *(char *)puVar14)) {
            puVar14 = (uint *)((int)puVar14 + 1);
          }
          iStack_28 = (int)puVar14 - (int)puVar7;
LAB_00abaa85:
          iStack_28 = iStack_28 + 4;
          uStack_20 = (int)puVar18 - (int)puVar19;
          puVar7 = puVar18;
          if (param_2 < puVar18 && (uint *)(uVar12 + iVar3) < puVar19) {
            do {
              puVar19 = (uint *)((int)puVar19 + -1);
              if (*(char *)((int)puVar7 + -1) != *(char *)puVar19) break;
              puVar7 = (uint *)((int)puVar7 + -1);
              iStack_28 = iStack_28 + 1;
            } while ((uint *)(uVar12 + iVar3) < puVar19 && param_2 < puVar7);
          }
          puVar14 = *(uint **)(param_1 + 0x17c);
          uStack_48 = iStack_28 - 3;
          uVar8 = (int)puVar7 - (int)param_2;
          puVar19 = (uint *)((int)puVar14 + uVar8);
          do {
            *puVar14 = *param_2;
            puVar14[1] = param_2[1];
            puVar14 = puVar14 + 2;
            param_2 = param_2 + 2;
          } while (puVar14 < puVar19);
          *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar8;
          if (0xffff < uVar8) {
            *(undefined4 *)(param_1 + 0x18c) = 1;
            *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
          }
          *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar8;
          **(int **)(param_1 + 0x174) = uStack_20 + 3;
          uStack_24 = uVar9;
          goto LAB_00abab52;
        }
        puVar7 = (uint *)((int)puVar18 + ((int)puVar18 - (int)param_2 >> 8) + 1);
      }
      else {
        puVar17 = (uint *)((int)puVar18 + 5);
        puVar14 = (uint *)((int)puVar18 + (5 - uVar9));
        puVar19 = puVar17;
        if (puVar17 < (uint *)((int)puVar5 - 3U)) {
LAB_00aba956:
          uVar8 = *puVar14 ^ *puVar19;
          if (uVar8 == 0) goto code_r0x00aba960;
          uVar16 = 0;
          if (uVar8 != 0) {
            for (; (uVar8 >> uVar16 & 1) == 0; uVar16 = uVar16 + 1) {
            }
          }
          iVar10 = ((uVar16 >> 3) - (int)puVar17) + (int)puVar19;
          goto LAB_00aba992;
        }
LAB_00aba96d:
        if ((puVar19 < (uint *)((int)puVar5 - 1U)) && (*(short *)puVar14 == *(short *)puVar19)) {
          puVar19 = (uint *)((int)puVar19 + 2);
          puVar14 = (uint *)((int)puVar14 + 2);
        }
        if ((puVar19 < puVar5) && (*(char *)puVar14 == *(char *)puVar19)) {
          puVar19 = (uint *)((int)puVar19 + 1);
        }
        iVar10 = (int)puVar19 - (int)puVar17;
LAB_00aba992:
        iStack_28 = iVar10 + 4;
        puVar14 = *(uint **)(param_1 + 0x17c);
        uStack_48 = iVar10 + 1;
        uVar8 = (int)puVar7 - (int)param_2;
        puVar19 = (uint *)((int)puVar14 + uVar8);
        do {
          *puVar14 = *param_2;
          puVar14[1] = param_2[1];
          puVar14 = puVar14 + 2;
          param_2 = param_2 + 2;
        } while (puVar14 < puVar19);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar8;
        if (0xffff < uVar8) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar8;
        **(undefined4 **)(param_1 + 0x174) = 1;
        uStack_20 = uVar9;
LAB_00abab52:
        if (uStack_48 < 0x10000) {
          iVar10 = *(int *)(param_1 + 0x174);
        }
        else {
          iVar10 = *(int *)(param_1 + 0x174);
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = iVar10 - *piVar1 >> 3;
        }
        param_2 = (uint *)((int)puVar7 + iStack_28);
        *(short *)(iVar10 + 6) = (short)uStack_48;
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        puVar7 = param_2;
        uVar9 = uStack_20;
        if (param_2 <= puVar6) {
          FUN_016f39b0(*(undefined4 *)((int)puVar18 + 2),*(undefined4 *)((int)puVar18 + 6),
                       0xbb000000,0xcf1bbcdc);
          iVar10 = FUN_016f4650();
          *(int *)(iVar2 + iVar10 * 4) = ((int)puVar18 - iVar3) + 2;
          FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),
                       0xbb000000,0xcf1bbcdc);
          iVar10 = FUN_016f4650();
          *(int *)(iVar2 + iVar10 * 4) = (int)param_2 + (-2 - iVar3);
          do {
            uVar9 = uStack_20;
            uVar8 = uStack_24;
            puVar7 = param_2;
            if (uStack_24 == 0 || *param_2 != *(uint *)((int)param_2 - uStack_24)) break;
            iVar10 = FUN_00abcfb0(param_2 + 1,(uint *)((int)param_2 - uStack_24) + 1,puVar5);
            uStack_24 = uStack_20;
            uStack_20 = uVar8;
            FUN_016f39b0(*param_2,param_2[1],0xbb000000,0xcf1bbcdc);
            iVar11 = FUN_016f4650();
            *(int *)(iVar2 + iVar11 * 4) = (int)param_2 - iVar3;
            FUN_00abd980(piVar1,0,param_2,0,iVar10 + 1);
            param_2 = (uint *)((int)param_2 + iVar10 + 4);
            puVar7 = param_2;
            uVar9 = uVar8;
          } while (param_2 <= puVar6);
        }
      }
      goto joined_r0x00aba8b8;
    }
  }
  else if (iVar10 == 6) {
    uVar9 = *(uint *)(param_1 + 0x198);
    puVar6 = puVar5 + -2;
    uVar8 = *(uint *)(param_1 + 0x194);
    puVar7 = (uint *)((uint)(param_2 == (uint *)(uVar12 + iVar3)) + (int)param_2);
    uVar16 = (int)puVar7 - (int)(uVar12 + iVar3);
    uStack_24 = 0;
    if (uVar9 <= uVar16) {
      uStack_24 = uVar9;
    }
    uVar15 = uVar8;
    if (uVar8 <= uVar16) {
      uVar15 = -(uint)(uVar16 < uVar9) & uVar9;
    }
    uVar9 = 0;
    if (uVar8 <= uVar16) {
      uVar9 = uVar8;
    }
joined_r0x00aba457:
    puVar18 = puVar7;
    if (puVar18 < puVar6) {
      FUN_016f39b0(*puVar18,puVar18[1],0xbf9b0000,0xcf1bbcdc);
      iVar10 = FUN_016f4650();
      uVar8 = *(uint *)(iVar2 + iVar10 * 4);
      puVar19 = (uint *)(iVar3 + uVar8);
      *(int *)(iVar2 + iVar10 * 4) = (int)puVar18 - iVar3;
      puVar7 = (uint *)((int)puVar18 + 1);
      if (uVar9 == 0 || *(uint *)((int)puVar18 + (1 - uVar9)) != *puVar7) {
        if ((uVar12 < uVar8) && (*puVar19 == *puVar18)) {
          puVar7 = puVar18 + 1;
          puVar17 = puVar19 + 1;
          puVar14 = puVar7;
          if (puVar7 < (uint *)((int)puVar5 - 3U)) {
LAB_00aba5e6:
            uVar8 = *puVar14 ^ *puVar17;
            if (uVar8 == 0) goto code_r0x00aba5f6;
            uVar16 = 0;
            if (uVar8 != 0) {
              for (; (uVar8 >> uVar16 & 1) == 0; uVar16 = uVar16 + 1) {
              }
            }
            iStack_28 = ((uVar16 >> 3) - (int)puVar7) + (int)puVar14;
            goto LAB_00aba624;
          }
LAB_00aba600:
          if ((puVar14 < (uint *)((int)puVar5 + -1)) && (*(short *)puVar17 == *(short *)puVar14)) {
            puVar14 = (uint *)((int)puVar14 + 2);
            puVar17 = (uint *)((int)puVar17 + 2);
          }
          if ((puVar14 < puVar5) && (*(char *)puVar17 == *(char *)puVar14)) {
            puVar14 = (uint *)((int)puVar14 + 1);
          }
          iStack_28 = (int)puVar14 - (int)puVar7;
LAB_00aba624:
          iStack_28 = iStack_28 + 4;
          uStack_20 = (int)puVar18 - (int)puVar19;
          puVar7 = puVar18;
          if (param_2 < puVar18 && (uint *)(uVar12 + iVar3) < puVar19) {
            do {
              puVar19 = (uint *)((int)puVar19 + -1);
              if (*(char *)((int)puVar7 + -1) != *(char *)puVar19) break;
              puVar7 = (uint *)((int)puVar7 + -1);
              iStack_28 = iStack_28 + 1;
            } while ((uint *)(uVar12 + iVar3) < puVar19 && param_2 < puVar7);
          }
          puVar14 = *(uint **)(param_1 + 0x17c);
          uStack_48 = iStack_28 - 3;
          uVar8 = (int)puVar7 - (int)param_2;
          puVar19 = (uint *)((int)puVar14 + uVar8);
          do {
            *puVar14 = *param_2;
            puVar14[1] = param_2[1];
            puVar14 = puVar14 + 2;
            param_2 = param_2 + 2;
          } while (puVar14 < puVar19);
          *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar8;
          if (0xffff < uVar8) {
            *(undefined4 *)(param_1 + 0x18c) = 1;
            *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
          }
          *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar8;
          **(int **)(param_1 + 0x174) = uStack_20 + 3;
          uStack_24 = uVar9;
          goto LAB_00aba6f1;
        }
        puVar7 = (uint *)((int)puVar18 + ((int)puVar18 - (int)param_2 >> 8) + 1);
      }
      else {
        puVar17 = (uint *)((int)puVar18 + 5);
        puVar14 = (uint *)((int)puVar18 + (5 - uVar9));
        puVar19 = puVar17;
        if (puVar17 < (uint *)((int)puVar5 - 3U)) {
LAB_00aba4f5:
          uVar8 = *puVar19 ^ *puVar14;
          if (uVar8 == 0) goto code_r0x00aba4ff;
          uVar16 = 0;
          if (uVar8 != 0) {
            for (; (uVar8 >> uVar16 & 1) == 0; uVar16 = uVar16 + 1) {
            }
          }
          iVar10 = ((uVar16 >> 3) - (int)puVar17) + (int)puVar19;
          goto LAB_00aba531;
        }
LAB_00aba50c:
        if ((puVar19 < (uint *)((int)puVar5 - 1U)) && (*(short *)puVar14 == *(short *)puVar19)) {
          puVar19 = (uint *)((int)puVar19 + 2);
          puVar14 = (uint *)((int)puVar14 + 2);
        }
        if ((puVar19 < puVar5) && (*(char *)puVar14 == *(char *)puVar19)) {
          puVar19 = (uint *)((int)puVar19 + 1);
        }
        iVar10 = (int)puVar19 - (int)puVar17;
LAB_00aba531:
        iStack_28 = iVar10 + 4;
        puVar14 = *(uint **)(param_1 + 0x17c);
        uStack_48 = iVar10 + 1;
        uVar8 = (int)puVar7 - (int)param_2;
        puVar19 = (uint *)((int)puVar14 + uVar8);
        do {
          *puVar14 = *param_2;
          puVar14[1] = param_2[1];
          puVar14 = puVar14 + 2;
          param_2 = param_2 + 2;
        } while (puVar14 < puVar19);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar8;
        if (0xffff < uVar8) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar8;
        **(undefined4 **)(param_1 + 0x174) = 1;
        uStack_20 = uVar9;
LAB_00aba6f1:
        if (uStack_48 < 0x10000) {
          iVar10 = *(int *)(param_1 + 0x174);
        }
        else {
          iVar10 = *(int *)(param_1 + 0x174);
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = iVar10 - *piVar1 >> 3;
        }
        param_2 = (uint *)((int)puVar7 + iStack_28);
        *(short *)(iVar10 + 6) = (short)uStack_48;
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        puVar7 = param_2;
        uVar9 = uStack_20;
        if (param_2 <= puVar6) {
          FUN_016f39b0(*(undefined4 *)((int)puVar18 + 2),*(undefined4 *)((int)puVar18 + 6),
                       0xbf9b0000,0xcf1bbcdc);
          iVar10 = FUN_016f4650();
          *(int *)(iVar2 + iVar10 * 4) = ((int)puVar18 - iVar3) + 2;
          FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),
                       0xbf9b0000,0xcf1bbcdc);
          iVar10 = FUN_016f4650();
          *(int *)(iVar2 + iVar10 * 4) = (int)param_2 + (-2 - iVar3);
          do {
            uVar9 = uStack_20;
            uVar8 = uStack_24;
            puVar7 = param_2;
            if (uStack_24 == 0 || *param_2 != *(uint *)((int)param_2 - uStack_24)) break;
            iVar10 = FUN_00abcfb0(param_2 + 1,(uint *)((int)param_2 - uStack_24) + 1,puVar5);
            uStack_24 = uStack_20;
            uStack_20 = uVar8;
            FUN_016f39b0(*param_2,param_2[1],0xbf9b0000,0xcf1bbcdc);
            iVar11 = FUN_016f4650();
            *(int *)(iVar2 + iVar11 * 4) = (int)param_2 - iVar3;
            FUN_00abd980(piVar1,0,param_2,0,iVar10 + 1);
            param_2 = (uint *)((int)param_2 + iVar10 + 4);
            puVar7 = param_2;
            uVar9 = uVar8;
          } while (param_2 <= puVar6);
        }
      }
      goto joined_r0x00aba457;
    }
  }
  else {
    uVar9 = *(uint *)(param_1 + 0x198);
    if (iVar10 != 7) {
      puVar6 = puVar5 + -2;
      uVar8 = *(uint *)(param_1 + 0x194);
      puVar7 = (uint *)((uint)(param_2 == (uint *)(iVar3 + uVar12)) + (int)param_2);
      uVar16 = (int)puVar7 - (uVar12 + iVar3);
      uStack_24 = 0;
      if (uVar9 <= uVar16) {
        uStack_24 = uVar9;
      }
      uVar15 = uVar8;
      if (uVar8 <= uVar16) {
        uVar15 = -(uint)(uVar16 < uVar9) & uVar9;
      }
      uStack_20 = 0;
      if (uVar8 <= uVar16) {
        uStack_20 = uVar8;
      }
      if (puVar7 < puVar6) {
        bVar13 = 0x20 - (char)uVar4;
        do {
          uVar8 = *puVar7 * -0x61c8864f >> (bVar13 & 0x1f);
          uVar9 = *(uint *)(iVar2 + uVar8 * 4);
          puVar19 = (uint *)(iVar3 + uVar9);
          *(int *)(iVar2 + uVar8 * 4) = (int)puVar7 - iVar3;
          puVar18 = (uint *)((int)puVar7 + 1);
          if (uStack_20 == 0 || *(uint *)((int)puVar7 + (1 - uStack_20)) != *puVar18) {
            if ((uVar12 < uVar9) && (*puVar19 == *puVar7)) {
              puVar18 = puVar7 + 1;
              puVar17 = puVar19 + 1;
              puVar14 = puVar18;
              if (puVar18 < (uint *)((int)puVar5 - 3U)) {
LAB_00ab9d84:
                uVar9 = *puVar14 ^ *puVar17;
                if (uVar9 == 0) goto code_r0x00ab9d94;
                uVar8 = 0;
                if (uVar9 != 0) {
                  for (; (uVar9 >> uVar8 & 1) == 0; uVar8 = uVar8 + 1) {
                  }
                }
                iStack_1c = ((uVar8 >> 3) - (int)puVar18) + (int)puVar14;
                goto LAB_00ab9dc2;
              }
LAB_00ab9d9e:
              if ((puVar14 < (uint *)((int)puVar5 + -1)) && (*(short *)puVar17 == *(short *)puVar14)
                 ) {
                puVar14 = (uint *)((int)puVar14 + 2);
                puVar17 = (uint *)((int)puVar17 + 2);
              }
              if ((puVar14 < puVar5) && (*(char *)puVar17 == *(char *)puVar14)) {
                puVar14 = (uint *)((int)puVar14 + 1);
              }
              iStack_1c = (int)puVar14 - (int)puVar18;
LAB_00ab9dc2:
              iStack_1c = iStack_1c + 4;
              uVar9 = (int)puVar7 - (int)puVar19;
              puVar18 = puVar7;
              if (param_2 < puVar7 && (uint *)(uVar12 + iVar3) < puVar19) {
                do {
                  puVar19 = (uint *)((int)puVar19 + -1);
                  if (*(char *)((int)puVar18 + -1) != *(char *)puVar19) break;
                  iStack_1c = iStack_1c + 1;
                  puVar18 = (uint *)((int)puVar18 + -1);
                } while (param_2 < puVar18 && (uint *)(uVar12 + iVar3) < puVar19);
              }
              puVar14 = *(uint **)(param_1 + 0x17c);
              uStack_24 = uStack_20;
              uStack_30 = iStack_1c - 3;
              uVar8 = (int)puVar18 - (int)param_2;
              puVar19 = (uint *)((int)puVar14 + uVar8);
              do {
                *puVar14 = *param_2;
                puVar14[1] = param_2[1];
                puVar14 = puVar14 + 2;
                param_2 = param_2 + 2;
              } while (puVar14 < puVar19);
              *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar8;
              if (0xffff < uVar8) {
                *(undefined4 *)(param_1 + 0x18c) = 1;
                *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
              }
              *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar8;
              **(int **)(param_1 + 0x174) = uVar9 + 3;
              uStack_20 = uVar9;
              goto LAB_00ab9e91;
            }
            puVar18 = (uint *)((int)puVar7 + ((int)puVar7 - (int)param_2 >> 8) + 1);
          }
          else {
            puVar17 = (uint *)((int)puVar7 + 5);
            puVar14 = (uint *)((int)puVar7 + (5 - uStack_20));
            puVar19 = puVar17;
            if (puVar17 < (uint *)((int)puVar5 - 3U)) {
LAB_00ab9c90:
              uVar9 = *puVar19 ^ *puVar14;
              if (uVar9 == 0) goto code_r0x00ab9c9a;
              uVar8 = 0;
              if (uVar9 != 0) {
                for (; (uVar9 >> uVar8 & 1) == 0; uVar8 = uVar8 + 1) {
                }
              }
              iVar10 = ((uVar8 >> 3) - (int)puVar17) + (int)puVar19;
              goto LAB_00ab9ccc;
            }
LAB_00ab9ca7:
            if ((puVar19 < (uint *)((int)puVar5 - 1U)) && (*(short *)puVar14 == *(short *)puVar19))
            {
              puVar19 = (uint *)((int)puVar19 + 2);
              puVar14 = (uint *)((int)puVar14 + 2);
            }
            if ((puVar19 < puVar5) && (*(char *)puVar14 == *(char *)puVar19)) {
              puVar19 = (uint *)((int)puVar19 + 1);
            }
            iVar10 = (int)puVar19 - (int)puVar17;
LAB_00ab9ccc:
            iStack_1c = iVar10 + 4;
            puVar14 = *(uint **)(param_1 + 0x17c);
            uStack_30 = iVar10 + 1;
            uVar9 = (int)puVar18 - (int)param_2;
            puVar19 = (uint *)((int)puVar14 + uVar9);
            do {
              *puVar14 = *param_2;
              puVar14[1] = param_2[1];
              puVar14 = puVar14 + 2;
              param_2 = param_2 + 2;
            } while (puVar14 < puVar19);
            *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar9;
            if (0xffff < uVar9) {
              *(undefined4 *)(param_1 + 0x18c) = 1;
              *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
            }
            *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar9;
            **(undefined4 **)(param_1 + 0x174) = 1;
LAB_00ab9e91:
            if (uStack_30 < 0x10000) {
              iVar10 = *(int *)(param_1 + 0x174);
            }
            else {
              iVar10 = *(int *)(param_1 + 0x174);
              *(undefined4 *)(param_1 + 0x18c) = 2;
              *(int *)(param_1 + 400) = iVar10 - *piVar1 >> 3;
            }
            puVar18 = (uint *)((int)puVar18 + iStack_1c);
            *(short *)(iVar10 + 6) = (short)uStack_30;
            *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
            param_2 = puVar18;
            if (puVar18 <= puVar6) {
              *(int *)(iVar2 + ((uint)(*(int *)((int)puVar7 + 2) * -0x61c8864f) >> (bVar13 & 0x1f))
                               * 4) = ((int)puVar7 - iVar3) + 2;
              *(int *)(iVar2 + ((uint)(*(int *)((int)puVar18 + -2) * -0x61c8864f) >> (bVar13 & 0x1f)
                               ) * 4) = (int)puVar18 + (-2 - iVar3);
              do {
                uVar9 = uStack_24;
                param_2 = puVar18;
                if (uStack_24 == 0 || *puVar18 != *(uint *)((int)puVar18 - uStack_24)) break;
                iVar10 = FUN_00abcfb0(puVar18 + 1,(uint *)((int)puVar18 - uStack_24) + 1,puVar5);
                uStack_24 = uStack_20;
                uStack_20 = uVar9;
                *(int *)(iVar2 + (*puVar18 * -0x61c8864f >> (bVar13 & 0x1f)) * 4) =
                     (int)puVar18 - iVar3;
                FUN_00abd980(piVar1,0,puVar18,0,iVar10 + 1);
                puVar18 = (uint *)((int)puVar18 + iVar10 + 4);
                param_2 = puVar18;
              } while (puVar18 <= puVar6);
            }
          }
          puVar7 = puVar18;
        } while (puVar18 < puVar6);
      }
      uVar12 = uVar15;
      if (uStack_20 != 0) {
        uVar12 = uStack_20;
      }
      *(uint *)(param_1 + 0x1a0) = uVar12;
      goto LAB_00abacd7;
    }
    puVar6 = puVar5 + -2;
    uVar8 = *(uint *)(param_1 + 0x194);
    puVar7 = (uint *)((uint)(param_2 == (uint *)(iVar3 + uVar12)) + (int)param_2);
    uVar16 = (int)puVar7 - (uVar12 + iVar3);
    uStack_24 = 0;
    if (uVar9 <= uVar16) {
      uStack_24 = uVar9;
    }
    uVar15 = uVar8;
    if (uVar8 <= uVar16) {
      uVar15 = -(uint)(uVar16 < uVar9) & uVar9;
    }
    uVar9 = 0;
    if (uVar8 <= uVar16) {
      uVar9 = uVar8;
    }
joined_r0x00aba010:
    puVar18 = puVar7;
    if (puVar18 < puVar6) {
      FUN_016f39b0(*puVar18,puVar18[1],0xbfa56300,0xcf1bbcdc);
      iVar10 = FUN_016f4650();
      uVar8 = *(uint *)(iVar2 + iVar10 * 4);
      puVar19 = (uint *)(iVar3 + uVar8);
      *(int *)(iVar2 + iVar10 * 4) = (int)puVar18 - iVar3;
      puVar7 = (uint *)((int)puVar18 + 1);
      if (uVar9 == 0 || *(uint *)((int)puVar18 + (1 - uVar9)) != *puVar7) {
        if ((uVar12 < uVar8) && (*puVar19 == *puVar18)) {
          puVar7 = puVar18 + 1;
          puVar17 = puVar19 + 1;
          puVar14 = puVar7;
          if (puVar7 < (uint *)((int)puVar5 - 3U)) {
LAB_00aba1a5:
            uVar8 = *puVar14 ^ *puVar17;
            if (uVar8 == 0) goto code_r0x00aba1b5;
            uVar16 = 0;
            if (uVar8 != 0) {
              for (; (uVar8 >> uVar16 & 1) == 0; uVar16 = uVar16 + 1) {
              }
            }
            iStack_28 = ((uVar16 >> 3) - (int)puVar7) + (int)puVar14;
            goto LAB_00aba1e3;
          }
LAB_00aba1bf:
          if ((puVar14 < (uint *)((int)puVar5 + -1)) && (*(short *)puVar17 == *(short *)puVar14)) {
            puVar14 = (uint *)((int)puVar14 + 2);
            puVar17 = (uint *)((int)puVar17 + 2);
          }
          if ((puVar14 < puVar5) && (*(char *)puVar17 == *(char *)puVar14)) {
            puVar14 = (uint *)((int)puVar14 + 1);
          }
          iStack_28 = (int)puVar14 - (int)puVar7;
LAB_00aba1e3:
          iStack_28 = iStack_28 + 4;
          uStack_20 = (int)puVar18 - (int)puVar19;
          puVar7 = puVar18;
          if (param_2 < puVar18 && (uint *)(uVar12 + iVar3) < puVar19) {
            do {
              puVar19 = (uint *)((int)puVar19 + -1);
              if (*(char *)((int)puVar7 + -1) != *(char *)puVar19) break;
              iStack_28 = iStack_28 + 1;
              puVar7 = (uint *)((int)puVar7 + -1);
            } while (param_2 < puVar7 && (uint *)(uVar12 + iVar3) < puVar19);
          }
          puVar14 = *(uint **)(param_1 + 0x17c);
          uStack_40 = iStack_28 - 3;
          uVar8 = (int)puVar7 - (int)param_2;
          puVar19 = (uint *)(uVar8 + (int)puVar14);
          do {
            *puVar14 = *param_2;
            puVar14[1] = param_2[1];
            puVar14 = puVar14 + 2;
            param_2 = param_2 + 2;
          } while (puVar14 < puVar19);
          *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar8;
          if (0xffff < uVar8) {
            *(undefined4 *)(param_1 + 0x18c) = 1;
            *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
          }
          *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar8;
          **(int **)(param_1 + 0x174) = uStack_20 + 3;
          uStack_24 = uVar9;
          goto LAB_00aba2b1;
        }
        puVar7 = (uint *)((int)puVar18 + ((int)puVar18 - (int)param_2 >> 8) + 1);
      }
      else {
        puVar17 = (uint *)((int)puVar18 + 5);
        puVar14 = (uint *)((int)puVar18 + (5 - uVar9));
        puVar19 = puVar17;
        if (puVar17 < (uint *)((int)puVar5 - 3U)) {
LAB_00aba0b4:
          uVar8 = *puVar14 ^ *puVar19;
          if (uVar8 == 0) goto code_r0x00aba0be;
          uVar16 = 0;
          if (uVar8 != 0) {
            for (; (uVar8 >> uVar16 & 1) == 0; uVar16 = uVar16 + 1) {
            }
          }
          iVar10 = ((uVar16 >> 3) - (int)puVar17) + (int)puVar19;
          goto LAB_00aba0f0;
        }
LAB_00aba0cb:
        if ((puVar19 < (uint *)((int)puVar5 - 1U)) && (*(short *)puVar14 == *(short *)puVar19)) {
          puVar19 = (uint *)((int)puVar19 + 2);
          puVar14 = (uint *)((int)puVar14 + 2);
        }
        if ((puVar19 < puVar5) && (*(char *)puVar14 == *(char *)puVar19)) {
          puVar19 = (uint *)((int)puVar19 + 1);
        }
        iVar10 = (int)puVar19 - (int)puVar17;
LAB_00aba0f0:
        iStack_28 = iVar10 + 4;
        puVar14 = *(uint **)(param_1 + 0x17c);
        uStack_40 = iVar10 + 1;
        uVar8 = (int)puVar7 - (int)param_2;
        puVar19 = (uint *)((int)puVar14 + uVar8);
        do {
          *puVar14 = *param_2;
          puVar14[1] = param_2[1];
          puVar14 = puVar14 + 2;
          param_2 = param_2 + 2;
        } while (puVar14 < puVar19);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar8;
        if (0xffff < uVar8) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar8;
        **(undefined4 **)(param_1 + 0x174) = 1;
        uStack_20 = uVar9;
LAB_00aba2b1:
        if (uStack_40 < 0x10000) {
          iVar10 = *(int *)(param_1 + 0x174);
        }
        else {
          iVar10 = *(int *)(param_1 + 0x174);
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = iVar10 - *piVar1 >> 3;
        }
        param_2 = (uint *)((int)puVar7 + iStack_28);
        *(short *)(iVar10 + 6) = (short)uStack_40;
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        puVar7 = param_2;
        uVar9 = uStack_20;
        if (param_2 <= puVar6) {
          FUN_016f39b0(*(undefined4 *)((int)puVar18 + 2),*(undefined4 *)((int)puVar18 + 6),
                       0xbfa56300,0xcf1bbcdc);
          iVar10 = FUN_016f4650();
          *(int *)(iVar2 + iVar10 * 4) = ((int)puVar18 - iVar3) + 2;
          FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),
                       0xbfa56300,0xcf1bbcdc);
          iVar10 = FUN_016f4650();
          *(int *)(iVar2 + iVar10 * 4) = (int)param_2 + (-2 - iVar3);
          do {
            uVar9 = uStack_20;
            uVar8 = uStack_24;
            puVar7 = param_2;
            if (uStack_24 == 0 || *param_2 != *(uint *)((int)param_2 - uStack_24)) break;
            iVar10 = FUN_00abcfb0(param_2 + 1,(uint *)((int)param_2 - uStack_24) + 1,puVar5);
            uStack_24 = uStack_20;
            uStack_20 = uVar8;
            iVar11 = FUN_00abd760(param_2,uVar4,7);
            *(int *)(iVar2 + iVar11 * 4) = (int)param_2 - iVar3;
            FUN_00abd980(piVar1,0,param_2,0,iVar10 + 1);
            param_2 = (uint *)((int)param_2 + iVar10 + 4);
            puVar7 = param_2;
            uVar9 = uVar8;
          } while (param_2 <= puVar6);
        }
      }
      goto joined_r0x00aba010;
    }
  }
  uVar12 = uVar15;
  if (uVar9 != 0) {
    uVar12 = uVar9;
  }
  *(uint *)(param_1 + 0x1a0) = uVar12;
LAB_00abacd7:
  if (uStack_24 != 0) {
    uVar15 = uStack_24;
  }
  *(uint *)(param_1 + 0x1a4) = uVar15;
  return (int)puVar5 - (int)param_2;
code_r0x00abaa57:
  puVar14 = puVar14 + 1;
  puVar17 = puVar17 + 1;
  if ((uint *)((int)puVar5 - 3U) <= puVar14) goto LAB_00abaa61;
  goto LAB_00abaa47;
code_r0x00aba960:
  puVar19 = puVar19 + 1;
  puVar14 = puVar14 + 1;
  if ((uint *)((int)puVar5 - 3U) <= puVar19) goto LAB_00aba96d;
  goto LAB_00aba956;
code_r0x00aba5f6:
  puVar14 = puVar14 + 1;
  puVar17 = puVar17 + 1;
  if ((uint *)((int)puVar5 - 3U) <= puVar14) goto LAB_00aba600;
  goto LAB_00aba5e6;
code_r0x00aba4ff:
  puVar19 = puVar19 + 1;
  puVar14 = puVar14 + 1;
  if ((uint *)((int)puVar5 - 3U) <= puVar19) goto LAB_00aba50c;
  goto LAB_00aba4f5;
code_r0x00ab9d94:
  puVar14 = puVar14 + 1;
  puVar17 = puVar17 + 1;
  if ((uint *)((int)puVar5 - 3U) <= puVar14) goto LAB_00ab9d9e;
  goto LAB_00ab9d84;
code_r0x00ab9c9a:
  puVar19 = puVar19 + 1;
  puVar14 = puVar14 + 1;
  if ((uint *)((int)puVar5 - 3U) <= puVar19) goto LAB_00ab9ca7;
  goto LAB_00ab9c90;
code_r0x00aba1b5:
  puVar14 = puVar14 + 1;
  puVar17 = puVar17 + 1;
  if ((uint *)((int)puVar5 - 3U) <= puVar14) goto LAB_00aba1bf;
  goto LAB_00aba1a5;
code_r0x00aba0be:
  puVar19 = puVar19 + 1;
  puVar14 = puVar14 + 1;
  if ((uint *)((int)puVar5 - 3U) <= puVar19) goto LAB_00aba0cb;
  goto LAB_00aba0b4;
}



/* FUNCTION 22076 ; VA 0x00abacf0 ; FUN_00abacf0 */

void FUN_00abacf0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xa0);
  if (iVar1 == 5) {
    FUN_00aa9e80(param_1,param_2,param_3,5);
    return;
  }
  if (iVar1 != 6) {
    if (iVar1 != 7) {
      FUN_00aa9e80(param_1,param_2,param_3,4);
      return;
    }
    FUN_00aa9e80(param_1,param_2,param_3,7);
    return;
  }
  FUN_00aa9e80(param_1,param_2,param_3,6);
  return;
}



/* FUNCTION 22077 ; VA 0x00abad60 ; FUN_00abad60 */

int FUN_00abad60(int param_1,uint *param_2,uint param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  uint uVar9;
  uint *puVar10;
  uint *puVar11;
  uint *puVar12;
  uint *puVar13;
  int iStack_1c;
  int iStack_18;
  uint *puStack_14;
  char *pcStack_10;
  uint *puStack_c;
  uint *puStack_8;
  
  puStack_8 = (uint *)(param_3 + (int)param_2);
  uVar9 = *(uint *)(param_1 + 0x194);
  puStack_c = puStack_8 + -2;
  uVar4 = *(uint *)(param_1 + 0x198);
  puStack_14 = (uint *)(*(int *)(param_1 + 0xc) + *(int *)(param_1 + 4));
  uVar1 = *(undefined4 *)(param_1 + 0x9c);
  uVar2 = *(undefined4 *)(param_1 + 0xa0);
  puVar10 = (uint *)((uint)(param_2 == puStack_14) + (int)param_2);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  uVar6 = (int)puVar10 - (int)puStack_14;
  uVar3 = 0;
  if (uVar4 <= uVar6) {
    uVar3 = uVar4;
  }
  param_3 = 0;
  if (uVar9 <= uVar6) {
    param_3 = uVar9;
    uVar9 = -(uint)(uVar6 < uVar4) & uVar4;
  }
  puVar13 = param_2;
  param_2 = (uint *)uVar3;
  if (puVar10 < puStack_c) {
    do {
      iStack_18 = 0;
      pcStack_10 = (char *)((int)puVar10 - param_3);
      puVar8 = (uint *)((int)puVar10 + 1);
      if (param_3 == 0 || *puVar8 != *(uint *)((int)pcStack_10 + 1)) {
        iStack_1c = 99999999;
        pcStack_10 = (char *)FUN_00aa8ea0(param_1,puVar10,puStack_8,&iStack_1c,
                                          1 << ((byte)uVar1 & 0x1f),uVar2);
        if ((pcStack_10 != (char *)0x0) && (iStack_18 = iStack_1c, (char *)0x3 < pcStack_10)) {
          if (iStack_1c != 0) {
            if (puVar13 < puVar10) {
              do {
                if ((puVar10 <= (uint *)((int)puStack_14 + iStack_1c + -2)) ||
                   (*(char *)((int)puVar10 + -1) != *(char *)((int)puVar10 + (1 - iStack_1c))))
                break;
                puVar10 = (uint *)((int)puVar10 + -1);
                pcStack_10 = pcStack_10 + 1;
              } while (puVar13 < puVar10);
            }
            param_2 = (uint *)param_3;
            param_3 = iStack_1c - 2;
          }
          goto LAB_00abaf1d;
        }
        puVar10 = (uint *)((int)puVar10 + ((int)puVar10 - (int)puVar13 >> 8) + 1);
      }
      else {
        puVar11 = (uint *)((int)puVar10 + 5);
        puVar7 = (uint *)((int)pcStack_10 + 5);
        puVar12 = puVar11;
        puVar10 = puVar8;
        if (puVar11 < (uint *)((int)puStack_8 + -3)) {
LAB_00abae43:
          uVar4 = *puVar12 ^ *puVar7;
          if (uVar4 == 0) goto code_r0x00abae49;
          uVar3 = 0;
          if (uVar4 != 0) {
            for (; (uVar4 >> uVar3 & 1) == 0; uVar3 = uVar3 + 1) {
            }
          }
          pcStack_10 = (char *)((int)puVar12 + ((uVar3 >> 3) - (int)puVar11) + 4);
          goto LAB_00abaf1d;
        }
LAB_00abae59:
        if ((puVar12 < (uint *)((int)puStack_8 + -1)) && (*(short *)puVar7 == *(short *)puVar12)) {
          puVar12 = (uint *)((int)puVar12 + 2);
          puVar7 = (uint *)((int)puVar7 + 2);
        }
        if ((puVar12 < puStack_8) && (*(char *)puVar7 == *(char *)puVar12)) {
          puVar12 = (uint *)((int)puVar12 + 1);
        }
        pcStack_10 = (char *)((int)puVar12 + (4 - (int)puVar11));
LAB_00abaf1d:
        uVar4 = (int)puVar10 - (int)puVar13;
        puVar8 = *(uint **)(param_1 + 0x17c);
        puVar12 = (uint *)(uVar4 + (int)puVar8);
        do {
          *puVar8 = *puVar13;
          puVar8[1] = puVar13[1];
          puVar8 = puVar8 + 2;
          puVar13 = puVar13 + 2;
        } while (puVar8 < puVar12);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar4;
        if (0xffff < uVar4) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar4;
        **(int **)(param_1 + 0x174) = iStack_18 + 1;
        if ((char *)0xffff < pcStack_10 + -3) {
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)(pcStack_10 + -3);
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        puVar10 = (uint *)(pcStack_10 + (int)puVar10);
        puVar13 = puVar10;
        if (puVar10 <= puStack_c) {
          do {
            uVar4 = param_3;
            puVar13 = puVar10;
            if (param_2 == (uint *)0x0 || *puVar10 != *(uint *)((int)puVar10 - (int)param_2)) break;
            iVar5 = FUN_00abcfb0(puVar10 + 1,(uint *)((int)puVar10 - (int)param_2) + 1,puStack_8);
            param_3 = (uint)param_2;
            param_2 = (uint *)uVar4;
            FUN_00abd980(param_1 + 0x170,0,puVar10,0,iVar5 + 1);
            puVar10 = (uint *)((int)puVar10 + iVar5 + 4);
            puVar13 = puVar10;
          } while (puVar10 <= puStack_c);
        }
      }
    } while (puVar10 < puStack_c);
  }
  uVar4 = uVar9;
  if (param_3 != 0) {
    uVar4 = param_3;
  }
  *(uint *)(param_1 + 0x1a0) = uVar4;
  if (param_2 != (uint *)0x0) {
    uVar9 = (uint)param_2;
  }
  *(uint *)(param_1 + 0x1a4) = uVar9;
  return (int)puStack_8 - (int)puVar13;
code_r0x00abae49:
  puVar12 = puVar12 + 1;
  puVar7 = puVar7 + 1;
  if ((uint *)((int)puStack_8 + -3) <= puVar12) goto LAB_00abae59;
  goto LAB_00abae43;
}



/* FUNCTION 22078 ; VA 0x00abb070 ; FUN_00abb070 */

int FUN_00abb070(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  char *pcVar3;
  char *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  char *pcVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  char *pcVar12;
  char *pcVar13;
  int *piVar14;
  char *pcVar15;
  int *piVar16;
  int *piVar17;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  char *pcStack_18;
  int iStack_14;
  int *piStack_10;
  int iStack_c;
  char *pcStack_8;
  
  pcStack_8 = (char *)(param_3 + (int)param_2);
  iStack_20 = *(int *)(param_1 + 4);
  piVar1 = (int *)(param_1 + 0x170);
  piStack_10 = (int *)(pcStack_8 + -8);
  pcVar3 = *(char **)(param_1 + 0xc);
  piStack_24 = (int *)(pcVar3 + iStack_20);
  pcVar4 = *(char **)(param_1 + 0x10);
  iStack_2c = *(int *)(param_1 + 8);
  pcVar7 = pcVar3 + iStack_2c;
  piVar2 = (int *)(pcVar4 + iStack_2c);
  uVar5 = *(undefined4 *)(param_1 + 0x9c);
  uVar6 = *(undefined4 *)(param_1 + 0xa0);
  iStack_c = *(int *)(param_1 + 0x194);
  iStack_14 = *(int *)(param_1 + 0x198);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  piVar16 = (int *)((uint)(param_2 == piStack_24) + (int)param_2);
  piVar17 = param_2;
  if (piVar16 < pcStack_8 + -8) {
    do {
      piStack_1c = (int *)((int)piVar16 + 1);
      iStack_28 = 0;
      pcStack_18 = (char *)((int)piVar16 + (-iStack_20 - iStack_c) + 1);
      iVar8 = iStack_20;
      if (pcStack_18 < pcVar3) {
        iVar8 = iStack_2c;
      }
      if ((pcVar4 < pcStack_18 && (char *)0x2 < pcVar3 + (-1 - (int)pcStack_18)) &&
         (*piStack_1c == *(int *)(pcStack_18 + iVar8))) {
        pcVar15 = (char *)((int)piVar16 + 5);
        piVar16 = (int *)((int)(pcStack_18 + iVar8) + 4);
        pcVar12 = pcStack_8;
        if (pcStack_18 < pcVar3) {
          pcVar12 = pcVar7;
        }
        pcVar13 = pcStack_8;
        if (pcVar12 + ((int)pcVar15 - (int)piVar16) < pcStack_8) {
          pcVar13 = pcVar12 + ((int)pcVar15 - (int)piVar16);
        }
        iVar8 = FUN_00abcfb0(pcVar15,piVar16,pcVar13);
        if ((char *)(iVar8 + (int)piVar16) == pcVar12) {
          iVar9 = FUN_00abcfb0(pcVar15 + iVar8,piStack_24,pcStack_8);
          iVar8 = iVar8 + iVar9;
        }
        pcVar15 = (char *)(iVar8 + 4);
        piVar17 = param_2;
LAB_00abb24d:
        piVar16 = *(int **)(param_1 + 0x17c);
        uVar10 = (int)piStack_1c - (int)piVar17;
        piVar11 = (int *)(uVar10 + (int)piVar16);
        do {
          *piVar16 = *piVar17;
          piVar16[1] = piVar17[1];
          piVar16 = piVar16 + 2;
          piVar17 = piVar17 + 2;
        } while (piVar16 < piVar11);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar10;
        if (0xffff < uVar10) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar10;
        **(int **)(param_1 + 0x174) = iStack_28 + 1;
        if ((char *)0xffff < pcVar15 + -3) {
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *piVar1 >> 3;
        }
        piVar16 = (int *)(pcVar15 + (int)piStack_1c);
        *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)(pcVar15 + -3);
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        piVar17 = piVar16;
        if (piStack_10 < piVar16) break;
        do {
          pcVar15 = (char *)((int)piVar16 + (-iStack_20 - iStack_14));
          iVar8 = iStack_20;
          if (pcVar15 < pcVar3) {
            iVar8 = iStack_2c;
          }
          piVar17 = piVar16;
          param_2 = piVar16;
          if ((pcVar15 <= pcVar4 || pcVar3 + (-1 - (int)pcVar15) < (char *)0x3) ||
             (*piVar16 != *(int *)(pcVar15 + iVar8))) break;
          pcVar12 = pcStack_8;
          if (pcVar15 < pcVar3) {
            pcVar12 = pcVar7;
          }
          iVar9 = FUN_00abd020(piVar16 + 1,pcVar15 + iVar8 + 4,pcStack_8,pcVar12,piStack_24);
          iVar8 = iStack_c;
          iStack_c = iStack_14;
          iStack_14 = iVar8;
          FUN_00abd980(piVar1,0,piVar16,0,iVar9 + 1);
          piVar16 = (int *)((int)piVar16 + iVar9 + 4);
          piVar17 = piVar16;
          param_2 = piVar16;
        } while (piVar16 <= piStack_10);
      }
      else {
        iStack_30 = 99999999;
        pcStack_18 = (char *)FUN_00aa89b0(param_1,piVar16,pcStack_8,&iStack_30,
                                          1 << ((byte)uVar5 & 0x1f),uVar6);
        if ((pcStack_18 != (char *)0x0) && (iStack_28 = iStack_30, (char *)0x3 < pcStack_18)) {
          pcVar15 = pcStack_18;
          piStack_1c = piVar16;
          if (iStack_30 != 0) {
            pcVar15 = (char *)((int)piVar16 + (-iStack_20 - iStack_30) + 2);
            piVar11 = piStack_24;
            if (pcVar15 < pcVar3) {
              piVar11 = piVar2;
            }
            if (piVar17 < piVar16) {
              iVar8 = iStack_2c;
              if (pcVar3 <= pcVar15) {
                iVar8 = iStack_20;
              }
              piVar14 = (int *)(pcVar15 + iVar8);
              do {
                piStack_1c = piVar16;
                if ((piVar14 <= piVar11) ||
                   (piVar16 = (int *)((int)piVar16 - 1),
                   *(char *)piVar16 != *(char *)((int)piVar14 + -1))) break;
                pcStack_18 = pcStack_18 + 1;
                piVar14 = (int *)((int)piVar14 + -1);
                piStack_1c = piVar16;
              } while (piVar17 < piVar16);
            }
            iStack_14 = iStack_c;
            iStack_c = iStack_30 + -2;
            pcVar15 = pcStack_18;
          }
          goto LAB_00abb24d;
        }
        piVar16 = (int *)((int)piVar16 + ((int)piVar16 - (int)piVar17 >> 8) + 1);
      }
    } while (piVar16 < piStack_10);
  }
  *(int *)(param_1 + 0x1a0) = iStack_c;
  *(int *)(param_1 + 0x1a4) = iStack_14;
  return (int)pcStack_8 - (int)piVar17;
}



/* FUNCTION 22079 ; VA 0x00abb3a0 ; FUN_00abb3a0 */

int FUN_00abb3a0(int param_1,uint *param_2,int param_3)

{
  char *pcVar1;
  undefined4 uVar2;
  uint uVar3;
  char *pcVar4;
  int iVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  uint uVar9;
  int iVar10;
  uint *puVar11;
  char *pcVar12;
  uint *puVar13;
  bool bVar14;
  uint *puStack_28;
  int iStack_24;
  uint *puStack_20;
  uint *puStack_1c;
  int iStack_18;
  uint *puStack_14;
  uint uStack_10;
  uint *puStack_c;
  uint uStack_8;
  
  puStack_14 = (uint *)(param_3 + (int)param_2);
  puStack_c = puStack_14 + -2;
  uVar9 = *(uint *)(param_1 + 0x194);
  uVar3 = *(uint *)(param_1 + 0x198);
  puStack_1c = (uint *)(*(int *)(param_1 + 0xc) + *(int *)(param_1 + 4));
  iVar10 = 1 << ((byte)*(undefined4 *)(param_1 + 0x9c) & 0x1f);
  uVar2 = *(undefined4 *)(param_1 + 0xa0);
  puVar11 = (uint *)((uint)(param_2 == puStack_1c) + (int)param_2);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  uVar6 = (int)puVar11 - (int)puStack_1c;
  uStack_10 = 0;
  if (uVar3 <= uVar6) {
    uStack_10 = uVar3;
  }
  uStack_8 = 0;
  if (uVar9 <= uVar6) {
    uStack_8 = uVar9;
    uVar9 = -(uint)(uVar6 < uVar3) & uVar3;
  }
  if (puVar11 < puStack_c) {
    do {
      puVar13 = (uint *)((int)puVar11 + 1);
      pcVar12 = (char *)0x0;
      puStack_28 = (uint *)((int)puVar11 - uStack_8);
      param_3 = 0;
      bVar14 = uStack_8 != 0;
      if (bVar14 && *puVar13 == *(uint *)((int)puStack_28 + 1)) {
        puStack_20 = (uint *)((int)puVar11 + 5);
        puVar8 = (uint *)((int)puStack_28 + 5);
        puVar7 = puStack_20;
        if (puStack_20 < (uint *)((int)puStack_14 + -3)) {
LAB_00abb481:
          uVar3 = *puVar7 ^ *puVar8;
          if (uVar3 == 0) goto code_r0x00abb487;
          uVar6 = 0;
          if (uVar3 != 0) {
            for (; (uVar3 >> uVar6 & 1) == 0; uVar6 = uVar6 + 1) {
            }
          }
          pcVar12 = (char *)(((uVar6 >> 3) - (int)puStack_20) + (int)puVar7);
          goto LAB_00abb4b9;
        }
LAB_00abb491:
        if ((puVar7 < (uint *)((int)puStack_14 + -1)) && (*(short *)puVar8 == *(short *)puVar7)) {
          puVar7 = (uint *)((int)puVar7 + 2);
          puVar8 = (uint *)((int)puVar8 + 2);
        }
        if ((puVar7 < puStack_14) && (*(char *)puVar8 == *(char *)puVar7)) {
          puVar7 = (uint *)((int)puVar7 + 1);
        }
        pcVar12 = (char *)((int)puVar7 - (int)puStack_20);
LAB_00abb4b9:
        pcVar12 = pcVar12 + 4;
      }
      iStack_24 = 99999999;
      pcVar4 = (char *)FUN_00aa8ea0(param_1,puVar11,puStack_14,&iStack_24,iVar10,uVar2);
      if (pcVar12 < pcVar4) {
        param_3 = iStack_24;
        pcVar12 = pcVar4;
        puVar13 = puVar11;
      }
      if (pcVar12 < (char *)0x4) {
        puVar11 = (uint *)((int)puVar11 + ((int)puVar11 - (int)param_2 >> 8) + 1);
      }
      else {
        pcVar4 = pcVar12;
        if (puVar11 < puStack_c) {
          do {
            puVar11 = (uint *)((int)puVar11 + 1);
            puVar7 = (uint *)((int)puStack_28 + 1);
            pcVar4 = pcVar12;
            if ((param_3 != 0) && (bVar14 && *puVar11 == *puVar7)) {
              iVar5 = FUN_00abcfb0(uStack_8 + 4 + (int)puVar7,(int)puStack_28 + 5,puStack_14);
              puStack_20 = (uint *)0x0;
              pcVar1 = (char *)(iVar5 + 4);
              iVar5 = 0x1f;
              if (param_3 + 1U != 0) {
                for (; param_3 + 1U >> iVar5 == 0; iVar5 = iVar5 + -1) {
                }
              }
              if (((char *)0x3 < pcVar1) && (((int)pcVar12 * 3 - iVar5) + 1 < (int)pcVar1 * 3)) {
                param_3 = 0;
                pcVar4 = pcVar1;
                puVar13 = puVar11;
              }
            }
            iStack_18 = 99999999;
            pcVar12 = (char *)FUN_00aa8ea0(param_1,puVar11,puStack_14,&iStack_18,iVar10,uVar2);
            puStack_20 = (uint *)0x1f;
            if (iStack_18 + 1U != 0) {
              for (; iStack_18 + 1U >> (int)puStack_20 == 0;
                  puStack_20 = (uint *)((int)puStack_20 + -1)) {
              }
            }
            iVar5 = 0x1f;
            if (param_3 + 1U != 0) {
              for (; param_3 + 1U >> iVar5 == 0; iVar5 = iVar5 + -1) {
              }
            }
            if ((pcVar12 < &DAT_00000004) ||
               ((int)pcVar12 * 4 - (int)puStack_20 <= ((int)pcVar4 * 4 + 4) - iVar5)) break;
            param_3 = iStack_18;
            pcVar4 = pcVar12;
            puVar13 = puVar11;
            puStack_28 = puVar7;
          } while (puVar11 < puStack_c);
        }
        if (param_3 != 0) {
          if (param_2 < puVar13) {
            do {
              if ((puVar13 <= (uint *)((int)puStack_1c + param_3 + -2)) ||
                 (*(char *)((int)puVar13 + -1) != *(char *)((int)puVar13 + (1 - param_3)))) break;
              puVar13 = (uint *)((int)puVar13 + -1);
              pcVar4 = pcVar4 + 1;
            } while (param_2 < puVar13);
          }
          uStack_10 = uStack_8;
          uStack_8 = param_3 - 2;
        }
        uVar3 = (int)puVar13 - (int)param_2;
        puVar11 = *(uint **)(param_1 + 0x17c);
        puVar7 = (uint *)(uVar3 + (int)puVar11);
        do {
          *puVar11 = *param_2;
          puVar11[1] = param_2[1];
          puVar11 = puVar11 + 2;
          param_2 = param_2 + 2;
        } while (puVar11 < puVar7);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar3;
        if (0xffff < uVar3) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar3;
        **(int **)(param_1 + 0x174) = param_3 + 1;
        if ((char *)0xffff < pcVar4 + -3) {
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)(pcVar4 + -3);
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        puVar11 = (uint *)((int)puVar13 + (int)pcVar4);
        param_2 = puVar11;
        if (puStack_c < puVar11) break;
        do {
          param_2 = puVar11;
          if (uStack_10 == 0 || *puVar11 != *(uint *)((int)puVar11 - uStack_10)) break;
          iVar5 = FUN_00abcfb0(puVar11 + 1,(uint *)((int)puVar11 - uStack_10) + 1,puStack_14);
          uVar3 = uStack_8;
          uStack_8 = uStack_10;
          uStack_10 = uVar3;
          FUN_00abd980(param_1 + 0x170,0,puVar11,0,iVar5 + 1);
          puVar11 = (uint *)((int)puVar11 + iVar5 + 4);
          param_2 = puVar11;
        } while (puVar11 <= puStack_c);
      }
    } while (puVar11 < puStack_c);
  }
  uVar3 = uVar9;
  if (uStack_8 != 0) {
    uVar3 = uStack_8;
  }
  *(uint *)(param_1 + 0x1a0) = uVar3;
  if (uStack_10 != 0) {
    uVar9 = uStack_10;
  }
  *(uint *)(param_1 + 0x1a4) = uVar9;
  return (int)puStack_14 - (int)param_2;
code_r0x00abb487:
  puVar7 = puVar7 + 1;
  puVar8 = puVar8 + 1;
  if ((uint *)((int)puStack_14 + -3) <= puVar7) goto LAB_00abb491;
  goto LAB_00abb481;
}



/* FUNCTION 22080 ; VA 0x00abb780 ; FUN_00abb780 */

int FUN_00abb780(int param_1,uint *param_2,int param_3)

{
  char *pcVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  char *pcVar5;
  int iVar6;
  uint uVar7;
  uint *puVar8;
  uint *puVar9;
  uint uVar10;
  uint *puVar11;
  char *pcVar12;
  int iVar13;
  int iVar14;
  int iStack_3c;
  uint *puStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  int iStack_24;
  uint *puStack_20;
  uint *puStack_1c;
  uint uStack_18;
  uint uStack_14;
  uint *puStack_10;
  uint *puStack_c;
  uint *puStack_8;
  
  puVar3 = (uint *)(param_3 + (int)param_2);
  uVar10 = *(uint *)(param_1 + 0x194);
  puStack_10 = puVar3 + -2;
  uVar4 = *(uint *)(param_1 + 0x198);
  puStack_38 = (uint *)(*(int *)(param_1 + 0xc) + *(int *)(param_1 + 4));
  iStack_30 = 1 << ((byte)*(undefined4 *)(param_1 + 0x9c) & 0x1f);
  uStack_2c = *(undefined4 *)(param_1 + 0xa0);
  puVar11 = (uint *)((uint)(param_2 == puStack_38) + (int)param_2);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  uVar7 = (int)puVar11 - (int)puStack_38;
  uStack_18 = 0;
  if (uVar4 <= uVar7) {
    uStack_18 = uVar4;
  }
  uStack_14 = 0;
  if (uVar10 <= uVar7) {
    uStack_14 = uVar10;
    uVar10 = -(uint)(uVar7 < uVar4) & uVar4;
  }
  if (puVar11 < puStack_10) {
    do {
      pcVar12 = (char *)0x0;
      puStack_8 = (uint *)((int)puVar11 + 1);
      iVar13 = 0;
      puStack_1c = (uint *)((int)puVar11 - uStack_14);
      puStack_c = (uint *)0x0;
      uStack_28 = (uint)(uStack_14 != 0);
      if (uStack_14 != 0 && *puStack_8 == *(uint *)((int)puStack_1c + 1)) {
        puStack_20 = (uint *)((int)puVar11 + 5);
        puVar9 = (uint *)((int)puStack_1c + 5);
        puVar8 = puStack_20;
        if (puStack_20 < (uint *)((int)puVar3 + -3)) {
LAB_00abb862:
          uVar4 = *puVar8 ^ *puVar9;
          if (uVar4 == 0) goto code_r0x00abb868;
          uVar7 = 0;
          if (uVar4 != 0) {
            for (; (uVar4 >> uVar7 & 1) == 0; uVar7 = uVar7 + 1) {
            }
          }
          pcVar12 = (char *)(((uVar7 >> 3) - (int)puStack_20) + (int)puVar8);
          goto LAB_00abb89a;
        }
LAB_00abb872:
        if ((puVar8 < (uint *)((int)puVar3 + -1)) && (*(short *)puVar9 == *(short *)puVar8)) {
          puVar8 = (uint *)((int)puVar8 + 2);
          puVar9 = (uint *)((int)puVar9 + 2);
        }
        if ((puVar8 < puVar3) && (*(char *)puVar9 == *(char *)puVar8)) {
          puVar8 = (uint *)((int)puVar8 + 1);
        }
        pcVar12 = (char *)((int)puVar8 - (int)puStack_20);
LAB_00abb89a:
        pcVar12 = pcVar12 + 4;
      }
      iStack_3c = 99999999;
      pcVar5 = (char *)FUN_00aa8ea0(param_1,puVar11,puVar3,&iStack_3c,iStack_30,uStack_2c);
      if (pcVar12 < pcVar5) {
        puStack_c = (uint *)iStack_3c;
        pcVar12 = pcVar5;
        iVar13 = iStack_3c;
        puStack_8 = puVar11;
      }
      if (pcVar12 < (char *)0x4) {
        puVar11 = (uint *)((int)puVar11 + ((int)puVar11 - (int)param_2 >> 8) + 1);
      }
      else {
        pcVar5 = pcVar12;
        puVar8 = puStack_c;
        if (puVar11 < puStack_10) {
          puStack_20 = puVar11 + 1;
          puStack_c = puStack_1c + 1;
          do {
            puStack_1c = (uint *)((int)puStack_1c + 1);
            puStack_c = (uint *)((int)puStack_c + 1);
            puStack_20 = (uint *)((int)puStack_20 + 1);
            puVar9 = (uint *)((int)puVar11 + 1);
            pcVar5 = pcVar12;
            if ((iVar13 != 0) && ((uStack_28 & *puVar9 == *puStack_1c) != 0)) {
              iVar6 = FUN_00abcfb0(puStack_20,puStack_c,puVar3);
              pcVar1 = (char *)(iVar6 + 4);
              iVar6 = 0x1f;
              if (iVar13 + 1U != 0) {
                for (; iVar13 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                }
              }
              if (((char *)0x3 < pcVar1) && (((int)pcVar12 * 3 - iVar6) + 1 < (int)pcVar1 * 3)) {
                iVar13 = 0;
                pcVar5 = pcVar1;
                puStack_8 = puVar9;
              }
            }
            iStack_24 = 99999999;
            pcVar12 = (char *)FUN_00aa8ea0(param_1,puVar9,puVar3,&iStack_24,iStack_30,uStack_2c);
            iVar6 = 0x1f;
            if (iStack_24 + 1U != 0) {
              for (; iStack_24 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
              }
            }
            iVar2 = 0x1f;
            if (iVar13 + 1U != 0) {
              for (; iVar13 + 1U >> iVar2 == 0; iVar2 = iVar2 + -1) {
              }
            }
            if ((pcVar12 < &DAT_00000004) ||
               (iVar14 = iStack_24, (int)pcVar12 * 4 - iVar6 <= ((int)pcVar5 * 4 - iVar2) + 4)) {
              puVar8 = (uint *)iVar13;
              if (puStack_10 <= puVar9) break;
              puVar9 = (uint *)((int)puVar11 + 2);
              puStack_c = (uint *)((int)puStack_c + 1);
              puStack_1c = (uint *)((int)puStack_1c + 1);
              puStack_20 = (uint *)((int)puStack_20 + 1);
              if ((iVar13 != 0) && ((uStack_28 & *puVar9 == *puStack_1c) != 0)) {
                iVar6 = FUN_00abcfb0(puStack_20,puStack_c,puVar3);
                pcVar12 = (char *)(iVar6 + 4);
                iVar6 = 0x1f;
                if (iVar13 + 1U != 0) {
                  for (; iVar13 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                  }
                }
                if (((char *)0x3 < pcVar12) &&
                   (iVar6 = ((int)pcVar5 * 4 - iVar6) + 1,
                   (int)pcVar12 * 4 - iVar6 != 0 && iVar6 <= (int)pcVar12 * 4)) {
                  iVar13 = 0;
                  pcVar5 = pcVar12;
                  puStack_8 = puVar9;
                }
              }
              iStack_34 = 99999999;
              pcVar12 = (char *)FUN_00aa8ea0(param_1,puVar9,puVar3,&iStack_34,iStack_30,uStack_2c);
              iVar6 = 0x1f;
              if (iStack_34 + 1U != 0) {
                for (; iStack_34 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
                }
              }
              iVar2 = 0x1f;
              if (iVar13 + 1U != 0) {
                for (; iVar13 + 1U >> iVar2 == 0; iVar2 = iVar2 + -1) {
                }
              }
              puVar8 = (uint *)iVar13;
              if ((pcVar12 < &DAT_00000004) ||
                 (iVar14 = iStack_34, (int)pcVar12 * 4 - iVar6 <= ((int)pcVar5 * 4 - iVar2) + 7))
              break;
            }
            puVar11 = puVar9;
            pcVar5 = pcVar12;
            iVar13 = iVar14;
            puVar8 = (uint *)iVar14;
            puStack_8 = puVar9;
          } while (puVar9 < puStack_10);
        }
        puStack_c = puVar8;
        puVar11 = puStack_8;
        if (iVar13 != 0) {
          puVar8 = (uint *)iVar13;
          if (param_2 < puStack_8) {
            do {
              puVar8 = puStack_c;
              if ((puVar11 <= (uint *)((int)puStack_38 + iVar13 + -2)) ||
                 (*(char *)((int)puVar11 + -1) != *(char *)((int)puVar11 + (1 - iVar13)))) break;
              puVar11 = (uint *)((int)puVar11 + -1);
              pcVar5 = pcVar5 + 1;
            } while (param_2 < puVar11);
          }
          uStack_18 = uStack_14;
          uStack_14 = (int)puVar8 - 2;
        }
        uVar4 = (int)puVar11 - (int)param_2;
        puVar8 = *(uint **)(param_1 + 0x17c);
        puVar9 = (uint *)(uVar4 + (int)puVar8);
        do {
          *puVar8 = *param_2;
          puVar8[1] = param_2[1];
          puVar8 = puVar8 + 2;
          param_2 = param_2 + 2;
        } while (puVar8 < puVar9);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar4;
        if (0xffff < uVar4) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar4;
        **(int **)(param_1 + 0x174) = (int)puStack_c + 1;
        if ((char *)0xffff < pcVar5 + -3) {
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)(pcVar5 + -3);
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        puVar11 = (uint *)((int)puVar11 + (int)pcVar5);
        param_2 = puVar11;
        if (puStack_10 < puVar11) break;
        do {
          param_2 = puVar11;
          if (uStack_18 == 0 || *puVar11 != *(uint *)((int)puVar11 - uStack_18)) break;
          iVar13 = FUN_00abcfb0(puVar11 + 1,(uint *)((int)puVar11 - uStack_18) + 1,puVar3);
          uVar4 = uStack_14;
          uStack_14 = uStack_18;
          uStack_18 = uVar4;
          FUN_00abd980(param_1 + 0x170,0,puVar11,0,iVar13 + 1);
          puVar11 = (uint *)((int)puVar11 + iVar13 + 4);
          param_2 = puVar11;
        } while (puVar11 <= puStack_10);
      }
    } while (puVar11 < puStack_10);
  }
  uVar4 = uVar10;
  if (uStack_14 != 0) {
    uVar4 = uStack_14;
  }
  *(uint *)(param_1 + 0x1a0) = uVar4;
  if (uStack_18 != 0) {
    uVar10 = uStack_18;
  }
  *(uint *)(param_1 + 0x1a4) = uVar10;
  return (int)puVar3 - (int)param_2;
code_r0x00abb868:
  puVar8 = puVar8 + 1;
  puVar9 = puVar9 + 1;
  if ((uint *)((int)puVar3 + -3) <= puVar8) goto LAB_00abb872;
  goto LAB_00abb862;
}



/* FUNCTION 22081 ; VA 0x00abbc70 ; FUN_00abbc70 */

int FUN_00abbc70(int param_1,int *param_2,int param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  char *pcVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  int *piVar11;
  int *piVar12;
  uint uStack_50;
  int iStack_4c;
  int *piStack_48;
  int iStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  char *pcStack_34;
  int *piStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  int *piStack_10;
  char *pcStack_c;
  int *piStack_8;
  
  pcStack_c = (char *)(param_3 + (int)param_2);
  iStack_18 = *(int *)(param_1 + 4);
  piStack_14 = (int *)(pcStack_c + -8);
  piStack_48 = (int *)(param_1 + 0x170);
  piStack_10 = *(int **)(param_1 + 0xc);
  piStack_1c = (int *)(iStack_18 + (int)piStack_10);
  piStack_30 = *(int **)(param_1 + 0x10);
  iStack_28 = *(int *)(param_1 + 8);
  pcStack_34 = (char *)((int)piStack_10 + iStack_28);
  piVar2 = (int *)((int)piStack_30 + iStack_28);
  iStack_40 = 1 << ((byte)*(undefined4 *)(param_1 + 0x9c) & 0x1f);
  uStack_3c = *(undefined4 *)(param_1 + 0xa0);
  iStack_20 = *(int *)(param_1 + 0x194);
  iStack_2c = *(int *)(param_1 + 0x198);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  piVar9 = (int *)((uint)(param_2 == piStack_1c) + (int)param_2);
  if (piVar9 < pcStack_c + -8) {
    do {
      piVar11 = (int *)((int)piVar9 + (-iStack_20 - iStack_18));
      uStack_50 = 0;
      param_3 = 0;
      piStack_8 = (int *)((int)piVar9 + 1);
      piStack_24 = (int *)((int)piVar11 + 1);
      iVar3 = iStack_18;
      if (piStack_24 < piStack_10) {
        iVar3 = iStack_28;
      }
      if ((piStack_30 < (int *)((int)piVar11 + 1U) &&
           (char *)0x2 < (char *)((int)piStack_10 + (-1 - (int)((int)piVar11 + 1)))) &&
         (*piStack_8 == *(int *)(iVar3 + (int)piStack_24))) {
        piVar10 = (int *)(iVar3 + (int)piStack_24) + 1;
        pcVar6 = pcStack_c;
        if (piStack_24 < piStack_10) {
          pcVar6 = pcStack_34;
        }
        pcVar7 = pcStack_c;
        if (pcVar6 + (((int)piVar9 + 5) - (int)piVar10) < pcStack_c) {
          pcVar7 = pcVar6 + (((int)piVar9 + 5) - (int)piVar10);
        }
        iVar3 = FUN_00abcfb0((char *)((int)piVar9 + 5),piVar10,pcVar7);
        if ((char *)(iVar3 + (int)piVar10) == pcVar6) {
          iVar4 = FUN_00abcfb0((char *)(iVar3 + 5 + (int)piVar9),piStack_1c,pcStack_c);
          iVar3 = iVar3 + iVar4;
        }
        uStack_50 = iVar3 + 4;
      }
      iStack_4c = 99999999;
      uVar5 = FUN_00aa89b0(param_1,piVar9,pcStack_c,&iStack_4c,iStack_40,uStack_3c);
      if (uStack_50 < uVar5) {
        param_3 = iStack_4c;
        uStack_50 = uVar5;
        piStack_8 = piVar9;
      }
      if (uStack_50 < 4) {
        piVar9 = (int *)((int)piVar9 + ((int)piVar9 - (int)param_2 >> 8) + 1);
      }
      else {
        if (piVar9 < piStack_14) {
          piStack_24 = piVar9 + 1;
          do {
            piStack_24 = (int *)((int)piStack_24 + 1);
            piVar10 = (int *)((int)piVar9 + 1);
            piVar12 = (int *)((int)piVar11 + 1);
            if (param_3 != 0) {
              iVar3 = iStack_18;
              if (piVar12 < piStack_10) {
                iVar3 = iStack_28;
              }
              if ((piStack_30 < piVar12 &&
                   (char *)0x2 < (char *)((int)piStack_10 + (-1 - (int)piVar12))) &&
                 (*piVar10 == *(int *)(iVar3 + (int)piVar12))) {
                pcVar6 = pcStack_c;
                if (piVar12 < piStack_10) {
                  pcVar6 = pcStack_34;
                }
                iVar3 = FUN_00abd020(piStack_24,(char *)(iVar3 + 4 + (int)piVar12),pcStack_c,pcVar6,
                                     piStack_1c);
                uVar5 = iVar3 + 4;
                iVar3 = 0x1f;
                if (param_3 + 1U != 0) {
                  for (; param_3 + 1U >> iVar3 == 0; iVar3 = iVar3 + -1) {
                  }
                }
                if ((3 < uVar5) && ((int)((uStack_50 * 3 - iVar3) + 1) < (int)(uVar5 * 3))) {
                  param_3 = 0;
                  uStack_50 = uVar5;
                  piStack_8 = piVar10;
                }
              }
            }
            iStack_38 = 99999999;
            uVar5 = FUN_00aa89b0(param_1,piVar10,pcStack_c,&iStack_38,iStack_40,uStack_3c);
            iVar3 = 0x1f;
            if (iStack_38 + 1U != 0) {
              for (; iStack_38 + 1U >> iVar3 == 0; iVar3 = iVar3 + -1) {
              }
            }
            uVar1 = param_3 + 1;
            iVar4 = 0x1f;
            if (uVar1 != 0) {
              for (; uVar1 >> iVar4 == 0; iVar4 = iVar4 + -1) {
              }
            }
            if ((uVar5 < 4) ||
               (iVar8 = iStack_38, (int)(uVar5 * 4 - iVar3) <= (int)((uStack_50 * 4 - iVar4) + 4)))
            {
              if (piStack_14 <= piVar10) break;
              piStack_24 = (int *)((int)piStack_24 + 1);
              piVar10 = (int *)((int)piVar9 + 2);
              piVar12 = (int *)((int)piVar11 + 2);
              if (param_3 != 0) {
                iVar3 = iStack_18;
                if (piVar12 < piStack_10) {
                  iVar3 = iStack_28;
                }
                if ((piStack_30 < piVar12 &&
                     (char *)0x2 < (char *)((int)piStack_10 + (-1 - (int)piVar12))) &&
                   (*piVar10 == *(int *)(iVar3 + (int)piVar12))) {
                  pcVar6 = pcStack_c;
                  if (piVar12 < piStack_10) {
                    pcVar6 = pcStack_34;
                  }
                  iVar3 = FUN_00abd020(piStack_24,(char *)(iVar3 + 4 + (int)piVar12),pcStack_c,
                                       pcVar6,piStack_1c);
                  uVar5 = iVar3 + 4;
                  iVar3 = 0x1f;
                  if (uVar1 != 0) {
                    for (; uVar1 >> iVar3 == 0; iVar3 = iVar3 + -1) {
                    }
                  }
                  if ((3 < uVar5) &&
                     (iVar3 = (uStack_50 * 4 - iVar3) + 1,
                     uVar5 * 4 - iVar3 != 0 && iVar3 <= (int)(uVar5 * 4))) {
                    param_3 = 0;
                    uStack_50 = uVar5;
                    piStack_8 = piVar10;
                  }
                }
              }
              iStack_44 = 99999999;
              uVar5 = FUN_00aa89b0(param_1,piVar10,pcStack_c,&iStack_44,iStack_40,uStack_3c);
              iVar3 = 0x1f;
              if (iStack_44 + 1U != 0) {
                for (; iStack_44 + 1U >> iVar3 == 0; iVar3 = iVar3 + -1) {
                }
              }
              iVar4 = 0x1f;
              if (param_3 + 1U != 0) {
                for (; param_3 + 1U >> iVar4 == 0; iVar4 = iVar4 + -1) {
                }
              }
              if ((uVar5 < 4) ||
                 (iVar8 = iStack_44, (int)(uVar5 * 4 - iVar3) <= (int)((uStack_50 * 4 - iVar4) + 7))
                 ) break;
            }
            uStack_50 = uVar5;
            piVar9 = piVar10;
            piVar11 = piVar12;
            param_3 = iVar8;
            piStack_8 = piVar10;
          } while (piVar10 < piStack_14);
        }
        piVar11 = piStack_10;
        if (param_3 != 0) {
          piVar10 = (int *)((int)piStack_8 + (-iStack_18 - param_3) + 2);
          piVar9 = piStack_1c;
          if (piVar10 < piStack_10) {
            piVar9 = piVar2;
          }
          if (param_2 < piStack_8) {
            iVar3 = iStack_28;
            if (piStack_10 <= piVar10) {
              iVar3 = iStack_18;
            }
            piVar10 = (int *)(iVar3 + (int)piVar10);
            do {
              if ((piVar10 <= piVar9) ||
                 (piVar12 = (int *)((int)piStack_8 - 1),
                 *(char *)piVar12 != *(char *)((int)piVar10 + -1))) break;
              piVar10 = (int *)((int)piVar10 + -1);
              uStack_50 = uStack_50 + 1;
              piStack_8 = piVar12;
            } while (param_2 < piVar12);
          }
          iStack_2c = iStack_20;
          iStack_20 = param_3 + -2;
        }
        uVar5 = (int)piStack_8 - (int)param_2;
        piVar10 = *(int **)(param_1 + 0x17c);
        piVar9 = (int *)((int)piVar10 + uVar5);
        do {
          *piVar10 = *param_2;
          piVar10[1] = param_2[1];
          piVar10 = piVar10 + 2;
          param_2 = param_2 + 2;
        } while (piVar10 < piVar9);
        piStack_48[3] = piStack_48[3] + uVar5;
        if (0xffff < uVar5) {
          piStack_48[7] = 1;
          piStack_48[8] = piStack_48[1] - *piStack_48 >> 3;
        }
        *(short *)(piStack_48[1] + 4) = (short)uVar5;
        *(int *)piStack_48[1] = param_3 + 1;
        if (0xffff < uStack_50 - 3) {
          piStack_48[7] = 2;
          piStack_48[8] = piStack_48[1] - *piStack_48 >> 3;
        }
        *(short *)(piStack_48[1] + 6) = (short)(uStack_50 - 3);
        piStack_48[1] = piStack_48[1] + 8;
        param_2 = (int *)((int)piStack_8 + uStack_50);
        if (piStack_14 < param_2) break;
        do {
          piVar10 = (int *)((int)param_2 + (-iStack_18 - iStack_2c));
          iVar3 = iStack_18;
          if (piVar10 < piVar11) {
            iVar3 = iStack_28;
          }
          piVar9 = param_2;
          if ((piVar10 <= piStack_30 || (char *)((int)piVar11 + (-1 - (int)piVar10)) < (char *)0x3)
             || (*param_2 != *(int *)(iVar3 + (int)piVar10))) break;
          pcVar6 = pcStack_c;
          if (piVar10 < piVar11) {
            pcVar6 = pcStack_34;
          }
          iVar4 = FUN_00abd020(param_2 + 1,(char *)((int)piVar10 + iVar3 + 4),pcStack_c,pcVar6,
                               piStack_1c);
          iVar3 = iStack_20;
          iStack_20 = iStack_2c;
          iStack_2c = iVar3;
          FUN_00abd980(piStack_48,0,param_2,0,iVar4 + 1);
          param_2 = (int *)((int)param_2 + iVar4 + 4);
          piVar9 = param_2;
        } while (param_2 <= piStack_14);
      }
    } while (piVar9 < piStack_14);
  }
  piStack_48[0xc] = iStack_20;
  piStack_48[0xd] = iStack_2c;
  return (int)pcStack_c - (int)param_2;
}



/* FUNCTION 22082 ; VA 0x00abc1d0 ; FUN_00abc1d0 */

int FUN_00abc1d0(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  int iStack_40;
  int *piStack_3c;
  uint uStack_38;
  uint uStack_34;
  int iStack_30;
  uint uStack_2c;
  int iStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  int *piStack_10;
  uint uStack_c;
  uint uStack_8;
  
  piStack_3c = (int *)(param_1 + 0x170);
  iStack_1c = *(int *)(param_1 + 4);
  uStack_8 = param_3 + (int)param_2;
  piStack_10 = (int *)(uStack_8 - 8);
  uStack_c = *(uint *)(param_1 + 0xc);
  piStack_20 = (int *)(iStack_1c + uStack_c);
  uStack_34 = *(uint *)(param_1 + 0x10);
  iStack_28 = *(int *)(param_1 + 8);
  uStack_38 = uStack_c + iStack_28;
  piVar1 = (int *)(uStack_34 + iStack_28);
  iVar3 = 1 << ((byte)*(undefined4 *)(param_1 + 0x9c) & 0x1f);
  uVar2 = *(undefined4 *)(param_1 + 0xa0);
  iStack_18 = *(int *)(param_1 + 0x194);
  iStack_24 = *(int *)(param_1 + 0x198);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  piVar9 = (int *)((uint)(param_2 == piStack_20) + (int)param_2);
  if (piVar9 < (int *)(uStack_8 - 8)) {
    do {
      piStack_14 = (int *)((int)piVar9 + 1);
      uVar11 = 0;
      uVar12 = (int)piVar9 + (-iStack_18 - iStack_1c);
      param_3 = 0;
      uStack_2c = uVar12 + 1;
      iVar5 = iStack_1c;
      if (uStack_2c < uStack_c) {
        iVar5 = iStack_28;
      }
      if ((uStack_34 < uVar12 + 1 && 2 < (uStack_c - (uVar12 + 1)) - 1) &&
         (*piStack_14 == *(int *)(iVar5 + uStack_2c))) {
        piVar10 = (int *)(iVar5 + uStack_2c) + 1;
        uVar11 = uStack_8;
        if (uStack_2c < uStack_c) {
          uVar11 = uStack_38;
        }
        uVar4 = (((int)piVar9 + 5) - (int)piVar10) + uVar11;
        uVar7 = uStack_8;
        if (uVar4 < uStack_8) {
          uVar7 = uVar4;
        }
        iVar5 = FUN_00abcfb0((int)piVar9 + 5,piVar10,uVar7);
        if (iVar5 + (int)piVar10 == uVar11) {
          iVar6 = FUN_00abcfb0(iVar5 + 5 + (int)piVar9,piStack_20,uStack_8);
          iVar5 = iVar5 + iVar6;
        }
        uVar11 = iVar5 + 4;
      }
      iStack_40 = 99999999;
      uVar7 = FUN_00aa89b0(param_1,piVar9,uStack_8,&iStack_40,iVar3,uVar2);
      if (uVar11 < uVar7) {
        param_3 = iStack_40;
        uVar11 = uVar7;
        piStack_14 = piVar9;
      }
      if (uVar11 < 4) {
        piVar9 = (int *)((int)piVar9 + ((int)piVar9 - (int)param_2 >> 8) + 1);
      }
      else {
        uVar7 = uVar11;
        if (piVar9 < piStack_10) {
          do {
            piVar10 = (int *)((int)piVar9 + 1);
            uVar12 = uVar12 + 1;
            uVar7 = uVar11;
            if (param_3 != 0) {
              iVar5 = iStack_1c;
              if (uVar12 < uStack_c) {
                iVar5 = iStack_28;
              }
              if ((uStack_34 < uVar12 && 2 < (uStack_c - uVar12) - 1) &&
                 (*piVar10 == *(int *)(iVar5 + uVar12))) {
                uVar4 = uStack_8;
                if (uVar12 < uStack_c) {
                  uVar4 = uStack_38;
                }
                iVar5 = FUN_00abd020((int)piVar9 + 5,iVar5 + 4 + uVar12,uStack_8,uVar4,piStack_20);
                uVar4 = iVar5 + 4;
                iVar5 = 0x1f;
                if (param_3 + 1U != 0) {
                  for (; param_3 + 1U >> iVar5 == 0; iVar5 = iVar5 + -1) {
                  }
                }
                if ((3 < uVar4) && ((int)((uVar11 * 3 - iVar5) + 1) < (int)(uVar4 * 3))) {
                  param_3 = 0;
                  uVar7 = uVar4;
                  piStack_14 = piVar10;
                }
              }
            }
            iStack_30 = 99999999;
            uVar11 = FUN_00aa89b0(param_1,piVar10,uStack_8,&iStack_30,iVar3,uVar2);
            iVar5 = 0x1f;
            if (iStack_30 + 1U != 0) {
              for (; iStack_30 + 1U >> iVar5 == 0; iVar5 = iVar5 + -1) {
              }
            }
            iVar6 = 0x1f;
            if (param_3 + 1U != 0) {
              for (; param_3 + 1U >> iVar6 == 0; iVar6 = iVar6 + -1) {
              }
            }
            if ((uVar11 < 4) || ((int)(uVar11 * 4 - iVar5) <= (int)((uVar7 * 4 + 4) - iVar6)))
            break;
            param_3 = iStack_30;
            piVar9 = piVar10;
            uVar7 = uVar11;
            piStack_14 = piVar10;
          } while (piVar10 < piStack_10);
        }
        uVar11 = uStack_c;
        piVar9 = piStack_14;
        if (param_3 != 0) {
          uVar12 = (int)piStack_14 + (-iStack_1c - param_3) + 2;
          piVar10 = piStack_20;
          if (uVar12 < uStack_c) {
            piVar10 = piVar1;
          }
          if (param_2 < piStack_14) {
            iVar5 = iStack_28;
            if (uStack_c <= uVar12) {
              iVar5 = iStack_1c;
            }
            piVar8 = (int *)(iVar5 + uVar12);
            do {
              if ((piVar8 <= piVar10) ||
                 (*(char *)((int)piVar9 + -1) != *(char *)((int)piVar8 + -1))) break;
              piVar9 = (int *)((int)piVar9 + -1);
              piVar8 = (int *)((int)piVar8 + -1);
              uVar7 = uVar7 + 1;
            } while (param_2 < piVar9);
          }
          iStack_24 = iStack_18;
          iStack_18 = param_3 + -2;
        }
        uVar12 = (int)piVar9 - (int)param_2;
        piVar8 = *(int **)(param_1 + 0x17c);
        piVar10 = (int *)((int)piVar8 + uVar12);
        do {
          *piVar8 = *param_2;
          piVar8[1] = param_2[1];
          piVar8 = piVar8 + 2;
          param_2 = param_2 + 2;
        } while (piVar8 < piVar10);
        piStack_3c[3] = piStack_3c[3] + uVar12;
        if (0xffff < uVar12) {
          piStack_3c[7] = 1;
          piStack_3c[8] = piStack_3c[1] - *piStack_3c >> 3;
        }
        *(short *)(piStack_3c[1] + 4) = (short)uVar12;
        *(int *)piStack_3c[1] = param_3 + 1;
        if (0xffff < uVar7 - 3) {
          piStack_3c[7] = 2;
          piStack_3c[8] = piStack_3c[1] - *piStack_3c >> 3;
        }
        *(short *)(piStack_3c[1] + 6) = (short)(uVar7 - 3);
        piStack_3c[1] = piStack_3c[1] + 8;
        param_2 = (int *)((int)piVar9 + uVar7);
        if (piStack_10 < param_2) break;
        do {
          uVar12 = (int)param_2 + (-iStack_1c - iStack_24);
          iVar5 = iStack_1c;
          if (uVar12 < uVar11) {
            iVar5 = iStack_28;
          }
          piVar9 = param_2;
          if ((uVar12 <= uStack_34 || (uVar11 - uVar12) - 1 < 3) ||
             (*param_2 != *(int *)(iVar5 + uVar12))) break;
          uVar7 = uStack_8;
          if (uVar12 < uVar11) {
            uVar7 = uStack_38;
          }
          iVar6 = FUN_00abd020(param_2 + 1,uVar12 + 4 + iVar5,uStack_8,uVar7,piStack_20);
          iVar5 = iStack_18;
          iStack_18 = iStack_24;
          iStack_24 = iVar5;
          FUN_00abd980(piStack_3c,0,param_2,0,iVar6 + 1);
          param_2 = (int *)((int)param_2 + iVar6 + 4);
          piVar9 = param_2;
        } while (param_2 <= piStack_10);
      }
    } while (piVar9 < piStack_10);
  }
  piStack_3c[0xc] = iStack_18;
  piStack_3c[0xd] = iStack_24;
  return uStack_8 - (int)param_2;
}



/* FUNCTION 22083 ; VA 0x00abc600 ; FUN_00abc600 */

void FUN_00abc600(int param_1,uint *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  code *pcVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined4 uVar10;
  int iVar11;
  int iVar12;
  byte *pbVar13;
  int iVar14;
  uint uVar15;
  uint *puVar16;
  uint uVar17;
  uint uVar18;
  uint *puVar19;
  uint uVar20;
  uint *puVar21;
  uint *puVar22;
  uint *puVar23;
  uint *puVar24;
  undefined4 *puVar25;
  uint uVar26;
  int iVar27;
  uint *puVar28;
  byte *pbVar29;
  uint *puVar30;
  byte *pbVar31;
  uint *puVar32;
  undefined4 uVar33;
  int iVar34;
  longlong lVar35;
  undefined8 uVar36;
  byte *pbStack_70;
  uint uStack_50;
  undefined8 uStack_48;
  byte *pbStack_3c;
  uint *puStack_24;
  uint *puStack_18;
  int iStack_14;
  uint *puStack_10;
  uint *puStack_8;
  
  puStack_18 = (uint *)0x0;
  uVar10 = *(undefined4 *)(param_1 + 0xcc);
  iVar11 = *(int *)(param_1 + 0xd0);
  iVar12 = *(int *)(param_1 + 0xd4);
  pbVar13 = *(byte **)(param_1 + 0xd8);
  uVar2 = *(undefined4 *)(param_1 + 0x20c);
  uVar3 = *(undefined4 *)(param_1 + 0x208);
  uVar26 = *(uint *)(param_1 + 0xdc);
  iVar14 = iVar11 - iVar12;
  iVar4 = *(int *)(param_1 + 4);
  uVar15 = (1 << ((byte)uVar26 & 0x1f)) - 1;
  uVar20 = *(uint *)(param_1 + 0xc);
  puVar21 = (uint *)((int)param_2 + param_3);
  puVar16 = (uint *)(uVar20 + iVar4);
  pbVar31 = &DAT_00000008;
  if (&DAT_00000008 < pbVar13) {
    pbVar31 = pbVar13;
  }
  puVar22 = (uint *)((int)puVar21 - (int)pbVar31);
  puStack_10 = param_2;
  puStack_8 = param_2;
  pcVar5 = (code *)(&PTR_FUN_01948a20)[*(int *)(param_1 + 0xa8)];
  uVar6 = *(undefined4 *)(param_1 + 0x194);
  *(undefined4 *)(param_1 + 0x1a0) = uVar6;
  uVar7 = *(undefined4 *)(param_1 + 0x198);
  *(undefined4 *)(param_1 + 0x1a4) = uVar7;
  uVar8 = *(undefined4 *)(param_1 + 0x19c);
  *(undefined4 *)(param_1 + 0x1a8) = uVar8;
  puVar32 = param_2;
  if (param_2 < puVar22) {
    uStack_48 = 0;
    do {
      pbStack_3c = (byte *)0x0;
      iStack_14 = 0;
      puStack_24 = (uint *)0x0;
      if (puStack_10 == param_2) {
        uStack_48 = FUN_00aae9f0(puStack_10,pbVar13);
      }
      else {
        lVar35 = FUN_016f39b0(*(byte *)puStack_18 + 10,0xfffffff5 < *(byte *)puStack_18,uVar3,uVar2)
        ;
        uVar36 = FUN_016f39b0(uStack_48 - lVar35,0xb7a56463,0xcf1bbcdc);
        uVar17 = (uint)uVar36 + (uint)*(byte *)((int)puStack_18 + (int)pbVar13);
        uStack_48 = CONCAT44((int)((ulonglong)uVar36 >> 0x20) +
                             (uint)CARRY4((uint)uVar36,
                                          (uint)*(byte *)((int)puStack_18 + (int)pbVar13)) +
                             (uint)(0xfffffff5 < uVar17),uVar17 + 10);
      }
      uStack_50 = (uint)uStack_48;
      if (uVar26 <= 0x20U - iVar14) {
        uStack_50 = (uint)(uStack_48 >> (ulonglong)((0x20 - uVar26) - iVar14));
      }
      if ((uVar15 & uStack_50) == uVar15) {
        iVar27 = iVar14;
        if (iVar14 != 0) {
          iVar27 = (int)(uStack_48 >> (ulonglong)(0x40 - iVar14));
        }
        puVar19 = (uint *)(*(int *)(param_1 + 0x200) + (iVar27 << ((byte)iVar12 & 0x1f)) * 8);
        pbStack_70 = (byte *)0x0;
        puVar30 = puVar19 + (1 << ((byte)iVar12 & 0x1f)) * 2;
        if (puVar30 <= puVar19) {
LAB_00abccfe:
          FUN_00aaea60(param_1 + 0x200,uStack_48,iVar14,(int)puStack_10 - iVar4,uVar10,iVar11,iVar12
                       ,pbVar13,uVar26);
          goto LAB_00abcd2e;
        }
        do {
          puVar32 = (uint *)(iVar4 + *puVar19);
          if ((puVar19[1] == (uint)(uStack_48 >> (ulonglong)(0x20U - iVar14))) &&
             (uVar20 < *puVar19)) {
            puVar23 = puStack_10;
            puVar28 = puVar32;
            if (puStack_10 < (uint *)((int)puVar21 + -3)) {
LAB_00abc890:
              uVar17 = *puVar28 ^ *puVar23;
              if (uVar17 == 0) goto code_r0x00abc89a;
              uVar18 = 0;
              if (uVar17 != 0) {
                for (; (uVar17 >> uVar18 & 1) == 0; uVar18 = uVar18 + 1) {
                }
              }
              pbVar31 = (byte *)(((uVar18 >> 3) - (int)puStack_10) + (int)puVar23);
              goto LAB_00abc8ce;
            }
LAB_00abc8a4:
            if ((puVar23 < (uint *)((int)puVar21 + -1)) && (*(short *)puVar28 == *(short *)puVar23))
            {
              puVar23 = (uint *)((int)puVar23 + 2);
              puVar28 = (uint *)((int)puVar28 + 2);
            }
            if ((puVar23 < puVar21) && (*(byte *)puVar28 == *(byte *)puVar23)) {
              puVar23 = (uint *)((int)puVar23 + 1);
            }
            pbVar31 = (byte *)((int)puVar23 - (int)puStack_10);
LAB_00abc8ce:
            if (pbVar13 <= pbVar31) {
              iVar27 = 0;
              if (puStack_8 < puStack_10) {
                puVar28 = puStack_10;
                puVar23 = puVar32;
                do {
                  puVar24 = (uint *)((int)puVar23 + -1);
                  if ((puVar23 <= puVar16) ||
                     (*(byte *)(((int)puStack_10 - (int)puVar32) + (int)puVar24) != *(byte *)puVar24
                     )) break;
                  puVar28 = (uint *)((int)puVar28 + -1);
                  iVar27 = iVar27 + 1;
                  puVar23 = puVar24;
                } while (puStack_8 < puVar28);
              }
              if (pbStack_70 < pbVar31 + iVar27) {
                pbStack_70 = pbVar31 + iVar27;
                pbStack_3c = pbVar31;
                puStack_24 = puVar19;
                iStack_14 = iVar27;
              }
            }
          }
          puVar19 = puVar19 + 2;
        } while (puVar19 < puVar30);
        puVar32 = puStack_8;
        if (puStack_24 == (uint *)0x0) goto LAB_00abccfe;
        pbVar31 = (byte *)((int)puStack_10 + (-iVar4 - *puStack_24));
        *(undefined4 *)(param_1 + 0x194) = *(undefined4 *)(param_1 + 0x1a0);
        *(undefined4 *)(param_1 + 0x198) = *(undefined4 *)(param_1 + 0x1a4);
        *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x1a8);
        uVar17 = (int)puStack_8 - *(int *)(param_1 + 4);
        if (*(int *)(param_1 + 0x14) + 0x400U < uVar17) {
          uVar18 = (uVar17 - *(int *)(param_1 + 0x14)) - 0x400;
          if (0x200 < uVar18) {
            uVar18 = 0x200;
          }
          *(uint *)(param_1 + 0x14) = uVar17 - uVar18;
        }
        if (*(int *)(param_1 + 0xa8) == 1) {
          FUN_00abd420(param_1,puStack_8,*(undefined4 *)(param_1 + 0xa0));
LAB_00abca00:
          *(int *)(param_1 + 0x14) = (int)puStack_8 - *(int *)(param_1 + 4);
        }
        else if (*(int *)(param_1 + 0xa8) == 2) {
          FUN_00abd300(param_1,puStack_8,*(undefined4 *)(param_1 + 0xa0));
          goto LAB_00abca00;
        }
        uVar17 = (*pcVar5)(param_1,puStack_8,
                           (byte *)((int)puStack_10 + (-(int)puStack_8 - iStack_14)));
        *(byte **)(param_1 + 0x14) = (byte *)((int)puStack_10 + (-iVar4 - iStack_14));
        *(undefined4 *)(param_1 + 0x1a8) = *(undefined4 *)(param_1 + 0x1a4);
        *(undefined4 *)(param_1 + 0x1a4) = *(undefined4 *)(param_1 + 0x1a0);
        *(byte **)(param_1 + 0x1a0) = pbVar31;
        puVar25 = *(undefined4 **)(param_1 + 0x17c);
        puVar1 = (undefined4 *)((int)puVar25 + uVar17);
        pbVar29 = (byte *)((int)puStack_10 + (-uVar17 - iStack_14));
        do {
          *puVar25 = *(undefined4 *)pbVar29;
          puVar25[1] = *(undefined4 *)(pbVar29 + 4);
          puVar25 = puVar25 + 2;
          pbVar29 = pbVar29 + 8;
        } while (puVar25 < puVar1);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar17;
        if (0xffff < uVar17) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar17;
        **(undefined4 **)(param_1 + 0x174) = pbVar31 + 3;
        if ((byte *)0xffff < pbStack_3c + iStack_14 + -3) {
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)(pbStack_3c + iStack_14 + -3);
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        uVar33 = uVar10;
        iVar27 = iVar11;
        iVar34 = iVar12;
        pbVar31 = pbVar13;
        FUN_00aaea60(param_1 + 0x200,uStack_48,iVar14,(int)puStack_10 - iVar4,uVar10,iVar11,iVar12,
                     pbVar13,uVar26);
        puVar32 = (uint *)(pbStack_3c + (int)puStack_10);
        if (puVar22 <= puVar32) break;
        uStack_48 = FUN_00aae930(param_1 + 0x200,uStack_48,puStack_10,puVar32,iVar4,iVar14,uVar33,
                                 iVar27,iVar34,pbVar31,uVar26);
        puStack_10 = puVar32;
        while( true ) {
          puStack_18 = (uint *)((int)puStack_10 + -1);
          uVar17 = *(uint *)(param_1 + 0x1a4);
          puVar32 = puStack_10;
          puStack_8 = puStack_10;
          if (((uVar17 == 0) || ((uint)((int)puStack_10 - (int)puVar16) < uVar17)) ||
             (*puStack_10 != *(uint *)((int)puStack_10 - uVar17))) break;
          puVar32 = puStack_10 + 1;
          puVar30 = (uint *)((int)puStack_10 - uVar17) + 1;
          puVar19 = puVar32;
          if (puVar32 < (uint *)((int)puVar21 + -3)) {
LAB_00abcbc0:
            uVar18 = *puVar19 ^ *puVar30;
            if (uVar18 == 0) goto code_r0x00abcbca;
            uVar9 = 0;
            if (uVar18 != 0) {
              for (; (uVar18 >> uVar9 & 1) == 0; uVar9 = uVar9 + 1) {
              }
            }
            pbVar31 = (byte *)(((uVar9 >> 3) - (int)puVar32) + (int)puVar19);
            goto LAB_00abcbfc;
          }
LAB_00abcbd4:
          if ((puVar19 < (uint *)((int)puVar21 + -1)) && (*(short *)puVar30 == *(short *)puVar19)) {
            puVar19 = (uint *)((int)puVar19 + 2);
            puVar30 = (uint *)((int)puVar30 + 2);
          }
          if ((puVar19 < puVar21) && (*(byte *)puVar30 == *(byte *)puVar19)) {
            puVar19 = (uint *)((int)puVar19 + 1);
          }
          pbVar31 = (byte *)((int)puVar19 - (int)puVar32);
LAB_00abcbfc:
          *(undefined4 *)(param_1 + 0x1a4) = *(undefined4 *)(param_1 + 0x1a0);
          *(uint *)(param_1 + 0x1a0) = uVar17;
          puVar32 = *(uint **)(param_1 + 0x17c);
          puVar19 = puVar32;
          puVar30 = puStack_10;
          do {
            *puVar19 = *puVar30;
            puVar19[1] = puVar30[1];
            puVar19 = puVar19 + 2;
            puVar30 = puVar30 + 2;
          } while (puVar19 < puVar32);
          *(undefined2 *)(*(int *)(param_1 + 0x174) + 4) = 0;
          **(undefined4 **)(param_1 + 0x174) = 1;
          if ((byte *)0xffff < pbVar31 + 1) {
            *(undefined4 *)(param_1 + 0x18c) = 2;
            *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
          }
          puVar32 = (uint *)((int)puStack_10 + (int)(pbVar31 + 4));
          *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)(pbVar31 + 1);
          *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
          if (puVar22 <= puVar32) goto LAB_00abcd3b;
          uStack_48 = FUN_00aae930(param_1 + 0x200,uStack_48,puStack_18,puVar32,iVar4,iVar14,uVar10,
                                   iVar11,iVar12,pbVar13,uVar26);
          puStack_10 = puVar32;
        }
      }
      else {
LAB_00abcd2e:
        puStack_18 = puStack_10;
        puStack_10 = (uint *)((int)puStack_10 + 1);
      }
    } while (puStack_10 < puVar22);
  }
LAB_00abcd3b:
  *(undefined4 *)(param_1 + 0x194) = *(undefined4 *)(param_1 + 0x1a0);
  *(undefined4 *)(param_1 + 0x198) = *(undefined4 *)(param_1 + 0x1a4);
  *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x1a8);
  uVar26 = (int)puVar32 - *(int *)(param_1 + 4);
  if (*(int *)(param_1 + 0x14) + 0x400U < uVar26) {
    uVar20 = (uVar26 - *(int *)(param_1 + 0x14)) - 0x400;
    if (0x200 < uVar20) {
      uVar20 = 0x200;
    }
    *(uint *)(param_1 + 0x14) = uVar26 - uVar20;
  }
  if (*(int *)(param_1 + 0xa8) == 1) {
    FUN_00abd420(param_1,puVar32,*(undefined4 *)(param_1 + 0xa0));
  }
  else {
    if (*(int *)(param_1 + 0xa8) != 2) goto LAB_00abcdbf;
    FUN_00abd300(param_1,puVar32,*(undefined4 *)(param_1 + 0xa0));
  }
  *(int *)(param_1 + 0x14) = (int)puVar32 - *(int *)(param_1 + 4);
LAB_00abcdbf:
  (*pcVar5)(param_1,puVar32,(int)puVar21 - (int)puVar32);
  *(int *)(param_1 + 0x14) = (int)puVar21 - iVar4;
  *(undefined4 *)(param_1 + 0x194) = uVar6;
  *(undefined4 *)(param_1 + 0x198) = uVar7;
  *(undefined4 *)(param_1 + 0x19c) = uVar8;
  return;
code_r0x00abc89a:
  puVar23 = puVar23 + 1;
  puVar28 = puVar28 + 1;
  if ((uint *)((int)puVar21 + -3) <= puVar23) goto LAB_00abc8a4;
  goto LAB_00abc890;
code_r0x00abcbca:
  puVar19 = puVar19 + 1;
  puVar30 = puVar30 + 1;
  if ((uint *)((int)puVar21 + -3) <= puVar19) goto LAB_00abcbd4;
  goto LAB_00abcbc0;
}



/* FUNCTION 22084 ; VA 0x00abce00 ; FUN_00abce00 */

void FUN_00abce00(void)

{
  FUN_00aaa5a0();
  return;
}



/* FUNCTION 22085 ; VA 0x00abce10 ; FUN_00abce10 */

int FUN_00abce10(uint param_1)

{
  if (param_1 < 0x20000) {
    return (param_1 >> 8) + (0x20000 - param_1 >> 0xb) + param_1;
  }
  return (param_1 >> 8) + param_1;
}



/* FUNCTION 22086 ; VA 0x00abce40 ; FUN_00abce40 */

uint FUN_00abce40(int param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  uVar3 = FUN_00aaace0(param_1,param_2,param_3,param_4,param_5,1,1);
  if (0xffffff88 < uVar3) {
    return uVar3;
  }
  puVar1 = (undefined4 *)(uVar3 + param_2);
  uVar6 = param_3 - uVar3;
  iVar2 = *(int *)(param_1 + 0x24);
  if (iVar2 == 0) {
    return 0xffffffc4;
  }
  if (iVar2 == 1) {
    uVar4 = FUN_00aafea0(puVar1,uVar6,*(undefined4 *)(param_1 + 0x8c),
                         *(undefined4 *)(param_1 + 0x90),*(undefined4 *)(param_1 + 0x94),
                         *(undefined4 *)(param_1 + 0x98),*(undefined4 *)(param_1 + 0x9c),
                         *(undefined4 *)(param_1 + 0xa0),*(undefined4 *)(param_1 + 0xa4),
                         *(undefined4 *)(param_1 + 0xa8),*(undefined4 *)(param_1 + 0xac),
                         *(undefined4 *)(param_1 + 0xb0),*(undefined4 *)(param_1 + 0xb4),
                         *(undefined4 *)(param_1 + 0xb8),*(undefined4 *)(param_1 + 0xbc),
                         *(undefined4 *)(param_1 + 0xc0),*(undefined4 *)(param_1 + 0xc4),
                         *(undefined4 *)(param_1 + 200),*(undefined4 *)(param_1 + 0xcc),
                         *(undefined4 *)(param_1 + 0xd0),*(undefined4 *)(param_1 + 0xd4),
                         *(undefined4 *)(param_1 + 0xd8),*(undefined4 *)(param_1 + 0xdc),
                         *(undefined4 *)(param_1 + 0xe0),*(undefined4 *)(param_1 + 0xe4),
                         *(undefined4 *)(param_1 + 0xe8),0,0,0);
    if (0xffffff88 < uVar4) {
      return uVar4;
    }
    uVar6 = uVar6 - uVar4;
    *(undefined4 *)(param_1 + 0x24) = 2;
    puVar7 = (undefined4 *)(uVar4 + (int)puVar1);
  }
  else {
    puVar7 = puVar1;
    if (iVar2 == 3) goto LAB_00abcf26;
  }
  if (uVar6 < 4) {
    return 0xffffffba;
  }
  *puVar7 = 1;
  uVar6 = uVar6 - 3;
  puVar7 = (undefined4 *)((int)puVar7 + 3);
LAB_00abcf26:
  if (*(int *)(param_1 + 0xb0) != 0) {
    uVar5 = FUN_00ab2750(param_1 + 0x108);
    if (uVar6 < 4) {
      return 0xffffffba;
    }
    *puVar7 = uVar5;
    puVar7 = puVar7 + 1;
  }
  uVar6 = (int)puVar7 - (int)puVar1;
  *(undefined4 *)(param_1 + 0x24) = 0;
  if (uVar6 < 0xffffff89) {
    if ((*(int *)(param_1 + 0xac) != 0) &&
       ((*(int *)(param_1 + 0xf8) != *(uint *)(param_1 + 0x100) + 1 ||
        (*(int *)(param_1 + 0xfc) !=
         *(int *)(param_1 + 0x104) + (uint)(0xfffffffe < *(uint *)(param_1 + 0x100)))))) {
      return 0xffffffb8;
    }
    return uVar3 + uVar6;
  }
  return uVar6;
}



/* FUNCTION 22087 ; VA 0x00abcfb0 ; FUN_00abcfb0 */

char * FUN_00abcfb0(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint *puVar2;
  uint uVar3;
  
  puVar2 = param_1;
  if (param_1 < (uint *)((int)param_3 - 3U)) {
    do {
      uVar3 = *puVar2 ^ *param_2;
      if (uVar3 != 0) {
        uVar1 = 0;
        if (uVar3 != 0) {
          for (; (uVar3 >> uVar1 & 1) == 0; uVar1 = uVar1 + 1) {
          }
        }
        return (char *)((int)puVar2 + ((uVar1 >> 3) - (int)param_1));
      }
      puVar2 = puVar2 + 1;
      param_2 = param_2 + 1;
    } while (puVar2 < (uint *)((int)param_3 - 3U));
  }
  if ((puVar2 < (uint *)((int)param_3 - 1U)) && (*(short *)param_2 == *(short *)puVar2)) {
    puVar2 = (uint *)((int)puVar2 + 2);
    param_2 = (uint *)((int)param_2 + 2);
  }
  if ((puVar2 < param_3) && (*(char *)param_2 == *(char *)puVar2)) {
    puVar2 = (uint *)((int)puVar2 + 1);
  }
  return (char *)((int)puVar2 - (int)param_1);
}



/* FUNCTION 22088 ; VA 0x00abd020 ; FUN_00abd020 */

int FUN_00abd020(int param_1,int param_2,uint param_3,int param_4,undefined4 param_5)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = (param_1 - param_2) + param_4;
  uVar4 = param_3;
  if (uVar1 < param_3) {
    uVar4 = uVar1;
  }
  iVar2 = FUN_00abcfb0(param_1,param_2,uVar4);
  if (iVar2 + param_2 == param_4) {
    iVar3 = FUN_00abcfb0(param_1 + iVar2,param_5,param_3);
    iVar2 = iVar3 + iVar2;
  }
  return iVar2;
}



/* FUNCTION 22089 ; VA 0x00abd070 ; FUN_00abd070 */

undefined4 FUN_00abd070(code *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 extraout_ECX;
  
  if ((param_2 == 0) == (param_1 == (code *)0x0)) {
    if (param_1 == (code *)0x0) {
      iVar1 = FUN_0171e1f2(0x25d60);
    }
    else {
      iVar1 = (*param_1)(param_3);
    }
    if (iVar1 != 0) {
      *(ulonglong *)(iVar1 + 0x5ce8) = CONCAT44(param_2,param_1);
      *(undefined4 *)(iVar1 + 0x5cf0) = param_3;
      *(undefined4 *)(iVar1 + 0x5d30) = 0;
      *(undefined4 *)(iVar1 + 0x5d34) = 0;
      FUN_00aae1f0(iVar1);
      return extraout_ECX;
    }
  }
  return 0;
}



/* FUNCTION 22090 ; VA 0x00abd0f0 ; FUN_00abd0f0 */

undefined4 FUN_00abd0f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_00abd070(DAT_01947678,DAT_01947680);
  if (iVar1 == 0) {
    return 0xffffffc0;
  }
  uVar2 = FUN_00aac340(iVar1,param_1,param_2,param_3,param_4,0,0,0);
  FUN_00abd500(iVar1);
  return uVar2;
}



/* FUNCTION 22091 ; VA 0x00abd150 ; FUN_00abd150 */

undefined4 FUN_00abd150(int *param_1)

{
  param_1[0x171d] = 0;
  param_1[0x171a] = 0;
  param_1[0x171b] = 0;
  param_1[0x170b] = 0;
  param_1[0x170c] = 0;
  param_1[0x170d] = 0;
  param_1[0x170f] = (uint)(param_1[0x1738] != 1) * 4 + 1;
  param_1[0x170e] = 0;
  param_1[0x507] = 0xc00000c;
  param_1[0x171f] = 0;
  param_1[0x171e] = 0;
  param_1[0x1737] = 0;
  *(undefined8 *)(param_1 + 0x1708) = DAT_01947684;
  param_1[0x170a] = DAT_0194768c;
  *param_1 = (int)(param_1 + 4);
  param_1[1] = (int)(param_1 + 0x306);
  param_1[2] = (int)(param_1 + 0x205);
  param_1[3] = (int)(param_1 + 0x507);
  return 0;
}



/* FUNCTION 22092 ; VA 0x00abd220 ; FUN_00abd220 */

uint FUN_00abd220(int *param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = FUN_00abd150(param_1);
  if (uVar1 < 0xffffff89) {
    if (param_2 != 0) {
      param_1[0x1737] = *(int *)(param_2 + 0x5c28);
      param_1[0x170c] = *(int *)(param_2 + 4);
      param_1[0x170d] = *(int *)(param_2 + 4);
      iVar2 = *(int *)(param_2 + 4) + *(int *)(param_2 + 8);
      param_1[0x170e] = iVar2;
      param_1[0x170b] = iVar2;
      if (*(int *)(param_2 + 0x5c2c) != 0) {
        param_1[0x171e] = 1;
        *param_1 = param_2 + 0xc;
        param_1[1] = param_2 + 0xc14;
        param_1[2] = param_2 + 0x810;
        param_1[3] = param_2 + 0x1418;
        param_1[0x171f] = 1;
        param_1[0x1708] = *(int *)(param_2 + 0x5c1c);
        param_1[0x1709] = *(int *)(param_2 + 0x5c20);
        param_1[0x170a] = *(int *)(param_2 + 0x5c24);
        return 0;
      }
      param_1[0x171e] = 0;
      param_1[0x171f] = 0;
    }
    uVar1 = 0;
  }
  return uVar1;
}



/* FUNCTION 22093 ; VA 0x00abd300 ; FUN_00abd300 */

void FUN_00abd300(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  int iStack_8;
  
  iVar1 = *(int *)(param_1 + 0x210);
  uVar2 = *(undefined4 *)(param_1 + 0x94);
  iVar3 = *(int *)(param_1 + 0x218);
  iStack_8 = *(int *)(param_1 + 0x14);
  piVar6 = (int *)(*(int *)(param_1 + 4) + iStack_8);
  if (piVar6 <= (int *)(param_2 + -8)) {
    do {
      switch(param_3) {
      case 5:
        uVar7 = 0xbb000000;
        break;
      case 6:
        uVar7 = 0xbf9b0000;
        break;
      case 7:
        uVar7 = 0xbfa56300;
        break;
      case 8:
        uVar7 = 0xb7a56463;
        break;
      default:
        uVar4 = (uint)(*piVar6 * -0x61c8864f) >> (0x20U - (char)uVar2 & 0x1f);
        goto LAB_00abd3bf;
      }
      FUN_016f39b0(*piVar6,piVar6[1],uVar7,0xcf1bbcdc);
      uVar4 = FUN_016f4650();
LAB_00abd3bf:
      *(int *)(iVar3 + uVar4 * 4) = iStack_8;
      FUN_016f39b0(*piVar6,piVar6[1],0xb7a56463,0xcf1bbcdc);
      iVar5 = FUN_016f4650();
      piVar6 = (int *)((int)piVar6 + 3);
      *(int *)(iVar1 + iVar5 * 4) = iStack_8;
      iStack_8 = iStack_8 + 3;
    } while (piVar6 <= (int *)(param_2 + -8));
  }
  return;
}



/* FUNCTION 22094 ; VA 0x00abd420 ; FUN_00abd420 */

void FUN_00abd420(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  
  iVar1 = *(int *)(param_1 + 0x210);
  iVar5 = *(int *)(param_1 + 0x14);
  piVar4 = (int *)(*(int *)(param_1 + 4) + iVar5);
  uVar2 = *(undefined4 *)(param_1 + 0x98);
  if (piVar4 <= (int *)(param_2 + -8)) {
    do {
      switch(param_3) {
      case 5:
        uVar6 = 0xbb000000;
        break;
      case 6:
        uVar6 = 0xbf9b0000;
        break;
      case 7:
        uVar6 = 0xbfa56300;
        break;
      case 8:
        uVar6 = 0xb7a56463;
        break;
      default:
        uVar3 = (uint)(*piVar4 * -0x61c8864f) >> (0x20U - (char)uVar2 & 0x1f);
        goto LAB_00abd4cd;
      }
      FUN_016f39b0(*piVar4,piVar4[1],uVar6,0xcf1bbcdc);
      uVar3 = FUN_016f4650();
LAB_00abd4cd:
      *(int *)(iVar1 + uVar3 * 4) = iVar5;
      piVar4 = (int *)((int)piVar4 + 3);
      iVar5 = iVar5 + 3;
    } while (piVar4 <= (int *)(param_2 + -8));
  }
  return;
}



/* FUNCTION 22095 ; VA 0x00abd500 ; FUN_00abd500 */

undefined4 FUN_00abd500(int param_1)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 uStack_c;
  
  if (param_1 != 0) {
    if (*(int *)(param_1 + 0x5cfc) != 0) {
      return 0xffffffc0;
    }
    uVar1 = *(undefined8 *)(param_1 + 0x5ce8);
    uVar2 = *(undefined4 *)(param_1 + 0x5cf0);
    FUN_00abd5b0(*(undefined4 *)(param_1 + 0x5d00));
    uStack_c = (code *)((ulonglong)uVar1 >> 0x20);
    *(undefined4 *)(param_1 + 0x5d00) = 0;
    if (*(int *)(param_1 + 0x5d0c) != 0) {
      if (uStack_c == (code *)0x0) {
        FUN_017168b0(*(int *)(param_1 + 0x5d0c));
      }
      else {
        (*uStack_c)(uVar2);
      }
    }
    *(undefined4 *)(param_1 + 0x5d0c) = 0;
    if (uStack_c != (code *)0x0) {
      (*uStack_c)(uVar2);
      return 0;
    }
    FUN_017168b0(param_1);
  }
  return 0;
}



/* FUNCTION 22096 ; VA 0x00abd5b0 ; FUN_00abd5b0 */

undefined4 FUN_00abd5b0(int *param_1)

{
  int iVar1;
  code *pcStack_c;
  
  if (param_1 == (int *)0x0) {
    return 0;
  }
  iVar1 = param_1[0x170e];
  pcStack_c = (code *)((ulonglong)*(undefined8 *)(param_1 + 0x170c) >> 0x20);
  if (*param_1 != 0) {
    if (pcStack_c == (code *)0x0) {
      FUN_017168b0(*param_1);
      goto LAB_00abd603;
    }
    (*pcStack_c)(iVar1);
  }
  if (pcStack_c != (code *)0x0) {
    (*pcStack_c)(iVar1,param_1);
    return 0;
  }
LAB_00abd603:
  FUN_017168b0(param_1);
  return 0;
}



/* FUNCTION 22097 ; VA 0x00abd620 ; FUN_00abd620 */

undefined4 * FUN_00abd620(undefined4 *param_1,int param_2,undefined8 param_3,uint param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  undefined auStack_20 [28];
  
  iVar5 = param_3._4_4_;
  if ((uint)param_3 == 0 && param_3._4_4_ == 0) {
    param_3._4_4_ = 500;
  }
  else {
    param_3._4_4_ = 0;
  }
  if (param_4 + (uint)param_3 == 0 && iVar5 + (uint)CARRY4(param_4,(uint)param_3) == 0) {
    uVar6 = 0xffffffff;
    iVar9 = -1;
  }
  else {
    uVar6 = param_4 + param_3._4_4_ + (uint)param_3;
    iVar9 = (uint)CARRY4(param_4,param_3._4_4_) + iVar5 +
            (uint)CARRY4(param_4 + param_3._4_4_,(uint)param_3);
    if ((iVar9 == 0) && (uVar6 < 0x40001)) {
      param_3._4_4_ = 0x17;
      goto LAB_00abd68f;
    }
  }
  param_3._4_4_ = 0;
LAB_00abd68f:
  if ((iVar9 == 0) && (uVar6 < 0x20001)) {
    iVar10 = 0x17;
  }
  else {
    iVar10 = 0;
  }
  if ((iVar9 == 0) && (uVar6 < 0x4001)) {
    iVar9 = 0x17;
  }
  else {
    iVar9 = 0;
  }
  iVar8 = 3;
  if (0 < param_2) {
    iVar8 = param_2;
  }
  if (0x16 < iVar8) {
    iVar8 = 0x16;
  }
  iVar8 = param_3._4_4_ + iVar10 + iVar9 + iVar8;
  iVar9 = iVar8 * 0x1c;
  puVar7 = (undefined4 *)
           FUN_00aa9240(auStack_20,*(undefined4 *)(&DAT_019479c8 + iVar9),
                        *(undefined4 *)(&UNK_019479cc + iVar9),
                        *(undefined4 *)(&UNK_019479d0 + iVar9),
                        *(undefined4 *)(&UNK_019479d4 + iVar9),
                        *(undefined8 *)(&DAT_019479d8 + iVar8 * 0x1c),
                        *(undefined4 *)(&DAT_019479e0 + iVar8 * 0x1c),(uint)param_3,iVar5,param_4);
  uVar2 = puVar7[1];
  uVar3 = puVar7[2];
  uVar4 = puVar7[3];
  uVar1 = puVar7[6];
  *param_1 = *puVar7;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar7 + 4);
  param_1[6] = uVar1;
  return param_1;
}



/* FUNCTION 22098 ; VA 0x00abd740 ; FUN_00abd740 */

void FUN_00abd740(void)

{
  FUN_00ab02f0();
  return;
}



/* FUNCTION 22099 ; VA 0x00abd760 ; FUN_00abd760 */

uint FUN_00abd760(int *param_1,char param_2,undefined4 param_3)

{
  uint uVar1;
  undefined4 uVar2;
  
  switch(param_3) {
  case 5:
    uVar2 = 0xbb000000;
    break;
  case 6:
    uVar2 = 0xbf9b0000;
    break;
  case 7:
    uVar2 = 0xbfa56300;
    break;
  case 8:
    uVar2 = 0xb7a56463;
    break;
  default:
    return (uint)(*param_1 * -0x61c8864f) >> (0x20U - param_2 & 0x1f);
  }
  FUN_016f39b0(*param_1,param_1[1],uVar2,0xcf1bbcdc);
  uVar1 = FUN_016f4650();
  return uVar1;
}



/* FUNCTION 22100 ; VA 0x00abd7f0 ; FUN_00abd7f0 */

undefined4 FUN_00abd7f0(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  
  iVar1 = *(int *)(param_1 + 0x210);
  uVar2 = *(undefined4 *)(param_1 + 0x94);
  uVar7 = *(uint *)(param_1 + 0x14);
  uVar3 = *(undefined4 *)(param_1 + 0x98);
  iVar5 = *(int *)(param_1 + 0x218);
  uVar4 = param_2 - *(int *)(param_1 + 4);
  if (uVar7 < uVar4) {
    piVar8 = (int *)(uVar7 + *(int *)(param_1 + 4));
    do {
      switch(param_3) {
      case 5:
        FUN_016f39b0(*piVar8,piVar8[1],0xbb000000,0xcf1bbcdc);
        uVar6 = FUN_016f4650();
        break;
      case 6:
        FUN_016f39b0(*piVar8,piVar8[1],0xbf9b0000,0xcf1bbcdc);
        uVar6 = FUN_016f4650();
        break;
      case 7:
        FUN_016f39b0(*piVar8,piVar8[1],0xbfa56300,0xcf1bbcdc);
        uVar6 = FUN_016f4650();
        break;
      case 8:
        FUN_016f39b0(*piVar8,piVar8[1],0xb7a56463,0xcf1bbcdc);
        uVar6 = FUN_016f4650();
        break;
      default:
        uVar6 = (uint)(*piVar8 * -0x61c8864f) >> (0x20U - (char)uVar3 & 0x1f);
      }
      piVar8 = (int *)((int)piVar8 + 1);
      *(undefined4 *)(iVar5 + (uVar7 & (1 << ((byte)uVar2 & 0x1f)) - 1U) * 4) =
           *(undefined4 *)(iVar1 + uVar6 * 4);
      *(uint *)(iVar1 + uVar6 * 4) = uVar7;
      uVar7 = uVar7 + 1;
    } while (uVar7 < uVar4);
  }
  *(uint *)(param_1 + 0x14) = uVar4;
  iVar5 = FUN_00abd760(param_2,uVar3,param_3);
  return *(undefined4 *)(iVar1 + iVar5 * 4);
}



/* FUNCTION 22101 ; VA 0x00abd960 ; FUN_00abd960 */

bool FUN_00abd960(uint param_1)

{
  return 0xffffff88 < param_1;
}



/* FUNCTION 22102 ; VA 0x00abd980 ; FUN_00abd980 */

void FUN_00abd980(int *param_1,uint param_2,undefined4 *param_3,int param_4,uint param_5)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)param_1[3];
  puVar1 = (undefined4 *)((int)puVar2 + param_2);
  do {
    *puVar2 = *param_3;
    puVar2[1] = param_3[1];
    puVar2 = puVar2 + 2;
    param_3 = param_3 + 2;
  } while (puVar2 < puVar1);
  param_1[3] = param_1[3] + param_2;
  if (0xffff < param_2) {
    param_1[7] = 1;
    param_1[8] = param_1[1] - *param_1 >> 3;
  }
  *(short *)(param_1[1] + 4) = (short)param_2;
  *(int *)param_1[1] = param_4 + 1;
  if (0xffff < param_5) {
    param_1[7] = 2;
    param_1[8] = param_1[1] - *param_1 >> 3;
  }
  *(short *)(param_1[1] + 6) = (short)param_5;
  param_1[1] = param_1[1] + 8;
  return;
}



/* FUNCTION 22103 ; VA 0x00abda10 ; FUN_00abda10 */

/* WARNING: Type propagation algorithm not settling */

void FUN_00abda10(int param_1,int param_2,uint *param_3,int param_4,undefined4 param_5)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  int *piVar4;
  undefined *puVar5;
  uint uVar6;
  byte *pbVar7;
  undefined *puVar8;
  uint *puVar9;
  undefined *puVar10;
  int iVar11;
  undefined *puVar12;
  uint *puVar13;
  int iStack_4c;
  byte *pbStack_48;
  uint *puStack_44;
  uint *puStack_40;
  undefined *puStack_3c;
  undefined *puStack_38;
  int iStack_34;
  undefined *puStack_30;
  uint *puStack_2c;
  undefined *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  undefined *puStack_10;
  undefined *puStack_c;
  int *piStack_8;
  
  iStack_14 = *(int *)(param_1 + 4);
  puVar5 = (undefined *)(param_2 - iStack_14);
  puStack_c = *(undefined **)(param_1 + 0x14);
  do {
    if (puVar5 <= puStack_c) {
      return;
    }
    iVar11 = *(int *)(param_1 + 0x210);
    iVar2 = FUN_00abd760(puStack_c + iStack_14,*(undefined4 *)(param_1 + 0x98),param_5);
    iStack_34 = *(int *)(param_1 + 0x218);
    puVar13 = *(uint **)(iVar11 + iVar2 * 4);
    puStack_28 = (undefined *)0x0;
    puStack_20 = (undefined *)((1 << ((char)*(undefined4 *)(param_1 + 0x94) - 1U & 0x1f)) + -1);
    puStack_3c = (undefined *)0x0;
    puStack_30 = &DAT_00000008;
    iStack_24 = *(int *)(param_1 + 4);
    puStack_10 = puStack_c + (iStack_14 - iStack_24);
    puStack_40 = (uint *)(-(uint)(puStack_20 < puStack_10) & (int)puStack_10 - (int)puStack_20);
    piStack_8 = (int *)(iStack_34 + ((uint)puStack_10 & (uint)puStack_20) * 8);
    piStack_1c = piStack_8 + 1;
    puStack_44 = *(uint **)(param_1 + 0x10);
    puVar8 = puStack_10 + 8;
    *(undefined **)(iVar11 + iVar2 * 4) = puStack_10;
    piVar4 = piStack_8;
    puVar10 = puVar8;
    iVar11 = param_4;
    puStack_38 = puVar8;
    puStack_2c = puVar13;
    if (param_4 != 0) {
      do {
        iVar11 = iVar11 + -1;
        piVar4 = piStack_8;
        iStack_4c = iVar11;
        puStack_2c = puVar13;
        if (puVar13 <= puStack_44) break;
        piStack_18 = (int *)(iStack_34 + ((uint)puVar13 & (uint)puStack_20) * 8);
        puVar12 = puStack_28;
        if (puStack_3c < puStack_28) {
          puVar12 = puStack_3c;
        }
        pbStack_48 = (byte *)(iStack_24 + (int)puVar13);
        if (pbStack_48[(int)puVar12] == puVar12[(int)(puStack_c + iStack_14)]) {
          puStack_2c = (uint *)(puVar12 + (int)(puStack_c + iStack_14 + 1));
          puVar9 = (uint *)(pbStack_48 + 1 + (int)puVar12);
          puVar3 = puStack_2c;
          if (puStack_2c < (uint *)((int)param_3 + -3)) {
LAB_00abdb40:
            uVar6 = *puVar3 ^ *puVar9;
            if (uVar6 == 0) goto code_r0x00abdb4a;
            uVar1 = 0;
            if (uVar6 != 0) {
              for (; (uVar6 >> uVar1 & 1) == 0; uVar1 = uVar1 + 1) {
              }
            }
            pbStack_48 = (byte *)0x0;
            pbVar7 = (byte *)(((uVar1 >> 3) - (int)puStack_2c) + (int)puVar3);
            goto LAB_00abdb7c;
          }
LAB_00abdb54:
          if ((puVar3 < (uint *)((int)param_3 + -1)) && (*(short *)puVar9 == *(short *)puVar3)) {
            puVar3 = (uint *)((int)puVar3 + 2);
            puVar9 = (uint *)((int)puVar9 + 2);
          }
          if ((puVar3 < param_3) && (*(byte *)puVar9 == *(byte *)puVar3)) {
            puVar3 = (uint *)((int)puVar3 + 1);
          }
          pbVar7 = (byte *)((int)puVar3 - (int)puStack_2c);
LAB_00abdb7c:
          puVar12 = puVar12 + 1 + (int)pbVar7;
          puVar10 = puStack_38;
        }
        if ((puStack_30 < puVar12) && (puStack_30 = puVar12, puVar10 + -(int)puVar13 < puVar12)) {
          puVar10 = puVar12 + (int)puVar13;
          puStack_38 = puVar10;
        }
        if ((uint *)(puVar12 + (int)(puStack_c + iStack_14)) == param_3) break;
        if (((byte *)(iStack_24 + (int)puVar13))[(int)puVar12] <
            (byte)puVar12[(int)(puStack_c + iStack_14)]) {
          *piStack_8 = (int)puVar13;
          puStack_3c = puVar12;
          if (puVar13 <= puStack_40) {
            piVar4 = &iStack_4c;
            break;
          }
          puVar13 = (uint *)piStack_18[1];
          piStack_8 = piStack_18 + 1;
        }
        else {
          *piStack_1c = (int)puVar13;
          puStack_28 = puVar12;
          if (puVar13 <= puStack_40) {
            piStack_1c = &iStack_4c;
            break;
          }
          puVar13 = (uint *)*piStack_18;
          piStack_1c = piStack_18;
        }
        piVar4 = piStack_8;
        puStack_2c = puVar13;
      } while (iVar11 != 0);
    }
    *piStack_1c = 0;
    *piVar4 = 0;
    if (puStack_30 < (undefined *)0x181) {
      if (puVar8 < puVar10) {
        puVar10 = puVar10 + (-8 - (int)puStack_10);
      }
      else {
        puVar10 = (undefined *)0x1;
      }
    }
    else {
      puVar10 = puStack_30 + -0x180;
      if ((undefined *)0xc0 < puVar10) {
        puVar10 = (undefined *)0xc0;
      }
    }
    puStack_c = puStack_c + (int)puVar10;
  } while( true );
code_r0x00abdb4a:
  puVar3 = puVar3 + 1;
  puVar9 = puVar9 + 1;
  if ((uint *)((int)param_3 + -3) <= puVar3) goto LAB_00abdb54;
  goto LAB_00abdb40;
}



/* FUNCTION 22104 ; VA 0x00abdc80 ; FUN_00abdc80 */

/* WARNING: Type propagation algorithm not settling */

void FUN_00abdc80(int param_1,int param_2,uint *param_3,uint param_4,undefined4 param_5)

{
  undefined *puVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint *puVar5;
  int iVar6;
  char *pcVar7;
  uint uVar8;
  byte *pbVar9;
  uint *puVar10;
  undefined *puVar11;
  uint uVar12;
  uint uVar13;
  undefined *puVar14;
  uint uStack_58;
  undefined *puStack_54;
  int iStack_50;
  uint uStack_4c;
  undefined *puStack_48;
  undefined *puStack_44;
  uint *puStack_40;
  uint uStack_3c;
  undefined *puStack_38;
  int iStack_34;
  undefined *puStack_30;
  byte *pbStack_2c;
  uint *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  int iStack_1c;
  uint uStack_18;
  uint *puStack_14;
  undefined *puStack_10;
  undefined *puStack_c;
  uint *puStack_8;
  
  iVar2 = *(int *)(param_1 + 4);
  puStack_48 = *(undefined **)(param_1 + 0x14);
  do {
    if ((undefined *)(param_2 - iVar2) <= puStack_48) {
      return;
    }
    puStack_c = puStack_48 + iVar2;
    iVar6 = *(int *)(param_1 + 0x210);
    iVar4 = FUN_00abd760(puStack_c,*(undefined4 *)(param_1 + 0x98),param_5);
    iStack_24 = *(int *)(param_1 + 0x218);
    uVar12 = *(uint *)(iVar6 + iVar4 * 4);
    uStack_18 = (1 << ((char)*(undefined4 *)(param_1 + 0x94) - 1U & 0x1f)) - 1;
    puStack_20 = &DAT_00000008;
    puStack_44 = (undefined *)0x0;
    puStack_38 = (undefined *)0x0;
    iStack_34 = *(int *)(param_1 + 4);
    iStack_50 = *(int *)(param_1 + 8);
    puStack_30 = *(undefined **)(param_1 + 0xc);
    pbStack_2c = puStack_30 + iStack_50;
    puStack_54 = puStack_30 + iStack_34;
    uVar13 = (int)puStack_c - iStack_34;
    uStack_3c = -(uint)(uStack_18 < uVar13) & uVar13 - uStack_18;
    puStack_8 = (uint *)(iStack_24 + (uVar13 & uStack_18) * 8);
    puStack_14 = puStack_8 + 1;
    uStack_4c = *(uint *)(param_1 + 0x10);
    puVar1 = (undefined *)(uVar13 + 8);
    *(uint *)(iVar6 + iVar4 * 4) = uVar13;
    puVar5 = puStack_8;
    puVar11 = puVar1;
    uVar8 = param_4;
    puStack_10 = puVar1;
    if (param_4 != 0) {
      do {
        uStack_58 = uVar8 - 1;
        puVar5 = puStack_8;
        if (uVar12 <= uStack_4c) break;
        puVar14 = puStack_38;
        if (puStack_44 < puStack_38) {
          puVar14 = puStack_44;
        }
        puStack_40 = (uint *)(iStack_24 + (uVar12 & uStack_18) * 8);
        pcVar7 = puVar14 + (int)puStack_c;
        if (puVar14 + uVar12 < puStack_30) {
          iStack_1c = iStack_50 + uVar12;
          puVar11 = puVar14 + iStack_1c;
          puVar5 = param_3;
          if (pbStack_2c + ((int)pcVar7 - (int)puVar11) < param_3) {
            puVar5 = (uint *)(pbStack_2c + ((int)pcVar7 - (int)puVar11));
          }
          puVar5 = (uint *)FUN_00abcfb0(puStack_c + (int)puVar14,puVar11,puVar5);
          puStack_28 = puVar5;
          if ((byte *)((int)puVar5 + (int)puVar11) == pbStack_2c) {
            iVar6 = FUN_00abcfb0(puStack_c + (int)puVar14 + (int)puVar5,puStack_54,param_3);
            puVar5 = (uint *)((int)puStack_28 + iVar6);
          }
          puVar14 = puVar14 + (int)puVar5;
          puVar11 = puStack_10;
          iVar6 = iStack_1c;
          if (puStack_30 <= puVar14 + uVar12) {
            iVar6 = iStack_34 + uVar12;
          }
        }
        else {
          iStack_1c = iStack_34 + uVar12;
          iVar6 = iStack_1c;
          if (puVar14[iStack_1c] == *pcVar7) {
            puStack_28 = (uint *)(pcVar7 + 1);
            puVar10 = (uint *)(puVar14 + iStack_1c + 1);
            puVar5 = puStack_28;
            if (puStack_28 < (uint *)((int)param_3 + -3)) {
LAB_00abddc0:
              uVar8 = *puVar5 ^ *puVar10;
              if (uVar8 == 0) goto code_r0x00abddca;
              uVar3 = 0;
              if (uVar8 != 0) {
                for (; (uVar8 >> uVar3 & 1) == 0; uVar3 = uVar3 + 1) {
                }
              }
              pbVar9 = (byte *)(((uVar3 >> 3) - (int)puStack_28) + (int)puVar5);
              goto LAB_00abddfc;
            }
LAB_00abddd4:
            if ((puVar5 < (uint *)((int)param_3 + -1)) && (*(short *)puVar10 == *(short *)puVar5)) {
              puVar5 = (uint *)((int)puVar5 + 2);
              puVar10 = (uint *)((int)puVar10 + 2);
            }
            if ((puVar5 < param_3) && (*(byte *)puVar10 == *(byte *)puVar5)) {
              puVar5 = (uint *)((int)puVar5 + 1);
            }
            pbVar9 = (byte *)((int)puVar5 - (int)puStack_28);
LAB_00abddfc:
            puVar14 = puVar14 + 1 + (int)pbVar9;
            puVar11 = puStack_10;
          }
        }
        if ((puStack_20 < puVar14) && (puStack_20 = puVar14, puVar11 + -uVar12 < puVar14)) {
          puVar11 = puVar14 + uVar12;
          puStack_10 = puVar11;
        }
        puVar5 = puStack_8;
        if ((uint *)(puVar14 + (int)puStack_c) == param_3) break;
        if ((byte)puVar14[iVar6] < (byte)puVar14[(int)puStack_c]) {
          *puStack_8 = uVar12;
          puStack_44 = puVar14;
          if (uVar12 <= uStack_3c) {
            puVar5 = &uStack_58;
            break;
          }
          puStack_8 = puStack_40 + 1;
          uVar12 = *puStack_8;
        }
        else {
          *puStack_14 = uVar12;
          puStack_38 = puVar14;
          if (uVar12 <= uStack_3c) {
            puStack_14 = &uStack_58;
            break;
          }
          puStack_14 = puStack_40;
          uVar12 = *puStack_40;
        }
        puVar5 = puStack_8;
        uVar8 = uStack_58;
      } while (uStack_58 != 0);
    }
    *puStack_14 = 0;
    *puVar5 = 0;
    if (puStack_20 < (undefined *)0x181) {
      if (puVar1 < puVar11) {
        puVar11 = puVar11 + (-8 - uVar13);
      }
      else {
        puVar11 = (undefined *)0x1;
      }
    }
    else {
      puVar11 = puStack_20 + -0x180;
      if ((undefined *)0xc0 < puVar11) {
        puVar11 = (undefined *)0xc0;
      }
    }
    puStack_48 = puStack_48 + (int)puVar11;
  } while( true );
code_r0x00abddca:
  puVar5 = puVar5 + 1;
  puVar10 = puVar10 + 1;
  if ((uint *)((int)param_3 + -3) <= puVar5) goto LAB_00abddd4;
  goto LAB_00abddc0;
}



/* FUNCTION 22105 ; VA 0x00abdf70 ; FUN_00abdf70 */

void FUN_00abdf70(undefined4 *param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(param_3 + (int)param_1);
  param_2 = param_2 - (int)param_1;
  do {
    *param_1 = *(undefined4 *)(param_2 + (int)param_1);
    param_1[1] = *(undefined4 *)(param_2 + 4 + (int)param_1);
    param_1 = param_1 + 2;
  } while (param_1 < puVar1);
  return;
}



/* FUNCTION 22106 ; VA 0x00abdfa0 ; FUN_00abdfa0 */

int * __thiscall
FUN_00abdfa0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0d8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00abe1a0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::PlayerEmulatorService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::PlayerEmulatorService::*)(void)const_,void_(__thiscall_RBX::PlayerEmulatorService::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::
                  TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                  ::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::PlayerEmulatorService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::PlayerEmulatorService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22107 ; VA 0x00abe0a0 ; FUN_00abe0a0 */

int * __thiscall
FUN_00abe0a0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00abe1a0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PlayerEmulatorService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::PlayerEmulatorService::*)(void)const_,void_(__thiscall_RBX::PlayerEmulatorService::*)(bool)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::PlayerEmulatorService,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::PlayerEmulatorService,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22108 ; VA 0x00abe1a0 ; FUN_00abe1a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00abe1a0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7420;
  pvStack_10 = ExceptionList;
  if (DAT_01eeb2c4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb4d8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eeb4d8);
      if (DAT_01eeb4d8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"PlayerEmulatorService",1,uStack_20,0,0,0xb,5,0);
        _DAT_01eeb4d0 = RBX::Creator<class_RBX::PlayerEmulatorService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eeb2c8,&DAT_01eeb4d0);
        FUN_016f3654(FUN_0188afa0);
        FUN_016f37bf(&DAT_01eeb4d8);
      }
    }
    DAT_01eeb2c4 = &DAT_01eeb2c8;
  }
  ExceptionList = pvStack_10;
  return DAT_01eeb2c4;
}



/* FUNCTION 22109 ; VA 0x00abe2a0 ; FUN_00abe2a0 */

void FUN_00abe2a0(void)

{
  int iVar1;
  
  if (DAT_01eeb4dc == 0) {
    iVar1 = FUN_00abe1a0();
    DAT_01eeb4dc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 22110 ; VA 0x00abe2c0 ; FUN_00abe2c0 */

undefined4 * __thiscall
FUN_00abe2c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  undefined4 *puStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e747b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00abe1a0();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::PlayerEmulatorService,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8 = 1;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar3 = (undefined4 *)param_1[0x10];
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_008881d0();
    puStack_e4 = (undefined4 *)0x0;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e0 = *puVar3;
    uStack_dc = puVar3[1];
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8a9c) {
      FUN_016f3809(&DAT_01ea8a9c);
      if (DAT_01ea8a9c == -1) {
        DAT_01ea8a90 = FUN_0057bbb0;
        DAT_01ea8a94 = FUN_005880a0;
        DAT_01ea8a98 = FUN_0057d5e0;
        FUN_016f37bf(&DAT_01ea8a9c);
      }
    }
    puStack_e4 = &DAT_01ea8a90;
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_008881d0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_e4 != (undefined4 *)0x0) {
      (*(code *)puStack_e4[2])(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22111 ; VA 0x00abe4d0 ; FUN_00abe4d0 */

undefined4 * __fastcall FUN_00abe4d0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e74da;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::PlayerEmulatorService,class_RBX::ServiceInstance>::
             vftable;
  uVar1 = FUN_00abe1a0();
  param_1[3] = uVar1;
  *param_1 = RBX::PlayerEmulatorService::vftable;
  *(undefined *)(param_1 + 0x16) = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0xf;
  *(undefined *)(param_1 + 0x17) = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0xf;
  *(undefined *)(param_1 + 0x1d) = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0xf;
  *(undefined *)(param_1 + 0x23) = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  uStack_8._0_1_ = 5;
  uStack_8._1_3_ = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("PlayerEmulatorService",0x15);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22112 ; VA 0x00abe600 ; FUN_00abe600 */

void __fastcall FUN_00abe600(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::PlayerEmulatorService>::vftable;
  uVar1 = FUN_00abe1a0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22113 ; VA 0x00abe640 ; FUN_00abe640 */

void __thiscall
FUN_00abe640(undefined4 *param_1,undefined4 param_2,uint param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 *param_8,
            ulonglong param_9,uint param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  code *pcVar1;
  uint *puVar2;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint auStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7508;
  pvStack_10 = ExceptionList;
  param_2 = auStack_3c;
  pcVar1 = (code *)*param_1;
  uStack_8 = 1;
  auStack_3c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_3c;
  if (param_10 != 0) {
    auStack_3c[0] = param_10;
    if ((param_10 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_12;
      uStack_4c = 0xabe6ae;
      ExceptionList = &pvStack_10;
      (**(code **)(param_10 & 0xfffffffe))();
      puVar2 = param_2;
    }
    else {
      uStack_34 = param_12;
      uStack_30 = param_13;
      uStack_2c = param_14;
      uStack_28 = param_15;
      uStack_24 = param_16;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_3c;
    }
  }
  param_2 = puVar2;
  uStack_8._0_1_ = 2;
  if (param_3 != 0) {
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_54,0);
    }
    else {
      uStack_54 = param_5;
      uStack_50 = param_6;
      uStack_4c = param_7;
      puStack_48 = param_8;
      uStack_44 = param_9;
    }
  }
  uStack_8._0_1_ = 1;
  (*pcVar1)();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  uStack_8 = 4;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_10 & 0xfffffffe))(&param_12,&param_12,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22114 ; VA 0x00abe770 ; FUN_00abe770 */

int __thiscall FUN_00abe770(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0xa8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0xa0);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x8c);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_00abe8ad;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x9c) = 0;
  *(undefined4 *)(param_1 + 0xa0) = 0xf;
  *(undefined *)(param_1 + 0x8c) = 0;
  uVar3 = *(uint *)(param_1 + 0x88);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x74);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_00abe8ad;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0xf;
  *(undefined *)(param_1 + 0x74) = 0;
  uVar3 = *(uint *)(param_1 + 0x70);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x5c);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_00abe8ad:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0xf;
  *(undefined *)(param_1 + 0x5c) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xac);
  }
  return param_1;
}



/* FUNCTION 22115 ; VA 0x00abe8c0 ; FUN_00abe8c0 */

undefined4 * FUN_00abe8c0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_006724f0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 22116 ; VA 0x00abe930 ; FUN_00abe930 */

undefined4 __thiscall FUN_00abe930(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_34 [4];
  int *piStack_30;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e7548;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined4 *)FUN_009d0ef0(auStack_34,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcStack_28 = *(code **)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcStack_28)(*puVar3,puVar3[1]);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[1] + -1;
    piStack_30[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piStack_30 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 22117 ; VA 0x00abea10 ; FUN_00abea10 */

undefined4 __thiscall FUN_00abea10(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x5c);
  return param_2;
}



/* FUNCTION 22118 ; VA 0x00abea30 ; FUN_00abea30 */

undefined4 __thiscall FUN_00abea30(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x74);
  return param_2;
}



/* FUNCTION 22119 ; VA 0x00abea50 ; FUN_00abea50 */

void __thiscall FUN_00abea50(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xa8);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0xa8);
  }
  *param_2 = *(undefined4 *)(param_1 + 0xa4);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 22120 ; VA 0x00abea90 ; FUN_00abea90 */

void __thiscall FUN_00abea90(int param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  uint in_stack_00000024;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7590;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0xa4);
  uStack_8 = 1;
  if (iVar2 == 0) {
    uStack_40 = uStack_40 & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("Emulated policy info is empty",0x1d);
    uStack_8._0_1_ = 4;
    if (in_stack_00000024 == 0) {
      FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0();
    }
    (**(code **)((in_stack_00000024 & 0xfffffffe) + 4))
              (&stack0x0000002c,uStack_40,uStack_3c,uStack_38,uStack_34,0xf00000000);
  }
  else {
    iVar1 = *(int *)(param_1 + 0xa8);
    ExceptionList = &pvStack_10;
    if (iVar1 != 0) {
      LOCK();
      ExceptionList = &pvStack_10;
      *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
      UNLOCK();
      iVar2 = *(int *)(param_1 + 0xa4);
      iVar1 = *(int *)(param_1 + 0xa8);
    }
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    if (param_2 == 0) {
      FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0();
    }
    (**(code **)((param_2 & 0xfffffffe) + 4))(&stack0x0000000c,iVar2,iVar1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  uStack_8 = 7;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22121 ; VA 0x00abec10 ; FUN_00abec10 */

undefined4 __thiscall FUN_00abec10(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x8c);
  return param_2;
}



/* FUNCTION 22122 ; VA 0x00abec30 ; FUN_00abec30 */

undefined4 * FUN_00abec30(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_1c [5];
  uint uStack_8;
  
  puVar4 = (undefined4 *)(*(code *)*param_2)(aiStack_1c);
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  if (0xf < uStack_8) {
    uVar6 = uStack_8 + 1;
    iVar5 = aiStack_1c[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_1c[0] + -4);
      uVar6 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  return param_1;
}



/* FUNCTION 22123 ; VA 0x00abecc0 ; FUN_00abecc0 */

void FUN_00abecc0(int param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
                 ulonglong param_10,uint param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e75c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uVar2 = *(undefined4 *)(param_1 + 8);
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_11 != 0) {
    uStack_3c = param_11;
    if ((param_11 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_13;
      uStack_4c = 0xabed2c;
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_13;
      uStack_30 = param_14;
      uStack_2c = param_15;
      puStack_28 = (undefined4 *)param_16;
      uStack_24 = param_17;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_54,0);
    }
    else {
      uStack_54 = param_6;
      uStack_50 = param_7;
      uStack_4c = param_8;
      puStack_48 = param_9;
      uStack_44 = param_10;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00abe640(uVar2);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      uStack_24 = CONCAT44(0xabed9c,(undefined4)uStack_24);
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uStack_24 = CONCAT44(0xabedab,(undefined4)uStack_24);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_6;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xabedcc;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_13;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xabedfa;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22124 ; VA 0x00abee10 ; FUN_00abee10 */

uint FUN_00abee10(void)

{
  int iVar1;
  
  iVar1 = FUN_00abe1a0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 22125 ; VA 0x00abee30 ; FUN_00abee30 */

uint FUN_00abee30(void)

{
  int iVar1;
  
  iVar1 = FUN_00abe1a0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 22126 ; VA 0x00abee50 ; FUN_00abee50 */

void FUN_00abee50(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd2424);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::_mfi::cmf0<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::PlayerEmulatorService>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::PlayerEmulatorService*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 22127 ; VA 0x00abeec0 ; FUN_00abeec0 */

void FUN_00abeec0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd215c);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::PlayerEmulatorService,class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list3<class_boost::_bi::value<class_RBX::PlayerEmulatorService*>,struct_boost::arg<2>,struct_boost::arg<3>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 22128 ; VA 0x00abef30 ; FUN_00abef30 */

void __thiscall FUN_00abef30(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  if ((undefined4 *)(param_1 + 0x5c) != param_2) {
    puVar1 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar1);
  }
  if (DAT_01d665a8 != '\0') {
    FUN_008a4940(&DAT_02127c80);
    FUN_00abf4c0();
    return;
  }
  FUN_008a4940(&DAT_02127b50);
  return;
}



/* FUNCTION 22129 ; VA 0x00abef90 ; FUN_00abef90 */

void __thiscall FUN_00abef90(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_1c [5];
  uint uStack_8;
  
  puVar4 = (undefined4 *)FUN_00f854f0(aiStack_1c,param_2);
  if ((undefined4 *)(param_1 + 0x74) != puVar4) {
    FUN_005507b0();
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *(undefined4 *)(param_1 + 0x74) = *puVar4;
    *(undefined4 *)(param_1 + 0x78) = uVar1;
    *(undefined4 *)(param_1 + 0x7c) = uVar2;
    *(undefined4 *)(param_1 + 0x80) = uVar3;
    *(undefined8 *)(param_1 + 0x84) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
  }
  if (0xf < uStack_8) {
    uVar6 = uStack_8 + 1;
    iVar5 = aiStack_1c[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_1c[0] + -4);
      uVar6 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  FUN_008a4940(&DAT_02127c48);
  FUN_00abf590();
  return;
}



/* FUNCTION 22130 ; VA 0x00abf030 ; FUN_00abf030 */

int FUN_00abf030(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined auStack_cc [20];
  int *piStack_b8;
  int *piStack_b4;
  int *piStack_a8;
  uint *puStack_a4;
  int *piStack_98;
  uint uStack_8c;
  uint uStack_88;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7604;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uStack_8._0_1_ = 1;
  FUN_00cb57f0(auStack_cc,param_1,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_14 = 2;
  if (((uStack_88 & 2) == 0) && (uVar3 = *puStack_a4, uVar3 != 0)) {
    if (uVar3 < uStack_8c) {
      uVar3 = uStack_8c;
    }
    iVar2 = *piStack_b4;
    iVar4 = uVar3 - iVar2;
  }
  else {
    if (((uStack_88 & 4) != 0) || (*piStack_a8 == 0)) goto LAB_00abf100;
    iVar2 = *piStack_b8;
    iVar4 = (*piStack_a8 - iVar2) + *piStack_98;
  }
  FUN_005542c0(iVar2,iVar4);
LAB_00abf100:
  uStack_8 = 3;
  FUN_00abf1e0(auStack_2c);
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar3 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar3 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar5);
  }
  iVar2 = FUN_005705c0();
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar4 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar2 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar2 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 22131 ; VA 0x00abf190 ; FUN_00abf190 */

void __thiscall FUN_00abf190(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x58) = param_2;
  if (DAT_01d665a8 == '\0') {
    FUN_008a4940(&DAT_02127b18);
  }
  else {
    FUN_008a4940(&DAT_02127c10);
    if (*(char *)(param_1 + 0x58) != '\0') {
      FUN_00abf590();
      FUN_00abf4c0();
      FUN_00abf610();
      return;
    }
  }
  return;
}



/* FUNCTION 22132 ; VA 0x00abf1e0 ; FUN_00abf1e0 */

void __thiscall FUN_00abf1e0(int param_1,byte *param_2)

{
  int *piVar1;
  code *pcVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  byte *pbVar7;
  byte *pbVar8;
  byte *pbVar9;
  bool bVar10;
  undefined auStack_cc [36];
  uint *puStack_a8;
  uint *puStack_a4;
  uint *puStack_98;
  uint *puStack_94;
  uint *puStack_88;
  int *piStack_84;
  uint uStack_7c;
  uint uStack_78;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7623;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_2 + 0x10);
  if (uVar3 == 0) {
    return;
  }
  pbVar9 = (byte *)(param_1 + 0x8c);
  pbVar8 = param_2;
  if (0xf < *(uint *)(param_2 + 0x14)) {
    pbVar8 = *(byte **)param_2;
  }
  pbVar7 = pbVar9;
  if (0xf < *(uint *)(param_1 + 0xa0)) {
    pbVar7 = *(byte **)pbVar9;
  }
  uVar4 = *(uint *)(param_1 + 0x9c);
  if (uVar3 < *(uint *)(param_1 + 0x9c)) {
    uVar4 = uVar3;
  }
  while (uVar3 = uVar4 - 4, 3 < uVar4) {
    if (*(int *)pbVar7 != *(int *)pbVar8) goto LAB_00abf256;
    pbVar7 = pbVar7 + 4;
    pbVar8 = pbVar8 + 4;
    uVar4 = uVar3;
  }
  if (uVar3 != 0xfffffffc) {
LAB_00abf256:
    bVar10 = *pbVar7 < *pbVar8;
    if ((*pbVar7 != *pbVar8) ||
       ((uVar3 != 0xfffffffd &&
        ((bVar10 = pbVar7[1] < pbVar8[1], pbVar7[1] != pbVar8[1] ||
         ((uVar3 != 0xfffffffe &&
          ((bVar10 = pbVar7[2] < pbVar8[2], pbVar7[2] != pbVar8[2] ||
           ((uVar3 != 0xffffffff && (bVar10 = pbVar7[3] < pbVar8[3], pbVar7[3] != pbVar8[3])))))))))
        ))) {
      uVar3 = -(uint)bVar10 | 1;
      goto LAB_00abf28c;
    }
  }
  uVar3 = 0;
LAB_00abf28c:
  uVar4 = *(uint *)(param_2 + 0x10);
  if (((uVar3 != 0) || (*(uint *)(param_1 + 0x9c) < uVar4)) || (uVar4 < *(uint *)(param_1 + 0x9c)))
  {
    ExceptionList = &pvStack_10;
    iStack_14 = param_1;
    if (pbVar9 != param_2) {
      if (0xf < *(uint *)(param_2 + 0x14)) {
        param_2 = *(byte **)param_2;
      }
      ExceptionList = &pvStack_10;
      FUN_005542c0(param_2,uVar4);
    }
    FUN_008a4940(&DAT_02127cb8);
    FUN_00565940(3,1);
    uStack_8 = 0;
    FUN_00577980();
    uVar3 = *(uint *)(param_1 + 0x9c);
    if (0xf < *(uint *)(param_1 + 0xa0)) {
      pbVar9 = *(byte **)pbVar9;
    }
    if (0x7fffffff < uVar3) {
      FUN_010c5e30();
      pcVar2 = (code *)swi(3);
      (*pcVar2)();
      return;
    }
    if ((uVar3 == 0) || (((byte)uStack_78 & 6) == 6)) {
      uStack_7c = 0;
    }
    else {
      uVar4 = FUN_00554060(uVar3);
      FUN_0170c6f0(uVar4,pbVar9,uVar3);
      uStack_7c = uVar3 + uVar4;
      if ((uStack_78 & 4) == 0) {
        *puStack_a8 = uVar4;
        *puStack_98 = uVar4;
        *puStack_88 = uVar3;
      }
      if ((uStack_78 & 2) == 0) {
        uVar3 = uVar4;
        if ((uStack_78 & 0x18) != 0) {
          uVar3 = uStack_7c;
        }
        *puStack_a4 = uVar4;
        *puStack_94 = uVar3;
        *piStack_84 = uStack_7c - uVar3;
        if ((uStack_78 & 4) != 0) {
          *puStack_a8 = uVar4;
          *puStack_98 = 0;
          *puStack_88 = uVar4;
        }
      }
      uStack_78 = uStack_78 | 1;
    }
    piVar5 = (int *)FUN_01674e20(0x24);
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5[1] = 1;
      piVar5[2] = 1;
      *piVar5 = (int)std::
                     _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                     ::vftable;
      *(undefined *)(piVar5 + 3) = 0;
      iVar6 = FUN_00588320(0xb);
      piVar5[4] = iVar6;
      piVar5[5] = 0;
      piVar5[6] = 0x3f800000;
      piVar5[7] = 0;
      piVar5[8] = 0;
    }
    piVar1 = piVar5 + 3;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piStack_1c = piVar1;
    piStack_18 = piVar5;
    FUN_00cb40d0(auStack_cc,piVar1,0);
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    *(int **)(iStack_14 + 0xa4) = piVar1;
    piVar1 = *(int **)(iStack_14 + 0xa8);
    *(int **)(iStack_14 + 0xa8) = piVar5;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar6 = piVar1[1] + -1;
      piVar1[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar6 = piVar1[2] + -1;
        piVar1[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_00abf610();
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[1] + -1;
      piVar5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    FUN_005705c0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22133 ; VA 0x00abf4c0 ; FUN_00abf4c0 */

void __fastcall FUN_00abf4c0(int param_1)

{
  char cVar1;
  int iVar2;
  code *pcStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  
  if (*(int *)(param_1 + 0x6c) != 0) {
    iVar2 = FUN_008f7870(param_1);
    if ((*(char *)(param_1 + 0x58) != '\0') && (iVar2 != 0)) {
      cVar1 = FUN_008ff0d0();
      if (cVar1 != '\0') {
        cVar1 = FUN_008ff0a0();
        if (cVar1 == '\0') {
          iVar2 = FUN_009171d0(param_1);
          if (iVar2 != 0) {
            pcStack_30 = FUN_00abea10;
            uStack_2c = 0;
            iStack_28 = param_1;
            cVar1 = FUN_00585a40(&pcStack_30);
            if (cVar1 == '\0') {
              FUN_00a4cac0(&DAT_01949179);
              return;
            }
            FUN_00a4cac0(0);
          }
        }
      }
    }
  }
  return;
}



/* FUNCTION 22134 ; VA 0x00abf590 ; FUN_00abf590 */

void __fastcall FUN_00abf590(int param_1)

{
  char cVar1;
  int iVar2;
  
  if (((((*(int *)(param_1 + 0x84) != 0) &&
        (iVar2 = FUN_008f7870(param_1), *(char *)(param_1 + 0x58) != '\0')) && (iVar2 != 0)) &&
      ((cVar1 = FUN_008ff0d0(), cVar1 != '\0' && (cVar1 = FUN_008ff0a0(), cVar1 == '\0')))) &&
     ((iVar2 = FUN_009171d0(param_1), iVar2 != 0 &&
      ((*(int *)(param_1 + 0x84) != 0 &&
       (FUN_00a4c5c0(param_1 + 0x74), *(int *)(param_1 + 0x84) != 0)))))) {
    FUN_00a4c1e0(param_1 + 0x74);
  }
  return;
}



/* FUNCTION 22135 ; VA 0x00abf610 ; FUN_00abf610 */

void __fastcall FUN_00abf610(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  code *pcStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  
  if ((((*(int *)(param_1 + 0xa4) != 0) &&
       (iStack_18 = param_1, iVar2 = FUN_008f7870(param_1), *(char *)(param_1 + 0x58) != '\0')) &&
      (iVar2 != 0)) &&
     ((cVar1 = FUN_008ff0d0(), cVar1 != '\0' && (cVar1 = FUN_008ff0a0(), cVar1 == '\0')))) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar2 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      FUN_005789c0(&DAT_01eaddb4,&LAB_00670c90);
      uVar4 = FUN_00675d30();
      piStack_14 = (int *)FUN_008aa140(uVar4);
      if (*piStack_14 == 0) {
        uVar4 = FUN_00c097f0();
        piVar5 = (int *)FUN_008a9ba0(auStack_20,uVar4);
        iVar2 = *piVar5;
        iVar3 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piStack_14 = iVar2;
        piVar5 = (int *)piStack_14[1];
        piStack_14[1] = iVar3;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar2 = piVar5[1] + -1;
          piVar5[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar2 = piVar5[2] + -1;
            piVar5[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar2 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            piVar5 = piStack_1c + 2;
            iVar2 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
      }
      if (*piStack_14 != 0) {
        pcStack_30 = FUN_00abea90;
        uStack_2c = 0;
        iStack_28 = iStack_18;
        cVar1 = FUN_00585a40(&pcStack_30);
        if (cVar1 == '\0') {
          FUN_00c0e860(&DAT_01949181);
          return;
        }
        FUN_00c0e860(0);
      }
    }
  }
  return;
}



/* FUNCTION 22136 ; VA 0x00abf7e0 ; FUN_00abf7e0 */

undefined4 * __thiscall
FUN_00abf7e0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  void *pvVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar2 = ExceptionList;
  puStack_c = &LAB_017e7638;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_4;
  param_1[1] = param_4[1];
  uStack_8 = 0;
  param_1[2] = *param_3;
  param_1[3] = 0;
  if ((undefined4 *)param_3[1] != (undefined4 *)0x0) {
    (**(code **)param_3[1])(param_3 + 2,param_1 + 4);
    param_1[3] = param_3[1];
    ExceptionList = pvStack_10;
    return param_1;
  }
  param_1[3] = 0;
  ExceptionList = pvVar2;
  return param_1;
}



/* FUNCTION 22137 ; VA 0x00abf890 ; FUN_00abf890 */

undefined4 * __thiscall FUN_00abf890(undefined4 *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000018;
  int in_stack_0000001c;
  undefined auStack_74 [20];
  undefined4 uStack_60;
  int iStack_5c;
  int *piStack_58;
  int aiStack_4c [5];
  uint uStack_38;
  int iStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7668;
  pvStack_10 = ExceptionList;
  piStack_58 = &param_2;
  uStack_8 = 0;
  iStack_5c = 0xabf8c5;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  iStack_34 = in_stack_0000001c;
  piStack_58 = aiStack_4c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_5c = 0xabf8e1;
  FUN_0054ef60();
  iStack_18 = iStack_34;
  piStack_58 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_74;
  FUN_0054ef60(aiStack_30);
  iStack_5c = iStack_18;
  ppuVar3 = &PTR_FUN_0194b58c;
  cVar1 = FUN_00ac1280();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_1c) {
    piStack_58 = (int *)(uStack_1c + 1);
    iVar2 = aiStack_30[0];
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      piStack_58 = (int *)(uStack_1c + 0x24);
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)0xabf9c6;
        FUN_017167a3();
      }
    }
    uStack_60 = 0xabf94a;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_38) {
    piStack_58 = (int *)(uStack_38 + 1);
    iVar2 = aiStack_4c[0];
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(aiStack_4c[0] + -4);
      piStack_58 = (int *)(uStack_38 + 0x24);
      if (0x1f < (aiStack_4c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)0xabf9cb;
        FUN_017167a3();
      }
    }
    uStack_60 = 0xabf97a;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000018) {
    piStack_58 = (int *)(in_stack_00000018 + 1);
    iVar2 = param_2;
    if (0xfff < piStack_58) {
      iVar2 = *(int *)(param_2 + -4);
      piStack_58 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)&UNK_00abf9d0;
        FUN_017167a3();
      }
    }
    uStack_60 = 0xabf9aa;
    iStack_5c = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22138 ; VA 0x00abf9e0 ; FUN_00abf9e0 */

undefined4 * __thiscall
FUN_00abf9e0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_00ac1420(param_2,param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 22139 ; VA 0x00abfae0 ; FUN_00abfae0 */

undefined4 * __thiscall FUN_00abfae0(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  int in_stack_00000024;
  undefined auStack_a4 [24];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  int iStack_84;
  undefined auStack_80 [24];
  undefined4 uStack_68;
  undefined4 uStack_64;
  int iStack_60;
  undefined auStack_5c [24];
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  undefined auStack_38 [24];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e76ba;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  FUN_0054ef60(&stack0x00000004);
  uStack_8c = in_stack_0000001c;
  if (in_stack_00000024 != 0) {
    LOCK();
    *(int *)(in_stack_00000024 + 8) = *(int *)(in_stack_00000024 + 8) + 1;
    UNLOCK();
  }
  uStack_88 = in_stack_00000020;
  iStack_84 = in_stack_00000024;
  uStack_8._0_1_ = 1;
  FUN_0054ef60(auStack_a4);
  uStack_68 = uStack_8c;
  if (iStack_84 != 0) {
    LOCK();
    *(int *)(iStack_84 + 8) = *(int *)(iStack_84 + 8) + 1;
    UNLOCK();
  }
  uStack_64 = uStack_88;
  iStack_60 = iStack_84;
  uStack_8._0_1_ = 2;
  FUN_0054ef60(auStack_80);
  uStack_20 = uStack_68;
  if (iStack_60 != 0) {
    LOCK();
    *(int *)(iStack_60 + 8) = *(int *)(iStack_60 + 8) + 1;
    UNLOCK();
  }
  uStack_1c = uStack_64;
  iStack_18 = iStack_60;
  uStack_8._0_1_ = 3;
  cVar2 = FUN_00585a40(auStack_38);
  if (cVar2 == '\0') {
    FUN_0054ef60(auStack_38);
    uStack_44 = uStack_20;
    if (iStack_18 != 0) {
      LOCK();
      *(int *)(iStack_18 + 8) = *(int *)(iStack_18 + 8) + 1;
      UNLOCK();
    }
    uStack_40 = uStack_1c;
    iStack_3c = iStack_18;
    uStack_8._0_1_ = 4;
    iVar3 = FUN_01674e20(0x24);
    uStack_8._0_1_ = 5;
    iStack_14 = iVar3;
    if (iVar3 == 0) {
      iVar3 = 0;
    }
    else {
      FUN_0054ef60(auStack_5c);
      *(undefined4 *)(iVar3 + 0x18) = uStack_44;
      *(undefined4 *)(iVar3 + 0x1c) = 0;
      *(undefined4 *)(iVar3 + 0x20) = 0;
      if (iStack_3c != 0) {
        LOCK();
        *(int *)(iStack_3c + 8) = *(int *)(iStack_3c + 8) + 1;
        UNLOCK();
      }
      *(undefined4 *)(iVar3 + 0x1c) = uStack_40;
      *(int *)(iVar3 + 0x20) = iStack_3c;
    }
    param_1[2] = iVar3;
    FUN_00ac7bb0();
    FUN_00ac7bb0();
    bVar1 = true;
  }
  else {
    FUN_00ac7bb0();
    bVar1 = false;
  }
  FUN_00ac7bb0();
  ppuVar4 = &PTR_FUN_0194b584;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00ac7bb0();
  FUN_00ac7bb0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22140 ; VA 0x00abfca0 ; FUN_00abfca0 */

undefined4 * __thiscall
FUN_00abfca0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_00ac1530(param_2,param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 22141 ; VA 0x00abfda0 ; FUN_00abfda0 */

undefined4 * __fastcall FUN_00abfda0(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  undefined **ppuVar4;
  undefined auStack_dc [40];
  undefined auStack_b4 [40];
  undefined auStack_8c [40];
  undefined auStack_64 [40];
  undefined auStack_3c [40];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7718;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008c1490(&stack0x00000004);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_008c1490(auStack_dc);
  uStack_8._0_1_ = 2;
  FUN_008c1490(auStack_b4);
  uStack_8._0_1_ = 3;
  FUN_008c1490(auStack_8c);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(auStack_3c);
  if (cVar2 == '\0') {
    FUN_008c1490(auStack_3c);
    uStack_8._0_1_ = 5;
    puStack_14 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 6;
    if (puStack_14 == (undefined4 *)0x0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_008c1490(auStack_64);
    }
    param_1[2] = uVar3;
    FUN_008c3670();
    FUN_008c3670();
    bVar1 = true;
  }
  else {
    FUN_008c3670();
    bVar1 = false;
  }
  FUN_008c3670();
  ppuVar4 = &PTR_FUN_0194b51c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_008c3670();
  FUN_008c3670();
  FUN_008c3670();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22142 ; VA 0x00abfee0 ; FUN_00abfee0 */

undefined4 * __thiscall
FUN_00abfee0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11,undefined8 param_12)

{
  undefined4 *puVar1;
  char cVar2;
  undefined **ppuVar3;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  uint uStack_70;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 *puStack_50;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7740;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_34 = 0;
  if (param_6 != 0) {
    uStack_34 = param_6;
    if ((param_6 & 1) == 0) {
      puStack_50 = (undefined4 *)0x0;
      uStack_58 = CONCAT44(&uStack_2c,&param_8);
      uStack_5c = 0xabff58;
      (**(code **)(param_6 & 0xfffffffe))();
    }
    else {
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      uStack_20 = param_11;
      uStack_1c = param_12;
    }
  }
  puStack_50 = param_1 + 2;
  uStack_8._0_1_ = 1;
  puStack_14 = (undefined *)&uStack_80;
  uStack_80 = param_2;
  uStack_7c = param_3;
  uStack_78 = param_4;
  uStack_70 = 0;
  puVar1 = &uStack_80;
  if (uStack_34 != 0) {
    uStack_70 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_68,0);
      puVar1 = (undefined4 *)puStack_14;
    }
    else {
      uStack_68 = uStack_2c;
      uStack_64 = uStack_28;
      uStack_60 = uStack_24;
      uStack_5c = uStack_20;
      uStack_58 = uStack_1c;
      puVar1 = &uStack_80;
    }
  }
  puStack_14 = (undefined *)puVar1;
  ppuVar3 = &PTR_FUN_0194b52c;
  cVar2 = FUN_00ac1640();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    puStack_50 = (undefined4 *)0x2;
    uStack_58 = CONCAT44(&uStack_2c,&uStack_2c);
    uStack_5c = 0xabfff4;
    (**(code **)(uStack_34 & 0xfffffffe))();
  }
  uStack_8 = 3;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_50 = (undefined4 *)0x2;
    uStack_58 = CONCAT44(&param_8,&param_8);
    uStack_5c = 0xac0022;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22143 ; VA 0x00ac0040 ; FUN_00ac0040 */

undefined4 __thiscall FUN_00ac0040(undefined4 param_1)

{
  uint in_stack_00000014;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined8 in_stack_0000002c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7758;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (in_stack_00000014 != 0) {
    if ((in_stack_00000014 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000014 & 0xfffffffe))(&stack0x0000001c,&uStack_34,0);
    }
    else {
      uStack_34 = in_stack_0000001c;
      uStack_30 = in_stack_00000020;
      uStack_2c = in_stack_00000024;
      uStack_28 = in_stack_00000028;
      uStack_24 = in_stack_0000002c;
      ExceptionList = &pvStack_10;
    }
  }
  FUN_00abfee0();
  uStack_8 = 1;
  if (((in_stack_00000014 != 0) && ((in_stack_00000014 & 1) == 0)) &&
     (*(code **)(in_stack_00000014 & 0xfffffffe) != (code *)0x0)) {
    uStack_1c = 2;
    uStack_24 = CONCAT44(&stack0x0000001c,&stack0x0000001c);
    uStack_28 = 0xac00ea;
    (**(code **)(in_stack_00000014 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22144 ; VA 0x00ac0100 ; FUN_00ac0100 */

undefined4 * __thiscall FUN_00ac0100(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_19c [72];
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined auStack_14c [72];
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined auStack_fc [72];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined auStack_ac [72];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined auStack_5c [72];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e77bb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00ac4d90(&stack0x0000000c);
  uStack_154 = param_2;
  uStack_150 = param_3;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00ac4d90(auStack_19c);
  uStack_104 = uStack_154;
  uStack_100 = uStack_150;
  uStack_8._0_1_ = 2;
  FUN_00ac4d90(auStack_14c);
  uStack_64 = uStack_104;
  uStack_60 = uStack_100;
  uStack_8._0_1_ = 3;
  FUN_00ac4d90(auStack_fc);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(&uStack_64);
  if (cVar2 == '\0') {
    uStack_b4 = uStack_64;
    uStack_b0 = uStack_60;
    FUN_00ac4d90(auStack_5c);
    uStack_8._0_1_ = 5;
    puVar3 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 6;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_b4;
      puVar3[1] = uStack_b0;
      FUN_00ac4d90(auStack_ac);
    }
    param_1[2] = puVar3;
    FUN_0096ca80();
    FUN_0096ca80();
    bVar1 = true;
  }
  else {
    FUN_0096ca80();
    bVar1 = false;
  }
  FUN_0096ca80();
  ppuVar4 = &PTR_FUN_0194b524;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_0096ca80();
  FUN_0096ca80();
  FUN_0096ca80();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22145 ; VA 0x00ac02c0 ; FUN_00ac02c0 */

undefined4 * __thiscall FUN_00ac02c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_00000034;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_cc;
  undefined *puStack_c8;
  undefined *puStack_c4;
  undefined4 *puStack_c0;
  undefined auStack_ac [40];
  uint uStack_84;
  undefined auStack_7c [24];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined auStack_5c [40];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e77eb;
  pvStack_10 = ExceptionList;
  puStack_c0 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_c4 = (undefined *)0xac030d;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00ac5050();
  uStack_64 = param_2;
  uStack_60 = param_3;
  puStack_c0 = (undefined4 *)auStack_ac;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_c4 = (undefined *)0xac0338;
  FUN_00ac5050();
  puStack_c0 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = &uStack_110;
  uStack_110 = uStack_64;
  uStack_10c = uStack_60;
  FUN_00ac5050(auStack_5c);
  ppuVar2 = &PTR_FUN_0194b56c;
  cVar1 = FUN_00ac1800();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = auStack_2c;
      puStack_c0 = (undefined4 *)0x2;
      uStack_cc = 0xac0395;
      puStack_c4 = puStack_c8;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_c0 = (undefined4 *)0xac03a7;
  FUN_00ac8540();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_84 != 0) {
    if (((uStack_84 & 1) == 0) && (*(code **)(uStack_84 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = auStack_7c;
      puStack_c0 = (undefined4 *)0x2;
      uStack_cc = 0xac03c8;
      puStack_c4 = puStack_c8;
      (**(code **)(uStack_84 & 0xfffffffe))();
    }
    uStack_84 = 0;
  }
  puStack_c0 = (undefined4 *)0xac03dd;
  FUN_00ac8540();
  uStack_8 = 5;
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = &stack0x0000003c;
      puStack_c0 = (undefined4 *)0x2;
      uStack_cc = 0xac0401;
      puStack_c4 = puStack_c8;
      (**(code **)(in_stack_00000034 & 0xfffffffe))();
    }
    in_stack_00000034 = 0;
  }
  puStack_c0 = (undefined4 *)0xac0413;
  FUN_00ac8540();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22146 ; VA 0x00ac0430 ; FUN_00ac0430 */

undefined4 * __thiscall FUN_00ac0430(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  char cVar5;
  undefined **ppuVar6;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined auStack_60 [20];
  undefined4 uStack_4c;
  int *piStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [20];
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7818;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a66ab0(&stack0x0000000c);
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_4c = in_stack_00000020;
  piStack_48 = in_stack_00000024;
  uStack_40 = param_2;
  uStack_3c = param_3;
  *param_1 = 0;
  FUN_00a66ab0(auStack_60);
  piVar4 = piStack_48;
  if (piStack_48 != (int *)0x0) {
    LOCK();
    piStack_48[1] = piStack_48[1] + 1;
    UNLOCK();
  }
  uStack_24 = uStack_4c;
  piStack_20 = piStack_48;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar7 = uStack_40;
  uVar8 = uStack_3c;
  FUN_00a66ab0(auStack_38);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  ppuVar6 = &PTR_FUN_0194b534;
  cVar5 = FUN_00ac19b0(uVar7,uVar8);
  piVar2 = piStack_20;
  if (cVar5 == '\0') {
    ppuVar6 = (undefined **)0x0;
  }
  *param_1 = ppuVar6;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00a678e0();
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00a678e0();
  piVar4 = in_stack_00000024;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar2 = piVar4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00a678e0();
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 22147 ; VA 0x00ac05c0 ; FUN_00ac05c0 */

undefined4 * __thiscall FUN_00ac05c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_0000006c;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_13c;
  undefined *puStack_138;
  undefined *puStack_134;
  undefined4 *puStack_130;
  undefined auStack_11c [96];
  uint uStack_bc;
  undefined auStack_b4 [24];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined auStack_94 [96];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e784e;
  pvStack_10 = ExceptionList;
  puStack_130 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_134 = (undefined *)0xac060d;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00ac7310();
  uStack_9c = param_2;
  uStack_98 = param_3;
  puStack_130 = (undefined4 *)auStack_11c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_134 = (undefined *)0xac0641;
  FUN_00ac7310();
  puStack_130 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = &uStack_1b8;
  uStack_1b8 = uStack_9c;
  uStack_1b4 = uStack_98;
  FUN_00ac7310(auStack_94);
  ppuVar2 = &PTR_FUN_0194b564;
  cVar1 = FUN_00ac1b90();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = auStack_2c;
      puStack_130 = (undefined4 *)0x2;
      uStack_13c = 0xac06aa;
      puStack_134 = puStack_138;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_130 = (undefined4 *)0xac06bf;
  FUN_00ac8750();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_bc != 0) {
    if (((uStack_bc & 1) == 0) && (*(code **)(uStack_bc & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = auStack_b4;
      puStack_130 = (undefined4 *)0x2;
      uStack_13c = 0xac06e6;
      puStack_134 = puStack_138;
      (**(code **)(uStack_bc & 0xfffffffe))();
    }
    uStack_bc = 0;
  }
  puStack_130 = (undefined4 *)0xac06fe;
  FUN_00ac8750();
  uStack_8 = 5;
  if (in_stack_0000006c != 0) {
    if (((in_stack_0000006c & 1) == 0) &&
       (*(code **)(in_stack_0000006c & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = &stack0x00000074;
      puStack_130 = (undefined4 *)0x2;
      uStack_13c = 0xac0722;
      puStack_134 = puStack_138;
      (**(code **)(in_stack_0000006c & 0xfffffffe))();
    }
    in_stack_0000006c = 0;
  }
  puStack_130 = (undefined4 *)0xac0734;
  FUN_00ac8750();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22148 ; VA 0x00ac0750 ; FUN_00ac0750 */

undefined4 * __thiscall FUN_00ac0750(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_0000006c;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_13c;
  undefined *puStack_138;
  undefined *puStack_134;
  undefined4 *puStack_130;
  undefined auStack_11c [96];
  uint uStack_bc;
  undefined auStack_b4 [24];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined auStack_94 [96];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e784e;
  pvStack_10 = ExceptionList;
  puStack_130 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_134 = (undefined *)0xac079d;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00ac7310();
  uStack_9c = param_2;
  uStack_98 = param_3;
  puStack_130 = (undefined4 *)auStack_11c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_134 = (undefined *)0xac07d1;
  FUN_00ac7310();
  puStack_130 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = &uStack_1b8;
  uStack_1b8 = uStack_9c;
  uStack_1b4 = uStack_98;
  FUN_00ac7310(auStack_94);
  ppuVar2 = &PTR_FUN_0194b554;
  cVar1 = FUN_00ac1b90();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = auStack_2c;
      puStack_130 = (undefined4 *)0x2;
      uStack_13c = 0xac083a;
      puStack_134 = puStack_138;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_130 = (undefined4 *)0xac084f;
  FUN_00ac8750();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_bc != 0) {
    if (((uStack_bc & 1) == 0) && (*(code **)(uStack_bc & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = auStack_b4;
      puStack_130 = (undefined4 *)0x2;
      uStack_13c = 0xac0876;
      puStack_134 = puStack_138;
      (**(code **)(uStack_bc & 0xfffffffe))();
    }
    uStack_bc = 0;
  }
  puStack_130 = (undefined4 *)0xac088e;
  FUN_00ac8750();
  uStack_8 = 5;
  if (in_stack_0000006c != 0) {
    if (((in_stack_0000006c & 1) == 0) &&
       (*(code **)(in_stack_0000006c & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = &stack0x00000074;
      puStack_130 = (undefined4 *)0x2;
      uStack_13c = 0xac08b2;
      puStack_134 = puStack_138;
      (**(code **)(in_stack_0000006c & 0xfffffffe))();
    }
    in_stack_0000006c = 0;
  }
  puStack_130 = (undefined4 *)0xac08c4;
  FUN_00ac8750();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22149 ; VA 0x00ac08e0 ; FUN_00ac08e0 */

undefined4 * __thiscall FUN_00ac08e0(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = FUN_00adb720();
  *param_1 = uVar2;
  iVar3 = FUN_00adb9a0();
  iVar1 = param_1[1];
  if (iVar1 == iVar3) {
    param_1[2] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = *param_2;
  param_1[1] = iVar3;
  return param_1;
}



/* FUNCTION 22150 ; VA 0x00ac0940 ; FUN_00ac0940 */

int * __thiscall FUN_00ac0940(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00adb9a0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 22151 ; VA 0x00ac0990 ; FUN_00ac0990 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00ac0990(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee226c) {
    FUN_016f3809(&DAT_01ee226c);
    if (DAT_01ee226c == -1) {
      _DAT_01ee2260 = FUN_005c65e0;
      _DAT_01ee2264 = FUN_005c65e0;
      _DAT_01ee2268 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee226c);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01ee2260) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01ee2260;
  return param_1;
}



/* FUNCTION 22152 ; VA 0x00ac0a40 ; FUN_00ac0a40 */

undefined4 * __thiscall FUN_00ac0a40(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = FUN_00adb880();
  *param_1 = uVar2;
  iVar3 = FUN_00adba10();
  iVar1 = param_1[1];
  if (iVar1 == iVar3) {
    param_1[2] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = *param_2;
  param_1[1] = iVar3;
  return param_1;
}



/* FUNCTION 22153 ; VA 0x00ac0aa0 ; FUN_00ac0aa0 */

int * __thiscall FUN_00ac0aa0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00adba10();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 22154 ; VA 0x00ac0af0 ; FUN_00ac0af0 */

void __thiscall FUN_00ac0af0(int param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  code *pcVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  int iStack_60;
  undefined8 uStack_5c;
  uint uStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  undefined8 uStack_34;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7880;
  pvStack_10 = ExceptionList;
  uStack_4c = 0;
  uVar2 = *(uint *)(param_1 + 8);
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_4c = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_5c = ZEXT48(&uStack_44);
      iStack_60 = param_1 + 0x10;
      uStack_64 = 0xac0b4c;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_44 = *(undefined4 *)(param_1 + 0x10);
      uStack_40 = *(undefined4 *)(param_1 + 0x14);
      uStack_3c = *(undefined4 *)(param_1 + 0x18);
      iStack_38 = *(int *)(param_1 + 0x1c);
      uStack_34 = *(undefined8 *)(param_1 + 0x20);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_5c = CONCAT44(*param_4,0xac0b63);
  FUN_0054ef60();
  uStack_8 = 2;
  pcVar1 = (code *)*param_3;
  if (uStack_4c != 0) {
    if ((uStack_4c & 1) == 0) {
      (**(code **)(uStack_4c & 0xfffffffe))(&uStack_44,&uStack_6c,0);
    }
    else {
      uStack_6c = uStack_44;
      uStack_68 = uStack_40;
      uStack_64 = uStack_3c;
      iStack_60 = iStack_38;
      uStack_5c = uStack_34;
    }
  }
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_2c);
  uStack_8._0_1_ = 2;
  (*pcVar1)();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8 = 4;
  if (((uStack_4c != 0) && ((uStack_4c & 1) == 0)) &&
     (*(code **)(uStack_4c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_4c & 0xfffffffe))(&uStack_44,&uStack_44,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22155 ; VA 0x00ac0c60 ; FUN_00ac0c60 */

void __fastcall FUN_00ac0c60(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e78b8;
  pvStack_10 = ExceptionList;
  uVar2 = *param_1;
  uVar3 = param_1[0x16];
  ExceptionList = &pvStack_10;
  if ((uVar3 != 0) && (ExceptionList = &pvStack_10, (uVar3 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  uStack_8 = 0;
  uVar3 = param_1[0xe];
  if ((uVar3 != 0) && ((uVar3 & 1) == 0)) {
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  if (param_1[0xc] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[0xc] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_1[10] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[10] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_1[8] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[8] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(param_1 + 1);
  uStack_8 = 0xffffffff;
  FUN_00aca580(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22156 ; VA 0x00ac0dd0 ; FUN_00ac0dd0 */

void __fastcall FUN_00ac0dd0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7900;
  pvStack_10 = ExceptionList;
  uVar2 = *param_1;
  uVar3 = param_1[0x18];
  ExceptionList = &pvStack_10;
  if ((uVar3 != 0) && (ExceptionList = &pvStack_10, (uVar3 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  uStack_8 = 0;
  uVar3 = param_1[0x10];
  if ((uVar3 != 0) && ((uVar3 & 1) == 0)) {
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  if (param_1[0xe] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[0xe] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_1[0xc] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[0xc] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_1[10] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[10] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_1[8] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[8] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0054ef60(param_1 + 1);
  uStack_8 = 0xffffffff;
  FUN_00aca810(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22157 ; VA 0x00ac0f70 ; FUN_00ac0f70 */

undefined * FUN_00ac0f70(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e791c;
  pvStack_10 = ExceptionList;
  if (DAT_01eeb6b0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb8c0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eeb8c0);
      if (DAT_01eeb8c0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"TeleportService",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0188b690);
        FUN_016f37bf(&DAT_01eeb8c0);
      }
    }
    DAT_01eeb6b0 = &DAT_01eeb6b8;
  }
  ExceptionList = pvStack_10;
  return DAT_01eeb6b0;
}



/* FUNCTION 22158 ; VA 0x00ac1050 ; FUN_00ac1050 */

void FUN_00ac1050(void)

{
  int iVar1;
  
  if (DAT_01eeb8c4 == 0) {
    iVar1 = FUN_00ac0f70();
    DAT_01eeb8c4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 22159 ; VA 0x00ac1070 ; FUN_00ac1070 */

void __thiscall FUN_00ac1070(float *param_1,float *param_2,byte *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  float fVar3;
  uint uVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7930;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  fVar3 = param_1[1];
  uVar4 = (uint)param_1[6] &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193;
  fVar5 = *(float *)((int)param_1[3] + uVar4 * 8);
  pfStack_1c = param_1;
  if (fVar3 != fVar5) {
    fVar3 = **(float **)((int)param_1[3] + 4 + uVar4 * 8);
    while (fVar3 != fVar5) {
      fVar3 = *(float *)((int)fVar3 + 4);
      if (*(int *)param_3 == *(int *)((int)fVar3 + 8)) {
        ExceptionList = &pvStack_10;
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        puStack_14 = &stack0xffffffd0;
        FUN_01674ea0(param_4,0x10);
        *param_2 = fVar3;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  ExceptionList = &pvStack_10;
  if (fVar3 != fVar5) {
    ExceptionList = &pvStack_10;
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar3;
    **(undefined4 **)((int)fVar3 + 4) = param_4;
    fVar1 = *(float *)((int)fVar3 + 4);
    *(undefined4 *)((int)fVar3 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar4 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar4 * 8) = param_4;
  }
  else if (fVar1 == fVar3) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar4 * 8);
    *(float **)((int)fVar5 + 4 + uVar4 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar4 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar4 * 8) + 4);
    }
  }
  fVar3 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar3 + (double)(&DAT_018c0d90)[-((int)fVar3 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar3 < 0x200) {
      fVar3 = (float)((int)fVar3 << 3);
    }
    else if ((uint)fVar3 < 0x1fffffff) {
      fVar3 = (float)((int)fVar3 * 2);
    }
    FUN_005cb500(fVar3);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar3 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00ac1070(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar3);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22160 ; VA 0x00ac1256 ; Catch_All@00ac1256 */

void Catch_All_00ac1256(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00ac3210(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 22161 ; VA 0x00ac1280 ; FUN_00ac1280 */

undefined FUN_00ac1280(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined uVar5;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  int aiStack_4c [5];
  uint uStack_38;
  undefined4 uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7967;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_18 = in_stack_0000001c;
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_30);
  if (cVar1 == '\0') {
    FUN_0054ef60(auStack_30);
    uStack_34 = uStack_18;
    uStack_8._0_1_ = 2;
    iVar2 = FUN_01674e20(0x1c);
    uStack_8._0_1_ = 3;
    iStack_14 = iVar2;
    if (iVar2 == 0) {
      iVar2 = 0;
    }
    else {
      FUN_0054ef60(aiStack_4c);
      *(undefined4 *)(iVar2 + 0x18) = uStack_34;
    }
    *in_stack_00000020 = iVar2;
    if (0xf < uStack_38) {
      uVar3 = uStack_38 + 1;
      iVar2 = aiStack_4c[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_4c[0] + -4);
        uVar3 = uStack_38 + 0x24;
        if (0x1f < (aiStack_4c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    if (0xf < uStack_1c) {
      uVar4 = uStack_1c + 1;
      uVar3 = auStack_30[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_30[0] - 4);
        uVar4 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 1;
  }
  else {
    if (0xf < uStack_1c) {
      uVar4 = uStack_1c + 1;
      uVar3 = auStack_30[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_30[0] - 4);
        uVar4 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 0;
  }
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_1c = 0xf;
  uStack_20 = 0;
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 22162 ; VA 0x00ac1420 ; FUN_00ac1420 */

undefined ** __thiscall
FUN_00ac1420(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  cVar3 = FUN_00963340(param_2,param_3,param_4,param_5,param_1 + 2,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0194b50c;
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = (int)ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    ppuVar4 = (undefined **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      ppuVar4 = (undefined **)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuVar4 = (undefined **)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      ppuVar4 = (undefined **)(**(code **)(*param_3 + 4))();
    }
  }
  return ppuVar4;
}



/* FUNCTION 22163 ; VA 0x00ac1530 ; FUN_00ac1530 */

undefined ** __thiscall
FUN_00ac1530(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  cVar3 = FUN_00963340(param_2,param_3,param_4,param_5,param_1 + 2,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0194b514;
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = (int)ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    ppuVar4 = (undefined **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      ppuVar4 = (undefined **)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuVar4 = (undefined **)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      ppuVar4 = (undefined **)(**(code **)(*param_3 + 4))();
    }
  }
  return ppuVar4;
}



/* FUNCTION 22164 ; VA 0x00ac1640 ; FUN_00ac1640 */

undefined FUN_00ac1640(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined4 param_9,undefined4 param_10,undefined8 param_11,
                      undefined4 *param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined uVar3;
  undefined auStack_74 [16];
  uint uStack_64;
  undefined auStack_5c [24];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e79a7;
  pvStack_10 = ExceptionList;
  uStack_44 = param_1;
  uStack_40 = param_2;
  uStack_3c = param_3;
  uStack_8 = 0;
  uStack_34 = 0;
  uStack_14 = param_5;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    uStack_34 = param_5;
    if ((param_5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_2c,0);
    }
    else {
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = param_10;
      uStack_1c = param_11;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_14 = param_5;
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(&uStack_44);
  if (cVar1 == '\0') {
    FUN_008e72f0(&uStack_44);
    uStack_8._0_1_ = 2;
    uStack_14 = FUN_01674e20(0x30);
    uStack_8._0_1_ = 3;
    if (uStack_14 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_008e72f0(auStack_74);
    }
    *param_12 = uVar2;
    uStack_8._0_1_ = 4;
    if (uStack_64 != 0) {
      if (((uStack_64 & 1) == 0) && (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_64 & 0xfffffffe))(auStack_5c,auStack_5c,2);
      }
      uStack_64 = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
      }
      uStack_34 = 0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
        uStack_14 = param_5;
      }
      uStack_34 = 0;
    }
    uVar3 = 0;
    param_5 = uStack_14;
  }
  uStack_8 = 7;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    param_12._3_1_ = uVar3;
    (**(code **)(param_5 & 0xfffffffe))(&param_7,&param_7,2);
    ExceptionList = pvStack_10;
    return param_12._3_1_;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 22165 ; VA 0x00ac1800 ; FUN_00ac1800 */

undefined FUN_00ac1800(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined uVar5;
  uint in_stack_00000034;
  int *in_stack_00000054;
  undefined auStack_ac [40];
  uint uStack_84;
  undefined auStack_7c [24];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined auStack_5c [40];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e79ea;
  pvStack_10 = ExceptionList;
  uStack_64 = param_1;
  uStack_60 = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ac5050(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(&uStack_64);
  uVar2 = uStack_60;
  uVar1 = uStack_64;
  if (cVar3 == '\0') {
    FUN_00ac5050(auStack_5c);
    uStack_8._0_1_ = 2;
    puVar4 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[1] = uVar2;
      FUN_00ac5050(auStack_ac);
    }
    *in_stack_00000054 = (int)puVar4;
    uStack_8._0_1_ = 4;
    if (uStack_84 != 0) {
      if (((uStack_84 & 1) == 0) && (*(code **)(uStack_84 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_84 & 0xfffffffe))(auStack_7c,auStack_7c,2);
      }
      uStack_84 = 0;
    }
    FUN_00ac8540();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00ac8540();
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00ac8540();
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000034 & 0xfffffffe))(&stack0x0000003c,&stack0x0000003c,2);
    }
    in_stack_00000034 = 0;
  }
  FUN_00ac8540();
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 22166 ; VA 0x00ac19b0 ; FUN_00ac19b0 */

undefined FUN_00ac19b0(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined uVar7;
  int *piVar8;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  int *in_stack_0000002c;
  undefined auStack_58 [20];
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [20];
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7a18;
  pvStack_10 = ExceptionList;
  uStack_38 = param_1;
  uStack_34 = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a66ab0(&stack0x0000000c);
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_1c = in_stack_00000020;
  piStack_18 = in_stack_00000024;
  uStack_8._0_1_ = 1;
  cVar5 = FUN_00585a40(&uStack_38);
  piVar8 = piStack_18;
  uVar4 = uStack_34;
  uVar3 = uStack_38;
  if (cVar5 == '\0') {
    FUN_00a66ab0(auStack_30);
    piVar8 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    uStack_44 = uStack_1c;
    piStack_40 = piStack_18;
    uStack_8._0_1_ = 2;
    puVar6 = (undefined4 *)FUN_01674e20(0x28);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = uVar3;
      puVar6[1] = uVar4;
      FUN_00a66ab0(auStack_58);
      puVar6[7] = 0;
      puVar6[8] = 0;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        piStack_40[1] = piStack_40[1] + 1;
        UNLOCK();
      }
      puVar6[7] = uStack_44;
      puVar6[8] = piStack_40;
      piVar8 = piStack_40;
    }
    *in_stack_0000002c = (int)puVar6;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar2 = piVar8[1] + -1;
      piVar8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar2 = piVar8[2] + -1;
        piVar8[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    FUN_00a678e0();
    piVar8 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar8 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    FUN_00a678e0();
    uVar7 = 1;
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar8 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    FUN_00a678e0();
    uVar7 = 0;
  }
  piVar8 = in_stack_00000024;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  FUN_00a678e0();
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 22167 ; VA 0x00ac1b90 ; FUN_00ac1b90 */

undefined FUN_00ac1b90(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined uVar5;
  uint in_stack_0000006c;
  int *in_stack_0000008c;
  undefined auStack_11c [96];
  uint uStack_bc;
  undefined auStack_b4 [24];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined auStack_94 [96];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7a60;
  pvStack_10 = ExceptionList;
  uStack_9c = param_1;
  uStack_98 = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ac7310(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(&uStack_9c);
  uVar2 = uStack_98;
  uVar1 = uStack_9c;
  if (cVar3 == '\0') {
    FUN_00ac7310(auStack_94);
    uStack_8._0_1_ = 2;
    puVar4 = (undefined4 *)FUN_01674e20(0x88);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[1] = uVar2;
      FUN_00ac7310(auStack_11c);
    }
    *in_stack_0000008c = (int)puVar4;
    uStack_8._0_1_ = 4;
    if (uStack_bc != 0) {
      if (((uStack_bc & 1) == 0) && (*(code **)(uStack_bc & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_bc & 0xfffffffe))(auStack_b4,auStack_b4,2);
      }
      uStack_bc = 0;
    }
    FUN_00ac8750();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00ac8750();
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00ac8750();
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (in_stack_0000006c != 0) {
    if (((in_stack_0000006c & 1) == 0) &&
       (*(code **)(in_stack_0000006c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000006c & 0xfffffffe))(&stack0x00000074,&stack0x00000074,2);
    }
    in_stack_0000006c = 0;
  }
  FUN_00ac8750();
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 22168 ; VA 0x00ac1d70 ; FUN_00ac1d70 */

uint * FUN_00ac1d70(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,
                   uint param_6,uint param_7,undefined8 param_8,uint param_9,int *param_10)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  uint uStack_20;
  int *piStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_10;
  puStack_c = &LAB_017e7a90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  uStack_14 = param_9;
  if (param_10 != (int *)0x0) {
    piVar1 = param_10 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_20 = param_9;
  piStack_1c = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 2;
  uStack_40 = 0;
  if (param_2 != 0) {
    uStack_40 = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_38,0);
    }
    else {
      uStack_38 = param_4;
      uStack_34 = param_5;
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
    }
  }
  uStack_8._0_1_ = 3;
  *param_1 = 0;
  if (uStack_40 != 0) {
    *param_1 = uStack_40;
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_38;
      param_1[3] = uStack_34;
      param_1[4] = uStack_30;
      param_1[5] = uStack_2c;
      *(undefined8 *)(param_1 + 6) = uStack_28;
    }
  }
  param_1[8] = 0;
  param_1[9] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
  }
  param_1[8] = uStack_14;
  param_1[9] = (uint)piVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  piVar3 = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22169 ; VA 0x00ac1f70 ; FUN_00ac1f70 */

undefined4 *
FUN_00ac1f70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11,undefined8 param_12)

{
  uint uStack_74;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7ac0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  if (param_6 != 0) {
    uStack_34 = param_6;
    if ((param_6 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_2c,0);
    }
    else {
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      uStack_20 = param_11;
      uStack_1c = param_12;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_4c,0);
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  uStack_8._0_1_ = 2;
  uStack_74 = 0;
  if (uStack_54 != 0) {
    uStack_74 = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_6c,0);
    }
    else {
      uStack_6c = uStack_4c;
      uStack_68 = uStack_48;
      uStack_64 = uStack_44;
      uStack_60 = uStack_40;
      uStack_5c = uStack_3c;
    }
  }
  uStack_8._0_1_ = 3;
  if (uStack_54 != 0) {
    if (((uStack_54 & 1) == 0) && (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
    }
    uStack_54 = 0;
  }
  uStack_8._0_1_ = 4;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 5;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[4] = 0;
  if (uStack_74 != 0) {
    param_1[4] = uStack_74;
    if ((uStack_74 & 1) == 0) {
      (**(code **)(uStack_74 & 0xfffffffe))(&uStack_6c,param_1 + 6,0);
    }
    else {
      param_1[6] = uStack_6c;
      param_1[7] = uStack_68;
      param_1[8] = uStack_64;
      param_1[9] = uStack_60;
      *(undefined8 *)(param_1 + 10) = uStack_5c;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((uStack_74 != 0) && ((uStack_74 & 1) == 0)) &&
     (*(code **)(uStack_74 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_74 & 0xfffffffe))(&uStack_6c,&uStack_6c,2);
  }
  uStack_8 = 7;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_6 & 0xfffffffe))(&param_8,&param_8,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22170 ; VA 0x00ac2190 ; FUN_00ac2190 */

undefined4 *
FUN_00ac2190(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19)

{
  undefined4 uVar1;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 *puStack_90;
  ulonglong uStack_8c;
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 *puStack_70;
  undefined8 uStack_6c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7af0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_84 = 0;
  ExceptionList = &pvStack_10;
  if (param_13 != 0) {
    uStack_84 = param_13;
    if ((param_13 & 1) == 0) {
      uStack_8c = ZEXT48(&uStack_7c);
      puStack_90 = &param_15;
      uStack_94 = 0xac21f7;
      ExceptionList = &pvStack_10;
      (**(code **)(param_13 & 0xfffffffe))();
    }
    else {
      uStack_7c = param_15;
      uStack_78 = param_16;
      uStack_74 = param_17;
      puStack_70 = (undefined4 *)param_18;
      uStack_6c = param_19;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_9c,0);
    }
    else {
      uStack_9c = param_8;
      uStack_98 = param_9;
      uStack_94 = param_10;
      puStack_90 = param_11;
      uStack_8c = param_12;
    }
  }
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00ac4e60(param_4,param_5);
  uStack_8._0_1_ = 3;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_6c = CONCAT44(uVar1,0xac2274);
  FUN_00ac4d90();
  uStack_6c = CONCAT44(0xac227c,(undefined4)uStack_6c);
  FUN_0096ca80();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_70 = &param_8;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0xac229d;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_70 = &param_15;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0xac22cb;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22171 ; VA 0x00ac22e0 ; FUN_00ac22e0 */

undefined4 *
FUN_00ac22e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,int *param_7,uint param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 *param_13,
            ulonglong param_14)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint auStack_94 [2];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 *puStack_80;
  undefined8 uStack_7c;
  undefined auStack_6c [48];
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  ulonglong uStack_24;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7b28;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_8 != 0) {
    uStack_3c = param_8;
    if ((param_8 & 1) == 0) {
      uStack_7c = ZEXT48(&uStack_34);
      puStack_80 = &param_10;
      uStack_84 = 0xac233e;
      ExceptionList = &pvStack_10;
      (**(code **)(param_8 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_10;
      uStack_30 = param_11;
      uStack_2c = param_12;
      puStack_28 = param_13;
      uStack_24 = param_14;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  uStack_1c = param_6;
  piStack_18 = param_7;
  puStack_14 = (undefined *)auStack_94;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  auStack_94[0] = 0;
  puVar3 = auStack_94;
  if (uStack_3c != 0) {
    auStack_94[0] = uStack_3c;
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_8c,0);
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_8c = uStack_34;
      uStack_88 = uStack_30;
      uStack_84 = uStack_2c;
      puStack_80 = puStack_28;
      uStack_7c = uStack_24;
      puVar3 = auStack_94;
    }
  }
  puStack_14 = (undefined *)puVar3;
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  FUN_00ac5df0(param_4,param_5,param_6,param_7);
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_7c = CONCAT44(0xac23e3,(undefined4)uStack_7c);
      (**(code **)*param_7)();
      LOCK();
      iVar2 = param_7[2] + -1;
      param_7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_7c = CONCAT44(0xac23f3,(undefined4)uStack_7c);
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 4;
  if (uStack_3c != 0) {
    if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
      puStack_80 = &uStack_34;
      uStack_7c = CONCAT44(2,puStack_80);
      uStack_84 = 0xac2418;
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    uStack_3c = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_7c = CONCAT44(auStack_6c,0xac2440);
  FUN_00ac4f90();
  uStack_7c = CONCAT44(0xac2448,(undefined4)uStack_7c);
  FUN_00ac85c0();
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_7c = CONCAT44(0xac245f,(undefined4)uStack_7c);
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_7c = CONCAT44(0xac2471,(undefined4)uStack_7c);
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  uStack_8 = 6;
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    puStack_80 = &param_10;
    uStack_7c = CONCAT44(2,puStack_80);
    uStack_84 = 0xac2495;
    (**(code **)(param_8 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22172 ; VA 0x00ac24b0 ; FUN_00ac24b0 */

undefined4 *
FUN_00ac24b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  undefined4 *in_stack_0000002c;
  int *in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined *in_stack_00000048;
  undefined8 in_stack_0000004c;
  undefined auStack_ac [16];
  undefined4 uStack_9c;
  undefined4 *puStack_98;
  undefined4 *puStack_94;
  int *piStack_90;
  uint auStack_8c [2];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 *puStack_78;
  undefined8 uStack_74;
  uint uStack_3c;
  undefined auStack_34 [24];
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7b70;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_8c;
  puStack_18 = (undefined *)auStack_8c;
  uStack_8 = 2;
  auStack_8c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar4 = auStack_8c;
  if (in_stack_00000034 != 0) {
    auStack_8c[0] = in_stack_00000034;
    if ((in_stack_00000034 & 1) == 0) {
      puStack_94 = &uStack_84;
      piStack_90 = (int *)0x0;
      puStack_98 = &stack0x0000003c;
      uStack_9c = 0xac2518;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000034 & 0xfffffffe))();
      puVar4 = (uint *)puStack_14;
    }
    else {
      uStack_84 = in_stack_0000003c;
      uStack_80 = in_stack_00000040;
      uStack_7c = in_stack_00000044;
      puStack_78 = (undefined4 *)in_stack_00000048;
      uStack_74 = in_stack_0000004c;
      ExceptionList = &pvStack_10;
      puVar4 = auStack_8c;
    }
  }
  puStack_14 = (undefined *)puVar4;
  puStack_18 = (undefined *)&puStack_94;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  puStack_94 = in_stack_0000002c;
  piStack_90 = in_stack_00000030;
  puStack_1c = auStack_ac;
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_5);
  uStack_8._0_1_ = 2;
  uVar5 = FUN_00ac5120(param_4);
  uStack_8._0_1_ = 5;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_74 = CONCAT44(uVar5,0xac258a);
  FUN_00ac5050();
  uStack_8._0_1_ = 6;
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = (undefined4 *)auStack_34;
    uStack_74 = CONCAT44(2,puStack_78);
    uStack_7c = 0xac25ab;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_74 = CONCAT44(0xac25bd,(undefined4)uStack_74);
  FUN_00ac8540();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < in_stack_00000028) {
    uVar7 = in_stack_00000028 + 1;
    uVar6 = param_5;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(param_5 - 4);
      uVar7 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - uVar6) - 4) {
        uStack_74 = CONCAT44(&UNK_00ac2670,(undefined4)uStack_74);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_74 = CONCAT44(uVar7,uVar6);
    puStack_78 = (undefined4 *)0xac25f2;
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000030;
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_74 = CONCAT44(0xac2620,(undefined4)uStack_74);
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_74 = CONCAT44(0xac262f,(undefined4)uStack_74);
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 7;
  if (((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) &&
     (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &stack0x0000003c;
    uStack_74 = CONCAT44(2,puStack_78);
    uStack_7c = 0xac2656;
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22173 ; VA 0x00ac2680 ; FUN_00ac2680 */

undefined4 *
FUN_00ac2680(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 in_stack_00000034;
  int *in_stack_00000038;
  undefined4 in_stack_0000003c;
  int *in_stack_00000040;
  undefined4 *in_stack_00000044;
  int *in_stack_00000048;
  uint in_stack_0000004c;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined4 *in_stack_00000060;
  ulonglong in_stack_00000064;
  uint in_stack_0000006c;
  undefined4 in_stack_00000074;
  undefined4 in_stack_00000078;
  undefined4 in_stack_0000007c;
  undefined *in_stack_00000080;
  undefined8 in_stack_00000084;
  undefined auStack_12c [24];
  undefined4 uStack_114;
  int *piStack_110;
  undefined4 uStack_10c;
  int *piStack_108;
  undefined4 uStack_104;
  int *piStack_100;
  undefined4 *puStack_fc;
  int *piStack_f8;
  uint auStack_f4 [2];
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 *puStack_e0;
  ulonglong uStack_dc;
  uint auStack_d4 [2];
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 *puStack_c0;
  undefined8 uStack_bc;
  uint uStack_4c;
  undefined auStack_44 [24];
  undefined *puStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7bf3;
  pvStack_10 = ExceptionList;
  puStack_20 = (undefined *)auStack_d4;
  puStack_18 = (undefined *)auStack_d4;
  uStack_8 = 6;
  auStack_d4[0] = 0;
  ExceptionList = &pvStack_10;
  puVar4 = auStack_d4;
  if (in_stack_0000006c != 0) {
    auStack_d4[0] = in_stack_0000006c;
    if ((in_stack_0000006c & 1) == 0) {
      uStack_dc = ZEXT48(&uStack_cc);
      puStack_e0 = &stack0x00000074;
      uStack_e4 = 0xac26ee;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_0000006c & 0xfffffffe))();
      puVar4 = (uint *)puStack_20;
    }
    else {
      uStack_cc = in_stack_00000074;
      uStack_c8 = in_stack_00000078;
      uStack_c4 = in_stack_0000007c;
      puStack_c0 = (undefined4 *)in_stack_00000080;
      uStack_bc = in_stack_00000084;
      ExceptionList = &pvStack_10;
      puVar4 = auStack_d4;
    }
  }
  puStack_20 = (undefined *)puVar4;
  puStack_18 = (undefined *)auStack_f4;
  puStack_1c = (undefined *)auStack_f4;
  uStack_8._0_1_ = 7;
  auStack_f4[0] = 0;
  puVar4 = auStack_f4;
  if (in_stack_0000004c != 0) {
    auStack_f4[0] = in_stack_0000004c;
    if ((in_stack_0000004c & 1) == 0) {
      puStack_fc = &uStack_ec;
      piStack_f8 = (int *)0x0;
      piStack_100 = &stack0x00000054;
      uStack_104 = 0xac2739;
      (**(code **)(in_stack_0000004c & 0xfffffffe))();
      puVar4 = (uint *)puStack_18;
    }
    else {
      uStack_ec = in_stack_00000054;
      uStack_e8 = in_stack_00000058;
      uStack_e4 = in_stack_0000005c;
      puStack_e0 = in_stack_00000060;
      uStack_dc = in_stack_00000064;
      puVar4 = auStack_f4;
    }
  }
  puStack_18 = (undefined *)puVar4;
  puStack_1c = (undefined *)&puStack_fc;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    in_stack_00000048[1] = in_stack_00000048[1] + 1;
    UNLOCK();
  }
  puStack_fc = in_stack_00000044;
  piStack_f8 = in_stack_00000048;
  puStack_24 = (undefined *)&uStack_104;
  if (in_stack_00000040 != (int *)0x0) {
    LOCK();
    in_stack_00000040[1] = in_stack_00000040[1] + 1;
    UNLOCK();
  }
  uStack_104 = in_stack_0000003c;
  piStack_100 = in_stack_00000040;
  puStack_28 = (undefined *)&uStack_10c;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    in_stack_00000038[1] = in_stack_00000038[1] + 1;
    UNLOCK();
  }
  uStack_10c = in_stack_00000034;
  piStack_108 = in_stack_00000038;
  puStack_2c = (undefined *)&uStack_114;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  uStack_114 = in_stack_0000002c;
  piStack_110 = in_stack_00000030;
  puStack_14 = auStack_12c;
  uStack_8._0_1_ = 0xc;
  FUN_0054ef60(&param_5);
  uStack_8._0_1_ = 6;
  uVar5 = FUN_00ac5760(param_4);
  uStack_8._0_1_ = 0xd;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_bc = CONCAT44(uVar5,0xac282f);
  FUN_00ac7310();
  uStack_8._0_1_ = 0xe;
  if (((uStack_4c != 0) && ((uStack_4c & 1) == 0)) &&
     (*(code **)(uStack_4c & 0xfffffffe) != (code *)0x0)) {
    puStack_c0 = (undefined4 *)auStack_44;
    uStack_bc = CONCAT44(2,puStack_c0);
    uStack_c4 = 0xac2850;
    (**(code **)(uStack_4c & 0xfffffffe))();
  }
  uStack_bc = CONCAT44(0xac2865,(undefined4)uStack_bc);
  FUN_00ac8750();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < in_stack_00000028) {
    uVar7 = in_stack_00000028 + 1;
    uVar6 = param_5;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(param_5 - 4);
      uVar7 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - uVar6) - 4) {
        uStack_bc = CONCAT44(&UNK_00ac29b3,(undefined4)uStack_bc);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_bc = CONCAT44(uVar7,uVar6);
    puStack_c0 = (undefined4 *)0xac289a;
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000030;
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_bc = CONCAT44(0xac28c8,(undefined4)uStack_bc);
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_bc = CONCAT44(0xac28d8,(undefined4)uStack_bc);
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000038;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000038[1] + -1;
    in_stack_00000038[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_bc = CONCAT44(0xac28ee,(undefined4)uStack_bc);
      (**(code **)*in_stack_00000038)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_bc = CONCAT44(0xac28fe,(undefined4)uStack_bc);
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000040;
  if (in_stack_00000040 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000040[1] + -1;
    in_stack_00000040[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_bc = CONCAT44(0xac2914,(undefined4)uStack_bc);
      (**(code **)*in_stack_00000040)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_bc = CONCAT44(0xac2924,(undefined4)uStack_bc);
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000048;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000048[1] + -1;
    in_stack_00000048[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_bc = CONCAT44(0xac293a,(undefined4)uStack_bc);
      (**(code **)*in_stack_00000048)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_bc = CONCAT44(0xac2949,(undefined4)uStack_bc);
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (in_stack_0000004c != 0) {
    if (((in_stack_0000004c & 1) == 0) &&
       (*(code **)(in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
      puStack_c0 = &stack0x00000054;
      uStack_bc = CONCAT44(2,puStack_c0);
      uStack_c4 = 0xac296a;
      (**(code **)(in_stack_0000004c & 0xfffffffe))();
    }
    in_stack_0000004c = 0;
  }
  uStack_8 = 0x10;
  if (((in_stack_0000006c != 0) && ((in_stack_0000006c & 1) == 0)) &&
     (*(code **)(in_stack_0000006c & 0xfffffffe) != (code *)0x0)) {
    puStack_c0 = &stack0x00000074;
    uStack_bc = CONCAT44(2,puStack_c0);
    uStack_c4 = 0xac2998;
    (**(code **)(in_stack_0000006c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22174 ; VA 0x00ac29c0 ; FUN_00ac29c0 */

undefined4 *
FUN_00ac29c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 in_stack_00000034;
  int *in_stack_00000038;
  undefined4 in_stack_0000003c;
  int *in_stack_00000040;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  uint in_stack_00000064;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 in_stack_00000074;
  undefined4 in_stack_00000078;
  undefined8 in_stack_0000007c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7c63;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000064 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000064 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000064 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 6;
  if ((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) {
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  if (in_stack_00000040 != (int *)0x0) {
    LOCK();
    in_stack_00000040[1] = in_stack_00000040[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    in_stack_00000038[1] = in_stack_00000038[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 10;
  FUN_0054ef60(&param_5);
  uStack_8._0_1_ = 5;
  FUN_00ac54d0(param_4);
  uStack_8._0_1_ = 0xb;
  *param_1 = param_2;
  param_1[1] = param_3;
  FUN_00ac6f20();
  FUN_00ac87e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < in_stack_00000028) {
    if ((0xfff < in_stack_00000028 + 1) && (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000030;
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000038;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000038[1] + -1;
    in_stack_00000038[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000038)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000040;
  if (in_stack_00000040 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000040[1] + -1;
    in_stack_00000040[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000040)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (in_stack_00000044 != 0) {
    if (((in_stack_00000044 & 1) == 0) &&
       (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
    }
    in_stack_00000044 = 0;
  }
  uStack_8 = 0xd;
  if (((in_stack_00000064 != 0) && ((in_stack_00000064 & 1) == 0)) &&
     (*(code **)(in_stack_00000064 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000064 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22175 ; VA 0x00ac2c80 ; FUN_00ac2c80 */

undefined4 *
FUN_00ac2c80(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,undefined4 param_9,
            int *param_10)

{
  int *piVar1;
  int iVar2;
  int *piStack_c;
  
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  iVar2 = FUN_00ac53c0(param_4);
  *param_1 = param_2;
  param_1[1] = param_3;
  FUN_00a66ab0();
  param_1[7] = 0;
  param_1[8] = 0;
  if (*(int *)(iVar2 + 0x18) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x18) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[7] = *(undefined4 *)(iVar2 + 0x14);
  param_1[8] = *(undefined4 *)(iVar2 + 0x18);
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  FUN_00a678e0();
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22176 ; VA 0x00ac2e00 ; FUN_00ac2e00 */

undefined4
FUN_00ac2e00(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5,undefined4 param_6,int param_7,undefined4 param_8,int param_9,
            int param_10)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7c90;
  pvStack_10 = ExceptionList;
  uVar2 = *param_5;
  param_1 = param_5[1];
  ExceptionList = &pvStack_10;
  if (*(int *)(param_10 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_10 + 4) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0;
  if (*(undefined4 **)(param_9 + 4) != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)(param_9 + 4))();
  }
  uStack_8._0_1_ = 1;
  FUN_0054ef60();
  if (*(int *)(param_7 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_7 + 4) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_6);
  uStack_8 = 0xffffffff;
  (*param_2)(uVar2,param_1);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 22177 ; VA 0x00ac2f20 ; FUN_00ac2f20 */

undefined4
FUN_00ac2f20(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5,undefined4 param_6,int param_7,undefined4 param_8,int param_9,
            int param_10)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7cc0;
  pvStack_10 = ExceptionList;
  uVar2 = *param_5;
  param_1 = param_5[1];
  ExceptionList = &pvStack_10;
  if (*(int *)(param_10 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_10 + 4) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0;
  if (*(undefined4 **)(param_9 + 4) != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)(param_9 + 4))();
  }
  uStack_8._0_1_ = 1;
  FUN_0054ef60();
  if (*(int *)(param_7 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_7 + 4) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_6);
  uStack_8 = 0xffffffff;
  (*param_2)(uVar2,param_1);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 22178 ; VA 0x00ac3040 ; FUN_00ac3040 */

int * __fastcall FUN_00ac3040(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_00adb880();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00ac30db:
    thunk_FUN_00adb880();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_00adb880();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00ac30db;
    FUN_00ac0aa0(&piStack_8);
    iVar3 = FUN_00adb880();
    *param_1 = iVar3;
    iVar2 = FUN_00adb880();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22179 ; VA 0x00ac3110 ; FUN_00ac3110 */

void __fastcall FUN_00ac3110(int param_1)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  int iStack_24;
  int iStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7ce0;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x2c);
  if (iVar3 != 0) {
    piVar6 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      iVar3 = *(int *)(param_1 + 0x2c);
      piVar6 = *(int **)(param_1 + 0x30);
    }
    uStack_8 = 0;
    FUN_00569460(iVar3);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar3 = piVar6[1] + -1;
      piVar6[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uVar7 = 0;
    uVar5 = iStack_20 - iStack_24 >> 3;
    if (uVar5 != 0) {
      do {
        if (uVar5 <= uVar7) {
          FUN_00577c40();
          pcVar2 = (code *)swi(3);
          (*pcVar2)();
          return;
        }
        iVar3 = *(int *)(iStack_24 + uVar7 * 8);
        if ((iVar3 == 0) ||
           (iVar3 = *(int *)(iVar3 + 0xc), iVar4 = FUN_00ae2430(),
           (uint)*(ushort *)(iVar4 + 0x1da) <
           (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
          FUN_00ac3110();
        }
        else {
          (**(code **)(**(int **)(iStack_24 + uVar7 * 8) + 0x2c))();
        }
        uVar7 = uVar7 + 1;
      } while (uVar7 < uVar5);
    }
    FUN_00577ac0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22180 ; VA 0x00ac3210 ; FUN_00ac3210 */

void __thiscall FUN_00ac3210(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*(byte *)(param_3 + 2) ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 9))
            * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 10)) * 0x1000193 ^
          (uint)*(byte *)((int)param_3 + 0xb)) * 0x1000193) * 8;
  piVar2 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar2[1] == param_3) {
    if ((int *)*piVar2 == param_3) {
      *piVar2 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar2[1] = param_3[1];
    }
  }
  else if ((int *)*piVar2 == param_3) {
    *piVar2 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_01674ea0(param_3,0x10);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 22181 ; VA 0x00ac32c0 ; FUN_00ac32c0 */

int FUN_00ac32c0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eaddd4,&LAB_00670c00);
  uVar3 = FUN_006758b0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b67e80();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 22182 ; VA 0x00ac3380 ; FUN_00ac3380 */

int __fastcall FUN_00ac3380(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int aiStack_dc [50];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00adb720();
  iVar6 = *param_1;
  if (iVar3 == iVar2) {
    iVar3 = FUN_00adb720();
    if (iVar6 == iVar3) {
      piVar4 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar4 = (int *)0x0;
      }
      ExceptionList = pvStack_10;
      return *piVar4;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar5 = (undefined4 *)param_1[1];
  if (puVar5 != (undefined4 *)0x0) {
    (*(code *)*puVar5)(param_1 + 2,aiStack_dc);
    puVar5 = (undefined4 *)param_1[1];
  }
  uStack_8 = 0;
  iVar3 = FUN_00adb720();
  if (iVar6 == iVar3) {
    piVar4 = aiStack_dc;
    if (puVar5 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) goto LAB_00ac34c8;
  }
  iVar3 = FUN_0088cb40();
  if (iVar6 == iVar3) {
    iVar3 = FUN_0088cb40();
    if (iVar6 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = aiStack_dc;
    if (puVar5 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    FUN_00adb720();
    if (0xf < (uint)piVar4[5]) {
      piVar4 = (int *)*piVar4;
    }
    cVar1 = FUN_009cb180(piVar4,auStack_14);
    if (cVar1 != '\0') {
      FUN_00ac0940(auStack_14);
      iVar3 = FUN_00adb720();
      iVar6 = FUN_00adb720();
      if (iVar3 != iVar6) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar4 = aiStack_dc;
      if (puVar5 == (undefined4 *)0x0) {
        piVar4 = (int *)0x0;
      }
LAB_00ac34c8:
      iVar3 = *piVar4;
      uStack_8 = 1;
      if (puVar5 != (undefined4 *)0x0) {
        (*(code *)puVar5[2])(aiStack_dc);
      }
      ExceptionList = pvStack_10;
      return iVar3;
    }
  }
  thunk_FUN_00adb720();
  uVar7 = FUN_005543f0();
  uVar8 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar8,uVar7);
}



/* FUNCTION 22183 ; VA 0x00ac3540 ; FUN_00ac3540 */

int __fastcall FUN_00ac3540(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int aiStack_dc [50];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00adb880();
  iVar6 = *param_1;
  if (iVar3 == iVar2) {
    iVar3 = FUN_00adb880();
    if (iVar6 == iVar3) {
      piVar4 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar4 = (int *)0x0;
      }
      ExceptionList = pvStack_10;
      return *piVar4;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar5 = (undefined4 *)param_1[1];
  if (puVar5 != (undefined4 *)0x0) {
    (*(code *)*puVar5)(param_1 + 2,aiStack_dc);
    puVar5 = (undefined4 *)param_1[1];
  }
  uStack_8 = 0;
  iVar3 = FUN_00adb880();
  if (iVar6 == iVar3) {
    piVar4 = aiStack_dc;
    if (puVar5 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) goto LAB_00ac3688;
  }
  iVar3 = FUN_0088cb40();
  if (iVar6 == iVar3) {
    iVar3 = FUN_0088cb40();
    if (iVar6 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = aiStack_dc;
    if (puVar5 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    FUN_00adb880();
    if (0xf < (uint)piVar4[5]) {
      piVar4 = (int *)*piVar4;
    }
    cVar1 = FUN_009cb180(piVar4,auStack_14);
    if (cVar1 != '\0') {
      FUN_00ac0aa0(auStack_14);
      iVar3 = FUN_00adb880();
      iVar6 = FUN_00adb880();
      if (iVar3 != iVar6) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar4 = aiStack_dc;
      if (puVar5 == (undefined4 *)0x0) {
        piVar4 = (int *)0x0;
      }
LAB_00ac3688:
      iVar3 = *piVar4;
      uStack_8 = 1;
      if (puVar5 != (undefined4 *)0x0) {
        (*(code *)puVar5[2])(aiStack_dc);
      }
      ExceptionList = pvStack_10;
      return iVar3;
    }
  }
  thunk_FUN_00adb880();
  uVar7 = FUN_005543f0();
  uVar8 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar8,uVar7);
}



/* FUNCTION 22184 ; VA 0x00ac3700 ; thunk_FUN_00adb7d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00adb7d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea3b6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb9b4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb9b4);
    if (DAT_01eeb9b4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("TeleportState");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeb950 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService_TeleportState>::vftable;
      FUN_009caf20(&DAT_01d6684c,5);
      FUN_016f3654(&LAB_0188b5c0);
      FUN_016f37bf(&DAT_01eeb9b4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb950;
}



/* FUNCTION 22185 ; VA 0x00ac3710 ; thunk_FUN_00adb880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00adb880(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea3d6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb94c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb94c);
    if (DAT_01eeb94c == -1) {
      uStack_8 = 0;
      FUN_009ca470("TeleportType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeb8e8 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService_TeleportType>::vftable;
      FUN_009caf20(&DAT_01d66874,3);
      FUN_016f3654(&LAB_0188b5e0);
      FUN_016f37bf(&DAT_01eeb94c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb8e8;
}



/* FUNCTION 22186 ; VA 0x00ac3720 ; FUN_00ac3720 */

void __thiscall FUN_00ac3720(byte *param_1,int param_2,int *param_3,undefined4 *param_4,int param_5)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  
  uVar7 = param_3[1];
  if (((int)uVar7 < 1) && ((int)uVar7 < 0)) {
    uVar7 = ~uVar7;
  }
  uVar7 = (uVar7 >> 2) + uVar7 * 0x40 + *param_3 ^ uVar7;
  FUN_00606ff0(&param_3,uVar7,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  puVar10 = param_4;
  if (param_3 == (int *)0x0) {
    iVar6 = *(int *)(param_2 + 4);
    if (iVar6 == 0) {
      *(undefined2 *)(param_2 + 8) = 0;
      puVar4 = (undefined4 *)FUN_01674e20(0x10);
      *(undefined4 **)(param_2 + 4) = puVar4;
      *puVar4 = 0;
      puVar4[1] = 0;
      *(undefined8 *)(puVar4 + 2) = 0;
      iVar6 = *(int *)(param_2 + 4);
      *(undefined *)(param_2 + 8) = 1;
    }
    else if (*(char *)(param_2 + 9) != '\0') {
      *(undefined *)(param_2 + 9) = 0;
    }
    *(undefined4 *)(iVar6 + 8) = *puVar10;
    *(undefined4 *)(iVar6 + 0xc) = puVar10[1];
    *(undefined *)(param_2 + 9) = 1;
    uVar5 = *(uint *)(param_1 + 8);
    if (*(uint *)(param_1 + 0x10) < uVar5 + 1) {
      uVar9 = param_5 - (int)param_4 >> 3;
      param_3 = (int *)(uVar9 + uVar5);
      if (*(int *)(param_1 + 0x14) == 0) {
        uVar5 = FUN_005c9310(param_3);
        if (uVar5 <= *(uint *)(param_1 + 4)) {
          uVar5 = *(uint *)(param_1 + 4);
        }
        FUN_005d2b00(uVar5);
      }
      else if (*(uint *)(param_1 + 0x10) < param_3) {
        uVar8 = uVar5 >> 1;
        if ((uVar5 >> 1) + uVar5 <= param_3) {
          uVar8 = uVar9;
        }
        iVar6 = FUN_005c9310(uVar8 + uVar5);
        if (iVar6 != *(int *)(param_1 + 4)) {
          FUN_005d2b00(iVar6);
          puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
          puVar4 = (undefined4 *)*puVar10;
          while (puVar4 != (undefined4 *)0x0) {
            piVar1 = (int *)(*(int *)(param_1 + 0x14) +
                            ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4);
            if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4)
                == 0) {
              *piVar1 = (int)puVar10;
              puVar10 = puVar4;
            }
            else {
              *puVar10 = *puVar4;
              *puVar4 = *(undefined4 *)*piVar1;
              *(undefined4 **)*piVar1 = puVar4;
            }
            puVar4 = (undefined4 *)*puVar10;
          }
        }
      }
    }
    piVar3 = *(int **)(param_2 + 4);
    *(undefined4 *)(param_2 + 4) = 0;
    piVar3[1] = uVar7;
    uVar7 = uVar7 % *(uint *)(param_1 + 4);
    puVar10 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (puVar10 == (undefined4 *)0x0) {
      piVar2 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar2 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *piVar1 = (int)piVar2;
      *piVar3 = *piVar2;
      *piVar2 = (int)piVar3;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      return;
    }
    *piVar3 = *puVar10;
    *(int **)*piVar1 = piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  }
  return;
}



/* FUNCTION 22187 ; VA 0x00ac38f0 ; FUN_00ac38f0 */

void FUN_00ac38f0(int *param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a655f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<class_RBX::Timer<0>_>::vftable;
    FUN_01682800(puVar1 + 4);
  }
  *param_1 = (int)(puVar1 + 4);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22188 ; VA 0x00ac3970 ; FUN_00ac3970 */

void FUN_00ac3970(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f937;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x24);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
              ::vftable;
    *(undefined *)(puVar1 + 3) = 0;
    uVar2 = FUN_005c9310(*(undefined4 *)(param_2 + 8));
    puVar1[4] = uVar2;
    puVar1[5] = 0;
    puVar1[6] = *(undefined4 *)(param_2 + 0xc);
    puVar1[7] = 0;
    puVar1[8] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_005c9140(param_2);
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22189 ; VA 0x00ac3a20 ; thunk_FUN_00adb720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00adb720(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea396;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeba84) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeba84);
    if (DAT_01eeba84 == -1) {
      uStack_8 = 0;
      FUN_009ca470("TeleportMethod");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeba20 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService_TeleportMethod>::vftable;
      FUN_009caf20(&DAT_01d6688c,5);
      FUN_016f3654(&LAB_0188b5a0);
      FUN_016f37bf(&DAT_01eeba84);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeba20;
}



/* FUNCTION 22190 ; VA 0x00ac3a30 ; FUN_00ac3a30 */

void FUN_00ac3a30(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined auStack_e4 [200];
  int iStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7d0e;
  pvStack_10 = ExceptionList;
  iVar4 = *param_2;
  iVar3 = *(int *)(iVar4 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00888410();
  if (iVar3 != iVar1) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar5 = (undefined4 *)(iVar4 + 0xd8);
  if (*(int *)(iVar4 + 0xd4) == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  uStack_ec = *puVar5;
  puStack_e8 = (undefined4 *)0x0;
  puVar2 = (undefined4 *)puVar5[1];
  if (puVar2 != (undefined4 *)0x0) {
    (*(code *)*puVar2)(puVar5 + 2,auStack_e4);
    puVar2 = (undefined4 *)puVar5[1];
  }
  param_2 = (int *)*param_2;
  uStack_8 = 0;
  iVar4 = *param_2;
  puStack_e8 = puVar2;
  iVar3 = FUN_0088cdc0();
  if (iVar4 == iVar3) {
    piVar6 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar6 = (int *)0x0;
    }
    iVar4 = piVar6[1];
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar6[1];
    }
    iVar3 = *piVar6;
    uStack_8 = 2;
    iStack_1c = iVar3;
    iStack_18 = iVar4;
    FUN_005caf00(&uStack_ec);
    iStack_1c = 0;
    iStack_18 = 0;
    FUN_00acac20(iVar3,iVar4);
    uStack_8 = 3;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22191 ; VA 0x00ac3b80 ; FUN_00ac3b80 */

undefined4 * __thiscall FUN_00ac3b80(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7d5f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  if (param_2[0xd] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xd] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  param_1[0xe] = 0;
  uVar2 = param_2[0xe];
  uStack_8._0_1_ = 4;
  if (uVar2 != 0) {
    param_1[0xe] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x10,param_1 + 0x10,0);
    }
    else {
      uVar3 = param_2[0x11];
      uVar4 = param_2[0x12];
      uVar5 = param_2[0x13];
      param_1[0x10] = param_2[0x10];
      param_1[0x11] = uVar3;
      param_1[0x12] = uVar4;
      param_1[0x13] = uVar5;
      *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_2 + 0x14);
    }
  }
  param_1[0x16] = 0;
  uVar2 = param_2[0x16];
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (uVar2 != 0) {
    param_1[0x16] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x19];
      uVar4 = param_2[0x1a];
      uVar5 = param_2[0x1b];
      param_1[0x18] = param_2[0x18];
      param_1[0x19] = uVar3;
      param_1[0x1a] = uVar4;
      param_1[0x1b] = uVar5;
      *(undefined8 *)(param_1 + 0x1c) = *(undefined8 *)(param_2 + 0x1c);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x18,param_1 + 0x18,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22192 ; VA 0x00ac3d00 ; FUN_00ac3d00 */

undefined4 * __thiscall
FUN_00ac3d00(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 *param_6,uint *param_7,uint *param_8)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7d5f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = *param_4;
  param_1[9] = param_4[1];
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = *param_5;
  param_1[0xb] = param_5[1];
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  if (param_6[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xc] = *param_6;
  param_1[0xd] = param_6[1];
  param_1[0xe] = 0;
  uStack_8._0_1_ = 4;
  uVar2 = *param_7;
  if (uVar2 != 0) {
    param_1[0xe] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_7 + 2,param_1 + 0x10,0);
    }
    else {
      uVar2 = param_7[3];
      uVar3 = param_7[4];
      uVar4 = param_7[5];
      param_1[0x10] = param_7[2];
      param_1[0x11] = uVar2;
      param_1[0x12] = uVar3;
      param_1[0x13] = uVar4;
      *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_7 + 6);
    }
  }
  param_1[0x16] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uVar2 = *param_8;
  if (uVar2 != 0) {
    param_1[0x16] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar2 = param_8[3];
      uVar3 = param_8[4];
      uVar4 = param_8[5];
      param_1[0x18] = param_8[2];
      param_1[0x19] = uVar2;
      param_1[0x1a] = uVar3;
      param_1[0x1b] = uVar4;
      *(undefined8 *)(param_1 + 0x1c) = *(undefined8 *)(param_8 + 6);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_8 + 2,param_1 + 0x18,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22193 ; VA 0x00ac3e80 ; FUN_00ac3e80 */

undefined4 * __thiscall FUN_00ac3e80(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  return param_1;
}



/* FUNCTION 22194 ; VA 0x00ac3ee0 ; FUN_00ac3ee0 */

undefined8 * __thiscall
FUN_00ac3ee0(undefined8 *param_1,undefined8 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 *param_5,undefined4 *param_6,undefined4 *param_7,undefined4 *param_8,
            uint *param_9,uint *param_10)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7db2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  *(undefined4 *)(param_1 + 1) = *param_3;
  FUN_0054ef60(param_4);
  *(undefined4 *)((int)param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 5) = 0;
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)((int)param_1 + 0x24) = *param_5;
  *(undefined4 *)(param_1 + 5) = param_5[1];
  *(undefined4 *)((int)param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  if (param_6[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)((int)param_1 + 0x2c) = *param_6;
  *(undefined4 *)(param_1 + 6) = param_6[1];
  *(undefined4 *)((int)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  if (param_7[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_7[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)((int)param_1 + 0x34) = *param_7;
  *(undefined4 *)(param_1 + 7) = param_7[1];
  *(undefined4 *)((int)param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  if (param_8[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_8[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)((int)param_1 + 0x3c) = *param_8;
  *(undefined4 *)(param_1 + 8) = param_8[1];
  *(undefined4 *)(param_1 + 9) = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  uVar2 = *param_9;
  if (uVar2 != 0) {
    *(uint *)(param_1 + 9) = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_9 + 2,param_1 + 10,0);
    }
    else {
      uVar2 = param_9[3];
      uVar3 = param_9[4];
      uVar4 = param_9[5];
      *(uint *)(param_1 + 10) = param_9[2];
      *(uint *)((int)param_1 + 0x54) = uVar2;
      *(uint *)(param_1 + 0xb) = uVar3;
      *(uint *)((int)param_1 + 0x5c) = uVar4;
      param_1[0xc] = *(undefined8 *)(param_9 + 6);
    }
  }
  *(undefined4 *)(param_1 + 0xd) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uVar2 = *param_10;
  if (uVar2 != 0) {
    *(uint *)(param_1 + 0xd) = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar2 = param_10[3];
      uVar3 = param_10[4];
      uVar4 = param_10[5];
      *(uint *)(param_1 + 0xe) = param_10[2];
      *(uint *)((int)param_1 + 0x74) = uVar2;
      *(uint *)(param_1 + 0xf) = uVar3;
      *(uint *)((int)param_1 + 0x7c) = uVar4;
      param_1[0x10] = *(undefined8 *)(param_10 + 6);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_10 + 2,param_1 + 0xe,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22195 ; VA 0x00ac4070 ; FUN_00ac4070 */

undefined8 * __thiscall FUN_00ac4070(undefined8 *param_1,undefined8 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7db2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 1);
  FUN_0054ef60((int)param_2 + 0xc);
  *(undefined4 *)((int)param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 5) = 0;
  if (*(int *)(param_2 + 5) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 5) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)((int)param_1 + 0x24) = *(undefined4 *)((int)param_2 + 0x24);
  *(undefined4 *)(param_1 + 5) = *(undefined4 *)(param_2 + 5);
  *(undefined4 *)((int)param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  if (*(int *)(param_2 + 6) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 6) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)((int)param_1 + 0x2c) = *(undefined4 *)((int)param_2 + 0x2c);
  *(undefined4 *)(param_1 + 6) = *(undefined4 *)(param_2 + 6);
  *(undefined4 *)((int)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  if (*(int *)(param_2 + 7) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 7) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)((int)param_1 + 0x34) = *(undefined4 *)((int)param_2 + 0x34);
  *(undefined4 *)(param_1 + 7) = *(undefined4 *)(param_2 + 7);
  *(undefined4 *)((int)param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  if (*(int *)(param_2 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)((int)param_1 + 0x3c) = *(undefined4 *)((int)param_2 + 0x3c);
  *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_2 + 8);
  *(undefined4 *)(param_1 + 9) = 0;
  uVar2 = *(uint *)(param_2 + 9);
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  if (uVar2 != 0) {
    *(uint *)(param_1 + 9) = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
    }
    else {
      uVar3 = *(undefined4 *)((int)param_2 + 0x54);
      uVar4 = *(undefined4 *)(param_2 + 0xb);
      uVar5 = *(undefined4 *)((int)param_2 + 0x5c);
      *(undefined4 *)(param_1 + 10) = *(undefined4 *)(param_2 + 10);
      *(undefined4 *)((int)param_1 + 0x54) = uVar3;
      *(undefined4 *)(param_1 + 0xb) = uVar4;
      *(undefined4 *)((int)param_1 + 0x5c) = uVar5;
      param_1[0xc] = param_2[0xc];
    }
  }
  *(undefined4 *)(param_1 + 0xd) = 0;
  uVar2 = *(uint *)(param_2 + 0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (uVar2 != 0) {
    *(uint *)(param_1 + 0xd) = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = *(undefined4 *)((int)param_2 + 0x74);
      uVar4 = *(undefined4 *)(param_2 + 0xf);
      uVar5 = *(undefined4 *)((int)param_2 + 0x7c);
      *(undefined4 *)(param_1 + 0xe) = *(undefined4 *)(param_2 + 0xe);
      *(undefined4 *)((int)param_1 + 0x74) = uVar3;
      *(undefined4 *)(param_1 + 0xf) = uVar4;
      *(undefined4 *)((int)param_1 + 0x7c) = uVar5;
      param_1[0x10] = param_2[0x10];
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22196 ; VA 0x00ac4200 ; FUN_00ac4200 */

undefined4 * __thiscall FUN_00ac4200(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7e0a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  if (param_2[0xd] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xd] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  if (param_2[0xf] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xf] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xe] = param_2[0xe];
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = 0;
  uVar2 = param_2[0x10];
  uStack_8._0_1_ = 5;
  if (uVar2 != 0) {
    param_1[0x10] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x12,param_1 + 0x12,0);
    }
    else {
      uVar3 = param_2[0x13];
      uVar4 = param_2[0x14];
      uVar5 = param_2[0x15];
      param_1[0x12] = param_2[0x12];
      param_1[0x13] = uVar3;
      param_1[0x14] = uVar4;
      param_1[0x15] = uVar5;
      *(undefined8 *)(param_1 + 0x16) = *(undefined8 *)(param_2 + 0x16);
    }
  }
  param_1[0x18] = 0;
  uVar2 = param_2[0x18];
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (uVar2 != 0) {
    param_1[0x18] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x1b];
      uVar4 = param_2[0x1c];
      uVar5 = param_2[0x1d];
      param_1[0x1a] = param_2[0x1a];
      param_1[0x1b] = uVar3;
      param_1[0x1c] = uVar4;
      param_1[0x1d] = uVar5;
      *(undefined8 *)(param_1 + 0x1e) = *(undefined8 *)(param_2 + 0x1e);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x1a,param_1 + 0x1a,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22197 ; VA 0x00ac43a0 ; FUN_00ac43a0 */

undefined4 * __thiscall
FUN_00ac43a0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 *param_6,undefined4 *param_7,uint *param_8,uint *param_9)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7e0a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = *param_4;
  param_1[9] = param_4[1];
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = *param_5;
  param_1[0xb] = param_5[1];
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  if (param_6[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xc] = *param_6;
  param_1[0xd] = param_6[1];
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  if (param_7[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_7[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xe] = *param_7;
  param_1[0xf] = param_7[1];
  param_1[0x10] = 0;
  uStack_8._0_1_ = 5;
  uVar2 = *param_8;
  if (uVar2 != 0) {
    param_1[0x10] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_8 + 2,param_1 + 0x12,0);
    }
    else {
      uVar2 = param_8[3];
      uVar3 = param_8[4];
      uVar4 = param_8[5];
      param_1[0x12] = param_8[2];
      param_1[0x13] = uVar2;
      param_1[0x14] = uVar3;
      param_1[0x15] = uVar4;
      *(undefined8 *)(param_1 + 0x16) = *(undefined8 *)(param_8 + 6);
    }
  }
  param_1[0x18] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  uVar2 = *param_9;
  if (uVar2 != 0) {
    param_1[0x18] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar2 = param_9[3];
      uVar3 = param_9[4];
      uVar4 = param_9[5];
      param_1[0x1a] = param_9[2];
      param_1[0x1b] = uVar2;
      param_1[0x1c] = uVar3;
      param_1[0x1d] = uVar4;
      *(undefined8 *)(param_1 + 0x1e) = *(undefined8 *)(param_9 + 6);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_9 + 2,param_1 + 0x1a,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22198 ; VA 0x00ac4540 ; FUN_00ac4540 */

undefined4 * __thiscall
FUN_00ac4540(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,int param_12,
            undefined4 param_13,undefined4 *param_14)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 *in_stack_00000118;
  undefined8 in_stack_0000011c;
  undefined4 in_stack_00000124;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7e99;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ac0f70();
  FUN_009cb790(uVar1,param_4,in_stack_00000118,in_stack_0000011c,in_stack_00000124);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::TeleportService,void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,class_std::shared_ptr<class_RBX::Instance>),6>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  uStack_8._0_1_ = 4;
  in_stack_00000118 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 5;
  if (in_stack_00000118 == (undefined4 *)0x0) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_0054ef60(&stack0x00000100);
  }
  param_1[0x13] = uVar1;
  uStack_8._0_1_ = 6;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 7;
  in_stack_00000118 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_13;
    puVar2[1] = 0;
    if (param_14 != (undefined4 *)0x0) {
      (*(code *)*param_14)();
    }
    puVar2[1] = param_14;
  }
  param_1[0x14] = puVar2;
  uStack_8._0_1_ = 8;
  puVar2 = (undefined4 *)FUN_01674e20(8);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (param_12 != 0) {
      LOCK();
      *(int *)(param_12 + 4) = *(int *)(param_12 + 4) + 1;
      UNLOCK();
    }
    *puVar2 = param_11;
    puVar2[1] = param_12;
  }
  param_1[0x15] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_00ad1fa0(param_5,param_6,param_7,param_8,param_9,param_10);
  FUN_00ac88f0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22199 ; VA 0x00ac46c0 ; FUN_00ac46c0 */

undefined4 * __thiscall
FUN_00ac46c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,int param_12,
            undefined4 param_13,undefined4 *param_14)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 in_stack_00000118;
  int *in_stack_0000011c;
  undefined4 *in_stack_00000120;
  undefined8 in_stack_00000124;
  undefined4 in_stack_0000012c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7f29;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_00ac0f70();
  FUN_009cb790(uVar4,param_4,in_stack_00000120,in_stack_00000124,in_stack_0000012c);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::TeleportService,void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,class_std::shared_ptr<class_RBX::Instance>),6>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 3;
  puVar5 = (undefined4 *)FUN_01674e20(8);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 0;
    if (in_stack_0000011c != (int *)0x0) {
      LOCK();
      in_stack_0000011c[1] = in_stack_0000011c[1] + 1;
      UNLOCK();
    }
    *puVar5 = in_stack_00000118;
    puVar5[1] = in_stack_0000011c;
  }
  param_1[0x12] = puVar5;
  uStack_8._0_1_ = 4;
  in_stack_00000120 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 5;
  if (in_stack_00000120 == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0054ef60(&stack0x00000100);
  }
  param_1[0x13] = uVar4;
  uStack_8._0_1_ = 6;
  puVar5 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 7;
  in_stack_00000120 = puVar5;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = param_13;
    puVar5[1] = 0;
    if (param_14 != (undefined4 *)0x0) {
      (*(code *)*param_14)();
    }
    puVar5[1] = param_14;
  }
  param_1[0x14] = puVar5;
  uStack_8._0_1_ = 8;
  puVar5 = (undefined4 *)FUN_01674e20(8);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 0;
    if (param_12 != 0) {
      LOCK();
      *(int *)(param_12 + 4) = *(int *)(param_12 + 4) + 1;
      UNLOCK();
    }
    *puVar5 = param_11;
    puVar5[1] = param_12;
  }
  param_1[0x15] = puVar5;
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_00ad25d0(param_5,param_6,param_7,param_8,param_9,param_10);
  piVar3 = in_stack_0000011c;
  if (in_stack_0000011c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000011c[1] + -1;
    in_stack_0000011c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000011c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00ac88f0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22200 ; VA 0x00ac48b0 ; FUN_00ac48b0 */

undefined4 * __thiscall
FUN_00ac48b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,int param_11,undefined4 param_12,
            undefined4 *param_13)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 in_stack_000000fc;
  int in_stack_00000100;
  undefined4 in_stack_00000104;
  undefined8 in_stack_00000108;
  undefined4 in_stack_00000110;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7f9c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ac0f70();
  FUN_009cb790(uVar1,param_4,in_stack_00000104,in_stack_00000108,in_stack_00000110);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::TeleportService,void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::Variant,class_std::shared_ptr<class_RBX::Instance>),5>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(8);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (in_stack_00000100 != 0) {
      LOCK();
      *(int *)(in_stack_00000100 + 4) = *(int *)(in_stack_00000100 + 4) + 1;
      UNLOCK();
    }
    *puVar2 = in_stack_000000fc;
    puVar2[1] = in_stack_00000100;
  }
  param_1[0x12] = puVar2;
  uStack_8._0_1_ = 4;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 5;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_12;
    puVar2[1] = 0;
    if (param_13 != (undefined4 *)0x0) {
      (*(code *)*param_13)();
    }
    puVar2[1] = param_13;
  }
  param_1[0x13] = puVar2;
  uStack_8._0_1_ = 6;
  puVar2 = (undefined4 *)FUN_01674e20(8);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (param_11 != 0) {
      LOCK();
      *(int *)(param_11 + 4) = *(int *)(param_11 + 4) + 1;
      UNLOCK();
    }
    *puVar2 = param_10;
    puVar2[1] = param_11;
  }
  param_1[0x14] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_00ad2c40(param_5,param_6,param_7,param_8,param_9);
  FUN_00ac8a00();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22201 ; VA 0x00ac4a40 ; FUN_00ac4a40 */

undefined4 * __thiscall
FUN_00ac4a40(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,int *param_10,undefined4 param_11,undefined4 *param_12)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *in_stack_000000f8;
  undefined8 in_stack_000000fc;
  undefined4 in_stack_00000104;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8001;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00ac0f70();
  FUN_009cb820(uVar3,param_4,in_stack_000000f8,in_stack_000000fc,in_stack_00000104);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::TeleportService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(__int64,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,class_RBX::Reflection::Variant,class_std::shared_ptr<class_RBX::Instance>),4>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 4;
  in_stack_000000f8 = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = param_11;
    puVar4[1] = 0;
    if (param_12 != (undefined4 *)0x0) {
      (*(code *)*param_12)();
    }
    puVar4[1] = param_12;
  }
  param_1[0x12] = puVar4;
  uStack_8._0_1_ = 5;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (param_10 != (int *)0x0) {
      LOCK();
      param_10[1] = param_10[1] + 1;
      UNLOCK();
    }
    *puVar4 = param_9;
    puVar4[1] = param_10;
  }
  param_1[0x13] = puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00ad3620(param_5,param_6,param_7,param_8);
  uStack_8 = 7;
  if (param_12 != (undefined4 *)0x0) {
    (*(code *)param_12[2])(&stack0x00000030);
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22202 ; VA 0x00ac4bc0 ; FUN_00ac4bc0 */

undefined4 * __thiscall
FUN_00ac4bc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e805b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00ac0f70();
  FUN_009cb820(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::TeleportService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(__int64),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088cbe0();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x10];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_0088da50();
    iStack_e4 = 0;
    uStack_e0 = *puVar2;
    uStack_dc = puVar2[1];
    iStack_e4 = FUN_005c9e80();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22203 ; VA 0x00ac4d40 ; FUN_00ac4d40 */

undefined4 * __thiscall FUN_00ac4d40(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  FUN_00a66ab0(param_2 + 2);
  param_1[7] = 0;
  param_1[8] = 0;
  if (param_2[8] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[8] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  return param_1;
}



/* FUNCTION 22204 ; VA 0x00ac4d90 ; FUN_00ac4d90 */

undefined4 * __thiscall FUN_00ac4d90(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8078;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  uVar1 = param_2[2];
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar2 = param_2[5];
      uVar3 = param_2[6];
      uVar4 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar2;
      param_1[6] = uVar3;
      param_1[7] = uVar4;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar1 = param_2[10];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[10] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0xd];
      uVar3 = param_2[0xe];
      uVar4 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar2;
      param_1[0xe] = uVar3;
      param_1[0xf] = uVar4;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22205 ; VA 0x00ac4e60 ; FUN_00ac4e60 */

undefined4 __thiscall
FUN_00ac4e60(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 *param_9,ulonglong param_10,uint param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e80a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_11 != 0) {
    uStack_3c = param_11;
    if ((param_11 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_13;
      uStack_4c = 0xac4ecc;
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_13;
      uStack_30 = param_14;
      uStack_2c = param_15;
      puStack_28 = (undefined4 *)param_16;
      uStack_24 = param_17;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_54,0);
    }
    else {
      uStack_54 = param_6;
      uStack_50 = param_7;
      uStack_4c = param_8;
      puStack_48 = param_9;
      uStack_44 = param_10;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_00ac5c60(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_6;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xac4f49;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_13;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xac4f77;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22206 ; VA 0x00ac4f90 ; FUN_00ac4f90 */

undefined4 * __thiscall FUN_00ac4f90(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017e80c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  uVar2 = param_2[4];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22207 ; VA 0x00ac5050 ; FUN_00ac5050 */

undefined4 * __thiscall FUN_00ac5050(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e80e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  FUN_0054ef60(param_2 + 1);
  param_1[7] = 0;
  param_1[8] = 0;
  if (param_2[8] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[8] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22208 ; VA 0x00ac5120 ; FUN_00ac5120 */

undefined4 __thiscall FUN_00ac5120(undefined4 param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8128;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000028 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000028 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  FUN_00ac5f20(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 5;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22209 ; VA 0x00ac52a0 ; FUN_00ac52a0 */

undefined4 __thiscall
FUN_00ac52a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  FUN_00ac5b70(param_2,param_3,param_4,param_5,param_6);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22210 ; VA 0x00ac53c0 ; FUN_00ac53c0 */

undefined4 __thiscall
FUN_00ac53c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,undefined4 param_9)

{
  int *piVar1;
  int iVar2;
  
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  FUN_00ac6790(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22211 ; VA 0x00ac54d0 ; FUN_00ac54d0 */

undefined4 __thiscall FUN_00ac54d0(undefined4 param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  uint in_stack_00000058;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined8 in_stack_00000070;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8198;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000058 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000058 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000058 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 6;
  if ((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) {
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 10;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 5;
  FUN_00ac7080(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (in_stack_00000038 != 0) {
    if (((in_stack_00000038 & 1) == 0) &&
       (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    in_stack_00000038 = 0;
  }
  uStack_8 = 0xc;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000058 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22212 ; VA 0x00ac5760 ; FUN_00ac5760 */

undefined4 __thiscall FUN_00ac5760(undefined4 param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined8 in_stack_00000058;
  uint in_stack_00000060;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 in_stack_00000074;
  undefined8 in_stack_00000078;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8218;
  pvStack_10 = ExceptionList;
  uStack_8 = 6;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000060 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000060 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000060 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 7;
  if ((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) {
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 0xc;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 6;
  FUN_00ac7490(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000003c;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000003c[1] + -1;
    in_stack_0000003c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000003c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (in_stack_00000040 != 0) {
    if (((in_stack_00000040 & 1) == 0) &&
       (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
    }
    in_stack_00000040 = 0;
  }
  uStack_8 = 0xe;
  if (((in_stack_00000060 != 0) && ((in_stack_00000060 & 1) == 0)) &&
     (*(code **)(in_stack_00000060 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000060 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22213 ; VA 0x00ac5a40 ; FUN_00ac5a40 */

undefined4 * __thiscall FUN_00ac5a40(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8248;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&param_3);
  *param_1 = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(aiStack_2c);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar3 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[7] = 0;
  param_1[8] = 0;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  param_1[7] = in_stack_00000020;
  param_1[8] = in_stack_00000024;
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar4 = param_3;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_3 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  piVar2 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22214 ; VA 0x00ac5b70 ; FUN_00ac5b70 */

undefined4 * __thiscall
FUN_00ac5b70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  param_1[1] = param_3;
  param_1[2] = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  param_1[3] = param_5;
  param_1[4] = param_6;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22215 ; VA 0x00ac5c60 ; FUN_00ac5c60 */

undefined4 * __thiscall
FUN_00ac5c60(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10,uint param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8280;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_30,0);
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  *param_1 = param_2;
  uStack_8._0_1_ = 2;
  param_1[2] = 0;
  if (uStack_38 != 0) {
    param_1[2] = uStack_38;
    if ((uStack_38 & 1) == 0) {
      (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_30;
      param_1[5] = uStack_2c;
      param_1[6] = uStack_28;
      param_1[7] = uStack_24;
      *(undefined8 *)(param_1 + 8) = uStack_20;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,&uStack_30,2);
  }
  uStack_8._0_1_ = 4;
  param_1[10] = 0;
  if (param_11 != 0) {
    param_1[10] = param_11;
    if ((param_11 & 1) == 0) {
      (**(code **)(param_11 & 0xfffffffe))(&param_13,param_1 + 0xc,0);
    }
    else {
      param_1[0xc] = param_13;
      param_1[0xd] = param_14;
      param_1[0xe] = param_15;
      param_1[0xf] = param_16;
      *(undefined8 *)(param_1 + 0x10) = param_17;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  uStack_8 = 6;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_11 & 0xfffffffe))(&param_13,&param_13,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22216 ; VA 0x00ac5df0 ; FUN_00ac5df0 */

undefined4 * __thiscall
FUN_00ac5df0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined8 param_12)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e82a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar1 = param_5[1] + -1;
    param_5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar1 = param_5[2] + -1;
      param_5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  param_1[4] = 0;
  if (param_6 != 0) {
    param_1[4] = param_6;
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,param_1 + 6,0);
    }
    else {
      param_1[6] = param_8;
      param_1[7] = param_9;
      param_1[8] = param_10;
      param_1[9] = param_11;
      *(undefined8 *)(param_1 + 10) = param_12;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar1 = param_5[1] + -1;
    param_5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar1 = param_5[2] + -1;
      param_5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = 3;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_6 & 0xfffffffe))(&param_8,&param_8,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22217 ; VA 0x00ac5f20 ; FUN_00ac5f20 */

int __thiscall FUN_00ac5f20(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e82e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  FUN_00ac5a40(param_2);
  uStack_8._0_1_ = 4;
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (in_stack_00000028 != 0) {
    *(uint *)(param_1 + 0x28) = in_stack_00000028;
    if ((in_stack_00000028 & 1) == 0) {
      (**(code **)(in_stack_00000028 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x30) = in_stack_00000030;
      *(undefined4 *)(param_1 + 0x34) = in_stack_00000034;
      *(undefined4 *)(param_1 + 0x38) = in_stack_00000038;
      *(undefined4 *)(param_1 + 0x3c) = in_stack_0000003c;
      *(undefined8 *)(param_1 + 0x40) = in_stack_00000040;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 5;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22218 ; VA 0x00ac60a0 ; FUN_00ac60a0 */

int __thiscall FUN_00ac60a0(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e8320;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8 = 3;
  uStack_7 = 0;
  FUN_0054ef60(&param_3);
  _uStack_8 = CONCAT31(uStack_7,2);
  FUN_00ac5a40(param_2);
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x24) = in_stack_00000028;
  *(int **)(param_1 + 0x28) = in_stack_0000002c;
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22219 ; VA 0x00ac61f0 ; FUN_00ac61f0 */

int __thiscall FUN_00ac61f0(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e8350;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8 = 3;
  uStack_7 = 0;
  FUN_0054ef60(&param_3);
  _uStack_8 = CONCAT31(uStack_7,2);
  FUN_00ac5a40(param_2);
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x24) = in_stack_00000028;
  *(int **)(param_1 + 0x28) = in_stack_0000002c;
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22220 ; VA 0x00ac6340 ; FUN_00ac6340 */

int __thiscall
FUN_00ac6340(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  FUN_00ac5b70(param_2,param_3,param_4,param_5,param_6);
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x14) = param_7;
  *(int **)(param_1 + 0x18) = param_8;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22221 ; VA 0x00ac6450 ; FUN_00ac6450 */

int __thiscall FUN_00ac6450(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e8390;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8 = 5;
  uStack_7 = 0;
  FUN_0054ef60(&param_3);
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_00ac60a0(param_2);
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x2c) = in_stack_00000030;
  *(int **)(param_1 + 0x30) = in_stack_00000034;
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22222 ; VA 0x00ac65f0 ; FUN_00ac65f0 */

int __thiscall FUN_00ac65f0(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e83d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8 = 5;
  uStack_7 = 0;
  FUN_0054ef60(&param_3);
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_00ac61f0(param_2);
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x2c) = in_stack_00000030;
  *(int **)(param_1 + 0x30) = in_stack_00000034;
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22223 ; VA 0x00ac6790 ; FUN_00ac6790 */

undefined4 __thiscall
FUN_00ac6790(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  FUN_00ac6340(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22224 ; VA 0x00ac68a0 ; FUN_00ac68a0 */

int __thiscall FUN_00ac68a0(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e8420;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8 = 7;
  uStack_7 = 0;
  FUN_0054ef60(&param_3);
  _uStack_8 = CONCAT31(uStack_7,4);
  FUN_00ac6450(param_2);
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x34) = in_stack_00000038;
  *(int **)(param_1 + 0x38) = in_stack_0000003c;
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000003c;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000003c[1] + -1;
    in_stack_0000003c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000003c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22225 ; VA 0x00ac6a90 ; FUN_00ac6a90 */

int __thiscall FUN_00ac6a90(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8478;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 4;
  FUN_00ac65f0(param_2);
  uStack_8._0_1_ = 8;
  *(undefined4 *)(param_1 + 0x38) = 0;
  if (in_stack_00000038 != 0) {
    *(uint *)(param_1 + 0x38) = in_stack_00000038;
    if ((in_stack_00000038 & 1) == 0) {
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x40) = in_stack_00000040;
      *(undefined4 *)(param_1 + 0x44) = in_stack_00000044;
      *(undefined4 *)(param_1 + 0x48) = in_stack_00000048;
      *(undefined4 *)(param_1 + 0x4c) = in_stack_0000004c;
      *(undefined8 *)(param_1 + 0x50) = in_stack_00000050;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 9;
  if (((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) &&
     (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22226 ; VA 0x00ac6cb0 ; FUN_00ac6cb0 */

int __thiscall FUN_00ac6cb0(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined8 in_stack_00000058;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e84e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 9;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 5;
  FUN_00ac68a0(param_2);
  uStack_8._0_1_ = 10;
  *(undefined4 *)(param_1 + 0x40) = 0;
  if (in_stack_00000040 != 0) {
    *(uint *)(param_1 + 0x40) = in_stack_00000040;
    if ((in_stack_00000040 & 1) == 0) {
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x48) = in_stack_00000048;
      *(undefined4 *)(param_1 + 0x4c) = in_stack_0000004c;
      *(undefined4 *)(param_1 + 0x50) = in_stack_00000050;
      *(undefined4 *)(param_1 + 0x54) = in_stack_00000054;
      *(undefined8 *)(param_1 + 0x58) = in_stack_00000058;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000003c;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000003c[1] + -1;
    in_stack_0000003c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000003c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 0xb;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22227 ; VA 0x00ac6f20 ; FUN_00ac6f20 */

undefined4 * __thiscall FUN_00ac6f20(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8510;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  FUN_0054ef60(param_2 + 1);
  param_1[7] = 0;
  param_1[8] = 0;
  if (param_2[8] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[8] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = 0;
  param_1[10] = 0;
  if (param_2[10] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[10] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  if (param_2[0xc] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xc] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  param_1[0xe] = 0;
  uVar2 = param_2[0xe];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[0xe] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x10,param_1 + 0x10,0);
    }
    else {
      uVar3 = param_2[0x11];
      uVar4 = param_2[0x12];
      uVar5 = param_2[0x13];
      param_1[0x10] = param_2[0x10];
      param_1[0x11] = uVar3;
      param_1[0x12] = uVar4;
      param_1[0x13] = uVar5;
      *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_2 + 0x14);
    }
  }
  param_1[0x16] = 0;
  uVar2 = param_2[0x16];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0x16] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x19];
      uVar4 = param_2[0x1a];
      uVar5 = param_2[0x1b];
      param_1[0x18] = param_2[0x18];
      param_1[0x19] = uVar3;
      param_1[0x1a] = uVar4;
      param_1[0x1b] = uVar5;
      *(undefined8 *)(param_1 + 0x1c) = *(undefined8 *)(param_2 + 0x1c);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x18,param_1 + 0x18,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22228 ; VA 0x00ac7080 ; FUN_00ac7080 */

int __thiscall FUN_00ac7080(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  uint in_stack_00000058;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined8 in_stack_00000070;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8578;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000038 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000038 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 9;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 5;
  FUN_00ac6a90(param_2);
  uStack_8._0_1_ = 10;
  *(undefined4 *)(param_1 + 0x58) = 0;
  if (in_stack_00000058 != 0) {
    *(uint *)(param_1 + 0x58) = in_stack_00000058;
    if ((in_stack_00000058 & 1) == 0) {
      (**(code **)(in_stack_00000058 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x60) = in_stack_00000060;
      *(undefined4 *)(param_1 + 100) = in_stack_00000064;
      *(undefined4 *)(param_1 + 0x68) = in_stack_00000068;
      *(undefined4 *)(param_1 + 0x6c) = in_stack_0000006c;
      *(undefined8 *)(param_1 + 0x70) = in_stack_00000070;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (in_stack_00000038 != 0) {
    if (((in_stack_00000038 & 1) == 0) &&
       (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    in_stack_00000038 = 0;
  }
  uStack_8 = 0xc;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000058 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22229 ; VA 0x00ac7310 ; FUN_00ac7310 */

undefined4 * __thiscall FUN_00ac7310(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e85a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  FUN_0054ef60(param_2 + 1);
  param_1[7] = 0;
  param_1[8] = 0;
  if (param_2[8] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[8] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = 0;
  param_1[10] = 0;
  if (param_2[10] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[10] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  if (param_2[0xc] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xc] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  if (param_2[0xe] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xe] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xd] = param_2[0xd];
  param_1[0xe] = param_2[0xe];
  param_1[0x10] = 0;
  uVar2 = param_2[0x10];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[0x10] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x12,param_1 + 0x12,0);
    }
    else {
      uVar3 = param_2[0x13];
      uVar4 = param_2[0x14];
      uVar5 = param_2[0x15];
      param_1[0x12] = param_2[0x12];
      param_1[0x13] = uVar3;
      param_1[0x14] = uVar4;
      param_1[0x15] = uVar5;
      *(undefined8 *)(param_1 + 0x16) = *(undefined8 *)(param_2 + 0x16);
    }
  }
  param_1[0x18] = 0;
  uVar2 = param_2[0x18];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0x18] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x1b];
      uVar4 = param_2[0x1c];
      uVar5 = param_2[0x1d];
      param_1[0x1a] = param_2[0x1a];
      param_1[0x1b] = uVar3;
      param_1[0x1c] = uVar4;
      param_1[0x1d] = uVar5;
      *(undefined8 *)(param_1 + 0x1e) = *(undefined8 *)(param_2 + 0x1e);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x1a,param_1 + 0x1a,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22230 ; VA 0x00ac7490 ; FUN_00ac7490 */

int __thiscall FUN_00ac7490(int param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined8 in_stack_00000058;
  uint in_stack_00000060;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 in_stack_00000074;
  undefined8 in_stack_00000078;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8618;
  pvStack_10 = ExceptionList;
  uStack_8 = 6;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000040 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000040 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 0xb;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 6;
  FUN_00ac6cb0(param_2);
  uStack_8._0_1_ = 0xc;
  *(undefined4 *)(param_1 + 0x60) = 0;
  if (in_stack_00000060 != 0) {
    *(uint *)(param_1 + 0x60) = in_stack_00000060;
    if ((in_stack_00000060 & 1) == 0) {
      (**(code **)(in_stack_00000060 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x68) = in_stack_00000068;
      *(undefined4 *)(param_1 + 0x6c) = in_stack_0000006c;
      *(undefined4 *)(param_1 + 0x70) = in_stack_00000070;
      *(undefined4 *)(param_1 + 0x74) = in_stack_00000074;
      *(undefined8 *)(param_1 + 0x78) = in_stack_00000078;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000003c;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000003c[1] + -1;
    in_stack_0000003c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_0000003c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (in_stack_00000040 != 0) {
    if (((in_stack_00000040 & 1) == 0) &&
       (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
    }
    in_stack_00000040 = 0;
  }
  uStack_8 = 0xe;
  if (((in_stack_00000060 != 0) && ((in_stack_00000060 & 1) == 0)) &&
     (*(code **)(in_stack_00000060 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000060 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22231 ; VA 0x00ac7770 ; FUN_00ac7770 */

undefined4 * __fastcall FUN_00ac7770(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined **ppuVar2;
  undefined **ppuVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e86f5;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::TeleportService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00ac0f70();
  param_1[3] = uVar1;
  *param_1 = RBX::TeleportService::vftable;
  *(undefined *)(param_1 + 0x16) = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0xf;
  uStack_8 = 1;
  *(undefined *)(param_1 + 0x17) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  *(undefined *)(param_1 + 0x23) = 0;
  uStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  param_1[0x24] = *ppuVar3;
  param_1[0x25] = 0;
  param_1[0x26] = 0x3f800000;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  *(undefined *)(param_1 + 0x2a) = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  *(undefined *)(param_1 + 0x31) = 0;
  uStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  param_1[0x32] = *ppuVar3;
  param_1[0x33] = 0;
  param_1[0x34] = 0x3f800000;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  *(undefined *)(param_1 + 0x37) = 0;
  uStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  param_1[0x38] = *ppuVar3;
  param_1[0x39] = 0;
  param_1[0x3a] = 0x3f800000;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  *(undefined *)(param_1 + 0x3d) = 0;
  uStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  param_1[0x3e] = *ppuVar3;
  param_1[0x3f] = 0;
  param_1[0x40] = 0x3f800000;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  uStack_8._0_1_ = 0xe;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Teleport Service",0x10);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    uVar4 = auStack_30[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_30[0] - 4);
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22232 ; VA 0x00ac7a50 ; FUN_00ac7a50 */

code * __fastcall FUN_00ac7a50(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  code *pcVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x58);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x60,param_1 + 0x60,2);
      }
    }
    *(undefined4 *)(param_1 + 0x58) = 0;
  }
  pcVar6 = *(code **)(param_1 + 0x38);
  uStack_8 = 1;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  piVar4 = *(int **)(param_1 + 0x34);
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      puVar1 = (uint *)(piVar4 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = *(int **)(param_1 + 0x2c);
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      puVar1 = (uint *)(piVar4 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = *(int **)(param_1 + 0x24);
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      puVar1 = (uint *)(piVar4 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar3) {
    iVar5 = *(int *)(param_1 + 8);
    uVar8 = uVar3 + 1;
    iVar7 = iVar5;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar5 + -4);
      uVar8 = uVar3 + 0x24;
      if (0x1f < (iVar5 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pcVar6 = (code *)FUN_01674ea0(iVar7,uVar8);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar2 = piVar4 + 2;
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 22233 ; VA 0x00ac7bb0 ; FUN_00ac7bb0 */

void __fastcall FUN_00ac7bb0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar1 = (int *)param_1[8];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar2 = param_1[5];
  if (0xf < uVar2) {
    iVar3 = *param_1;
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 22234 ; VA 0x00ac7c20 ; FUN_00ac7c20 */

code * __fastcall FUN_00ac7c20(int param_1)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  code *pcVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar4 = *(uint *)(param_1 + 0x68);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x70,param_1 + 0x70,2);
      }
    }
    *(undefined4 *)(param_1 + 0x68) = 0;
  }
  pcVar6 = *(code **)(param_1 + 0x48);
  uStack_8 = 1;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x50,param_1 + 0x50,2);
      }
    }
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  piVar5 = *(int **)(param_1 + 0x40);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar4 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 0x38);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar4 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 0x30);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar4 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 0x28);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  uVar4 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0xc);
    uVar8 = uVar4 + 1;
    iVar7 = iVar3;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar3 + -4);
      uVar8 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pcVar6 = (code *)FUN_01674ea0(iVar7,uVar8);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 22235 ; VA 0x00ac7d90 ; FUN_00ac7d90 */

code * __fastcall FUN_00ac7d90(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  code *pcVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x60);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x68,param_1 + 0x68,2);
      }
    }
    *(undefined4 *)(param_1 + 0x60) = 0;
  }
  pcVar6 = *(code **)(param_1 + 0x40);
  uStack_8 = 1;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x48,param_1 + 0x48,2);
      }
    }
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  piVar4 = *(int **)(param_1 + 0x3c);
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      puVar1 = (uint *)(piVar4 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = *(int **)(param_1 + 0x34);
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      puVar1 = (uint *)(piVar4 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = *(int **)(param_1 + 0x2c);
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      puVar1 = (uint *)(piVar4 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = *(int **)(param_1 + 0x24);
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      puVar1 = (uint *)(piVar4 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar3) {
    iVar5 = *(int *)(param_1 + 8);
    uVar8 = uVar3 + 1;
    iVar7 = iVar5;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar5 + -4);
      uVar8 = uVar3 + 0x24;
      if (0x1f < (iVar5 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pcVar6 = (code *)FUN_01674ea0(iVar7,uVar8);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar2 = piVar4 + 2;
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 22236 ; VA 0x00ac7f20 ; FUN_00ac7f20 */

void __fastcall FUN_00ac7f20(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x54);
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    ExceptionList = &pvStack_10;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      ExceptionList = &pvStack_10;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  iVar2 = *(int *)(param_1 + 0x50);
  if (iVar2 != 0) {
    uStack_8 = 0;
    if (*(int *)(iVar2 + 4) != 0) {
      (**(code **)(*(int *)(iVar2 + 4) + 8))(iVar2 + 8);
    }
    FUN_01674ea0(iVar2,0xd0);
  }
  FUN_005c4ac0();
  iVar2 = *(int *)(param_1 + 0x48);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22237 ; VA 0x00ac8030 ; FUN_00ac8030 */

void __fastcall FUN_00ac8030(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x50);
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    ExceptionList = &pvStack_10;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      ExceptionList = &pvStack_10;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  iVar2 = *(int *)(param_1 + 0x4c);
  if (iVar2 != 0) {
    uStack_8 = 0;
    if (*(int *)(iVar2 + 4) != 0) {
      (**(code **)(*(int *)(iVar2 + 4) + 8))(iVar2 + 8);
    }
    FUN_01674ea0(iVar2,0xd0);
  }
  iVar2 = *(int *)(param_1 + 0x48);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22238 ; VA 0x00ac8130 ; FUN_00ac8130 */

void __fastcall FUN_00ac8130(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x4c);
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    ExceptionList = &pvStack_10;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      ExceptionList = &pvStack_10;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  iVar2 = *(int *)(param_1 + 0x48);
  if (iVar2 != 0) {
    uStack_8 = 0;
    if (*(int *)(iVar2 + 4) != 0) {
      (**(code **)(*(int *)(iVar2 + 4) + 8))(iVar2 + 8);
    }
    FUN_01674ea0(iVar2,0xd0);
  }
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22239 ; VA 0x00ac8230 ; FUN_00ac8230 */

void __fastcall FUN_00ac8230(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x4c);
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    ExceptionList = &pvStack_10;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      ExceptionList = &pvStack_10;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  iVar2 = *(int *)(param_1 + 0x48);
  if (iVar2 != 0) {
    uStack_8 = 0;
    if (*(int *)(iVar2 + 4) != 0) {
      (**(code **)(*(int *)(iVar2 + 4) + 8))(iVar2 + 8);
    }
    FUN_01674ea0(iVar2,0xd0);
  }
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22240 ; VA 0x00ac8330 ; FUN_00ac8330 */

void FUN_00ac8330(void)

{
  FUN_00ac85c0();
  return;
}



/* FUNCTION 22241 ; VA 0x00ac8340 ; FUN_00ac8340 */

void __fastcall FUN_00ac8340(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  FUN_00ac8540();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22242 ; VA 0x00ac83a0 ; FUN_00ac83a0 */

void FUN_00ac83a0(void)

{
  FUN_00a678e0();
  return;
}



/* FUNCTION 22243 ; VA 0x00ac83b0 ; FUN_00ac83b0 */

void __fastcall FUN_00ac83b0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00a678e0();
  return;
}



/* FUNCTION 22244 ; VA 0x00ac83f0 ; FUN_00ac83f0 */

void FUN_00ac83f0(void)

{
  FUN_00ac87e0();
  return;
}



/* FUNCTION 22245 ; VA 0x00ac8400 ; FUN_00ac8400 */

void __fastcall FUN_00ac8400(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x68);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x70,param_1 + 0x70,2);
      }
    }
    *(undefined4 *)(param_1 + 0x68) = 0;
  }
  FUN_00ac8750();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22246 ; VA 0x00ac8460 ; thunk_FUN_00ac85c0 */

code * __fastcall thunk_FUN_00ac85c0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar5 = *(int **)(param_1 + 0xc);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 22247 ; VA 0x00ac8470 ; FUN_00ac8470 */

void __fastcall FUN_00ac8470(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  FUN_00ac8540();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22248 ; VA 0x00ac84d0 ; thunk_FUN_00ac87e0 */

void __fastcall thunk_FUN_00ac87e0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x58);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x60,param_1 + 0x60,2);
      }
    }
    *(undefined4 *)(param_1 + 0x58) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x38);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  FUN_00ac8650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22249 ; VA 0x00ac84e0 ; FUN_00ac84e0 */

void __fastcall FUN_00ac84e0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x60);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x68,param_1 + 0x68,2);
      }
    }
    *(undefined4 *)(param_1 + 0x60) = 0;
  }
  FUN_00ac8750();
  ExceptionList = pvStack_10;
  return;
}


