/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 11000 ; VA 0x00779620 ; FUN_00779620 */

undefined4 * __thiscall FUN_00779620(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  int *piStack_64;
  int *piStack_54;
  undefined auStack_48 [4];
  int *piStack_44;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af458;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar5 = FUN_01675290(DAT_01eb1b4c);
  uStack_8 = 0;
  uStack_18 = uVar5;
  if ((DAT_01d60d04 == '\0') && (*(int *)(*param_3 + 0x48) == 3)) {
    uVar6 = FUN_0147d4b0();
    uStack_8._0_1_ = 1;
    FUN_0147d420(param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_0147bf30(param_2,auStack_38,uVar6);
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_34[1] + -1;
      piStack_34[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        iVar4 = piStack_34[2] + -1;
        piStack_34[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_54[1] + -1;
      piStack_54[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        piVar1 = piStack_54 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_54 + 4))();
        }
      }
    }
    uStack_8 = 3;
  }
  else {
    uVar7 = 0;
    iVar4 = *(int *)(param_1 + 0x6c);
    uVar8 = *(int *)(iStack_14 + 0x70) - iVar4 >> 3;
    if (uVar8 != 0) {
      do {
        iVar2 = *(int *)(iVar4 + uVar7 * 8);
        if ((*(int *)(iVar2 + 0x28) == *(int *)(*param_3 + 0x30)) &&
           (*(int *)(iVar2 + 0x2c) == *(int *)(*param_3 + 0x34))) {
          puVar3 = (undefined4 *)(iVar4 + uVar7 * 8);
          *param_2 = 0;
          param_2[1] = 0;
          if (puVar3[1] != 0) {
            LOCK();
            piVar1 = (int *)(puVar3[1] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          *param_2 = *puVar3;
          param_2[1] = puVar3[1];
          uStack_8 = 4;
          FUN_01675290(uVar5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        uVar7 = uVar7 + 1;
      } while (uVar7 < uVar8);
    }
    FUN_0147c180(auStack_28,0,3,*(undefined4 *)(*param_3 + 0x30),*(undefined4 *)(*param_3 + 0x34),3)
    ;
    uStack_8._0_1_ = 5;
    uVar6 = FUN_0147d4b0();
    uStack_8._0_1_ = 6;
    FUN_0147d420(auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_0147bf30(&uStack_20,auStack_48,uVar6);
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_44[1] + -1;
      piStack_44[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_44)();
        LOCK();
        iVar4 = piStack_44[2] + -1;
        piStack_44[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_44 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    if (piStack_64 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_64[1] + -1;
      piStack_64[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_64)();
        LOCK();
        iVar4 = piStack_64[2] + -1;
        piStack_64[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_64 + 4))();
        }
      }
    }
    puVar3 = *(undefined4 **)(iStack_14 + 0x70);
    if (*(undefined4 **)(iStack_14 + 0x74) == puVar3) {
      FUN_005c1970(puVar3,&uStack_20);
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_20;
      puVar3[1] = iStack_1c;
      *(int *)(iStack_14 + 0x70) = *(int *)(iStack_14 + 0x70) + 8;
    }
    uVar6 = uStack_20;
    uStack_20 = 0;
    *param_2 = uVar6;
    param_2[1] = iStack_1c;
    iStack_1c = 0;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piStack_24 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    uStack_8 = 0xb;
  }
  FUN_01675290(uVar5);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11001 ; VA 0x007798d0 ; FUN_007798d0 */

int * __thiscall FUN_007798d0(int param_1,int *param_2,int param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  int *piStack_4c;
  undefined auStack_40 [4];
  int *piStack_3c;
  int iStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af498;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar5 = FUN_01675290(DAT_01eb1b4c);
  uVar9 = 0;
  piVar7 = *(int **)(param_1 + 0x60);
  uVar8 = *(int *)(param_1 + 100) - (int)piVar7 >> 3;
  uStack_8 = 0;
  iStack_18 = uVar5;
  if (uVar8 != 0) {
    do {
      iVar2 = *piVar7;
      iVar3 = *(int *)(iVar2 + 0x90);
      if (((iVar3 != 0) && (*(int *)(iVar3 + 0x30) == param_3)) &&
         ((int *)*(int *)(iVar3 + 0x34) == param_4)) {
        if (DAT_01eb1b24 != '\0') {
          FUN_016774b0(DAT_01eb1b24,"TC Reuse texture %p",iVar3);
        }
        iVar3 = iStack_14;
        param_4 = *(int **)(iVar2 + 0x94);
        if (param_4 != (int *)0x0) {
          LOCK();
          *(int *)((int)param_4 + 4) = *(int *)((int)param_4 + 4) + 1;
          UNLOCK();
          param_4 = *(int **)(iVar2 + 0x94);
        }
        iStack_18 = *(int *)(iVar2 + 0x90);
        param_3 = *(int *)(iVar2 + 0x9c);
        if (param_3 != 0) {
          LOCK();
          *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
          UNLOCK();
          param_3 = *(int *)(iVar2 + 0x9c);
        }
        piStack_1c = *(int **)(iVar2 + 0x98);
        iStack_24 = *(int *)(iVar2 + 0xa0);
        iVar2 = *(int *)(iStack_14 + 0x60) + uVar9 * 8;
        FUN_00775350(iVar2 + 8,*(undefined4 *)(iStack_14 + 100),iVar2);
        piVar7 = *(int **)(*(int *)(iVar3 + 100) + -4);
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar2 = piVar7[1] + -1;
          piVar7[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        *(int *)(iStack_14 + 100) = *(int *)(iStack_14 + 100) + -8;
        *param_2 = iStack_18;
        param_2[1] = (int)param_4;
        param_2[2] = (int)piStack_1c;
        param_2[3] = param_3;
        param_2[4] = iStack_24;
        FUN_0056b650();
        uStack_8 = 1;
        FUN_01675290(uVar5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      uVar9 = uVar9 + 1;
      piVar7 = piVar7 + 2;
      param_1 = iStack_14;
    } while (uVar9 < uVar8);
  }
  FUN_0147c180(&iStack_30,0,(*(int *)(param_1 + 0x34) != 0x10) + '\x02',param_3,param_4,5);
  uStack_8._0_1_ = 2;
  if (DAT_01eb1b24 != '\0') {
    FUN_016774b0(DAT_01eb1b24,"TC Create texture %p",iStack_30);
  }
  param_3 = 0;
  uStack_28 = 0;
  param_4 = (int *)0x0;
  iStack_24 = 0;
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if ((DAT_01d60d04 != '\0') && (uVar4 = (undefined)uStack_8, *(int *)(iStack_30 + 0x48) == 3)) {
    uVar6 = FUN_0147d4b0();
    uStack_8._0_1_ = 4;
    FUN_0147d420(&iStack_30);
    uStack_8._0_1_ = 5;
    piVar7 = (int *)FUN_0147bf30(auStack_20,auStack_40,uVar6);
    param_3 = *piVar7;
    param_4 = (int *)piVar7[1];
    *piVar7 = 0;
    piVar7[1] = 0;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar2 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        iVar2 = piStack_3c[2] + -1;
        piStack_3c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_3c + 4))();
        }
      }
    }
    uVar4 = (undefined)uStack_8;
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_4c[1] + -1;
      piStack_4c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_4c)();
        LOCK();
        iVar2 = piStack_4c[2] + -1;
        piStack_4c[2] = iVar2;
        UNLOCK();
        uVar4 = (undefined)uStack_8;
        if (iVar2 == 0) {
          (**(code **)(*piStack_4c + 4))();
          uVar4 = (undefined)uStack_8;
        }
      }
    }
  }
  uStack_8._0_1_ = uVar4;
  *param_2 = 0;
  param_2[1] = 0;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piStack_2c[1] = piStack_2c[1] + 1;
    UNLOCK();
  }
  *param_2 = iStack_30;
  param_2[1] = (int)piStack_2c;
  param_2[2] = 0;
  param_2[3] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  param_2[2] = param_3;
  param_2[3] = (int)param_4;
  param_2[4] = 0;
  piVar7 = piStack_2c;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      piVar7 = piStack_2c;
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
        piVar7 = piStack_2c;
      }
    }
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar2 = piVar7[1] + -1;
    piVar7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  uStack_8 = 6;
  FUN_01675290(uVar5);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11002 ; VA 0x00779c60 ; FUN_00779c60 */

undefined4
FUN_00779c60(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_14 = param_2;
  uStack_10 = param_3;
  uStack_c = param_4;
  uStack_8 = param_5;
  FUN_00790e00(param_1,&uStack_14,2);
  return param_1;
}



/* FUNCTION 11003 ; VA 0x00779ca0 ; FUN_00779ca0 */

int __thiscall FUN_00779ca0(int param_1,uint param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  
  iVar3 = 0;
  iVar4 = 0;
  if (param_3 <= param_2) {
    return 0;
  }
  if (1 < param_3 - param_2) {
    iVar6 = ((param_3 - param_2) - 2 >> 1) + 1;
    uVar1 = *(uint *)(param_1 + 0x34) >> 3;
    iVar4 = 0;
    iVar2 = param_2 * 8;
    param_2 = param_2 + iVar6 * 2;
    piVar5 = (int *)(*(int *)(param_1 + 0x54) + iVar2);
    do {
      iVar3 = iVar3 + *(int *)(*piVar5 + 0x1c) * *(int *)(*piVar5 + 0x18) * uVar1;
      iVar4 = iVar4 + *(int *)(piVar5[2] + 0x1c) * *(int *)(piVar5[2] + 0x18) * uVar1;
      iVar6 = iVar6 + -1;
      piVar5 = piVar5 + 4;
    } while (iVar6 != 0);
  }
  iVar2 = 0;
  if (param_2 < param_3) {
    iVar2 = *(int *)(*(int *)(param_1 + 0x54) + param_2 * 8);
    iVar2 = (*(uint *)(param_1 + 0x34) >> 3) * *(int *)(iVar2 + 0x1c) * *(int *)(iVar2 + 0x18);
  }
  return iVar4 + iVar3 + iVar2;
}



/* FUNCTION 11004 ; VA 0x00779d60 ; FUN_00779d60 */

int * __thiscall FUN_00779d60(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  
  piVar1 = *(int **)(param_1 + 0x40);
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  piVar2 = (int *)*piVar1;
  param_2[4] = 0;
  param_2[5] = 0;
  while (piVar2 != piVar1) {
    iVar6 = piVar2[10];
    iVar7 = *(int *)(iVar6 + 0x90);
    if (iVar7 != 0) {
      uVar3 = *(undefined4 *)(iVar7 + 0x34);
      iVar4 = *(int *)(iVar7 + 0x30);
      uVar5 = *(undefined4 *)(iVar7 + 0x2c);
      if (iVar4 == *(int *)(iVar6 + 0x18)) {
        *param_2 = *param_2 + 1;
        iVar6 = FUN_0147d000(uVar5,iVar4,uVar3);
        param_2[1] = param_2[1] + iVar6;
      }
      else {
        param_2[2] = param_2[2] + 1;
        iVar6 = FUN_0147d000(uVar5,iVar4,uVar3);
        param_2[3] = param_2[3] + iVar6;
      }
    }
    FUN_00551320();
    piVar1 = *(int **)(param_1 + 0x40);
  }
  uVar8 = 0;
  iVar6 = *(int *)(param_1 + 0x60);
  if (*(int *)(param_1 + 100) - iVar6 >> 3 != 0) {
    do {
      iVar6 = *(int *)(iVar6 + uVar8 * 8);
      param_2[4] = param_2[4] + 1;
      iVar6 = *(int *)(iVar6 + 0x90);
      if (iVar6 == 0) {
        iVar7 = 0;
      }
      else {
        iVar7 = FUN_0147d000(*(undefined4 *)(iVar6 + 0x2c),*(undefined4 *)(iVar6 + 0x30),
                             *(undefined4 *)(iVar6 + 0x34));
      }
      iVar4 = *(int *)(param_1 + 100);
      uVar8 = uVar8 + 1;
      iVar6 = *(int *)(param_1 + 0x60);
      param_2[5] = param_2[5] + iVar7;
    } while (uVar8 < (uint)(iVar4 - iVar6 >> 3));
  }
  return param_2;
}



/* FUNCTION 11005 ; VA 0x00779e30 ; FUN_00779e30 */

void FUN_00779e30(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_2;
  *param_1 = 0;
  param_1[1] = 0;
  if (*(int *)(iVar2 + 0xa8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0xa8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *(undefined4 *)(iVar2 + 0xa4);
  param_1[1] = *(undefined4 *)(iVar2 + 0xa8);
  return;
}



/* FUNCTION 11006 ; VA 0x00779e70 ; FUN_00779e70 */

undefined4 FUN_00779e70(undefined4 *param_1)

{
  return *param_1;
}



/* FUNCTION 11007 ; VA 0x00779e80 ; FUN_00779e80 */

void __thiscall FUN_00779e80(int param_1,int *param_2)

{
  uint uVar1;
  char cVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uVar5;
  uint uVar6;
  uint *puVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  int *piVar11;
  int *piVar12;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af4c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00559500(*param_2,param_2[1],param_2);
  param_2[1] = *param_2;
  FUN_00775760(*(undefined4 *)(param_1 + 0x44),param_2);
  iStack_20 = 0;
  FUN_0060e810(0,&iStack_20,&uStack_11);
  piVar3 = *(int **)(param_1 + 100);
  piVar12 = *(int **)(param_1 + 0x60);
  uStack_8 = 0;
  for (; piVar12 != piVar3; piVar12 = piVar12 + 2) {
    iStack_20 = *piVar12;
    if ((uint)((iStack_40 - iStack_44 >> 2) * 3) >> 2 == 0) {
      FUN_006286d0();
    }
    FUN_00620c30(&iStack_20);
  }
  piVar3 = *(int **)(param_1 + 0x40);
  piVar12 = (int *)*piVar3;
  if (piVar12 != piVar3) {
    iStack_20 = 0;
    do {
      piVar11 = (int *)piVar12[0xb];
      piVar4 = piVar12 + 4;
      if (piVar11 != (int *)0x0) {
        LOCK();
        piVar11[1] = piVar11[1] + 1;
        UNLOCK();
        piVar11 = (int *)piVar12[0xb];
      }
      uVar8 = piVar12[10];
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_1c = *param_2 + iStack_20;
      piStack_18 = piVar11;
      if ((int *)iStack_1c != piVar4) {
        if (0xf < (uint)piVar12[9]) {
          piVar4 = (int *)*piVar4;
        }
        FUN_005542c0(piVar4,piVar12[8]);
      }
      iVar10 = *(int *)(uVar8 + 0x90);
      if (iVar10 == 0) {
        *(undefined4 *)(iStack_1c + 0x18) = 0;
      }
      else {
        uVar5 = FUN_0147d000(*(undefined4 *)(iVar10 + 0x2c),*(undefined4 *)(iVar10 + 0x30),
                             *(undefined4 *)(iVar10 + 0x34));
        *(undefined4 *)(iStack_1c + 0x18) = uVar5;
      }
      if (iStack_44 == iStack_40) {
        puVar7 = (uint *)0x0;
      }
      else if (uVar8 == 0) {
        puVar7 = (uint *)0x0;
      }
      else {
        uVar1 = (iStack_40 - iStack_44 >> 2) - 1;
        uVar6 = (uVar8 >> 3) + uVar8;
        uVar9 = 0;
        do {
          uVar6 = uVar6 & uVar1;
          puVar7 = (uint *)(iStack_44 + uVar6 * 4);
          piVar11 = piStack_18;
          if (*puVar7 == uVar8) goto LAB_0077a009;
          if (*puVar7 == 0) break;
          uVar6 = uVar6 + 1 + uVar9;
          uVar9 = uVar9 + 1;
        } while (uVar9 <= uVar1);
        puVar7 = (uint *)0x0;
      }
LAB_0077a009:
      uStack_8 = uStack_8 & 0xffffff00;
      iStack_20 = iStack_20 + 0x20;
      *(bool *)(iStack_1c + 0x1c) = puVar7 != (uint *)0x0;
      if (piVar11 != (int *)0x0) {
        LOCK();
        iVar10 = piVar11[1] + -1;
        piVar11[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar11)();
          LOCK();
          iVar10 = piVar11[2] + -1;
          piVar11[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      piVar4 = (int *)piVar12[2];
      if (*(char *)((int)piVar4 + 0xd) == '\0') {
        cVar2 = *(char *)(*piVar4 + 0xd);
        piVar12 = piVar4;
        piVar4 = (int *)*piVar4;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*piVar4 + 0xd);
          piVar12 = piVar4;
          piVar4 = (int *)*piVar4;
        }
      }
      else {
        cVar2 = *(char *)(piVar12[1] + 0xd);
        piVar11 = (int *)piVar12[1];
        piVar4 = piVar12;
        while ((piVar12 = piVar11, cVar2 == '\0' && (piVar4 == (int *)piVar12[2]))) {
          cVar2 = *(char *)(piVar12[1] + 0xd);
          piVar11 = (int *)piVar12[1];
          piVar4 = piVar12;
        }
      }
    } while (piVar12 != piVar3);
  }
  if (iStack_44 != 0) {
    uVar8 = iStack_3c - iStack_44 & 0xfffffffc;
    iVar10 = iStack_44;
    if (0xfff < uVar8) {
      iVar10 = *(int *)(iStack_44 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iStack_44 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar10,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11008 ; VA 0x0077a0e0 ; FUN_0077a0e0 */

int __fastcall FUN_0077a0e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = 0;
  piVar1 = *(int **)(param_1 + 0x40);
  piVar2 = (int *)*piVar1;
  while (piVar2 != piVar1) {
    iVar3 = *(int *)(piVar2[10] + 0x90);
    if (iVar3 == 0) {
      iVar3 = 0;
    }
    else {
      iVar3 = FUN_0147d000(*(undefined4 *)(iVar3 + 0x2c),*(undefined4 *)(iVar3 + 0x30),
                           *(undefined4 *)(iVar3 + 0x34));
    }
    iVar4 = iVar4 + iVar3;
    FUN_00551320();
    piVar1 = *(int **)(param_1 + 0x40);
  }
  return iVar4;
}



/* FUNCTION 11009 ; VA 0x0077a140 ; FUN_0077a140 */

void FUN_0077a140(int param_1)

{
  FUN_009022e0(param_1,*(undefined8 *)(param_1 + 0x10));
  return;
}



/* FUNCTION 11010 ; VA 0x0077a160 ; FUN_0077a160 */

void FUN_0077a160(int param_1)

{
  FUN_00902190(param_1,*(undefined8 *)(param_1 + 0x10));
  return;
}



/* FUNCTION 11011 ; VA 0x0077a180 ; FUN_0077a180 */

void FUN_0077a180(undefined4 param_1,undefined4 param_2)

{
  FUN_007777a0(param_2);
  return;
}



/* FUNCTION 11012 ; VA 0x0077a190 ; FUN_0077a190 */

uint __fastcall FUN_0077a190(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x48);
  if ((uVar1 == *(uint *)(param_1 + 0x4c)) &&
     (uVar1 = *(uint *)(param_1 + 0x54), uVar1 == *(uint *)(param_1 + 0x58))) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 11013 ; VA 0x0077a1b0 ; FUN_0077a1b0 */

void FUN_0077a1b0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_00776490(param_1);
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 0x10);
      if (param_3 == 1) {
        FUN_005e6280();
        return;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_005e6280();
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9f9bc);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_25a61529f4347d53c25f732beadf65e9>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 11014 ; VA 0x0077a240 ; FUN_0077a240 */

void FUN_0077a240(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_00776490(param_1);
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 0x10);
      if (param_3 == 1) {
        FUN_005e6280();
        return;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_005e6280();
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9f984);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_86927da7bab945215640e6b2b8125eb3>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 11015 ; VA 0x0077a2d0 ; FUN_0077a2d0 */

void FUN_0077a2d0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_00776490(param_1);
      if (param_3 != 1) {
        return;
      }
      FUN_005e6280();
      return;
    }
    if (param_3 == 2) {
      FUN_005e6280();
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9f94c);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_8ff1a3904c1ddaff2682519c9f01a0b3>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 11016 ; VA 0x0077a350 ; FUN_0077a350 */

void FUN_0077a350(void)

{
  if (DAT_01eb1b24 != '\0') {
    FUN_016774b0(DAT_01eb1b24,"TC Device lost",0);
  }
  return;
}



/* FUNCTION 11017 ; VA 0x0077a370 ; FUN_0077a370 */

int FUN_0077a370(int param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined **ppuVar5;
  undefined4 uVar6;
  undefined auStack_6c [12];
  undefined auStack_60 [12];
  undefined auStack_54 [12];
  undefined auStack_48 [12];
  undefined auStack_3c [12];
  undefined auStack_30 [12];
  undefined auStack_24 [12];
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af510;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    FUN_00776490(param_1 + 0x34);
    uStack_8._0_1_ = 1;
    FUN_00776490(auStack_6c);
    uStack_8._0_1_ = 2;
    FUN_00776490(auStack_60);
    uStack_8._0_1_ = 3;
    uVar6 = 0;
    FUN_00776490(auStack_54);
    uStack_8._0_1_ = 4;
    FUN_00776490(auStack_48);
    uStack_8._0_1_ = 5;
    FUN_00776490(auStack_3c);
    uStack_8._0_1_ = 6;
    cVar3 = FUN_00585a40(auStack_24,uVar6);
    if (cVar3 != '\0') {
      FUN_005e6280();
    }
    else {
      FUN_00776490(auStack_24);
      uStack_8._0_1_ = 7;
      FUN_00776490(auStack_30);
      FUN_005e6280();
      FUN_005e6280();
    }
    FUN_005e6280();
    ppuVar5 = &PTR_FUN_018fbb44;
    if (cVar3 != '\0') {
      ppuVar5 = (undefined **)0x0;
    }
    FUN_005e6280(ppuVar5);
    FUN_005e6280();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_005e6280();
    FUN_0090ca30(ppuVar5);
    iVar4 = FUN_005e6280();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 11018 ; VA 0x0077a4f0 ; FUN_0077a4f0 */

void __thiscall FUN_0077a4f0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af548;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar2 + 0x34) < DAT_01eb1b98) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1b98), DAT_01eb1b98 == -1)) {
    uStack_8 = 0;
    uVar11 = FUN_0152dab0("Render","TextureCompositor::render",0xffffffff);
    DAT_01eb1b94 = (undefined4)((ulonglong)uVar11 >> 0x20);
    DAT_01eb1b90 = (undefined4)uVar11;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb1b98);
  }
  uVar5 = DAT_01eb1b94;
  uVar4 = DAT_01eb1b90;
  uVar11 = FUN_0152d930(DAT_01eb1b90,DAT_01eb1b94);
  uStack_8 = 1;
  if ((*(int *)(iVar2 + 0x34) < DAT_01eb1ba8) && (FUN_016f3809(&DAT_01eb1ba8), DAT_01eb1ba8 == -1))
  {
    uStack_8._0_1_ = 2;
    uVar12 = FUN_0152dab0(&DAT_018fb928,"TextureCompositor::render",0xffffffff);
    DAT_01eb1ba4 = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb1ba0 = (undefined4)uVar12;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016f37bf(&DAT_01eb1ba8);
  }
  uVar7 = DAT_01eb1ba4;
  uVar6 = DAT_01eb1ba0;
  uVar12 = FUN_0152d930(DAT_01eb1ba0,DAT_01eb1ba4);
  uVar9 = 0;
  piVar10 = *(int **)(param_1 + 0x54);
  uVar8 = *(int *)(param_1 + 0x58) - (int)piVar10 >> 3;
  uStack_8._0_1_ = 3;
  if (uVar8 != 0) {
    do {
      iVar2 = *piVar10;
      iVar3 = *(int *)(iVar2 + 0xac);
      if ((iVar3 != 0) &&
         (*(int *)(iVar3 + 0x18) == (*(int *)(iVar3 + 0x10) - *(int *)(iVar3 + 0xc)) / 0x60)) {
        FUN_0077ad70(iVar2,uVar9,param_2);
        *(undefined4 *)(iVar2 + 0xac) = 0;
        piVar10 = *(int **)(iVar2 + 0xb0);
        *(undefined4 *)(iVar2 + 0xb0) = 0;
        if (piVar10 != (int *)0x0) {
          LOCK();
          iVar2 = piVar10[1] + -1;
          piVar10[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar10)();
            LOCK();
            iVar2 = piVar10[2] + -1;
            piVar10[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar10 + 4))();
            }
          }
        }
        iVar2 = *(int *)(param_1 + 0x54) + uVar9 * 8;
        FUN_00775350(iVar2 + 8,*(undefined4 *)(param_1 + 0x58),iVar2);
        piVar10 = *(int **)(*(int *)(param_1 + 0x58) + -4);
        if (piVar10 != (int *)0x0) {
          LOCK();
          iVar2 = piVar10[1] + -1;
          piVar10[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar10)();
            LOCK();
            piVar1 = piVar10 + 2;
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piVar10 + 4))();
            }
          }
        }
        *(int *)(param_1 + 0x58) = *(int *)(param_1 + 0x58) + -8;
        break;
      }
      uVar9 = uVar9 + 1;
      piVar10 = piVar10 + 2;
    } while (uVar9 < uVar8);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0152dda0(uVar6,uVar7,uVar12);
  uStack_8 = 5;
  FUN_0152dda0(uVar4,uVar5,uVar11);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11019 ; VA 0x0077a780 ; FUN_0077a780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0077a780(int *param_1,int *param_2,int *param_3)

{
  char cVar1;
  int *piVar2;
  undefined4 *puVar3;
  uint3 uVar4;
  int iVar5;
  uint *puVar6;
  undefined4 uVar7;
  int iVar8;
  int *piVar9;
  undefined4 *puVar10;
  char *pcVar11;
  int iVar12;
  float fVar13;
  undefined auStack_6a4 [848];
  undefined auStack_354 [580];
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined auStack_c4 [64];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  char *pcStack_64;
  undefined4 uStack_60;
  char *pcStack_5c;
  int iStack_58;
  undefined2 auStack_54 [2];
  undefined4 uStack_50;
  undefined2 uStack_4c;
  int iStack_48;
  int *piStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  char *pcStack_38;
  undefined4 uStack_34;
  undefined uStack_30;
  undefined uStack_2f;
  undefined uStack_2e;
  undefined uStack_2d;
  undefined uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af568;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  iVar5 = (**(code **)(**(int **)(*param_1 + 0x3c) + 0x40))();
  fVar13 = DAT_018ce2f4;
  if (*(char *)(iVar5 + 0x39) == '\0') {
    fVar13 = 0.0;
  }
  iVar12 = *(int *)(*param_3 + 0x2c);
  iVar8 = *(int *)(*param_3 + 0x28);
  iStack_40 = iVar5;
  FUN_01165a00(DAT_018daf58 / (float)param_1[1],0,0,
               DAT_018f7864 -
               (fVar13 + fVar13) /
               (float)((double)iVar8 + (double)(&DAT_018c0d90)[-(iVar8 >> 0x1f)]),0,
               DAT_018daf58 / (float)param_1[2],0,
               (fVar13 + fVar13) /
               (float)((double)iVar12 + (double)(&DAT_018c0d90)[-(iVar12 >> 0x1f)]) - DAT_018ce2f8,0
               ,0,0x3a83126f,0x3f000000,0,0,0,0x3f800000);
  if (*(char *)(iVar5 + 0x3a) != '\0') {
    puVar6 = (uint *)FUN_01165f10(1);
    uStack_28 = *puVar6 ^ DAT_018c4ea0;
    uStack_24 = puVar6[1] ^ _UNK_018c4ea4;
    uStack_20 = puVar6[2] ^ _UNK_018c4ea8;
    uStack_1c = puVar6[3] ^ _UNK_018c4eac;
    FUN_01165f50(1,&uStack_28);
  }
  FUN_007cc9d0();
  uVar7 = FUN_01165df0();
  FUN_007cdb40(uVar7);
  FUN_007cd560(auStack_c4,0);
  FUN_00776530();
  FUN_007ce460(auStack_354);
  FUN_0147bca0();
  uStack_110 = 1;
  uStack_10c = _DAT_018fbb60;
  uStack_108 = _UNK_018fbb64;
  uStack_104 = _UNK_018fbb68;
  uStack_100 = _UNK_018fbb6c;
  (**(code **)(*param_2 + 0x14))(*param_3,0,1,&uStack_110,0);
  (**(code **)(*param_2 + 0x30))(0,auStack_6a4,0x350);
  iVar5 = param_1[3];
  uStack_18 = 0;
  iVar12 = piStack_14[4] - iVar5 >> 0x1f;
  if ((piStack_14[4] - iVar5) / 0x60 + iVar12 != iVar12) {
    iVar12 = 0;
    do {
      pcStack_5c = "TexCompPMAFS";
      if (*(int *)(iVar5 + 0x50 + iVar12) != 0) {
        pcStack_5c = "TexCompFS";
      }
      uStack_3c = *(undefined4 *)(*piStack_14 + 0x4f4);
      pcStack_38 = pcStack_5c + 1;
      pcVar11 = pcStack_5c;
      do {
        cVar1 = *pcVar11;
        pcVar11 = pcVar11 + 1;
      } while (cVar1 != '\0');
      iStack_58 = (int)pcVar11 - (int)pcStack_38;
      pcStack_64 = "TexCompVS";
      uStack_60 = 9;
      FUN_00790e00(&iStack_48,&pcStack_64,2);
      uStack_8 = 0;
      if ((iStack_48 != 0) && (**(int **)(iVar5 + 0x54 + iVar12) != 0)) {
        piVar2 = *(int **)(iVar5 + 0x58 + iVar12);
        piVar9 = (int *)&DAT_01eb1b04;
        if (piVar2 != (int *)0x0) {
          piVar9 = piVar2;
        }
        if (*piVar9 != 0) {
          uVar4 = (uint3)param_3;
          param_3 = (int *)(uint)(uVar4 & 0xff);
          uStack_34 = 0xf;
          uStack_2c = 0;
          uStack_20 = 0;
          iVar8 = 0;
          uStack_1c = uStack_1c & 0xffffff00;
          if (*(int *)(iVar5 + 0x50 + iVar12) == 0) {
            iVar8 = 8;
          }
          uStack_2f = (&DAT_018fa101)[iVar8];
          uStack_30 = (&DAT_018fa100)[iVar8];
          uStack_24 = CONCAT31((int3)(uStack_24 >> 8),(*(char *)(iStack_40 + 0x3a) != '\0') + '\x01'
                              ) & 0xffff00ff;
          uStack_2e = uStack_30;
          uStack_2d = uStack_2f;
          (**(code **)(*param_2 + 0x3c))(&uStack_24,&uStack_34,(int)&param_3 + 1);
          (**(code **)(*param_2 + 0x24))(iStack_48);
          auStack_54[0] = 0x101;
          uStack_50 = 0;
          uStack_4c = 0;
          puVar3 = *(undefined4 **)(iVar5 + 0x58 + iVar12);
          puVar10 = (undefined4 *)&DAT_01eb1b04;
          if (puVar3 != (undefined4 *)0x0) {
            puVar10 = puVar3;
          }
          (**(code **)(*param_2 + 0x34))(0,*puVar10,auStack_54);
          puVar3 = (undefined4 *)(iVar5 + 0x40 + iVar12);
          uStack_84 = *puVar3;
          uStack_80 = puVar3[1];
          uStack_7c = puVar3[2];
          uStack_78 = puVar3[3];
          uStack_68 = *(undefined4 *)(iVar5 + 0x3c + iVar12);
          uStack_74 = *(undefined4 *)(iVar5 + 0x30 + iVar12);
          uStack_70 = *(undefined4 *)(iVar5 + 0x34 + iVar12);
          uStack_6c = *(undefined4 *)(iVar5 + 0x38 + iVar12);
          if (*(int *)(iVar5 + 0x50 + iVar12) == 2) {
            uStack_68 = 0x40800000;
          }
          (**(code **)(*param_2 + 0x30))(1,&uStack_84,0x20);
          puVar3 = (undefined4 *)**(int **)(iVar5 + 0x54 + iVar12);
          (**(code **)(*param_2 + 0x40))(*puVar3,puVar3[2],puVar3[3],puVar3[4],puVar3[5],0);
        }
      }
      piVar2 = piStack_44;
      uStack_8 = 0xffffffff;
      if (piStack_44 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_44[1] + -1;
        piStack_44[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_44)();
          LOCK();
          piVar9 = piVar2 + 2;
          iVar5 = *piVar9 + -1;
          *piVar9 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      iVar12 = iVar12 + 0x60;
      uStack_18 = uStack_18 + 1;
      iVar5 = piStack_14[3];
    } while (uStack_18 < (uint)((piStack_14[4] - iVar5) / 0x60));
  }
  (**(code **)(*param_2 + 0x18))();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11020 ; VA 0x0077abf0 ; FUN_0077abf0 */

void FUN_0077abf0(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  undefined *puVar2;
  double *pdVar3;
  undefined auStack_30 [8];
  double adStack_28 [2];
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af580;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc4;
  piVar1 = (int *)(param_1 + 0x90);
  ExceptionList = &pvStack_10;
  piStack_18 = piVar1;
  puVar2 = &stack0xffffffc4;
  if (*(int *)(*(int *)(param_1 + 0x90) + 0x48) != 3) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016827e0(adStack_28);
    (**(code **)(*param_3 + 8))(*param_2,*piVar1,0,0);
    puVar2 = puStack_14;
    if (DAT_01eb1b24 != '\0') {
      pdVar3 = (double *)FUN_016827e0(auStack_30);
      FUN_01677490(DAT_01eb1b24,"TC Job[%p]: texture blit (width %d) took %d us",param_1,
                   *(undefined4 *)(*piVar1 + 0x30),
                   (int)((*pdVar3 - adStack_28[0]) * DAT_018c0d70 * DAT_018c0d70));
      FUN_0077ad2a();
      return;
    }
  }
  puStack_14 = puVar2;
  uStack_8 = 0xffffffff;
  if ((*(int *)(param_1 + 0xa4) != 0) && (*(int *)(*(int *)(param_1 + 0xa4) + 8) != 0)) {
    FUN_00773c10(piVar1);
  }
  FUN_00778490(param_1);
  FUN_0077a370(param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11021 ; VA 0x0077acae ; Catch@0077acae */

undefined * Catch_0077acae(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  int *piVar2;
  
  if (DAT_01eb1b24 != '\0') {
    FUN_01677490(DAT_01eb1b24,"TC Job[%p]: texture blit (width %d) failed",
                 *(undefined4 *)(unaff_EBP + 8),
                 *(undefined4 *)(**(int **)(unaff_EBP + -0x14) + 0x30),0);
    if (DAT_01eb1b24 != '\0') {
      piVar2 = *(int **)(unaff_EBP + -0x18);
      uVar1 = (**(code **)(*piVar2 + 4))();
      FUN_01677650(DAT_01eb1b24,"TC: Failure reason %s",uVar1);
      goto LAB_0077ad04;
    }
  }
  piVar2 = *(int **)(unaff_EBP + -0x18);
LAB_0077ad04:
  uVar1 = (**(code **)(*piVar2 + 4))();
  FUN_0086f2f0(0,"TextureCompositor copyFramebuffer failed: %s",uVar1);
  return &DAT_0077ad21;
}



/* FUNCTION 11022 ; VA 0x0077ad2a ; FUN_0077ad2a */

void FUN_0077ad2a(void)

{
  int unaff_EBP;
  int unaff_ESI;
  undefined4 unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if ((*(int *)(unaff_ESI + 0xa4) != 0) && (*(int *)(*(int *)(unaff_ESI + 0xa4) + 8) != 0)) {
    FUN_00773c10(unaff_EDI);
  }
  FUN_00778490(unaff_ESI);
  FUN_0077a370(unaff_ESI);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 11023 ; VA 0x0077ad70 ; FUN_0077ad70 */

void __thiscall FUN_0077ad70(int param_1,int param_2,int param_3,undefined4 param_4)

{
  uint *puVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  undefined auStack_68 [20];
  undefined4 uStack_54;
  int *piStack_50;
  int iStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  int iStack_3c;
  int *piStack_38;
  uint uStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af5a8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff8c;
  ExceptionList = &pvStack_10;
  iStack_2c = param_1;
  iStack_1c = FUN_0077a0e0();
  uVar10 = 0;
  piVar8 = *(int **)(param_1 + 0x48);
  iVar9 = *(int *)(param_1 + 0x4c) - (int)piVar8 >> 3;
  if (iVar9 != 0) {
    puVar1 = (uint *)(param_1 + 0x34);
    do {
      iVar2 = *piVar8;
      piVar8 = piVar8 + 2;
      uVar10 = uVar10 + (*puVar1 >> 3) * *(int *)(iVar2 + 0x1c) * *(int *)(iVar2 + 0x18);
      iVar9 = iVar9 + -1;
      param_1 = iStack_2c;
    } while (iVar9 != 0);
  }
  uVar4 = FUN_00779ca0(param_3 + 1,*(int *)(param_1 + 0x58) - *(int *)(param_1 + 0x54) >> 3);
  iVar9 = FUN_00779ca0(0,param_3);
  iVar9 = (uVar4 >> 2) + iVar9 + (uVar10 >> 2);
  piStack_30 = *(int **)(param_2 + 0x1c);
  uStack_34 = *(uint *)(param_2 + 0x18);
  if (*(uint *)(param_1 + 0x38) <=
      (*(uint *)(param_1 + 0x34) >> 3) * uStack_34 * (int)piStack_30 + iVar9 + iStack_1c) {
    uStack_34 = uStack_34 >> 1;
    piStack_30 = (int *)((uint)piStack_30 >> 1);
  }
  piStack_28 = (int *)(param_2 + 0x90);
  iVar2 = *piStack_28;
  piStack_20 = piStack_30;
  uStack_18 = uStack_34;
  if (iVar2 != 0) {
    if ((*(uint *)(iVar2 + 0x30) == uStack_34) && (*(int **)(iVar2 + 0x34) == piStack_30)) {
      ExceptionList = pvStack_10;
      return;
    }
    piStack_38 = (int *)FUN_01674e20(0xb4);
    if (piStack_38 == (int *)0x0) {
      uVar5 = 0;
    }
    else {
      FUN_0170d1f0(piStack_38,0,0xb4);
      uVar5 = FUN_007769b0();
    }
    iStack_3c = 0;
    piStack_38 = (int *)0x0;
    FUN_007759c0(uVar5,param_2);
    iVar2 = iStack_3c;
    uStack_8 = 0;
    *(undefined4 *)(iStack_3c + 0x40) = 0x7f7fffff;
    FUN_007772c0(param_2 + 0x90);
    if (DAT_01eb1b24 != '\0') {
      FUN_01677490(DAT_01eb1b24,"TC Job[%p]: store previous texture as orphaned job %p",param_2,
                   iVar2,0);
    }
    piVar8 = *(int **)(param_1 + 100);
    if (*(int **)(param_1 + 0x68) == piVar8) {
      FUN_00603260(piVar8,&iStack_3c);
    }
    else {
      *piVar8 = 0;
      piVar8[1] = 0;
      if (piStack_38 != (int *)0x0) {
        LOCK();
        piStack_38[1] = piStack_38[1] + 1;
        UNLOCK();
      }
      *piVar8 = iVar2;
      piVar8[1] = (int)piStack_38;
      *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + 8;
    }
    piVar8 = piStack_38;
    FUN_0077b3d0();
    uStack_8 = 0xffffffff;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar2 = piVar8[1] + -1;
      piVar8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar2 = piVar8[2] + -1;
        piVar8[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  uVar10 = uStack_18;
  if (DAT_01eb1b24 != '\0') {
    FUN_016773b0(DAT_01eb1b24,
                 "TC Job[%p]: render (totalSize %d, pendingSize %d, budget %d -> width %d)",param_2,
                 iStack_1c,iVar9,*(undefined4 *)(param_1 + 0x38),uStack_18);
  }
  uStack_54 = 0;
  piStack_50 = (int *)0x0;
  iStack_4c = 0;
  piStack_48 = (int *)0x0;
  uStack_44 = 0;
  iStack_3c = 0;
  piStack_38 = (int *)0x0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  FUN_0077b450(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puVar6 = (undefined4 *)FUN_007798d0(auStack_68,uVar10,piStack_20);
  piVar11 = piStack_50;
  uStack_54 = *puVar6;
  piVar8 = (int *)puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_50[1] + -1;
    piStack_50[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      puVar3 = (undefined4 *)*piStack_50;
      piStack_50 = piVar8;
      (*(code *)*puVar3)();
      LOCK();
      piVar8 = piVar11 + 2;
      iVar9 = *piVar8 + -1;
      *piVar8 = iVar9;
      UNLOCK();
      piVar8 = piStack_50;
      if (iVar9 == 0) {
        (**(code **)(*piVar11 + 4))();
        piVar8 = piStack_50;
      }
    }
  }
  piStack_50 = piVar8;
  piVar11 = piStack_48;
  iStack_4c = puVar6[2];
  piVar8 = (int *)puVar6[3];
  puVar6[2] = 0;
  puVar6[3] = 0;
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_48[1] + -1;
    piStack_48[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      puVar3 = (undefined4 *)*piStack_48;
      piStack_48 = piVar8;
      (*(code *)*puVar3)();
      LOCK();
      piVar8 = piVar11 + 2;
      iVar9 = *piVar8 + -1;
      *piVar8 = iVar9;
      UNLOCK();
      piVar8 = piStack_48;
      if (iVar9 == 0) {
        (**(code **)(*piVar11 + 4))();
        piVar8 = piStack_48;
      }
    }
  }
  piStack_48 = piVar8;
  uStack_44 = puVar6[4];
  FUN_0056b650();
  if (iStack_4c == 0) {
    piVar7 = (int *)FUN_00779620(auStack_24,&uStack_54);
    piVar11 = piStack_20;
    iStack_3c = *piVar7;
    piVar8 = (int *)piVar7[1];
    *piVar7 = 0;
    piVar7[1] = 0;
    piStack_38 = piVar8;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_20[1] + -1;
      piStack_20[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar7 = piVar11 + 2;
        iVar9 = *piVar7 + -1;
        *piVar7 = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
  }
  else {
    if (piStack_48 != (int *)0x0) {
      LOCK();
      piStack_48[1] = piStack_48[1] + 1;
      UNLOCK();
    }
    iStack_3c = iStack_4c;
    piStack_38 = piStack_48;
    piVar8 = piStack_48;
  }
  uStack_8 = 2;
  FUN_0077a780(param_4,&iStack_3c);
  FUN_007772c0(&uStack_54);
  if (DAT_01d60d04 != '\0') {
    *(undefined4 *)(param_2 + 0xa0) =
         *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x30) + 0x4e4) + 0x24);
  }
  piVar11 = &iStack_3c;
  FUN_0077abf0(param_2,piVar11,param_4);
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar9 = piVar8[1] + -1;
    piVar8[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      piVar7 = piVar8 + 2;
      iVar9 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piVar8 + 4))();
        FUN_0077b19e(piVar11,param_4);
        return;
      }
    }
  }
  FUN_0056b650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11024 ; VA 0x0077b163 ; Catch@0077b163 */

undefined * Catch_0077b163(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x3c) + 4))();
  FUN_0086f2f0(3,"Failed to allocate %d kB VRAM for humanoid texture: %s",
               (*(uint *)(*(int *)(unaff_EBP + -0x28) + 0x34) >> 3) * *(int *)(unaff_EBP + -0x2c) *
               *(int *)(unaff_EBP + -0x30) >> 10,uVar1);
  return &DAT_0077b196;
}



/* FUNCTION 11025 ; VA 0x0077b19e ; FUN_0077b19e */

void FUN_0077b19e(void)

{
  int unaff_EBP;
  
  FUN_0056b650();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 11026 ; VA 0x0077b1c0 ; FUN_0077b1c0 */

undefined4 * __thiscall FUN_0077b1c0(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af5d0;
  pvStack_10 = ExceptionList;
  iVar5 = (int)param_1 + *(byte *)(param_1 + 3) + 0xd;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  uVar1 = FUN_009cc8a0(param_2);
  FUN_00607080(&iStack_1c,uVar1,param_2,-(uint)(iVar5 != 0) & iVar5 + 1U);
  if (iStack_1c != 0) {
    ExceptionList = pvStack_10;
    return (undefined4 *)(iStack_1c + 0x20);
  }
  piVar6 = &iStack_18;
  uVar7 = 0;
  uVar1 = FUN_008ccd50(0,piVar6);
  piVar2 = (int *)FUN_009dd5a0(auStack_30,param_2,0x41700000,uVar1,uVar7,piVar6);
  piVar6 = (int *)piVar2[1];
  iStack_28 = *piVar2;
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = (int *)piVar2[1];
  }
  uStack_8 = 0;
  piStack_24 = piVar6;
  iStack_1c = iStack_28;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar5 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (iStack_18 == 0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    iVar5 = FUN_007773d0(param_2);
    puVar4 = (undefined4 *)(iVar5 + 0x18);
    if (iStack_18 == 1) {
      FUN_007781f0(&uStack_48,*(undefined4 *)(*piStack_14 + 0x3c),iStack_1c);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      puVar3 = (undefined4 *)FUN_01674e20(0x18);
      if (puVar3 == (undefined4 *)0x0) {
        puVar3 = (undefined4 *)0x0;
      }
      else {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (iStack_44 != 0) {
          LOCK();
          *(int *)(iStack_44 + 4) = *(int *)(iStack_44 + 4) + 1;
          UNLOCK();
        }
        *puVar3 = uStack_48;
        puVar3[1] = iStack_44;
        puVar3[2] = uStack_40;
        puVar3[3] = uStack_3c;
        puVar3[4] = uStack_38;
        puVar3[5] = uStack_34;
      }
      uStack_20 = 0;
      iStack_1c = 0;
      FUN_00775930(puVar3,puVar4);
      *puVar4 = uStack_20;
      piVar2 = *(int **)(iVar5 + 0x1c);
      *(int *)(iVar5 + 0x1c) = iStack_1c;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar5 = piVar2[1] + -1;
        piVar2[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar5 = piVar2[2] + -1;
          piVar2[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      FUN_00550b30();
    }
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar5 = piVar6[1] + -1;
    piVar6[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar2 = piVar6 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 11027 ; VA 0x0077b3d0 ; FUN_0077b3d0 */

void __fastcall FUN_0077b3d0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  param_1[2] = 0;
  piVar2 = (int *)param_1[3];
  param_1[3] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = 0;
  piVar2 = (int *)param_1[1];
  param_1[1] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[4] = 0;
  return;
}



/* FUNCTION 11028 ; VA 0x0077b450 ; FUN_0077b450 */

void * FUN_0077b450(void)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  void *pvVar4;
  float10 fVar5;
  undefined auStack_c0 [16];
  double dStack_b0;
  undefined auStack_a8 [16];
  double dStack_98;
  undefined auStack_90 [16];
  double dStack_80;
  undefined auStack_78 [16];
  double dStack_68;
  undefined auStack_60 [16];
  double dStack_50;
  undefined auStack_48 [12];
  double dStack_3c;
  undefined auStack_34 [16];
  double dStack_24;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af629;
  pvStack_10 = ExceptionList;
  pvVar4 = ExceptionList;
  if ((DAT_01d5a308 != '\0') && (DAT_01d5a210 != '\0')) {
    ExceptionList = &pvStack_10;
    fVar5 = (float10)FUN_01683110();
    dStack_3c = (double)fVar5;
    pvVar4 = (void *)FUN_00587490();
    uStack_8 = 0;
    if (iStack_1c != 0) {
      FUN_00776490();
      uStack_8._0_1_ = 1;
      FUN_00776490(auStack_48);
      dStack_b0 = dStack_3c;
      uStack_8._0_1_ = 2;
      FUN_00776490(auStack_c0);
      dStack_98 = dStack_b0;
      uStack_8._0_1_ = 3;
      FUN_00776490(auStack_a8);
      dStack_80 = dStack_98;
      uStack_8._0_1_ = 4;
      FUN_00776490(auStack_90);
      dStack_68 = dStack_80;
      uStack_8._0_1_ = 5;
      FUN_00776490(auStack_78);
      dStack_24 = dStack_68;
      uStack_8._0_1_ = 6;
      cVar3 = FUN_00585a40(auStack_34);
      if (cVar3 == '\0') {
        FUN_00776490(auStack_34);
        dStack_50 = dStack_24;
        uStack_8._0_1_ = 7;
        FUN_00776490(auStack_60);
        FUN_005e6280();
        FUN_005e6280();
      }
      else {
        FUN_005e6280();
      }
      FUN_005e6280();
      FUN_005e6280();
      FUN_005e6280();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_005e6280();
      FUN_0090ca30();
      pvVar4 = (void *)FUN_005e6280();
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 11029 ; VA 0x0077b660 ; FUN_0077b660 */

void __thiscall FUN_0077b660(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  double *pdVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  undefined8 uVar11;
  int *piStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af654;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1b88) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1b88), DAT_01eb1b88 == -1)) {
    uStack_8 = 0;
    uVar11 = FUN_0152dab0("Render","TextureCompositor::update",0xffffffff);
    DAT_01eb1b84 = (undefined4)((ulonglong)uVar11 >> 0x20);
    DAT_01eb1b80 = (undefined4)uVar11;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb1b88);
  }
  uStack_1c = DAT_01eb1b80;
  uStack_18 = DAT_01eb1b84;
  uVar11 = FUN_0152d930(DAT_01eb1b80,DAT_01eb1b84);
  uStack_8 = 1;
  FUN_0077bcc0(param_2);
  FUN_00778a10();
  if ((*(int *)(param_1 + 0x48) == *(int *)(param_1 + 0x4c)) &&
     (*(int *)(param_1 + 0x54) == *(int *)(param_1 + 0x58))) {
    pdVar4 = (double *)FUN_01682800(&piStack_24);
    if (DAT_018c0d60 <= *pdVar4 - *(double *)(param_1 + 0x78)) {
      FUN_00778690();
    }
  }
  else {
    puVar5 = (undefined4 *)FUN_01682800(&piStack_24);
    *(undefined4 *)(param_1 + 0x78) = *puVar5;
    *(undefined4 *)(param_1 + 0x7c) = puVar5[1];
  }
  piVar7 = *(int **)(param_1 + 0x4c);
  piVar10 = *(int **)(param_1 + 0x48);
  uVar8 = (int)piVar7 - (int)piVar10 >> 3;
  param_2 = piVar7;
  if ((uVar8 == 0) || (uVar9 = *(int *)(param_1 + 0x58) - *(int *)(param_1 + 0x54) >> 3, 7 < uVar9))
  {
    if ((DAT_01d60cec != '\0') && (piVar10 != piVar7)) {
LAB_0077b820:
      do {
        if (NAN(*(float *)(*piVar10 + 0x40)) == (*(float *)(*piVar10 + 0x40) == 0.0)) {
          piVar10 = piVar10 + 2;
          if (piVar10 != piVar7) goto LAB_0077b820;
        }
        if (piVar10 == *(int **)(param_1 + 0x4c)) break;
        piVar7 = *(int **)(param_1 + 0x58);
        param_2 = *(int **)(param_1 + 0x54);
        if (*(int **)(param_1 + 0x5c) == piVar7) {
          FUN_00603260(param_2,piVar10);
        }
        else if (param_2 == piVar7) {
          *piVar7 = 0;
          piVar7[1] = 0;
          if (piVar10[1] != 0) {
            LOCK();
            piVar1 = (int *)(piVar10[1] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          *piVar7 = *piVar10;
          piVar7[1] = piVar10[1];
          *(int *)(param_1 + 0x58) = *(int *)(param_1 + 0x58) + 8;
        }
        else {
          uStack_14 = piVar10[1];
          if (uStack_14 != 0) {
            LOCK();
            *(int *)(uStack_14 + 4) = *(int *)(uStack_14 + 4) + 1;
            UNLOCK();
            uStack_14 = piVar10[1];
          }
          iVar2 = *piVar10;
          piVar1 = piVar7 + -2;
          *piVar7 = 0;
          piVar7[1] = 0;
          *piVar7 = *piVar1;
          piVar7[1] = piVar7[-1];
          *piVar1 = 0;
          piVar7[-1] = 0;
          *(int *)(param_1 + 0x58) = *(int *)(param_1 + 0x58) + 8;
          FUN_007752e0(param_2,piVar1,piVar7);
          *param_2 = iVar2;
          piVar7 = (int *)param_2[1];
          param_2[1] = uStack_14;
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar2 = piVar7[1] + -1;
            piVar7[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piVar7)();
              LOCK();
              iVar2 = piVar7[2] + -1;
              piVar7[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
        }
        FUN_00775350(piVar10 + 2,*(undefined4 *)(param_1 + 0x4c),piVar10);
        piVar7 = *(int **)(*(int *)(param_1 + 0x4c) + -4);
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar2 = piVar7[1] + -1;
          piVar7[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            iVar2 = piVar7[2] + -1;
            piVar7[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        piVar7 = (int *)(*(int *)(param_1 + 0x4c) + -8);
        *(int **)(param_1 + 0x4c) = piVar7;
        piVar10 = *(int **)(param_1 + 0x48);
      } while (piVar10 != piVar7);
    }
  }
  else {
    uVar9 = 8 - uVar9;
    uStack_14 = uVar8;
    if (uVar9 < uVar8) {
      uStack_14 = uVar9;
    }
    piVar1 = piVar10 + uStack_14 * 2;
    if (piVar1 != piVar7) {
      piVar7 = piVar10;
      if (0x20 < (int)uVar8) {
        do {
          FUN_007753d0(&piStack_24,piVar7,param_2,param_2);
          piVar10 = piStack_20;
          if ((piVar1 < piStack_20) &&
             (param_2 = piStack_24, piVar10 = piVar7, piStack_24 <= piVar1)) goto LAB_0077b7bb;
          piVar7 = piVar10;
        } while (0x100 < (int)((int)param_2 - (int)piVar10 & 0xfffffff8U));
      }
      FUN_00774f50(piVar10,param_2,param_2);
    }
LAB_0077b7bb:
    uVar8 = uStack_14;
    FUN_00774bf0(*(undefined4 *)(param_1 + 0x58),*(int *)(param_1 + 0x48),
                 *(int *)(param_1 + 0x48) + uStack_14 * 8,param_2);
    iVar3 = *(int *)(param_1 + 0x48);
    iVar2 = iVar3 + uVar8 * 8;
    if (iVar3 != iVar2) {
      uVar6 = FUN_00775350(iVar2,*(undefined4 *)(param_1 + 0x4c),iVar3);
      FUN_005596d0(uVar6,*(undefined4 *)(param_1 + 0x4c),(int *)(param_1 + 0x48));
      *(undefined4 *)(param_1 + 0x4c) = uVar6;
    }
  }
  FUN_00775ae0(*(int *)(param_1 + 0x54),*(int *)(param_1 + 0x58),
               *(int *)(param_1 + 0x58) - *(int *)(param_1 + 0x54) >> 3,param_2);
  uVar8 = 0;
  if (*(int *)(param_1 + 0x58) - *(int *)(param_1 + 0x54) >> 3 != 0) {
    do {
      FUN_0077ba30(*(undefined4 *)(*(int *)(param_1 + 0x54) + uVar8 * 8));
      uVar8 = uVar8 + 1;
    } while (uVar8 < (uint)(*(int *)(param_1 + 0x58) - *(int *)(param_1 + 0x54) >> 3));
  }
  uStack_8 = 2;
  FUN_0152dda0(uStack_1c,uStack_18,uVar11);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11030 ; VA 0x0077ba30 ; FUN_0077ba30 */

void __thiscall FUN_0077ba30(int param_1,float param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  float fVar7;
  double dVar8;
  int iStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = (int)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af66f;
  pvStack_10 = ExceptionList;
  dVar8 = (double)*(float *)((int)param_2 + 0x40);
  ExceptionList = &pvStack_10;
  FUN_017267a0();
  fVar7 = DAT_018fbb54 - DAT_018ce2f8 / ((float)dVar8 + DAT_018ce2f8);
  if (DAT_01d60cf4 == '\0') {
    param_2 = DAT_018fbb50;
    fVar7 = param_2;
  }
  else if ((DAT_01d60cec != '\0') &&
          (NAN(*(float *)((int)param_2 + 0x40)) != (*(float *)((int)param_2 + 0x40) == 0.0))) {
    param_2 = DAT_018fbb4c;
    fVar7 = param_2;
  }
  param_2 = fVar7;
  if (*(int *)(iVar6 + 0xac) == 0) {
    if (DAT_01eb1b24 != '\0') {
      FUN_01677520(DAT_01eb1b24,"TC Job[%p]: start loading assets (priority %f)",iVar6,
                   (double)param_2);
    }
    iVar3 = FUN_01674e20();
    uStack_8 = 0;
    if (iVar3 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00776d70(*(undefined4 *)(param_1 + 0x30),iVar6 + 0x20,iVar6 + 0x28,param_2,
                           iVar6 + 0x44);
    }
    uStack_8 = 0xffffffff;
    FUN_00775a50(uVar4,param_2);
    *(undefined4 *)(iVar6 + 0xac) = 0;
    piVar2 = *(int **)(iVar6 + 0xb0);
    *(undefined4 *)(iVar6 + 0xb0) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  piVar2 = *(int **)(iVar6 + 0xac);
  iVar5 = 0;
  uStack_18 = 0;
  iVar6 = piVar2[3];
  iVar3 = piVar2[4] - iVar6 >> 0x1f;
  if ((piVar2[4] - iVar6) / 0x60 + iVar3 != iVar3) {
    iStack_1c = 0;
    do {
      iVar6 = iVar6 + iStack_1c;
      if ((DAT_01d80ecc != '\0') &&
         (((DAT_01d60cfc != '\0' ||
           ((NAN(param_2) || NAN(DAT_018fbb4c)) != (param_2 == DAT_018fbb4c))) &&
          (*(int *)(*piVar2 + 0x518) != 0)))) {
        if (DAT_01d62f40 == '\0') {
          FUN_008dac50(iVar6 + 0x18,param_2);
        }
        else {
          fVar7 = param_2;
          uVar4 = FUN_008ccda0();
          FUN_008dab00(iVar6 + 0x18,uVar4,fVar7);
        }
      }
      if (*(int *)(iVar6 + 0x54) == 0) {
        iVar3 = FUN_0077b1c0();
        *(int *)(iVar6 + 0x54) = iVar3;
        if (iVar3 != 0) goto LAB_0077bc58;
      }
      else {
LAB_0077bc58:
        if ((*(int *)(iVar6 + 0x58) == 0) || (*(int *)(*(int *)(iVar6 + 0x58) + 8) != 1)) {
          iVar5 = iVar5 + 1;
        }
      }
      iVar6 = piVar2[3];
      uStack_18 = uStack_18 + 1;
      iStack_1c = iStack_1c + 0x60;
    } while (uStack_18 < (uint)((piVar2[4] - iVar6) / 0x60));
  }
  piVar2[6] = iVar5;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11031 ; VA 0x0077bcc0 ; FUN_0077bcc0 */

void __thiscall FUN_0077bcc0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  undefined auStack_44 [8];
  undefined4 *puStack_3c;
  int iStack_38;
  int iStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017af690;
  pvStack_10 = ExceptionList;
  puStack_3c = (undefined4 *)0x0;
  iStack_38 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  puStack_3c = (undefined4 *)FUN_00601dc0();
  iStack_8 = 0;
  uStack_24 = 0;
  FUN_00587490(&iStack_34);
  iStack_8._0_1_ = 1;
  if ((iStack_34 != 0) && (DAT_01d60cec != '\0')) {
    uStack_24 = FUN_0097bf90(iStack_34 + 0xc);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_30[1] + -1;
    piStack_30[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar4 = piStack_30[2] + -1;
      piStack_30[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  iVar4 = param_2;
  piStack_20 = (int *)**(int **)(param_1 + 0x40);
  if (piStack_20 != *(int **)(param_1 + 0x40)) {
    piStack_18 = piStack_20;
    do {
      piVar8 = piStack_18;
      param_2 = piStack_18[10];
      uStack_28 = 0x7f7fffff;
      piVar7 = *(int **)(param_2 + 0x38);
      piStack_20 = piStack_18;
      puVar5 = (undefined4 *)
               FUN_007761e0(&piStack_30,*(undefined4 *)(param_2 + 0x34),piVar7,&uStack_24,&uStack_28
                            ,iVar4,param_2);
      piStack_1c = (int *)*puVar5;
      if (piStack_1c != piVar7) {
        piVar9 = *(int **)(param_2 + 0x38);
        piStack_2c = piVar9;
        for (; piVar7 != piVar9; piVar7 = piVar7 + 2) {
          iVar1 = *piVar7;
          iVar2 = piVar7[1];
          *piVar7 = 0;
          piVar7[1] = 0;
          *piStack_1c = iVar1;
          piStack_2c = (int *)piStack_1c[1];
          piStack_1c[1] = iVar2;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar1 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_2c + 4))();
            }
          }
          piStack_1c = piStack_1c + 2;
          piVar8 = piStack_18;
        }
        piVar7 = *(int **)(param_2 + 0x38);
        piVar9 = piStack_1c;
        piStack_18 = piVar7;
        if (piStack_1c != piVar7) {
          do {
            piVar3 = (int *)piVar9[1];
            if (piVar3 != (int *)0x0) {
              LOCK();
              iVar1 = piVar3[2] + -1;
              piVar3[2] = iVar1;
              UNLOCK();
              piVar7 = piStack_18;
              if (iVar1 == 0) {
                (**(code **)(*piVar3 + 4))();
                piVar7 = piStack_18;
              }
            }
            piVar9 = piVar9 + 2;
          } while (piVar9 != piVar7);
        }
        *(int **)(param_2 + 0x38) = piStack_1c;
      }
      iVar1 = param_2;
      *(undefined4 *)(param_2 + 0x40) = uStack_28;
      if ((*(int *)(param_2 + 0xa8) == 0) || (*(int *)(*(int *)(param_2 + 0xa8) + 4) != 1)) {
        FUN_00551320();
        param_1 = iStack_14;
      }
      else {
        if (DAT_01eb1b24 != '\0') {
          FUN_016774b0(DAT_01eb1b24,"TC Job[%p]: orphaning job (no materials)",param_2);
        }
        *(undefined4 *)(iVar1 + 0xa4) = 0;
        piStack_2c = *(int **)(iVar1 + 0xa8);
        *(undefined4 *)(iVar1 + 0xa8) = 0;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar2 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            iVar2 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
        *(undefined4 *)(iVar1 + 0xac) = 0;
        piStack_2c = *(int **)(iVar1 + 0xb0);
        *(undefined4 *)(iVar1 + 0xb0) = 0;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar2 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            iVar2 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
        piVar7 = *(int **)(iVar1 + 0x38);
        piVar9 = *(int **)(iVar1 + 0x34);
        piStack_1c = piVar7;
        if (piVar9 != piVar7) {
          do {
            piVar3 = (int *)piVar9[1];
            if (piVar3 != (int *)0x0) {
              LOCK();
              iVar1 = piVar3[2] + -1;
              piVar3[2] = iVar1;
              UNLOCK();
              piVar7 = piStack_1c;
              if (iVar1 == 0) {
                (**(code **)(*piVar3 + 4))();
                piVar7 = piStack_1c;
              }
            }
            piVar9 = piVar9 + 2;
          } while (piVar9 != piVar7);
          piVar9 = *(int **)(param_2 + 0x34);
        }
        *(int **)(param_2 + 0x38) = piVar9;
        FUN_00774a90(auStack_44,0,piVar8 + 10,param_2);
        FUN_00551320();
        param_1 = iStack_14;
        uVar6 = FUN_00553830(piVar8);
        FUN_0056cac0();
        FUN_01674ea0(uVar6,0x30);
      }
      piStack_18 = piStack_20;
    } while (piStack_20 != *(int **)(param_1 + 0x40));
  }
  piStack_18 = piStack_20;
  if (iStack_38 != 0) {
    FUN_00774d70(*(undefined4 *)(param_1 + 100),*puStack_3c,puStack_3c,param_2);
    iVar4 = *(int *)(iStack_14 + 0x4c);
    piVar7 = (int *)FUN_00775ff0(&param_2,*(undefined4 *)(param_1 + 0x48),iVar4,&puStack_3c);
    if (*piVar7 != iVar4) {
      uVar6 = FUN_00775350(iVar4,*(undefined4 *)(param_1 + 0x4c),*piVar7);
      FUN_005596d0(uVar6,*(undefined4 *)(param_1 + 0x4c),(undefined4 *)(param_1 + 0x48));
      *(undefined4 *)(param_1 + 0x4c) = uVar6;
    }
    iVar1 = iStack_14;
    puVar5 = (undefined4 *)(iStack_14 + 0x54);
    iVar4 = *(int *)(iStack_14 + 0x58);
    piVar7 = (int *)FUN_00775ff0(&param_2,*puVar5,iVar4,&puStack_3c);
    if (*piVar7 != iVar4) {
      uVar6 = FUN_00775350(iVar4,*(undefined4 *)(iVar1 + 0x58),*piVar7);
      FUN_005596d0(uVar6,*(undefined4 *)(iVar1 + 0x58),puVar5);
      *(undefined4 *)(iVar1 + 0x58) = uVar6;
    }
  }
  puVar5 = puStack_3c;
  iStack_8 = 2;
  FUN_00777e50(puStack_3c[1]);
  puStack_3c[1] = puVar5;
  *puStack_3c = puVar5;
  puStack_3c[2] = puVar5;
  iStack_38 = 0;
  FUN_01674ea0(puStack_3c,0x18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11032 ; VA 0x0077c0a0 ; FUN_0077c0a0 */

undefined4 * __thiscall FUN_0077c0a0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined **ppuVar5;
  int *in_stack_00000098;
  undefined4 auStack_1ec [37];
  undefined4 uStack_158;
  undefined4 *puStack_154;
  undefined auStack_13c [140];
  int *piStack_b0;
  undefined4 uStack_ac;
  undefined auStack_a4 [140];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af6be;
  pvStack_10 = ExceptionList;
  puStack_154 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  uStack_158 = 0x77c0e5;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0077d630();
  uStack_ac = param_2;
  puStack_154 = (undefined4 *)auStack_13c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  uStack_158 = 0x77c10d;
  FUN_0077d630();
  puStack_154 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = auStack_1ec;
  auStack_1ec[0] = uStack_ac;
  FUN_0077d630(auStack_a4);
  ppuVar5 = &PTR_FUN_018fc594;
  cVar4 = FUN_0077c8d0();
  if (cVar4 == '\0') {
    ppuVar5 = (undefined **)0x0;
  }
  *param_1 = ppuVar5;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_154 = (undefined4 *)0x77c165;
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_154 = (undefined4 *)0x77c175;
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  puStack_154 = (undefined4 *)0x77c17d;
  FUN_00637950();
  puStack_154 = (undefined4 *)0x77c188;
  FUN_0077f390();
  if (piStack_b0 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_b0[1] + -1;
    piStack_b0[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_154 = (undefined4 *)0x77c1a1;
      (**(code **)*piStack_b0)();
      LOCK();
      iVar2 = piStack_b0[2] + -1;
      piStack_b0[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_154 = (undefined4 *)0x77c1b1;
        (**(code **)(*piStack_b0 + 4))();
      }
    }
  }
  puStack_154 = (undefined4 *)0x77c1bc;
  FUN_00637950();
  puStack_154 = (undefined4 *)0x77c1c7;
  FUN_0077f390();
  piVar3 = in_stack_00000098;
  if (in_stack_00000098 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000098[1] + -1;
    in_stack_00000098[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_154 = (undefined4 *)0x77c1e0;
      (**(code **)*in_stack_00000098)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_154 = (undefined4 *)0x77c1ef;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  puStack_154 = (undefined4 *)0x77c1f7;
  FUN_00637950();
  puStack_154 = (undefined4 *)0x77c1ff;
  FUN_0077f390();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11033 ; VA 0x0077c220 ; FUN_0077c220 */

int FUN_0077c220(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af6d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00616d10(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  *(undefined *)(iVar1 + 0x20) = *(undefined *)(param_3 + 0x18);
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 11034 ; VA 0x0077c282 ; Catch_All@0077c282 */

void Catch_All_0077c282(void)

{
  int unaff_EBP;
  
  FUN_00781060(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11035 ; VA 0x0077c2a0 ; FUN_0077c2a0 */

int __thiscall FUN_0077c2a0(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar5 = *param_1;
  iVar2 = (int)(param_1[1] - uVar5) >> 3;
  if (iVar2 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar4 = (int)(param_1[2] - uVar5) >> 3;
  uVar7 = uVar1;
  if ((uVar4 <= 0x1fffffff - (uVar4 >> 1)) && (uVar7 = (uVar4 >> 1) + uVar4, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar4 = uVar7 * 8;
  if (uVar7 < 0x20000000) {
    uVar7 = uVar4;
    if (0xfff < uVar4) goto LAB_0077c30f;
    if (uVar4 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_0077c30f:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar3);
    if (iVar2 == 0) goto LAB_0077c417;
    uVar7 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar2;
  }
  iVar2 = ((int)(param_2 - uVar5) >> 3) * 8;
  *(undefined4 *)(iVar2 + uVar7) = 0;
  *(undefined4 *)(iVar2 + 4 + uVar7) = 0;
  *(undefined4 *)(iVar2 + uVar7) = *param_3;
  *(undefined4 *)(iVar2 + 4 + uVar7) = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  uVar5 = *param_1;
  uVar3 = param_1[1];
  uVar6 = uVar7;
  if (param_2 != uVar3) {
    FUN_005c23f0(uVar5,param_2,uVar7,param_1);
    uVar3 = param_1[1];
    uVar6 = iVar2 + 8 + uVar7;
    uVar5 = param_2;
  }
  FUN_005c23f0(uVar5,uVar3,uVar6,param_1);
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    uVar5 = *param_1;
    uVar6 = param_1[2] - uVar5 & 0xfffffff8;
    uVar3 = uVar5;
    if (0xfff < uVar6) {
      uVar3 = *(uint *)(uVar5 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar5 - uVar3) - 4) {
LAB_0077c417:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + uVar1 * 8;
  param_1[2] = uVar4 + uVar7;
  return *param_1 + iVar2;
}



/* FUNCTION 11036 ; VA 0x0077c430 ; FUN_0077c430 */

void __thiscall FUN_0077c430(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  char cVar6;
  uint uVar7;
  undefined4 uVar8;
  int *piVar9;
  int *piVar10;
  int iVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af6e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar7 = FUN_009cc8a0(param_3);
  iVar11 = *(int *)(param_1 + 4);
  iVar1 = (*(uint *)(param_1 + 0x18) &
          (uVar7 ^ uVar7 * 0x40 + (uint)*(byte *)(param_3 + 0x18) + (uVar7 >> 2) + 0x9e3779b9)) * 8;
  if (*(int *)(iVar1 + *(int *)(param_1 + 0xc)) != iVar11) {
    iVar11 = **(int **)(iVar1 + 4 + *(int *)(param_1 + 0xc));
  }
  do {
    if (iVar11 == *(int *)(iVar1 + *(int *)(param_1 + 0xc))) {
      uStack_8 = 0xffffffff;
      iVar2 = **(int **)(param_1 + 4);
      puVar3 = *(undefined4 **)(iVar2 + 4);
      uVar8 = FUN_0077c220(iVar2,puVar3,param_3);
      if (*(int *)(param_1 + 8) == 0x71c71c6) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      *(undefined4 *)(iVar2 + 4) = uVar8;
      *puVar3 = uVar8;
      piVar10 = *(int **)(param_1 + 4);
      piVar4 = (int *)*piVar10;
      iVar2 = *piVar4;
      if (iVar11 != iVar2) {
        *(int *)piVar4[1] = iVar2;
        **(int **)(iVar2 + 4) = iVar11;
        **(int **)(iVar11 + 4) = (int)piVar4;
        iVar5 = *(int *)(iVar11 + 4);
        *(undefined4 *)(iVar11 + 4) = *(undefined4 *)(iVar2 + 4);
        *(int *)(iVar2 + 4) = piVar4[1];
        piVar4[1] = iVar5;
        piVar10 = *(int **)(param_1 + 4);
      }
      piVar9 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
      if ((int *)*piVar9 == piVar10) {
        *piVar9 = (int)piVar4;
        *(int **)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = piVar4;
      }
      else if (*piVar9 == iVar11) {
        *piVar9 = (int)piVar4;
      }
      else {
        piVar10 = *(int **)piVar9[1];
        piVar9[1] = (int)piVar10;
        if (piVar10 != piVar4) {
          *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar1) =
               *(undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 4 + iVar1) + 4);
        }
      }
      uStack_8 = 2;
      FUN_00780560();
      *param_2 = (int)piVar4;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    iVar11 = *(int *)(iVar11 + 4);
    cVar6 = FUN_009cbaa0(param_3,iVar11 + 8);
  } while ((cVar6 == '\0') || (*(char *)(param_3 + 0x18) != *(char *)(iVar11 + 0x20)));
  *param_2 = iVar11;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11037 ; VA 0x0077c5cb ; Catch_All@0077c5cb */

void Catch_All_0077c5cb(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 0xc,*(undefined4 *)(unaff_EBP + -0x18));
  FUN_007810a0(unaff_EBP + 8,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11038 ; VA 0x0077c5e8 ; Catch_All@0077c5e8 */

void Catch_All_0077c5e8(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11039 ; VA 0x0077c600 ; FUN_0077c600 */

void __thiscall FUN_0077c600(int param_1,int *param_2,int param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af6f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_009cc8a0(param_3);
  iVar7 = *(int *)(param_1 + 4);
  iVar1 = (*(uint *)(param_1 + 0x18) &
          (uVar5 ^ uVar5 * 0x40 + *(byte *)(param_3 + 0x18) + 0x9e3779b9 + (uVar5 >> 2))) * 8;
  if (*(int *)(*(int *)(param_1 + 0xc) + iVar1) != iVar7) {
    iVar7 = **(int **)(*(int *)(param_1 + 0xc) + 4 + iVar1);
  }
  do {
    iVar6 = *(int *)(param_1 + 0xc);
    if (iVar7 == *(int *)(iVar6 + iVar1)) {
      iVar2 = *param_4;
      if (iVar7 != iVar2) {
        *(int *)param_4[1] = iVar2;
        **(int **)(iVar2 + 4) = iVar7;
        **(undefined4 **)(iVar7 + 4) = param_4;
        iVar6 = *(int *)(iVar7 + 4);
        *(undefined4 *)(iVar7 + 4) = *(undefined4 *)(iVar2 + 4);
        *(int *)(iVar2 + 4) = param_4[1];
        param_4[1] = iVar6;
        iVar6 = *(int *)(param_1 + 0xc);
      }
      if (*(int *)(iVar6 + iVar1) == *(int *)(param_1 + 4)) {
        *(int **)(iVar6 + iVar1) = param_4;
        *(int **)(*(int *)(param_1 + 0xc) + 4 + iVar1) = param_4;
      }
      else if (*(int *)(iVar6 + iVar1) == iVar7) {
        *(int **)(iVar6 + iVar1) = param_4;
      }
      else {
        piVar3 = (int *)**(undefined4 **)(iVar6 + 4 + iVar1);
        *(int **)(iVar6 + 4 + iVar1) = piVar3;
        if (piVar3 != param_4) {
          *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar1) =
               *(undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 4 + iVar1) + 4);
        }
      }
      uStack_8 = 2;
      FUN_00780560();
      *param_2 = (int)param_4;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    iVar7 = *(int *)(iVar7 + 4);
    cVar4 = FUN_009cbaa0(param_3,iVar7 + 8);
  } while ((cVar4 == '\0') || (*(char *)(param_3 + 0x18) != *(char *)(iVar7 + 0x20)));
  *(int *)param_4[1] = *param_4;
  *(int *)(*param_4 + 4) = param_4[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00780650(param_4);
  *param_2 = iVar7;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11040 ; VA 0x0077c76f ; Catch_All@0077c76f */

void Catch_All_0077c76f(void)

{
  int unaff_EBP;
  
  FUN_00780620(*(undefined4 *)(unaff_EBP + 0x10));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11041 ; VA 0x0077c783 ; Catch_All@0077c783 */

void Catch_All_0077c783(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 0xc,*(undefined4 *)(unaff_EBP + 0xc));
  FUN_007810a0(unaff_EBP + 8,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11042 ; VA 0x0077c7b0 ; FUN_0077c7b0 */

void __thiscall FUN_0077c7b0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af700;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count<class_rbx::safe_queue<struct_RBX::Graphics::TextureManager::LoadedImage>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11043 ; VA 0x0077c81e ; Catch_All@0077c81e */

void Catch_All_0077c81e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00780530(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11044 ; VA 0x0077c840 ; FUN_0077c840 */

void __thiscall FUN_0077c840(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af710;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::ThreadPool>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11045 ; VA 0x0077c8ae ; Catch_All@0077c8ae */

void Catch_All_0077c8ae(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11046 ; VA 0x0077c8d0 ; FUN_0077c8d0 */

undefined FUN_0077c8d0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined uVar7;
  int *in_stack_00000098;
  int *in_stack_0000009c;
  undefined auStack_13c [140];
  int *piStack_b0;
  undefined4 auStack_ac [2];
  undefined auStack_a4 [140];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af750;
  pvStack_10 = ExceptionList;
  auStack_ac[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0077d630(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar5 = FUN_00585a40(auStack_ac);
  uVar4 = auStack_ac[0];
  if (cVar5 == '\0') {
    FUN_0077d630(auStack_a4);
    uStack_8._0_1_ = 2;
    puVar6 = (undefined4 *)FUN_01674e20(0x98);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar6;
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = uVar4;
      FUN_0077d630(auStack_13c);
    }
    *in_stack_0000009c = (int)puVar6;
    if (piStack_b0 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_b0[1] + -1;
      piStack_b0[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_b0)();
        LOCK();
        iVar2 = piStack_b0[2] + -1;
        piStack_b0[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_b0 + 4))();
        }
      }
    }
    FUN_00637950();
    FUN_0077f390();
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar2 = piStack_18[2] + -1;
        piStack_18[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    FUN_00637950();
    FUN_0077f390();
    uVar7 = 1;
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar2 = piStack_18[2] + -1;
        piStack_18[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    FUN_00637950();
    FUN_0077f390();
    uVar7 = 0;
  }
  piVar3 = in_stack_00000098;
  if (in_stack_00000098 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000098[1] + -1;
    in_stack_00000098[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000098)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00637950();
  FUN_0077f390();
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 11047 ; VA 0x0077caa0 ; FUN_0077caa0 */

undefined4 *
FUN_0077caa0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,uint param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  undefined4 in_stack_00000028;
  uint in_stack_0000002c;
  undefined in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined *in_stack_0000003c;
  undefined4 in_stack_00000088;
  undefined4 in_stack_0000008c;
  undefined4 in_stack_00000090;
  undefined4 in_stack_00000094;
  int *in_stack_00000098;
  undefined auStack_13c [24];
  undefined uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined *puStack_118;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  uint uStack_c0;
  int *piStack_bc;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017af7b1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000098 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000098[1] = in_stack_00000098[1] + 1;
    UNLOCK();
  }
  uStack_c0 = in_stack_00000094;
  piStack_bc = in_stack_00000098;
  uStack_8 = 4;
  uStack_7 = 0;
  uStack_c8 = in_stack_0000008c;
  uStack_c4 = in_stack_00000090;
  puStack_118 = &stack0x00000040;
  uStack_11c = 0x77cb2f;
  FUN_0054ef60();
  puStack_118 = &stack0x00000058;
  uStack_8 = 5;
  uStack_11c = 0x77cb3f;
  FUN_0054ef60();
  puStack_118 = &stack0x00000070;
  uStack_8 = 6;
  uStack_11c = 0x77cb4f;
  FUN_0054ef60();
  uStack_cc = in_stack_00000088;
  uStack_8 = 7;
  puStack_118 = in_stack_0000003c;
  in_stack_0000003c = auStack_13c;
  uStack_120 = in_stack_00000034;
  uStack_11c = in_stack_00000038;
  FUN_0054ef60(&param_6);
  uStack_124 = in_stack_00000030;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 3;
  piStack_bc = (int *)FUN_0077d710(param_3,param_4,param_5);
  _uStack_8 = CONCAT31(uStack_7,8);
  *param_1 = param_2;
  uStack_c0 = 0x77cbe1;
  FUN_0077d630();
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_bc = (int *)0x77cbfa;
      (**(code **)*piStack_20)();
      LOCK();
      iVar2 = piStack_20[2] + -1;
      piStack_20[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_bc = (int *)0x77cc0a;
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  piStack_bc = (int *)0x77cc12;
  FUN_00637950();
  piStack_bc = (int *)0x77cc1d;
  FUN_0077f390();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_bc = (int *)0x77cc33;
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_bc = (int *)0x77cc43;
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000002c) {
    piStack_bc = (int *)(in_stack_0000002c + 1);
    uVar4 = param_6;
    if (0xfff < piStack_bc) {
      uVar4 = *(uint *)(param_6 - 4);
      piStack_bc = (int *)(in_stack_0000002c + 0x24);
      if (0x1f < (param_6 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_bc = (int *)&UNK_0077cccd;
        FUN_017167a3();
      }
    }
    uStack_c4 = 0x77cc70;
    uStack_c0 = uVar4;
    FUN_01674ea0();
  }
  in_stack_00000028 = 0;
  in_stack_0000002c = 0xf;
  param_6 = param_6 & 0xffffff00;
  piStack_bc = (int *)0x77cc8d;
  FUN_00637950();
  piVar3 = in_stack_00000098;
  if (in_stack_00000098 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000098[1] + -1;
    in_stack_00000098[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_bc = (int *)0x77cca6;
      (**(code **)*in_stack_00000098)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_bc = (int *)0x77ccb5;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11048 ; VA 0x0077ccd0 ; FUN_0077ccd0 */

undefined4 *
FUN_0077ccd0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,uint param_6)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_stack_00000028;
  uint in_stack_0000002c;
  undefined in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined *in_stack_00000040;
  undefined4 in_stack_0000008c;
  undefined4 in_stack_00000090;
  undefined4 in_stack_00000094;
  undefined auStack_134 [24];
  undefined uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined *puStack_10c;
  undefined4 uStack_c0;
  uint uStack_bc;
  undefined *puStack_b8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af7fe;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_bc = in_stack_00000090;
  puStack_b8 = (undefined *)in_stack_00000094;
  puStack_10c = &stack0x00000044;
  uStack_110 = 0x77cd27;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  puStack_10c = &stack0x0000005c;
  uStack_8._0_1_ = 3;
  uStack_110 = 0x77cd37;
  FUN_0054ef60();
  puStack_10c = &stack0x00000074;
  uStack_8._0_1_ = 4;
  uStack_110 = 0x77cd47;
  FUN_0054ef60();
  uStack_c0 = in_stack_0000008c;
  uStack_8._0_1_ = 5;
  puStack_10c = in_stack_00000040;
  uStack_110 = in_stack_0000003c;
  in_stack_00000040 = auStack_134;
  uStack_118 = in_stack_00000034;
  uStack_114 = in_stack_00000038;
  FUN_0054ef60(&param_6);
  uStack_11c = in_stack_00000030;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  puStack_b8 = (undefined *)FUN_0077d4c0(param_3,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  *param_1 = param_2;
  uStack_bc = 0x77cde5;
  FUN_0077d420();
  puStack_b8 = (undefined *)0x77cded;
  FUN_00637950();
  puStack_b8 = (undefined *)0x77cdf8;
  FUN_0077f390();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_b8 = (undefined *)0x77ce11;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_b8 = (undefined *)0x77ce20;
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000002c) {
    puStack_b8 = (undefined *)(in_stack_0000002c + 1);
    uVar3 = param_6;
    if (0xfff < puStack_b8) {
      uVar3 = *(uint *)(param_6 - 4);
      puStack_b8 = (undefined *)(in_stack_0000002c + 0x24);
      if (0x1f < (param_6 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_b8 = &UNK_0077ce82;
        FUN_017167a3();
      }
    }
    uStack_c0 = 0x77ce4d;
    uStack_bc = uVar3;
    FUN_01674ea0();
  }
  in_stack_00000028 = 0;
  in_stack_0000002c = 0xf;
  param_6 = param_6 & 0xffffff00;
  puStack_b8 = (undefined *)0x77ce6a;
  FUN_00637950();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11049 ; VA 0x0077ce90 ; FUN_0077ce90 */

void FUN_0077ce90(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_2[0x12];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00577ac0();
  uVar3 = param_2[0xc];
  if (0xf < uVar3) {
    iVar4 = param_2[7];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0077cf50;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_2[0xb] = 0;
  param_2[0xc] = 0xf;
  *(undefined *)(param_2 + 7) = 0;
  uVar3 = param_2[5];
  if (0xf < uVar3) {
    iVar4 = *param_2;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_0077cf50:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 11050 ; VA 0x0077cf60 ; FUN_0077cf60 */

void __thiscall FUN_0077cf60(int param_1,undefined4 *param_2,uint param_3,int param_4)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar1;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          cVar2 = FUN_009cbaa0(param_4,piVar4 + 2);
          if ((cVar2 != '\0') && (*(char *)(param_4 + 0x18) == *(char *)(piVar4 + 8))) break;
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 11051 ; VA 0x0077d000 ; FUN_0077d000 */

undefined4 * __thiscall FUN_0077d000(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af836;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  param_1[2] = param_2[2];
  FUN_0054ef60(param_2 + 3);
  *(undefined *)(param_1 + 9) = *(undefined *)(param_2 + 9);
  uStack_8._0_1_ = 1;
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  FUN_0054ef60(param_2 + 0xd);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(param_2 + 0x13);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_2 + 0x19);
  param_1[0x1f] = param_2[0x1f];
  param_1[0x20] = param_2[0x20];
  param_1[0x21] = param_2[0x21];
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  if (param_2[0x23] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x23] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x22] = param_2[0x22];
  param_1[0x23] = param_2[0x23];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11052 ; VA 0x0077d130 ; FUN_0077d130 */

undefined4 * __thiscall FUN_0077d130(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af836;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  param_1[2] = param_2[2];
  FUN_0054ef60(param_2 + 3);
  *(undefined *)(param_1 + 9) = *(undefined *)(param_2 + 9);
  uStack_8._0_1_ = 1;
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  FUN_0054ef60(param_2 + 0xe);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(param_2 + 0x14);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_2 + 0x1a);
  param_1[0x20] = param_2[0x20];
  param_1[0x22] = param_2[0x22];
  param_1[0x23] = param_2[0x23];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11053 ; VA 0x0077d220 ; FUN_0077d220 */

undefined4 * __thiscall FUN_0077d220(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af836;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  param_1[2] = param_2[2];
  FUN_0054ef60(param_2 + 3);
  *(undefined *)(param_1 + 9) = *(undefined *)(param_2 + 9);
  uStack_8._0_1_ = 1;
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  FUN_0054ef60(param_2 + 0xd);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(param_2 + 0x13);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_2 + 0x19);
  param_1[0x1f] = param_2[0x1f];
  param_1[0x20] = param_2[0x20];
  param_1[0x21] = param_2[0x21];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11054 ; VA 0x0077d310 ; FUN_0077d310 */

undefined4 * __thiscall FUN_0077d310(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017af871;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  uStack_8 = 1;
  uStack_7 = 0;
  param_1[4] = param_2[4];
  FUN_0054ef60(param_2 + 5);
  *(undefined *)(param_1 + 0xb) = *(undefined *)(param_2 + 0xb);
  uStack_8 = 2;
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  param_1[0xe] = param_2[0xe];
  FUN_0054ef60(param_2 + 0xf);
  uStack_8 = 3;
  FUN_0054ef60(param_2 + 0x15);
  _uStack_8 = CONCAT31(uStack_7,4);
  FUN_0054ef60(param_2 + 0x1b);
  param_1[0x21] = param_2[0x21];
  param_1[0x22] = param_2[0x22];
  param_1[0x23] = param_2[0x23];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11055 ; VA 0x0077d420 ; FUN_0077d420 */

int __thiscall FUN_0077d420(int param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af89b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0077da20(param_2);
  *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_2 + 0x34);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x38);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2 + 0x50);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_2 + 0x68);
  *(undefined4 *)(param_1 + 0x80) = *(undefined4 *)(param_2 + 0x80);
  *(undefined4 *)(param_1 + 0x88) = *(undefined4 *)(param_2 + 0x88);
  *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(param_2 + 0x8c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11056 ; VA 0x0077d4c0 ; FUN_0077d4c0 */

undefined4 __thiscall
FUN_0077d4c0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_00000084;
  undefined4 in_stack_00000088;
  undefined4 in_stack_0000008c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af8e3;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0077e0d0(param_2,param_3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    if (0xfff < in_stack_00000024 + 1) {
      if (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  FUN_00637950();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11057 ; VA 0x0077d630 ; FUN_0077d630 */

int __thiscall FUN_0077d630(int param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af90b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0077da20(param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x34);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2 + 0x4c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_2 + 100);
  *(undefined4 *)(param_1 + 0x7c) = *(undefined4 *)(param_2 + 0x7c);
  *(undefined4 *)(param_1 + 0x80) = *(undefined4 *)(param_2 + 0x80);
  *(undefined4 *)(param_1 + 0x84) = *(undefined4 *)(param_2 + 0x84);
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0;
  if (*(int *)(param_2 + 0x8c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x8c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x88) = *(undefined4 *)(param_2 + 0x88);
  *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(param_2 + 0x8c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11058 ; VA 0x0077d710 ; FUN_0077d710 */

undefined4 __thiscall
FUN_0077d710(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000080;
  undefined4 in_stack_00000084;
  undefined4 in_stack_00000088;
  undefined4 in_stack_0000008c;
  int *in_stack_00000090;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017af966;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000090 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000090[1] = in_stack_00000090[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  uStack_7 = 0;
  FUN_0054ef60();
  uStack_8 = 5;
  FUN_0054ef60();
  uStack_8 = 6;
  FUN_0054ef60();
  uStack_8 = 7;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_0077e240(param_2,param_3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    if (0xfff < in_stack_00000024 + 1) {
      if (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  FUN_00637950();
  piVar3 = in_stack_00000090;
  if (in_stack_00000090 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000090[1] + -1;
    in_stack_00000090[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000090)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11059 ; VA 0x0077d8e0 ; FUN_0077d8e0 */

undefined4 * __thiscall
FUN_0077d8e0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000024;
  undefined in_stack_00000028;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af988;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 1;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  param_1[2] = param_4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(&param_5);
  *(undefined *)(param_1 + 9) = in_stack_00000028;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar3 = in_stack_00000024 + 1;
    iVar2 = param_5;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_5 + -4);
      uVar3 = in_stack_00000024 + 0x24;
      if (0x1f < (param_5 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11060 ; VA 0x0077da20 ; FUN_0077da20 */

undefined4 * __thiscall FUN_0077da20(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af9a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 3);
  *(undefined *)(param_1 + 9) = *(undefined *)(param_2 + 9);
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11061 ; VA 0x0077dab0 ; FUN_0077dab0 */

int __thiscall
FUN_0077dab0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint in_stack_00000024;
  undefined in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  int iStack_54;
  undefined4 *puStack_50;
  int aiStack_40 [5];
  uint uStack_2c;
  undefined uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af9e0;
  pvStack_10 = ExceptionList;
  puStack_50 = &param_5;
  uStack_8 = 1;
  iStack_54 = 0x77dae6;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_0054ef60();
  uStack_28 = in_stack_00000028;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  uStack_24 = param_2;
  piStack_20 = param_3;
  puStack_1c = auStack_68;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(aiStack_40);
  puStack_50 = (undefined4 *)CONCAT31(puStack_50._1_3_,uStack_28);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0077d8e0(uStack_14,param_3,param_4);
  *(undefined4 *)(param_1 + 0x28) = in_stack_0000002c;
  *(undefined4 *)(param_1 + 0x2c) = in_stack_00000030;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_50 = (undefined4 *)0x77db71;
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_50 = (undefined4 *)0x77db81;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < uStack_2c) {
    puStack_50 = (undefined4 *)(uStack_2c + 1);
    iVar2 = aiStack_40[0];
    if (0xfff < puStack_50) {
      iVar2 = *(int *)(aiStack_40[0] + -4);
      puStack_50 = (undefined4 *)(uStack_2c + 0x24);
      if (0x1f < (aiStack_40[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_50 = (undefined4 *)0x77dc29;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x77dbae;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  iVar2 = iStack_18;
  *(undefined4 *)(iStack_18 + 0x30) = in_stack_00000034;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_50 = (undefined4 *)0x77dbd0;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_50 = (undefined4 *)0x77dbdf;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    puStack_50 = (undefined4 *)(in_stack_00000024 + 1);
    iVar3 = param_5;
    if (0xfff < puStack_50) {
      iVar3 = *(int *)(param_5 + -4);
      puStack_50 = (undefined4 *)(in_stack_00000024 + 0x24);
      if (0x1f < (param_5 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_50 = (undefined4 *)&UNK_0077dc2e;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x77dc0c;
    iStack_54 = iVar3;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 11062 ; VA 0x0077dc30 ; FUN_0077dc30 */

int __thiscall
FUN_0077dc30(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000080;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017afa23;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0077dab0(param_2,param_3,param_4);
  uStack_8._0_1_ = 3;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  FUN_0054ef60();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0054ef60();
  *(undefined4 *)(param_1 + 0x7c) = in_stack_00000080;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    if (0xfff < in_stack_00000024 + 1) {
      if (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  FUN_00637950();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11063 ; VA 0x0077dd80 ; FUN_0077dd80 */

int __thiscall
FUN_0077dd80(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_00000084;
  undefined auStack_74 [24];
  undefined uStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 *puStack_50;
  int aiStack_40 [5];
  uint uStack_2c;
  undefined uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017afa73;
  pvStack_10 = ExceptionList;
  puStack_50 = &param_5;
  uStack_8 = 2;
  uStack_54 = 0x77ddb6;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_0054ef60();
  uStack_28 = in_stack_00000028;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  uStack_24 = param_2;
  piStack_20 = param_3;
  puStack_50 = (undefined4 *)in_stack_00000034;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_54 = in_stack_00000030;
  uStack_58 = in_stack_0000002c;
  puStack_1c = auStack_74;
  FUN_0054ef60(aiStack_40);
  uStack_5c = uStack_28;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0077dab0(uStack_14,param_3,param_4);
  *(undefined4 *)(param_1 + 0x34) = in_stack_00000038;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_50 = (undefined4 *)0x77de44;
      (**(code **)*param_3)();
      LOCK();
      iVar3 = param_3[2] + -1;
      param_3[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        puStack_50 = (undefined4 *)0x77de54;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 2;
  if (0xf < uStack_2c) {
    puStack_50 = (undefined4 *)(uStack_2c + 1);
    iVar3 = aiStack_40[0];
    if (0xfff < puStack_50) {
      iVar3 = *(int *)(aiStack_40[0] + -4);
      puStack_50 = (undefined4 *)(uStack_2c + 0x24);
      if (0x1f < (aiStack_40[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_50 = (undefined4 *)0x77df56;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x77de89;
    uStack_54 = iVar3;
    FUN_01674ea0();
  }
  iVar3 = iStack_18;
  puStack_50 = (undefined4 *)&stack0x0000003c;
  uStack_8._0_1_ = 5;
  puStack_1c = (undefined *)(iStack_18 + 0x38);
  uStack_54 = 0x77dea4;
  FUN_0054ef60();
  puStack_50 = (undefined4 *)&stack0x00000054;
  uStack_8._0_1_ = 6;
  uStack_54 = 0x77deb4;
  FUN_0054ef60();
  puStack_50 = (undefined4 *)&stack0x0000006c;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uStack_54 = 0x77dec4;
  FUN_0054ef60();
  *(undefined4 *)(iVar3 + 0x80) = in_stack_00000084;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_50 = (undefined4 *)0x77dee3;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_50 = (undefined4 *)0x77def2;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    puStack_50 = (undefined4 *)(in_stack_00000024 + 1);
    uVar4 = param_5;
    if (0xfff < puStack_50) {
      uVar4 = *(uint *)(param_5 - 4);
      puStack_50 = (undefined4 *)(in_stack_00000024 + 0x24);
      if (0x1f < (param_5 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_50 = (undefined4 *)&UNK_0077df5b;
        FUN_017167a3();
      }
    }
    uStack_58 = 0x77df1f;
    uStack_54 = uVar4;
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  puStack_50 = (undefined4 *)0x77df3c;
  FUN_00637950();
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 11064 ; VA 0x0077df60 ; FUN_0077df60 */

int __thiscall
FUN_0077df60(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000080;
  undefined4 in_stack_00000084;
  undefined4 in_stack_00000088;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017afab3;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0077dc30(param_2,param_3,param_4);
  *(undefined4 *)(param_1 + 0x80) = in_stack_00000084;
  *(undefined4 *)(param_1 + 0x84) = in_stack_00000088;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    if (0xfff < in_stack_00000024 + 1) {
      if (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  FUN_00637950();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11065 ; VA 0x0077e0d0 ; FUN_0077e0d0 */

int __thiscall
FUN_0077e0d0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_00000084;
  undefined4 in_stack_00000088;
  undefined4 in_stack_0000008c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af8e3;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0077dd80(param_2,param_3,param_4);
  *(undefined4 *)(param_1 + 0x88) = in_stack_00000088;
  *(undefined4 *)(param_1 + 0x8c) = in_stack_0000008c;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    if (0xfff < in_stack_00000024 + 1) {
      if (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  FUN_00637950();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11066 ; VA 0x0077e240 ; FUN_0077e240 */

int __thiscall
FUN_0077e240(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000080;
  undefined4 in_stack_00000084;
  undefined4 in_stack_00000088;
  undefined4 in_stack_0000008c;
  int *in_stack_00000090;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017afafe;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  FUN_0054ef60();
  uStack_8._0_1_ = 6;
  FUN_0054ef60(&param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0077df60(param_2,param_3,param_4);
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0;
  if (in_stack_00000090 != (int *)0x0) {
    LOCK();
    in_stack_00000090[1] = in_stack_00000090[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x88) = in_stack_0000008c;
  *(int **)(param_1 + 0x8c) = in_stack_00000090;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    if (0xfff < in_stack_00000024 + 1) {
      if (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  FUN_00637950();
  piVar3 = in_stack_00000090;
  if (in_stack_00000090 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000090[1] + -1;
    in_stack_00000090[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000090)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11067 ; VA 0x0077e410 ; FUN_0077e410 */

int * __thiscall FUN_0077e410(int *param_1,int param_2)

{
  int iVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int *piVar7;
  uint uVar8;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017afba5;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = 0;
  piStack_14 = param_1;
  iVar3 = FUN_00588320(0xb);
  param_1[2] = iVar3;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  uStack_8 = 0;
  FUN_016f4053(param_1 + 7,8,0xd,FUN_005502b0,FUN_00550b30);
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  piVar7 = param_1 + 0x25;
  uStack_8._0_1_ = 3;
  *piVar7 = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  piStack_18 = piVar7;
  iVar3 = FUN_00616d10(0,0);
  param_1[0x26] = iVar3;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  uStack_8._0_1_ = 5;
  *piVar7 = 0x3f800000;
  FUN_005cb500(8);
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0xf;
  *(undefined *)(param_1 + 0x36) = 0;
  *(undefined *)(param_1 + 0x3c) = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  uStack_8._0_1_ = 7;
  uVar4 = FUN_01675290(DAT_01eb1bf4);
  uStack_8._0_1_ = 8;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  uStack_1c = uVar4;
  if (DAT_01d60d74 == '\0') {
    piStack_18 = (int *)FUN_01674e20(0x24);
    uStack_8._0_1_ = 9;
    if (piStack_18 == (int *)0x0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_0153b6a0("TextureManager",1,0,0);
    }
    uStack_8._0_1_ = 8;
    iStack_24 = 0;
    piStack_20 = (int *)0x0;
    FUN_0077c840(uVar5,param_2);
    piStack_14[0x23] = iStack_24;
    piStack_18 = (int *)piStack_14[0x24];
    piStack_14[0x24] = (int)piStack_20;
    uVar2 = (undefined)uStack_8;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        uVar2 = (undefined)uStack_8;
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
          uVar2 = (undefined)uStack_8;
        }
      }
    }
  }
  uStack_8._0_1_ = uVar2;
  piStack_18 = (int *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 10;
  if (piStack_18 == (undefined4 *)0x0) {
    piVar7 = (undefined4 *)0x0;
  }
  else {
    *piStack_18 = 0;
    piStack_18[1] = 0;
    piStack_18[2] = 0;
    piStack_18[3] = 0;
    *(undefined8 *)(piStack_18 + 4) = 0;
    *piStack_18 = 0;
    piStack_18[1] = 0;
    piStack_18[2] = 0;
    piStack_18[3] = 0;
    piStack_18[4] = 0;
    puVar6 = (undefined4 *)FUN_01674e20(8);
    *piStack_18 = (int)puVar6;
    *puVar6 = 0;
    puVar6[1] = 0;
    *(int **)*piStack_18 = piStack_18;
    piStack_18[5] = 0;
    piVar7 = piStack_18;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iStack_24 = 0;
  piStack_20 = (int *)0x0;
  FUN_0077c7b0(piVar7,param_2);
  piStack_14[0x21] = iStack_24;
  piStack_18 = (int *)piStack_14[0x22];
  piStack_14[0x22] = (int)piStack_20;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0xff,0xff,0xff,0xff,0);
  iVar3 = *piVar7;
  iVar1 = piVar7[1];
  *piVar7 = 0;
  piVar7[1] = 0;
  piStack_14[9] = iVar3;
  piStack_18 = (int *)piStack_14[10];
  piStack_14[10] = iVar1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0x80,0x80,0x80,0xff,0);
  iVar3 = *piVar7;
  iVar1 = piVar7[1];
  *piVar7 = 0;
  piVar7[1] = 0;
  piStack_14[0xb] = iVar3;
  piStack_18 = (int *)piStack_14[0xc];
  piStack_14[0xc] = iVar1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0,0,0,0xff,0);
  iVar3 = *piVar7;
  iVar1 = piVar7[1];
  *piVar7 = 0;
  piVar7[1] = 0;
  piStack_14[0xd] = iVar3;
  piStack_18 = (int *)piStack_14[0xe];
  piStack_14[0xe] = iVar1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0,0,0,0,0);
  iVar3 = *piVar7;
  iVar1 = piVar7[1];
  *piVar7 = 0;
  piVar7[1] = 0;
  piStack_14[0xf] = iVar3;
  piStack_18 = (int *)piStack_14[0x10];
  piStack_14[0x10] = iVar1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0xff,0x80,0,0x80,0);
  iVar3 = *piVar7;
  iVar1 = piVar7[1];
  *piVar7 = 0;
  piVar7[1] = 0;
  piStack_14[0x11] = iVar3;
  piStack_18 = (int *)piStack_14[0x12];
  piStack_14[0x12] = iVar1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0,0x80,0,0,0);
  iVar3 = *piVar7;
  iVar1 = piVar7[1];
  *piVar7 = 0;
  piVar7[1] = 0;
  piStack_14[0x13] = iVar3;
  piStack_18 = (int *)piStack_14[0x14];
  piStack_14[0x14] = iVar1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0,0,0,0xff,2);
  iVar3 = *piVar7;
  iVar1 = piVar7[1];
  *piVar7 = 0;
  piVar7[1] = 0;
  piStack_14[0x15] = iVar3;
  piStack_18 = (int *)piStack_14[0x16];
  piStack_14[0x16] = iVar1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0xff,0xff,0xff,0xff,2);
  iVar3 = *piVar7;
  iVar1 = piVar7[1];
  *piVar7 = 0;
  piVar7[1] = 0;
  piStack_14[0x17] = iVar3;
  piStack_18 = (int *)piStack_14[0x18];
  piStack_14[0x18] = iVar1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0x80,0x80,0x80,0xff,2);
  iVar3 = *piVar7;
  iVar1 = piVar7[1];
  *piVar7 = 0;
  piVar7[1] = 0;
  piStack_14[0x19] = iVar3;
  piStack_18 = (int *)piStack_14[0x1a];
  piStack_14[0x1a] = iVar1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  iVar3 = (**(code **)(**(int **)(param_2 + 0x3c) + 0x40))();
  if (*(char *)(iVar3 + 0x16) != '\0') {
    piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0,0,0,0xff,1);
    iVar3 = *piVar7;
    iVar1 = piVar7[1];
    *piVar7 = 0;
    piVar7[1] = 0;
    piStack_14[0x1b] = iVar3;
    piStack_18 = (int *)piStack_14[0x1c];
    piStack_14[0x1c] = iVar1;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piStack_18 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0xff,0xff,0xff,0xff,1);
    iVar3 = *piVar7;
    iVar1 = piVar7[1];
    *piVar7 = 0;
    piVar7[1] = 0;
    piStack_14[0x1d] = iVar3;
    piStack_18 = (int *)piStack_14[0x1e];
    piStack_14[0x1e] = iVar1;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piStack_18 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piVar7 = (int *)FUN_00780d80(&iStack_24,*(undefined4 *)(param_2 + 0x3c),0,0,0,0,1);
    iVar3 = *piVar7;
    iVar1 = piVar7[1];
    *piVar7 = 0;
    piVar7[1] = 0;
    piStack_14[0x1f] = iVar3;
    piStack_18 = (int *)piStack_14[0x20];
    piStack_14[0x20] = iVar1;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piStack_18 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar7 = piStack_18 + 2;
        iVar3 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  piVar7 = piStack_14;
  if (**(uint **)(param_2 + 0x520) < 0x6000000) {
    uVar8 = 0x2000000;
  }
  else {
    uVar8 = **(uint **)(param_2 + 0x520) / 3;
  }
  piStack_14[0x3d] = uVar8;
  if (DAT_01eb1bb0 != 0) {
    piStack_14[0x3d] = DAT_01eb1bb0 << 0x14;
  }
  if (DAT_01d60d7c != '\0') {
    FUN_0153c480(piStack_14,FUN_007850b0);
  }
  *(byte *)(piVar7 + 0x42) = -(DAT_01d60d9c != '\0') & 4;
  iVar3 = (**(code **)(**(int **)(param_2 + 0x3c) + 0x40))();
  if (DAT_01eb1bb8 == 0) goto LAB_0077ee93;
  if (*(char *)(iVar3 + 0x17) != '\0') {
    if (DAT_01eb1bb8 == 1) {
      *(undefined *)(piVar7 + 0x42) = 5;
      goto LAB_0077ee93;
    }
    if (DAT_01eb1bb8 != 2) goto LAB_0077ee93;
  }
  *(undefined *)(piVar7 + 0x42) = 4;
LAB_0077ee93:
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return piVar7;
}



/* FUNCTION 11068 ; VA 0x0077eec0 ; FUN_0077eec0 */

void __fastcall FUN_0077eec0(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x8c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00637950();
  uVar3 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0xc);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0077ef4f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 11069 ; VA 0x0077ef60 ; FUN_0077ef60 */

int __fastcall FUN_0077ef60(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = FUN_00637950();
  uVar2 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 0xc);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0077efc1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 11070 ; VA 0x0077efd0 ; FUN_0077efd0 */

int __fastcall FUN_0077efd0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = FUN_00637950();
  uVar2 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 0xc);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0077f031. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 11071 ; VA 0x0077f040 ; FUN_0077f040 */

int __fastcall FUN_0077f040(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = FUN_00637950();
  uVar2 = *(uint *)(param_1 + 0x28);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 0x14);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0xf;
  *(undefined *)(param_1 + 0x14) = 0;
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0077f0b9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 11072 ; VA 0x0077f0d0 ; FUN_0077f0d0 */

void __fastcall FUN_0077f0d0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0077f2d0();
  return;
}



/* FUNCTION 11073 ; VA 0x0077f130 ; FUN_0077f130 */

void __fastcall FUN_0077f130(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x94);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00637950();
  FUN_0077f390();
  return;
}



/* FUNCTION 11074 ; VA 0x0077f180 ; FUN_0077f180 */

void FUN_0077f180(void)

{
  FUN_00637950();
  FUN_0077f390();
  return;
}



/* FUNCTION 11075 ; VA 0x0077f1a0 ; FUN_0077f1a0 */

void __fastcall FUN_0077f1a0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    FUN_0077f560();
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0xa8);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 11076 ; VA 0x0077f260 ; FUN_0077f260 */

void FUN_0077f260(void)

{
  FUN_00637950();
  FUN_0077f390();
  return;
}



/* FUNCTION 11077 ; VA 0x0077f280 ; FUN_0077f280 */

void __fastcall FUN_0077f280(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x8c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00637950();
  FUN_0077f390();
  return;
}



/* FUNCTION 11078 ; VA 0x0077f2d0 ; FUN_0077f2d0 */

void __fastcall FUN_0077f2d0(int *param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  
  piVar5 = (int *)*param_1;
  piVar7 = (int *)*piVar5;
  *piVar5 = (int)piVar5;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar5 = (int *)*param_1;
  if (piVar7 != piVar5) {
    do {
      uVar1 = piVar7[7];
      piVar2 = (int *)*piVar7;
      if (0xf < uVar1) {
        iVar3 = piVar7[2];
        uVar6 = uVar1 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar6) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar6 = uVar1 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar6);
      }
      piVar7[6] = 0;
      piVar7[7] = 0xf;
      *(undefined *)(piVar7 + 2) = 0;
      FUN_01674ea0(piVar7,0x24);
      piVar5 = (int *)*param_1;
      piVar7 = piVar2;
    } while (piVar2 != piVar5);
  }
  FUN_01674ea0(piVar5,0x24);
  return;
}



/* FUNCTION 11079 ; VA 0x0077f360 ; FUN_0077f360 */

void __fastcall FUN_0077f360(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_0077ce90(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x60);
  }
  return;
}



/* FUNCTION 11080 ; VA 0x0077f390 ; FUN_0077f390 */

void __fastcall FUN_0077f390(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0xc);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0077f3fd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 11081 ; VA 0x0077f410 ; FUN_0077f410 */

void __fastcall FUN_0077f410(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0xc);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0077f3fd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 11082 ; VA 0x0077f420 ; FUN_0077f420 */

void __fastcall FUN_0077f420(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_0077ce90(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x60);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 11083 ; VA 0x0077f4d0 ; FUN_0077f4d0 */

void __fastcall FUN_0077f4d0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_0077ce90(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x60);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 11084 ; VA 0x0077f4e0 ; FUN_0077f4e0 */

void __fastcall FUN_0077f4e0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0077f2d0();
  return;
}



/* FUNCTION 11085 ; VA 0x0077f4f0 ; thunk_FUN_00637950 */

void __fastcall thunk_FUN_00637950(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0x11];
  if (0xf < uVar1) {
    iVar2 = param_1[0xc];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637a1d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  uVar1 = param_1[0xb];
  if (0xf < uVar1) {
    iVar2 = param_1[6];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637a1d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00637a1d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 11086 ; VA 0x0077f500 ; FUN_0077f500 */

void __fastcall FUN_0077f500(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0077f553. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 11087 ; VA 0x0077f560 ; FUN_0077f560 */

void __fastcall FUN_0077f560(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x8c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x84);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x7c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x60);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x4c);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0xf;
  *(undefined *)(param_1 + 0x4c) = 0;
  FUN_00637950();
  return;
}



/* FUNCTION 11088 ; VA 0x0077f640 ; FUN_0077f640 */

void __fastcall FUN_0077f640(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d60d74 == '\0') {
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_1 + 0x8c) = 0;
    piVar2 = *(int **)(param_1 + 0x90);
    *(undefined4 *)(param_1 + 0x90) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (DAT_01d60d7c != '\0') {
    FUN_0153c530(param_1,FUN_007850b0);
  }
  uVar3 = *(uint *)(param_1 + 0xec);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0xd8);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0xe8) = 0;
  *(undefined4 *)(param_1 + 0xec) = 0xf;
  *(undefined *)(param_1 + 0xd8) = 0;
  FUN_0077f0d0();
  piVar2 = *(int **)(param_1 + 0x90);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x88);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0x1c,8,0xd,FUN_00550b30);
  FUN_0077f420();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11089 ; VA 0x0077f7a0 ; FUN_0077f7a0 */

int * __thiscall FUN_0077f7a0(byte *param_1,int param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  undefined uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017afbc0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_009cc8a0(param_2);
  uStack_14 = uStack_14 * 0x40 + (uint)*(byte *)(iVar4 + 0x18) + (uStack_14 >> 2) + 0x9e3779b9 ^
              uStack_14;
  FUN_0077cf60(&param_2,uStack_14,iVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return (int *)(param_2 + 8);
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  uStack_28 = *(undefined *)(iVar4 + 0x18);
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  piVar3 = (int *)FUN_01674e20(0x60);
  piStack_18 = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  piStack_20 = piVar3;
  FUN_0170d1f0(piStack_18,0,0x58);
  uStack_1c = CONCAT11(uStack_1c._1_1_,1);
  FUN_0054ef60(aiStack_40);
  *(undefined *)(piVar3 + 8) = uStack_28;
  piVar3[0xd] = 0;
  piVar3[0xe] = 0xf;
  *(undefined *)(piVar3 + 9) = 0;
  *(undefined *)(piVar3 + 0xf) = 0;
  piVar3[0x10] = 0;
  piVar3[0x11] = 0;
  piVar3[0x12] = 0;
  piVar3[0x13] = 0;
  piVar3[0x14] = 0;
  piVar3[0x15] = 0;
  piVar3[0x16] = 0;
  *(undefined *)(piVar3 + 0x17) = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005d6bb0(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_00780ee0(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = 1;
    uVar5 = uVar1 >> 1;
    if ((uVar1 >> 1) + uVar1 <= uVar7) {
      uVar5 = 1;
    }
    iVar4 = FUN_005d6bb0(uVar5 + uVar1);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_00780ee0(iVar4);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar8;
      while (puVar2 != (undefined4 *)0x0) {
        piVar6 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar6 = (int)puVar8;
          puVar8 = puVar2;
        }
        else {
          *puVar8 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar6;
          *(undefined4 **)*piVar6 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar3[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar3;
    }
    *puVar8 = piVar6;
    *piVar3 = *piVar6;
  }
  else {
    *piVar3 = *piVar6;
    piVar6 = (int *)*puVar8;
  }
  *piVar6 = (int)piVar3;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 11090 ; VA 0x0077fa30 ; FUN_0077fa30 */

void __fastcall FUN_0077fa30(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined8 uVar7;
  undefined auStack_118 [184];
  undefined auStack_60 [24];
  uint auStack_48 [4];
  int iStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017afc07;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1c50) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1c50);
    if (DAT_01eb1c50 == -1) {
      uStack_8 = 0;
      uVar7 = FUN_0152dab0("Systems","Async_Texture",0xffffffff);
      DAT_01eb1c4c = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eb1c48 = (undefined4)uVar7;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb1c50);
    }
  }
  uVar3 = DAT_01eb1c48;
  uStack_1c = DAT_01eb1c4c;
  uStack_2c = DAT_01eb1c48;
  uStack_28 = DAT_01eb1c4c;
  uStack_24 = FUN_0152d930(DAT_01eb1c48,DAT_01eb1c4c);
  uStack_8 = 1;
  FUN_00587490(&iStack_18);
  uStack_8._0_1_ = 2;
  if (iStack_18 == 0) {
    if (DAT_01eb1bac != '\0') {
      puVar6 = (undefined4 *)(param_1 + 0xc);
      if (0xf < *(uint *)(param_1 + 0x20)) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_01677650(DAT_01eb1bac,"Abandoning image %s because TextureManager is dead",puVar6);
    }
  }
  else {
    iVar2 = param_1 + 0xc;
    FUN_00781200(auStack_48,iVar2,*(undefined4 *)(param_1 + 0x34));
    uStack_8._0_1_ = 4;
    if (iStack_38 == 0) {
      FUN_007835f0(&iStack_18,iVar2,"File not found",param_1 + 0x38);
    }
    else {
      puVar6 = (undefined4 *)FUN_0151a8d0(auStack_60,auStack_48);
      uStack_8._0_1_ = 6;
      if (7 < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_0054ebd0(puVar6,0x21,0x40,1);
      uStack_8._0_1_ = 8;
      FUN_00550800();
      FUN_00783450(&iStack_18,*(undefined4 *)(param_1 + 8),iVar2,param_1 + 0x28,
                   *(undefined4 *)(param_1 + 0x30),uStack_30,param_1 + 0x38,
                   *(undefined4 *)(param_1 + 0x88),*(undefined4 *)(param_1 + 0x8c),auStack_118);
      FUN_00551650();
    }
    uStack_8._0_1_ = 2;
    if (0xf < uStack_34) {
      uVar5 = uStack_34 + 1;
      uVar4 = auStack_48[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_48[0] - 4);
        uVar5 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
    iStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  uStack_8 = 9;
  FUN_0152dda0(uVar3,uStack_1c,uStack_24);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11091 ; VA 0x0077fc90 ; FUN_0077fc90 */

uint __thiscall
FUN_0077fc90(undefined *param_1,int param_2,int param_3,int *param_4,int param_5,int *param_6,
            undefined4 param_7,int *param_8)

{
  uint *puVar1;
  undefined *puVar2;
  uint *puVar3;
  int *piVar4;
  uint uVar5;
  undefined *puVar6;
  char cVar7;
  int iVar8;
  uint uVar9;
  undefined auStack_3a8 [144];
  undefined auStack_318 [144];
  undefined auStack_288 [144];
  undefined auStack_1f8 [164];
  int iStack_154;
  undefined **appuStack_150 [2];
  undefined auStack_148 [52];
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_104;
  undefined **ppuStack_100;
  int iStack_b8;
  int *piStack_b4;
  undefined4 uStack_b0;
  undefined uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined auStack_84 [72];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017afcff;
  pvStack_10 = ExceptionList;
  piStack_20 = (int *)0x0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  iVar8 = FUN_00780cc0();
  if (((iVar8 == 0) && (param_5 == 0)) && (param_3 != 0)) {
    appuStack_150[0] = &PTR_018be314;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    piStack_20 = (int *)0x1;
    ppuStack_100 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_104 = 0x48;
    FUN_00554f20();
    uStack_8 = 5;
    *(undefined ***)((int)appuStack_150 + (int)appuStack_150[0][1]) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_154 + (int)appuStack_150[0][1]) = appuStack_150[0][1] + -0x50;
    FUN_0054ee60();
    appuStack_150[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_114 = 0;
    uStack_110 = 4;
    uStack_8._0_1_ = 6;
    FUN_0056f130();
    FUN_0058c400();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00729170();
    FUN_005587e0();
    FUN_00550b30();
    FUN_005507b0();
    FUN_00570540();
  }
  FUN_00587490();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (iStack_1c == 0) {
    uVar9 = (uint)DAT_01eb1bac;
    if (DAT_01eb1bac != 0) {
      uVar9 = FUN_01677650();
    }
LAB_0077fe43:
    if (piStack_18 == (int *)0x0) goto LAB_007800cb;
    LOCK();
    puVar1 = (uint *)(piStack_18 + 1);
    uVar5 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar5 - 1;
    UNLOCK();
    if (uVar5 - 1 != 0) goto LAB_007800cb;
    (**(code **)*piStack_18)();
    LOCK();
    puVar1 = (uint *)(piStack_18 + 2);
    uVar5 = *puVar1 - 1;
    uVar9 = *puVar1;
    *puVar1 = uVar5;
    UNLOCK();
  }
  else {
    if (param_2 != 1) {
      uVar9 = FUN_007835f0();
      goto LAB_0077fe43;
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    iStack_28 = iStack_1c;
    piStack_24 = piStack_18;
    piStack_20 = &iStack_b8;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    iStack_b8 = iStack_1c;
    piStack_b4 = piStack_18;
    uStack_b0 = *(undefined4 *)(puStack_14 + 8);
    uStack_8._0_1_ = 10;
    FUN_0054ef60(param_1 + 0xc);
    puVar6 = puStack_14;
    uStack_94 = param_1[0x24];
    uStack_8._0_1_ = 0xb;
    uStack_90 = *(undefined4 *)(puStack_14 + 0x28);
    puVar2 = puStack_14 + 0x34;
    uStack_8c = *(undefined4 *)(puStack_14 + 0x2c);
    uStack_88 = *(undefined4 *)(puStack_14 + 0x30);
    puStack_14 = auStack_84;
    FUN_0054ef60(puVar2);
    uStack_8._0_1_ = 0xc;
    FUN_0054ef60(puVar6 + 0x4c);
    uStack_8._0_1_ = 0xd;
    FUN_0054ef60(puVar6 + 100);
    uStack_3c = *(undefined4 *)(puVar6 + 0x7c);
    uStack_38 = *(undefined4 *)(puVar6 + 0x80);
    uStack_34 = *(undefined4 *)(puVar6 + 0x84);
    if (param_6 != (int *)0x0) {
      LOCK();
      param_6[1] = param_6[1] + 1;
      UNLOCK();
    }
    iStack_30 = param_5;
    piStack_2c = param_6;
    uStack_8._0_1_ = 0xe;
    FUN_0077d000(&iStack_b8);
    uStack_8._0_1_ = 0xf;
    FUN_0077d000(auStack_148);
    uStack_8._0_1_ = 0x10;
    FUN_0077d000(auStack_3a8);
    uStack_8._0_1_ = 0x11;
    FUN_0077d000(auStack_318);
    uStack_8._0_1_ = 0x12;
    cVar7 = FUN_00585a40(auStack_1f8);
    if (cVar7 == '\0') {
      FUN_0077d000(auStack_1f8);
      uStack_8._0_1_ = 0x13;
      iVar8 = FUN_01674e20(0x90);
      uStack_8._0_1_ = 0x14;
      if (iVar8 != 0) {
        FUN_0077d000(auStack_288);
      }
      FUN_0077eec0();
      FUN_0077eec0();
    }
    else {
      FUN_0077eec0();
    }
    FUN_0077eec0();
    FUN_0077eec0();
    FUN_0077eec0();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_0077eec0();
    uVar9 = FUN_0151ddd0();
    if (piStack_18 == (int *)0x0) goto LAB_007800cb;
    puVar1 = (uint *)(piStack_18 + 2);
    LOCK();
    uVar9 = *puVar1;
    *puVar1 = uVar9 - 1;
    UNLOCK();
    if (uVar9 - 1 == 0) {
      (**(code **)(*piStack_18 + 4))();
    }
    LOCK();
    puVar3 = (uint *)(piStack_18 + 1);
    uVar5 = *puVar3;
    uVar9 = *puVar3;
    *puVar3 = uVar5 - 1;
    UNLOCK();
    if (uVar5 - 1 != 0) goto LAB_007800cb;
    (**(code **)*piStack_18)();
    LOCK();
    uVar5 = *puVar1 - 1;
    uVar9 = *puVar1;
    *puVar1 = uVar5;
    UNLOCK();
  }
  if (uVar5 == 0) {
    uVar9 = (**(code **)(*piStack_18 + 4))();
  }
LAB_007800cb:
  if (param_4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_4 + 1);
    uVar5 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar5 - 1;
    UNLOCK();
    if (uVar5 - 1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      puVar1 = (uint *)(param_4 + 2);
      uVar5 = *puVar1;
      uVar9 = *puVar1;
      *puVar1 = uVar5 - 1;
      UNLOCK();
      if (uVar5 - 1 == 0) {
        uVar9 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_6 + 1);
    uVar5 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar5 - 1;
    UNLOCK();
    if (uVar5 - 1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      puVar1 = (uint *)(param_6 + 2);
      uVar5 = *puVar1;
      uVar9 = *puVar1;
      *puVar1 = uVar5 - 1;
      UNLOCK();
      if (uVar5 - 1 == 0) {
        uVar9 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_8 + 1);
    uVar5 = *puVar1;
    uVar9 = *puVar1;
    *puVar1 = uVar5 - 1;
    UNLOCK();
    if (uVar5 - 1 == 0) {
      uVar9 = (**(code **)*param_8)();
      LOCK();
      piVar4 = param_8 + 2;
      iVar8 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        uVar9 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar9;
}



/* FUNCTION 11092 ; VA 0x00780150 ; FUN_00780150 */

/* WARNING: Type propagation algorithm not settling */

int __thiscall
FUN_00780150(int param_1,int param_2,int *param_3,int *param_4,int param_5,int *param_6,
            undefined4 param_7,int *param_8)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_100 [20];
  int iStack_ec;
  undefined **appuStack_e8 [15];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_9c;
  undefined **ppuStack_98;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_3c;
  int iStack_38;
  int *piStack_34;
  uint uStack_30;
  int iStack_2c;
  int *piStack_28;
  uint uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017afdd2;
  pvStack_1c = ExceptionList;
  uStack_24 = 0;
  uStack_30 = 0;
  uStack_14 = 2;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_00780cc0(0,10,"rbxtemp://");
  if (((iVar3 == 0) && (param_5 == 0)) && (param_3 != (int *)0x0)) {
    appuStack_e8[0] = &PTR_018be314;
    uStack_14 = CONCAT31(uStack_14._1_3_,3);
    uStack_24 = 0x10;
    uStack_30 = 0x10;
    ppuStack_98 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_9c = 0x48;
    FUN_00554f20(appuStack_e8 + 1,0);
    uStack_14 = 5;
    *(undefined ***)(appuStack_e8[0][1] + (int)appuStack_e8) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_ec + (int)appuStack_e8[0][1]) = appuStack_e8[0][1] + -0x50;
    FUN_0054ee60();
    appuStack_e8[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_ac = 0;
    uStack_a8 = 4;
    uStack_14._0_1_ = 6;
    FUN_0056f130(*(undefined4 *)(*(int *)(*param_3 + 4) + 0x38 + (int)param_3));
    uVar4 = FUN_0058c400(auStack_100);
    uStack_14 = CONCAT31(uStack_14._1_3_,7);
    uVar4 = FUN_00729170(&iStack_2c,uVar4);
    FUN_005587e0(uVar4);
    FUN_00550b30();
    FUN_005507b0();
    FUN_00570540();
  }
  if (DAT_01d60da4 == '\0') {
    if (param_2 == 1) {
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      iStack_2c = param_5;
      piStack_28 = param_6;
      piVar5 = &iStack_2c;
      uStack_14 = CONCAT31(uStack_14._1_3_,8);
      uStack_30 = uStack_24 | 1;
    }
    else {
      iStack_38 = 0;
      piStack_34 = (int *)0x0;
      piVar5 = &iStack_38;
      uStack_30 = uStack_24 | 2;
      uStack_14 = 9;
    }
    piVar6 = piStack_28;
    uStack_24 = uStack_30;
    iVar3 = FUN_00783880(param_1,param_1 + 8,*(undefined4 *)(param_1 + 0x10),param_1 + 0x14,
                         param_1 + 0x30,*(undefined4 *)(param_1 + 0x38),param_1 + 0x3c,
                         *(undefined4 *)(param_1 + 0x88),*(undefined4 *)(param_1 + 0x8c),piVar5);
    if (((uStack_24 & 2) != 0) && (uStack_24 = uStack_24 & 0xfffffffd, piStack_34 != (int *)0x0)) {
      LOCK();
      piVar5 = piStack_34 + 1;
      iVar1 = *piVar5;
      iVar3 = *piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar5 = piStack_34 + 2;
        iVar1 = *piVar5;
        iVar3 = *piVar5;
        *piVar5 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_34 + 4))();
        }
      }
    }
    uVar2 = uStack_24 & 1;
  }
  else {
    if (param_2 == 1) {
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      iStack_2c = param_5;
      piStack_28 = param_6;
      uStack_14 = CONCAT31(uStack_14._1_3_,10);
      uStack_30 = uStack_24 | 4;
    }
    else {
      iStack_2c = 0;
      piStack_28 = (int *)0x0;
      uStack_30 = uStack_24 | 8;
      uStack_14 = 0xb;
    }
    piVar6 = piStack_28;
    uStack_48 = *(undefined4 *)(param_1 + 0x88);
    uStack_3c = *(undefined4 *)(param_1 + 0x8c);
    uStack_4c = *(undefined4 *)(param_1 + 0x38);
    uStack_50 = *(undefined4 *)(param_1 + 0x10);
    if (param_8 != (int *)0x0) {
      LOCK();
      param_8[1] = param_8[1] + 1;
      UNLOCK();
    }
    uStack_24 = uStack_30;
    iVar3 = FUN_00783ad0(param_1,param_1 + 8,uStack_50,param_1 + 0x14,param_1 + 0x30,uStack_4c,
                         param_1 + 0x3c,uStack_48,uStack_3c,&iStack_2c,param_7,param_8);
    if (((uStack_24 & 8) != 0) && (uStack_24 = uStack_24 & 0xfffffff7, piStack_28 != (int *)0x0)) {
      LOCK();
      piVar5 = piStack_28 + 1;
      iVar1 = *piVar5;
      iVar3 = *piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar5 = piStack_28 + 2;
        iVar1 = *piVar5;
        iVar3 = *piVar5;
        *piVar5 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    uVar2 = uStack_24 & 4;
  }
  if ((uVar2 != 0) && (piVar6 != (int *)0x0)) {
    LOCK();
    piVar5 = piVar6 + 1;
    iVar1 = *piVar5;
    iVar3 = *piVar5;
    *piVar5 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar5 = piVar6 + 2;
      iVar1 = *piVar5;
      iVar3 = *piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar3 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar6 = param_4 + 1;
    iVar1 = *piVar6;
    iVar3 = *piVar6;
    *piVar6 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar6 = param_4 + 2;
      iVar1 = *piVar6;
      iVar3 = *piVar6;
      *piVar6 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar6 = param_6 + 1;
    iVar1 = *piVar6;
    iVar3 = *piVar6;
    *piVar6 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar6 = param_6 + 2;
      iVar1 = *piVar6;
      iVar3 = *piVar6;
      *piVar6 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar3 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar6 = param_8 + 1;
    iVar1 = *piVar6;
    iVar3 = *piVar6;
    *piVar6 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*param_8)();
      LOCK();
      piVar6 = param_8 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iVar3;
}



/* FUNCTION 11093 ; VA 0x00780530 ; FUN_00780530 */

undefined4 __thiscall FUN_00780530(undefined4 param_1,byte param_2)

{
  FUN_0077f1a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 11094 ; VA 0x00780560 ; FUN_00780560 */

void __fastcall FUN_00780560(float *param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  undefined auStack_c [8];
  
  fVar2 = param_1[7];
  fVar3 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar2 + (double)(&DAT_018c0d90)[-((int)fVar2 >> 0x1f)]);
  if (*param_1 <= fVar3 && fVar3 != *param_1) {
    if ((uint)fVar2 < 0x200) {
      fVar2 = (float)((int)fVar2 << 3);
    }
    else if ((uint)fVar2 < 0x1fffffff) {
      fVar2 = (float)((int)fVar2 * 2);
    }
    FUN_005cb500(fVar2);
    pfVar1 = (float *)param_1[1];
    if ((float *)*pfVar1 != pfVar1) {
      fVar2 = pfVar1[1];
      do {
        fVar3 = *(float *)param_1[1];
        FUN_0077c600(auStack_c,(int)fVar3 + 8,fVar3);
      } while (fVar3 != fVar2);
    }
  }
  return;
}



/* FUNCTION 11095 ; VA 0x00780600 ; FUN_00780600 */

void __fastcall FUN_00780600(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_0077f1a0();
    FUN_01674ea0(iVar1,0x18);
  }
  return;
}



/* FUNCTION 11096 ; VA 0x00780620 ; FUN_00780620 */

void __thiscall FUN_00780620(int param_1,int *param_2)

{
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00780650(param_2);
  return;
}



/* FUNCTION 11097 ; VA 0x00780650 ; FUN_00780650 */

void FUN_00780650(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  FUN_01674ea0(param_1,0x24);
  return;
}



/* FUNCTION 11098 ; VA 0x007806b0 ; FUN_007806b0 */

void __thiscall FUN_007806b0(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if (0x1861861 - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_0078088c:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_00780714;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_00780714:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_0078088c;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_0078088c;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}



/* FUNCTION 11099 ; VA 0x007808a0 ; FUN_007808a0 */

void __thiscall FUN_007808a0(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017afdf8;
  pvStack_10 = ExceptionList;
  iVar6 = *(int *)(param_1 + 0x28);
  iStack_1c = param_1;
  if ((iVar6 == 0) || (*(int *)(iVar6 + 8) != 3)) {
    piStack_14 = *(int **)(param_1 + 0x1c);
    uVar7 = 0;
    uVar8 = *(int *)(param_1 + 0x20) - (int)piStack_14 >> 3;
    if (uVar8 != 0) {
      piStack_20 = (int *)*param_3;
      do {
        piVar5 = (int *)&DAT_01eb1b04;
        if ((int *)piStack_14[uVar7 * 2] != (int *)0x0) {
          piVar5 = (int *)piStack_14[uVar7 * 2];
        }
        if ((int *)*piVar5 == piStack_20) {
          *param_2 = 0;
          param_2[1] = 0;
          if (piStack_14[uVar7 * 2 + 1] != 0) {
            LOCK();
            piVar5 = (int *)(piStack_14[uVar7 * 2 + 1] + 4);
            *piVar5 = *piVar5 + 1;
            UNLOCK();
          }
          *param_2 = piStack_14[uVar7 * 2];
          iVar6 = piStack_14[uVar7 * 2 + 1];
          goto LAB_00780a70;
        }
        uVar7 = uVar7 + 1;
      } while (uVar7 < uVar8);
    }
    if ((iVar6 == 0) || (*(int *)(iVar6 + 8) != 1)) {
      ExceptionList = &pvStack_10;
      FUN_007735a0(param_3,3);
      puVar2 = *(undefined4 **)(param_1 + 0x20);
      uStack_8 = 2;
      if (*(undefined4 **)(param_1 + 0x24) != puVar2) {
        *puVar2 = 0;
        puVar2[1] = 0;
        *puVar2 = uStack_24;
        puVar2[1] = piStack_20;
        *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + 8;
        goto LAB_00780a47;
      }
      FUN_0077c2a0(puVar2,&uStack_24);
      piVar5 = piStack_20;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar4 = (undefined4 *)FUN_00773a00(auStack_18,param_3);
      puVar2 = *(undefined4 **)(param_1 + 0x20);
      uStack_8 = 1;
      if (*(undefined4 **)(param_1 + 0x24) == puVar2) {
        FUN_0077c2a0(puVar2,puVar4);
        piVar5 = piStack_14;
      }
      else {
        *puVar2 = 0;
        puVar2[1] = 0;
        *puVar2 = *puVar4;
        puVar2[1] = puVar4[1];
        *puVar4 = 0;
        puVar4[1] = 0;
        *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + 8;
        piVar5 = piStack_14;
      }
    }
  }
  else {
    if (*(int *)(param_1 + 0x1c) != *(int *)(param_1 + 0x20)) goto LAB_00780a47;
    ExceptionList = &pvStack_10;
    uVar3 = FUN_007738a0(auStack_18);
    uStack_8 = 0;
    FUN_00786610(uVar3);
    piVar5 = piStack_14;
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar6 = piVar5[1] + -1;
    piVar5[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
LAB_00780a47:
  iVar6 = *(int *)(iStack_1c + 0x20);
  *param_2 = 0;
  param_2[1] = 0;
  if (*(int *)(iVar6 + -4) != 0) {
    LOCK();
    piVar5 = (int *)(*(int *)(iVar6 + -4) + 4);
    *piVar5 = *piVar5 + 1;
    UNLOCK();
  }
  *param_2 = *(int *)(iVar6 + -8);
  iVar6 = *(int *)(iVar6 + -4);
LAB_00780a70:
  param_2[1] = iVar6;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11100 ; VA 0x00780a90 ; FUN_00780a90 */

void __fastcall FUN_00780a90(int param_1)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  undefined auStack_c [4];
  int iStack_8;
  
  iStack_8 = param_1;
  if (*(int *)(param_1 + 0xc) == 0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4 = *(undefined4 **)(*(int *)(param_1 + 0x18) + *(int *)(param_1 + 8) * 4);
  }
  while (puVar4 != (undefined4 *)0x0) {
    if (puVar4[0x13] == 0) {
      iVar5 = 0;
    }
    else {
      iVar5 = *(int *)(puVar4[0x13] + 8);
    }
    piVar6 = puVar4 + 2;
    iVar3 = FUN_00780cc0(0,4,&DAT_018c71bc);
    if (((((iVar3 == 0) || (iVar3 = FUN_00780cc0(0,0xd,"rbxassetid://"), iVar3 == 0)) ||
         (iVar3 = FUN_00780cc0(0,10,"rbxhttp://"), iVar3 == 0)) ||
        ((cVar2 = FUN_009cc920(), cVar2 != '\0' ||
         (iVar3 = FUN_00780cc0(0,10,"rbxtemp://"), iVar3 == 0)))) ||
       (iVar3 = FUN_00780cc0(0,0xb,"rbxthumb://"), iVar3 == 0)) {
      bVar1 = true;
    }
    else {
      bVar1 = false;
    }
    if ((iVar5 == 1) && (bVar1)) {
      if (DAT_01eb1bac != '\0') {
        if (0xf < (uint)puVar4[7]) {
          piVar6 = (int *)*piVar6;
        }
        FUN_01677650(DAT_01eb1bac,"Cancelling image %s upon request",piVar6);
      }
      iVar5 = iStack_8;
      if (*(char *)(puVar4 + 0x17) != '\0') {
        FUN_007868b0(puVar4 + 9);
      }
      puVar4 = (undefined4 *)FUN_00781140(auStack_c,puVar4);
      puVar4 = (undefined4 *)*puVar4;
      *(int *)(iVar5 + 0xb4) = *(int *)(iVar5 + 0xb4) + -1;
    }
    else {
      puVar4 = (undefined4 *)*puVar4;
    }
  }
  return;
}



/* FUNCTION 11101 ; VA 0x00780bc0 ; FUN_00780bc0 */

void __thiscall FUN_00780bc0(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined *puVar6;
  byte *pbVar7;
  byte *pbVar8;
  undefined auStack_14 [4];
  int iStack_10;
  undefined4 uStack_c;
  byte *pbStack_8;
  
  if (param_2 < *(uint *)(param_1 + 200)) {
    pbVar7 = (byte *)(param_1 + 4);
    iStack_10 = param_1;
    pbStack_8 = pbVar7;
    do {
      iVar3 = iStack_10;
      iVar2 = *(int *)(iStack_10 + 0xcc);
      if (*(int *)(iVar2 + 0x30) == 0) {
        *(undefined4 *)(iStack_10 + 0xcc) = *(undefined4 *)(iVar2 + 0x34);
      }
      else {
        *(undefined4 *)(*(int *)(iVar2 + 0x30) + 0x34) = *(undefined4 *)(iVar2 + 0x34);
      }
      if (*(int *)(iVar2 + 0x34) == 0) {
        *(undefined4 *)(iStack_10 + 0xd0) = *(undefined4 *)(iVar2 + 0x30);
      }
      else {
        *(undefined4 *)(*(int *)(iVar2 + 0x34) + 0x30) = *(undefined4 *)(iVar2 + 0x30);
      }
      *(undefined *)(iVar2 + 0x38) = 0;
      *(undefined4 *)(iVar2 + 0x30) = 0;
      *(undefined4 *)(iVar2 + 0x34) = 0;
      puVar6 = &DAT_01eb1b04;
      if (*(undefined **)(iVar2 + 0x28) != (undefined *)0x0) {
        puVar6 = *(undefined **)(iVar2 + 0x28);
      }
      iVar4 = FUN_00781d30(puVar6);
      piVar1 = (int *)(iVar3 + 200);
      *piVar1 = *piVar1 - iVar4;
      piVar1 = (int *)(iVar3 + 0xc4);
      *piVar1 = *piVar1 + -1;
      pbVar8 = pbVar7 + *pbVar7 + 1;
      uVar5 = FUN_009cc8a0(iVar2);
      pbVar7 = pbStack_8;
      FUN_0077cf60(&uStack_c,
                   (uVar5 >> 2) + (uint)*(byte *)(iVar2 + 0x18) + uVar5 * 0x40 + -0x61c88647 ^ uVar5
                   ,iVar2,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
      FUN_00781140(auStack_14,uStack_c);
    } while (param_2 < *(uint *)(iStack_10 + 200));
  }
  return;
}



/* FUNCTION 11102 ; VA 0x00780cc0 ; FUN_00780cc0 */

uint __thiscall FUN_00780cc0(undefined4 *param_1,uint param_2,uint param_3,byte *param_4)

{
  byte bVar1;
  code *pcVar2;
  uint uVar3;
  uint uVar4;
  byte *pbVar5;
  uint uVar6;
  bool bVar7;
  
  if ((uint)param_1[4] < param_2) {
    FUN_00554050();
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
  }
  pbVar5 = param_4;
  do {
    bVar1 = *pbVar5;
    pbVar5 = pbVar5 + 1;
  } while (bVar1 != 0);
  uVar6 = (int)pbVar5 - (int)(param_4 + 1);
  uVar4 = param_1[4] - param_2;
  if (uVar4 < param_3) {
    param_3 = uVar4;
  }
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar4 = param_3;
  if (uVar6 < param_3) {
    uVar4 = uVar6;
  }
  pbVar5 = (byte *)((int)param_1 + param_2);
  while (uVar3 = uVar4 - 4, 3 < uVar4) {
    if (*(int *)pbVar5 != *(int *)param_4) goto LAB_00780d26;
    pbVar5 = pbVar5 + 4;
    param_4 = param_4 + 4;
    uVar4 = uVar3;
  }
  if (uVar3 != 0xfffffffc) {
LAB_00780d26:
    bVar7 = *pbVar5 < *param_4;
    if ((*pbVar5 != *param_4) ||
       ((uVar3 != 0xfffffffd &&
        ((bVar7 = pbVar5[1] < param_4[1], pbVar5[1] != param_4[1] ||
         ((uVar3 != 0xfffffffe &&
          ((bVar7 = pbVar5[2] < param_4[2], pbVar5[2] != param_4[2] ||
           ((uVar3 != 0xffffffff && (bVar7 = pbVar5[3] < param_4[3], pbVar5[3] != param_4[3]))))))))
        )))) {
      uVar4 = -(uint)bVar7 | 1;
      goto LAB_00780d5c;
    }
  }
  uVar4 = 0;
LAB_00780d5c:
  if (uVar4 == 0) {
    if (param_3 < uVar6) {
      return 0xffffffff;
    }
    uVar4 = (uint)(uVar6 < param_3);
  }
  return uVar4;
}



/* FUNCTION 11103 ; VA 0x00780d80 ; FUN_00780d80 */

undefined4 *
FUN_00780d80(undefined4 *param_1,int *param_2,undefined param_3,undefined param_4,undefined param_5,
            undefined param_6,int param_7)

{
  code *pcVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined uVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar9 = param_7;
  puStack_c = &LAB_017afe31;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0147c180(param_1,param_7,3,1,1,5);
  param_7 = CONCAT13(param_6,CONCAT12(param_5,CONCAT11(param_4,param_3)));
  uStack_8 = 0;
  uStack_14 = 1;
  iVar5 = (**(code **)(*param_2 + 0x40))();
  uVar6 = param_7;
  if (*(char *)(iVar5 + 0x38) != '\0') {
    uVar2 = (undefined)param_7;
    uVar4 = param_7._2_1_;
    param_7 = CONCAT31(param_7._1_3_,uVar4);
    uVar3 = param_7;
    param_7._3_1_ = SUB41(uVar6,3);
    param_7._0_3_ = CONCAT12(uVar2,(short)uVar3);
  }
  iVar5 = 1;
  if (iVar9 == 2) {
    iVar5 = 6;
  }
  iVar9 = 0;
  do {
    pcVar1 = *(code **)(*(int *)*param_1 + 0x10);
    uVar6 = FUN_0147ce60(0,0,1,1);
    (*pcVar1)(iVar9,0,uVar6,&param_7,4);
    iVar9 = iVar9 + 1;
  } while (iVar9 < iVar5);
  (**(code **)(*(int *)*param_1 + 0x2c))();
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  pcVar1 = *(code **)(*(int *)*param_1 + 0xc);
  FUN_005542c0("TM fallback",0xb);
  uStack_8 = 1;
  (*pcVar1)(auStack_2c);
  if (0xf < uStack_18) {
    uVar8 = uStack_18 + 1;
    uVar7 = auStack_2c[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_2c[0] - 4);
      uVar8 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11104 ; VA 0x00780ee0 ; FUN_00780ee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00780ee0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  float10 fVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017afe48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar6 = param_2 + 1;
  if ((uVar6 < 0x40000000) && (uVar6 * 4 < 0x1000)) {
    if (uVar6 * 4 == 0) {
      puVar7 = (undefined4 *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar7 = (undefined4 *)FUN_01674e20();
    }
  }
  else {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_01674e20();
    if (iVar2 == 0) goto LAB_00781057;
    puVar7 = (undefined4 *)(iVar2 + 0x23U & 0xffffffe0);
    puVar7[-1] = iVar2;
  }
  for (puVar3 = puVar7; puVar3 != puVar7 + uVar6; puVar3 = puVar3 + 1) {
    *puVar3 = 0;
  }
  if (*(int *)(param_1 + 0x14) != 0) {
    puVar7[param_2] = *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar1 = *(int *)(param_1 + 0x14);
    iVar4 = iVar1;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar1 - iVar4) - 4U) {
LAB_00781057:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  *(int *)(param_1 + 4) = param_2;
  *(undefined4 **)(param_1 + 0x14) = puVar7;
  if (puVar7 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    fVar8 = (float10)FUN_01725160((double)*(float *)(param_1 + 0xc) *
                                  ((double)param_2 + (double)(&DAT_018c0d90)[-(param_2 >> 0x1f)]));
    if ((double)fVar8 < _DAT_018c4e98) {
      uVar5 = FUN_016f3eb1();
    }
    else {
      uVar5 = 0xffffffff;
    }
  }
  *(undefined4 *)(param_1 + 0x10) = uVar5;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11105 ; VA 0x00781060 ; FUN_00781060 */

void FUN_00781060(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x24;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 11106 ; VA 0x007810a0 ; FUN_007810a0 */

void __thiscall FUN_007810a0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  
  uVar2 = FUN_009cc8a0(param_3 + 2);
  iVar1 = (((uVar2 >> 2) + (uint)*(byte *)(param_3 + 8) + uVar2 * 0x40 + -0x61c88647 ^ uVar2) &
          *(uint *)(param_1 + 0x18)) * 8;
  piVar3 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar3[1] == param_3) {
    if ((int *)*piVar3 == param_3) {
      *piVar3 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar3[1] = param_3[1];
    }
  }
  else if ((int *)*piVar3 == param_3) {
    *piVar3 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00780650(param_3);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 11107 ; VA 0x00781140 ; FUN_00781140 */

int * __thiscall FUN_00781140(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  
  piVar1 = (int *)*param_3;
  *param_2 = (int)piVar1;
  uVar3 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  for (piVar5 = (int *)*piVar2; piVar5 != param_3; piVar5 = (int *)*piVar5) {
    piVar2 = piVar5;
  }
  do {
    *piVar2 = *piVar5;
    FUN_0077ce90(-(uint)(param_1 != -3) & param_1 + 4U,piVar5 + 2);
    FUN_01674ea0(piVar5,0x60);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar4 = uVar3;
    if (*piVar2 == 0) {
LAB_007811c9:
      if (*(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4) = 0;
      }
    }
    else {
      uVar4 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uVar3 != uVar4) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar2;
        goto LAB_007811c9;
      }
    }
    piVar5 = (int *)*piVar2;
    uVar3 = uVar4;
    if (piVar5 == piVar1) {
      return param_2;
    }
  } while( true );
}



/* FUNCTION 11108 ; VA 0x00781200 ; FUN_00781200 */

undefined4 * FUN_00781200(undefined4 *param_1,char *param_2,float param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  uint *puVar7;
  undefined4 ***pppuVar8;
  undefined4 *puVar9;
  char *pcVar10;
  int iVar11;
  uint uVar12;
  char *pcVar13;
  uint uVar14;
  int iVar15;
  int aiStack_d0 [5];
  uint uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  int iStack_a0;
  int iStack_9c;
  int iStack_98;
  int iStack_94;
  undefined8 uStack_90;
  undefined4 **ppuStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  undefined8 uStack_78;
  uint auStack_70 [4];
  int iStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined4 uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  undefined4 **ppuStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017afebf;
  pvStack_10 = ExceptionList;
  iVar15 = (int)param_3;
  ExceptionList = &pvStack_10;
  if (1 < iVar15) {
    pcVar10 = param_2;
    if (0xf < *(uint *)(param_2 + 0x14)) {
      pcVar10 = *(char **)param_2;
    }
    if (*(int *)(param_2 + 0x10) == 0) {
LAB_00781260:
      uVar14 = 0xffffffff;
    }
    else {
      iVar5 = *(int *)(param_2 + 0x10) + -1;
      iVar11 = -1;
      if (iVar5 != -1) {
        iVar11 = iVar5;
      }
      pcVar13 = pcVar10 + iVar11;
      cVar1 = *pcVar13;
      while (cVar1 != '.') {
        if (pcVar13 == pcVar10) goto LAB_00781260;
        pcVar13 = pcVar13 + -1;
        cVar1 = *pcVar13;
      }
      uVar14 = (int)pcVar13 - (int)pcVar10;
    }
    ExceptionList = &pvStack_10;
    if (uVar14 != 0xffffffff) {
      uVar12 = uVar14;
      if (*(uint *)(param_2 + 0x10) < uVar14) {
        uVar12 = *(uint *)(param_2 + 0x10);
      }
      uStack_18 = 0xf00000000;
      ppuStack_28 = (undefined4 **)((uint)ppuStack_28 & 0xffffff00);
      pcVar10 = param_2;
      if (0xf < *(uint *)(param_2 + 0x14)) {
        pcVar10 = *(char **)param_2;
      }
      ExceptionList = &pvStack_10;
      FUN_005542c0(pcVar10,uVar12);
      uStack_8 = 0;
      piVar6 = (int *)FUN_00554150(&DAT_018fbf24,1);
      ppuStack_88 = (undefined4 **)*piVar6;
      iStack_84 = piVar6[1];
      iStack_80 = piVar6[2];
      iStack_7c = piVar6[3];
      uStack_78 = *(undefined8 *)(piVar6 + 4);
      piVar6[4] = 0;
      piVar6[5] = 0xf;
      *(undefined *)piVar6 = 0;
      uStack_8._0_1_ = 2;
      FUN_005507b0();
      uStack_a8 = 0;
      uStack_a4 = 0xf;
      uStack_b8 = 0;
      if (*(uint *)(param_2 + 0x10) < uVar14) {
        FUN_00554050();
        goto LAB_00781708;
      }
      iVar5 = *(uint *)(param_2 + 0x10) - uVar14;
      iVar11 = -1;
      if (iVar5 != -1) {
        iVar11 = iVar5;
      }
      pcVar10 = param_2;
      if (0xf < *(uint *)(param_2 + 0x14)) {
        pcVar10 = *(char **)param_2;
      }
      FUN_005542c0(pcVar10 + uVar14,iVar11);
      uStack_8._0_1_ = 3;
      piVar6 = (int *)FUN_00585d40(0,&DAT_018fbf28,1);
      ppuStack_28 = (undefined4 **)*piVar6;
      iStack_24 = piVar6[1];
      iStack_20 = piVar6[2];
      iStack_1c = piVar6[3];
      uStack_18 = *(undefined8 *)(piVar6 + 4);
      piVar6[4] = 0;
      piVar6[5] = 0xf;
      *(undefined *)piVar6 = 0;
      uStack_8._0_1_ = 5;
      FUN_005507b0();
      do {
        FUN_005bde90(&param_3,&DAT_018bed68,iVar15);
        pcVar10 = (char *)&param_3;
        uStack_48 = 0;
        uStack_44 = 0xf;
        uStack_58 = uStack_58 & 0xffffff00;
        do {
          cVar1 = *pcVar10;
          pcVar10 = pcVar10 + 1;
        } while (cVar1 != '\0');
        FUN_005542c0(&param_3,(int)pcVar10 - ((int)&param_3 + 1));
        pppuVar8 = &ppuStack_88;
        if (0xf < uStack_78._4_4_) {
          pppuVar8 = (undefined4 ***)ppuStack_88;
        }
        uStack_8._0_1_ = 6;
        puVar7 = (uint *)FUN_00585d40(0,pppuVar8,(undefined4)uStack_78);
        uStack_40 = *puVar7;
        uStack_3c = puVar7[1];
        uStack_38 = puVar7[2];
        uStack_34 = puVar7[3];
        uStack_30 = *(undefined8 *)(puVar7 + 4);
        puVar7[4] = 0;
        puVar7[5] = 0xf;
        *(undefined *)puVar7 = 0;
        pppuVar8 = &ppuStack_28;
        if (0xf < uStack_18._4_4_) {
          pppuVar8 = (undefined4 ***)ppuStack_28;
        }
        uStack_8._0_1_ = 7;
        piVar6 = (int *)FUN_00554150(pppuVar8,(undefined4)uStack_18);
        iStack_a0 = *piVar6;
        iStack_9c = piVar6[1];
        iStack_98 = piVar6[2];
        iStack_94 = piVar6[3];
        uStack_90 = *(undefined8 *)(piVar6 + 4);
        piVar6[4] = 0;
        piVar6[5] = 0xf;
        *(undefined *)piVar6 = 0;
        uStack_8._0_1_ = 8;
        FUN_0054ef60(&iStack_a0);
        uStack_8._0_1_ = 9;
        FUN_009cbbb0(aiStack_d0);
        uStack_8._0_1_ = 0xb;
        if (0xf < uStack_90._4_4_) {
          uVar14 = uStack_90._4_4_ + 1;
          iVar11 = iStack_a0;
          if (0xfff < uVar14) {
            iVar11 = *(int *)(iStack_a0 + -4);
            uVar14 = uStack_90._4_4_ + 0x24;
            if (0x1f < (iStack_a0 - iVar11) - 4U) goto LAB_00781708;
          }
          FUN_01674ea0(iVar11,uVar14);
        }
        uStack_8._0_1_ = 0xc;
        if (0xf < uStack_30._4_4_) {
          uVar12 = uStack_30._4_4_ + 1;
          uVar14 = uStack_40;
          if (0xfff < uVar12) {
            uVar14 = *(uint *)(uStack_40 - 4);
            uVar12 = uStack_30._4_4_ + 0x24;
            if (0x1f < (uStack_40 - uVar14) - 4) goto LAB_00781708;
          }
          FUN_01674ea0(uVar14,uVar12);
        }
        uStack_30 = 0xf00000000;
        uStack_40 = uStack_40 & 0xffffff00;
        uStack_8._0_1_ = 0xd;
        if (0xf < uStack_44) {
          uVar12 = uStack_44 + 1;
          uVar14 = uStack_58;
          if (0xfff < uVar12) {
            uVar14 = *(uint *)(uStack_58 - 4);
            uVar12 = uStack_44 + 0x24;
            if (0x1f < (uStack_58 - uVar14) - 4) goto LAB_00781708;
          }
          FUN_01674ea0(uVar14,uVar12);
        }
        uStack_48 = 0;
        uStack_44 = 0xf;
        uStack_58 = uStack_58 & 0xffffff00;
        FUN_008cb670(auStack_70,aiStack_d0);
        uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
        if (iStack_60 != 0) {
          FUN_0054ef60(auStack_70);
          param_1[6] = iVar15;
          FUN_005507b0();
          FUN_005507b0();
          FUN_005507b0();
          FUN_005507b0();
          ExceptionList = pvStack_10;
          return param_1;
        }
        iVar15 = iVar15 + -1;
        uStack_8._0_1_ = 0xd;
        if (0xf < uStack_5c) {
          uVar12 = uStack_5c + 1;
          uVar14 = auStack_70[0];
          if (0xfff < uVar12) {
            uVar14 = *(uint *)(auStack_70[0] - 4);
            uVar12 = uStack_5c + 0x24;
            if (0x1f < (auStack_70[0] - uVar14) - 4) goto LAB_00781708;
          }
          FUN_01674ea0(uVar14,uVar12);
        }
        iStack_60 = 0;
        uStack_5c = 0xf;
        auStack_70[0] = auStack_70[0] & 0xffffff00;
        uStack_8._0_1_ = 5;
        if (0xf < uStack_bc) {
          uVar14 = uStack_bc + 1;
          iVar11 = aiStack_d0[0];
          if (0xfff < uVar14) {
            iVar11 = *(int *)(aiStack_d0[0] + -4);
            uVar14 = uStack_bc + 0x24;
            if (0x1f < (aiStack_d0[0] - iVar11) - 4U) goto LAB_00781708;
          }
          FUN_01674ea0(iVar11,uVar14);
        }
      } while (1 < iVar15);
      FUN_005507b0();
      uStack_8._0_1_ = 0xff;
      uStack_8._1_3_ = 0xffffff;
      FUN_005507b0();
    }
  }
  puVar9 = (undefined4 *)FUN_008cb670(&iStack_a0,param_2);
  param_1[4] = 0;
  param_1[5] = 0;
  uVar2 = puVar9[1];
  uVar3 = puVar9[2];
  uVar4 = puVar9[3];
  *param_1 = *puVar9;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar9 + 4);
  puVar9[4] = 0;
  puVar9[5] = 0xf;
  *(undefined *)puVar9 = 0;
  param_1[6] = 1;
  if (0xf < uStack_90._4_4_) {
    uVar14 = uStack_90._4_4_ + 1;
    iVar15 = iStack_a0;
    if (0xfff < uVar14) {
      iVar15 = *(int *)(iStack_a0 + -4);
      uVar14 = uStack_90._4_4_ + 0x24;
      if (0x1f < (iStack_a0 - iVar15) - 4U) {
LAB_00781708:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar15,uVar14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11109 ; VA 0x00781710 ; FUN_00781710 */

void __fastcall FUN_00781710(int param_1)

{
  undefined4 *puVar1;
  int iStack_8;
  
  iStack_8 = param_1;
  if (*(int *)(param_1 + 0xc) == 0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x18) + *(int *)(param_1 + 8) * 4);
  }
  for (; puVar1 != (undefined4 *)0x0; puVar1 = (undefined4 *)*puVar1) {
    if ((puVar1[0x13] != 0) && (*(int *)(puVar1[0x13] + 8) == 2)) {
      puVar1 = (undefined4 *)FUN_00781140(&iStack_8,puVar1);
    }
  }
  return;
}



/* FUNCTION 11110 ; VA 0x00781760 ; FUN_00781760 */

void __fastcall FUN_00781760(int param_1)

{
  FUN_007850d0(*(undefined4 *)(param_1 + 0xc));
  FUN_00780bc0(0);
  *(undefined4 *)(param_1 + 0xd4) = *(undefined4 *)(param_1 + 0xc);
  return;
}



/* FUNCTION 11111 ; VA 0x00781780 ; FUN_00781780 */

void __fastcall FUN_00781780(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined8 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017afee4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1c40) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1c40);
    if (DAT_01eb1c40 == -1) {
      uStack_8 = 0;
      uVar6 = FUN_0152dab0("Render","TextureManager::garbageCollectIncremental",0xffffffff);
      DAT_01eb1c3c = (undefined4)((ulonglong)uVar6 >> 0x20);
      DAT_01eb1c38 = (undefined4)uVar6;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb1c40);
    }
  }
  uVar2 = DAT_01eb1c3c;
  uVar1 = DAT_01eb1c38;
  uVar6 = FUN_0152d930(DAT_01eb1c38,DAT_01eb1c3c);
  uVar5 = *(uint *)(param_1 + 0xc);
  uVar4 = *(uint *)(param_1 + 0xd4);
  uStack_8 = 1;
  uVar3 = uVar4;
  if (uVar4 <= uVar5) {
    uVar3 = uVar5;
  }
  uVar4 = (uVar3 - uVar4) + 8;
  if (uVar5 <= uVar4) {
    uVar4 = uVar5;
  }
  FUN_007850d0(uVar4);
  uVar4 = *(int *)(param_1 + 200) + *(int *)(param_1 + 0xc0);
  uVar5 = *(uint *)(param_1 + 0xf4);
  if (uVar5 < uVar4) {
    uVar3 = 0;
  }
  else {
    uVar3 = uVar5 >> 2;
    if (0x4000000 < uVar3) {
      uVar3 = 0x4000000;
    }
    uVar5 = uVar5 - uVar4;
    if (uVar5 <= uVar3) {
      uVar3 = uVar5;
    }
  }
  FUN_00780bc0(uVar3);
  *(undefined4 *)(param_1 + 0xd4) = *(undefined4 *)(param_1 + 0xc);
  uStack_8 = 2;
  FUN_0152dda0(uVar1,uVar2,uVar6);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11112 ; VA 0x007818d0 ; FUN_007818d0 */

undefined * FUN_007818d0(undefined *param_1,char param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  undefined *puVar4;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d6ca30 == '\0') {
LAB_0078199d:
    switch(param_2) {
    case '\x04':
      if (DAT_01d60d9c == '\0') {
        *(undefined4 *)(param_1 + 0x10) = 0;
        *(undefined4 *)(param_1 + 0x14) = 0xf;
        *param_1 = 0;
        FUN_005542c0(&DAT_018bfda4,3);
        ExceptionList = pvStack_10;
        return param_1;
      }
      break;
    case '\x05':
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0xf;
      *param_1 = 0;
      FUN_005542c0("ktx/dxt",7);
      ExceptionList = pvStack_10;
      return param_1;
    case '\x06':
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0xf;
      *param_1 = 0;
      FUN_005542c0("ktx/etc",7);
      ExceptionList = pvStack_10;
      return param_1;
    case '\a':
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0xf;
      *param_1 = 0;
      FUN_005542c0("ktx/etc2",8);
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_0054ef60(&DAT_01d62f20);
    ExceptionList = pvStack_10;
    return param_1;
  }
  pcVar3 = "";
  uStack_18 = 0;
  if (DAT_01d6cae0 == '\0') {
    pcVar3 = "rbx-format/";
  }
  uStack_14 = 0xf;
  auStack_28[0] = 0;
  pcVar2 = pcVar3;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar3,(int)pcVar2 - (int)(pcVar3 + 1));
  uStack_8 = 0;
  if (param_2 == '\x01') {
    puVar4 = &DAT_01d6c9a0;
  }
  else if (param_2 == '\x02') {
    puVar4 = &DAT_01d6c9b8;
  }
  else {
    if (param_2 != '\x03') {
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      goto LAB_0078199d;
    }
    puVar4 = &DAT_01d6c9d0;
  }
  FUN_005f3cd0(param_1,auStack_28,puVar4);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11113 ; VA 0x00781ac0 ; FUN_00781ac0 */

undefined4 FUN_00781ac0(undefined4 param_1,char param_2)

{
  undefined4 uVar1;
  
  if ((DAT_01d6ca30 != '\0') &&
     (((param_2 == '\x01' || (param_2 == '\x02')) || (param_2 == '\x03')))) {
    uVar1 = FUN_008ccdb0();
    FUN_0054ef60(uVar1);
    return param_1;
  }
  uVar1 = FUN_008ccda0();
  FUN_0054ef60(uVar1);
  return param_1;
}



/* FUNCTION 11114 ; VA 0x00781b10 ; FUN_00781b10 */

int FUN_00781b10(int *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  
  uVar1 = *(undefined4 *)(*param_1 + 0x2c);
  uVar2 = param_2[1];
  uVar3 = *param_2;
  uVar4 = FUN_0147d0e0(uVar3,uVar2,1);
  iVar9 = 0;
  uVar10 = 0;
  if (uVar4 != 0) {
    do {
      uVar5 = FUN_0147d110(uVar2,uVar10);
      uVar6 = FUN_0147d110(uVar3,uVar10);
      iVar7 = FUN_0147d000(uVar1,uVar6,uVar5);
      iVar8 = FUN_0147d110(1,uVar10);
      uVar10 = uVar10 + 1;
      iVar9 = iVar9 + iVar7 * iVar8;
    } while (uVar10 < uVar4);
  }
  iVar7 = 1;
  if (*(int *)(*param_1 + 0x28) == 2) {
    iVar7 = 6;
  }
  return iVar7 * iVar9;
}



/* FUNCTION 11115 ; VA 0x00781bb0 ; FUN_00781bb0 */

undefined4 * __thiscall FUN_00781bb0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 0xc4);
  uVar2 = *(undefined4 *)(param_1 + 0xb4);
  param_2[1] = *(undefined4 *)(param_1 + 0xf4);
  param_2[2] = *(undefined4 *)(param_1 + 0xbc);
  uVar3 = *(undefined4 *)(param_1 + 0xc0);
  param_2[4] = uVar1;
  uVar1 = *(undefined4 *)(param_1 + 200);
  *param_2 = uVar2;
  param_2[3] = uVar3;
  param_2[5] = uVar1;
  return param_2;
}



/* FUNCTION 11116 ; VA 0x00781c00 ; FUN_00781c00 */

void __thiscall FUN_00781c00(int param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017afef8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00559500(*param_2,param_2[1],param_2);
  param_2[1] = *param_2;
  FUN_00775760(*(undefined4 *)(param_1 + 0xc),param_2);
  if (*(int *)(param_1 + 0xc) == 0) {
    piVar6 = (int *)0x0;
  }
  else {
    piVar6 = *(int **)(*(int *)(param_1 + 0x18) + *(int *)(param_1 + 8) * 4);
  }
  if (piVar6 != (int *)0x0) {
    iStack_14 = 0;
    do {
      piVar4 = piVar6 + 9;
      iVar5 = *param_2 + iStack_14;
      if (0xf < (uint)piVar6[0xe]) {
        piVar4 = (int *)*piVar4;
      }
      piVar2 = piVar4;
      do {
        cVar1 = *(char *)piVar2;
        piVar2 = (int *)((int)piVar2 + 1);
      } while (cVar1 != '\0');
      FUN_005542c0(piVar4,(int)piVar2 - (int)((int)piVar4 + 1));
      piVar4 = (int *)&DAT_01eb1b04;
      if ((int *)piVar6[0x13] != (int *)0x0) {
        piVar4 = (int *)piVar6[0x13];
      }
      piVar2 = (int *)piVar4[1];
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
        piVar2 = (int *)piVar4[1];
      }
      iStack_1c = *piVar4;
      uStack_8 = 0;
      piStack_18 = piVar2;
      if (iStack_1c == 0) {
        *(undefined4 *)(iVar5 + 0x18) = 0;
      }
      else {
        uVar3 = FUN_00781d30(&iStack_1c);
        *(undefined4 *)(iVar5 + 0x18) = uVar3;
      }
      *(undefined *)(iVar5 + 0x1c) = *(undefined *)(piVar6 + 0x17);
      iStack_14 = iStack_14 + 0x20;
      uStack_8 = 0xffffffff;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar5 = piVar2[1] + -1;
        piVar2[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar5 = piVar2[2] + -1;
          piVar2[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar6 = (int *)*piVar6;
    } while (piVar6 != (int *)0x0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11117 ; VA 0x00781d30 ; FUN_00781d30 */

int FUN_00781d30(int *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined4 uStack_8;
  
  iVar6 = 0;
  uVar7 = 0;
  uStack_8 = 0;
  iVar5 = *param_1;
  if (*(int *)(iVar5 + 0x3c) != 0) {
    do {
      uVar2 = FUN_0147d110(*(undefined4 *)(iVar5 + 0x34),uVar7);
      uVar3 = FUN_0147d110(*(undefined4 *)(*param_1 + 0x30),uVar7);
      uVar1 = *(undefined4 *)(*param_1 + 0x38);
      iVar6 = FUN_0147d000(*(undefined4 *)(*param_1 + 0x2c),uVar3,uVar2);
      iVar4 = FUN_0147d110(uVar1,uVar7);
      uVar7 = uVar7 + 1;
      iVar5 = *param_1;
      iVar6 = uStack_8 + iVar6 * iVar4;
      uStack_8 = iVar6;
    } while (uVar7 < *(uint *)(iVar5 + 0x3c));
  }
  iVar4 = 1;
  if (*(int *)(iVar5 + 0x28) == 2) {
    iVar4 = 6;
  }
  return iVar4 * iVar6;
}



/* FUNCTION 11118 ; VA 0x00781dc0 ; FUN_00781dc0 */

undefined4 __fastcall FUN_00781dc0(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x84) >> 8),
                  *(int *)(*(int *)(param_1 + 0x84) + 0x10) != 0);
}



/* FUNCTION 11119 ; VA 0x00781dd0 ; FUN_00781dd0 */

void FUN_00781dd0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined8 uVar5;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aff2c;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1c60) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1c60);
    if (DAT_01eb1c60 == -1) {
      uStack_8 = 0;
      uVar5 = FUN_0152dab0("Systems","Async_Texture",0xffffffff);
      DAT_01eb1c5c = (undefined4)((ulonglong)uVar5 >> 0x20);
      DAT_01eb1c58 = (undefined4)uVar5;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb1c60);
    }
  }
  uVar3 = DAT_01eb1c5c;
  uStack_14 = DAT_01eb1c58;
  uVar5 = FUN_0152d930(DAT_01eb1c58,DAT_01eb1c5c);
  uStack_8 = 1;
  FUN_00587490(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_1c == 0) {
    if (DAT_01eb1bac != '\0') {
      puVar4 = (undefined4 *)(iVar2 + 0xc);
      if (0xf < *(uint *)(iVar2 + 0x20)) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_01677650(DAT_01eb1bac,"Abandoning image %s because TextureManager is dead",puVar4);
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    uStack_8 = 3;
  }
  else {
    FUN_00783520(&iStack_1c,*(undefined4 *)(iVar2 + 8),iVar2 + 0xc,iVar2 + 0x28,
                 *(undefined4 *)(iVar2 + 0x30),1,iVar2 + 0x34,*(undefined4 *)(iVar2 + 0x80),
                 *(undefined4 *)(iVar2 + 0x84),*(undefined4 *)(iVar2 + 0x88));
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    uStack_8 = 4;
  }
  FUN_0152dda0(uStack_14,uVar3,uVar5);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11120 ; VA 0x00781f90 ; FUN_00781f90 */

void FUN_00781f90(void)

{
  FUN_0077fa30();
  return;
}



/* FUNCTION 11121 ; VA 0x00781fa0 ; FUN_00781fa0 */

void FUN_00781fa0(int *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)*param_1;
  (*(code *)*puVar1)(puVar1 + 2,puVar1[4],puVar1 + 5,puVar1 + 0xc,puVar1[0xe],puVar1 + 0xf,
                     puVar1[0x22],puVar1[0x23],puVar1 + 0x24);
  return;
}



/* FUNCTION 11122 ; VA 0x00781fe0 ; FUN_00781fe0 */

void FUN_00781fe0(int *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)*param_1;
  (*(code *)*puVar1)(puVar1 + 2,puVar1[4],puVar1 + 5,puVar1 + 0xc,puVar1[0xe],puVar1[0xf],
                     puVar1 + 0x10,puVar1[0x24],puVar1[0x25]);
  return;
}



/* FUNCTION 11123 ; VA 0x00782020 ; FUN_00782020 */

/* WARNING: Removing unreachable block (ram,0x00782101) */
/* WARNING: Removing unreachable block (ram,0x0078210a) */
/* WARNING: Removing unreachable block (ram,0x00782119) */
/* WARNING: Removing unreachable block (ram,0x007820db) */
/* WARNING: Removing unreachable block (ram,0x007820e4) */
/* WARNING: Removing unreachable block (ram,0x007820f3) */
/* WARNING: Removing unreachable block (ram,0x00782127) */
/* WARNING: Removing unreachable block (ram,0x00782130) */
/* WARNING: Removing unreachable block (ram,0x0078213e) */

undefined4
FUN_00782020(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0077fc90(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 11124 ; VA 0x00782160 ; FUN_00782160 */

/* WARNING: Removing unreachable block (ram,0x00782241) */
/* WARNING: Removing unreachable block (ram,0x0078224a) */
/* WARNING: Removing unreachable block (ram,0x00782259) */
/* WARNING: Removing unreachable block (ram,0x0078221b) */
/* WARNING: Removing unreachable block (ram,0x00782224) */
/* WARNING: Removing unreachable block (ram,0x00782233) */
/* WARNING: Removing unreachable block (ram,0x00782267) */
/* WARNING: Removing unreachable block (ram,0x00782270) */
/* WARNING: Removing unreachable block (ram,0x0078227e) */

undefined4
FUN_00782160(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00780150(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 11125 ; VA 0x007822a0 ; FUN_007822a0 */

bool FUN_007822a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00780cc0(0,0xb,"rbxasset://");
  return iVar1 == 0;
}



/* FUNCTION 11126 ; VA 0x007822c0 ; FUN_007822c0 */

uint __thiscall FUN_007822c0(int param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  
  uVar2 = 0;
  piVar1 = (int *)(param_1 + 0x1c);
  do {
    if (*param_2 == *piVar1) {
      return CONCAT31((int3)((uint)piVar1 >> 8),1);
    }
    uVar2 = uVar2 + 1;
    piVar1 = piVar1 + 2;
  } while (uVar2 < 0xd);
  return (uint)piVar1 & 0xffffff00;
}



/* FUNCTION 11127 ; VA 0x007822f0 ; FUN_007822f0 */

undefined4 FUN_007822f0(void)

{
  char cVar1;
  int iVar2;
  
  iVar2 = FUN_00780cc0(0,4,&DAT_018c71bc);
  if (iVar2 != 0) {
    iVar2 = FUN_00780cc0(0,0xd,"rbxassetid://");
    if (iVar2 != 0) {
      iVar2 = FUN_00780cc0(0,10,"rbxhttp://");
      if (iVar2 != 0) {
        cVar1 = FUN_009cc920();
        if (cVar1 == '\0') {
          iVar2 = FUN_00780cc0(0,10,"rbxtemp://");
          if (iVar2 != 0) {
            iVar2 = FUN_00780cc0(0,0xb,"rbxthumb://");
            if (iVar2 != 0) {
              return 0;
            }
          }
        }
      }
    }
  }
  return 1;
}



/* FUNCTION 11128 ; VA 0x00782370 ; FUN_00782370 */

bool FUN_00782370(void)

{
  int iVar1;
  
  iVar1 = FUN_00780cc0(0,4,&DAT_018c71bc);
  return iVar1 == 0;
}



/* FUNCTION 11129 ; VA 0x00782390 ; FUN_00782390 */

bool FUN_00782390(void)

{
  int iVar1;
  
  iVar1 = FUN_00780cc0(0,0xb,"rbxthumb://");
  return iVar1 == 0;
}



/* FUNCTION 11130 ; VA 0x007823b0 ; FUN_007823b0 */

undefined4 __thiscall
FUN_007823b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  undefined uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aff48;
  pvStack_10 = ExceptionList;
  uVar2 = *(undefined4 *)(param_1 + 0xfc);
  uVar1 = *(undefined *)(param_1 + 0x108);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  uStack_14 = 0;
  if (DAT_01d60d9c != '\0') {
    uStack_14 = uVar1;
  }
  uStack_8 = 0;
  FUN_00784040(param_2,aiStack_2c,param_4,param_5,param_6,param_7,uVar2);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar3 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11131 ; VA 0x00782480 ; FUN_00782480 */

undefined4 __thiscall
FUN_00782480(int param_1,undefined4 param_2,undefined4 param_3,int param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  undefined uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aff48;
  pvStack_10 = ExceptionList;
  uVar2 = *(undefined4 *)(param_1 + 0xfc);
  uVar1 = *(undefined *)(param_1 + 0x108);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  uStack_14 = 0;
  if (DAT_01d60d9c != '\0') {
    uStack_14 = uVar1;
  }
  uStack_8 = 0;
  FUN_00784040(param_2,aiStack_2c,param_4 * 8 + 0x1c + param_1,param_5,param_6,param_7,uVar2);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar3 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11132 ; VA 0x00782550 ; FUN_00782550 */

undefined4 __thiscall
FUN_00782550(int param_1,undefined4 param_2,undefined4 param_3,char param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aff48;
  pvStack_10 = ExceptionList;
  uVar2 = *(undefined4 *)(param_1 + 0xfc);
  cVar1 = *(char *)(param_1 + 0x108);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  cStack_14 = param_4;
  if ((DAT_01d60d9c != '\0') && (cStack_14 = param_4, param_4 == '\0')) {
    cStack_14 = cVar1;
  }
  uStack_8 = 0;
  FUN_00784040(param_2,aiStack_2c,param_5 * 8 + 0x1c + param_1,param_6,param_7,param_8,uVar2);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar3 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11133 ; VA 0x00782630 ; FUN_00782630 */

undefined4 __thiscall
FUN_00782630(int *param_1,int param_2,int param_3,undefined4 param_4,uint param_5,int param_6)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  undefined4 uVar11;
  undefined auStack_554 [44];
  undefined4 uStack_528;
  int *piStack_524;
  undefined4 uStack_520;
  int iStack_51c;
  undefined4 uStack_518;
  undefined ***pppuStack_514;
  undefined *puStack_510;
  undefined4 **ppuStack_50c;
  undefined4 **ppuStack_508;
  undefined ***pppuStack_504;
  undefined auStack_4ec [8];
  undefined auStack_4e4 [136];
  undefined4 uStack_45c;
  undefined auStack_454 [8];
  undefined auStack_44c [136];
  undefined4 uStack_3c4;
  undefined auStack_3bc [8];
  undefined auStack_3b4 [136];
  undefined4 auStack_32c [2];
  undefined auStack_324 [8];
  undefined auStack_31c [136];
  undefined4 uStack_294;
  undefined auStack_28c [8];
  undefined auStack_284 [136];
  undefined auStack_1fc [8];
  undefined4 uStack_1f4;
  int iStack_1f0;
  undefined4 uStack_1ec;
  undefined uStack_1d0;
  uint uStack_1cc;
  uint uStack_1c8;
  uint uStack_1c4;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined auStack_16c [24];
  undefined auStack_154 [24];
  undefined auStack_13c [28];
  undefined **appuStack_120 [2];
  undefined4 uStack_118;
  undefined **appuStack_100 [2];
  undefined4 *apuStack_f8 [6];
  undefined4 auStack_e0 [2];
  int iStack_d8;
  int *piStack_d4;
  undefined4 uStack_d0;
  int iStack_cc;
  undefined4 uStack_c8;
  undefined uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  int iStack_40;
  int *piStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  char *pcStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0209;
  pvStack_10 = ExceptionList;
  piStack_38 = (int *)0x0;
  puStack_14 = &stack0xfffffb00;
  pppuStack_504 = (undefined ***)0x782669;
  ExceptionList = &pvStack_10;
  pcStack_18 = (char *)(**(code **)(**(int **)(*param_1 + 0x3c) + 0x40))();
  pppuStack_504 = (undefined ***)0x18ceb4c;
  ppuStack_508 = (undefined4 **)0xb;
  ppuStack_50c = (undefined4 **)0x0;
  puStack_510 = (undefined *)0x78267d;
  iVar5 = FUN_00780cc0();
  if (iVar5 == 0) {
    if ((uint)param_1[0x3d] < DAT_01eb1bb4) {
      uStack_20 = 0x800;
      if (*(uint *)(pcStack_18 + 0x28) < 0x800) {
        uStack_20 = *(uint *)(pcStack_18 + 0x28);
      }
    }
    else {
      uStack_20 = *(uint *)(pcStack_18 + 0x28);
    }
  }
  else {
    uStack_20 = 0x200;
    if (pcStack_18[0x17] != '\0') {
      uStack_20 = 0x400;
    }
  }
  uStack_24 = uStack_20;
  if (*(uint *)(&DAT_01d60db4 + param_6 * 8) <= uStack_20) {
    uStack_24 = *(uint *)(&DAT_01d60db4 + param_6 * 8);
  }
  if (*(uint *)(&DAT_01d60db8 + param_6 * 8) <= uStack_20) {
    uStack_20 = *(uint *)(&DAT_01d60db8 + param_6 * 8);
  }
  uVar6 = 0x20;
  if (pcStack_18[0x12] != '\0') {
    uVar6 = 0;
  }
  uVar7 = 0;
  if (pcStack_18[0x38] != '\0') {
    uVar7 = 4;
  }
  uVar8 = 0x10;
  if (pcStack_18[0x11] != '\0') {
    uVar8 = 0;
  }
  uVar9 = 8;
  if (pcStack_18[0x18] != '\0') {
    uVar9 = 0;
  }
  uVar10 = 2;
  if (pcStack_18[0x17] != '\0') {
    uVar10 = 0;
  }
  param_5 = param_5 | (pcStack_18[0xf] == '\0') + 0x40 | uVar6 | uVar7 | uVar8 | uVar9 | uVar10;
  cVar4 = *pcStack_18;
  pcStack_18 = *(char **)(*param_1 + 0x594);
  if (cVar4 == '\0') {
    param_6 = 0;
  }
  else {
    param_6 = *(undefined4 *)(*param_1 + 0x3c);
  }
  pppuStack_504 = (undefined ***)&uStack_2c;
  ppuStack_508 = (undefined4 **)0x78275e;
  FUN_016830f0();
  uStack_8 = 0;
  if (DAT_01eb1bac != 0) {
    pppuStack_504 = (undefined ***)param_2;
    ppuStack_50c = (undefined4 **)(uint)DAT_01eb1bac;
    ppuStack_508 = (undefined4 **)0x18fc0cc;
    puStack_510 = (undefined *)0x782783;
    FUN_01677760();
  }
  pppuStack_504 = (undefined ***)0x18ceb4c;
  ppuStack_508 = (undefined4 **)0xb;
  ppuStack_50c = (undefined4 **)0x0;
  puStack_510 = (undefined *)0x782796;
  iVar5 = FUN_00780cc0();
  if (iVar5 != 0) {
    pppuStack_504 = (undefined ***)0x18fbdc0;
    ppuStack_508 = (undefined4 **)0x9;
    ppuStack_50c = (undefined4 **)0x0;
    puStack_510 = (undefined *)0x7827ae;
    iVar5 = FUN_00780cc0();
    if (iVar5 != 0) {
      pppuStack_504 = (undefined ***)param_2;
      ppuStack_508 = (undefined4 **)0x7827bc;
      cVar4 = FUN_007822f0();
      if (cVar4 == '\0') {
        pppuStack_504 = (undefined ***)0x18fc108;
                    /* WARNING: Subroutine does not return */
        ppuStack_508 = (undefined4 **)&UNK_00783447;
        FUN_016757c0();
      }
      piStack_1c = *(int **)(*param_1 + 0x518);
      if (piStack_1c != (int *)0x0) {
        param_1[0x2d] = param_1[0x2d] + 1;
        if (DAT_01d60d74 != '\0') {
          pppuStack_504 = (undefined ***)(param_1 + 0x21);
          ppuStack_508 = (undefined4 **)0x7827fc;
          FUN_005587b0();
          if (iStack_30 != 0) {
            LOCK();
            *(int *)(iStack_30 + 8) = *(int *)(iStack_30 + 8) + 1;
            UNLOCK();
          }
          uStack_1f4 = uStack_34;
          iStack_1f0 = iStack_30;
          pppuStack_504 = (undefined ***)param_2;
          uStack_8._0_1_ = 0x1a;
          uStack_1ec = param_6;
          ppuStack_508 = (undefined4 **)0x782843;
          FUN_0054ef60();
          uStack_1d0 = *(undefined *)(param_2 + 0x18);
          pppuStack_504 = (undefined ***)param_3;
          uStack_1cc = uStack_24;
          uStack_1c8 = uStack_20;
          uStack_8._0_1_ = 0x1b;
          ppuStack_508 = (undefined4 **)0x78287e;
          uStack_1c4 = param_5;
          FUN_0054ef60();
          pppuStack_504 = (undefined ***)(param_3 + 0x18);
          uStack_8._0_1_ = 0x1c;
          ppuStack_508 = (undefined4 **)0x782894;
          FUN_0054ef60();
          pppuStack_504 = (undefined ***)(param_3 + 0x30);
          uStack_8._0_1_ = 0x1d;
          ppuStack_508 = (undefined4 **)0x7828aa;
          FUN_0054ef60();
          uStack_178 = *(undefined4 *)(param_3 + 0x48);
          uStack_174 = uStack_2c;
          uStack_170 = uStack_28;
          pppuStack_504 = (undefined ***)(uint)*(byte *)(param_2 + 0x18);
          ppuStack_508 = (undefined4 **)auStack_154;
          uStack_8._0_1_ = 0x1e;
          ppuStack_50c = (undefined4 **)0x7828dd;
          uVar11 = FUN_00781ac0();
          uStack_8 = CONCAT31(uStack_8._1_3_,0x1f);
          if (DAT_01d60d9c == '\0') {
            cVar4 = *(char *)(param_2 + 0x18);
            if (cVar4 == '\0') {
              cVar4 = *(char *)(param_1 + 0x42);
            }
            pppuStack_504 = (undefined ***)CONCAT31((int3)((uint)uVar11 >> 8),cVar4);
            ppuStack_508 = (undefined4 **)auStack_16c;
            ppuStack_50c = (undefined4 **)0x782922;
            pppuStack_504 = (undefined ***)FUN_007818d0();
            bVar3 = false;
            bVar2 = true;
          }
          else {
            pppuStack_504 = (undefined ***)(uint)*(byte *)(param_2 + 0x18);
            ppuStack_508 = apuStack_f8;
            ppuStack_50c = (undefined4 **)0x7828fe;
            pppuStack_504 = (undefined ***)FUN_007818d0();
            bVar3 = true;
            bVar2 = false;
          }
          ppuStack_508 = (undefined4 **)0x782939;
          FUN_0054ef20();
          uStack_8 = 0x21;
          if (bVar2) {
            pppuStack_504 = (undefined ***)0x782958;
            FUN_005507b0();
          }
          uStack_8._0_1_ = 0x22;
          if (bVar3) {
            pppuStack_504 = (undefined ***)0x78296e;
            FUN_005507b0();
          }
          pppuStack_504 = (undefined ***)&uStack_1f4;
          ppuStack_508 = (undefined4 **)0x782980;
          FUN_0077d220();
          pppuStack_504 = (undefined ***)&uStack_d0;
          uStack_8._0_1_ = 0x23;
          ppuStack_508 = (undefined4 **)0x782996;
          FUN_0077d220();
          pppuStack_504 = (undefined ***)auStack_284;
          uStack_8._0_1_ = 0x24;
          appuStack_120[0] = (undefined **)0x0;
          ppuStack_508 = (undefined4 **)0x7829b6;
          FUN_0077d220();
          pppuStack_504 = (undefined ***)auStack_4e4;
          uStack_8._0_1_ = 0x25;
          ppuStack_508 = (undefined4 **)0x7829cc;
          FUN_0077d220();
          pppuStack_504 = (undefined ***)auStack_44c;
          uStack_8._0_1_ = 0x26;
          ppuStack_508 = (undefined4 **)0x7829e2;
          FUN_0077d220();
          pppuStack_504 = (undefined ***)auStack_31c;
          uStack_8._0_1_ = 0x27;
          ppuStack_508 = (undefined4 **)0x7829f2;
          cVar4 = FUN_00585a40();
          if (cVar4 == '\0') {
            pppuStack_504 = (undefined ***)auStack_31c;
            ppuStack_508 = (undefined4 **)0x782a0b;
            FUN_0077d220();
            pppuStack_504 = (undefined ***)0x88;
            uStack_8._0_1_ = 0x28;
            ppuStack_508 = (undefined4 **)0x782a19;
            iVar5 = FUN_01674e20();
            uStack_8._0_1_ = 0x29;
            if (iVar5 == 0) {
              uStack_118 = 0;
            }
            else {
              pppuStack_504 = (undefined ***)auStack_3b4;
              ppuStack_508 = (undefined4 **)0x782a35;
              uStack_118 = FUN_0077d220();
            }
            pppuStack_504 = (undefined ***)0x782a4a;
            FUN_0077efd0();
            pppuStack_504 = (undefined ***)0x782a55;
            FUN_0077efd0();
            bVar2 = true;
          }
          else {
            pppuStack_504 = (undefined ***)0x782a66;
            FUN_0077efd0();
            bVar2 = false;
          }
          pppuStack_504 = (undefined ***)0x782a75;
          FUN_0077efd0();
          appuStack_120[0] = &PTR_FUN_018fc584;
          if (!bVar2) {
            appuStack_120[0] = (undefined **)0x0;
          }
          pppuStack_504 = (undefined ***)0x782a93;
          FUN_0077efd0();
          pppuStack_504 = (undefined ***)0x782a9e;
          FUN_0077efd0();
          pppuStack_504 = (undefined ***)0x782aa9;
          FUN_0077efd0();
          ppuStack_50c = (undefined4 **)auStack_13c;
          pppuStack_504 = (undefined ***)0x1;
          ppuStack_508 = (undefined4 **)0x0;
          puStack_510 = auStack_154;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x2a);
          pppuStack_514 = appuStack_120;
          uStack_518 = param_4;
          iStack_51c = param_2;
          uStack_520 = 0x782ada;
          FUN_008cd330();
          pppuStack_504 = (undefined ***)0x782ae5;
          FUN_00550990();
          pppuStack_504 = (undefined ***)0x782af0;
          FUN_005507b0();
          pppuStack_504 = (undefined ***)0x782afb;
          FUN_005507b0();
          pppuStack_504 = (undefined ***)0x782b06;
          FUN_0077efd0();
          pppuStack_504 = (undefined ***)0x782b0e;
          FUN_0056c200();
          ExceptionList = pvStack_10;
          return 1;
        }
        piStack_3c = (int *)param_1[0x24];
        if (piStack_3c != (int *)0x0) {
          LOCK();
          *(int *)((int)piStack_3c + 8) = *(int *)((int)piStack_3c + 8) + 1;
          UNLOCK();
          piStack_3c = (int *)param_1[0x24];
        }
        iStack_40 = param_1[0x23];
        pppuStack_504 = (undefined ***)(param_1 + 0x21);
        ppuStack_508 = (undefined4 **)0x782b5b;
        iStack_30 = iStack_40;
        pcStack_18 = (char *)piStack_3c;
        FUN_005587b0();
        if (pcStack_18 != (char *)0x0) {
          LOCK();
          *(int *)((int)pcStack_18 + 8) = *(int *)((int)pcStack_18 + 8) + 1;
          UNLOCK();
        }
        iStack_d8 = iStack_30;
        piStack_d4 = (int *)pcStack_18;
        if (iStack_44 != 0) {
          LOCK();
          *(int *)(iStack_44 + 8) = *(int *)(iStack_44 + 8) + 1;
          UNLOCK();
        }
        uStack_d0 = uStack_48;
        iStack_cc = iStack_44;
        pppuStack_504 = (undefined ***)param_2;
        uStack_8._0_1_ = 0x2e;
        uStack_c8 = param_6;
        ppuStack_508 = (undefined4 **)0x782bd0;
        FUN_0054ef60();
        uStack_ac = CONCAT31(uStack_ac._1_3_,*(undefined *)(param_2 + 0x18));
        pppuStack_504 = (undefined ***)param_3;
        uStack_a8 = uStack_24;
        uStack_a4 = uStack_20;
        uStack_8._0_1_ = 0x2f;
        ppuStack_508 = (undefined4 **)0x782c0b;
        uStack_a0 = param_5;
        FUN_0054ef60();
        pppuStack_504 = (undefined ***)(param_3 + 0x18);
        uStack_8._0_1_ = 0x30;
        ppuStack_508 = (undefined4 **)0x782c1e;
        FUN_0054ef60();
        pppuStack_504 = (undefined ***)(param_3 + 0x30);
        uStack_8._0_1_ = 0x31;
        ppuStack_508 = (undefined4 **)0x782c31;
        FUN_0054ef60();
        uStack_54 = *(undefined4 *)(param_3 + 0x48);
        uStack_50 = uStack_2c;
        uStack_4c = uStack_28;
        pppuStack_504 = (undefined ***)(uint)*(byte *)(param_2 + 0x18);
        ppuStack_508 = (undefined4 **)auStack_13c;
        uStack_8._0_1_ = 0x32;
        ppuStack_50c = (undefined4 **)0x782c5b;
        uVar11 = FUN_00781ac0();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x33);
        if (DAT_01d60d9c == '\0') {
          cVar4 = *(char *)(param_2 + 0x18);
          if (cVar4 == '\0') {
            cVar4 = *(char *)(param_1 + 0x42);
          }
          pppuStack_504 = (undefined ***)CONCAT31((int3)((uint)uVar11 >> 8),cVar4);
          ppuStack_508 = apuStack_f8;
          ppuStack_50c = (undefined4 **)0x782ca0;
          pppuStack_504 = (undefined ***)FUN_007818d0();
          bVar3 = false;
          bVar2 = true;
        }
        else {
          pppuStack_504 = (undefined ***)(uint)*(byte *)(param_2 + 0x18);
          ppuStack_508 = (undefined4 **)auStack_16c;
          ppuStack_50c = (undefined4 **)0x782c7c;
          pppuStack_504 = (undefined ***)FUN_007818d0();
          bVar3 = true;
          bVar2 = false;
        }
        ppuStack_508 = (undefined4 **)0x782cb7;
        FUN_0054ef20();
        uStack_8 = 0x35;
        if (bVar2) {
          pppuStack_504 = (undefined ***)0x782cd6;
          FUN_005507b0();
        }
        uStack_8._0_1_ = 0x36;
        if (bVar3) {
          pppuStack_504 = (undefined ***)0x782cec;
          FUN_005507b0();
        }
        pppuStack_504 = (undefined ***)&iStack_d8;
        ppuStack_508 = (undefined4 **)0x782cfe;
        FUN_0077d310();
        pppuStack_504 = (undefined ***)auStack_1fc;
        uStack_8._0_1_ = 0x37;
        ppuStack_508 = (undefined4 **)0x782d14;
        FUN_0077d310();
        pppuStack_504 = (undefined ***)auStack_324;
        uStack_8._0_1_ = 0x38;
        appuStack_120[0] = (undefined **)0x0;
        ppuStack_508 = (undefined4 **)0x782d34;
        FUN_0077d310();
        pppuStack_504 = (undefined ***)auStack_3bc;
        uStack_8._0_1_ = 0x39;
        ppuStack_508 = (undefined4 **)0x782d4a;
        FUN_0077d310();
        pppuStack_504 = (undefined ***)auStack_454;
        uStack_8._0_1_ = 0x3a;
        ppuStack_508 = (undefined4 **)0x782d60;
        FUN_0077d310();
        pppuStack_504 = (undefined ***)auStack_28c;
        uStack_8._0_1_ = 0x3b;
        ppuStack_508 = (undefined4 **)0x782d70;
        cVar4 = FUN_00585a40();
        if (cVar4 == '\0') {
          pppuStack_504 = (undefined ***)auStack_28c;
          ppuStack_508 = (undefined4 **)0x782d89;
          FUN_0077d310();
          pppuStack_504 = (undefined ***)0x90;
          uStack_8._0_1_ = 0x3c;
          ppuStack_508 = (undefined4 **)0x782d97;
          iVar5 = FUN_01674e20();
          uStack_8._0_1_ = 0x3d;
          if (iVar5 == 0) {
            uStack_118 = 0;
          }
          else {
            pppuStack_504 = (undefined ***)auStack_4ec;
            ppuStack_508 = (undefined4 **)0x782db3;
            uStack_118 = FUN_0077d310();
          }
          pppuStack_504 = (undefined ***)0x782dc8;
          FUN_0077f040();
          pppuStack_504 = (undefined ***)0x782dd3;
          FUN_0077f040();
          bVar2 = true;
        }
        else {
          pppuStack_504 = (undefined ***)0x782de4;
          FUN_0077f040();
          bVar2 = false;
        }
        pppuStack_504 = (undefined ***)0x782df3;
        FUN_0077f040();
        appuStack_120[0] = &PTR_FUN_018fc58c;
        if (!bVar2) {
          appuStack_120[0] = (undefined **)0x0;
        }
        pppuStack_504 = (undefined ***)0x782e11;
        FUN_0077f040();
        pppuStack_504 = (undefined ***)0x782e1c;
        FUN_0077f040();
        pppuStack_504 = (undefined ***)0x782e27;
        FUN_0077f040();
        ppuStack_50c = (undefined4 **)auStack_154;
        pppuStack_504 = (undefined ***)0x1;
        ppuStack_508 = (undefined4 **)0x0;
        puStack_510 = auStack_13c;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x3e);
        pppuStack_514 = appuStack_120;
        uStack_518 = param_4;
        iStack_51c = param_2;
        uStack_520 = 0x782e58;
        FUN_008cd330();
        pppuStack_504 = (undefined ***)0x782e63;
        FUN_00550990();
        pppuStack_504 = (undefined ***)0x782e6e;
        FUN_005507b0();
        pppuStack_504 = (undefined ***)0x782e79;
        FUN_005507b0();
        pppuStack_504 = (undefined ***)0x782e84;
        FUN_0077f040();
        pppuStack_504 = (undefined ***)0x782e8c;
        FUN_0056c200();
        pppuStack_504 = (undefined ***)0x782e94;
        FUN_0056c200();
        ExceptionList = pvStack_10;
        return 1;
      }
      pppuStack_504 = (undefined ***)0x18fc0e0;
                    /* WARNING: Subroutine does not return */
      ppuStack_508 = (undefined4 **)0x78343d;
      FUN_016757c0();
    }
  }
  param_1[0x2d] = param_1[0x2d] + 1;
  if (DAT_01d60d74 == '\0') {
    pppuStack_504 = (undefined ***)uStack_28;
    ppuStack_508 = (undefined4 **)uStack_2c;
    piStack_38 = (int *)auStack_554;
    FUN_0054ef60();
    uStack_8._0_1_ = 0xd;
    FUN_0054ef60();
    uStack_8._0_1_ = 0xe;
    FUN_0054ef60();
    ppuStack_50c = *(undefined4 ***)(param_3 + 0x48);
    uStack_8._0_1_ = 0xf;
    FUN_0054ef60(param_2);
    if (param_1[0x22] != 0) {
      LOCK();
      piVar1 = (int *)(param_1[0x22] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 0;
    FUN_0077ccd0(auStack_32c,FUN_00783740,param_1[0x21],param_1[0x22],param_6);
    uStack_3c4 = auStack_32c[0];
    pppuStack_504 = (undefined ***)auStack_324;
    uStack_8._0_1_ = 0x10;
    ppuStack_508 = (undefined4 **)0x783208;
    FUN_0077d420();
    uStack_45c = uStack_3c4;
    pppuStack_504 = (undefined ***)auStack_3bc;
    uStack_8._0_1_ = 0x11;
    appuStack_100[0] = (undefined **)0x0;
    ppuStack_508 = (undefined4 **)0x783234;
    FUN_0077d420();
    uVar11 = uStack_45c;
    pppuStack_504 = (undefined ***)auStack_454;
    uStack_8._0_1_ = 0x12;
    ppuStack_508 = (undefined4 **)0x783256;
    FUN_0077d420();
    auStack_e0[0] = uVar11;
    pppuStack_504 = (undefined ***)auStack_4ec;
    uStack_8._0_1_ = 0x13;
    ppuStack_508 = (undefined4 **)0x783278;
    FUN_0077d420();
    pppuStack_504 = (undefined ***)auStack_e0;
    uStack_8._0_1_ = 0x14;
    ppuStack_508 = (undefined4 **)0x783288;
    cVar4 = FUN_00585a40();
    if (cVar4 == '\0') {
      uStack_294 = auStack_e0[0];
      pppuStack_504 = (undefined ***)&iStack_d8;
      ppuStack_508 = (undefined4 **)0x7832b1;
      FUN_0077d420();
      pppuStack_504 = (undefined ***)0x98;
      uStack_8._0_1_ = 0x15;
      ppuStack_508 = (undefined4 **)0x7832bf;
      apuStack_f8[0] = (undefined4 *)FUN_01674e20();
      uStack_8._0_1_ = 0x16;
      if (apuStack_f8[0] == (undefined4 *)0x0) {
        apuStack_f8[0] = (undefined4 *)0x0;
      }
      else {
        *apuStack_f8[0] = uStack_294;
        pppuStack_504 = (undefined ***)auStack_28c;
        ppuStack_508 = (undefined4 **)0x7832e6;
        FUN_0077d420();
      }
      pppuStack_504 = (undefined ***)0x7832fb;
      FUN_00637950();
      pppuStack_504 = (undefined ***)0x783306;
      FUN_0077f390();
      pppuStack_504 = (undefined ***)0x783311;
      FUN_00637950();
      pppuStack_504 = (undefined ***)0x78331c;
      FUN_0077f390();
      bVar2 = true;
    }
    else {
      pppuStack_504 = (undefined ***)0x78332d;
      FUN_00637950();
      pppuStack_504 = (undefined ***)0x783338;
      FUN_0077f390();
      bVar2 = false;
    }
    pppuStack_504 = (undefined ***)0x783347;
    FUN_00637950();
    pppuStack_504 = (undefined ***)0x783352;
    FUN_0077f390();
    appuStack_100[0] = &PTR_FUN_018fc574;
    if (!bVar2) {
      appuStack_100[0] = (undefined **)0x0;
    }
    pppuStack_504 = (undefined ***)0x783370;
    FUN_00637950();
    pppuStack_504 = (undefined ***)0x78337b;
    FUN_0077f390();
    pppuStack_504 = (undefined ***)0x783386;
    FUN_00637950();
    pppuStack_504 = (undefined ***)0x783391;
    FUN_0077f390();
    pppuStack_504 = (undefined ***)0x78339c;
    FUN_00637950();
    pppuStack_504 = (undefined ***)0x7833a7;
    FUN_0077f390();
    pppuStack_504 = appuStack_100;
    uStack_8._0_1_ = 0x17;
    ppuStack_508 = (undefined4 **)0x7833bd;
    FUN_0153c140();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
    if (((appuStack_100[0] != (undefined **)0x0) && (((uint)appuStack_100[0] & 1) == 0)) &&
       (*(code **)((uint)appuStack_100[0] & 0xfffffffe) != (code *)0x0)) {
      ppuStack_50c = apuStack_f8;
      pppuStack_504 = (undefined ***)0x2;
      puStack_510 = (undefined *)0x7833e4;
      ppuStack_508 = ppuStack_50c;
      (**(code **)((uint)appuStack_100[0] & 0xfffffffe))();
    }
  }
  else {
    piStack_d4 = (int *)param_1[0x22];
    if (piStack_d4 != (int *)0x0) {
      LOCK();
      piStack_d4[2] = piStack_d4[2] + 1;
      UNLOCK();
      piStack_d4 = (int *)param_1[0x22];
    }
    iStack_d8 = param_1[0x21];
    piStack_38 = &iStack_d8;
    if (piStack_d4 != (int *)0x0) {
      LOCK();
      piStack_d4[2] = piStack_d4[2] + 1;
      UNLOCK();
    }
    piStack_524 = (int *)param_2;
    uStack_8._0_1_ = 2;
    uStack_d0 = param_6;
    uStack_528 = 0x782f32;
    iStack_40 = iStack_d8;
    piStack_3c = piStack_d4;
    piStack_1c = piStack_d4;
    FUN_0054ef60();
    uStack_b4 = *(undefined *)(param_2 + 0x18);
    uStack_b0 = uStack_24;
    uStack_ac = uStack_20;
    piStack_524 = (int *)param_3;
    uStack_8._0_1_ = 3;
    uStack_a4 = (uint)pcStack_18;
    uStack_528 = 0x782f7b;
    uStack_a8 = param_5;
    FUN_0054ef60();
    piStack_524 = (int *)(param_3 + 0x18);
    uStack_8._0_1_ = 4;
    uStack_528 = 0x782f8e;
    FUN_0054ef60();
    piStack_524 = (int *)(param_3 + 0x30);
    uStack_8._0_1_ = 5;
    uStack_528 = 0x782f9e;
    FUN_0054ef60();
    uStack_58 = *(undefined4 *)(param_3 + 0x48);
    uStack_50 = uStack_2c;
    uStack_4c = uStack_28;
    piStack_524 = &iStack_d8;
    uStack_8._0_1_ = 6;
    uStack_528 = 0x782fc6;
    FUN_0077d130();
    piStack_524 = (int *)auStack_324;
    uStack_8._0_1_ = 7;
    uStack_528 = 0x782fe5;
    FUN_0077d130();
    piStack_524 = (int *)auStack_3bc;
    uStack_8._0_1_ = 8;
    uStack_528 = 0x782ffb;
    FUN_0077d130();
    piStack_524 = (int *)auStack_454;
    uStack_8._0_1_ = 9;
    uStack_528 = 0x783011;
    FUN_0077d130();
    piStack_524 = (int *)auStack_28c;
    uStack_8._0_1_ = 10;
    uStack_528 = 0x783021;
    cVar4 = FUN_00585a40();
    if (cVar4 == '\0') {
      piStack_524 = (int *)auStack_28c;
      uStack_528 = 0x78303a;
      FUN_0077d130();
      piStack_524 = (int *)0x90;
      uStack_8._0_1_ = 0xb;
      uStack_528 = 0x783048;
      iVar5 = FUN_01674e20();
      uStack_8._0_1_ = 0xc;
      if (iVar5 != 0) {
        piStack_524 = (int *)auStack_4ec;
        uStack_528 = 0x783064;
        FUN_0077d130();
      }
      piStack_524 = (int *)0x783076;
      FUN_0077ef60();
      piStack_524 = (int *)0x783081;
      FUN_0077ef60();
    }
    else {
      piStack_524 = (int *)0x783092;
      FUN_0077ef60();
    }
    piStack_524 = (int *)0x7830a1;
    FUN_0077ef60();
    piStack_524 = (int *)0x7830bb;
    FUN_0077ef60();
    piStack_524 = (int *)0x7830c6;
    FUN_0077ef60();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piStack_524 = (int *)0x7830d5;
    FUN_0077ef60();
    piStack_524 = (int *)0x7830da;
    FUN_0151ddd0();
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        pppuStack_504 = (undefined ***)0x7830fb;
        (**(code **)(*piStack_1c + 4))();
        ExceptionList = pvStack_10;
        return 1;
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 11134 ; VA 0x007833fc ; Catch@007833fc */

undefined * Catch_007833fc(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x120) + 4))();
  FUN_00784440(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0xc),uVar1);
  return &LAB_0078341e;
}



/* FUNCTION 11135 ; VA 0x00783450 ; FUN_00783450 */

void FUN_00783450(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10)

{
  undefined auStack_44 [32];
  undefined auStack_24 [16];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0228;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_016827e0(auStack_24);
  FUN_007d2110(auStack_44,param_10,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00783d70(param_1,param_2,param_3,param_6,param_7,param_8,param_9,auStack_24,auStack_44);
  FUN_0077f500();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11136 ; VA 0x007834db ; Catch@007834db */

undefined4 Catch_007834db(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))(*(undefined4 *)(unaff_EBP + 0x20));
  FUN_007835f0(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0x10),uVar1);
  return 0x7834ca;
}



/* FUNCTION 11137 ; VA 0x007834fb ; Catch@007834fb */

undefined4 Catch_007834fb(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))(*(undefined4 *)(unaff_EBP + 0x20));
  FUN_007835f0(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0x10),uVar1);
  return 0x7834ca;
}



/* FUNCTION 11138 ; VA 0x00783520 ; FUN_00783520 */

void FUN_00783520(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10)

{
  undefined auStack_44 [32];
  undefined auStack_24 [16];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0248;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_016827e0(auStack_24);
  FUN_007d2350(auStack_44,param_10,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00783d70(param_1,param_2,param_3,param_6,param_7,param_8,param_9,auStack_24,auStack_44);
  FUN_0077f500();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11139 ; VA 0x007835ab ; Catch@007835ab */

undefined4 Catch_007835ab(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))(*(undefined4 *)(unaff_EBP + 0x20));
  FUN_007835f0(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0x10),uVar1);
  return 0x78359a;
}



/* FUNCTION 11140 ; VA 0x007835cb ; Catch@007835cb */

undefined4 Catch_007835cb(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))(*(undefined4 *)(unaff_EBP + 0x20));
  FUN_007835f0(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0x10),uVar1);
  return 0x78359a;
}



/* FUNCTION 11141 ; VA 0x007835f0 ; FUN_007835f0 */

void FUN_007835f0(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined auStack_b8 [16];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined auStack_6c [16];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0273;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00784440(param_2,param_4,param_3);
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  auStack_b8[0] = 0;
  uStack_90 = 0;
  uStack_8c = 0xf;
  uStack_a0 = 0;
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = 0;
  uStack_5c = 0;
  uStack_58 = 0xf;
  auStack_6c[0] = 0;
  uStack_54 = 0;
  uStack_50 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if ((undefined4 *)auStack_6c != param_2) {
    puVar3 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar3 = (undefined4 *)*param_2;
    }
    FUN_005542c0(puVar3,param_2[4]);
  }
  uStack_54 = *(undefined *)(param_2 + 6);
  FUN_00777360(param_4);
  puVar1 = (uint *)(*param_1 + 0x14);
  do {
    LOCK();
    uVar2 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar2 & 1) != 0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00786430(auStack_b8);
  *puVar1 = 0;
  FUN_0077f560();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11142 ; VA 0x00783740 ; FUN_00783740 */

void FUN_00783740(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  undefined auStack_fc [184];
  undefined auStack_44 [24];
  int aiStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b029b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00781200(aiStack_2c,param_3,param_6);
  uStack_8 = 0;
  if (iStack_1c == 0) {
    FUN_007835f0(param_1,param_3,"File not found",param_7);
  }
  else {
    puVar1 = (undefined4 *)FUN_0151a8d0(auStack_44,aiStack_2c);
    uStack_8._0_1_ = 1;
    if (7 < (uint)puVar1[5]) {
      puVar1 = (undefined4 *)*puVar1;
    }
    FUN_0054ebd0(puVar1,0x21,0x40,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00550800();
    FUN_00783450(param_1,param_2,param_3,param_4,param_5,uStack_14,param_7,param_8,param_9,
                 auStack_fc);
    FUN_00551650();
  }
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11143 ; VA 0x00783850 ; FUN_00783850 */

void FUN_00783850(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 *param_9)

{
  FUN_00783520(param_1,param_2,param_3,param_4,param_5,1,param_6,param_7,param_8,*param_9);
  return;
}



/* FUNCTION 11144 ; VA 0x00783880 ; FUN_00783880 */

code * FUN_00783880(undefined4 param_1,undefined4 param_2,undefined4 param_3,char *param_4,
                   undefined4 *param_5,undefined4 param_6,int param_7,undefined4 param_8,
                   undefined4 param_9,int *param_10)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined auStack_198 [24];
  char cStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  int iStack_174;
  undefined auStack_170 [72];
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  int iStack_11c;
  int iStack_118;
  undefined auStack_114 [136];
  undefined4 uStack_8c;
  int *piStack_88;
  char *pcStack_84;
  char *pcStack_80;
  code **ppcStack_7c;
  code *apcStack_70 [2];
  char acStack_68 [24];
  int iStack_50;
  int *piStack_4c;
  int iStack_48;
  int *piStack_44;
  undefined *puStack_40;
  undefined *puStack_3c;
  undefined *puStack_38;
  undefined *puStack_34;
  undefined4 uStack_30;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b02eb;
  pvStack_1c = ExceptionList;
  ppcStack_7c = (code **)&iStack_50;
  pcStack_80 = (char *)0x7838bd;
  ExceptionList = &pvStack_1c;
  FUN_00587490();
  ppcStack_7c = (code **)&iStack_48;
  uStack_14 = 0;
  pcStack_80 = (char *)0x7838d0;
  pcVar3 = (code *)FUN_00587490();
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  if ((iStack_50 == 0) || (iStack_48 == 0)) {
    if (DAT_01eb1bac != 0) {
      if (0xf < *(uint *)(param_4 + 0x14)) {
        param_4 = *(char **)param_4;
      }
      pcStack_84 = (char *)(uint)DAT_01eb1bac;
      pcStack_80 = "Abandoning image %s because TextureManager is dead";
      piStack_88 = (int *)0x783a5d;
      ppcStack_7c = (code **)param_4;
      pcVar3 = (code *)FUN_01677650();
    }
  }
  else if (*param_10 == 0) {
    ppcStack_7c = (code **)param_7;
    piStack_88 = &iStack_48;
    pcStack_80 = "Request failed";
    pcStack_84 = param_4;
    uStack_8c = 0x783a34;
    pcVar3 = (code *)FUN_007835f0();
  }
  else {
    ppcStack_7c = (code **)0x0;
    puStack_34 = auStack_114;
    puStack_38 = (undefined *)&iStack_11c;
    uStack_30 = *param_5;
    uStack_24 = param_5[1];
    if (param_10[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_10[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iStack_11c = *param_10;
    iStack_118 = param_10[1];
    uStack_120 = param_9;
    uStack_124 = param_8;
    uStack_14._0_1_ = 2;
    puStack_3c = auStack_170;
    puStack_40 = auStack_170;
    iStack_174 = param_7;
    uStack_178 = 0x783957;
    FUN_0054ef60();
    iStack_174 = param_7 + 0x18;
    uStack_14._0_1_ = 3;
    uStack_178 = 0x783967;
    FUN_0054ef60();
    iStack_174 = param_7 + 0x30;
    uStack_14._0_1_ = 4;
    uStack_178 = 0x783977;
    FUN_0054ef60();
    uStack_128 = *(undefined4 *)(param_7 + 0x48);
    iStack_174 = param_6;
    uStack_178 = uStack_24;
    uStack_14._0_1_ = 5;
    uStack_17c = uStack_30;
    puStack_40 = auStack_198;
    FUN_0054ef60(param_4);
    cStack_180 = param_4[0x18];
    if (piStack_44 != (int *)0x0) {
      LOCK();
      piStack_44[1] = piStack_44[1] + 1;
      UNLOCK();
    }
    uStack_14._0_1_ = 1;
    FUN_0077caa0(puStack_34,FUN_00783850,iStack_48,piStack_44,param_3);
    iStack_118 = 0x7839ea;
    FUN_0077c0a0();
    ppcStack_7c = apcStack_70;
    uStack_14._0_1_ = 6;
    pcStack_80 = (char *)0x7839fa;
    FUN_0153c140();
    uStack_14 = CONCAT31(uStack_14._1_3_,7);
    pcVar3 = apcStack_70[0];
    if (((apcStack_70[0] != (code *)0x0) && (((uint)apcStack_70[0] & 1) == 0)) &&
       (pcVar3 = *(code **)((uint)apcStack_70[0] & 0xfffffffe), pcVar3 != (code *)0x0)) {
      pcStack_84 = acStack_68;
      ppcStack_7c = (code **)0x2;
      piStack_88 = (int *)0x783a1b;
      pcStack_80 = pcStack_84;
      pcVar3 = (code *)(*pcVar3)();
    }
  }
  if (piStack_44 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_44 + 1;
    iVar2 = *piVar1;
    pcVar3 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppcStack_7c = (code **)0x783a79;
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piStack_44 + 2;
      iVar2 = *piVar1;
      pcVar3 = (code *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppcStack_7c = (code **)0x783a89;
        pcVar3 = (code *)(**(code **)(*piStack_44 + 4))();
      }
    }
  }
  if (piStack_4c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_4c + 1;
    iVar2 = *piVar1;
    pcVar3 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppcStack_7c = (code **)0x783a9f;
      pcVar3 = (code *)(**(code **)*piStack_4c)();
      LOCK();
      piVar1 = piStack_4c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppcStack_7c = (code **)0x783aae;
        pcVar3 = (code *)(**(code **)(*piStack_4c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return pcVar3;
}



/* FUNCTION 11145 ; VA 0x00783ad0 ; FUN_00783ad0 */

code * FUN_00783ad0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
                   undefined4 *param_5,undefined4 param_6,int param_7,undefined4 param_8,
                   undefined4 param_9,int *param_10,int *param_11,int *param_12)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  code *pcVar4;
  undefined auStack_198 [24];
  undefined uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  int iStack_174;
  undefined auStack_170 [72];
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  int iStack_11c;
  int iStack_118;
  undefined auStack_114 [124];
  undefined4 uStack_98;
  int *piStack_94;
  undefined4 *puStack_90;
  undefined4 **ppuStack_8c;
  int iStack_88;
  undefined4 **ppuStack_84;
  undefined4 **ppuStack_80;
  code **ppcStack_7c;
  code *apcStack_70 [2];
  undefined4 **appuStack_68 [5];
  uint uStack_54;
  int iStack_50;
  int *piStack_4c;
  int iStack_48;
  int *piStack_44;
  undefined *puStack_40;
  undefined *puStack_3c;
  undefined *puStack_38;
  undefined *puStack_34;
  undefined4 uStack_30;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017b034e;
  pvStack_1c = ExceptionList;
  ppcStack_7c = (code **)&iStack_50;
  uStack_14 = 0;
  ppuStack_80 = (undefined4 **)0x783b14;
  ExceptionList = &pvStack_1c;
  FUN_00587490();
  ppcStack_7c = (code **)&iStack_48;
  ppuStack_80 = (undefined4 ***)0x783b20;
  pcVar4 = (code *)FUN_00587490();
  uStack_14._0_1_ = 2;
  if ((iStack_50 == 0) || (iStack_48 == 0)) {
    uVar3 = (undefined)uStack_14;
    if (DAT_01eb1bac != 0) {
      if (0xf < (uint)param_4[5]) {
        param_4 = (undefined4 *)*param_4;
      }
      ppuStack_84 = (undefined4 **)(uint)DAT_01eb1bac;
      ppuStack_80 = (undefined4 **)0x18fc078;
      iStack_88 = 0x783ce1;
      ppcStack_7c = (code **)param_4;
      pcVar4 = (code *)FUN_01677650();
      uVar3 = (undefined)uStack_14;
    }
  }
  else if (*param_10 == 0) {
    ppcStack_7c = (code **)0x783c82;
    ppcStack_7c = (code **)(**(code **)(*param_11 + 4))();
    ppuStack_84 = appuStack_68;
    ppuStack_80 = (undefined4 **)0x18fc118;
    iStack_88 = 0x783c91;
    FUN_01675640();
    iStack_88 = param_7;
    ppuStack_8c = appuStack_68;
    if (0xf < uStack_54) {
      ppuStack_8c = appuStack_68[0];
    }
    puStack_90 = param_4;
    piStack_94 = &iStack_48;
    uStack_14._0_1_ = 9;
    uStack_98 = 0x783cb0;
    FUN_007835f0();
    ppcStack_7c = (code **)0x783cbb;
    pcVar4 = (code *)FUN_005507b0();
    uVar3 = (undefined)uStack_14;
  }
  else {
    ppcStack_7c = (code **)0x0;
    puStack_34 = auStack_114;
    puStack_38 = (undefined *)&iStack_11c;
    uStack_30 = *param_5;
    uStack_24 = param_5[1];
    if (param_10[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_10[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iStack_11c = *param_10;
    iStack_118 = param_10[1];
    uStack_120 = param_9;
    uStack_124 = param_8;
    uStack_14._0_1_ = 3;
    puStack_3c = auStack_170;
    puStack_40 = auStack_170;
    iStack_174 = param_7;
    uStack_178 = 0x783ba7;
    FUN_0054ef60();
    iStack_174 = param_7 + 0x18;
    uStack_14._0_1_ = 4;
    uStack_178 = 0x783bb7;
    FUN_0054ef60();
    iStack_174 = param_7 + 0x30;
    uStack_14._0_1_ = 5;
    uStack_178 = 0x783bc7;
    FUN_0054ef60();
    uStack_128 = *(undefined4 *)(param_7 + 0x48);
    iStack_174 = param_6;
    uStack_178 = uStack_24;
    uStack_14._0_1_ = 6;
    uStack_17c = uStack_30;
    puStack_40 = auStack_198;
    FUN_0054ef60(param_4);
    uStack_180 = *(undefined *)(param_4 + 6);
    if (piStack_44 != (int *)0x0) {
      LOCK();
      piStack_44[1] = piStack_44[1] + 1;
      UNLOCK();
    }
    uStack_14._0_1_ = 2;
    FUN_0077caa0(puStack_34,FUN_00783850,iStack_48,piStack_44,param_3);
    iStack_118 = 0x783c3a;
    FUN_0077c0a0();
    ppcStack_7c = apcStack_70;
    uStack_14._0_1_ = 7;
    ppuStack_80 = (undefined4 ***)0x783c4a;
    FUN_0153c140();
    uStack_14._0_1_ = 8;
    uVar3 = (undefined)uStack_14;
    uStack_14._0_1_ = 8;
    pcVar4 = apcStack_70[0];
    if (((apcStack_70[0] != (code *)0x0) &&
        (uVar3 = (undefined)uStack_14, ((uint)apcStack_70[0] & 1) == 0)) &&
       (pcVar4 = *(code **)((uint)apcStack_70[0] & 0xfffffffe), pcVar4 != (code *)0x0)) {
      ppuStack_84 = appuStack_68;
      ppcStack_7c = (code **)0x2;
      iStack_88 = 0x783c73;
      ppuStack_80 = ppuStack_84;
      pcVar4 = (code *)(*pcVar4)();
      uVar3 = (undefined)uStack_14;
    }
  }
  uStack_14._0_1_ = uVar3;
  if (piStack_44 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_44 + 1;
    iVar2 = *piVar1;
    pcVar4 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppcStack_7c = (code **)0x783cfd;
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piStack_44 + 2;
      iVar2 = *piVar1;
      pcVar4 = (code *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppcStack_7c = (code **)0x783d0d;
        pcVar4 = (code *)(**(code **)(*piStack_44 + 4))();
      }
    }
  }
  if (piStack_4c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_4c + 1;
    iVar2 = *piVar1;
    pcVar4 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppcStack_7c = (code **)0x783d23;
      (**(code **)*piStack_4c)();
      LOCK();
      piVar1 = piStack_4c + 2;
      iVar2 = *piVar1;
      pcVar4 = (code *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppcStack_7c = (code **)0x783d33;
        pcVar4 = (code *)(**(code **)(*piStack_4c + 4))();
      }
    }
  }
  if (param_12 != (int *)0x0) {
    LOCK();
    piVar1 = param_12 + 1;
    iVar2 = *piVar1;
    pcVar4 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppcStack_7c = (code **)0x783d49;
      pcVar4 = (code *)(**(code **)*param_12)();
      LOCK();
      piVar1 = param_12 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppcStack_7c = (code **)0x783d58;
        pcVar4 = (code *)(**(code **)(*param_12 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return pcVar4;
}



/* FUNCTION 11146 ; VA 0x00783d70 ; FUN_00783d70 */

void FUN_00783d70(int *param_1,int param_2,undefined4 *param_3,uint param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,double *param_8,undefined4 *param_9)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined *puVar5;
  double *pdVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined auStack_e0 [8];
  undefined auStack_d8 [8];
  undefined auStack_d0 [4];
  int *piStack_cc;
  undefined auStack_c4 [16];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined uStack_ac;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined uStack_94;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined auStack_78 [16];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  undefined uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  double dStack_2c;
  double dStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0373;
  pvStack_10 = ExceptionList;
  uStack_b4 = 0;
  puStack_14 = &stack0xffffff14;
  uStack_b0 = 0xf;
  auStack_c4[0] = 0;
  uStack_9c = 0;
  uStack_98 = 0xf;
  uStack_ac = 0;
  uStack_84 = 0;
  uStack_80 = 0xf;
  uStack_94 = 0;
  uStack_68 = 0;
  uStack_64 = 0xf;
  auStack_78[0] = 0;
  uStack_60 = 0;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_54 = 0;
  uStack_50 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  piStack_40 = (int *)0x0;
  uStack_3c = 0;
  piStack_38 = (int *)0x0;
  uStack_34 = 0;
  uStack_30 = 0;
  dStack_2c = 0.0;
  dStack_24 = 0.0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = &stack0xffffff14;
  if ((undefined4 *)auStack_78 != param_3) {
    puVar7 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar7 = (undefined4 *)*param_3;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0(puVar7,param_3[4]);
    puVar5 = puStack_14;
  }
  puStack_14 = puVar5;
  uStack_60 = *(undefined *)(param_3 + 6);
  FUN_00773740(param_9 + 2);
  FUN_00777360(param_5);
  uStack_34 = param_6;
  uStack_30 = param_7;
  pdVar6 = (double *)FUN_016827e0(auStack_d8);
  piVar3 = piStack_40;
  uStack_5c = uStack_5c / param_4;
  uStack_58 = uStack_58 / param_4;
  dStack_2c = *pdVar6 - *param_8;
  if (param_2 == 0) {
    piVar8 = (int *)param_9[1];
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = (int *)param_9[1];
    }
    uStack_44 = *param_9;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_40[1] + -1;
      piStack_40[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puVar7 = (undefined4 *)*piStack_40;
        piStack_40 = piVar8;
        (*(code *)*puVar7)();
        LOCK();
        piVar8 = piVar3 + 2;
        iVar4 = *piVar8;
        *piVar8 = *piVar8 + -1;
        UNLOCK();
        piVar8 = piStack_40;
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
          piVar8 = piStack_40;
        }
      }
    }
  }
  else {
    FUN_016827e0(&uStack_1c);
    *(undefined4 *)param_8 = uStack_1c;
    *(undefined4 *)((int)param_8 + 4) = uStack_18;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puVar7 = (undefined4 *)FUN_00786d10(auStack_d0,param_2,*param_9,auStack_78);
    piVar8 = piStack_38;
    uStack_3c = *puVar7;
    piVar3 = (int *)puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_38[1] + -1;
      piStack_38[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puVar7 = (undefined4 *)*piStack_38;
        piStack_38 = piVar3;
        (*(code *)*puVar7)();
        LOCK();
        piVar3 = piVar8 + 2;
        iVar4 = *piVar3 + -1;
        *piVar3 = iVar4;
        UNLOCK();
        piVar3 = piStack_38;
        if (iVar4 == 0) {
          (**(code **)(*piVar8 + 4))();
          piVar3 = piStack_38;
        }
      }
    }
    piStack_38 = piVar3;
    if (piStack_cc != (int *)0x0) {
      LOCK();
      iVar4 = piStack_cc[1] + -1;
      piStack_cc[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_cc)();
        LOCK();
        piVar3 = piStack_cc + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_cc + 4))();
        }
      }
    }
    pdVar6 = (double *)FUN_016827e0(auStack_e0);
    dStack_24 = *pdVar6 - *param_8;
    uStack_8 = 0;
    piVar8 = piStack_40;
  }
  piStack_40 = piVar8;
  puVar1 = (uint *)(*param_1 + 0x14);
  do {
    LOCK();
    uVar2 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar2 & 1) != 0);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00786430(auStack_c4);
  *puVar1 = 0;
  FUN_0077f560();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11147 ; VA 0x00783f84 ; Catch@00783f84 */

undefined4 Catch_00783f84(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0xc4) + 4))(*(undefined4 *)(unaff_EBP + 0x18));
  FUN_007835f0(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0x10),uVar1);
  return 0x783f7b;
}



/* FUNCTION 11148 ; VA 0x00784040 ; FUN_00784040 */

undefined4 __thiscall
FUN_00784040(int *param_1,undefined4 param_2,undefined4 ****param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  char cVar4;
  uint uVar5;
  undefined4 ****ppppuVar6;
  undefined4 *puVar7;
  undefined *puVar8;
  int iVar9;
  bool bVar10;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  byte bStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar9 = (int)param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b03a1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  bStack_28 = *(byte *)(iVar9 + 0x18);
  uStack_8 = 0;
  if (*(int *)(*param_1 + 0x518) != 0) {
    FUN_008cc060(apppuStack_40);
  }
  iVar9 = (int)param_1 + *(byte *)(param_1 + 1) + 5;
  uVar5 = FUN_009cc8a0(apppuStack_40);
  FUN_0077cf60(&param_3,(uVar5 >> 2) + uVar5 * 0x40 + bStack_28 + 0x9e3779b9 ^ uVar5,apppuStack_40,
               -(uint)(iVar9 != 0) & iVar9 + 1U);
  iVar9 = (int)param_3;
  if (param_3 != (undefined4 ****)0x0) {
    if (*(char *)((int)param_3 + 0x5c) != '\0') {
      FUN_007868b0((int)param_3 + 0x24);
      puVar8 = &DAT_01eb1b04;
      if (*(undefined **)(iVar9 + 0x4c) != (undefined *)0x0) {
        puVar8 = *(undefined **)(iVar9 + 0x4c);
      }
      iVar9 = FUN_00781d30(puVar8);
      param_1[0x2f] = param_1[0x2f] + 1;
      param_1[0x30] = param_1[0x30] + iVar9;
    }
    FUN_007808a0(param_2,param_4);
    if (0xf < uStack_2c) {
      uVar5 = uStack_2c + 1;
      ppppuVar6 = (undefined4 ****)apppuStack_40[0];
      if (0xfff < uVar5) {
        ppppuVar6 = (undefined4 ****)apppuStack_40[0][-1];
        uVar5 = uStack_2c + 0x24;
        if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar6,uVar5);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  cVar4 = FUN_00782630(apppuStack_40,param_5,param_6,param_7,param_8);
  iVar9 = FUN_0077f7a0(apppuStack_40);
  param_3 = (undefined4 ****)(iVar9 + 0x1c);
  if (param_3 != apppuStack_40) {
    ppppuVar6 = apppuStack_40;
    if (0xf < uStack_2c) {
      ppppuVar6 = (undefined4 ****)apppuStack_40[0];
    }
    FUN_005542c0(ppppuVar6,uStack_30);
  }
  *(byte *)(iVar9 + 0x34) = bStack_28;
  bVar10 = cVar4 == '\0';
  if (bVar10) {
    puVar7 = (undefined4 *)FUN_007735a0(param_4,2);
  }
  else {
    puVar7 = (undefined4 *)FUN_00773a00(auStack_24,param_4);
  }
  uVar1 = *puVar7;
  uVar2 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *(undefined4 *)(iVar9 + 0x44) = uVar1;
  piVar3 = *(int **)(iVar9 + 0x48);
  *(undefined4 *)(iVar9 + 0x48) = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar9 = piVar3[1] + -1;
    piVar3[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar9 = piVar3[2] + -1;
      piVar3[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (bVar10) {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_18[1] + -1;
      piStack_18[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar9 = piStack_18[2] + -1;
        piStack_18[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  uStack_8 = 0;
  if ((!bVar10) && (piStack_20 != (int *)0x0)) {
    LOCK();
    iVar9 = piStack_20[1] + -1;
    piStack_20[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar3 = piStack_20 + 2;
      iVar9 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  FUN_007808a0(param_2,param_4);
  if (0xf < uStack_2c) {
    uVar5 = uStack_2c + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < uVar5) {
      ppppuVar6 = (undefined4 ****)apppuStack_40[0][-1];
      uVar5 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11149 ; VA 0x00784300 ; FUN_00784300 */

undefined4 __thiscall FUN_00784300(int param_1,undefined4 param_2,undefined4 param_3,char param_4)

{
  char cVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  undefined auStack_78 [16];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined uStack_60;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int aiStack_2c [5];
  uint uStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b03c0;
  pvStack_10 = ExceptionList;
  if (param_4 == '\x02') {
    iVar4 = 5;
  }
  else if (param_4 == '\x03') {
    iVar4 = 6;
  }
  else {
    iVar4 = 2;
  }
  uVar2 = *(undefined4 *)(param_1 + 0xfc);
  uStack_68 = 0;
  uStack_64 = 0xf;
  auStack_78[0] = 0;
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_60 = 0;
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = 0;
  cVar1 = *(char *)(param_1 + 0x108);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  cStack_14 = param_4;
  if ((DAT_01d60d9c != '\0') && (cStack_14 = param_4, param_4 == '\0')) {
    cStack_14 = cVar1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00784040(param_2,aiStack_2c,param_1 + 0x1c + iVar4 * 8,auStack_78,0x425c0000,0,uVar2);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    iVar4 = aiStack_2c[0];
    if (0xfff < uVar3) {
      iVar4 = *(int *)(aiStack_2c[0] + -4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar3);
  }
  FUN_00637950();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11150 ; VA 0x00784440 ; FUN_00784440 */

void FUN_00784440(char *param_1,int param_2,char *param_3)

{
  char cVar1;
  undefined4 uVar2;
  uint *puVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b041c;
  pvStack_10 = ExceptionList;
  uStack_44 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01eb1bac != '\0') {
    iStack_8 = 0;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    uStack_44 = 1;
    ExceptionList = &pvStack_10;
    FUN_0058a190(*(int *)(param_1 + 0x10) + 2);
    pcVar4 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcVar4 = *(char **)param_1;
    }
    FUN_00554150(pcVar4,*(undefined4 *)(param_1 + 0x10));
    FUN_00554150(&DAT_018bcaac,2);
    pcVar4 = param_3;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    puVar3 = (uint *)FUN_00554150(param_3,(int)pcVar4 - (int)(param_3 + 1));
    uStack_44 = 3;
    uStack_40 = *puVar3;
    uStack_3c = puVar3[1];
    uStack_38 = puVar3[2];
    uStack_34 = puVar3[3];
    uStack_30 = *(undefined8 *)(puVar3 + 4);
    puVar3[4] = 0;
    puVar3[5] = 0xf;
    *(undefined *)puVar3 = 0;
    iStack_8._0_1_ = 1;
    FUN_01677760(DAT_01eb1bac,"Image failed to load: %s",&uStack_40);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_30._4_4_) {
      uVar6 = uStack_30._4_4_ + 1;
      uVar5 = uStack_40;
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(uStack_40 - 4);
        uVar6 = uStack_30._4_4_ + 0x24;
        if (0x1f < (uStack_40 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uStack_30 = 0xf00000000;
    uStack_40 = uStack_40 & 0xffffff00;
    iStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar6 = uStack_14 + 1;
      uVar5 = auStack_28[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_28[0] - 4);
        uVar6 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  if (DAT_01d60dac != '\0') {
    FUN_0151f6f0(DAT_01eb1bc0,0,DAT_01eb1bc4);
    iStack_8 = 2;
    FUN_0151f950("AssetURL",param_1);
    FUN_0151f850("FailureMessage",param_3);
    FUN_0151f950("Context",param_2 + 0x18);
    FUN_0151f950("PropertyName",param_2 + 0x30);
    FUN_0151f950("GuidString",param_2);
    uVar2 = DAT_01eb1bc0;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("AssetLoadFailure",0x10);
    iStack_8._0_1_ = 3;
    FUN_01520d20(auStack_28,uVar2,0);
    iStack_8 = CONCAT31(iStack_8._1_3_,2);
    if (0xf < uStack_14) {
      uVar6 = uStack_14 + 1;
      uVar5 = auStack_28[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_28[0] - 4);
        uVar6 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    iStack_8 = 0xffffffff;
    FUN_0151f7f0();
  }
  uStack_4c = 0;
  uStack_48 = 0xf;
  auStack_5c[0] = auStack_5c[0] & 0xffffff00;
  pcVar4 = param_3;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_3,(int)pcVar4 - (int)(param_3 + 1));
  iStack_8 = 4;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    param_1 = *(char **)param_1;
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar4 = param_1;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_1,(int)pcVar4 - (int)(param_1 + 1));
  iStack_8._0_1_ = 5;
  uStack_30._0_4_ = 0;
  uStack_30._4_4_ = 0xf;
  uStack_40 = uStack_40 & 0xffffff00;
  FUN_005542c0("Image",5);
  iStack_8 = CONCAT31(iStack_8._1_3_,6);
  FUN_008d2350(&uStack_40,param_2,auStack_28,auStack_5c);
  if (0xf < uStack_30._4_4_) {
    uVar6 = uStack_30._4_4_ + 1;
    uVar5 = uStack_40;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(uStack_40 - 4);
      uVar6 = uStack_30._4_4_ + 0x24;
      if (0x1f < (uStack_40 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_30 = 0xf00000000;
  uStack_40 = uStack_40 & 0xffffff00;
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    uVar5 = auStack_28[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_28[0] - 4);
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_48) {
    uVar6 = uStack_48 + 1;
    uVar5 = auStack_5c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_5c[0] - 4);
      uVar6 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11151 ; VA 0x00784870 ; FUN_00784870 */

void FUN_00784870(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0442;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x90);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0077d000(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0077eec0();
        FUN_01674ea0(iVar2,0x90);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d9fe84);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_0899548184a8aea9a0ad42f01b826d56>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 11152 ; VA 0x007849c0 ; FUN_007849c0 */

void FUN_007849c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0442;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x90);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0077d130(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0077ef60();
        FUN_01674ea0(iVar2,0x90);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da0108);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_25ea55c6745f12d6c4dcb17145ae03c8>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 11153 ; VA 0x00784b10 ; FUN_00784b10 */

void FUN_00784b10(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0462;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x88);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0077d220(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0077efd0();
        FUN_01674ea0(iVar2,0x88);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d9fe4c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_863250a5f9f2757ab9dfd7278f09157e>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 11154 ; VA 0x00784c60 ; FUN_00784c60 */

void FUN_00784c60(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0442;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x90);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0077d310(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0077f040();
        FUN_01674ea0(iVar2,0x90);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d9fe14);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_8693c95342c37cefde36c89159ed22a1>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 11155 ; VA 0x00784db0 ; FUN_00784db0 */

void FUN_00784db0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0482;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar4 = (undefined4 *)FUN_01674e20(0x98);
      uStack_8 = 0;
      if (puVar4 != (undefined4 *)0x0) {
        *puVar4 = *puVar1;
        FUN_0077d630(puVar1 + 2);
        *param_2 = (int)puVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar5 = *param_2;
      if (iVar5 != 0) {
        piVar2 = *(int **)(iVar5 + 0x94);
        ExceptionList = &pvStack_10;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[1] + -1;
          ExceptionList = &pvStack_10;
          piVar2[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar3 = piVar2[2] + -1;
            piVar2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        FUN_00637950();
        FUN_0077f390();
        FUN_01674ea0(iVar5,0x98);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar5 = FUN_0170d8dd(*param_2 + 4,0x1d9fb1c);
      if (iVar5 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_rbx::safe_queue<struct_RBX::Graphics::TextureManager::LoadedImage>_>_const&,class_RBX::Graphics::Device*,struct_RBX::Graphics::TextureManager::Key_const&,struct_RBX::Graphics::TextureSizeRestrictions_const&,unsigned_int,class_RBX::InstanceIdentifier_const&,class_RBX::Time,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_const&),class_boost::_bi::list8<class_boost::_bi::value<class_std::shared_ptr<class_rbx::safe_queue<struct_RBX::Graphics::TextureManager::LoadedImage>_>_>,class_boost::_bi::value<class_RBX::Graphics::Device*>,class_boost::_bi::value<struct_RBX::Graphics::TextureManager::Key>,class_boost::_bi::value<struct_RBX::Graphics::TextureSizeRestrictions>,class_boost::_bi::value<unsigned_int>,class_boost::_bi::value<class_RBX::InstanceIdentifier>,class_boost::_bi::value<class_RBX::Time>,class_boost::_bi::value<class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 11156 ; VA 0x00784f40 ; FUN_00784f40 */

void FUN_00784f40(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0482;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x98);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_0077d420(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00637950();
        FUN_0077f390();
        FUN_01674ea0(iVar3,0x98);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d9febc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_rbx::safe_queue<struct_RBX::Graphics::TextureManager::LoadedImage>_>_const&,class_RBX::Graphics::Device*,struct_RBX::Graphics::TextureManager::Key_const&,struct_RBX::Graphics::TextureSizeRestrictions_const&,unsigned_int,float,class_RBX::InstanceIdentifier_const&,class_RBX::Time),class_boost::_bi::list8<class_boost::_bi::value<class_std::shared_ptr<class_rbx::safe_queue<struct_RBX::Graphics::TextureManager::LoadedImage>_>_>,class_boost::_bi::value<class_RBX::Graphics::Device*>,class_boost::_bi::value<struct_RBX::Graphics::TextureManager::Key>,class_boost::_bi::value<struct_RBX::Graphics::TextureSizeRestrictions>,class_boost::_bi::value<unsigned_int>,class_boost::_bi::value<float>,class_boost::_bi::value<class_RBX::InstanceIdentifier>,class_boost::_bi::value<class_RBX::Time>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 11157 ; VA 0x007850b0 ; FUN_007850b0 */

void FUN_007850b0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0xfc) = param_2;
  return;
}



/* FUNCTION 11158 ; VA 0x007850d0 ; FUN_007850d0 */

void __thiscall FUN_007850d0(int param_1,int param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  undefined *puVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  uint *puVar9;
  uint uVar10;
  uint auStack_54 [5];
  uint uStack_40;
  undefined auStack_3c [4];
  uint auStack_38 [4];
  undefined4 *puStack_28;
  uint uStack_24;
  undefined uStack_20;
  uint *puStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b04c2;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  puStack_1c = (uint *)(param_1 + 0xd8);
  iVar7 = param_1 + 5 + (uint)*(byte *)(param_1 + 4);
  ExceptionList = &pvStack_10;
  uVar3 = FUN_009cc8a0(puStack_1c);
  FUN_0077cf60(&puStack_14,
               uVar3 * 0x40 + (uint)*(byte *)(param_1 + 0xf0) + (uVar3 >> 2) + 0x9e3779b9 ^ uVar3,
               param_1 + 0xd8,-(uint)(iVar7 != 0) & iVar7 + 1U);
  puVar8 = puStack_14;
  if (param_2 != 0) {
    do {
      puVar8 = puStack_14;
      if (puStack_14 == (undefined4 *)0x0) {
        if (*(int *)(param_1 + 0xc) == 0) {
          puVar8 = (undefined4 *)0x0;
        }
        else {
          puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x18) + *(int *)(param_1 + 8) * 4);
        }
      }
      puVar1 = puVar8 + 9;
      FUN_00786920();
      if ((((*(char *)(puVar8 + 0x17) == '\0') && (puVar8[0x10] == puVar8[0x11])) &&
          (puVar8[0x13] != 0)) && (*(int *)(puVar8[0x13] + 8) == 3)) {
        *(undefined *)(puVar8 + 0x17) = 1;
        if (*(int *)(param_1 + 0xcc) == 0) {
          *(undefined4 **)(param_1 + 0xcc) = puVar1;
        }
        else {
          puVar8[0x15] = *(undefined4 *)(param_1 + 0xd0);
          *(undefined4 **)(*(int *)(param_1 + 0xd0) + 0x34) = puVar1;
        }
        *(undefined4 **)(param_1 + 0xd0) = puVar1;
        puVar5 = &DAT_01eb1b04;
        if ((undefined *)puVar8[0x13] != (undefined *)0x0) {
          puVar5 = (undefined *)puVar8[0x13];
        }
        iVar7 = FUN_00781d30(puVar5);
        *(int *)(param_1 + 0xbc) = *(int *)(param_1 + 0xbc) + -1;
        *(int *)(param_1 + 0xc0) = *(int *)(param_1 + 0xc0) - iVar7;
        *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + 1;
        *(int *)(param_1 + 200) = *(int *)(param_1 + 200) + iVar7;
      }
      param_2 = param_2 + -1;
      puStack_14 = (undefined4 *)*puVar8;
      puVar8 = puStack_14;
    } while (param_2 != 0);
  }
  if (puVar8 != (undefined4 *)0x0) {
    FUN_0054ef60(puVar8 + 2);
    auStack_3c[0] = *(undefined *)(puVar8 + 8);
    puVar9 = auStack_54;
    uVar3 = 2;
  }
  else {
    puStack_28 = puVar8;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    uStack_20 = 0;
    puVar9 = auStack_38;
    uVar3 = 1;
  }
  uStack_8 = (uint)(puVar8 != (undefined4 *)0x0);
  uStack_18 = uVar3;
  if (puStack_1c != puVar9) {
    puVar4 = puVar9;
    if (0xf < puVar9[5]) {
      puVar4 = (uint *)*puVar9;
    }
    FUN_005542c0(puVar4,puVar9[4]);
  }
  uVar2 = uStack_24;
  *(undefined *)(puStack_1c + 6) = *(undefined *)(puVar9 + 6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    if (0xf < uStack_40) {
      uVar6 = uStack_40 + 1;
      uVar10 = auStack_54[0];
      if (0xfff < uVar6) {
        uVar10 = *(uint *)(auStack_54[0] - 4);
        uVar6 = uStack_40 + 0x24;
        if (0x1f < (auStack_54[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar6);
    }
  }
  if (((uVar3 & 1) != 0) && (0xf < uVar2)) {
    uVar10 = uVar2 + 1;
    uVar3 = auStack_38[0];
    if (0xfff < uVar10) {
      uVar3 = *(uint *)(auStack_38[0] - 4);
      uVar10 = uVar2 + 0x24;
      if (0x1f < (auStack_38[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11159 ; VA 0x00785300 ; FUN_00785300 */

undefined4 __thiscall FUN_00785300(int *param_1,int param_2)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017b04d8;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)(param_1 + 5);
  ExceptionList = &pvStack_10;
  do {
    LOCK();
    uVar2 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
    uStack_8 = (uint)((uVar2 & 1) != 0);
  } while (uStack_8 != 0);
  if (param_1[4] == 0) {
    uVar6 = 0;
  }
  else {
    puVar4 = (undefined4 *)*param_1;
    if (puVar4 != (undefined4 *)0x0) {
      puVar4 = (undefined4 *)*puVar4;
    }
    iVar3 = *(int *)(puVar4[1] + (puVar4[2] - 1 & param_1[3]) * 4);
    FUN_00777360(iVar3);
    piVar5 = (int *)(iVar3 + 0x4c);
    if ((int *)(param_2 + 0x4c) != piVar5) {
      if (0xf < *(uint *)(iVar3 + 0x60)) {
        piVar5 = (int *)*piVar5;
      }
      FUN_005542c0(piVar5,*(undefined4 *)(iVar3 + 0x5c));
    }
    *(undefined *)(param_2 + 100) = *(undefined *)(iVar3 + 100);
    FUN_00773740(iVar3 + 0x68);
    iVar7 = *(int *)(iVar3 + 0x84);
    if (iVar7 != 0) {
      LOCK();
      *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
      UNLOCK();
      iVar7 = *(int *)(iVar3 + 0x84);
    }
    *(undefined4 *)(param_2 + 0x80) = *(undefined4 *)(iVar3 + 0x80);
    piVar5 = *(int **)(param_2 + 0x84);
    *(int *)(param_2 + 0x84) = iVar7;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar7 = piVar5[1] + -1;
      piVar5[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar7 = piVar5[2] + -1;
        piVar5[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    iVar7 = *(int *)(iVar3 + 0x8c);
    if (iVar7 != 0) {
      LOCK();
      *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
      UNLOCK();
      iVar7 = *(int *)(iVar3 + 0x8c);
    }
    *(undefined4 *)(param_2 + 0x88) = *(undefined4 *)(iVar3 + 0x88);
    piVar5 = *(int **)(param_2 + 0x8c);
    *(int *)(param_2 + 0x8c) = iVar7;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar7 = piVar5[1] + -1;
      piVar5[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar7 = piVar5[2] + -1;
        piVar5[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    *(undefined4 *)(param_2 + 0x90) = *(undefined4 *)(iVar3 + 0x90);
    *(undefined4 *)(param_2 + 0x94) = *(undefined4 *)(iVar3 + 0x94);
    *(undefined4 *)(param_2 + 0x98) = *(undefined4 *)(iVar3 + 0x98);
    *(undefined4 *)(param_2 + 0x9c) = *(undefined4 *)(iVar3 + 0x9c);
    *(undefined4 *)(param_2 + 0xa0) = *(undefined4 *)(iVar3 + 0xa0);
    *(undefined4 *)(param_2 + 0xa4) = *(undefined4 *)(iVar3 + 0xa4);
    FUN_0077f560();
    piVar5 = param_1 + 4;
    *piVar5 = *piVar5 + -1;
    if (*piVar5 == 0) {
      param_1[3] = 0;
      uVar6 = 1;
    }
    else {
      param_1[3] = param_1[3] + 1;
      uVar6 = 1;
    }
  }
  *puVar1 = 0;
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 11160 ; VA 0x00785500 ; FUN_00785500 */

/* WARNING: Removing unreachable block (ram,0x00785569) */
/* WARNING: Removing unreachable block (ram,0x00785577) */
/* WARNING: Removing unreachable block (ram,0x00785ba7) */
/* WARNING: Removing unreachable block (ram,0x0078558b) */

void __thiscall FUN_00785500(int param_1,int param_2,int param_3)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  undefined4 *puVar8;
  double dVar9;
  double dVar10;
  undefined8 uVar11;
  undefined8 uStack_58;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  uint uStack_3c;
  uint uStack_38;
  int iStack_34;
  uint *puStack_30;
  int iStack_2c;
  uint uStack_28;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0513;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  FUN_005542c0("TextureManager::ReloadTextureMemoryPrioritization",0x31);
  uStack_8 = 0;
  FUN_00d102b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iStack_40 = *(int *)(param_1 + 0xc0);
  if (DAT_01eb1bad != '\0') {
    FUN_01677520(DAT_01eb1bad,
                 "void TextureManager::processMemoryPrioritizationChange() currentMemoryPressureLevel: %d level: %d liveSize: %u"
                 ,param_2,param_3,iStack_40);
  }
  uVar2 = *(uint *)(&DAT_018fbb70 + param_3 * 4);
  uStack_24 = 0;
  iStack_14 = 0;
  iStack_34 = 0;
  iStack_50 = 0;
  iStack_4c = 0;
  iStack_48 = 0;
  iStack_44 = 0;
  if (*(int *)(param_1 + 0xc) == 0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x18) + *(int *)(param_1 + 8) * 4);
  }
  do {
    if (puVar8 == (undefined4 *)0x0) {
LAB_00785a1b:
      iVar5 = *(int *)(param_1 + 0x104) + 1;
      *(int *)(param_1 + 0x104) = iVar5;
      if (iStack_14 == 0) {
        if (DAT_01eb1bad != '\0') {
          FUN_01677520(DAT_01eb1bad,
                       "TextureManager::MemoryPrioritizationState changed to None currentLevel: %u newLevel: %u numFramesTaken: %u"
                       ,param_2,param_3,iVar5);
        }
        *(undefined4 *)(param_1 + 0xf8) = *(undefined4 *)(param_1 + 0xfc);
        *(undefined4 *)(param_1 + 0x100) = 0;
      }
      if (DAT_01eb1bad != '\0') {
        FUN_01677520();
      }
      uStack_58 = DAT_018d0930;
      dVar9 = ((double)iStack_40 + (double)(&DAT_018c0d90)[-(iStack_40 >> 0x1f)]) * DAT_018d0930;
      dVar10 = ((double)*(int *)(param_1 + 0xc0) +
               (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 0xc0) >> 0x1f)]) * DAT_018d0930;
      if ((DAT_01eb1bad != '\0') &&
         (FUN_01677520(DAT_01eb1bad,
                       "\t==== liveSize: %.2fMB finalLiveSize: %.2fMB delta: %.2fMB (currentMemoryPressureLevel: %d level: %d liveCount: %u)"
                       ,dVar9,dVar10,dVar9 - dVar10,param_2,param_3,*(undefined4 *)(param_1 + 0xbc))
         , DAT_01eb1bad != '\0')) {
        FUN_01677520();
      }
      FUN_00637950();
      ExceptionList = pvStack_10;
      return;
    }
    uStack_18 = (uint)(puVar8 + 9);
    if (0xf < (uint)puVar8[0xe]) {
      uStack_18 = *(uint *)uStack_18;
    }
    piStack_1c = (int *)puVar8[0x13];
    if (piStack_1c == (int *)0x0) {
      puStack_30 = &DAT_01eb1b0c;
      piStack_1c = (int *)&DAT_01eb1b04;
    }
    else {
      puStack_30 = (uint *)(piStack_1c + 3);
    }
    piVar7 = (int *)piStack_1c[1];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      piVar7 = (int *)piStack_1c[1];
    }
    piStack_1c = (int *)*piStack_1c;
    uStack_58 = (double)CONCAT44(piVar7,piStack_1c);
    uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
    uStack_8._0_1_ = 3;
    if (piStack_1c == (int *)0x0) {
      if (DAT_01eb1bad != '\0') {
        FUN_01677520();
      }
LAB_007859a8:
      if (uVar2 <= uStack_24) {
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        param_1 = iStack_20;
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar5 = piVar7[1] + -1;
          piVar7[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar5 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            param_1 = iStack_20;
            if (iVar5 == 1) {
              (**(code **)(*piVar7 + 4))();
              param_1 = iStack_20;
            }
          }
        }
        goto LAB_00785a1b;
      }
    }
    else {
      FUN_00780cc0(0,0xb,"rbxasset://");
      FUN_01675290();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      cVar3 = FUN_0147d280(piStack_1c[0xb]);
      if (cVar3 == '\0') {
        uStack_38 = *(uint *)(&DAT_01d60db8 + param_3 * 8);
      }
      else {
        uStack_38 = *(uint *)(&DAT_01d60db4 + param_3 * 8);
      }
      iStack_2c = FUN_00781d30();
      cVar3 = FUN_0147d280(piStack_1c[0xb]);
      if (cVar3 == '\0') {
        iStack_48 = iStack_48 + 1;
        iStack_44 = iStack_44 + iStack_2c;
      }
      else {
        iStack_50 = iStack_50 + 1;
        iStack_4c = iStack_4c + iStack_2c;
      }
      if (DAT_01eb1bad != '\0') {
        uVar4 = 0x55;
        if (cVar3 != '\0') {
          uVar4 = 0x43;
        }
        FUN_01677520(DAT_01eb1bad,
                     "[%4d] %4ux%4ux%4u mips: %2u format %2d %c (%4dx%4d) size: %u %32s",iStack_34,
                     piStack_1c[0xc],piStack_1c[0xd],piStack_1c[0xe],piStack_1c[0xf],piStack_1c[0xb]
                     ,uVar4,*puStack_30,puStack_30[1],iStack_2c);
      }
      if ((puVar8[0x13] == 0) || (*(int *)(puVar8[0x13] + 8) != 3)) {
        if (DAT_01eb1bad != '\0') {
          FUN_01677520(DAT_01eb1bad,"\tWARNING: Texture is not loaded %u");
        }
        uStack_8._0_1_ = 5;
        FUN_01675290();
      }
      else {
        if (*(char *)(puVar8 + 0x17) == '\0') {
          if (param_3 < param_2) {
            if ((DAT_01d60d8c != '\0') &&
               (((uint)piStack_1c[0xc] < *puStack_30 || ((uint)piStack_1c[0xd] < puStack_30[1])))) {
              iVar5 = FUN_00781b10(&uStack_58);
              uStack_24 = uStack_24 + iVar5;
              iStack_14 = iStack_14 + 1;
              FUN_00786710();
              if (DAT_01eb1bad != '\0') {
                uVar11 = 0x18fc27c;
LAB_0078593f:
                FUN_016774b0(DAT_01eb1bad,uVar11);
              }
            }
          }
          else if ((1 < (uint)piStack_1c[0xf]) &&
                  (((uVar6 = piStack_1c[0xc], uStack_38 < uVar6 ||
                    (uStack_38 < (uint)piStack_1c[0xd])) || (uStack_38 < (uint)piStack_1c[0xe])))) {
            uStack_3c = piStack_1c[0xd];
            uStack_28 = piStack_1c[0xe];
            uStack_18 = 0;
            for (; ((uStack_38 < uVar6 || (uStack_38 < uStack_3c)) || (uStack_38 < uStack_28));
                uStack_28 = uStack_28 >> 1) {
              uStack_18 = uStack_18 + 1;
              uStack_3c = uStack_3c >> 1;
              uVar6 = uVar6 >> 1;
            }
            uVar6 = piStack_1c[0xf] - 1;
            if (uStack_18 < (uint)piStack_1c[0xf]) {
              uVar6 = uStack_18;
            }
            uStack_18 = uVar6;
            cVar3 = (**(code **)(*piStack_1c + 0x30))();
            if ((cVar3 == '\0') || (cVar3 = (**(code **)(*piStack_1c + 0x34))(), cVar3 == '\0')) {
              if ((DAT_01d60d84 != '\0') && (DAT_01d60d94 != '\0')) {
                iVar5 = FUN_00781b10(&uStack_58);
                uStack_24 = uStack_24 + iVar5;
                iStack_14 = iStack_14 + 1;
                FUN_00786710();
                if (DAT_01eb1bad != '\0') {
                  uVar11 = 0x18fc320;
                  goto LAB_0078593f;
                }
              }
            }
            else {
              uStack_28 = FUN_00781d30();
              uStack_24 = uStack_24 + uStack_28;
              iStack_14 = iStack_14 + 1;
              *(int *)(iStack_20 + 0xc0) = *(int *)(iStack_20 + 0xc0) + (uStack_28 - iStack_2c);
              if (DAT_01eb1bad != '\0') {
                uVar4 = FUN_0147d0e0(piStack_1c[0xc],piStack_1c[0xd]);
                FUN_01677520(DAT_01eb1bad,
                             "\t--- Reduced texture using GPU downscaling --- %ux%ux%u mips: %u/%u totalRemoved: %u size: %u diff: %u"
                             ,piStack_1c[0xc],piStack_1c[0xd],piStack_1c[0xe],piStack_1c[0xf],uVar4,
                             uStack_18,uStack_28,iStack_2c - uStack_28);
              }
            }
          }
          uStack_8._0_1_ = 7;
          FUN_01675290();
          goto LAB_007859a8;
        }
        if (DAT_01eb1bad != '\0') {
          FUN_016774b0(DAT_01eb1bad,"\tINFO: Skipping orphaned texture");
        }
        uStack_8._0_1_ = 6;
        FUN_01675290();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar5 = piVar7[1] + -1;
      piVar7[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar5 = piVar7[2] + -1;
        piVar7[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    puVar8 = (undefined4 *)*puVar8;
    iStack_34 = iStack_34 + 1;
    param_1 = iStack_20;
  } while( true );
}



/* FUNCTION 11161 ; VA 0x00785bb0 ; FUN_00785bb0 */

void __fastcall FUN_00785bb0(int *param_1)

{
  undefined4 *puVar1;
  undefined *puVar2;
  char cVar3;
  uint uVar4;
  int *piVar5;
  double *pdVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int iVar10;
  int iVar11;
  undefined8 uVar12;
  undefined auStack_13c [8];
  undefined auStack_134 [8];
  double dStack_12c;
  double dStack_124;
  undefined auStack_11c [4];
  int *piStack_118;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined auStack_100 [16];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined uStack_d0;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined auStack_b4 [16];
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  byte bStack_9c;
  int iStack_98;
  int iStack_94;
  undefined4 uStack_90;
  undefined uStack_8c;
  int iStack_88;
  undefined4 uStack_84;
  int iStack_80;
  undefined4 uStack_7c;
  int iStack_78;
  int *piStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  int iStack_58;
  int *piStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  double dStack_38;
  undefined8 uStack_30;
  int iStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0553;
  pvStack_10 = ExceptionList;
  iVar11 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  puStack_14 = &stack0xfffffeb8;
  ExceptionList = &pvStack_10;
  piStack_20 = param_1;
  piStack_18 = param_1;
  puVar2 = &stack0xfffffeb8;
  if ((*(int *)(iVar11 + 0x34) < DAT_01eb1c20) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1c20), puVar2 = puStack_14,
     DAT_01eb1c20 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","TextureManager::processPendingRequests",0xffffffff);
    DAT_01eb1c1c = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb1c18 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb1c20);
    puVar2 = puStack_14;
  }
  puStack_14 = puVar2;
  uStack_48 = DAT_01eb1c18;
  uStack_44 = DAT_01eb1c1c;
  uStack_40 = FUN_0152d930(DAT_01eb1c18,DAT_01eb1c1c);
  uStack_8 = 1;
  FUN_016827e0(&dStack_12c);
  uStack_50 = CONCAT44(uStack_50._4_4_,(undefined4)uStack_50);
  if ((DAT_01d60d7c != '\0') &&
     ((param_1[0x3f] != param_1[0x3e] ||
      (uStack_50 = CONCAT44(uStack_50._4_4_,(undefined4)uStack_50), param_1[0x40] != 0)))) {
    if (*(int *)(iVar11 + 0x34) < DAT_01eb1c30) {
      FUN_016f3809(&DAT_01eb1c30);
      if (DAT_01eb1c30 == -1) {
        uStack_8._0_1_ = 2;
        uVar12 = FUN_0152dab0("Render","TextureManager::processMemoryPrioritizationChange",
                              0xffffffff);
        DAT_01eb1c2c = (int *)((ulonglong)uVar12 >> 0x20);
        DAT_01eb1c28 = (int)uVar12;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01eb1c30);
      }
    }
    iStack_24 = DAT_01eb1c28;
    iStack_58 = DAT_01eb1c28;
    piStack_1c = DAT_01eb1c2c;
    piStack_54 = DAT_01eb1c2c;
    uStack_50 = FUN_0152d930(DAT_01eb1c28,DAT_01eb1c2c);
    iVar11 = param_1[0x3f];
    iVar10 = param_1[0x3e];
    uStack_8._0_1_ = 3;
    if ((iVar11 != iVar10) && (param_1[0x40] == 0)) {
      if (DAT_01eb1bad != '\0') {
        FUN_01677520(DAT_01eb1bad,
                     "TextureManager::MemoryPrioritizationState changed to ModifyingTextures currentLevel: %u newLevel: %u "
                     ,iVar10,iVar11);
        iVar10 = param_1[0x3e];
        iVar11 = param_1[0x3f];
      }
      param_1[0x40] = 1;
      param_1[0x41] = 0;
    }
    FUN_00785500(iVar10,iVar11);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_0152dda0(iStack_24,piStack_1c,uStack_50);
  }
  uStack_f0 = 0;
  uStack_ec = 0xf;
  auStack_100[0] = 0;
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  uStack_e8 = 0;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  uStack_d0 = 0;
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  auStack_b4[0] = 0;
  bStack_9c = 0;
  iStack_98 = 0;
  iStack_94 = 0;
  uStack_90 = 0;
  uStack_8c = 0;
  iStack_88 = 0;
  uStack_84 = 0;
  iStack_80 = 0;
  uStack_7c = 0;
  iStack_78 = 0;
  piStack_74 = (int *)0x0;
  uStack_70 = 0;
  uStack_6c = 0;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0.0;
  uStack_8._0_1_ = 5;
  dStack_38 = DAT_018c0d70;
  do {
    do {
      do {
        cVar3 = FUN_00785300(auStack_100);
        if (cVar3 == '\0') goto LAB_00786351;
        iVar11 = (int)param_1 + *(byte *)(param_1 + 1) + 5;
        uVar4 = FUN_009cc8a0(auStack_b4);
        FUN_0077cf60(&iStack_24,uVar4 * 0x40 + (uint)bStack_9c + (uVar4 >> 2) + 0x9e3779b9 ^ uVar4,
                     auStack_b4,-(uint)(iVar11 != 0) & iVar11 + 1U);
        piVar8 = piStack_18;
        iVar11 = iStack_24;
        param_1 = piStack_18;
      } while (iStack_24 == 0);
      iStack_28 = iStack_24 + 0x24;
      piStack_1c = (int *)(iStack_24 + 0x4c);
      uStack_30 = (double)CONCAT44(piStack_1c,(undefined4)uStack_30);
      if ((*piStack_1c != 0) && (*(int *)(*piStack_1c + 8) == 1)) {
        piStack_18[0x2d] = piStack_18[0x2d] + -1;
      }
      if (iStack_80 == 0) {
        if (iStack_78 != 0) goto LAB_00786008;
        uVar4 = 0;
        if (*(int *)(iStack_24 + 0x44) - *(int *)(iStack_24 + 0x40) >> 3 != 0) {
          do {
            FUN_00773c00();
            uVar4 = uVar4 + 1;
          } while (uVar4 < (uint)(*(int *)(iVar11 + 0x44) - *(int *)(iVar11 + 0x40) >> 3));
        }
        FUN_00773c00();
      }
      else {
        if (iStack_78 == 0) {
          FUN_016827e0(&dStack_124);
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          piVar5 = (int *)FUN_00786d10(auStack_11c,*(undefined4 *)(*piVar8 + 0x3c),iStack_80,
                                       auStack_b4);
          piVar7 = piStack_74;
          iStack_78 = *piVar5;
          piVar8 = (int *)piVar5[1];
          *piVar5 = 0;
          piVar5[1] = 0;
          if (piStack_74 != (int *)0x0) {
            LOCK();
            iVar11 = piStack_74[1] + -1;
            piStack_74[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              puVar1 = (undefined4 *)*piStack_74;
              piStack_74 = piVar8;
              (*(code *)*puVar1)();
              LOCK();
              piVar8 = piVar7 + 2;
              iVar11 = *piVar8 + -1;
              *piVar8 = iVar11;
              UNLOCK();
              piVar8 = piStack_74;
              if (iVar11 == 0) {
                (**(code **)(*piVar7 + 4))();
                piVar8 = piStack_74;
              }
            }
          }
          piStack_74 = piVar8;
          if (piStack_118 != (int *)0x0) {
            LOCK();
            iVar11 = piStack_118[1] + -1;
            piStack_118[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piStack_118)();
              LOCK();
              iVar11 = piStack_118[2] + -1;
              piStack_118[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piStack_118 + 4))();
              }
            }
          }
          pdVar6 = (double *)FUN_016827e0(auStack_134);
          uStack_60 = *pdVar6 - dStack_124;
          FUN_00785fc6();
          return;
        }
LAB_00786008:
        pdVar6 = (double *)FUN_016830f0(auStack_13c);
        uStack_30 = *pdVar6 - (double)CONCAT44(uStack_6c,uStack_70);
        uStack_108 = (undefined4)uStack_60;
        uStack_104 = uStack_60._4_4_;
        uStack_110 = uStack_68;
        uStack_10c = uStack_64;
        if (DAT_01eb1bac != '\0') {
          FUN_01677760(DAT_01eb1bac,"Image loaded from %s",auStack_b4);
        }
        iVar10 = *(int *)(iStack_78 + 0x30);
        if ((iVar10 == iStack_98) && (*(int *)(iStack_78 + 0x34) == iStack_94)) {
          if (DAT_01eb1bac != '\0') {
            FUN_01677490(DAT_01eb1bac,"Image dimensions: %dx%d format %d",iVar10,
                         *(undefined4 *)(iStack_78 + 0x34),*(undefined4 *)(iStack_78 + 0x2c));
LAB_007860cd:
            if (DAT_01eb1bac != '\0') {
              FUN_01677490(DAT_01eb1bac,"Image timings: decode %d ms, upload %d ms, latency %d ms",
                           (int)((double)CONCAT44(uStack_10c,uStack_110) * dStack_38),
                           (int)((double)CONCAT44(uStack_104,uStack_108) * dStack_38),
                           (int)(uStack_30 * dStack_38));
            }
          }
        }
        else if (DAT_01eb1bac != '\0') {
          FUN_016773b0(DAT_01eb1bac,"Image dimensions: %dx%d format %d (scaled from %dx%d)",iVar10,
                       *(undefined4 *)(iStack_78 + 0x34),*(undefined4 *)(iStack_78 + 0x2c),iStack_98
                       ,iStack_94);
          goto LAB_007860cd;
        }
        uVar4 = 0;
        if (*(int *)(iVar11 + 0x44) - *(int *)(iVar11 + 0x40) >> 3 != 0) {
          do {
            FUN_00773cd0(&iStack_78,&iStack_98);
            uVar4 = uVar4 + 1;
          } while (uVar4 < (uint)(*(int *)(iVar11 + 0x44) - *(int *)(iVar11 + 0x40) >> 3));
        }
        FUN_00773cd0(&iStack_78,&iStack_98);
        piVar8[0x2f] = piVar8[0x2f] + 1;
        iVar11 = FUN_00781d30(&iStack_78);
        piVar8[0x30] = piVar8[0x30] + iVar11;
      }
      uVar4 = FUN_009cc8a0(auStack_b4);
      piStack_1c = piStack_20 + 0x26;
      uVar4 = (uVar4 ^ (uVar4 >> 2) + 0x9e3779b9 + uVar4 * 0x40 + (uint)bStack_9c) &
              piStack_20[0x2b];
      piVar8 = *(int **)(piStack_20[0x28] + uVar4 * 8);
      while( true ) {
        piVar7 = (int *)*piStack_1c;
        piVar5 = piVar7;
        if (*(int **)(piStack_20[0x28] + uVar4 * 8) != piVar7) {
          piVar5 = (int *)**(undefined4 **)(piStack_20[0x28] + 4 + uVar4 * 8);
        }
        piVar9 = piVar7;
        if (piVar8 == piVar5) goto LAB_0078624c;
        cVar3 = FUN_009cbaa0(piVar8 + 2,auStack_b4);
        if ((cVar3 != '\0') && (*(byte *)(piVar8 + 8) == bStack_9c)) break;
        piVar8 = (int *)*piVar8;
      }
      cVar3 = FUN_009cbaa0(auStack_b4,piVar8 + 2);
      if ((cVar3 == '\0') || (bStack_9c != *(byte *)(piVar8 + 8))) {
        piVar7 = (int *)piStack_20[0x26];
        piVar9 = piVar7;
      }
      else {
        piVar7 = (int *)piStack_20[0x26];
        piVar9 = piVar8;
      }
LAB_0078624c:
      param_1 = piStack_18;
      if (piVar9 != piVar7) {
        uVar4 = FUN_009cc8a0(piVar9 + 2);
        param_1 = piStack_20;
        uVar4 = (uVar4 ^ (uVar4 >> 2) + 0x9e3779b9 + uVar4 * 0x40 + (uint)*(byte *)(piVar9 + 8)) &
                piStack_20[0x2b];
        iVar11 = piStack_20[0x28];
        if (*(int **)(iVar11 + 4 + uVar4 * 8) == piVar9) {
          if (*(int **)(iVar11 + uVar4 * 8) == piVar9) {
            *(int *)(iVar11 + uVar4 * 8) = piStack_20[0x26];
            *(int *)(piStack_20[0x28] + 4 + uVar4 * 8) = piStack_20[0x26];
          }
          else {
            *(int *)(iVar11 + 4 + uVar4 * 8) = piVar9[1];
          }
        }
        else if (*(int **)(iVar11 + uVar4 * 8) == piVar9) {
          *(int *)(iVar11 + uVar4 * 8) = *piVar9;
        }
        *(int *)piVar9[1] = *piVar9;
        *(int *)(*piVar9 + 4) = piVar9[1];
        piStack_1c[1] = piStack_1c[1] + -1;
        FUN_00780650(piVar9);
        FUN_00786710(auStack_b4,auStack_100,-(iStack_88 != 0) & 0x80,param_1[0x3e]);
      }
    } while (*(char *)(*(int *)(*param_1 + 0x510) + 0x2c) != '\0');
    pdVar6 = (double *)FUN_016827e0(&uStack_50);
  } while ((*pdVar6 - dStack_12c) * dStack_38 <= DAT_018cf100);
LAB_00786351:
  FUN_0077f560();
  uStack_8 = 8;
  FUN_0152dda0(uStack_48,uStack_44,uStack_40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11162 ; VA 0x00785f8b ; Catch@00785f8b */

undefined * Catch_00785f8b(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x110) + 4))();
  FUN_00784440(unaff_EBP + -0xb0,unaff_EBP + -0xfc,uVar1);
  return &DAT_00785fb3;
}



/* FUNCTION 11163 ; VA 0x00785fc6 ; FUN_00785fc6 */

void FUN_00785fc6(void)

{
  double dVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  char cVar5;
  undefined4 *puVar6;
  int *piVar7;
  double *pdVar8;
  int *piVar9;
  int *unaff_EBX;
  int unaff_EBP;
  int unaff_ESI;
  int *piVar10;
  int *piVar11;
  int iVar12;
  uint uVar13;
  
  *(undefined4 *)(unaff_EBP + -4) = 5;
  if (*(int *)(unaff_EBP + -0x74) != 0) goto LAB_00786008;
  uVar13 = 0;
  if (*(int *)(unaff_ESI + 0x20) - *(int *)(unaff_ESI + 0x1c) >> 3 != 0) {
    do {
      FUN_00773c00();
      uVar13 = uVar13 + 1;
    } while (uVar13 < (uint)(*(int *)(unaff_ESI + 0x20) - *(int *)(unaff_ESI + 0x1c) >> 3));
  }
  FUN_00773c00();
LAB_0078617f:
  do {
    uVar13 = FUN_009cc8a0(unaff_EBP + -0xb0);
    iVar12 = *(int *)(unaff_EBP + -0x1c);
    iVar4 = *(int *)(iVar12 + 0xa0);
    piVar9 = (int *)(iVar12 + 0x98);
    uVar13 = (uVar13 ^ (uVar13 >> 2) + 0x9e3779b9 +
                       uVar13 * 0x40 + (uint)*(byte *)(unaff_EBP + -0x98)) &
             *(uint *)(iVar12 + 0xac);
    *(int **)(unaff_EBP + -0x18) = piVar9;
    piVar10 = *(int **)(iVar4 + uVar13 * 8);
    while( true ) {
      piVar9 = (int *)*piVar9;
      piVar7 = piVar9;
      if (*(int **)(*(int *)(iVar12 + 0xa0) + uVar13 * 8) != piVar9) {
        piVar7 = (int *)**(undefined4 **)(*(int *)(iVar12 + 0xa0) + 4 + uVar13 * 8);
      }
      piVar11 = piVar9;
      if (piVar10 == piVar7) goto LAB_0078624c;
      cVar5 = FUN_009cbaa0(piVar10 + 2,unaff_EBP + -0xb0);
      if ((cVar5 != '\0') && (*(char *)(piVar10 + 8) == *(char *)(unaff_EBP + -0x98))) break;
      piVar10 = (int *)*piVar10;
      piVar9 = *(int **)(unaff_EBP + -0x18);
      iVar12 = *(int *)(unaff_EBP + -0x1c);
    }
    cVar5 = FUN_009cbaa0(unaff_EBP + -0xb0,piVar10 + 2);
    if ((cVar5 == '\0') || (*(char *)(unaff_EBP + -0x98) != *(char *)(piVar10 + 8))) {
      piVar9 = *(int **)(*(int *)(unaff_EBP + -0x1c) + 0x98);
      piVar11 = piVar9;
    }
    else {
      piVar9 = *(int **)(*(int *)(unaff_EBP + -0x1c) + 0x98);
      piVar11 = piVar10;
    }
LAB_0078624c:
    if (piVar11 == piVar9) {
      unaff_EBX = *(int **)(unaff_EBP + -0x14);
    }
    else {
      uVar13 = FUN_009cc8a0(piVar11 + 2);
      unaff_EBX = *(int **)(unaff_EBP + -0x1c);
      uVar13 = (uVar13 ^ (uVar13 >> 2) + 0x9e3779b9 + uVar13 * 0x40 + (uint)*(byte *)(piVar11 + 8))
               & unaff_EBX[0x2b];
      iVar12 = unaff_EBX[0x28];
      if (*(int **)(iVar12 + 4 + uVar13 * 8) == piVar11) {
        if (*(int **)(iVar12 + uVar13 * 8) == piVar11) {
          *(int *)(iVar12 + uVar13 * 8) = unaff_EBX[0x26];
          *(int *)(unaff_EBX[0x28] + 4 + uVar13 * 8) = unaff_EBX[0x26];
        }
        else {
          *(int *)(iVar12 + 4 + uVar13 * 8) = piVar11[1];
        }
      }
      else if (*(int **)(iVar12 + uVar13 * 8) == piVar11) {
        *(int *)(iVar12 + uVar13 * 8) = *piVar11;
      }
      *(int *)piVar11[1] = *piVar11;
      *(int *)(*piVar11 + 4) = piVar11[1];
      piVar9 = (int *)(*(int *)(unaff_EBP + -0x18) + 4);
      *piVar9 = *piVar9 + -1;
      FUN_00780650(piVar11);
      FUN_00786710(unaff_EBP + -0xb0,unaff_EBP + -0xfc,-(*(int *)(unaff_EBP + -0x84) != 0) & 0x80,
                   unaff_EBX[0x3e]);
    }
    if ((*(char *)(*(int *)(*unaff_EBX + 0x510) + 0x2c) == '\0') &&
       (pdVar8 = (double *)FUN_016827e0(unaff_EBP + -0x4c),
       DAT_018cf100 < (*pdVar8 - *(double *)(unaff_EBP + -0x128)) * *(double *)(unaff_EBP + -0x34)))
    {
LAB_00786351:
      FUN_0077f560();
      *(undefined4 *)(unaff_EBP + -4) = 8;
      FUN_0152dda0(*(undefined4 *)(unaff_EBP + -0x44),*(undefined4 *)(unaff_EBP + -0x40),
                   *(undefined4 *)(unaff_EBP + -0x3c),*(undefined4 *)(unaff_EBP + -0x38));
      ExceptionList = *(void **)(unaff_EBP + -0xc);
      return;
    }
    do {
      cVar5 = FUN_00785300(unaff_EBP + -0xfc);
      if (cVar5 == '\0') goto LAB_00786351;
      iVar12 = (int)unaff_EBX + *(byte *)(unaff_EBX + 1) + 5;
      uVar13 = FUN_009cc8a0(unaff_EBP + -0xb0);
      FUN_0077cf60(unaff_EBP + -0x20,
                   uVar13 * 0x40 + (uint)*(byte *)(unaff_EBP + -0x98) + (uVar13 >> 2) + 0x9e3779b9 ^
                   uVar13,unaff_EBP + -0xb0,-(uint)(iVar12 != 0) & iVar12 + 1U);
      iVar12 = *(int *)(unaff_EBP + -0x20);
      unaff_EBX = *(int **)(unaff_EBP + -0x14);
    } while (iVar12 == 0);
    unaff_ESI = iVar12 + 0x24;
    piVar9 = (int *)(iVar12 + 0x4c);
    *(int *)(unaff_EBP + -0x24) = unaff_ESI;
    *(int **)(unaff_EBP + -0x18) = piVar9;
    *(int **)(unaff_EBP + -0x28) = piVar9;
    if ((*piVar9 != 0) && (*(int *)(*piVar9 + 8) == 1)) {
      unaff_EBX[0x2d] = unaff_EBX[0x2d] + -1;
    }
    if (*(int *)(unaff_EBP + -0x7c) != 0) {
      if (*(int *)(unaff_EBP + -0x74) == 0) {
        FUN_016827e0(unaff_EBP + -0x120);
        iVar12 = *unaff_EBX;
        *(undefined *)(unaff_EBP + -4) = 6;
        puVar6 = (undefined4 *)
                 FUN_00786d10(unaff_EBP + -0x118,*(undefined4 *)(iVar12 + 0x3c),
                              *(undefined4 *)(unaff_EBP + -0x7c),unaff_EBP + -0xb0);
        uVar2 = *puVar6;
        uVar3 = puVar6[1];
        *puVar6 = 0;
        puVar6[1] = 0;
        piVar9 = *(int **)(unaff_EBP + -0x70);
        *(undefined4 *)(unaff_EBP + -0x74) = uVar2;
        *(undefined4 *)(unaff_EBP + -0x70) = uVar3;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar12 = piVar9[1] + -1;
          piVar9[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar12 = piVar9[2] + -1;
            piVar9[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        piVar9 = *(int **)(unaff_EBP + -0x114);
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar12 = piVar9[1] + -1;
          piVar9[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar12 = piVar9[2] + -1;
            piVar9[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        pdVar8 = (double *)FUN_016827e0(unaff_EBP + -0x130);
        *(double *)(unaff_EBP + -0x5c) = *pdVar8 - *(double *)(unaff_EBP + -0x120);
        FUN_00785fc6();
        return;
      }
LAB_00786008:
      pdVar8 = (double *)FUN_016830f0(unaff_EBP + -0x138);
      dVar1 = *pdVar8;
      *(undefined4 *)(unaff_EBP + -0x104) = *(undefined4 *)(unaff_EBP + -0x5c);
      *(undefined4 *)(unaff_EBP + -0x100) = *(undefined4 *)(unaff_EBP + -0x58);
      *(undefined4 *)(unaff_EBP + -0x10c) = *(undefined4 *)(unaff_EBP + -100);
      *(undefined4 *)(unaff_EBP + -0x108) = *(undefined4 *)(unaff_EBP + -0x60);
      cVar5 = DAT_01eb1bac;
      *(double *)(unaff_EBP + -0x2c) = dVar1 - *(double *)(unaff_EBP + -0x6c);
      if (cVar5 != '\0') {
        FUN_01677760(cVar5,"Image loaded from %s",unaff_EBP + -0xb0);
        cVar5 = DAT_01eb1bac;
      }
      iVar12 = *(int *)(unaff_EBP + -0x74);
      iVar4 = *(int *)(iVar12 + 0x30);
      if ((iVar4 == *(int *)(unaff_EBP + -0x94)) &&
         (*(int *)(iVar12 + 0x34) == *(int *)(unaff_EBP + -0x90))) {
        if (cVar5 != '\0') {
          FUN_01677490(cVar5,"Image dimensions: %dx%d format %d",iVar4,
                       *(undefined4 *)(iVar12 + 0x34),*(undefined4 *)(iVar12 + 0x2c));
LAB_007860cd:
          if (DAT_01eb1bac != '\0') {
            dVar1 = *(double *)(unaff_EBP + -0x34);
            FUN_01677490(DAT_01eb1bac,"Image timings: decode %d ms, upload %d ms, latency %d ms",
                         (int)(*(double *)(unaff_EBP + -0x10c) * dVar1),
                         (int)(*(double *)(unaff_EBP + -0x104) * dVar1),
                         (int)(*(double *)(unaff_EBP + -0x2c) * dVar1));
          }
        }
      }
      else if (cVar5 != '\0') {
        FUN_016773b0(cVar5,"Image dimensions: %dx%d format %d (scaled from %dx%d)",iVar4,
                     *(undefined4 *)(iVar12 + 0x34),*(undefined4 *)(iVar12 + 0x2c),
                     *(undefined4 *)(unaff_EBP + -0x94),*(int *)(unaff_EBP + -0x90));
        goto LAB_007860cd;
      }
      uVar13 = 0;
      if (*(int *)(unaff_ESI + 0x20) - *(int *)(unaff_ESI + 0x1c) >> 3 != 0) {
        do {
          FUN_00773cd0(unaff_EBP + -0x74,unaff_EBP + -0x94);
          uVar13 = uVar13 + 1;
        } while (uVar13 < (uint)(*(int *)(unaff_ESI + 0x20) - *(int *)(unaff_ESI + 0x1c) >> 3));
      }
      FUN_00773cd0(unaff_EBP + -0x74,unaff_EBP + -0x94);
      unaff_EBX[0x2f] = unaff_EBX[0x2f] + 1;
      iVar12 = FUN_00781d30(unaff_EBP + -0x74);
      unaff_EBX[0x30] = unaff_EBX[0x30] + iVar12;
      goto LAB_0078617f;
    }
    if (*(int *)(unaff_EBP + -0x74) != 0) goto LAB_00786008;
    uVar13 = 0;
    if (*(int *)(iVar12 + 0x44) - *(int *)(iVar12 + 0x40) >> 3 != 0) {
      do {
        FUN_00773c00();
        uVar13 = uVar13 + 1;
      } while (uVar13 < (uint)(*(int *)(iVar12 + 0x44) - *(int *)(iVar12 + 0x40) >> 3));
    }
    FUN_00773c00();
  } while( true );
}



/* FUNCTION 11164 ; VA 0x00786430 ; FUN_00786430 */

void __thiscall FUN_00786430(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b057b;
  pvStack_10 = ExceptionList;
  uVar5 = *(uint *)(param_1 + 8);
  ExceptionList = &pvStack_10;
  if (uVar5 <= *(int *)(param_1 + 0x10) + 1U) {
    ExceptionList = &pvStack_10;
    FUN_007806b0(1);
    uVar5 = *(uint *)(param_1 + 8);
  }
  uVar5 = uVar5 - 1 & *(uint *)(param_1 + 0xc);
  *(uint *)(param_1 + 0xc) = uVar5;
  uVar5 = *(int *)(param_1 + 8) - 1U & *(int *)(param_1 + 0x10) + uVar5;
  iVar4 = *(int *)(param_1 + 4);
  iVar2 = uVar5 * 4;
  if (*(int *)(iVar4 + uVar5 * 4) == 0) {
    uVar3 = FUN_01674e20(0xa8);
    *(undefined4 *)(iVar2 + *(int *)(param_1 + 4)) = uVar3;
    iVar4 = *(int *)(param_1 + 4);
  }
  iVar2 = *(int *)(iVar2 + iVar4);
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2 + 0x30);
  *(undefined4 *)(iVar2 + 0x48) = *(undefined4 *)(param_2 + 0x48);
  uStack_8 = 2;
  FUN_0054ef60(param_2 + 0x4c);
  *(undefined *)(iVar2 + 100) = *(undefined *)(param_2 + 100);
  *(undefined4 *)(iVar2 + 0x68) = *(undefined4 *)(param_2 + 0x68);
  *(undefined4 *)(iVar2 + 0x6c) = *(undefined4 *)(param_2 + 0x6c);
  *(undefined4 *)(iVar2 + 0x70) = *(undefined4 *)(param_2 + 0x70);
  *(undefined *)(iVar2 + 0x74) = *(undefined *)(param_2 + 0x74);
  *(undefined4 *)(iVar2 + 0x78) = 0;
  *(undefined4 *)(iVar2 + 0x7c) = 0;
  if (*(int *)(param_2 + 0x7c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x7c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 0x78) = *(undefined4 *)(param_2 + 0x78);
  *(undefined4 *)(iVar2 + 0x7c) = *(undefined4 *)(param_2 + 0x7c);
  *(undefined4 *)(iVar2 + 0x80) = 0;
  *(undefined4 *)(iVar2 + 0x84) = 0;
  if (*(int *)(param_2 + 0x84) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x84) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 0x80) = *(undefined4 *)(param_2 + 0x80);
  *(undefined4 *)(iVar2 + 0x84) = *(undefined4 *)(param_2 + 0x84);
  *(undefined4 *)(iVar2 + 0x88) = 0;
  *(undefined4 *)(iVar2 + 0x8c) = 0;
  if (*(int *)(param_2 + 0x8c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x8c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 0x88) = *(undefined4 *)(param_2 + 0x88);
  *(undefined4 *)(iVar2 + 0x8c) = *(undefined4 *)(param_2 + 0x8c);
  *(undefined4 *)(iVar2 + 0x90) = *(undefined4 *)(param_2 + 0x90);
  *(undefined4 *)(iVar2 + 0x94) = *(undefined4 *)(param_2 + 0x94);
  *(undefined4 *)(iVar2 + 0x98) = *(undefined4 *)(param_2 + 0x98);
  *(undefined4 *)(iVar2 + 0x9c) = *(undefined4 *)(param_2 + 0x9c);
  *(undefined4 *)(iVar2 + 0xa0) = *(undefined4 *)(param_2 + 0xa0);
  *(undefined4 *)(iVar2 + 0xa4) = *(undefined4 *)(param_2 + 0xa4);
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11165 ; VA 0x00786610 ; FUN_00786610 */

void __thiscall FUN_00786610(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = 0;
    puVar1[1] = 0;
    *puVar1 = *param_2;
    puVar1[1] = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
    return;
  }
  FUN_0077c2a0(puVar1,param_2);
  return;
}



/* FUNCTION 11166 ; VA 0x00786660 ; FUN_00786660 */

void __thiscall FUN_00786660(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aff48;
  pvStack_10 = ExceptionList;
  uVar2 = *(undefined4 *)(param_1 + 0xfc);
  uVar1 = *(undefined *)(param_1 + 0x108);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_14 = 0;
  if (DAT_01d60d9c != '\0') {
    uStack_14 = uVar1;
  }
  uStack_8 = 0;
  FUN_00786710(aiStack_2c,param_3,param_4,uVar2);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar3 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11167 ; VA 0x00786710 ; FUN_00786710 */

void __thiscall
FUN_00786710(int *param_1,int *param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  undefined *puVar7;
  int iVar8;
  int aiStack_38 [5];
  uint uStack_24;
  byte bStack_20;
  undefined auStack_1c [8];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0598;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  FUN_0054ef60(param_2);
  bStack_20 = *(byte *)(piVar3 + 6);
  uStack_8 = 0;
  if (*(int *)(*param_1 + 0x518) != 0) {
    FUN_008cc060(aiStack_38);
  }
  iVar8 = (int)param_1 + *(byte *)(param_1 + 1) + 5;
  uVar5 = FUN_009cc8a0(aiStack_38);
  FUN_0077cf60(&param_2,bStack_20 + 0x9e3779b9 + uVar5 * 0x40 + (uVar5 >> 2) ^ uVar5,aiStack_38,
               -(uint)(iVar8 != 0) & iVar8 + 1U);
  piVar3 = param_2;
  if (param_2 != (int *)0x0) {
    piVar1 = param_2 + 0x13;
    puVar7 = &DAT_01eb1b04;
    if ((undefined *)param_2[0x13] != (undefined *)0x0) {
      puVar7 = (undefined *)param_2[0x13];
    }
    param_2 = piVar1;
    iVar6 = FUN_00781d30(puVar7);
    piVar2 = piStack_14;
    iVar8 = *piVar1;
    if ((iVar8 == 0) || (*(int *)(iVar8 + 8) != 1)) {
      cVar4 = FUN_00782630(aiStack_38,param_3,0x425c0000,param_4,param_5);
      if (cVar4 != '\0') {
        if (*(char *)(piVar3 + 0x17) == '\0') {
          piVar1 = piVar2 + 0x2f;
          *piVar1 = *piVar1 + -1;
          piVar2 = piVar2 + 0x30;
          *piVar2 = *piVar2 - iVar6;
        }
        uVar5 = 0;
        if (piVar3[0x11] - piVar3[0x10] >> 3 != 0) {
          do {
            FUN_00773d90();
            uVar5 = uVar5 + 1;
          } while (uVar5 < (uint)(piVar3[0x11] - piVar3[0x10] >> 3));
        }
        FUN_00773d90();
      }
    }
    else {
      FUN_0077c430(auStack_1c,aiStack_38,param_2);
    }
  }
  if (0xf < uStack_24) {
    uVar5 = uStack_24 + 1;
    iVar8 = aiStack_38[0];
    if (0xfff < uVar5) {
      iVar8 = *(int *)(aiStack_38[0] + -4);
      uVar5 = uStack_24 + 0x24;
      if (0x1f < (aiStack_38[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11168 ; VA 0x007868b0 ; FUN_007868b0 */

void __thiscall FUN_007868b0(int param_1,int param_2)

{
  int iVar1;
  undefined *puVar2;
  
  if (*(int *)(param_2 + 0x30) == 0) {
    *(undefined4 *)(param_1 + 0xcc) = *(undefined4 *)(param_2 + 0x34);
  }
  else {
    *(undefined4 *)(*(int *)(param_2 + 0x30) + 0x34) = *(undefined4 *)(param_2 + 0x34);
  }
  if (*(int *)(param_2 + 0x34) == 0) {
    *(undefined4 *)(param_1 + 0xd0) = *(undefined4 *)(param_2 + 0x30);
  }
  else {
    *(undefined4 *)(*(int *)(param_2 + 0x34) + 0x30) = *(undefined4 *)(param_2 + 0x30);
  }
  *(undefined *)(param_2 + 0x38) = 0;
  *(undefined4 *)(param_2 + 0x30) = 0;
  *(undefined4 *)(param_2 + 0x34) = 0;
  puVar2 = &DAT_01eb1b04;
  if (*(undefined **)(param_2 + 0x28) != (undefined *)0x0) {
    puVar2 = *(undefined **)(param_2 + 0x28);
  }
  iVar1 = FUN_00781d30(puVar2);
  *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + -1;
  *(int *)(param_1 + 200) = *(int *)(param_1 + 200) - iVar1;
  return;
}



/* FUNCTION 11169 ; VA 0x00786920 ; FUN_00786920 */

void __fastcall FUN_00786920(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  puVar6 = *(undefined4 **)(param_1 + 0x1c);
  puVar7 = *(undefined4 **)(param_1 + 0x20);
  if (puVar6 != puVar7) {
    do {
      if ((puVar6[1] != 0) && (*(int *)(puVar6[1] + 4) == 1)) break;
      puVar6 = puVar6 + 2;
    } while (puVar6 != puVar7);
    puVar5 = puVar6;
    if (puVar6 != puVar7) {
      while (puVar5 = puVar5 + 2, puVar5 != puVar7) {
        iVar1 = puVar5[1];
        if ((iVar1 == 0) || (*(int *)(iVar1 + 4) != 1)) {
          uVar2 = *puVar5;
          *puVar5 = 0;
          puVar5[1] = 0;
          *puVar6 = uVar2;
          piVar3 = (int *)puVar6[1];
          puVar6[1] = iVar1;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar1 = piVar3[1] + -1;
            piVar3[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              iVar1 = piVar3[2] + -1;
              piVar3[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          puVar6 = puVar6 + 2;
        }
      }
      if (puVar6 != puVar7) {
        puVar5 = *(undefined4 **)(param_1 + 0x20);
        if (puVar7 != puVar5) {
          do {
            uVar2 = *puVar7;
            uVar4 = puVar7[1];
            *puVar7 = 0;
            puVar7[1] = 0;
            *puVar6 = uVar2;
            piVar3 = (int *)puVar6[1];
            puVar6[1] = uVar4;
            if (piVar3 != (int *)0x0) {
              LOCK();
              iVar1 = piVar3[1] + -1;
              piVar3[1] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)*piVar3)();
                LOCK();
                iVar1 = piVar3[2] + -1;
                piVar3[2] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)(*piVar3 + 4))();
                }
              }
            }
            puVar7 = puVar7 + 2;
            puVar6 = puVar6 + 2;
          } while (puVar7 != puVar5);
          puVar5 = *(undefined4 **)(param_1 + 0x20);
        }
        FUN_005596d0(puVar6,puVar5,param_1 + 0x1c);
        *(undefined4 **)(param_1 + 0x20) = puVar6;
      }
    }
  }
  return;
}



/* FUNCTION 11170 ; VA 0x00786a40 ; FUN_00786a40 */

void __fastcall FUN_00786a40(int *param_1)

{
  int iVar1;
  
  if ((*param_1 != 0) && (iVar1 = *(int *)(*param_1 + 0x518), iVar1 != 0)) {
    FUN_00786a60(iVar1);
  }
  return;
}



/* FUNCTION 11171 ; VA 0x00786a60 ; FUN_00786a60 */

void FUN_00786a60(int param_1)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  undefined4 uVar4;
  int iVar5;
  double *pdVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  undefined auStack_b4 [76];
  undefined auStack_68 [8];
  int aiStack_60 [5];
  uint uStack_4c;
  undefined uStack_48;
  double dStack_44;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_20;
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b05d3;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x6c) != *(int *)(param_1 + 0x70)) {
    ExceptionList = &pvStack_10;
    FUN_016827e0(&dStack_44);
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    FUN_005542c0("TextureManager::PreloadTexture",0x1e);
    uStack_8 = 0;
    FUN_00d102b0(auStack_3c);
    uStack_8._0_1_ = 2;
    if (0xf < uStack_28) {
      uVar8 = uStack_28 + 1;
      uVar9 = auStack_3c[0];
      if (0xfff < uVar8) {
        uVar9 = *(uint *)(auStack_3c[0] - 4);
        uVar8 = uStack_28 + 0x24;
        if (0x1f < (auStack_3c[0] - uVar9) - 4) {
LAB_00786d02:
          uStack_8._0_1_ = 2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar8);
    }
    iVar5 = *(int *)(param_1 + 0x70);
    iVar7 = *(int *)(param_1 + 0x6c);
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    uStack_18 = 0;
    iVar10 = iStack_14;
    if (iVar5 - iVar7 >> 6 != 0) {
      do {
        uStack_1c = (*(int *)(iVar10 + 0xb8) + uStack_18) % (uint)(iVar5 - iVar7 >> 6);
        iVar5 = uStack_1c * 0x40;
        if (*(int *)(iVar5 + iVar7 + 0x18) == 0) {
          uVar4 = *(undefined4 *)(iVar10 + 0xfc);
          uVar3 = *(undefined *)(iVar10 + 0x108);
          FUN_0054ef60(iVar5 + iVar7);
          iVar10 = iStack_14;
          uStack_48 = 0;
          if (DAT_01d60d9c != '\0') {
            uStack_48 = uVar3;
          }
          uStack_8._0_1_ = 3;
          FUN_00784040(&iStack_24,aiStack_60,iStack_14 + 0x1c,auStack_b4,0x425c0000,0,uVar4);
          uStack_8._0_1_ = 2;
          if (0xf < uStack_4c) {
            uVar9 = uStack_4c + 1;
            iVar7 = aiStack_60[0];
            if (0xfff < uVar9) {
              iVar7 = *(int *)(aiStack_60[0] + -4);
              uVar9 = uStack_4c + 0x24;
              if (0x1f < (aiStack_60[0] - iVar7) - 4U) goto LAB_00786d02;
            }
            FUN_01674ea0(iVar7,uVar9);
          }
          uStack_8._0_1_ = 4;
          if (iStack_24 == 0) {
LAB_00786c22:
            *(undefined4 *)(iVar5 + 0x18 + *(int *)(param_1 + 0x6c)) = 2;
          }
          else {
            iVar7 = *(int *)(iStack_24 + 8);
            if (iVar7 == 3) {
              *(undefined4 *)(iVar5 + 0x18 + *(int *)(param_1 + 0x6c)) = 1;
            }
            else if ((iVar7 == 2) || (iVar7 == 0)) goto LAB_00786c22;
          }
          pdVar6 = (double *)FUN_016827e0(auStack_68);
          piVar2 = piStack_20;
          if ((double)DAT_01d60d1c < (*pdVar6 - dStack_44) * DAT_018c0d70 * DAT_018c0d70) {
            *(uint *)(iVar10 + 0xb8) = uStack_1c + 1;
            if (piStack_20 != (int *)0x0) {
              LOCK();
              iVar5 = piStack_20[1] + -1;
              piStack_20[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)*piStack_20)();
                LOCK();
                piVar2 = piStack_20 + 2;
                iVar5 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar5 == 1) {
                  (**(code **)(*piStack_20 + 4))();
                }
              }
            }
            break;
          }
          uStack_8._0_1_ = 2;
          if (piStack_20 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_20[1] + -1;
            piStack_20[1] = iVar5;
            UNLOCK();
            iVar10 = iStack_14;
            if (iVar5 == 0) {
              (**(code **)*piStack_20)();
              LOCK();
              piVar1 = piVar2 + 2;
              iVar5 = *piVar1 + -1;
              *piVar1 = iVar5;
              UNLOCK();
              iVar10 = iStack_14;
              if (iVar5 == 0) {
                (**(code **)(*piVar2 + 4))();
                iVar10 = iStack_14;
              }
            }
          }
        }
        iVar5 = *(int *)(param_1 + 0x70);
        iVar7 = *(int *)(param_1 + 0x6c);
        uStack_18 = uStack_18 + 1;
      } while (uStack_18 < (uint)(iVar5 - iVar7 >> 6));
    }
    FUN_00637950();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11172 ; VA 0x00786d10 ; FUN_00786d10 */

undefined4 * FUN_00786d10(undefined4 *param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int iVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  uint uVar10;
  uint uVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0601;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00780cc0(0,0xb,"rbxasset://");
  uVar4 = DAT_01eafa18;
  if (iVar3 == 0) {
    uVar4 = DAT_01eb1bf4;
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  FUN_0147c150(param_1,*param_3,param_3[1],param_3[2],param_3[3],param_3[4],param_3[5],param_3[6],5)
  ;
  (**(code **)(*(int *)*param_1 + 0xc))(param_4);
  iVar3 = 1;
  if (*param_3 == 2) {
    iVar3 = 6;
  }
  iVar1 = param_3[6];
  param_4 = 0;
  if (iVar1 * iVar3 != 0) {
    uVar10 = param_3[5];
    do {
      uVar11 = 0;
      if (uVar10 != 0) {
        do {
          uVar5 = FUN_0147d110(param_3[2],uVar11);
          uVar6 = FUN_0147d110(param_3[3],uVar11);
          iVar7 = FUN_0147d110(param_3[4],uVar11);
          iVar8 = FUN_0147d000(param_3[1],uVar5,uVar6);
          uVar9 = FUN_007d2090(param_4,uVar11);
          pcVar2 = *(code **)(*(int *)*param_1 + 0x10);
          uVar5 = FUN_0147ce90(0,0,0,uVar5,uVar6,iVar7);
          (*pcVar2)(param_4,uVar11,uVar5,uVar9,iVar8 * iVar7);
          uVar10 = param_3[5];
          uVar11 = uVar11 + 1;
        } while (uVar11 < uVar10);
      }
      param_4 = param_4 + 1;
    } while (param_4 < (uint)(iVar1 * iVar3));
  }
  (**(code **)(*(int *)*param_1 + 0x2c))();
  uStack_8 = 2;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11173 ; VA 0x00786ed0 ; FUN_00786ed0 */

int FUN_00786ed0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0610;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0078a0d0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054ef60(*param_2);
  *(undefined4 *)(iVar1 + 0x28) = 0;
  *(undefined4 *)(iVar1 + 0x2c) = 0;
  *(undefined4 *)(iVar1 + 0x30) = 0;
  *(undefined4 *)(iVar1 + 0x34) = 0;
  *(undefined4 *)(iVar1 + 0x38) = 0;
  *(undefined4 *)(iVar1 + 0x3c) = 0;
  *(undefined4 *)(iVar1 + 0x40) = 0x3f800000;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 11174 ; VA 0x00786f5e ; Catch_All@00786f5e */

void Catch_All_00786f5e(void)

{
  int unaff_EBP;
  
  FUN_0078a1d0(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11175 ; VA 0x00786f80 ; FUN_00786f80 */

void FUN_00786f80(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 4);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_1 = param_1 + 0x10;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 11176 ; VA 0x00786fd0 ; FUN_00786fd0 */

void __thiscall
FUN_00786fd0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x3c3c3c1 < (uint)param_1[1]) {
    FUN_0078a110(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00787082:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00787082;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 11177 ; VA 0x00787130 ; FUN_00787130 */

undefined4 * __thiscall
FUN_00787130(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0620;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00786fd0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar2 = FUN_00570370(param_4,param_3 + 4);
    if (cVar2 != '\0') {
      FUN_00786fd0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar1 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar2 = FUN_00570370(iVar1 + 0x10,param_4);
    if (cVar2 != '\0') {
      FUN_00786fd0(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_00570370(param_4,param_3 + 4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar2 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar2 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00786fd0(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00786fd0(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar2 = FUN_00570370(param_3 + 4,param_4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      FUN_00551320();
      piVar3 = piStack_18;
      if ((piStack_18 == (int *)*param_1) ||
         (cVar2 = FUN_00570370(param_4,piStack_18 + 4), cVar2 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00786fd0(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00786fd0(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = (undefined4 *)FUN_00787370(auStack_20,0,param_4,param_5);
  *param_2 = *puVar4;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11178 ; VA 0x00787352 ; Catch_All@00787352 */

void Catch_All_00787352(void)

{
  int unaff_EBP;
  
  FUN_0078a110(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11179 ; VA 0x00787370 ; FUN_00787370 */

void __thiscall
FUN_00787370(int *param_1,undefined4 *param_2,char param_3,byte *param_4,int param_5)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  byte bVar5;
  char cVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  byte *pbVar10;
  byte *pbVar11;
  undefined4 *puVar12;
  bool bVar13;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0630;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar5 = 1;
  puVar9 = (undefined4 *)((undefined4 *)*param_1)[1];
  cVar6 = *(char *)((int)puVar9 + 0xd);
  puVar3 = (undefined4 *)*param_1;
  while (cVar6 == '\0') {
    pbVar10 = (byte *)(puVar9 + 4);
    if (param_3 == '\0') {
      uVar1 = puVar9[8];
      if (0xf < (uint)puVar9[9]) {
        pbVar10 = *(byte **)pbVar10;
      }
      uVar7 = *(uint *)(param_4 + 0x10);
      pbVar11 = param_4;
      if (0xf < *(uint *)(param_4 + 0x14)) {
        pbVar11 = *(byte **)param_4;
      }
      uVar8 = uVar7;
      if (uVar1 < uVar7) {
        uVar8 = uVar1;
      }
      while (uVar2 = uVar8 - 4, 3 < uVar8) {
        if (*(int *)pbVar11 != *(int *)pbVar10) goto LAB_007874a6;
        pbVar11 = pbVar11 + 4;
        pbVar10 = pbVar10 + 4;
        uVar8 = uVar2;
      }
      if (uVar2 == 0xfffffffc) {
LAB_007874da:
        uVar8 = 0;
      }
      else {
LAB_007874a6:
        bVar13 = *pbVar11 < *pbVar10;
        if ((*pbVar11 == *pbVar10) &&
           ((uVar2 == 0xfffffffd ||
            ((bVar13 = pbVar11[1] < pbVar10[1], pbVar11[1] == pbVar10[1] &&
             ((uVar2 == 0xfffffffe ||
              ((bVar13 = pbVar11[2] < pbVar10[2], pbVar11[2] == pbVar10[2] &&
               ((uVar2 == 0xffffffff || (bVar13 = pbVar11[3] < pbVar10[3], pbVar11[3] == pbVar10[3])
                ))))))))))) goto LAB_007874da;
        uVar8 = -(uint)bVar13 | 1;
      }
      if (uVar8 == 0) {
        if (uVar7 < uVar1) {
          uVar8 = 0xffffffff;
        }
        else {
          uVar8 = 0;
        }
      }
      bVar5 = (byte)(uVar8 >> 0x1f);
    }
    else {
      pbVar11 = param_4;
      if (0xf < *(uint *)(param_4 + 0x14)) {
        pbVar11 = *(byte **)param_4;
      }
      uVar1 = puVar9[8];
      if (0xf < (uint)puVar9[9]) {
        pbVar10 = *(byte **)pbVar10;
      }
      uVar7 = uVar1;
      if (*(uint *)(param_4 + 0x10) < uVar1) {
        uVar7 = *(uint *)(param_4 + 0x10);
      }
      while (uVar8 = uVar7 - 4, 3 < uVar7) {
        if (*(int *)pbVar10 != *(int *)pbVar11) goto LAB_00787406;
        pbVar10 = pbVar10 + 4;
        pbVar11 = pbVar11 + 4;
        uVar7 = uVar8;
      }
      if (uVar8 == 0xfffffffc) {
LAB_0078743a:
        uVar7 = 0;
      }
      else {
LAB_00787406:
        bVar13 = *pbVar10 < *pbVar11;
        if ((*pbVar10 == *pbVar11) &&
           ((uVar8 == 0xfffffffd ||
            ((bVar13 = pbVar10[1] < pbVar11[1], pbVar10[1] == pbVar11[1] &&
             ((uVar8 == 0xfffffffe ||
              ((bVar13 = pbVar10[2] < pbVar11[2], pbVar10[2] == pbVar11[2] &&
               ((uVar8 == 0xffffffff || (bVar13 = pbVar10[3] < pbVar11[3], pbVar10[3] == pbVar11[3])
                ))))))))))) goto LAB_0078743a;
        uVar7 = -(uint)bVar13 | 1;
      }
      if (uVar7 == 0) {
        if (uVar1 < *(uint *)(param_4 + 0x10)) {
          bVar5 = 0;
          goto LAB_007874f6;
        }
        uVar7 = 0;
      }
      bVar5 = (byte)(uVar7 >> 0x1f) ^ 1;
    }
LAB_007874f6:
    if (bVar5 == 0) {
      puVar12 = (undefined4 *)puVar9[2];
    }
    else {
      puVar12 = (undefined4 *)*puVar9;
    }
    puVar3 = puVar9;
    puVar9 = puVar12;
    cVar6 = *(char *)((int)puVar12 + 0xd);
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar3;
  if (bVar5 != 0) {
    if (puVar3 == *(undefined4 **)*param_1) {
      bVar5 = 1;
      ExceptionList = &pvStack_10;
      pbVar10 = param_4;
      goto LAB_00787531;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  pbVar10 = param_4;
  puVar9 = _param_3;
  cVar6 = FUN_00570370(_param_3 + 4,param_4);
  iVar4 = param_5;
  if (cVar6 == '\0') {
    FUN_00787a40(param_1,param_5 + 0x10);
    FUN_01674ea0(iVar4,0x44);
    *param_2 = puVar9;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00787531:
  puVar9 = (undefined4 *)FUN_00786fd0(&param_3,bVar5,puVar3,pbVar10,param_5);
  *param_2 = *puVar9;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11180 ; VA 0x007875bd ; Catch_All@007875bd */

void Catch_All_007875bd(void)

{
  int unaff_EBP;
  
  FUN_0078a110(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11181 ; VA 0x007875e0 ; FUN_007875e0 */

undefined4 * __thiscall FUN_007875e0(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)((undefined4 *)*param_1)[1];
  cVar2 = *(char *)((int)puVar4 + 0xd);
  puVar1 = (undefined4 *)*param_1;
  while (cVar2 == '\0') {
    cVar2 = FUN_00570370(puVar4 + 4,param_2);
    if (cVar2 == '\0') {
      puVar3 = (undefined4 *)*puVar4;
    }
    else {
      puVar3 = (undefined4 *)puVar4[2];
      puVar4 = puVar1;
    }
    puVar1 = puVar4;
    puVar4 = puVar3;
    cVar2 = *(char *)((int)puVar3 + 0xd);
  }
  return puVar1;
}



/* FUNCTION 11182 ; VA 0x00787620 ; FUN_00787620 */

void __thiscall FUN_00787620(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0640;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Graphics::GlyphRenderer>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11183 ; VA 0x0078768e ; Catch_All@0078768e */

void Catch_All_0078768e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00789f10(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11184 ; VA 0x007876b0 ; FUN_007876b0 */

int __thiscall FUN_007876b0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0650;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TextService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11185 ; VA 0x00787782 ; Catch_All@00787782 */

void Catch_All_00787782(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11186 ; VA 0x007877b0 ; FUN_007877b0 */

undefined4 FUN_007877b0(int param_1)

{
  undefined4 uVar1;
  
  if (param_1 != 0) {
    uVar1 = FUN_006348f0();
    return uVar1;
  }
  return 0;
}



/* FUNCTION 11187 ; VA 0x007877d0 ; FUN_007877d0 */

undefined4 FUN_007877d0(int param_1)

{
  undefined4 uVar1;
  
  if (param_1 != 0) {
    uVar1 = FUN_005c2c60();
    return uVar1;
  }
  return 0;
}



/* FUNCTION 11188 ; VA 0x007877f0 ; FUN_007877f0 */

undefined4 * FUN_007877f0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0690;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00d27ac0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00d28880();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_007876b0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11189 ; VA 0x007878b0 ; FUN_007878b0 */

int FUN_007878b0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b06a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eb1cbc,&LAB_007877a0);
  uVar2 = FUN_00787aa0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00d27ba0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_007877f0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eb1cbc,&LAB_007877a0);
      uVar2 = FUN_00787aa0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 11190 ; VA 0x00787a40 ; FUN_00787a40 */

void FUN_00787a40(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00789bc0();
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 11191 ; VA 0x00787aa0 ; FUN_00787aa0 */

undefined4 FUN_00787aa0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b06cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1cc8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1cc8);
    if (DAT_01eb1cc8 == -1) {
      uStack_8 = 0;
      DAT_01eb1cc4 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eb1cc8);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eb1cc4;
}



/* FUNCTION 11192 ; VA 0x00787b20 ; FUN_00787b20 */

int * FUN_00787b20(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eb1cbc,&LAB_007877a0);
  uVar3 = FUN_00787aa0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00d27ba0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 11193 ; VA 0x00787bd0 ; FUN_00787bd0 */

void FUN_00787bd0(char *param_1,char *param_2,char *param_3,char *param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = 0;
  iVar2 = (int)param_2 - (int)param_1;
  if (param_2 < param_1) {
    iVar2 = 0;
  }
  if (iVar2 != 0) {
    do {
      if (*param_1 == *param_3) {
        *param_1 = *param_4;
      }
      iVar1 = iVar1 + 1;
      param_1 = param_1 + 1;
    } while (iVar1 != iVar2);
  }
  return;
}



/* FUNCTION 11194 ; VA 0x00787c10 ; FUN_00787c10 */

undefined4 * __thiscall
FUN_00787c10(undefined4 *param_1,int *param_2,undefined4 param_3,undefined4 *param_4)

{
  int iVar1;
  undefined uVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  uint in_stack_ffffff78;
  undefined4 in_stack_ffffff7c;
  undefined4 in_stack_ffffff80;
  undefined4 in_stack_ffffff84;
  undefined4 uVar12;
  int aiStack_60 [5];
  uint uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint auStack_3c [3];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b0b75;
  pvStack_10 = ExceptionList;
  iStack_14 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::VisualEngine::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[10] = 0;
  *(undefined8 *)(param_1 + 8) = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  param_1[0xf] = param_2;
  puStack_20 = param_1;
  FUN_007cc9d0();
  FUN_007cc9d0();
  param_1[0x132] = 0;
  param_1[0x133] = 0;
  param_1[0x134] = 0;
  param_1[0x135] = 0;
  param_1[0x136] = 0;
  param_1[0x137] = 0;
  param_1[0x138] = 0x3f800000;
  param_1[0x139] = 0;
  param_1[0x13a] = 0;
  param_1[0x13b] = 0;
  param_1[0x13c] = 0;
  param_1[0x13d] = 0;
  param_1[0x13e] = 0;
  param_1[0x13f] = 0;
  param_1[0x140] = 0;
  param_1[0x141] = 0;
  param_1[0x142] = 0;
  param_1[0x143] = 0;
  param_1[0x144] = param_3;
  param_1[0x145] = 0;
  param_1[0x146] = 0;
  param_1[0x147] = 0;
  param_1[0x148] = 0;
  param_1[0x149] = 0;
  param_1[0x14a] = 0;
  param_1[0x14b] = 0;
  param_1[0x14c] = 0;
  param_1[0x14d] = 0;
  param_1[0x14e] = 0;
  param_1[0x14f] = 0;
  param_1[0x150] = 0;
  param_1[0x151] = 0;
  param_1[0x152] = 0;
  param_1[0x153] = 0;
  param_1[0x154] = 0;
  param_1[0x155] = 0;
  param_1[0x156] = 0;
  param_1[0x157] = 0;
  param_1[0x158] = 0;
  param_1[0x159] = 0;
  param_1[0x15a] = 0;
  param_1[0x15b] = 0;
  param_1[0x15c] = 0;
  param_1[0x15d] = 0;
  param_1[0x15e] = 0;
  *(undefined *)(param_1 + 0x15f) = 0;
  uVar4 = FUN_00588320(0xb);
  param_1[0x160] = uVar4;
  param_1[0x161] = 0;
  param_1[0x162] = 0x3f800000;
  param_1[0x163] = 0;
  param_1[0x164] = 0;
  puVar7 = param_1 + 0x166;
  param_1[0x165] = param_4;
  uStack_8 = 0x1d;
  *puVar7 = 0;
  param_1[0x167] = 0;
  param_4 = puVar7;
  uVar4 = FUN_0078a0b0();
  *puVar7 = uVar4;
  param_1[0x168] = 0;
  param_1[0x169] = 0;
  param_1[0x16a] = 0;
  param_1[0x16f] = 0;
  param_1[0x170] = 0xf;
  *(undefined *)(param_1 + 0x16b) = 0;
  param_1[0x171] = 0;
  param_1[0x172] = 0;
  param_1[0x173] = 0;
  param_1[0x178] = 0;
  param_1[0x179] = 0xf;
  *(undefined *)(param_1 + 0x174) = 0;
  *(undefined *)(param_1 + 0x17a) = 0;
  uStack_8 = 0x23;
  uVar4 = FUN_01675290(DAT_01eb1ca0);
  uStack_8 = 0x24;
  uStack_24 = uVar4;
  param_4 = (undefined4 *)FUN_01674e20(0xa0);
  uStack_8 = 0x25;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_01154f00();
  }
  iVar6 = param_1[0x149];
  uStack_8 = 0x24;
  param_1[0x149] = uVar5;
  if (iVar6 != 0) {
    _guard_check_icall();
    FUN_01674ea0(iVar6,0xa0);
  }
  param_4 = (undefined4 *)FUN_01674e20(0xa0);
  uStack_8 = 0x26;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_01154f00();
  }
  iVar6 = param_1[0x14a];
  uStack_8 = 0x24;
  param_1[0x14a] = uVar5;
  if (iVar6 != 0) {
    _guard_check_icall();
    FUN_01674ea0(iVar6,0xa0);
  }
  piVar11 = param_2;
  iVar6 = (**(code **)(*param_2 + 0x40))();
  param_4 = *(undefined4 **)(iVar6 + 0x40);
  if ((*(int *)(iVar6 + 0x44) != 0) || (0x80000000 < param_4)) {
    param_4 = (undefined4 *)0x80000000;
  }
  iStack_14 = FUN_01674e20(0x24);
  uStack_8 = 0x27;
  if (iStack_14 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = 0;
    uVar12 = 0xf;
    in_stack_ffffff78 = in_stack_ffffff78 & 0xffffff00;
    uVar10 = (uint)param_4;
    FUN_005542c0("Unknown",7);
    uVar5 = FUN_01155040(in_stack_ffffff78,in_stack_ffffff7c,in_stack_ffffff80,in_stack_ffffff84,
                         uVar5,uVar12,uVar10);
  }
  iVar6 = param_1[0x148];
  _uStack_8 = CONCAT31(uStack_7,0x24);
  param_1[0x148] = uVar5;
  if (iVar6 != 0) {
    FUN_00789ea0(iVar6);
  }
  if (DAT_01f6dcc0 != '\0') {
    FUN_016774b0(DAT_01f6dcc0,"Video memory size: %lld",param_4);
  }
  param_4 = (undefined4 *)FUN_01674e20(0x30);
  uStack_8 = 0x28;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_007d5ea0(piVar11);
  }
  param_4 = (undefined4 *)param_1[0x143];
  _uStack_8 = CONCAT31(uStack_7,0x24);
  param_1[0x143] = uVar5;
  if (param_4 != (undefined4 *)0x0) {
    FUN_00789040();
    FUN_00789040();
    FUN_01674ea0(param_4,0x30);
  }
  FUN_005542c0(&DAT_018fc7ac,7);
  if ((DAT_01d6c814 != '\0') || (DAT_01d60e88 != '\0')) {
    if (DAT_01d60e90 == '\0') {
      FUN_00554150("DoubleSided",0xb);
    }
    else {
      FUN_00554150("DoubleSidedFix",0xe);
    }
    goto LAB_007881b4;
  }
  puVar7 = (undefined4 *)(**(code **)(*piVar11 + 0x30))(aiStack_60);
  if (DAT_01d60e40 == '\0') {
LAB_00788160:
    if (DAT_01d60e48 != '\0') {
      puVar8 = puVar7 + 4;
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      cVar3 = FUN_0055c360(puVar7,*puVar8,"glsles3",7);
      param_4 = (undefined4 *)CONCAT13(1,param_4._0_3_);
      if (cVar3 != '\0') goto LAB_00788191;
    }
    param_4 = (undefined4 *)((uint)param_4 & 0xffffff);
  }
  else {
    puVar8 = puVar7;
    if (0xf < (uint)puVar7[5]) {
      puVar8 = (undefined4 *)*puVar7;
    }
    cVar3 = FUN_0055c360(puVar8,puVar7[4],"glsles",6);
    if (cVar3 == '\0') goto LAB_00788160;
    param_4 = (undefined4 *)CONCAT13(1,param_4._0_3_);
  }
LAB_00788191:
  FUN_005507b0();
  piVar11 = param_2;
  if (param_4._3_1_ != '\0') {
    FUN_00554150("Mediump",7);
    piVar11 = param_2;
  }
LAB_007881b4:
  param_4 = (undefined4 *)FUN_01674e20(0x60);
  uStack_8 = 0x29;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_00790220(param_1);
  }
  param_4 = (undefined4 *)param_1[0x13d];
  uStack_8 = 0x24;
  param_1[0x13d] = uVar5;
  if (param_4 != (undefined4 *)0x0) {
    FUN_007903d0();
    FUN_01674ea0(param_4,0x60);
  }
  puStack_1c = (undefined4 *)param_1[0x13d];
  uStack_18 = (**(code **)(*piVar11 + 0x30))(aiStack_60);
  uStack_8 = 0x2a;
  param_4 = (undefined4 *)FUN_008c8420();
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  uStack_8 = 0x2b;
  iStack_14 = 1;
  FUN_0058a190(param_4[4] + 10);
  puVar7 = param_4;
  if (0xf < (uint)param_4[5]) {
    puVar7 = (undefined4 *)*param_4;
  }
  FUN_00554150(puVar7,param_4[4]);
  FUN_00554150("../shaders",10);
  FUN_00791300(auStack_3c,uStack_18,param_1 + 0x16b,0);
  uStack_8 = 0x2a;
  uVar2 = uStack_8;
  uStack_8 = 0x2a;
  if (0xf < uStack_28) {
    uVar9 = uStack_28 + 1;
    uVar10 = auStack_3c[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_3c[0] - 4);
      uVar9 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar10) - 4) {
        uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  uStack_8 = 0x24;
  uVar2 = uStack_8;
  uStack_8 = 0x24;
  if (0xf < uStack_4c) {
    uVar10 = uStack_4c + 1;
    iVar6 = aiStack_60[0];
    if (0xfff < uVar10) {
      iVar6 = *(int *)(aiStack_60[0] + -4);
      uVar10 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar6) - 4U) {
        uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar10);
  }
  param_4 = (undefined4 *)FUN_01674e20(0x10c);
  uStack_8 = 0x2c;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_0077e410(param_1);
  }
  param_4 = (undefined4 *)param_1[0x13b];
  uStack_8 = 0x24;
  param_1[0x13b] = uVar5;
  if (param_4 != (undefined4 *)0x0) {
    FUN_0077f640();
    FUN_01674ea0(param_4,0x10c);
  }
  param_4 = (undefined4 *)FUN_01674e20(0xc);
  uStack_8 = 0x2d;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_007d6820();
  }
  param_4 = (undefined4 *)param_1[0x13c];
  _uStack_8 = CONCAT31(uStack_7,0x24);
  param_1[0x13c] = uVar5;
  if (param_4 != (undefined4 *)0x0) {
    FUN_007d68d0();
    FUN_01674ea0(param_4,0xc);
  }
  puVar8 = (undefined4 *)(**(code **)(*piVar11 + 0x30))(aiStack_60);
  puVar7 = puVar8 + 4;
  if (0xf < (uint)puVar8[5]) {
    puVar8 = (undefined4 *)*puVar8;
  }
  uVar10 = FUN_0055c360(puVar8,*puVar7,"glsles",6);
  param_4 = (undefined4 *)(uVar10 & 0xff ^ 1);
  if (0xf < uStack_4c) {
    uVar10 = uStack_4c + 1;
    iVar6 = aiStack_60[0];
    if (0xfff < uVar10) {
      iVar6 = *(int *)(aiStack_60[0] + -4);
      uVar10 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar10);
  }
  uStack_2c = 4;
  if (*(uint *)param_1[0x148] < 0x6400001) {
    uStack_30 = 4;
    uStack_28 = 4;
  }
  else {
    uStack_30 = 8;
    uStack_28 = 8;
  }
  uStack_48 = CONCAT44(4,uStack_30);
  uStack_40 = uStack_28;
  puVar7 = (undefined4 *)FUN_01675290(DAT_01eb1c9c);
  _uStack_8 = CONCAT31(uStack_7,0x2e);
  puStack_1c = puVar7;
  if (DAT_01d60e68 == '\0') {
    uVar5 = FUN_007e6680(param_1,&uStack_48,param_4);
  }
  else {
    uVar5 = FUN_007eff30();
  }
  puVar8 = (undefined4 *)param_1[0x14b];
  param_1[0x14b] = uVar5;
  if (puVar8 != (undefined4 *)0x0) {
    (**(code **)*puVar8)(1);
  }
  uStack_8 = 0x2f;
  FUN_01675290(puVar7);
  uStack_8 = 0x24;
  FUN_0078bd30();
  param_4 = (undefined4 *)FUN_01674e20(&LAB_0051dda8);
  uStack_8 = 0x30;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_0075d8e0(param_1);
  }
  iVar6 = param_1[0x153];
  _uStack_8 = CONCAT31(uStack_7,0x24);
  param_1[0x153] = uVar5;
  if (iVar6 != 0) {
    FUN_00789f40(1);
  }
  param_4 = (undefined4 *)FUN_01674e20(0x10);
  if (param_4 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    *param_4 = param_1;
    param_4[1] = 0;
    param_4[2] = 0;
    param_4[3] = 0;
    puVar7 = param_4;
  }
  iVar6 = param_1[0x154];
  param_1[0x154] = puVar7;
  if (iVar6 != 0) {
    FUN_00788fb0();
    FUN_01674ea0(iVar6,0x10);
  }
  param_4 = (undefined4 *)FUN_01674e20(0x4b8);
  uStack_8 = 0x31;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_007920d0(param_1);
  }
  iVar6 = param_1[0x13e];
  uStack_8 = 0x24;
  param_1[0x13e] = uVar5;
  if (iVar6 != 0) {
    FUN_00793620();
    FUN_01674ea0(iVar6,0x4b8);
  }
  param_4 = (undefined4 *)FUN_01674e20(0x208);
  uStack_8 = 0x32;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_01155340();
  }
  iVar6 = param_1[0x13f];
  uStack_8 = 0x24;
  param_1[0x13f] = uVar5;
  if (iVar6 != 0) {
    FUN_01155670();
    FUN_01674ea0(iVar6,0x208);
  }
  param_4 = (undefined4 *)FUN_01674e20(0x178);
  uStack_8 = 0x33;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_007f7850(param_1);
  }
  iVar6 = param_1[0x133];
  uStack_8 = 0x24;
  param_1[0x133] = uVar5;
  if (iVar6 != 0) {
    FUN_007f8b70();
    FUN_01674ea0(iVar6,0x178);
  }
  param_4 = (undefined4 *)FUN_01674e20(0x80);
  uStack_8 = 0x34;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_00776aa0(param_1);
  }
  puVar7 = (undefined4 *)param_1[0x13a];
  uStack_8 = 0x24;
  param_1[0x13a] = uVar5;
  if (puVar7 != (undefined4 *)0x0) {
    (**(code **)*puVar7)(1);
  }
  iVar6 = FUN_01674e20(0xc0);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    *(undefined4 *)(iVar6 + 4) = 0;
    *(undefined4 *)(iVar6 + 8) = 0;
    *(undefined4 *)(iVar6 + 0xc) = 0;
    *(undefined4 *)(iVar6 + 0x10) = 0;
    *(undefined4 *)(iVar6 + 0x14) = 0;
    *(undefined4 *)(iVar6 + 0x18) = 0;
    *(undefined4 *)(iVar6 + 0x1c) = 0;
    *(undefined4 *)(iVar6 + 0x20) = 0;
    uStack_8 = 0x39;
    param_4 = (undefined4 *)iVar6;
    FUN_016f4053(iVar6 + 0x24,8,10,FUN_005502b0,FUN_00550b30);
    *(undefined4 *)(iVar6 + 0x74) = 0;
    *(undefined4 *)(iVar6 + 0x78) = 0;
    *(undefined4 *)(iVar6 + 0x7c) = 0;
    *(undefined4 *)(iVar6 + 0x80) = 0;
    uStack_8 = 0x3c;
    FUN_01166000(0xf018a4d2);
    *(undefined4 *)(iVar6 + 0x94) = 0;
    *(undefined4 *)(iVar6 + 0x98) = 0;
    *(undefined4 *)(iVar6 + 0x9c) = 0;
    *(undefined4 *)(iVar6 + 0xa0) = 0;
    *(undefined4 *)(iVar6 + 0xa4) = 0;
    *(undefined4 *)(iVar6 + 0xa8) = 0;
    *(undefined4 *)(iVar6 + 0xb0) = 0;
    *(undefined4 *)(iVar6 + 0xb4) = 0;
    *(undefined4 *)(iVar6 + 0xac) = 0;
  }
  param_4 = (undefined4 *)param_1[0x140];
  uStack_8 = 0x24;
  param_1[0x140] = iVar6;
  if (param_4 != (undefined4 *)0x0) {
    FUN_007890e0();
    FUN_01674ea0(param_4,0xc0);
  }
  iVar6 = FUN_01674e20(0x88);
  param_4 = (undefined4 *)iVar6;
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    *(undefined4 *)(iVar6 + 4) = 0;
    *(undefined4 *)(iVar6 + 8) = 0;
    *(undefined4 *)(iVar6 + 0xc) = 0;
    *(undefined4 *)(iVar6 + 0x10) = 0;
    *(undefined4 *)(iVar6 + 0x14) = 0;
    *(undefined4 *)(iVar6 + 0x18) = 0;
    *(undefined4 *)(iVar6 + 0x1c) = 0;
    *(undefined4 *)(iVar6 + 0x20) = 0;
    *(undefined4 *)(iVar6 + 0x24) = 0;
    *(undefined4 *)(iVar6 + 0x28) = 0;
    *(undefined4 *)(iVar6 + 0x2c) = 0;
    *(undefined4 *)(iVar6 + 0x30) = 0;
    *(undefined4 *)(iVar6 + 0x34) = 0;
    *(undefined4 *)(iVar6 + 0x38) = 0;
    *(undefined4 *)(iVar6 + 0x3c) = 0;
    *(undefined4 *)(iVar6 + 0x40) = 0;
    *(undefined4 *)(iVar6 + 0x44) = 0;
    *(undefined4 *)(iVar6 + 0x48) = 0;
    *(undefined4 *)(iVar6 + 0x4c) = 0;
    *(undefined4 *)(iVar6 + 0x50) = 0;
    *(undefined4 *)(iVar6 + 0x54) = 0;
    *(undefined4 *)(iVar6 + 0x58) = 0;
    *(undefined4 *)(iVar6 + 0x5c) = 0;
    *(undefined4 *)(iVar6 + 0x60) = 0;
    *(undefined4 *)(iVar6 + 100) = 0;
    puVar7 = (undefined4 *)(iVar6 + 0x68);
    uStack_8 = 0x4c;
    *puVar7 = 0;
    *(undefined4 *)(iVar6 + 0x6c) = 0;
    *(undefined4 *)(iVar6 + 0x70) = 0;
    puStack_1c = puVar7;
    uVar5 = FUN_00575b50(0,0);
    *(undefined4 *)(iVar6 + 0x6c) = uVar5;
    *(undefined4 *)(iVar6 + 0x74) = 0;
    *(undefined4 *)(iVar6 + 0x78) = 0;
    *(undefined4 *)(iVar6 + 0x7c) = 0;
    uStack_8 = 0x4e;
    *puVar7 = 0x3f800000;
    FUN_005cb500(8);
    iVar6 = (int)param_4;
    param_1 = puStack_20;
  }
  iVar1 = param_1[0x141];
  uStack_8 = 0x24;
  param_1[0x141] = iVar6;
  if (iVar1 != 0) {
    FUN_00789310();
    FUN_01674ea0(iVar1,0x88);
  }
  param_4 = (undefined4 *)FUN_01674e20(0x110);
  uStack_8 = 0x4f;
  if (param_4 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_0076a570(param_1);
  }
  iVar6 = param_1[0x142];
  _uStack_8 = CONCAT31(uStack_7,0x24);
  param_1[0x142] = uVar5;
  if (iVar6 != 0) {
    FUN_0076b1f0();
    FUN_01674ea0(iVar6,0x110);
  }
  piVar11 = param_2;
  puVar8 = (undefined4 *)(**(code **)(*param_2 + 0x30))(aiStack_60);
  puVar7 = puVar8 + 4;
  if (0xf < (uint)puVar8[5]) {
    puVar8 = (undefined4 *)*puVar8;
  }
  cVar3 = FUN_0055c360(puVar8,*puVar7,"glsles",6);
  param_2 = (int *)0x48;
  if (cVar3 != '\0') {
    param_2 = (int *)0x20;
  }
  if (0xf < uStack_4c) {
    uVar10 = uStack_4c + 1;
    iVar6 = aiStack_60[0];
    if (0xfff < uVar10) {
      iVar6 = *(int *)(aiStack_60[0] + -4);
      uVar10 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar10);
  }
  *(int **)(param_1[0x148] + 0x20) = param_2;
  FUN_01155fc0(param_1[0x148],param_3);
  param_2 = (int *)FUN_01674e20(0xfc0);
  uStack_8 = 0x50;
  if (param_2 == (int *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_0078e6a0();
  }
  param_2 = (int *)param_1[0x16a];
  uStack_8 = 0x24;
  param_1[0x16a] = uVar5;
  if (param_2 != (undefined4 *)0x0) {
    uStack_8 = 0x51;
    FUN_016f32d1(param_2,0xa8,0x18,FUN_00789520);
    uStack_8 = 0x24;
    FUN_01674ea0(param_2,0xfc0);
  }
  FUN_007b40c0(piVar11);
  FUN_007aa5c0(piVar11);
  iStack_14 = 0;
  if (DAT_01d60ea0 != '\0') {
    param_3 = FUN_00bac980();
    uStack_8 = 0x52;
    puVar7 = (undefined4 *)FUN_01675290(DAT_02110da8);
    uStack_8 = 0x53;
    puStack_1c = puVar7;
    param_4 = (undefined4 *)FUN_01674e20(0x1c);
    if (param_4 == (undefined4 *)0x0) {
      param_4 = (undefined4 *)0x0;
    }
    else {
      *param_4 = 0;
      param_4[1] = 1;
      param_4[2] = FUN_0078adf0;
      param_4[3] = _guard_check_icall;
      param_4[4] = 0;
      param_4[5] = param_3;
      param_4[6] = param_1;
    }
    FUN_016797d0(param_4);
    param_2 = param_4;
    if (param_4 != (undefined4 *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    iStack_14 = 2;
    uStack_8 = 0x54;
    FUN_01675290(puVar7);
    _uStack_8 = CONCAT31(uStack_7,0x52);
    cVar3 = FUN_01679300(&param_2);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_2);
    }
    uStack_8 = 0x24;
    if (param_2 != (undefined4 *)0x0) {
      piVar11 = param_2 + 1;
      LOCK();
      iVar6 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      iStack_14 = 0;
      if (iVar6 == 1) {
        FUN_01674ea0(param_2);
      }
    }
  }
  iStack_14 = 0;
  if (DAT_01d60e80 != '\0') {
    param_3 = FUN_0153c830();
    uStack_8 = 0x55;
    puVar7 = (undefined4 *)FUN_01675290(DAT_02110da8);
    uStack_8 = 0x56;
    puStack_1c = puVar7;
    param_4 = (undefined4 *)FUN_01674e20(0x1c);
    if (param_4 == (undefined4 *)0x0) {
      param_4 = (undefined4 *)0x0;
    }
    else {
      *param_4 = 0;
      param_4[1] = 1;
      param_4[2] = FUN_0078ae10;
      param_4[3] = _guard_check_icall;
      param_4[4] = 0;
      param_4[5] = param_3;
      param_4[6] = param_1;
    }
    FUN_016797d0(param_4);
    param_2 = param_4;
    if (param_4 != (undefined4 *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    iStack_14 = 4;
    uStack_8 = 0x57;
    FUN_01675290(puVar7);
    uStack_8 = 0x55;
    cVar3 = FUN_01679300(&param_2);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_2);
    }
    if (param_2 != (undefined4 *)0x0) {
      piVar11 = param_2 + 1;
      LOCK();
      iVar6 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        FUN_01674ea0(param_2);
      }
    }
  }
  _uStack_8 = CONCAT31(uStack_7,0x58);
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11195 ; VA 0x00788ca0 ; FUN_00788ca0 */

void __fastcall FUN_00788ca0(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1,0xa8,0x18,FUN_00789520);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11196 ; VA 0x00788ce0 ; FUN_00788ce0 */

void __fastcall FUN_00788ce0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0078a140(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x44);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11197 ; VA 0x00788d40 ; FUN_00788d40 */

void __fastcall FUN_00788d40(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_007890e0();
    FUN_01674ea0(iVar1,0xc0);
  }
  return;
}



/* FUNCTION 11198 ; VA 0x00788d60 ; FUN_00788d60 */

void __fastcall FUN_00788d60(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00789310();
    FUN_01674ea0(iVar1,0x88);
  }
  return;
}



/* FUNCTION 11199 ; VA 0x00788d80 ; FUN_00788d80 */

void __fastcall FUN_00788d80(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00789040();
    FUN_00789040();
    FUN_01674ea0(iVar1,0x30);
  }
  return;
}



/* FUNCTION 11200 ; VA 0x00788db0 ; FUN_00788db0 */

void __fastcall FUN_00788db0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_01155670();
    FUN_01674ea0(iVar1,0x208);
  }
  return;
}



/* FUNCTION 11201 ; VA 0x00788dd0 ; FUN_00788dd0 */

void __fastcall FUN_00788dd0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_00789f40(1);
  }
  return;
}



/* FUNCTION 11202 ; VA 0x00788de0 ; FUN_00788de0 */

void __fastcall FUN_00788de0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_0076b1f0();
    FUN_01674ea0(iVar1,0x110);
  }
  return;
}



/* FUNCTION 11203 ; VA 0x00788e00 ; FUN_00788e00 */

void __fastcall FUN_00788e00(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar1,0xa8,0x18,FUN_00789520);
    FUN_01674ea0(iVar1,0xfc0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11204 ; VA 0x00788e60 ; FUN_00788e60 */

void __fastcall FUN_00788e60(int *param_1)

{
  if (*param_1 != 0) {
    FUN_00789ea0(*param_1);
  }
  return;
}



/* FUNCTION 11205 ; VA 0x00788e70 ; FUN_00788e70 */

void __fastcall FUN_00788e70(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar1,0xc,0xf,FUN_00612d60);
    FUN_01674ea0(iVar1,0xbc);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11206 ; VA 0x00788ed0 ; FUN_00788ed0 */

void __fastcall FUN_00788ed0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    _guard_check_icall();
    FUN_01674ea0(iVar1,0xa0);
  }
  return;
}



/* FUNCTION 11207 ; VA 0x00788ef0 ; FUN_00788ef0 */

void __fastcall FUN_00788ef0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00793620();
    FUN_01674ea0(iVar1,0x4b8);
  }
  return;
}



/* FUNCTION 11208 ; VA 0x00788f10 ; FUN_00788f10 */

void __fastcall FUN_00788f10(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_007903d0();
    FUN_01674ea0(iVar1,0x60);
  }
  return;
}



/* FUNCTION 11209 ; VA 0x00788f30 ; FUN_00788f30 */

void __fastcall FUN_00788f30(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_0077f640();
    FUN_01674ea0(iVar1,0x10c);
  }
  return;
}



/* FUNCTION 11210 ; VA 0x00788f50 ; FUN_00788f50 */

void __fastcall FUN_00788f50(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00788fb0();
    FUN_01674ea0(iVar1,0x10);
  }
  return;
}



/* FUNCTION 11211 ; VA 0x00788f70 ; FUN_00788f70 */

void __fastcall FUN_00788f70(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_007f8b70();
    FUN_01674ea0(iVar1,0x178);
  }
  return;
}



/* FUNCTION 11212 ; VA 0x00788f90 ; FUN_00788f90 */

void __fastcall FUN_00788f90(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_007d68d0();
    FUN_01674ea0(iVar1,0xc);
  }
  return;
}



/* FUNCTION 11213 ; VA 0x00788fb0 ; FUN_00788fb0 */

void __fastcall FUN_00788fb0(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        iVar4 = iVar4 + 0x10;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = param_1[2] - iVar4 & 0xfffffff0;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11214 ; VA 0x00789040 ; FUN_00789040 */

void __fastcall FUN_00789040(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar4 = iVar4 + 0x10;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = param_1[2] - iVar4 & 0xfffffff0;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11215 ; VA 0x007890e0 ; FUN_007890e0 */

int __fastcall FUN_007890e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0xac));
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0;
  *(undefined4 *)(param_1 + 0xb4) = 0;
  iVar4 = *(int *)(param_1 + 0xa0);
  uStack_8 = 0xffffffff;
  if (iVar4 != 0) {
    uVar5 = *(int *)(param_1 + 0xa8) - iVar4 & 0xfffffffc;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_00789304;
    }
    FUN_01674ea0(iVar3,uVar5);
    *(undefined4 *)(param_1 + 0xa0) = 0;
    *(undefined4 *)(param_1 + 0xa4) = 0;
    *(undefined4 *)(param_1 + 0xa8) = 0;
  }
  iVar4 = *(int *)(param_1 + 0x94);
  if (iVar4 != 0) {
    uVar5 = *(int *)(param_1 + 0x9c) - iVar4 & 0xfffffffc;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) {
LAB_00789304:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
    *(undefined4 *)(param_1 + 0x94) = 0;
    *(undefined4 *)(param_1 + 0x98) = 0;
    *(undefined4 *)(param_1 + 0x9c) = 0;
  }
  FUN_01166070();
  piVar2 = *(int **)(param_1 + 0x80);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x78);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar4 = FUN_016f32d1(param_1 + 0x24,8,10,FUN_00550b30);
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 11216 ; VA 0x00789310 ; FUN_00789310 */

int __fastcall FUN_00789310(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  FUN_0070a3d0();
  iVar4 = *(int *)(param_1 + 0x5c);
  if (iVar4 != 0) {
    uVar5 = *(int *)(param_1 + 100) - iVar4 & 0xfffffffc;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar3,uVar5);
    *(undefined4 *)(param_1 + 0x5c) = 0;
    *(undefined4 *)(param_1 + 0x60) = 0;
    *(undefined4 *)(param_1 + 100) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x58);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x50);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x48);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x40);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x38);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x30);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x28);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0078950d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar2 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 11217 ; VA 0x00789520 ; FUN_00789520 */

void __fastcall FUN_00789520(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0xa4);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x90);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0078964d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xa0) = 0;
  *(undefined4 *)(param_1 + 0xa4) = 0xf;
  *(undefined *)(param_1 + 0x90) = 0;
  uVar1 = *(uint *)(param_1 + 0x8c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x78);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0078964d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0xf;
  *(undefined *)(param_1 + 0x78) = 0;
  uVar1 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x60);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0078964d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  uVar1 = *(uint *)(param_1 + 0x5c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x48);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0078964d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  return;
}



/* FUNCTION 11218 ; VA 0x00789660 ; FUN_00789660 */

void __fastcall FUN_00789660(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1,0xc,0xf,FUN_00612d60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11219 ; VA 0x007896a0 ; FUN_007896a0 */

void __fastcall FUN_007896a0(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::VisualEngine::vftable;
  FUN_01679490();
  if (DAT_01d60ea0 != '\0') {
    FUN_01679490();
  }
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  FUN_0078a530(&uStack_18);
  piVar3 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uVar2 = param_1[0x179];
  if (0xf < uVar2) {
    iVar4 = param_1[0x174];
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_00789bb1;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x178] = 0;
  param_1[0x179] = 0xf;
  *(undefined *)(param_1 + 0x174) = 0;
  if (param_1[0x173] != 0) {
    FUN_01674ea0(param_1[0x173],1);
  }
  uVar2 = param_1[0x170];
  if (0xf < uVar2) {
    iVar4 = param_1[0x16b];
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_00789bb1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x16f] = 0;
  param_1[0x170] = 0xf;
  *(undefined *)(param_1 + 0x16b) = 0;
  iVar4 = param_1[0x16a];
  if (iVar4 != 0) {
    uStack_8 = 0;
    FUN_016f32d1(iVar4,0xa8,0x18,FUN_00789520);
    FUN_01674ea0(iVar4,0xfc0);
  }
  piVar3 = (int *)param_1[0x169];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar4 = param_1[0x166];
  piVar3 = param_1 + 0x166;
  uStack_8 = 1;
  FUN_0078a140(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar3 + 4) = iVar4;
  *(int *)*piVar3 = iVar4;
  *(int *)(*piVar3 + 8) = iVar4;
  param_1[0x167] = 0;
  FUN_01674ea0(*piVar3,0x44);
  FUN_005d1280();
  if ((undefined4 *)param_1[0x15e] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x15e])(1);
  }
  if ((undefined4 *)param_1[0x15d] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x15d])(1);
  }
  piVar3 = (int *)param_1[0x15c];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x15a];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x158];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x156];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar4 = param_1[0x154];
  if (iVar4 != 0) {
    FUN_00788fb0();
    FUN_01674ea0(iVar4,0x10);
  }
  if (param_1[0x153] != 0) {
    FUN_00789f40(1);
  }
  FUN_00577ac0();
  if ((undefined4 *)param_1[0x14f] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x14f])(1);
  }
  FUN_00577ac0();
  if ((undefined4 *)param_1[0x14b] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x14b])(1);
  }
  iVar4 = param_1[0x14a];
  if (iVar4 != 0) {
    _guard_check_icall();
    FUN_01674ea0(iVar4,0xa0);
  }
  iVar4 = param_1[0x149];
  if (iVar4 != 0) {
    _guard_check_icall();
    FUN_01674ea0(iVar4,0xa0);
  }
  if (param_1[0x148] != 0) {
    FUN_00789ea0(param_1[0x148]);
  }
  iVar4 = param_1[0x143];
  if (iVar4 != 0) {
    FUN_00789040();
    FUN_00789040();
    FUN_01674ea0(iVar4,0x30);
  }
  iVar4 = param_1[0x142];
  if (iVar4 != 0) {
    FUN_0076b1f0();
    FUN_01674ea0(iVar4,0x110);
  }
  iVar4 = param_1[0x141];
  if (iVar4 != 0) {
    FUN_00789310();
    FUN_01674ea0(iVar4,0x88);
  }
  iVar4 = param_1[0x140];
  if (iVar4 != 0) {
    FUN_007890e0();
    FUN_01674ea0(iVar4,0xc0);
  }
  iVar4 = param_1[0x13f];
  if (iVar4 != 0) {
    FUN_01155670();
    FUN_01674ea0(iVar4,0x208);
  }
  iVar4 = param_1[0x13e];
  if (iVar4 != 0) {
    FUN_00793620();
    FUN_01674ea0(iVar4,0x4b8);
  }
  iVar4 = param_1[0x13d];
  if (iVar4 != 0) {
    FUN_007903d0();
    FUN_01674ea0(iVar4,0x60);
  }
  iVar4 = param_1[0x13c];
  if (iVar4 != 0) {
    FUN_007d68d0();
    FUN_01674ea0(iVar4,0xc);
  }
  iVar4 = param_1[0x13b];
  if (iVar4 != 0) {
    FUN_0077f640();
    FUN_01674ea0(iVar4,0x10c);
  }
  if ((undefined4 *)param_1[0x13a] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x13a])(1);
  }
  if ((undefined4 *)param_1[0x139] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x139])(1);
  }
  FUN_00789bc0();
  uStack_8 = 2;
  FUN_01679490();
  iVar4 = param_1[0xe];
  if (iVar4 != 0) {
    piVar3 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar4 = param_1[0xd];
  if (iVar4 != 0) {
    piVar3 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11220 ; VA 0x00789bc0 ; FUN_00789bc0 */

void __fastcall FUN_00789bc0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[2];
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar1,0xc,0xf,FUN_00612d60);
    FUN_01674ea0(iVar1,0xbc);
  }
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    FUN_007f8b70();
    FUN_01674ea0(iVar1,0x178);
  }
  if ((int *)*param_1 != (int *)0x0) {
    (**(code **)(*(int *)*param_1 + 4))(1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11221 ; VA 0x00789c40 ; FUN_00789c40 */

int * __thiscall FUN_00789c40(int param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  undefined4 *puVar11;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0b90;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_005702d0(param_2);
  uStack_14 = uVar4 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar11 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
    uVar10 = uStack_14;
    if (puVar11 == (undefined4 *)0x0) {
      puVar11 = (undefined4 *)0x0;
    }
    else {
      puVar11 = (undefined4 *)*puVar11;
    }
    for (; puVar11 != (undefined4 *)0x0; puVar11 = (undefined4 *)*puVar11) {
      if (uVar4 == puVar11[1]) {
        piVar5 = puVar11 + 2;
        if (0xf < (uint)puVar11[7]) {
          piVar5 = (int *)*piVar5;
        }
        puVar7 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar7 = (undefined4 *)*param_2;
        }
        cVar3 = FUN_0055c360(puVar7,param_2[4],piVar5,puVar11[6]);
        uVar10 = uStack_14;
        if (cVar3 != '\0') {
          if (puVar11 != (undefined4 *)0x0) {
            ExceptionList = pvStack_10;
            return puVar11 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar11[1] % *(uint *)(param_1 + 4) != uVar10) break;
    }
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != -3) & param_1 + 4U;
  iStack_8 = 0;
  FUN_0054ef60(param_2);
  iStack_8._0_1_ = 1;
  FUN_005d2a40();
  piVar5 = piStack_20;
  piStack_18 = piStack_20 + 2;
  FUN_0054ef60(aiStack_3c);
  if (piVar5 + 8 != (int *)0x0) {
    piVar5[8] = 0;
  }
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar10 = uStack_28 + 1;
    iVar6 = aiStack_3c[0];
    if (0xfff < uVar10) {
      iVar6 = *(int *)(aiStack_3c[0] + -4);
      uVar10 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar10);
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar10 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar10 = FUN_005d6bb0(uVar10);
    if (uVar10 <= *(uint *)(param_1 + 4)) {
      uVar10 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar10);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar10) {
    uStack_14 = 1;
    uVar8 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar10) {
      uVar8 = 1;
    }
    iVar6 = FUN_005d6bb0(uVar8 + uVar2);
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar6);
      puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar11;
      while (puVar7 != (undefined4 *)0x0) {
        uVar10 = (uint)puVar7[1] % *(uint *)(param_1 + 4);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar10 * 4) == 0) {
          *piVar1 = (int)puVar11;
          puVar11 = puVar7;
        }
        else {
          *puVar11 = *puVar7;
          *puVar7 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar7;
        }
        puVar7 = (undefined4 *)*puVar11;
      }
    }
  }
  piVar5[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar9 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *piVar1 = (int)piVar9;
    *piVar5 = *piVar9;
  }
  else {
    *piVar5 = *piVar9;
    piVar9 = (int *)*piVar1;
  }
  *piVar9 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 11222 ; VA 0x00789ea0 ; FUN_00789ea0 */

void FUN_00789ea0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (param_1 != 0) {
    uVar1 = *(uint *)(param_1 + 0x18);
    if (0xf < uVar1) {
      iVar2 = *(int *)(param_1 + 4);
      uVar4 = uVar1 + 1;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar1 + 0x24;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0xf;
    *(undefined *)(param_1 + 4) = 0;
    FUN_01674ea0(param_1,0x24);
  }
  return;
}



/* FUNCTION 11223 ; VA 0x00789f10 ; FUN_00789f10 */

undefined4 __thiscall FUN_00789f10(undefined4 param_1,byte param_2)

{
  FUN_007f6720();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 11224 ; VA 0x00789f40 ; FUN_00789f40 */

int __thiscall FUN_00789f40(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(&DAT_0051dda4 + param_1);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)((int)&PTR_s_ApplyAtCenterOfMass_0051dd9c + param_1);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(&DAT_0051dd90 + param_1);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0x4bf28c,8,0xbd60,FUN_00550b30);
  FUN_016f32d1(param_1 + 0x3f200c,0x34,0x3f20,FUN_0075e2f0);
  FUN_016f32d1(param_1 + 0xc,8,0x7e400,FUN_00550b30);
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,&LAB_0051dda8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11225 ; VA 0x0078a080 ; FUN_0078a080 */

undefined4 __thiscall FUN_0078a080(undefined4 param_1,byte param_2)

{
  FUN_007896a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5f0);
  }
  return param_1;
}



/* FUNCTION 11226 ; VA 0x0078a0b0 ; FUN_0078a0b0 */

void FUN_0078a0b0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x44);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 11227 ; VA 0x0078a0d0 ; FUN_0078a0d0 */

void __fastcall FUN_0078a0d0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x44);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 11228 ; VA 0x0078a0f0 ; FUN_0078a0f0 */

void __fastcall FUN_0078a0f0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_007f6720();
    FUN_01674ea0(iVar1,0x34);
  }
  return;
}



/* FUNCTION 11229 ; VA 0x0078a110 ; FUN_0078a110 */

void __thiscall FUN_0078a110(undefined4 param_1,int param_2)

{
  FUN_00787a40(param_1,param_2 + 0x10);
  FUN_01674ea0(param_2,0x44);
  return;
}



/* FUNCTION 11230 ; VA 0x0078a140 ; FUN_0078a140 */

void FUN_0078a140(int *param_1)

{
  char cVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_0078a140(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00789bc0();
    uVar3 = param_1[9];
    if (0xf < uVar3) {
      iVar4 = param_1[4];
      uVar6 = uVar3 + 1;
      iVar5 = iVar4;
      if (0xfff < uVar6) {
        iVar5 = *(int *)(iVar4 + -4);
        uVar6 = uVar3 + 0x24;
        if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    param_1[8] = 0;
    param_1[9] = 0xf;
    *(undefined *)(param_1 + 4) = 0;
    FUN_01674ea0(param_1,0x44);
    cVar1 = *(char *)((int)piVar2 + 0xd);
    param_1 = piVar2;
  } while( true );
}



/* FUNCTION 11231 ; VA 0x0078a1d0 ; FUN_0078a1d0 */

void FUN_0078a1d0(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x44);
  return;
}



/* FUNCTION 11232 ; VA 0x0078a1f0 ; FUN_0078a1f0 */

void __thiscall FUN_0078a1f0(int param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0bc4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_007875e0(param_2);
  if (iVar2 != *(int *)(param_1 + 0x598)) {
    cVar1 = FUN_00570370(iVar3,iVar2 + 0x10);
    if (cVar1 == '\0') goto LAB_0078a265;
  }
  iStack_14 = iVar3;
  iVar3 = FUN_00786ed0(&DAT_018bdeda,&iStack_14,(int)&param_2 + 3);
  FUN_00787130(&param_2,iVar2,iVar3 + 0x10,iVar3);
  iVar2 = param_2;
LAB_0078a265:
  *(undefined4 *)(iVar2 + 0x3c) = param_3;
  *(undefined4 *)(iVar2 + 0x38) = 0;
  *(undefined4 *)(iVar2 + 0x34) = 0;
  param_2 = FUN_01674e20(0x178);
  uStack_8 = 0;
  if (param_2 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_007f7850(param_1);
  }
  iVar3 = *(int *)(iVar2 + 0x2c);
  uStack_8 = 0xffffffff;
  *(undefined4 *)(iVar2 + 0x2c) = uVar4;
  if (iVar3 != 0) {
    FUN_007f8b70();
    FUN_01674ea0(iVar3,0x178);
  }
  param_2 = FUN_01674e20(0xbc);
  uStack_8 = 1;
  if (param_2 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_007f6300();
  }
  iVar3 = *(int *)(iVar2 + 0x30);
  *(undefined4 *)(iVar2 + 0x30) = uVar4;
  if (iVar3 != 0) {
    uStack_8 = 2;
    FUN_016f32d1(iVar3,0xc,0xf,FUN_00612d60);
    FUN_01674ea0(iVar3,0xbc);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11233 ; VA 0x0078a340 ; FUN_0078a340 */

void __thiscall FUN_0078a340(int param_1,int *param_2,char param_3)

{
  code *pcVar1;
  bool bVar2;
  char cVar3;
  int *piVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined2 auStack_24 [2];
  undefined4 uStack_20;
  undefined2 uStack_1c;
  undefined auStack_18 [4];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0bd8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x52c) + 4))(param_2);
  if (*(int **)(param_1 + 0x574) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x574) + 0xc))(param_2);
  }
  if (DAT_01d60f70 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  if (DAT_01d60f78 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  cVar3 = FUN_0078bbb0();
  if (cVar3 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  cVar3 = FUN_0078ba00();
  if (cVar3 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  cVar3 = FUN_009d7ee0(*(undefined4 *)(param_1 + 0x5c4));
  if (cVar3 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  uVar6 = uStack_14;
  if (param_3 != '\0') {
    piVar4 = (int *)FUN_005c8a60(auStack_18);
    uVar6 = 1;
    if (*piVar4 != 0) {
      bVar2 = true;
      goto LAB_0078a407;
    }
  }
  bVar2 = false;
LAB_0078a407:
  if ((uVar6 & 1) != 0) {
    FUN_00550b30();
  }
  auStack_24[0] = 0x100;
  uStack_20 = 0;
  uStack_1c = 0;
  if (!bVar2) {
    (**(code **)(*param_2 + 0x34))(10,*(undefined4 *)(*(int *)(param_1 + 0x4ec) + 0x24),auStack_24);
    ExceptionList = pvStack_10;
    return;
  }
  pcVar1 = *(code **)(*param_2 + 0x34);
  puVar5 = (undefined4 *)FUN_005c8a60(auStack_18);
  uStack_8 = 0;
  (*pcVar1)(10,*puVar5,auStack_24);
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11234 ; VA 0x0078a4a0 ; FUN_0078a4a0 */

void __thiscall FUN_0078a4a0(int param_1,int *param_2)

{
  char cVar1;
  undefined2 auStack_10 [2];
  undefined4 uStack_c;
  undefined2 uStack_8;
  
  if ((DAT_01d60f70 != '\0') && (DAT_01d60f78 != '\0')) {
    cVar1 = FUN_0078bbb0();
    if (cVar1 != '\0') {
      cVar1 = FUN_0078ba00();
      if (cVar1 != '\0') {
        cVar1 = FUN_009d7ee0(*(undefined4 *)(param_1 + 0x5c4));
        if (cVar1 != '\0') {
          auStack_10[0] = 0x100;
          uStack_c = 0;
          uStack_8 = 0;
          (**(code **)(*param_2 + 0x34))
                    (10,*(undefined4 *)(*(int *)(param_1 + 0x4ec) + 0x24),auStack_10);
        }
      }
    }
  }
  (**(code **)(**(int **)(param_1 + 0x52c) + 8))(param_2);
  return;
}



/* FUNCTION 11235 ; VA 0x0078a530 ; FUN_0078a530 */

int __thiscall FUN_0078a530(int param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined uVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined4 uVar9;
  int iVar10;
  uint uVar11;
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0c57;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined4 *)0x0;
  piStack_18 = (int *)0x0;
  iStack_30 = 0;
  uStack_8 = 0;
  if ((DAT_01d60e50 != '\0') || (ExceptionList = &pvStack_10, DAT_01d68674 != '\0')) {
    piStack_18 = *(int **)(param_1 + 0x5a4);
    iStack_30 = *(int *)(param_1 + 0x5a0);
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_1 + 0x5a0) = 0;
    *(undefined4 *)(param_1 + 0x5a4) = 0;
  }
  iVar4 = iStack_30;
  iVar10 = param_2[1];
  if (iVar10 != 0) {
    LOCK();
    *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + 1;
    UNLOCK();
    iVar10 = param_2[1];
  }
  *(int *)(param_1 + 0x5a0) = *param_2;
  piStack_1c = *(int **)(param_1 + 0x5a4);
  *(int *)(param_1 + 0x5a4) = iVar10;
  piStack_2c = piStack_18;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar10 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar10 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  FUN_01155db0(param_2);
  iVar10 = param_2[1];
  piStack_1c = *(int **)(param_1 + 0x4e8);
  if (iVar10 != 0) {
    LOCK();
    *(int *)(iVar10 + 8) = *(int *)(iVar10 + 8) + 1;
    UNLOCK();
    iVar10 = param_2[1];
  }
  piStack_1c[10] = *param_2;
  piVar8 = (int *)piStack_1c[0xb];
  piStack_1c[0xb] = iVar10;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar10 = piVar8[2] + -1;
    piVar8[2] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)(*piVar8 + 4))();
    }
  }
  puVar1 = (undefined4 *)(param_1 + 0x530);
  FUN_005596d0(*puVar1,*(undefined4 *)(param_1 + 0x534),puVar1);
  *(undefined4 *)(param_1 + 0x534) = *puVar1;
  if (*param_2 == 0) {
    if ((DAT_01d62f80 != '\0') && ((-(uint)(iVar4 != 0) & iVar4 + 0xcU) != 0)) {
      piVar8 = (int *)FUN_005c4070();
      if (*piVar8 != 0) {
        *(undefined *)(*piVar8 + 0xb0) = 0;
      }
    }
    if ((((DAT_01d60e50 != '\0') || (DAT_01d68674 != '\0')) &&
        ((-(uint)(iVar4 != 0) & iVar4 + 0xcU) != 0)) && (iVar10 = FUN_00562f00(), iVar10 != 0)) {
      FUN_00c3e4d0(1);
    }
    *(undefined4 *)(param_1 + 0x518) = 0;
    *(undefined4 *)(param_1 + 0x514) = 0;
    *(undefined4 *)(param_1 + 0x51c) = 0;
    if (*(int *)(param_1 + 0x4e4) != 0) {
      FUN_007c9390();
      puVar1 = *(undefined4 **)(param_1 + 0x4e4);
      *(undefined4 *)(param_1 + 0x4e4) = 0;
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
      }
    }
    piVar8 = *(int **)(param_1 + 0x4c8);
    *(undefined4 *)(param_1 + 0x4c8) = 0;
    if (piVar8 != (int *)0x0) {
      (**(code **)(*piVar8 + 4))(1);
    }
    piVar8 = *(int **)(param_1 + 0x598);
    piVar2 = (int *)*piVar8;
    while (piVar2 != piVar8) {
      piVar3 = (int *)piVar2[10];
      piVar2[10] = 0;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(1);
      }
      FUN_00551320();
    }
    FUN_00778110();
    FUN_00780a90();
    iVar10 = FUN_0076d0a0();
  }
  else {
    uVar7 = FUN_01675290(DAT_01eb1ca0);
    uStack_8._0_1_ = 1;
    uVar11 = -(uint)(*param_2 != 0) & *param_2 + 0xcU;
    uStack_20 = uVar7;
    if (uVar11 == 0) {
      iVar10 = 0;
    }
    else {
      piVar8 = (int *)FUN_005c4070();
      iVar10 = *piVar8;
      if (*piVar8 == 0) {
        FUN_005c26a0(&iStack_28);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_008a5700(uVar11);
        FUN_005789c0(&DAT_01ea8c5c,&LAB_005c2460);
        uVar9 = FUN_005c36d0();
        piVar8 = (int *)FUN_008aa140(uVar9);
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[1] = piStack_24[1] + 1;
          UNLOCK();
        }
        *piVar8 = iStack_28;
        piStack_1c = (int *)piVar8[1];
        piVar8[1] = (int)piStack_24;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar10 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            iVar10 = piStack_1c[2] + -1;
            piStack_1c[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
        uStack_8._0_1_ = 1;
        piStack_1c = piStack_24;
        iVar10 = iStack_28;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_24[1] + -1;
          piStack_24[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar4 = piStack_1c[2] + -1;
            piStack_1c[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
      }
    }
    *(int *)(param_1 + 0x518) = iVar10;
    if (DAT_01d62f80 != '\0') {
      *(undefined *)(iVar10 + 0xb0) = 1;
    }
    if ((-(uint)(*param_2 != 0) & *param_2 + 0xcU) == 0) {
      uVar9 = 0;
    }
    else {
      uVar9 = FUN_005c2f20();
    }
    *(undefined4 *)(param_1 + 0x514) = uVar9;
    if ((-(uint)(*param_2 != 0) & *param_2 + 0xcU) == 0) {
      uVar9 = 0;
    }
    else {
      uVar9 = FUN_005c2c60();
    }
    *(undefined4 *)(param_1 + 0x51c) = uVar9;
    FUN_009ddcc0(*(undefined4 *)(*(int *)(param_1 + 0x510) + 0x30));
    iVar10 = *param_2;
    if ((-(uint)(iVar10 != 0) & iVar10 + 0xcU) != 0) {
      FUN_005c34e0();
      iVar10 = *param_2;
    }
    if ((-(uint)(iVar10 != 0) & iVar10 + 0xcU) != 0) {
      FUN_006348f0();
    }
    FUN_00b9cea0((int)*(float *)(param_1 + 0x594));
    if ((-(uint)(*param_2 != 0) & *param_2 + 0xcU) != 0) {
      FUN_007878b0();
    }
    FUN_00d2d3e0(*(undefined4 *)(param_1 + 0x594));
    if (((DAT_01d60e50 != '\0') || (DAT_01d68674 != '\0')) &&
       (((-(uint)(*param_2 != 0) & *param_2 + 0xcU) != 0 && (iVar10 = FUN_00562f00(), iVar10 != 0)))
       ) {
      FUN_00c3e4d0(0);
    }
    iVar10 = FUN_01674e20(0x2f4);
    uStack_8._0_1_ = 3;
    if (iVar10 == 0) {
      uVar9 = 0;
    }
    else {
      if (param_2[1] != 0) {
        LOCK();
        piVar8 = (int *)(param_2[1] + 4);
        *piVar8 = *piVar8 + 1;
        UNLOCK();
      }
      uVar9 = FUN_007c1340(*param_2,param_2[1],param_1);
    }
    puVar1 = *(undefined4 **)(param_1 + 0x4e4);
    uStack_8._0_1_ = 1;
    *(undefined4 *)(param_1 + 0x4e4) = uVar9;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
    }
    iVar10 = FUN_01674e20(0x380);
    uStack_8._0_1_ = 4;
    uVar6 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (iVar10 == 0) {
      uVar9 = 0;
      uStack_8._0_1_ = uVar6;
    }
    else {
      uStack_38 = 0;
      uStack_34 = 0xf;
      auStack_48[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      puStack_14 = (undefined4 *)0x1;
      uStack_8._0_1_ = 5;
      uVar9 = FUN_007fc610(param_1,*(undefined4 *)(param_1 + 0x5a0),*(undefined4 *)(param_1 + 0x4cc)
                           ,auStack_48);
    }
    piVar8 = *(int **)(param_1 + 0x4c8);
    *(undefined4 *)(param_1 + 0x4c8) = uVar9;
    if (piVar8 != (int *)0x0) {
      (**(code **)(*piVar8 + 4))(1);
    }
    uStack_8 = 1;
    if (((uint)puStack_14 & 1) != 0) {
      FUN_005507b0();
    }
    FUN_00804190(*(undefined4 *)(param_1 + 0x4d4),*(undefined4 *)(param_1 + 0x4d8));
    puVar1 = *(undefined4 **)(param_1 + 0x598);
    puVar5 = (undefined4 *)*puVar1;
    while (puStack_14 = puVar5, puVar5 != puVar1) {
      if (puVar5[10] == 0) {
        piStack_1c = (int *)FUN_01674e20(0x380);
        uStack_8._0_1_ = 7;
        if (piStack_1c == (int *)0x0) {
          uVar9 = 0;
        }
        else {
          uVar9 = FUN_007fc610(param_1,*(undefined4 *)(param_1 + 0x5a0),puVar5[0xb],puVar5 + 4);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        piVar8 = (int *)puVar5[10];
        puVar5[10] = uVar9;
        if (piVar8 != (int *)0x0) {
          (**(code **)(*piVar8 + 4))(1);
        }
        FUN_00804190(puVar5[0xd],puVar5[0xe]);
      }
      FUN_00551320();
      puVar5 = puStack_14;
    }
    if (*(int **)(param_1 + 0x52c) != (int *)0x0) {
      (**(code **)(**(int **)(param_1 + 0x52c) + 0xc))();
      (**(code **)(**(int **)(param_1 + 0x52c) + 0x10))();
    }
    FUN_0078ab70();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    iVar10 = FUN_01675290(uVar7);
  }
  piVar8 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_18 + 1;
    iVar4 = *piVar2;
    iVar10 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar10 = (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piVar8 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar10 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar10;
}



/* FUNCTION 11236 ; VA 0x0078ab70 ; FUN_0078ab70 */

void __fastcall FUN_0078ab70(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uStack_34;
  int *piStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0c97;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  uVar6 = FUN_01675290(DAT_01f0795c);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  uStack_24 = uVar6;
  if (((-(uint)(*(int *)(param_1 + 0x5a0) != 0) & *(int *)(param_1 + 0x5a0) + 0xcU) != 0) &&
     (iStack_14 = FUN_007878b0(), iStack_14 != 0)) {
    puVar2 = (undefined4 *)(param_1 + 0x530);
    FUN_005596d0(*puVar2,*(undefined4 *)(param_1 + 0x534),puVar2);
    *(undefined4 *)(param_1 + 0x534) = *puVar2;
    uStack_18 = 0;
    if (*(int *)(iStack_14 + 0x5c) - *(int *)(iStack_14 + 0x58) >> 3 != 0) {
      do {
        uVar5 = uStack_18;
        uVar6 = FUN_01675290(DAT_01f0795c);
        uStack_8._0_1_ = 1;
        iStack_1c = *(int *)(*(int *)(iStack_14 + 0x58) + uVar5 * 8);
        uStack_28 = uVar6;
        iStack_2c = FUN_01674e20(0x34);
        uStack_8._0_1_ = 2;
        if (iStack_2c == 0) {
          uVar7 = 0;
        }
        else {
          uVar7 = FUN_007f65d0(iStack_1c + 0x20,*(undefined4 *)(iStack_20 + 0x53c),uVar5);
        }
        uStack_8._0_1_ = 1;
        uStack_34 = 0;
        piStack_30 = (int *)0x0;
        FUN_00787620(uVar7,iStack_2c);
        puVar2 = *(undefined4 **)(param_1 + 0x534);
        uStack_8._0_1_ = 3;
        if (*(undefined4 **)(param_1 + 0x538) == puVar2) {
          FUN_0077c2a0(puVar2,&uStack_34);
          piVar4 = piStack_30;
          if (piStack_30 != (int *)0x0) {
            LOCK();
            iVar3 = piStack_30[1] + -1;
            piStack_30[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piStack_30)();
              LOCK();
              piVar1 = piVar4 + 2;
              iVar3 = *piVar1 + -1;
              *piVar1 = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
        }
        else {
          *puVar2 = uStack_34;
          puVar2[1] = piStack_30;
          *(int *)(param_1 + 0x534) = *(int *)(param_1 + 0x534) + 8;
          uStack_34 = 0;
          piStack_30 = (int *)0x0;
        }
        uStack_8._0_1_ = 4;
        FUN_01675290(uVar6);
        uStack_18 = uStack_18 + 1;
        uStack_8._0_1_ = 0;
        uVar6 = uStack_24;
      } while (uStack_18 < (uint)(*(int *)(iStack_14 + 0x5c) - *(int *)(iStack_14 + 0x58) >> 3));
    }
  }
  uStack_8 = 5;
  FUN_01675290(uVar6);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11237 ; VA 0x0078ad30 ; FUN_0078ad30 */

void __fastcall FUN_0078ad30(int param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  void **ppvVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0cc2;
  piVar1 = *(int **)(param_1 + 0x598);
  piVar2 = (int *)*piVar1;
  ppvVar4 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar4, piVar2 != piVar1) {
    if (piVar2[10] == 0) {
      iVar5 = FUN_01674e20(0x380);
      uStack_8 = 0;
      if (iVar5 == 0) {
        uVar6 = 0;
      }
      else {
        uVar6 = FUN_007fc610(param_1,*(undefined4 *)(param_1 + 0x5a0),piVar2[0xb],piVar2 + 4);
      }
      piVar3 = (int *)piVar2[10];
      uStack_8 = 0xffffffff;
      piVar2[10] = uVar6;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(1);
      }
      FUN_00804190(piVar2[0xd],piVar2[0xe]);
    }
    FUN_00551320();
    ppvVar4 = (void **)ExceptionList;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11238 ; VA 0x0078adf0 ; FUN_0078adf0 */

void FUN_0078adf0(undefined4 param_1,undefined4 param_2)

{
  FUN_0078be60(param_2);
  return;
}



/* FUNCTION 11239 ; VA 0x0078ae10 ; FUN_0078ae10 */

void FUN_0078ae10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_0078d100(param_2,param_3);
  return;
}



/* FUNCTION 11240 ; VA 0x0078ae30 ; FUN_0078ae30 */

undefined4 __fastcall FUN_0078ae30(int param_1)

{
  return *(undefined4 *)(param_1 + 0x4c8);
}



/* FUNCTION 11241 ; VA 0x0078ae40 ; FUN_0078ae40 */

float10 __thiscall FUN_0078ae40(int param_1,undefined4 param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  iVar3 = FUN_007875e0(param_2);
  iVar1 = *(int *)(param_1 + 0x598);
  if (iVar3 != iVar1) {
    cVar2 = FUN_00570370(param_2,iVar3 + 0x10);
    if (cVar2 == '\0') goto LAB_0078ae72;
  }
  iVar3 = iVar1;
LAB_0078ae72:
  if (iVar3 != iVar1) {
    return (float10)*(float *)(iVar3 + 0x40);
  }
  return (float10)1;
}



/* FUNCTION 11242 ; VA 0x0078ae90 ; FUN_0078ae90 */

float10 FUN_0078ae90(void)

{
  return (float10)0.0;
}



/* FUNCTION 11243 ; VA 0x0078aeb0 ; FUN_0078aeb0 */

undefined4 __thiscall FUN_0078aeb0(int param_1,undefined4 param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  iVar3 = FUN_007875e0(param_2);
  iVar1 = *(int *)(param_1 + 0x598);
  if (iVar3 != iVar1) {
    cVar2 = FUN_00570370(param_2,iVar3 + 0x10);
    if (cVar2 == '\0') goto LAB_0078aee2;
  }
  iVar3 = iVar1;
LAB_0078aee2:
  if (iVar3 != iVar1) {
    return *(undefined4 *)(iVar3 + 0x3c);
  }
  return 0;
}



/* FUNCTION 11244 ; VA 0x0078af00 ; FUN_0078af00 */

undefined4 __fastcall FUN_0078af00(int param_1)

{
  return *(undefined4 *)(param_1 + 0x4cc);
}



/* FUNCTION 11245 ; VA 0x0078af10 ; FUN_0078af10 */

undefined4 __fastcall FUN_0078af10(int param_1)

{
  return *(undefined4 *)(param_1 + 0x4d8);
}



/* FUNCTION 11246 ; VA 0x0078af20 ; FUN_0078af20 */

undefined4 __fastcall FUN_0078af20(int param_1)

{
  return *(undefined4 *)(param_1 + 0x4d4);
}



/* FUNCTION 11247 ; VA 0x0078af30 ; FUN_0078af30 */

void FUN_0078af30(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)FUN_007c8f00(param_2);
  *param_1 = 0;
  param_1[1] = 0;
  if (puVar2[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *puVar2;
  param_1[1] = puVar2[1];
  return;
}



/* FUNCTION 11248 ; VA 0x0078af70 ; FUN_0078af70 */

undefined4 __thiscall FUN_0078af70(int param_1,undefined4 param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  iVar3 = FUN_007875e0(param_2);
  iVar1 = *(int *)(param_1 + 0x598);
  if (iVar3 != iVar1) {
    cVar2 = FUN_00570370(param_2,iVar3 + 0x10);
    if (cVar2 == '\0') goto LAB_0078afa2;
  }
  iVar3 = iVar1;
LAB_0078afa2:
  if (iVar3 != iVar1) {
    return *(undefined4 *)(iVar3 + 0x28);
  }
  return 0;
}



/* FUNCTION 11249 ; VA 0x0078afc0 ; FUN_0078afc0 */

undefined4 * __thiscall FUN_0078afc0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017b0ce9;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  puVar1 = *(undefined4 **)(param_1 + 0x598);
  uStack_8 = 0;
  uStack_18 = 1;
  puStack_14 = (undefined4 *)*puVar1;
  while (puStack_14 != puVar1) {
    iStack_1c = puStack_14[10];
    piVar2 = (int *)param_2[1];
    if ((int *)param_2[2] == piVar2) {
      FUN_006030d0(piVar2,&iStack_1c);
    }
    else {
      *piVar2 = iStack_1c;
      param_2[1] = param_2[1] + 4;
    }
    FUN_00551320();
  }
  ExceptionList = pvStack_10;
  return param_2;
}


