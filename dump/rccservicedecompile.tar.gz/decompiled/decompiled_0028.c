/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 7000 ; VA 0x006335fc ; FUN_006335fc */

int __fastcall FUN_006335fc(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  int in_EAX;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *unaff_EBX;
  int unaff_EBP;
  undefined4 *puVar10;
  
  iVar5 = *param_1;
  *(int *)(unaff_EBP + 8) = in_EAX - iVar5 >> 2;
  iVar3 = param_1[1] - iVar5 >> 2;
  if (iVar3 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  iVar1 = param_1[2];
  uVar7 = iVar3 + 1;
  *(uint *)(unaff_EBP + -4) = uVar7;
  uVar6 = iVar1 - iVar5 >> 2;
  uVar4 = uVar7;
  if ((uVar6 <= 0x3fffffff - (uVar6 >> 1)) && (uVar4 = (uVar6 >> 1) + uVar6, uVar4 < uVar7)) {
    uVar4 = uVar7;
  }
  uVar7 = uVar4 * 4;
  *(uint *)(unaff_EBP + -8) = uVar7;
  if (uVar4 < 0x40000000) {
    if (0xfff < uVar7) goto LAB_00633664;
    if (uVar7 == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = (undefined4 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00633664:
    uVar4 = uVar7 + 0x23;
    if (uVar4 <= uVar7) {
      uVar4 = 0xffffffff;
    }
    iVar5 = FUN_01674e20(uVar4);
    if (iVar5 == 0) goto LAB_006337b1;
    puVar10 = (undefined4 *)(iVar5 + 0x23U & 0xffffffe0);
    puVar10[-1] = iVar5;
  }
  iVar5 = *(int *)(unaff_EBP + 8);
  puVar2 = *(undefined4 **)(unaff_EBP + 0xc);
  *(int *)(unaff_EBP + 8) = iVar5 * 4;
  puVar10[iVar5] = *puVar2;
  *puVar2 = 0;
  puVar2 = (undefined4 *)param_1[1];
  puVar8 = (undefined4 *)*param_1;
  puVar9 = puVar10;
  if (unaff_EBX == puVar2) {
    for (; puVar8 != puVar2; puVar8 = puVar8 + 1) {
      *puVar9 = *puVar8;
      *puVar8 = 0;
      puVar9 = puVar9 + 1;
    }
  }
  else {
    for (; puVar8 != unaff_EBX; puVar8 = puVar8 + 1) {
      *puVar9 = *puVar8;
      *puVar8 = 0;
      puVar9 = puVar9 + 1;
    }
    FUN_00633350(puVar9,puVar9,param_1);
    puVar2 = (undefined4 *)param_1[1];
    *(undefined4 **)(unaff_EBP + 0xc) = puVar2;
    puVar9 = (undefined4 *)(*(int *)(unaff_EBP + 8) + 4 + (int)puVar10);
    if (unaff_EBX != puVar2) {
      puVar2 = *(undefined4 **)(unaff_EBP + 0xc);
      puVar8 = (undefined4 *)
               ((int)unaff_EBX + (int)puVar9 + (-*(int *)(unaff_EBP + 8) - (int)puVar10) + -4);
      do {
        *puVar9 = *puVar8;
        puVar9 = puVar9 + 1;
        *puVar8 = 0;
        puVar8 = puVar8 + 1;
      } while (puVar8 != puVar2);
    }
  }
  FUN_00633350(puVar9,puVar9,param_1);
  if (*param_1 != 0) {
    FUN_00633350(*param_1,param_1[1],param_1);
    iVar5 = *param_1;
    uVar7 = param_1[2] - iVar5 & 0xfffffffc;
    iVar3 = iVar5;
    if (0xfff < uVar7) {
      iVar3 = *(int *)(iVar5 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar5 - iVar3) - 4U) {
LAB_006337b1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar7);
  }
  iVar5 = *(int *)(unaff_EBP + -4);
  *param_1 = (int)puVar10;
  param_1[1] = (int)(puVar10 + iVar5);
  param_1[2] = *(int *)(unaff_EBP + -8) + (int)puVar10;
  return *param_1 + *(int *)(unaff_EBP + 8);
}



/* FUNCTION 7001 ; VA 0x006337c0 ; FUN_006337c0 */

void FUN_006337c0(int param_1,uint param_2,int param_3,uint param_4)

{
  undefined uVar1;
  undefined *puVar2;
  uint uVar3;
  undefined *puVar4;
  
  if (param_2 != param_4) {
    do {
      param_4 = param_4 - 1;
      if (param_2 == param_4) {
        return;
      }
      puVar4 = (undefined *)
               ((param_4 & 0xf) +
               *(int *)(*(int *)(param_3 + 4) + (param_4 >> 4 & *(int *)(param_3 + 8) - 1U) * 4));
      uVar3 = param_2 + 1;
      puVar2 = (undefined *)
               ((param_2 & 0xf) +
               *(int *)(*(int *)(param_1 + 4) + (*(int *)(param_1 + 8) - 1U & param_2 >> 4) * 4));
      uVar1 = *puVar2;
      *puVar2 = *puVar4;
      *puVar4 = uVar1;
      param_2 = uVar3;
    } while (uVar3 != param_4);
  }
  return;
}



/* FUNCTION 7002 ; VA 0x00633830 ; FUN_00633830 */

int __thiscall FUN_00633830(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f430;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::CookiesService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7003 ; VA 0x00633902 ; Catch_All@00633902 */

void Catch_All_00633902(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7004 ; VA 0x00633920 ; FUN_00633920 */

int __thiscall FUN_00633920(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f440;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::CorePackages*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7005 ; VA 0x006339f2 ; Catch_All@006339f2 */

void Catch_All_006339f2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7006 ; VA 0x00633a10 ; FUN_00633a10 */

int __thiscall FUN_00633a10(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f450;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::FileSyncItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7007 ; VA 0x00633ae2 ; Catch_All@00633ae2 */

void Catch_All_00633ae2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7008 ; VA 0x00633b00 ; FUN_00633b00 */

int __thiscall FUN_00633b00(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f460;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Folder*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7009 ; VA 0x00633bd2 ; Catch_All@00633bd2 */

void Catch_All_00633bd2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7010 ; VA 0x00633bf0 ; FUN_00633bf0 */

int __thiscall FUN_00633bf0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f470;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::GuiService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7011 ; VA 0x00633cc2 ; Catch_All@00633cc2 */

void Catch_All_00633cc2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7012 ; VA 0x00633ce0 ; FUN_00633ce0 */

int __thiscall FUN_00633ce0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f480;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::InsertService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7013 ; VA 0x00633db2 ; Catch_All@00633db2 */

void Catch_All_00633db2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7014 ; VA 0x00633dd0 ; FUN_00633dd0 */

int __thiscall FUN_00633dd0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f490;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::UserInputService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7015 ; VA 0x00633ea2 ; Catch_All@00633ea2 */

void Catch_All_00633ea2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7016 ; VA 0x00633ec0 ; FUN_00633ec0 */

int __thiscall FUN_00633ec0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f4a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Visit*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7017 ; VA 0x00633f92 ; Catch_All@00633f92 */

void Catch_All_00633f92(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7018 ; VA 0x00633fb0 ; FUN_00633fb0 */

int __thiscall FUN_00633fb0(undefined4 param_1,int param_2,int param_3,int param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f4b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      FUN_0054ef60(param_2);
      param_4 = param_4 + 0x18;
      param_2 = param_2 + 0x18;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar1;
  FUN_00559570(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 7019 ; VA 0x00634030 ; FUN_00634030 */

void __thiscall FUN_00634030(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  uVar2 = param_1[5];
  puVar3 = param_1;
  if (0xf < uVar2) {
    puVar3 = (undefined4 *)*param_1;
  }
  piVar1 = param_1 + 4;
  puVar4 = param_1;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*param_1;
  }
  if (0xf < uVar2) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_00591430((int)puVar4 - (int)param_1,(int)puVar3 + (*piVar1 - (int)puVar4),param_2,
               param_3 - param_2);
  return;
}



/* FUNCTION 7020 ; VA 0x00634120 ; FUN_00634120 */

void FUN_00634120(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (param_1 != (int *)0x0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_0168c070(auStack_18,param_1 + 10);
    if (7 < (uint)param_1[5]) {
      iVar2 = *param_1;
      iVar1 = param_1[5] * 2;
      uVar4 = iVar1 + 2;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = iVar1 + 0x25;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    param_1[4] = 0;
    param_1[5] = 7;
    *(undefined2 *)param_1 = 0;
    FUN_01674ea0(param_1,0x2c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7021 ; VA 0x006341d0 ; FUN_006341d0 */

void FUN_006341d0(int *param_1,int param_2,int param_3,int param_4)

{
  undefined auStack_c [7];
  undefined uStack_5;
  
  FUN_0055b6b0(&uStack_5,auStack_c,auStack_c);
  FUN_0170cc70(param_4,param_2,param_3 - param_2);
  *param_1 = (param_3 - param_2) + param_4;
  return;
}



/* FUNCTION 7022 ; VA 0x00634210 ; FUN_00634210 */

undefined4 * FUN_00634210(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f500;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b84c80();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b84d80();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00633830(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7023 ; VA 0x006342d0 ; FUN_006342d0 */

int FUN_006342d0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead5f0,&LAB_00634080);
  uVar2 = FUN_00635050();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b84d60();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00634210(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead5f0,&LAB_00634080);
      uVar2 = FUN_00635050();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7024 ; VA 0x00634460 ; FUN_00634460 */

undefined4 * FUN_00634460(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f560;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b9ead0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x58);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b9ebd0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00633920(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7025 ; VA 0x00634520 ; FUN_00634520 */

int FUN_00634520(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f578;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead610,&LAB_006340a0);
  uVar2 = FUN_00635150();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b9ebb0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00634460(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead610,&LAB_006340a0);
      uVar2 = FUN_00635150();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7026 ; VA 0x006346b0 ; FUN_006346b0 */

undefined4 * FUN_006346b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f5c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00ba0840();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xd4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00ba1d10();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00633a10(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7027 ; VA 0x00634770 ; FUN_00634770 */

undefined4 * FUN_00634770(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f600;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b9e640();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x54);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b9e740();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00633b00(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7028 ; VA 0x00634830 ; FUN_00634830 */

undefined4 * FUN_00634830(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f643;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b8c330();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x1f0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b909c0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00633bf0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7029 ; VA 0x006348f0 ; FUN_006348f0 */

int FUN_006348f0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f658;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
  uVar2 = FUN_006352d0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b8c410();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00634830(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
      uVar2 = FUN_006352d0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7030 ; VA 0x00634a80 ; FUN_00634a80 */

undefined4 * FUN_00634a80(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f6a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b85410();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x7c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b86030();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00633ce0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7031 ; VA 0x00634b40 ; FUN_00634b40 */

int FUN_00634b40(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f6b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead608,&LAB_006340e0);
  uVar2 = FUN_00635350();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b85510();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00634a80(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead608,&LAB_006340e0);
      uVar2 = FUN_00635350();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7032 ; VA 0x00634cd0 ; FUN_00634cd0 */

undefined4 * FUN_00634cd0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f703;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b7a090();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x238);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b7bb80();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00633dd0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7033 ; VA 0x00634d90 ; FUN_00634d90 */

int FUN_00634d90(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f718;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead600,&LAB_00634100);
  uVar2 = FUN_00635450();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b7a190();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00634cd0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead600,&LAB_00634100);
      uVar2 = FUN_00635450();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7034 ; VA 0x00634f20 ; FUN_00634f20 */

undefined4 * FUN_00634f20(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f760;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b8a890();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x74);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b8a990();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00633ec0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7035 ; VA 0x00634fe0 ; FUN_00634fe0 */

void FUN_00634fe0(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00637a50();
  FUN_0056e380();
  FUN_0056e380();
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 7036 ; VA 0x00635050 ; FUN_00635050 */

undefined4 FUN_00635050(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f77c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead62c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead62c);
    if (DAT_01ead62c == -1) {
      uStack_8 = 0;
      DAT_01ead628 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead62c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead628;
}



/* FUNCTION 7037 ; VA 0x006350d0 ; FUN_006350d0 */

undefined4 FUN_006350d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f79c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead684) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead684);
    if (DAT_01ead684 == -1) {
      uStack_8 = 0;
      DAT_01ead680 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead684);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead680;
}



/* FUNCTION 7038 ; VA 0x00635150 ; FUN_00635150 */

undefined4 FUN_00635150(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f7bc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead664) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead664);
    if (DAT_01ead664 == -1) {
      uStack_8 = 0;
      DAT_01ead660 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead664);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead660;
}



/* FUNCTION 7039 ; VA 0x006351d0 ; FUN_006351d0 */

undefined4 FUN_006351d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f7dc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead67c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead67c);
    if (DAT_01ead67c == -1) {
      uStack_8 = 0;
      DAT_01ead678 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead67c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead678;
}



/* FUNCTION 7040 ; VA 0x00635250 ; FUN_00635250 */

undefined4 FUN_00635250(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f7fc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead69c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead69c);
    if (DAT_01ead69c == -1) {
      uStack_8 = 0;
      DAT_01ead698 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead69c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead698;
}



/* FUNCTION 7041 ; VA 0x006352d0 ; FUN_006352d0 */

undefined4 FUN_006352d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f81c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead634) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead634);
    if (DAT_01ead634 == -1) {
      uStack_8 = 0;
      DAT_01ead630 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead634);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead630;
}



/* FUNCTION 7042 ; VA 0x00635350 ; FUN_00635350 */

undefined4 FUN_00635350(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f83c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead64c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead64c);
    if (DAT_01ead64c == -1) {
      uStack_8 = 0;
      DAT_01ead648 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead64c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead648;
}



/* FUNCTION 7043 ; VA 0x006353d0 ; FUN_006353d0 */

undefined4 FUN_006353d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f85c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead66c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead66c);
    if (DAT_01ead66c == -1) {
      uStack_8 = 0;
      DAT_01ead668 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead66c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead668;
}



/* FUNCTION 7044 ; VA 0x00635450 ; FUN_00635450 */

undefined4 FUN_00635450(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f87c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead644) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead644);
    if (DAT_01ead644 == -1) {
      uStack_8 = 0;
      DAT_01ead640 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead644);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead640;
}



/* FUNCTION 7045 ; VA 0x006354d0 ; FUN_006354d0 */

undefined4 FUN_006354d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f89c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead694) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead694);
    if (DAT_01ead694 == -1) {
      uStack_8 = 0;
      DAT_01ead690 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead694);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead690;
}



/* FUNCTION 7046 ; VA 0x00635550 ; FUN_00635550 */

void __thiscall FUN_00635550(int param_1,undefined4 *param_2,undefined8 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    puVar1[4] = 0;
    puVar1[5] = 0;
    uVar3 = param_2[1];
    uVar4 = param_2[2];
    uVar5 = param_2[3];
    *puVar1 = *param_2;
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(param_2 + 4);
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
    iVar2 = *(int *)(param_1 + 4);
    *(undefined8 *)(puVar1 + 6) = *param_3;
    *(int *)(param_1 + 4) = iVar2 + 0x20;
    return;
  }
  FUN_00633500(puVar1,param_2,param_3);
  return;
}



/* FUNCTION 7047 ; VA 0x006355c0 ; FUN_006355c0 */

undefined4 * FUN_006355c0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f8dc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[10] = &DAT_018cf050;
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_lexical_cast::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  puVar1 = param_1 + 5;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x18);
  param_1[6] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0x14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7048 ; VA 0x006356b0 ; FUN_006356b0 */

undefined4 * FUN_006356b0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_lexical_cast::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = boost::exception::vftable;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>::vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>::vftable;
  return param_1;
}



/* FUNCTION 7049 ; VA 0x00635720 ; FUN_00635720 */

void FUN_00635720(int *param_1,undefined4 *param_2,int param_3,int param_4)

{
  uint uVar1;
  code *pcVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  uVar1 = param_2[4];
  uVar5 = param_3 - (int)puVar3;
  if (uVar5 <= uVar1) {
    uVar4 = param_4 - param_3;
    if (uVar1 - uVar5 < (uint)(param_4 - param_3)) {
      uVar4 = uVar1 - uVar5;
    }
    puVar3 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar3 = (undefined4 *)*param_2;
    }
    param_2[4] = uVar1 - uVar4;
    FUN_0170cc70((int)puVar3 + uVar5,(int)puVar3 + uVar5 + uVar4,((uVar1 - uVar4) - uVar5) + 1);
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    *param_1 = (int)param_2 + uVar5;
    return;
  }
  FUN_00554050();
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}



/* FUNCTION 7050 ; VA 0x00635790 ; FUN_00635790 */

int FUN_00635790(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = thunk_FUN_00897b90();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 7051 ; VA 0x006357d0 ; FUN_006357d0 */

int FUN_006357d0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ead658,&LAB_00634090);
  uVar3 = FUN_006350d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b57070();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 7052 ; VA 0x00635890 ; FUN_00635890 */

int FUN_00635890(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ead650,&LAB_006340b0);
  uVar3 = FUN_006351d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b75e90();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 7053 ; VA 0x00635950 ; FUN_00635950 */

int FUN_00635950(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01ead688,&LAB_006340c0);
  uVar3 = FUN_00635250();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00bacc40();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 7054 ; VA 0x00635a10 ; FUN_00635a10 */

int FUN_00635a10(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eaad5c,&LAB_005f4450);
  uVar3 = FUN_005f5610();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00a36f60();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 7055 ; VA 0x00635ad0 ; FUN_00635ad0 */

int FUN_00635ad0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01ead670,&LAB_00634110);
  uVar3 = FUN_006354d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00baf450();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 7056 ; VA 0x00635b90 ; FUN_00635b90 */

void FUN_00635b90(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined auStack_20 [8];
  undefined4 uStack_18;
  
  puVar2 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar2 = (undefined4 *)*param_1;
  }
  puVar3 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar3 = (undefined4 *)*param_1;
  }
  piVar1 = (int *)FUN_00632f40(auStack_20,puVar3,param_1[4] + (int)puVar2);
  uStack_18 = param_3;
  if (*piVar1 != piVar1[1]) {
    FUN_00635c30(param_1,param_2,param_3,param_4,param_5,*piVar1,piVar1[1],param_4,param_5);
  }
  return;
}



/* FUNCTION 7057 ; VA 0x00635c30 ; FUN_00635c30 */

/* WARNING: Type propagation algorithm not settling */

void FUN_00635c30(char *param_1,char *param_2,char *param_3,undefined4 param_4,int param_5,
                 undefined4 param_6,char *param_7,char *param_8,int param_9,undefined4 param_10)

{
  uint *puVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  char *pcVar5;
  char *pcVar6;
  int *piVar7;
  undefined4 *******pppppppuVar8;
  undefined4 *puVar9;
  char *pcVar10;
  undefined4 *puVar11;
  int iVar12;
  uint uVar13;
  char *pcVar14;
  uint uVar15;
  undefined4 uVar16;
  int *piStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  undefined4 *******apppppppuStack_40 [3];
  undefined auStack_34 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  char *pcStack_28;
  char *pcStack_24;
  uint *puStack_20;
  int iStack_1c;
  char *pcStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f900;
  pvStack_10 = ExceptionList;
  iStack_1c = param_9;
  puStack_20 = (uint *)param_10;
  piStack_54 = (int *)0x0;
  iStack_50 = 0;
  iStack_4c = 0;
  iStack_48 = 0;
  iStack_44 = 0;
  ExceptionList = &pvStack_10;
  piStack_54 = (int *)FUN_01674e20(8);
  *piStack_54 = 0;
  piStack_54[1] = 0;
  *piStack_54 = (int)&piStack_54;
  uStack_8 = 0;
  pcStack_18 = param_1;
  pcVar6 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcStack_18 = *(char **)param_1;
    pcVar6 = *(char **)param_1;
  }
  pcVar10 = param_8;
  if (param_7 != param_8) {
    do {
      FUN_00632fb0(&pcStack_28,&piStack_54,param_1,pcStack_18,pcVar6,param_7);
      pcStack_18 = pcStack_28;
      uVar16 = 0;
      if ((piStack_54 != (int *)0x0) && ((undefined4 *)*piStack_54 != (undefined4 *)0x0)) {
        uVar16 = *(undefined4 *)*piStack_54;
      }
      pcStack_24 = pcVar10;
      FUN_00636340(auStack_34,uVar16,0,iStack_48 + iStack_44,iStack_1c,puStack_20);
      pcVar5 = param_1;
      if (0xf < *(uint *)(param_1 + 0x14)) {
        pcVar5 = *(char **)param_1;
      }
      pcVar5 = pcVar5 + *(int *)(param_1 + 0x10);
      for (pcVar14 = pcVar10; pcVar10 = pcVar5, param_7 = pcVar5, pcVar6 = pcStack_24,
          pcVar14 != pcVar5; pcVar14 = pcVar14 + 1) {
        pcVar10 = pcVar14;
        pcVar4 = param_2;
        if (param_2 == param_3) goto LAB_00635da4;
        for (; param_7 = pcVar14, pcVar10 != pcVar5; pcVar10 = pcVar10 + 1) {
          if (pcVar4 == param_3) goto LAB_00635d83;
          if (*pcVar10 != *pcVar4) break;
          pcVar4 = pcVar4 + 1;
        }
        if (pcVar4 == param_3) break;
      }
LAB_00635d83:
      if (param_7 == pcVar10) break;
      iStack_1c = param_5;
      puStack_20 = (uint *)param_6;
    } while( true );
  }
LAB_00635da4:
  pcVar10 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar10 = *(char **)param_1;
  }
  puVar1 = (uint *)(param_1 + 0x10);
  puStack_20 = puVar1;
  FUN_00632fb0(&pcStack_28,&piStack_54,param_1,pcStack_18,pcVar6,pcVar10 + *(int *)(param_1 + 0x10))
  ;
  if (iStack_44 == 0) {
    pcVar6 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcVar6 = *(char **)param_1;
    }
    uVar13 = *puVar1;
    pcStack_24 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcStack_24 = *(char **)param_1;
    }
    uVar15 = (int)pcStack_28 - (int)pcStack_24;
    if (uVar13 < uVar15) {
      FUN_00554050();
LAB_00635fe9:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    iVar3 = uVar13 - (int)pcStack_28;
    pcStack_28 = pcVar6 + iVar3;
    if ((char *)(uVar13 - uVar15) < pcVar6 + iVar3) {
      pcStack_28 = (char *)(uVar13 - uVar15);
    }
    if (0xf < *(uint *)(param_1 + 0x14)) {
      param_1 = *(char **)param_1;
    }
    *puStack_20 = uVar13 - (int)pcStack_28;
    FUN_0170cc70(param_1 + uVar15,pcStack_28 + (int)(param_1 + uVar15),
                 ((uVar13 - (int)pcStack_28) - uVar15) + 1);
  }
  else {
    pcVar6 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcVar6 = *(char **)param_1;
    }
    uVar13 = *puVar1;
    puVar11 = (undefined4 *)0x0;
    iStack_1c = iStack_48;
    pcStack_24 = (char *)(iStack_48 + iStack_44);
    if ((piStack_54 != (int *)0x0) && ((undefined4 *)*piStack_54 != (undefined4 *)0x0)) {
      puVar11 = *(undefined4 **)*piStack_54;
    }
    puVar9 = (undefined4 *)0x0;
    if ((piStack_54 != (int *)0x0) && ((undefined4 *)*piStack_54 != (undefined4 *)0x0)) {
      puVar9 = *(undefined4 **)*piStack_54;
    }
    piVar7 = (int *)0x0;
    if ((puVar11 != (undefined4 *)0x0) && ((undefined4 *)*puVar11 != (undefined4 *)0x0)) {
      piVar7 = *(int **)*puVar11;
    }
    if (((puVar9 == (undefined4 *)0x0) || ((undefined4 *)*puVar9 == (undefined4 *)0x0)) ||
       (puVar11 = *(undefined4 **)*puVar9, puVar11 == (undefined4 *)0x0)) {
      pcStack_18 = (char *)0x0;
    }
    else {
      pcStack_18 = (char *)*puVar11;
    }
    if (piVar7 == (int *)0x0) {
      puStack_20 = (uint *)0x0;
    }
    else {
      puStack_20 = (uint *)*piVar7;
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    apppppppuStack_40[0] = (undefined4 *******)((uint)apppppppuStack_40[0] & 0xffffff00);
    FUN_0058a190((int)pcStack_24 - iStack_48);
    FUN_00633180(pcStack_18,iStack_1c,puStack_20,pcStack_24,param_8);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < *(uint *)(param_1 + 0x14)) {
      param_1 = *(char **)param_1;
    }
    pppppppuVar8 = apppppppuStack_40;
    if (0xf < uStack_2c) {
      pppppppuVar8 = apppppppuStack_40[0];
    }
    FUN_00591430(pcVar6 + (uVar13 - (int)param_1),0,pppppppuVar8,uStack_30);
    if (0xf < uStack_2c) {
      uVar13 = uStack_2c + 1;
      pppppppuVar8 = apppppppuStack_40[0];
      if (0xfff < uVar13) {
        pppppppuVar8 = (undefined4 *******)apppppppuStack_40[0][-1];
        uVar13 = uStack_2c + 0x24;
        if (0x1f < (uint)((int)apppppppuStack_40[0] + (-4 - (int)pppppppuVar8))) goto LAB_00635fe9;
      }
      FUN_01674ea0(pppppppuVar8,uVar13);
    }
  }
  iVar3 = iStack_50;
  iVar12 = iStack_4c;
  if (iStack_44 != 0) {
    do {
      iStack_44 = iStack_44 + -1;
    } while (iStack_44 != 0);
    iStack_48 = 0;
    iStack_44 = 0;
  }
  while (iVar12 != 0) {
    iVar2 = *(int *)(iVar3 + -4 + iVar12 * 4);
    iVar12 = iVar12 + -1;
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x10);
      iVar3 = iStack_50;
    }
  }
  if (iVar3 != 0) {
    uVar13 = iStack_4c * 4;
    iVar12 = iVar3;
    if (0xfff < uVar13) {
      iVar12 = *(int *)(iVar3 + -4);
      uVar13 = uVar13 + 0x23;
      if (0x1f < (iVar3 - iVar12) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar12,uVar13);
  }
  iStack_4c = 0;
  iStack_50 = 0;
  FUN_01674ea0(piStack_54,8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7058 ; VA 0x00636000 ; FUN_00636000 */

int * __thiscall FUN_00636000(int *param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008881d0();
  if (iVar4 != iVar1) {
    puVar2 = (undefined4 *)param_1[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)(param_1 + 2,auStack_d8);
      puVar2 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_00887bf0();
    iVar4 = piVar3[1];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    *param_2 = *piVar3;
    param_2[1] = iVar4;
    uStack_8 = 1;
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)puVar2[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar4 = *param_1;
  iVar1 = FUN_008881d0();
  if (iVar4 == iVar1) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iVar4 = piVar3[1];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    *param_2 = *piVar3;
    param_2[1] = iVar4;
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 7059 ; VA 0x00636130 ; FUN_00636130 */

int * __thiscall FUN_00636130(int *param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008882f0();
  if (iVar4 != iVar1) {
    puVar2 = (undefined4 *)param_1[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)(param_1 + 2,auStack_d8);
      puVar2 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_00887e80();
    iVar4 = piVar3[1];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    *param_2 = *piVar3;
    param_2[1] = iVar4;
    uStack_8 = 1;
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)puVar2[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar4 = *param_1;
  iVar1 = FUN_008882f0();
  if (iVar4 == iVar1) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iVar4 = piVar3[1];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    *param_2 = *piVar3;
    param_2[1] = iVar4;
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 7060 ; VA 0x00636260 ; FUN_00636260 */

undefined __fastcall FUN_00636260(int *param_1)

{
  undefined uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined *puVar6;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088daf0();
  if (iVar2 != iVar3) {
    puVar5 = (undefined4 *)param_1[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(param_1 + 2,auStack_d8);
      puVar5 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    puVar6 = (undefined *)FUN_0088bcc0();
    uVar1 = *puVar6;
    uStack_8 = 1;
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)puVar5[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return uVar1;
  }
  iVar2 = *param_1;
  iVar3 = FUN_0088daf0();
  if (iVar2 == iVar3) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    ExceptionList = pvStack_10;
    return *(undefined *)piVar4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 7061 ; VA 0x00636340 ; FUN_00636340 */

void __thiscall
FUN_00636340(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined *param_6,undefined *param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  undefined *puVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  int iVar11;
  undefined auStack_38 [12];
  int iStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  uint uStack_20;
  int *piStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179f910;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  uStack_20 = param_5 - param_1[3];
  uVar9 = param_1[4];
  puStack_24 = param_6;
  puStack_28 = param_7;
  if (param_6 != param_7) {
    piStack_1c = param_1;
    uStack_18 = uVar9;
    if (uVar9 >> 1 < uStack_20) {
      uStack_8 = 2;
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffbc;
      for (; iVar3 = param_1[3], param_6 != puStack_28; param_6 = param_6 + 1) {
        if (((iVar3 + uVar9 & 0xf) == 0) && ((uint)param_1[2] <= uVar9 + 0x10 >> 4)) {
          FUN_00638430(1);
        }
        uVar9 = param_1[2] * 0x10 - 1U & param_1[3];
        param_1[3] = uVar9;
        puStack_24 = (undefined *)(param_1[4] + uVar9);
        iStack_2c = ((uint)puStack_24 >> 4 & param_1[2] - 1U) * 4;
        iVar3 = param_1[1];
        if (*(int *)(iStack_2c + iVar3) == 0) {
          uVar1 = FUN_01674e20(0x10);
          *(undefined4 *)(iStack_2c + param_1[1]) = uVar1;
          iVar3 = param_1[1];
        }
        *(undefined *)(((uint)puStack_24 & 0xf) + *(int *)(iStack_2c + iVar3)) = *param_6;
        param_1[4] = param_1[4] + 1;
        uVar9 = param_1[4];
      }
      piVar6 = (int *)*param_1;
      puVar5 = (undefined *)(iVar3 + uVar9);
      iVar11 = *param_1;
      piVar7 = (int *)0x0;
      if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
        piVar7 = *(int **)*piVar6;
      }
      iVar4 = iVar3 + uStack_18;
      uVar1 = 0;
      if ((piVar7 != (int *)0x0) && ((undefined4 *)*piVar7 != (undefined4 *)0x0)) {
        uVar1 = *(undefined4 *)*piVar7;
      }
      puVar2 = (undefined4 *)0x0;
      if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
        puVar2 = *(undefined4 **)*piVar6;
      }
      iVar8 = uStack_20 + iVar3;
      iVar10 = 0;
      puStack_28 = (undefined *)iVar3;
      if ((puVar2 != (undefined4 *)0x0) && ((int *)*puVar2 != (int *)0x0)) {
        iVar10 = *(int *)*puVar2;
      }
    }
    else {
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      for (; puStack_24 != puStack_28; puStack_24 = puStack_24 + 1) {
        if (((*(byte *)(param_1 + 3) & 0xf) == 0) && ((uint)param_1[2] <= uVar9 + 0x10 >> 4)) {
          FUN_00638430(1);
        }
        uVar9 = param_1[2] * 0x10 - 1U & param_1[3];
        param_1[3] = uVar9;
        if (uVar9 == 0) {
          uVar9 = param_1[2] << 4;
        }
        uVar9 = uVar9 - 1;
        iStack_2c = (uVar9 >> 4 & param_1[2] - 1U) * 4;
        iVar3 = param_1[1];
        if (*(int *)(iVar3 + iStack_2c) == 0) {
          uVar1 = FUN_01674e20(0x10);
          *(undefined4 *)(iStack_2c + param_1[1]) = uVar1;
          iVar3 = param_1[1];
        }
        *(undefined *)((uVar9 & 0xf) + *(int *)(iStack_2c + iVar3)) = *puStack_24;
        param_1[3] = uVar9;
        param_1[4] = param_1[4] + 1;
        uVar9 = param_1[4];
      }
      puStack_28 = (undefined *)(uVar9 - uStack_18);
      piVar7 = (int *)0x0;
      piVar6 = (int *)*param_1;
      if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
        piVar7 = *(int **)*piVar6;
      }
      iStack_2c = (int)puStack_28 + param_1[3];
      puVar2 = (undefined4 *)0x0;
      if ((piVar7 != (int *)0x0) && ((undefined4 *)*piVar7 != (undefined4 *)0x0)) {
        puVar2 = *(undefined4 **)*piVar7;
      }
      if (puVar2 == (undefined4 *)0x0) {
        uVar1 = 0;
      }
      else {
        uVar1 = *puVar2;
      }
      if (piVar6 == (int *)0x0) {
        iVar3 = 0;
      }
      else {
        iVar3 = *piVar6;
      }
      FUN_006337c0(iVar3,param_1[3],uVar1,iStack_2c);
      piVar6 = (int *)*param_1;
      puVar2 = (undefined4 *)0x0;
      if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
        puVar2 = *(undefined4 **)*piVar6;
      }
      iVar4 = (int)puStack_28 + param_1[3];
      puVar5 = (undefined *)(iVar4 + uStack_20);
      iVar11 = 0;
      if ((puVar2 != (undefined4 *)0x0) && ((int *)*puVar2 != (int *)0x0)) {
        iVar11 = *(int *)*puVar2;
      }
      piVar7 = (int *)0x0;
      if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
        piVar7 = *(int **)*piVar6;
      }
      uVar1 = 0;
      if ((piVar7 != (int *)0x0) && ((undefined4 *)*piVar7 != (undefined4 *)0x0)) {
        uVar1 = *(undefined4 *)*piVar7;
      }
      iVar8 = piStack_1c[3];
      iVar10 = *piStack_1c;
      iStack_2c = iVar4;
      puStack_24 = puVar5;
    }
    param_1 = piStack_1c;
    FUN_00636d10(auStack_38,iVar10,0,iVar8,uVar1,0,iVar4,iVar11,0,puVar5);
  }
  piVar6 = (int *)0x0;
  iVar3 = param_1[3];
  if (((int *)*param_1 != (int *)0x0) &&
     (puVar2 = *(undefined4 **)*param_1, puVar2 != (undefined4 *)0x0)) {
    piVar6 = (int *)*puVar2;
  }
  *param_2 = 0;
  param_2[1] = 0;
  if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
    *param_2 = *(undefined4 *)*piVar6;
  }
  param_2[2] = iVar3 + uStack_20;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7062 ; VA 0x00636435 ; Catch_All@00636435 */

void Catch_All_00636435(void)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int unaff_EBP;
  
  iVar2 = *(int *)(unaff_EBP + -0x18);
  uVar3 = *(uint *)(unaff_EBP + -0x14);
  uVar1 = *(uint *)(iVar2 + 0x10);
  while (uVar3 < uVar1) {
    FUN_0063c960();
    uVar1 = *(uint *)(iVar2 + 0x10);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7063 ; VA 0x006365dd ; Catch_All@006365dd */

void Catch_All_006365dd(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int unaff_EBP;
  
  iVar3 = *(int *)(unaff_EBP + -0x18);
  uVar4 = *(uint *)(unaff_EBP + -0x14);
  uVar2 = *(uint *)(iVar3 + 0x10);
  while (uVar4 < uVar2) {
    piVar1 = (int *)(iVar3 + 0x10);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      *(undefined4 *)(iVar3 + 0xc) = 0;
    }
    uVar2 = *(uint *)(iVar3 + 0x10);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7064 ; VA 0x00636710 ; FUN_00636710 */

void FUN_00636710(undefined4 *param_1,int param_2,int *param_3,undefined4 param_4,int param_5,
                 int *param_6,undefined4 param_7,int param_8)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 ****ppppuVar3;
  int *piVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 ***apppuStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)0x0;
  if ((param_6 != (int *)0x0) && ((undefined4 *)*param_6 != (undefined4 *)0x0)) {
    piVar2 = *(int **)*param_6;
  }
  piVar4 = (int *)0x0;
  if ((param_3 != (int *)0x0) && ((undefined4 *)*param_3 != (undefined4 *)0x0)) {
    piVar4 = *(int **)*param_3;
  }
  puVar5 = (undefined4 *)0x0;
  if ((piVar2 != (int *)0x0) && ((undefined4 *)*piVar2 != (undefined4 *)0x0)) {
    puVar5 = *(undefined4 **)*piVar2;
  }
  if (((piVar4 == (int *)0x0) || ((int *)*piVar4 == (int *)0x0)) ||
     (puVar1 = *(undefined4 **)*piVar4, puVar1 == (undefined4 *)0x0)) {
    uStack_18 = 0;
  }
  else {
    uStack_18 = *puVar1;
  }
  iStack_1c = param_5;
  if (puVar5 == (undefined4 *)0x0) {
    uStack_14 = 0;
  }
  else {
    uStack_14 = *puVar5;
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_0058a190(param_8 - param_5);
  FUN_00633180(uStack_18,iStack_1c,uStack_14,param_8,param_2);
  uStack_8 = 0;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  ppppuVar3 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar3 = (undefined4 ****)apppuStack_34[0];
  }
  FUN_00591430(param_2 - (int)param_1,0,ppppuVar3,uStack_24);
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_34[0];
    if (0xfff < uVar6) {
      ppppuVar3 = (undefined4 ****)apppuStack_34[0][-1];
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7065 ; VA 0x00636840 ; FUN_00636840 */

void __thiscall FUN_00636840(int param_1,undefined4 param_2,int param_3,int param_4,int param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = param_3;
  uVar2 = FUN_005702d0(param_3);
  FUN_005d4110(&param_3,uVar2,iVar1);
  if (param_3 == 0) {
    FUN_00605ce0(param_4);
    if (*(uint *)(param_1 + 0x10) < *(int *)(param_1 + 8) + 1U) {
      FUN_005d99d0((param_5 - param_4) / 0x30 + *(int *)(param_1 + 8));
    }
    FUN_005c5550(&param_4,param_2,uVar2);
  }
  return;
}



/* FUNCTION 7066 ; VA 0x006368c0 ; FUN_006368c0 */

undefined4 * FUN_006368c0(undefined4 *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined auStack_43 [21];
  undefined auStack_2e [2];
  undefined *puStack_2c;
  undefined *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  undefined uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  puStack_2c = auStack_43;
  uStack_8 = 0;
  puStack_28 = auStack_2e;
  uStack_14 = 1;
  iVar1 = *param_2;
  iStack_24 = iVar1;
  if (iVar1 < 0) {
    iStack_24 = -iVar1;
  }
  puStack_20 = auStack_2e;
  uStack_1c = 0x30;
  uStack_18 = 0x30;
  puStack_2c = (undefined *)FUN_0063a3c0();
  if (iVar1 < 0) {
    puStack_2c = puStack_2c + -1;
    *puStack_2c = 0x2d;
  }
  uVar2 = param_1[5];
  puStack_28 = auStack_2e;
  puVar5 = param_1;
  if (0xf < uVar2) {
    puVar5 = (undefined4 *)*param_1;
  }
  puVar3 = param_1;
  if (0xf < uVar2) {
    puVar3 = (undefined4 *)*param_1;
  }
  puVar4 = param_1;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*param_1;
  }
  FUN_00591430((int)puVar3 - (int)puVar4,(undefined *)((int)puVar5 + (param_1[4] - (int)puVar3)),
               puStack_2c,auStack_2e + -(int)puStack_2c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7067 ; VA 0x006369a0 ; FUN_006369a0 */

void FUN_006369a0(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f937;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x24);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>
              ::vftable;
    *(undefined *)(puVar1 + 3) = 0;
    uVar2 = FUN_005c9310(*(undefined4 *)(param_2 + 8));
    puVar1[4] = uVar2;
    puVar1[5] = 0;
    puVar1[6] = *(undefined4 *)(param_2 + 0xc);
    puVar1[7] = 0;
    puVar1[8] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_005c9140(param_2);
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7068 ; VA 0x00636a50 ; FUN_00636a50 */

int * FUN_00636a50(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ead658,&LAB_00634090);
  uVar3 = FUN_006350d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b57070();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 7069 ; VA 0x00636b00 ; FUN_00636b00 */

int * FUN_00636b00(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
  uVar3 = FUN_006352d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b8c410();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 7070 ; VA 0x00636bb0 ; FUN_00636bb0 */

int * FUN_00636bb0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ead638,&LAB_006340f0);
  uVar3 = FUN_006353d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b774a0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 7071 ; VA 0x00636c60 ; FUN_00636c60 */

int * FUN_00636c60(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ead600,&LAB_00634100);
  uVar3 = FUN_00635450();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b7a190();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 7072 ; VA 0x00636d10 ; FUN_00636d10 */

void FUN_00636d10(undefined4 *param_1,int *param_2,undefined4 param_3,int param_4,
                 undefined4 *param_5,undefined4 param_6,int param_7,undefined4 *param_8,
                 undefined4 param_9,int param_10)

{
  int iVar1;
  int iVar2;
  undefined4 *puStack_c;
  
  if (param_8 != (undefined4 *)0x0) {
    param_8 = (undefined4 *)*param_8;
  }
  if (param_5 == (undefined4 *)0x0) {
    puStack_c = param_5;
  }
  else {
    puStack_c = (undefined4 *)*param_5;
  }
  if (param_2 == (int *)0x0) {
    iVar1 = 0;
  }
  else {
    iVar1 = *param_2;
  }
  iVar2 = param_10;
  if ((param_4 != param_7) && (iVar2 = param_4, param_7 != param_10)) {
    FUN_006337c0(iVar1,param_4,puStack_c,param_7);
    FUN_006337c0(puStack_c,param_7,param_8,param_10);
    FUN_006337c0(iVar1,param_4,param_8,param_10);
    iVar2 = param_10 + (param_4 - param_7);
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = iVar2;
  if ((param_2 != (int *)0x0) && ((undefined4 *)*param_2 != (undefined4 *)0x0)) {
    *param_1 = *(undefined4 *)*param_2;
  }
  return;
}



/* FUNCTION 7073 ; VA 0x00636dc0 ; FUN_00636dc0 */

void FUN_00636dc0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_6c [52];
  undefined auStack_38 [40];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f958;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_006356b0(auStack_38,param_1);
  uStack_8 = 0;
  FUN_006355c0(auStack_6c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_6c,&DAT_01c2ba38);
}



/* FUNCTION 7074 ; VA 0x00636e10 ; FUN_00636e10 */

void * __thiscall FUN_00636e10(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  void *pvVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  undefined4 *puVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_0179f980;
  puVar9 = *(undefined4 **)(param_1 + 0x2c);
  pvVar5 = ExceptionList;
  if (puVar9 != (undefined4 *)0x0) {
    piVar7 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar7 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      piVar7 = *(int **)(param_1 + 0x30);
      puVar9 = *(undefined4 **)(param_1 + 0x2c);
    }
    piVar1 = (int *)puVar9[1];
    piVar10 = (int *)*puVar9;
    iStack_8 = 0;
    pvVar5 = pvStack_10;
    for (; piVar10 != piVar1; piVar10 = piVar10 + 2) {
      piVar8 = (int *)piVar10[1];
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
        piVar8 = (int *)piVar10[1];
      }
      iVar2 = *piVar10;
      iVar3 = *(int *)(iVar2 + 0xc);
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      iVar4 = FUN_009ec190();
      iVar6 = 0;
      if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        iVar6 = iVar2;
      }
      if (iVar6 != 0) {
        *(undefined *)(iVar6 + 0xee) = 1;
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar2 = piVar8[1] + -1;
        piVar8[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar2 = piVar8[2] + -1;
          piVar8[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      pvVar5 = (void *)FUN_00636e10(param_2);
    }
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar1 = piVar7 + 1;
      iVar2 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piVar7)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 7075 ; VA 0x00636f40 ; FUN_00636f40 */

undefined4 * __thiscall FUN_00636f40(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f9b4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[10] = &DAT_018cf050;
    param_1[0xc] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_lexical_cast::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 1;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7076 ; VA 0x00637030 ; FUN_00637030 */

undefined4 * __thiscall FUN_00637030(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f9c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_lexical_cast::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 0;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>::vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7077 ; VA 0x006370e0 ; FUN_006370e0 */

undefined * __thiscall FUN_006370e0(undefined *param_1,int param_2,int param_3,uint param_4)

{
  int iVar1;
  undefined **ppuVar2;
  undefined **ppuVar3;
  uint uVar4;
  uint uStack_28;
  int iStack_24;
  undefined2 uStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179f9f0;
  pvStack_10 = ExceptionList;
  iStack_18 = param_3;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar4 = (param_3 - param_2) / 0x30 + 1;
  if (param_4 <= uVar4) {
    param_4 = uVar4;
  }
  puStack_1c = param_1;
  ppuVar2 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_4);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  *(undefined **)(param_1 + 4) = *ppuVar3;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  if (param_2 != param_3) {
    iStack_24 = 0;
    uStack_20 = 0;
    uStack_28 = -(uint)(param_1 != (undefined *)0xfffffffd) & (uint)(param_1 + 4);
    uStack_8 = 1;
    FUN_00636840(&uStack_28,param_2,param_2,param_3);
    param_2 = param_2 + 0x30;
    if (param_2 != param_3) {
      param_3 = param_3 - param_2;
      do {
        uStack_14 = FUN_005702d0(param_2);
        FUN_005d4110(&param_4,uStack_14,param_2);
        if (param_4 == 0) {
          FUN_00605ce0(param_2);
          if (*(uint *)(param_1 + 0x10) < *(int *)(param_1 + 8) + 1U) {
            FUN_005d99d0(param_3 / 0x30 + *(int *)(param_1 + 8));
          }
          FUN_005c5550(&uStack_14,&uStack_28,uStack_14);
        }
        param_2 = param_2 + 0x30;
        param_3 = param_3 + -0x30;
      } while (param_2 != iStack_18);
    }
    iVar1 = iStack_24;
    if (iStack_24 != 0) {
      if (uStack_20._1_1_ != '\0') {
        FUN_005509f0();
      }
      FUN_01674ea0(iVar1,0x38);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7078 ; VA 0x00637260 ; FUN_00637260 */

int * __thiscall FUN_00637260(int *param_1,int *param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179fa08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar2 = FUN_00616b10((param_2[1] - *param_2) / 0x18);
  if (cVar2 != '\0') {
    iVar4 = *param_1;
    iVar1 = param_2[1];
    iVar3 = *param_2;
    uStack_8 = 1;
    for (; iVar3 != iVar1; iVar3 = iVar3 + 0x18) {
      FUN_0054ef60(iVar3);
      iVar4 = iVar4 + 0x18;
    }
    FUN_00559570(iVar4,iVar4,param_1);
    param_1[1] = iVar4;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7079 ; VA 0x0063731d ; Catch_All@0063731d */

void Catch_All_0063731d(void)

{
  FUN_00577a40();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7080 ; VA 0x00637330 ; FUN_00637330 */

undefined * __thiscall FUN_00637330(undefined *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar2 = param_2;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_2,(int)pcVar2 - (int)(param_2 + 1));
  uStack_8 = 0;
  FUN_009cbbb0(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7081 ; VA 0x006373b0 ; FUN_006373b0 */

undefined4 * __thiscall FUN_006373b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179fa2f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x24);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::vftable;
    FUN_0054ef60(param_3);
  }
  param_1[2] = puVar1 + 3;
  param_1[3] = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7082 ; VA 0x00637440 ; FUN_00637440 */

undefined4 * __thiscall FUN_00637440(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_lexical_cast::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  return param_1;
}



/* FUNCTION 7083 ; VA 0x00637490 ; FUN_00637490 */

undefined4 * __thiscall FUN_00637490(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined8 *)(param_1 + 1) = 0;
  param_1[3] = param_2;
  param_1[4] = param_3;
  param_1[1] = "bad cast";
  *param_1 = boost::bad_lexical_cast::vftable;
  return param_1;
}



/* FUNCTION 7084 ; VA 0x006374c0 ; FUN_006374c0 */

undefined4 __thiscall FUN_006374c0(undefined4 param_1,undefined4 param_2)

{
  undefined2 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179fa48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined2 *)FUN_01674e20(0x2c);
  if (puVar1 == (undefined2 *)0x0) {
    puVar1 = (undefined2 *)0x0;
  }
  else {
    *(undefined4 *)(puVar1 + 8) = 0;
    *(undefined4 *)(puVar1 + 10) = 7;
    *puVar1 = 0;
    *(undefined4 *)(puVar1 + 0xc) = 0;
    *(undefined4 *)(puVar1 + 0xe) = 0xffff;
    *(undefined4 *)(puVar1 + 0x10) = 0;
    *(undefined4 *)(puVar1 + 0x12) = 0xffff;
    *(undefined4 *)(puVar1 + 0x14) = 0;
  }
  FUN_00632a90(puVar1);
  uStack_8 = 0;
  FUN_0168c2c0(param_1,param_2,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7085 ; VA 0x00637550 ; FUN_00637550 */

void __fastcall FUN_00637550(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7086 ; VA 0x006375c0 ; FUN_006375c0 */

void __fastcall FUN_006375c0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00634fe0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x58);
  }
  return;
}



/* FUNCTION 7087 ; VA 0x006375f0 ; FUN_006375f0 */

void __fastcall FUN_006375f0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0x17];
  if (0xf < uVar1) {
    iVar2 = param_1[0x12];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637703;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x16] = 0;
  param_1[0x17] = 0xf;
  *(undefined *)(param_1 + 0x12) = 0;
  uVar1 = param_1[0x11];
  if (0xf < uVar1) {
    iVar2 = param_1[0xc];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637703;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  uVar1 = param_1[0xb];
  if (0xf < uVar1) {
    iVar2 = param_1[6];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637703;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00637703:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 7088 ; VA 0x00637710 ; FUN_00637710 */

void __fastcall FUN_00637710(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00634fe0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x58);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7089 ; VA 0x006377c0 ; FUN_006377c0 */

void __fastcall FUN_006377c0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_006375f0();
        FUN_01674ea0(puVar6,0x68);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7090 ; VA 0x00637850 ; FUN_00637850 */

void __fastcall FUN_00637850(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00634fe0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x58);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7091 ; VA 0x00637860 ; FUN_00637860 */

void __fastcall FUN_00637860(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00637af0();
        iVar2 = iVar2 + 0x3c;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x3c) * 0x3c;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 7092 ; VA 0x006378f0 ; FUN_006378f0 */

void __fastcall FUN_006378f0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_00633350(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 7093 ; VA 0x00637950 ; FUN_00637950 */

void __fastcall FUN_00637950(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0x11];
  if (0xf < uVar1) {
    iVar2 = param_1[0xc];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637a1d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  uVar1 = param_1[0xb];
  if (0xf < uVar1) {
    iVar2 = param_1[6];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637a1d;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00637a1d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 7094 ; VA 0x00637a30 ; FUN_00637a30 */

void FUN_00637a30(void)

{
  FUN_00637a50();
  FUN_0056e380();
  FUN_0056e380();
  return;
}



/* FUNCTION 7095 ; VA 0x00637a50 ; FUN_00637a50 */

void __fastcall FUN_00637a50(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (7 < (uint)param_1[0xb]) {
    iVar2 = param_1[6];
    iVar1 = param_1[0xb] * 2;
    uVar4 = iVar1 + 2;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = iVar1 + 0x25;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637ae7;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 7;
  *(undefined2 *)(param_1 + 6) = 0;
  if (7 < (uint)param_1[5]) {
    iVar2 = *param_1;
    iVar1 = param_1[5] * 2;
    uVar4 = iVar1 + 2;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = iVar1 + 0x25;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00637ae7:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 7;
  *(undefined2 *)param_1 = 0;
  return;
}



/* FUNCTION 7096 ; VA 0x00637af0 ; FUN_00637af0 */

void __fastcall FUN_00637af0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0xe];
  if (0xf < uVar1) {
    iVar2 = param_1[9];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637b77;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0xd] = 0;
  param_1[0xe] = 0xf;
  *(undefined *)(param_1 + 9) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00637b77:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 7097 ; VA 0x00637b80 ; FUN_00637b80 */

void __fastcall FUN_00637b80(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0xb4);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xa0);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637d8e;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xb0) = 0;
  *(undefined4 *)(param_1 + 0xb4) = 0xf;
  *(undefined *)(param_1 + 0xa0) = 0;
  uVar1 = *(uint *)(param_1 + 0x9c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x88);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637d8e;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x98) = 0;
  *(undefined4 *)(param_1 + 0x9c) = 0xf;
  *(undefined *)(param_1 + 0x88) = 0;
  uVar1 = *(uint *)(param_1 + 0x84);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x70);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637d8e;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0xf;
  *(undefined *)(param_1 + 0x70) = 0;
  uVar1 = *(uint *)(param_1 + 0x6c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x58);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637d8e;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0xf;
  *(undefined *)(param_1 + 0x58) = 0;
  uVar1 = *(uint *)(param_1 + 0x54);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x40);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637d8e;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0xf;
  *(undefined *)(param_1 + 0x40) = 0;
  uVar1 = *(uint *)(param_1 + 0x38);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x24);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00637d8e;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0xf;
  *(undefined *)(param_1 + 0x24) = 0;
  uVar1 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xc);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00637d8e:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  return;
}



/* FUNCTION 7098 ; VA 0x00637da0 ; FUN_00637da0 */

int __thiscall FUN_00637da0(int param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  
  FUN_00886840(param_2);
  puVar2 = (undefined4 *)(param_2 + 8);
  if ((undefined4 *)(param_1 + 8) != puVar2) {
    if (7 < *(uint *)(param_2 + 0x1c)) {
      puVar2 = (undefined4 *)*puVar2;
    }
    FUN_0058ed10(puVar2,*(undefined4 *)(param_2 + 0x18));
  }
  piVar1 = (int *)(param_2 + 0x20);
  if ((int *)(param_1 + 0x20) != piVar1) {
    if (7 < *(uint *)(param_2 + 0x34)) {
      piVar1 = (int *)*piVar1;
    }
    FUN_0058ed10(piVar1,*(undefined4 *)(param_2 + 0x30));
  }
  return param_1;
}



/* FUNCTION 7099 ; VA 0x00637e00 ; FUN_00637e00 */

undefined __thiscall FUN_00637e00(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint uVar10;
  int aiStack_5c [5];
  uint uStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179fa92;
  pvStack_10 = ExceptionList;
  bVar5 = false;
  bVar4 = false;
  bVar3 = false;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 4) == *(int *)(param_2 + 4)) {
LAB_00637ebf:
    param_2._3_1_ = 1;
  }
  else {
    ExceptionList = &pvStack_10;
    puVar6 = (undefined4 *)FUN_0063c740(aiStack_5c);
    puVar1 = puVar6 + 4;
    uStack_8 = 0;
    bVar4 = false;
    bVar3 = false;
    uStack_14 = 1;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    iVar7 = FUN_0055c2d0(puVar6,*puVar1,&DAT_018c0df0,1);
    if (iVar7 != 0) {
      puVar8 = (undefined4 *)FUN_0063c740(auStack_44);
      uStack_8 = 1;
      uStack_14 = 3;
      puVar6 = (undefined4 *)FUN_0063c740(auStack_2c);
      bVar5 = true;
      bVar4 = true;
      bVar3 = true;
      puVar1 = puVar6 + 4;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      puVar2 = puVar8 + 4;
      if (0xf < (uint)puVar8[5]) {
        puVar8 = (undefined4 *)*puVar8;
      }
      iVar7 = FUN_0055c2d0(puVar8,*puVar2,puVar6,*puVar1);
      if (iVar7 == 0) goto LAB_00637ebf;
    }
    bVar5 = true;
    param_2._3_1_ = 0;
  }
  if (bVar3) {
    if (0xf < uStack_18) {
      uVar9 = uStack_18 + 1;
      uVar10 = auStack_2c[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_2c[0] - 4);
        uVar9 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  }
  if (bVar4) {
    if (0xf < uStack_30) {
      uVar9 = uStack_30 + 1;
      uVar10 = auStack_44[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_44[0] - 4);
        uVar9 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
  }
  if ((bVar5) && (0xf < uStack_48)) {
    uVar10 = uStack_48 + 1;
    iVar7 = aiStack_5c[0];
    if (0xfff < uVar10) {
      iVar7 = *(int *)(aiStack_5c[0] + -4);
      uVar10 = uStack_48 + 0x24;
      if (0x1f < (aiStack_5c[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar10);
  }
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 7100 ; VA 0x00637fc0 ; FUN_00637fc0 */

int * __thiscall FUN_00637fc0(int param_1,undefined4 *param_2)

{
  uint uVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179fab0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_005702d0(param_2);
  uStack_14 = uVar3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar10 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
    uVar9 = uStack_14;
    if (puVar10 == (undefined4 *)0x0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = (undefined4 *)*puVar10;
    }
    for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
      if (uVar3 == puVar10[1]) {
        piVar4 = puVar10 + 2;
        if (0xf < (uint)puVar10[7]) {
          piVar4 = (int *)*piVar4;
        }
        puVar6 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar6 = (undefined4 *)*param_2;
        }
        cVar2 = FUN_0055c360(puVar6,param_2[4],piVar4,puVar10[6]);
        uVar9 = uStack_14;
        if (cVar2 != '\0') {
          if (puVar10 != (undefined4 *)0x0) {
            ExceptionList = pvStack_10;
            return puVar10 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar10[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != -3) & param_1 + 4U;
  iStack_8 = 0;
  FUN_0054ef60(param_2);
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  piVar4 = (int *)FUN_01674e20(0x58);
  piStack_18 = piVar4 + 2;
  *piVar4 = 0;
  piVar4[1] = 0;
  piStack_20 = piVar4;
  FUN_0170d1f0(piStack_18,0,0x50);
  uStack_1c = CONCAT11(uStack_1c._1_1_,1);
  FUN_0054ef60(aiStack_3c);
  FUN_0170d1f0(piVar4 + 8,0,0x38);
  FUN_008866d0();
  piVar4[0xe] = 0;
  piVar4[0xf] = 7;
  *(undefined2 *)(piVar4 + 10) = 0;
  piVar4[0x14] = 0;
  piVar4[0x15] = 7;
  *(undefined2 *)(piVar4 + 0x10) = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar9 = uStack_28 + 1;
    iVar5 = aiStack_3c[0];
    if (0xfff < uVar9) {
      iVar5 = *(int *)(aiStack_3c[0] + -4);
      uVar9 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar9);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar9 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar9 = FUN_005c9310(uVar9);
    if (uVar9 <= *(uint *)(param_1 + 4)) {
      uVar9 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar9);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar9) {
    uStack_14 = 1;
    uVar7 = uVar1 >> 1;
    if ((uVar1 >> 1) + uVar1 <= uVar9) {
      uVar7 = 1;
    }
    iVar5 = FUN_005c9310(uVar7 + uVar1);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar6 = (undefined4 *)*puVar10;
      while (puVar6 != (undefined4 *)0x0) {
        uVar9 = (uint)puVar6[1] % *(uint *)(param_1 + 4);
        piVar8 = (int *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar9 * 4) == 0) {
          *piVar8 = (int)puVar10;
          puVar10 = puVar6;
        }
        else {
          *puVar10 = *puVar6;
          *puVar6 = *(undefined4 *)*piVar8;
          *(undefined4 **)*piVar8 = puVar6;
        }
        puVar6 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar4[1] = uVar3;
  uVar3 = uVar3 % *(uint *)(param_1 + 4);
  piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar4;
    }
    *puVar10 = piVar8;
    *piVar4 = *piVar8;
  }
  else {
    *piVar4 = *piVar8;
    piVar8 = (int *)*puVar10;
  }
  *piVar8 = (int)piVar4;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 7101 ; VA 0x00638270 ; FUN_00638270 */

void __fastcall FUN_00638270(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7102 ; VA 0x00638308 ; FUN_00638308 */

void FUN_00638308(void)

{
  FUN_00638360();
  return;
}



/* FUNCTION 7103 ; VA 0x00638313 ; FUN_00638313 */

void FUN_00638313(void)

{
  FUN_00638360();
  return;
}



/* FUNCTION 7104 ; VA 0x0063831b ; FUN_0063831b */

void FUN_0063831b(void)

{
  FUN_00638390();
  return;
}



/* FUNCTION 7105 ; VA 0x00638330 ; FUN_00638330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00638330(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::CreatorType>::vftable;
  _DAT_01ee08a0 = _DAT_01ee08a0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 7106 ; VA 0x00638360 ; FUN_00638360 */

undefined4 __thiscall FUN_00638360(undefined4 param_1,byte param_2)

{
  FUN_00638270();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 7107 ; VA 0x00638390 ; FUN_00638390 */

undefined4 * __thiscall FUN_00638390(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7108 ; VA 0x00638410 ; FUN_00638410 */

void __thiscall FUN_00638410(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00633350(param_2,param_3,param_1);
  return;
}



/* FUNCTION 7109 ; VA 0x00638430 ; FUN_00638430 */

void __thiscall FUN_00638430(int param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar4 = *(uint *)(param_1 + 8);
  uVar1 = 1;
  if (uVar4 != 0) {
    uVar1 = uVar4;
  }
  for (; (uVar3 = uVar1 - uVar4, uVar3 < param_2 || (uVar1 < 8)); uVar1 = uVar1 * 2) {
    if (0xfffffff - uVar1 < uVar1) {
      FUN_00593ce0();
LAB_00638607:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar4 = uVar1 * 4;
  uVar5 = *(uint *)(param_1 + 0xc) >> 4;
  if (uVar1 < 0x40000000) {
    if (0xfff < uVar4) goto LAB_00638497;
    if (uVar4 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar4 = 0xffffffff;
LAB_00638497:
    uVar1 = uVar4 + 0x23;
    if (uVar1 <= uVar4) {
      uVar1 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 == 0) goto LAB_00638607;
    uVar4 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar4 - 4) = iVar2;
  }
  iVar7 = *(int *)(param_1 + 4);
  iVar8 = uVar5 * 4;
  iVar2 = iVar7 + iVar8;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar7 = (*(int *)(param_1 + 8) * 4 - iVar2) + iVar7;
  FUN_0170cc70(iVar8 + uVar4,iVar2,iVar7);
  iVar7 = iVar7 + iVar8 + uVar4;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar3 < uVar5) {
    iVar6 = uVar3 * 4;
    FUN_0170cc70(iVar7,*(undefined4 *)(param_1 + 4),iVar6);
    iVar7 = *(int *)(param_1 + 4);
    iVar2 = iVar6 + iVar7;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar8 = (iVar7 - iVar2) + iVar8;
    FUN_0170cc70(uVar4,iVar2,iVar8);
    FUN_0170d1f0(iVar8 + uVar4,0,iVar6);
  }
  else {
    FUN_0170cc70(iVar7,*(undefined4 *)(param_1 + 4),uVar5 * 4);
    FUN_0170d1f0(iVar7 + iVar8,0,(uVar3 - uVar5) * 4);
    FUN_0170d1f0(uVar4,0,iVar8);
  }
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    uVar1 = *(int *)(param_1 + 8) * 4;
    iVar7 = iVar2;
    if (0xfff < uVar1) {
      iVar7 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar7) - 4U) goto LAB_00638607;
    }
    FUN_01674ea0(iVar7,uVar1);
  }
  *(uint *)(param_1 + 4) = uVar4;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar3;
  return;
}



/* FUNCTION 7110 ; VA 0x00638610 ; FUN_00638610 */

int FUN_00638610(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,char param_5,
                char param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  uint auStack_40 [2];
  undefined auStack_38 [8];
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179faf7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006346b0(&piStack_18);
  uStack_8._0_1_ = 1;
  FUN_00ba8ce0(param_3);
  uVar3 = FUN_0151a940(auStack_40,param_2);
  uStack_8._0_1_ = 2;
  FUN_00ba89c0(uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < piStack_2c) {
    uVar6 = (int)piStack_2c + 1;
    uVar5 = auStack_40[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_40[0] - 4);
      uVar6 = (int)piStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  FUN_008a65e0(param_1,0);
  (**(code **)(*piStack_18 + 0x1c))(0);
  if (param_6 != '\0') {
    FUN_00ba8a30(1);
  }
  uStack_30 = 0;
  piStack_2c = (int *)&DAT_0000000f;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 3;
  uStack_28 = 0;
  uStack_24 = 0;
  piStack_1c = (int *)FUN_01674e20(0x24);
  uStack_8._0_1_ = 4;
  if (piStack_1c == (int *)0x0) {
    piStack_1c = (int *)0x0;
  }
  else {
    piStack_1c[1] = 1;
    piStack_1c[2] = 1;
    *piStack_1c = (int)std::
                       _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                       ::vftable;
    FUN_0054ef60(auStack_40);
  }
  piStack_20 = piStack_1c + 3;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (&DAT_0000000f < piStack_2c) {
    piVar7 = (int *)((int)piStack_2c + 1);
    uVar5 = auStack_40[0];
    if ((int *)0xfff < piVar7) {
      uVar5 = *(uint *)(auStack_40[0] - 4);
      piVar7 = piStack_2c + 9;
      if (0x1f < (auStack_40[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,piVar7);
  }
  if (param_5 != '\0') {
    uStack_24 = 2;
  }
  FUN_00ba8d80(auStack_38,&uStack_28);
  piVar7 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  iVar4 = FUN_00ba8890(1);
  piVar7 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar7 = piStack_14 + 1;
    iVar2 = *piVar7;
    iVar4 = *piVar7;
    *piVar7 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar7 = piStack_14 + 2;
      iVar2 = *piVar7;
      iVar4 = *piVar7;
      *piVar7 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar7 = param_4 + 1;
    iVar2 = *piVar7;
    iVar4 = *piVar7;
    *piVar7 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_4)();
      LOCK();
      piVar7 = param_4 + 2;
      iVar2 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 7111 ; VA 0x00638860 ; FUN_00638860 */

void __thiscall FUN_00638860(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0xc) = param_2;
  FUN_006394c0();
  return;
}



/* FUNCTION 7112 ; VA 0x00638880 ; FUN_00638880 */

uint __fastcall FUN_00638880(int param_1)

{
  int *piVar1;
  uint *puVar2;
  int *piVar3;
  uint uVar4;
  code *pcVar5;
  char cVar6;
  int iVar7;
  uint uVar8;
  undefined **ppuVar9;
  int iVar10;
  int *****pppppiVar11;
  int *******pppppppiVar12;
  undefined4 *puVar13;
  undefined **ppuVar14;
  int ******ppppppiVar15;
  undefined *puVar16;
  int ******ppppppiVar17;
  int ******ppppppiVar18;
  int ******ppppppiStack_178;
  int ******ppppppiStack_174;
  int ******ppppppiStack_170;
  int *****pppppiStack_16c;
  undefined auStack_130 [8];
  undefined auStack_128 [48];
  undefined auStack_f8 [4];
  undefined *puStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined auStack_e0 [4];
  undefined *puStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined2 auStack_c8 [8];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined auStack_b0 [12];
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  int ******ppppppiStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined *puStack_88;
  uint uStack_84;
  undefined *puStack_80;
  undefined2 auStack_7c [8];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  int iStack_64;
  int *piStack_60;
  int *piStack_5c;
  int *piStack_58;
  int ******ppppppiStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined *puStack_44;
  uint uStack_40;
  int ******ppppppiStack_3c;
  undefined auStack_38 [4];
  int *****pppppiStack_34;
  int iStack_30;
  undefined4 uStack_28;
  int ******ppppppiStack_24;
  int iStack_20;
  int *****pppppiStack_1c;
  int iStack_18;
  int *****pppppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179fc5f;
  pvStack_10 = ExceptionList;
  pppppiStack_14 = (int *****)0x0;
  pppppiStack_1c = (int *****)0x0;
  uVar8 = *(int *)(param_1 + 0xc) + 0xc;
  if ((-(uint)(*(int *)(param_1 + 0xc) != 0) & uVar8) == 0) {
    return uVar8;
  }
  pppppiStack_16c = (int *****)0x6388c4;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  iVar7 = FUN_006357d0();
  if (iVar7 == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  pppppiStack_16c = (int *****)&iStack_64;
  ppppppiStack_170 = (int ******)0x6388d7;
  uVar8 = FUN_00b5efb0();
  uStack_8 = 0;
  if (iStack_64 == 0) goto LAB_006392af;
  pppppiStack_16c = (int *****)0x6388f6;
  cVar6 = FUN_00585a40();
  if (cVar6 != '\0') {
    pppppiStack_16c = (int *****)0x6388ff;
    FUN_00b74e80();
  }
  pppppiStack_16c = (int *****)0x63890d;
  cVar6 = FUN_00585a40();
  if (cVar6 != '\0') {
    pppppiStack_16c = (int *****)0x638916;
    cVar6 = FUN_00b74e80();
    if (cVar6 == '\0') {
      pppppiStack_16c = *(int ******)(param_1 + 0xc);
      if ((-(uint)(pppppiStack_16c != (int *****)0x0) & (int)pppppiStack_16c + 0xcU) != 0) {
        pppppiStack_16c = (int *****)0x63892f;
        FUN_00634520();
        pppppiStack_16c = *(int ******)(param_1 + 0xc);
      }
      ppppppiStack_170 = (int ******)0x63893e;
      uVar8 = FUN_00ba0110();
      goto LAB_006392af;
    }
  }
  pppppiStack_16c = (int *****)&piStack_5c;
  ppppppiStack_170 = (int ******)0x63894c;
  FUN_00634770();
  pppppiStack_16c = (int *****)&DAT_01d5a360;
  uStack_8._0_1_ = 1;
  ppppppiStack_170 = (int ******)0x638960;
  (**(code **)(*piStack_5c + 0x38))();
  pppppiStack_16c = (int *****)iStack_64;
  ppppppiStack_170 = (int ******)0x63896b;
  ppppppiStack_170 = (int ******)FUN_00635790();
  pppppiStack_16c = (int *****)0x0;
  ppppppiStack_174 = (int ******)0x638978;
  FUN_008a65e0();
  pppppiStack_16c = (int *****)&pppppiStack_14;
  auStack_f8[0] = 0;
  ppppppiStack_170 = (int ******)&boost::lock_error::vftable_meta_ptr;
  ppppppiStack_174 = (int ******)&DAT_018be100;
  pppppiStack_14 = (int *****)0xb;
  ppppppiStack_178 = (int ******)0x638999;
  ppuVar9 = (undefined **)FUN_00563d40();
  ppuVar14 = ppuVar9 + -1;
  if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar14 = ppuVar9;
  }
  puStack_f4 = *ppuVar14;
  uStack_f0 = 0;
  uStack_ec = 0x3f800000;
  uStack_e8 = 0;
  uStack_e4 = 0;
  ppppppiStack_178 = &pppppiStack_14;
  auStack_e0[0] = 0;
  pppppiStack_14 = (int *****)&DAT_0000000b;
  ppuVar9 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr);
  ppuVar14 = ppuVar9 + -1;
  if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar14 = ppuVar9;
  }
  puStack_dc = *ppuVar14;
  uStack_d8 = 0;
  uStack_d4 = 0x3f800000;
  uStack_d0 = 0;
  uStack_cc = 0;
  uStack_8._0_1_ = 3;
  pppppiStack_16c = (int *****)0x638a3c;
  cVar6 = FUN_00554b40();
  if (cVar6 == '\0') {
    pppppiStack_16c = (int *****)auStack_38;
    ppppppiStack_170 = (int ******)0x638d86;
    FUN_009edec0();
    uStack_8._0_1_ = 0x17;
    pppppiStack_14 = pppppiStack_34;
    if (iStack_30 == 0) {
      ppppppiVar17 = (int ******)0x0;
    }
    else {
      ppppppiVar17 = (int ******)ppppppiStack_24[(int)pppppiStack_34];
    }
    if (ppppppiVar17 != (int ******)0x0) {
      puStack_80 = auStack_128;
      do {
        pppppiStack_16c = ppppppiVar17[6];
        ppppppiStack_170 = ppppppiVar17 + 2;
        if ((int *****)0xf < ppppppiVar17[7]) {
          ppppppiStack_170 = (int ******)*ppppppiStack_170;
        }
        ppppppiStack_174 = (int ******)&ppppppiStack_98;
        ppppppiStack_178 = (int ******)0x638ddb;
        FUN_015312b0();
        ppppppiStack_178 = ppppppiVar17 + 0x14;
        uStack_8._0_1_ = 0x18;
        iStack_18 = FUN_008869b0(&uStack_a0);
        uStack_6c = 0;
        ppppppiVar18 = ppppppiVar17 + 0xe;
        uStack_68 = 7;
        auStack_7c[0] = 0;
        pppppiVar11 = ppppppiVar17[0x12];
        uStack_8._0_1_ = 0x1a;
        if (pppppiVar11 != (int *****)0x0) {
          ppppppiVar15 = ppppppiVar18;
          if ((int *****)0xf < ppppppiVar17[0x13]) {
            ppppppiVar15 = (int ******)*ppppppiVar18;
          }
          ppppppiStack_3c = (int ******)((int)pppppiVar11 + (int)ppppppiVar15);
          pppppiStack_14 = (int *****)ppppppiVar18;
          if ((int *****)0xf < ppppppiVar17[0x13]) {
            pppppiStack_14 = *ppppppiVar18;
          }
          pppppiStack_16c = (int *****)0x638e3a;
          pppppiStack_16c = (int *****)FUN_01686580();
          ppppppiStack_170 = (int ******)auStack_7c;
          ppppppiStack_174 = ppppppiStack_3c;
          ppppppiStack_178 = (int ******)pppppiStack_14;
          FUN_01685950();
          pppppiVar11 = ppppppiVar17[0x12];
        }
        uStack_b8 = 0;
        uStack_b4 = 7;
        auStack_c8[0] = 0;
        uStack_8._0_1_ = 0x1c;
        if (pppppiVar11 != (int *****)0x0) {
          ppppppiVar15 = ppppppiVar18;
          if ((int *****)0xf < ppppppiVar17[0x13]) {
            ppppppiVar15 = (int ******)*ppppppiVar18;
          }
          ppppppiStack_3c = (int ******)((int)pppppiVar11 + (int)ppppppiVar15);
          if ((int *****)0xf < ppppppiVar17[0x13]) {
            ppppppiVar18 = (int ******)*ppppppiVar18;
          }
          pppppiStack_16c = (int *****)0x638e92;
          pppppiStack_16c = (int *****)FUN_01686580();
          ppppppiStack_170 = (int ******)auStack_c8;
          ppppppiStack_174 = ppppppiStack_3c;
          ppppppiStack_178 = ppppppiVar18;
          FUN_01685950();
        }
        pppppiStack_16c = (int *****)auStack_c8;
        uStack_8._0_1_ = 0x1d;
        ppppppiStack_170 = (int ******)auStack_7c;
        ppppppiStack_174 = (int ******)0x638ec0;
        iVar7 = FUN_00b767d0();
        pppppiStack_16c = (int *****)iStack_18;
        uStack_8._0_1_ = 0x1e;
        ppppppiStack_170 = (int ******)0x638ed4;
        FUN_008866a0();
        uStack_8._0_1_ = 0x1f;
        ppppppiStack_170 = (int ******)0x638ee4;
        pppppiStack_16c = (int *****)iVar7;
        FUN_0054f050();
        pppppiStack_16c = (int *****)(iVar7 + 0x18);
        uStack_8._0_1_ = 0x20;
        ppppppiStack_170 = (int ******)0x638ef7;
        FUN_0054f050();
        pppppiStack_16c = (int *****)0x638f02;
        FUN_00637a50();
        pppppiStack_16c = (int *****)0x638f0d;
        FUN_00550800();
        pppppiStack_16c = (int *****)0x638f15;
        FUN_00550800();
        pppppiStack_16c = (int *****)0x638f20;
        FUN_0056e380();
        pppppiStack_16c = (int *****)0x638f2b;
        FUN_0056e380();
        pppppiStack_1c = (int *****)((uint)pppppiStack_1c | 2);
        uStack_8._0_1_ = 0x26;
        pppppiStack_16c = (int *****)(DAT_01d5a328 + 1);
        puStack_44 = (undefined *)0x0;
        uStack_40 = 0xf;
        ppppppiStack_54 = (int ******)((uint)ppppppiStack_54 & 0xffffff00);
        ppppppiStack_170 = (int ******)0x638f5c;
        pppppiStack_14 = pppppiStack_1c;
        FUN_0058a190();
        pppppiStack_16c = (int *****)DAT_01d5a328;
        ppppppiStack_170 = (int ******)&DAT_01d5a318;
        if (0xf < DAT_01d5a32c) {
          ppppppiStack_170 = (int ******)DAT_01d5a318;
        }
        ppppppiStack_174 = (int ******)0x638f7e;
        FUN_00554150();
        pppppiStack_16c = (int *****)0x1;
        ppppppiStack_170 = (int ******)&DAT_018c36fc;
        ppppppiStack_174 = (int ******)0x638f8d;
        FUN_00554150();
        ppppppiVar18 = ppppppiStack_54;
        pppppiStack_16c = (int *****)puStack_44;
        ppppppiStack_170 = (int ******)&ppppppiStack_54;
        if (0xf < uStack_40) {
          ppppppiStack_170 = ppppppiStack_54;
        }
        ppppppiStack_174 = (int ******)(DAT_01d5a328 + 1);
        if (puStack_88 < (undefined *)(DAT_01d5a328 + 1)) {
          ppppppiStack_174 = (int ******)puStack_88;
        }
        ppppppiStack_178 = (int ******)&ppppppiStack_98;
        if (0xf < uStack_84) {
          ppppppiStack_178 = ppppppiStack_98;
        }
        iStack_18 = FUN_0055c2d0();
        pppppiStack_1c = (int *****)((uint)pppppiStack_1c & 0xfffffffd);
        uStack_8._0_1_ = 0x25;
        if (0xf < uStack_40) {
          pppppiStack_16c = (int *****)(uStack_40 + 1);
          pppppppiVar12 = (int *******)ppppppiVar18;
          if (0xfff < pppppiStack_16c) {
            pppppppiVar12 = (int *******)ppppppiVar18[-1];
            pppppiStack_16c = (int *****)(uStack_40 + 0x24);
            if ((undefined *)0x1f < (undefined *)((int)ppppppiVar18 + (-4 - (int)pppppppiVar12)))
            goto LAB_006392e7;
          }
          ppppppiStack_174 = (int ******)0x639008;
          ppppppiStack_170 = (int ******)pppppppiVar12;
          FUN_01674ea0();
        }
        if (iStack_18 == 0) {
          puVar16 = (undefined *)(DAT_01d5a328 + 1);
          puStack_44 = (undefined *)0x0;
          uStack_40 = 0xf;
          ppppppiStack_54 = (int ******)((uint)ppppppiStack_54 & 0xffffff00);
          if (puStack_88 < puVar16) {
            pppppiStack_16c = (int *****)0x6392f1;
            FUN_00554050();
            pcVar5 = (code *)swi(3);
            uVar8 = (*pcVar5)();
            return uVar8;
          }
          pppppiStack_16c = (int *****)-1;
          if ((int)puStack_88 - (int)puVar16 != -1) {
            pppppiStack_16c = (int *****)((int)puStack_88 - (int)puVar16);
          }
          pppppppiVar12 = &ppppppiStack_98;
          if (0xf < uStack_84) {
            pppppppiVar12 = (int *******)ppppppiStack_98;
          }
          ppppppiStack_170 = (int ******)((int)pppppppiVar12 + (int)puVar16);
          ppppppiStack_174 = (int ******)0x63906b;
          FUN_005542c0();
          pppppiStack_1c = (int *****)((uint)pppppiStack_1c | 4);
          pppppiStack_16c = (int *****)0x63907a;
          FUN_005507b0();
          ppppppiStack_98 = ppppppiStack_54;
          ppppppiStack_54 = (int ******)((uint)ppppppiStack_54 & 0xffffff00);
          uStack_94 = uStack_50;
          uStack_90 = uStack_4c;
          uStack_8c = uStack_48;
          puStack_88 = puStack_44;
          uStack_84 = uStack_40;
          puStack_44 = (undefined *)0x0;
          uStack_40 = 0xf;
          pppppiStack_16c = (int *****)0x6390ac;
          FUN_005507b0();
        }
        pppppiStack_16c = (int *****)auStack_130;
        ppppppiStack_170 = (int ******)&ppppppiStack_98;
        ppppppiStack_174 = (int ******)0x6390c5;
        FUN_00637fc0();
        ppppppiStack_170 = (int ******)0x6390cd;
        FUN_00637da0();
        pppppiStack_16c = (int *****)0x6390d8;
        FUN_00637a50();
        pppppiStack_16c = (int *****)0x6390e3;
        FUN_0056e380();
        pppppiStack_16c = (int *****)0x6390ee;
        FUN_0056e380();
        uStack_8._0_1_ = 0x17;
        if (0xf < uStack_84) {
          pppppiStack_16c = (int *****)(uStack_84 + 1);
          pppppppiVar12 = (int *******)ppppppiStack_98;
          if (0xfff < pppppiStack_16c) {
            pppppppiVar12 = (int *******)ppppppiStack_98[-1];
            pppppiStack_16c = (int *****)(uStack_84 + 0x24);
            if ((undefined *)0x1f < (undefined *)((int)ppppppiStack_98 + (-4 - (int)pppppppiVar12)))
            goto LAB_006392e7;
          }
          ppppppiStack_174 = (int ******)0x639126;
          ppppppiStack_170 = (int ******)pppppppiVar12;
          FUN_01674ea0();
        }
        ppppppiVar17 = (int ******)*ppppppiVar17;
      } while (ppppppiVar17 != (int ******)0x0);
    }
    ppppppiVar17 = ppppppiStack_24;
    uStack_8._0_1_ = 3;
    iVar7 = iStack_20;
    pppppiStack_14 = pppppiStack_34;
    if ((int *******)ppppppiStack_24 != (int *******)0x0) {
      if (iStack_30 != 0) {
        pppppppiVar12 = (int *******)ppppppiStack_24[(int)pppppiStack_34];
        do {
          ppppppiVar17[(int)pppppiStack_14] = (int *****)*pppppppiVar12;
          pppppiStack_16c = (int *****)0x63915d;
          FUN_006375f0();
          pppppiStack_16c = (int *****)0x68;
          ppppppiStack_174 = (int ******)0x639165;
          ppppppiStack_170 = (int ******)pppppppiVar12;
          FUN_01674ea0();
          iStack_30 = iStack_30 + -1;
          pppppppiVar12 = (int *******)ppppppiVar17[(int)pppppiStack_14];
        } while (pppppppiVar12 != (int *******)0x0);
      }
      pppppiStack_16c = (int *****)((int)pppppiStack_34 * 4 + 4);
      pppppppiVar12 = (int *******)ppppppiStack_24;
      if (0xfff < pppppiStack_16c) {
        pppppppiVar12 = (int *******)ppppppiStack_24[-1];
        pppppiStack_16c = (int *****)((int)pppppiStack_34 * 4 + 0x27);
        if ((undefined *)0x1f < (undefined *)((int)ppppppiStack_24 + (-4 - (int)pppppppiVar12))) {
LAB_006392e7:
                    /* WARNING: Subroutine does not return */
          pppppiStack_16c = (int *****)0x6392ec;
          FUN_017167a3();
        }
      }
      ppppppiStack_174 = (int ******)0x6391a7;
      ppppppiStack_170 = (int ******)pppppppiVar12;
      FUN_01674ea0();
      iVar7 = iStack_20;
    }
  }
  else {
    pppppiStack_16c = (int *****)0x638a49;
    cVar6 = FUN_00b74e80();
    if (cVar6 == '\0') {
      pppppiStack_16c = (int *****)0x1e;
      ppppppiStack_170 = (int ******)0x18ceeb0;
      uStack_28 = 0;
      ppppppiStack_24 = (int ******)&DAT_0000000f;
      auStack_38[0] = 0;
      ppppppiStack_174 = (int ******)0x638ad5;
      FUN_005542c0();
      pppppiStack_16c = (int *****)auStack_38;
      uStack_8._0_1_ = 4;
      ppppppiStack_170 = (int ******)0x638ae2;
      FUN_009cbbb0();
      ppppppiStack_170 = (int ******)auStack_38;
      uStack_8._0_1_ = 5;
      ppppppiStack_174 = (int ******)auStack_7c;
      ppppppiStack_178 = (int ******)0x638af3;
      FUN_008cb670();
      pppppiStack_16c = (int *****)0x638afe;
      FUN_005507b0();
      pppppiStack_16c = (int *****)iStack_18;
      ppppppiStack_170 = (int ******)&iStack_64;
      uStack_8._0_1_ = 6;
      ppppppiStack_174 = (int ******)auStack_7c;
      uStack_a4 = 0;
      uStack_a0 = 0;
      piStack_9c = (int *)0x0;
      ppppppiStack_178 = (int ******)0x638b36;
      FUN_00604490();
      pppppiStack_16c = (int *****)auStack_f8;
      uStack_8._0_1_ = 7;
      ppppppiStack_170 = (int ******)&uStack_a4;
      ppppppiStack_174 = (int ******)0x638b4d;
      FUN_0063bb90();
      pppppiStack_16c = (int *****)0x638b5b;
      FUN_00577a40();
      pppppiStack_16c = (int *****)FUN_005507b0;
      ppppppiStack_170 = (int ******)0x1;
      ppppppiStack_174 = (int ******)0x18;
      ppppppiStack_178 = (int ******)auStack_7c;
      uStack_8._0_1_ = 3;
      FUN_016f32d1();
    }
    else {
      pppppiStack_16c = (int *****)0x638a55;
      iVar7 = FUN_008fbd40();
      if (iVar7 == 0) {
        pppppiStack_16c = (int *****)0x638a5e;
        cVar6 = FUN_00baac40();
        if (cVar6 != '\0') {
          ppppppiStack_174 = *(int *******)(param_1 + 0xc);
          if (piStack_60 != (int *)0x0) {
            LOCK();
            piStack_60[1] = piStack_60[1] + 1;
            UNLOCK();
          }
          ppppppiStack_170 = (int ******)iStack_64;
          pppppiStack_16c = (int *****)piStack_60;
          ppppppiStack_178 = (int ******)0x638a95;
          FUN_0063cd40();
          goto LAB_00638b71;
        }
      }
      pppppiStack_16c = (int *****)auStack_f8;
      ppppppiStack_170 = (int ******)0x638aa6;
      ppppppiStack_170 = (int ******)FUN_00b74d10();
      ppppppiStack_174 = (int ******)0x638aac;
      FUN_0063bb90();
    }
LAB_00638b71:
    pppppiStack_16c = (int *****)0x638b76;
    cVar6 = FUN_00baac40();
    if (cVar6 != '\0') {
      pppppiStack_16c = (int *****)0x638b83;
      cVar6 = FUN_00b74e70();
      if (cVar6 != '\0') {
        pppppiStack_16c = (int *****)0x638b90;
        pppppiStack_16c = (int *****)FUN_00b74de0();
        ppppppiStack_170 = (int ******)auStack_c8;
        ppppppiStack_174 = (int ******)0x638b9d;
        pppppiStack_16c = (int *****)FUN_0151a8d0();
        uStack_8._0_1_ = 8;
        ppppppiStack_170 = (int ******)0x638bad;
        FUN_0054f050();
        uStack_8._0_1_ = 10;
        pppppiStack_16c = (int *****)0x638bbc;
        FUN_00550800();
        pppppiStack_16c = (int *****)0x638bc4;
        iVar7 = FUN_008fbd40();
        if (iVar7 == 0) {
          iVar10 = *(int *)(param_1 + 0xc);
          iVar7 = iVar10 + 0xc;
          pppppiStack_16c = (int *****)0x638bd5;
          pppppiStack_14 = (int *****)FUN_00634520();
          if (iVar10 == 0) {
            iVar7 = 0;
          }
          ppppppiStack_170 = (int ******)0x638be5;
          pppppiStack_16c = (int *****)iVar7;
          iVar10 = FUN_00635950();
          if (iVar10 != 0) {
            pppppiStack_16c = (int *****)0x1;
            ppppppiStack_170 = (int ******)0x0;
            FUN_0060dcd0(&ppppppiStack_178,pppppiStack_14);
            iVar7 = iStack_20;
            FUN_00638610(iVar10,auStack_7c);
            uStack_8._0_1_ = 3;
            pppppiStack_16c = (int *****)0x638c1e;
            FUN_00550800();
            goto LAB_006391ad;
          }
        }
        else {
          pppppiStack_16c = (int *****)auStack_38;
          ppppppiStack_170 = (int ******)0x638c2f;
          ppppppiStack_174 = (int ******)FUN_005569d0();
          pppppiStack_16c = (int *****)auStack_e0;
          uStack_8._0_1_ = 0xb;
          ppppppiStack_170 = (int ******)auStack_7c;
          ppppppiStack_178 = (int ******)0x638c44;
          FUN_0063acc0();
          pppppiStack_16c = (int *****)0x638c4f;
          FUN_005507b0();
        }
        iVar7 = iStack_20;
        uStack_8._0_1_ = 3;
        pppppiStack_16c = (int *****)0x638c5e;
        FUN_00550800();
        goto LAB_006391ad;
      }
    }
    pppppiStack_16c = (int *****)(DAT_01d5a328 + 0xb);
    uStack_8._0_1_ = 0xc;
    uStack_28 = 0;
    ppppppiStack_24 = (int ******)&DAT_0000000f;
    auStack_38[0] = 0;
    pppppiStack_14 = (int *****)0x1;
    ppppppiStack_170 = (int ******)0x638c91;
    FUN_0058a190();
    pppppiStack_16c = (int *****)0xb;
    ppppppiStack_170 = (int ******)0x18ceb4c;
    ppppppiStack_174 = (int ******)0x638ca0;
    FUN_00554150();
    pppppiStack_16c = (int *****)DAT_01d5a328;
    ppppppiStack_170 = (int ******)&DAT_01d5a318;
    if (0xf < DAT_01d5a32c) {
      ppppppiStack_170 = (int ******)DAT_01d5a318;
    }
    ppppppiStack_174 = (int ******)0x638cc2;
    FUN_00554150();
    pppppiStack_16c = (int *****)auStack_38;
    ppppppiStack_170 = (int ******)0x638cce;
    FUN_0054ef60();
    pppppiStack_16c = (int *****)auStack_7c;
    uStack_8._0_1_ = 0xd;
    ppppppiStack_170 = (int ******)0x638cdb;
    FUN_009cbbb0();
    ppppppiStack_170 = (int ******)auStack_7c;
    uStack_8._0_1_ = 0xe;
    ppppppiStack_174 = (int ******)auStack_b0;
    ppppppiStack_178 = (int ******)0x638cef;
    ppppppiStack_178 = (int ******)FUN_008cb670();
    uStack_8._0_1_ = 0xf;
    pppppiStack_16c = (int *****)FUN_0151a8d0(&ppppppiStack_54);
    uStack_8._0_1_ = 0x10;
    ppppppiStack_170 = (int ******)0x638d10;
    FUN_0054f050();
    pppppiStack_16c = (int *****)0x638d18;
    FUN_00550800();
    pppppiStack_16c = (int *****)0x638d23;
    FUN_005507b0();
    pppppiStack_16c = (int *****)0x638d2b;
    FUN_005507b0();
    uStack_8._0_1_ = 0x15;
    pppppiStack_16c = (int *****)0x638d37;
    FUN_005507b0();
    pppppiStack_16c = (int *****)auStack_38;
    ppppppiStack_170 = (int ******)0x638d46;
    ppppppiStack_174 = (int ******)FUN_005569d0();
    pppppiStack_16c = (int *****)auStack_e0;
    uStack_8._0_1_ = 0x16;
    ppppppiStack_170 = (int ******)auStack_c8;
    ppppppiStack_178 = (int ******)0x638d5e;
    FUN_0063acc0();
    pppppiStack_16c = (int *****)0x638d69;
    FUN_005507b0();
    uStack_8._0_1_ = 3;
    pppppiStack_16c = (int *****)0x638d78;
    FUN_00550800();
    iVar7 = iStack_20;
  }
LAB_006391ad:
  if ((-(uint)(*(int *)(iVar7 + 0xc) != 0) & *(int *)(iVar7 + 0xc) + 0xcU) == 0) {
    pppppiStack_16c = (int *****)0x0;
  }
  else {
    pppppiStack_16c = (int *****)0x6391c0;
    pppppiStack_16c = (int *****)FUN_00634520();
  }
  ppppppiStack_170 = (int ******)&uStack_a0;
  ppppppiStack_174 = (int ******)0x6391d1;
  puVar13 = (undefined4 *)FUN_0060dcd0();
  uStack_8._0_1_ = 0x27;
  ppppppiStack_170 = (int ******)*puVar13;
  pppppiStack_16c = (int *****)puVar13[1];
  ppppppiStack_174 = (int ******)auStack_e0;
  *puVar13 = 0;
  puVar13[1] = 0;
  ppppppiStack_178 = (int ******)0x639209;
  FUN_0063b3f0();
  piVar3 = piStack_9c;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (piStack_9c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_9c[1] + -1;
    piStack_9c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      pppppiStack_16c = (int *****)0x63922c;
      (**(code **)*piStack_9c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        pppppiStack_16c = (int *****)0x63923c;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    piStack_58[1] = piStack_58[1] + 1;
    UNLOCK();
  }
  ppppppiStack_170 = (int ******)piStack_5c;
  pppppiStack_16c = (int *****)piStack_58;
  ppppppiStack_174 = (int ******)auStack_f8;
  ppppppiStack_178 = (int ******)0x639270;
  FUN_0063b3f0();
  pppppiStack_16c = (int *****)0x63927e;
  FUN_00637710();
  pppppiStack_16c = (int *****)0x639289;
  uVar8 = FUN_00637710();
  if (piStack_58 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piStack_58 + 1);
    uVar4 = *puVar2;
    uVar8 = *puVar2;
    *puVar2 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      pppppiStack_16c = (int *****)0x63929f;
      (**(code **)*piStack_58)();
      LOCK();
      puVar2 = (uint *)(piStack_58 + 2);
      uVar4 = *puVar2;
      uVar8 = *puVar2;
      *puVar2 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        pppppiStack_16c = (int *****)0x6392af;
        uVar8 = (**(code **)(*piStack_58 + 4))();
      }
    }
  }
LAB_006392af:
  if (piStack_60 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piStack_60 + 1);
    uVar4 = *puVar2;
    uVar8 = *puVar2;
    *puVar2 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      pppppiStack_16c = (int *****)0x6392c8;
      uVar8 = (**(code **)*piStack_60)();
      LOCK();
      piVar3 = piStack_60 + 2;
      iVar7 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        pppppiStack_16c = (int *****)0x6392d7;
        uVar8 = (**(code **)(*piStack_60 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 7113 ; VA 0x006392f2 ; FUN_006392f2 */

void FUN_006392f2(void)

{
  FUN_00639300();
  return;
}



/* FUNCTION 7114 ; VA 0x00639300 ; FUN_00639300 */

int __fastcall FUN_00639300(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179fcab;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[10] = &DAT_018cf050;
    puVar3[0xc] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x2c,puVar3 + 1);
    *puVar3 = boost::bad_lexical_cast::vftable;
    puVar3[3] = *(undefined4 *)(param_1 + -0x24);
    puVar3[4] = *(undefined4 *)(param_1 + -0x20);
    puVar1 = puVar3 + 5;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[6] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[7] = *(undefined4 *)(param_1 + -0x14);
    puVar3[8] = *(undefined4 *)(param_1 + -0x10);
    puVar3[9] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_lexical_cast>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[10] + 4) + 0x24 + (int)puVar3) = *(int *)(puVar3[10] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 7115 ; VA 0x00639430 ; FUN_00639430 */

void __thiscall FUN_00639430(undefined4 *param_1,uint param_2,uint param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  code *pcVar2;
  uint uVar3;
  
  if (param_2 <= (uint)param_1[4]) {
    puVar1 = param_4 + 4;
    if (0xf < (uint)param_4[5]) {
      param_4 = (undefined4 *)*param_4;
    }
    uVar3 = param_1[4] - param_2;
    if (uVar3 < param_3) {
      param_3 = uVar3;
    }
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    FUN_0055c2d0((int)param_1 + param_2,param_3,param_4,*puVar1);
    return;
  }
  FUN_00554050();
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}



/* FUNCTION 7116 ; VA 0x00639480 ; FUN_00639480 */

void __thiscall FUN_00639480(undefined4 *param_1,char *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  char *pcVar3;
  
  pcVar3 = param_2;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_0055c2d0(param_1,*puVar1,param_2,(int)pcVar3 - (int)(param_2 + 1));
  return;
}



/* FUNCTION 7117 ; VA 0x006394c0 ; FUN_006394c0 */

void __fastcall FUN_006394c0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined uVar6;
  char cVar7;
  undefined **ppuVar8;
  undefined4 uVar9;
  undefined4 ***pppuVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined **ppuVar13;
  uint uVar14;
  uint uVar15;
  undefined4 ***pppuVar16;
  undefined auStack_f4 [24];
  undefined auStack_dc [24];
  undefined auStack_c4 [4];
  undefined *puStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined auStack_ac [4];
  undefined *puStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  uint auStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  undefined4 uStack_7c;
  int iStack_6c;
  uint uStack_68;
  undefined4 **appuStack_64 [4];
  int iStack_54;
  uint uStack_50;
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined uStack_15;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179fdb3;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if ((-(uint)(*(int *)(param_1 + 0xc) != 0) & *(int *)(param_1 + 0xc) + 0xcU) == 0) {
    uStack_34 = 0;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    uStack_34 = FUN_00634520();
  }
  auStack_c4[0] = 0;
  uStack_14 = 0xb;
  ppuVar8 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar13 = ppuVar8 + -1;
  if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar13 = ppuVar8;
  }
  puStack_c0 = *ppuVar13;
  uStack_bc = 0;
  uStack_b8 = 0x3f800000;
  uStack_b4 = 0;
  uStack_b0 = 0;
  uStack_8 = 0;
  cVar7 = FUN_00554b40();
  if (cVar7 == '\0') {
    FUN_0086f2f0(3,"compileLuaPackages cannot compile scripts");
  }
  else {
    iStack_54 = 0;
    uStack_50 = 7;
    appuStack_64[0] = (undefined4 **)((uint)appuStack_64[0] & 0xffff0000);
    uStack_8._0_1_ = 1;
    cVar7 = FUN_00baac40();
    if ((cVar7 == '\0') || (cVar7 = FUN_00b74e70(), cVar7 == '\0')) {
      uStack_8._0_1_ = 3;
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = auStack_30[0] & 0xffffff00;
      uStack_14 = 1;
      FUN_0058a190(DAT_01d5a328 + 0xb);
      FUN_00554150("rbxasset://",0xb);
      puVar11 = &DAT_01d5a318;
      if (0xf < DAT_01d5a32c) {
        puVar11 = DAT_01d5a318;
      }
      FUN_00554150(puVar11,DAT_01d5a328);
      FUN_0054ef60(auStack_30);
      uStack_8._0_1_ = 4;
      FUN_009cbbb0(auStack_94);
      uStack_8._0_1_ = 5;
      uVar9 = FUN_008cb670(auStack_f4,auStack_94);
      uStack_8._0_1_ = 6;
      pppuVar10 = (undefined4 ***)FUN_0151a8d0(auStack_dc,uVar9);
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      if (appuStack_64 != pppuVar10) {
        pppuVar16 = pppuVar10 + 4;
        if ((undefined4 **)0x7 < pppuVar10[5]) {
          pppuVar10 = (undefined4 ***)*pppuVar10;
        }
        FUN_0058ed10(pppuVar10,*pppuVar16);
      }
      FUN_00550800();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
    }
    else {
      uVar9 = FUN_00b74de0();
      pppuVar10 = (undefined4 ***)FUN_0151a8d0(auStack_94,uVar9);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (appuStack_64 != pppuVar10) {
        pppuVar16 = pppuVar10 + 4;
        if ((undefined4 **)0x7 < pppuVar10[5]) {
          pppuVar10 = (undefined4 ***)*pppuVar10;
        }
        FUN_0058ed10(pppuVar10,*pppuVar16);
      }
      FUN_00550800();
    }
    uStack_8._0_1_ = 8;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    uStack_14 = 2;
    if (iStack_54 != 0) {
      pppuVar10 = appuStack_64;
      if (7 < uStack_50) {
        pppuVar10 = (undefined4 ***)appuStack_64[0];
      }
      iVar3 = iStack_54 * 2;
      pppuVar16 = appuStack_64;
      if (7 < uStack_50) {
        pppuVar16 = (undefined4 ***)appuStack_64[0];
      }
      uVar9 = FUN_01686580();
      FUN_01685a20(pppuVar16,(int)pppuVar10 + iVar3,auStack_30,uVar9);
    }
    FUN_0063acc0(auStack_30,appuStack_64,auStack_c4);
    uStack_8._0_1_ = 1;
    uVar6 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_1c) {
      uVar14 = uStack_1c + 1;
      uVar15 = auStack_30[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_30[0] - 4);
        uVar14 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar15) - 4) {
          uStack_8._0_1_ = uVar6;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar14);
    }
    FUN_00634770(&piStack_3c);
    uStack_8._0_1_ = 9;
    FUN_00634770(&piStack_44);
    uStack_8._0_1_ = 10;
    FUN_00634770(&piStack_4c);
    uStack_8._0_1_ = 0xb;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    pcVar4 = *(code **)(*piStack_3c + 0x38);
    FUN_005542c0("modules",7);
    uStack_8._0_1_ = 0xc;
    (*pcVar4)(auStack_30);
    uStack_8._0_1_ = 0xb;
    uVar6 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xb;
    if (0xf < uStack_1c) {
      uVar14 = uStack_1c + 1;
      uVar15 = auStack_30[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_30[0] - 4);
        uVar14 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar15) - 4) {
          uStack_8._0_1_ = uVar6;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar14);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    pcVar4 = *(code **)(*piStack_44 + 0x38);
    FUN_005542c0(&DAT_018ceed0,3);
    uStack_8._0_1_ = 0xd;
    (*pcVar4)(auStack_30);
    uStack_8._0_1_ = 0xb;
    uVar6 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xb;
    if (0xf < uStack_1c) {
      uVar14 = uStack_1c + 1;
      uVar15 = auStack_30[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_30[0] - 4);
        uVar14 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar15) - 4) {
          uStack_8._0_1_ = uVar6;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar14);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    pcVar4 = *(code **)(*piStack_4c + 0x38);
    FUN_005542c0("hidden",6);
    uStack_8._0_1_ = 0xe;
    (*pcVar4)(auStack_30);
    uStack_8._0_1_ = 0xb;
    uVar6 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xb;
    if (0xf < uStack_1c) {
      uVar14 = uStack_1c + 1;
      uVar15 = auStack_30[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_30[0] - 4);
        uVar14 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar15) - 4) {
          uStack_8._0_1_ = uVar6;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar14);
    }
    FUN_008a65e0(piStack_44,0);
    FUN_008a65e0(piStack_4c,0);
    FUN_008a65e0(uStack_34,0);
    auStack_ac[0] = 0;
    uStack_14 = 0xb;
    ppuVar8 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
    ppuVar13 = ppuVar8 + -1;
    if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar13 = ppuVar8;
    }
    puStack_a8 = *ppuVar13;
    uStack_a4 = 0;
    uStack_a0 = 0x3f800000;
    uStack_9c = 0;
    uStack_98 = 0;
    uStack_8._0_1_ = 0xf;
    uVar9 = FUN_008c8420(&DAT_01d5a330);
    puVar11 = (undefined4 *)FUN_005f3cd0(auStack_94,uVar9);
    uStack_68 = 7;
    iStack_6c = 0;
    uStack_7c = (undefined4 *)((uint)uStack_7c._2_2_ << 0x10);
    iVar3 = puVar11[4];
    uStack_8._0_1_ = 0x11;
    if (iVar3 != 0) {
      puVar12 = puVar11;
      if (0xf < (uint)puVar11[5]) {
        puVar12 = (undefined4 *)*puVar11;
      }
      if (0xf < (uint)puVar11[5]) {
        puVar11 = (undefined4 *)*puVar11;
      }
      uVar9 = FUN_01686580();
      FUN_01685950(puVar11,iVar3 + (int)puVar12,&uStack_7c,uVar9);
    }
    uStack_8._0_1_ = 0x13;
    uVar6 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x13;
    if (0xf < uStack_80) {
      uVar15 = uStack_80 + 1;
      uVar14 = auStack_94[0];
      if (0xfff < uVar15) {
        uVar14 = *(uint *)(auStack_94[0] - 4);
        uVar15 = uStack_80 + 0x24;
        if (0x1f < (auStack_94[0] - uVar14) - 4) {
          uStack_8._0_1_ = uVar6;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar14,uVar15);
    }
    uStack_84 = 0;
    uStack_80 = 0xf;
    auStack_94[0] = auStack_94[0] & 0xffffff00;
    uStack_8._0_1_ = 0x14;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    uStack_14 = 4;
    if (iStack_6c != 0) {
      puVar11 = &uStack_7c;
      if (7 < uStack_68) {
        puVar11 = uStack_7c;
      }
      iVar3 = iStack_6c * 2;
      uVar9 = FUN_01686580();
      FUN_01685a20(puVar11,(int)puVar11 + iVar3,auStack_30,uVar9);
    }
    FUN_0063acc0(auStack_30,&uStack_7c,auStack_ac);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
    if (0xf < uStack_1c) {
      uVar14 = uStack_1c + 1;
      uVar15 = auStack_30[0];
      if (0xfff < uVar14) {
        uVar15 = *(uint *)(auStack_30[0] - 4);
        uVar14 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar14);
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      piStack_38[1] = piStack_38[1] + 1;
      UNLOCK();
    }
    FUN_0063b3f0(auStack_ac,piStack_3c,piStack_38);
    if (DAT_01d5a310 != '\0') {
      uStack_15 = 0;
      FUN_00636e10(&uStack_15);
    }
    FUN_00550800();
    FUN_00637710();
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_48[1] + -1;
      piStack_48[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_48)();
        LOCK();
        iVar3 = piStack_48[2] + -1;
        piStack_48[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_48 + 4))();
        }
      }
    }
    piVar2 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_40[1] + -1;
      piStack_40[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_38[1] + -1;
      piStack_38[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        iVar3 = piStack_38[2] + -1;
        piStack_38[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_00550800();
  }
  puVar11 = (undefined4 *)FUN_0060dcd0(&piStack_44,uStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  uVar9 = *puVar11;
  uVar5 = puVar11[1];
  *puVar11 = 0;
  puVar11[1] = 0;
  FUN_0063b3f0(auStack_c4,uVar9,uVar5);
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_40[1] + -1;
    piStack_40[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      piVar2 = piStack_40 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
  }
  FUN_00637710();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7118 ; VA 0x00639c70 ; FUN_00639c70 */

undefined4 * FUN_00639c70(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  char cVar4;
  undefined **ppuVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 ****ppppuVar8;
  undefined4 *puVar9;
  undefined **ppuVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  undefined4 ****ppppuVar14;
  int in_stack_00000018;
  uint in_stack_0000001c;
  int in_stack_00000020;
  uint in_stack_00000034;
  undefined auStack_d4 [24];
  undefined auStack_bc [24];
  int aiStack_a4 [5];
  uint uStack_90;
  undefined auStack_8c [4];
  int iStack_88;
  undefined auStack_84 [4];
  undefined *puStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 ***apppuStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined auStack_54 [4];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 ***apppuStack_48 [4];
  int iStack_38;
  uint uStack_34;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179fe69;
  pvStack_10 = ExceptionList;
  uStack_4c = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00634770(&piStack_18);
  uStack_8._0_1_ = 2;
  (**(code **)(*piStack_18 + 0x38))(&stack0x00000020);
  auStack_84[0] = 0;
  uStack_50 = 0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_50);
  ppuVar10 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar10 = ppuVar5;
  }
  puStack_80 = *ppuVar10;
  uStack_7c = 0;
  uStack_78 = 0x3f800000;
  uStack_74 = 0;
  uStack_70 = 0;
  uStack_8._0_1_ = 3;
  cVar4 = FUN_00554b40();
  if (cVar4 == '\0') {
    FUN_0086f2f0(3,"compileModuleFolderFromPath cannot compile scripts");
    piVar6 = piStack_18;
    piStack_18 = (int *)0x0;
    *param_1 = piVar6;
    param_1[1] = piStack_14;
    piStack_14 = (int *)0x0;
    FUN_00637710();
    piVar6 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar13 = piStack_14[1] + -1;
      piStack_14[1] = iVar13;
      UNLOCK();
      if (iVar13 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar13 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar13 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (in_stack_0000001c < 0x10) goto LAB_0063a17a;
    uVar12 = in_stack_0000001c + 1;
    puVar9 = param_2;
    if (0xfff < uVar12) {
      puVar9 = (undefined4 *)param_2[-1];
      uVar12 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    iStack_38 = 0;
    uStack_34 = 7;
    apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffff0000);
    uStack_8._0_1_ = 4;
    cVar4 = FUN_00b74e80();
    if (cVar4 == '\0') {
      uStack_8._0_1_ = 8;
      uStack_20 = 0;
      uStack_1c = 0xf;
      apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
      uStack_4c = 4;
      FUN_0058a190(in_stack_00000018 + 0x1e);
      FUN_00554150("rbxasset://scripts/CoreScripts",0x1e);
      puVar9 = &param_2;
      if (0xf < in_stack_0000001c) {
        puVar9 = param_2;
      }
      FUN_00554150(puVar9,in_stack_00000018);
      FUN_0054ef60(apppuStack_30);
      uStack_8._0_1_ = 9;
      FUN_009cbbb0(aiStack_a4);
      uStack_8._0_1_ = 10;
      uVar7 = FUN_008cb670(auStack_d4,aiStack_a4);
      uStack_8._0_1_ = 0xb;
      uVar7 = FUN_0151a8d0(auStack_bc,uVar7);
      uStack_8._0_1_ = 0xc;
      FUN_0054f050(uVar7);
      ppppuVar8 = apppuStack_6c;
      if (7 < uStack_58) {
        ppppuVar8 = (undefined4 ****)apppuStack_6c[0];
      }
      uStack_8._0_1_ = 0xd;
      FUN_0058ed10(ppppuVar8,uStack_5c);
      FUN_00550800();
      FUN_00550800();
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 4;
      FUN_005507b0();
    }
    else {
      piVar6 = (int *)FUN_00b74d10();
      iVar2 = piVar6[1];
      for (iVar13 = *piVar6; iVar13 != iVar2; iVar13 = iVar13 + 0x18) {
        FUN_005f3cd0(apppuStack_6c,iVar13,&param_2);
        uStack_8._0_1_ = 5;
        uVar7 = FUN_0151a8d0(aiStack_a4,apppuStack_6c);
        uStack_8._0_1_ = 6;
        FUN_0054f050(uVar7);
        ppppuVar8 = apppuStack_30;
        if (7 < uStack_1c) {
          ppppuVar8 = (undefined4 ****)apppuStack_30[0];
        }
        uStack_8._0_1_ = 7;
        FUN_0058ed10(ppppuVar8,uStack_20);
        uStack_8._0_1_ = 6;
        if (7 < uStack_1c) {
          uVar12 = uStack_1c * 2 + 2;
          ppppuVar8 = (undefined4 ****)apppuStack_30[0];
          if (0xfff < uVar12) {
            ppppuVar8 = (undefined4 ****)apppuStack_30[0][-1];
            uVar12 = uStack_1c * 2 + 0x25;
            if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar8))) goto LAB_0063a35c;
          }
          FUN_01674ea0(ppppuVar8,uVar12);
        }
        uStack_8._0_1_ = 5;
        if (7 < uStack_90) {
          uVar12 = uStack_90 * 2 + 2;
          iVar11 = aiStack_a4[0];
          if (0xfff < uVar12) {
            iVar11 = *(int *)(aiStack_a4[0] + -4);
            uVar12 = uStack_90 * 2 + 0x25;
            if (0x1f < (aiStack_a4[0] - iVar11) - 4U) goto LAB_0063a35c;
          }
          FUN_01674ea0(iVar11,uVar12);
        }
        piVar6 = (int *)FUN_0168e1c0(auStack_54,apppuStack_48,0);
        iStack_88 = piVar6[1];
        if ((*piVar6 != 0) && (*piVar6 != 1)) {
          uStack_8._0_1_ = 4;
          if (0xf < uStack_58) {
            uVar12 = uStack_58 + 1;
            ppppuVar8 = (undefined4 ****)apppuStack_6c[0];
            if (0xfff < uVar12) {
              ppppuVar8 = (undefined4 ****)apppuStack_6c[0][-1];
              uVar12 = uStack_58 + 0x24;
              if (0x1f < (uint)((int)apppuStack_6c[0] + (-4 - (int)ppppuVar8))) {
LAB_0063a35c:
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(ppppuVar8,uVar12);
          }
          break;
        }
        uStack_8._0_1_ = 4;
        if (0xf < uStack_58) {
          uVar12 = uStack_58 + 1;
          ppppuVar8 = (undefined4 ****)apppuStack_6c[0];
          if (0xfff < uVar12) {
            ppppuVar8 = (undefined4 ****)apppuStack_6c[0][-1];
            uVar12 = uStack_58 + 0x24;
            if (0x1f < (uint)((int)apppuStack_6c[0] + (-4 - (int)ppppuVar8))) goto LAB_0063a35c;
          }
          FUN_01674ea0(ppppuVar8,uVar12);
        }
      }
    }
    piVar6 = (int *)FUN_0168e1c0(auStack_8c,apppuStack_48,0);
    if ((*piVar6 == 0) || (*piVar6 == 1)) {
      puVar9 = &param_2;
      if (0xf < in_stack_0000001c) {
        puVar9 = param_2;
      }
      FUN_0086f2f0(3,"Cannot find folder (%s).",puVar9);
      piVar6 = piStack_18;
      piStack_18 = (int *)0x0;
      *param_1 = piVar6;
      param_1[1] = piStack_14;
      piStack_14 = (int *)0x0;
      if (7 < uStack_34) {
        uVar12 = uStack_34 * 2 + 2;
        ppppuVar8 = (undefined4 ****)apppuStack_48[0];
        if (0xfff < uVar12) {
          ppppuVar8 = (undefined4 ****)apppuStack_48[0][-1];
          uVar12 = uStack_34 * 2 + 0x25;
          if (0x1f < (uint)((int)apppuStack_48[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar8,uVar12);
      }
      iStack_38 = 0;
      uStack_34 = 7;
      apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffff0000);
      FUN_00637710();
      piVar6 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar13 = piStack_14[1] + -1;
        piStack_14[1] = iVar13;
        UNLOCK();
        if (iVar13 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar13 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar13 == 1) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (in_stack_0000001c < 0x10) goto LAB_0063a17a;
      uVar12 = in_stack_0000001c + 1;
      puVar9 = param_2;
      if (0xfff < uVar12) {
        puVar9 = (undefined4 *)param_2[-1];
        uVar12 = in_stack_0000001c + 0x24;
        if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
    }
    else {
      uStack_8._0_1_ = 0xe;
      uStack_20 = 0;
      uStack_1c = 0xf;
      apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
      uStack_4c = 8;
      if (iStack_38 != 0) {
        ppppuVar8 = apppuStack_48;
        if (7 < uStack_34) {
          ppppuVar8 = (undefined4 ****)apppuStack_48[0];
        }
        iVar13 = iStack_38 * 2;
        ppppuVar14 = apppuStack_48;
        if (7 < uStack_34) {
          ppppuVar14 = (undefined4 ****)apppuStack_48[0];
        }
        uVar7 = FUN_01686580();
        FUN_01685a20(ppppuVar14,(int)ppppuVar8 + iVar13,apppuStack_30,uVar7);
      }
      FUN_0063acc0(apppuStack_30,apppuStack_48,auStack_84);
      uStack_8._0_1_ = 4;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 4;
      if (0xf < uStack_1c) {
        uVar12 = uStack_1c + 1;
        ppppuVar8 = (undefined4 ****)apppuStack_30[0];
        if (0xfff < uVar12) {
          ppppuVar8 = (undefined4 ****)apppuStack_30[0][-1];
          uVar12 = uStack_1c + 0x24;
          if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar8))) {
            uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar8,uVar12);
      }
      uStack_8._0_1_ = 3;
      if (7 < uStack_34) {
        uVar12 = uStack_34 * 2 + 2;
        ppppuVar8 = (undefined4 ****)apppuStack_48[0];
        if (0xfff < uVar12) {
          ppppuVar8 = (undefined4 ****)apppuStack_48[0][-1];
          uVar12 = uStack_34 * 2 + 0x25;
          if (0x1f < (uint)((int)apppuStack_48[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar8,uVar12);
      }
      if (piStack_14 != (int *)0x0) {
        LOCK();
        *(int *)((int)piStack_14 + 4) = *(int *)((int)piStack_14 + 4) + 1;
        UNLOCK();
      }
      FUN_0063b3f0(auStack_84,piStack_18,piStack_14);
      piVar6 = piStack_18;
      piStack_18 = (int *)0x0;
      *param_1 = piVar6;
      param_1[1] = piStack_14;
      piStack_14 = (int *)0x0;
      FUN_00637710();
      piVar6 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar13 = piStack_14[1] + -1;
        piStack_14[1] = iVar13;
        UNLOCK();
        if (iVar13 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar13 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar13 == 1) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (in_stack_0000001c < 0x10) goto LAB_0063a17a;
      uVar12 = in_stack_0000001c + 1;
      puVar9 = param_2;
      if (0xfff < uVar12) {
        uVar12 = in_stack_0000001c + 0x24;
        puVar9 = (undefined4 *)param_2[-1];
        if (0x1f < (uint)((int)param_2 + (-4 - (int)param_2[-1]))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
    }
  }
  FUN_01674ea0(puVar9,uVar12);
LAB_0063a17a:
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  if (0xf < in_stack_00000034) {
    uVar12 = in_stack_00000034 + 1;
    iVar13 = in_stack_00000020;
    if (0xfff < uVar12) {
      iVar13 = *(int *)(in_stack_00000020 + -4);
      uVar12 = in_stack_00000034 + 0x24;
      if (0x1f < (in_stack_00000020 - iVar13) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar13,uVar12);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7119 ; VA 0x0063a390 ; FUN_0063a390 */

void __thiscall FUN_0063a390(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  *(undefined4 *)(param_1 + 0xc) = param_3;
  FUN_0063c890(param_4);
  FUN_00634b40();
  FUN_0063be30();
  return;
}



/* FUNCTION 7120 ; VA 0x0063a3c0 ; FUN_0063a3c0 */

uint __fastcall FUN_0063a3c0(uint *param_1)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  uint uVar4;
  int *piVar5;
  char ****ppppcVar6;
  undefined4 *puVar7;
  uint uVar8;
  char ***apppcStack_3c [4];
  uint uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  char cStack_12;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179fe90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_016de181(1);
  uStack_8 = 1;
  piStack_20 = piVar2;
  uVar3 = FUN_016de368();
  cVar1 = FUN_00637e00(uVar3);
  if (cVar1 != '\0') {
    uVar4 = FUN_0063c710();
    goto LAB_0063a53e;
  }
  piVar5 = (int *)FUN_00564bf0(auStack_24);
  (**(code **)(*piVar5 + 0x14))(apppcStack_3c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_18 = uStack_2c;
  if (uStack_2c == 0) {
LAB_0063a4ee:
    uVar4 = FUN_0063c710();
  }
  else {
    ppppcVar6 = apppcStack_3c;
    if (0xf < uStack_28) {
      ppppcVar6 = (char ****)apppcStack_3c[0];
    }
    if (*(char *)ppppcVar6 < '\x01') goto LAB_0063a4ee;
    uStack_11 = (**(code **)(*piVar5 + 0x10))();
    uVar4 = 0;
    uStack_1c = 10;
    ppppcVar6 = apppcStack_3c;
    if (0xf < uStack_28) {
      ppppcVar6 = (char ****)apppcStack_3c[0];
    }
    cVar1 = *(char *)ppppcVar6;
    cStack_12 = cVar1;
    do {
      if (cStack_12 == '\0') {
        uVar4 = uVar4 + 1;
        if (uVar4 < uStack_18) {
          ppppcVar6 = apppcStack_3c;
          if (0xf < uStack_28) {
            ppppcVar6 = (char ****)apppcStack_3c[0];
          }
          cVar1 = *(char *)((int)ppppcVar6 + uVar4);
          if (cVar1 < '\x01') {
            cVar1 = '\x7f';
          }
        }
        param_1[1] = param_1[1] - 1;
        *(undefined *)param_1[1] = uStack_11;
        cStack_12 = cVar1;
      }
      param_1[1] = param_1[1] - 1;
      cStack_12 = cStack_12 + -1;
      *(char *)param_1[1] = (char)param_1[3] + (char)(*param_1 % 10);
      uVar8 = *param_1;
      *param_1 = uVar8 / 10;
    } while (uVar8 / 10 != 0);
    uVar4 = param_1[1];
    piVar2 = piStack_20;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    ppppcVar6 = (char ****)apppcStack_3c[0];
    if (0xfff < uVar8) {
      ppppcVar6 = (char ****)apppcStack_3c[0][-1];
      uVar8 = uStack_28 + 0x24;
      if ((char *)0x1f < (char *)((int)apppcStack_3c[0] + (-4 - (int)ppppcVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppcVar6,uVar8);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  apppcStack_3c[0] = (char ***)((uint)apppcStack_3c[0] & 0xffffff00);
LAB_0063a53e:
  uStack_8 = 3;
  if ((piVar2 != (int *)0x0) &&
     (puVar7 = (undefined4 *)(**(code **)(*piVar2 + 8))(), puVar7 != (undefined4 *)0x0)) {
    (**(code **)*puVar7)(1);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 7121 ; VA 0x0063a580 ; FUN_0063a580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0063a580(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = thunk_FUN_0063cc40();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ead624) {
      FUN_016f3809(&DAT_01ead624);
      if (DAT_01ead624 == -1) {
        _DAT_01ead618 = FUN_005c65e0;
        _DAT_01ead61c = FUN_005c65e0;
        _DAT_01ead620 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead624);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01ead618) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01ead618;
  }
  return;
}



/* FUNCTION 7122 ; VA 0x0063a640 ; FUN_0063a640 */

void FUN_0063a640(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_0063cc40();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 7123 ; VA 0x0063a680 ; FUN_0063a680 */

void __fastcall FUN_0063a680(int param_1)

{
  FUN_00634120(*(undefined4 *)(param_1 + 0xc));
  return;
}



/* FUNCTION 7124 ; VA 0x0063a690 ; FUN_0063a690 */

void __thiscall FUN_0063a690(undefined4 *param_1,int *param_2,int param_3,int param_4)

{
  uint uVar1;
  code *pcVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  
  puVar3 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar3 = (undefined4 *)*param_1;
  }
  uVar1 = param_1[4];
  uVar5 = param_3 - (int)puVar3;
  if (uVar5 <= uVar1) {
    uVar4 = param_4 - param_3;
    if (uVar1 - uVar5 < (uint)(param_4 - param_3)) {
      uVar4 = uVar1 - uVar5;
    }
    puVar3 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar3 = (undefined4 *)*param_1;
    }
    param_1[4] = uVar1 - uVar4;
    FUN_0170cc70((int)puVar3 + uVar5,(int)puVar3 + uVar5 + uVar4,((uVar1 - uVar4) - uVar5) + 1);
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    *param_2 = (int)param_1 + uVar5;
    return;
  }
  FUN_00554050();
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}



/* FUNCTION 7125 ; VA 0x0063a700 ; FUN_0063a700 */

undefined4 * FUN_0063a700(undefined4 *param_1,undefined4 param_2,char param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  bool bVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179feb9;
  pvStack_10 = ExceptionList;
  bVar5 = param_3 == '\0';
  uStack_14 = 0;
  if (bVar5) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_008a1240(param_2);
    puVar4 = (undefined4 *)FUN_0060dcd0(auStack_1c,uVar3);
  }
  else {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_008a13b0(param_2);
    puVar4 = (undefined4 *)FUN_0060dcd0(auStack_24,uVar3);
  }
  uVar3 = *puVar4;
  *puVar4 = 0;
  *param_1 = uVar3;
  param_1[1] = puVar4[1];
  puVar4[1] = 0;
  if ((bVar5) && (piStack_18 != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if ((!bVar5) && (piStack_20 != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7126 ; VA 0x0063a800 ; FUN_0063a800 */

undefined4 FUN_0063a800(byte *param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  uint uVar1;
  byte *pbVar2;
  undefined4 *****pppppuVar3;
  char cVar4;
  int *piVar5;
  undefined4 ******ppppppuVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  int iVar10;
  byte *pbVar11;
  int iVar12;
  uint uVar13;
  byte *pbVar14;
  uint uVar15;
  bool bVar16;
  int aiStack_8c [5];
  uint uStack_78;
  int aiStack_74 [5];
  uint uStack_60;
  undefined4 *****apppppuStack_5c [4];
  uint uStack_4c;
  uint uStack_48;
  int iStack_44;
  int iStack_40;
  int aiStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 *****pppppuStack_24;
  int iStack_20;
  int iStack_1c;
  byte *pbStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ff27;
  pvStack_10 = ExceptionList;
  pbVar14 = (byte *)0x0;
  pbStack_18 = (byte *)0x0;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_0168e1c0(&iStack_44,param_2,0);
  iStack_40 = piVar5[1];
  if ((*piVar5 == 0) || (*piVar5 == 1)) {
    ExceptionList = pvStack_10;
    return 0;
  }
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_8 = 0;
  pppppuStack_24 = (undefined4 *****)FUN_01674e20(0x2c);
  if ((undefined4 ******)pppppuStack_24 == (undefined4 ******)0x0) {
    ppppppuVar6 = (undefined4 ******)0x0;
  }
  else {
    ((undefined4 ******)pppppuStack_24)[4] = (undefined4 *****)0x0;
    ((undefined4 ******)pppppuStack_24)[5] = (undefined4 *****)0x7;
    *(undefined2 *)pppppuStack_24 = 0;
    ((undefined4 ******)pppppuStack_24)[6] = (undefined4 *****)0x0;
    ((undefined4 ******)pppppuStack_24)[7] = (undefined4 *****)0xffff;
    ((undefined4 ******)pppppuStack_24)[8] = (undefined4 *****)0x0;
    ((undefined4 ******)pppppuStack_24)[9] = (undefined4 *****)0xffff;
    ((undefined4 ******)pppppuStack_24)[10] = (undefined4 *****)0x0;
    ppppppuVar6 = (undefined4 ******)pppppuStack_24;
  }
  FUN_00632a90(ppppppuVar6);
  uStack_8._0_1_ = 1;
  FUN_0168c2c0(&iStack_2c,param_2,0);
  uStack_8._0_1_ = 2;
  do {
    if (iStack_2c == 0) {
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_28[1] + -1;
        piStack_28[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piStack_28 + 4))();
          LOCK();
          piVar5 = piStack_28 + 2;
          iVar10 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar10 == 1) {
            (**(code **)(*piStack_28 + 8))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return 0;
    }
    FUN_0168d170(aiStack_3c,0);
    if ((aiStack_3c[0] == 3) && (cVar4 = FUN_0063b920(iStack_2c), cVar4 == '\0')) {
      cVar4 = FUN_0063a800(param_1,iStack_2c,param_3,param_4);
      if (cVar4 != '\0') {
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_28[1] + -1;
          piStack_28[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piStack_28 + 4))();
            LOCK();
            piVar5 = piStack_28 + 2;
            iVar10 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar10 == 1) {
              (**(code **)(*piStack_28 + 8))();
            }
          }
        }
        ExceptionList = pvStack_10;
        return 1;
      }
    }
    else {
      FUN_0168d170(&iStack_44,0);
      if (iStack_44 == 2) {
        FUN_0054f050(iStack_2c);
        uStack_8._0_1_ = 4;
        puVar7 = (undefined4 *)FUN_01686b00(aiStack_8c);
        uStack_8._0_1_ = 6;
        uStack_4c = 0;
        pbStack_18 = (byte *)((uint)pbVar14 | 1);
        uStack_48 = 0xf;
        apppppuStack_5c[0] = (undefined4 *****)((uint)apppppuStack_5c[0] & 0xffffff00);
        iVar10 = puVar7[4];
        pbStack_14 = pbStack_18;
        if (iVar10 != 0) {
          puVar8 = puVar7;
          if (7 < (uint)puVar7[5]) {
            puVar8 = (undefined4 *)*puVar7;
          }
          if (7 < (uint)puVar7[5]) {
            puVar7 = (undefined4 *)*puVar7;
          }
          uVar9 = FUN_01686580();
          FUN_01685a20(puVar7,(int)puVar8 + iVar10 * 2,apppppuStack_5c,uVar9);
        }
        uVar13 = uStack_48;
        pppppuVar3 = apppppuStack_5c[0];
        ppppppuVar6 = apppppuStack_5c;
        if (0xf < uStack_48) {
          ppppppuVar6 = (undefined4 ******)apppppuStack_5c[0];
        }
        iVar10 = FUN_0055c2d0(ppppppuVar6,uStack_4c,&DAT_018bf1c0,4);
        pbStack_14 = (byte *)((uint)pbStack_14 & 0xfffffffe);
        uStack_8._0_1_ = 5;
        if (0xf < uVar13) {
          uVar15 = uVar13 + 1;
          ppppppuVar6 = (undefined4 ******)pppppuVar3;
          if (0xfff < uVar15) {
            ppppppuVar6 = (undefined4 ******)pppppuVar3[-1];
            uVar15 = uVar13 + 0x24;
            if (0x1f < (uint)((int)pppppuVar3 + (-4 - (int)ppppppuVar6))) goto LAB_0063acb0;
          }
          FUN_01674ea0(ppppppuVar6,uVar15);
        }
        uStack_4c = 0;
        uStack_48 = 0xf;
        apppppuStack_5c[0] = (undefined4 *****)((uint)apppppuStack_5c[0] & 0xffffff00);
        uStack_8._0_1_ = 4;
        if (7 < uStack_78) {
          uVar13 = uStack_78 * 2 + 2;
          iVar12 = aiStack_8c[0];
          if (0xfff < uVar13) {
            iVar12 = *(int *)(aiStack_8c[0] + -4);
            uVar13 = uStack_78 * 2 + 0x25;
            if (0x1f < (aiStack_8c[0] - iVar12) - 4U) goto LAB_0063acb0;
          }
          FUN_01674ea0(iVar12,uVar13);
        }
        if (iVar10 == 0) {
          if ((char)param_4 == '\0') {
            if (*(int *)(param_3 + 8) == *(int *)(param_3 + 4)) {
              FUN_00633390(*(int *)(param_3 + 4),aiStack_74);
            }
            else {
              FUN_0054f050(aiStack_74);
              *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 0x18;
            }
          }
          else {
            FUN_005569d0(apppppuStack_5c);
            uStack_8._0_1_ = 7;
            uVar13 = *(uint *)(param_1 + 0x10);
            pbVar14 = param_1;
            if (0xf < *(uint *)(param_1 + 0x14)) {
              pbVar14 = *(byte **)param_1;
            }
            pppppuStack_24 = apppppuStack_5c;
            if (0xf < uStack_48) {
              pppppuStack_24 = apppppuStack_5c[0];
            }
            pbStack_18 = pbVar14;
            if (uStack_4c < uVar13) {
LAB_0063ab60:
              iVar10 = -1;
            }
            else {
              if (uVar13 != 0) {
                iStack_20 = (int)(char)*pbVar14;
                iStack_1c = (uStack_4c - uVar13) + 1 + (int)pppppuStack_24;
                pbVar11 = (byte *)FUN_0170db20(pppppuStack_24,iStack_20,
                                               iStack_1c - (int)pppppuStack_24);
                while (pbVar2 = pbVar11, uVar15 = uVar13, pbVar11 != (byte *)0x0) {
                  while (uVar1 = uVar15 - 4, 3 < uVar15) {
                    if (*(int *)pbVar2 != *(int *)pbVar14) goto LAB_0063ab06;
                    pbVar14 = pbVar14 + 4;
                    pbVar2 = pbVar2 + 4;
                    uVar15 = uVar1;
                  }
                  if (uVar1 == 0xfffffffc) {
LAB_0063ab3a:
                    uVar15 = 0;
                  }
                  else {
LAB_0063ab06:
                    bVar16 = *pbVar2 < *pbVar14;
                    if ((*pbVar2 == *pbVar14) &&
                       ((uVar1 == 0xfffffffd ||
                        ((bVar16 = pbVar2[1] < pbVar14[1], pbVar2[1] == pbVar14[1] &&
                         ((uVar1 == 0xfffffffe ||
                          ((bVar16 = pbVar2[2] < pbVar14[2], pbVar2[2] == pbVar14[2] &&
                           ((uVar1 == 0xffffffff ||
                            (bVar16 = pbVar2[3] < pbVar14[3], pbVar2[3] == pbVar14[3]))))))))))))
                    goto LAB_0063ab3a;
                    uVar15 = -(uint)bVar16 | 1;
                  }
                  if (uVar15 == 0) {
                    iVar10 = (int)pbVar11 - (int)pppppuStack_24;
                    goto LAB_0063ab63;
                  }
                  pbVar11 = (byte *)FUN_0170db20(pbVar11 + 1,iStack_20,
                                                 iStack_1c - (int)(pbVar11 + 1));
                  pbVar14 = pbStack_18;
                }
                goto LAB_0063ab60;
              }
              iVar10 = 0;
            }
LAB_0063ab63:
            if (iVar10 != -1) {
              uVar9 = FUN_0058c540(aiStack_8c,uVar13 + 1 + iVar10,0xffffffff);
              FUN_005511f0(uVar9);
              FUN_005507b0();
            }
            if (uStack_4c != 0) {
              uVar9 = FUN_00558140(apppppuStack_5c,0);
              uStack_8._0_1_ = 8;
              if (*(int *)(param_3 + 8) == *(int *)(param_3 + 4)) {
                FUN_0058d1c0(*(int *)(param_3 + 4),uVar9);
              }
              else {
                FUN_0054f050(uVar9);
                *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 0x18;
              }
              FUN_00550800();
            }
            FUN_005507b0();
          }
        }
        uStack_8._0_1_ = 2;
        pbVar14 = pbStack_14;
        if (7 < uStack_60) {
          uVar13 = uStack_60 * 2 + 2;
          iVar10 = aiStack_74[0];
          if (0xfff < uVar13) {
            iVar10 = *(int *)(aiStack_74[0] + -4);
            uVar13 = uStack_60 * 2 + 0x25;
            if (0x1f < (aiStack_74[0] - iVar10) - 4U) {
LAB_0063acb0:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar10,uVar13);
          pbVar14 = pbStack_14;
        }
      }
    }
    FUN_0168c5c0(&iStack_2c,0);
  } while( true );
}



/* FUNCTION 7127 ; VA 0x0063acc0 ; FUN_0063acc0 */

uint FUN_0063acc0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ff48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar1 = (int *)FUN_0168e1c0(auStack_18,param_2,0);
  uStack_24 = piVar1[1];
  if ((*piVar1 != 0) && (*piVar1 != 1)) {
    uStack_24 = 0;
    uStack_20 = 0;
    iStack_1c = 0;
    uStack_8 = 0;
    FUN_0063a800(param_1,param_2,&uStack_24,1);
    FUN_0063c050(&uStack_24,param_2,param_3);
    if (uStack_24 != 0) {
      FUN_0058cd80(uStack_24,uStack_20,&uStack_24);
      uVar2 = ((int)(iStack_1c - uStack_24) / 0x18) * 0x18;
      uVar3 = uStack_24;
      if (0xfff < uVar2) {
        uVar3 = *(uint *)(uStack_24 - 4);
        uVar2 = uVar2 + 0x23;
        if (0x1f < (uStack_24 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_24 = FUN_01674ea0(uVar3,uVar2);
    }
  }
  ExceptionList = pvStack_10;
  return uStack_24 & 0xffffff00;
}



/* FUNCTION 7128 ; VA 0x0063adb0 ; FUN_0063adb0 */

int __fastcall FUN_0063adb0(int *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)*param_1;
  if (puVar1 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*puVar1;
  }
  return (param_1[3] & 0xfU) + *(int *)(puVar1[1] + ((uint)param_1[3] >> 4 & puVar1[2] - 1) * 4);
}



/* FUNCTION 7129 ; VA 0x0063adf0 ; FUN_0063adf0 */

int * FUN_0063adf0(int *param_1,int param_2,int *param_3)

{
  int *piVar1;
  bool bVar2;
  undefined uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 ****ppppuVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  int *piVar10;
  code ****ppppcVar11;
  uint uVar12;
  uint uVar13;
  int *piVar14;
  undefined4 ****ppppuVar15;
  uint auStack_a8 [4];
  undefined4 uStack_98;
  uint uStack_94;
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  int *piStack_84;
  int iStack_80;
  undefined4 uStack_7c;
  int *piStack_78;
  undefined4 uStack_74;
  int *piStack_70;
  uint uStack_6c;
  undefined4 ***apppuStack_68 [4];
  int iStack_58;
  uint uStack_54;
  int iStack_50;
  int iStack_4c;
  code ***apppcStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  code ***pppcStack_24;
  int iStack_20;
  char cStack_19;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0001;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = (int)param_3;
  uVar12 = 1;
  uStack_14 = 1;
  uStack_18 = 1;
  FUN_016863f0(apppuStack_68);
  uStack_8._0_1_ = 2;
  FUN_01686ad0(auStack_a8);
  uStack_8._0_1_ = 3;
  while ((iStack_50 != iStack_90 || (iStack_4c != iStack_8c))) {
    bVar2 = false;
    piVar1 = *(int **)(*param_1 + 0x2c);
    if ((piVar1 != (int *)0x0) && (piVar14 = (int *)*piVar1, piVar14 != (int *)piVar1[1])) {
      do {
        if ((*piVar14 == 0) ||
           (iVar8 = *(int *)(*piVar14 + 0xc), iVar4 = FUN_00b9e640(), uVar12 = uStack_14,
           (uint)*(ushort *)(iVar4 + 0x1da) <
           (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
          uVar13 = uVar12 | 4;
          piStack_70 = (int *)0x0;
          puVar5 = &uStack_74;
          iStack_20 = 0;
        }
        else {
          piStack_78 = (int *)piVar14[1];
          iStack_20 = *piVar14;
          if (piStack_78 != (int *)0x0) {
            LOCK();
            piStack_78[1] = piStack_78[1] + 1;
            UNLOCK();
            piStack_78 = (int *)piVar14[1];
          }
          uVar13 = uStack_14 | 2;
          puVar5 = &uStack_7c;
        }
        uVar12 = uVar13 | 8;
        piStack_84 = (int *)puVar5[1];
        *puVar5 = 0;
        puVar5[1] = 0;
        iStack_88 = iStack_20;
        piStack_28 = piStack_84;
        uStack_18 = uVar12;
        uStack_14 = uVar12;
        if (((uVar13 & 4) != 0) &&
           (uVar12 = uVar13 & 0xfffffffb | 8, uStack_18 = uVar12, uStack_14 = uVar12,
           piStack_70 != (int *)0x0)) {
          LOCK();
          iVar8 = piStack_70[1] + -1;
          piStack_70[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_70)();
            LOCK();
            iVar8 = piStack_70[2] + -1;
            piStack_70[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piStack_70 + 4))();
            }
          }
        }
        if (((uVar12 & 2) != 0) &&
           (uVar12 = uVar12 & 0xfffffffd, uStack_18 = uVar12, uStack_14 = uVar12,
           piStack_78 != (int *)0x0)) {
          LOCK();
          iVar8 = piStack_78[1] + -1;
          piStack_78[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_78)();
            LOCK();
            iVar8 = piStack_78[2] + -1;
            piStack_78[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piStack_78 + 4))();
            }
          }
        }
        uStack_6c = uVar12;
        if (iStack_20 != 0) {
          uStack_18 = uVar12 | 0x10;
          uStack_8._0_1_ = 5;
          uStack_38 = 0;
          uStack_34 = 0xf;
          apppcStack_48[0] = (code ***)((uint)apppcStack_48[0] & 0xffffff00);
          if (iStack_58 != 0) {
            ppppuVar6 = apppuStack_68;
            if (7 < uStack_54) {
              ppppuVar6 = (undefined4 ****)apppuStack_68[0];
            }
            uStack_14 = (int)ppppuVar6 + iStack_58 * 2;
            ppppuVar6 = apppuStack_68;
            if (7 < uStack_54) {
              ppppuVar6 = (undefined4 ****)apppuStack_68[0];
            }
            uVar7 = FUN_01686580();
            FUN_01685a20(ppppuVar6,uStack_14,apppcStack_48,uVar7);
          }
          pppcStack_24 = apppcStack_48[0];
          ppppcVar11 = apppcStack_48;
          if (0xf < uStack_34) {
            ppppcVar11 = (code ****)apppcStack_48[0];
          }
          piVar10 = *(int **)(iStack_20 + 0x28);
          piVar1 = piVar10 + 4;
          if (0xf < (uint)piVar10[5]) {
            piVar10 = (int *)*piVar10;
          }
          cStack_19 = FUN_0055c360(piVar10,*piVar1,ppppcVar11,uStack_38);
          uVar12 = uStack_6c & 0xffffffef;
          uStack_8._0_1_ = 4;
          uVar3 = (undefined)uStack_8;
          uStack_8._0_1_ = 4;
          uStack_18 = uVar12;
          uStack_14 = uVar12;
          if (0xf < uStack_34) {
            uVar13 = uStack_34 + 1;
            ppppcVar11 = (code ****)pppcStack_24;
            if (0xfff < uVar13) {
              ppppcVar11 = (code ****)pppcStack_24[-1];
              uVar13 = uStack_34 + 0x24;
              if (0x1f < (uint)((int)pppcStack_24 + (-4 - (int)ppppcVar11))) goto LAB_0063b3c4;
            }
            FUN_01674ea0(ppppcVar11,uVar13);
          }
          piVar1 = piStack_28;
          if (cStack_19 != '\0') {
            if (piStack_28 != (int *)0x0) {
              LOCK();
              piStack_28[1] = piStack_28[1] + 1;
              UNLOCK();
            }
            *param_1 = iStack_20;
            piVar14 = (int *)param_1[1];
            param_1[1] = (int)piStack_28;
            if (piVar14 != (int *)0x0) {
              LOCK();
              iVar8 = piVar14[1] + -1;
              piVar14[1] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)*piVar14)();
                LOCK();
                iVar8 = piVar14[2] + -1;
                piVar14[2] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)(*piVar14 + 4))();
                }
              }
            }
            uStack_8._0_1_ = 3;
            bVar2 = true;
            if (piVar1 != (int *)0x0) {
              LOCK();
              iVar8 = piVar1[1] + -1;
              piVar1[1] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)*piVar1)();
                LOCK();
                iVar8 = piVar1[2] + -1;
                piVar1[2] = iVar8;
                UNLOCK();
                bVar2 = true;
                if (iVar8 == 0) {
                  (**(code **)(*piVar1 + 4))();
                }
              }
            }
            break;
          }
        }
        uStack_8._0_1_ = 3;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_28[1] + -1;
          piStack_28[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            iVar8 = piStack_28[2] + -1;
            piStack_28[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piStack_28 + 4))();
            }
          }
        }
        piVar14 = piVar14 + 2;
      } while (piVar14 != *(int **)(*(int *)(*param_1 + 0x2c) + 4));
    }
    if (!bVar2) {
      uStack_8._0_1_ = 6;
      iVar8 = FUN_00b9e640();
      uVar7 = DAT_01edf5b0;
      if (*(undefined4 **)(iVar8 + 0x1dc) != (undefined4 *)0x0) {
        uVar7 = **(undefined4 **)(iVar8 + 0x1dc);
      }
      uVar7 = FUN_01675290(uVar7);
      uStack_8._0_1_ = 7;
      pppcStack_24 = (code ***)uVar7;
      iStack_80 = FUN_01674e20(0x54);
      uStack_8._0_1_ = 8;
      if (iStack_80 == 0) {
        uVar9 = 0;
      }
      else {
        uVar9 = FUN_00b9e740();
      }
      uStack_8._0_1_ = 7;
      piStack_30 = (int *)0x0;
      piStack_2c = (int *)0x0;
      FUN_00633b00(uVar9,param_1);
      uStack_18 = uVar12 | 0x20;
      uStack_8._0_1_ = 0xc;
      FUN_01675290(uVar7);
      pppcStack_24 = *(code ****)(*piStack_30 + 0x38);
      uStack_18 = uVar12 | 0x60;
      uStack_8._0_1_ = 0xd;
      uStack_38 = 0;
      uStack_34 = 0xf;
      apppcStack_48[0] = (code ***)((uint)apppcStack_48[0] & 0xffffff00);
      uStack_14 = uStack_18;
      if (iStack_58 != 0) {
        ppppuVar6 = apppuStack_68;
        if (7 < uStack_54) {
          ppppuVar6 = (undefined4 ****)apppuStack_68[0];
        }
        iVar8 = iStack_58 * 2;
        ppppuVar15 = apppuStack_68;
        if (7 < uStack_54) {
          ppppuVar15 = (undefined4 ****)apppuStack_68[0];
        }
        uVar7 = FUN_01686580();
        FUN_01685a20(ppppuVar15,(int)ppppuVar6 + iVar8,apppcStack_48,uVar7);
      }
      uVar12 = uStack_14;
      (*(code *)pppcStack_24)(apppcStack_48);
      uStack_18 = uVar12 & 0xffffffbf;
      uStack_8._0_1_ = 6;
      if (0xf < uStack_34) {
        uVar13 = uStack_34 + 1;
        ppppcVar11 = (code ****)apppcStack_48[0];
        if (0xfff < uVar13) {
          ppppcVar11 = (code ****)apppcStack_48[0][-1];
          uVar13 = uStack_34 + 0x24;
          uVar3 = (undefined)uStack_8;
          if (0x1f < (uint)((int)apppcStack_48[0] + (-4 - (int)ppppcVar11))) goto LAB_0063b3c4;
        }
        FUN_01674ea0(ppppcVar11,uVar13);
      }
      FUN_008a65e0(*param_1,0);
      piVar1 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[1] = piStack_2c[1] + 1;
        UNLOCK();
      }
      *param_1 = (int)piStack_30;
      piVar14 = (int *)param_1[1];
      param_1[1] = (int)piStack_2c;
      if (piVar14 != (int *)0x0) {
        LOCK();
        iVar8 = piVar14[1] + -1;
        piVar14[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar14)();
          LOCK();
          iVar8 = piVar14[2] + -1;
          piVar14[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar14 + 4))();
          }
        }
      }
      uVar12 = uVar12 & 0xffffff9f;
      uStack_8._0_1_ = 3;
      uStack_18 = uVar12;
      uStack_14 = uVar12;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar8 = piVar1[1] + -1;
        piVar1[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar8 = piVar1[2] + -1;
          piVar1[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
    }
    FUN_01688400(apppuStack_68);
  }
  if (7 < uStack_94) {
    uVar12 = uStack_94 * 2 + 2;
    uVar13 = auStack_a8[0];
    if (0xfff < uVar12) {
      uVar13 = *(uint *)(auStack_a8[0] - 4);
      uVar12 = uStack_94 * 2 + 0x25;
      uVar3 = (undefined)uStack_8;
      if (0x1f < (auStack_a8[0] - uVar13) - 4) {
LAB_0063b3c4:
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar12);
  }
  uStack_98 = 0;
  uStack_94 = 7;
  auStack_a8[0] = auStack_a8[0] & 0xffff0000;
  if (7 < uStack_54) {
    uVar12 = uStack_54 * 2 + 2;
    ppppuVar6 = (undefined4 ****)apppuStack_68[0];
    if (0xfff < uVar12) {
      ppppuVar6 = (undefined4 ****)apppuStack_68[0][-1];
      uVar12 = uStack_54 * 2 + 0x25;
      if (0x1f < (uint)((int)apppuStack_68[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar12);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar8 = param_3[1] + -1;
    param_3[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7130 ; VA 0x0063b3d0 ; FUN_0063b3d0 */

undefined4 __thiscall FUN_0063b3d0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x130);
  return param_2;
}



/* FUNCTION 7131 ; VA 0x0063b3f0 ; FUN_0063b3f0 */

int FUN_0063b3f0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  int *piVar11;
  int aiStack_94 [5];
  uint uStack_80;
  undefined auStack_7c [4];
  code *pcStack_78;
  undefined auStack_74 [4];
  int *piStack_70;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int *piStack_4c;
  int iStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  uint uStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017a0064;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_44 = 0;
  iStack_8 = 0;
  iStack_1c = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00baac40();
  if ((char)iVar3 != '\0') {
    iVar3 = FUN_008f7870(param_2);
    iStack_1c = iVar3;
  }
  if (*(int *)((int)param_1 + 8) == 0) {
    puVar10 = (undefined4 *)0x0;
  }
  else {
    puVar10 = *(undefined4 **)(*(int *)((int)param_1 + 0x14) + *(int *)((int)param_1 + 4) * 4);
  }
  do {
    if (puVar10 == (undefined4 *)0x0) {
      if (param_3 != (int *)0x0) {
        LOCK();
        piVar11 = param_3 + 1;
        iVar1 = *piVar11;
        iVar3 = *piVar11;
        *piVar11 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          iVar3 = (**(code **)*param_3)();
          LOCK();
          piVar11 = param_3 + 2;
          iVar1 = *piVar11;
          *piVar11 = *piVar11 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            iVar3 = (**(code **)(*param_3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar3;
    }
    FUN_005c30b0(&piStack_24);
    uStack_5c = 0;
    piVar11 = puVar10 + 2;
    uStack_58 = 7;
    auStack_6c[0] = auStack_6c[0] & 0xffff0000;
    iVar3 = puVar10[6];
    iStack_8._0_1_ = 2;
    if (iVar3 != 0) {
      piVar6 = piVar11;
      if (0xf < (uint)puVar10[7]) {
        piVar6 = (int *)*piVar11;
      }
      if (0xf < (uint)puVar10[7]) {
        piVar11 = (int *)*piVar11;
      }
      uVar4 = FUN_01686580();
      FUN_01685950(piVar11,(int)piVar6 + iVar3,auStack_6c,uVar4);
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_28 = param_2;
    uStack_54 = param_2;
    piStack_50 = param_3;
    iStack_8._0_1_ = 4;
    iVar3 = FUN_01688660(auStack_40);
    iVar3 = *(int *)(iVar3 + 0x10);
    if (7 < uStack_2c) {
      uVar8 = uStack_2c * 2 + 2;
      uVar9 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar9 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c * 2 + 0x25;
        if (0x1f < (auStack_40[0] - uVar9) - 4) goto LAB_0063b915;
      }
      FUN_01674ea0(uVar9,uVar8);
    }
    piVar11 = param_3;
    if (iVar3 != 0) {
      uVar4 = FUN_01688660(auStack_40);
      iStack_8 = CONCAT31(iStack_8._1_3_,5);
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      puVar5 = (undefined4 *)FUN_0063adf0(auStack_74,param_2,param_3,uVar4);
      uStack_54 = *puVar5;
      piVar11 = (int *)puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      piStack_50 = piVar11;
      uStack_28 = uStack_54;
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar3 = param_3[1] + -1;
        param_3[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*param_3)();
          LOCK();
          iVar3 = param_3[2] + -1;
          param_3[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*param_3 + 4))();
          }
        }
      }
      piVar6 = piStack_70;
      if (piStack_70 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_70[1] + -1;
        piStack_70[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_70)();
          LOCK();
          piVar7 = piVar6 + 2;
          iVar3 = *piVar7 + -1;
          *piVar7 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      iStack_8._0_1_ = 4;
      if (7 < uStack_2c) {
        uVar8 = uStack_2c * 2 + 2;
        uVar9 = auStack_40[0];
        if (0xfff < uVar8) {
          uVar9 = *(uint *)(auStack_40[0] - 4);
          uVar8 = uStack_2c * 2 + 0x25;
          if (0x1f < (auStack_40[0] - uVar9) - 4) goto LAB_0063b915;
        }
        FUN_01674ea0(uVar9,uVar8);
      }
    }
    piStack_4c = piStack_24;
    pcStack_14 = *(code **)(*piStack_24 + 0x38);
    param_1 = (undefined4 *)FUN_01686c70(aiStack_94);
    uStack_44 = uStack_18 | 2;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    iStack_8._0_1_ = 7;
    uStack_18 = uStack_44;
    if (param_1[4] != 0) {
      puVar5 = param_1;
      if (7 < (uint)param_1[5]) {
        puVar5 = (undefined4 *)*param_1;
      }
      iStack_48 = (int)puVar5 + param_1[4] * 2;
      if (7 < (uint)param_1[5]) {
        param_1 = (undefined4 *)*param_1;
      }
      uVar4 = FUN_01686580();
      FUN_01685a20(param_1,iStack_48,auStack_40,uVar4);
    }
    (*pcStack_14)(auStack_40);
    uStack_18 = uStack_18 & 0xfffffffd;
    iStack_8._0_1_ = 6;
    if (0xf < uStack_2c) {
      uVar9 = uStack_2c + 1;
      uVar8 = auStack_40[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_40[0] - 4);
        uVar9 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar8) - 4) goto LAB_0063b915;
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    iStack_8._0_1_ = 4;
    if (7 < uStack_80) {
      uVar8 = uStack_80 * 2 + 2;
      iVar3 = aiStack_94[0];
      if (0xfff < uVar8) {
        iVar3 = *(int *)(aiStack_94[0] + -4);
        uVar8 = uStack_80 * 2 + 0x25;
        if (0x1f < (aiStack_94[0] - iVar3) - 4U) goto LAB_0063b915;
      }
      FUN_01674ea0(iVar3,uVar8);
    }
    FUN_009ed830(puVar10 + 8);
    *(undefined *)(piStack_24 + 0x3b) = 1;
    cVar2 = FUN_00baac40();
    if ((cVar2 != '\0') && (iStack_1c != 0)) {
      FUN_005789c0(&DAT_01ead650,&LAB_006340b0);
      uVar4 = FUN_006351d0();
      piVar6 = (int *)FUN_008aa140(uVar4);
      if (*piVar6 == 0) {
        uVar4 = FUN_00b75e90();
        piVar7 = (int *)FUN_008a9ba0(auStack_7c,uVar4);
        iVar3 = *piVar7;
        iVar1 = piVar7[1];
        *piVar7 = 0;
        piVar7[1] = 0;
        *piVar6 = iVar3;
        pcStack_14 = (code *)piVar6[1];
        piVar6[1] = iVar1;
        if (pcStack_14 != (code *)0x0) {
          LOCK();
          iVar3 = *(int *)((int)pcStack_14 + 4) + -1;
          *(int *)((int)pcStack_14 + 4) = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (*(code *)**(undefined4 **)pcStack_14)();
            LOCK();
            iVar3 = *(int *)((int)pcStack_14 + 8) + -1;
            *(int *)((int)pcStack_14 + 8) = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*(int *)pcStack_14 + 4))();
            }
          }
        }
        pcStack_14 = pcStack_78;
        if (pcStack_78 != (code *)0x0) {
          LOCK();
          iVar3 = *(int *)(pcStack_78 + 4) + -1;
          *(int *)(pcStack_78 + 4) = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (*(code *)**(undefined4 **)pcStack_78)();
            LOCK();
            iVar3 = *(int *)(pcStack_14 + 8) + -1;
            *(int *)(pcStack_14 + 8) = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*(int *)pcStack_14 + 4))();
            }
          }
        }
      }
      if (*piVar6 != 0) {
        uVar4 = FUN_01687ca0();
        FUN_00b76b00(piStack_24,uVar4);
      }
    }
    FUN_008a65e0(uStack_28,0);
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar3 = piVar11[1] + -1;
      piVar11[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar11)();
        LOCK();
        iVar3 = piVar11[2] + -1;
        piVar11[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
    iStack_8._0_1_ = 1;
    if (7 < uStack_58) {
      uVar8 = uStack_58 * 2 + 2;
      uVar9 = auStack_6c[0];
      if (0xfff < uVar8) {
        uVar9 = *(uint *)(auStack_6c[0] - 4);
        uVar8 = uStack_58 * 2 + 0x25;
        if (0x1f < (auStack_6c[0] - uVar9) - 4) {
LAB_0063b915:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar8);
    }
    piVar11 = piStack_20;
    iVar3 = 0;
    uStack_5c = 0;
    uStack_58 = 7;
    auStack_6c[0] = auStack_6c[0] & 0xffff0000;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar6 = piStack_20 + 1;
      iVar1 = *piVar6;
      iVar3 = *piVar6;
      *piVar6 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar6 = piVar11 + 2;
        iVar1 = *piVar6;
        iVar3 = *piVar6;
        *piVar6 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          iVar3 = (**(code **)(*piVar11 + 4))();
        }
      }
    }
    puVar10 = (undefined4 *)*puVar10;
  } while( true );
}



/* FUNCTION 7132 ; VA 0x0063b920 ; FUN_0063b920 */

undefined FUN_0063b920(void)

{
  bool bVar1;
  undefined uVar2;
  undefined4 uVar3;
  short ****ppppsVar4;
  undefined4 ****ppppuVar5;
  uint uVar6;
  int iVar7;
  undefined2 auStack_78 [8];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined2 auStack_60 [8];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  short ***apppsStack_48 [5];
  uint uStack_34;
  undefined4 ***apppuStack_30 [4];
  int iStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a00ca;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_01686c70(apppsStack_48);
  uStack_68 = 0;
  uStack_64 = 7;
  auStack_78[0] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  iStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  FUN_005542c0(&DAT_018ceeac,2);
  uStack_8._0_1_ = 2;
  if (iStack_20 != 0) {
    ppppuVar5 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar5 = (undefined4 ****)apppuStack_30[0];
    }
    iVar7 = (int)ppppuVar5 + iStack_20;
    ppppuVar5 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar5 = (undefined4 ****)apppuStack_30[0];
    }
    uVar3 = FUN_01686580();
    FUN_01685950(ppppuVar5,iVar7,auStack_78,uVar3);
  }
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar6) {
      ppppuVar5 = (undefined4 ****)apppuStack_30[0][-1];
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar5))) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar6);
  }
  iStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  bVar1 = false;
  uStack_18 = 1;
  iVar7 = FUN_01686710(auStack_78);
  if (iVar7 != 0) {
    uStack_50 = 0;
    uStack_4c = 7;
    auStack_60[0] = 0;
    uStack_8 = 4;
    iStack_20 = 0;
    uStack_1c = 0xf;
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    FUN_005542c0(&DAT_018c1030,1);
    uStack_8._0_1_ = 5;
    if (iStack_20 != 0) {
      ppppuVar5 = apppuStack_30;
      if (0xf < uStack_1c) {
        ppppuVar5 = (undefined4 ****)apppuStack_30[0];
      }
      iVar7 = (int)ppppuVar5 + iStack_20;
      ppppuVar5 = apppuStack_30;
      if (0xf < uStack_1c) {
        ppppuVar5 = (undefined4 ****)apppuStack_30[0];
      }
      uVar3 = FUN_01686580();
      FUN_01685950(ppppuVar5,iVar7,auStack_60,uVar3);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (0xf < uStack_1c) {
      uVar6 = uStack_1c + 1;
      ppppuVar5 = (undefined4 ****)apppuStack_30[0];
      if (0xfff < uVar6) {
        ppppuVar5 = (undefined4 ****)apppuStack_30[0][-1];
        uVar6 = uStack_1c + 0x24;
        if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar5,uVar6);
    }
    iStack_20 = 0;
    uStack_1c = 0xf;
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    uStack_8 = 6;
    bVar1 = true;
    uStack_18 = 3;
    iVar7 = FUN_01686710(auStack_60);
    if (iVar7 != 0) {
      uStack_11 = 1;
      ppppsVar4 = apppsStack_48;
      if (7 < uStack_34) {
        ppppsVar4 = (short ****)apppsStack_48[0];
      }
      if (*(short *)ppppsVar4 == 0x2e) goto LAB_0063bb1c;
    }
  }
  uStack_11 = 0;
LAB_0063bb1c:
  if (bVar1) {
    FUN_00550800();
  }
  FUN_00550800();
  if (7 < uStack_34) {
    uVar6 = uStack_34 * 2 + 2;
    ppppsVar4 = (short ****)apppsStack_48[0];
    if (0xfff < uVar6) {
      ppppsVar4 = (short ****)apppsStack_48[0][-1];
      uVar6 = uStack_34 * 2 + 0x25;
      if (0x1f < (uint)((int)apppsStack_48[0] + (-4 - (int)ppppsVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppsVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return uStack_11;
}



/* FUNCTION 7133 ; VA 0x0063bb90 ; FUN_0063bb90 */

void FUN_0063bb90(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  bool bVar3;
  undefined uVar4;
  void **ppvVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined4 *****pppppuVar9;
  uint uVar10;
  uint uVar11;
  undefined4 *puVar12;
  uint uVar13;
  undefined4 *****pppppuVar14;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 ****appppuStack_54 [4];
  int iStack_44;
  uint uStack_40;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [8];
  uint uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0122;
  uVar13 = 0;
  puVar12 = (undefined4 *)*param_1;
  puVar2 = (undefined4 *)param_1[1];
  ppvVar5 = &pvStack_10;
  pvStack_10 = ExceptionList;
  do {
    ExceptionList = ppvVar5;
    if (puVar12 == puVar2) {
      ExceptionList = pvStack_10;
      return;
    }
    uStack_14 = uVar13 | 1;
    uStack_8 = 0;
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    FUN_0058a190(DAT_01d5a358 + puVar12[4]);
    puVar6 = puVar12;
    if (0xf < (uint)puVar12[5]) {
      puVar6 = (undefined4 *)*puVar12;
    }
    FUN_00554150(puVar6,puVar12[4]);
    puVar6 = &DAT_01d5a348;
    if (0xf < DAT_01d5a35c) {
      puVar6 = DAT_01d5a348;
    }
    FUN_00554150(puVar6,DAT_01d5a358);
    uVar7 = FUN_0151a8d0(auStack_6c,auStack_3c);
    uStack_8._0_1_ = 1;
    FUN_0054f050(uVar7);
    uStack_8._0_1_ = 3;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (7 < uStack_58) {
      uVar10 = uStack_58 * 2 + 2;
      uVar11 = auStack_6c[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_6c[0] - 4);
        uVar10 = uStack_58 * 2 + 0x25;
        if (0x1f < (auStack_6c[0] - uVar11) - 4) goto LAB_0063be1d;
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_5c = 0;
    uVar13 = uVar13 & 0xfffffffe;
    uStack_58 = 7;
    auStack_6c[0] = auStack_6c[0] & 0xffff0000;
    uStack_8._0_1_ = 4;
    uStack_1c = uVar13;
    if (0xf < uStack_28) {
      uVar11 = uStack_28 + 1;
      uVar10 = auStack_3c[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_3c[0] - 4);
        uVar11 = uStack_28 + 0x24;
        uVar4 = (undefined)uStack_8;
        if (0x1f < (auStack_3c[0] - uVar10) - 4) goto LAB_0063be1d;
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    piVar8 = (int *)FUN_0168e1c0(auStack_24,appppuStack_54,0);
    uStack_14 = piVar8[1];
    if ((*piVar8 == 0) || (*piVar8 == 1)) {
      bVar3 = false;
    }
    else {
      bVar3 = true;
    }
    if (bVar3) {
      uStack_14 = uVar13 | 2;
      uStack_8._0_1_ = 5;
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      if (iStack_44 != 0) {
        pppppuVar9 = appppuStack_54;
        if (7 < uStack_40) {
          pppppuVar9 = (undefined4 *****)appppuStack_54[0];
        }
        iVar1 = iStack_44 * 2;
        pppppuVar14 = appppuStack_54;
        if (7 < uStack_40) {
          pppppuVar14 = (undefined4 *****)appppuStack_54[0];
        }
        uVar7 = FUN_01686580();
        FUN_01685a20(pppppuVar14,(int)pppppuVar9 + iVar1,auStack_3c,uVar7);
      }
      FUN_0063acc0(auStack_3c,appppuStack_54,param_2);
      uVar13 = uStack_1c & 0xfffffffd;
      uStack_8._0_1_ = 4;
      if (0xf < uStack_28) {
        uVar11 = uStack_28 + 1;
        uVar10 = auStack_3c[0];
        if (0xfff < uVar11) {
          uVar10 = *(uint *)(auStack_3c[0] - 4);
          uVar11 = uStack_28 + 0x24;
          uVar4 = (undefined)uStack_8;
          if (0x1f < (auStack_3c[0] - uVar10) - 4) goto LAB_0063be1d;
        }
        FUN_01674ea0(uVar10,uVar11);
      }
    }
    uStack_8._0_1_ = 0xff;
    uStack_8._1_3_ = 0xffffff;
    if (7 < uStack_40) {
      uVar10 = uStack_40 * 2 + 2;
      pppppuVar9 = (undefined4 *****)appppuStack_54[0];
      if (0xfff < uVar10) {
        pppppuVar9 = (undefined4 *****)appppuStack_54[0][-1];
        uVar10 = uStack_40 * 2 + 0x25;
        uVar4 = (undefined)uStack_8;
        if (0x1f < (uint)((int)appppuStack_54[0] + (-4 - (int)pppppuVar9))) {
LAB_0063be1d:
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar9,uVar10);
    }
    puVar12 = puVar12 + 6;
    ppvVar5 = (void **)ExceptionList;
  } while( true );
}



/* FUNCTION 7134 ; VA 0x0063be30 ; FUN_0063be30 */

void __fastcall FUN_0063be30(int param_1)

{
  bool bVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined in_stack_ffffffbc;
  undefined uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0150;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_0097c970();
  if (cVar2 == '\0') {
    FUN_0063c9f0();
  }
  else {
    FUN_00638880();
  }
  cVar2 = FUN_00983210();
  if (cVar2 != '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  if (DAT_01ef0a2a != '\0') {
    piVar3 = (int *)(param_1 + 0x1c);
    if (0xf < *(uint *)(param_1 + 0x30)) {
      piVar3 = (int *)*piVar3;
    }
    cVar2 = FUN_0055c360(piVar3,*(undefined4 *)(param_1 + 0x2c));
    if (cVar2 != '\0') {
      ExceptionList = pvStack_10;
      return;
    }
  }
  iVar4 = FUN_008fbd40();
  if (iVar4 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar4 = FUN_0055ea10();
  if ((iVar4 != 0) && (*(int *)(param_1 + 0x2c) != 0)) {
    uStack_8 = 0;
    FUN_0054ef60(param_1 + 0x1c);
    goto LAB_0063c029;
  }
  iVar4 = FUN_0055ea10();
  if (iVar4 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar4 = *(int *)(param_1 + 0x18);
  bVar1 = false;
  if (iVar4 == 2) {
    bVar1 = true;
LAB_0063bf4f:
    uStack_8 = 1;
    uVar5 = 0;
    FUN_005542c0("ServerStarterScript",0x13);
    uStack_8 = 0xffffffff;
    FUN_0094a3b0(uVar5);
    uStack_8 = 2;
    uVar5 = 0;
    FUN_005542c0("rcc/HiddenStarterScript",0x17);
    uStack_8 = 0xffffffff;
    FUN_0094a2b0(uVar5);
    if (!bVar1) {
      ExceptionList = pvStack_10;
      return;
    }
  }
  else if (iVar4 != 0) {
    if (iVar4 != 1) {
      ExceptionList = pvStack_10;
      return;
    }
    goto LAB_0063bf4f;
  }
  uStack_8 = 3;
  in_stack_ffffffbc = 0;
  FUN_005542c0("StarterScript",0xd);
LAB_0063c029:
  uStack_8 = 0xffffffff;
  FUN_0094a3b0(in_stack_ffffffbc);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7135 ; VA 0x0063c050 ; FUN_0063c050 */

void FUN_0063c050(uint *param_1,undefined4 param_2)

{
  undefined uVar1;
  undefined4 uVar2;
  char *pcVar3;
  int iVar4;
  uint uVar5;
  undefined4 ****ppppuVar6;
  undefined4 ****ppppuVar7;
  undefined1 *puVar8;
  undefined4 ****ppppuVar9;
  undefined4 **ppuStack_164;
  undefined4 uStack_160;
  undefined4 ***pppuStack_15c;
  undefined1 *puStack_158;
  undefined4 ***pppuStack_154;
  undefined4 ***pppuStack_150;
  int iStack_140;
  uint uStack_12c;
  undefined4 ***pppuStack_128;
  uint uStack_114;
  undefined4 ***pppuStack_110;
  uint uStack_fc;
  undefined4 ***apppuStack_f8 [4];
  undefined4 uStack_e8;
  uint uStack_e4;
  undefined4 ***apppuStack_e0 [4];
  undefined4 uStack_d0;
  uint uStack_cc;
  undefined4 ***pppuStack_c8;
  undefined4 uStack_b8;
  uint uStack_b4;
  undefined auStack_b0 [8];
  undefined4 ***apppuStack_a8 [4];
  undefined4 uStack_98;
  uint uStack_94;
  undefined4 ***apppuStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  char acStack_70 [12];
  int aiStack_64 [4];
  int iStack_54;
  uint uStack_50;
  undefined4 ***apppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 ***pppuStack_34;
  undefined4 ***apppuStack_30 [4];
  int iStack_20;
  uint uStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017a01fd;
  pvStack_10 = ExceptionList;
  ppppuVar9 = (undefined4 ****)*param_1;
  ExceptionList = &pvStack_10;
  if (ppppuVar9 != (undefined4 ****)param_1[1]) {
    do {
      pppuStack_154 = (undefined4 ****)0x63c08b;
      pppuStack_150 = ppppuVar9;
      FUN_0054f050();
      uStack_8 = 0;
      if (iStack_54 != 0) {
        pppuStack_34 = &ppuStack_164;
        FUN_0054f050(param_2);
        uStack_8._0_1_ = 1;
        uVar2 = FUN_01686150(aiStack_64);
        FUN_0054f050(uVar2);
        uStack_8._0_1_ = 0;
        uVar1 = (undefined)uStack_8;
        uStack_8._0_1_ = 0;
        if (7 < uStack_12c) {
          uVar5 = uStack_12c * 2 + 2;
          iVar4 = iStack_140;
          if (0xfff < uVar5) {
            iVar4 = *(int *)(iStack_140 + -4);
            uVar5 = uStack_12c * 2 + 0x25;
            if (0x1f < (iStack_140 - iVar4) - 4U) goto LAB_0063c6c4;
          }
          FUN_01674ea0(iVar4,uVar5);
        }
        pcVar3 = (char *)FUN_00a34f50(acStack_70);
        uStack_8._0_1_ = 2;
        pppuStack_150 = (undefined4 ***)0x63c129;
        pppuStack_150 = (undefined4 ***)FUN_008866d0();
        uStack_8._0_1_ = 3;
        if (*pcVar3 != '\0') {
          pppuStack_150 = (undefined4 ***)(pcVar3 + 4);
        }
        pppuStack_154 = (undefined4 ****)0x63c13e;
        FUN_008866a0();
        pppuStack_150 = (undefined4 ***)0x63c146;
        FUN_0056e380();
        pppuStack_150 = (undefined4 ***)0x63c14e;
        FUN_0056e380();
        uStack_8._0_1_ = 6;
        if (acStack_70[0] != '\0') {
          pppuStack_150 = (undefined4 ***)0x63c160;
          FUN_0056e380();
          pppuStack_150 = (undefined4 ***)0x63c168;
          FUN_0056e380();
          acStack_70[0] = '\0';
        }
        pppuStack_150 = (undefined4 ***)0x63c174;
        iVar4 = FUN_00a33fa0();
        if (*(int *)(iVar4 + 0x10) == 0) {
          pppuStack_150 = (undefined4 ***)0x63c182;
          iVar4 = FUN_00a33fa0();
          if (*(int *)(iVar4 + 0x10) != 0) goto LAB_0063c18c;
        }
        else {
LAB_0063c18c:
          pppuStack_150 = (undefined4 ***)aiStack_64;
          pppuStack_154 = (undefined4 ***)0x63c19b;
          FUN_0054f050();
          uStack_3c = 0;
          uStack_38 = 7;
          apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffff0000);
          pppuStack_150 = (undefined4 ****)0x0;
          pppuStack_154 = (undefined4 ***)&DAT_018bc9b8;
          uStack_8._0_1_ = 8;
          iStack_20 = 0;
          uStack_1c = 0xf;
          apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
          puStack_158 = (undefined1 *)0x63c1ce;
          FUN_005542c0();
          uStack_8._0_1_ = 9;
          if (iStack_20 != 0) {
            ppppuVar6 = apppuStack_30;
            if (0xf < uStack_1c) {
              ppppuVar6 = (undefined4 ****)apppuStack_30[0];
            }
            puVar8 = (undefined1 *)((int)ppppuVar6 + iStack_20);
            ppppuVar6 = apppuStack_30;
            if (0xf < uStack_1c) {
              ppppuVar6 = (undefined4 ****)apppuStack_30[0];
            }
            pppuStack_150 = (undefined4 ***)0x63c1f6;
            pppuStack_150 = (undefined4 ***)FUN_01686580();
            pppuStack_154 = apppuStack_4c;
            uStack_160 = 0x63c202;
            pppuStack_15c = ppppuVar6;
            puStack_158 = puVar8;
            FUN_01685950();
          }
          uStack_8._0_1_ = 8;
          if (0xf < uStack_1c) {
            uVar5 = uStack_1c + 1;
            ppppuVar6 = (undefined4 ****)apppuStack_30[0];
            if (0xfff < uVar5) {
              ppppuVar6 = (undefined4 ****)apppuStack_30[0][-1];
              uVar5 = uStack_1c + 0x24;
              uVar1 = (undefined)uStack_8;
              if ((undefined1 *)0x1f < (undefined1 *)((int)apppuStack_30[0] + (-4 - (int)ppppuVar6))
                 ) goto LAB_0063c6c4;
            }
            puStack_158 = (undefined1 *)0x63c23d;
            pppuStack_154 = ppppuVar6;
            pppuStack_150 = (undefined4 ***)uVar5;
            FUN_01674ea0();
          }
          iStack_20 = 0;
          uStack_1c = 0xf;
          apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
          pppuStack_150 = apppuStack_4c;
          uStack_8._0_1_ = 10;
          pppuStack_154 = (undefined4 ****)0x63c262;
          FUN_01688950();
          uStack_8._0_1_ = 7;
          if (7 < uStack_38) {
            uVar5 = uStack_38 * 2 + 2;
            ppppuVar6 = (undefined4 ****)apppuStack_4c[0];
            if (0xfff < uVar5) {
              ppppuVar6 = (undefined4 ****)apppuStack_4c[0][-1];
              uVar5 = uStack_38 * 2 + 0x25;
              uVar1 = (undefined)uStack_8;
              if ((undefined1 *)0x1f < (undefined1 *)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar6))
                 ) goto LAB_0063c6c4;
            }
            puStack_158 = (undefined1 *)0x63c29d;
            pppuStack_154 = ppppuVar6;
            pppuStack_150 = (undefined4 ***)uVar5;
            FUN_01674ea0();
          }
          pppuStack_150 = apppuStack_e0;
          pppuStack_154 = (undefined4 ***)0x63c2af;
          FUN_005569d0();
          uStack_8._0_1_ = 0xb;
          pppuStack_154 = (undefined4 ***)0x63c2bf;
          pppuStack_150 = (undefined4 ***)param_2;
          FUN_0054f050();
          uStack_8._0_1_ = 0xc;
          pppuStack_150 = (undefined4 ***)0x63c2ce;
          uVar2 = FUN_01687ca0();
          pppuStack_154 = (undefined4 ***)0x63c2d9;
          pppuStack_150 = (undefined4 ***)param_2;
          FUN_0054f050();
          pppuStack_150 = apppuStack_f8;
          uStack_8._0_1_ = 0xd;
          pppuStack_154 = (undefined4 ***)0x63c2ec;
          pppuStack_150 = (undefined4 ***)FUN_01686150();
          pppuStack_154 = (undefined4 ****)0x63c2f5;
          FUN_0054f050();
          uStack_8._0_1_ = 0xc;
          if (7 < uStack_38) {
            uVar5 = uStack_38 * 2 + 2;
            ppppuVar6 = (undefined4 ****)apppuStack_4c[0];
            if (0xfff < uVar5) {
              ppppuVar6 = (undefined4 ****)apppuStack_4c[0][-1];
              uVar5 = uStack_38 * 2 + 0x25;
              uVar1 = (undefined)uStack_8;
              if ((undefined1 *)0x1f < (undefined1 *)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar6))
                 ) goto LAB_0063c6c4;
            }
            puStack_158 = (undefined1 *)0x63c330;
            pppuStack_154 = ppppuVar6;
            pppuStack_150 = (undefined4 ***)uVar5;
            FUN_01674ea0();
          }
          uStack_3c = 0;
          uStack_38 = 7;
          apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffff0000);
          uStack_8._0_1_ = 0xe;
          pppuStack_150 = (undefined4 ***)0x63c353;
          pppuStack_154 = (undefined4 ***)FUN_01687ca0();
          puStack_158 = (undefined1 *)0x63c360;
          pppuStack_150 = (undefined4 ***)uVar2;
          iVar4 = FUN_00b767d0();
          pppuStack_150 = (undefined4 ***)auStack_18;
          uStack_8._0_1_ = 0xf;
          pppuStack_154 = (undefined4 ***)0x63c375;
          FUN_008866a0();
          pppuStack_34 = apppuStack_a8;
          uStack_8._0_1_ = 0x10;
          pppuStack_154 = (undefined4 ***)0x63c38a;
          pppuStack_150 = (undefined4 ***)iVar4;
          FUN_0054f050();
          pppuStack_150 = (undefined4 ***)(iVar4 + 0x18);
          uStack_8._0_1_ = 0x11;
          pppuStack_154 = (undefined4 ***)0x63c39d;
          FUN_0054f050();
          pppuStack_150 = apppuStack_e0;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
          pppuStack_154 = (undefined4 ***)0x63c3b0;
          iVar4 = FUN_00637fc0();
          pppuStack_150 = (undefined4 ***)auStack_b0;
          pppuStack_154 = (undefined4 ****)0x63c3c1;
          FUN_00886840();
          if ((undefined4 ****)(iVar4 + 0x20) != apppuStack_a8) {
            pppuStack_150 = (undefined4 ***)uStack_98;
            pppuStack_154 = apppuStack_a8;
            if (7 < uStack_94) {
              pppuStack_154 = apppuStack_a8[0];
            }
            puStack_158 = (undefined1 *)0x63c3ea;
            FUN_0058ed10();
          }
          if ((undefined4 ****)(iVar4 + 0x38) != apppuStack_90) {
            pppuStack_150 = (undefined4 ***)uStack_80;
            pppuStack_154 = apppuStack_90;
            if (7 < uStack_7c) {
              pppuStack_154 = apppuStack_90[0];
            }
            puStack_158 = (undefined1 *)0x63c40b;
            FUN_0058ed10();
          }
          pppuStack_150 = (undefined4 ***)0x63c416;
          FUN_00637a50();
          pppuStack_150 = (undefined4 ***)0x63c421;
          FUN_0056e380();
          pppuStack_150 = (undefined4 ****)0x63c42c;
          FUN_0056e380();
          uStack_8._0_1_ = 0xe;
          if (7 < uStack_fc) {
            ppppuVar6 = (undefined4 ****)(uStack_fc * 2 + 2);
            ppppuVar7 = (undefined4 ****)pppuStack_110;
            if ((undefined4 ****)0xfff < ppppuVar6) {
              ppppuVar7 = (undefined4 ****)pppuStack_110[-1];
              ppppuVar6 = (undefined4 ****)(uStack_fc * 2 + 0x25);
              uVar1 = (undefined)uStack_8;
              if ((undefined1 *)0x1f < (undefined1 *)((int)pppuStack_110 + (-4 - (int)ppppuVar7)))
              goto LAB_0063c6c4;
            }
            puStack_158 = (undefined1 *)0x63c46d;
            pppuStack_154 = ppppuVar7;
            pppuStack_150 = ppppuVar6;
            FUN_01674ea0();
          }
          uStack_fc = 7;
          pppuStack_110 = (undefined4 ***)((uint)pppuStack_110 & 0xffff0000);
          if (7 < uStack_114) {
            ppppuVar6 = (undefined4 ****)(uStack_114 * 2 + 2);
            ppppuVar7 = (undefined4 ****)pppuStack_128;
            if ((undefined4 ****)0xfff < ppppuVar6) {
              ppppuVar7 = (undefined4 ****)pppuStack_128[-1];
              ppppuVar6 = (undefined4 ****)(uStack_114 * 2 + 0x25);
              uVar1 = (undefined)uStack_8;
              if ((undefined1 *)0x1f < (undefined1 *)((int)pppuStack_128 + (-4 - (int)ppppuVar7)))
              goto LAB_0063c6c4;
            }
            puStack_158 = (undefined1 *)0x63c4ca;
            pppuStack_154 = ppppuVar7;
            pppuStack_150 = ppppuVar6;
            FUN_01674ea0();
          }
          uStack_114 = 7;
          pppuStack_128 = (undefined4 ***)((uint)pppuStack_128 & 0xffff0000);
          uStack_8._0_1_ = 0xc;
          if (7 < uStack_1c) {
            ppppuVar6 = (undefined4 ****)(uStack_1c * 2 + 2);
            ppppuVar7 = (undefined4 ****)apppuStack_30[0];
            if ((undefined4 ****)0xfff < ppppuVar6) {
              ppppuVar7 = (undefined4 ****)apppuStack_30[0][-1];
              ppppuVar6 = (undefined4 ****)(uStack_1c * 2 + 0x25);
              uVar1 = (undefined)uStack_8;
              if ((undefined1 *)0x1f < (undefined1 *)((int)apppuStack_30[0] + (-4 - (int)ppppuVar7))
                 ) goto LAB_0063c6c4;
            }
            puStack_158 = (undefined1 *)0x63c525;
            pppuStack_154 = ppppuVar7;
            pppuStack_150 = ppppuVar6;
            FUN_01674ea0();
          }
          iStack_20 = 0;
          uStack_1c = 7;
          apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffff0000);
          uStack_8._0_1_ = 0xb;
          if (7 < uStack_b4) {
            ppppuVar6 = (undefined4 ****)(uStack_b4 * 2 + 2);
            ppppuVar7 = (undefined4 ****)pppuStack_c8;
            if ((undefined4 ****)0xfff < ppppuVar6) {
              ppppuVar7 = (undefined4 ****)pppuStack_c8[-1];
              ppppuVar6 = (undefined4 ****)(uStack_b4 * 2 + 0x25);
              uVar1 = (undefined)uStack_8;
              if ((undefined1 *)0x1f < (undefined1 *)((int)pppuStack_c8 + (-4 - (int)ppppuVar7)))
              goto LAB_0063c6c4;
            }
            puStack_158 = (undefined1 *)0x63c57d;
            pppuStack_154 = ppppuVar7;
            pppuStack_150 = ppppuVar6;
            FUN_01674ea0();
          }
          uStack_b8 = 0;
          uStack_b4 = 7;
          pppuStack_c8 = (undefined4 ***)((uint)pppuStack_c8 & 0xffff0000);
          uStack_8._0_1_ = 7;
          if (0xf < uStack_cc) {
            ppppuVar7 = (undefined4 ****)(uStack_cc + 1);
            ppppuVar6 = (undefined4 ****)apppuStack_e0[0];
            if ((undefined4 ****)0xfff < ppppuVar7) {
              ppppuVar6 = (undefined4 ****)apppuStack_e0[0][-1];
              ppppuVar7 = (undefined4 ****)(uStack_cc + 0x24);
              uVar1 = (undefined)uStack_8;
              if ((undefined1 *)0x1f < (undefined1 *)((int)apppuStack_e0[0] + (-4 - (int)ppppuVar6))
                 ) goto LAB_0063c6c4;
            }
            puStack_158 = (undefined1 *)0x63c5d8;
            pppuStack_154 = ppppuVar6;
            pppuStack_150 = ppppuVar7;
            FUN_01674ea0();
          }
          uStack_d0 = 0;
          uStack_cc = 0xf;
          apppuStack_e0[0] = (undefined4 ***)((uint)apppuStack_e0[0] & 0xffffff00);
          uStack_8._0_1_ = 6;
          if (7 < uStack_e4) {
            uVar5 = uStack_e4 * 2 + 2;
            ppppuVar6 = (undefined4 ****)apppuStack_f8[0];
            if (0xfff < uVar5) {
              ppppuVar6 = (undefined4 ****)apppuStack_f8[0][-1];
              uVar5 = uStack_e4 * 2 + 0x25;
              uVar1 = (undefined)uStack_8;
              if ((undefined1 *)0x1f < (undefined1 *)((int)apppuStack_f8[0] + (-4 - (int)ppppuVar6))
                 ) goto LAB_0063c6c4;
            }
            puStack_158 = (undefined1 *)0x63c637;
            pppuStack_154 = ppppuVar6;
            pppuStack_150 = (undefined4 ***)uVar5;
            FUN_01674ea0();
          }
          uStack_e8 = 0;
          uStack_e4 = 7;
          apppuStack_f8[0] = (undefined4 ***)((uint)apppuStack_f8[0] & 0xffff0000);
        }
        pppuStack_150 = (undefined4 ***)0x63c65f;
        FUN_0056e380();
        pppuStack_150 = (undefined4 ****)0x63c667;
        FUN_0056e380();
      }
      uStack_8._0_1_ = 0xff;
      uStack_8._1_3_ = 0xffffff;
      if (7 < uStack_50) {
        uVar5 = uStack_50 * 2 + 2;
        iVar4 = aiStack_64[0];
        if (0xfff < uVar5) {
          iVar4 = *(int *)(aiStack_64[0] + -4);
          uVar5 = uStack_50 * 2 + 0x25;
          uVar1 = (undefined)uStack_8;
          if (0x1f < (aiStack_64[0] - iVar4) - 4U) {
LAB_0063c6c4:
            uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        puStack_158 = (undefined1 *)0x63c6a1;
        pppuStack_154 = (undefined4 ***)iVar4;
        pppuStack_150 = (undefined4 ***)uVar5;
        FUN_01674ea0();
      }
      ppppuVar9 = ppppuVar9 + 6;
    } while (ppppuVar9 != (undefined4 ****)param_1[1]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7136 ; VA 0x0063c6d0 ; FUN_0063c6d0 */

void FUN_0063c6d0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_0063cc40();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 7137 ; VA 0x0063c710 ; FUN_0063c710 */

uint __fastcall FUN_0063c710(uint *param_1)

{
  uint uVar1;
  
  do {
    param_1[1] = param_1[1] - 1;
    *(char *)param_1[1] = (char)((ulonglong)*param_1 % 10) + *(char *)(param_1 + 3);
    uVar1 = *param_1;
    *param_1 = uVar1 / 10;
  } while (uVar1 / 10 != 0);
  return param_1[1];
}



/* FUNCTION 7138 ; VA 0x0063c740 ; FUN_0063c740 */

uint * __thiscall FUN_0063c740(int param_1,uint *param_2)

{
  undefined8 uVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  bool bVar7;
  char *pcVar8;
  uint *puVar9;
  uint uVar10;
  char *pcVar11;
  uint uVar12;
  uint auStack_44 [4];
  int iStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0229;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 == 0) {
    iStack_34 = iVar3;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    puVar9 = auStack_44;
    bVar7 = true;
    bVar6 = false;
    ExceptionList = &pvStack_10;
  }
  else {
    pcVar11 = *(char **)(iVar3 + 0x18);
    if (pcVar11 == (char *)0x0) {
      pcVar11 = (char *)(iVar3 + 0x1c);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    pcVar8 = pcVar11;
    do {
      cVar2 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar2 != '\0');
    ExceptionList = &pvStack_10;
    FUN_005542c0(pcVar11,(int)pcVar8 - (int)(pcVar11 + 1));
    puVar9 = auStack_2c;
    bVar7 = false;
    bVar6 = true;
  }
  uVar10 = *puVar9;
  uVar12 = puVar9[1];
  uVar4 = puVar9[2];
  uVar5 = puVar9[3];
  param_2[4] = 0;
  param_2[5] = 0;
  *param_2 = uVar10;
  param_2[1] = uVar12;
  param_2[2] = uVar4;
  param_2[3] = uVar5;
  uVar1 = *(undefined8 *)(puVar9 + 4);
  puVar9[4] = 0;
  puVar9[5] = 0xf;
  *(undefined8 *)(param_2 + 4) = uVar1;
  *(undefined *)puVar9 = 0;
  if (bVar6) {
    if (0xf < uStack_18) {
      uVar12 = uStack_18 + 1;
      uVar10 = auStack_2c[0];
      if (0xfff < uVar12) {
        uVar10 = *(uint *)(auStack_2c[0] - 4);
        uVar12 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar12);
    }
  }
  if ((bVar7) && (0xf < uStack_30)) {
    uVar12 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar12) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar12 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar12);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7139 ; VA 0x0063c890 ; FUN_0063c890 */

void __thiscall FUN_0063c890(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined **ppuVar5;
  undefined **ppuVar6;
  int iStack_8;
  
  iStack_8 = param_1;
  puVar4 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
    iStack_8 = 0;
  }
  else {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::
              _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>
              ::vftable;
    *(undefined *)(puVar4 + 3) = 0;
    iStack_8 = 0xb;
    ppuVar5 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_8);
    ppuVar6 = ppuVar5 + -1;
    if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar6 = ppuVar5;
    }
    puVar4[4] = *ppuVar6;
    puVar4[5] = 0;
    puVar4[6] = 0x3f800000;
    puVar4[7] = 0;
    puVar4[8] = 0;
  }
  *(int *)(param_1 + 0x10) = (int)(puVar4 + 3);
  piVar2 = *(int **)(param_1 + 0x14);
  *(undefined4 **)(param_1 + 0x14) = puVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0098f070(param_2,(int *)(param_1 + 0x10),0);
  return;
}



/* FUNCTION 7140 ; VA 0x0063c960 ; FUN_0063c960 */

void __fastcall FUN_0063c960(int param_1)

{
  int *piVar1;
  
  piVar1 = (int *)(param_1 + 0x10);
  *piVar1 = *piVar1 + -1;
  if (*piVar1 == 0) {
    *(undefined4 *)(param_1 + 0xc) = 0;
    return;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 1;
  return;
}



/* FUNCTION 7141 ; VA 0x0063c980 ; FUN_0063c980 */

void __thiscall FUN_0063c980(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *param_2 = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
    return;
  }
  FUN_006335f0(puVar1,param_2);
  return;
}



/* FUNCTION 7142 ; VA 0x0063c9b0 ; FUN_0063c9b0 */

void FUN_0063c9b0(void)

{
  FUN_0063c9c0();
  return;
}



/* FUNCTION 7143 ; VA 0x0063c9c0 ; FUN_0063c9c0 */

void __fastcall FUN_0063c9c0(int param_1)

{
  undefined auStack_38 [52];
  
  FUN_00636f40(param_1 + -0x30,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_38,&DAT_01c2ba38);
}



/* FUNCTION 7144 ; VA 0x0063c9f0 ; FUN_0063c9f0 */

int __fastcall FUN_0063c9f0(int param_1)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined auStack_54 [12];
  undefined4 uStack_48;
  int *piStack_44;
  int **ppiStack_40;
  undefined auStack_30 [4];
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0270;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((-(uint)(*(int *)(param_1 + 0xc) != 0) & *(int *)(param_1 + 0xc) + 0xcU) == 0) {
LAB_0063cbea:
    ppiStack_40 = (int **)0x18cef58;
    piStack_44 = (int *)0x3;
    uStack_48 = 0x63cbf6;
    iVar4 = FUN_0086f2f0();
    ExceptionList = pvStack_10;
    return iVar4;
  }
  ppiStack_40 = (int **)0x63ca27;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_006357d0();
  if (iVar4 == 0) goto LAB_0063cbea;
  ppiStack_40 = (int **)&iStack_28;
  piStack_44 = (int *)0x63ca3a;
  FUN_00b5efb0();
  uStack_8 = 0;
  if (iStack_28 == 0) {
    ppiStack_40 = (int **)0x18cef78;
    piStack_44 = (int *)0x3;
    uStack_48 = 0x63ca56;
    iVar4 = FUN_0086f2f0();
    goto LAB_0063cbb4;
  }
  if (DAT_01d5a2d8 == '\0') {
LAB_0063ca74:
    ppiStack_40 = &piStack_20;
    piStack_44 = (int *)0x63ca7d;
    FUN_00634770();
    ppiStack_40 = (int **)&DAT_01d5a360;
    uStack_8._0_1_ = 1;
    piStack_44 = (int *)0x63ca91;
    (**(code **)(*piStack_20 + 0x38))();
    ppiStack_40 = (int **)iStack_28;
    piStack_44 = (int *)0x63ca9c;
    piStack_44 = (int *)FUN_00635790();
    ppiStack_40 = (int **)0x0;
    uStack_48 = 0x63caa9;
    FUN_008a65e0();
    puStack_14 = auStack_54;
    FUN_0054ef60(&DAT_01d5a390);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&DAT_01d5a378);
    uStack_8._0_1_ = 1;
    FUN_00639c70(auStack_30);
    ppiStack_40 = (int **)0x0;
    piStack_44 = piStack_20;
    uStack_8._0_1_ = 3;
    uStack_48 = 0x63caee;
    FUN_008a65e0();
    piVar2 = piStack_2c;
    uStack_8._0_1_ = 1;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppiStack_40 = (int **)0x63cb08;
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppiStack_40 = (int **)0x63cb18;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    puStack_18 = auStack_54;
    FUN_0054ef60(&DAT_01d5a3c0);
    uStack_8._0_1_ = 4;
    FUN_0054ef60(&DAT_01d5a3a8);
    uStack_8._0_1_ = 1;
    FUN_00639c70(auStack_30);
    ppiStack_40 = (int **)0x0;
    piStack_44 = piStack_20;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    uStack_48 = 0x63cb5d;
    FUN_008a65e0();
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppiStack_40 = (int **)0x63cb73;
        (**(code **)*piStack_2c)();
        LOCK();
        iVar4 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppiStack_40 = (int **)0x63cb83;
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppiStack_40 = (int **)0x63cb9d;
        (**(code **)*piStack_1c)();
        LOCK();
        iVar4 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppiStack_40 = (int **)0x63cbad;
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  else {
    ppiStack_40 = (int **)0x63ca6c;
    cVar3 = FUN_00b74e80();
    if (cVar3 == '\0') goto LAB_0063ca74;
  }
  ppiStack_40 = (int **)0x63cbb4;
  iVar4 = FUN_006394c0();
LAB_0063cbb4:
  if (piStack_24 == (int *)0x0) {
    ExceptionList = pvStack_10;
    return iVar4;
  }
  LOCK();
  piVar2 = piStack_24 + 1;
  iVar4 = *piVar2;
  iVar5 = *piVar2;
  *piVar2 = iVar4 + -1;
  UNLOCK();
  if (iVar4 + -1 != 0) {
    ExceptionList = pvStack_10;
    return iVar5;
  }
  ppiStack_40 = (int **)0x63cbca;
  iVar5 = (**(code **)*piStack_24)();
  LOCK();
  piVar2 = piStack_24 + 2;
  iVar4 = *piVar2;
  *piVar2 = *piVar2 + -1;
  UNLOCK();
  if (iVar4 != 1) {
    ExceptionList = pvStack_10;
    return iVar5;
  }
  ppiStack_40 = (int **)0x63cbd9;
  iVar4 = (**(code **)(*piStack_24 + 4))();
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 7145 ; VA 0x0063cc10 ; FUN_0063cc10 */

void __thiscall FUN_0063cc10(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0xee) = param_2;
  return;
}



/* FUNCTION 7146 ; VA 0x0063cc20 ; FUN_0063cc20 */

void __thiscall FUN_0063cc20(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0x2f8) = param_2;
  *(undefined4 *)(param_1 + 0x2fc) = param_3;
  return;
}



/* FUNCTION 7147 ; VA 0x0063cc40 ; FUN_0063cc40 */

undefined * FUN_0063cc40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a028c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead5ec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead5ec);
    if (DAT_01ead5ec == -1) {
      uStack_8 = 0;
      FUN_008e7010();
      FUN_016f3654(&LAB_0187cbb0);
      FUN_016f37bf(&DAT_01ead5ec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ead588;
}



/* FUNCTION 7148 ; VA 0x0063ccd0 ; FUN_0063ccd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0063ccd0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead624) {
    FUN_016f3809(&DAT_01ead624);
    if (DAT_01ead624 == -1) {
      _DAT_01ead618 = FUN_005c65e0;
      _DAT_01ead61c = FUN_005c65e0;
      _DAT_01ead620 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead624);
    }
  }
  return &DAT_01ead618;
}



/* FUNCTION 7149 ; VA 0x0063cd40 ; FUN_0063cd40 */

int FUN_0063cd40(int param_1,undefined4 param_2,int *param_3)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int aiStack_a8 [5];
  uint uStack_94;
  undefined auStack_88 [8];
  int aiStack_80 [5];
  uint uStack_6c;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a02db;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00635950(-(uint)(param_1 != 0) & param_1 + 0xcU);
  if (iVar2 != 0) {
    uVar3 = FUN_00b74d10();
    FUN_00637260(uVar3);
    uStack_8 = 1;
    for (iVar8 = iStack_20; iVar8 != iStack_1c; iVar8 = iVar8 + 0x18) {
      FUN_005f3cd0(aiStack_80,iVar8,&DAT_01d5a348);
      uStack_8 = 2;
      uVar3 = FUN_0151a8d0(auStack_68,aiStack_80);
      uStack_8 = 3;
      FUN_0054f050(uVar3);
      uStack_8 = 5;
      if (7 < uStack_54) {
        uVar7 = uStack_54 * 2 + 2;
        uVar5 = auStack_68[0];
        if (0xfff < uVar7) {
          uVar5 = *(uint *)(auStack_68[0] - 4);
          uVar7 = uStack_54 * 2 + 0x25;
          if (0x1f < (auStack_68[0] - uVar5) - 4) goto LAB_0063d026;
        }
        FUN_01674ea0(uVar5,uVar7);
      }
      uStack_58 = 0;
      auStack_68[0] = auStack_68[0] & 0xffff0000;
      uStack_54 = 7;
      piVar4 = (int *)FUN_0168e1c0(auStack_88,auStack_50,0);
      if ((*piVar4 == 0) || (*piVar4 == 1)) {
        bVar1 = false;
      }
      else {
        bVar1 = true;
      }
      if (bVar1) {
        uVar3 = FUN_0151a8d0(aiStack_a8,iVar8);
        uStack_8 = 6;
        FUN_0054f050(uVar3);
        uStack_8 = 7;
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        FUN_00638610(iVar2,auStack_38,param_2,param_3,1,0);
        uStack_8 = 6;
        if (7 < uStack_24) {
          uVar7 = uStack_24 * 2 + 2;
          uVar5 = auStack_38[0];
          if (0xfff < uVar7) {
            uVar5 = *(uint *)(auStack_38[0] - 4);
            uVar7 = uStack_24 * 2 + 0x25;
            if (0x1f < (auStack_38[0] - uVar5) - 4) goto LAB_0063d026;
          }
          FUN_01674ea0(uVar5,uVar7);
        }
        uStack_28 = 0;
        uStack_24 = 7;
        auStack_38[0] = auStack_38[0] & 0xffff0000;
        uStack_8 = 5;
        if (7 < uStack_94) {
          uVar7 = uStack_94 * 2 + 2;
          iVar6 = aiStack_a8[0];
          if (0xfff < uVar7) {
            iVar6 = *(int *)(aiStack_a8[0] + -4);
            uVar7 = uStack_94 * 2 + 0x25;
            if (0x1f < (aiStack_a8[0] - iVar6) - 4U) goto LAB_0063d026;
          }
          FUN_01674ea0(iVar6,uVar7);
        }
      }
      uStack_8 = 2;
      if (7 < uStack_3c) {
        uVar7 = uStack_3c * 2 + 2;
        uVar5 = auStack_50[0];
        if (0xfff < uVar7) {
          uVar5 = *(uint *)(auStack_50[0] - 4);
          uVar7 = uStack_3c * 2 + 0x25;
          if (0x1f < (auStack_50[0] - uVar5) - 4) goto LAB_0063d026;
        }
        FUN_01674ea0(uVar5,uVar7);
      }
      uStack_40 = 0;
      uStack_3c = 7;
      auStack_50[0] = auStack_50[0] & 0xffff0000;
      uStack_8 = 1;
      if (0xf < uStack_6c) {
        uVar7 = uStack_6c + 1;
        iVar6 = aiStack_80[0];
        if (0xfff < uVar7) {
          iVar6 = *(int *)(aiStack_80[0] + -4);
          uVar7 = uStack_6c + 0x24;
          if (0x1f < (aiStack_80[0] - iVar6) - 4U) {
LAB_0063d026:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar6,uVar7);
      }
    }
    iVar2 = FUN_00577a40();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar4 = param_3 + 1;
    iVar8 = *piVar4;
    iVar2 = *piVar4;
    *piVar4 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      iVar2 = (**(code **)*param_3)();
      LOCK();
      piVar4 = param_3 + 2;
      iVar8 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        iVar2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 7150 ; VA 0x0063d030 ; FUN_0063d030 */

char * FUN_0063d030(void)

{
  return "bad lexical cast: source type value could not be interpreted as target";
}



/* FUNCTION 7151 ; VA 0x0063d040 ; FUN_0063d040 */

int * __thiscall FUN_0063d040(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0310;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_3;
  piStack_18 = param_1;
  if (param_4 != (int *)0x0) {
    piVar1 = param_4 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar3 = param_4[2] + -1;
    param_4[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  piVar1 = param_4 + 2;
  uStack_24 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_20 = uStack_14;
  piStack_1c = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar3 = param_4[2] + -1;
    param_4[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  uStack_8._0_1_ = 1;
  iVar3 = FUN_0063f8c0(&uStack_24);
  *param_1 = iVar3;
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[2] + -1;
    piStack_1c[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  cVar2 = FUN_0168a8f0();
  if (cVar2 != '\0') {
    if (param_4 != (int *)0x0) {
      LOCK();
      piVar1 = param_4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar4 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar4);
}



/* FUNCTION 7152 ; VA 0x0063d170 ; FUN_0063d170 */

undefined * __thiscall FUN_0063d170(undefined *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = (char *)*param_2;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  *(double *)(param_1 + 0x18) = (double)(int)param_2[1];
  return param_1;
}



/* FUNCTION 7153 ; VA 0x0063d1d0 ; FUN_0063d1d0 */

undefined * __thiscall FUN_0063d1d0(undefined *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = (char *)*param_2;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  *(double *)(param_1 + 0x18) =
       (double)(int)param_2[1] + (double)(&DAT_018c0d90)[-((int)param_2[1] >> 0x1f)];
  return param_1;
}



/* FUNCTION 7154 ; VA 0x0063d230 ; FUN_0063d230 */

undefined * __thiscall FUN_0063d230(undefined *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = (char *)*param_2;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  *(undefined8 *)(param_1 + 0x18) = *(undefined8 *)(param_2 + 2);
  return param_1;
}



/* FUNCTION 7155 ; VA 0x0063d280 ; FUN_0063d280 */

undefined4 * __thiscall
FUN_0063d280(undefined4 *param_1,int param_2,int param_3,undefined4 *param_4,undefined4 param_5,
            uint param_6,undefined4 param_7)

{
  uint uVar1;
  undefined4 uVar2;
  undefined **ppuVar3;
  undefined4 ***pppuVar4;
  undefined *puStack_58;
  undefined4 **ppuStack_54;
  undefined4 **ppuStack_50;
  undefined4 **ppuStack_4c;
  undefined4 **appuStack_3c [2];
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 **appuStack_2c [2];
  uint uStack_24;
  undefined4 uStack_20;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_6;
  puStack_c = &LAB_017a0340;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = param_6;
  appuStack_3c[0] = (undefined4 ***)0x0;
  puStack_18 = param_1;
  if (param_6 < 9) {
    ppuStack_54 = appuStack_3c;
    ppuStack_50 = &param_4;
    ExceptionList = &pvStack_10;
  }
  else {
    ppuStack_4c = (undefined4 **)param_6;
    ppuStack_50 = (undefined4 **)0x63d2ca;
    ExceptionList = &pvStack_10;
    ppuStack_54 = (undefined4 **)FUN_01674e20();
    ppuStack_50 = (undefined4 **)param_4;
    appuStack_3c[0] = ppuStack_54;
  }
  ppuStack_4c = (undefined4 **)uVar1;
  puStack_58 = (undefined *)0x63d2db;
  FUN_0170c6f0();
  uVar1 = uStack_34;
  uVar2 = param_7;
  uStack_14 = param_7;
  uStack_30 = param_7;
  uStack_8._0_1_ = 1;
  uStack_24 = uStack_34;
  appuStack_2c[0] = (undefined4 ***)0x0;
  if (uStack_34 < 9) {
    ppuStack_54 = appuStack_2c;
    ppuStack_50 = appuStack_3c;
  }
  else {
    ppuStack_4c = (undefined4 **)uStack_34;
    ppuStack_50 = (undefined4 **)0x63d30b;
    ppuStack_54 = (undefined4 **)FUN_01674e20();
    ppuStack_50 = appuStack_3c[0];
    appuStack_2c[0] = ppuStack_54;
  }
  ppuStack_4c = (undefined4 **)uVar1;
  puStack_58 = (undefined *)0x63d31c;
  FUN_0170c6f0();
  uStack_20 = uVar2;
  *param_1 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_1c = (undefined *)&puStack_58;
  ppuVar3 = &puStack_58;
  ppuStack_50 = (undefined4 **)uStack_24;
  puStack_58 = (undefined *)0x0;
  if (uStack_24 < 9) {
    pppuVar4 = appuStack_2c;
    puStack_1c = (undefined *)&puStack_58;
  }
  else {
    ppuVar3 = (undefined **)FUN_01674e20(uStack_24);
    pppuVar4 = (undefined4 ***)appuStack_2c[0];
    puStack_58 = (undefined *)ppuVar3;
  }
  FUN_0170c6f0(ppuVar3,pppuVar4,ppuStack_50);
  ppuStack_4c = (undefined4 **)uStack_14;
  FUN_0063e950();
  if ((8 < uStack_24) && ((undefined4 ***)appuStack_2c[0] != (undefined4 ***)0x0)) {
    ppuStack_4c = appuStack_2c[0];
    ppuStack_50 = (undefined4 **)0x63d385;
    FUN_01674ea0();
  }
  if ((8 < uVar1) && ((undefined4 ***)appuStack_3c[0] != (undefined4 ***)0x0)) {
    ppuStack_4c = appuStack_3c[0];
    ppuStack_50 = (undefined4 **)0x63d39a;
    FUN_01674ea0();
  }
  param_1[8] = param_2;
  param_1[9] = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  param_1[10] = param_2;
  param_1[0xb] = param_3;
  *(undefined *)(param_1 + 0xc) = 0;
  if (param_2 != param_3) {
    ppuStack_4c = (undefined4 **)0x63d3c2;
    FUN_00645080();
  }
  if ((8 < param_6) && (param_4 != (undefined4 *)0x0)) {
    ppuStack_4c = (undefined4 **)param_4;
    ppuStack_50 = (undefined4 **)0x63d3d5;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7156 ; VA 0x0063d3f0 ; FUN_0063d3f0 */

undefined4 * __thiscall
FUN_0063d3f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  FUN_0063eca0(param_2,param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 7157 ; VA 0x0063d480 ; FUN_0063d480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0063d480(undefined4 *param_1,undefined8 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead488) {
    FUN_016f3809(&DAT_01ead488);
    if (DAT_01ead488 == -1) {
      _DAT_01ead47c = FUN_00619e80;
      _DAT_01ead480 = FUN_00619e80;
      DAT_01ead484 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead488);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01ead47c) {
    *(undefined8 *)(param_1 + 1) = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  *(undefined8 *)(param_1 + 1) = *param_2;
  *param_1 = &DAT_01ead47c;
  return param_1;
}



/* FUNCTION 7158 ; VA 0x0063d540 ; FUN_0063d540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0063d540(undefined4 *param_1,undefined8 *param_2)

{
  undefined *puVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_0088ca00();
  iVar2 = _tls_index;
  *param_1 = uVar3;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ead488) {
    FUN_016f3809(&DAT_01ead488);
    if (DAT_01ead488 == -1) {
      _DAT_01ead47c = FUN_00619e80;
      _DAT_01ead480 = FUN_00619e80;
      DAT_01ead484 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead488);
    }
  }
  puVar1 = (undefined *)param_1[1];
  if (puVar1 == &DAT_01ead47c) {
    *(undefined8 *)(param_1 + 2) = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  *(undefined8 *)(param_1 + 2) = *param_2;
  param_1[1] = &DAT_01ead47c;
  return param_1;
}



/* FUNCTION 7159 ; VA 0x0063d600 ; FUN_0063d600 */

undefined4 * FUN_0063d600(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar4 = (undefined4 *)FUN_00585d40(0,param_2,*puVar4);
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  return param_1;
}



/* FUNCTION 7160 ; VA 0x0063d660 ; FUN_0063d660 */

undefined4 __thiscall FUN_0063d660(char *param_1,char param_2)

{
  char *pcVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = *(uint *)(param_1 + 8);
  if (8 < uVar3) {
    param_1 = *(char **)param_1;
  }
  pcVar1 = param_1 + uVar3;
  while (uVar2 = uVar3, 0 < (int)uVar2) {
    uVar3 = (int)uVar2 >> 1;
    if (param_1[uVar3] < param_2) {
      param_1 = param_1 + uVar3 + 1;
      uVar3 = uVar2 + (-1 - uVar3);
    }
  }
  if ((param_1 != pcVar1) && (*param_1 <= param_2)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 7161 ; VA 0x0063d6c0 ; FUN_0063d6c0 */

/* WARNING: Type propagation algorithm not settling */

undefined4 * __thiscall FUN_0063d6c0(char *param_1,undefined4 *param_2,char *param_3,char *param_4)

{
  char *pcVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  char *******pppppppcVar5;
  char *pcVar6;
  int iVar7;
  uint uVar8;
  char *******apppppppcStack_24 [2];
  uint uStack_1c;
  char *******pppppppcStack_14;
  char *pcStack_10;
  char *pcStack_c;
  
  apppppppcStack_24[0] = (char *******)0x0;
  uVar2 = *(uint *)(param_1 + 8);
  uStack_1c = uVar2;
  pcStack_10 = param_1;
  if (uVar2 < 9) {
    pppppppcVar5 = (char *******)apppppppcStack_24;
    pcVar6 = param_1;
  }
  else {
    pppppppcVar5 = (char *******)FUN_01674e20(uVar2);
    pcVar6 = *(char **)param_1;
    apppppppcStack_24[0] = pppppppcVar5;
  }
  FUN_0170c6f0(pppppppcVar5,pcVar6,uVar2);
  pcStack_c = param_3;
  if (param_3 != param_4) {
    do {
      pppppppcVar5 = (char *******)apppppppcStack_24;
      if (8 < uStack_1c) {
        pppppppcVar5 = apppppppcStack_24[0];
      }
      pppppppcStack_14 = (char *******)((int)pppppppcVar5 + uStack_1c);
      iVar7 = (int)pppppppcStack_14 - (int)pppppppcVar5;
      while (iVar3 = iVar7, 0 < iVar3) {
        iVar7 = iVar3 >> 1;
        if (*(char *)((int)pppppppcVar5 + iVar7) < *pcStack_c) {
          pppppppcVar5 = (char *******)((int)pppppppcVar5 + iVar7 + 1);
          iVar7 = iVar3 + (-1 - iVar7);
        }
      }
      param_1 = pcStack_10;
    } while (((pppppppcVar5 == pppppppcStack_14) || (*pcStack_c < *(char *)pppppppcVar5)) &&
            (pcStack_c = pcStack_c + 1, pcStack_c != param_4));
  }
  if ((8 < uStack_1c) && (apppppppcStack_24[0] != (char *******)0x0)) {
    FUN_01674ea0(apppppppcStack_24[0]);
  }
  if (pcStack_c != param_4) {
    if (*(int *)(param_1 + 0xc) != 0) {
      param_2[1] = pcStack_c + 1;
      *param_2 = pcStack_c;
      return param_2;
    }
    uVar2 = *(uint *)(param_1 + 8);
    pcVar6 = pcStack_c;
    do {
      if (8 < uVar2) {
        param_1 = *(char **)param_1;
      }
      pcVar1 = param_1 + uVar2;
      uVar8 = uVar2;
      while (uVar4 = uVar8, 0 < (int)uVar4) {
        uVar8 = (int)uVar4 >> 1;
        if (param_1[uVar8] < *pcVar6) {
          param_1 = param_1 + uVar8 + 1;
          uVar8 = uVar4 + (-1 - uVar8);
        }
      }
    } while (((param_1 != pcVar1) && (*param_1 <= *pcVar6)) &&
            (pcVar6 = pcVar6 + 1, param_1 = pcStack_10, pcVar6 != param_4));
    param_2[1] = pcVar6;
    *param_2 = pcStack_c;
    return param_2;
  }
  *param_2 = param_4;
  param_2[1] = param_4;
  return param_2;
}



/* FUNCTION 7162 ; VA 0x0063d860 ; FUN_0063d860 */

int __thiscall FUN_0063d860(int *param_1,int param_2,char *param_3,undefined8 *param_4)

{
  uint uVar1;
  undefined *puVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0350;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  iVar5 = param_1[1] - iVar4 >> 5;
  if (iVar5 != 0x7ffffff) {
    uVar1 = iVar5 + 1;
    uVar6 = param_1[2] - iVar4 >> 5;
    uVar8 = uVar1;
    if (uVar6 <= 0x7ffffff - (uVar6 >> 1)) {
      uVar8 = (uVar6 >> 1) + uVar6;
      if (uVar8 < uVar1) {
        uVar8 = uVar1;
      }
    }
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00577f40(uVar8);
    uVar6 = param_2 - iVar4 & 0xffffffe0;
    *(undefined4 *)(uVar6 + 0x10 + iVar5) = 0;
    puVar2 = (undefined *)(uVar6 + iVar5);
    uStack_8 = 0;
    *(undefined4 *)(puVar2 + 0x14) = 0xf;
    *puVar2 = 0;
    pcVar7 = param_3;
    do {
      cVar3 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar3 != '\0');
    FUN_005542c0(param_3,(int)pcVar7 - (int)(param_3 + 1));
    *(undefined8 *)(puVar2 + 0x18) = *param_4;
    if (param_2 == param_1[1]) {
      FUN_0055c650(*param_1,param_1[1],iVar5,param_1);
    }
    else {
      FUN_0055c650(*param_1,param_2,iVar5,param_1);
      FUN_0055c650(param_2,param_1[1],puVar2 + 0x20,param_1);
    }
    FUN_00575c60(iVar5,uVar1,uVar8);
    ExceptionList = pvStack_10;
    return *param_1 + uVar6;
  }
  ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 7163 ; VA 0x0063d984 ; Catch_All@0063d984 */

void Catch_All_0063d984(void)

{
  int unaff_EBP;
  
  FUN_00576230(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7164 ; VA 0x0063d9b0 ; FUN_0063d9b0 */

int __thiscall FUN_0063d9b0(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  
  iVar2 = *param_1;
  iVar8 = param_2 - iVar2;
  iVar3 = param_1[1] - iVar2 >> 2;
  if (iVar3 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar6 = param_1[2] - iVar2 >> 2;
  uVar7 = uVar1;
  if ((uVar6 <= 0x3fffffff - (uVar6 >> 1)) && (uVar7 = (uVar6 >> 1) + uVar6, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  iVar4 = FUN_00577ed0(uVar7);
  iVar2 = (iVar8 >> 2) * 4;
  puVar5 = (undefined4 *)(iVar4 + iVar2);
  *puVar5 = *param_3;
  iVar3 = param_1[1];
  if (param_2 == iVar3) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar4,*param_1,iVar3 - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar4,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(puVar5 + 1,param_2,param_1[1] - param_2);
  }
  FUN_00601e00(iVar4,uVar1,uVar7);
  return *param_1 + iVar2;
}



/* FUNCTION 7165 ; VA 0x0063dac0 ; FUN_0063dac0 */

int __thiscall FUN_0063dac0(int *param_1,int *param_2,int *param_3)

{
  uint uVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  int *piVar11;
  int iVar12;
  
  iVar8 = *param_1;
  iVar12 = (int)param_2 - iVar8 >> 3;
  iVar5 = param_1[1] - iVar8 >> 3;
  if (iVar5 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar5 + 1;
  uVar9 = param_1[2] - iVar8 >> 3;
  uVar6 = uVar1;
  if ((uVar9 <= 0x1fffffff - (uVar9 >> 1)) && (uVar6 = (uVar9 >> 1) + uVar9, uVar6 < uVar1)) {
    uVar6 = uVar1;
  }
  uVar9 = uVar6 * 8;
  if (uVar6 < 0x20000000) {
    if (0xfff < uVar9) goto LAB_0063db32;
    if (uVar9 == 0) {
      piVar11 = (int *)0x0;
    }
    else {
      piVar11 = (int *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_0063db32:
    uVar7 = uVar9 + 0x23;
    if (uVar7 <= uVar9) {
      uVar7 = 0xffffffff;
    }
    iVar8 = FUN_01674e20(uVar7);
    if (iVar8 == 0) goto LAB_0063dc58;
    piVar11 = (int *)(iVar8 + 0x23U & 0xffffffe0);
    piVar11[-1] = iVar8;
  }
  iVar8 = *param_3;
  piVar11[iVar12 * 2] = iVar8;
  LOCK();
  piVar2 = (int *)(iVar8 + 0x28);
  *piVar2 = *piVar2 + 1;
  UNLOCK();
  iVar8 = param_3[1];
  piVar11[iVar12 * 2 + 1] = iVar8;
  LOCK();
  piVar2 = (int *)(iVar8 + 0x28);
  *piVar2 = *piVar2 + 1;
  UNLOCK();
  piVar2 = (int *)param_1[1];
  piVar10 = (int *)*param_1;
  piVar4 = piVar11;
  if (param_2 == piVar2) {
    for (; piVar10 != piVar2; piVar10 = piVar10 + 2) {
      iVar8 = *piVar10;
      *piVar4 = iVar8;
      LOCK();
      piVar3 = (int *)(iVar8 + 0x28);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
      iVar8 = piVar10[1];
      piVar4[1] = iVar8;
      LOCK();
      piVar3 = (int *)(iVar8 + 0x28);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
      piVar4 = piVar4 + 2;
    }
  }
  else {
    FUN_006429d0(piVar10,param_2,piVar11);
    FUN_006429d0(param_2,param_1[1],piVar11 + iVar12 * 2 + 2);
  }
  iVar8 = *param_1;
  if (iVar8 != 0) {
    iVar5 = param_1[1];
    if (iVar8 != iVar5) {
      do {
        FUN_0056cd30();
        FUN_0056cd30();
        iVar8 = iVar8 + 8;
      } while (iVar8 != iVar5);
      iVar8 = *param_1;
    }
    uVar9 = param_1[2] - iVar8 & 0xfffffff8;
    iVar5 = iVar8;
    if (0xfff < uVar9) {
      iVar5 = *(int *)(iVar8 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar8 - iVar5) - 4U) {
LAB_0063dc58:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar9);
  }
  *param_1 = (int)piVar11;
  param_1[1] = (int)(piVar11 + uVar1 * 2);
  param_1[2] = (int)(piVar11 + uVar6 * 2);
  return *param_1 + iVar12 * 8;
}



/* FUNCTION 7166 ; VA 0x0063dc70 ; FUN_0063dc70 */

void FUN_0063dc70(char *param_1,char *param_2,char *param_3)

{
  char *pcVar1;
  char cVar2;
  char *pcVar3;
  char cVar4;
  int iVar5;
  char *pcVar6;
  
  if ((int)param_3 - (int)param_1 < 0x29) {
    cVar4 = *param_2;
    if (cVar4 < *param_1) {
      *param_2 = *param_1;
      *param_1 = cVar4;
      cVar4 = *param_2;
    }
    cVar2 = *param_3;
    if (cVar2 < cVar4) {
      *param_3 = cVar4;
      *param_2 = cVar2;
      if (cVar2 < *param_1) {
        *param_2 = *param_1;
        *param_1 = cVar2;
      }
    }
  }
  else {
    iVar5 = ((int)param_3 - (int)param_1) + 1 >> 3;
    cVar4 = param_1[iVar5];
    pcVar1 = param_1 + iVar5;
    if (cVar4 < *param_1) {
      *pcVar1 = *param_1;
      *param_1 = cVar4;
      cVar4 = *pcVar1;
    }
    cVar2 = param_1[iVar5 * 2];
    if (cVar2 < cVar4) {
      param_1[iVar5 * 2] = cVar4;
      *pcVar1 = cVar2;
      if (cVar2 < *param_1) {
        *pcVar1 = *param_1;
        *param_1 = cVar2;
      }
    }
    pcVar3 = param_2 + -iVar5;
    cVar4 = *param_2;
    if (cVar4 < *pcVar3) {
      *param_2 = *pcVar3;
      *pcVar3 = cVar4;
      cVar4 = *param_2;
    }
    cVar2 = param_2[iVar5];
    if (cVar2 < cVar4) {
      param_2[iVar5] = cVar4;
      *param_2 = cVar2;
      if (cVar2 < *pcVar3) {
        *param_2 = *pcVar3;
        *pcVar3 = cVar2;
      }
    }
    pcVar3 = param_3 + -iVar5;
    pcVar6 = param_3 + iVar5 * -2;
    cVar4 = *pcVar3;
    if (cVar4 < *pcVar6) {
      *pcVar3 = *pcVar6;
      *pcVar6 = cVar4;
      cVar4 = *pcVar3;
    }
    cVar2 = *param_3;
    if (cVar2 < cVar4) {
      *param_3 = cVar4;
      *pcVar3 = cVar2;
      if (cVar2 < *pcVar6) {
        *pcVar3 = *pcVar6;
        *pcVar6 = cVar2;
      }
    }
    cVar4 = *param_2;
    if (cVar4 < *pcVar1) {
      *param_2 = *pcVar1;
      *pcVar1 = cVar4;
      cVar4 = *param_2;
    }
    cVar2 = *pcVar3;
    if (cVar2 < cVar4) {
      *pcVar3 = cVar4;
      *param_2 = cVar2;
      if (cVar2 < *pcVar1) {
        *param_2 = *pcVar1;
        *pcVar1 = cVar2;
        return;
      }
    }
  }
  return;
}



/* FUNCTION 7167 ; VA 0x0063dd70 ; FUN_0063dd70 */

void FUN_0063dd70(int param_1,int param_2,uint param_3,char *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = (int)(param_3 - 1) >> 1;
  iVar1 = param_2;
  iVar2 = param_2;
  if (param_2 < iVar3) {
    do {
      iVar2 = iVar1 * 2;
      iVar2 = (*(char *)(param_1 + 1 + iVar2) <= *(char *)(param_1 + 2 + iVar2)) + 1 + iVar2;
      *(undefined *)(param_1 + iVar1) = *(undefined *)(iVar2 + param_1);
      iVar1 = iVar2;
    } while (iVar2 < iVar3);
  }
  if ((iVar2 == iVar3) && ((param_3 & 1) == 0)) {
    *(undefined *)(param_1 + iVar2) = *(undefined *)(param_1 + -1 + param_3);
    iVar2 = param_3 - 1;
  }
  if (iVar2 <= param_2) {
    *(char *)(iVar2 + param_1) = *param_4;
    return;
  }
  do {
    iVar1 = iVar2 + -1 >> 1;
    if (*param_4 <= *(char *)(iVar1 + param_1)) break;
    *(char *)(iVar2 + param_1) = *(char *)(iVar1 + param_1);
    iVar2 = iVar1;
  } while (param_2 < iVar1);
  *(char *)(iVar2 + param_1) = *param_4;
  return;
}



/* FUNCTION 7168 ; VA 0x0063de10 ; FUN_0063de10 */

void __thiscall FUN_0063de10(int param_1,uint param_2)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  bool bVar4;
  undefined4 *puVar5;
  bool bVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  int *in_stack_00000024;
  int *in_stack_00000028;
  int *in_stack_0000002c;
  int *in_stack_00000030;
  char in_stack_00000034;
  uint in_stack_00000044;
  int *in_stack_00000064;
  int in_stack_00000068;
  int *in_stack_0000006c;
  int *in_stack_00000070;
  char in_stack_00000074;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined auStack_30 [8];
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0378;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffac;
  uStack_24 = 0;
  uStack_8 = 2;
  piStack_18 = in_stack_0000002c;
  piStack_1c = in_stack_00000028;
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
LAB_0063de58:
  do {
    if ((param_2 == 0) || (in_stack_00000034 != '\0')) {
      bVar6 = true;
    }
    else {
      bVar6 = false;
    }
    uStack_20 = in_stack_00000044;
    if ((in_stack_00000044 == 0) || (in_stack_00000074 != '\0')) {
      bVar4 = true;
    }
    else {
      bVar4 = false;
    }
    if ((bVar6) || (bVar4)) {
      bVar6 = (bool)(bVar4 ^ bVar6 ^ 1);
    }
    else {
      uVar7 = (int)piStack_1c - (int)in_stack_00000024;
      piVar2 = in_stack_00000024;
      piVar3 = in_stack_00000064;
      if (uVar7 == in_stack_00000068 - (int)in_stack_00000064) {
        while (uVar8 = uVar7 - 4, 3 < uVar7) {
          if (*piVar2 != *piVar3) goto LAB_0063deb6;
          piVar2 = piVar2 + 1;
          piVar3 = piVar3 + 1;
          uVar7 = uVar8;
        }
        if (uVar8 != 0xfffffffc) {
LAB_0063deb6:
          if ((*(char *)piVar2 != *(char *)piVar3) ||
             ((uVar8 != 0xfffffffd &&
              ((*(char *)((int)piVar2 + 1) != *(char *)((int)piVar3 + 1) ||
               ((uVar8 != 0xfffffffe &&
                ((*(char *)((int)piVar2 + 2) != *(char *)((int)piVar3 + 2) ||
                 ((uVar8 != 0xffffffff && (*(char *)((int)piVar2 + 3) != *(char *)((int)piVar3 + 3))
                  ))))))))))) goto LAB_0063defa;
        }
        if ((piStack_18 == in_stack_0000006c) && (in_stack_00000030 == in_stack_00000070)) {
          bVar6 = true;
          goto LAB_0063df05;
        }
      }
LAB_0063defa:
      bVar6 = false;
    }
LAB_0063df05:
    in_stack_00000028 = piStack_1c;
    in_stack_0000002c = piStack_18;
    if (bVar6) {
      uStack_8 = 6;
      if (((param_2 != 0) && ((param_2 & 1) == 0)) &&
         (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(param_2 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
      }
      uStack_8 = 7;
      if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
         (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_00000044 & 0xfffffffe))(&stack0x0000004c,&stack0x0000004c,2);
      }
      ExceptionList = pvStack_10;
      return;
    }
    uStack_48 = uStack_48 & 0xffffff00;
    uStack_38 = 0;
    uStack_34 = 0xf;
    if (in_stack_00000024 != piStack_1c) {
      FUN_005542c0(in_stack_00000024,(int)piStack_1c - (int)in_stack_00000024);
    }
    uVar7 = uStack_48;
    uStack_24 = uStack_24 | 0x1f;
    uStack_8._0_1_ = 4;
    puVar1 = *(uint **)(iStack_28 + 4);
    if (*(uint **)(iStack_28 + 8) == puVar1) {
      FUN_0058d0a0(puVar1,&uStack_48);
      uVar7 = uStack_34;
    }
    else {
      uStack_48 = uStack_48 & 0xffffff00;
      *puVar1 = uVar7;
      puVar1[1] = uStack_44;
      puVar1[2] = uStack_40;
      puVar1[3] = uStack_3c;
      puVar1[4] = uStack_38;
      puVar1[5] = uStack_34;
      *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 0x18;
      uVar7 = 0xf;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uVar7) {
      uVar9 = uVar7 + 1;
      uVar8 = uStack_48;
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(uStack_48 - 4);
        uVar9 = uVar7 + 0x24;
        if (0x1f < (uStack_48 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    if (param_2 == 0) {
      piStack_18 = in_stack_00000030;
      piStack_1c = in_stack_00000030;
    }
    else {
      puVar5 = (undefined4 *)
               (**(code **)((param_2 & 0xfffffffe) + 4))
                         (auStack_30,&stack0x0000000c,in_stack_0000002c,in_stack_00000030);
      piStack_1c = (int *)*puVar5;
      piStack_18 = (int *)puVar5[1];
      if ((piStack_1c != in_stack_00000030) || (piStack_18 != in_stack_00000030)) {
        in_stack_00000024 = in_stack_0000002c;
        goto LAB_0063de58;
      }
    }
    in_stack_00000024 = in_stack_0000002c;
    if (in_stack_00000028 == in_stack_00000030) {
      in_stack_00000034 = '\x01';
    }
  } while( true );
}



/* FUNCTION 7169 ; VA 0x0063e0a7 ; Catch_All@0063e0a7 */

void Catch_All_0063e0a7(void)

{
  FUN_00577a40();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7170 ; VA 0x0063e0c0 ; FUN_0063e0c0 */

int __thiscall FUN_0063e0c0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0390;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Security::AslrPmcSharedHasher>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 4) == 0 || (*(int *)(*(int *)(param_2 + 4) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)param_2 = param_2;
    piVar3 = *(int **)(param_2 + 4);
    *(int **)(param_2 + 4) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7171 ; VA 0x0063e193 ; Catch_All@0063e193 */

void Catch_All_0063e193(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00642210(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7172 ; VA 0x0063e1b0 ; FUN_0063e1b0 */

int __thiscall FUN_0063e1b0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a03a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::NetworkOwnerJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7173 ; VA 0x0063e284 ; Catch_All@0063e284 */

void Catch_All_0063e284(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7174 ; VA 0x0063e2a0 ; FUN_0063e2a0 */

int __thiscall FUN_0063e2a0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a03b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::RomarkPhaseTrackingJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7175 ; VA 0x0063e374 ; Catch_All@0063e374 */

void Catch_All_0063e374(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7176 ; VA 0x0063e390 ; FUN_0063e390 */

int __thiscall FUN_0063e390(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a03c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::ClusterPacketCache*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7177 ; VA 0x0063e462 ; Catch_All@0063e462 */

void Catch_All_0063e462(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7178 ; VA 0x0063e480 ; FUN_0063e480 */

int __thiscall FUN_0063e480(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a03d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::ServerReplicator*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7179 ; VA 0x0063e552 ; Catch_All@0063e552 */

void Catch_All_0063e552(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7180 ; VA 0x0063e570 ; FUN_0063e570 */

int __thiscall FUN_0063e570(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a03e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::StarterPlayerService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7181 ; VA 0x0063e642 ; Catch_All@0063e642 */

void Catch_All_0063e642(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7182 ; VA 0x0063e660 ; FUN_0063e660 */

void FUN_0063e660(char *param_1,char *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  char cVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  char *pcVar8;
  int iVar9;
  int iVar10;
  char *pcVar11;
  char *pcVar12;
  char *pcVar13;
  char *pcVar14;
  char *pcStack_c;
  char *pcStack_8;
  
  iVar10 = (int)param_2 - (int)param_1;
  pcVar13 = param_2;
  do {
    param_2 = pcVar13;
    if (iVar10 < 0x21) {
LAB_0063e7f2:
      if ((1 < iVar10) && (pcVar11 = param_1, param_1 != pcVar13)) {
        while (pcVar14 = pcVar11 + 1, pcVar14 != pcVar13) {
          cVar2 = *pcVar14;
          param_2 = (char *)CONCAT13(cVar2,param_2._0_3_);
          if (cVar2 < *param_1) {
            FUN_0170cc70(pcVar14 + (1 - ((int)pcVar14 - (int)param_1)),param_1,
                         (int)pcVar14 - (int)param_1);
            *param_1 = param_2._3_1_;
            pcVar11 = pcVar14;
          }
          else {
            uVar6 = (uint)CONCAT11(cVar2,*pcVar11);
            uVar7 = uVar6;
            pcVar12 = pcVar14;
            pcVar8 = pcVar14;
            if (cVar2 < *pcVar11) {
              do {
                pcVar8 = pcVar12 + -1;
                *pcVar12 = (char)uVar7;
                pcVar11 = pcVar12 + -2;
                uVar6 = CONCAT31((int3)(uVar7 >> 8),*pcVar11);
                uVar4 = uVar7 >> 8;
                uVar7 = uVar6;
                pcVar12 = pcVar8;
              } while ((char)uVar4 < *pcVar11);
            }
            *pcVar8 = (char)(uVar6 >> 8);
            pcVar11 = pcVar14;
          }
        }
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar10) {
        pcStack_8 = (char *)((int)pcVar13 - (int)param_1);
        iVar10 = (int)pcStack_8 >> 1;
        if (0 < iVar10) {
          iVar5 = (int)((int)pcStack_8 - 1U) >> 1;
          do {
            cVar2 = param_1[iVar10 + -1];
            iVar10 = iVar10 + -1;
            iVar1 = iVar10;
            while (iVar1 < iVar5) {
              iVar9 = iVar1 * 2;
              iVar9 = (param_1[iVar9 + 1] <= param_1[iVar9 + 2]) + 1 + iVar9;
              param_1[iVar1] = param_1[iVar9];
              iVar1 = iVar9;
            }
            if ((iVar1 == iVar5) && (((uint)pcStack_8 & 1) == 0)) {
              param_1[iVar1] = pcVar13[-1];
              iVar1 = (int)pcStack_8 - 1;
            }
            while (iVar10 < iVar1) {
              iVar9 = iVar1 + -1 >> 1;
              if (cVar2 <= param_1[iVar9]) break;
              param_1[iVar1] = param_1[iVar9];
              iVar1 = iVar9;
            }
            param_1[iVar1] = cVar2;
          } while (0 < iVar10);
        }
        if ((int)pcStack_8 < 2) {
          return;
        }
        do {
          param_2 = (char *)CONCAT13(param_1[(int)pcStack_8 - 1],param_2._0_3_);
          param_1[(int)pcStack_8 - 1] = *param_1;
          FUN_0063dd70(param_1,0,(int)pcStack_8 - 1,(int)&param_2 + 3,param_4);
          pcStack_8 = (char *)((int)pcStack_8 - 1);
        } while (1 < (int)pcStack_8);
        return;
      }
      goto LAB_0063e7f2;
    }
    pcVar11 = param_1 + (iVar10 >> 1);
    FUN_0063dc70(param_1,pcVar11,pcVar13 + -1,param_4);
    pcVar13 = pcVar11 + 1;
    for (; param_1 < pcVar11; pcVar11 = pcVar11 + -1) {
      if ((pcVar11[-1] < *pcVar11) || (*pcVar11 < pcVar11[-1])) break;
    }
    pcVar14 = pcVar13;
    pcStack_c = pcVar13;
    pcStack_8 = pcVar11;
    pcVar12 = pcVar11;
    if (pcVar13 < param_2) {
      do {
        pcVar14 = pcVar13;
        pcStack_c = pcVar13;
        if ((*pcVar13 < *pcVar11) || (*pcVar11 < *pcVar13)) break;
        pcVar13 = pcVar13 + 1;
        pcVar14 = pcVar13;
        pcStack_c = pcVar13;
      } while (pcVar13 < param_2);
    }
joined_r0x0063e6e2:
    pcVar8 = pcVar11;
    if (pcVar13 < param_2) {
      cVar2 = *pcVar13;
      pcVar11 = pcStack_8;
      if (cVar2 <= *pcVar12) {
        pcVar8 = pcStack_8;
        pcStack_c = pcVar13;
        if (cVar2 < *pcVar12) goto joined_r0x0063e70e;
        if (pcVar14 != pcVar13) {
          cVar3 = *pcVar14;
          *pcVar14 = cVar2;
          *pcVar13 = cVar3;
        }
        pcVar14 = pcVar14 + 1;
      }
      pcVar13 = pcVar13 + 1;
      pcStack_c = pcVar13;
      goto joined_r0x0063e6e2;
    }
joined_r0x0063e70e:
    while (param_1 < pcVar11) {
      pcVar8 = pcVar8 + -1;
      cVar2 = *pcVar8;
      pcVar13 = pcStack_c;
      if (*pcVar12 <= cVar2) {
        pcStack_8 = pcVar11;
        if (*pcVar12 < cVar2) break;
        pcVar12 = pcVar12 + -1;
        if (pcVar12 != pcVar8) {
          cVar3 = *pcVar12;
          *pcVar12 = cVar2;
          *pcVar8 = cVar3;
        }
      }
      pcStack_8 = pcVar11 + -1;
      pcVar11 = pcStack_8;
    }
    if (pcVar11 != param_1) {
      pcVar11 = pcVar11 + -1;
      pcStack_8 = pcVar11;
      if (pcVar13 == param_2) {
        pcVar12 = pcVar12 + -1;
        if (pcVar11 != pcVar12) {
          cVar2 = *pcVar11;
          *pcVar11 = *pcVar12;
          *pcVar12 = cVar2;
        }
        cVar2 = *pcVar12;
        *pcVar12 = pcVar14[-1];
        pcVar14[-1] = cVar2;
        pcVar14 = pcVar14 + -1;
      }
      else {
        cVar2 = *pcVar13;
        *pcVar13 = *pcVar11;
        pcVar13 = pcVar13 + 1;
        *pcVar11 = cVar2;
        pcStack_c = pcVar13;
      }
      goto joined_r0x0063e6e2;
    }
    if (pcVar13 != param_2) {
      if (pcVar14 != pcVar13) {
        cVar2 = *pcVar12;
        *pcVar12 = *pcVar14;
        *pcVar14 = cVar2;
      }
      cVar2 = *pcVar12;
      *pcVar12 = *pcVar13;
      *pcVar13 = cVar2;
      pcVar13 = pcVar13 + 1;
      pcVar14 = pcVar14 + 1;
      pcStack_c = pcVar13;
      pcVar12 = pcVar12 + 1;
      goto joined_r0x0063e6e2;
    }
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)pcVar12 - (int)param_1 < (int)param_2 - (int)pcVar14) {
      FUN_0063e660(param_1,pcVar12,param_3,param_4);
      param_1 = pcVar14;
    }
    else {
      FUN_0063e660(pcVar14,param_2,param_3,param_4);
      param_2 = pcVar12;
    }
    iVar10 = (int)param_2 - (int)param_1;
    pcVar13 = param_2;
  } while( true );
}



/* FUNCTION 7183 ; VA 0x0063e950 ; FUN_0063e950 */

void __thiscall
FUN_0063e950(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,uint param_4,
            undefined4 param_5)

{
  undefined4 *puVar1;
  bool bVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 **ppuVar5;
  char cVar6;
  undefined4 ***pppuVar7;
  undefined4 ***pppuVar8;
  undefined4 *puVar9;
  undefined **ppuVar10;
  undefined4 ***pppuVar11;
  undefined4 **appuStack_48 [2];
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 **appuStack_38 [2];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 **appuStack_28 [2];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = param_4;
  puStack_c = &LAB_017a0410;
  pvStack_10 = ExceptionList;
  puVar1 = param_1 + 2;
  uStack_8 = 0;
  uStack_30 = param_4;
  appuStack_38[0] = (undefined4 ***)0x0;
  puStack_18 = param_1;
  if (param_4 < 9) {
    pppuVar8 = appuStack_38;
    puVar9 = &param_2;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    pppuVar8 = (undefined4 ***)FUN_01674e20(param_4);
    puVar9 = param_2;
    appuStack_38[0] = pppuVar8;
  }
  FUN_0170c6f0(pppuVar8,puVar9,uVar3);
  pppuVar8 = (undefined4 ***)appuStack_38[0];
  uVar4 = param_5;
  uStack_2c = param_5;
  uStack_8._0_1_ = 1;
  uStack_20 = uStack_30;
  appuStack_28[0] = (undefined4 ***)0x0;
  if (uStack_30 < 9) {
    pppuVar7 = appuStack_28;
    pppuVar11 = appuStack_38;
  }
  else {
    pppuVar7 = (undefined4 ***)FUN_01674e20(uStack_30);
    pppuVar11 = pppuVar8;
    appuStack_28[0] = pppuVar7;
  }
  FUN_0170c6f0(pppuVar7,pppuVar11,uStack_20);
  uStack_1c = uVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar6 = FUN_00585a40(appuStack_28);
  uVar3 = uStack_20;
  if (cVar6 == '\0') {
    uStack_40 = uStack_20;
    appuStack_48[0] = (undefined4 ***)0x0;
    if (uStack_20 < 9) {
      pppuVar8 = appuStack_48;
      pppuVar7 = appuStack_28;
    }
    else {
      pppuVar8 = (undefined4 ***)FUN_01674e20(uStack_20);
      pppuVar7 = (undefined4 ***)appuStack_28[0];
      appuStack_48[0] = pppuVar8;
    }
    FUN_0170c6f0(pppuVar8,pppuVar7,uVar3);
    uVar3 = uStack_40;
    ppuVar5 = appuStack_48[0];
    uStack_14 = uStack_1c;
    uStack_3c = uStack_1c;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    param_1[4] = uStack_40;
    *puVar1 = 0;
    if (uStack_40 < 9) {
      puVar9 = puVar1;
      pppuVar8 = appuStack_48;
    }
    else {
      puVar9 = (undefined4 *)FUN_01674e20(uStack_40);
      *puVar1 = puVar9;
      pppuVar8 = (undefined4 ***)ppuVar5;
    }
    FUN_0170c6f0(puVar9,pppuVar8,param_1[4]);
    param_1[5] = uStack_14;
    if ((8 < uVar3) && ((undefined4 ***)ppuVar5 != (undefined4 ***)0x0)) {
      FUN_01674ea0(ppuVar5);
    }
    if ((8 < uStack_20) && ((undefined4 ***)appuStack_28[0] != (undefined4 ***)0x0)) {
      FUN_01674ea0(appuStack_28[0]);
    }
    bVar2 = true;
    pppuVar8 = (undefined4 ***)appuStack_38[0];
  }
  else {
    if ((8 < uStack_20) && ((undefined4 ***)appuStack_28[0] != (undefined4 ***)0x0)) {
      FUN_01674ea0(appuStack_28[0]);
    }
    bVar2 = false;
  }
  if ((8 < uStack_30) && (pppuVar8 != (undefined4 ***)0x0)) {
    FUN_01674ea0(pppuVar8);
  }
  ppuVar10 = &PTR_FUN_018d0924;
  if (!bVar2) {
    ppuVar10 = (undefined **)0x0;
  }
  *puStack_18 = ppuVar10;
  if ((8 < param_4) && (param_2 != (undefined4 *)0x0)) {
    FUN_01674ea0(param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7184 ; VA 0x0063eb20 ; FUN_0063eb20 */

void __thiscall
FUN_0063eb20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4,
            undefined4 param_5,int param_6)

{
  bool bVar1;
  char cVar2;
  undefined **ppuVar3;
  uint uVar4;
  int iVar5;
  int aiStack_54 [2];
  int iStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int aiStack_3c [2];
  int iStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [20];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0440;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006400f0(&param_4);
  uStack_2c = param_2;
  uStack_28 = param_3;
  uStack_8._0_1_ = 1;
  FUN_006400f0(aiStack_54);
  uStack_8._0_1_ = 2;
  cVar2 = FUN_00585a40(&uStack_2c);
  if (cVar2 == '\0') {
    uStack_44 = uStack_2c;
    uStack_40 = uStack_28;
    FUN_006400f0(auStack_24);
    param_1[2] = uStack_44;
    param_1[3] = uStack_40;
    uStack_8._0_1_ = 3;
    FUN_006400f0(aiStack_3c);
    if (aiStack_3c[0] != 0) {
      uVar4 = iStack_34 - aiStack_3c[0];
      iVar5 = aiStack_3c[0];
      if (0xfff < uVar4) {
        iVar5 = *(int *)(aiStack_3c[0] + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (aiStack_3c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar4);
    }
    FUN_00640bb0();
    bVar1 = true;
  }
  else {
    FUN_00640bb0();
    bVar1 = false;
  }
  if (aiStack_54[0] != 0) {
    uVar4 = iStack_4c - aiStack_54[0];
    iVar5 = aiStack_54[0];
    if (0xfff < uVar4) {
      iVar5 = *(int *)(aiStack_54[0] + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (aiStack_54[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  ppuVar3 = &PTR_FUN_018d08f4;
  if (!bVar1) {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (param_4 != 0) {
    uVar4 = param_6 - param_4;
    iVar5 = param_4;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(param_4 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (param_4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7185 ; VA 0x0063eca0 ; FUN_0063eca0 */

void __thiscall FUN_0063eca0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  undefined **ppuVar5;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 *puStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_c = param_4;
  uStack_10 = param_3;
  puStack_8 = param_1;
  cVar4 = FUN_00585a40(&uStack_14);
  if (cVar4 == '\0') {
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = 0;
    param_1[4] = 0;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[3] = uStack_10;
    param_1[4] = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = true;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = false;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ppuVar5 = &PTR_FUN_018d08d8;
  if (!bVar3) {
    ppuVar5 = (undefined **)0x0;
  }
  *puStack_8 = ppuVar5;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return;
}



/* FUNCTION 7186 ; VA 0x0063edb0 ; FUN_0063edb0 */

undefined4 * FUN_0063edb0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
    piVar1 = param_4 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  piVar1 = param_4 + 2;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_3;
  param_1[2] = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 7187 ; VA 0x0063ee70 ; FUN_0063ee70 */

int FUN_0063ee70(undefined4 *param_1,undefined4 *param_2,code *param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  
  iVar3 = 0;
  if (param_1 != param_2) {
    do {
      if (param_1[1] != 0) {
        LOCK();
        piVar1 = (int *)(param_1[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      cVar2 = (*param_3)(*param_1,param_1[1]);
      if (cVar2 != '\0') {
        iVar3 = iVar3 + 1;
      }
      param_1 = param_1 + 2;
    } while (param_1 != param_2);
  }
  return iVar3;
}



/* FUNCTION 7188 ; VA 0x0063eed0 ; FUN_0063eed0 */

undefined4 * FUN_0063eed0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0483;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00705fc0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x128);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00706890();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0063e390(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7189 ; VA 0x0063ef90 ; FUN_0063ef90 */

int FUN_0063ef90(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0498;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead2dc,&LAB_00605b50);
  uVar2 = FUN_00605fa0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_007060a0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_0063eed0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead2dc,&LAB_00605b50);
      uVar2 = FUN_00605fa0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7190 ; VA 0x0063f120 ; FUN_0063f120 */

int FUN_0063f120(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a04b8;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00564080();
  iVar5 = *piVar3;
  if (iVar5 == 0) {
    FUN_0055e4a0(&iStack_18);
    iStack_8 = iVar5;
    FUN_008a5700(param_1);
    FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
    uVar4 = FUN_00560c40();
    piVar3 = (int *)FUN_008aa140(uVar4);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    *piVar3 = iStack_18;
    piVar1 = (int *)piVar3[1];
    piVar3[1] = (int)piStack_14;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[1] + -1;
      piVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    iVar5 = iStack_18;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7191 ; VA 0x0063f220 ; FUN_0063f220 */

int FUN_0063f220(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a04d8;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar5 != 0) && (param_1 = iVar5, ExceptionList = &pvStack_10, *(int *)(iVar5 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar5 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      piVar3 = (int *)FUN_00564130();
      iVar5 = *piVar3;
      if (iVar5 == 0) {
        FUN_005f50b0(&iStack_18);
        iStack_8 = iVar5;
        FUN_008a5700(param_1);
        FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
        uVar4 = FUN_00560d40();
        piVar3 = (int *)FUN_008aa140(uVar4);
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        *piVar3 = iStack_18;
        piVar1 = (int *)piVar3[1];
        piVar3[1] = (int)piStack_14;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar5 = piVar1[1] + -1;
          piVar1[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar5 = piVar1[2] + -1;
            piVar1[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar5 = iStack_18;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_14[1] + -1;
          piStack_14[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            piVar3 = piStack_14 + 2;
            iVar2 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piStack_14 + 4))();
            }
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar5;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 7192 ; VA 0x0063f370 ; FUN_0063f370 */

undefined4 * FUN_0063f370(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0523;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005ee350();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x3d70);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    FUN_005ef5c0(param_2);
    uVar3 = FUN_00677b90();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0063e480(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7193 ; VA 0x0063f450 ; FUN_0063f450 */

undefined4 * FUN_0063f450(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0563;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bb25e0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x13c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bb2ea0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0063e570(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7194 ; VA 0x0063f510 ; FUN_0063f510 */

int FUN_0063f510(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0578;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead790,&LAB_0063ee60);
  uVar2 = FUN_0063f700();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00bb26e0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_0063f450(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead790,&LAB_0063ee60);
      uVar2 = FUN_0063f700();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 7195 ; VA 0x0063f6a0 ; FUN_0063f6a0 */

undefined4 FUN_0063f6a0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_0063f510();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 7196 ; VA 0x0063f700 ; FUN_0063f700 */

undefined4 FUN_0063f700(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a059c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead79c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead79c);
    if (DAT_01ead79c == -1) {
      uStack_8 = 0;
      DAT_01ead798 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ead79c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ead798;
}



/* FUNCTION 7197 ; VA 0x0063f780 ; FUN_0063f780 */

void __thiscall FUN_0063f780(int param_1,char *param_2,undefined8 *param_3)

{
  char cVar1;
  undefined *puVar2;
  int iVar3;
  char *pcVar4;
  
  puVar2 = *(undefined **)(param_1 + 4);
  if (*(undefined **)(param_1 + 8) != puVar2) {
    *(undefined4 *)(puVar2 + 0x10) = 0;
    *(undefined4 *)(puVar2 + 0x14) = 0xf;
    *puVar2 = 0;
    pcVar4 = param_2;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(param_2,(int)pcVar4 - (int)(param_2 + 1));
    iVar3 = *(int *)(param_1 + 4);
    *(undefined8 *)(puVar2 + 0x18) = *param_3;
    *(int *)(param_1 + 4) = iVar3 + 0x20;
    return;
  }
  FUN_0063d860(puVar2,param_2,param_3);
  return;
}



/* FUNCTION 7198 ; VA 0x0063f7f0 ; FUN_0063f7f0 */

int FUN_0063f7f0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_009fb200();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 7199 ; VA 0x0063f830 ; FUN_0063f830 */

void __thiscall FUN_0063f830(int param_1,undefined4 *param_2,uint param_3)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar1;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          cVar2 = FUN_00a33d60(piVar4 + 2);
          if (cVar2 != '\0') break;
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 7200 ; VA 0x0063f8c0 ; FUN_0063f8c0 */

undefined4 * FUN_0063f8c0(undefined4 *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a05b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,0x48);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar3 = boost::detail::
              thread_data<class_boost::_bi::bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::Security::AslrPmcSharedHasher>),class_boost::_bi::list1<class_boost::_bi::value<class_std::weak_ptr<class_RBX::Security::AslrPmcSharedHasher>_>_>_>_>
              ::vftable;
    puVar3[0xf] = *param_1;
    puVar3[0x10] = 0;
    puVar3[0x11] = 0;
    puVar3[0x10] = param_1[1];
    puVar3[0x11] = param_1[2];
    param_1[1] = 0;
    param_1[2] = 0;
    ExceptionList = pvStack_10;
    return puVar3;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 7201 ; VA 0x0063f952 ; Catch_All@0063f952 */

void Catch_All_0063f952(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7202 ; VA 0x0063f980 ; FUN_0063f980 */

undefined4 *
FUN_0063f980(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            uint param_5,undefined4 param_6)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined auStack_1b0 [40];
  undefined4 uStack_188;
  undefined *puStack_184;
  undefined4 *puStack_180;
  uint uStack_17c;
  undefined *puStack_178;
  uint *puStack_174;
  uint uStack_170;
  uint *puStack_16c;
  undefined4 auStack_168 [8];
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined *puStack_138;
  undefined *puStack_134;
  uint *puStack_130;
  uint auStack_120 [2];
  undefined auStack_118 [56];
  uint auStack_e0 [2];
  undefined auStack_d8 [56];
  uint auStack_a0 [2];
  undefined auStack_98 [56];
  uint auStack_60 [2];
  undefined auStack_58 [56];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0614;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar5 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar5 = (undefined4 *)*param_2;
  }
  iVar1 = param_2[4];
  puVar6 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar6 = (undefined4 *)*param_2;
  }
  puStack_130 = param_2;
  puStack_14 = (undefined *)&puStack_178;
  puStack_184 = (undefined *)&puStack_178;
  uStack_170 = param_5;
  puStack_178 = (undefined *)0x0;
  if (param_5 < 9) {
    puStack_180 = &param_3;
    ExceptionList = &pvStack_10;
    puStack_14 = (undefined *)&puStack_178;
  }
  else {
    uStack_17c = param_5;
    puStack_180 = (undefined4 *)0x63f9f2;
    ExceptionList = &pvStack_10;
    puStack_184 = (undefined *)FUN_01674e20();
    puStack_180 = param_3;
    puStack_178 = puStack_184;
  }
  uStack_188 = 0x63fa07;
  uStack_17c = uStack_170;
  FUN_0170c6f0();
  puStack_16c = (uint *)param_6;
  puStack_184 = (undefined *)0x63fa1a;
  puStack_180 = puVar6;
  uStack_17c = iVar1 + (int)puVar5;
  FUN_0063d280();
  puStack_16c = auStack_120;
  uStack_170 = 0x63fa26;
  FUN_0063fd10();
  uStack_8._0_1_ = 1;
  auStack_168[0] = 0;
  uStack_148 = 0;
  uStack_144 = 0;
  uStack_140 = 0;
  uStack_13c = 0;
  puStack_138 = (undefined *)CONCAT31(puStack_138._1_3_,1);
  puStack_16c = auStack_e0;
  uStack_170 = 0x63fa67;
  puStack_130 = auStack_168;
  FUN_0063fd10();
  puStack_130 = auStack_e0;
  uStack_8._0_1_ = 2;
  puStack_134 = (undefined *)0x63fa80;
  FUN_00640080();
  puStack_130 = auStack_120;
  uStack_8._0_1_ = 3;
  puStack_134 = (undefined *)0x63fa93;
  FUN_00640080();
  puStack_174 = auStack_a0;
  uStack_8._0_1_ = 5;
  puStack_14 = (undefined *)&uStack_170;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  puStack_178 = (undefined *)0x63fac6;
  puStack_130 = auStack_168;
  FUN_00640080();
  puStack_14 = auStack_1b0;
  uStack_8._0_1_ = 6;
  FUN_00640080(auStack_60);
  uStack_8._0_1_ = 5;
  FUN_0063de10();
  uStack_8._0_1_ = 7;
  if (auStack_60[0] != 0) {
    if (((auStack_60[0] & 1) == 0) && (*(code **)(auStack_60[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = auStack_58;
      puStack_130 = (uint *)0x2;
      uStack_13c = 0x63fb08;
      puStack_134 = puStack_138;
      (**(code **)(auStack_60[0] & 0xfffffffe))();
    }
    auStack_60[0] = 0;
  }
  uStack_8._0_1_ = 8;
  if (((auStack_a0[0] != 0) && ((auStack_a0[0] & 1) == 0)) &&
     (*(code **)(auStack_a0[0] & 0xfffffffe) != (code *)0x0)) {
    puStack_138 = auStack_98;
    puStack_130 = (uint *)0x2;
    uStack_13c = 0x63fb39;
    puStack_134 = puStack_138;
    (**(code **)(auStack_a0[0] & 0xfffffffe))();
  }
  if (param_1 != &uStack_20) {
    uVar2 = *param_1;
    *param_1 = uStack_20;
    uVar3 = param_1[1];
    param_1[1] = uStack_1c;
    uVar4 = param_1[2];
    param_1[2] = uStack_18;
    uStack_20 = uVar2;
    uStack_1c = uVar3;
    uStack_18 = uVar4;
  }
  puStack_130 = (uint *)0x63fb70;
  FUN_00577a40();
  uStack_8._0_1_ = 9;
  if (auStack_e0[0] != 0) {
    if (((auStack_e0[0] & 1) == 0) && (*(code **)(auStack_e0[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = auStack_d8;
      puStack_130 = (uint *)0x2;
      uStack_13c = 0x63fb97;
      puStack_134 = puStack_138;
      (**(code **)(auStack_e0[0] & 0xfffffffe))();
    }
    auStack_e0[0] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (auStack_120[0] != 0) {
    if (((auStack_120[0] & 1) == 0) && (*(code **)(auStack_120[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = auStack_118;
      puStack_130 = (uint *)0x2;
      uStack_13c = 0x63fbcb;
      puStack_134 = puStack_138;
      (**(code **)(auStack_120[0] & 0xfffffffe))();
    }
    auStack_120[0] = 0;
  }
  if ((8 < param_5) && (param_3 != (undefined4 *)0x0)) {
    puStack_130 = param_3;
    puStack_134 = (undefined *)0x63fbeb;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7203 ; VA 0x0063fc10 ; FUN_0063fc10 */

undefined4 * FUN_0063fc10(undefined4 *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  bool bVar6;
  undefined auStack_5b [39];
  undefined *puStack_34;
  undefined **ppuStack_30;
  int iStack_2c;
  int iStack_28;
  undefined **ppuStack_24;
  undefined uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  puStack_34 = auStack_5b;
  uStack_8 = 0;
  ppuStack_30 = &puStack_34;
  uStack_14 = 1;
  iVar1 = param_2[1];
  iStack_2c = *param_2;
  iStack_28 = iVar1;
  if ((iVar1 < 1) && (iVar1 < 0)) {
    bVar6 = iStack_2c != 0;
    iStack_2c = -iStack_2c;
    iStack_28 = -(iVar1 + (uint)bVar6);
  }
  ppuStack_24 = &puStack_34;
  uStack_20 = 0x30;
  uStack_1c = 0x30;
  puStack_34 = (undefined *)FUN_00642d60();
  if ((iVar1 < 1) && (iVar1 < 0)) {
    puStack_34 = puStack_34 + -1;
    *puStack_34 = 0x2d;
  }
  uVar2 = param_1[5];
  ppuStack_30 = &puStack_34;
  puVar5 = param_1;
  if (0xf < uVar2) {
    puVar5 = (undefined4 *)*param_1;
  }
  puVar3 = param_1;
  if (0xf < uVar2) {
    puVar3 = (undefined4 *)*param_1;
  }
  puVar4 = param_1;
  if (0xf < uVar2) {
    puVar4 = (undefined4 *)*param_1;
  }
  FUN_00591430((int)puVar3 - (int)puVar4,(undefined *)((int)puVar5 + (param_1[4] - (int)puVar3)),
               puStack_34,(int)&puStack_34 - (int)puStack_34);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7204 ; VA 0x0063fd10 ; FUN_0063fd10 */

undefined4 FUN_0063fd10(undefined4 param_1,uint param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0628;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00640080(&param_2);
  uStack_8 = 1;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&stack0x00000010,&stack0x00000010,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7205 ; VA 0x0063fd80 ; FUN_0063fd80 */

undefined4
FUN_0063fd80(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4,
            uint param_5,undefined4 param_6)

{
  uint uVar1;
  undefined4 **ppuVar2;
  undefined4 ***pppuVar3;
  undefined **ppuVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 ***pppuVar7;
  undefined *apuStack_48 [2];
  uint uStack_40;
  undefined4 *puStack_3c;
  undefined4 **appuStack_2c [2];
  uint uStack_24;
  undefined4 **appuStack_20 [2];
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uVar1 = param_5;
  puStack_c = &LAB_017a0658;
  pvStack_10 = ExceptionList;
  ppuVar4 = apuStack_48;
  uStack_8 = 0;
  uStack_24 = param_5;
  appuStack_2c[0] = (undefined4 ***)0x0;
  if (param_5 < 9) {
    pppuVar3 = appuStack_2c;
    puVar6 = &param_3;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    pppuVar3 = (undefined4 ***)FUN_01674e20(param_5);
    puVar6 = param_3;
    appuStack_2c[0] = pppuVar3;
  }
  FUN_0170c6f0(pppuVar3,puVar6,uVar1);
  uVar1 = uStack_24;
  ppuVar2 = appuStack_2c[0];
  uStack_8._0_1_ = 1;
  uStack_18 = uStack_24;
  appuStack_20[0] = (undefined4 ***)0x0;
  if (uStack_24 < 9) {
    pppuVar3 = appuStack_20;
    pppuVar7 = appuStack_2c;
  }
  else {
    pppuVar3 = (undefined4 ***)FUN_01674e20(uStack_24);
    pppuVar7 = (undefined4 ***)ppuVar2;
    appuStack_20[0] = pppuVar3;
  }
  FUN_0170c6f0(pppuVar3,pppuVar7,uVar1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_40 = uStack_18;
  apuStack_48[0] = (undefined *)0x0;
  if (uStack_18 < 9) {
    pppuVar3 = appuStack_20;
  }
  else {
    ppuVar4 = (undefined **)FUN_01674e20(uStack_18);
    pppuVar3 = (undefined4 ***)appuStack_20[0];
    apuStack_48[0] = (undefined *)ppuVar4;
  }
  FUN_0170c6f0(ppuVar4,pppuVar3,uStack_40);
  puStack_3c = (undefined4 *)param_6;
  if ((8 < uStack_18) && ((undefined4 ***)appuStack_20[0] != (undefined4 ***)0x0)) {
    FUN_01674ea0(appuStack_20[0]);
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if ((8 < uVar1) && ((undefined4 ***)ppuVar2 != (undefined4 ***)0x0)) {
    FUN_01674ea0(ppuVar2);
  }
  uVar5 = FUN_0063f980(param_1,param_2);
  if ((8 < param_5) && (param_3 != (undefined4 *)0x0)) {
    puStack_3c = param_3;
    uStack_40 = 0x63fea7;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 7206 ; VA 0x0063fec0 ; FUN_0063fec0 */

undefined4 *
FUN_0063fec0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,uint param_4,
            undefined4 param_5)

{
  uint uVar1;
  undefined4 **ppuVar2;
  undefined4 ***pppuVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 **appuStack_1c [2];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_4;
  puStack_c = &LAB_017a0680;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = param_4;
  appuStack_1c[0] = (undefined4 ***)0x0;
  if (param_4 < 9) {
    pppuVar3 = appuStack_1c;
    puVar4 = &param_2;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    pppuVar3 = (undefined4 ***)FUN_01674e20(param_4);
    puVar4 = param_2;
    appuStack_1c[0] = pppuVar3;
  }
  FUN_0170c6f0(pppuVar3,puVar4,uVar1);
  uVar1 = uStack_14;
  ppuVar2 = appuStack_1c[0];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  param_1[2] = uStack_14;
  *param_1 = 0;
  if (uStack_14 < 9) {
    puVar4 = param_1;
    pppuVar3 = appuStack_1c;
    uVar5 = uStack_14;
  }
  else {
    puVar4 = (undefined4 *)FUN_01674e20(uStack_14);
    uVar5 = param_1[2];
    *param_1 = puVar4;
    pppuVar3 = (undefined4 ***)ppuVar2;
  }
  FUN_0170c6f0(puVar4,pppuVar3,uVar5);
  param_1[3] = param_5;
  if ((8 < uVar1) && ((undefined4 ***)ppuVar2 != (undefined4 ***)0x0)) {
    FUN_01674ea0(ppuVar2);
  }
  if ((8 < param_4) && (param_2 != (undefined4 *)0x0)) {
    FUN_01674ea0(param_2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7207 ; VA 0x0063ffa0 ; FUN_0063ffa0 */

void * __thiscall FUN_0063ffa0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvVar4;
  int *piVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puVar6 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_1 + 0x30);
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar6[1];
    puVar6 = (undefined4 *)*puVar6;
    uStack_8 = 0;
    pvVar4 = pvStack_10;
    for (; puVar6 != puVar3; puVar6 = puVar6 + 2) {
      if (puVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00645950(*puVar6,puVar6[1]);
      pvVar4 = (void *)FUN_0063ffa0(param_2);
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 7208 ; VA 0x00640080 ; FUN_00640080 */

uint * __thiscall FUN_00640080(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  *(undefined *)(param_1 + 0xc) = *(undefined *)(param_2 + 0xc);
  return param_1;
}



/* FUNCTION 7209 ; VA 0x006400f0 ; FUN_006400f0 */

uint * __thiscall FUN_006400f0(uint *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined auStack_10 [4];
  uint *puStack_c;
  undefined uStack_5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = param_2[1] - *param_2;
  if (uVar3 != 0) {
    puStack_c = param_1;
    if (0x7fffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    if (uVar3 < 0x1000) {
      uVar1 = FUN_01674e20(uVar3);
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar3;
    iVar2 = *param_2;
    uVar3 = *param_1;
    FUN_0055b6b0(&uStack_5,auStack_10,auStack_10);
    iVar4 = param_2[1] - iVar2;
    FUN_0170cc70(uVar3,iVar2,iVar4);
    puStack_c[1] = uVar3 + iVar4;
    param_1 = puStack_c;
  }
  return param_1;
}



/* FUNCTION 7210 ; VA 0x006401b0 ; FUN_006401b0 */

uint * __thiscall FUN_006401b0(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a06b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x3a83a83 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar3 = param_2 * 0x46;
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar3);
      }
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    uStack_8 = 0;
    param_1[2] = *param_1 + uVar3;
    uVar3 = *param_1;
    for (; param_2 != 0; param_2 = param_2 - 1) {
      FUN_005f7120();
      uVar3 = uVar3 + 0x46;
    }
    param_1[1] = uVar3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7211 ; VA 0x00640286 ; Catch_All@00640286 */

void Catch_All_00640286(void)

{
  FUN_00642960();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7212 ; VA 0x006402a0 ; FUN_006402a0 */

undefined4 * __thiscall
FUN_006402a0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 ******param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *****pppppuVar3;
  uint uVar4;
  undefined4 ******ppppppuVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 ******ppppppuVar8;
  undefined4 *puVar9;
  undefined4 uStack_7c;
  undefined4 *****pppppuStack_78;
  int *piStack_74;
  undefined4 *****pppppuStack_70;
  undefined4 *apuStack_60 [5];
  uint uStack_4c;
  undefined4 *****pppppuStack_48;
  undefined4 *****pppppuStack_44;
  undefined4 uStack_40;
  undefined4 *****apppppuStack_3c [2];
  uint uStack_34;
  undefined4 *****apppppuStack_30 [2];
  uint uStack_28;
  undefined4 *****apppppuStack_24 [2];
  uint uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0714;
  pvStack_10 = ExceptionList;
  pppppuStack_70 = (undefined4 *****)0xb;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_7c = 0;
  pppppuStack_78 = (undefined4 *****)param_2;
  piStack_74 = param_3;
  puStack_14 = param_1;
  FUN_00a360a0("Romark Phase Tracking Job",1);
  *param_1 = RBX::Network::RomarkPhaseTrackingJob::vftable;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  param_1[0x4a] = param_2;
  param_1[0x4b] = param_3;
  param_1[0x4c] = param_4;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  pppppuStack_70 = (undefined4 *****)(param_1 + 0x54);
  uStack_8._0_1_ = 3;
  param_1[0x50] = 0;
  param_1[0x51] = 0x1010101;
  *(undefined2 *)(param_1 + 0x52) = 0x101;
  *(undefined *)((int)param_1 + 0x14a) = 1;
  piStack_74 = (int *)0x640392;
  FUN_01682800();
  piStack_74 = param_1 + 0x56;
  pppppuStack_78 = (undefined4 *****)0x64039e;
  FUN_01682800();
  param_1[0x58] = 0;
  pppppuStack_70 = (undefined4 *****)&DAT_01d5a518;
  piStack_74 = (int *)0x6403b8;
  FUN_0054ef60();
  pppppuStack_48 = (undefined4 ******)0x0;
  pppppuStack_44 = (undefined4 ******)0x0;
  uStack_40 = 0;
  pppppuStack_70 = (undefined4 *****)0x1;
  pppppuStack_78 = apppppuStack_24;
  uStack_8._0_1_ = 5;
  piStack_74 = (int *)&DAT_018bf378;
  apppppuStack_24[0] = (undefined4 ******)0x0;
  uStack_1c = 1;
  uStack_7c = 0x6403ef;
  FUN_0170cc70();
  uStack_7c = param_4;
  FUN_0063e660(apppppuStack_24,(int)apppppuStack_24 + uStack_1c,
               ((int)apppppuStack_24 + uStack_1c) - (int)apppppuStack_24);
  uVar4 = uStack_1c;
  param_4 = (undefined4 ******)&uStack_7c;
  uStack_8._0_1_ = 6;
  uStack_34 = uStack_1c;
  apppppuStack_3c[0] = (undefined4 ******)0x0;
  if (uStack_1c < 9) {
    ppppppuVar5 = apppppuStack_3c;
    ppppppuVar8 = apppppuStack_24;
    param_4 = (undefined4 ******)&uStack_7c;
  }
  else {
    ppppppuVar5 = (undefined4 ******)FUN_01674e20(uStack_1c);
    ppppppuVar8 = (undefined4 ******)apppppuStack_24[0];
    apppppuStack_3c[0] = ppppppuVar5;
  }
  FUN_0170c6f0(ppppppuVar5,ppppppuVar8,uVar4);
  uVar4 = uStack_34;
  uStack_8._0_1_ = 7;
  uStack_28 = uStack_34;
  apppppuStack_30[0] = (undefined4 ******)0x0;
  if (uStack_34 < 9) {
    ppppppuVar5 = apppppuStack_30;
    ppppppuVar8 = apppppuStack_3c;
  }
  else {
    ppppppuVar5 = (undefined4 ******)FUN_01674e20(uStack_34);
    ppppppuVar8 = (undefined4 ******)apppppuStack_3c[0];
    apppppuStack_30[0] = ppppppuVar5;
  }
  FUN_0170c6f0(ppppppuVar5,ppppppuVar8,uVar4);
  uVar7 = uStack_28;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  param_4[2] = (undefined4 *****)uStack_28;
  *param_4 = (undefined4 *****)0x0;
  if (uVar7 < 9) {
    ppppppuVar5 = apppppuStack_30;
    puVar6 = param_4;
  }
  else {
    puVar6 = (undefined4 *)FUN_01674e20(uVar7);
    ppppppuVar5 = (undefined4 ******)apppppuStack_30[0];
    *param_4 = (undefined4 *****)puVar6;
    uVar7 = (uint)param_4[2];
  }
  FUN_0170c6f0(puVar6,ppppppuVar5,uVar7);
  uVar7 = uStack_28;
  param_4[3] = (undefined4 *****)0x1;
  if ((8 < uVar7) && ((undefined4 ******)apppppuStack_30[0] != (undefined4 ******)0x0)) {
    FUN_01674ea0(apppppuStack_30[0]);
  }
  uStack_8._0_1_ = 6;
  if ((8 < uVar4) && ((undefined4 ******)apppppuStack_3c[0] != (undefined4 ******)0x0)) {
    FUN_01674ea0(apppppuStack_3c[0]);
  }
  FUN_0063f980(&pppppuStack_48,apuStack_60);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if ((8 < uStack_1c) && ((undefined4 ******)apppppuStack_24[0] != (undefined4 ******)0x0)) {
    pppppuStack_70 = apppppuStack_24[0];
    piStack_74 = (undefined4 *)0x64051d;
    FUN_01674ea0();
  }
  pppppuVar3 = pppppuStack_44;
  param_4 = (undefined4 ******)pppppuStack_44;
  puVar6 = param_1;
  ppppppuVar5 = (undefined4 ******)pppppuStack_48;
  if ((uint)(((int)pppppuStack_44 - (int)pppppuStack_48) / 0x18) < 2) {
    pppppuStack_70 = (undefined4 *****)0x18d0370;
    piStack_74 = (undefined4 *)0x3;
    pppppuStack_78 = (undefined4 ******)0x64059e;
    FUN_0086f2f0();
    puVar9 = (undefined4 *)param_1[0x4e];
    param_4 = (undefined4 ******)0x1;
    if ((undefined4 *)param_1[0x4f] == puVar9) {
      pppppuStack_70 = &param_4;
      pppppuStack_78 = (undefined4 ******)0x6405c8;
      piStack_74 = puVar9;
      FUN_0063d9b0();
    }
    else {
      *puVar9 = 1;
      param_1[0x4e] = param_1[0x4e] + 4;
    }
  }
  else {
    for (; ppppppuVar5 != (undefined4 ******)pppppuVar3; ppppppuVar5 = ppppppuVar5 + 6) {
      pppppuStack_78 = ppppppuVar5;
      if ((undefined4 *****)0xf < ppppppuVar5[5]) {
        pppppuStack_78 = *ppppppuVar5;
      }
      pppppuStack_70 = (undefined4 *****)0xa;
      piStack_74 = (undefined4 *)0x0;
      uStack_7c = 0x640564;
      param_4 = (undefined4 ******)FUN_0171d785();
      puVar6 = (undefined4 *)param_1[0x4e];
      if ((undefined4 *)param_1[0x4f] == puVar6) {
        pppppuStack_70 = &param_4;
        pppppuStack_78 = (undefined4 ******)0x640586;
        piStack_74 = puVar6;
        FUN_0063d9b0();
      }
      else {
        *puVar6 = param_4;
        param_1[0x4e] = param_1[0x4e] + 4;
      }
      puVar6 = puStack_14;
    }
  }
  pppppuStack_70 = (undefined4 *****)0x6405d0;
  FUN_00577a40();
  if (0xf < uStack_4c) {
    pppppuStack_70 = (undefined4 *****)(uStack_4c + 1);
    puVar9 = apuStack_60[0];
    if (0xfff < pppppuStack_70) {
      puVar9 = (undefined4 *)apuStack_60[0][-1];
      pppppuStack_70 = (undefined4 *****)(uStack_4c + 0x24);
      if ((undefined *)0x1f < (undefined *)((int)apuStack_60[0] + (-4 - (int)puVar9))) {
                    /* WARNING: Subroutine does not return */
        pppppuStack_70 = (undefined4 *****)&UNK_00640642;
        FUN_017167a3();
      }
    }
    pppppuStack_78 = (undefined4 ******)0x6405fd;
    piStack_74 = puVar9;
    FUN_01674ea0();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      pppppuStack_70 = (undefined4 *****)0x640619;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pppppuStack_70 = (undefined4 *****)0x640628;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 7213 ; VA 0x00640650 ; FUN_00640650 */

undefined4 * __fastcall FUN_00640650(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  undefined uVar3;
  char cVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined **ppuVar7;
  int iVar8;
  undefined **ppuVar9;
  uint uVar10;
  uint uVar11;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 *puStack_1c;
  uint *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a087e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_1c = param_1;
  FUN_006c43c0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Network::Server,class_RBX::Network::Peer>::vftable;
  param_1[0x15] =
       RBX::DescribedCreatable<class_RBX::Network::Server,class_RBX::Network::Peer>::vftable;
  uVar5 = FUN_005ee250();
  param_1[3] = uVar5;
  *(undefined *)(param_1 + 0x40) = 1;
  *param_1 = RBX::Network::Server::vftable;
  param_1[0x15] = RBX::Network::Server::vftable;
  param_1[0x41] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  param_1[0x49] = 0;
  FUN_006d0970(1,param_1);
  param_1[0xe6] = 0;
  param_1[0xe7] = 0;
  param_1[0xe8] = 0;
  *(undefined2 *)(param_1 + 0xe9) = 0;
  uStack_8._0_1_ = 8;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  iVar8 = DAT_01ea94c4;
  if (DAT_01ea94c4 == 0) {
    piVar6 = (int *)FUN_00910d90();
    puStack_14 = (undefined4 *)((uint)puStack_14 & 0xffffff00);
    iVar8 = *piVar6;
    puStack_18 = (uint *)(iVar8 + 0x94);
    FUN_00587410();
    uStack_8._0_1_ = 9;
    if (DAT_01ea94c4 == 0) {
      FUN_005eeb00(auStack_24);
      uStack_8._0_1_ = 10;
      FUN_008a65e0(iVar8,0);
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_20[1] + -1;
        piStack_20[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar6 = piStack_20 + 2;
          iVar8 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar8 == 1) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
    }
    iVar8 = DAT_01ea94c4;
    uStack_8._0_1_ = 0xb;
    uVar3 = (undefined)uStack_8;
    if ((char)puStack_14 != '\0') {
      LOCK();
      uVar10 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar10 & 0x40000000) == 0) && (-0x80000000 < (int)uVar10)) {
        LOCK();
        uVar10 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar10 >> 0x1e & 1) == 0) {
          uVar5 = FUN_00554e40();
          SetEvent(uVar5);
          uVar3 = (undefined)uStack_8;
        }
      }
    }
  }
  uStack_8._0_1_ = uVar3;
  uVar2 = DAT_018ce330;
  param_1[0xea] = iVar8;
  param_1[0xeb] = 0;
  *(undefined8 *)(param_1 + 0xec) = uVar2;
  param_1[0xee] = 0;
  param_1[0xef] = 0;
  param_1[0xf0] = 0;
  *(undefined *)(param_1 + 0xf1) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar7 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar9 = ppuVar7 + -1;
  if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar7;
  }
  param_1[0xf2] = *ppuVar9;
  param_1[0xf3] = 0;
  param_1[0xf4] = 0x3f800000;
  param_1[0xf5] = 0;
  param_1[0xf6] = 0;
  *(undefined *)(param_1 + 0xf7) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar7 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar9 = ppuVar7 + -1;
  if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar7;
  }
  param_1[0xf8] = *ppuVar9;
  param_1[0xf9] = 0;
  param_1[0xfa] = 0x3f800000;
  param_1[0xfb] = 0;
  param_1[0xfc] = 0;
  param_1[0xfd] = 0;
  param_1[0xfe] = 0;
  *(undefined *)(param_1 + 0xff) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar7 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar9 = ppuVar7 + -1;
  if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar7;
  }
  param_1[0x100] = *ppuVar9;
  param_1[0x101] = 0;
  param_1[0x102] = 0x3f800000;
  param_1[0x103] = 0;
  param_1[0x104] = 0;
  *(undefined *)(param_1 + 0x105) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar7 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar9 = ppuVar7 + -1;
  if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar7;
  }
  param_1[0x106] = *ppuVar9;
  param_1[0x107] = 0;
  param_1[0x108] = 0x3f800000;
  param_1[0x109] = 0;
  param_1[0x10a] = 0;
  param_1[0x10b] = 0;
  param_1[0x10c] = 0;
  param_1[0x10d] = 0;
  param_1[0x10e] = 0;
  param_1[0x10f] = 0;
  param_1[0x110] = 0;
  param_1[0x111] = 0;
  uStack_8._0_1_ = 0x13;
  FUN_008866d0();
  uStack_8._0_1_ = 0x14;
  FUN_008866d0();
  param_1[0x116] = 0xffffffff;
  param_1[0x118] = 0;
  param_1[0x119] = 0;
  param_1[0x11a] = 3;
  *(undefined8 *)(param_1 + 0x11c) = 0;
  param_1[0x11e] = 0;
  puVar1 = param_1 + 0x11f;
  uStack_8._0_1_ = 0x17;
  *puVar1 = 0;
  param_1[0x120] = 0;
  puStack_14 = puVar1;
  uVar5 = FUN_00575b30();
  *puVar1 = uVar5;
  puVar1 = param_1 + 0x121;
  uStack_8._0_1_ = 0x18;
  *puVar1 = 0;
  param_1[0x122] = 0;
  puStack_14 = puVar1;
  uVar5 = FUN_00575b30();
  *puVar1 = uVar5;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
  uVar5 = FUN_01255560();
  cVar4 = FUN_01255580(uVar5,6);
  if (cVar4 == '\0') {
    FUN_01255600(6,"create a NetworkServer");
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0("NetworkServer",0xd);
  uStack_8._0_1_ = 0x1a;
  FUN_008a6520(auStack_3c);
  uStack_8._0_1_ = 0x19;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x19;
  if (0xf < uStack_28) {
    uVar11 = uStack_28 + 1;
    uVar10 = auStack_3c[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_3c[0] - 4);
      uVar11 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar10) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  uVar5 = FUN_00a33c70();
  uStack_8._0_1_ = 0x1b;
  FUN_00646a30(uVar5);
  uStack_8._0_1_ = 0x19;
  FUN_0056cd30();
  uVar5 = FUN_00a33c70();
  uStack_8._0_1_ = 0x1c;
  iVar8 = FUN_00641930(uVar5);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
  *(undefined4 *)(iVar8 + 4) = 0;
  FUN_0056cd30();
  param_1[0x42] = 4;
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"NetworkServer:Create",0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7214 ; VA 0x00640bb0 ; FUN_00640bb0 */

void __fastcall FUN_00640bb0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 8);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x10) - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7215 ; VA 0x00640c00 ; thunk_FUN_006c4520 */

void __fastcall thunk_FUN_006c4520(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Network::Peer::vftable;
  param_1[0x15] = RBX::Network::Peer::vftable;
  if ((undefined4 *)param_1[0x3e] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x3e])(1);
  }
  piVar2 = (int *)param_1[0x3d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x3b];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x36];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x33];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006bcd30();
  FUN_0089b230();
  return;
}



/* FUNCTION 7216 ; VA 0x00640c10 ; FUN_00640c10 */

void __fastcall FUN_00640c10(int *param_1)

{
  if ((8 < (uint)param_1[2]) && (*param_1 != 0)) {
    FUN_01674ea0(*param_1);
  }
  return;
}



/* FUNCTION 7217 ; VA 0x00640c30 ; FUN_00640c30 */

void __fastcall FUN_00640c30(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_005cf430(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 7218 ; VA 0x00640c60 ; FUN_00640c60 */

void __fastcall FUN_00640c60(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_0056cd30();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x10);
  }
  return;
}



/* FUNCTION 7219 ; VA 0x00640c90 ; FUN_00640c90 */

void __fastcall FUN_00640c90(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    piVar1 = *(int **)(*(int *)(param_1[1] + (iVar4 + param_1[3] + -1 & param_1[2] - 1) * 4) + 0x18)
    ;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x1c);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 7220 ; VA 0x00640d60 ; FUN_00640d60 */

void __fastcall FUN_00640d60(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00640e1d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00640e1d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7221 ; VA 0x00640e30 ; FUN_00640e30 */

void __fastcall FUN_00640e30(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_0056cd30();
        FUN_01674ea0(puVar6,0x10);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7222 ; VA 0x00640ec0 ; FUN_00640ec0 */

void __fastcall FUN_00640ec0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[5];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        FUN_01674ea0(puVar7,0x18);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7223 ; VA 0x00640f60 ; thunk_FUN_0056cd30 */

void __fastcall thunk_FUN_0056cd30(int *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  void *pvVar6;
  char cVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  LOCK();
  iVar4 = *(int *)(*param_1 + 0x28) + -1;
  ExceptionList = &pvStack_10;
  *(int *)(*param_1 + 0x28) = iVar4;
  UNLOCK();
  if (iVar4 != 0) {
    ExceptionList = pvVar6;
    return;
  }
  FUN_00585a90();
  uVar5 = DAT_01ea8518;
  EnterCriticalSection(DAT_01ea8518);
  cVar7 = FUN_00578b90(param_1);
  if (cVar7 == '\0') goto LAB_0056ce24;
  iVar4 = *param_1;
  piVar11 = (int *)(-(uint)(iVar4 != 0) & iVar4 + 0x30U);
  piVar8 = (int *)(DAT_01ea8514 + 0x28);
  if (DAT_01ea8514 == -0xc) {
    piVar8 = (int *)0x28;
  }
  *piVar8 = *piVar8 + -1;
  puVar1 = (undefined4 *)piVar11[1];
  piVar8 = *(int **)(*piVar11 + 4);
  if (piVar8 == piVar11) {
    piVar8 = (int *)*puVar1;
    *(undefined4 **)(*piVar11 + 4) = puVar1;
    if (piVar8 == piVar11) goto LAB_0056cdd0;
    piVar8 = *(int **)piVar11[1];
  }
  else if ((int *)*puVar1 == piVar11) {
    *piVar8 = (int)puVar1;
LAB_0056cdd0:
    piVar8 = (int *)piVar11[1];
  }
  else {
    *piVar8 = 0;
    *(int *)(*piVar11 + 4) = piVar11[1];
    piVar8 = *(int **)piVar11[1];
  }
  *piVar8 = *piVar11;
  uVar2 = *(uint *)(iVar4 + 0x24);
  if (0xf < uVar2) {
    iVar3 = *(int *)(iVar4 + 0x10);
    uVar10 = uVar2 + 1;
    iVar9 = iVar3;
    if (0xfff < uVar10) {
      iVar9 = *(int *)(iVar3 + -4);
      uVar10 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar10);
  }
  *(undefined4 *)(iVar4 + 0x20) = 0;
  *(undefined4 *)(iVar4 + 0x24) = 0xf;
  *(undefined *)(iVar4 + 0x10) = 0;
  FUN_01674ea0(iVar4,0x38);
LAB_0056ce24:
  LeaveCriticalSection(uVar5);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7224 ; VA 0x00640f70 ; FUN_00640f70 */

void __fastcall FUN_00640f70(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00640e1d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00640e1d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7225 ; VA 0x00640f80 ; FUN_00640f80 */

void __fastcall FUN_00640f80(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_0056cd30();
        FUN_01674ea0(puVar6,0x10);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7226 ; VA 0x00640f90 ; thunk_FUN_0056d250 */

void __fastcall thunk_FUN_0056d250(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x18);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7227 ; VA 0x00640fa0 ; FUN_00640fa0 */

void __fastcall FUN_00640fa0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[5];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        FUN_01674ea0(puVar7,0x18);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 7228 ; VA 0x00640fb0 ; FUN_00640fb0 */

void __fastcall FUN_00640fb0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0056cd30();
        FUN_0056cd30();
        iVar2 = iVar2 + 8;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xfffffff8;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 7229 ; VA 0x00641030 ; thunk_FUN_00642960 */

void __fastcall thunk_FUN_00642960(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x46) * 0x46;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 7230 ; VA 0x00641040 ; FUN_00641040 */

void __fastcall FUN_00641040(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar4 = iVar4 + 8;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = param_1[2] - iVar4 & 0xfffffff8;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 7231 ; VA 0x006410e0 ; FUN_006410e0 */

void __fastcall FUN_006410e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar6 = *(int *)(param_1 + 0x3c);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00576640(*(undefined4 *)(iVar6 + 4));
  *(int *)(*(int *)(param_1 + 0x3c) + 4) = iVar6;
  **(int **)(param_1 + 0x3c) = iVar6;
  *(int *)(*(int *)(param_1 + 0x3c) + 8) = iVar6;
  *(undefined4 *)(param_1 + 0x40) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x3c),0x2c);
  LOCK();
  iVar6 = *(int *)(param_1 + 0x38);
  *(int *)(param_1 + 0x38) = 0;
  UNLOCK();
  if (iVar6 != 0) {
    CloseHandle(iVar6);
  }
  iVar6 = *(int *)(param_1 + 0x28);
  if (iVar6 != 0) {
    iVar4 = *(int *)(param_1 + 0x2c);
    if (iVar6 != iVar4) {
      do {
        piVar2 = *(int **)(iVar6 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[1] + -1;
          piVar2[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar3 = piVar2[2] + -1;
            piVar2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        iVar6 = iVar6 + 8;
      } while (iVar6 != iVar4);
      iVar6 = *(int *)(param_1 + 0x28);
    }
    uVar5 = *(int *)(param_1 + 0x30) - iVar6 & 0xfffffff8;
    iVar4 = iVar6;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar6 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar6 - iVar4) - 4U) goto LAB_006412d9;
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = 0;
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  LOCK();
  iVar6 = *(int *)(param_1 + 0x24);
  *(int *)(param_1 + 0x24) = 0;
  UNLOCK();
  if (iVar6 != 0) {
    CloseHandle(iVar6);
  }
  iVar6 = *(int *)(param_1 + 0x18);
  while (iVar6 != 0) {
    piVar2 = *(int **)(*(int *)(*(int *)(param_1 + 0xc) +
                               (iVar6 + *(int *)(param_1 + 0x14) + -1 &
                               *(int *)(param_1 + 0x10) - 1U) * 4) + 0x18);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    piVar2 = (int *)(param_1 + 0x18);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      *(undefined4 *)(param_1 + 0x14) = 0;
    }
    iVar6 = *(int *)(param_1 + 0x18);
  }
  iVar6 = *(int *)(param_1 + 0x10);
  while (iVar6 != 0) {
    iVar6 = iVar6 + -1;
    iVar4 = *(int *)(*(int *)(param_1 + 0xc) + iVar6 * 4);
    if (iVar4 != 0) {
      FUN_01674ea0(iVar4,0x1c);
    }
  }
  iVar6 = *(int *)(param_1 + 0xc);
  if (iVar6 != 0) {
    uVar5 = *(int *)(param_1 + 0x10) * 4;
    iVar4 = iVar6;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar6 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar6 - iVar4) - 4U) {
LAB_006412d9:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 8),8);
  *(undefined4 *)(param_1 + 8) = 0;
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar6 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7232 ; VA 0x006412e0 ; FUN_006412e0 */

void __fastcall FUN_006412e0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x18);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x006412f3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 7233 ; VA 0x00641300 ; FUN_00641300 */

void FUN_00641300(void)

{
  FUN_0056cd30();
  FUN_0056cd30();
  return;
}



/* FUNCTION 7234 ; VA 0x00641320 ; FUN_00641320 */

void __fastcall FUN_00641320(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a950;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::Server::vftable;
  param_1[0x15] = RBX::Network::Server::vftable;
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"NetworkServer:Destroy",0);
  }
  iVar3 = param_1[0x121];
  piVar4 = param_1 + 0x121;
  uStack_8 = 0;
  FUN_00576720(*(undefined4 *)(iVar3 + 4));
  *(int *)(*piVar4 + 4) = iVar3;
  *(int *)*piVar4 = iVar3;
  *(int *)(*piVar4 + 8) = iVar3;
  param_1[0x122] = 0;
  FUN_01674ea0(*piVar4,0x28);
  iVar3 = param_1[0x11f];
  piVar4 = param_1 + 0x11f;
  uStack_8 = 1;
  FUN_00576720(*(undefined4 *)(iVar3 + 4));
  *(int *)(*piVar4 + 4) = iVar3;
  *(int *)*piVar4 = iVar3;
  *(int *)(*piVar4 + 8) = iVar3;
  param_1[0x120] = 0;
  FUN_01674ea0(*piVar4,0x28);
  FUN_016790b0();
  LOCK();
  iVar3 = param_1[0x119];
  param_1[0x119] = 0;
  UNLOCK();
  if (iVar3 != 0) {
    CloseHandle(iVar3);
  }
  FUN_0056cd30();
  FUN_0056cd30();
  FUN_0056cd30();
  FUN_0056cd30();
  piVar4 = (int *)param_1[0x111];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x10c];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00640ec0();
  FUN_0056d250();
  LOCK();
  iVar3 = param_1[0xfe];
  param_1[0xfe] = 0;
  UNLOCK();
  if (iVar3 != 0) {
    CloseHandle(iVar3);
  }
  FUN_00640e30();
  FUN_00640e30();
  FUN_00640fb0();
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = param_1[0xe8];
  if (iVar3 != 0) {
    piVar4 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar3 = param_1[0xe7];
  if (iVar3 != 0) {
    piVar4 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar3 = param_1[0xe6];
  if (iVar3 != 0) {
    piVar4 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_006d21e0();
  piVar4 = (int *)param_1[0x48];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x46];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x44];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_006c4520();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7235 ; VA 0x00641610 ; FUN_00641610 */

int * __thiscall FUN_00641610(int param_1,byte *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  byte *pbVar9;
  byte *pbVar10;
  bool bVar11;
  int aiStack_4c [5];
  uint uStack_38;
  uint uStack_34;
  int *piStack_30;
  undefined2 uStack_2c;
  uint uStack_28;
  int *piStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a08a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uStack_20 = FUN_005702d0(param_2);
  uStack_28 = *(uint *)(param_1 + 4);
  puStack_18 = (uint *)(param_1 + 4);
  uStack_1c = uStack_20 % uStack_28;
  if (*(int *)(param_1 + 8) != 0) {
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uStack_1c * 4);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      param_1 = iStack_14;
      if (uStack_20 == puVar5[1]) {
        pbVar9 = (byte *)(puVar5 + 2);
        piStack_24 = (int *)puVar5[6];
        if (0xf < (uint)puVar5[7]) {
          pbVar9 = *(byte **)pbVar9;
        }
        uVar3 = *(uint *)(param_2 + 0x10);
        pbVar10 = param_2;
        if (0xf < *(uint *)(param_2 + 0x14)) {
          pbVar10 = *(byte **)param_2;
        }
        if ((int *)uVar3 == piStack_24) {
          while (uVar2 = uVar3 - 4, 3 < uVar3) {
            if (*(int *)pbVar10 != *(int *)pbVar9) goto LAB_006416d6;
            pbVar10 = pbVar10 + 4;
            pbVar9 = pbVar9 + 4;
            uVar3 = uVar2;
          }
          if (uVar2 == 0xfffffffc) {
LAB_0064170a:
            uVar3 = 0;
          }
          else {
LAB_006416d6:
            bVar11 = *pbVar10 < *pbVar9;
            if ((*pbVar10 == *pbVar9) &&
               ((uVar2 == 0xfffffffd ||
                ((bVar11 = pbVar10[1] < pbVar9[1], pbVar10[1] == pbVar9[1] &&
                 ((uVar2 == 0xfffffffe ||
                  ((bVar11 = pbVar10[2] < pbVar9[2], pbVar10[2] == pbVar9[2] &&
                   ((uVar2 == 0xffffffff ||
                    (bVar11 = pbVar10[3] < pbVar9[3], pbVar10[3] == pbVar9[3]))))))))))))
            goto LAB_0064170a;
            uVar3 = -(uint)bVar11 | 1;
          }
          if (uVar3 == 0) {
            if (puVar5 != (undefined4 *)0x0) {
              ExceptionList = pvStack_10;
              return puVar5 + 2;
            }
            break;
          }
        }
      }
      else if ((uint)puVar5[1] % uStack_28 != uStack_1c) break;
    }
  }
  piStack_30 = (int *)0x0;
  uStack_2c = 0;
  uStack_34 = -(uint)(param_1 != -3) & param_1 + 4U;
  iStack_8 = 0;
  FUN_0054ef60(param_2);
  iStack_8._0_1_ = 1;
  uStack_2c = 0;
  piVar4 = (int *)FUN_01674e20(0x28);
  uStack_2c = CONCAT11(uStack_2c._1_1_,1);
  piStack_24 = piVar4 + 2;
  *piVar4 = 0;
  piVar4[1] = 0;
  *piStack_24 = 0;
  piVar4[3] = 0;
  piVar4[4] = 0;
  piVar4[5] = 0;
  piVar4[6] = 0;
  piVar4[7] = 0;
  piVar4[8] = 0;
  piVar4[9] = 0;
  piStack_30 = piVar4;
  FUN_0054ef60(aiStack_4c);
  piVar4[8] = 0;
  piVar4[9] = 0;
  uStack_2c = CONCAT11(1,(undefined)uStack_2c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_38) {
    uVar3 = uStack_38 + 1;
    iVar6 = aiStack_4c[0];
    if (0xfff < uVar3) {
      iVar6 = *(int *)(aiStack_4c[0] + -4);
      uVar3 = uStack_38 + 0x24;
      if (0x1f < (aiStack_4c[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar3);
  }
  iVar6 = iStack_14;
  uVar2 = *(uint *)(iStack_14 + 8);
  uVar3 = uVar2 + 1;
  if (*(int *)(iStack_14 + 0x14) == 0) {
    uVar3 = FUN_005c9310(uVar3);
    if (uVar3 <= *puStack_18) {
      uVar3 = *puStack_18;
    }
    FUN_005d2b00(uVar3);
  }
  else if (*(uint *)(iStack_14 + 0x10) < uVar3) {
    uVar7 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar3) {
      uVar7 = 1;
    }
    uVar3 = FUN_005c9310(uVar7 + uVar2);
    if (uVar3 != *puStack_18) {
      FUN_005d2b00(uVar3);
      puVar5 = (undefined4 *)(*(int *)(iVar6 + 0x14) + *puStack_18 * 4);
      puVar1 = (undefined4 *)*puVar5;
      while (puVar1 != (undefined4 *)0x0) {
        piVar4 = (int *)(*(int *)(iStack_14 + 0x14) + ((uint)puVar1[1] % *puStack_18) * 4);
        if (*(int *)(*(int *)(iStack_14 + 0x14) + ((uint)puVar1[1] % *puStack_18) * 4) == 0) {
          *piVar4 = (int)puVar5;
          puVar5 = puVar1;
        }
        else {
          *puVar5 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar4;
          *(undefined4 **)*piVar4 = puVar1;
        }
        piVar4 = piStack_30;
        puVar1 = (undefined4 *)*puVar5;
      }
    }
  }
  piVar4[1] = uStack_20;
  uVar3 = *puStack_18;
  iVar6 = *(int *)(iStack_14 + 0x14);
  piVar8 = *(int **)(iVar6 + (uStack_20 % uVar3) * 4);
  puVar5 = (undefined4 *)(iVar6 + (uStack_20 % uVar3) * 4);
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)(iVar6 + uVar3 * 4);
    if (*piVar8 != 0) {
      *(int **)(iVar6 + (*(uint *)(*piVar8 + 4) % uVar3) * 4) = piVar4;
    }
    *puVar5 = piVar8;
    *piVar4 = *piVar8;
  }
  else {
    *piVar4 = *piVar8;
    piVar8 = (int *)*puVar5;
  }
  *piVar8 = (int)piVar4;
  *(int *)(iStack_14 + 8) = *(int *)(iStack_14 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_24;
}



/* FUNCTION 7236 ; VA 0x00641930 ; FUN_00641930 */

int * __thiscall FUN_00641930(byte *param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  piVar1 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a08c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_00a33fd0(param_2);
  FUN_0063f830(&param_2,uVar4,piVar1,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    param_2 = (int *)*piVar1;
    LOCK();
    *(int *)((int)param_2 + 0x28) = *(int *)((int)param_2 + 0x28) + 1;
    UNLOCK();
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    piVar5 = (int *)FUN_01674e20(0x10);
    piVar1 = piVar5 + 2;
    *piVar5 = 0;
    piVar5[1] = 0;
    piVar1[0] = 0;
    piVar1[1] = 0;
    *piVar1 = (int)param_2;
    LOCK();
    *(int *)((int)param_2 + 0x28) = *(int *)((int)param_2 + 0x28) + 1;
    UNLOCK();
    if (piVar5 + 3 != (int *)0x0) {
      piVar5[3] = 0;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_0056cd30();
    uVar2 = *(uint *)(param_1 + 8);
    uVar6 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar6 = FUN_005c9310(uVar6);
      if (uVar6 <= *(uint *)(param_1 + 4)) {
        uVar6 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar6);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar6) {
      param_2 = (int *)0x1;
      uVar8 = uVar2 >> 1;
      if (uVar2 + (uVar2 >> 1) <= uVar6) {
        uVar8 = 1;
      }
      iVar7 = FUN_005c9310(uVar8 + uVar2);
      if (iVar7 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar7);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar10;
        while (puVar3 != (undefined4 *)0x0) {
          piVar9 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar9 = (int)puVar10;
            puVar10 = puVar3;
          }
          else {
            *puVar10 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar9;
            *(undefined4 **)*piVar9 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar10;
        }
      }
    }
    piVar5[1] = uVar4;
    uVar4 = uVar4 % *(uint *)(param_1 + 4);
    piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    if (piVar9 == (int *)0x0) {
      piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar9 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar5;
      }
      *puVar10 = piVar9;
      *piVar5 = *piVar9;
    }
    else {
      *piVar5 = *piVar9;
      piVar9 = (int *)*puVar10;
    }
    *piVar9 = (int)piVar5;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 7237 ; VA 0x00641b10 ; FUN_00641b10 */

int * __thiscall FUN_00641b10(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a08d8;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar8 = uVar4;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar8 = ~uVar4;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar5 ^ uVar8;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x18);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[3] = uVar4;
    piVar3[2] = iVar5;
    if (piVar3 + 4 != (int *)0x0) {
      piVar3[4] = 0;
    }
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005c9310(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      param_2 = (int *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005c9310(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 7238 ; VA 0x00641d00 ; FUN_00641d00 */

int * __thiscall FUN_00641d00(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a08f8;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar8 = uVar4;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar8 = ~uVar4;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar5 ^ uVar8;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x18);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[2] = iVar5;
    piVar3[3] = uVar4;
    piVar3[4] = 0;
    piVar3[5] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005c9310(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      param_2 = (int *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005c9310(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 7239 ; VA 0x00641ef0 ; FUN_00641ef0 */

int __thiscall FUN_00641ef0(int *param_1,int param_2)

{
  return *param_1 + param_2 * 0x18;
}



/* FUNCTION 7240 ; VA 0x00641f10 ; FUN_00641f10 */

/* WARNING: Removing unreachable block (ram,0x00641f62) */
/* WARNING: Removing unreachable block (ram,0x00641f72) */
/* WARNING: Removing unreachable block (ram,0x00641f78) */

void * __thiscall FUN_00641f10(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0928;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 7241 ; VA 0x00641ff5 ; Catch@00641ff5 */

undefined * Catch_00641ff5(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00642006;
}



/* FUNCTION 7242 ; VA 0x00642020 ; FUN_00642020 */

/* WARNING: Removing unreachable block (ram,0x00642072) */
/* WARNING: Removing unreachable block (ram,0x00642082) */
/* WARNING: Removing unreachable block (ram,0x00642088) */

void __fastcall FUN_00642020(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0958;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar1);
  }
  FUN_0056d2d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7243 ; VA 0x006420dc ; Catch@006420dc */

undefined * Catch_006420dc(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_006420ed;
}



/* FUNCTION 7244 ; VA 0x006420ff ; FUN_006420ff */

void FUN_006420ff(void)

{
  FUN_006421c0();
  return;
}



/* FUNCTION 7245 ; VA 0x00642107 ; FUN_00642107 */

void FUN_00642107(void)

{
  FUN_006422e0();
  return;
}



/* FUNCTION 7246 ; VA 0x00642110 ; FUN_00642110 */

int __thiscall FUN_00642110(int param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 8);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x10) - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 7247 ; VA 0x00642180 ; FUN_00642180 */

int __thiscall FUN_00642180(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 7248 ; VA 0x006421c0 ; FUN_006421c0 */

undefined4 __thiscall FUN_006421c0(undefined4 param_1,byte param_2)

{
  FUN_006c4520();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x100);
  }
  return param_1;
}



/* FUNCTION 7249 ; VA 0x006421f0 ; FUN_006421f0 */

undefined4 __thiscall FUN_006421f0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x74);
  }
  return param_1;
}


