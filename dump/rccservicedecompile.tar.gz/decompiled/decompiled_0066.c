/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 16500 ; VA 0x00926c40 ; FUN_00926c40 */

void FUN_00926c40(void)

{
  int iVar1;
  
  if (DAT_01ee1e9c == 0) {
    iVar1 = FUN_00913630();
    DAT_01ee1e9c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16501 ; VA 0x00926c60 ; FUN_00926c60 */

void __thiscall FUN_00926c60(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 0xc0);
  uVar2 = *(undefined4 *)(param_1 + 0xc4);
  uVar3 = *(undefined4 *)(param_1 + 200);
  *param_2 = *(undefined4 *)(param_1 + 0xbc);
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0xd0);
  uVar2 = *(undefined4 *)(param_1 + 0xd4);
  uVar3 = *(undefined4 *)(param_1 + 0xd8);
  param_2[4] = *(undefined4 *)(param_1 + 0xcc);
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0xe0);
  uVar2 = *(undefined4 *)(param_1 + 0xe4);
  uVar3 = *(undefined4 *)(param_1 + 0xe8);
  param_2[8] = *(undefined4 *)(param_1 + 0xdc);
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  return;
}



/* FUNCTION 16502 ; VA 0x00926ca0 ; FUN_00926ca0 */

undefined4 __fastcall FUN_00926ca0(int param_1)

{
  return *(undefined4 *)(param_1 + 100);
}



/* FUNCTION 16503 ; VA 0x00926cb0 ; FUN_00926cb0 */

int __fastcall FUN_00926cb0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  piVar4 = (int *)0x0;
  iVar3 = *(int *)(param_1 + 0xb8);
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    iVar3 = *(int *)(iVar3 + 4);
    while (iVar3 != 0) {
      LOCK();
      iVar1 = *piVar2;
      if (iVar3 == iVar1) {
        *piVar2 = iVar3 + 1;
        iVar1 = iVar3;
      }
      UNLOCK();
      if (iVar1 == iVar3) {
        iVar3 = *(int *)(param_1 + 0xb4);
        piVar4 = *(int **)(param_1 + 0xb8);
        if (iVar3 != 0) goto LAB_00926cf7;
        break;
      }
      iVar3 = *piVar2;
    }
  }
  iVar3 = 0;
LAB_00926cf7:
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar1 = piVar4[1] + -1;
    piVar4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar2 = piVar4 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return iVar3;
}



/* FUNCTION 16504 ; VA 0x00926d50 ; FUN_00926d50 */

undefined4 __fastcall FUN_00926d50(int param_1)

{
  return *(undefined4 *)(param_1 + 0xa4);
}



/* FUNCTION 16505 ; VA 0x00926d60 ; FUN_00926d60 */

undefined __fastcall FUN_00926d60(int param_1)

{
  return *(undefined *)(param_1 + 0xa9);
}



/* FUNCTION 16506 ; VA 0x00926d70 ; FUN_00926d70 */

float10 FUN_00926d70(void)

{
  return (float10)0;
}



/* FUNCTION 16507 ; VA 0x00926df0 ; FUN_00926df0 */

undefined4 __thiscall FUN_00926df0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x100);
  return param_2;
}



/* FUNCTION 16508 ; VA 0x00926e10 ; FUN_00926e10 */

undefined4 __fastcall FUN_00926e10(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  char *pcVar5;
  undefined auStack_28 [12];
  int aiStack_1c [2];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8910;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00562c90(aiStack_1c,&stack0x00000004);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (aiStack_1c[0] == 0) {
    pcVar5 = "player argument must be of type Player";
  }
  else {
    iVar1 = FUN_0064e810(param_1);
    if (((iVar1 != 0) && (*(int *)(param_1 + 0x34) == iVar1)) &&
       (*(int *)(aiStack_1c[0] + 0x34) == iVar1)) {
      iStack_14 = FUN_00917170(param_1);
      if (iStack_14 != 0) {
        uVar3 = FUN_00928340();
        uVar4 = FUN_00928340();
        uVar2 = FUN_00bf1ef0(uVar4,uVar3);
        FUN_00550b30();
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return uVar2;
      }
      FUN_00550b30();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return 0;
    }
    pcVar5 = "Player objects must be children of \'Players\'";
  }
  FUN_00550130(pcVar5);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_28,&DAT_01c17198);
}



/* FUNCTION 16509 ; VA 0x00926f10 ; FUN_00926f10 */

void __thiscall
FUN_00926f10(int param_1,int param_2,uint param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 *param_8,ulonglong param_9,
            char *param_10,undefined4 param_11,uint param_12,undefined4 param_13,undefined4 param_14
            ,undefined4 param_15,undefined8 param_16)

{
  int iVar1;
  int iVar2;
  int extraout_EDX;
  undefined8 uVar3;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  undefined8 uStack_4c;
  char *pcStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8938;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (200 < param_2) {
    uStack_2c = 0x1931ce000000002;
    puStack_30 = (undefined4 *)0x926f4e;
    ExceptionList = &pvStack_10;
    FUN_0086f2f0();
  }
  if (param_1 == 0) {
LAB_0092700c:
    uStack_2c = CONCAT44(param_1,0x927012);
    iVar2 = FUN_006719d0();
    if (iVar2 != 0) {
      uStack_2c = CONCAT44(0x927026,(undefined4)uStack_2c);
      uVar3 = FUN_00928340();
      pcStack_44 = (char *)0x0;
      if (param_10 != (char *)0x0) {
        pcStack_44 = param_10;
        if (((uint)param_10 & 1) == 0) {
          uStack_4c = ZEXT48(&uStack_3c);
          puStack_50 = &param_12;
          uStack_54 = 0x92706f;
          (**(code **)((uint)param_10 & 0xfffffffe))();
        }
        else {
          uStack_3c = param_12;
          uStack_38 = param_13;
          uStack_34 = param_14;
          puStack_30 = (undefined4 *)param_15;
          uStack_2c = param_16;
        }
      }
      uStack_8._0_1_ = 2;
      if (param_3 != 0) {
        if ((param_3 & 1) == 0) {
          (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_5c,0);
        }
        else {
          uStack_5c = param_5;
          uStack_58 = param_6;
          uStack_54 = param_7;
          puStack_50 = param_8;
          uStack_4c = param_9;
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00bf1f90(uVar3,param_2);
      goto LAB_009270f8;
    }
    uStack_40 = 0x17;
    pcStack_44 = "Player not in Workspace";
  }
  else {
    iVar2 = *(int *)(param_1 + 0x34);
    iVar1 = param_1;
    if (iVar2 == 0) {
LAB_00926f6f:
    }
    else {
      iVar1 = iVar2;
      if (*(int *)(iVar2 + 0x34) != 0) {
        uStack_2c = CONCAT44(0x926f6f,(undefined4)uStack_2c);
        iVar1 = FUN_005c8ac0();
        goto LAB_00926f6f;
      }
    }
    if (iVar1 == 0) goto LAB_0092700c;
    iVar2 = *(int *)(iVar1 + 0xc);
    uStack_2c = CONCAT44(0x926f81,(undefined4)uStack_2c);
    iVar1 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar1 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8)) goto LAB_0092700c;
    uStack_2c = CONCAT44(0x926fa3,(undefined4)uStack_2c);
    iVar2 = FUN_005cf750();
    if (iVar2 == 0) goto LAB_0092700c;
    if (param_1 != *(int *)(iVar2 + 0xf4)) {
      uStack_40 = 0x34;
      uStack_2c = 0xf00000000;
      pcStack_44 = "GetFriendsOnline must be invoked on the Local Player";
      uStack_3c = uStack_3c & 0xffffff00;
      uStack_4c = CONCAT44(0x926fd4,(undefined4)uStack_4c);
      FUN_005542c0();
      uStack_40 = 0x926fdc;
      FUN_005e65e0();
      goto LAB_0092700c;
    }
    if (DAT_01d641cc == '\0') goto LAB_0092700c;
    uStack_2c = CONCAT44(0x926fee,(undefined4)uStack_2c);
    FUN_00928340();
    if ((0 < extraout_EDX) || (-1 < extraout_EDX)) goto LAB_0092700c;
    uStack_40 = 0x29;
    pcStack_44 = "GetFriendsOnline does not work for guests";
  }
  uStack_2c = 0xf00000000;
  uStack_3c = uStack_3c & 0xffffff00;
  uStack_4c = CONCAT44(0x9270f0,(undefined4)uStack_4c);
  FUN_005542c0();
  uStack_40 = 0x9270f8;
  FUN_005e65e0();
LAB_009270f8:
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_30 = &param_5;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x927119;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_10 != (char *)0x0) && (((uint)param_10 & 1) == 0)) &&
     (*(code **)((uint)param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &param_12;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x927147;
    (**(code **)((uint)param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16510 ; VA 0x00927160 ; FUN_00927160 */

float10 __fastcall FUN_00927160(int param_1)

{
  return (float10)(float)(**(uint **)(param_1 + 0x1fc) ^ (uint)*(uint **)(param_1 + 0x1fc));
}



/* FUNCTION 16511 ; VA 0x009271a0 ; FUN_009271a0 */

float10 __fastcall FUN_009271a0(double *param_1)

{
  undefined4 *puVar1;
  undefined auStack_18 [8];
  double dStack_10;
  float fStack_8;
  
  if ((NAN(*(float *)((int)param_1 + 0x14)) == (*(float *)((int)param_1 + 0x14) == 0.0)) &&
     (NAN(*(float *)(param_1 + 2)) == (*(float *)(param_1 + 2) == 0.0))) {
    FUN_016830f0(&dStack_10);
    fStack_8 = *(float *)(param_1 + 1) -
               (float)(dStack_10 - *param_1) *
               (*(float *)(param_1 + 2) / *(float *)((int)param_1 + 0x14));
    if (fStack_8 <= 0.0) {
      fStack_8 = 0.0;
      *(undefined4 *)(param_1 + 1) = 0;
      puVar1 = (undefined4 *)FUN_016830f0(auStack_18);
      *(undefined4 *)param_1 = *puVar1;
      *(undefined4 *)((int)param_1 + 4) = puVar1[1];
    }
    return (float10)fStack_8;
  }
  return (float10)0;
}



/* FUNCTION 16512 ; VA 0x00927240 ; FUN_00927240 */

undefined4 __thiscall FUN_00927240(int param_1,undefined4 param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_34 [16];
  int iStack_24;
  undefined auStack_1c [4];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((((DAT_01d64234 != '\0') &&
       (ExceptionList = &pvStack_10, iVar3 = FUN_008f78c0(param_1), iVar3 != 0)) &&
      (cVar2 = FUN_008ff0d0(), cVar2 != '\0')) && (iVar3 != -0xc)) {
    FUN_005789c0(&DAT_01eaddec,&LAB_00670c70);
    uVar4 = FUN_00675c30();
    piVar5 = (int *)FUN_008aa140(uVar4);
    piStack_14 = piVar5;
    if (*piVar5 == 0) {
      uVar4 = FUN_00abe2a0();
      piVar6 = (int *)FUN_008a9ba0(auStack_1c,uVar4);
      iVar3 = *piVar6;
      iVar1 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      *piVar5 = iVar3;
      piVar6 = (int *)piVar5[1];
      piVar5[1] = iVar1;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar3 = piVar6[1] + -1;
        piVar6[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar3 = piVar6[2] + -1;
          piVar6[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_18[1] + -1;
        piStack_18[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar5 = piStack_18 + 2;
          iVar3 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    if ((*piStack_14 != 0) && (cVar2 = FUN_007cfe50(), cVar2 != '\0')) {
      FUN_00abea30(auStack_34);
      uStack_8 = 0;
      if (iStack_24 != 0) {
        FUN_0054ef20(auStack_34);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_2;
      }
      FUN_0054ef60(param_1 + 0x22c);
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  FUN_0054ef60(param_1 + 0x22c);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16513 ; VA 0x009273c0 ; FUN_009273c0 */

undefined4 __thiscall FUN_009273c0(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = param_1 + 0x244;
  if (*(int *)(param_1 + 0x254) == 0) {
    iVar1 = param_1 + 0x22c;
  }
  FUN_0054ef60(iVar1);
  return param_2;
}



/* FUNCTION 16514 ; VA 0x009273f0 ; FUN_009273f0 */

void __thiscall FUN_009273f0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x494) == 0) {
    iVar4 = FUN_0097bfc0(param_1);
    if (param_1 == iVar4) {
      puVar5 = (undefined4 *)FUN_00916660(auStack_c);
      uVar1 = *puVar5;
      uVar2 = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      *(undefined4 *)(param_1 + 0x494) = uVar1;
      piVar3 = *(int **)(param_1 + 0x498);
      *(undefined4 *)(param_1 + 0x498) = uVar2;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      if (piStack_8 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_8[1] + -1;
        piStack_8[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_8)();
          LOCK();
          piVar3 = piStack_8 + 2;
          iVar4 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_8 + 4))();
          }
        }
      }
      *(undefined *)(*(int *)(param_1 + 0x494) + 0x22) = 1;
      iVar4 = FUN_005c3ac0(param_1);
      if (iVar4 != 0) {
        FUN_00e8a020(iVar4);
      }
    }
  }
  iVar4 = *(int *)(param_1 + 0x498);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = *(int *)(param_1 + 0x498);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x494);
  param_2[1] = iVar4;
  return;
}



/* FUNCTION 16515 ; VA 0x00927510 ; FUN_00927510 */

void FUN_00927510(void)

{
  FUN_0068b520();
  return;
}



/* FUNCTION 16516 ; VA 0x00927520 ; FUN_00927520 */

undefined4 __thiscall FUN_00927520(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x1fc);
  return param_2;
}



/* FUNCTION 16517 ; VA 0x00927540 ; FUN_00927540 */

undefined4 __thiscall FUN_00927540(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x118);
  return param_2;
}



/* FUNCTION 16518 ; VA 0x00927560 ; thunk_FUN_0068f830 */

int __fastcall thunk_FUN_0068f830(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00c91ca0(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 16519 ; VA 0x00927570 ; thunk_FUN_00676db0 */

int __fastcall thunk_FUN_00676db0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00b56e90(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 16520 ; VA 0x00927580 ; FUN_00927580 */

undefined8 *
FUN_00927580(undefined8 *param_1,undefined4 param_2,int *param_3,int *param_4,int param_5)

{
  int *piVar1;
  undefined8 uVar2;
  float *pfVar3;
  undefined8 *puVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  float10 fVar8;
  float fVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  undefined auStack_d4 [12];
  undefined auStack_c8 [12];
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_b0;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  undefined8 uStack_74;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  undefined8 uStack_3c;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8958;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pfVar3 = (float *)FUN_00b077e0();
  fStack_a4 = *pfVar3;
  fStack_a0 = pfVar3[1];
  fStack_9c = pfVar3[2];
  fStack_98 = pfVar3[3];
  fStack_94 = pfVar3[4];
  fStack_90 = pfVar3[5];
  fStack_8c = pfVar3[6];
  fStack_88 = pfVar3[7];
  fStack_84 = pfVar3[8];
  fStack_80 = pfVar3[9];
  fStack_7c = pfVar3[10];
  fStack_78 = pfVar3[0xb];
  puVar4 = (undefined8 *)FUN_00b08320();
  uStack_3c = *puVar4;
  fStack_34 = *(float *)(puVar4 + 1);
  fVar9 = (float)uStack_3c * DAT_018ce2f4 - DAT_018ce2f8;
  fStack_20 = 0.0;
  if (0.0 <= fVar9) {
    fStack_20 = fVar9;
  }
  fStack_18 = 0.0;
  fVar9 = fStack_34 * DAT_018ce2f4 - DAT_018ce2f8;
  fStack_24 = 0.0;
  if (0.0 <= fVar9) {
    fStack_24 = fVar9;
  }
  fStack_1c = 0.0;
  fStack_14 = 0.0;
  if (param_3 != (int *)0x0) {
    pfVar3 = (float *)(**(code **)(*param_3 + 0xa4))(auStack_d4);
    fStack_14 = pfVar3[3] - *pfVar3;
    fStack_1c = pfVar3[4] - pfVar3[1];
    fStack_18 = pfVar3[5] - pfVar3[2];
  }
  dVar10 = (double)(fStack_1c * fStack_1c + fStack_14 * fStack_14 + fStack_18 * fStack_18);
  if (NAN(dVar10) == (dVar10 == 0.0)) {
    uStack_68 = (double)CONCAT44((uint)((ulonglong)dVar10 >> 0x20) & DAT_018c0da0._4_4_,
                                 SUB84(dVar10,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    uStack_58 = (double)CONCAT44((uint)((ulonglong)(dVar10 - 0.0) >> 0x20) & DAT_018c0da0._4_4_,
                                 SUB84(dVar10 - 0.0,0) & (uint)DAT_018c0da0);
    fVar8 = (float10)FUN_01160810();
    uStack_60 = (double)fVar8;
    dVar10 = DAT_018f76b0;
    if ((NAN(uStack_68) || NAN(uStack_60)) == (uStack_68 == uStack_60)) {
      dVar10 = uStack_68 * DAT_018f76b0;
    }
    fVar11 = fStack_14;
    fVar12 = fStack_18;
    fVar9 = fStack_1c;
    if (dVar10 < uStack_58) goto LAB_0092774f;
  }
  fVar11 = DAT_01ee1c3c;
  fVar12 = DAT_01ee1c44;
  fVar9 = DAT_01ee1c40;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1c48) &&
     (FUN_016f3809(&DAT_01ee1c48), fVar11 = DAT_01ee1c3c, fVar12 = DAT_01ee1c44,
     fVar9 = DAT_01ee1c40, DAT_01ee1c48 == -1)) {
    DAT_01ee1c3c = 2.5;
    DAT_01ee1c40 = 2.5;
    DAT_01ee1c44 = 2.5;
    FUN_016f37bf(&DAT_01ee1c48);
    fVar11 = DAT_01ee1c3c;
    fVar12 = DAT_01ee1c44;
    fVar9 = DAT_01ee1c40;
  }
LAB_0092774f:
  uVar2 = CONCAT44(fStack_7c,fStack_80);
  iVar6 = (int)((fStack_24 * fStack_20 * DAT_018e3f8c) / (fVar9 * fVar11));
  if (iVar6 < 2) {
    *param_1 = uVar2;
    *(float *)(param_1 + 1) = fStack_78;
  }
  else {
    iVar7 = iVar6 * 2;
    if (SBORROW4(DAT_01d640c8,iVar6 * 2) != DAT_01d640c8 + iVar6 * -2 < 0) {
      iVar7 = DAT_01d640c8;
    }
    iVar6 = 0;
    fStack_14 = fStack_78;
    uStack_60 = (double)CONCAT44(*(undefined4 *)(*(int *)(param_5 + 0x1b4) + 0x6ac),
                                 (undefined4)uStack_60);
    fStack_18 = (float)DAT_01d640d0 * fVar9;
    uStack_58 = (double)CONCAT44(fStack_18,(undefined4)uStack_58);
    fStack_b0 = fVar11 * DAT_018ce2f4;
    fStack_ac = fVar9 * DAT_018ce2f4;
    fStack_a8 = fVar12 * DAT_018ce2f4;
    fVar9 = fStack_78;
    uStack_74 = uVar2;
    if (0 < iVar7) {
      fStack_1c = (float)((uint)fStack_20 ^ DAT_018c4ea0);
      fStack_20 = fStack_20 - fStack_1c;
      fStack_40 = (float)((uint)fStack_24 ^ DAT_018c4ea0);
      fStack_24 = fStack_24 - fStack_40;
      fStack_48 = fStack_a0 * 0.0;
      fStack_4c = fStack_94 * 0.0;
      fStack_50 = fStack_88 * 0.0;
      uStack_68 = (double)CONCAT44(uStack_3c._4_4_ * DAT_018ce2f4,(undefined4)uStack_68);
      do {
        iVar5 = FUN_0171d737();
        fStack_44 = ((float)iVar5 * fStack_20) / DAT_01901f68 + fStack_1c;
        iVar5 = FUN_0171d737();
        fVar9 = ((float)iVar5 * fStack_24) / DAT_01901f68 + fStack_40;
        fStack_bc = fStack_a4 * fStack_44 + fStack_48 + fStack_9c * fVar9 + fStack_80;
        fStack_b8 = fStack_98 * fStack_44 + fStack_4c + fStack_90 * fVar9 + fStack_7c;
        fStack_b4 = fStack_8c * fStack_44 + fStack_50 + fStack_84 * fVar9 + fStack_78;
        pfVar3 = (float *)FUN_00ce1340(auStack_c8,uStack_58._4_4_,&fStack_bc,&fStack_b0);
        fStack_30 = *pfVar3 - 0.0;
        fStack_2c = pfVar3[1] - fStack_ac;
        fStack_28 = pfVar3[2] - 0.0;
        if ((fStack_2c - fStack_7c) - uStack_68._4_4_ < DAT_018ce2f8) {
          uStack_74 = CONCAT44(fStack_2c,fStack_30);
          fVar9 = fStack_28;
          break;
        }
        if (fStack_2c < fStack_18) {
          uStack_74 = CONCAT44(fStack_2c,fStack_30);
          fStack_18 = fStack_2c;
          fStack_14 = fStack_28;
        }
        iVar6 = iVar6 + 1;
        fVar9 = fStack_14;
      } while (iVar6 < iVar7);
    }
    uStack_74 = CONCAT44(uStack_3c._4_4_ * DAT_018ce2f4 + fStack_7c,(undefined4)uStack_74);
    *param_1 = uStack_74;
    *(float *)(param_1 + 1) = fVar9;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar6 = param_4[1] + -1;
    param_4[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16521 ; VA 0x00927ac0 ; FUN_00927ac0 */

void __thiscall
FUN_00927ac0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,char *param_11,undefined4 param_12,uint param_13,undefined4 param_14,
            undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  undefined8 uStack_4c;
  char *pcStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8988;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    ExceptionList = &pvStack_10;
    if (iVar4 == 0) {
LAB_00927b04:
    }
    else {
      iVar3 = iVar4;
      ExceptionList = &pvStack_10;
      if (*(int *)(iVar4 + 0x34) != 0) {
        uStack_2c = CONCAT44(0x927b04,(undefined4)uStack_2c);
        ExceptionList = &pvStack_10;
        iVar3 = FUN_005c8ac0();
        goto LAB_00927b04;
      }
    }
    if (iVar3 != 0) {
      iVar4 = *(int *)(iVar3 + 0xc);
      uStack_2c = CONCAT44(0x927b16,(undefined4)uStack_2c);
      iVar3 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        uStack_2c = CONCAT44(0x927b3c,(undefined4)uStack_2c);
        iVar4 = FUN_00916100();
        if (iVar4 != 0) {
          uVar1 = *(undefined4 *)(param_1 + 0xf0);
          uVar2 = *(undefined4 *)(param_1 + 0xf4);
          pcStack_44 = (char *)0x0;
          if (param_11 != (char *)0x0) {
            pcStack_44 = param_11;
            if (((uint)param_11 & 1) == 0) {
              uStack_4c = ZEXT48(&uStack_3c);
              puStack_50 = &param_13;
              uStack_54 = 0x927b9c;
              (**(code **)((uint)param_11 & 0xfffffffe))();
            }
            else {
              uStack_3c = param_13;
              uStack_38 = param_14;
              uStack_34 = param_15;
              puStack_30 = (undefined4 *)param_16;
              uStack_2c = param_17;
            }
          }
          uStack_8._0_1_ = 2;
          if (param_4 != 0) {
            if ((param_4 & 1) == 0) {
              (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_5c,0);
            }
            else {
              uStack_5c = param_6;
              uStack_58 = param_7;
              uStack_54 = param_8;
              puStack_50 = param_9;
              uStack_4c = param_10;
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_00cb1050(uVar1,uVar2,param_2,param_3);
          goto LAB_00927c28;
        }
      }
    }
  }
  uStack_40 = 0x34;
  uStack_2c = 0xf00000000;
  pcStack_44 = "Player:GetRankInGroup error: Player not in datamodel";
  uStack_3c = uStack_3c & 0xffffff00;
  uStack_4c = CONCAT44(0x927c20,(undefined4)uStack_4c);
  FUN_005542c0();
  uStack_40 = 0x927c28;
  FUN_005e65e0();
LAB_00927c28:
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_30 = &param_6;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x927c49;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_11 != (char *)0x0) && (((uint)param_11 & 1) == 0)) &&
     (*(code **)((uint)param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &param_13;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x927c77;
    (**(code **)((uint)param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16522 ; VA 0x00927ca0 ; FUN_00927ca0 */

undefined * __fastcall FUN_00927ca0(int param_1)

{
  undefined *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c89ac;
  pvStack_10 = ExceptionList;
  puVar1 = *(undefined **)(param_1 + 0x26c);
  if (puVar1 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1c6c) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee1c6c);
      if (DAT_01ee1c6c == -1) {
        uStack_8 = 0;
        FUN_005f7140();
        FUN_016f37bf(&DAT_01ee1c6c);
      }
    }
    puVar1 = &DAT_01ee1c4c;
  }
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 16523 ; VA 0x00927d30 ; FUN_00927d30 */

void __thiscall FUN_00927d30(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x274);
  return;
}



/* FUNCTION 16524 ; VA 0x00927d50 ; FUN_00927d50 */

void FUN_00927d50(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = *(int *)(iStack_18 + 0x34);
    iVar2 = iStack_18;
    if ((iVar3 != 0) && (iVar2 = iVar3, *(int *)(iVar3 + 0x34) != 0)) {
      iVar2 = FUN_005c8ac0();
    }
    if (((iVar2 != 0) &&
        (iVar3 = *(int *)(iVar2 + 0xc), iVar2 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da))) && (iVar3 = FUN_00562f00(), iVar3 != 0)) {
      *param_1 = iStack_18;
      param_1[1] = (int)piStack_14;
      ExceptionList = pvStack_10;
      return;
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  *param_1 = 0;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16525 ; VA 0x00927e40 ; FUN_00927e40 */

int __thiscall FUN_00927e40(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined auStack_50 [48];
  int iStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c89d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00927d50(&iStack_20);
  uStack_8 = 0;
  if (iStack_20 == 0) {
    if ((*(int **)(param_1 + 100) == (int *)0x0) ||
       (iVar7 = (**(code **)(**(int **)(param_1 + 100) + 0xa8))(), iVar7 == 0)) {
      iVar7 = 0;
    }
    else {
      (**(code **)(**(int **)(param_1 + 100) + 0xa8))();
      puVar6 = (undefined4 *)FUN_00b077e0();
      uVar2 = puVar6[1];
      uVar3 = puVar6[2];
      uVar4 = puVar6[3];
      *param_2 = *puVar6;
      param_2[1] = uVar2;
      param_2[2] = uVar3;
      param_2[3] = uVar4;
      uVar2 = puVar6[5];
      uVar3 = puVar6[6];
      uVar4 = puVar6[7];
      param_2[4] = puVar6[4];
      param_2[5] = uVar2;
      param_2[6] = uVar3;
      param_2[7] = uVar4;
      uVar2 = puVar6[9];
      uVar3 = puVar6[10];
      uVar4 = puVar6[0xb];
      param_2[8] = puVar6[8];
      param_2[9] = uVar2;
      param_2[10] = uVar3;
      param_2[0xb] = uVar4;
      iVar7 = (**(code **)(**(int **)(param_1 + 100) + 0xa8))();
    }
  }
  else {
    iVar7 = *(int *)(param_1 + 0x60);
    puStack_18 = (undefined4 *)0x0;
    piStack_14 = (int *)0x0;
    if (iVar7 != 0) {
      piVar1 = (int *)(iVar7 + 4);
      iVar7 = *(int *)(iVar7 + 4);
      while (iVar7 != 0) {
        LOCK();
        iVar5 = *piVar1;
        if (iVar7 == iVar5) {
          *piVar1 = iVar7 + 1;
          iVar5 = iVar7;
        }
        UNLOCK();
        if (iVar5 == iVar7) {
          puStack_18 = *(undefined4 **)(param_1 + 0x5c);
          piStack_14 = *(int **)(param_1 + 0x60);
          break;
        }
        iVar7 = *piVar1;
      }
    }
    piVar1 = piStack_14;
    uStack_8 = 1;
    puVar6 = (undefined4 *)(**(code **)*puStack_18)(auStack_50);
    uVar2 = puVar6[1];
    uVar3 = puVar6[2];
    uVar4 = puVar6[3];
    *param_2 = *puVar6;
    param_2[1] = uVar2;
    param_2[2] = uVar3;
    param_2[3] = uVar4;
    uVar2 = puVar6[5];
    uVar3 = puVar6[6];
    uVar4 = puVar6[7];
    param_2[4] = puVar6[4];
    param_2[5] = uVar2;
    param_2[6] = uVar3;
    param_2[7] = uVar4;
    uVar2 = puVar6[9];
    uVar3 = puVar6[10];
    uVar4 = puVar6[0xb];
    param_2[8] = puVar6[8];
    param_2[9] = uVar2;
    param_2[10] = uVar3;
    param_2[0xb] = uVar4;
    iVar7 = iStack_20;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[1] + -1;
      piVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        iVar7 = iStack_20;
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
          iVar7 = iStack_20;
        }
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 16526 ; VA 0x00927fa0 ; FUN_00927fa0 */

undefined4 FUN_00927fa0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 16527 ; VA 0x00928010 ; FUN_00928010 */

void __thiscall
FUN_00928010(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,char *param_11,undefined4 param_12,uint param_13,undefined4 param_14,
            undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  undefined8 uStack_4c;
  char *pcStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c89f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    ExceptionList = &pvStack_10;
    if (iVar4 == 0) {
LAB_00928054:
    }
    else {
      iVar3 = iVar4;
      ExceptionList = &pvStack_10;
      if (*(int *)(iVar4 + 0x34) != 0) {
        uStack_2c = CONCAT44(0x928054,(undefined4)uStack_2c);
        ExceptionList = &pvStack_10;
        iVar3 = FUN_005c8ac0();
        goto LAB_00928054;
      }
    }
    if (iVar3 != 0) {
      iVar4 = *(int *)(iVar3 + 0xc);
      uStack_2c = CONCAT44(0x928066,(undefined4)uStack_2c);
      iVar3 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        uStack_2c = CONCAT44(0x92808c,(undefined4)uStack_2c);
        iVar4 = FUN_00916100();
        if (iVar4 != 0) {
          uVar1 = *(undefined4 *)(param_1 + 0xf0);
          uVar2 = *(undefined4 *)(param_1 + 0xf4);
          pcStack_44 = (char *)0x0;
          if (param_11 != (char *)0x0) {
            pcStack_44 = param_11;
            if (((uint)param_11 & 1) == 0) {
              uStack_4c = ZEXT48(&uStack_3c);
              puStack_50 = &param_13;
              uStack_54 = 0x9280ec;
              (**(code **)((uint)param_11 & 0xfffffffe))();
            }
            else {
              uStack_3c = param_13;
              uStack_38 = param_14;
              uStack_34 = param_15;
              puStack_30 = (undefined4 *)param_16;
              uStack_2c = param_17;
            }
          }
          uStack_8._0_1_ = 2;
          if (param_4 != 0) {
            if ((param_4 & 1) == 0) {
              (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_5c,0);
            }
            else {
              uStack_5c = param_6;
              uStack_58 = param_7;
              uStack_54 = param_8;
              puStack_50 = param_9;
              uStack_4c = param_10;
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_00cb11f0(uVar1,uVar2,param_2,param_3);
          goto LAB_00928178;
        }
      }
    }
  }
  uStack_40 = 0x34;
  uStack_2c = 0xf00000000;
  pcStack_44 = "Player:GetRoleInGroup error: Player not in datamodel";
  uStack_3c = uStack_3c & 0xffffff00;
  uStack_4c = CONCAT44(0x928170,(undefined4)uStack_4c);
  FUN_005542c0();
  uStack_40 = 0x928178;
  FUN_005e65e0();
LAB_00928178:
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_30 = &param_6;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x928199;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_11 != (char *)0x0) && (((uint)param_11 & 1) == 0)) &&
     (*(code **)((uint)param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &param_13;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x9281c7;
    (**(code **)((uint)param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16528 ; VA 0x009281e0 ; FUN_009281e0 */

ulonglong __fastcall FUN_009281e0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  ulonglong uVar4;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    iVar1 = param_1;
    if ((iVar2 != 0) && (iVar1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      iVar1 = FUN_005c8ac0();
    }
    if ((((iVar1 != 0) &&
         (iVar2 = *(int *)(iVar1 + 0xc), iVar1 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
         (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_005cf750(), iVar2 != 0)) &&
       (uVar4 = FUN_0097fa40(), (char)uVar4 != '\0')) goto LAB_00928295;
  }
  iVar3 = *(uint *)(param_1 + 0xf8) + 0xaaf55c4e;
  iVar2 = *(int *)(param_1 + 0xf0);
  iVar1 = *(int *)(param_1 + 0xf4);
  if ((iVar2 != iVar3) ||
     (iVar1 != *(int *)(param_1 + 0xfc) - (uint)(*(uint *)(param_1 + 0xf8) < 0x550aa3b2))) {
    iVar3 = FUN_01675310("SecurityViolation",&DAT_018bc9b8);
    iVar2 = *(int *)(param_1 + 0xf0);
    iVar1 = *(int *)(param_1 + 0xf4);
  }
  uVar4 = CONCAT44(iVar2,iVar3);
  if ((iVar1 < 1) && (uVar4 = CONCAT44(iVar2,iVar3), iVar1 < 0)) {
    return CONCAT44(iVar2,CONCAT31((int3)((uint)iVar3 >> 8),1));
  }
LAB_00928295:
  return uVar4 & 0xffffffffffffff00;
}



/* FUNCTION 16529 ; VA 0x009282a0 ; FUN_009282a0 */

int __fastcall FUN_009282a0(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (DAT_01d641d4 == '\0') {
    piVar3 = (int *)FUN_00587490(auStack_c);
    iVar2 = *piVar3;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  else {
    iVar2 = FUN_009174b0(param_1);
    if ((iVar2 == 0) || (iVar2 = FUN_00bdfee0(param_1), iVar2 == 0)) {
      return 0;
    }
  }
  return iVar2;
}



/* FUNCTION 16530 ; VA 0x00928330 ; FUN_00928330 */

undefined __fastcall FUN_00928330(int param_1)

{
  return *(undefined *)(param_1 + 0xaf);
}



/* FUNCTION 16531 ; VA 0x00928340 ; FUN_00928340 */

undefined8 __fastcall FUN_00928340(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0xf0);
  iVar2 = *(int *)(param_1 + 0xf4);
  if ((iVar1 != *(uint *)(param_1 + 0xf8) + 0xaaf55c4e) ||
     (iVar2 != *(int *)(param_1 + 0xfc) - (uint)(*(uint *)(param_1 + 0xf8) < 0x550aa3b2))) {
    FUN_01675310("SecurityViolation",&DAT_018bc9b8);
    iVar1 = *(int *)(param_1 + 0xf0);
    iVar2 = *(int *)(param_1 + 0xf4);
  }
  return CONCAT44(iVar2,iVar1);
}



/* FUNCTION 16532 ; VA 0x00928390 ; FUN_00928390 */

void __thiscall FUN_00928390(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x78);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x78);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x74);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 16533 ; VA 0x009283c0 ; FUN_009283c0 */

float10 __thiscall FUN_009283c0(int param_1,int param_2)

{
  return (float10)*(float *)(param_2 + *(int *)(param_1 + 8));
}



/* FUNCTION 16534 ; VA 0x009283d0 ; FUN_009283d0 */

undefined4 __thiscall FUN_009283d0(int param_1,undefined4 param_2,int param_3)

{
  FUN_0054ef60(*(int *)(param_1 + 8) + param_3);
  return param_2;
}



/* FUNCTION 16535 ; VA 0x009283f0 ; FUN_009283f0 */

void __thiscall FUN_009283f0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(**(code **)(param_1 + 8))(&stack0x00000008);
  *param_2 = *puVar1;
  return;
}



/* FUNCTION 16536 ; VA 0x00928410 ; FUN_00928410 */

undefined4 * __thiscall FUN_00928410(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_34 [48];
  
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))(auStack_34);
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_2[4] = puVar4[4];
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_2[8] = puVar4[8];
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  return param_2;
}



/* FUNCTION 16537 ; VA 0x00928450 ; FUN_00928450 */

undefined8 * __thiscall FUN_00928450(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  undefined auStack_10 [12];
  
  puVar2 = (undefined8 *)(**(code **)(param_1 + 8))(auStack_10);
  uVar1 = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return param_2;
}



/* FUNCTION 16538 ; VA 0x00928480 ; FUN_00928480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00928480(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  
  puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_2,param_2);
  uVar5 = FUN_0088cfa0();
  puVar3 = param_3;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar5;
  if (*(int *)(iVar1 + 0x34) < DAT_01ead2a8) {
    FUN_016f3809(&DAT_01ead2a8);
    if (DAT_01ead2a8 == -1) {
      _DAT_01ead29c = FUN_005c65e0;
      _DAT_01ead2a0 = FUN_005c65e0;
      _DAT_01ead2a4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead2a8);
    }
  }
  puVar2 = (undefined *)puVar3[1];
  if (puVar2 == &DAT_01ead29c) {
    puVar3[2] = *puVar4;
    return;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(puVar3 + 2);
    puVar3[1] = 0;
  }
  puVar3[2] = *puVar4;
  puVar3[1] = &DAT_01ead29c;
  return;
}



/* FUNCTION 16539 ; VA 0x00928550 ; FUN_00928550 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00928550(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined auStack_34 [48];
  
  puVar5 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_34,param_2);
  uVar6 = FUN_00b00260();
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar6;
  if (*(int *)(iVar1 + 0x34) < DAT_01ead3d8) {
    FUN_016f3809(&DAT_01ead3d8);
    if (DAT_01ead3d8 == -1) {
      _DAT_01ead3cc = FUN_00619ef0;
      _DAT_01ead3d0 = FUN_00619ef0;
      DAT_01ead3d4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3d8);
    }
  }
  puVar2 = (undefined *)param_3[1];
  if (puVar2 == &DAT_01ead3cc) {
    uVar6 = puVar5[1];
    uVar3 = puVar5[2];
    uVar4 = puVar5[3];
    param_3[2] = *puVar5;
    param_3[3] = uVar6;
    param_3[4] = uVar3;
    param_3[5] = uVar4;
    uVar6 = puVar5[5];
    uVar3 = puVar5[6];
    uVar4 = puVar5[7];
    param_3[6] = puVar5[4];
    param_3[7] = uVar6;
    param_3[8] = uVar3;
    param_3[9] = uVar4;
    uVar6 = puVar5[9];
    uVar3 = puVar5[10];
    uVar4 = puVar5[0xb];
    param_3[10] = puVar5[8];
    param_3[0xb] = uVar6;
    param_3[0xc] = uVar3;
    param_3[0xd] = uVar4;
    return;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  uVar6 = puVar5[1];
  uVar3 = puVar5[2];
  uVar4 = puVar5[3];
  param_3[2] = *puVar5;
  param_3[3] = uVar6;
  param_3[4] = uVar3;
  param_3[5] = uVar4;
  uVar6 = puVar5[5];
  uVar3 = puVar5[6];
  uVar4 = puVar5[7];
  param_3[6] = puVar5[4];
  param_3[7] = uVar6;
  param_3[8] = uVar3;
  param_3[9] = uVar4;
  uVar6 = puVar5[9];
  uVar3 = puVar5[10];
  uVar4 = puVar5[0xb];
  param_3[10] = puVar5[8];
  param_3[0xb] = uVar6;
  param_3[0xc] = uVar3;
  param_3[0xd] = uVar4;
  param_3[1] = &DAT_01ead3cc;
  return;
}



/* FUNCTION 16540 ; VA 0x00928640 ; FUN_00928640 */

void __thiscall FUN_00928640(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_10 [12];
  
  puVar2 = (undefined8 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_10,param_2);
  uVar3 = FUN_0088d870();
  *param_3 = uVar3;
  iVar4 = FUN_006315b0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    *(undefined8 *)(param_3 + 2) = *puVar2;
    param_3[4] = *(undefined4 *)(puVar2 + 1);
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  *(undefined8 *)(param_3 + 2) = *puVar2;
  param_3[4] = *(undefined4 *)(puVar2 + 1);
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16541 ; VA 0x009286c0 ; FUN_009286c0 */

void __thiscall FUN_009286c0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00935b10();
  *param_3 = uVar3;
  iVar4 = FUN_00935f00();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16542 ; VA 0x00928720 ; FUN_00928720 */

void __thiscall FUN_00928720(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_005f3000();
  *param_3 = uVar3;
  iVar4 = FUN_005f3690();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16543 ; VA 0x00928780 ; FUN_00928780 */

void __thiscall FUN_00928780(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_005f3120();
  *param_3 = uVar3;
  iVar4 = FUN_005f3770();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16544 ; VA 0x009287e0 ; FUN_009287e0 */

void __thiscall FUN_009287e0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00935ba0();
  *param_3 = uVar3;
  iVar4 = FUN_00935f70();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16545 ; VA 0x00928840 ; FUN_00928840 */

void __thiscall FUN_00928840(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00935c30();
  *param_3 = uVar3;
  iVar4 = FUN_00935ff0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16546 ; VA 0x009288a0 ; FUN_009288a0 */

void __thiscall FUN_009288a0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00935cc0();
  *param_3 = uVar3;
  iVar4 = FUN_00936060();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16547 ; VA 0x00928900 ; FUN_00928900 */

void __thiscall FUN_00928900(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00935d50();
  *param_3 = uVar3;
  iVar4 = FUN_009360d0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16548 ; VA 0x00928960 ; FUN_00928960 */

void __thiscall FUN_00928960(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00935de0();
  *param_3 = uVar3;
  iVar4 = FUN_00936140();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16549 ; VA 0x009289c0 ; FUN_009289c0 */

void __thiscall FUN_009289c0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_005f32d0();
  *param_3 = uVar3;
  iVar4 = FUN_005f3850();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16550 ; VA 0x00928a20 ; FUN_00928a20 */

int * __thiscall
FUN_00928a20(int *param_1,int param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void **ppvVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8a20;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  piVar6 = (int *)ExceptionList;
  ppvVar4 = &pvStack_10;
  if ((param_2 == 0) && (ppvVar4 = &pvStack_10, param_1 != (int *)0x0)) {
    piVar8 = (int *)param_1[0xd];
    ppvVar4 = &pvStack_10;
    if ((piVar8 != (int *)0x0) && (param_1 = piVar8, ppvVar4 = &pvStack_10, piVar8[0xd] != 0)) {
      ExceptionList = &pvStack_10;
      param_1 = (int *)FUN_005c8ac0();
      piVar6 = param_1;
      ppvVar4 = (void **)ExceptionList;
    }
    ExceptionList = ppvVar4;
    ppvVar4 = (void **)ExceptionList;
    if (param_1 != (int *)0x0) {
      iVar2 = param_1[3];
      iVar5 = FUN_008a8c30();
      piVar6 = (int *)(uint)*(ushort *)(iVar5 + 0x1da);
      ppvVar4 = (void **)ExceptionList;
      if ((int *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) <= piVar6) {
        FUN_005789c0(&DAT_01ead2e4,&LAB_00605b60);
        uVar7 = FUN_00606020();
        piVar8 = (int *)FUN_008aa140(uVar7);
        piVar6 = piVar8;
        if (*piVar8 == 0) {
          uVar7 = FUN_00ac1050();
          piVar6 = (int *)FUN_008a9ba0(auStack_18,uVar7);
          iVar2 = *piVar6;
          iVar5 = piVar6[1];
          *piVar6 = 0;
          piVar6[1] = 0;
          *piVar8 = iVar2;
          piVar3 = (int *)piVar8[1];
          piVar8[1] = iVar5;
          if (piVar3 != (int *)0x0) {
            LOCK();
            piVar1 = piVar3 + 1;
            iVar2 = *piVar1;
            piVar6 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              piVar1 = piVar3 + 2;
              iVar2 = *piVar1;
              piVar6 = (int *)*piVar1;
              *piVar1 = iVar2 + -1;
              UNLOCK();
              if (iVar2 + -1 == 0) {
                piVar6 = (int *)(**(code **)(*piVar3 + 4))();
              }
            }
          }
          if (piStack_14 != (int *)0x0) {
            LOCK();
            piVar3 = piStack_14 + 1;
            iVar2 = *piVar3;
            piVar6 = (int *)*piVar3;
            *piVar3 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              (**(code **)*piStack_14)();
              LOCK();
              piVar3 = piStack_14 + 2;
              iVar2 = *piVar3;
              piVar6 = (int *)*piVar3;
              *piVar3 = iVar2 + -1;
              UNLOCK();
              if (iVar2 + -1 == 0) {
                piVar6 = (int *)(**(code **)(*piStack_14 + 4))();
              }
            }
          }
        }
        ppvVar4 = (void **)ExceptionList;
        if (*piVar8 != 0) {
          if (param_6 != (int *)0x0) {
            LOCK();
            param_6[1] = param_6[1] + 1;
            UNLOCK();
          }
          if (param_4 != (int *)0x0) {
            LOCK();
            param_4[1] = param_4[1] + 1;
            UNLOCK();
          }
          piVar6 = (int *)FUN_00ace320(param_3,param_4,param_5,param_6);
          ppvVar4 = (void **)ExceptionList;
        }
      }
    }
  }
  ExceptionList = ppvVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar8 = param_4 + 1;
    iVar2 = *piVar8;
    piVar6 = (int *)*piVar8;
    *piVar8 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar8 = param_4 + 2;
      iVar2 = *piVar8;
      piVar6 = (int *)*piVar8;
      *piVar8 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar6 = (int *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar8 = param_6 + 1;
    iVar2 = *piVar8;
    piVar6 = (int *)*piVar8;
    *piVar8 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar6 = (int *)(**(code **)*param_6)();
      LOCK();
      piVar8 = param_6 + 2;
      iVar2 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar6 = (int *)(**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar6;
}



/* FUNCTION 16551 ; VA 0x00928c00 ; FUN_00928c00 */

void __thiscall FUN_00928c00(int param_1,int param_2)

{
  if (((param_2 != 4) && (param_2 != 1)) && (param_2 != 2)) {
    *(undefined *)(param_1 + 0x264) = 0;
    return;
  }
  *(undefined *)(param_1 + 0x264) = 1;
  return;
}



/* FUNCTION 16552 ; VA 0x00928c30 ; FUN_00928c30 */

bool __thiscall FUN_00928c30(int param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  iVar3 = FUN_005e9db0(&param_2);
  puVar1 = *(undefined4 **)(param_1 + 0x514);
  puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x51c) + iVar3 * 8);
  puVar5 = puVar2;
  while( true ) {
    puVar4 = puVar1;
    if (puVar2 != puVar1) {
      puVar4 = (undefined4 *)**(undefined4 **)(*(int *)(param_1 + 0x51c) + 4 + iVar3 * 8);
    }
    puVar6 = puVar1;
    if ((puVar5 == puVar4) || ((puVar5[2] == param_2 && (puVar6 = puVar5, puVar5[3] == param_3))))
    break;
    puVar5 = (undefined4 *)*puVar5;
  }
  return puVar6 != *(undefined4 **)(param_1 + 0x514);
}



/* FUNCTION 16553 ; VA 0x00928cb0 ; FUN_00928cb0 */

/* WARNING: Removing unreachable block (ram,0x00928d82) */
/* WARNING: Removing unreachable block (ram,0x00928dd3) */
/* WARNING: Removing unreachable block (ram,0x00928dcb) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00928cb0(int param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined8 uStack_24;
  int iStack_1c;
  uint uStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8a40;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_2 + 8) != 0) {
    puStack_14 = (uint *)(param_1 + 4);
    uStack_18 = *puStack_14;
    uStack_8 = 0;
    uStack_24 = (ulonglong)(uint)uStack_24;
    ExceptionList = &pvStack_10;
    iStack_1c = param_1;
    FUN_005c24c0((int)&uStack_24 + 4,uStack_18 + 1);
    if (*(int *)(param_1 + 0x14) != 0) {
      *(undefined4 *)(uStack_18 * 4) = *(undefined4 *)(*(int *)(param_1 + 0x14) + *puStack_14 * 4);
      uVar6 = *puStack_14 * 4 + 4;
      iVar1 = *(int *)(param_1 + 0x14);
      iVar4 = iVar1;
      if (0xfff < uVar6) {
        iVar4 = *(int *)(iVar1 + -4);
        uVar6 = *puStack_14 * 4 + 0x27;
        if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar6);
    }
    *puStack_14 = uStack_18;
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    uStack_8 = 2;
    if (*(int *)(param_2 + 8) == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      puVar7 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    puVar3 = (undefined4 *)(uStack_18 * 4);
    while (puVar7 != (undefined4 *)0x0) {
      uStack_24 = uStack_24 & 0xffff000000000000;
      puVar5 = (undefined4 *)FUN_01674e20();
      uStack_24 = CONCAT35(uStack_24._5_3_,0x100000000);
      uStack_24 = CONCAT44(uStack_24._4_4_,puVar5);
      *puVar5 = 0;
      puVar5[1] = 0;
      puVar5[2] = 0;
      puVar5[3] = 0;
      puVar5[4] = 0;
      puVar5[5] = 0;
      *(undefined8 *)(puVar5 + 6) = 0;
      puVar5[8] = 0;
      puVar5[2] = puVar7[2];
      FUN_0054ef60();
      puVar5[1] = puVar7[1];
      *puVar3 = puVar5;
      *(int *)(iStack_1c + 8) = *(int *)(iStack_1c + 8) + 1;
      puVar2 = (undefined4 *)*puVar3;
      puVar7 = (undefined4 *)*puVar7;
      puVar5 = (undefined4 *)(*(int *)(iStack_1c + 0x14) + ((uint)puVar2[1] % *puStack_14) * 4);
      if (*(int *)(*(int *)(iStack_1c + 0x14) + ((uint)puVar2[1] % *puStack_14) * 4) == 0) {
        *puVar5 = puVar3;
        puVar3 = puVar2;
      }
      else {
        *puVar3 = *puVar2;
        *puVar2 = *(undefined4 *)*puVar5;
        *(undefined4 **)*puVar5 = puVar2;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16554 ; VA 0x00928ef0 ; FUN_00928ef0 */

void __thiscall FUN_00928ef0(int param_1,int *param_2,undefined4 *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 uVar5;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8a60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00929190(&iStack_14,param_2);
  if (iStack_14 != 0) {
    FUN_009302c0(&iStack_14);
  }
  iStack_1c = param_4;
  piStack_24 = (int *)param_3[1];
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piStack_24[1] = piStack_24[1] + 1;
    UNLOCK();
    piStack_24 = (int *)param_3[1];
  }
  iStack_34 = *param_2;
  iStack_30 = param_2[1];
  iStack_2c = param_4;
  iStack_28 = *param_3;
  uStack_18 = 0;
  iStack_14 = 0;
  uStack_8 = 1;
  iVar2 = **(int **)(param_1 + 4);
  puVar3 = *(undefined4 **)(iVar2 + 4);
  uVar5 = FUN_009137e0(iVar2,puVar3,&iStack_34);
  piVar4 = piStack_24;
  if (*(int *)(param_1 + 8) == 0x7fffffe) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *(undefined4 *)(iVar2 + 4) = uVar5;
  *puVar3 = uVar5;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = 0xffffffff;
  piStack_24 = (int *)**(undefined4 **)(param_1 + 4);
  iStack_2c = *param_2;
  iStack_28 = param_2[1];
  FUN_00916c40(&uStack_18,&iStack_2c,&iStack_2c);
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + param_4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16555 ; VA 0x00929030 ; FUN_00929030 */

void __thiscall FUN_00929030(int param_1,int *param_2,undefined4 *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 uVar5;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8a60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009314c0(-(uint)(*(int *)(param_1 + 0x28) != 0) & *(int *)(param_1 + 0x28) - 1U);
  FUN_00929190(&iStack_14,param_2);
  if (iStack_14 != 0) {
    FUN_009302c0(&iStack_14);
  }
  iStack_1c = param_4;
  piStack_24 = (int *)param_3[1];
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piStack_24[1] = piStack_24[1] + 1;
    UNLOCK();
    piStack_24 = (int *)param_3[1];
  }
  iStack_34 = *param_2;
  iStack_30 = param_2[1];
  iStack_2c = param_4;
  iStack_28 = *param_3;
  uStack_18 = 0;
  iStack_14 = 0;
  uStack_8 = 1;
  iVar2 = **(int **)(param_1 + 4);
  puVar3 = *(undefined4 **)(iVar2 + 4);
  uVar5 = FUN_009137e0(iVar2,puVar3,&iStack_34);
  piVar4 = piStack_24;
  if (*(int *)(param_1 + 8) == 0x7fffffe) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *(undefined4 *)(iVar2 + 4) = uVar5;
  *puVar3 = uVar5;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = 0xffffffff;
  piStack_24 = (int *)**(undefined4 **)(param_1 + 4);
  iStack_2c = *param_2;
  iStack_28 = param_2[1];
  FUN_00916c40(&uStack_18,&iStack_2c,&iStack_2c);
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + param_4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16556 ; VA 0x00929190 ; FUN_00929190 */

int * __thiscall FUN_00929190(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  
  uVar4 = param_3[1];
  iVar5 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar4 = ~uVar4;
  }
  FUN_00606ff0(param_2,(uVar4 >> 2) + uVar4 * 0x40 + *param_3 ^ uVar4,param_3,
               -(uint)(iVar5 != 0) & iVar5 + 1U);
  if (*param_2 != 0) {
    piVar1 = *(int **)(*param_2 + 0x10);
    piVar2 = (int *)**(int **)(param_1 + 4);
    if (((piVar1 != *(int **)(param_1 + 4)) && (iVar5 = *piVar1, piVar2 != piVar1)) &&
       (piVar2 != (int *)iVar5)) {
      *(int *)piVar1[1] = iVar5;
      **(int **)(iVar5 + 4) = (int)piVar2;
      *(int **)piVar2[1] = piVar1;
      iVar3 = piVar2[1];
      piVar2[1] = *(undefined4 *)(iVar5 + 4);
      *(int *)(iVar5 + 4) = piVar1[1];
      piVar1[1] = iVar3;
    }
  }
  return param_2;
}



/* FUNCTION 16557 ; VA 0x00929230 ; FUN_00929230 */

int FUN_00929230(int param_1)

{
  int *piVar1;
  int iVar2;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iStack_18 = FUN_00930640(iStack_18,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),3
                            );
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iStack_18 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_18 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_18 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 16558 ; VA 0x009292c0 ; FUN_009292c0 */

void FUN_009292c0(void)

{
  FUN_0091b1a0();
  return;
}



/* FUNCTION 16559 ; VA 0x009292d0 ; FUN_009292d0 */

int FUN_009292d0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iStack_18 = FUN_00930640(iStack_18,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),2
                            );
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iStack_18 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_18 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_18 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 16560 ; VA 0x00929360 ; FUN_00929360 */

int FUN_00929360(int param_1)

{
  int *piVar1;
  int iVar2;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iStack_18 = FUN_00930640(iStack_18,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),1
                            );
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iStack_18 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_18 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_18 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 16561 ; VA 0x009293f0 ; FUN_009293f0 */

void FUN_009293f0(int *param_1)

{
  char cVar1;
  int iVar2;
  undefined uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8a80;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(*param_1 + 0xac) = 0;
  if ((((*(int *)(*param_1 + 100) != 0) && (iVar2 = FUN_009ba880(), iVar2 != 0)) &&
      (cVar1 = FUN_009b4a80(), cVar1 == '\0')) &&
     ((DAT_018ce2f0 < (float)(**(uint **)(iVar2 + 0x1fc) ^ (uint)*(uint **)(iVar2 + 0x1fc)) &&
      (iVar2 = FUN_009b54b0(), iVar2 != 0)))) {
    ExceptionList = pvStack_10;
    return;
  }
  uStack_8 = 1;
  uVar3 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0xffffffff;
  FUN_0092ab80(1,uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16562 ; VA 0x009294d0 ; FUN_009294d0 */

int FUN_009294d0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iStack_18 = FUN_00930640(iStack_18,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),0
                            );
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iStack_18 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_18 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_18 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 16563 ; VA 0x00929560 ; FUN_00929560 */

void FUN_00929560(undefined4 *param_1)

{
  (*(code *)*param_1)(param_1 + 1,param_1[3]);
  return;
}



/* FUNCTION 16564 ; VA 0x00929580 ; FUN_00929580 */

/* WARNING: Removing unreachable block (ram,0x009295e2) */
/* WARNING: Removing unreachable block (ram,0x009295f0) */
/* WARNING: Removing unreachable block (ram,0x00929600) */

void FUN_00929580(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,uint param_7)

{
  int iVar1;
  uint uVar2;
  
  if (0xf < param_7) {
    uVar2 = param_7 + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = param_7 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2,param_2,param_3,param_4,param_5);
  }
  return;
}



/* FUNCTION 16565 ; VA 0x00929620 ; FUN_00929620 */

/* WARNING: Removing unreachable block (ram,0x0092967c) */
/* WARNING: Removing unreachable block (ram,0x00929688) */
/* WARNING: Removing unreachable block (ram,0x00929696) */

undefined4 FUN_00929620(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8a98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0091b470(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 16566 ; VA 0x009296b0 ; FUN_009296b0 */

/* WARNING: Removing unreachable block (ram,0x0092970c) */
/* WARNING: Removing unreachable block (ram,0x00929718) */
/* WARNING: Removing unreachable block (ram,0x00929726) */

undefined4 FUN_009296b0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8a98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0091b5e0(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 16567 ; VA 0x00929740 ; FUN_00929740 */

/* WARNING: Removing unreachable block (ram,0x00929783) */
/* WARNING: Removing unreachable block (ram,0x0092978c) */
/* WARNING: Removing unreachable block (ram,0x0092979a) */

void FUN_00929740(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  
  param_2 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return;
}



/* FUNCTION 16568 ; VA 0x009297b0 ; FUN_009297b0 */

int FUN_009297b0(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  uint uVar5;
  uint3 uVar6;
  int iVar7;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c8ac0;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  pcVar4 = (code *)*puVar3;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_24 = param_2;
  piStack_20 = param_3;
  iStack_8._1_3_ = 0;
  uVar6 = iStack_8._1_3_;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  uVar5 = puVar3[2];
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(puVar3 + 4,&uStack_3c,0);
      uVar6 = iStack_8._1_3_;
    }
    else {
      uStack_3c = puVar3[4];
      uStack_38 = puVar3[5];
      uStack_34 = puVar3[6];
      uStack_30 = puVar3[7];
      uStack_2c = *(undefined8 *)(puVar3 + 8);
      uVar6 = iStack_8._1_3_;
    }
  }
  iStack_8._1_3_ = uVar6;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar7 = (*pcVar4)();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_20 = (int *)0x92986e;
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_20 = (int *)0x92987d;
        iVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 16569 ; VA 0x00929890 ; FUN_00929890 */

int FUN_00929890(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8ad8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pcVar3 = (code *)*param_1;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_1[1],param_1[2],param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16570 ; VA 0x00929950 ; FUN_00929950 */

int FUN_00929950(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfa90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_1c = (undefined *)&param_2;
  puStack_18 = (undefined *)&param_3;
  puStack_14 = (undefined *)&param_5;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00913410(param_1,*param_1,&puStack_1c,0);
  piVar3 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_6)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16571 ; VA 0x00929a00 ; FUN_00929a00 */

void FUN_00929a00(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 *param_8,
                 ulonglong param_9,uint param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  undefined4 uVar1;
  int extraout_EDX;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  ulonglong uStack_50;
  uint uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8b10;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01d641cc != '\0') {
    uStack_30 = CONCAT44(0x929a33,(undefined4)uStack_30);
    ExceptionList = &pvStack_10;
    FUN_00928340();
    if ((extraout_EDX < 1) && (extraout_EDX < 0)) {
      if (param_3 == 0) {
        uStack_30 = CONCAT44(0x929b69,(undefined4)uStack_30);
        uVar1 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        uStack_30 = CONCAT44(uVar1,&UNK_00929b73);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0();
      }
      uStack_30 = ZEXT48(&param_5);
      puStack_34 = (undefined4 *)0x929a56;
      (**(code **)((param_3 & 0xfffffffe) + 4))();
      goto LAB_00929afe;
    }
  }
  uStack_48 = 0;
  if (param_10 != 0) {
    uStack_48 = param_10;
    if ((param_10 & 1) == 0) {
      uStack_50 = ZEXT48(&uStack_40);
      puStack_54 = &param_12;
      uStack_58 = 0x929aa2;
      (**(code **)(param_10 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_12;
      uStack_3c = param_13;
      uStack_38 = param_14;
      puStack_34 = (undefined4 *)param_15;
      uStack_30 = param_16;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_3 != 0) {
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_60,0);
    }
    else {
      uStack_60 = param_5;
      uStack_5c = param_6;
      uStack_58 = param_7;
      puStack_54 = param_8;
      uStack_50 = param_9;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00929bb0(param_1,param_2);
LAB_00929afe:
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_34 = &param_5;
    uStack_30 = CONCAT44(2,puStack_34);
    uStack_38 = 0x929b1f;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_34 = &param_12;
    uStack_30 = CONCAT44(2,puStack_34);
    uStack_38 = 0x929b4d;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16572 ; VA 0x00929b80 ; FUN_00929b80 */

uint __fastcall FUN_00929b80(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x38) & 1;
  if (DAT_01d65340 != '\0') {
    if (uVar1 != 0) {
      return (uint)(*(uint *)(param_1 + 0x38) != 3);
    }
    uVar1 = 0;
  }
  return uVar1;
}



/* FUNCTION 16573 ; VA 0x00929ba0 ; FUN_00929ba0 */

undefined __fastcall FUN_00929ba0(int param_1)

{
  return *(undefined *)(param_1 + 0x4c5);
}



/* FUNCTION 16574 ; VA 0x00929bb0 ; FUN_00929bb0 */

void __thiscall
FUN_00929bb0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,char *param_11,undefined4 param_12,uint param_13,undefined4 param_14,
            undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  int extraout_EDX;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 *puStack_5c;
  undefined8 uStack_58;
  char *pcStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  undefined8 uStack_38;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8b40;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01d641cc != '\0') {
    uStack_38 = CONCAT44(0x929be4,(undefined4)uStack_38);
    ExceptionList = &pvStack_10;
    FUN_00928340();
    if ((extraout_EDX < 1) && (extraout_EDX < 0)) {
      if (param_4 == 0) {
        uStack_38 = CONCAT44(0x929d6d,(undefined4)uStack_38);
        uVar3 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        uStack_38 = CONCAT44(uVar3,&UNK_00929d77);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0();
      }
      uStack_38 = ZEXT48(&param_6);
      puStack_3c = (undefined4 *)0x929c07;
      (**(code **)((param_4 & 0xfffffffe) + 4))();
      goto LAB_00929d01;
    }
  }
  uStack_38 = CONCAT44(param_1,0x929c15);
  iVar2 = FUN_006719d0();
  if (iVar2 == 0) {
    uStack_4c = 0x10;
    uStack_38 = 0xf00000000;
    pcStack_50 = "No FriendService";
    uStack_48 = uStack_48 & 0xffffff00;
    uStack_58 = CONCAT44(0x929cf9,(undefined4)uStack_58);
    FUN_005542c0();
    uStack_4c = 0x929d01;
    FUN_005e65e0();
  }
  else {
    uVar3 = *(undefined4 *)(param_1 + 0xf0);
    uVar1 = *(undefined4 *)(param_1 + 0xf4);
    pcStack_50 = (char *)0x0;
    if (param_11 != (char *)0x0) {
      pcStack_50 = param_11;
      if (((uint)param_11 & 1) == 0) {
        uStack_58 = ZEXT48(&uStack_48);
        puStack_5c = &param_13;
        uStack_60 = 0x929c75;
        (**(code **)((uint)param_11 & 0xfffffffe))();
      }
      else {
        uStack_48 = param_13;
        uStack_44 = param_14;
        uStack_40 = param_15;
        puStack_3c = (undefined4 *)param_16;
        uStack_38 = param_17;
      }
    }
    uStack_8._0_1_ = 3;
    if (param_4 != 0) {
      if ((param_4 & 1) == 0) {
        (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_68,0);
      }
      else {
        uStack_68 = param_6;
        uStack_64 = param_7;
        uStack_60 = param_8;
        puStack_5c = param_9;
        uStack_58 = param_10;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00bf0a20(uVar3,uVar1,param_2,param_3);
  }
LAB_00929d01:
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_3c = &param_6;
    uStack_38 = CONCAT44(2,puStack_3c);
    uStack_40 = 0x929d22;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_11 != (char *)0x0) && (((uint)param_11 & 1) == 0)) &&
     (*(code **)((uint)param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_3c = &param_13;
    uStack_38 = CONCAT44(2,puStack_3c);
    uStack_40 = 0x929d50;
    (**(code **)((uint)param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16575 ; VA 0x00929da0 ; FUN_00929da0 */

void __thiscall
FUN_00929da0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,char *param_11,undefined4 param_12,uint param_13,undefined4 param_14,
            undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  undefined8 uStack_4c;
  char *pcStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8b68;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    ExceptionList = &pvStack_10;
    if (iVar4 == 0) {
LAB_00929de4:
    }
    else {
      iVar3 = iVar4;
      ExceptionList = &pvStack_10;
      if (*(int *)(iVar4 + 0x34) != 0) {
        uStack_2c = CONCAT44(0x929de4,(undefined4)uStack_2c);
        ExceptionList = &pvStack_10;
        iVar3 = FUN_005c8ac0();
        goto LAB_00929de4;
      }
    }
    if (iVar3 != 0) {
      iVar4 = *(int *)(iVar3 + 0xc);
      uStack_2c = CONCAT44(0x929df6,(undefined4)uStack_2c);
      iVar3 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        uStack_2c = CONCAT44(0x929e1c,(undefined4)uStack_2c);
        iVar4 = FUN_00916100();
        if (iVar4 != 0) {
          uVar1 = *(undefined4 *)(param_1 + 0xf0);
          uVar2 = *(undefined4 *)(param_1 + 0xf4);
          pcStack_44 = (char *)0x0;
          if (param_11 != (char *)0x0) {
            pcStack_44 = param_11;
            if (((uint)param_11 & 1) == 0) {
              uStack_4c = ZEXT48(&uStack_3c);
              puStack_50 = &param_13;
              uStack_54 = 0x929e7c;
              (**(code **)((uint)param_11 & 0xfffffffe))();
            }
            else {
              uStack_3c = param_13;
              uStack_38 = param_14;
              uStack_34 = param_15;
              puStack_30 = (undefined4 *)param_16;
              uStack_2c = param_17;
            }
          }
          uStack_8._0_1_ = 2;
          if (param_4 != 0) {
            if ((param_4 & 1) == 0) {
              (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_5c,0);
            }
            else {
              uStack_5c = param_6;
              uStack_58 = param_7;
              uStack_54 = param_8;
              puStack_50 = param_9;
              uStack_4c = param_10;
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_00cb1390(uVar1,uVar2,param_2,param_3);
          goto LAB_00929f08;
        }
      }
    }
  }
  uStack_40 = 0x2f;
  uStack_2c = 0xf00000000;
  pcStack_44 = "Player:IsInGroup error: Player not in datamodel";
  uStack_3c = uStack_3c & 0xffffff00;
  uStack_4c = CONCAT44(0x929f00,(undefined4)uStack_4c);
  FUN_005542c0();
  uStack_40 = 0x929f08;
  FUN_005e65e0();
LAB_00929f08:
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_30 = &param_6;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x929f29;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_11 != (char *)0x0) && (((uint)param_11 & 1) == 0)) &&
     (*(code **)((uint)param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &param_13;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x929f57;
    (**(code **)((uint)param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16576 ; VA 0x00929f70 ; FUN_00929f70 */

uint FUN_00929f70(void)

{
  int iVar1;
  
  iVar1 = FUN_00913630();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 16577 ; VA 0x00929f90 ; FUN_00929f90 */

byte __fastcall FUN_00929f90(int param_1)

{
  return *(byte *)(param_1 + 0x3c) & 1;
}



/* FUNCTION 16578 ; VA 0x00929fa0 ; FUN_00929fa0 */

uint FUN_00929fa0(void)

{
  int iVar1;
  
  iVar1 = FUN_00913630();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 16579 ; VA 0x00929fd0 ; FUN_00929fd0 */

undefined __fastcall FUN_00929fd0(int param_1)

{
  char cVar1;
  undefined uVar2;
  char *pcVar3;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    pcVar3 = "LocalScripts cannot use LoadBoolean";
  }
  else {
    if (*(char *)(param_1 + 0xa9) != '\0') {
      uVar2 = FUN_00f847d0(&stack0x00000004);
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return uVar2;
    }
    pcVar3 = "Data for player not yet loaded, wait for DataReady";
  }
  FUN_00550130(pcVar3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16580 ; VA 0x0092a060 ; FUN_0092a060 */

int FUN_0092a060(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00f7f010(param_1,param_2);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 16581 ; VA 0x0092a0f0 ; FUN_0092a0f0 */

void FUN_0092a0f0(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 *param_6,ulonglong param_7,uint param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined8 param_14)

{
  undefined uVar1;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8ba0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_8 != 0) {
    uStack_40 = param_8;
    if ((param_8 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_10;
      uStack_50 = 0x92a159;
      ExceptionList = &pvStack_10;
      (**(code **)(param_8 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_10;
      uStack_34 = param_11;
      uStack_30 = param_12;
      puStack_2c = (undefined4 *)param_13;
      uStack_28 = param_14;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_1 != 0) {
    if ((param_1 & 1) == 0) {
      (**(code **)(param_1 & 0xfffffffe))(&param_3,&uStack_58,0);
    }
    else {
      uStack_58 = param_3;
      uStack_54 = param_4;
      uStack_50 = param_5;
      puStack_4c = param_6;
      uStack_48 = param_7;
    }
  }
  uStack_8._0_1_ = 3;
  uVar1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 1;
  FUN_0092ab80(0,uVar1);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_3;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0x92a1fb;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_10;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0x92a229;
    (**(code **)(param_8 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16582 ; VA 0x0092a240 ; FUN_0092a240 */

int __thiscall FUN_0092a240(int param_1,int param_2,int *param_3,undefined4 param_4,char param_5)

{
  undefined4 *puVar1;
  int *piVar2;
  code *pcVar3;
  undefined uVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  undefined4 uVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  undefined4 *puVar14;
  int *piVar15;
  undefined8 uVar16;
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  int iStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  uint auStack_34 [3];
  code *pcStack_28;
  int *piStack_24;
  int *piStack_20;
  code *pcStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c8c2a;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1c78) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee1c78), DAT_01ee1c78 == -1)) {
    iStack_8._0_1_ = 1;
    uVar16 = FUN_0152dab0("Player","loadCharacterScripts",0xffffffff);
    DAT_01ee1c74 = (undefined4)((ulonglong)uVar16 >> 0x20);
    DAT_01ee1c70 = (undefined4)uVar16;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_016f37bf(&DAT_01ee1c78);
  }
  uStack_3c = DAT_01ee1c70;
  uStack_58 = DAT_01ee1c70;
  uStack_38 = DAT_01ee1c74;
  uStack_54 = DAT_01ee1c74;
  uStack_50 = FUN_0152d930(DAT_01ee1c70,DAT_01ee1c74);
  iStack_8._0_1_ = 2;
  if (param_2 != 0) {
    pcStack_1c = FUN_00933020;
    FUN_00917830(&pcStack_1c);
  }
  uStack_18 = uStack_18 & 0xffffff00;
  pcStack_1c = (code *)((uint)pcStack_1c & 0xffffff00);
  if (param_1 != 0) {
    iVar7 = *(int *)(param_1 + 0x34);
    iVar6 = param_1;
    if ((iVar7 != 0) && (iVar6 = iVar7, *(int *)(iVar7 + 0x34) != 0)) {
      iVar6 = FUN_005c8ac0();
    }
    if (iVar6 != 0) {
      iVar7 = *(int *)(iVar6 + 0xc);
      iVar6 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        iVar7 = FUN_0063f510();
        if ((iVar7 != 0) && (puVar14 = *(undefined4 **)(iVar7 + 0x2c), puVar14 != (undefined4 *)0x0)
           ) {
          puVar1 = (undefined4 *)puVar14[1];
          for (puVar14 = (undefined4 *)*puVar14; puVar14 != puVar1; puVar14 = puVar14 + 2) {
            piStack_20 = (int *)*puVar14;
            if (piStack_20 != (int *)0x0) {
              iVar7 = piStack_20[3];
              iVar6 = FUN_00c4b870();
              piVar15 = piStack_20;
              if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
                  (uint)*(ushort *)(iVar6 + 0x1da)) {
                param_1 = iStack_14;
                if (piStack_20 != (int *)0x0) {
                  piStack_24 = (int *)0x0;
                  piStack_20 = (int *)0x0;
                  piStack_24 = (int *)FUN_00601dc0();
                  iStack_8 = CONCAT31(iStack_8._1_3_,3);
                  uStack_44 = (double)CONCAT44(&piStack_24,FUN_00933a90);
                  FUN_00917910(&uStack_44);
                  uVar12 = 0;
                  iVar7 = FUN_005d6c30();
                  if (iVar7 == 0) goto LAB_0092a472;
                  goto LAB_0092a3e0;
                }
                break;
              }
            }
            param_1 = iStack_14;
          }
        }
      }
    }
  }
  goto LAB_0092a604;
LAB_0092a3e0:
  do {
    if (DAT_01d641bc == '\0') {
LAB_0092a414:
      FUN_0089d950(&uStack_44,3);
      iStack_8._0_1_ = 4;
      if ((int)uStack_44 != 0) {
        FUN_008a65e0(param_2,0);
      }
      piVar2 = uStack_44._4_4_;
      iStack_8 = CONCAT31(iStack_8._1_3_,3);
      if (uStack_44._4_4_ != (int *)0x0) {
        LOCK();
        iVar7 = uStack_44._4_4_[1] + -1;
        uStack_44._4_4_[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*uStack_44._4_4_)();
          LOCK();
          piVar8 = piVar2 + 2;
          iVar7 = *piVar8 + -1;
          *piVar8 = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    else {
      piVar8 = *(int **)(*(int *)(*(int *)piVar15[0xb] + uVar12 * 8) + 0x28);
      piVar2 = piVar8 + 4;
      if (0xf < (uint)piVar8[5]) {
        piVar8 = (int *)*piVar8;
      }
      cVar5 = FUN_0055c360(piVar8,*piVar2,"Sound",5);
      if (cVar5 == '\0') goto LAB_0092a414;
    }
    uVar12 = uVar12 + 1;
    uVar13 = FUN_005d6c30();
  } while (uVar12 < uVar13);
LAB_0092a472:
  piVar15 = (int *)*piStack_24;
  if (piVar15 != piStack_24) {
    do {
      (**(code **)(*(int *)piVar15[4] + 0x1c))(0);
      piVar2 = (int *)piVar15[2];
      if (*(char *)((int)piVar2 + 0xd) == '\0') {
        cVar5 = *(char *)(*piVar2 + 0xd);
        piVar15 = piVar2;
        piVar2 = (int *)*piVar2;
        while (cVar5 == '\0') {
          cVar5 = *(char *)(*piVar2 + 0xd);
          piVar15 = piVar2;
          piVar2 = (int *)*piVar2;
        }
      }
      else {
        cVar5 = *(char *)(piVar15[1] + 0xd);
        piVar8 = (int *)piVar15[1];
        piVar2 = piVar15;
        while ((piVar15 = piVar8, cVar5 == '\0' && (piVar2 == (int *)piVar15[2]))) {
          cVar5 = *(char *)(piVar15[1] + 0xd);
          piVar8 = (int *)piVar15[1];
          piVar2 = piVar15;
        }
      }
    } while (piVar15 != piStack_24);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0("Health",6);
  iStack_8._0_1_ = 5;
  iVar7 = FUN_008a1240(auStack_70);
  iStack_8._0_1_ = 3;
  uVar4 = (undefined)iStack_8;
  iStack_8._0_1_ = 3;
  if (0xf < uStack_5c) {
    uVar13 = uStack_5c + 1;
    uVar12 = auStack_70[0];
    if (0xfff < uVar13) {
      uVar12 = *(uint *)(auStack_70[0] - 4);
      uVar13 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar12) - 4) {
        iStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar13);
  }
  uStack_18 = uStack_18 & 0xff;
  uStack_60 = 0;
  if (iVar7 != 0) {
    uStack_18 = 1;
  }
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018db428,7);
  iStack_8._0_1_ = 6;
  iVar7 = FUN_008a1240(auStack_70);
  iStack_8._0_1_ = 3;
  uVar4 = (undefined)iStack_8;
  iStack_8._0_1_ = 3;
  if (0xf < uStack_5c) {
    uVar13 = uStack_5c + 1;
    uVar12 = auStack_70[0];
    if (0xfff < uVar13) {
      uVar12 = *(uint *)(auStack_70[0] - 4);
      uVar13 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar12) - 4) {
        iStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar13);
  }
  piVar15 = piStack_24;
  pcStack_1c = (code *)((uint)pcStack_1c & 0xff);
  if (iVar7 != 0) {
    pcStack_1c = (code *)0x1;
  }
  iStack_8._0_1_ = 7;
  FUN_00777e50(piStack_24[1]);
  iStack_8._0_1_ = 2;
  piStack_24[1] = (int)piVar15;
  *piStack_24 = (int)piVar15;
  piStack_24[2] = (int)piVar15;
  piStack_20 = (int *)0x0;
  FUN_01674ea0(piStack_24,0x18);
  param_1 = iStack_14;
LAB_0092a604:
  if ((param_5 != '\0') && ((char)uStack_18 == '\0')) {
    iStack_48 = 0;
    uStack_44 = 0.0;
    iStack_8._0_1_ = 8;
    if (param_1 != 0) {
      iVar7 = *(int *)(param_1 + 0x34);
      if ((iVar7 != 0) && (param_1 = iVar7, *(int *)(iVar7 + 0x34) != 0)) {
        param_1 = FUN_005c8ac0();
      }
      if (param_1 != 0) {
        iVar7 = *(int *)(param_1 + 0xc);
        iVar6 = FUN_008a8c30();
        if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          FUN_005c2760();
        }
      }
    }
    uVar9 = FUN_009cc450(auStack_88,"avatar/scripts/humanoidHealthRegenScript.rbxmx");
    iStack_8._0_1_ = 9;
    FUN_008c8540(uVar9,&iStack_48,&DAT_01d62f20);
    iStack_8._0_1_ = 8;
    uVar4 = (undefined)iStack_8;
    iStack_8._0_1_ = 8;
    if (0xf < uStack_74) {
      uVar13 = uStack_74 + 1;
      uVar12 = auStack_88[0];
      if (0xfff < uVar13) {
        uVar12 = *(uint *)(auStack_88[0] - 4);
        uVar13 = uStack_74 + 0x24;
        if (0x1f < (auStack_88[0] - uVar12) - 4) {
          iStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar13);
    }
    iVar7 = iStack_48;
    uVar4 = DAT_01ee1c34;
    iVar6 = (int)uStack_44;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    FUN_009158f0(&pcStack_28,FUN_0091d230,param_2,param_3,uVar4);
    iStack_8 = CONCAT31(iStack_8._1_3_,10);
    piVar15 = piStack_20;
    for (; iVar7 != iVar6; iVar7 = iVar7 + 8) {
      piStack_20 = piVar15;
      (*pcStack_28)(&piStack_24,iVar7);
      piVar15 = piStack_20;
    }
    piStack_24 = (int *)0x0;
    piStack_20 = (int *)0x0;
    if (piVar15 != (int *)0x0) {
      LOCK();
      iVar7 = piVar15[1] + -1;
      piVar15[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar15)();
        LOCK();
        iVar7 = piVar15[2] + -1;
        piVar15[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar15 + 4))();
        }
      }
    }
    iStack_8._0_1_ = 2;
    if (iStack_48 != 0) {
      iVar6 = (int)uStack_44;
      for (iVar7 = iStack_48; iVar7 != iVar6; iVar7 = iVar7 + 8) {
        piVar15 = *(int **)(iVar7 + 4);
        if (piVar15 != (int *)0x0) {
          LOCK();
          iVar10 = piVar15[1] + -1;
          piVar15[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar15)();
            LOCK();
            iVar10 = piVar15[2] + -1;
            piVar15[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar15 + 4))();
            }
          }
        }
      }
      uStack_44._4_4_ = (int *)((ulonglong)uStack_44 >> 0x20);
      uVar12 = ((int)uStack_44._4_4_ - iStack_48 >> 3) * 8;
      iVar7 = iStack_48;
      if (0xfff < uVar12) {
        iVar7 = *(int *)(iStack_48 + -4);
        uVar12 = uVar12 + 0x23;
        if (0x1f < (iStack_48 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar12);
    }
  }
  if ((char)pcStack_1c == '\0') {
    if (iStack_14 == 0) {
LAB_0092a851:
      uVar9 = 0;
    }
    else {
      iVar7 = *(int *)(iStack_14 + 0x34);
      iVar6 = iStack_14;
      if ((iVar7 != 0) && (iVar6 = iVar7, *(int *)(iVar7 + 0x34) != 0)) {
        iVar6 = FUN_005c8ac0();
      }
      if (iVar6 == 0) goto LAB_0092a851;
      iVar7 = *(int *)(iVar6 + 0xc);
      iVar6 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar6 + 0x1da) <
          (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) goto LAB_0092a851;
      uVar9 = FUN_005c2760();
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    FUN_00f80590(uVar9,param_2,param_3,param_4);
  }
  if (DAT_01d640e8 < 1) goto LAB_0092aa12;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  uStack_44 = (double)((float)DAT_01d640e8 / DAT_018ce320);
  FUN_005542c0(&DAT_018db428,7);
  iStack_8 = CONCAT31(iStack_8._1_3_,0xb);
  iVar7 = FUN_008a1240(auStack_70);
  if (iVar7 == 0) {
LAB_0092a907:
    iVar7 = 0;
  }
  else {
    iVar6 = *(int *)(iVar7 + 0xc);
    iVar10 = thunk_FUN_00897b90();
    if ((uint)*(ushort *)(iVar10 + 0x1da) <
        (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8)) goto LAB_0092a907;
  }
  iStack_8._0_1_ = 2;
  if (0xf < uStack_5c) {
    uVar13 = uStack_5c + 1;
    uVar12 = auStack_70[0];
    if (0xfff < uVar13) {
      uVar12 = *(uint *)(auStack_70[0] - 4);
      uVar13 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar13);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  if (iVar7 == 0) goto LAB_0092aa12;
  piStack_24 = (int *)0x0;
  piStack_20 = (int *)0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  FUN_005542c0("ScaleDampeningPercent",0x15);
  iStack_8 = CONCAT31(iStack_8._1_3_,0xc);
  iVar6 = FUN_008a1240(auStack_34);
  if (iVar6 == 0) {
LAB_0092a9b4:
    iVar6 = 0;
  }
  else {
    iVar10 = *(int *)(iVar6 + 0xc);
    iVar11 = FUN_00daf5e0();
    if ((uint)*(ushort *)(iVar11 + 0x1da) <
        (uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar11 + 0x1d8)) goto LAB_0092a9b4;
  }
  iStack_8._0_1_ = 2;
  if (0xf < piStack_20) {
    uVar13 = (int)piStack_20 + 1;
    uVar12 = auStack_34[0];
    if (0xfff < uVar13) {
      uVar12 = *(uint *)(auStack_34[0] - 4);
      uVar13 = (int)piStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar13);
  }
  piStack_24 = (int *)0x0;
  piStack_20 = (int *)&DAT_0000000f;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  if (iVar6 == 0) {
    FUN_00915ec0(&piStack_24);
    iStack_8._0_1_ = 0xd;
    FUN_00db5760(&uStack_44);
    uStack_78 = 0;
    uStack_74 = 0xf;
    auStack_88[0] = auStack_88[0] & 0xffffff00;
    pcVar3 = *(code **)(*piStack_24 + 0x38);
    FUN_005542c0("ScaleDampeningPercent",0x15);
    iStack_8._0_1_ = 0xe;
    (*pcVar3)(auStack_88);
    iStack_8._0_1_ = 0xd;
    FUN_005507b0();
    FUN_008a65e0(iVar7,0);
    piVar15 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_20[1] + -1;
      piStack_20[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar2 = piVar15 + 2;
        iVar7 = *piVar2 + -1;
        *piVar2 = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar15 + 4))();
        }
      }
    }
  }
  else {
    FUN_00db5760(&uStack_44);
  }
LAB_0092aa12:
  iStack_8 = CONCAT31(iStack_8._1_3_,0xf);
  iVar7 = FUN_0152dda0(uStack_3c,uStack_38,uStack_50);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar15 = param_3 + 1;
    iVar6 = *piVar15;
    iVar7 = *piVar15;
    *piVar15 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar15 = param_3 + 2;
      iVar6 = *piVar15;
      *piVar15 = *piVar15 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 16583 ; VA 0x0092ab80 ; FUN_0092ab80 */

void FUN_0092ab80(undefined4 param_1,uint param_2)

{
  undefined uVar1;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined8 in_stack_00000038;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined8 in_stack_00000058;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8c70;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000040 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000040 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  if ((in_stack_00000020 != 0) && ((in_stack_00000020 & 1) == 0)) {
    (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028);
  }
  uStack_8._0_1_ = 5;
  FUN_0054ef60(&param_2);
  uStack_8._0_1_ = 2;
  FUN_00f7f980(param_1);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4)) {
      uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (in_stack_00000020 != 0) {
    if (((in_stack_00000020 & 1) == 0) &&
       (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000020 & 0xfffffffe))();
    }
    in_stack_00000020 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16584 ; VA 0x0092ad20 ; FUN_0092ad20 */

void __fastcall FUN_0092ad20(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *unaff_FS_OFFSET;
  uint auStack_80 [2];
  undefined auStack_78 [24];
  uint auStack_60 [2];
  undefined auStack_58 [24];
  uint auStack_40 [2];
  undefined auStack_38 [24];
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_14;
  undefined4 uStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8cb3;
  uStack_10 = *unaff_FS_OFFSET;
  *unaff_FS_OFFSET = &uStack_10;
  FUN_0060e0c0(&uStack_20,param_1);
  uStack_8 = 0;
  uVar5 = FUN_008ed2c0(param_1);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[2] = piStack_1c[2] + 1;
    UNLOCK();
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[2] = piStack_1c[2] + 1;
      UNLOCK();
    }
  }
  auStack_60[0] = 0;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[2] = piStack_1c[2] + 1;
    UNLOCK();
  }
  FUN_00914840(uStack_20,piStack_1c,uVar5);
  if (piStack_1c != (int *)0x0) {
    piVar1 = piStack_1c + 2;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piStack_1c + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  uStack_8._0_1_ = 1;
  uVar5 = FUN_0151a450(auStack_80,auStack_60,"rbx_getPlayerMetaData");
  uStack_8._0_1_ = 2;
  auStack_40[0] = 0;
  FUN_005880d0(uVar5);
  uStack_8._0_1_ = 3;
  puStack_14 = (undefined4 *)FUN_00563bf0(auStack_40);
  if (puStack_14 != (undefined4 *)0x0) {
    LOCK();
    puStack_14[1] = puStack_14[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 6;
  if (auStack_40[0] != 0) {
    if (((auStack_40[0] & 1) == 0) && (*(code **)(auStack_40[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_40[0] & 0xfffffffe))(auStack_38,auStack_38,2);
    }
    auStack_40[0] = 0;
  }
  uStack_8._0_1_ = 5;
  cVar4 = FUN_0168a8f0();
  if (cVar4 != '\0') {
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_016899e0();
    puVar3 = puStack_14;
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      iVar2 = puStack_14[1] + -1;
      puStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*puStack_14)(0);
        uVar5 = GetProcessHeap(0,puVar3);
        HeapFree(uVar5);
      }
    }
    uStack_8._0_1_ = 9;
    if (auStack_80[0] != 0) {
      if (((auStack_80[0] & 1) == 0) && (*(code **)(auStack_80[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_80[0] & 0xfffffffe))(auStack_78,auStack_78,2);
      }
      auStack_80[0] = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    if (((auStack_60[0] != 0) && ((auStack_60[0] & 1) == 0)) &&
       (*(code **)(auStack_60[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_60[0] & 0xfffffffe))(auStack_58,auStack_58,2);
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
    *unaff_FS_OFFSET = uStack_10;
    return;
  }
  uVar5 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar5);
}



/* FUNCTION 16585 ; VA 0x0092af20 ; FUN_0092af20 */

void * FUN_0092af20(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  undefined uVar4;
  void **ppvVar5;
  undefined *puVar6;
  char cVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined4 uVar10;
  void *pvVar11;
  undefined4 ****ppppuVar12;
  uint uVar13;
  uint uVar14;
  undefined4 *****pppppuVar15;
  int *piVar16;
  undefined1 *puVar17;
  undefined4 ****ppppuStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined8 uStack_164;
  uint uStack_144;
  undefined4 uStack_134;
  uint uStack_130;
  uint uStack_110;
  undefined4 uStack_100;
  uint uStack_fc;
  undefined auStack_f4 [12];
  uint auStack_e8 [4];
  undefined4 uStack_d8;
  uint uStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  undefined auStack_b8 [12];
  uint auStack_ac [4];
  undefined4 uStack_9c;
  uint uStack_98;
  int *piStack_90;
  int *piStack_88;
  uint auStack_84 [4];
  undefined4 uStack_74;
  uint uStack_70;
  undefined auStack_6c [12];
  undefined auStack_60 [4];
  int *piStack_5c;
  undefined auStack_58 [4];
  int *piStack_54;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 ****ppppuStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined4 ****ppppuStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8d3a;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffe80;
  uStack_48 = 0;
  uStack_4c = 0;
  iStack_24 = 0;
  piStack_1c = (int *)0x0;
  piStack_20 = (int *)0x0;
  pvVar11 = ExceptionList;
  ppvVar5 = &pvStack_10;
  if (param_2 != (int *)0x0) {
    piVar16 = param_2 + 1;
    pvVar3 = (void *)param_2[1];
    ppvVar5 = &pvStack_10;
    while (ExceptionList = ppvVar5, ppvVar5 = (void **)ExceptionList, piStack_1c = piStack_20,
          pvVar3 != (void *)0x0) {
      LOCK();
      pvVar11 = (void *)*piVar16;
      if (pvVar3 == pvVar11) {
        *piVar16 = (int)pvVar3 + 1;
        pvVar11 = pvVar3;
      }
      UNLOCK();
      if (pvVar11 == pvVar3) {
        iStack_24 = param_1;
        piStack_1c = param_2;
        ppvVar5 = (void **)ExceptionList;
        break;
      }
      ppvVar5 = (void **)ExceptionList;
      pvVar3 = (void *)*piVar16;
    }
  }
  ExceptionList = ppvVar5;
  iVar2 = iStack_24;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  piStack_20 = piStack_1c;
  puVar6 = &stack0xfffffe80;
  if (iStack_24 == 0) goto LAB_0092b4f6;
  uStack_9c = 0;
  uStack_98 = 0xf;
  auStack_ac[0] = auStack_ac[0] & 0xffffff00;
  uStack_8 = 3;
  uStack_74 = 0;
  uStack_70 = 0xf;
  auStack_84[0] = auStack_84[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 4;
  if ((*(int *)(iVar2 + 0xf0) != *(uint *)(iVar2 + 0xf8) + 0xaaf55c4e) ||
     (*(int *)(iVar2 + 0xf4) !=
      *(int *)(iVar2 + 0xfc) - (uint)(*(uint *)(iVar2 + 0xf8) < 0x550aa3b2))) {
    FUN_01675310("SecurityViolation",&DAT_018bc9b8);
  }
  uVar8 = FUN_00f54b90(auStack_d0,*(undefined4 *)(iVar2 + 0xf0),*(undefined4 *)(iVar2 + 0xf4),
                       auStack_84);
  uStack_8._0_1_ = 5;
  FUN_014cc090(uVar8,7,0);
  uStack_8._0_1_ = 7;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_bc) {
    uVar13 = uStack_bc + 1;
    uVar14 = auStack_d0[0];
    if (0xfff < uVar13) {
      uVar14 = *(uint *)(auStack_d0[0] - 4);
      uVar13 = uStack_bc + 0x24;
      if (0x1f < (auStack_d0[0] - uVar14) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar14,uVar13);
  }
  uStack_c0 = 0;
  uStack_bc = 0xf;
  auStack_d0[0] = auStack_d0[0] & 0xffffff00;
  uStack_8._0_1_ = 8;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_70) {
    uVar13 = uStack_70 + 1;
    uVar14 = auStack_84[0];
    if (0xfff < uVar13) {
      uVar14 = *(uint *)(auStack_84[0] - 4);
      uVar13 = uStack_70 + 0x24;
      if (0x1f < (auStack_84[0] - uVar14) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar14,uVar13);
  }
  uStack_74 = 0;
  uStack_70 = 0xf;
  auStack_84[0] = auStack_84[0] & 0xffffff00;
  FUN_014cd0a0(auStack_ac,0,0);
  uStack_34 = 0xf00000000;
  ppppuStack_44 = (undefined4 ****)((uint)ppppuStack_44 & 0xffffff00);
  uStack_8._0_1_ = 9;
  FUN_016819e0(auStack_6c,auStack_ac);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  cVar7 = FUN_016816d0();
  if (cVar7 != '\0') {
    FUN_016756b0(auStack_f4,"JSON parse error");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_f4,&DAT_01c17198);
  }
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"Completed Player\'s JSON parsing...",0);
  }
  FUN_0167eea0(auStack_b8,PTR_s_ChatFilter_01d64288);
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  auStack_e8[0] = auStack_e8[0] & 0xffffff00;
  uStack_8._0_1_ = 0xb;
  FUN_01681330(&ppppuStack_174,auStack_e8);
  uStack_48 = uStack_48 | 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (0xf < uStack_d4) {
    uVar13 = uStack_d4 + 1;
    uVar14 = auStack_e8[0];
    if (0xfff < uVar13) {
      uVar14 = *(uint *)(auStack_e8[0] - 4);
      uVar13 = uStack_d4 + 0x24;
      if (0x1f < (auStack_e8[0] - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar14,uVar13);
  }
  if (0xf < uStack_34._4_4_) {
    uVar14 = uStack_34._4_4_ + 1;
    ppppuVar12 = ppppuStack_44;
    if (0xfff < uVar14) {
      ppppuVar12 = (undefined4 ****)ppppuStack_44[-1];
      uVar14 = uStack_34._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_44 + (-4 - (int)ppppuVar12))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar12,uVar14);
  }
  ppppuStack_44 = ppppuStack_174;
  uStack_40 = uStack_170;
  uStack_3c = uStack_16c;
  uStack_38 = uStack_168;
  uStack_34 = uStack_164;
  if (DAT_01ee420a != '\0') {
    FUN_01677760(DAT_01ee420a,"loadChatInfoInternal.chatFilterType: %s",&ppppuStack_44);
  }
  uStack_8._0_1_ = 0xc;
  piStack_88 = (int *)FUN_016de181(1);
  uStack_8._0_1_ = 0xe;
  piStack_54 = piStack_88;
  (**(code **)(*piStack_88 + 4))();
  pppppuVar15 = &ppppuStack_44;
  if (0xf < uStack_34._4_4_) {
    pppppuVar15 = (undefined4 *****)ppppuStack_44;
  }
  puVar17 = &DAT_01931e9c;
  uStack_8._0_1_ = 0xf;
  ppppuStack_28 = (undefined4 *****)((int)uStack_34 + (int)pppppuVar15);
  pppppuVar15 = &ppppuStack_44;
  if (0xf < uStack_34._4_4_) {
    pppppuVar15 = (undefined4 *****)ppppuStack_44;
  }
  for (; piVar16 = piStack_88, puVar17 != &DAT_01931ea5; puVar17 = puVar17 + 1) {
    if (pppppuVar15 == (undefined4 *****)ppppuStack_28) goto LAB_0092b31f;
    cStack_15 = FUN_00564a80(*(undefined *)pppppuVar15,auStack_58);
    cVar7 = FUN_00564a80(*puVar17,auStack_58);
    piVar16 = piStack_88;
    if (cVar7 != cStack_15) {
      uStack_8._0_1_ = 0x10;
      if ((piStack_88 != (int *)0x0) &&
         (puVar9 = (undefined4 *)(**(code **)(*piStack_88 + 8))(), puVar9 != (undefined4 *)0x0)) {
        (**(code **)*puVar9)(1);
      }
      cStack_15 = '\0';
      goto LAB_0092b354;
    }
    pppppuVar15 = (undefined4 *****)((int)pppppuVar15 + 1);
  }
  if (pppppuVar15 == (undefined4 *****)ppppuStack_28) {
LAB_0092b31f:
    cStack_15 = '\x01';
    if (puVar17 != &DAT_01931ea5) goto LAB_0092b32b;
  }
  else {
LAB_0092b32b:
    cStack_15 = '\0';
  }
  uStack_8._0_1_ = 0x11;
  if ((piStack_88 != (int *)0x0) &&
     (puVar9 = (undefined4 *)(**(code **)(*piStack_88 + 8))(), puVar9 != (undefined4 *)0x0)) {
    (**(code **)*puVar9)(1);
  }
LAB_0092b354:
  uStack_8._0_1_ = 0x12;
  if ((piVar16 != (int *)0x0) &&
     (puVar9 = (undefined4 *)(**(code **)(*piVar16 + 8))(), puVar9 != (undefined4 *)0x0)) {
    (**(code **)*puVar9)(1);
  }
  if (cStack_15 == '\0') {
    uStack_8._0_1_ = 0x13;
    piStack_90 = (int *)FUN_016de181(1);
    uStack_8._0_1_ = 0x15;
    piStack_5c = piStack_90;
    (**(code **)(*piStack_90 + 4))();
    pppppuVar15 = &ppppuStack_44;
    if (0xf < uStack_34._4_4_) {
      pppppuVar15 = (undefined4 *****)ppppuStack_44;
    }
    puVar17 = &DAT_018d46dc;
    uStack_8._0_1_ = 0x16;
    ppppuStack_28 = (undefined4 *****)((int)uStack_34 + (int)pppppuVar15);
    pppppuVar15 = &ppppuStack_44;
    if (0xf < uStack_34._4_4_) {
      pppppuVar15 = (undefined4 *****)ppppuStack_44;
    }
    for (; piVar16 = piStack_90, puVar17 != &DAT_018d46e5; puVar17 = puVar17 + 1) {
      if (pppppuVar15 == (undefined4 *****)ppppuStack_28) goto LAB_0092b43a;
      cStack_15 = FUN_00564a80(*(undefined *)pppppuVar15,auStack_60);
      cVar7 = FUN_00564a80(*puVar17,auStack_60);
      piVar16 = piStack_90;
      if (cVar7 != cStack_15) {
        uStack_8._0_1_ = 0x17;
        if ((piStack_90 != (int *)0x0) &&
           (puVar9 = (undefined4 *)(**(code **)(*piStack_90 + 8))(), puVar9 != (undefined4 *)0x0)) {
          (**(code **)*puVar9)(1);
        }
        cStack_15 = '\0';
        goto LAB_0092b46f;
      }
      pppppuVar15 = (undefined4 *****)((int)pppppuVar15 + 1);
    }
    if (pppppuVar15 == (undefined4 *****)ppppuStack_28) {
LAB_0092b43a:
      cStack_15 = '\x01';
      if (puVar17 != &DAT_018d46e5) goto LAB_0092b446;
    }
    else {
LAB_0092b446:
      cStack_15 = '\0';
    }
    uStack_8._0_1_ = 0x18;
    if ((piStack_90 != (int *)0x0) &&
       (puVar9 = (undefined4 *)(**(code **)(*piStack_90 + 8))(), puVar9 != (undefined4 *)0x0)) {
      (**(code **)*puVar9)(1);
    }
LAB_0092b46f:
    uStack_8._0_1_ = 0x19;
    if ((piVar16 != (int *)0x0) &&
       (puVar9 = (undefined4 *)(**(code **)(*piVar16 + 8))(), puVar9 != (undefined4 *)0x0)) {
      (**(code **)*puVar9)(1);
    }
    uStack_8._0_1_ = 10;
    if (cStack_15 == '\0') {
      FUN_0167ec40();
      uStack_8._0_1_ = 8;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 8;
      if (0xf < uStack_34._4_4_) {
        uVar14 = uStack_34._4_4_ + 1;
        pppppuVar15 = (undefined4 *****)ppppuStack_44;
        if (0xfff < uVar14) {
          pppppuVar15 = (undefined4 *****)ppppuStack_44[-1];
          uVar14 = uStack_34._4_4_ + 0x24;
          if ((undefined *)0x1f < (undefined *)((int)ppppuStack_44 + (-4 - (int)pppppuVar15))) {
            uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppuVar15,uVar14);
      }
      uStack_34 = 0xf00000000;
      ppppuStack_44 = (undefined4 ****)((uint)ppppuStack_44 & 0xffffff00);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (0xf < uStack_fc) {
        uVar13 = uStack_fc + 1;
        uVar14 = uStack_110;
        if (0xfff < uVar13) {
          uVar14 = *(uint *)(uStack_110 - 4);
          uVar13 = uStack_fc + 0x24;
          if (0x1f < (uStack_110 - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar14,uVar13);
      }
      uStack_100 = 0;
      uStack_fc = 0xf;
      uStack_110 = uStack_110 & 0xffffff00;
      FUN_0056cfd0();
      if (0xf < uStack_130) {
        uVar13 = uStack_130 + 1;
        uVar14 = uStack_144;
        if (0xfff < uVar13) {
          uVar14 = *(uint *)(uStack_144 - 4);
          uVar13 = uStack_130 + 0x24;
          if (0x1f < (uStack_144 - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar14,uVar13);
      }
      uStack_134 = 0;
      uStack_130 = 0xf;
      uStack_144 = uStack_144 & 0xffffff00;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (0xf < uStack_98) {
        uVar13 = uStack_98 + 1;
        uVar14 = auStack_ac[0];
        if (0xfff < uVar13) {
          uVar14 = *(uint *)(auStack_ac[0] - 4);
          uVar13 = uStack_98 + 0x24;
          if (0x1f < (auStack_ac[0] - uVar14) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar14,uVar13);
      }
      pvVar11 = (void *)FUN_0092b6c1();
      return pvVar11;
    }
    uVar8 = 1;
  }
  else {
    uVar8 = 0;
  }
  iVar2 = iStack_24;
  uStack_8._0_1_ = 10;
  uVar10 = FUN_008f7870(iStack_24);
  FUN_008e9480(uVar10,1);
  FUN_008eb110();
  *(undefined4 *)(iVar2 + 0x490) = uVar8;
  *(undefined *)(iVar2 + 0x4c5) = 1;
  FUN_0167ec40();
  FUN_005507b0();
  FUN_0056db40();
  pvVar11 = (void *)FUN_005507b0();
  puVar6 = puStack_14;
LAB_0092b4f6:
  puStack_14 = puVar6;
  piVar16 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    pvVar11 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar16 + 2;
      iVar2 = *piVar1;
      pvVar11 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar11 = (void *)(**(code **)(*piVar16 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar16 = param_2 + 2;
    iVar2 = *piVar16;
    *piVar16 = *piVar16 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      pvVar11 = (void *)(**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pvVar11;
}



/* FUNCTION 16586 ; VA 0x0092b68f ; Catch@0092b68f */

undefined * Catch_0092b68f(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0xac) + 4))();
  FUN_0086f2f0(3,"loadChatInfoInternal had an error: %s",uVar1);
  FUN_0086f2f0(1,"loadChatInfoInternal retrying...");
  return &DAT_0092b6be;
}



/* FUNCTION 16587 ; VA 0x0092b6c1 ; FUN_0092b6c1 */

uint FUN_0092b6c1(void)

{
  uint *puVar1;
  int *piVar2;
  char *pcVar3;
  uint uVar4;
  char cVar5;
  undefined uVar6;
  byte *pbVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  uint uVar10;
  char *pcVar11;
  uint uVar12;
  int iVar13;
  int unaff_EBP;
  int *piVar14;
  byte *pbVar15;
  int *unaff_ESI;
  int iVar16;
  byte *pbVar17;
  undefined4 uVar18;
  longlong lVar19;
  undefined8 uVar20;
  char *pcStack_8;
  char *pcStack_4;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  *(undefined4 *)(unaff_EBP + -0x20) = 0;
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  if (unaff_ESI != (int *)0x0) {
    LOCK();
    iVar13 = unaff_ESI[1] + -1;
    unaff_ESI[1] = iVar13;
    UNLOCK();
    if (iVar13 == 0) {
      pcStack_4 = (char *)0x92b6ec;
      (**(code **)*unaff_ESI)();
      LOCK();
      iVar13 = unaff_ESI[2] + -1;
      unaff_ESI[2] = iVar13;
      UNLOCK();
      if (iVar13 == 0) {
        pcStack_4 = (char *)0x92b6fc;
        (**(code **)(*unaff_ESI + 4))();
      }
    }
  }
  pcStack_4 = (char *)0x0;
  pcStack_8 = (char *)0x3e8;
  lVar19 = FUN_016f3900((longlong)(1000 << ((byte)*(undefined4 *)(unaff_EBP + -0x48) & 0x1f)) * 1000
                       );
  uVar18 = (undefined4)lVar19;
  *(int *)(unaff_EBP + -0x18) = (int)((ulonglong)lVar19 >> 0x20);
  if ((lVar19 < 0x100000000) && (lVar19 < 0)) {
    *(undefined8 *)(unaff_EBP + -0x28) = 0;
    uVar18 = *(undefined4 *)(unaff_EBP + -0x28);
    *(undefined4 *)(unaff_EBP + -0x18) = *(undefined4 *)(unaff_EBP + -0x24);
  }
  if (DAT_01ea94c0 == (code *)0x0) {
    uVar9 = GetModuleHandleA("KERNEL32.DLL","GetTickCount64");
    DAT_01ea94c0 = (code *)GetProcAddress(uVar9);
    if (DAT_01ea94c0 == (code *)0x0) {
      DAT_01ea94c0 = FUN_005efd30;
    }
  }
  uVar20 = (*DAT_01ea94c0)();
  FUN_005f0a90(&pcStack_8,FUN_005f1e70,uVar20,uVar18,*(undefined4 *)(unaff_EBP + -0x18),1);
  FUN_01689e80(0xffffffff);
  uVar4 = *(uint *)(unaff_EBP + -0x48);
  uVar10 = (uint)DAT_01d640a0;
  uVar12 = uVar4 + 1;
  if (uVar10 <= uVar4) {
    uVar12 = uVar4;
  }
  piVar14 = (int *)0x0;
  *(uint *)(unaff_EBP + -0x48) = uVar12;
  iVar13 = *(int *)(unaff_EBP + 0xc);
  iVar16 = 0;
  *(undefined4 *)(unaff_EBP + -0x20) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0;
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  if (iVar13 != 0) {
    puVar1 = (uint *)(iVar13 + 4);
    uVar4 = *(uint *)(iVar13 + 4);
    while (uVar4 != 0) {
      LOCK();
      uVar10 = *puVar1;
      if (uVar4 == uVar10) {
        *puVar1 = uVar4 + 1;
        uVar10 = uVar4;
      }
      UNLOCK();
      if (uVar10 == uVar4) {
        iVar16 = *(int *)(unaff_EBP + 8);
        piVar14 = *(int **)(unaff_EBP + 0xc);
        *(int *)(unaff_EBP + -0x20) = iVar16;
        *(int **)(unaff_EBP + -0x1c) = piVar14;
        goto LAB_0092af92;
      }
      uVar4 = *puVar1;
    }
    piVar14 = *(int **)(unaff_EBP + -0x1c);
    iVar16 = *(int *)(unaff_EBP + -0x20);
LAB_0092af92:
    *(int **)(unaff_EBP + -0x18) = piVar14;
  }
  *(undefined *)(unaff_EBP + -4) = 1;
  if (iVar16 == 0) goto LAB_0092b4f6;
  *(undefined4 *)(unaff_EBP + -0x98) = 0;
  *(undefined4 *)(unaff_EBP + -0x94) = 0xf;
  *(undefined *)(unaff_EBP + -0xa8) = 0;
  pcStack_4 = (char *)0x0;
  pcStack_8 = "";
  *(undefined *)(unaff_EBP + -4) = 3;
  *(undefined4 *)(unaff_EBP + -0x70) = 0;
  *(undefined4 *)(unaff_EBP + -0x6c) = 0xf;
  *(undefined *)(unaff_EBP + -0x80) = 0;
  FUN_005542c0();
  uVar10 = *(uint *)(iVar16 + 0xf8);
  iVar13 = *(int *)(iVar16 + 0xfc);
  *(undefined *)(unaff_EBP + -4) = 4;
  if ((*(int *)(iVar16 + 0xf0) != uVar10 + 0xaaf55c4e) ||
     (*(int *)(iVar16 + 0xf4) != iVar13 - (uint)(uVar10 < 0x550aa3b2))) {
    pcStack_4 = "";
    pcStack_8 = "SecurityViolation";
    FUN_01675310();
  }
  pcStack_4 = (char *)(unaff_EBP + -0x80);
  pcStack_8 = *(char **)(iVar16 + 0xf4);
  FUN_00f54b90(unaff_EBP + -0xcc,*(undefined4 *)(iVar16 + 0xf0));
  pcStack_4 = (char *)0x0;
  pcStack_8 = (char *)0x7;
  *(undefined *)(unaff_EBP + -4) = 5;
  FUN_014cc090();
  uVar10 = *(uint *)(unaff_EBP + -0xb8);
  *(undefined *)(unaff_EBP + -4) = 7;
  if (0xf < uVar10) {
    pcVar3 = *(char **)(unaff_EBP + -0xcc);
    pcStack_4 = (char *)(uVar10 + 1);
    pcVar11 = pcVar3;
    if (0xfff < pcStack_4) {
      pcVar11 = *(char **)(pcVar3 + -4);
      pcStack_4 = (char *)(uVar10 + 0x24);
      if ((char *)0x1f < pcVar3 + (-4 - (int)pcVar11)) {
                    /* WARNING: Subroutine does not return */
        pcStack_4 = (char *)0x92b7c4;
        FUN_017167a3();
      }
    }
    pcStack_8 = pcVar11;
    FUN_01674ea0();
  }
  *(undefined4 *)(unaff_EBP + -0xbc) = 0;
  *(undefined4 *)(unaff_EBP + -0xb8) = 0xf;
  *(undefined *)(unaff_EBP + -0xcc) = 0;
  uVar10 = *(uint *)(unaff_EBP + -0x6c);
  *(undefined *)(unaff_EBP + -4) = 8;
  if (0xf < uVar10) {
    pcVar3 = *(char **)(unaff_EBP + -0x80);
    pcStack_4 = (char *)(uVar10 + 1);
    pcVar11 = pcVar3;
    if (0xfff < pcStack_4) {
      pcVar11 = *(char **)(pcVar3 + -4);
      pcStack_4 = (char *)(uVar10 + 0x24);
      if ((char *)0x1f < pcVar3 + (-4 - (int)pcVar11)) {
                    /* WARNING: Subroutine does not return */
        pcStack_4 = (char *)0x92b7c9;
        FUN_017167a3();
      }
    }
    pcStack_8 = pcVar11;
    FUN_01674ea0();
  }
  pcStack_4 = (char *)0x0;
  pcStack_8 = (char *)0x0;
  *(undefined4 *)(unaff_EBP + -0x70) = 0;
  *(undefined4 *)(unaff_EBP + -0x6c) = 0xf;
  *(undefined *)(unaff_EBP + -0x80) = 0;
  FUN_014cd0a0();
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  *(undefined *)(unaff_EBP + -0x40) = 0;
  pcStack_4 = (char *)(unaff_EBP + -0xa8);
  *(undefined *)(unaff_EBP + -4) = 9;
  pcStack_8 = (char *)(unaff_EBP + -0x68);
  FUN_016819e0();
  *(undefined *)(unaff_EBP + -4) = 10;
  pcStack_4 = (char *)0x92b14f;
  cVar5 = FUN_016816d0();
  if (cVar5 != '\0') {
    pcStack_8 = (char *)(unaff_EBP + -0xf0);
    pcStack_4 = "JSON parse error";
    FUN_016756b0();
    pcStack_8 = (char *)(unaff_EBP + -0xf0);
    pcStack_4 = "";
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8();
  }
  if (DAT_01ee420a != '\0') {
    pcStack_4 = (char *)0x0;
    pcStack_8 = "Completed Player\'s JSON parsing...";
    FUN_016774b0();
  }
  pcStack_4 = PTR_s_ChatFilter_01d64288;
  pcStack_8 = (char *)(unaff_EBP + -0xb4);
  FUN_0167eea0();
  *(undefined4 *)(unaff_EBP + -0xd4) = 0;
  *(undefined4 *)(unaff_EBP + -0xd0) = 0xf;
  *(undefined *)(unaff_EBP + -0xe4) = 0;
  pcStack_4 = (char *)(unaff_EBP + -0xe4);
  *(undefined *)(unaff_EBP + -4) = 0xb;
  pcStack_8 = (char *)(unaff_EBP + -0x170);
  FUN_01681330();
  *(uint *)(unaff_EBP + -0x44) = *(uint *)(unaff_EBP + -0x44) | 1;
  uVar10 = *(uint *)(unaff_EBP + -0xd0);
  *(undefined *)(unaff_EBP + -4) = 10;
  if (0xf < uVar10) {
    pcVar3 = *(char **)(unaff_EBP + -0xe4);
    pcStack_4 = (char *)(uVar10 + 1);
    pcVar11 = pcVar3;
    if (0xfff < pcStack_4) {
      pcVar11 = *(char **)(pcVar3 + -4);
      pcStack_4 = (char *)(uVar10 + 0x24);
      if ((char *)0x1f < pcVar3 + (-4 - (int)pcVar11)) {
                    /* WARNING: Subroutine does not return */
        pcStack_4 = (char *)0x92b7f3;
        FUN_017167a3();
      }
    }
    pcStack_8 = pcVar11;
    FUN_01674ea0();
  }
  uVar10 = *(uint *)(unaff_EBP + -0x2c);
  if (0xf < uVar10) {
    pcVar3 = *(char **)(unaff_EBP + -0x40);
    pcStack_4 = (char *)(uVar10 + 1);
    pcVar11 = pcVar3;
    if (0xfff < pcStack_4) {
      pcVar11 = *(char **)(pcVar3 + -4);
      pcStack_4 = (char *)(uVar10 + 0x24);
      if ((char *)0x1f < pcVar3 + (-4 - (int)pcVar11)) {
                    /* WARNING: Subroutine does not return */
        pcStack_4 = (char *)0x92b7f8;
        FUN_017167a3();
      }
    }
    pcStack_8 = pcVar11;
    FUN_01674ea0();
  }
  cVar5 = DAT_01ee420a;
  *(undefined4 *)(unaff_EBP + -0x40) = *(undefined4 *)(unaff_EBP + -0x170);
  *(undefined4 *)(unaff_EBP + -0x3c) = *(undefined4 *)(unaff_EBP + -0x16c);
  *(undefined4 *)(unaff_EBP + -0x38) = *(undefined4 *)(unaff_EBP + -0x168);
  *(undefined4 *)(unaff_EBP + -0x34) = *(undefined4 *)(unaff_EBP + -0x164);
  *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(unaff_EBP + -0x160);
  if (cVar5 != '\0') {
    pcStack_4 = (char *)(unaff_EBP + -0x40);
    pcStack_8 = "loadChatInfoInternal.chatFilterType: %s";
    FUN_01677760();
  }
  pcStack_4 = (char *)0x1;
  *(undefined *)(unaff_EBP + -4) = 0xc;
  pcStack_8 = (char *)0x92b277;
  piVar14 = (int *)FUN_016de181();
  *(int **)(unaff_EBP + -0x84) = piVar14;
  iVar13 = *piVar14;
  *(undefined *)(unaff_EBP + -4) = 0xe;
  *(int **)(unaff_EBP + -0x50) = piVar14;
  pcStack_4 = (char *)0x92b28e;
  (**(code **)(iVar13 + 4))();
  iVar13 = unaff_EBP + -0x40;
  if (0xf < *(uint *)(unaff_EBP + -0x2c)) {
    iVar13 = *(int *)(unaff_EBP + -0x40);
  }
  pbVar17 = &DAT_01931e9c;
  pbVar7 = (byte *)(*(int *)(unaff_EBP + -0x30) + iVar13);
  *(undefined *)(unaff_EBP + -4) = 0xf;
  *(byte **)(unaff_EBP + -0x24) = pbVar7;
  pbVar15 = (byte *)(unaff_EBP + -0x40);
  if (0xf < *(uint *)(unaff_EBP + -0x2c)) {
    pbVar15 = *(byte **)(unaff_EBP + -0x40);
  }
  for (; pbVar17 != &DAT_01931ea5; pbVar17 = pbVar17 + 1) {
    if (pbVar15 == pbVar7) goto LAB_0092b31f;
    pcStack_4 = (char *)(unaff_EBP + -0x54);
    pcStack_8 = (char *)(uint)*pbVar15;
    uVar6 = FUN_00564a80();
    pcStack_8 = (char *)(uint)*pbVar17;
    *(undefined *)(unaff_EBP + -0x11) = uVar6;
    pcStack_4 = (char *)(unaff_EBP + -0x54);
    cVar5 = FUN_00564a80();
    if (cVar5 != *(char *)(unaff_EBP + -0x11)) {
      piVar14 = *(int **)(unaff_EBP + -0x84);
      *(undefined *)(unaff_EBP + -4) = 0x10;
      if (piVar14 != (int *)0x0) {
        pcStack_4 = (char *)0x92b300;
        puVar8 = (undefined4 *)(**(code **)(*piVar14 + 8))();
        if (puVar8 != (undefined4 *)0x0) {
          pcStack_4 = (char *)0x1;
          pcStack_8 = (char *)0x92b30e;
          (**(code **)*puVar8)();
        }
      }
      *(undefined *)(unaff_EBP + -0x11) = 0;
      goto LAB_0092b354;
    }
    pbVar7 = *(byte **)(unaff_EBP + -0x24);
    pbVar15 = pbVar15 + 1;
  }
  if (pbVar15 == pbVar7) {
LAB_0092b31f:
    *(undefined *)(unaff_EBP + -0x11) = 1;
    if (pbVar17 != &DAT_01931ea5) goto LAB_0092b32b;
  }
  else {
LAB_0092b32b:
    *(undefined *)(unaff_EBP + -0x11) = 0;
  }
  piVar14 = *(int **)(unaff_EBP + -0x84);
  *(undefined *)(unaff_EBP + -4) = 0x11;
  if (piVar14 != (int *)0x0) {
    pcStack_4 = (char *)0x92b346;
    puVar8 = (undefined4 *)(**(code **)(*piVar14 + 8))();
    if (puVar8 != (undefined4 *)0x0) {
      pcStack_4 = (char *)0x1;
      pcStack_8 = (char *)0x92b354;
      (**(code **)*puVar8)();
    }
  }
LAB_0092b354:
  *(undefined *)(unaff_EBP + -4) = 0x12;
  if (piVar14 != (int *)0x0) {
    pcStack_4 = (char *)0x92b365;
    puVar8 = (undefined4 *)(**(code **)(*piVar14 + 8))();
    if (puVar8 != (undefined4 *)0x0) {
      pcStack_4 = (char *)0x1;
      pcStack_8 = (char *)0x92b373;
      (**(code **)*puVar8)();
    }
  }
  *(undefined *)(unaff_EBP + -4) = 10;
  if (*(char *)(unaff_EBP + -0x11) == '\0') {
    pcStack_4 = (char *)0x1;
    *(undefined *)(unaff_EBP + -4) = 0x13;
    pcStack_8 = (char *)0x92b38f;
    piVar14 = (int *)FUN_016de181();
    *(int **)(unaff_EBP + -0x8c) = piVar14;
    iVar13 = *piVar14;
    *(undefined *)(unaff_EBP + -4) = 0x15;
    *(int **)(unaff_EBP + -0x58) = piVar14;
    pcStack_4 = (char *)0x92b3a6;
    (**(code **)(iVar13 + 4))();
    iVar13 = unaff_EBP + -0x40;
    if (0xf < *(uint *)(unaff_EBP + -0x2c)) {
      iVar13 = *(int *)(unaff_EBP + -0x40);
    }
    pbVar17 = &DAT_018d46dc;
    pbVar7 = (byte *)(*(int *)(unaff_EBP + -0x30) + iVar13);
    *(undefined *)(unaff_EBP + -4) = 0x16;
    *(byte **)(unaff_EBP + -0x24) = pbVar7;
    pbVar15 = (byte *)(unaff_EBP + -0x40);
    if (0xf < *(uint *)(unaff_EBP + -0x2c)) {
      pbVar15 = *(byte **)(unaff_EBP + -0x40);
    }
    for (; pbVar17 != &DAT_018d46e5; pbVar17 = pbVar17 + 1) {
      if (pbVar15 == pbVar7) goto LAB_0092b43a;
      pcStack_4 = (char *)(unaff_EBP + -0x5c);
      pcStack_8 = (char *)(uint)*pbVar15;
      uVar6 = FUN_00564a80();
      pcStack_8 = (char *)(uint)*pbVar17;
      *(undefined *)(unaff_EBP + -0x11) = uVar6;
      pcStack_4 = (char *)(unaff_EBP + -0x5c);
      cVar5 = FUN_00564a80();
      if (cVar5 != *(char *)(unaff_EBP + -0x11)) {
        piVar14 = *(int **)(unaff_EBP + -0x8c);
        *(undefined *)(unaff_EBP + -4) = 0x17;
        if (piVar14 != (int *)0x0) {
          pcStack_4 = (char *)0x92b41b;
          puVar8 = (undefined4 *)(**(code **)(*piVar14 + 8))();
          if (puVar8 != (undefined4 *)0x0) {
            pcStack_4 = (char *)0x1;
            pcStack_8 = (char *)0x92b429;
            (**(code **)*puVar8)();
          }
        }
        *(undefined *)(unaff_EBP + -0x11) = 0;
        goto LAB_0092b46f;
      }
      pbVar7 = *(byte **)(unaff_EBP + -0x24);
      pbVar15 = pbVar15 + 1;
    }
    if (pbVar15 == pbVar7) {
LAB_0092b43a:
      *(undefined *)(unaff_EBP + -0x11) = 1;
      if (pbVar17 != &DAT_018d46e5) goto LAB_0092b446;
    }
    else {
LAB_0092b446:
      *(undefined *)(unaff_EBP + -0x11) = 0;
    }
    piVar14 = *(int **)(unaff_EBP + -0x8c);
    *(undefined *)(unaff_EBP + -4) = 0x18;
    if (piVar14 != (int *)0x0) {
      pcStack_4 = (char *)0x92b461;
      puVar8 = (undefined4 *)(**(code **)(*piVar14 + 8))();
      if (puVar8 != (undefined4 *)0x0) {
        pcStack_4 = (char *)0x1;
        pcStack_8 = (char *)0x92b46f;
        (**(code **)*puVar8)();
      }
    }
LAB_0092b46f:
    *(undefined *)(unaff_EBP + -4) = 0x19;
    if (piVar14 != (int *)0x0) {
      pcStack_4 = (char *)0x92b480;
      puVar8 = (undefined4 *)(**(code **)(*piVar14 + 8))();
      if (puVar8 != (undefined4 *)0x0) {
        pcStack_4 = (char *)0x1;
        pcStack_8 = (char *)0x92b48e;
        (**(code **)*puVar8)();
      }
    }
    *(undefined *)(unaff_EBP + -4) = 10;
    if (*(char *)(unaff_EBP + -0x11) == '\0') {
      pcStack_4 = (char *)0x92b549;
      FUN_0167ec40();
      uVar10 = *(uint *)(unaff_EBP + -0x2c);
      *(undefined *)(unaff_EBP + -4) = 8;
      if (0xf < uVar10) {
        pcVar3 = *(char **)(unaff_EBP + -0x40);
        pcStack_4 = (char *)(uVar10 + 1);
        pcVar11 = pcVar3;
        if (0xfff < pcStack_4) {
          pcVar11 = *(char **)(pcVar3 + -4);
          pcStack_4 = (char *)(uVar10 + 0x24);
          if ((char *)0x1f < pcVar3 + (-4 - (int)pcVar11)) {
                    /* WARNING: Subroutine does not return */
            pcStack_4 = (char *)0x92b7fd;
            FUN_017167a3();
          }
        }
        pcStack_8 = pcVar11;
        FUN_01674ea0();
      }
      uVar10 = *(uint *)(unaff_EBP + -0xf8);
      *(undefined4 *)(unaff_EBP + -0x30) = 0;
      *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
      *(undefined *)(unaff_EBP + -0x40) = 0;
      *(undefined *)(unaff_EBP + -4) = 3;
      if (0xf < uVar10) {
        pcVar3 = *(char **)(unaff_EBP + -0x10c);
        pcStack_4 = (char *)(uVar10 + 1);
        pcVar11 = pcVar3;
        if (0xfff < pcStack_4) {
          pcVar11 = *(char **)(pcVar3 + -4);
          pcStack_4 = (char *)(uVar10 + 0x24);
          if ((char *)0x1f < pcVar3 + (-4 - (int)pcVar11)) {
                    /* WARNING: Subroutine does not return */
            pcStack_4 = (char *)0x92b802;
            FUN_017167a3();
          }
        }
        pcStack_8 = pcVar11;
        FUN_01674ea0();
      }
      *(undefined4 *)(unaff_EBP + -0xfc) = 0;
      *(undefined4 *)(unaff_EBP + -0xf8) = 0xf;
      *(undefined *)(unaff_EBP + -0x10c) = 0;
      pcStack_4 = (char *)0x92b5f7;
      FUN_0056cfd0();
      uVar10 = *(uint *)(unaff_EBP + -300);
      if (0xf < uVar10) {
        pcVar3 = *(char **)(unaff_EBP + -0x140);
        pcStack_4 = (char *)(uVar10 + 1);
        pcVar11 = pcVar3;
        if (0xfff < pcStack_4) {
          pcVar11 = *(char **)(pcVar3 + -4);
          pcStack_4 = (char *)(uVar10 + 0x24);
          if ((char *)0x1f < pcVar3 + (-4 - (int)pcVar11)) {
                    /* WARNING: Subroutine does not return */
            pcStack_4 = (char *)0x92b807;
            FUN_017167a3();
          }
        }
        pcStack_8 = pcVar11;
        FUN_01674ea0();
      }
      uVar10 = *(uint *)(unaff_EBP + -0x94);
      *(undefined4 *)(unaff_EBP + -0x130) = 0;
      *(undefined4 *)(unaff_EBP + -300) = 0xf;
      *(undefined *)(unaff_EBP + -0x140) = 0;
      *(undefined *)(unaff_EBP + -4) = 2;
      if (0xf < uVar10) {
        pcVar3 = *(char **)(unaff_EBP + -0xa8);
        pcStack_4 = (char *)(uVar10 + 1);
        pcVar11 = pcVar3;
        if (0xfff < pcStack_4) {
          pcVar11 = *(char **)(pcVar3 + -4);
          pcStack_4 = (char *)(uVar10 + 0x24);
          if ((char *)0x1f < pcVar3 + (-4 - (int)pcVar11)) {
                    /* WARNING: Subroutine does not return */
            pcStack_4 = &UNK_0092b80c;
            FUN_017167a3();
          }
        }
        pcStack_8 = pcVar11;
        FUN_01674ea0();
      }
      uVar10 = FUN_0092b6c1();
      return uVar10;
    }
    uVar18 = 1;
  }
  else {
    uVar18 = 0;
  }
  iVar13 = *(int *)(unaff_EBP + -0x20);
  pcStack_8 = (char *)0x92b4aa;
  pcStack_4 = (char *)iVar13;
  pcStack_8 = (char *)FUN_008f7870();
  pcStack_4 = (char *)0x1;
  FUN_008e9480();
  pcStack_4 = (char *)0x92b4c0;
  FUN_008eb110();
  *(undefined4 *)(iVar13 + 0x490) = uVar18;
  *(undefined *)(iVar13 + 0x4c5) = 1;
  pcStack_4 = (char *)0x92b4d5;
  FUN_0167ec40();
  pcStack_4 = (char *)0x92b4dd;
  FUN_005507b0();
  pcStack_4 = (char *)0x92b4e8;
  FUN_0056db40();
  pcStack_4 = (char *)0x92b4f3;
  uVar10 = FUN_005507b0();
  piVar14 = *(int **)(unaff_EBP + -0x18);
LAB_0092b4f6:
  if (piVar14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar14 + 1);
    uVar4 = *puVar1;
    uVar10 = *puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      pcStack_4 = (char *)0x92b50c;
      (**(code **)*piVar14)();
      LOCK();
      puVar1 = (uint *)(piVar14 + 2);
      uVar4 = *puVar1;
      uVar10 = *puVar1;
      *puVar1 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        pcStack_4 = (char *)0x92b51c;
        uVar10 = (**(code **)(*piVar14 + 4))();
      }
    }
  }
  piVar14 = *(int **)(unaff_EBP + 0xc);
  if (piVar14 != (int *)0x0) {
    LOCK();
    piVar2 = piVar14 + 2;
    iVar13 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar13 == 1) {
      pcStack_4 = (char *)0x92b530;
      uVar10 = (**(code **)(*piVar14 + 4))();
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return uVar10;
}



/* FUNCTION 16588 ; VA 0x0092b810 ; FUN_0092b810 */

uint FUN_0092b810(undefined4 param_1,int *param_2)

{
  uint *puVar1;
  int iVar2;
  undefined uVar3;
  char cVar4;
  undefined4 *puVar5;
  uint uVar6;
  byte ****ppppbVar7;
  undefined4 uVar8;
  byte *****pppppbVar9;
  int *piVar10;
  byte *pbVar11;
  uint uVar12;
  longlong lVar13;
  undefined8 uVar14;
  byte ****ppppbStack_160;
  byte ****ppppbStack_15c;
  byte ****ppppbStack_134;
  uint uStack_120;
  byte ****ppppbStack_100;
  uint uStack_ec;
  byte **appbStack_e4 [2];
  byte **appbStack_dc [2];
  byte **appbStack_d4 [4];
  byte ****appppbStack_c4 [4];
  undefined4 uStack_b4;
  uint uStack_b0;
  int *piStack_a8;
  int *piStack_a0;
  byte **appbStack_9c [3];
  byte ****appppbStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  undefined auStack_78 [4];
  int *piStack_74;
  undefined auStack_70 [4];
  int *piStack_6c;
  byte ****ppppbStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int iStack_54;
  uint uStack_50;
  undefined8 uStack_4c;
  uint uStack_44;
  int iStack_40;
  int *piStack_3c;
  byte ****ppppbStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  byte ****ppppbStack_1c;
  byte bStack_16;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8dcd;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffea8;
  uStack_44 = 0;
  ppppbStack_15c = (byte ****)&iStack_40;
  uStack_8 = 0;
  uStack_20 = 0;
  ppppbStack_160 = (byte ****)0x92b853;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  bStack_16 = iStack_40 != 0;
  uStack_8._0_1_ = 1;
  uVar6 = (uint)bStack_16;
  uVar12 = 0;
  do {
    iVar2 = iStack_40;
    uStack_4c = CONCAT44(uVar12,(undefined4)uStack_4c);
    if ((char)uVar6 == '\0') {
      if (piStack_3c != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_3c + 1);
        uVar12 = *puVar1;
        uVar6 = *puVar1;
        *puVar1 = uVar12 - 1;
        UNLOCK();
        if (uVar12 - 1 == 0) {
          ppppbStack_15c = (byte ****)0x92bffe;
          (**(code **)*piStack_3c)();
          LOCK();
          puVar1 = (uint *)(piStack_3c + 2);
          uVar12 = *puVar1;
          uVar6 = *puVar1;
          *puVar1 = uVar12 - 1;
          UNLOCK();
          if (uVar12 - 1 == 0) {
            ppppbStack_15c = (byte ****)0x92c00e;
            uVar6 = (**(code **)(*piStack_3c + 4))();
          }
        }
      }
      if (param_2 != (int *)0x0) {
        LOCK();
        piVar10 = param_2 + 2;
        iVar2 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          ppppbStack_15c = (byte ****)0x92c022;
          uVar6 = (**(code **)(*param_2 + 4))();
        }
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
    uStack_b4 = 0;
    uStack_b0 = 0xf;
    appppbStack_c4[0] = (byte ****)((uint)appppbStack_c4[0] & 0xffffff00);
    ppppbStack_15c = (byte ****)0x0;
    ppppbStack_160 = (byte ****)&DAT_018bc9b8;
    uStack_8._0_1_ = 3;
    iStack_54 = 0;
    uStack_50 = 0xf;
    ppppbStack_64 = (byte ****)((uint)ppppbStack_64 & 0xffffff00);
    FUN_005542c0();
    uStack_8._0_1_ = 4;
    if ((*(int *)(iVar2 + 0xf0) != *(uint *)(iVar2 + 0xf8) + 0xaaf55c4e) ||
       (*(int *)(iVar2 + 0xf4) !=
        *(int *)(iVar2 + 0xfc) - (uint)(*(uint *)(iVar2 + 0xf8) < 0x550aa3b2))) {
      ppppbStack_15c = (byte ****)&DAT_018bc9b8;
      ppppbStack_160 = (byte ****)0x193180c;
      FUN_01675310();
    }
    ppppbStack_15c = (byte ****)&ppppbStack_64;
    ppppbStack_160 = *(byte *****)(iVar2 + 0xf4);
    FUN_00f54b90(appppbStack_90,*(undefined4 *)(iVar2 + 0xf0));
    ppppbStack_15c = (byte ****)0x0;
    ppppbStack_160 = (byte ****)&DAT_00000007;
    uStack_8._0_1_ = 5;
    FUN_014cc090();
    uStack_8._0_1_ = 7;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if (0xf < uStack_7c) {
      ppppbStack_15c = (byte ****)(uStack_7c + 1);
      pppppbVar9 = (byte *****)appppbStack_90[0];
      if (0xfff < ppppbStack_15c) {
        pppppbVar9 = (byte *****)appppbStack_90[0][-1];
        ppppbStack_15c = (byte ****)(uStack_7c + 0x24);
        if ((undefined *)0x1f < (undefined *)((int)appppbStack_90[0] + (-4 - (int)pppppbVar9))) {
                    /* WARNING: Subroutine does not return */
          ppppbStack_15c = (byte ****)0x92c038;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      ppppbStack_160 = (byte ****)pppppbVar9;
      FUN_01674ea0();
    }
    uStack_80 = 0;
    uStack_7c = 0xf;
    appppbStack_90[0] = (byte ****)((uint)appppbStack_90[0] & 0xffffff00);
    uStack_8._0_1_ = 8;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_50) {
      ppppbStack_15c = (byte ****)(uStack_50 + 1);
      ppppbVar7 = ppppbStack_64;
      if (0xfff < ppppbStack_15c) {
        ppppbVar7 = (byte ****)ppppbStack_64[-1];
        ppppbStack_15c = (byte ****)(uStack_50 + 0x24);
        if (0x1f < (uint)((int)ppppbStack_64 + (-4 - (int)ppppbVar7))) {
                    /* WARNING: Subroutine does not return */
          ppppbStack_15c = (byte ****)0x92c03d;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      ppppbStack_160 = ppppbVar7;
      FUN_01674ea0();
    }
    ppppbStack_15c = (byte ****)0x0;
    ppppbStack_160 = (byte ****)0x0;
    iStack_54 = 0;
    uStack_50 = 0xf;
    ppppbStack_64 = (byte ****)((uint)ppppbStack_64 & 0xffffff00);
    FUN_014cd0a0();
    iStack_28 = 0;
    uStack_24 = 0xf;
    ppppbStack_38 = (byte ****)((uint)ppppbStack_38 & 0xffffff00);
    ppppbStack_15c = (byte ****)appppbStack_c4;
    uStack_8._0_1_ = 9;
    ppppbStack_160 = (byte ****)appbStack_9c;
    FUN_016819e0();
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    ppppbStack_15c = (byte ****)0x92ba05;
    cVar4 = FUN_016816d0();
    if (cVar4 != '\0') {
      ppppbStack_160 = (byte ****)appbStack_d4;
      ppppbStack_15c = (byte ****)0x1931e3c;
      FUN_016756b0();
      ppppbStack_160 = (byte ****)appbStack_d4;
      ppppbStack_15c = (byte ****)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8();
    }
    if (DAT_01ee420a != '\0') {
      ppppbStack_15c = (byte ****)0x0;
      ppppbStack_160 = (byte ****)0x1931e50;
      FUN_016774b0();
    }
    ppppbStack_15c = (byte ****)PTR_s_ChatFilter_01d6428c;
    ppppbStack_160 = (byte ****)appbStack_dc;
    FUN_0167eea0();
    ppppbStack_15c = (byte ****)PTR_s_ChatFilter_01d6428c;
    ppppbStack_160 = (byte ****)appbStack_e4;
    FUN_0167eea0();
    uStack_80 = 0;
    uStack_7c = 0xf;
    appppbStack_90[0] = (byte ****)((uint)appppbStack_90[0] & 0xffffff00);
    ppppbStack_15c = (byte ****)appppbStack_90;
    uStack_8._0_1_ = 0xb;
    ppppbStack_160 = (byte ****)&ppppbStack_64;
    FUN_01681330();
    uStack_44 = uStack_44 | 1;
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    if (0xf < uStack_7c) {
      ppppbStack_15c = (byte ****)(uStack_7c + 1);
      pppppbVar9 = (byte *****)appppbStack_90[0];
      if (0xfff < ppppbStack_15c) {
        pppppbVar9 = (byte *****)appppbStack_90[0][-1];
        ppppbStack_15c = (byte ****)(uStack_7c + 0x24);
        if ((undefined *)0x1f < (undefined *)((int)appppbStack_90[0] + (-4 - (int)pppppbVar9))) {
                    /* WARNING: Subroutine does not return */
          ppppbStack_15c = (byte ****)0x92c067;
          FUN_017167a3();
        }
      }
      ppppbStack_160 = (byte ****)pppppbVar9;
      FUN_01674ea0();
    }
    if (0xf < uStack_24) {
      ppppbStack_15c = (byte ****)(uStack_24 + 1);
      ppppbVar7 = ppppbStack_38;
      if (0xfff < ppppbStack_15c) {
        ppppbVar7 = (byte ****)ppppbStack_38[-1];
        ppppbStack_15c = (byte ****)(uStack_24 + 0x24);
        if (0x1f < (uint)((int)ppppbStack_38 + (-4 - (int)ppppbVar7))) {
                    /* WARNING: Subroutine does not return */
          ppppbStack_15c = (byte ****)0x92c06c;
          FUN_017167a3();
        }
      }
      ppppbStack_160 = ppppbVar7;
      FUN_01674ea0();
    }
    ppppbStack_38 = ppppbStack_64;
    uStack_34 = uStack_60;
    uStack_30 = uStack_5c;
    uStack_2c = uStack_58;
    iStack_28 = iStack_54;
    uStack_24 = uStack_50;
    if (DAT_01ee420a != '\0') {
      ppppbStack_15c = (byte ****)&ppppbStack_38;
      ppppbStack_160 = (byte ****)0x1931e74;
      FUN_01677760();
    }
    ppppbStack_15c = (byte ****)0x1;
    uStack_8._0_1_ = 0xc;
    ppppbStack_160 = (byte ****)0x92bb32;
    piStack_a0 = (int *)FUN_016de181();
    uStack_8._0_1_ = 0xe;
    ppppbStack_15c = (byte ****)0x92bb49;
    piStack_6c = piStack_a0;
    (**(code **)(*piStack_a0 + 4))();
    pppppbVar9 = &ppppbStack_38;
    if (0xf < uStack_24) {
      pppppbVar9 = (byte *****)ppppbStack_38;
    }
    pbVar11 = &DAT_01931e9c;
    uStack_8._0_1_ = 0xf;
    ppppbStack_1c = (byte ****)((int)pppppbVar9 + iStack_28);
    pppppbVar9 = &ppppbStack_38;
    if (0xf < uStack_24) {
      pppppbVar9 = (byte *****)ppppbStack_38;
    }
    for (; piVar10 = piStack_a0, pbVar11 != &DAT_01931ea5; pbVar11 = pbVar11 + 1) {
      if (pppppbVar9 == (byte *****)ppppbStack_1c) goto LAB_0092bbda;
      ppppbStack_15c = (byte ****)auStack_70;
      ppppbStack_160 = (byte ****)(uint)*(byte *)pppppbVar9;
      cStack_15 = FUN_00564a80();
      ppppbStack_160 = (byte ****)(uint)*pbVar11;
      ppppbStack_15c = (byte ****)auStack_70;
      cVar4 = FUN_00564a80();
      piVar10 = piStack_a0;
      if (cVar4 != cStack_15) {
        uStack_8._0_1_ = 0x10;
        if (piStack_a0 != (int *)0x0) {
          ppppbStack_15c = (byte ****)0x92bbbb;
          puVar5 = (undefined4 *)(**(code **)(*piStack_a0 + 8))();
          if (puVar5 != (undefined4 *)0x0) {
            ppppbStack_15c = (byte ****)0x1;
            ppppbStack_160 = (byte ****)0x92bbc9;
            (**(code **)*puVar5)();
          }
        }
        cStack_15 = '\0';
        goto LAB_0092bc0f;
      }
      pppppbVar9 = (byte *****)((int)pppppbVar9 + 1);
    }
    if (pppppbVar9 == (byte *****)ppppbStack_1c) {
LAB_0092bbda:
      cStack_15 = '\x01';
      if (pbVar11 != &DAT_01931ea5) goto LAB_0092bbe6;
    }
    else {
LAB_0092bbe6:
      cStack_15 = '\0';
    }
    uStack_8._0_1_ = 0x11;
    if (piStack_a0 != (int *)0x0) {
      ppppbStack_15c = (byte ****)0x92bc01;
      puVar5 = (undefined4 *)(**(code **)(*piStack_a0 + 8))();
      if (puVar5 != (undefined4 *)0x0) {
        ppppbStack_15c = (byte ****)0x1;
        ppppbStack_160 = (byte ****)0x92bc0f;
        (**(code **)*puVar5)();
      }
    }
LAB_0092bc0f:
    uStack_8._0_1_ = 0x12;
    if (piVar10 != (int *)0x0) {
      ppppbStack_15c = (byte ****)0x92bc20;
      puVar5 = (undefined4 *)(**(code **)(*piVar10 + 8))();
      if (puVar5 != (undefined4 *)0x0) {
        ppppbStack_15c = (byte ****)0x1;
        ppppbStack_160 = (byte ****)0x92bc2e;
        (**(code **)*puVar5)();
      }
    }
    if (cStack_15 == '\0') {
      ppppbStack_15c = (byte ****)0x1;
      uStack_8._0_1_ = 0x13;
      ppppbStack_160 = (byte ****)0x92bc4a;
      piStack_a8 = (int *)FUN_016de181();
      uStack_8._0_1_ = 0x15;
      ppppbStack_15c = (byte ****)0x92bc61;
      piStack_74 = piStack_a8;
      (**(code **)(*piStack_a8 + 4))();
      pppppbVar9 = &ppppbStack_38;
      if (0xf < uStack_24) {
        pppppbVar9 = (byte *****)ppppbStack_38;
      }
      pbVar11 = &DAT_018d46dc;
      uStack_8._0_1_ = 0x16;
      ppppbStack_1c = (byte ****)((int)pppppbVar9 + iStack_28);
      pppppbVar9 = &ppppbStack_38;
      if (0xf < uStack_24) {
        pppppbVar9 = (byte *****)ppppbStack_38;
      }
      for (; piVar10 = piStack_a8, pbVar11 != &DAT_018d46e5; pbVar11 = pbVar11 + 1) {
        if (pppppbVar9 == (byte *****)ppppbStack_1c) goto LAB_0092bcf2;
        ppppbStack_15c = (byte ****)auStack_78;
        ppppbStack_160 = (byte ****)(uint)*(byte *)pppppbVar9;
        cStack_15 = FUN_00564a80();
        ppppbStack_160 = (byte ****)(uint)*pbVar11;
        ppppbStack_15c = (byte ****)auStack_78;
        cVar4 = FUN_00564a80();
        piVar10 = piStack_a8;
        if (cVar4 != cStack_15) {
          uStack_8._0_1_ = 0x17;
          if (piStack_a8 != (int *)0x0) {
            ppppbStack_15c = (byte ****)0x92bcd3;
            puVar5 = (undefined4 *)(**(code **)(*piStack_a8 + 8))();
            if (puVar5 != (undefined4 *)0x0) {
              ppppbStack_15c = (byte ****)0x1;
              ppppbStack_160 = (byte ****)0x92bce1;
              (**(code **)*puVar5)();
            }
          }
          cStack_15 = '\0';
          goto LAB_0092bd27;
        }
        pppppbVar9 = (byte *****)((int)pppppbVar9 + 1);
      }
      if (pppppbVar9 == (byte *****)ppppbStack_1c) {
LAB_0092bcf2:
        cStack_15 = '\x01';
        if (pbVar11 != &DAT_018d46e5) goto LAB_0092bcfe;
      }
      else {
LAB_0092bcfe:
        cStack_15 = '\0';
      }
      uStack_8._0_1_ = 0x18;
      if (piStack_a8 != (int *)0x0) {
        ppppbStack_15c = (byte ****)0x92bd19;
        puVar5 = (undefined4 *)(**(code **)(*piStack_a8 + 8))();
        if (puVar5 != (undefined4 *)0x0) {
          ppppbStack_15c = (byte ****)0x1;
          ppppbStack_160 = (byte ****)0x92bd27;
          (**(code **)*puVar5)();
        }
      }
LAB_0092bd27:
      uStack_8._0_1_ = 0x19;
      if (piVar10 != (int *)0x0) {
        ppppbStack_15c = (byte ****)0x92bd38;
        puVar5 = (undefined4 *)(**(code **)(*piVar10 + 8))();
        if (puVar5 != (undefined4 *)0x0) {
          ppppbStack_15c = (byte ****)0x1;
          ppppbStack_160 = (byte ****)0x92bd46;
          (**(code **)*puVar5)();
        }
      }
      uStack_8._0_1_ = 10;
      if (cStack_15 != '\0') {
        uVar8 = 1;
        goto LAB_0092bd55;
      }
    }
    else {
      uVar8 = 0;
LAB_0092bd55:
      iVar2 = iStack_40;
      uStack_8._0_1_ = 10;
      ppppbStack_15c = (byte ****)iStack_40;
      ppppbStack_160 = (byte ****)0x92bd5e;
      ppppbStack_160 = (byte ****)FUN_008f7870();
      ppppbStack_15c = (byte ****)0x1;
      FUN_008e9480();
      ppppbStack_15c = (byte ****)0x92bd74;
      FUN_008eb110();
      *(undefined4 *)(iVar2 + 0x490) = uVar8;
      *(undefined *)(iVar2 + 0x4c5) = 1;
      bStack_16 = 0;
    }
    ppppbStack_15c = (byte ****)0x92bd90;
    FUN_0167ec40();
    uStack_8._0_1_ = 8;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_24) {
      ppppbStack_15c = (byte ****)(uStack_24 + 1);
      pppppbVar9 = (byte *****)ppppbStack_38;
      if (0xfff < ppppbStack_15c) {
        pppppbVar9 = (byte *****)ppppbStack_38[-1];
        ppppbStack_15c = (byte ****)(uStack_24 + 0x24);
        if ((byte *)0x1f < (byte *)((int)ppppbStack_38 + (-4 - (int)pppppbVar9))) {
                    /* WARNING: Subroutine does not return */
          ppppbStack_15c = (byte ****)0x92c071;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      ppppbStack_160 = (byte ****)pppppbVar9;
      FUN_01674ea0();
    }
    iStack_28 = 0;
    uStack_24 = 0xf;
    ppppbStack_38 = (byte ****)((uint)ppppbStack_38 & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (0xf < uStack_ec) {
      ppppbStack_15c = (byte ****)(uStack_ec + 1);
      pppppbVar9 = (byte *****)ppppbStack_100;
      if (0xfff < ppppbStack_15c) {
        pppppbVar9 = (byte *****)ppppbStack_100[-1];
        ppppbStack_15c = (byte ****)(uStack_ec + 0x24);
        if ((byte *)0x1f < (byte *)((int)ppppbStack_100 + (-4 - (int)pppppbVar9))) {
                    /* WARNING: Subroutine does not return */
          ppppbStack_15c = (byte ****)0x92c076;
          FUN_017167a3();
        }
      }
      ppppbStack_160 = (byte ****)pppppbVar9;
      FUN_01674ea0();
    }
    uStack_ec = 0xf;
    ppppbStack_100 = (byte ****)((uint)ppppbStack_100 & 0xffffff00);
    ppppbStack_15c = (byte ****)0x92be3e;
    FUN_0056cfd0();
    if (0xf < uStack_120) {
      ppppbStack_15c = (byte ****)(uStack_120 + 1);
      pppppbVar9 = (byte *****)ppppbStack_134;
      if (0xfff < ppppbStack_15c) {
        pppppbVar9 = (byte *****)ppppbStack_134[-1];
        ppppbStack_15c = (byte ****)(uStack_120 + 0x24);
        if ((byte *)0x1f < (byte *)((int)ppppbStack_134 + (-4 - (int)pppppbVar9))) {
                    /* WARNING: Subroutine does not return */
          ppppbStack_15c = (byte ****)0x92c07b;
          FUN_017167a3();
        }
      }
      ppppbStack_160 = (byte ****)pppppbVar9;
      FUN_01674ea0();
    }
    uStack_120 = 0xf;
    ppppbStack_134 = (byte ****)((uint)ppppbStack_134 & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_b0) {
      ppppbStack_15c = (byte ****)(uStack_b0 + 1);
      pppppbVar9 = (byte *****)appppbStack_c4[0];
      if (0xfff < ppppbStack_15c) {
        pppppbVar9 = (byte *****)appppbStack_c4[0][-1];
        ppppbStack_15c = (byte ****)(uStack_b0 + 0x24);
        if ((byte *)0x1f < (byte *)((int)appppbStack_c4[0] + (-4 - (int)pppppbVar9))) {
                    /* WARNING: Subroutine does not return */
          ppppbStack_15c = (byte ****)&UNK_0092c080;
          FUN_017167a3();
        }
      }
      ppppbStack_160 = (byte ****)pppppbVar9;
      FUN_01674ea0();
    }
    uVar6 = (uint)bStack_16;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    uVar12 = uStack_20;
    if (bStack_16 != 0) {
      ppppbStack_15c = (byte ****)0x0;
      ppppbStack_160 = (byte ****)0x3e8;
      lVar13 = FUN_016f3900((longlong)(1000 << ((byte)((ulonglong)uStack_4c >> 0x20) & 0x1f)) * 1000
                           );
      if ((lVar13 < 0x100000000) && (lVar13 < 0)) {
        uStack_4c = 0;
        lVar13 = 0;
      }
      ppppbStack_1c = (byte ****)((ulonglong)lVar13 >> 0x20);
      if (DAT_01ea94c0 == (code *)0x0) {
        uVar8 = GetModuleHandleA("KERNEL32.DLL","GetTickCount64");
        DAT_01ea94c0 = (code *)GetProcAddress(uVar8);
        if (DAT_01ea94c0 == (code *)0x0) {
          DAT_01ea94c0 = FUN_005efd30;
        }
      }
      uVar14 = (*DAT_01ea94c0)();
      FUN_005f0a90(&ppppbStack_160,FUN_005f1e70,uVar14,(int)lVar13,ppppbStack_1c);
      FUN_01689e80(0xffffffff);
      uVar6 = (uint)bStack_16;
      uVar12 = uStack_20;
      if (uStack_20 < DAT_01d640a0) {
        uVar12 = uStack_20 + 1;
        uStack_20 = uVar12;
      }
    }
  } while( true );
}



/* FUNCTION 16589 ; VA 0x0092bf57 ; Catch@0092bf57 */

undefined4 Catch_0092bf57(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0xc4) + 4))();
  FUN_0086f2f0(3,"loadChatInfoInternal had an error: %s",uVar1);
  FUN_0086f2f0(1,"loadChatInfoInternal retrying...");
  return 0x92bed1;
}



/* FUNCTION 16590 ; VA 0x0092c090 ; FUN_0092c090 */

void __fastcall FUN_0092c090(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 auStack_7c [5];
  undefined4 uStack_68;
  undefined *puStack_64;
  undefined *puStack_60;
  char *pcStack_5c;
  undefined auStack_4c [24];
  undefined auStack_34 [12];
  undefined auStack_28 [4];
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8de8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    ExceptionList = &pvStack_10;
    if ((iVar4 != 0) && (iVar3 = iVar4, ExceptionList = &pvStack_10, *(int *)(iVar4 + 0x34) != 0)) {
      pcStack_5c = (char *)0x92c0cb;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_005c8ac0();
    }
    if (iVar3 != 0) {
      iVar4 = *(int *)(iVar3 + 0xc);
      pcStack_5c = (char *)0x92c0e1;
      iVar3 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        pcStack_5c = (char *)0x92c107;
        iVar4 = FUN_005cf750();
        if (iVar4 != 0) {
          pcStack_5c = *(char **)(param_1 + 0xf4);
          puStack_60 = *(undefined **)(param_1 + 0xf0);
          if (((int)pcStack_5c < 1) && ((int)pcStack_5c < 0)) {
            puStack_60 = (undefined *)0x0;
            pcStack_5c = (char *)0x0;
            puStack_64 = (undefined *)0x92c13e;
            FUN_0092c330();
            ExceptionList = pvStack_10;
            return;
          }
          puStack_64 = auStack_4c;
          uStack_68 = 0x92c15c;
          FUN_0097f4b0();
          iVar4 = *(int *)(param_1 + 0x34);
          uStack_8 = 0;
          iVar3 = param_1;
          if ((iVar4 != 0) && (iVar3 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
            pcStack_5c = (char *)0x92c176;
            iVar3 = FUN_005c8ac0();
          }
          if (iVar3 != 0) {
            iVar4 = *(int *)(iVar3 + 0xc);
            pcStack_5c = (char *)0x92c18c;
            iVar3 = FUN_008a8c30();
            if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
                (uint)*(ushort *)(iVar3 + 0x1da)) {
              pcStack_5c = (char *)0x92c1b2;
              iStack_1c = FUN_00916350();
              if (iStack_1c != 0) {
                pcStack_5c = (char *)0x3;
                puStack_18 = auStack_7c;
                FUN_0060e0c0(&uStack_24,param_1);
                piVar1 = piStack_20;
                if (piStack_20 != (int *)0x0) {
                  LOCK();
                  piStack_20[2] = piStack_20[2] + 1;
                  UNLOCK();
                }
                uStack_14 = uStack_24;
                if (piStack_20 != (int *)0x0) {
                  piVar5 = piStack_20 + 2;
                  LOCK();
                  *piVar5 = *piVar5 + 1;
                  UNLOCK();
                  LOCK();
                  *piVar5 = *piVar5 + 1;
                  UNLOCK();
                  LOCK();
                  *piVar5 = *piVar5 + 1;
                  UNLOCK();
                  LOCK();
                  iVar4 = *piVar5;
                  *piVar5 = iVar4 + -1;
                  UNLOCK();
                  if (iVar4 + -1 == 0) {
                    (**(code **)(*piStack_20 + 4))();
                  }
                  LOCK();
                  iVar4 = piVar1[2] + -1;
                  piVar1[2] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar1 + 4))();
                  }
                  LOCK();
                  iVar4 = piVar1[2] + -1;
                  piVar1[2] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar1 + 4))();
                  }
                  piVar5 = piVar1 + 2;
                  if (piVar1 != (int *)0x0) {
                    LOCK();
                    *piVar5 = *piVar5 + 1;
                    UNLOCK();
                    LOCK();
                    iVar4 = *piVar5;
                    *piVar5 = iVar4 + -1;
                    UNLOCK();
                    if (iVar4 + -1 == 0) {
                      (**(code **)(*piVar1 + 4))();
                    }
                  }
                  if (piStack_20 != (int *)0x0) {
                    LOCK();
                    iVar4 = piStack_20[2] + -1;
                    piStack_20[2] = iVar4;
                    UNLOCK();
                    if (iVar4 == 0) {
                      (**(code **)(*piStack_20 + 4))();
                    }
                  }
                  if (piVar1 != (int *)0x0) {
                    LOCK();
                    piVar1[2] = piVar1[2] + 1;
                    UNLOCK();
                  }
                }
                uVar2 = uStack_14;
                piVar5 = piVar1 + 2;
                *puStack_18 = 0;
                if (piVar1 != (int *)0x0) {
                  LOCK();
                  *piVar5 = *piVar5 + 1;
                  UNLOCK();
                }
                FUN_00915710(FUN_0091ce60,uVar2,piVar1);
                if (piVar1 != (int *)0x0) {
                  LOCK();
                  iVar4 = *piVar5;
                  *piVar5 = iVar4 + -1;
                  UNLOCK();
                  if (iVar4 + -1 == 0) {
                    (**(code **)(*piVar1 + 4))();
                  }
                  LOCK();
                  iVar4 = *piVar5;
                  *piVar5 = *piVar5 + -1;
                  UNLOCK();
                  if (iVar4 == 1) {
                    (**(code **)(*piVar1 + 4))();
                  }
                }
                FUN_00e517f0(auStack_4c,0,7);
                pcStack_5c = (char *)0x92c2df;
                FUN_005507b0();
                ExceptionList = pvStack_10;
                return;
              }
            }
          }
          pcStack_5c = "Can\'t find LuaWebService, something is very wrong";
          puStack_60 = (undefined *)0x92c318;
          FUN_00550130();
          pcStack_5c = "";
          puStack_60 = auStack_28;
                    /* WARNING: Subroutine does not return */
          puStack_64 = &UNK_0092c326;
          FUN_0170c2a8();
        }
      }
    }
  }
  pcStack_5c = "Cannot load data from Player that is not in DataModel";
  puStack_60 = (undefined *)0x92c2fd;
  FUN_00550130();
  pcStack_5c = "";
  puStack_60 = auStack_34;
                    /* WARNING: Subroutine does not return */
  puStack_64 = (undefined *)0x92c30b;
  FUN_0170c2a8();
}



/* FUNCTION 16591 ; VA 0x0092c330 ; FUN_0092c330 */

int __thiscall FUN_0092c330(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  int iStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c8e17;
  pvStack_10 = ExceptionList;
  piStack_28 = (int *)0x10;
  iStack_8 = 0;
  uStack_2c = 0x92c35d;
  ExceptionList = &pvStack_10;
  iVar7 = FUN_01674e20();
  iStack_8._0_1_ = 1;
  if (iVar7 == 0) {
    uStack_2c = 0;
  }
  else {
    uVar2 = *(undefined4 *)(param_1 + 0xa4);
    uStack_2c = 0x92c377;
    piStack_28 = (int *)param_1;
    uStack_2c = FUN_0064e810();
    uStack_30 = param_2;
    uStack_34 = 0x92c387;
    piStack_28 = (int *)uVar2;
    uStack_2c = FUN_00f842b0();
  }
  piStack_28 = param_3;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uStack_30 = 0x92c3a9;
  FUN_00913e20();
  *(undefined4 *)(param_1 + 0x35c) = 0;
  piVar3 = *(int **)(param_1 + 0x360);
  *(undefined4 *)(param_1 + 0x360) = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar7 = piVar3[1] + -1;
    piVar3[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      piStack_28 = (int *)0x92c3d5;
      (**(code **)*piVar3)();
      LOCK();
      iVar7 = piVar3[2] + -1;
      piVar3[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        piStack_28 = (int *)0x92c3e6;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piStack_28 = (int *)&DAT_0211d900;
  *(undefined *)(param_1 + 0xa9) = 1;
  uStack_2c = 0x92c3f9;
  FUN_008a4940();
  puVar4 = *(undefined4 **)(param_1 + 0x364);
  for (puVar5 = (undefined4 *)*puVar4; puVar5 != puVar4; puVar5 = (undefined4 *)*puVar5) {
    uVar6 = puVar5[2];
    if (uVar6 != 0) {
      if ((uVar6 & 1) == 0) {
        (**(code **)(uVar6 & 0xfffffffe))(puVar5 + 4,&iStack_3c,0);
      }
      else {
        iStack_3c = puVar5[4];
        uStack_38 = puVar5[5];
        uStack_34 = puVar5[6];
        uStack_30 = puVar5[7];
        uStack_2c = puVar5[8];
        piStack_28 = (int *)puVar5[9];
      }
    }
    FUN_0091cdd0();
  }
  piStack_28 = (int *)0x92c46c;
  iVar7 = FUN_0091ecd0();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar1 = *piVar3;
    iVar7 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      piStack_28 = (int *)0x92c485;
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        piStack_28 = (int *)0x92c494;
        iVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 16592 ; VA 0x0092c4b0 ; FUN_0092c4b0 */

undefined4 __thiscall FUN_0092c4b0(int param_1,undefined4 param_2)

{
  char cVar1;
  char *pcVar2;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,1);
  if (cVar1 == '\0') {
    pcVar2 = "LocalScripts cannot use LoadInstance";
  }
  else {
    if (*(char *)(param_1 + 0xa9) != '\0') {
      FUN_00f84910(param_2,&stack0x00000008);
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
    pcVar2 = "Data for player not yet loaded, wait for DataReady";
  }
  FUN_00550130(pcVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16593 ; VA 0x0092c540 ; FUN_0092c540 */

float10 __fastcall FUN_0092c540(int param_1)

{
  char cVar1;
  float10 fVar2;
  char *pcVar3;
  undefined auStack_1c [4];
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,1);
  if (cVar1 == '\0') {
    pcVar3 = "LocalScripts cannot use LoadNumber";
  }
  else {
    if (*(char *)(param_1 + 0xa9) != '\0') {
      fVar2 = (float10)FUN_00f849f0(&stack0x00000004);
      dStack_18 = (double)fVar2;
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return (float10)dStack_18;
    }
    pcVar3 = "Data for player not yet loaded, wait for DataReady";
  }
  FUN_00550130(pcVar3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16594 ; VA 0x0092c5d0 ; FUN_0092c5d0 */

undefined4 __thiscall FUN_0092c5d0(int param_1,undefined4 param_2)

{
  char cVar1;
  char *pcVar2;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    pcVar2 = "LocalScripts cannot use LoadString";
  }
  else {
    if (*(char *)(param_1 + 0xa9) != '\0') {
      FUN_00f84b50(param_2,&stack0x00000008);
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
    pcVar2 = "Data for player not yet loaded, wait for DataReady";
  }
  FUN_00550130(pcVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16595 ; VA 0x0092c660 ; FUN_0092c660 */

void FUN_0092c660(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00935a60();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16596 ; VA 0x0092c6a0 ; FUN_0092c6a0 */

void FUN_0092c6a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935b10();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16597 ; VA 0x0092c6e0 ; FUN_0092c6e0 */

void FUN_0092c6e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935ba0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16598 ; VA 0x0092c720 ; FUN_0092c720 */

void FUN_0092c720(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935c30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16599 ; VA 0x0092c760 ; FUN_0092c760 */

void FUN_0092c760(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935cc0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16600 ; VA 0x0092c7a0 ; FUN_0092c7a0 */

void FUN_0092c7a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935d50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16601 ; VA 0x0092c7e0 ; FUN_0092c7e0 */

void FUN_0092c7e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935de0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16602 ; VA 0x0092c820 ; FUN_0092c820 */

void FUN_0092c820(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935e70();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16603 ; VA 0x0092c860 ; FUN_0092c860 */

void __thiscall FUN_0092c860(int param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  uint in_stack_00000018;
  undefined auStack_48 [24];
  undefined auStack_30 [12];
  undefined auStack_24 [4];
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c8e61;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  iStack_8 = 0;
  if (*(char *)(param_1 + 0x4cb) != '\0') {
    if (0xf < in_stack_00000018) {
      uVar7 = in_stack_00000018 + 1;
      iVar6 = param_2;
      if (0xfff < uVar7) {
        iVar6 = *(int *)(param_2 + -4);
        uVar7 = in_stack_00000018 + 0x24;
        if (0x1f < (param_2 - iVar6) - 4U) {
          ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      ExceptionList = &pvStack_10;
      FUN_01674ea0(iVar6,uVar7);
    }
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  iStack_18 = FUN_0064e810(param_1);
  if ((iStack_18 != 0) && (iVar6 = *(int *)(param_1 + 0x34), iStack_18 == iVar6)) {
    if ((DAT_01d64224 != '\0') && (*(char *)(param_1 + 0x26b) == '\0')) {
      iVar3 = param_1;
      if ((iVar6 != 0) && (iVar3 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
        iVar3 = FUN_005c8ac0();
      }
      if ((iVar3 != 0) &&
         (iVar6 = *(int *)(iVar3 + 0xc), iVar3 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
        uVar4 = FUN_00560d40();
        piStack_14 = (int *)FUN_008aa140(uVar4);
        if (*piStack_14 == 0) {
          uVar4 = FUN_00995770();
          piVar5 = (int *)FUN_008a9ba0(&uStack_20,uVar4);
          iVar6 = *piVar5;
          iVar3 = piVar5[1];
          *piVar5 = 0;
          piVar5[1] = 0;
          *piStack_14 = iVar6;
          piVar5 = (int *)piStack_14[1];
          piStack_14[1] = iVar3;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar6 = piVar5[1] + -1;
            piVar5[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              iVar6 = piVar5[2] + -1;
              piVar5[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          piVar5 = piStack_1c;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar6 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piStack_1c)();
              LOCK();
              piVar1 = piVar5 + 2;
              iVar6 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar6 == 1) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
        }
        if ((*piStack_14 != 0) && (cVar2 = FUN_00585a40(), cVar2 == '\0')) {
          if (*(int *)(iStack_18 + 0xf4) == param_1) {
            uVar4 = FUN_01530500(auStack_48);
            iStack_8._0_1_ = 1;
            uVar4 = FUN_00558d90(auStack_30,"LuaKicksCounterAll,LuaKicksCounter_",uVar4);
            iStack_8._0_1_ = 2;
            FUN_00878480(uVar4,0);
            FUN_005507b0();
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_005507b0();
          }
          else {
            piVar5 = (int *)(param_1 + 0x1fc);
            iStack_8._0_1_ = 3;
            uStack_20 = 0;
            piStack_1c = (int *)&DAT_0000000f;
            auStack_30[0] = 0;
            piStack_14 = (int *)0x1;
            FUN_0058a190(*(int *)(param_1 + 0x20c) + 0x23);
            FUN_00554150("LuaKicksCounterAll,LuaKicksCounter_",0x23);
            if (0xf < *(uint *)(param_1 + 0x210)) {
              piVar5 = (int *)*piVar5;
            }
            FUN_00554150(piVar5,*(undefined4 *)(param_1 + 0x20c));
            FUN_00878480(auStack_30,0);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_005507b0();
          }
        }
      }
      *(undefined *)(param_1 + 0x26b) = 1;
    }
    FUN_00983cb0(param_1,&param_2);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  FUN_00550130("Player:Kick() can only be called on a Player under Players");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c17198);
}



/* FUNCTION 16604 ; VA 0x0092c8da ; FUN_0092c8da */

void FUN_0092c8da(void)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined4 *puVar9;
  int unaff_EBP;
  int unaff_EDI;
  
  iVar5 = FUN_0064e810();
  *(int *)(unaff_EBP + -0x14) = iVar5;
  if ((iVar5 != 0) && (iVar6 = *(int *)(unaff_EDI + 0x34), iVar5 == iVar6)) {
    if ((DAT_01d64224 != '\0') && (*(char *)(unaff_EDI + 0x26b) == '\0')) {
      iVar5 = unaff_EDI;
      if ((iVar6 != 0) && (iVar5 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
        iVar5 = FUN_005c8ac0();
      }
      if ((iVar5 != 0) &&
         (iVar5 = *(int *)(iVar5 + 0xc), iVar6 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
         (uint)*(ushort *)(iVar6 + 0x1da))) {
        FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
        uVar7 = FUN_00560d40();
        piVar8 = (int *)FUN_008aa140(uVar7);
        *(int **)(unaff_EBP + -0x10) = piVar8;
        if (*piVar8 == 0) {
          uVar7 = FUN_00995770();
          puVar9 = (undefined4 *)FUN_008a9ba0(unaff_EBP + -0x1c,uVar7);
          puVar2 = *(undefined4 **)(unaff_EBP + -0x10);
          uVar7 = *puVar9;
          uVar3 = puVar9[1];
          *puVar9 = 0;
          puVar9[1] = 0;
          *puVar2 = uVar7;
          piVar8 = (int *)puVar2[1];
          puVar2[1] = uVar3;
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar5 = piVar8[1] + -1;
            piVar8[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piVar8)();
              LOCK();
              iVar5 = piVar8[2] + -1;
              piVar8[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          piVar8 = *(int **)(unaff_EBP + -0x18);
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar5 = piVar8[1] + -1;
            piVar8[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piVar8)();
              LOCK();
              piVar1 = piVar8 + 2;
              iVar5 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar5 == 1) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          piVar8 = *(int **)(unaff_EBP + -0x10);
        }
        if (*piVar8 != 0) {
          cVar4 = FUN_00585a40();
          if (cVar4 == '\0') {
            if (*(int *)(*(int *)(unaff_EBP + -0x14) + 0xf4) == unaff_EDI) {
              uVar7 = FUN_01530500(unaff_EBP + -0x44);
              *(undefined *)(unaff_EBP + -4) = 1;
              uVar7 = FUN_00558d90(unaff_EBP + -0x2c,"LuaKicksCounterAll,LuaKicksCounter_",uVar7);
              *(undefined *)(unaff_EBP + -4) = 2;
              FUN_00878480(uVar7,0);
              FUN_005507b0();
              *(undefined *)(unaff_EBP + -4) = 0;
              FUN_005507b0();
            }
            else {
              piVar8 = (int *)(unaff_EDI + 0x1fc);
              iVar5 = *(int *)(unaff_EDI + 0x20c);
              *(undefined *)(unaff_EBP + -4) = 3;
              *(undefined4 *)(unaff_EBP + -0x1c) = 0;
              *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
              *(undefined *)(unaff_EBP + -0x2c) = 0;
              *(undefined4 *)(unaff_EBP + -0x10) = 1;
              FUN_0058a190(iVar5 + 0x23);
              FUN_00554150("LuaKicksCounterAll,LuaKicksCounter_",0x23);
              if (0xf < *(uint *)(unaff_EDI + 0x210)) {
                piVar8 = (int *)*piVar8;
              }
              FUN_00554150(piVar8,*(undefined4 *)(unaff_EDI + 0x20c));
              FUN_00878480(unaff_EBP + -0x2c,0);
              *(undefined *)(unaff_EBP + -4) = 0;
              FUN_005507b0();
            }
          }
        }
      }
      *(undefined *)(unaff_EDI + 0x26b) = 1;
    }
    FUN_00983cb0(unaff_EDI,unaff_EBP + 8);
    FUN_005507b0();
    ExceptionList = *(void **)(unaff_EBP + -0xc);
    return;
  }
  FUN_00550130("Player:Kick() can only be called on a Player under Players");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c17198);
}



/* FUNCTION 16605 ; VA 0x0092cb30 ; FUN_0092cb30 */

void __thiscall
FUN_0092cb30(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 *param_7,ulonglong param_8,uint param_9
            ,undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15)

{
  undefined uVar1;
  uint *puVar2;
  char cVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_78 [2];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 *puStack_64;
  ulonglong uStack_60;
  uint auStack_58 [2];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  char *pcStack_44;
  undefined8 uStack_40;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8e98;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01ee420a != 0) {
    pcStack_44 = (char *)(uint)DAT_01ee420a;
    uStack_40 = 0x193148c;
    uStack_48 = 0x92cb6e;
    ExceptionList = &pvStack_10;
    FUN_016774b0();
  }
  uStack_40 = 0x100000001;
  pcStack_44 = "luaLoadCharacter_start";
  uStack_48 = 0x92cb81;
  FUN_00930760();
  uStack_40 = 0x18bc9b8;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  pcStack_44 = (char *)0x92cba2;
  FUN_005542c0();
  uStack_40 = CONCAT44(1,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  pcStack_44 = (char *)0x92cbae;
  cVar3 = FUN_00971ce0();
  if (cVar3 != '\0') {
    uStack_40 = CONCAT44(1,param_1);
    pcStack_44 = (char *)0x92cbbd;
    cVar3 = FUN_0097c970();
    if (cVar3 != '\0') {
      uStack_40 = CONCAT44(0x92cbc9,(undefined4)uStack_40);
      puVar4 = (uint *)FUN_00acb320();
      if (auStack_34 != puVar4) {
        puVar2 = puVar4 + 4;
        if (0xf < puVar4[5]) {
          puVar4 = (uint *)*puVar4;
        }
        uStack_40 = CONCAT44(*puVar2,puVar4);
        pcStack_44 = (char *)0x92cbe5;
        FUN_005542c0();
      }
      uStack_40 = CONCAT44(0x92cbea,(undefined4)uStack_40);
      FUN_00accbc0();
    }
  }
  puStack_14 = (undefined *)auStack_58;
  puStack_18 = (undefined *)auStack_58;
  auStack_58[0] = 0;
  puVar4 = auStack_58;
  if (param_9 != 0) {
    auStack_58[0] = param_9;
    if ((param_9 & 1) == 0) {
      uStack_60 = ZEXT48(&uStack_50);
      puStack_64 = &param_11;
      uStack_68 = 0x92cc2e;
      (**(code **)(param_9 & 0xfffffffe))();
      puVar4 = (uint *)puStack_14;
    }
    else {
      uStack_50 = param_11;
      uStack_4c = param_12;
      uStack_48 = param_13;
      pcStack_44 = (char *)param_14;
      uStack_40 = param_15;
      puVar4 = auStack_58;
    }
  }
  puStack_14 = (undefined *)puVar4;
  puStack_18 = (undefined *)auStack_78;
  puStack_1c = (undefined *)auStack_78;
  uStack_8._0_1_ = 3;
  auStack_78[0] = 0;
  puVar4 = auStack_78;
  puVar2 = auStack_78;
  if (param_2 != 0) {
    auStack_78[0] = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_70,0);
      puVar4 = (uint *)puStack_1c;
      puVar2 = (uint *)puStack_18;
    }
    else {
      uStack_70 = param_4;
      uStack_6c = param_5;
      uStack_68 = param_6;
      puStack_64 = param_7;
      uStack_60 = param_8;
      puVar4 = auStack_78;
      puVar2 = auStack_78;
    }
  }
  puStack_18 = (undefined *)puVar2;
  puStack_1c = (undefined *)puVar4;
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_34);
  uStack_8._0_1_ = 2;
  FUN_0092ab80(1);
  uStack_40 = 0x100000001;
  pcStack_44 = "luaLoadCharacter_end";
  uStack_48 = 0x92ccab;
  FUN_00930760();
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    uVar5 = auStack_34[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_34[0] - 4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar5) - 4) {
        uStack_40 = CONCAT44(&UNK_0092cd47,(undefined4)uStack_40);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_40 = CONCAT44(uVar6,uVar5);
    pcStack_44 = (char *)0x92ccdc;
    FUN_01674ea0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    pcStack_44 = (char *)&param_4;
    uStack_40 = CONCAT44(2,pcStack_44);
    uStack_48 = 0x92cd00;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    pcStack_44 = (char *)&param_11;
    uStack_40 = CONCAT44(2,pcStack_44);
    uStack_48 = 0x92cd2e;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16606 ; VA 0x0092cd50 ; FUN_0092cd50 */

void __thiscall
FUN_0092cd50(undefined4 param_1,undefined4 *param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,char *param_11,undefined4 param_12,uint param_13,undefined4 param_14,
            undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  int *piVar1;
  uint *puVar2;
  undefined8 uVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  char **ppcVar7;
  char cVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined **ppuVar11;
  int *piVar12;
  undefined4 ****ppppuVar13;
  uint *puVar14;
  char *pcVar15;
  undefined **ppuVar16;
  char *pcVar17;
  uint uVar18;
  uint uVar19;
  undefined4 *puStack_fc;
  int *piStack_f8;
  uint auStack_f4 [2];
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 *puStack_e0;
  undefined8 uStack_dc;
  char *pcStack_d4;
  undefined4 uStack_d0;
  uint uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  char *pcStack_c0;
  undefined8 uStack_bc;
  uint auStack_ac [4];
  undefined4 uStack_9c;
  uint uStack_98;
  undefined4 *puStack_94;
  int *piStack_90;
  undefined4 ***pppuStack_8c;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  undefined8 uStack_7c;
  uint auStack_74 [4];
  undefined4 uStack_64;
  uint uStack_60;
  undefined auStack_5c [4];
  undefined *puStack_58;
  int iStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  undefined4 ***apppuStack_44 [4];
  int iStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8f19;
  pvStack_10 = ExceptionList;
  uStack_24 = param_1;
  piStack_1c = (int *)0x0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_2 != (undefined4 *)0x0) {
    iVar4 = param_2[3];
    uStack_bc = CONCAT44(0x92cd90,(undefined4)uStack_bc);
    ExceptionList = &pvStack_10;
    iVar9 = FUN_00e2c3f0();
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
        (uint)*(ushort *)(iVar9 + 0x1da)) {
      puStack_18 = param_2;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      piStack_1c = param_3;
      pcVar15 = &DAT_00000005;
      puVar10 = &uStack_20;
      goto LAB_0092cde0;
    }
  }
  piStack_28 = (int *)0x0;
  puVar10 = &uStack_2c;
  puStack_18 = (undefined4 *)0x0;
  pcVar15 = &DAT_00000006;
LAB_0092cde0:
  piVar5 = (int *)puVar10[1];
  *puVar10 = 0;
  puVar10[1] = 0;
  piVar12 = piStack_28;
  puStack_94 = puStack_18;
  piStack_90 = piVar5;
  if ((((uint)pcVar15 & 2) != 0) &&
     (pcStack_14 = (char *)((uint)pcVar15 & 0xfffffffd), pcVar15 = pcStack_14,
     piStack_28 != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_28[1] + -1;
    piStack_28[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      uStack_bc = CONCAT44(0x92ce1e,(undefined4)uStack_bc);
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar12 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        uStack_bc = CONCAT44(0x92ce2f,(undefined4)uStack_bc);
        (**(code **)(*piVar12 + 4))();
      }
      pcVar15 = pcStack_14;
    }
  }
  piVar12 = piStack_1c;
  if ((((uint)pcVar15 & 1) != 0) && (piStack_1c != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      uStack_bc = CONCAT44(0x92ce4e,(undefined4)uStack_bc);
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar12 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        uStack_bc = CONCAT44(0x92ce5f,(undefined4)uStack_bc);
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 3;
  if (puStack_18 == (undefined4 *)0x0) {
    uStack_d0 = 0x4a;
    uStack_bc = 0xf00000000;
    pcStack_d4 = "Player::LoadCharacterWithHumanoidDescription() got nil humanoidDescription";
    uStack_cc = uStack_cc & 0xffffff00;
    uStack_dc = CONCAT44(0x92ce88,(undefined4)uStack_dc);
    FUN_005542c0();
    uStack_d0 = 0x92ce90;
    FUN_005e65e0();
  }
  else {
    auStack_5c[0] = 0;
    uStack_bc = CONCAT44(&pcStack_14,&boost::lock_error::vftable_meta_ptr);
    pcStack_c0 = "\x11";
    pcStack_14 = &DAT_0000000b;
    uStack_c4 = 0x92ceb3;
    ppuVar11 = (undefined **)FUN_00563d40();
    ppuVar16 = ppuVar11 + -1;
    if (ppuVar11 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar16 = ppuVar11;
    }
    puStack_58 = *ppuVar16;
    iStack_54 = 0;
    uStack_50 = 0x3f800000;
    uStack_4c = 0;
    iStack_48 = 0;
    uStack_8._0_1_ = 4;
    uStack_bc = CONCAT44(auStack_5c,0x92cef1);
    FUN_00e2fdb0();
    if (iStack_54 != 0) {
      iStack_34 = 0;
      uStack_30 = 0xf;
      apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
      uStack_8._0_1_ = 5;
      puVar10 = *(undefined4 **)(iStack_48 + (int)puStack_58 * 4);
      while (puVar10 != (undefined4 *)0x0) {
        uStack_bc = CONCAT44(puVar10 + 2,auStack_ac);
        pcStack_c0 = (char *)0x92cf33;
        piStack_1c = (int *)FUN_009ee550();
        pcVar15 = "";
        uStack_8._0_1_ = 6;
        if (iStack_34 != 0) {
          pcVar15 = ", ";
        }
        pcStack_14 = pcVar15 + 1;
        pcVar17 = pcVar15;
        do {
          cVar8 = *pcVar17;
          pcVar17 = pcVar17 + 1;
        } while (cVar8 != '\0');
        uStack_bc = CONCAT44((int)pcVar17 - (int)pcStack_14,pcVar15);
        pcStack_c0 = (char *)0x0;
        uStack_c4 = 0x92cf6c;
        piVar12 = (int *)FUN_00585d40();
        pppuStack_8c = (undefined4 ***)*piVar12;
        iStack_88 = piVar12[1];
        iStack_84 = piVar12[2];
        iStack_80 = piVar12[3];
        uVar3 = *(undefined8 *)(piVar12 + 4);
        piVar12[4] = 0;
        piVar12[5] = 0xf;
        *(undefined *)piVar12 = 0;
        uStack_7c._4_4_ = (uint)((ulonglong)uVar3 >> 0x20);
        uStack_8._0_1_ = 7;
        ppppuVar13 = &pppuStack_8c;
        if (0xf < uStack_7c._4_4_) {
          ppppuVar13 = (undefined4 ****)pppuStack_8c;
        }
        uStack_bc = CONCAT44((int)uVar3,ppppuVar13);
        pcStack_c0 = (char *)0x92cfb2;
        uStack_7c = uVar3;
        FUN_00554150();
        uStack_8._0_1_ = 6;
        if (0xf < uStack_7c._4_4_) {
          uVar18 = uStack_7c._4_4_ + 1;
          ppppuVar13 = (undefined4 ****)pppuStack_8c;
          if (0xfff < uVar18) {
            ppppuVar13 = (undefined4 ****)pppuStack_8c[-1];
            uVar18 = uStack_7c._4_4_ + 0x24;
            if (0x1f < (uint)((int)pppuStack_8c + (-4 - (int)ppppuVar13))) goto LAB_0092d32c;
          }
          uStack_bc = CONCAT44(uVar18,ppppuVar13);
          pcStack_c0 = (char *)0x92cfea;
          FUN_01674ea0();
        }
        uStack_8._0_1_ = 5;
        if (0xf < uStack_98) {
          uVar19 = uStack_98 + 1;
          uVar18 = auStack_ac[0];
          if (0xfff < uVar19) {
            uVar18 = *(uint *)(auStack_ac[0] - 4);
            uVar19 = uStack_98 + 0x24;
            if (0x1f < (auStack_ac[0] - uVar18) - 4) goto LAB_0092d32c;
          }
          uStack_bc = CONCAT44(uVar19,uVar18);
          pcStack_c0 = (char *)0x92d028;
          FUN_01674ea0();
        }
        puVar10 = (undefined4 *)*puVar10;
        uStack_9c = 0;
        uStack_98 = 0xf;
        auStack_ac[0] = auStack_ac[0] & 0xffffff00;
      }
      ppppuVar13 = apppuStack_44;
      if (0xf < uStack_30) {
        ppppuVar13 = (undefined4 ****)apppuStack_44[0];
      }
      uStack_bc = CONCAT44(ppppuVar13,
                           "Player::LoadCharacterWithHumanoidDescription() humanoidDescription contains duplicate assets: %s"
                          );
      pcStack_c0 = (char *)0x2;
      uStack_c4 = 0x92d06a;
      FUN_0086f2f0();
      uStack_8._0_1_ = 4;
      if (0xf < uStack_30) {
        uVar18 = uStack_30 + 1;
        ppppuVar13 = (undefined4 ****)apppuStack_44[0];
        if (0xfff < uVar18) {
          ppppuVar13 = (undefined4 ****)apppuStack_44[0][-1];
          uVar18 = uStack_30 + 0x24;
          if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar13))) {
LAB_0092d32c:
            uStack_bc = CONCAT44(0x92d331,(undefined4)uStack_bc);
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        uStack_bc = CONCAT44(uVar18,ppppuVar13);
        pcStack_c0 = (char *)0x92d0a2;
        FUN_01674ea0();
      }
      iStack_34 = 0;
      uStack_30 = 0xf;
      apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
    }
    if (DAT_01ee420a != 0) {
      pcStack_c0 = (char *)(uint)DAT_01ee420a;
      uStack_bc = 0x193158c;
      uStack_c4 = 0x92d0d0;
      FUN_016774b0();
    }
    uVar6 = uStack_24;
    uStack_bc = 0x100000001;
    pcStack_c0 = "luaLoadCharacterWithHumanoidDescription_start";
    uStack_c4 = 0x92d0e6;
    FUN_00930760();
    uStack_bc = 0x18bc9b8;
    uStack_64 = 0;
    uStack_60 = 0xf;
    auStack_74[0] = auStack_74[0] & 0xffffff00;
    pcStack_c0 = (char *)0x92d107;
    FUN_005542c0();
    uStack_bc = CONCAT44(1,uVar6);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    pcStack_c0 = (char *)0x92d113;
    cVar8 = FUN_00971ce0();
    if (cVar8 != '\0') {
      uStack_bc = CONCAT44(1,uVar6);
      pcStack_c0 = (char *)0x92d122;
      cVar8 = FUN_0097c970();
      if (cVar8 != '\0') {
        uStack_bc = CONCAT44(0x92d12e,(undefined4)uStack_bc);
        puVar14 = (uint *)FUN_00acb320();
        if (auStack_74 != puVar14) {
          puVar2 = puVar14 + 4;
          if (0xf < puVar14[5]) {
            puVar14 = (uint *)*puVar14;
          }
          uStack_bc = CONCAT44(*puVar2,puVar14);
          pcStack_c0 = (char *)0x92d14a;
          FUN_005542c0();
        }
        uStack_bc = CONCAT44(0x92d14f,(undefined4)uStack_bc);
        FUN_00accbc0();
      }
    }
    piStack_1c = (int *)&pcStack_d4;
    pcStack_14 = (char *)&pcStack_d4;
    pcStack_d4 = (char *)0x0;
    ppcVar7 = &pcStack_d4;
    if (param_11 != (char *)0x0) {
      pcStack_d4 = param_11;
      if (((uint)param_11 & 1) == 0) {
        uStack_dc = ZEXT48(&uStack_cc);
        puStack_e0 = &param_13;
        uStack_e4 = 0x92d193;
        (**(code **)((uint)param_11 & 0xfffffffe))();
        ppcVar7 = (char **)piStack_1c;
      }
      else {
        uStack_cc = param_13;
        uStack_c8 = param_14;
        uStack_c4 = param_15;
        pcStack_c0 = (char *)param_16;
        uStack_bc = param_17;
        ppcVar7 = &pcStack_d4;
      }
    }
    piStack_1c = (int *)ppcVar7;
    pcStack_14 = (char *)auStack_f4;
    piStack_28 = (int *)auStack_f4;
    uStack_8._0_1_ = 9;
    auStack_f4[0] = 0;
    puVar14 = auStack_f4;
    if (param_4 != 0) {
      auStack_f4[0] = param_4;
      if ((param_4 & 1) == 0) {
        puStack_fc = &uStack_ec;
        piStack_f8 = (int *)0x0;
        (**(code **)(param_4 & 0xfffffffe))(&param_6);
        puVar14 = (uint *)pcStack_14;
      }
      else {
        uStack_ec = param_6;
        uStack_e8 = param_7;
        uStack_e4 = param_8;
        puStack_e0 = param_9;
        uStack_dc = param_10;
        puVar14 = auStack_f4;
      }
    }
    pcStack_14 = (char *)puVar14;
    piStack_28 = (int *)&puStack_fc;
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    puStack_fc = puStack_18;
    uStack_8._0_1_ = 0xb;
    piStack_f8 = piVar5;
    FUN_0054ef60(auStack_74);
    uStack_8._0_1_ = 8;
    FUN_00f7f980(1);
    uStack_bc = 0x100000001;
    pcStack_c0 = "luaLoadCharacterWithHumanoidDescription_end";
    uStack_c4 = 0x92d23a;
    FUN_00930760();
    uStack_8._0_1_ = 4;
    if (0xf < uStack_60) {
      uVar19 = uStack_60 + 1;
      uVar18 = auStack_74[0];
      if (0xfff < uVar19) {
        uVar18 = *(uint *)(auStack_74[0] - 4);
        uVar19 = uStack_60 + 0x24;
        if (0x1f < (auStack_74[0] - uVar18) - 4) {
          uStack_bc = CONCAT44(&UNK_0092d336,(undefined4)uStack_bc);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_bc = CONCAT44(uVar19,uVar18);
      pcStack_c0 = (char *)0x92d26f;
      FUN_01674ea0();
    }
    uStack_bc = CONCAT44(0x92d27a,(undefined4)uStack_bc);
    FUN_00612320();
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar4 = piVar5[1] + -1;
    piVar5[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      uStack_bc = CONCAT44(0x92d290,(undefined4)uStack_bc);
      (**(code **)*piVar5)();
      LOCK();
      iVar4 = piVar5[2] + -1;
      piVar5[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        uStack_bc = CONCAT44(0x92d2a0,(undefined4)uStack_bc);
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar4 = param_3[1] + -1;
    param_3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      uStack_bc = CONCAT44(0x92d2b9,(undefined4)uStack_bc);
      (**(code **)*param_3)();
      LOCK();
      piVar5 = param_3 + 2;
      iVar4 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uStack_bc = CONCAT44(0x92d2c8,(undefined4)uStack_bc);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    pcStack_c0 = (char *)&param_6;
    uStack_bc = CONCAT44(2,pcStack_c0);
    uStack_c4 = 0x92d2e9;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 0xd;
  if (((param_11 != (char *)0x0) && (((uint)param_11 & 1) == 0)) &&
     (*(code **)((uint)param_11 & 0xfffffffe) != (code *)0x0)) {
    pcStack_c0 = (char *)&param_13;
    uStack_bc = CONCAT44(2,pcStack_c0);
    uStack_c4 = 0x92d317;
    (**(code **)((uint)param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16607 ; VA 0x0092d340 ; FUN_0092d340 */

int * FUN_0092d340(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d3f7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d37e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf56c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_14ff1e5b5b8dd0b0d3371c550b1ce465>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16608 ; VA 0x0092d410 ; FUN_0092d410 */

int * FUN_0092d410(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d4c1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d44e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf4c4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_1ce0215b0cb4e0250c348d38018bd300>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16609 ; VA 0x0092d4e0 ; FUN_0092d4e0 */

int * FUN_0092d4e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d597. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d51e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf6bc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_2889607e40044ea28402385f2c246409>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16610 ; VA 0x0092d5b0 ; FUN_0092d5b0 */

int * FUN_0092d5b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d667. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d5ee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf4fc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_29262eed75a692277e782dea269427ff>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16611 ; VA 0x0092d680 ; FUN_0092d680 */

void FUN_0092d680(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1daf1a0);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_2dff539d3e10b557dd61a69be4a19083>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 16612 ; VA 0x0092d6e0 ; FUN_0092d6e0 */

int * FUN_0092d6e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d797. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d71e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf534);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_351bdb1b6e3e6cbfe5c148ae0d0fd549>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16613 ; VA 0x0092d7b0 ; FUN_0092d7b0 */

int * FUN_0092d7b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d867. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d7ee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf684);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_39a7983d497775d45f3153aaf837e8d5>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16614 ; VA 0x0092d880 ; FUN_0092d880 */

int * FUN_0092d880(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d92b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d8be. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf210);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_72e54bf38f03de481cb5ba0fe4b01fe7>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16615 ; VA 0x0092d940 ; FUN_0092d940 */

int * FUN_0092d940(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d9f7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092d97e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf5a4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_7d72b49f69b72474c819c7b6312c13df>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16616 ; VA 0x0092da10 ; FUN_0092da10 */

int * FUN_0092da10(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092dac7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092da4e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf64c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_88b017dac815f40dd29c5bfb9ff5e9d0>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16617 ; VA 0x0092dae0 ; FUN_0092dae0 */

void FUN_0092dae0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1daf72c);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_9d54076b1762e59647e5a5abbb490b11>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 16618 ; VA 0x0092db40 ; FUN_0092db40 */

int * FUN_0092db40(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092dbeb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092db7e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf168);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_a8bd786dacba543b056ace5f95aaca88>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16619 ; VA 0x0092dc00 ; FUN_0092dc00 */

int * FUN_0092dc00(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092dcd7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092dc56. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf828);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_aa62be476e299cf9066b5be28ed9ca8a>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16620 ; VA 0x0092dcf0 ; FUN_0092dcf0 */

int * FUN_0092dcf0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092dda7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092dd2e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf764);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_d4e18ae24ae1227f43ab4c437b734148>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16621 ; VA 0x0092ddc0 ; FUN_0092ddc0 */

void FUN_0092ddc0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1daf614);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_dcfb7e79c89f83f80db64bb2a3385c26>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 16622 ; VA 0x0092de20 ; FUN_0092de20 */

int * FUN_0092de20(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092ded7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092de5e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf5dc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_e5148b5473ef3261795dbf8575c21ae6>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16623 ; VA 0x0092def0 ; FUN_0092def0 */

void FUN_0092def0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1daf248);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_e6cfc3c55cbe7a6b01f34e915da4f9a6>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 16624 ; VA 0x0092df50 ; FUN_0092df50 */

void FUN_0092df50(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1daf1d8);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_f7891f698b81caaf24b504c72ece8a79>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 16625 ; VA 0x0092dfb0 ; FUN_0092dfb0 */

void FUN_0092dfb0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1daf280);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_faaa4ced503f194d9ab5ddfef46d6228>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 16626 ; VA 0x0092e010 ; FUN_0092e010 */

int * FUN_0092e010(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092e0c7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092e04e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf6f4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_fdd7493a5b21496db44dbe12495243e4>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16627 ; VA 0x0092e0e0 ; FUN_0092e0e0 */

int * FUN_0092e0e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092e198. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092e11e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dafa44);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::Player>&,class_RBX::ServiceProvider_const*),class_boost::_bi::list2<class_boost::_bi::value<class_std::weak_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_RBX::ServiceProvider_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16628 ; VA 0x0092e1b0 ; FUN_0092e1b0 */

int * FUN_0092e1b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092e268. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092e1ee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf08c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::Player>_const&,enum_RBX::Player::CanManageStatus),class_boost::_bi::list2<class_boost::_bi::value<class_std::weak_ptr<class_RBX::Player>_>,class_boost::_bi::value<enum_RBX::Player::CanManageStatus>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16629 ; VA 0x0092e280 ; FUN_0092e280 */

void FUN_0092e280(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1daef54);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 16630 ; VA 0x0092e3f0 ; FUN_0092e3f0 */

void FUN_0092e3f0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x38);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_009190b0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0091a340();
        FUN_01674ea0(iVar3,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1daf2bc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::Player>,__int64,enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_std::shared_ptr<class_std::exception>,class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Animation>)>),class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<__int64>,struct_boost::arg<1>,struct_boost::arg<2>,struct_boost::arg<3>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Animation>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 16631 ; VA 0x0092e540 ; FUN_0092e540 */

int * FUN_0092e540(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092e5f2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092e57e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf864);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::Player>,class_std::shared_ptr<class_std::map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_std::less<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_boost::_bi::list2<class_boost::_bi::value<class_std::weak_ptr<class_RBX::Player>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16632 ; VA 0x0092e610 ; FUN_0092e610 */

int * FUN_0092e610(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[3];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092e6f8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0092e666. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daf79c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf0<void,class_RBX::Player>,class_boost::_bi::list1<class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 16633 ; VA 0x0092e710 ; FUN_0092e710 */

void __thiscall FUN_0092e710(int param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  
  if (*(int *)(param_1 + 100) == 0) {
    FUN_0086edd0();
    return;
  }
  iVar1 = FUN_0068f8a0();
  if (iVar1 != 0) {
    FUN_009ba920(param_2,param_3,param_4);
    return;
  }
  FUN_0086edd0();
  return;
}



/* FUNCTION 16634 ; VA 0x0092e780 ; FUN_0092e780 */

void __fastcall FUN_0092e780(int param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_4c;
  undefined4 **ppuStack_48;
  undefined4 uStack_30;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8f51;
  pvStack_10 = ExceptionList;
  uStack_4c = 0x92e7af;
  ExceptionList = &pvStack_10;
  ppuStack_48 = (undefined4 **)param_1;
  iVar3 = FUN_0097bfc0();
  if (param_1 == iVar3) {
    uStack_4c = 0x92e7c0;
    ppuStack_48 = (undefined4 **)param_1;
    iVar3 = FUN_005c3ac0();
    ppuStack_48 = *(undefined4 ***)(param_1 + 100);
    if (ppuStack_48 == (undefined4 **)0x0) {
      piVar1 = (int *)(iVar3 + 0x144);
      ppuStack_48 = (undefined4 **)0x92e7dc;
      (**(code **)(*piVar1 + 4))();
      ppuStack_48 = (undefined4 **)0x0;
      uStack_4c = 0x92e7e5;
      FUN_00d24d00();
      ppuStack_48 = (undefined4 **)0x92e7ee;
      (**(code **)(*piVar1 + 4))();
      ppuStack_48 = (undefined4 **)0x0;
      uStack_4c = 0x92e7fd;
      FUN_00d24fe0();
      ppuStack_48 = (undefined4 **)0x92e806;
      (**(code **)(*piVar1 + 4))();
      ppuStack_48 = (undefined4 **)&DAT_bf800000;
      uStack_4c = 0x92e815;
      FUN_00d27430();
      ExceptionList = pvStack_10;
      return;
    }
    uStack_4c = 0x92e82b;
    iVar3 = FUN_009ba880();
    if (iVar3 == 0) {
      ppuStack_48 = (undefined4 **)0x92e855;
      iVar3 = FUN_008a4100();
      ppuStack_48 = (undefined4 **)DAT_02110da8;
      iStack_8 = 0;
      uStack_4c = 0x92e87e;
      uVar4 = FUN_01675290();
      uStack_4c = 0x28;
      iStack_8._0_1_ = 1;
      puStack_14 = (undefined4 *)FUN_01674e20();
      if (puStack_14 == (undefined4 *)0x0) {
        puStack_14 = (undefined4 *)0x0;
      }
      else {
        *puStack_14 = 0;
        puStack_14[1] = 1;
        puStack_14[2] = FUN_00923570;
        puStack_14[3] = _guard_check_icall;
        puStack_14[4] = 0;
        puStack_14[5] = iVar3 + 8;
        puStack_14[6] = FUN_0091e8e0;
        puStack_14[7] = 0;
        puStack_14[8] = param_1;
        puStack_14[9] = uStack_30;
      }
      uStack_4c = 0x92e8d4;
      ppuStack_48 = (undefined4 **)puStack_14;
      FUN_016797d0();
      if (puStack_14 != (undefined4 *)0x0) {
        LOCK();
        puStack_14[1] = puStack_14[1] + 1;
        UNLOCK();
      }
      iStack_8._0_1_ = 2;
      uStack_4c = 0x92e8f8;
      ppuStack_48 = (undefined4 **)uVar4;
      FUN_01675290();
      ppuStack_48 = &puStack_14;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      uStack_4c = 0x92e913;
      cVar2 = FUN_01679300();
      if (cVar2 != '\0') {
        ppuStack_48 = (undefined4 **)0x92e91e;
        FUN_01679490();
        ppuStack_48 = &puStack_14;
        uStack_4c = 0x92e929;
        FUN_016791c0();
      }
      iStack_8 = 0xffffffff;
      if (puStack_14 != (undefined4 *)0x0) {
        piVar1 = puStack_14 + 1;
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          ppuStack_48 = (undefined4 **)puStack_14;
          uStack_4c = 0x92e94e;
          FUN_01674ea0();
        }
      }
    }
    else {
      FUN_0060dcd0(&uStack_4c,iVar3);
      FUN_00935530();
    }
    ppuStack_48 = (undefined4 **)0x92e959;
    FUN_008ba310();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16635 ; VA 0x0092e970 ; FUN_0092e970 */

void __fastcall FUN_0092e970(int param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined **ppuVar6;
  undefined4 auStack_58 [2];
  undefined auStack_50 [20];
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8f68;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    ExceptionList = &pvStack_10;
    if ((iVar5 != 0) && (iVar3 = iVar5, ExceptionList = &pvStack_10, *(int *)(iVar5 + 0x34) != 0)) {
      uStack_38 = (double)CONCAT44(0x92e9ab,(undefined4)uStack_38);
      ExceptionList = &pvStack_10;
      iVar3 = FUN_005c8ac0();
    }
    if (iVar3 != 0) {
      iVar5 = *(int *)(iVar3 + 0xc);
      uStack_38 = (double)CONCAT44(0x92e9c1,(undefined4)uStack_38);
      iVar4 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        uStack_38 = (double)CONCAT44(param_1,0x92e9e6);
        iVar5 = FUN_0064e810();
        if ((iVar5 == 0) || (*(char *)(iVar5 + 0xa1) != '\0')) {
          if (DAT_01d6420c == '\0') {
            uStack_38 = (double)CONCAT44(iVar3,0x92ea0d);
            FUN_0091d530();
          }
          uStack_38 = (double)CONCAT44(param_1,0x92ea13);
          iStack_18 = FUN_00899230();
          if (iStack_18 != 0) {
            puStack_14 = DAT_018e3f90;
            if (iVar5 != 0) {
              puStack_14 = *(undefined4 **)(iVar5 + 0xa4);
            }
            if (*(char *)(param_1 + 0xac) == '\0') {
              *(undefined *)(param_1 + 0xac) = 1;
              uStack_38 = (double)CONCAT44(param_1,&uStack_24);
              uStack_3c = 0x92ea5d;
              FUN_0060dcd0();
              uStack_38 = (double)(float)puStack_14;
              uStack_8 = 0;
              puStack_14 = auStack_58;
              if (piStack_20 != (int *)0x0) {
                piVar1 = piStack_20 + 1;
                LOCK();
                *piVar1 = *piVar1 + 1;
                UNLOCK();
                LOCK();
                *piVar1 = *piVar1 + 1;
                UNLOCK();
              }
              auStack_58[0] = 0;
              if (piStack_20 != (int *)0x0) {
                LOCK();
                piStack_20[1] = piStack_20[1] + 1;
                UNLOCK();
              }
              if (piStack_20 != (int *)0x0) {
                LOCK();
                piStack_20[1] = piStack_20[1] + 1;
                UNLOCK();
              }
              ppuVar6 = &PTR_FUN_0193260c;
              cVar2 = FUN_0055c750(uStack_24,piStack_20,auStack_50);
              if (cVar2 == '\0') {
                ppuVar6 = (undefined **)0x0;
              }
              *puStack_14 = ppuVar6;
              if (piStack_20 != (int *)0x0) {
                LOCK();
                iVar5 = piStack_20[1] + -1;
                piStack_20[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piStack_20)();
                  LOCK();
                  iVar5 = piStack_20[2] + -1;
                  piStack_20[2] = iVar5;
                  UNLOCK();
                  if (iVar5 == 0) {
                    (**(code **)(*piStack_20 + 4))();
                  }
                }
                LOCK();
                iVar5 = piStack_20[1] + -1;
                piStack_20[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piStack_20)();
                  LOCK();
                  iVar5 = piStack_20[2] + -1;
                  piStack_20[2] = iVar5;
                  UNLOCK();
                  if (iVar5 == 0) {
                    (**(code **)(*piStack_20 + 4))();
                  }
                }
                LOCK();
                iVar5 = piStack_20[1] + -1;
                piStack_20[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piStack_20)();
                  LOCK();
                  piVar1 = piStack_20 + 2;
                  iVar5 = *piVar1;
                  *piVar1 = *piVar1 + -1;
                  UNLOCK();
                  if (iVar5 == 1) {
                    (**(code **)(*piStack_20 + 4))();
                  }
                }
              }
              FUN_009eef30();
              uStack_8 = 0xffffffff;
              uStack_38 = (double)CONCAT44(0x92eb55,(undefined4)uStack_38);
              FUN_00550b30();
            }
            uStack_38 = (double)CONCAT44(0x92eb60,(undefined4)uStack_38);
            cVar2 = FUN_016793f0();
            if (cVar2 != '\0') {
              uStack_38 = (double)CONCAT44(0x92eb6f,(undefined4)uStack_38);
              FUN_01679490();
            }
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16636 ; VA 0x0092eb80 ; FUN_0092eb80 */

void FUN_0092eb80(int param_1,int *param_2,undefined4 param_3,undefined4 param_4,int param_5,
                 int *param_6,int *param_7,undefined4 param_8,int *param_9,uint param_10)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8fb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  if ((param_5 == 1) && (puVar2 = (undefined4 *)*param_6, puVar2 != (undefined4 *)param_6[1])) {
    iStack_1c = puVar2[1];
    ExceptionList = &pvStack_10;
    if (iStack_1c != 0) {
      LOCK();
      ExceptionList = &pvStack_10;
      *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
      UNLOCK();
      iStack_1c = puVar2[1];
    }
    uStack_20 = *puVar2;
    uStack_8._0_1_ = 4;
    uStack_8._1_3_ = 0;
    FUN_00916f90(&iStack_18,&uStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (iStack_18 == 0) {
      iStack_18 = 0;
      iStack_14 = 0;
    }
    else {
      (**(code **)(*(int *)(param_1 + 0x330) + 8))(&param_3,&iStack_18,0);
      if (iStack_14 != 0) {
        LOCK();
        *(int *)(iStack_14 + 4) = *(int *)(iStack_14 + 4) + 1;
        UNLOCK();
      }
    }
    FUN_0091b750(iStack_18,iStack_14);
    FUN_00550b30();
    FUN_00550b30();
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0091b750(0,0);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar3 = param_2[2] + -1;
      param_2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  piVar4 = param_7;
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar3 = param_7[1] + -1;
    param_7[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = param_9;
  if (param_9 != (int *)0x0) {
    LOCK();
    iVar3 = param_9[1] + -1;
    param_9[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_9)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = 6;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_10 & 0xfffffffe))(&stack0x00000030,&stack0x00000030,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16637 ; VA 0x0092ed20 ; FUN_0092ed20 */

/* WARNING: Removing unreachable block (ram,0x0092ee06) */

uint __thiscall FUN_0092ed20(int param_1,int param_2,int *param_3,int param_4)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  longlong lVar12;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c8fd8;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0089bf10();
  iVar4 = *(int *)(param_2 + 0xc);
  iVar9 = FUN_00913630();
  iVar11 = 0;
  if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
      (uint)*(ushort *)(iVar9 + 0x1da)) {
    iVar11 = param_2;
  }
  uVar10 = (uint)*(ushort *)(iVar9 + 0x1da);
  if (((iVar11 != 0) && (uVar10 = FUN_006719d0(), uVar10 != 0)) &&
     ((param_4 == 2 || (param_4 == 1)))) {
    FUN_00928340();
    lVar12 = FUN_016f4270();
    if ((longlong)(int)DAT_01ee1b7c < lVar12 + 1) {
      FUN_00bf0dc0();
      uVar10 = FUN_00bf0dc0();
    }
    else if (param_4 == 2) {
      uVar5 = *(undefined4 *)(iVar11 + 0xf0);
      uVar6 = *(undefined4 *)(iVar11 + 0xf4);
      uVar7 = *(undefined4 *)(param_1 + 0xf0);
      uVar8 = *(undefined4 *)(param_1 + 0xf4);
      FUN_0054ef60(iVar11 + 0x100);
      iStack_8._0_1_ = 1;
      FUN_0054ef60(iVar11 + 0x118);
      iStack_8._0_1_ = 0;
      FUN_00bf0370(uVar7,uVar8,uVar5,uVar6);
      uVar5 = *(undefined4 *)(iVar11 + 0xf0);
      uVar6 = *(undefined4 *)(iVar11 + 0xf4);
      uVar7 = *(undefined4 *)(param_1 + 0xf0);
      uVar8 = *(undefined4 *)(param_1 + 0xf4);
      FUN_0054ef60(param_1 + 0x100);
      iStack_8._0_1_ = 2;
      FUN_0054ef60(param_1 + 0x118);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      uVar10 = FUN_00bf0370(uVar5,uVar6,uVar7,uVar8);
    }
    else {
      uVar10 = DAT_01ee1b7c;
      if (param_4 == 1) {
        FUN_00bf9680();
        uVar10 = FUN_00bf9680();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar10 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar10 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar10 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar10;
}



/* FUNCTION 16638 ; VA 0x0092ef80 ; FUN_0092ef80 */

void FUN_0092ef80(void)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_c [8];
  
  iVar1 = FUN_005cf750();
  if (((iVar1 != 0) && (iVar1 = *(int *)(iVar1 + 0xf4), iVar1 != 0)) &&
     (iVar2 = FUN_005c8880(iVar1), iVar2 != 0)) {
    puVar3 = (undefined4 *)FUN_01682800(auStack_c);
    *(undefined4 *)(iVar1 + 0x448) = *puVar3;
    *(undefined4 *)(iVar1 + 0x44c) = puVar3[1];
  }
  return;
}



/* FUNCTION 16639 ; VA 0x0092efd0 ; FUN_0092efd0 */

void __thiscall FUN_0092efd0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  double *pdVar2;
  int iVar3;
  int iVar4;
  undefined4 unaff_EBX;
  double dVar5;
  
  if (param_2 == &DAT_0211eac0) {
    if (*(char *)(param_1 + 400) == '\0') {
      if (DAT_01ee1b70 != '\0') {
        pdVar2 = (double *)FUN_01682800();
        iVar4 = *(int *)(param_1 + 0xf0);
        iVar3 = *(int *)(param_1 + 0xf4);
        dVar5 = (*pdVar2 - *(double *)(param_1 + 0x538)) * DAT_018c0d70;
        if ((iVar4 != *(uint *)(param_1 + 0xf8) + 0xaaf55c4e) ||
           (iVar3 != *(int *)(param_1 + 0xfc) - (uint)(*(uint *)(param_1 + 0xf8) < 0x550aa3b2))) {
          FUN_01675310("SecurityViolation",&DAT_018bc9b8);
          iVar4 = *(int *)(param_1 + 0xf0);
          iVar3 = *(int *)(param_1 + 0xf4);
        }
        FUN_01677520(DAT_01ee1b70,"network pause ended for userID %lld. Duration = %f",iVar4,iVar3,
                     dVar5);
      }
    }
    else {
      puVar1 = (undefined4 *)FUN_01682800();
      *(undefined4 *)(param_1 + 0x538) = *puVar1;
      *(undefined4 *)(param_1 + 0x53c) = puVar1[1];
      if (DAT_01ee1b70 != '\0') {
        iVar4 = *(int *)(param_1 + 0xf0);
        iVar3 = *(int *)(param_1 + 0xf4);
        if ((iVar4 != *(uint *)(param_1 + 0xf8) + 0xaaf55c4e) ||
           (iVar3 != *(int *)(param_1 + 0xfc) - (uint)(*(uint *)(param_1 + 0xf8) < 0x550aa3b2))) {
          FUN_01675310("SecurityViolation",&DAT_018bc9b8);
          iVar4 = *(int *)(param_1 + 0xf0);
          iVar3 = *(int *)(param_1 + 0xf4);
        }
        FUN_01677520(DAT_01ee1b70,"network pause started for userID %lld",iVar4,iVar3,unaff_EBX);
        return;
      }
    }
  }
  return;
}



/* FUNCTION 16640 ; VA 0x0092f130 ; FUN_0092f130 */

void __thiscall FUN_0092f130(int *param_1,undefined4 *param_2,int param_3)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  undefined4 *puVar7;
  code *pcStack_40;
  int iStack_3c;
  int *piStack_38;
  int iStack_34;
  undefined auStack_30 [4];
  int iStack_2c;
  int *piStack_28;
  undefined4 *puStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9099;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined4 *)0x0;
  puStack_18 = (undefined4 *)0x0;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  if ((param_2 != (undefined4 *)0x0) &&
     (ExceptionList = &pvStack_10, cVar1 = FUN_00971ce0(param_2,1), cVar1 != '\0')) {
    param_1[0xdb] = 0;
    piStack_20 = (int *)param_1[0xdc];
    param_1[0xdc] = 0;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar3 = piStack_20[2] + -1;
        piStack_20[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    FUN_009326f0(0);
    FUN_01679490();
    piVar2 = (int *)FUN_00676db0();
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0x2c))();
    }
    cVar1 = FUN_016793f0();
    if (cVar1 != '\0') {
      FUN_01679490();
    }
  }
  FUN_008a4210(param_2,param_3);
  if ((param_3 != 0) && (cVar1 = FUN_00983210(param_3), cVar1 == '\0')) {
    cVar1 = FUN_0097c970(param_3,1);
    if (cVar1 != '\0') {
      FUN_0092e780();
      piVar2 = (int *)FUN_0097bfc0(param_3);
      if ((piVar2 != (int *)0x0) && (param_1 == piVar2)) {
        cVar1 = FUN_0097c970(param_1,1);
        if (cVar1 == '\0') {
          FUN_00550130("rebuildPlayerScripts can only be called by the client");
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_30,&DAT_01c17198);
        }
        puVar7 = (undefined4 *)param_1[0xb];
        if (puVar7 != (undefined4 *)0x0) {
          piVar2 = (int *)puVar7[1];
          param_1 = piStack_1c;
          for (piVar6 = (int *)*puVar7; piStack_1c = param_1, piVar6 != piVar2; piVar6 = piVar6 + 2)
          {
            if (*piVar6 != 0) {
              piStack_20 = *(int **)(*piVar6 + 0xc);
              iVar3 = FUN_00c4b770();
              if ((uint)*(ushort *)(piStack_20 + 0x76) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
                  (uint)*(ushort *)(iVar3 + 0x1da)) goto LAB_0092f30b;
            }
            param_1 = piStack_1c;
          }
        }
        FUN_00916720(&iStack_2c);
        uStack_8 = 0;
        if (iStack_2c != 0) {
          FUN_008a65e0(param_1,0);
        }
        piVar2 = piStack_28;
        uStack_8 = 0xffffffff;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_28[1] + -1;
          piStack_28[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            piVar6 = piVar2 + 2;
            iVar3 = *piVar6 + -1;
            *piVar6 = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
      }
    }
LAB_0092f30b:
    cVar1 = FUN_00971ce0(param_3,1);
    param_1 = piStack_1c;
    if (cVar1 != '\0') {
      pcStack_40 = FUN_0092e970;
      iStack_3c = 0;
      piStack_38 = piStack_1c;
      FUN_006eccd0();
      FUN_00915d30(&piStack_1c,&pcStack_40);
      puStack_14 = (undefined4 *)0x1;
      puStack_18 = (undefined4 *)0x1;
      uStack_8 = 1;
      cVar1 = FUN_01679300(&piStack_1c);
      if (cVar1 != '\0') {
        FUN_01679490();
        FUN_016791c0(&piStack_1c);
      }
      uStack_8 = 0xffffffff;
      if (piStack_1c != (int *)0x0) {
        piVar2 = piStack_1c + 1;
        LOCK();
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(piStack_1c);
        }
      }
    }
    cVar1 = FUN_00971ce0(param_3,1);
    if (((cVar1 != '\0') && (param_2 == (undefined4 *)0x0)) &&
       (iVar3 = FUN_0063f6a0(param_1), iVar3 != 0)) {
      FUN_00932670(*(undefined4 *)(iVar3 + 0x58));
      FUN_00932570(*(undefined4 *)(iVar3 + 100));
      FUN_009325f0(*(undefined4 *)(iVar3 + 0x68));
      FUN_00933a30(*(undefined4 *)(iVar3 + 0x60));
      FUN_00933f50(*(undefined4 *)(iVar3 + 0x5c));
      piStack_20 = (int *)CONCAT31(piStack_20._1_3_,*(undefined *)(iVar3 + 0x6c));
      FUN_009335f0(piStack_20);
      FUN_009336c0(*(undefined4 *)(iVar3 + 0xb8));
      FUN_00933450(*(undefined4 *)(iVar3 + 0xbc));
      FUN_00933380(*(undefined4 *)(iVar3 + 0xc0));
      FUN_00933790(*(undefined4 *)(iVar3 + 0xc4));
      FUN_00933520(*(undefined4 *)(iVar3 + 200));
      piStack_20 = (int *)CONCAT31(piStack_20._1_3_,*(undefined *)(iVar3 + 0xd0));
      FUN_00932530(piStack_20);
    }
    pcStack_40 = FUN_00934730;
    iStack_3c = 0;
    piStack_38 = param_1;
    FUN_006eccd0();
    uStack_8 = 2;
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8 = 3;
    puStack_24 = (undefined4 *)uVar4;
    piStack_20 = (int *)FUN_01674e20(0x28);
    if (piStack_20 == (int *)0x0) {
      piStack_20 = (int *)0x0;
    }
    else {
      *piStack_20 = 0;
      piStack_20[1] = 1;
      piStack_20[2] = (int)FUN_00923550;
      piStack_20[3] = (int)_guard_check_icall;
      piStack_20[4] = 0;
      piStack_20[5] = (int)(param_1 + 0xec);
      piStack_20[6] = (int)pcStack_40;
      piStack_20[7] = iStack_3c;
      piStack_20[8] = (int)piStack_38;
      piStack_20[9] = iStack_34;
    }
    FUN_016797d0(piStack_20);
    piStack_1c = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    puStack_18 = (undefined4 *)((uint)puStack_14 | 4);
    uStack_8 = 4;
    puStack_14 = puStack_18;
    FUN_01675290(uVar4);
    puStack_24 = (undefined4 *)((uint)puStack_14 & 0xfffffffb | 2);
    uStack_8 = 5;
    puStack_18 = puStack_24;
    puStack_14 = puStack_24;
    cVar1 = FUN_01679300(&piStack_1c);
    if (cVar1 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_1c);
    }
    uStack_8 = 0xffffffff;
    if (piStack_1c != (int *)0x0) {
      piVar2 = piStack_1c + 1;
      LOCK();
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(piStack_1c);
      }
    }
    if (param_1 != (int *)0x0) {
      piStack_1c = (int *)param_1[0xd];
      piVar2 = param_1;
      if ((piStack_1c != (int *)0x0) && (piVar2 = piStack_1c, piStack_1c[0xd] != 0)) {
        piVar2 = (int *)FUN_005c8ac0();
      }
      piStack_1c = piVar2;
      if ((piStack_1c != (int *)0x0) &&
         (iVar3 = piStack_1c[3], iVar5 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
        uVar4 = FUN_006352d0();
        piStack_1c = (int *)FUN_008aa140(uVar4);
        if (*piStack_1c == 0) {
          uVar4 = FUN_00b8c410();
          piVar2 = (int *)FUN_008a9ba0(&iStack_2c,uVar4);
          iVar3 = *piVar2;
          iVar5 = piVar2[1];
          *piVar2 = 0;
          piVar2[1] = 0;
          *piStack_1c = iVar3;
          piStack_20 = (int *)piStack_1c[1];
          piStack_1c[1] = iVar5;
          if (piStack_20 != (int *)0x0) {
            LOCK();
            iVar3 = piStack_20[1] + -1;
            piStack_20[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piStack_20)();
              LOCK();
              iVar3 = piStack_20[2] + -1;
              piStack_20[2] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piStack_20 + 4))();
              }
            }
          }
          piStack_20 = piStack_28;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            iVar3 = piStack_28[1] + -1;
            piStack_28[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piStack_28)();
              LOCK();
              iVar3 = piStack_20[2] + -1;
              piStack_20[2] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piStack_20 + 4))();
              }
            }
          }
        }
        if ((int *)*piStack_1c != (int *)0x0) {
          pcStack_40 = FUN_00b9c950;
          iStack_3c = 0;
          iStack_34 = 0x10b;
          piStack_38 = (int *)*piStack_1c;
          FUN_006eccd0();
          uStack_8 = 6;
          piVar2 = (int *)FUN_01675290(DAT_02110da8);
          uStack_8 = 7;
          piStack_28 = piVar2;
          piStack_20 = (int *)FUN_01674e20(0x28);
          if (piStack_20 == (int *)0x0) {
            piStack_20 = (int *)0x0;
          }
          else {
            *piStack_20 = 0;
            piStack_20[1] = 1;
            piStack_20[2] = (int)FUN_009236c0;
            piStack_20[3] = (int)_guard_check_icall;
            piStack_20[4] = 0;
            piStack_20[5] = (int)(param_1 + 0xfe);
            piStack_20[6] = (int)pcStack_40;
            piStack_20[7] = iStack_3c;
            piStack_20[8] = (int)piStack_38;
            piStack_20[9] = iStack_34;
          }
          FUN_016797d0(piStack_20);
          piStack_1c = piStack_20;
          if (piStack_20 != (int *)0x0) {
            LOCK();
            piStack_20[1] = piStack_20[1] + 1;
            UNLOCK();
          }
          puStack_18 = (undefined4 *)((uint)puStack_14 | 0x10);
          uStack_8 = 8;
          FUN_01675290(piVar2);
          puStack_18 = (undefined4 *)((uint)puStack_24 & 0xffffffef | 8);
          uStack_8 = 9;
          puStack_14 = puStack_18;
          cVar1 = FUN_01679300(&piStack_1c);
          if (cVar1 != '\0') {
            FUN_01679490();
            FUN_016791c0(&piStack_1c);
          }
          uStack_8 = 0xffffffff;
          if (piStack_1c != (int *)0x0) {
            piVar2 = piStack_1c + 1;
            LOCK();
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
              FUN_01674ea0(piStack_1c);
            }
          }
        }
      }
    }
  }
  if ((param_2 == (undefined4 *)0x0) && (cVar1 = FUN_0097c970(param_3,1), cVar1 != '\0')) {
    piVar2 = (int *)FUN_01682800(&iStack_2c);
    param_1[0x112] = *piVar2;
    param_1[0x113] = piVar2[1];
    FUN_00922460();
  }
  if ((param_3 != 0) && (*(char *)(param_1 + 0x131) == '\0')) {
    *(undefined *)(param_1 + 0x131) = 1;
    cVar1 = FUN_0097c970(param_3,1);
    if ((cVar1 != '\0') && (piVar2 = (int *)FUN_0097bfc0(param_1), param_1 == piVar2)) {
      pcStack_40 = FUN_00928a20;
      iStack_3c = 0;
      piStack_38 = param_1;
      FUN_006eccd0();
      uStack_8 = 10;
      piVar2 = (int *)FUN_01675290(DAT_02110da8);
      uStack_8 = 0xb;
      piStack_28 = piVar2;
      param_2 = (undefined4 *)FUN_01674e20(0x28);
      if (param_2 == (undefined4 *)0x0) {
        param_2 = (undefined4 *)0x0;
      }
      else {
        *param_2 = 0;
        param_2[1] = 1;
        param_2[2] = FUN_009237a0;
        param_2[3] = _guard_check_icall;
        param_2[4] = 0;
        param_2[5] = param_1 + 0xfc;
        param_2[6] = pcStack_40;
        param_2[7] = iStack_3c;
        param_2[8] = piStack_38;
        param_2[9] = iStack_34;
      }
      FUN_016797d0(param_2);
      puStack_24 = param_2;
      if (param_2 != (undefined4 *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      puStack_18 = (undefined4 *)((uint)puStack_14 | 0x40);
      uStack_8 = 0xc;
      puStack_14 = puStack_18;
      FUN_01675290(piVar2);
      puStack_18 = (undefined4 *)((uint)puStack_14 & 0xffffffbf | 0x20);
      uStack_8 = 0xffffffff;
      puStack_14 = puStack_18;
      if (param_2 != (undefined4 *)0x0) {
        piVar2 = param_2 + 1;
        LOCK();
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
    cVar1 = FUN_00971ce0(param_3,1);
    if (cVar1 != '\0') {
      pcStack_40 = FUN_00928c00;
      iStack_3c = 0;
      piStack_38 = param_1;
      FUN_006eccd0();
      uStack_8 = 0xd;
      uVar4 = FUN_01675290(DAT_02110da8);
      uStack_8 = 0xe;
      piStack_28 = (int *)FUN_01674e20(0x28);
      if (piStack_28 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        *piStack_28 = 0;
        piStack_28[1] = 1;
        piStack_28[2] = (int)FUN_00923640;
        piStack_28[3] = (int)_guard_check_icall;
        piStack_28[4] = 0;
        piStack_28[5] = (int)(param_1 + 0xfa);
        piStack_28[6] = (int)pcStack_40;
        piStack_28[7] = iStack_3c;
        piStack_28[8] = (int)piStack_38;
        piStack_28[9] = iStack_34;
        puVar7 = piStack_28;
      }
      FUN_016797d0(puVar7);
      piVar2 = puVar7 + 1;
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      puStack_18 = (undefined4 *)((uint)puStack_14 | 0x100);
      uStack_8 = 0xf;
      piStack_28 = puVar7;
      FUN_01675290(uVar4);
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(puVar7);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16641 ; VA 0x0092faa0 ; FUN_0092faa0 */

int FUN_0092faa0(undefined4 param_1,int param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  undefined8 uVar8;
  undefined4 uStack_84;
  int iStack_80;
  int *piStack_7c;
  undefined4 uStack_78;
  int *piStack_74;
  int **ppiStack_70;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  int *apiStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c90f0;
  pvStack_10 = ExceptionList;
  ppiStack_70 = (int **)0x9;
  piStack_74 = (int *)0x1931e0c;
  uStack_8 = 1;
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  uStack_78 = 0x92faec;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8._0_1_ = 2;
  if (*(int *)(param_2 + 8) != 0) {
    ppiStack_70 = (int **)auStack_60;
    piStack_74 = &iStack_14;
    uStack_78 = 0x92fb09;
    FUN_00580040();
    if (iStack_14 != 0) {
      ppiStack_70 = (int **)0x7;
      iStack_20 = iStack_14 + 0x20;
      uStack_38 = 0;
      piStack_74 = (int *)0x18c5e18;
      uStack_34 = 0xf;
      apiStack_48[0] = (int *)((uint)apiStack_48[0] & 0xffffff00);
      uStack_78 = 0x92fb3e;
      FUN_005542c0();
      uStack_8._0_1_ = 4;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 4;
      if (*(int *)(param_2 + 8) == 0) {
LAB_0092fd0b:
        uStack_8._0_1_ = uVar4;
        ppiStack_70 = (int **)0x193229c;
        piStack_74 = (int *)0x92fd18;
        ppiStack_70 = (int **)FUN_0091a050();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        piStack_74 = (int *)0x92fd22;
        FUN_00917680();
        pcVar2 = (code *)swi(3);
        iVar5 = (*pcVar2)();
        return iVar5;
      }
      ppiStack_70 = apiStack_48;
      piStack_74 = &iStack_14;
      uStack_78 = 0x92fb5b;
      FUN_00580040();
      uVar4 = (undefined)uStack_8;
      if (iStack_14 == 0) goto LAB_0092fd0b;
      ppiStack_70 = (int **)0x92fb6e;
      uVar8 = FUN_00563790();
      FUN_00563690(&uStack_84);
      uVar3 = uStack_28;
      FUN_009257d0(uStack_28,param_1,uVar8);
      uStack_8._0_1_ = 2;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 2;
      if (0xf < uStack_34) {
        ppiStack_70 = (int **)(uStack_34 + 1);
        piVar6 = apiStack_48[0];
        if (0xfff < ppiStack_70) {
          piVar6 = (int *)apiStack_48[0][-1];
          ppiStack_70 = (int **)(uStack_34 + 0x24);
          if (0x1f < (uint)((int)apiStack_48[0] + (-4 - (int)piVar6))) goto LAB_0092fd01;
        }
        uStack_78 = 0x92fbc6;
        piStack_74 = piVar6;
        FUN_01674ea0();
      }
      uStack_38 = 0;
      uStack_34 = 0xf;
      apiStack_48[0] = (int *)((uint)apiStack_48[0] & 0xffffff00);
      uStack_8._0_1_ = 1;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 1;
      if (0xf < uStack_4c) {
        ppiStack_70 = (int **)(uStack_4c + 1);
        uVar7 = auStack_60[0];
        if (0xfff < ppiStack_70) {
          uVar7 = *(uint *)(auStack_60[0] - 4);
          ppiStack_70 = (int **)(uStack_4c + 0x24);
          if (0x1f < (auStack_60[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
            ppiStack_70 = (int **)0x92fd0b;
            uStack_8._0_1_ = uVar4;
            FUN_017167a3();
          }
        }
        uStack_78 = 0x92fc10;
        piStack_74 = (int *)uVar7;
        FUN_01674ea0();
      }
      if (param_5 != (int *)0x0) {
        LOCK();
        param_5[1] = param_5[1] + 1;
        UNLOCK();
      }
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      ppiStack_70 = (int **)&uStack_24;
      uStack_24 = 0;
      iStack_20 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      uStack_18 = 0;
      iStack_14 = 0;
      uStack_2c = 0;
      uStack_78 = param_4;
      piStack_74 = param_5;
      uStack_84 = param_1;
      uStack_28 = 0;
      iStack_80 = param_2;
      piStack_7c = param_3;
      iVar5 = FUN_00925580(uVar3);
      if (param_3 != (int *)0x0) {
        LOCK();
        piVar6 = param_3 + 1;
        iVar1 = *piVar6;
        iVar5 = *piVar6;
        *piVar6 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          ppiStack_70 = (int **)0x92fca2;
          (**(code **)*param_3)();
          LOCK();
          piVar6 = param_3 + 2;
          iVar1 = *piVar6;
          iVar5 = *piVar6;
          *piVar6 = iVar1 + -1;
          UNLOCK();
          if (iVar1 + -1 == 0) {
            ppiStack_70 = (int **)0x92fcb2;
            iVar5 = (**(code **)(*param_3 + 4))();
          }
        }
      }
      if (param_5 != (int *)0x0) {
        LOCK();
        piVar6 = param_5 + 1;
        iVar1 = *piVar6;
        iVar5 = *piVar6;
        *piVar6 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          ppiStack_70 = (int **)0x92fcc8;
          iVar5 = (**(code **)*param_5)();
          LOCK();
          piVar6 = param_5 + 2;
          iVar1 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            ppiStack_70 = (int **)0x92fcd7;
            iVar5 = (**(code **)(*param_5 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar5;
    }
  }
  ppiStack_70 = (int **)0x193229c;
  piStack_74 = (int *)0x92fcf7;
  ppiStack_70 = (int **)FUN_0091a050();
  uStack_8._0_1_ = 3;
  piStack_74 = (int *)0x92fd01;
  FUN_00917680();
  uVar4 = (undefined)uStack_8;
LAB_0092fd01:
  uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
  ppiStack_70 = (int **)0x92fd06;
  FUN_017167a3();
}



/* FUNCTION 16642 ; VA 0x0092fd30 ; FUN_0092fd30 */

void FUN_0092fd30(void)

{
  FUN_0068c610();
  return;
}



/* FUNCTION 16643 ; VA 0x0092fd40 ; FUN_0092fd40 */

void FUN_0092fd40(int param_1)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined auStack_4c [20];
  undefined4 uStack_38;
  undefined4 *puStack_34;
  undefined *puStack_30;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9118;
  pvStack_10 = ExceptionList;
  puStack_34 = &uStack_20;
  uStack_8 = 0;
  uStack_38 = 0x92fd71;
  ExceptionList = &pvStack_10;
  FUN_0060e0c0();
  puStack_14 = auStack_4c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[2] = piStack_1c[2] + 1;
    UNLOCK();
    LOCK();
    piStack_1c[2] = piStack_1c[2] + 1;
    UNLOCK();
  }
  FUN_00912b40(uStack_20,piStack_1c,0);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[2] + -1;
    piStack_1c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  uStack_8._0_1_ = 2;
  FUN_0054ef60(&param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0091ef70();
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_30 = (undefined *)0x92fdfc;
      (**(code **)(*piStack_1c + 4))();
    }
  }
  if (0xf < in_stack_00000018) {
    puStack_30 = (undefined *)(in_stack_00000018 + 1);
    iVar2 = param_1;
    if (0xfff < puStack_30) {
      iVar2 = *(int *)(param_1 + -4);
      puStack_30 = (undefined *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_30 = &UNK_0092fe44;
        FUN_017167a3();
      }
    }
    uStack_38 = 0x92fe29;
    puStack_34 = (undefined4 *)iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16644 ; VA 0x0092fe50 ; FUN_0092fe50 */

void __thiscall FUN_0092fe50(int param_1,undefined *param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  
  if ((((param_2 == &DAT_0211da48) && (iVar1 = FUN_008f7870(param_1), iVar1 != 0)) &&
      (*(int *)(iVar1 + 0x4a0) == 2)) &&
     (*(int *)(param_1 + 0x300) = *(int *)(param_1 + 0x300) + 1,
     DAT_01d640b0 < *(int *)(param_1 + 0x300))) {
    return;
  }
  FUN_009cba80(param_2,param_3,param_4);
  return;
}



/* FUNCTION 16645 ; VA 0x0092fea0 ; FUN_0092fea0 */

void __thiscall FUN_0092fea0(int param_1,byte param_2)

{
  *(byte *)(param_1 + 0x444) = *(byte *)(param_1 + 0x444) | param_2;
  return;
}



/* FUNCTION 16646 ; VA 0x0092feb0 ; FUN_0092feb0 */

int * __fastcall FUN_0092feb0(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  char cVar5;
  int *piVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 uVar9;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_30 [4];
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9558;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar5 = FUN_00971ce0(param_1,1);
  if (cVar5 == '\0') {
    FUN_00550130("rebuildBackpack can only be called by the backend server");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_30,&DAT_01c17198);
  }
  piVar6 = (int *)FUN_0068f830();
  while (piVar6 != (int *)0x0) {
    (**(code **)(*piVar6 + 0x2c))();
    piVar6 = (int *)FUN_0068f830();
  }
  puVar7 = (undefined4 *)FUN_00915f80(auStack_2c);
  uStack_24 = *puVar7;
  piStack_20 = (int *)puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  uStack_8 = 0;
  piStack_1c = piStack_20;
  uStack_18 = uStack_24;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar3 = piStack_28[2] + -1;
      piStack_28[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  piVar6 = (int *)FUN_008a65e0(param_1,0);
  if (param_1 != (int *)0x0) {
    piStack_14 = (int *)param_1[0xd];
    piVar6 = param_1;
    if ((piStack_14 != (int *)0x0) && (piVar6 = piStack_14, piStack_14[0xd] != 0)) {
      piVar6 = (int *)FUN_005c8ac0();
    }
    piStack_14 = piVar6;
    piVar6 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      iVar3 = piStack_14[3];
      iVar8 = FUN_008a8c30();
      piVar6 = (int *)(uint)*(ushort *)(iVar8 + 0x1da);
      if ((int *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) <= piVar6) {
        FUN_005789c0(&DAT_01eadd44,&LAB_00670d40);
        uVar9 = FUN_006762b0();
        piStack_14 = (int *)FUN_008aa140(uVar9);
        if (*piStack_14 == 0) {
          uVar9 = FUN_00bd3b90();
          piVar6 = (int *)FUN_008a9ba0(auStack_38,uVar9);
          iVar3 = *piVar6;
          iVar8 = piVar6[1];
          *piVar6 = 0;
          piVar6[1] = 0;
          *piStack_14 = iVar3;
          piVar6 = (int *)piStack_14[1];
          piStack_14[1] = iVar8;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar3 = piVar6[1] + -1;
            piVar6[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar3 = piVar6[2] + -1;
              piVar6[2] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          if (piStack_34 != (int *)0x0) {
            LOCK();
            iVar3 = piStack_34[1] + -1;
            piStack_34[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piStack_34)();
              LOCK();
              iVar3 = piStack_34[2] + -1;
              piStack_34[2] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piStack_34 + 4))();
              }
            }
          }
        }
        piVar6 = (int *)*piStack_14;
        if (piVar6 != (int *)0x0) {
          piVar6 = (int *)FUN_00920f30(piVar6,uStack_18);
        }
      }
    }
  }
  puVar7 = (undefined4 *)param_1[0xb];
  if (puVar7 != (undefined4 *)0x0) {
    puVar2 = (undefined4 *)puVar7[1];
    for (puVar7 = (undefined4 *)*puVar7; puVar7 != puVar2; puVar7 = puVar7 + 2) {
      piVar6 = (int *)*puVar7;
      piStack_14 = piVar6;
      if (piVar6 != (int *)0x0) {
        iVar3 = piVar6[3];
        iVar8 = FUN_00bd39b0();
        piVar6 = (int *)(uint)*(ushort *)(iVar8 + 0x1da);
        if ((int *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) <= piVar6)
        {
          piVar6 = piStack_14;
          if (piStack_14 != (int *)0x0) {
            piVar6 = (int *)FUN_00920f30(piStack_14,uStack_18);
          }
          break;
        }
      }
    }
  }
  piVar4 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar3 = *piVar1;
    piVar6 = (int *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piVar6 = (int *)(**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piVar6 = (int *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar6;
}



/* FUNCTION 16647 ; VA 0x00930130 ; FUN_00930130 */

void __fastcall FUN_00930130(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_009173a0(param_1);
  iVar2 = FUN_00676db0();
  if ((iVar2 != 0) && (iVar1 != 0)) {
    if (*(char *)(param_1 + 0x4c8) == '\0') {
      FUN_00b61b10(*(undefined4 *)(iVar1 + 0xe0));
      FUN_00920fe0(iVar1,iVar2,1);
      *(undefined *)(param_1 + 0x4c8) = 1;
      return;
    }
    if (*(char *)(iVar1 + 0xdd) != '\0') {
      FUN_00b61b10(*(undefined4 *)(iVar1 + 0xe0));
      FUN_00b61290();
      FUN_00920fe0(iVar1,iVar2,0);
    }
  }
  return;
}



/* FUNCTION 16648 ; VA 0x009301b0 ; FUN_009301b0 */

void __fastcall FUN_009301b0(int param_1)

{
  if (*(char *)(param_1 + 0x268) != '\0') {
    FUN_00930130();
    *(undefined *)(param_1 + 0x268) = 0;
  }
  return;
}



/* FUNCTION 16649 ; VA 0x009301d0 ; FUN_009301d0 */

uint __fastcall FUN_009301d0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  char cVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  undefined auStack_28 [12];
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9138;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  cVar6 = FUN_0097c970(param_1,1);
  if (cVar6 == '\0') {
    FUN_00550130("rebuildPlayerScripts can only be called by the client");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_28,&DAT_01c17198);
  }
  puVar3 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar3 != (undefined4 *)0x0) {
    piVar4 = (int *)puVar3[1];
    for (piVar9 = (int *)*puVar3; piVar9 != piVar4; piVar9 = piVar9 + 2) {
      if (*piVar9 != 0) {
        iVar5 = *(int *)(*piVar9 + 0xc);
        iVar7 = FUN_00c4b770();
        if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
            (uint)*(ushort *)(iVar7 + 0x1da)) {
          ExceptionList = pvStack_10;
          return (uint)*(ushort *)(iVar7 + 0x1da);
        }
      }
      param_1 = iStack_14;
    }
  }
  uVar8 = FUN_00916720(&iStack_1c);
  uStack_8 = 0;
  if (iStack_1c != 0) {
    uVar8 = FUN_008a65e0(param_1,0);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_18 + 1);
    uVar2 = *puVar1;
    uVar8 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar8 = (**(code **)*piStack_18)();
      LOCK();
      piVar4 = piStack_18 + 2;
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uVar8 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 16650 ; VA 0x009302c0 ; FUN_009302c0 */

void __thiscall FUN_009302c0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) - *(int *)(*(int *)(*param_2 + 0x10) + 0x10);
  piVar1 = *(int **)(*param_2 + 0x10);
  *(int *)piVar1[1] = *piVar1;
  *(int *)(*piVar1 + 4) = piVar1[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  piVar2 = (int *)piVar1[6];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar4 = piVar2 + 2;
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(piVar1,0x20);
  param_2 = (int *)*param_2;
  piVar1 = (int *)*param_2;
  uVar5 = (uint)param_2[1] % *(uint *)(param_1 + 0x10);
  piVar2 = *(int **)(*(int *)(param_1 + 0x20) + uVar5 * 4);
  for (piVar4 = (int *)*piVar2; piVar4 != param_2; piVar4 = (int *)*piVar4) {
    piVar2 = piVar4;
  }
  do {
    *piVar2 = *piVar4;
    FUN_01674ea0(piVar4,0x18);
    *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
    uVar6 = uVar5;
    if (*piVar2 == 0) {
LAB_0093037c:
      if (*(int **)(*(int *)(param_1 + 0x20) + uVar5 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x20) + uVar5 * 4) = 0;
      }
    }
    else {
      uVar6 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 0x10);
      if (uVar5 != uVar6) {
        *(int **)(*(int *)(param_1 + 0x20) + uVar6 * 4) = piVar2;
        goto LAB_0093037c;
      }
    }
    piVar4 = (int *)*piVar2;
    uVar5 = uVar6;
    if (piVar4 == piVar1) {
      return;
    }
  } while( true );
}



/* FUNCTION 16651 ; VA 0x009303a0 ; FUN_009303a0 */

void __fastcall FUN_009303a0(undefined4 param_1)

{
  char cVar1;
  undefined auStack_10 [12];
  
  cVar1 = FUN_00971ce0(param_1,1);
  if (cVar1 != '\0') {
    if (DAT_01ee420a != '\0') {
      FUN_016774b0(DAT_01ee420a,"Player:removeCharacter",0);
    }
    FUN_009326f0(0);
    return;
  }
  FUN_00550130("RemoveCharacter can only be called by the backend server");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 16652 ; VA 0x00930400 ; FUN_00930400 */

void __fastcall FUN_00930400(int param_1)

{
  code *pcStack_8;
  
  if (*(int *)(param_1 + 100) != 0) {
    pcStack_8 = FUN_00932470;
    FUN_008ad320(&pcStack_8);
  }
  return;
}



/* FUNCTION 16653 ; VA 0x00930420 ; FUN_00930420 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00930420(int param_1,undefined4 param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  float fVar6;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  float fStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  float fStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  float fStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [4];
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  uStack_5c = _DAT_018e3fb0;
  uStack_58 = _UNK_018e3fb4;
  fStack_54 = _UNK_018e3fb8;
  uStack_50 = _UNK_018e3fbc;
  uStack_4c = _DAT_018e3fb0;
  uStack_48 = _UNK_018e3fb4;
  fStack_44 = _UNK_018e3fb8;
  uStack_40 = _UNK_018e3fbc;
  uStack_3c = _DAT_018e3fb0;
  uStack_38 = _UNK_018e3fb4;
  fStack_34 = _UNK_018e3fb8;
  uStack_30 = _UNK_018e3fbc;
  iVar1 = FUN_00927e40(&uStack_5c);
  if (((((iVar1 != 0) && (*(int *)(param_1 + 100) != 0)) &&
       (iVar1 = FUN_009b48f0(*(int *)(param_1 + 100)), iVar1 != 0)) &&
      ((*(int *)(iVar1 + 0xa8) != 0 && (iVar1 = FUN_00c155c0(), iVar1 != 0)))) &&
     (iStack_8 = FUN_00ca1550(), iStack_8 != 0)) {
    piVar2 = (int *)FUN_00927d50(auStack_28);
    fVar6 = DAT_018df580;
    if (*piVar2 != 0) {
      fVar6 = 0.0;
    }
    fStack_34 = fStack_34 - fVar6;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_24[1] + -1;
      piStack_24[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar2 = piStack_24 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    puVar3 = (undefined4 *)FUN_00f81b20(auStack_2c,*(undefined4 *)(iStack_8 + 0x1dc));
    uStack_c = 0x3f19999a;
    uStack_1c = *puVar3;
    uStack_20 = puVar3[1];
    piStack_24 = (int *)puVar3[2];
    iStack_8 = *(undefined4 *)(param_1 + 0x188);
    uStack_18 = uStack_1c;
    uStack_14 = uStack_20;
    uStack_10 = piStack_24;
    uVar4 = FUN_00709da0(&uStack_38);
    FUN_0114ad50(param_2,uVar4,1,0x3f800000,iStack_8,&uStack_18,0);
    iVar1 = FUN_005c3ac0(param_1);
    if ((iVar1 != 0) && (*(char *)(iVar1 + 0x300) != '\0')) {
      uStack_18 = uStack_1c;
      uStack_14 = uStack_20;
      uStack_10 = piStack_24;
      uVar4 = *(undefined4 *)(param_1 + 0x18c);
      uStack_c = 0x3e99999a;
      uVar5 = FUN_00709da0(&uStack_38);
      FUN_0114ad50(param_2,uVar5,1,0x3f800000,uVar4,&uStack_18,0);
    }
  }
  return;
}



/* FUNCTION 16654 ; VA 0x00930610 ; FUN_00930610 */

void __fastcall FUN_00930610(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_005eef10(param_1);
  if (iVar1 != 0) {
    iVar1 = FUN_00688090();
    if (iVar1 != 0) {
      FUN_006f36c0();
      return;
    }
  }
  return;
}



/* FUNCTION 16655 ; VA 0x00930640 ; FUN_00930640 */

void FUN_00930640(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  code *pcVar1;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c917c;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_1c8 = FUN_0088da50();
  uStack_1c0 = param_2;
  uStack_1c4 = 0;
  uStack_1bc = param_3;
  uStack_1c4 = FUN_005c9e80();
  uStack_8 = 0;
  uStack_f8 = thunk_FUN_00bfa7a0();
  uStack_f4 = 0;
  uStack_f0 = param_4;
  uStack_f4 = FUN_009361b0();
  uStack_8 = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_1c8,&uStack_28,param_1);
  uStack_8._0_1_ = 2;
  (*pcVar1)(uStack_14,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_1c8,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16656 ; VA 0x00930760 ; FUN_00930760 */

uint __thiscall FUN_00930760(int param_1,undefined4 param_2,char param_3,char param_4)

{
  undefined uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 ****ppppuVar5;
  undefined *puVar6;
  uint uVar7;
  uint uVar8;
  bool bVar9;
  undefined8 uVar10;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  double dStack_98;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  undefined4 ***apppuStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  undefined8 uStack_50;
  double dStack_48;
  undefined auStack_40 [4];
  char *pcStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c91e6;
  pvStack_10 = ExceptionList;
  uStack_1c = *(uint *)(param_1 + 0x438) | *(uint *)(param_1 + 0x43c);
  ExceptionList = &pvStack_10;
  if (uStack_1c == 0) {
    ExceptionList = &pvStack_10;
    uVar2 = FUN_01679ce0();
    uStack_1c = uVar2 / DAT_01d640dc;
    if (DAT_01d64214 == '\0') {
      bVar9 = uVar2 % DAT_01d640dc == 1;
    }
    else {
      bVar9 = uVar2 % DAT_01d640dc == 0;
    }
    if (bVar9) {
      FUN_016830f0(auStack_40);
      uVar10 = FUN_01682de0();
      uStack_1c = (uint)uVar10;
      *(undefined8 *)(param_1 + 0x438) = uVar10;
    }
    else {
      *(undefined4 *)(param_1 + 0x43c) = 0xffffffff;
      *(undefined4 *)(param_1 + 0x438) = 0xffffffff;
    }
  }
  if (-1 < *(int *)(param_1 + 0x43c)) {
    FUN_016830f0(auStack_40);
    iVar3 = FUN_01682de0();
    uStack_1c = 0;
    iVar3 = iVar3 - *(int *)(param_1 + 0x438);
    pcStack_3c = "CharacterLoadTime";
    puStack_18 = (uint *)0x0;
    if (param_4 == '\0') {
      pcStack_3c = "ThumbnailingCharacterLoadTime";
    }
    puStack_14 = (uint *)0x0;
    puVar6 = &DAT_018ceea4;
    if (param_3 == '\0') {
      puVar6 = &DAT_018ceea8;
    }
    uStack_8 = 0;
    FUN_01675640(auStack_90,"%s_%s",pcStack_3c,param_2);
    uStack_8._0_1_ = 1;
    FUN_0054ef60(auStack_90);
    uStack_60 = uStack_38;
    uStack_38 = uStack_38 & 0xffffff00;
    uVar10 = CONCAT44(uStack_24,uStack_28);
    dStack_48 = (double)iVar3;
    uStack_28 = 0;
    uStack_24 = 0xf;
    uStack_5c = uStack_34;
    uStack_58 = uStack_30;
    uStack_54 = uStack_2c;
    uStack_8._0_1_ = 3;
    iStack_20 = iVar3;
    if (puStack_14 == puStack_18) {
      uStack_50 = uVar10;
      FUN_00603540(puStack_18,&uStack_60);
    }
    else {
      puStack_18[4] = 0;
      uStack_50._4_4_ = 0xf;
      *puStack_18 = uStack_60;
      puStack_18[1] = uStack_34;
      puStack_18[2] = uStack_30;
      puStack_18[3] = uStack_2c;
      uStack_60 = uStack_60 & 0xffffff00;
      *(undefined8 *)(puStack_18 + 4) = uVar10;
      *(double *)(puStack_18 + 6) = dStack_48;
      puStack_18 = puStack_18 + 8;
    }
    uStack_8._0_1_ = 2;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_50._4_4_) {
      uVar7 = uStack_50._4_4_ + 1;
      uVar2 = uStack_60;
      if (0xfff < uVar7) {
        uVar2 = *(uint *)(uStack_60 - 4);
        uVar7 = uStack_50._4_4_ + 0x24;
        if (0x1f < (uStack_60 - uVar2) - 4) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar7);
    }
    uStack_8._0_1_ = 1;
    FUN_01675640(apppuStack_78,"%s_%s_%s",pcStack_3c,param_2,puVar6);
    uStack_8._0_1_ = 4;
    FUN_0054ef60(apppuStack_78);
    uStack_60 = uStack_38;
    uStack_38 = uStack_38 & 0xffffff00;
    uStack_50 = CONCAT44(uStack_24,uStack_28);
    dStack_48 = (double)iVar3;
    uStack_28 = 0;
    uStack_24 = 0xf;
    uStack_5c = uStack_34;
    uStack_58 = uStack_30;
    uStack_54 = uStack_2c;
    uStack_8._0_1_ = 6;
    if (puStack_14 == puStack_18) {
      iStack_20 = iVar3;
      FUN_00603540(puStack_18,&uStack_60);
      uVar2 = uStack_50._4_4_;
    }
    else {
      puStack_18[4] = 0;
      *puStack_18 = uStack_60;
      puStack_18[1] = uStack_34;
      puStack_18[2] = uStack_30;
      puStack_18[3] = uStack_2c;
      uStack_60 = uStack_60 & 0xffffff00;
      *(undefined8 *)(puStack_18 + 4) = uStack_50;
      *(double *)(puStack_18 + 6) = dStack_48;
      puStack_18 = puStack_18 + 8;
      uVar2 = 0xf;
      iStack_20 = iVar3;
    }
    uStack_8._0_1_ = 5;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (0xf < uVar2) {
      uVar8 = uVar2 + 1;
      uVar7 = uStack_60;
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(uStack_60 - 4);
        uVar8 = uVar2 + 0x24;
        if (0x1f < (uStack_60 - uVar7) - 4) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_8._0_1_ = 4;
    iVar4 = FUN_008f7870(param_1);
    if (iVar4 != 0) {
      ppppuVar5 = apppuStack_78;
      if (0xf < uStack_64) {
        ppppuVar5 = (undefined4 ****)apppuStack_78[0];
      }
      FUN_01675640(&uStack_58,"%s_Datacenter_%d",ppppuVar5,*(undefined4 *)(iVar4 + 0x44c));
      uStack_8._0_1_ = 7;
      FUN_0054ef60(&uStack_58);
      uStack_b0 = uStack_38;
      uStack_38 = uStack_38 & 0xffffff00;
      uStack_ac = uStack_34;
      uStack_a8 = uStack_30;
      uStack_a4 = uStack_2c;
      uStack_a0 = CONCAT44(uStack_24,uStack_28);
      dStack_98 = (double)iVar3;
      uStack_28 = 0;
      uStack_24 = 0xf;
      uStack_8._0_1_ = 9;
      iStack_20 = iVar3;
      FUN_00625cd0(&uStack_b0);
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 4;
      FUN_005507b0();
    }
    FUN_00874d70(&uStack_1c,0);
    if (0xf < uStack_64) {
      uVar2 = uStack_64 + 1;
      ppppuVar5 = (undefined4 ****)apppuStack_78[0];
      if (0xfff < uVar2) {
        ppppuVar5 = (undefined4 ****)apppuStack_78[0][-1];
        uVar2 = uStack_64 + 0x24;
        if (0x1f < (uint)((int)apppuStack_78[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar5,uVar2);
    }
    uStack_68 = 0;
    uStack_64 = 0xf;
    apppuStack_78[0] = (undefined4 ***)((uint)apppuStack_78[0] & 0xffffff00);
    if (0xf < uStack_7c) {
      uVar7 = uStack_7c + 1;
      uVar2 = auStack_90[0];
      if (0xfff < uVar7) {
        uVar2 = *(uint *)(auStack_90[0] - 4);
        uVar7 = uStack_7c + 0x24;
        if (0x1f < (auStack_90[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar7);
    }
    uStack_80 = 0;
    uStack_7c = 0xf;
    auStack_90[0] = auStack_90[0] & 0xffffff00;
    if (uStack_1c != 0) {
      FUN_00559500(uStack_1c,puStack_18,&uStack_1c);
      uVar7 = (int)puStack_14 - uStack_1c & 0xffffffe0;
      uVar2 = uStack_1c;
      if (0xfff < uVar7) {
        uVar2 = *(uint *)(uStack_1c - 4);
        uVar7 = uVar7 + 0x23;
        if (0x1f < (uStack_1c - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_1c = FUN_01674ea0(uVar2,uVar7);
    }
  }
  ExceptionList = pvStack_10;
  return uStack_1c;
}



/* FUNCTION 16657 ; VA 0x00930bd0 ; FUN_00930bd0 */

void __thiscall FUN_00930bd0(int *param_1,int param_2)

{
  code *pcVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint in_stack_00000018;
  undefined4 in_stack_fffffe8c;
  undefined4 in_stack_fffffe90;
  undefined4 in_stack_fffffe94;
  undefined4 in_stack_fffffe98;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uStack_154;
  undefined4 uStack_150;
  uint uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined8 uStack_13c;
  uint uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  uint uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9231;
  pvStack_10 = ExceptionList;
  puVar6 = &param_2;
  uStack_8 = 0;
  uVar5 = 0x930c05;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(puVar6);
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_44 = uStack_5c;
  uStack_40 = uStack_58;
  uStack_3c = uStack_54;
  uStack_38 = uStack_50;
  uStack_5c = uStack_5c & 0xffffff00;
  uStack_34 = CONCAT44(uStack_48,uStack_4c);
  uStack_4c = 0;
  uStack_48 = 0xf;
  uStack_8._0_1_ = 2;
  FUN_0054ef60(&uStack_44);
  FUN_00925c80(param_1,in_stack_fffffe8c,in_stack_fffffe90,in_stack_fffffe94,in_stack_fffffe98,uVar5
               ,puVar6);
  uStack_84 = uStack_44;
  uStack_44 = uStack_44 & 0xffffff00;
  uStack_80 = uStack_40;
  uStack_7c = uStack_3c;
  uStack_78 = uStack_38;
  uStack_74 = uStack_84;
  uStack_70 = uStack_40;
  uStack_6c = uStack_3c;
  uStack_68 = uStack_38;
  uStack_24 = uStack_34;
  uStack_64 = uStack_34;
  uStack_34 = 0xf00000000;
  uStack_8._0_1_ = 3;
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_154 = FUN_0088cb40();
  uStack_150 = 0;
  uStack_14c = uStack_84;
  uStack_148 = uStack_80;
  uStack_144 = uStack_7c;
  uStack_140 = uStack_78;
  uStack_13c = uStack_24;
  uStack_64 = 0xf00000000;
  uStack_74 = uStack_74 & 0xffffff00;
  uStack_150 = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_154,&uStack_84,in_stack_00000018);
  uStack_8._0_1_ = 5;
  (*pcVar1)(&DAT_0211efe8,&uStack_1c,&uStack_2c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_016f32d1(&uStack_154,0xd0,1,FUN_0056e5b0);
  if (0xf < uStack_48) {
    uVar3 = uStack_48 + 1;
    uVar4 = uStack_5c;
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(uStack_5c - 4);
      uVar3 = uStack_48 + 0x24;
      if (0x1f < (uStack_5c - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    iVar2 = param_2;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(param_2 + -4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16658 ; VA 0x00930dc0 ; FUN_00930dc0 */

/* WARNING: Removing unreachable block (ram,0x00930f14) */
/* WARNING: Removing unreachable block (ram,0x00931102) */

void __fastcall FUN_00930dc0(int param_1)

{
  int *piVar1;
  int *piVar2;
  undefined *puVar3;
  char cVar4;
  uint *puVar5;
  int iVar6;
  longlong lVar7;
  undefined auStack_b8 [4];
  undefined4 uStack_b4;
  undefined *puStack_b0;
  char *pcStack_ac;
  undefined1 *puStack_a8;
  undefined4 uStack_a4;
  undefined auStack_a0 [4];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  int *piStack_94;
  undefined1 *puStack_90;
  undefined4 uStack_8c;
  undefined4 auStack_88 [5];
  undefined4 uStack_74;
  undefined *puStack_70;
  undefined4 uStack_6c;
  undefined auStack_68 [12];
  undefined4 uStack_5c;
  undefined1 *puStack_58;
  undefined *puStack_54;
  undefined4 *puStack_50;
  char *pcStack_4c;
  undefined auStack_34 [4];
  undefined4 uStack_30;
  int *piStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined1 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c92b8;
  pvStack_10 = ExceptionList;
  pcStack_4c = &stack0x00000004;
  uStack_8 = 1;
  puStack_50 = &uStack_30;
  puStack_54 = (undefined *)0x930e06;
  ExceptionList = &pvStack_10;
  puVar5 = (uint *)FUN_00562c90();
  piVar2 = piStack_2c;
  puStack_1c = (undefined *)*puVar5;
  *puVar5 = 0;
  puVar5[1] = 0;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      pcStack_4c = (char *)0x930e3d;
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        pcStack_4c = (char *)0x930e4d;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (puStack_1c == (undefined *)0x0) {
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "RequestFriendship should be passed a Player";
    puStack_54 = (undefined *)0x9312ed;
    FUN_016756b0();
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "";
                    /* WARNING: Subroutine does not return */
    puStack_54 = (undefined *)0x9312fe;
    FUN_0170c2a8();
  }
  if (DAT_01d640b0 < *(int *)(param_1 + 0x300)) {
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "RequestFriendship rate limit reached.";
    puStack_54 = (undefined *)0x93130c;
    FUN_016756b0();
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "";
                    /* WARNING: Subroutine does not return */
    puStack_54 = (undefined *)0x93131d;
    FUN_0170c2a8();
  }
  pcStack_4c = (char *)0x1;
  *(int *)(param_1 + 0x300) = *(int *)(param_1 + 0x300) + 1;
  puStack_54 = (undefined *)0x930e78;
  puStack_50 = (undefined4 *)param_1;
  cVar4 = FUN_00971ce0();
  if (cVar4 != '\0') {
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "RequestFriendship must be called from local script";
    puStack_54 = (undefined *)0x93132b;
    FUN_016756b0();
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "";
                    /* WARNING: Subroutine does not return */
    puStack_54 = (undefined *)0x93133c;
    FUN_0170c2a8();
  }
  puStack_50 = (undefined4 *)0x930e89;
  pcStack_4c = (char *)param_1;
  puStack_20 = (undefined *)FUN_00917170();
  if (puStack_20 == (undefined *)0x0) {
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "No FriendService";
    puStack_54 = (undefined *)0x93134a;
    FUN_016756b0();
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "";
                    /* WARNING: Subroutine does not return */
    puStack_54 = &UNK_0093135b;
    FUN_0170c2a8();
  }
  puStack_50 = &uStack_30;
  puStack_54 = (undefined *)0x930ea3;
  pcStack_4c = (char *)param_1;
  FUN_0060e0c0();
  puVar3 = puStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_1c = (undefined *)((uint)puStack_1c & 0xffffff00);
  puStack_50 = *(undefined4 **)((int)puVar3 + 0xf0);
  pcStack_4c = *(char **)((int)puVar3 + 0xf4);
  puStack_54 = *(undefined **)(param_1 + 0xf4);
  puStack_58 = *(undefined1 **)(param_1 + 0xf0);
  uStack_5c = 0x930ed8;
  puStack_18 = (undefined1 *)puStack_50;
  uStack_14 = pcStack_4c;
  iVar6 = FUN_00bf1ef0();
  if (iVar6 == 1) {
    pcStack_4c = (char *)0x0;
    puStack_50 = (undefined4 *)0x64;
    puStack_54 = *(undefined **)(param_1 + 0xf4);
    puStack_58 = *(undefined1 **)(param_1 + 0xf0);
    uStack_5c = 0x930ef9;
    lVar7 = FUN_016f4270();
    puStack_20 = (undefined *)(lVar7 + 1);
    if (lVar7 + 1 <= (longlong)DAT_01ee1b78) {
      puStack_20 = auStack_68;
      uStack_6c = 0;
      puStack_70 = puStack_1c;
      uStack_74 = 0x930f2f;
      FUN_00912af0();
      puStack_1c = (undefined *)auStack_88;
      if (piStack_2c != (int *)0x0) {
        piVar2 = piStack_2c + 2;
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      auStack_88[0] = 0;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[2] = piStack_2c[2] + 1;
        UNLOCK();
      }
      uStack_98 = uStack_30;
      piStack_94 = piStack_2c;
      puStack_90 = puStack_18;
      uStack_8c = uStack_14;
      uStack_9c = 0x930f7f;
      FUN_00915010();
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_8c = 0x930f95;
          (**(code **)(*piStack_2c + 4))();
        }
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_8c = 0x930fa7;
          (**(code **)(*piStack_2c + 4))();
        }
      }
      puStack_24 = auStack_a0;
      uStack_8._0_1_ = 4;
      uStack_a4 = 0;
      puStack_90 = (undefined1 *)0x0;
      uStack_8c = 0xf;
      puStack_a8 = &DAT_018bc9b8;
      auStack_a0[0] = 0;
      pcStack_ac = (char *)0x930fd0;
      FUN_005542c0();
      uStack_8._0_1_ = 5;
      FUN_00f82690(auStack_b8,puStack_18,uStack_14);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00bf6aa0(param_1);
      goto LAB_009312a9;
    }
    puStack_28 = auStack_68;
    uStack_6c = 0;
    puStack_70 = puStack_1c;
    uStack_74 = 0x931009;
    FUN_00912af0();
    puStack_24 = (undefined *)auStack_88;
    if (piStack_2c != (int *)0x0) {
      piVar2 = piStack_2c + 2;
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    auStack_88[0] = 0;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[2] = piStack_2c[2] + 1;
      UNLOCK();
    }
    uStack_98 = uStack_30;
    piStack_94 = piStack_2c;
    puStack_90 = puStack_18;
    uStack_8c = uStack_14;
    uStack_9c = 0x931059;
    FUN_00915250();
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_8c = 0x93106f;
        (**(code **)(*piStack_2c + 4))();
      }
      LOCK();
      iVar6 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_8c = 0x931081;
        (**(code **)(*piStack_2c + 4))();
      }
    }
    puStack_20 = auStack_a0;
    puStack_b0 = auStack_a0;
    uStack_8._0_1_ = 7;
    uStack_a4 = uStack_14;
    puStack_a8 = puStack_18;
    pcStack_ac = "recipientUserId=%lld";
    uStack_b4 = 0x93109e;
    FUN_01675640();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_00f82660(auStack_b8);
  }
  else {
    pcStack_4c = *(char **)(param_1 + 0xf4);
    puStack_50 = *(undefined4 **)(param_1 + 0xf0);
    puStack_54 = (undefined *)uStack_14;
    puStack_58 = puStack_18;
    uStack_5c = 0x9310ca;
    cVar4 = FUN_00bf3600();
    if (cVar4 == '\0') goto LAB_009312a9;
    pcStack_4c = (char *)0x0;
    puStack_50 = (undefined4 *)0x64;
    puStack_54 = *(undefined **)(param_1 + 0xf4);
    puStack_58 = *(undefined1 **)(param_1 + 0xf0);
    uStack_5c = 0x9310e7;
    lVar7 = FUN_016f4270();
    puStack_20 = (undefined *)(lVar7 + 1);
    if (lVar7 + 1 <= (longlong)DAT_01ee1b78) {
      puStack_28 = auStack_68;
      uStack_6c = 0;
      puStack_70 = puStack_1c;
      uStack_74 = 0x93111d;
      FUN_00912af0();
      puStack_24 = (undefined *)auStack_88;
      if (piStack_2c != (int *)0x0) {
        piVar2 = piStack_2c + 2;
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      auStack_88[0] = 0;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[2] = piStack_2c[2] + 1;
        UNLOCK();
      }
      uStack_98 = uStack_30;
      piStack_94 = piStack_2c;
      puStack_90 = puStack_18;
      uStack_8c = uStack_14;
      uStack_9c = 0x93116d;
      FUN_00914950();
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_8c = 0x931183;
          (**(code **)(*piStack_2c + 4))();
        }
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_8c = 0x931195;
          (**(code **)(*piStack_2c + 4))();
        }
      }
      puStack_20 = auStack_a0;
      uStack_8._0_1_ = 10;
      uStack_a4 = 0;
      puStack_90 = (undefined1 *)0x0;
      uStack_8c = 0xf;
      puStack_a8 = &DAT_018bc9b8;
      auStack_a0[0] = 0;
      pcStack_ac = (char *)0x9311be;
      FUN_005542c0();
      uStack_8._0_1_ = 0xb;
      FUN_00f81f50(auStack_b8,puStack_18,uStack_14);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00bf6aa0(param_1);
      goto LAB_009312a9;
    }
    puStack_28 = auStack_68;
    uStack_6c = 0;
    puStack_70 = puStack_1c;
    uStack_74 = 0x9311f7;
    FUN_00912af0();
    puStack_24 = (undefined *)auStack_88;
    if (piStack_2c != (int *)0x0) {
      piVar2 = piStack_2c + 2;
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    auStack_88[0] = 0;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[2] = piStack_2c[2] + 1;
      UNLOCK();
    }
    uStack_98 = uStack_30;
    piStack_94 = piStack_2c;
    puStack_90 = puStack_18;
    uStack_8c = uStack_14;
    uStack_9c = 0x931247;
    FUN_00914cb0();
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_8c = 0x93125d;
        (**(code **)(*piStack_2c + 4))();
      }
      LOCK();
      iVar6 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_8c = 0x93126f;
        (**(code **)(*piStack_2c + 4))();
      }
    }
    puStack_20 = auStack_a0;
    puStack_b0 = auStack_a0;
    uStack_8._0_1_ = 0xd;
    uStack_a4 = uStack_14;
    puStack_a8 = puStack_18;
    pcStack_ac = "requesterUserId=%lld";
    uStack_b4 = 0x93128c;
    FUN_01675640();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    FUN_00f81f20(auStack_b8);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00bf65c0(param_1);
LAB_009312a9:
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_2c + 2;
    iVar6 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      pcStack_4c = (char *)0x9312bc;
      (**(code **)(*piStack_2c + 4))();
    }
  }
  pcStack_4c = (char *)0x9312c4;
  FUN_00550b30();
  pcStack_4c = (char *)0x9312cc;
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16659 ; VA 0x00931360 ; FUN_00931360 */

void __thiscall
FUN_00931360(int param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,uint param_5,
            undefined4 param_6,uint param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11,uint param_12)

{
  code *pcVar1;
  undefined4 uVar2;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c92e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_2c = CONCAT44(DAT_01eaf294,0x931391);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (*(undefined4 **)(param_1 + 0x1ac) == (undefined4 *)0x0) {
    uStack_2c = 0xf00000000;
    uStack_3c = uStack_3c & 0xffffff00;
    FUN_005542c0();
    FUN_005e65e0();
  }
  else {
    pcVar1 = *(code **)**(undefined4 **)(param_1 + 0x1ac);
    if (param_5 != 0) {
      if ((param_5 & 1) == 0) {
        (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_3c,0);
      }
      else {
        uStack_3c = param_7;
        uStack_38 = param_8;
        uStack_34 = param_9;
        puStack_30 = (undefined4 *)param_10;
        uStack_2c = param_11;
      }
    }
    (*pcVar1)(param_2,param_3,param_4);
  }
  uStack_8._0_1_ = 3;
  uStack_2c = CONCAT44(uVar2,0x93144c);
  FUN_01675290();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_30 = &param_7;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x931470;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = (undefined4 *)&stack0x00000040;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x93149e;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16660 ; VA 0x009314c0 ; FUN_009314c0 */

void __thiscall FUN_009314c0(int param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  byte *pbVar3;
  int *piVar4;
  int iStack_8;
  
  uVar2 = *(uint *)(param_1 + 8);
  while (param_2 < uVar2) {
    pbVar3 = (byte *)(param_1 + 0xc) + *(byte *)(param_1 + 0xc) + 1;
    iVar1 = *(int *)(*(int *)(param_1 + 4) + 4);
    piVar4 = (int *)(iVar1 + 8);
    uVar2 = *(uint *)(iVar1 + 0xc);
    if (((int)uVar2 < 1) && ((int)uVar2 < 0)) {
      uVar2 = ~uVar2;
    }
    FUN_00606ff0(&iStack_8,(uVar2 >> 2) + uVar2 * 0x40 + *piVar4 ^ uVar2,piVar4,
                 -(uint)(pbVar3 != (byte *)0x0) & (uint)(pbVar3 + 1));
    if (iStack_8 != 0) {
      FUN_009302c0(&iStack_8);
    }
    uVar2 = *(uint *)(param_1 + 8);
  }
  return;
}



/* FUNCTION 16661 ; VA 0x00931550 ; FUN_00931550 */

void __thiscall FUN_00931550(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x28) = param_2;
  FUN_009314c0();
  return;
}



/* FUNCTION 16662 ; VA 0x00931570 ; FUN_00931570 */

int FUN_00931570(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9310;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_1c);
  uStack_8 = 0;
  if (iStack_1c != 0) {
    iStack_28 = 0;
    iStack_24 = 0;
    uStack_20 = 0;
    piVar1 = (int *)(iStack_1c + 0x308);
    uStack_8 = 1;
    if (piVar1 != &iStack_28) {
      iStack_28 = *piVar1;
      *piVar1 = 0;
      iStack_24 = *(int *)(iStack_1c + 0x30c);
      *(undefined4 *)(iStack_1c + 0x30c) = 0;
      uStack_20 = *(undefined4 *)(iStack_1c + 0x310);
      *(undefined4 *)(iStack_1c + 0x310) = 0;
    }
    iVar2 = iStack_24;
    *(undefined4 *)(iStack_1c + 0x304) = param_2;
    for (iVar3 = iStack_28; iVar3 != iVar2; iVar3 = iVar3 + 0x28) {
      uStack_14 = param_2;
      if (*(int **)(iVar3 + 0x24) == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddc9c();
      }
      (**(code **)(**(int **)(iVar3 + 0x24) + 8))(&uStack_14);
    }
    iVar3 = FUN_0091a5b0();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 16663 ; VA 0x00931655 ; FUN_00931655 */

void FUN_00931655(void)

{
  FUN_00931660();
  return;
}



/* FUNCTION 16664 ; VA 0x00931660 ; FUN_00931660 */

void __fastcall FUN_00931660(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00918f30(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c63f44);
}



/* FUNCTION 16665 ; VA 0x00931690 ; FUN_00931690 */

/* WARNING: Removing unreachable block (ram,0x009319d5) */
/* WARNING: Removing unreachable block (ram,0x009317e4) */
/* WARNING: Removing unreachable block (ram,0x00931bc6) */

void __fastcall FUN_00931690(int param_1)

{
  int *piVar1;
  int *piVar2;
  undefined *puVar3;
  char cVar4;
  uint *puVar5;
  int iVar6;
  longlong lVar7;
  undefined auStack_b8 [4];
  undefined4 uStack_b4;
  undefined *puStack_b0;
  char *pcStack_ac;
  undefined1 *puStack_a8;
  undefined4 uStack_a4;
  undefined auStack_a0 [4];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  int *piStack_94;
  undefined1 *puStack_90;
  undefined4 uStack_8c;
  undefined4 auStack_88 [5];
  undefined4 uStack_74;
  undefined *puStack_70;
  undefined4 uStack_6c;
  undefined auStack_68 [12];
  undefined4 uStack_5c;
  undefined1 *puStack_58;
  undefined *puStack_54;
  undefined4 *puStack_50;
  char *pcStack_4c;
  undefined auStack_34 [4];
  undefined4 uStack_30;
  int *piStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined1 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c93c8;
  pvStack_10 = ExceptionList;
  pcStack_4c = &stack0x00000004;
  uStack_8 = 1;
  puStack_50 = &uStack_30;
  puStack_54 = (undefined *)0x9316d6;
  ExceptionList = &pvStack_10;
  puVar5 = (uint *)FUN_00562c90();
  piVar2 = piStack_2c;
  puStack_1c = (undefined *)*puVar5;
  *puVar5 = 0;
  puVar5[1] = 0;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      pcStack_4c = (char *)0x93170d;
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        pcStack_4c = (char *)0x93171d;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (puStack_1c == (undefined *)0x0) {
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "RevokeFriendship should be passed a Player";
    puStack_54 = (undefined *)0x931dc7;
    FUN_016756b0();
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "";
                    /* WARNING: Subroutine does not return */
    puStack_54 = (undefined *)0x931dd8;
    FUN_0170c2a8();
  }
  if (DAT_01d640b0 < *(int *)(param_1 + 0x300)) {
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "RevokeFriendship rate limit reached.";
    puStack_54 = (undefined *)0x931de6;
    FUN_016756b0();
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "";
                    /* WARNING: Subroutine does not return */
    puStack_54 = (undefined *)0x931df7;
    FUN_0170c2a8();
  }
  pcStack_4c = (char *)0x1;
  *(int *)(param_1 + 0x300) = *(int *)(param_1 + 0x300) + 1;
  puStack_54 = (undefined *)0x931748;
  puStack_50 = (undefined4 *)param_1;
  cVar4 = FUN_00971ce0();
  if (cVar4 != '\0') {
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "Player:requestFriendship must be called from local script";
    puStack_54 = (undefined *)0x931e05;
    FUN_016756b0();
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "";
                    /* WARNING: Subroutine does not return */
    puStack_54 = (undefined *)0x931e16;
    FUN_0170c2a8();
  }
  puStack_50 = (undefined4 *)0x931759;
  pcStack_4c = (char *)param_1;
  puStack_20 = (undefined *)FUN_00917170();
  if (puStack_20 == (undefined *)0x0) {
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "No FriendService";
    puStack_54 = (undefined *)0x931e24;
    FUN_016756b0();
    puStack_50 = (undefined4 *)auStack_34;
    pcStack_4c = "";
                    /* WARNING: Subroutine does not return */
    puStack_54 = &UNK_00931e35;
    FUN_0170c2a8();
  }
  puStack_50 = &uStack_30;
  puStack_54 = (undefined *)0x931773;
  pcStack_4c = (char *)param_1;
  FUN_0060e0c0();
  puVar3 = puStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_1c = (undefined *)((uint)puStack_1c & 0xffffff00);
  puStack_50 = *(undefined4 **)((int)puVar3 + 0xf0);
  pcStack_4c = *(char **)((int)puVar3 + 0xf4);
  puStack_54 = *(undefined **)(param_1 + 0xf4);
  puStack_58 = *(undefined1 **)(param_1 + 0xf0);
  uStack_5c = 0x9317a8;
  puStack_18 = (undefined1 *)puStack_50;
  uStack_14 = pcStack_4c;
  iVar6 = FUN_00bf1ef0();
  if (iVar6 == 2) {
    pcStack_4c = (char *)0x0;
    puStack_50 = (undefined4 *)0x64;
    puStack_54 = *(undefined **)(param_1 + 0xf4);
    puStack_58 = *(undefined1 **)(param_1 + 0xf0);
    uStack_5c = 0x9317c9;
    lVar7 = FUN_016f4270();
    puStack_20 = (undefined *)(lVar7 + 1);
    if (lVar7 + 1 <= (longlong)DAT_01ee1b78) {
      puStack_20 = auStack_68;
      uStack_6c = 0;
      puStack_70 = puStack_1c;
      uStack_74 = 0x9317ff;
      FUN_00912c70();
      puStack_1c = (undefined *)auStack_88;
      if (piStack_2c != (int *)0x0) {
        piVar2 = piStack_2c + 2;
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      auStack_88[0] = 0;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[2] = piStack_2c[2] + 1;
        UNLOCK();
      }
      uStack_98 = uStack_30;
      piStack_94 = piStack_2c;
      puStack_90 = puStack_18;
      uStack_8c = uStack_14;
      uStack_9c = 0x93184f;
      FUN_00914ef0();
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_8c = 0x931865;
          (**(code **)(*piStack_2c + 4))();
        }
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_8c = 0x931877;
          (**(code **)(*piStack_2c + 4))();
        }
      }
      puStack_24 = auStack_a0;
      uStack_8._0_1_ = 4;
      uStack_a4 = 0;
      puStack_90 = (undefined1 *)0x0;
      uStack_8c = 0xf;
      puStack_a8 = &DAT_018bc9b8;
      auStack_a0[0] = 0;
      pcStack_ac = (char *)0x9318a0;
      FUN_005542c0();
      uStack_8._0_1_ = 5;
      FUN_00f839d0(auStack_b8,puStack_18,uStack_14);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00bf6aa0(param_1);
      goto LAB_00931d83;
    }
    puStack_28 = auStack_68;
    uStack_6c = 0;
    puStack_70 = puStack_1c;
    uStack_74 = 0x9318d9;
    FUN_00912c70();
    puStack_24 = (undefined *)auStack_88;
    if (piStack_2c != (int *)0x0) {
      piVar2 = piStack_2c + 2;
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    auStack_88[0] = 0;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[2] = piStack_2c[2] + 1;
      UNLOCK();
    }
    uStack_98 = uStack_30;
    piStack_94 = piStack_2c;
    puStack_90 = puStack_18;
    uStack_8c = uStack_14;
    uStack_9c = 0x931929;
    FUN_00915130();
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_8c = 0x93193f;
        (**(code **)(*piStack_2c + 4))();
      }
      LOCK();
      iVar6 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_8c = 0x931951;
        (**(code **)(*piStack_2c + 4))();
      }
    }
    puStack_20 = auStack_a0;
    puStack_b0 = auStack_a0;
    uStack_8._0_1_ = 7;
    uStack_a4 = uStack_14;
    puStack_a8 = puStack_18;
    pcStack_ac = "friendUserId=%lld";
    uStack_b4 = 0x93196e;
    FUN_01675640();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_00f839a0(auStack_b8);
  }
  else {
    pcStack_4c = *(char **)(param_1 + 0xf4);
    puStack_50 = *(undefined4 **)(param_1 + 0xf0);
    puStack_54 = (undefined *)uStack_14;
    puStack_58 = puStack_18;
    uStack_5c = 0x93199d;
    cVar4 = FUN_00bf3600();
    if (cVar4 == '\0') {
      pcStack_4c = (char *)uStack_14;
      puStack_50 = (undefined4 *)puStack_18;
      puStack_54 = *(undefined **)(param_1 + 0xf4);
      puStack_58 = *(undefined1 **)(param_1 + 0xf0);
      uStack_5c = 0x931b8e;
      cVar4 = FUN_00bf3600();
      if (cVar4 == '\0') goto LAB_00931d83;
      pcStack_4c = (char *)0x0;
      puStack_50 = (undefined4 *)0x64;
      puStack_54 = *(undefined **)(param_1 + 0xf4);
      puStack_58 = *(undefined1 **)(param_1 + 0xf0);
      uStack_5c = 0x931bab;
      lVar7 = FUN_016f4270();
      puStack_20 = (undefined *)(lVar7 + 1);
      if (lVar7 + 1 <= (longlong)DAT_01ee1b78) {
        puStack_28 = auStack_68;
        uStack_6c = 0;
        puStack_70 = puStack_1c;
        uStack_74 = 0x931be1;
        FUN_00912c70();
        puStack_24 = (undefined *)auStack_88;
        if (piStack_2c != (int *)0x0) {
          piVar2 = piStack_2c + 2;
          LOCK();
          *piVar2 = *piVar2 + 1;
          UNLOCK();
          LOCK();
          *piVar2 = *piVar2 + 1;
          UNLOCK();
        }
        auStack_88[0] = 0;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          piStack_2c[2] = piStack_2c[2] + 1;
          UNLOCK();
        }
        uStack_98 = uStack_30;
        piStack_94 = piStack_2c;
        puStack_90 = puStack_18;
        uStack_8c = uStack_14;
        uStack_9c = 0x931c31;
        FUN_00914b90();
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar6 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            uStack_8c = 0x931c47;
            (**(code **)(*piStack_2c + 4))();
          }
          LOCK();
          iVar6 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            uStack_8c = 0x931c59;
            (**(code **)(*piStack_2c + 4))();
          }
        }
        puStack_20 = auStack_a0;
        uStack_8._0_1_ = 0x10;
        uStack_a4 = 0;
        puStack_90 = (undefined1 *)0x0;
        uStack_8c = 0xf;
        puStack_a8 = &DAT_018bc9b8;
        auStack_a0[0] = 0;
        pcStack_ac = (char *)0x931c82;
        FUN_005542c0();
        uStack_8._0_1_ = 0x11;
        FUN_00f839d0(auStack_b8,puStack_18,uStack_14);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00bf6aa0(param_1);
        goto LAB_00931d83;
      }
      puStack_28 = auStack_68;
      uStack_6c = 0;
      puStack_70 = puStack_1c;
      uStack_74 = 0x931cbb;
      FUN_00912c70();
      puStack_24 = (undefined *)auStack_88;
      if (piStack_2c != (int *)0x0) {
        piVar2 = piStack_2c + 2;
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      auStack_88[0] = 0;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[2] = piStack_2c[2] + 1;
        UNLOCK();
      }
      uStack_98 = uStack_30;
      piStack_94 = piStack_2c;
      puStack_90 = puStack_18;
      uStack_8c = uStack_14;
      uStack_9c = 0x931d0b;
      FUN_00914a70();
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_8c = 0x931d21;
          (**(code **)(*piStack_2c + 4))();
        }
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_8c = 0x931d33;
          (**(code **)(*piStack_2c + 4))();
        }
      }
      puStack_20 = auStack_a0;
      puStack_b0 = auStack_a0;
      uStack_8._0_1_ = 0x13;
      uStack_a4 = uStack_14;
      puStack_a8 = puStack_18;
      pcStack_ac = "friendUserId=%lld";
      uStack_b4 = 0x931d50;
      FUN_01675640();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
      puStack_a8 = (undefined1 *)0x0;
      uStack_a4 = 0xf;
      auStack_b8[0] = 0;
      FUN_005542c0("user/unfriend",0xd);
    }
    else {
      pcStack_4c = (char *)0x0;
      puStack_50 = (undefined4 *)0x64;
      puStack_54 = *(undefined **)(param_1 + 0xf4);
      puStack_58 = *(undefined1 **)(param_1 + 0xf0);
      uStack_5c = 0x9319ba;
      lVar7 = FUN_016f4270();
      puStack_20 = (undefined *)(lVar7 + 1);
      if (lVar7 + 1 <= (longlong)DAT_01ee1b78) {
        puStack_28 = auStack_68;
        uStack_6c = 0;
        puStack_70 = puStack_1c;
        uStack_74 = 0x9319f0;
        FUN_00912c70();
        puStack_24 = (undefined *)auStack_88;
        if (piStack_2c != (int *)0x0) {
          piVar2 = piStack_2c + 2;
          LOCK();
          *piVar2 = *piVar2 + 1;
          UNLOCK();
          LOCK();
          *piVar2 = *piVar2 + 1;
          UNLOCK();
        }
        auStack_88[0] = 0;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          piStack_2c[2] = piStack_2c[2] + 1;
          UNLOCK();
        }
        uStack_98 = uStack_30;
        piStack_94 = piStack_2c;
        puStack_90 = puStack_18;
        uStack_8c = uStack_14;
        uStack_9c = 0x931a40;
        FUN_00914dd0();
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar6 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            uStack_8c = 0x931a56;
            (**(code **)(*piStack_2c + 4))();
          }
          LOCK();
          iVar6 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            uStack_8c = 0x931a68;
            (**(code **)(*piStack_2c + 4))();
          }
        }
        puStack_20 = auStack_a0;
        uStack_8._0_1_ = 10;
        uStack_a4 = 0;
        puStack_90 = (undefined1 *)0x0;
        uStack_8c = 0xf;
        puStack_a8 = &DAT_018bc9b8;
        auStack_a0[0] = 0;
        pcStack_ac = (char *)0x931a91;
        FUN_005542c0();
        uStack_8._0_1_ = 0xb;
        FUN_00f822f0(auStack_b8,puStack_18,uStack_14);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00bf6aa0(param_1);
        goto LAB_00931d83;
      }
      puStack_28 = auStack_68;
      uStack_6c = 0;
      puStack_70 = puStack_1c;
      uStack_74 = 0x931aca;
      FUN_00912c70();
      puStack_24 = (undefined *)auStack_88;
      if (piStack_2c != (int *)0x0) {
        piVar2 = piStack_2c + 2;
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      auStack_88[0] = 0;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[2] = piStack_2c[2] + 1;
        UNLOCK();
      }
      uStack_98 = uStack_30;
      piStack_94 = piStack_2c;
      puStack_90 = puStack_18;
      uStack_8c = uStack_14;
      uStack_9c = 0x931b1a;
      FUN_00914720();
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_8c = 0x931b30;
          (**(code **)(*piStack_2c + 4))();
        }
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_8c = 0x931b42;
          (**(code **)(*piStack_2c + 4))();
        }
      }
      puStack_20 = auStack_a0;
      puStack_b0 = auStack_a0;
      uStack_8._0_1_ = 0xd;
      uStack_a4 = uStack_14;
      puStack_a8 = puStack_18;
      pcStack_ac = "requesterUserId=%lld";
      uStack_b4 = 0x931b5f;
      FUN_01675640();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      FUN_00f822c0(auStack_b8);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00bf65c0(param_1);
LAB_00931d83:
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_2c + 2;
    iVar6 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      pcStack_4c = (char *)0x931d96;
      (**(code **)(*piStack_2c + 4))();
    }
  }
  pcStack_4c = (char *)0x931d9e;
  FUN_00550b30();
  pcStack_4c = (char *)0x931da6;
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16666 ; VA 0x00931e40 ; FUN_00931e40 */

void __thiscall FUN_00931e40(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 in_stack_0000001c;
  char *pcVar3;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    pcVar3 = "LocalScripts cannot use SaveBoolean";
  }
  else {
    if (*(char *)(param_1 + 0xa9) != '\0') {
      cVar1 = FUN_00f84dc0(&stack0x00000004,in_stack_0000001c);
      if (cVar1 != '\0') {
        FUN_008a4940(&DAT_0211d890);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
      FUN_008a4940(&DAT_0211d890);
      uVar2 = FUN_005543f0();
      FUN_016756b0(auStack_1c,"Exceeded DataComplexity limit for Boolean key %s",uVar2);
      goto LAB_00931eed;
    }
    pcVar3 = "Data for player not yet loaded, wait for DataReady";
  }
  FUN_00550130(pcVar3);
LAB_00931eed:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16667 ; VA 0x00931f00 ; FUN_00931f00 */

void __fastcall FUN_00931f00(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined *apuStack_e8 [2];
  code *apcStack_e0 [3];
  undefined4 uStack_d4;
  undefined *puStack_d0;
  undefined *puStack_cc;
  char *pcStack_c8;
  undefined auStack_50 [24];
  undefined auStack_38 [12];
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c93fb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar3 = *(int *)(param_1 + 0x34);
    iVar2 = param_1;
    ExceptionList = &pvStack_10;
    if ((iVar3 != 0) && (iVar2 = iVar3, ExceptionList = &pvStack_10, *(int *)(iVar3 + 0x34) != 0)) {
      pcStack_c8 = (char *)0x931f3e;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_005c8ac0();
    }
    if (iVar2 != 0) {
      iVar3 = *(int *)(iVar2 + 0xc);
      pcStack_c8 = (char *)0x931f54;
      iVar2 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        pcStack_c8 = (char *)0x931f7a;
        iVar3 = FUN_005cf750();
        if (iVar3 != 0) {
          pcStack_c8 = *(char **)(param_1 + 0xf4);
          puStack_cc = *(undefined **)(param_1 + 0xf0);
          if (((-1 < (int)pcStack_c8) && (*(int *)(param_1 + 0x35c) != 0)) &&
             (*(int *)(*(int *)(param_1 + 0x35c) + 4) != 0)) {
            puStack_d0 = auStack_50;
            uStack_d4 = 0x931fc7;
            FUN_00980550();
            uStack_1c = 0;
            uStack_18 = 0xf;
            auStack_2c[0] = 0;
            pcStack_c8 = auStack_2c;
            uStack_8._0_1_ = 1;
            uStack_8._1_3_ = 0;
            puStack_cc = (undefined *)0x931ff3;
            cVar1 = FUN_00f84c70();
            if (cVar1 != '\0') {
              pcStack_c8 = (char *)0x0;
              puStack_cc = (undefined *)0x7;
              puStack_d0 = auStack_50;
              uStack_d4 = 0x93200a;
              FUN_014cc090();
              pcStack_c8 = (char *)0x0;
              puStack_14 = (undefined *)apuStack_e8;
              uStack_8._0_1_ = 2;
              apuStack_e8[0] = (undefined *)0x0;
              FUN_005d6520(apcStack_e0,apcStack_e0,2);
              apcStack_e0[0] = _guard_check_icall;
              apuStack_e8[0] = &DAT_018c6f1d;
              FUN_014cd990(auStack_2c,&DAT_01d79f68,1);
              pcStack_c8 = (char *)0x93205e;
              FUN_0056db40();
            }
            pcStack_c8 = (char *)0x932066;
            FUN_005507b0();
            pcStack_c8 = (char *)0x93206e;
            FUN_005507b0();
          }
          ExceptionList = pvStack_10;
          return;
        }
      }
    }
  }
  pcStack_c8 = "Cannot save data for Player that is not in DataModel";
  puStack_cc = (undefined *)0x93208c;
  FUN_00550130();
  pcStack_c8 = "";
  puStack_cc = auStack_38;
                    /* WARNING: Subroutine does not return */
  puStack_d0 = &UNK_0093209a;
  FUN_0170c2a8();
}



/* FUNCTION 16668 ; VA 0x009320a0 ; FUN_009320a0 */

void __thiscall FUN_009320a0(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  int in_stack_0000001c;
  int in_stack_00000020;
  char *pcVar3;
  undefined auStack_20 [16];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9420;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,1);
  if (cVar1 == '\0') {
    pcVar3 = "LocalScripts cannot use SaveInstance";
  }
  else if (*(char *)(param_1 + 0xa9) == '\0') {
    pcVar3 = "Data for player not yet loaded, wait for DataReady";
  }
  else {
    if (in_stack_0000001c != 0) {
      if (in_stack_00000020 != 0) {
        LOCK();
        *(int *)(in_stack_00000020 + 4) = *(int *)(in_stack_00000020 + 4) + 1;
        UNLOCK();
      }
      cVar1 = FUN_00f84eb0(&stack0x00000004,in_stack_0000001c,in_stack_00000020);
      if (cVar1 != '\0') {
        FUN_008a4940(&DAT_0211d890);
        FUN_005507b0();
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return;
      }
      FUN_008a4940(&DAT_0211d890);
      uVar2 = FUN_005543f0();
      FUN_016756b0(auStack_20,"Exceeded DataComplexity limit for Instance key %s",uVar2);
      goto LAB_00932191;
    }
    pcVar3 = "Cannot save a null instance";
  }
  FUN_00550130(pcVar3);
LAB_00932191:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 16669 ; VA 0x009321a0 ; FUN_009321a0 */

void __thiscall FUN_009321a0(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 in_stack_0000001c;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,1);
  if ((cVar1 == '\0') || (*(char *)(param_1 + 0xa9) == '\0')) {
    FUN_00550130();
  }
  else {
    cVar1 = FUN_00f85090(&stack0x00000004,in_stack_0000001c);
    if (cVar1 != '\0') {
      FUN_008a4940();
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
    FUN_008a4940();
    uVar2 = FUN_005543f0();
    FUN_016756b0(auStack_1c,"Exceeded DataComplexity limit for Number key %s",uVar2);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16670 ; VA 0x00932270 ; FUN_00932270 */

void __fastcall FUN_00932270(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9440;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    pcVar3 = "LocalScripts cannot use SaveString";
  }
  else {
    if (*(char *)(param_1 + 0xa9) != '\0') {
      cVar1 = FUN_00f85300(&stack0x00000004,&stack0x0000001c);
      if (cVar1 != '\0') {
        FUN_008a4940(&DAT_0211d890);
        FUN_005507b0();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
      FUN_008a4940(&DAT_0211d890);
      uVar2 = FUN_005543f0();
      FUN_016756b0(auStack_1c,"Exceeded DataComplexity limit for String key %s",uVar2);
      goto LAB_00932326;
    }
    pcVar3 = "Data for player not yet loaded, wait for DataReady";
  }
  FUN_00550130(pcVar3);
LAB_00932326:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16671 ; VA 0x00932340 ; FUN_00932340 */

void __thiscall FUN_00932340(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x454) != param_2) {
    *(int *)(param_1 + 0x454) = param_2;
    FUN_008a4940(&DAT_0211ed58);
    FUN_008a4940(&DAT_0211ed20);
  }
  return;
}



/* FUNCTION 16672 ; VA 0x00932380 ; FUN_00932380 */

void __thiscall FUN_00932380(int param_1,char param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_00930760("setAppearanceDidLoad",param_3,param_4);
  if ((DAT_01d64204 != '\0') && ((char)param_3 == '\0')) {
    *(undefined4 *)(param_1 + 0x438) = 0xffffffff;
    *(undefined4 *)(param_1 + 0x43c) = 0xffffffff;
  }
  if (param_2 != *(char *)(param_1 + 0x260)) {
    *(char *)(param_1 + 0x260) = param_2;
    FUN_008a4940(&DAT_0211f028);
  }
  return;
}



/* FUNCTION 16673 ; VA 0x009323e0 ; FUN_009323e0 */

void * FUN_009323e0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00a698d0();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4) {
      pvVar4 = (void *)FUN_008a65e0(0,0);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 16674 ; VA 0x00932470 ; FUN_00932470 */

void * FUN_00932470(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00a698d0();
    if ((uint)*(ushort *)(iVar3 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
      iVar2 = *(int *)(param_1 + 0xc);
      iVar3 = FUN_00c8dce0();
      pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
      if (pvVar4 < (void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)))
      goto LAB_009324ed;
    }
    pvVar4 = (void *)FUN_008a65e0(0,0);
  }
LAB_009324ed:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 16675 ; VA 0x00932530 ; FUN_00932530 */

void __thiscall FUN_00932530(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x267)) {
    *(char *)(param_1 + 0x267) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 16676 ; VA 0x00932560 ; FUN_00932560 */

void __thiscall FUN_00932560(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x26a) = param_2;
  return;
}



/* FUNCTION 16677 ; VA 0x00932570 ; FUN_00932570 */

void __thiscall FUN_00932570(int param_1,float param_2)

{
  float fVar1;
  int iVar2;
  float fVar3;
  
  if ((NAN(*(float *)(param_1 + 0x4a8)) || NAN(param_2)) == (*(float *)(param_1 + 0x4a8) == param_2)
     ) {
    fVar3 = *(float *)(param_1 + 0x4ac);
    if (*(float *)(param_1 + 0x4ac) <= param_2) {
      fVar3 = param_2;
    }
    fVar1 = (float)DAT_01d67a58;
    if (fVar3 <= (float)DAT_01d67a58) {
      fVar1 = fVar3;
    }
    *(float *)(param_1 + 0x4a8) = fVar1;
    if (*(int *)(param_1 + 100) != 0) {
      iVar2 = FUN_0068f8a0();
      if (iVar2 != 0) {
        FUN_00f81e60(*(undefined4 *)(param_1 + 0x4a8));
      }
    }
    FUN_008a4940(&DAT_0211f118);
  }
  return;
}



/* FUNCTION 16678 ; VA 0x009325f0 ; FUN_009325f0 */

void __thiscall FUN_009325f0(int param_1,float param_2)

{
  int iVar1;
  float fVar2;
  float fVar3;
  
  if ((NAN(*(float *)(param_1 + 0x4ac)) || NAN(param_2)) == (*(float *)(param_1 + 0x4ac) == param_2)
     ) {
    fVar3 = *(float *)(param_1 + 0x4a8);
    if (param_2 <= *(float *)(param_1 + 0x4a8)) {
      fVar3 = param_2;
    }
    fVar2 = DAT_018ce2f4;
    if (DAT_018ce2f4 <= fVar3) {
      fVar2 = fVar3;
    }
    *(float *)(param_1 + 0x4ac) = fVar2;
    if (*(int *)(param_1 + 100) != 0) {
      iVar1 = FUN_0068f8a0();
      if (iVar1 != 0) {
        FUN_00f81e90(*(undefined4 *)(param_1 + 0x4ac));
      }
    }
    FUN_008a4940(&DAT_0211f150);
  }
  return;
}



/* FUNCTION 16679 ; VA 0x00932670 ; FUN_00932670 */

void __thiscall FUN_00932670(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x49c) != param_2) {
    *(int *)(param_1 + 0x49c) = param_2;
    if (*(int *)(param_1 + 100) != 0) {
      iVar1 = FUN_0068f8a0();
      if (iVar1 != 0) {
        FUN_00f81e40(*(undefined4 *)(param_1 + 0x49c));
      }
    }
    FUN_008a4940(&DAT_0211f0d8);
  }
  return;
}



/* FUNCTION 16680 ; VA 0x009326c0 ; FUN_009326c0 */

void __thiscall FUN_009326c0(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0xb0)) {
    *(char *)(param_1 + 0xb0) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 16681 ; VA 0x009326f0 ; FUN_009326f0 */

void __thiscall FUN_009326f0(int *param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  float10 fVar7;
  double dVar8;
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  code *pcStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int aiStack_28 [2];
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c94b1;
  pvStack_10 = ExceptionList;
  piStack_1c = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    iVar2 = (**(code **)(*param_2 + 0x10))();
    iVar3 = FUN_00b63f30();
    if (iVar2 != iVar3) {
      iVar2 = (**(code **)(*param_2 + 0x10))();
      iVar3 = FUN_00aff9a0();
      if (iVar2 != iVar3) {
        piVar4 = (int *)param_2[10];
        if (0xf < (uint)piVar4[5]) {
          piVar4 = (int *)*piVar4;
        }
        FUN_0086f2f0(2,"can\'t set character to %s, only Models or Parts are allowed!",piVar4);
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  if (param_2 == (int *)param_1[0x19]) {
    ExceptionList = pvStack_10;
    return;
  }
  if ((int *)param_1[0x19] == (int *)0x0) goto LAB_00932a77;
  FUN_01679490();
  if (param_1[0x1a] != 0) {
    LOCK();
    piVar4 = (int *)(param_1[0x1a] + 4);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  FUN_0089be10(param_1[0x19],param_1[0x1a]);
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 != '\0') {
    FUN_008a65e0(0,0);
  }
  param_1[0x19] = 0;
  piStack_14 = (int *)param_1[0x1a];
  param_1[0x1a] = 0;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  iVar2 = FUN_0090c170();
  if (*(int *)(iVar2 + 0x88) == 1) goto LAB_00932a77;
  iVar2 = param_1[3];
  iVar3 = thunk_FUN_00897b90();
  piVar4 = (int *)0x0;
  if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    piVar4 = param_1;
  }
  if (piVar4 == (int *)0x0) {
LAB_00932967:
    iVar2 = 0;
  }
  else {
    piStack_14 = (int *)piVar4[0xd];
    if ((piStack_14 != (int *)0x0) && (piVar4 = piStack_14, piStack_14[0xd] != 0)) {
      piVar4 = (int *)FUN_005c8ac0();
    }
    piStack_14 = piVar4;
    if ((piStack_14 == (int *)0x0) ||
       (iVar2 = piStack_14[3], iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar3 + 0x1da) <
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) goto LAB_00932967;
    FUN_005789c0(&DAT_01ead658,&LAB_00634090);
    uVar5 = FUN_006350d0();
    piStack_14 = (int *)FUN_008aa140(uVar5);
    if (*piStack_14 == 0) {
      uVar5 = FUN_00b57070();
      piVar4 = (int *)FUN_008a9ba0(&piStack_38,uVar5);
      iVar2 = *piVar4;
      iVar3 = piVar4[1];
      *piVar4 = 0;
      piVar4[1] = 0;
      *piStack_14 = iVar2;
      piStack_1c = (int *)piStack_14[1];
      piStack_14[1] = iVar3;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar2 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar2 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      piStack_1c = piStack_34;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_34[1] + -1;
        piStack_34[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_34)();
          LOCK();
          iVar2 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      iVar2 = *piStack_14;
    }
    else {
      iVar2 = *piStack_14;
    }
  }
  FUN_0060dcd0(aiStack_28,iVar2);
  uStack_8 = 0;
  if (aiStack_28[0] != 0) {
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = 0;
    FUN_005542c0("MouseLockLabel",0xe);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uVar5 = FUN_008a13b0(auStack_58);
    piVar4 = (int *)FUN_0060dcd0(&iStack_30,uVar5);
    iStack_18 = *piVar4;
    piStack_14 = (int *)piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    uStack_8 = 1;
    piStack_1c = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar2 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if ((iStack_18 == 0) ||
       (iVar2 = *(int *)(iStack_18 + 0xc), iVar6 = FUN_00ea2d80(), iVar3 = iStack_18,
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      iVar3 = 0;
    }
    FUN_00550b30();
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_005507b0();
    if (iVar3 != 0) {
      FUN_00c7cd30(0);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_00550b30();
LAB_00932a77:
  if (param_2 != (int *)0x0) {
    if (DAT_01ee4213 != '\0') {
      fVar7 = (float10)FUN_01683110();
      piStack_1c = (int *)(float)fVar7;
      FUN_016774d0(DAT_01ee4213,"setCharacter received character @ %f s",piStack_1c,0,0,0);
    }
    piVar4 = (int *)FUN_0060dcd0(&piStack_38,param_2);
    iVar2 = *piVar4;
    iVar3 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    param_1[0x19] = iVar2;
    piStack_1c = (int *)param_1[0x1a];
    param_1[0x1a] = iVar3;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar2 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    piStack_1c = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_34[1] + -1;
      piStack_34[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        iVar2 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    *(undefined *)(param_1[0x19] + 0x128) = 1;
    uVar5 = FUN_009ba880(param_2);
    FUN_0060e0c0(&iStack_18,uVar5);
    uStack_8 = 4;
    FUN_00587490(&iStack_20);
    uStack_8._0_1_ = 5;
    if (iStack_20 != 0) {
      FUN_00f81e40(param_1[0x127]);
      FUN_009c4320(param_1[0x128]);
      FUN_009c37e0(param_1[0x129]);
      FUN_00f81e90(param_1[299]);
      FUN_00f81e60(param_1[0x12a]);
    }
    uStack_8._0_1_ = 4;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar2 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    FUN_005c3ac0(param_1);
    cVar1 = FUN_00971ce0(param_1,0);
    if (cVar1 != '\0') {
      FUN_0092feb0();
      if (*(char *)((int)param_1 + 0x4c7) != '\0') {
        *(undefined *)(param_1 + 0x9a) = 1;
      }
      FUN_00587490(&iStack_30);
      uStack_8._0_1_ = 6;
      if (iStack_30 != 0) {
        pcStack_40 = FUN_0092e970;
        uStack_3c = 0;
        piStack_38 = param_1;
        uVar5 = FUN_00915d30(&param_2,&pcStack_40);
        uStack_8._0_1_ = 7;
        FUN_00614020(uVar5);
        FUN_0056e750();
      }
      uStack_8._0_1_ = 4;
      FUN_00550b30();
    }
    cVar1 = FUN_0097c970(param_1,0);
    param_2 = (int *)CONCAT13(cVar1,param_2._0_3_);
    if (cVar1 != '\0') {
      if (*(char *)((int)param_1 + 0x4c7) == '\0') {
        FUN_00930130();
      }
      else {
        piStack_1c = (int *)FUN_009173a0(param_1);
        iVar2 = FUN_00676db0();
        if ((iVar2 != 0) && (piStack_1c != (int *)0x0)) {
          if (*(char *)(param_1 + 0x132) == '\0') {
            *(undefined *)(param_1 + 0x132) = 1;
          }
          else if (*(char *)((int)piStack_1c + 0xdd) != '\0') {
            FUN_00b61290();
          }
        }
      }
    }
    if (DAT_01f2d868 == '\0') {
      if (param_1[0x1a] != 0) {
        LOCK();
        piVar4 = (int *)(param_1[0x1a] + 4);
        *piVar4 = *piVar4 + 1;
        UNLOCK();
      }
      FUN_0089be10(param_1[0x19],param_1[0x1a]);
    }
    if (param_2._3_1_ != '\0') {
      FUN_00587490(aiStack_28);
      if (aiStack_28[0] != 0) {
        iStack_30 = 0;
        piStack_2c = (int *)0x0;
        uStack_3c = 0;
        piStack_38 = (int *)0x0;
        piStack_34 = (int *)0x0;
        uStack_8._0_1_ = 9;
        (**(code **)(*param_1 + 8))(&DAT_0211f370,&uStack_3c,&iStack_30);
        uStack_8._0_1_ = 10;
        FUN_00577b20();
      }
      uStack_8._0_1_ = 4;
      FUN_00550b30();
      FUN_0092e780();
    }
    FUN_016830f0(&iStack_30);
    dVar8 = (double)CONCAT44(piStack_2c,iStack_30) - *(double *)(param_1 + 0x22);
    if (DAT_018d8a10 <= dVar8) {
      if (DAT_018cf108 < dVar8) {
        iVar3 = param_1[0x24] - (int)(dVar8 / DAT_018cf108);
        iVar2 = 0;
        if (-1 < iVar3) {
          iVar2 = iVar3;
        }
        param_1[0x24] = iVar2;
      }
    }
    else {
      param_1[0x24] = param_1[0x24] + 1;
    }
    param_1[0x22] = iStack_30;
    param_1[0x23] = (int)piStack_2c;
    uStack_8 = 0xffffffff;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_14 + 2;
      iVar2 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_008a4940(&DAT_0211e300);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16682 ; VA 0x00932e60 ; FUN_00932e60 */

void __thiscall FUN_00932e60(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  
  piVar1 = (int *)(param_1 + 0x168);
  piVar4 = piVar1;
  if (0xf < *(uint *)(param_1 + 0x17c)) {
    piVar4 = (int *)*piVar1;
  }
  iVar2 = param_2[4];
  piVar5 = param_2;
  if (0xf < (uint)param_2[5]) {
    piVar5 = (int *)*param_2;
  }
  cVar3 = FUN_0055c360(piVar5,iVar2,piVar4,*(undefined4 *)(param_1 + 0x178));
  if (cVar3 == '\0') {
    if (piVar1 != param_2) {
      if (0xf < (uint)param_2[5]) {
        param_2 = (int *)*param_2;
      }
      FUN_005542c0(param_2,iVar2);
    }
    FUN_008a4940(&DAT_0211e374);
  }
  return;
}



/* FUNCTION 16683 ; VA 0x00932ed0 ; FUN_00932ed0 */

void __thiscall FUN_00932ed0(int param_1,int param_2,int param_3)

{
  if ((param_2 != *(int *)(param_1 + 0x180)) || (param_3 != *(int *)(param_1 + 0x184))) {
    *(int *)(param_1 + 0x180) = param_2;
    *(int *)(param_1 + 0x184) = param_3;
    FUN_008a4940(&DAT_0211e33c);
  }
  return;
}



/* FUNCTION 16684 ; VA 0x00932f10 ; FUN_00932f10 */

void __thiscall FUN_00932f10(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x261)) {
    *(char *)(param_1 + 0x261) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 16685 ; VA 0x00932f40 ; FUN_00932f40 */

int __thiscall FUN_00932f40(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(int *)(param_1 + 0x36c) = param_2;
  piVar3 = *(int **)(param_1 + 0x370);
  *(int **)(param_1 + 0x370) = param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar2 = *piVar3;
    param_2 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 16686 ; VA 0x00932fc0 ; FUN_00932fc0 */

void __thiscall FUN_00932fc0(int param_1,float param_2,float param_3,float param_4)

{
  if ((((NAN(param_2) || NAN(*(float *)(param_1 + 0x194))) ==
        (param_2 == *(float *)(param_1 + 0x194))) ||
      ((NAN(param_3) || NAN(*(float *)(param_1 + 0x198))) ==
       (param_3 == *(float *)(param_1 + 0x198)))) ||
     ((NAN(param_4) || NAN(*(float *)(param_1 + 0x19c))) == (param_4 == *(float *)(param_1 + 0x19c))
     )) {
    *(ulonglong *)(param_1 + 0x194) = CONCAT44(param_3,param_2);
    *(float *)(param_1 + 0x19c) = param_4;
    FUN_008a4940(&DAT_0211f6c8);
  }
  return;
}



/* FUNCTION 16687 ; VA 0x00933020 ; FUN_00933020 */

void * FUN_00933020(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 == 0) goto LAB_009330a1;
  iVar2 = *(int *)(param_1 + 0xc);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00b73ae0();
  pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
  if (pvVar4 < (void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    if (param_1 == 0) goto LAB_009330a1;
    iVar2 = *(int *)(param_1 + 0xc);
    iVar3 = FUN_00b739e0();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if (pvVar4 < (void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)))
    goto LAB_009330a1;
  }
  pvVar4 = (void *)FUN_008a65e0(0,0);
LAB_009330a1:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 16688 ; VA 0x009330e0 ; FUN_009330e0 */

void __thiscall FUN_009330e0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0xec) = param_2;
  FUN_008a4940();
  return;
}



/* FUNCTION 16689 ; VA 0x00933100 ; FUN_00933100 */

void __thiscall FUN_00933100(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  
  piVar1 = (int *)(param_1 + 0x1e4);
  iVar2 = param_2[4];
  piVar5 = param_2;
  if (0xf < (uint)param_2[5]) {
    piVar5 = (int *)*param_2;
  }
  piVar4 = piVar1;
  if (0xf < *(uint *)(param_1 + 0x1f8)) {
    piVar4 = (int *)*piVar1;
  }
  cVar3 = FUN_0055c360(piVar4,*(undefined4 *)(param_1 + 500),piVar5,iVar2);
  if ((cVar3 == '\0') && (piVar1 != param_2)) {
    if (0xf < (uint)param_2[5]) {
      param_2 = (int *)*param_2;
    }
    FUN_005542c0(param_2,iVar2);
  }
  return;
}



/* FUNCTION 16690 ; VA 0x00933160 ; FUN_00933160 */

void __thiscall FUN_00933160(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  
  piVar1 = (int *)(param_1 + 0x1cc);
  iVar2 = param_2[4];
  piVar5 = param_2;
  if (0xf < (uint)param_2[5]) {
    piVar5 = (int *)*param_2;
  }
  piVar4 = piVar1;
  if (0xf < *(uint *)(param_1 + 0x1e0)) {
    piVar4 = (int *)*piVar1;
  }
  cVar3 = FUN_0055c360(piVar4,*(undefined4 *)(param_1 + 0x1dc),piVar5,iVar2);
  if ((cVar3 == '\0') && (piVar1 != param_2)) {
    if (0xf < (uint)param_2[5]) {
      param_2 = (int *)*param_2;
    }
    FUN_005542c0(param_2,iVar2);
  }
  return;
}



/* FUNCTION 16691 ; VA 0x009331c0 ; FUN_009331c0 */

void __thiscall FUN_009331c0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  
  piVar1 = (int *)(param_1 + 0x1b4);
  iVar2 = param_2[4];
  piVar5 = param_2;
  if (0xf < (uint)param_2[5]) {
    piVar5 = (int *)*param_2;
  }
  piVar4 = piVar1;
  if (0xf < *(uint *)(param_1 + 0x1c8)) {
    piVar4 = (int *)*piVar1;
  }
  cVar3 = FUN_0055c360(piVar4,*(undefined4 *)(param_1 + 0x1c4),piVar5,iVar2);
  if ((cVar3 == '\0') && (piVar1 != param_2)) {
    if (0xf < (uint)param_2[5]) {
      param_2 = (int *)*param_2;
    }
    FUN_005542c0(param_2,iVar2);
  }
  return;
}



/* FUNCTION 16692 ; VA 0x00933220 ; FUN_00933220 */

void __thiscall FUN_00933220(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  
  if (((((NAN((float)param_2[9]) || NAN(*(float *)(param_1 + 0xe0))) !=
         ((float)param_2[9] == *(float *)(param_1 + 0xe0))) &&
       ((NAN((float)param_2[10]) || NAN(*(float *)(param_1 + 0xe4))) !=
        ((float)param_2[10] == *(float *)(param_1 + 0xe4)))) &&
      ((NAN((float)param_2[0xb]) || NAN(*(float *)(param_1 + 0xe8))) !=
       ((float)param_2[0xb] == *(float *)(param_1 + 0xe8)))) &&
     (cVar4 = FUN_01160ab0((undefined4 *)(param_1 + 0xbc)), cVar4 != '\0')) {
    return;
  }
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *(undefined4 *)(param_1 + 0xbc) = *param_2;
  *(undefined4 *)(param_1 + 0xc0) = uVar1;
  *(undefined4 *)(param_1 + 0xc4) = uVar2;
  *(undefined4 *)(param_1 + 200) = uVar3;
  uVar1 = param_2[5];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  *(undefined4 *)(param_1 + 0xcc) = param_2[4];
  *(undefined4 *)(param_1 + 0xd0) = uVar1;
  *(undefined4 *)(param_1 + 0xd4) = uVar2;
  *(undefined4 *)(param_1 + 0xd8) = uVar3;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  *(undefined4 *)(param_1 + 0xdc) = param_2[8];
  *(undefined4 *)(param_1 + 0xe0) = uVar1;
  *(undefined4 *)(param_1 + 0xe4) = uVar2;
  *(undefined4 *)(param_1 + 0xe8) = uVar3;
  FUN_008a4940(&DAT_0211f420);
  return;
}



/* FUNCTION 16693 ; VA 0x009332a0 ; FUN_009332a0 */

void __thiscall FUN_009332a0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xab) != param_2) {
    *(char *)(param_1 + 0xab) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 16694 ; VA 0x009332d0 ; FUN_009332d0 */

void __thiscall FUN_009332d0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  
  piVar1 = (int *)(param_1 + 0x458);
  iVar2 = param_2[4];
  piVar4 = param_2;
  if (0xf < (uint)param_2[5]) {
    piVar4 = (int *)*param_2;
  }
  piVar5 = piVar1;
  if (0xf < *(uint *)(param_1 + 0x46c)) {
    piVar5 = (int *)*piVar1;
  }
  cVar3 = FUN_0055c360(piVar5,*(undefined4 *)(param_1 + 0x468),piVar4,iVar2);
  if (cVar3 == '\0') {
    if (piVar1 != param_2) {
      if (0xf < (uint)param_2[5]) {
        param_2 = (int *)*param_2;
      }
      FUN_005542c0(param_2,iVar2);
    }
    FUN_008a4940(&DAT_0211ed90);
  }
  return;
}



/* FUNCTION 16695 ; VA 0x00933340 ; FUN_00933340 */

void __thiscall FUN_00933340(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0xa4) != param_2) {
    *(int *)(param_1 + 0xa4) = param_2;
    if (*(int *)(param_1 + 0x35c) != 0) {
      FUN_00f84ea0(param_2);
    }
    FUN_008a4940(&DAT_0211d8c8);
  }
  return;
}



/* FUNCTION 16696 ; VA 0x00933380 ; FUN_00933380 */

void __thiscall FUN_00933380(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c94c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    cVar1 = FUN_0097c970(param_1,0);
    if (cVar1 != '\0') {
      uStack_8 = 0;
      uVar2 = FUN_01255560();
      cVar1 = FUN_01255580(uVar2,5);
      if (cVar1 == '\0') {
        FUN_01255600(5,"setDevCameraOcclusionMode");
      }
      uStack_8 = 0xffffffff;
    }
  }
  if (*(int *)(param_1 + 0x4b8) != param_2) {
    *(int *)(param_1 + 0x4b8) = param_2;
    FUN_008a4940(&DAT_0211f240);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16697 ; VA 0x00933423 ; Catch@00933423 */

void Catch_00933423(void)

{
  int unaff_EBP;
  
  FUN_0086f2f0(3,"Insufficent permissions to set DevCameraOcclusionMode");
  FUN_0054fe90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c243ac);
}



/* FUNCTION 16698 ; VA 0x00933450 ; FUN_00933450 */

void __thiscall FUN_00933450(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c94d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    cVar1 = FUN_0097c970(param_1,0);
    if (cVar1 != '\0') {
      uStack_8 = 0;
      uVar2 = FUN_01255560();
      cVar1 = FUN_01255580(uVar2,5);
      if (cVar1 == '\0') {
        FUN_01255600(5,"setDevComputerCameraMode");
      }
      uStack_8 = 0xffffffff;
    }
  }
  if (*(int *)(param_1 + 0x4b4) != param_2) {
    *(int *)(param_1 + 0x4b4) = param_2;
    FUN_008a4940(&DAT_0211f1c8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16699 ; VA 0x009334f3 ; Catch@009334f3 */

void Catch_009334f3(void)

{
  int unaff_EBP;
  
  FUN_0086f2f0(3,"Insufficent permissions to set DevComputerCameraMode");
  FUN_0054fe90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c243ac);
}



/* FUNCTION 16700 ; VA 0x00933520 ; FUN_00933520 */

void __thiscall FUN_00933520(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c94e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    cVar1 = FUN_0097c970(param_1,0);
    if (cVar1 != '\0') {
      uStack_8 = 0;
      uVar2 = FUN_01255560();
      cVar1 = FUN_01255580(uVar2,5);
      if (cVar1 == '\0') {
        FUN_01255600(5,"setDevComputerMovementMode");
      }
      uStack_8 = 0xffffffff;
    }
  }
  if (*(int *)(param_1 + 0x4c0) != param_2) {
    *(int *)(param_1 + 0x4c0) = param_2;
    FUN_008a4940(&DAT_0211f2c0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16701 ; VA 0x009335c3 ; Catch@009335c3 */

void Catch_009335c3(void)

{
  int unaff_EBP;
  
  FUN_0086f2f0(3,"Insufficent permissions to set DevComputerMovementMode");
  FUN_0054fe90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c243ac);
}



/* FUNCTION 16702 ; VA 0x009335f0 ; FUN_009335f0 */

void __thiscall FUN_009335f0(int param_1,char param_2)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c94f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    cVar1 = FUN_0097c970(param_1,0);
    if (cVar1 != '\0') {
      uStack_8 = 0;
      uVar2 = FUN_01255560();
      cVar1 = FUN_01255580(uVar2,5);
      if (cVar1 == '\0') {
        FUN_01255600(5,"setDevEnableMouseLockOption");
      }
      uStack_8 = 0xffffffff;
    }
  }
  if (*(char *)(param_1 + 0x4c6) != param_2) {
    *(char *)(param_1 + 0x4c6) = param_2;
    FUN_008a4940(&DAT_0211f208);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16703 ; VA 0x00933693 ; Catch@00933693 */

void Catch_00933693(void)

{
  int unaff_EBP;
  
  FUN_0086f2f0(3,"Insufficent permissions to set DevEnableMouseLockOption");
  FUN_0054fe90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c243ac);
}



/* FUNCTION 16704 ; VA 0x009336c0 ; FUN_009336c0 */

void __thiscall FUN_009336c0(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9500;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    cVar1 = FUN_0097c970(param_1,0);
    if (cVar1 != '\0') {
      uStack_8 = 0;
      uVar2 = FUN_01255560();
      cVar1 = FUN_01255580(uVar2,5);
      if (cVar1 == '\0') {
        FUN_01255600(5,"setDevTouchCameraMode");
      }
      uStack_8 = 0xffffffff;
    }
  }
  if (*(int *)(param_1 + 0x4b0) != param_2) {
    *(int *)(param_1 + 0x4b0) = param_2;
    FUN_008a4940(&DAT_0211f188);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16705 ; VA 0x00933763 ; Catch@00933763 */

void Catch_00933763(void)

{
  int unaff_EBP;
  
  FUN_0086f2f0(3,"Insufficent permissions to set DevTouchCameraMode");
  FUN_0054fe90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c243ac);
}



/* FUNCTION 16706 ; VA 0x00933790 ; FUN_00933790 */

void __thiscall FUN_00933790(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9510;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    cVar1 = FUN_0097c970(param_1,0);
    if (cVar1 != '\0') {
      uStack_8 = 0;
      uVar2 = FUN_01255560();
      cVar1 = FUN_01255580(uVar2,5);
      if (cVar1 == '\0') {
        FUN_01255600(5,"setDevTouchMovementMode");
      }
      uStack_8 = 0xffffffff;
    }
  }
  if (*(int *)(param_1 + 0x4bc) != param_2) {
    *(int *)(param_1 + 0x4bc) = param_2;
    FUN_008a4940(&DAT_0211f280);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16707 ; VA 0x00933833 ; Catch@00933833 */

void Catch_00933833(void)

{
  int unaff_EBP;
  
  FUN_0086f2f0(3,"Insufficent permissions to set DevTouchMovementMode");
  FUN_0054fe90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c243ac);
}



/* FUNCTION 16708 ; VA 0x00933860 ; FUN_00933860 */

void __thiscall FUN_00933860(int param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar7 = in_stack_00000018;
  piVar6 = param_2;
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)(param_1 + 0x100);
  uStack_8 = 0;
  piVar5 = (int *)&param_2;
  if (0xf < in_stack_00000018) {
    piVar5 = param_2;
  }
  piVar2 = piVar4;
  if (0xf < *(uint *)(param_1 + 0x114)) {
    piVar2 = (int *)*piVar4;
  }
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0055c360(piVar2,*(undefined4 *)(param_1 + 0x110),piVar5,in_stack_00000014);
  if (cVar1 == '\0') {
    uVar3 = FUN_01255560();
    cVar1 = FUN_01255580(uVar3,4);
    if (cVar1 == '\0') {
      FUN_01255600(4,"set a Player\'s display name");
    }
    piVar6 = param_2;
    uVar7 = in_stack_00000018;
    if ((int **)piVar4 != &param_2) {
      piVar4 = (int *)&param_2;
      if (0xf < in_stack_00000018) {
        piVar4 = param_2;
      }
      FUN_005542c0(piVar4,in_stack_00000014);
      piVar6 = param_2;
      uVar7 = in_stack_00000018;
    }
  }
  if (0xf < uVar7) {
    uVar8 = uVar7 + 1;
    piVar4 = piVar6;
    if (0xfff < uVar8) {
      piVar4 = (int *)piVar6[-1];
      uVar8 = uVar7 + 0x24;
      if (0x1f < (uint)((int)piVar6 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar4,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16709 ; VA 0x00933940 ; FUN_00933940 */

void __thiscall FUN_00933940(int param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  undefined4 *unaff_FS_OFFSET;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 uStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar6 = in_stack_00000018;
  piVar7 = param_2;
  uStack_10 = *unaff_FS_OFFSET;
  puStack_c = &LAB_01798858;
  *unaff_FS_OFFSET = &uStack_10;
  piVar3 = (int *)(param_1 + 0x2a8);
  uStack_8 = 0;
  piVar4 = piVar3;
  if (0xf < *(uint *)(param_1 + 700)) {
    piVar4 = (int *)*piVar3;
  }
  piVar2 = (int *)&param_2;
  if (0xf < in_stack_00000018) {
    piVar2 = param_2;
  }
  cVar1 = FUN_0055c360(piVar2,in_stack_00000014,piVar4,*(undefined4 *)(param_1 + 0x2b8));
  if ((cVar1 == '\0') && ((int **)piVar3 != &param_2)) {
    piVar3 = (int *)&param_2;
    if (0xf < uVar6) {
      piVar3 = piVar7;
    }
    FUN_005542c0(piVar3,in_stack_00000014);
    uVar6 = in_stack_00000018;
    piVar7 = param_2;
  }
  if (0xf < uVar6) {
    uVar5 = uVar6 + 1;
    piVar3 = piVar7;
    if (0xfff < uVar5) {
      piVar3 = (int *)piVar7[-1];
      uVar5 = uVar6 + 0x24;
      if (0x1f < (uint)((int)piVar7 + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar3,uVar5);
  }
  *unaff_FS_OFFSET = uStack_10;
  return;
}



/* FUNCTION 16710 ; VA 0x00933a00 ; FUN_00933a00 */

void __thiscall FUN_00933a00(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 400)) {
    *(char *)(param_1 + 400) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 16711 ; VA 0x00933a30 ; FUN_00933a30 */

void __thiscall FUN_00933a30(int param_1,float param_2)

{
  int iVar1;
  float fVar2;
  
  fVar2 = 0.0;
  if (0.0 <= param_2) {
    fVar2 = param_2;
  }
  if ((NAN(*(float *)(param_1 + 0x4a4)) || NAN(fVar2)) == (*(float *)(param_1 + 0x4a4) == fVar2)) {
    *(float *)(param_1 + 0x4a4) = fVar2;
    if (*(int *)(param_1 + 100) != 0) {
      iVar1 = FUN_0068f8a0();
      if (iVar1 != 0) {
        FUN_009c37e0(*(undefined4 *)(param_1 + 0x4a4));
      }
    }
    FUN_008a4940(&DAT_0211f338);
  }
  return;
}



/* FUNCTION 16712 ; VA 0x00933a90 ; FUN_00933a90 */

int * FUN_00933a90(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar4 = param_1;
  ExceptionList = &pvStack_10;
  if (*(char *)((int)param_1 + 0x21) == '\0') {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00773f80(&param_1);
    FUN_00913c20(auStack_18,0,iVar3 + 0x10,iVar3);
    piVar4 = (int *)(**(code **)(*param_1 + 0x1c))(1);
  }
  piVar2 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar3 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piVar4 = (int *)(**(code **)*param_2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piVar4 = (int *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 16713 ; VA 0x00933b20 ; FUN_00933b20 */

void __thiscall FUN_00933b20(int param_1,undefined4 param_2)

{
  int iVar1;
  
  *(undefined4 *)(param_1 + 0x440) = param_2;
  iVar1 = FUN_009171d0(param_1);
  if (iVar1 != 0) {
    FUN_00a49810(param_1,param_2);
  }
  return;
}



/* FUNCTION 16714 ; VA 0x00933b50 ; FUN_00933b50 */

int __thiscall FUN_00933b50(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = param_2[1];
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = param_2[1];
  }
  *(undefined4 *)(param_1 + 0x7c) = *param_2;
  piVar2 = *(int **)(param_1 + 0x80);
  *(int *)(param_1 + 0x80) = iVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar4 = param_3[1];
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = param_3[1];
  }
  iVar3 = *param_3;
  *(int *)(param_1 + 0x74) = iVar3;
  piVar2 = *(int **)(param_1 + 0x78);
  *(int *)(param_1 + 0x78) = iVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar3 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  return iVar3;
}



/* FUNCTION 16715 ; VA 0x00933bf0 ; FUN_00933bf0 */

void __thiscall FUN_00933bf0(int param_1,int param_2)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined4 ****ppppuVar7;
  undefined4 ****ppppuVar8;
  uint in_stack_00000018;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9530;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00f854f0(apppuStack_2c,&param_2);
  uVar6 = uStack_18;
  ppppuVar8 = (undefined4 ****)apppuStack_2c[0];
  ppppuVar7 = (undefined4 ****)(param_1 + 0x22c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  ppppuVar3 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
  }
  ppppuVar2 = ppppuVar7;
  if (0xf < *(uint *)(param_1 + 0x240)) {
    ppppuVar2 = (undefined4 ****)*ppppuVar7;
  }
  cVar1 = FUN_0055c360(ppppuVar2,*(undefined4 *)(param_1 + 0x23c),ppppuVar3,uStack_1c);
  if (cVar1 == '\0') {
    if (ppppuVar7 != apppuStack_2c) {
      ppppuVar3 = apppuStack_2c;
      if (0xf < uVar6) {
        ppppuVar3 = ppppuVar8;
      }
      FUN_005542c0(ppppuVar3,uStack_1c);
    }
    FUN_008a4940(&DAT_0211e5c4);
    FUN_008a4940(&DAT_0211e5fc);
    ppppuVar8 = (undefined4 ****)apppuStack_2c[0];
    uVar6 = uStack_18;
  }
  if (0xf < uVar6) {
    uVar4 = uVar6 + 1;
    ppppuVar3 = ppppuVar8;
    if (0xfff < uVar4) {
      ppppuVar3 = (undefined4 ****)ppppuVar8[-1];
      uVar4 = uVar6 + 0x24;
      if (0x1f < (uint)((int)ppppuVar8 + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar4);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    iVar5 = param_2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_2 + -4);
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16716 ; VA 0x00933d30 ; FUN_00933d30 */

void __thiscall FUN_00933d30(int param_1,undefined4 param_2)

{
  undefined4 ***pppuVar1;
  char cVar2;
  undefined4 ****ppppuVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  undefined4 ****ppppuVar6;
  undefined4 ****ppppuVar7;
  undefined4 ***pppuStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00f854f0(&pppuStack_2c,param_2);
  ppppuVar6 = (undefined4 ****)pppuStack_2c;
  ppppuVar7 = (undefined4 ****)(param_1 + 0x244);
  ppppuVar4 = &pppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar4 = (undefined4 ****)pppuStack_2c;
  }
  uStack_8 = 0;
  ppppuVar3 = ppppuVar7;
  if (0xf < *(uint *)(param_1 + 600)) {
    ppppuVar3 = (undefined4 ****)*ppppuVar7;
  }
  cVar2 = FUN_0055c360(ppppuVar3,*(undefined4 *)(param_1 + 0x254),ppppuVar4,uStack_1c);
  if (cVar2 == '\0') {
    if (ppppuVar7 != &pppuStack_2c) {
      FUN_005507b0();
      pppuVar1 = pppuStack_2c;
      pppuStack_2c = (undefined4 ***)((uint)pppuStack_2c & 0xffffff00);
      *ppppuVar7 = pppuVar1;
      *(undefined4 *)(param_1 + 0x248) = uStack_28;
      *(undefined4 *)(param_1 + 0x24c) = uStack_24;
      *(undefined4 *)(param_1 + 0x250) = uStack_20;
      *(ulonglong *)(param_1 + 0x254) = CONCAT44(uStack_18,uStack_1c);
      uStack_1c = 0;
      uStack_18 = 0xf;
    }
    FUN_008a4940(&DAT_0211e634);
    ppppuVar6 = (undefined4 ****)pppuStack_2c;
  }
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    ppppuVar7 = ppppuVar6;
    if (0xfff < uVar5) {
      ppppuVar7 = (undefined4 ****)ppppuVar6[-1];
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)ppppuVar6 + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar7,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16717 ; VA 0x00933e30 ; FUN_00933e30 */

void __thiscall FUN_00933e30(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar2 = DAT_018ce324;
  if (DAT_01d6422c != '\0') {
    fVar2 = (float)DAT_01d6414c;
  }
  fVar1 = DAT_018ce2f8;
  if (DAT_018ce2f8 <= param_2) {
    fVar1 = param_2;
  }
  param_2 = fVar2;
  if (fVar1 <= fVar2) {
    param_2 = fVar1;
  }
  if (((NAN(param_2) || NAN(*(float *)(param_1 + 0x18c))) ==
       (param_2 == *(float *)(param_1 + 0x18c))) &&
     ((**(code **)(*DAT_0211ea84 + 0x10))(param_1,&param_2), param_2 < *(float *)(param_1 + 0x188)))
  {
    FUN_00934730(param_2);
  }
  return;
}



/* FUNCTION 16718 ; VA 0x00933eb0 ; FUN_00933eb0 */

void __thiscall FUN_00933eb0(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x450) != param_2) {
    *(int *)(param_1 + 0x450) = param_2;
    FUN_008a4940(&DAT_0211ece0);
    FUN_008a4940(&DAT_0211eca0);
  }
  return;
}



/* FUNCTION 16719 ; VA 0x00933ef0 ; FUN_00933ef0 */

void __thiscall FUN_00933ef0(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = FUN_01255560();
  cVar1 = FUN_01255580(uVar2,4);
  if (cVar1 == '\0') {
    FUN_01255600(4,"set a Player\'s name");
  }
  FUN_008a6520(param_2);
  iVar3 = FUN_009171d0(param_1);
  if (iVar3 != 0) {
    FUN_00a3e1e0(param_2);
  }
  return;
}



/* FUNCTION 16720 ; VA 0x00933f50 ; FUN_00933f50 */

void __thiscall FUN_00933f50(int param_1,float param_2)

{
  int iVar1;
  float fVar2;
  
  fVar2 = 0.0;
  if (0.0 <= param_2) {
    fVar2 = param_2;
  }
  if ((NAN(*(float *)(param_1 + 0x4a0)) || NAN(fVar2)) == (*(float *)(param_1 + 0x4a0) == fVar2)) {
    *(float *)(param_1 + 0x4a0) = fVar2;
    if (*(int *)(param_1 + 100) != 0) {
      iVar1 = FUN_0068f8a0();
      if (iVar1 != 0) {
        FUN_009c4320(*(undefined4 *)(param_1 + 0x4a0));
      }
    }
    FUN_008a4940(&DAT_0211f300);
  }
  return;
}



/* FUNCTION 16721 ; VA 0x00933fb0 ; FUN_00933fb0 */

void __thiscall FUN_00933fb0(int param_1,char param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_2 != *(char *)(param_1 + 0xa8)) {
    *(char *)(param_1 + 0xa8) = param_2;
    if (((DAT_01d6420c == '\0') && (*(char *)(param_1 + 0x262) != '\0')) &&
       (*(int *)(param_1 + 0x148) != 0)) {
      FUN_005515c0();
    }
    FUN_008a4940(&DAT_0211ebf8);
    iVar1 = FUN_009174b0(param_1);
    if (iVar1 != 0) {
      uVar2 = FUN_00bdfee0(param_1);
      FUN_00934ae0(uVar2);
    }
  }
  return;
}



/* FUNCTION 16722 ; VA 0x00934020 ; FUN_00934020 */

void __thiscall
FUN_00934020(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,uint param_7)

{
  int iVar1;
  uint uVar2;
  
  if ((int *)(param_1 + 0x1fc) != &param_2) {
    FUN_005507b0();
    *(int *)(param_1 + 0x1fc) = param_2;
    *(undefined4 *)(param_1 + 0x200) = param_3;
    *(undefined4 *)(param_1 + 0x204) = param_4;
    *(undefined4 *)(param_1 + 0x208) = param_5;
    *(ulonglong *)(param_1 + 0x20c) = CONCAT44(param_7,param_6);
    return;
  }
  if (0xf < param_7) {
    uVar2 = param_7 + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = param_7 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 16723 ; VA 0x00934090 ; FUN_00934090 */

void __thiscall FUN_00934090(int param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar7 = in_stack_00000018;
  piVar6 = param_2;
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)(param_1 + 0x118);
  uStack_8 = 0;
  piVar5 = (int *)&param_2;
  if (0xf < in_stack_00000018) {
    piVar5 = param_2;
  }
  piVar2 = piVar4;
  if (0xf < *(uint *)(param_1 + 300)) {
    piVar2 = (int *)*piVar4;
  }
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0055c360(piVar2,*(undefined4 *)(param_1 + 0x128),piVar5,in_stack_00000014);
  if (cVar1 == '\0') {
    uVar3 = FUN_01255560();
    cVar1 = FUN_01255580(uVar3,4);
    if (cVar1 == '\0') {
      FUN_01255600(4,"set a Player\'s platform name");
    }
    piVar6 = param_2;
    uVar7 = in_stack_00000018;
    if ((int **)piVar4 != &param_2) {
      piVar4 = (int *)&param_2;
      if (0xf < in_stack_00000018) {
        piVar4 = param_2;
      }
      FUN_005542c0(piVar4,in_stack_00000014);
      piVar6 = param_2;
      uVar7 = in_stack_00000018;
    }
  }
  if (0xf < uVar7) {
    uVar8 = uVar7 + 1;
    piVar4 = piVar6;
    if (0xfff < uVar8) {
      piVar4 = (int *)piVar6[-1];
      uVar8 = uVar7 + 0x24;
      if (0x1f < (uint)((int)piVar6 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar4,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16724 ; VA 0x00934170 ; FUN_00934170 */

int __thiscall FUN_00934170(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(int *)(param_1 + 0x488) = param_2;
  piVar3 = *(int **)(param_1 + 0x48c);
  *(int **)(param_1 + 0x48c) = param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar2 = *piVar3;
    param_2 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 16725 ; VA 0x009341f0 ; FUN_009341f0 */

void __thiscall FUN_009341f0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  if ((undefined4 *)(param_1 + 0x290) != param_2) {
    puVar1 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar1);
  }
  return;
}



/* FUNCTION 16726 ; VA 0x00934220 ; FUN_00934220 */

void __thiscall FUN_00934220(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00b63e30(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 16727 ; VA 0x009342d0 ; FUN_009342d0 */

void __thiscall FUN_009342d0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00e469a0(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 16728 ; VA 0x00934380 ; FUN_00934380 */

void __thiscall FUN_00934380(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00e40f60(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 16729 ; VA 0x00934430 ; FUN_00934430 */

void __thiscall FUN_00934430(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  
  puVar7 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    uVar4 = param_2[1];
    uVar5 = param_2[2];
    uVar6 = param_2[3];
    *puVar7 = *param_2;
    puVar7[1] = uVar4;
    puVar7[2] = uVar5;
    puVar7[3] = uVar6;
    uVar4 = param_2[5];
    uVar5 = param_2[6];
    uVar6 = param_2[7];
    puVar7[4] = param_2[4];
    puVar7[5] = uVar4;
    puVar7[6] = uVar5;
    puVar7[7] = uVar6;
  }
  FUN_00913d90(puVar7,param_3);
  *(undefined4 *)(param_1 + 0x26c) = 0;
  piVar2 = *(int **)(param_1 + 0x270);
  *(undefined4 *)(param_1 + 0x270) = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    *(undefined4 *)(param_1 + 0x274) = param_3;
    return;
  }
  *(undefined4 *)(param_1 + 0x274) = param_3;
  return;
}



/* FUNCTION 16730 ; VA 0x009344e0 ; FUN_009344e0 */

int * __thiscall FUN_009344e0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  bool bVar6;
  undefined auStack_34 [12];
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9550;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_0060dcd0(&iStack_20,param_2);
  piStack_18 = (int *)(param_1 + 0x54);
  uStack_8 = 0;
  piVar4 = (int *)FUN_00587490(&iStack_28);
  iVar3 = iStack_20;
  piVar5 = piStack_24;
  bVar6 = *piVar4 != iStack_20;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      piVar4 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar4 = (int *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (bVar6) {
    uStack_8._0_1_ = 1;
    param_2 = FUN_0170d75d(iVar3,0,&RBX::Instance::RTTI_Type_Descriptor,
                           &RBX::IHasLocation::RTTI_Type_Descriptor,0);
    if (param_2 == 0) {
      param_2 = 0;
      piVar5 = (int *)0x0;
    }
    else {
      piVar5 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iStack_28 = param_2;
    piStack_24 = piVar5;
    if ((param_2 == 0) && (iStack_20 != 0)) {
      FUN_00550130("Invalid object type for ReplicationFocus property");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_34,&DAT_01c17198);
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[2] = piStack_1c[2] + 1;
      UNLOCK();
    }
    *piStack_18 = iStack_20;
    piVar4 = (int *)piStack_18[1];
    piStack_18[1] = (int)piStack_1c;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[2] = piVar5[2] + 1;
      UNLOCK();
    }
    *(int *)(iStack_14 + 0x5c) = param_2;
    piVar4 = *(int **)(iStack_14 + 0x60);
    *(int **)(iStack_14 + 0x60) = piVar5;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
    piVar4 = (int *)FUN_008a4940(&DAT_0211e3e4);
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar3 = *piVar1;
      piVar4 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar3 = *piVar1;
        piVar4 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar4 = (int *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar5 = piStack_1c + 1;
    iVar3 = *piVar5;
    piVar4 = (int *)*piVar5;
    *piVar5 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piVar4 = (int *)(**(code **)*piStack_1c)();
      LOCK();
      piVar5 = piStack_1c + 2;
      iVar3 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piVar4 = (int *)(**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 16731 ; VA 0x00934690 ; FUN_00934690 */

void __thiscall FUN_00934690(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_c [4];
  int *piStack_8;
  
  iVar2 = FUN_00926cb0();
  if (param_2 != iVar2) {
    puVar3 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
    iVar2 = puVar3[1];
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 8) = *(int *)(iVar2 + 8) + 1;
      UNLOCK();
      iVar2 = puVar3[1];
    }
    *(undefined4 *)(param_1 + 0xb4) = *puVar3;
    piVar1 = *(int **)(param_1 + 0xb8);
    *(int *)(param_1 + 0xb8) = iVar2;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[1] + -1;
      piStack_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    FUN_008a4940(&DAT_0211e4a8);
  }
  return;
}



/* FUNCTION 16732 ; VA 0x00934730 ; FUN_00934730 */

void __thiscall FUN_00934730(int param_1,float param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_10 [4];
  int *piStack_c;
  int *piStack_8;
  
  if (param_2 < *(float *)(param_1 + 0x188)) {
    iVar4 = *(int *)(param_1 + 0x34);
    iVar1 = param_1;
    if ((iVar4 != 0) && (iVar1 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
      iVar1 = FUN_005c8ac0();
    }
    if ((iVar1 != 0) &&
       (iVar4 = *(int *)(iVar1 + 0xc), iVar1 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
       (uint)*(ushort *)(iVar1 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8aa8,&LAB_0055d5b0);
      uVar2 = FUN_00560e40();
      piStack_8 = (int *)FUN_008aa140(uVar2);
      if (*piStack_8 == 0) {
        uVar2 = FUN_005ee510();
        piVar3 = (int *)FUN_008a9ba0(auStack_10,uVar2);
        iVar4 = *piVar3;
        iVar1 = piVar3[1];
        *piVar3 = 0;
        piVar3[1] = 0;
        *piStack_8 = iVar4;
        piVar3 = (int *)piStack_8[1];
        piStack_8[1] = iVar1;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        if (piStack_c != (int *)0x0) {
          LOCK();
          iVar4 = piStack_c[1] + -1;
          piStack_c[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_c)();
            LOCK();
            piVar3 = piStack_c + 2;
            iVar4 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              (**(code **)(*piStack_c + 4))();
            }
          }
        }
      }
      if ((*piStack_8 != 0) && (iVar4 = FUN_006448a0(), iVar4 != 0)) {
        FUN_006448a0();
        FUN_007137d0(*(undefined4 *)(param_1 + 0x274));
      }
    }
  }
  *(float *)(param_1 + 0x188) = param_2;
  if (*(char *)(param_1 + 0x269) == '\0') {
    *(undefined *)(param_1 + 0x269) = 1;
  }
  return;
}



/* FUNCTION 16733 ; VA 0x00934890 ; FUN_00934890 */

int __thiscall FUN_00934890(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(int *)(param_1 + 0x1ac) = param_2;
  piVar3 = *(int **)(param_1 + 0x1b0);
  *(int **)(param_1 + 0x1b0) = param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar2 = *piVar3;
    param_2 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 16734 ; VA 0x00934910 ; FUN_00934910 */

void __thiscall FUN_00934910(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0xae)) {
    *(char *)(param_1 + 0xae) = param_2;
    FUN_008a4940(&DAT_0211e930);
    FUN_008a4940(&DAT_0211eb40);
  }
  return;
}



/* FUNCTION 16735 ; VA 0x00934950 ; FUN_00934950 */

void __thiscall FUN_00934950(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_10 [12];
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    iVar2 = param_1;
    if ((iVar1 != 0) && (iVar2 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      iVar2 = FUN_005c8ac0();
    }
    if ((((iVar2 != 0) &&
         (iVar1 = *(int *)(iVar2 + 0xc), iVar2 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
         (uint)*(ushort *)(iVar2 + 0x1da))) && (iVar2 = FUN_005cf750(), iVar1 = param_2, iVar2 != 0)
        ) && (*(int *)(param_1 + 0x34) == iVar2)) {
      if (param_2 == 0) {
        FUN_00933fb0(1);
        return;
      }
      iVar2 = FUN_009174b0(param_1);
      if ((iVar2 != 0) && (*(int *)(iVar1 + 0x34) == iVar2)) {
        puVar3 = (undefined4 *)FUN_00a6bd20(&param_2);
        FUN_00934a60(*puVar3);
        FUN_00933fb0(0);
        return;
      }
      FUN_016756b0(auStack_10,
                   "Setting Player.Team failed because team must be a child of the Teams service");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_10,&DAT_01c17198);
    }
  }
  FUN_005c8aa0();
  uVar4 = FUN_005543f0();
  FUN_016756b0(auStack_10,"Failed to set %s\'s team because the player left the game",uVar4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 16736 ; VA 0x00934a60 ; FUN_00934a60 */

void __thiscall FUN_00934a60(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_2 != *(int *)(param_1 + 0x94)) {
    *(int *)(param_1 + 0x94) = param_2;
    if (((DAT_01d6420c == '\0') && (*(char *)(param_1 + 0x262) != '\0')) &&
       (*(int *)(param_1 + 0x148) != 0)) {
      FUN_005515c0();
    }
    FUN_008a4940(&DAT_0211ebc0);
    if (*(char *)(param_1 + 0xa8) == '\0') {
      iVar1 = FUN_009174b0(param_1);
      if (iVar1 != 0) {
        uVar2 = FUN_00bdff10(param_2);
        FUN_00934ae0(uVar2);
      }
    }
  }
  return;
}



/* FUNCTION 16737 ; VA 0x00934ae0 ; FUN_00934ae0 */

undefined4 * __thiscall FUN_00934ae0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9568;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_00587490(auStack_20);
  piVar5 = piStack_1c;
  piStack_14 = (int *)*puVar6;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    puVar6 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      puVar6 = (undefined4 *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (param_2 != piStack_14) {
    FUN_00587490(&iStack_18);
    uStack_8 = 0;
    puVar6 = (undefined4 *)FUN_0060e0c0(auStack_20,param_2);
    uVar3 = *puVar6;
    uVar4 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x98) = uVar3;
    piVar5 = *(int **)(param_1 + 0x9c);
    *(undefined4 *)(param_1 + 0x9c) = uVar4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
    if (iStack_18 != 0) {
      FUN_00e41950(param_1);
    }
    if (param_2 != (int *)0x0) {
      FUN_00e418b0(param_1);
    }
    puVar6 = (undefined4 *)FUN_008a4940(&DAT_0211e66c);
    piVar5 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      puVar6 = (undefined4 *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          puVar6 = (undefined4 *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 16738 ; VA 0x00934c20 ; FUN_00934c20 */

void __thiscall FUN_00934c20(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x265)) {
    *(char *)(param_1 + 0x265) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 16739 ; VA 0x00934c50 ; FUN_00934c50 */

void __thiscall FUN_00934c50(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0xaf)) {
    *(char *)(param_1 + 0xaf) = param_2;
  }
  return;
}



/* FUNCTION 16740 ; VA 0x00934c70 ; FUN_00934c70 */

void __thiscall FUN_00934c70(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  if ((undefined4 *)(param_1 + 0x470) != param_2) {
    puVar1 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar1);
  }
  return;
}



/* FUNCTION 16741 ; VA 0x00934ca0 ; FUN_00934ca0 */

void __thiscall FUN_00934ca0(int param_1,uint param_2,int param_3)

{
  char cVar1;
  undefined4 uVar2;
  
  if ((param_2 != *(uint *)(param_1 + 0xf0)) || (param_3 != *(int *)(param_1 + 0xf4))) {
    uVar2 = FUN_01255560();
    cVar1 = FUN_01255580(uVar2,4);
    if (cVar1 == '\0') {
      FUN_01255600(4,"set a Player\'s ID");
    }
    if (*(char *)(param_1 + 0xaa) == '\0') {
      *(uint *)(param_1 + 0xf0) = param_2;
      *(int *)(param_1 + 0xf4) = param_3;
      *(uint *)(param_1 + 0xf8) = param_2 + 0x550aa3b2;
      *(uint *)(param_1 + 0xfc) = param_3 + (uint)(0xaaf55c4d < param_2);
      FUN_008a4940(&DAT_0211e4e4);
      FUN_008a4940(&DAT_0211ec68);
    }
  }
  return;
}



/* FUNCTION 16742 ; VA 0x00934d30 ; FUN_00934d30 */

void __thiscall FUN_00934d30(int param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar7 = in_stack_00000018;
  piVar6 = param_2;
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)(param_1 + 0x214);
  uStack_8 = 0;
  piVar2 = (int *)&param_2;
  if (0xf < in_stack_00000018) {
    piVar2 = param_2;
  }
  piVar4 = piVar3;
  if (0xf < *(uint *)(param_1 + 0x228)) {
    piVar4 = (int *)*piVar3;
  }
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0055c360(piVar4,*(undefined4 *)(param_1 + 0x224),piVar2,in_stack_00000014);
  if (cVar1 == '\0') {
    if ((int **)piVar3 != &param_2) {
      piVar3 = (int *)&param_2;
      if (0xf < uVar7) {
        piVar3 = piVar6;
      }
      FUN_005542c0(piVar3,in_stack_00000014);
    }
    FUN_008a4940(&DAT_0211e9a0);
    piVar6 = param_2;
    uVar7 = in_stack_00000018;
  }
  if (0xf < uVar7) {
    uVar5 = uVar7 + 1;
    piVar3 = piVar6;
    if (0xfff < uVar5) {
      piVar3 = (int *)piVar6[-1];
      uVar5 = uVar7 + 0x24;
      if (0x1f < (uint)((int)piVar6 + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16743 ; VA 0x00934e00 ; FUN_00934e00 */

void __thiscall FUN_00934e00(int param_1,int param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  
  fVar1 = *param_3;
  fVar2 = *(float *)(*(int *)(param_1 + 8) + param_2);
  if ((NAN(fVar2) || NAN(fVar1)) == (fVar2 == fVar1)) {
    *(float *)(*(int *)(param_1 + 8) + param_2) = fVar1;
    if (*(code **)(param_1 + 0x10) != (code *)0x0) {
      (**(code **)(param_1 + 0x10))(*(undefined4 *)(param_1 + 4));
    }
    FUN_008a4940(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 16744 ; VA 0x00934e50 ; FUN_00934e50 */

void __thiscall FUN_00934e50(int param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  uVar1 = param_3[4];
  puVar5 = (undefined4 *)(*(int *)(param_1 + 8) + param_2);
  puVar4 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar4 = (undefined4 *)*param_3;
  }
  puVar3 = puVar5;
  if (0xf < (uint)puVar5[5]) {
    puVar3 = (undefined4 *)*puVar5;
  }
  cVar2 = FUN_0055c360(puVar3,puVar5[4],puVar4,uVar1);
  if (cVar2 == '\0') {
    if (puVar5 != param_3) {
      if (0xf < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      FUN_005542c0(param_3,uVar1);
    }
    if (*(code **)(param_1 + 0x10) != (code *)0x0) {
      (**(code **)(param_1 + 0x10))(*(undefined4 *)(param_1 + 4));
    }
    FUN_008a4940(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 16745 ; VA 0x00934ed0 ; FUN_00934ed0 */

void __thiscall FUN_00934ed0(int param_1,undefined4 param_2,undefined8 *param_3)

{
  (**(code **)(param_1 + 0x10))(*param_3,*(undefined4 *)(param_3 + 1));
  return;
}



/* FUNCTION 16746 ; VA 0x00934f00 ; FUN_00934f00 */

void __thiscall FUN_00934f00(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x10))(*param_3);
  return;
}



/* FUNCTION 16747 ; VA 0x00934f30 ; FUN_00934f30 */

void __thiscall FUN_00934f30(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_dc [200];
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088cfa0();
  if (iVar1 == iVar3) {
    iVar1 = *piVar2;
    iVar3 = FUN_0088cfa0();
    if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
  }
  else {
    puVar4 = (undefined4 *)piVar2[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(piVar2 + 2,auStack_dc);
      puVar4 = (undefined4 *)piVar2[1];
    }
    uStack_8 = 0;
    param_3 = (int *)FUN_0088a610();
    param_3 = (int *)*param_3;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_dc);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_14)(param_2,&param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16748 ; VA 0x00935030 ; FUN_00935030 */

void __thiscall FUN_00935030(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_110 [200];
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  code *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c958b;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 0x34);
  pcStack_18 = *(code **)(*piStack_14 + 0x10);
  iVar1 = *param_3;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00b00260();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_00b00260();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iStack_48 = *piVar3;
    iStack_44 = piVar3[1];
    iStack_40 = piVar3[2];
    iStack_3c = piVar3[3];
    iStack_38 = piVar3[4];
    iStack_34 = piVar3[5];
    iStack_30 = piVar3[6];
    iStack_2c = piVar3[7];
    iStack_28 = piVar3[8];
    iStack_24 = piVar3[9];
    iStack_20 = piVar3[10];
    iStack_1c = piVar3[0xb];
  }
  else {
    puVar4 = (undefined4 *)param_3[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_3 + 2,auStack_110);
      puVar4 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_0088ab30();
    iStack_48 = *piVar3;
    iStack_44 = piVar3[1];
    iStack_40 = piVar3[2];
    iStack_3c = piVar3[3];
    iStack_38 = piVar3[4];
    iStack_34 = piVar3[5];
    iStack_30 = piVar3[6];
    iStack_2c = piVar3[7];
    iStack_28 = piVar3[8];
    iStack_24 = piVar3[9];
    iStack_20 = piVar3[10];
    iStack_1c = piVar3[0xb];
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_110);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_18)(param_2,&iStack_48);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16749 ; VA 0x00935150 ; FUN_00935150 */

void __thiscall FUN_00935150(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  undefined auStack_e8 [200];
  undefined8 uStack_20;
  int iStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c95ab;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d870();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_0088d870();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    uStack_20 = *(undefined8 *)piVar3;
    iStack_18 = piVar3[2];
  }
  else {
    puVar4 = (undefined4 *)param_3[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_3 + 2,auStack_e8);
      puVar4 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    puVar5 = (undefined8 *)FUN_0088b880();
    uStack_20 = *puVar5;
    iStack_18 = *(int *)(puVar5 + 1);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_e8);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_14)(param_2,&uStack_20);
  ExceptionList = pvStack_10;
  return;
}


