/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 29750 ; VA 0x00c90280 ; FUN_00c90280 */

uint FUN_00c90280(void)

{
  int iVar1;
  
  iVar1 = FUN_00c8dce0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29751 ; VA 0x00c902a0 ; FUN_00c902a0 */

uint FUN_00c902a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c8dde0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29752 ; VA 0x00c902c0 ; FUN_00c902c0 */

void FUN_00c902c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1e11c9c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_61c9cac990edfc08812518c78ca15681>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 29753 ; VA 0x00c90320 ; FUN_00c90320 */

void __thiscall FUN_00c90320(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  bool bVar8;
  
  iVar3 = param_2[1];
  if (iVar3 == 0) {
LAB_00c90372:
    iVar3 = 0;
  }
  else {
    iVar5 = *(int *)(iVar3 + 0x34);
    if ((iVar5 != 0) && (iVar3 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      iVar3 = FUN_005c8ac0();
    }
    if ((iVar3 == 0) ||
       (iVar5 = *(int *)(iVar3 + 0xc), iVar4 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar4 + 0x1da) <
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) goto LAB_00c90372;
  }
  iVar5 = param_2[2];
  if (iVar5 != 0) {
    iVar4 = *(int *)(iVar5 + 0x34);
    if ((iVar4 != 0) && (iVar5 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
      iVar5 = FUN_005c8ac0();
    }
    if ((iVar5 != 0) &&
       (iVar4 = *(int *)(iVar5 + 0xc), iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
       (uint)*(ushort *)(iVar6 + 0x1da))) goto LAB_00c903b9;
  }
  iVar5 = 0;
LAB_00c903b9:
  bVar8 = *param_2 == param_1 || iVar3 != iVar5;
  iVar4 = FUN_00a9bfa0(param_2[1]);
  iVar6 = FUN_00a9bfa0(param_2[2]);
  if ((iVar6 != 0) && (iVar6 != iVar4)) {
    bVar8 = true;
  }
  if (DAT_01f2d868 != '\0') {
    if ((iVar3 == 0) && (iVar5 != 0)) {
      iVar4 = *(int *)(param_1 + 0x94);
      if (iVar4 != 0) {
        iVar6 = *(int *)(iVar4 + 4);
        while (iVar6 != 0) {
          LOCK();
          iVar7 = *(int *)(iVar4 + 4);
          if (iVar6 == iVar7) {
            *(int *)(iVar4 + 4) = iVar6 + 1;
            iVar7 = iVar6;
          }
          UNLOCK();
          if (iVar7 == iVar6) {
            if ((*(int *)(param_1 + 0x90) != 0) && (iVar5 == *(int *)(param_1 + 0x90))) {
              bVar8 = false;
            }
            break;
          }
          iVar6 = *(int *)(iVar4 + 4);
        }
      }
      FUN_00550b30();
    }
    *(undefined4 *)(param_1 + 0x90) = 0;
    piVar1 = *(int **)(param_1 + 0x94);
    *(undefined4 *)(param_1 + 0x94) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if ((iVar3 != 0) && (bVar8)) {
    if ((DAT_01d68a9c == '\0') && (cVar2 = FUN_00971ce0(iVar3,1), cVar2 == '\0')) {
      *(undefined4 *)(param_1 + 0x98) = 0;
    }
    else {
      FUN_00c91530(0,iVar3);
    }
  }
  FUN_008a3ee0(param_2);
  if (((iVar5 != 0) && (bVar8)) &&
     ((DAT_01d68a9c != '\0' || (cVar2 = FUN_00971ce0(iVar5,1), cVar2 != '\0')))) {
    FUN_00c90c50(iVar5);
  }
  return;
}



/* FUNCTION 29754 ; VA 0x00c90520 ; FUN_00c90520 */

void __thiscall FUN_00c90520(int param_1,undefined4 param_2)

{
  int *piVar1;
  uint uVar2;
  
  for (uVar2 = 0;
      (piVar1 = *(int **)(param_1 + -0x44), piVar1 != (int *)0x0 &&
      (uVar2 < (uint)(piVar1[1] - *piVar1 >> 3))); uVar2 = uVar2 + 1) {
    piVar1 = (int *)FUN_0170d75d(*(undefined4 *)(*piVar1 + uVar2 * 8),0,
                                 &RBX::Instance::RTTI_Type_Descriptor,
                                 &RBX::CameraSubject::RTTI_Type_Descriptor,0);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 8))(param_2);
    }
  }
  return;
}



/* FUNCTION 29755 ; VA 0x00c90580 ; FUN_00c90580 */

void __fastcall FUN_00c90580(int param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    if ((iVar1 != 0) && (iVar3 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      iVar3 = FUN_005c8ac0();
    }
    if (((iVar3 != 0) &&
        (iVar1 = *(int *)(iVar3 + 0xc), iVar3 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da))) && (cVar2 = FUN_00971ce0(param_1,1), cVar2 != '\0')) {
      uVar4 = FUN_005c8880(param_1);
      FUN_00c90c50(uVar4);
    }
  }
  return;
}



/* FUNCTION 29756 ; VA 0x00c905f0 ; FUN_00c905f0 */

void FUN_00c905f0(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  bool bVar6;
  
  iVar4 = *(int *)(param_2 + 4);
  iVar1 = *(int *)(param_2 + 8);
  if (iVar4 == iVar1) {
    return;
  }
  if (iVar4 == 0) {
    iVar3 = 0;
  }
  else {
    iVar5 = *(int *)(iVar4 + 0xc);
    iVar2 = FUN_00c8dce0();
    iVar3 = 0;
    if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar3 = iVar4;
    }
    if (iVar3 == 0) {
      iVar3 = FUN_00c8e600();
    }
  }
  if (iVar1 == 0) {
    iVar4 = 0;
  }
  else {
    iVar4 = *(int *)(iVar1 + 0xc);
    iVar2 = FUN_00c8dce0();
    iVar5 = 0;
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar5 = iVar1;
    }
    bVar6 = iVar5 == 0;
    if (!bVar6) goto LAB_00c90685;
    iVar4 = FUN_00c8e600();
  }
  bVar6 = iVar4 == 0;
LAB_00c90685:
  if ((iVar3 != 0) != !bVar6) {
    FUN_00c91b50(param_1,!bVar6);
  }
  return;
}



/* FUNCTION 29757 ; VA 0x00c906b0 ; FUN_00c906b0 */

void __thiscall FUN_00c906b0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810082;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d68a9c != '\0') {
    ExceptionList = &pvStack_10;
    if (param_2 != 0) {
      ExceptionList = &pvStack_10;
      FUN_01679490();
      FUN_01679490();
    }
    if (((DAT_01d68a9c != '\0') && (param_3 != 0)) &&
       (cVar4 = FUN_00971ce0(param_3,1), cVar4 != '\0')) {
      FUN_006eccd0();
      uStack_8 = 0;
      uVar5 = FUN_01675290(DAT_02110da8);
      uStack_8 = 1;
      puVar6 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar6 == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        *puVar6 = 0;
        puVar6[1] = 1;
        puVar6[2] = FUN_00c8f530;
        puVar6[3] = _guard_check_icall;
        puVar6[4] = 0;
        puVar6[5] = param_1 + 0xdc;
        puVar6[6] = param_1;
      }
      FUN_016797d0(puVar6);
      if (puVar6 != (undefined4 *)0x0) {
        LOCK();
        puVar6[1] = puVar6[1] + 1;
        UNLOCK();
      }
      uStack_8 = 2;
      FUN_01675290(uVar5);
      iVar3 = *(int *)(param_1 + 0x88);
      uStack_8 = 0xffffffff;
      *(undefined4 **)(param_1 + 0x88) = puVar6;
      if (iVar3 != 0) {
        piVar1 = (int *)(iVar3 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(iVar3);
        }
      }
      FUN_006eccd0();
      uStack_8 = 3;
      uVar5 = FUN_01675290(DAT_02110da8);
      uStack_8 = 4;
      puVar6 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar6 == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        *puVar6 = 0;
        puVar6[1] = 1;
        puVar6[2] = FUN_00c8f5f0;
        puVar6[3] = _guard_check_icall;
        puVar6[4] = 0;
        puVar6[5] = param_1 + 0xe4;
        puVar6[6] = param_1;
        puVar6[7] = param_3;
      }
      FUN_016797d0(puVar6);
      if (puVar6 != (undefined4 *)0x0) {
        LOCK();
        puVar6[1] = puVar6[1] + 1;
        UNLOCK();
      }
      uStack_8 = 5;
      FUN_01675290(uVar5);
      iVar3 = *(int *)(param_1 + 0x8c);
      *(undefined4 **)(param_1 + 0x8c) = puVar6;
      uStack_8 = 0xffffffff;
      if (iVar3 != 0) {
        piVar1 = (int *)(iVar3 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(iVar3);
        }
      }
    }
  }
  FUN_008a4210(param_2,param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29758 ; VA 0x00c90900 ; FUN_00c90900 */

void __fastcall FUN_00c90900(int param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  code *pcVar6;
  undefined auStack_b4 [48];
  undefined auStack_84 [48];
  undefined auStack_54 [24];
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018100c1;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009ba880(*(undefined4 *)(param_1 + 0x34));
  if (iVar2 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  piVar3 = (int *)FUN_00c48580();
  if (piVar3 == (int *)0x0) {
    ExceptionList = pvStack_10;
    return;
  }
  piStack_14 = piVar3;
  iStack_1c = FUN_0099fa70();
  if (((iStack_1c == 0) ||
      (piStack_20 = (int *)FUN_00c8fca0(*(undefined4 *)(param_1 + 0x34),
                                        *(undefined4 *)(iStack_1c + 0x28)), piStack_20 == (int *)0x0
      )) || (iStack_18 = FUN_006e16a0(*(undefined4 *)((int)piStack_20 + 0x34)), iStack_18 == 0)) {
    iStack_1c = FUN_009b4d50();
    if (iStack_1c == 0) goto LAB_00c90b2b;
    (**(code **)(*piVar3 + 0x124))(0);
    uVar4 = FUN_009b71c0(auStack_84);
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = 0;
    FUN_005542c0("HeadWeld",8);
    uStack_8 = 1;
    FUN_00c3b990(param_1 + 0x78,auStack_3c,iStack_1c,piVar3,uVar4,param_1 + 0x9c);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
    if (DAT_01f2d868 == '\0') goto LAB_00c90b2b;
    pcVar6 = *(code **)(*piVar3 + 0x108);
    FUN_00b077e0();
    uVar4 = FUN_00c3bd20();
    FUN_0071f260(auStack_84,uVar4);
    FUN_00c3bd10();
  }
  else {
    (**(code **)(*piVar3 + 0x124))(0);
    uVar4 = FUN_00d6c620(auStack_b4);
    uVar5 = FUN_00d6c620(auStack_84);
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = 0;
    FUN_005542c0("AccessoryWeld",0xd);
    piVar3 = piStack_14;
    uStack_8 = 0;
    FUN_00c3b990(param_1 + 0x78,auStack_3c,piStack_14,iStack_18,uVar5,uVar4);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
    if (DAT_01f2d868 == '\0') goto LAB_00c90b2b;
    pcVar6 = *(code **)(*piVar3 + 0x108);
    FUN_00b077e0();
    uVar4 = FUN_00c3bd10();
    FUN_0071f260(auStack_84,uVar4);
    FUN_00c3bd20();
  }
  uVar4 = FUN_0071fcc0(auStack_b4);
  uVar4 = FUN_0071f260(auStack_54,uVar4);
  (*pcVar6)(uVar4);
LAB_00c90b2b:
  FUN_01679490();
  iVar2 = FUN_00c48580();
  if ((iVar2 != 0) && (iStack_18 = FUN_0099fa70(), iStack_18 != 0)) {
    iStack_18 = iStack_18 + 0x4c;
    uStack_8 = 2;
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 3;
    iStack_1c = uVar4;
    piStack_20 = (int *)FUN_01674e20(0x1c);
    if (piStack_20 == (int *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      *piStack_20 = 0;
      piStack_20[1] = 1;
      piStack_20[2] = (int)FUN_00c8f510;
      piStack_20[3] = (int)_guard_check_icall;
      piStack_20[4] = 0;
      piStack_20[5] = iStack_18;
      piStack_20[6] = param_1;
      piVar3 = piStack_20;
    }
    FUN_016797d0(piVar3);
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
    }
    uStack_24 = 1;
    uStack_8._0_1_ = 4;
    piStack_14 = piVar3;
    FUN_01675290(uVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    cVar1 = FUN_01679300(&piStack_14);
    if (cVar1 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_14);
    }
    if (piStack_14 != (int *)0x0) {
      piVar3 = piStack_14 + 1;
      LOCK();
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(piStack_14);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29759 ; VA 0x00c90c50 ; FUN_00c90c50 */

void __thiscall FUN_00c90c50(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  byte bVar3;
  
  iVar2 = FUN_00c48580();
  if (iVar2 == 0) {
    bVar3 = 0;
  }
  else {
    cVar1 = FUN_00a97920(param_1);
    if (cVar1 == '\0') {
      bVar3 = 1;
    }
    else {
      iVar2 = FUN_009ba880(*(undefined4 *)(param_1 + 0x34));
      if (iVar2 == 0) {
        bVar3 = 2;
      }
      else {
        iVar2 = FUN_009b7250();
        bVar3 = -(iVar2 != 0) & 4;
      }
    }
  }
  if (param_2 == 0) {
    param_2 = FUN_005c8880(param_1);
  }
  FUN_00c91530(bVar3,param_2);
  return;
}



/* FUNCTION 29760 ; VA 0x00c90cc0 ; FUN_00c90cc0 */

void __thiscall FUN_00c90cc0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  uint uVar2;
  
  for (uVar2 = 0;
      (piVar1 = *(int **)(param_1 + -0x28), piVar1 != (int *)0x0 &&
      (uVar2 < (uint)(piVar1[1] - *piVar1 >> 3))); uVar2 = uVar2 + 1) {
    piVar1 = (int *)FUN_0170d75d(*(undefined4 *)(*piVar1 + uVar2 * 8),0,
                                 &RBX::Instance::RTTI_Type_Descriptor,
                                 &RBX::IAdornable::RTTI_Type_Descriptor,0);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x1c))(param_2,param_3);
    }
  }
  return;
}



/* FUNCTION 29761 ; VA 0x00c90d20 ; FUN_00c90d20 */

/* WARNING: Removing unreachable block (ram,0x00c90e2e) */
/* WARNING: Removing unreachable block (ram,0x00c90e3a) */
/* WARNING: Removing unreachable block (ram,0x00c90e48) */

undefined4 FUN_00c90d20(int *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01810101;
  pvStack_10 = ExceptionList;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_20 = param_2;
  uStack_1c = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  pcStack_18 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_104 = FUN_0088cdc0();
  uStack_100 = 0;
  uStack_fc = param_2;
  uStack_f8 = param_3;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_100 = FUN_006309e0();
  uStack_8 = 2;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687980(&uStack_104,&uStack_34,param_1);
  uStack_8 = 3;
  (*pcStack_18)(uStack_14,&uStack_2c,&uStack_34);
  uStack_8 = 4;
  FUN_00577b20();
  _uStack_8 = CONCAT31(uStack_7,1);
  uVar1 = FUN_016f32d1(&uStack_104,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 29762 ; VA 0x00c90e70 ; FUN_00c90e70 */

void __thiscall FUN_00c90e70(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  char cVar13;
  uint *puVar14;
  undefined auStack_40 [12];
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  uVar1 = *(undefined4 *)(param_1 + 0x9c);
  uVar2 = *(undefined4 *)(param_1 + 0xa0);
  uVar3 = *(undefined4 *)(param_1 + 0xa4);
  uVar4 = *(undefined4 *)(param_1 + 0xa8);
  uVar5 = *(undefined4 *)(param_1 + 0xac);
  uVar6 = *(undefined4 *)(param_1 + 0xb0);
  uVar7 = *(undefined4 *)(param_1 + 0xb4);
  uVar8 = *(undefined4 *)(param_1 + 0xb8);
  uVar9 = *(undefined4 *)(param_1 + 0xbc);
  fVar10 = *(float *)(param_1 + 0xc0);
  fVar11 = *(float *)(param_1 + 0xc4);
  fVar12 = *(float *)(param_1 + 200);
  FUN_011612d0(&fStack_34,1);
  puVar14 = (uint *)FUN_00c94eb0(auStack_40,param_2);
  fStack_1c = (float)(*puVar14 ^ DAT_018c4ea0);
  fStack_18 = (float)(puVar14[1] ^ DAT_018c4ea0);
  fStack_14 = (float)(puVar14[2] ^ DAT_018c4ea0);
  fStack_10 = fStack_30 * fStack_14 - fStack_2c * fStack_18;
  fStack_c = fStack_1c * fStack_2c - fStack_34 * fStack_14;
  fStack_8 = fStack_34 * fStack_18 - fStack_1c * fStack_30;
  FUN_01165610(0x358637bd);
  fStack_28 = fStack_8 * fStack_18 - fStack_c * fStack_14;
  fStack_24 = fStack_10 * fStack_14 - fStack_8 * fStack_1c;
  fStack_20 = fStack_c * fStack_1c - fStack_10 * fStack_18;
  FUN_01165610(0x358637bd);
  FUN_01162b00(0,&fStack_10);
  FUN_01162b00(1,&fStack_28);
  FUN_01162b00(2,&fStack_1c);
  if (((((NAN(fVar10) || NAN(*(float *)(param_1 + 0xc0))) != (fVar10 == *(float *)(param_1 + 0xc0)))
       && ((NAN(fVar11) || NAN(*(float *)(param_1 + 0xc4))) !=
           (fVar11 == *(float *)(param_1 + 0xc4)))) &&
      ((NAN(fVar12) || NAN(*(float *)(param_1 + 200))) != (fVar12 == *(float *)(param_1 + 200)))) &&
     (cVar13 = FUN_01160ab0((undefined4 *)(param_1 + 0x9c)), cVar13 != '\0')) {
    return;
  }
  *(undefined4 *)(param_1 + 0x9c) = uVar1;
  *(undefined4 *)(param_1 + 0xa0) = uVar2;
  *(undefined4 *)(param_1 + 0xa4) = uVar3;
  *(undefined4 *)(param_1 + 0xa8) = uVar4;
  *(undefined4 *)(param_1 + 0xac) = uVar5;
  *(undefined4 *)(param_1 + 0xb0) = uVar6;
  *(undefined4 *)(param_1 + 0xb4) = uVar7;
  *(undefined4 *)(param_1 + 0xb8) = uVar8;
  *(undefined4 *)(param_1 + 0xbc) = uVar9;
  *(float *)(param_1 + 0xc0) = fVar10;
  *(float *)(param_1 + 0xc4) = fVar11;
  *(float *)(param_1 + 200) = fVar12;
  FUN_008a4940(&DAT_0213a2d8);
  FUN_00c91c30();
  return;
}



/* FUNCTION 29763 ; VA 0x00c91040 ; FUN_00c91040 */

void __thiscall FUN_00c91040(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  
  if (((((NAN((float)param_2[9]) || NAN(*(float *)(param_1 + 0xc0))) !=
         ((float)param_2[9] == *(float *)(param_1 + 0xc0))) &&
       ((NAN((float)param_2[10]) || NAN(*(float *)(param_1 + 0xc4))) !=
        ((float)param_2[10] == *(float *)(param_1 + 0xc4)))) &&
      ((NAN((float)param_2[0xb]) || NAN(*(float *)(param_1 + 200))) !=
       ((float)param_2[0xb] == *(float *)(param_1 + 200)))) &&
     (cVar4 = FUN_01160ab0((undefined4 *)(param_1 + 0x9c)), cVar4 != '\0')) {
    return;
  }
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *(undefined4 *)(param_1 + 0x9c) = *param_2;
  *(undefined4 *)(param_1 + 0xa0) = uVar1;
  *(undefined4 *)(param_1 + 0xa4) = uVar2;
  *(undefined4 *)(param_1 + 0xa8) = uVar3;
  uVar1 = param_2[5];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  *(undefined4 *)(param_1 + 0xac) = param_2[4];
  *(undefined4 *)(param_1 + 0xb0) = uVar1;
  *(undefined4 *)(param_1 + 0xb4) = uVar2;
  *(undefined4 *)(param_1 + 0xb8) = uVar3;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  *(undefined4 *)(param_1 + 0xbc) = param_2[8];
  *(undefined4 *)(param_1 + 0xc0) = uVar1;
  *(undefined4 *)(param_1 + 0xc4) = uVar2;
  *(undefined4 *)(param_1 + 200) = uVar3;
  FUN_008a4940(&DAT_0213a2d8);
  FUN_00c91c30();
  return;
}



/* FUNCTION 29764 ; VA 0x00c910c0 ; FUN_00c910c0 */

void __thiscall FUN_00c910c0(int param_1,undefined8 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  char cVar12;
  float fStack_10;
  float fStack_c;
  
  uVar2 = *(undefined4 *)(param_1 + 0xbc);
  puVar1 = (undefined4 *)(param_1 + 0x9c);
  uVar4 = *puVar1;
  uVar5 = *(undefined4 *)(param_1 + 0xa0);
  uVar6 = *(undefined4 *)(param_1 + 0xa4);
  uVar7 = *(undefined4 *)(param_1 + 0xa8);
  uVar8 = *(undefined4 *)(param_1 + 0xac);
  uVar9 = *(undefined4 *)(param_1 + 0xb0);
  uVar10 = *(undefined4 *)(param_1 + 0xb4);
  uVar11 = *(undefined4 *)(param_1 + 0xb8);
  fVar3 = *(float *)(param_2 + 1);
  fStack_10 = (float)*param_2;
  fStack_c = (float)((ulonglong)*param_2 >> 0x20);
  if (((((NAN(fStack_10) || NAN(*(float *)(param_1 + 0xc0))) ==
         (fStack_10 == *(float *)(param_1 + 0xc0))) ||
       ((NAN(fStack_c) || NAN(*(float *)(param_1 + 0xc4))) ==
        (fStack_c == *(float *)(param_1 + 0xc4)))) ||
      ((NAN(fVar3) || NAN(*(float *)(param_1 + 200))) == (fVar3 == *(float *)(param_1 + 200)))) ||
     (cVar12 = FUN_01160ab0(puVar1), cVar12 == '\0')) {
    *puVar1 = uVar4;
    *(undefined4 *)(param_1 + 0xa0) = uVar5;
    *(undefined4 *)(param_1 + 0xa4) = uVar6;
    *(undefined4 *)(param_1 + 0xa8) = uVar7;
    *(undefined4 *)(param_1 + 0xac) = uVar8;
    *(undefined4 *)(param_1 + 0xb0) = uVar9;
    *(undefined4 *)(param_1 + 0xb4) = uVar10;
    *(undefined4 *)(param_1 + 0xb8) = uVar11;
    *(undefined4 *)(param_1 + 0xbc) = uVar2;
    *(float *)(param_1 + 0xc0) = fStack_10;
    *(float *)(param_1 + 0xc4) = fStack_c;
    *(float *)(param_1 + 200) = fVar3;
    FUN_008a4940(&DAT_0213a2d8);
    FUN_00c91c30();
  }
  return;
}



/* FUNCTION 29765 ; VA 0x00c91170 ; FUN_00c91170 */

void __thiscall FUN_00c91170(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  char cVar13;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  uVar1 = *(undefined4 *)(param_1 + 0x9c);
  uVar2 = *(undefined4 *)(param_1 + 0xa0);
  uVar3 = *(undefined4 *)(param_1 + 0xa4);
  uVar4 = *(undefined4 *)(param_1 + 0xa8);
  uVar5 = *(undefined4 *)(param_1 + 0xac);
  uVar6 = *(undefined4 *)(param_1 + 0xb0);
  uVar7 = *(undefined4 *)(param_1 + 0xb4);
  uVar8 = *(undefined4 *)(param_1 + 0xb8);
  uVar9 = *(undefined4 *)(param_1 + 0xbc);
  fVar10 = *(float *)(param_1 + 0xc0);
  fVar11 = *(float *)(param_1 + 0xc4);
  fVar12 = *(float *)(param_1 + 200);
  FUN_011612d0(&fStack_34,1);
  FUN_00c94eb0(&fStack_10,param_2);
  fStack_1c = fStack_c * fStack_2c - fStack_8 * fStack_30;
  fStack_18 = fStack_34 * fStack_8 - fStack_10 * fStack_2c;
  fStack_14 = fStack_10 * fStack_30 - fStack_34 * fStack_c;
  FUN_01165610(0x358637bd);
  fStack_28 = fStack_18 * fStack_8 - fStack_14 * fStack_c;
  fStack_20 = fStack_1c * fStack_c - fStack_18 * fStack_10;
  fStack_24 = fStack_14 * fStack_10 - fStack_1c * fStack_8;
  FUN_01165610(0x358637bd);
  FUN_01162b00(0,&fStack_10);
  FUN_01162b00(1,&fStack_28);
  FUN_01162b00(2,&fStack_1c);
  if (((((NAN(fVar10) || NAN(*(float *)(param_1 + 0xc0))) != (fVar10 == *(float *)(param_1 + 0xc0)))
       && ((NAN(fVar11) || NAN(*(float *)(param_1 + 0xc4))) !=
           (fVar11 == *(float *)(param_1 + 0xc4)))) &&
      ((NAN(fVar12) || NAN(*(float *)(param_1 + 200))) != (fVar12 == *(float *)(param_1 + 200)))) &&
     (cVar13 = FUN_01160ab0((undefined4 *)(param_1 + 0x9c)), cVar13 != '\0')) {
    return;
  }
  *(undefined4 *)(param_1 + 0x9c) = uVar1;
  *(undefined4 *)(param_1 + 0xa0) = uVar2;
  *(undefined4 *)(param_1 + 0xa4) = uVar3;
  *(undefined4 *)(param_1 + 0xa8) = uVar4;
  *(undefined4 *)(param_1 + 0xac) = uVar5;
  *(undefined4 *)(param_1 + 0xb0) = uVar6;
  *(undefined4 *)(param_1 + 0xb4) = uVar7;
  *(undefined4 *)(param_1 + 0xb8) = uVar8;
  *(undefined4 *)(param_1 + 0xbc) = uVar9;
  *(float *)(param_1 + 0xc0) = fVar10;
  *(float *)(param_1 + 0xc4) = fVar11;
  *(float *)(param_1 + 200) = fVar12;
  FUN_008a4940(&DAT_0213a2d8);
  FUN_00c91c30();
  return;
}



/* FUNCTION 29766 ; VA 0x00c91320 ; FUN_00c91320 */

void __thiscall FUN_00c91320(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  char cVar13;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  uVar1 = *(undefined4 *)(param_1 + 0x9c);
  uVar2 = *(undefined4 *)(param_1 + 0xa0);
  uVar3 = *(undefined4 *)(param_1 + 0xa4);
  uVar4 = *(undefined4 *)(param_1 + 0xa8);
  uVar5 = *(undefined4 *)(param_1 + 0xac);
  uVar6 = *(undefined4 *)(param_1 + 0xb0);
  uVar7 = *(undefined4 *)(param_1 + 0xb4);
  uVar8 = *(undefined4 *)(param_1 + 0xb8);
  uVar9 = *(undefined4 *)(param_1 + 0xbc);
  fVar10 = *(float *)(param_1 + 0xc0);
  fVar11 = *(float *)(param_1 + 0xc4);
  fVar12 = *(float *)(param_1 + 200);
  FUN_011612d0(&fStack_34,0);
  FUN_00c94eb0(&fStack_10,param_2);
  fStack_1c = fStack_30 * fStack_8 - fStack_2c * fStack_c;
  fStack_18 = fStack_10 * fStack_2c - fStack_34 * fStack_8;
  fStack_14 = fStack_34 * fStack_c - fStack_10 * fStack_30;
  FUN_01165610(0x358637bd);
  fStack_28 = fStack_14 * fStack_c - fStack_18 * fStack_8;
  fStack_24 = fStack_1c * fStack_8 - fStack_14 * fStack_10;
  fStack_20 = fStack_18 * fStack_10 - fStack_1c * fStack_c;
  FUN_01165610(0x358637bd);
  FUN_01162b00(0,&fStack_28);
  FUN_01162b00(1,&fStack_10);
  FUN_01162b00(2,&fStack_1c);
  if (((((NAN(fVar10) || NAN(*(float *)(param_1 + 0xc0))) != (fVar10 == *(float *)(param_1 + 0xc0)))
       && ((NAN(fVar11) || NAN(*(float *)(param_1 + 0xc4))) !=
           (fVar11 == *(float *)(param_1 + 0xc4)))) &&
      ((NAN(fVar12) || NAN(*(float *)(param_1 + 200))) != (fVar12 == *(float *)(param_1 + 200)))) &&
     (cVar13 = FUN_01160ab0((undefined4 *)(param_1 + 0x9c)), cVar13 != '\0')) {
    return;
  }
  *(undefined4 *)(param_1 + 0x9c) = uVar1;
  *(undefined4 *)(param_1 + 0xa0) = uVar2;
  *(undefined4 *)(param_1 + 0xa4) = uVar3;
  *(undefined4 *)(param_1 + 0xa8) = uVar4;
  *(undefined4 *)(param_1 + 0xac) = uVar5;
  *(undefined4 *)(param_1 + 0xb0) = uVar6;
  *(undefined4 *)(param_1 + 0xb4) = uVar7;
  *(undefined4 *)(param_1 + 0xb8) = uVar8;
  *(undefined4 *)(param_1 + 0xbc) = uVar9;
  *(float *)(param_1 + 0xc0) = fVar10;
  *(float *)(param_1 + 0xc4) = fVar11;
  *(float *)(param_1 + 200) = fVar12;
  FUN_008a4940(&DAT_0213a2d8);
  FUN_00c91c30();
  return;
}



/* FUNCTION 29767 ; VA 0x00c914d0 ; FUN_00c914d0 */

void __thiscall FUN_00c914d0(int param_1,uint param_2)

{
  char cVar1;
  int iVar2;
  
  if (((param_2 != *(uint *)(param_1 + 0x98)) && (param_2 < 5)) &&
     ((*(uint *)(param_1 + 0x98) = param_2, DAT_01d68a9c == '\0' ||
      ((iVar2 = FUN_005c8880(param_1), iVar2 != 0 &&
       (cVar1 = FUN_00971ce0(param_1,1), cVar1 != '\0')))))) {
    FUN_008a4940(&DAT_0213a3f0);
  }
  return;
}



/* FUNCTION 29768 ; VA 0x00c91530 ; FUN_00c91530 */

void __thiscall FUN_00c91530(int param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  bool bVar5;
  
  iVar4 = *(int *)(param_1 + 0x98);
  iVar2 = param_2 - iVar4;
  bVar5 = param_2 == iVar4;
  do {
    if (!bVar5 && SBORROW4(param_2,iVar4) == iVar2 < 0) {
      switch(iVar4) {
      case 0:
        FUN_00c8efd0();
        break;
      case 2:
        FUN_00c91920(param_3);
        break;
      case 3:
        FUN_00c91730(param_3);
      }
      uVar1 = *(uint *)(param_1 + 0x98) + 1;
      if (((uVar1 != *(uint *)(param_1 + 0x98)) && (uVar1 < 5)) &&
         ((*(uint *)(param_1 + 0x98) = uVar1, DAT_01d68a9c == '\0' ||
          ((iVar4 = FUN_005c8880(param_1), iVar4 != 0 &&
           (cVar3 = FUN_00971ce0(param_1,1), cVar3 != '\0')))))) {
        FUN_008a4940(&DAT_0213a3f0);
      }
      goto LAB_00c91613;
    }
    if (SBORROW4(param_2,iVar4) == iVar2 < 0) goto LAB_00c91613;
    switch(iVar4) {
    case 1:
      FUN_01679490();
      goto LAB_00c915ff;
    case 3:
      FUN_01679490();
LAB_00c915ff:
      FUN_01679490();
      break;
    case 4:
      FUN_00c8f730(param_3);
    }
    FUN_00c914d0(*(int *)(param_1 + 0x98) + -1);
LAB_00c91613:
    iVar4 = *(int *)(param_1 + 0x98);
    iVar2 = param_2 - iVar4;
    bVar5 = iVar2 == 0;
    if (bVar5) {
      return;
    }
  } while( true );
}



/* FUNCTION 29769 ; VA 0x00c91650 ; FUN_00c91650 */

undefined4 * __thiscall FUN_00c91650(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_00c91530(4,param_2);
  puVar6 = (undefined4 *)FUN_0068f9a0(auStack_c,param_2);
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 *)(param_1 + 0x90) = uVar3;
  piVar5 = *(int **)(param_1 + 0x94);
  *(undefined4 *)(param_1 + 0x94) = uVar4;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 2;
    iVar2 = *piVar1;
    puVar6 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar6 = (undefined4 *)(**(code **)(*piVar5 + 4))();
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_8 + 2;
    iVar2 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puVar6 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
    }
  }
  return puVar6;
}



/* FUNCTION 29770 ; VA 0x00c916d0 ; FUN_00c916d0 */

void __thiscall FUN_00c916d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x18))(param_3);
  return;
}



/* FUNCTION 29771 ; VA 0x00c91700 ; FUN_00c91700 */

void __thiscall FUN_00c91700(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 29772 ; VA 0x00c91730 ; FUN_00c91730 */

void __fastcall FUN_00c91730(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  int iVar9;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined auStack_20 [8];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810120;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iStack_2c = 0;
  iStack_28 = 0;
  iStack_24 = 0;
  uStack_8 = 0;
  FUN_00b061f0(param_1,&iStack_2c);
  FUN_00f29930(&iStack_2c);
  if (DAT_01d68a9c != '\0') {
    iVar9 = *(int *)(param_1 + 0x34);
    if ((iVar9 == 0) ||
       (iVar1 = *(int *)(iVar9 + 0xc), iVar6 = FUN_00b63e30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      iVar9 = 0;
    }
    puVar7 = (undefined4 *)FUN_0060e0c0(auStack_18,iVar9);
    uVar2 = *puVar7;
    uVar3 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(undefined4 *)(param_1 + 0x80) = uVar2;
    piVar4 = *(int **)(param_1 + 0x84);
    *(undefined4 *)(param_1 + 0x84) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar9 = piVar4[2] + -1;
      piVar4[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_14[2] + -1;
      piStack_14[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_00c90900();
  if (((DAT_01d68a9c != '\0') && (iVar9 = FUN_005c8880(param_1), iVar9 != 0)) &&
     (cVar5 = FUN_0097c970(param_1,1), cVar5 != '\0')) {
    puVar7 = (undefined4 *)FUN_00587490(auStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uVar2 = *puVar7;
    uVar3 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    FUN_00c90d20(param_1,uVar2,uVar3);
    FUN_00550b30();
  }
  iVar1 = iStack_28;
  iVar9 = iStack_2c;
  if (iStack_2c != 0) {
    for (; iVar9 != iVar1; iVar9 = iVar9 + 8) {
      piVar4 = *(int **)(iVar9 + 4);
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar6 = piVar4[2] + -1;
        piVar4[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    uVar8 = iStack_24 - iStack_2c & 0xfffffff8;
    iVar9 = iStack_2c;
    if (0xfff < uVar8) {
      iVar9 = *(int *)(iStack_2c + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iStack_2c - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29773 ; VA 0x00c91920 ; FUN_00c91920 */

void __thiscall FUN_00c91920(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01810172;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  uStack_1c = param_1;
  iVar3 = FUN_008a4100();
  puStack_20 = (undefined4 *)(iVar3 + 8);
  iStack_8 = 0;
  uVar4 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 1;
  puStack_14 = (undefined4 *)FUN_01674e20(0x20);
  if (puStack_14 == (undefined4 *)0x0) {
    puStack_14 = (undefined4 *)0x0;
  }
  else {
    *puStack_14 = 0;
    puStack_14[1] = 1;
    puStack_14[2] = FUN_00c8f430;
    puStack_14[3] = _guard_check_icall;
    puStack_14[4] = 0;
    puStack_14[5] = puStack_20;
    puStack_14[6] = param_1;
    puStack_14[7] = param_2;
  }
  FUN_016797d0(puStack_14);
  if (puStack_14 != (undefined4 *)0x0) {
    LOCK();
    puStack_14[1] = puStack_14[1] + 1;
    UNLOCK();
  }
  uStack_18 = 1;
  iStack_8._0_1_ = 2;
  FUN_01675290(uVar4);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  cVar2 = FUN_01679300(&puStack_14);
  if (cVar2 != '\0') {
    FUN_01679490();
    FUN_016791c0(&puStack_14);
  }
  uStack_18 = 0;
  iStack_8 = 0xffffffff;
  if (puStack_14 != (undefined4 *)0x0) {
    piVar1 = puStack_14 + 1;
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(puStack_14);
    }
  }
  iVar3 = FUN_008a4100();
  puStack_14 = (undefined4 *)(iVar3 + 0xc);
  iStack_8 = 3;
  uVar4 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 4;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00c8f340;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[6] = uStack_1c;
    puVar5[5] = puStack_14;
    puVar5[7] = param_2;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_18 = 2;
  iStack_8._0_1_ = 5;
  puStack_20 = puVar5;
  FUN_01675290(uVar4);
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  cVar2 = FUN_01679300(&puStack_20);
  if (cVar2 != '\0') {
    FUN_01679490();
    FUN_016791c0(&puStack_20);
  }
  if (puStack_20 != (undefined4 *)0x0) {
    piVar1 = puStack_20 + 1;
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(puStack_20);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29774 ; VA 0x00c91b50 ; FUN_00c91b50 */

int * FUN_00c91b50(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined auStack_c [4];
  int *piStack_8;
  
  if ((param_1 != (int *)0x0) &&
     (iVar3 = param_1[3], iVar5 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
     (uint)*(ushort *)(iVar5 + 0x1da))) {
    FUN_00b0db90(param_2);
  }
  piVar6 = (int *)(**(code **)(*param_1 + 0x40))(auStack_c);
  piVar2 = piStack_8;
  iVar3 = *piVar6;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_8 + 1;
    iVar5 = *piVar1;
    piVar6 = (int *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        piVar6 = (int *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (iVar3 != 0) {
    piVar6 = (int *)(**(code **)(*param_1 + 0x40))(auStack_c);
    puVar7 = (undefined4 *)*piVar6;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_8 + 1;
      iVar3 = *piVar2;
      piVar6 = (int *)*piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar6 = (int *)(**(code **)*piStack_8)();
        LOCK();
        piVar2 = piStack_8 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piVar6 = (int *)(**(code **)(*piStack_8 + 4))();
        }
      }
    }
    puVar4 = (undefined4 *)puVar7[1];
    for (puVar7 = (undefined4 *)*puVar7; puVar7 != puVar4; puVar7 = puVar7 + 2) {
      piVar6 = (int *)FUN_00c91b50(*puVar7,param_2);
    }
  }
  return piVar6;
}



/* FUNCTION 29775 ; VA 0x00c91c30 ; FUN_00c91c30 */

void __fastcall FUN_00c91c30(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined auStack_34 [48];
  
  if (*(int *)(param_1 + 0x78) != 0) {
    iVar3 = 0;
    iVar1 = FUN_00c48580();
    if ((iVar1 != 0) && (*(int *)(*(int *)(param_1 + 0x78) + 0x34) == iVar1)) {
      iVar3 = FUN_0099fa70();
    }
    if (iVar3 != 0) {
      uVar2 = FUN_00d6c620(auStack_34);
      FUN_00c3ceb0(uVar2);
      return;
    }
    FUN_00c3cee0(param_1 + 0x9c);
  }
  return;
}



/* FUNCTION 29776 ; VA 0x00c91ca0 ; FUN_00c91ca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c91ca0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018101a0;
  pvStack_10 = ExceptionList;
  if (DAT_01f01ce0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01ef8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f01ef8);
      if (DAT_01f01ef8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Backpack",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f01ef0 = RBX::Creator<class_RBX::Backpack>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f01ce8,&DAT_01f01ef0);
        FUN_016f3654(FUN_01897b40);
        FUN_016f37bf(&DAT_01f01ef8);
      }
    }
    DAT_01f01ce0 = &DAT_01f01ce8;
  }
  ExceptionList = pvStack_10;
  return DAT_01f01ce0;
}



/* FUNCTION 29777 ; VA 0x00c91da0 ; FUN_00c91da0 */

undefined4 * __fastcall FUN_00c91da0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018101c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Backpack,class_RBX::Instance>::vftable;
  uVar1 = FUN_00c91ca0();
  param_1[3] = uVar1;
  param_1[0x15] = RBX::IScriptFilter::vftable;
  uStack_8 = 1;
  *param_1 = RBX::Backpack::vftable;
  param_1[0x15] = RBX::Backpack::vftable;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("Backpack",8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29778 ; VA 0x00c91e70 ; FUN_00c91e70 */

void __fastcall FUN_00c91e70(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Backpack>::vftable;
  uVar1 = FUN_00c91ca0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29779 ; VA 0x00c91eb0 ; FUN_00c91eb0 */

undefined4 * FUN_00c91eb0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00915f80(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29780 ; VA 0x00c91f20 ; FUN_00c91f20 */

void FUN_00c91f20(void)

{
  int iVar1;
  
  if (DAT_01f01efc == 0) {
    iVar1 = FUN_00c91ca0();
    DAT_01f01efc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29781 ; VA 0x00c91f40 ; FUN_00c91f40 */

uint FUN_00c91f40(void)

{
  int iVar1;
  
  iVar1 = FUN_00c91ca0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29782 ; VA 0x00c91f60 ; FUN_00c91f60 */

uint FUN_00c91f60(void)

{
  int iVar1;
  
  iVar1 = FUN_00c91ca0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29783 ; VA 0x00c91f80 ; FUN_00c91f80 */

undefined4 __thiscall FUN_00c91f80(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  iVar1 = param_1 + -0x54;
  iVar4 = FUN_008b2e60(iVar1);
  if (iVar4 == 0) {
    return 0;
  }
  iVar5 = FUN_0097bfc0(iVar1);
  iVar4 = *(int *)(param_1 + -0x20);
  iVar7 = *(int *)(param_2 + 0xc);
  iVar6 = FUN_00b739e0();
  iVar8 = 0;
  if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
      (uint)*(ushort *)(iVar6 + 0x1da)) {
    iVar8 = param_2;
  }
  if ((iVar4 == iVar5) && (iVar8 != 0)) {
    return 1;
  }
  cVar2 = FUN_00971ce0(iVar1,1);
  if (DAT_01d68ab4 == '\0') {
    cVar3 = cVar2;
    if (iVar8 != 0) {
      return 0;
    }
    goto LAB_00c9204f;
  }
  iVar1 = *(int *)(param_1 + -0x20);
  if (iVar1 == 0) {
LAB_00c92039:
    cVar3 = '\0';
  }
  else {
    iVar4 = *(int *)(iVar1 + 0xc);
    iVar5 = FUN_00913630();
    iVar7 = 0;
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      iVar7 = iVar1;
    }
    if (iVar7 == 0) goto LAB_00c92039;
    cVar3 = '\x01';
  }
  if (iVar8 != 0) {
    return 0;
  }
  if (cVar2 == '\0') {
    return 0;
  }
LAB_00c9204f:
  if (cVar3 == '\0') {
    return 0;
  }
  return 1;
}



/* FUNCTION 29784 ; VA 0x00c92070 ; FUN_00c92070 */

undefined4 * __thiscall FUN_00c92070(undefined4 *param_1,undefined8 *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  double dVar3;
  float fVar4;
  
  *param_1 = G3D::Line::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined8 *)(param_1 + 1) = *param_2;
  param_1[3] = *(undefined4 *)(param_2 + 1);
  fVar1 = *param_3;
  dVar3 = (double)(fVar1 * fVar1 + param_3[1] * param_3[1] + param_3[2] * param_3[2]);
  FUN_017267a0();
  fVar4 = DAT_018ce2f8 / (float)dVar3;
  fVar2 = param_3[2];
  *(ulonglong *)(param_1 + 4) = CONCAT44(param_3[1] * fVar4,fVar1 * fVar4);
  param_1[6] = fVar2 * fVar4;
  return param_1;
}



/* FUNCTION 29785 ; VA 0x00c92140 ; FUN_00c92140 */

void __fastcall FUN_00c92140(undefined4 *param_1)

{
  *param_1 = G3D::Line::vftable;
  return;
}



/* FUNCTION 29786 ; VA 0x00c92150 ; FUN_00c92150 */

undefined4 * __thiscall FUN_00c92150(undefined4 *param_1,byte param_2)

{
  *param_1 = G3D::Line::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 29787 ; VA 0x00c92180 ; FUN_00c92180 */

float10 FUN_00c92180(float *param_1,float *param_2)

{
  double dVar1;
  float fVar2;
  
  fVar2 = param_1[1] * param_2[1] + *param_1 * *param_2 + param_1[2] * param_2[2];
  if (DAT_018ce2f8 <= fVar2) {
    return (float10)0.0;
  }
  if (fVar2 <= DAT_018f7864) {
    return (float10)3.1415927;
  }
  dVar1 = (double)fVar2;
  FUN_01729d90();
  return (float10)(float)dVar1;
}



/* FUNCTION 29788 ; VA 0x00c92200 ; FUN_00c92200 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00c92200(float param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = (float)(double)CONCAT44((uint)((ulonglong)(double)param_1 >> 0x20) & DAT_018c0da0._4_4_,
                                  SUB84((double)param_1,0) & (uint)DAT_018c0da0) + DAT_01973588;
  if (param_2 < 0.0) {
    fVar2 = (fVar1 + param_2) / (fVar1 - param_2);
    fVar1 = DAT_019735a0;
  }
  else {
    fVar2 = (param_2 - fVar1) / (fVar1 + param_2);
    fVar1 = DAT_01973598;
  }
  fVar1 = (fVar2 * _DAT_0197358c * fVar2 - _DAT_0197359c) * fVar2 + fVar1;
  if (param_1 < 0.0) {
    fVar1 = (float)((uint)fVar1 ^ DAT_018c4ea0);
  }
  return (float10)fVar1;
}



/* FUNCTION 29789 ; VA 0x00c92290 ; FUN_00c92290 */

void FUN_00c92290(float *param_1,undefined8 *param_2,undefined8 *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fStack_34;
  float fStack_30;
  float fStack_28;
  float fStack_24;
  float fStack_1c;
  float fStack_18;
  float fStack_10;
  float fStack_c;
  
  fVar1 = *(float *)(param_2 + 1);
  fStack_34 = (float)*(undefined8 *)((int)param_2 + 0xc);
  fStack_30 = (float)((ulonglong)*(undefined8 *)((int)param_2 + 0xc) >> 0x20);
  fStack_c = (float)((ulonglong)*(undefined8 *)((int)param_3 + 0xc) >> 0x20);
  fStack_10 = (float)*(undefined8 *)((int)param_3 + 0xc);
  fVar2 = *(float *)((int)param_2 + 0x14);
  fStack_28 = (float)*param_3;
  fStack_24 = (float)((ulonglong)*param_3 >> 0x20);
  fVar3 = fStack_34 * fStack_10 + fStack_30 * fStack_c + fVar2 * *(float *)((int)param_3 + 0x14);
  fStack_1c = (float)*param_2;
  fStack_18 = (float)((ulonglong)*param_2 >> 0x20);
  fVar5 = *(float *)(param_3 + 1) - fVar1;
  fVar4 = DAT_018ce2f8 - fVar3 * fVar3;
  if (DAT_01973590 < (double)fVar4) {
    fVar4 = ((float)((uint)((fStack_28 - fStack_1c) * fStack_10 + (fStack_24 - fStack_18) * fStack_c
                           + fVar5 * *(float *)((int)param_3 + 0x14)) ^ DAT_018c4ea0) * fVar3 +
            (fStack_28 - fStack_1c) * fStack_34 + (fStack_24 - fStack_18) * fStack_30 +
            fVar5 * fVar2) / fVar4;
    *param_1 = fStack_34 * fVar4 + fStack_1c;
    param_1[1] = fStack_30 * fVar4 + fStack_18;
    param_1[2] = fVar2 * fVar4 + fVar1;
    return;
  }
  fVar1 = *(float *)(param_2 + 1);
  *(undefined8 *)param_1 = *param_2;
  param_1[2] = fVar1;
  return;
}



/* FUNCTION 29790 ; VA 0x00c923e0 ; FUN_00c923e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00c923e0(float param_1,float param_2)

{
  float10 fVar1;
  double dVar2;
  
  dVar2 = (double)(param_1 - param_2);
  if ((_DAT_019399d0 <= dVar2) && (dVar2 < DAT_019011c8)) {
    return (float10)(param_1 - param_2);
  }
  fVar1 = (float10)FUN_01725280((dVar2 + DAT_019011c8) / DAT_019011d0);
  return (float10)(float)(dVar2 - (double)fVar1 * DAT_019011d0);
}



/* FUNCTION 29791 ; VA 0x00c92470 ; FUN_00c92470 */

float10 FUN_00c92470(int param_1)

{
  float fVar1;
  double dVar2;
  
  fVar1 = *(float *)(param_1 + 4);
  if (DAT_018ce2f8 <= fVar1) {
    return (float10)1.5707964;
  }
  if (fVar1 <= DAT_018f7864) {
    return (float10)DAT_01901f78;
  }
  dVar2 = (double)fVar1;
  FUN_01728670();
  return (float10)(float)dVar2;
}



/* FUNCTION 29792 ; VA 0x00c924d0 ; FUN_00c924d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00c924d0(undefined4 *param_1,float *param_2,float *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  double dVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  
  uVar3 = _DAT_01d71e68;
  uVar2 = uRam01d71e64;
  uVar1 = uRam01d71e60;
  *param_1 = _DAT_01d71e5c;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar3 = uRam01d71e78;
  uVar2 = _DAT_01d71e74;
  uVar1 = uRam01d71e70;
  param_1[4] = _DAT_01d71e6c;
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  param_1[8] = DAT_01d71e7c;
  fVar5 = *param_2 * *param_2;
  fVar10 = param_2[1] * param_2[1];
  fVar9 = param_2[2] * param_2[2];
  dVar8 = (double)(fVar5 + fVar10 + fVar9);
  FUN_017267a0();
  if (DAT_018f784c < (float)dVar8) {
    dVar8 = (double)*param_3;
    FUN_017279f0();
    fVar6 = DAT_018ce2f8 - (float)dVar8;
    fVar7 = fVar6 * param_2[1] * param_2[2];
    dVar8 = (double)*param_3;
    FUN_01728390();
    fVar13 = (float)dVar8;
    fVar11 = fVar6 * *param_2 * param_2[2];
    fVar12 = fVar6 * *param_2 * param_2[1];
    FUN_01162aa0((fVar5 - DAT_018ce2f8) * fVar6 + DAT_018ce2f8,fVar12 - fVar13 * param_2[2],
                 fVar13 * param_2[1] + fVar11,fVar13 * param_2[2] + fVar12,
                 (fVar10 - DAT_018ce2f8) * fVar6 + DAT_018ce2f8,fVar7 - fVar13 * *param_2,
                 fVar11 - fVar13 * param_2[1],fVar13 * *param_2 + fVar7,
                 (fVar9 - DAT_018ce2f8) * fVar6 + DAT_018ce2f8);
  }
  cVar4 = FUN_01162520();
  if (cVar4 == '\0') {
    FUN_01162820();
  }
  return param_1;
}



/* FUNCTION 29793 ; VA 0x00c92690 ; FUN_00c92690 */

undefined4 FUN_00c92690(undefined4 param_1,float *param_2,float param_3,float param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  fVar4 = DAT_018ce2f8 - param_4;
  fVar1 = param_2[1];
  fVar2 = param_2[2];
  fVar5 = *param_2 * fVar4;
  fVar3 = fVar1 * fVar4 * fVar2;
  FUN_01162aa0(fVar5 * *param_2 + param_4,fVar5 * fVar1 - fVar2 * param_3,
               fVar1 * param_3 + fVar5 * fVar2,fVar2 * param_3 + fVar5 * fVar1,
               fVar1 * fVar4 * param_2[1] + param_4,fVar3 - *param_2 * param_3,
               fVar5 * fVar2 - fVar1 * param_3,*param_2 * param_3 + fVar3,
               fVar2 * fVar4 * fVar2 + param_4);
  return param_1;
}



/* FUNCTION 29794 ; VA 0x00c927a0 ; FUN_00c927a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00c927a0(undefined4 *param_1,float *param_2,float *param_3)

{
  float fVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  char cVar11;
  float fVar12;
  double dVar13;
  double dVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  
  uVar4 = _DAT_01d71e68;
  uVar3 = uRam01d71e64;
  uVar2 = uRam01d71e60;
  *param_1 = _DAT_01d71e5c;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  uVar5 = DAT_01d71e7c;
  uVar4 = uRam01d71e78;
  uVar3 = _DAT_01d71e74;
  uVar2 = uRam01d71e70;
  fVar18 = param_3[2];
  fVar16 = param_2[1];
  fVar19 = *param_2;
  fVar12 = *param_3;
  fVar15 = param_2[2];
  param_1[4] = _DAT_01d71e6c;
  param_1[5] = uVar2;
  param_1[6] = uVar3;
  param_1[7] = uVar4;
  param_1[8] = uVar5;
  fVar16 = fVar18 * fVar16 - param_3[1] * param_2[2];
  fVar18 = fVar12 * fVar15 - fVar19 * param_3[2];
  fVar19 = fVar19 * param_3[1] - *param_3 * param_2[1];
  dVar13 = (double)(fVar18 * fVar18 + fVar16 * fVar16 + fVar19 * fVar19);
  FUN_017267a0();
  uVar10 = DAT_01d71e7c;
  uVar9 = uRam01d71e78;
  uVar8 = _DAT_01d71e74;
  uVar7 = uRam01d71e70;
  uVar6 = _DAT_01d71e6c;
  uVar5 = _DAT_01d71e68;
  uVar4 = uRam01d71e64;
  uVar3 = uRam01d71e60;
  uVar2 = _DAT_01d71e5c;
  if (DAT_018f784c < (float)dVar13) {
    fVar12 = DAT_018ce2f8 / (float)dVar13;
    fVar18 = fVar12 * fVar18;
    fVar16 = fVar12 * fVar16;
    fVar12 = fVar12 * fVar19;
    dVar13 = (double)(fVar16 * fVar16 + fVar18 * fVar18 + fVar12 * fVar12);
    FUN_017267a0();
    if (DAT_018f784c < (float)dVar13) {
      fVar19 = param_3[1];
      fVar15 = *param_3;
      fVar17 = param_2[1];
      fVar20 = *param_2;
      fVar21 = param_3[2];
      fVar1 = param_2[2];
      dVar13 = (double)(fVar15 * fVar15 + fVar19 * fVar19 + fVar21 * fVar21);
      FUN_017267a0();
      dVar14 = (double)(*param_2 * *param_2 + param_2[1] * param_2[1] + param_2[2] * param_2[2]);
      FUN_017267a0();
      dVar13 = (double)((fVar20 * fVar15 + fVar19 * fVar17 + fVar1 * fVar21) /
                       ((float)dVar13 * (float)dVar14));
      FUN_01729d90();
      dVar13 = (double)(float)dVar13;
      dVar14 = dVar13;
      FUN_017279f0();
      fVar19 = DAT_018ce2f8 - (float)dVar14;
      FUN_01728390();
      fVar15 = (float)dVar13;
      fVar20 = fVar12 * fVar16 * fVar19;
      fVar21 = fVar18 * fVar16 * fVar19;
      fVar17 = fVar18 * fVar19 * fVar12;
      FUN_01162aa0((fVar16 * fVar16 - DAT_018ce2f8) * fVar19 + DAT_018ce2f8,fVar21 - fVar12 * fVar15
                   ,fVar18 * fVar15 + fVar20,fVar12 * fVar15 + fVar21,
                   (fVar18 * fVar18 - DAT_018ce2f8) * fVar19 + DAT_018ce2f8,fVar17 - fVar16 * fVar15
                   ,fVar20 - fVar18 * fVar15,fVar16 * fVar15 + fVar17,
                   (fVar12 * fVar12 - DAT_018ce2f8) * fVar19 + DAT_018ce2f8);
    }
    cVar11 = FUN_01162520();
    if (cVar11 == '\0') {
      FUN_01162820();
    }
    *param_1 = uVar2;
    param_1[1] = uVar3;
    param_1[2] = uVar4;
    param_1[3] = uVar5;
    param_1[4] = uVar6;
    param_1[5] = uVar7;
    param_1[6] = uVar8;
    param_1[7] = uVar9;
    param_1[8] = uVar10;
  }
  return param_1;
}



/* FUNCTION 29795 ; VA 0x00c92b20 ; FUN_00c92b20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00c92b20(undefined4 *param_1,float *param_2,float *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  float fVar6;
  float fVar7;
  double dVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [40];
  
  dVar8 = (double)(*param_2 * *param_2 + param_2[1] * param_2[1] + param_2[2] * param_2[2]);
  FUN_017267a0();
  fVar9 = DAT_018ce2f8 / (float)dVar8;
  fVar6 = *param_2 * fVar9;
  fVar7 = param_2[1] * fVar9;
  fVar9 = param_2[2] * fVar9;
  fVar13 = param_3[1];
  dVar8 = (double)(*param_3 * *param_3 + fVar13 * fVar13 + param_3[2] * param_3[2]);
  fStack_8c = fVar6;
  fStack_88 = fVar7;
  fStack_84 = fVar9;
  FUN_017267a0();
  fVar10 = DAT_018ce2f8 / (float)dVar8;
  fVar12 = param_3[2] * fVar10;
  fVar13 = fVar13 * fVar10;
  fVar10 = *param_3 * fVar10;
  fStack_bc = fVar12 * fVar7 - fVar13 * fVar9;
  fStack_b4 = fVar10 * fVar9 - fVar12 * fVar6;
  fStack_b8 = fVar13 * fVar6 - fVar10 * fVar7;
  dVar8 = (double)(fStack_b4 * fStack_b4 + fStack_bc * fStack_bc + fStack_b8 * fStack_b8);
  FUN_017267a0();
  fVar11 = (float)dVar8;
  fVar13 = fVar13 * fVar7 + fVar10 * fVar6 + fVar12 * fVar9;
  if (fVar11 < DAT_018f784c) {
    uStack_30 = DAT_01d71e7c;
    uStack_50 = _DAT_01d71e5c;
    uStack_4c = uRam01d71e60;
    uStack_48 = uRam01d71e64;
    uStack_44 = _DAT_01d71e68;
    uStack_40 = _DAT_01d71e6c;
    uStack_3c = uRam01d71e70;
    uStack_38 = _DAT_01d71e74;
    uStack_34 = uRam01d71e78;
    if (fVar13 < 0.0) {
      fVar13 = (float)((uint)fVar13 ^ DAT_018c4ea0);
      fStack_bc = (float)((uint)fStack_bc ^ DAT_018c4ea0);
      fStack_b4 = (float)((uint)fStack_b4 ^ DAT_018c4ea0);
      fStack_98 = 0.0;
      fStack_94 = 0.0;
      fStack_b8 = (float)((uint)fStack_b8 ^ DAT_018c4ea0);
      fStack_90 = 0.0;
      uStack_80 = 0;
      uStack_7c = 0;
      uStack_78 = 0;
      FUN_01165060(&fStack_98,&uStack_80,&fStack_8c,1);
      fVar7 = fStack_98 * DAT_018daf58;
      fVar6 = fStack_94 * DAT_018daf58 * fStack_90;
      FUN_01162aa0(fVar7 * fStack_98 - DAT_018ce2f8,fStack_90 * DAT_018f9988 + fVar7 * fStack_94,
                   fStack_94 * 0.0 + fVar7 * fStack_90,fStack_90 * 0.0 + fVar7 * fStack_94,
                   fStack_94 * DAT_018daf58 * fStack_94 - DAT_018ce2f8,
                   fStack_98 * DAT_018f9988 + fVar6,fStack_94 * DAT_018f9988 + fVar7 * fStack_90,
                   fStack_98 * DAT_018ce2f0 + fVar6,
                   fStack_90 * DAT_018daf58 * fStack_90 - DAT_018ce2f8);
      uStack_50 = uStack_74;
      uStack_4c = uStack_70;
      uStack_48 = uStack_6c;
      uStack_44 = uStack_68;
      uStack_40 = uStack_64;
      uStack_3c = uStack_60;
      uStack_38 = uStack_5c;
      uStack_34 = uStack_58;
      uStack_30 = uStack_54;
    }
    fVar9 = (DAT_018ce2f8 - fVar13) * DAT_018e1340 + DAT_018ce2f4;
    fVar7 = fStack_bc * fVar9;
    fVar6 = fStack_b4 * fVar9 * fStack_b8;
    FUN_01162aa0(fVar7 * fStack_bc + fVar13,fVar7 * fStack_b4 - fStack_b8,
                 fVar7 * fStack_b8 + fStack_b4,fVar7 * fStack_b4 + fStack_b8,
                 fStack_b4 * fVar9 * fStack_b4 + fVar13,fVar6 - fStack_bc,
                 fVar7 * fStack_b8 - fStack_b4,fVar6 + fStack_bc,
                 fStack_b8 * fVar9 * fStack_b8 + fVar13);
    puVar5 = (undefined4 *)FUN_01160c20(auStack_2c,&uStack_50);
    uVar2 = puVar5[1];
    uVar3 = puVar5[2];
    uVar4 = puVar5[3];
    uVar1 = puVar5[8];
    *param_1 = *puVar5;
    param_1[1] = uVar2;
    param_1[2] = uVar3;
    param_1[3] = uVar4;
    uVar2 = puVar5[5];
    uVar3 = puVar5[6];
    uVar4 = puVar5[7];
    param_1[4] = puVar5[4];
    param_1[5] = uVar2;
    param_1[6] = uVar3;
    param_1[7] = uVar4;
    param_1[8] = uVar1;
    return param_1;
  }
  fVar6 = DAT_018ce2f8 / fVar11;
  fVar7 = DAT_018ce2f8 - fVar13;
  fStack_bc = fStack_bc * fVar6;
  fStack_b8 = fStack_b8 * fVar6;
  fStack_b4 = fStack_b4 * fVar6;
  fVar6 = fStack_bc * fVar7;
  fVar9 = fStack_b8 * fStack_b4 * fVar7;
  FUN_01162aa0(fStack_bc * fVar6 + fVar13,fStack_b4 * fVar6 - fStack_b8 * fVar11,
               fStack_b4 * fVar11 + fStack_b8 * fVar6,fStack_b8 * fVar11 + fStack_b4 * fVar6,
               fStack_b4 * fStack_b4 * fVar7 + fVar13,fVar9 - fStack_bc * fVar11,
               fStack_b8 * fVar6 - fStack_b4 * fVar11,fStack_bc * fVar11 + fVar9,
               fStack_b8 * fVar7 * fStack_b8 + fVar13);
  *param_1 = uStack_74;
  param_1[1] = uStack_70;
  param_1[2] = uStack_6c;
  param_1[3] = uStack_68;
  param_1[4] = uStack_64;
  param_1[5] = uStack_60;
  param_1[6] = uStack_5c;
  param_1[7] = uStack_58;
  param_1[8] = uStack_54;
  return param_1;
}



/* FUNCTION 29796 ; VA 0x00c93120 ; FUN_00c93120 */

undefined4 FUN_00c93120(undefined4 param_1,undefined4 param_2,float param_3)

{
  undefined8 *puVar1;
  int iVar2;
  int iVar3;
  undefined8 *puVar4;
  float *pfVar5;
  double dVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  undefined8 uStack_2c;
  
  iVar3 = 3;
  do {
    FUN_00569440();
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  iVar3 = 0;
  puVar4 = &uStack_2c;
  do {
    puVar1 = (undefined8 *)FUN_011612d0(&fStack_38,iVar3);
    iVar3 = iVar3 + 1;
    *puVar4 = *puVar1;
    *(undefined4 *)(puVar4 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar4 = (undefined8 *)((int)puVar4 + 0xc);
  } while (iVar3 < 3);
  iVar3 = 0;
  do {
    FUN_011612d0(&fStack_38,iVar3);
    iVar2 = 0;
    pfVar5 = (float *)((int)&uStack_2c + 4);
    while( true ) {
      fVar8 = pfVar5[1] * fStack_34 - *pfVar5 * fStack_30;
      fVar9 = *pfVar5 * fStack_38 - pfVar5[-1] * fStack_34;
      fVar7 = pfVar5[-1] * fStack_30 - pfVar5[1] * fStack_38;
      dVar6 = (double)(fVar7 * fVar7 + fVar8 * fVar8 + fVar9 * fVar9);
      FUN_017267a0();
      if ((float)dVar6 < param_3) break;
      iVar2 = iVar2 + 1;
      pfVar5 = pfVar5 + 3;
      if (2 < iVar2) {
        return 0;
      }
    }
    iVar3 = iVar3 + 1;
    if (2 < iVar3) {
      return 1;
    }
  } while( true );
}



/* FUNCTION 29797 ; VA 0x00c93230 ; FUN_00c93230 */

int FUN_00c93230(float *param_1,int param_2,float param_3,float param_4)

{
  float fVar1;
  float fVar2;
  uint3 uVar3;
  undefined2 uVar4;
  float *pfVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  
  iVar6 = 0;
  param_2 = param_2 - (int)param_1;
  pfVar5 = param_1 + 9;
  while( true ) {
    fVar1 = *(float *)(param_2 + (int)pfVar5);
    fVar2 = *pfVar5;
    uVar4 = (undefined2)((uint)param_2 >> 0x10);
    uVar3 = CONCAT21(uVar4,(fVar2 == fVar1) << 6 | (NAN(fVar2) || NAN(fVar1)) << 2 | 2U |
                           fVar2 < fVar1);
    uVar8 = (uint)DAT_018c0da0;
    uVar9 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    if (((NAN(fVar2) || NAN(fVar1)) == (fVar2 == fVar1)) &&
       (((float)(double)CONCAT44((uint)((ulonglong)(double)fVar2 >> 0x20) & uVar9,
                                 SUB84((double)fVar2,0) & uVar8) + DAT_018ce2f8) * param_3 <
        (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar2 - fVar1) >> 0x20) & uVar9,
                                SUB84((double)(fVar2 - fVar1),0) & uVar8))) break;
    iVar6 = iVar6 + 1;
    pfVar5 = pfVar5 + 1;
    if (2 < iVar6) {
      iVar6 = 0;
      do {
        iVar7 = 0;
        pfVar5 = param_1;
        do {
          fVar1 = *pfVar5;
          fVar2 = *(float *)((int)pfVar5 + param_2);
          uVar3 = CONCAT21(uVar4,(fVar1 == fVar2) << 6 | (NAN(fVar1) || NAN(fVar2)) << 2 | 2U |
                                 fVar1 < fVar2);
          if (((NAN(fVar1) || NAN(fVar2)) == (fVar1 == fVar2)) &&
             (((float)(double)CONCAT44((uint)((ulonglong)(double)fVar1 >> 0x20) & uVar9,
                                       SUB84((double)fVar1,0) & uVar8) + DAT_018ce2f8) * param_4 <
              (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar1 - fVar2) >> 0x20) & uVar9,
                                      SUB84((double)(fVar1 - fVar2),0) & uVar8))) goto LAB_00c93309;
          iVar7 = iVar7 + 1;
          pfVar5 = pfVar5 + 1;
        } while (iVar7 < 3);
        iVar6 = iVar6 + 1;
        param_1 = param_1 + 3;
        if (2 < iVar6) {
          return CONCAT31(uVar3,1);
        }
      } while( true );
    }
  }
LAB_00c93309:
  return (uint)uVar3 << 8;
}



/* FUNCTION 29798 ; VA 0x00c93310 ; FUN_00c93310 */

undefined FUN_00c93310(float *param_1,int param_2,float param_3)

{
  float fVar1;
  float fVar2;
  int iVar3;
  uint uVar4;
  
  iVar3 = 0;
  param_2 = param_2 - (int)param_1;
  while( true ) {
    fVar1 = *(float *)(param_2 + (int)param_1);
    fVar2 = *param_1;
    if (((NAN(fVar2) || NAN(fVar1)) == (fVar2 == fVar1)) &&
       (uVar4 = (uint)((ulonglong)DAT_018c0da0 >> 0x20),
       ((float)(double)CONCAT44((uint)((ulonglong)(double)fVar2 >> 0x20) & uVar4,
                                SUB84((double)fVar2,0) & (uint)DAT_018c0da0) + DAT_018ce2f8) *
       param_3 < (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar2 - fVar1) >> 0x20) & uVar4,
                                         SUB84((double)(fVar2 - fVar1),0) & (uint)DAT_018c0da0)))
    break;
    iVar3 = iVar3 + 1;
    param_1 = param_1 + 1;
    if (2 < iVar3) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 29799 ; VA 0x00c93380 ; FUN_00c93380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c93380(undefined4 param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018101f8;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar1 + 0x34) < DAT_01f01f9c) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01f01f9c), DAT_01f01f9c == -1)) {
    uStack_8 = 0;
    FUN_01161480(&DAT_01f01f78,0,0,0x3fc90fdb);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01f01f9c);
  }
  if ((*(int *)(iVar1 + 0x34) < DAT_01f01fc4) && (FUN_016f3809(&DAT_01f01fc4), DAT_01f01fc4 == -1))
  {
    uStack_8 = 1;
    FUN_01161480(&DAT_01f01fa0,0,0x3fc90fdb,0);
    FUN_016f37bf(&DAT_01f01fc4);
  }
  if ((*(int *)(iVar1 + 0x34) < DAT_01f01fec) && (FUN_016f3809(&DAT_01f01fec), DAT_01f01fec == -1))
  {
    _DAT_01f01fc8 = _DAT_01f01f78;
    uRam01f01fcc = uRam01f01f7c;
    uRam01f01fd0 = uRam01f01f80;
    uRam01f01fd4 = uRam01f01f84;
    _DAT_01f01fe8 = DAT_01f01f98;
    _DAT_01f01fd8 = _DAT_01f01f88;
    uRam01f01fdc = uRam01f01f8c;
    uRam01f01fe0 = uRam01f01f90;
    uRam01f01fe4 = uRam01f01f94;
    FUN_016f37bf(&DAT_01f01fec);
  }
  if ((*(int *)(iVar1 + 0x34) < DAT_01f02014) && (FUN_016f3809(&DAT_01f02014), DAT_01f02014 == -1))
  {
    _DAT_01f01ff0 = _DAT_01f01fa0;
    uRam01f01ff4 = uRam01f01fa4;
    uRam01f01ff8 = uRam01f01fa8;
    uRam01f01ffc = uRam01f01fac;
    _DAT_01f02010 = DAT_01f01fc0;
    _DAT_01f02000 = _DAT_01f01fb0;
    uRam01f02004 = uRam01f01fb4;
    uRam01f02008 = uRam01f01fb8;
    uRam01f0200c = uRam01f01fbc;
    FUN_016f37bf(&DAT_01f02014);
  }
  switch(param_1) {
  default:
    ExceptionList = pvStack_10;
    return &DAT_01d71e5c;
  case 1:
    ExceptionList = pvStack_10;
    return &DAT_01f01f78;
  case 2:
    ExceptionList = pvStack_10;
    return &DAT_01f01fa0;
  case 4:
    ExceptionList = pvStack_10;
    return &DAT_01f01fc8;
  case 5:
    ExceptionList = pvStack_10;
    return &DAT_01f01ff0;
  }
}



/* FUNCTION 29800 ; VA 0x00c935d0 ; FUN_00c935d0 */

undefined4 FUN_00c935d0(float *param_1,float *param_2)

{
  undefined4 uVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  double dVar5;
  uint uVar6;
  uint uVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  
  fVar2 = param_1[1];
  fVar3 = *param_1;
  fVar4 = param_1[2];
  fVar10 = param_2[1] * fVar3 + param_2[4] * fVar2 + param_2[7] * fVar4;
  fVar8 = param_2[2] * fVar3 + param_2[5] * fVar2 + param_2[8] * fVar4;
  fVar9 = param_2[3] * fVar2 + fVar3 * *param_2 + param_2[6] * fVar4;
  dVar5 = (double)fVar9;
  uVar6 = (uint)DAT_018c0da0;
  uVar7 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fVar2 = (float)(double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & uVar7,SUB84(dVar5,0) & uVar6);
  dVar5 = (double)fVar10;
  fVar3 = (float)(double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & uVar7,SUB84(dVar5,0) & uVar6);
  dVar5 = (double)fVar8;
  fVar4 = (float)(double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & uVar7,SUB84(dVar5,0) & uVar6);
  if (fVar2 <= fVar3) {
    if (fVar4 < fVar3) {
      uVar1 = 4;
      if (DAT_018ce2f0 < fVar10) {
        uVar1 = 1;
      }
      return uVar1;
    }
  }
  else if (fVar4 < fVar2) {
    uVar1 = 3;
    if (DAT_018ce2f0 < fVar9) {
      uVar1 = 0;
    }
    return uVar1;
  }
  uVar1 = 5;
  if (DAT_018ce2f0 < fVar8) {
    uVar1 = 2;
  }
  return uVar1;
}



/* FUNCTION 29801 ; VA 0x00c936d0 ; FUN_00c936d0 */

void FUN_00c936d0(undefined4 param_1,float *param_2,float *param_3)

{
  uint uVar1;
  int iVar2;
  float10 fVar3;
  double dVar4;
  undefined auStack_18 [12];
  double dStack_c;
  
  iVar2 = FUN_011612d0(auStack_18,2);
  uVar1 = *(uint *)(iVar2 + 4);
  dStack_c = (double)*(float *)(iVar2 + 8);
  fVar3 = (float10)FUN_01728580();
  dVar4 = (double)(float)(uVar1 ^ DAT_018c4ea0);
  *param_2 = (float)fVar3;
  FUN_01728670();
  *param_3 = (float)dVar4;
  return;
}



/* FUNCTION 29802 ; VA 0x00c93740 ; FUN_00c93740 */

undefined4 FUN_00c93740(undefined4 param_1,float *param_2,undefined4 param_3,undefined4 param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_4c [72];
  
  fVar1 = param_2[1];
  fVar2 = param_2[2];
  fVar3 = *param_2;
  uVar5 = (uint)(fVar2 * fVar1) ^ DAT_018c4ea0;
  uVar6 = (uint)(fVar2 * fVar3) ^ DAT_018c4ea0;
  uVar7 = (uint)(fVar1 * fVar3) ^ DAT_018c4ea0;
  uVar4 = FUN_01160a40(fVar2 * fVar2 + fVar1 * fVar1,uVar7,uVar6,uVar7,fVar2 * fVar2 + fVar3 * fVar3
                       ,uVar5,uVar6,uVar5,fVar1 * fVar1 + fVar3 * fVar3);
  uVar4 = FUN_01160b50(auStack_4c,param_4,uVar4);
  FUN_01160e20(param_1,uVar4);
  return param_1;
}



/* FUNCTION 29803 ; VA 0x00c93810 ; FUN_00c93810 */

undefined4
FUN_00c93810(undefined4 param_1,float *param_2,float *param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  uint uVar2;
  float fVar3;
  float fVar4;
  uint uVar5;
  float fVar6;
  uint uVar7;
  undefined auStack_4c [72];
  
  fVar6 = param_3[1] - param_2[1];
  fVar4 = param_3[2] - param_2[2];
  fVar3 = *param_3 - *param_2;
  uVar2 = (uint)(fVar4 * fVar6) ^ DAT_018c4ea0;
  uVar5 = (uint)(fVar4 * fVar3) ^ DAT_018c4ea0;
  uVar7 = (uint)(fVar6 * fVar3) ^ DAT_018c4ea0;
  uVar1 = FUN_01160a40(fVar4 * fVar4 + fVar6 * fVar6,uVar7,uVar5,uVar7,fVar4 * fVar4 + fVar3 * fVar3
                       ,uVar2,uVar5,uVar2,fVar6 * fVar6 + fVar3 * fVar3);
  uVar1 = FUN_01160b50(auStack_4c,param_5,uVar1);
  FUN_01160e20(param_1,uVar1);
  return param_1;
}



/* FUNCTION 29804 ; VA 0x00c938f0 ; FUN_00c938f0 */

int FUN_00c938f0(void)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined auStack_10 [12];
  
  uVar1 = FUN_011612d0(auStack_10,0);
  iVar2 = FUN_00d6a240(uVar1);
  uVar1 = FUN_011612d0(auStack_10,1);
  iVar3 = FUN_00d6a240(uVar1);
  return iVar3 + iVar2 * 6;
}



/* FUNCTION 29805 ; VA 0x00c93940 ; FUN_00c93940 */

int FUN_00c93940(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_10 [12];
  
  uVar3 = param_2;
  uVar1 = FUN_011612d0(auStack_10,0);
  iVar2 = FUN_00d6a2d0(uVar1,uVar3);
  if (iVar2 != 6) {
    uVar3 = FUN_011612d0(auStack_10,1);
    iVar4 = FUN_00d6a2d0(uVar3,param_2);
    if (iVar4 != 6) {
      return iVar4 + iVar2 * 6;
    }
  }
  return -1;
}



/* FUNCTION 29806 ; VA 0x00c939b0 ; FUN_00c939b0 */

undefined4 FUN_00c939b0(undefined4 param_1,float param_2,uint *param_3)

{
  undefined4 uVar1;
  double dVar2;
  double dVar3;
  undefined auStack_b8 [36];
  undefined auStack_94 [36];
  undefined auStack_70 [36];
  undefined auStack_4c [36];
  undefined auStack_28 [36];
  
  FUN_01160a40(0,param_3[2] ^ DAT_018c4ea0,param_3[1],param_3[2],0,*param_3 ^ DAT_018c4ea0,
               param_3[1] ^ DAT_018c4ea0,*param_3,0);
  FUN_01160c20(auStack_4c,auStack_28);
  uVar1 = FUN_01160b50(auStack_70,param_2 * DAT_018ce2f4,auStack_28);
  FUN_01160e20(auStack_94,uVar1);
  dVar2 = (double)param_2;
  FUN_017279f0();
  dVar3 = (double)param_2;
  FUN_01728390(auStack_4c);
  uVar1 = FUN_01160b50(auStack_b8,
                       DAT_018ce2f8 -
                       ((float)dVar3 * param_2) / (DAT_018daf58 - ((float)dVar2 + (float)dVar2)));
  FUN_01160e20(param_1,uVar1);
  return param_1;
}



/* FUNCTION 29807 ; VA 0x00c93af0 ; FUN_00c93af0 */

undefined4 FUN_00c93af0(undefined4 param_1,float *param_2)

{
  double dVar1;
  double dVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  undefined8 uStack_28;
  float fStack_20;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  
  fVar4 = *param_2;
  fVar3 = fVar4 * 0.0 + param_2[1] + param_2[2] * 0.0;
  fVar6 = 0.0 - *param_2 * fVar3;
  fVar5 = DAT_018ce2f8 - param_2[1] * fVar3;
  uStack_28 = (ulonglong)(uint)fVar6;
  fVar3 = 0.0 - param_2[2] * fVar3;
  dVar1 = (double)(fVar5 * fVar5 + fVar6 * fVar6 + fVar3 * fVar3);
  FUN_017267a0();
  dVar2 = (double)(float)dVar1;
  if ((float)(double)CONCAT44((uint)((ulonglong)dVar2 >> 0x20) & DAT_018c0da0._4_4_,
                              SUB84(dVar2,0) & (uint)DAT_018c0da0) <= DAT_018f784c) {
    fVar4 = param_2[1] * 0.0 + fVar4 * 0.0 + param_2[2];
    fVar3 = 0.0 - *param_2 * fVar4;
    fVar5 = 0.0 - param_2[1] * fVar4;
    uStack_28 = (ulonglong)(uint)fVar3;
    fVar4 = DAT_018ce2f8 - param_2[2] * fVar4;
    dVar1 = (double)(fVar5 * fVar5 + fVar3 * fVar3 + fVar4 * fVar4);
    FUN_017267a0();
    fStack_c = DAT_018ce2f8 / (float)dVar1;
    uStack_28._0_4_ = (float)uStack_28 * fStack_c;
    uStack_28._4_4_ = fVar5 * fStack_c;
    fStack_c = fVar4 * fStack_c;
  }
  else {
    fStack_c = DAT_018ce2f8 / (float)dVar1;
    uStack_28._0_4_ = (float)uStack_28 * fStack_c;
    uStack_28._4_4_ = fVar5 * fStack_c;
    fStack_c = fVar3 * fStack_c;
  }
  fStack_20 = fStack_c;
  fStack_14 = param_2[2] * uStack_28._4_4_ - param_2[1] * fStack_c;
  fStack_10 = *param_2 * fStack_c - param_2[2] * (float)uStack_28;
  fStack_c = param_2[1] * (float)uStack_28 - *param_2 * uStack_28._4_4_;
  FUN_01162b00(0,&fStack_14);
  FUN_01162b00(1,&uStack_28);
  FUN_01162b00(2,param_2);
  return param_1;
}



/* FUNCTION 29808 ; VA 0x00c93d40 ; FUN_00c93d40 */

int FUN_00c93d40(uint *param_1)

{
  uint3 uVar1;
  int iVar2;
  int iVar3;
  uint *puVar4;
  
  iVar2 = 0;
  puVar4 = param_1 + 9;
  do {
    if ((*puVar4 & 0x7f800000) == 0x7f800000) {
      return 0x7f800001;
    }
    iVar2 = iVar2 + 1;
    puVar4 = puVar4 + 1;
  } while (iVar2 < 3);
  iVar2 = 0;
  do {
    iVar3 = 0;
    puVar4 = param_1;
    do {
      uVar1 = (uint3)((*puVar4 & 0x7f800000) >> 8);
      if ((*puVar4 & 0x7f800000) == 0x7f800000) {
        return CONCAT31(uVar1,1);
      }
      iVar3 = iVar3 + 1;
      puVar4 = puVar4 + 1;
    } while (iVar3 < 3);
    iVar2 = iVar2 + 1;
    param_1 = param_1 + 3;
  } while (iVar2 < 3);
  return (uint)uVar1 << 8;
}



/* FUNCTION 29809 ; VA 0x00c93dd0 ; FUN_00c93dd0 */

undefined2 FUN_00c93dd0(float *param_1)

{
  ushort uVar1;
  undefined auVar2 [16];
  undefined auVar3 [16];
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined auVar8 [11];
  undefined auVar9 [12];
  undefined auVar10 [13];
  undefined auVar11 [14];
  char cVar12;
  char cVar13;
  char cVar14;
  char cVar15;
  char cVar16;
  char cVar17;
  char cVar18;
  char cVar19;
  char cVar20;
  char cVar21;
  char cVar22;
  char cVar23;
  char cVar24;
  char cVar25;
  char cVar26;
  byte bVar27;
  
  fVar4 = param_1[4] + *param_1 + param_1[8];
  fVar5 = param_1[5] + param_1[1] + param_1[9];
  fVar6 = param_1[6] + param_1[2] + param_1[10];
  fVar7 = param_1[7] + param_1[3] + param_1[0xb];
  fVar4 = fVar4 - fVar4;
  fVar5 = fVar5 - fVar5;
  fVar6 = fVar6 - fVar6;
  fVar7 = fVar7 - fVar7;
  cVar12 = -(SUB41(fVar4,0) == '\0');
  cVar13 = -((char)((uint)fVar4 >> 8) == '\0');
  cVar14 = -((char)((uint)fVar4 >> 0x10) == '\0');
  cVar15 = -((char)((uint)fVar4 >> 0x18) == '\0');
  cVar16 = -(SUB41(fVar5,0) == '\0');
  cVar17 = -((char)((uint)fVar5 >> 8) == '\0');
  cVar18 = -((char)((uint)fVar5 >> 0x10) == '\0');
  cVar19 = -((char)((uint)fVar5 >> 0x18) == '\0');
  cVar20 = -(SUB41(fVar6,0) == '\0');
  cVar21 = -((char)((uint)fVar6 >> 8) == '\0');
  cVar22 = -((char)((uint)fVar6 >> 0x10) == '\0');
  cVar23 = -((char)((uint)fVar6 >> 0x18) == '\0');
  cVar24 = -(SUB41(fVar7,0) == '\0');
  cVar25 = -((char)((uint)fVar7 >> 8) == '\0');
  cVar26 = -((char)((uint)fVar7 >> 0x10) == '\0');
  bVar27 = -((char)((uint)fVar7 >> 0x18) == '\0');
  auVar2[1] = cVar13;
  auVar2[0] = cVar12;
  auVar2[2] = cVar14;
  auVar2[3] = cVar15;
  auVar2[4] = cVar16;
  auVar2[5] = cVar17;
  auVar2[6] = cVar18;
  auVar2[7] = cVar19;
  auVar2[8] = cVar20;
  auVar2[9] = cVar21;
  auVar2[10] = cVar22;
  auVar2[0xb] = cVar23;
  auVar2[0xc] = cVar24;
  auVar2[0xd] = cVar25;
  auVar2[0xe] = cVar26;
  auVar2[0xf] = bVar27;
  auVar3[1] = cVar13;
  auVar3[0] = cVar12;
  auVar3[2] = cVar14;
  auVar3[3] = cVar15;
  auVar3[4] = cVar16;
  auVar3[5] = cVar17;
  auVar3[6] = cVar18;
  auVar3[7] = cVar19;
  auVar3[8] = cVar20;
  auVar3[9] = cVar21;
  auVar3[10] = cVar22;
  auVar3[0xb] = cVar23;
  auVar3[0xc] = cVar24;
  auVar3[0xd] = cVar25;
  auVar3[0xe] = cVar26;
  auVar3[0xf] = bVar27;
  auVar11[1] = cVar15;
  auVar11[0] = cVar14;
  auVar11[2] = cVar16;
  auVar11[3] = cVar17;
  auVar11[4] = cVar18;
  auVar11[5] = cVar19;
  auVar11[6] = cVar20;
  auVar11[7] = cVar21;
  auVar11[8] = cVar22;
  auVar11[9] = cVar23;
  auVar11[10] = cVar24;
  auVar11[0xb] = cVar25;
  auVar11[0xc] = cVar26;
  auVar11[0xd] = bVar27;
  auVar10[1] = cVar16;
  auVar10[0] = cVar15;
  auVar10[2] = cVar17;
  auVar10[3] = cVar18;
  auVar10[4] = cVar19;
  auVar10[5] = cVar20;
  auVar10[6] = cVar21;
  auVar10[7] = cVar22;
  auVar10[8] = cVar23;
  auVar10[9] = cVar24;
  auVar10[10] = cVar25;
  auVar10[0xb] = cVar26;
  auVar10[0xc] = bVar27;
  auVar9[1] = cVar17;
  auVar9[0] = cVar16;
  auVar9[2] = cVar18;
  auVar9[3] = cVar19;
  auVar9[4] = cVar20;
  auVar9[5] = cVar21;
  auVar9[6] = cVar22;
  auVar9[7] = cVar23;
  auVar9[8] = cVar24;
  auVar9[9] = cVar25;
  auVar9[10] = cVar26;
  auVar9[0xb] = bVar27;
  auVar8[1] = cVar18;
  auVar8[0] = cVar17;
  auVar8[2] = cVar19;
  auVar8[3] = cVar20;
  auVar8[4] = cVar21;
  auVar8[5] = cVar22;
  auVar8[6] = cVar23;
  auVar8[7] = cVar24;
  auVar8[8] = cVar25;
  auVar8[9] = cVar26;
  auVar8[10] = bVar27;
  uVar1 = (ushort)(bVar27 >> 7) << 0xf;
  return CONCAT11((char)(uVar1 >> 8),
                  (ushort)((ushort)(SUB161(auVar2 >> 7,0) & 1) |
                           (ushort)(SUB161(auVar3 >> 0xf,0) & 1) << 1 |
                           (ushort)(SUB141(auVar11 >> 7,0) & 1) << 2 |
                           (ushort)(SUB131(auVar10 >> 7,0) & 1) << 3 |
                           (ushort)(SUB121(auVar9 >> 7,0) & 1) << 4 |
                           (ushort)(SUB111(auVar8 >> 7,0) & 1) << 5 |
                           (ushort)((byte)(CONCAT19(bVar27,CONCAT18(cVar26,CONCAT17(cVar25,CONCAT16(
                                                  cVar24,CONCAT15(cVar23,CONCAT14(cVar22,CONCAT13(
                                                  cVar21,CONCAT12(cVar20,CONCAT11(cVar19,cVar18)))))
                                                  )))) >> 7) & 1) << 6 |
                           (ushort)((byte)(CONCAT18(bVar27,CONCAT17(cVar26,CONCAT16(cVar25,CONCAT15(
                                                  cVar24,CONCAT14(cVar23,CONCAT13(cVar22,CONCAT12(
                                                  cVar21,CONCAT11(cVar20,cVar19)))))))) >> 7) & 1)
                           << 7 | uVar1) != 0xffff);
}



/* FUNCTION 29810 ; VA 0x00c93e00 ; FUN_00c93e00 */

void FUN_00c93e00(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar1 = param_2[2];
  if (fVar1 < 0.0) {
    fVar1 = fVar1 - DAT_018ce2f4;
  }
  else {
    fVar1 = fVar1 + DAT_018ce2f4;
  }
  fVar2 = param_2[1];
  if (fVar2 < 0.0) {
    fVar2 = fVar2 - DAT_018ce2f4;
  }
  else {
    fVar2 = fVar2 + DAT_018ce2f4;
  }
  fVar3 = *param_2;
  if (fVar3 < 0.0) {
    fVar3 = fVar3 - DAT_018ce2f4;
  }
  else {
    fVar3 = fVar3 + DAT_018ce2f4;
  }
  param_1[1] = (float)(int)fVar2;
  *param_1 = (float)(int)fVar3;
  param_1[2] = (float)(int)fVar1;
  return;
}



/* FUNCTION 29811 ; VA 0x00c93e80 ; FUN_00c93e80 */

void FUN_00c93e80(int param_1)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined8 uStack_1c;
  float fStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  puVar2 = (undefined8 *)FUN_00d6a680(param_1 / 6);
  uStack_10 = *puVar2;
  fStack_8 = *(float *)(puVar2 + 1);
  puVar2 = (undefined8 *)FUN_00d6a680(param_1 % 6);
  uVar1 = *puVar2;
  fStack_14 = *(float *)(puVar2 + 1);
  uStack_1c._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
  uStack_1c._0_4_ = (float)uVar1;
  fStack_28 = uStack_10._4_4_ * fStack_14 - fStack_8 * uStack_1c._4_4_;
  fStack_24 = (float)uStack_1c * fStack_8 - (float)uStack_10 * fStack_14;
  fStack_20 = (float)uStack_10 * uStack_1c._4_4_ - (float)uStack_1c * uStack_10._4_4_;
  uStack_1c = uVar1;
  FUN_01162b00(0,&uStack_10);
  FUN_01162b00(1,&uStack_1c);
  FUN_01162b00(2,&fStack_28);
  return;
}



/* FUNCTION 29812 ; VA 0x00c93f50 ; FUN_00c93f50 */

void FUN_00c93f50(undefined4 *param_1)

{
  *param_1 = 0x7f800000;
  param_1[1] = 0x7f800000;
  param_1[2] = 0x7f800000;
  return;
}



/* FUNCTION 29813 ; VA 0x00c93f70 ; FUN_00c93f70 */

int FUN_00c93f70(undefined4 param_1,undefined4 param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined8 *puVar4;
  int iVar5;
  undefined auStack_10 [12];
  undefined2 uVar6;
  
  puVar4 = (undefined8 *)FUN_01168ec0(auStack_10,param_2);
  fVar3 = DAT_018e0028;
  *(undefined8 *)param_3 = *puVar4;
  fVar2 = *(float *)(puVar4 + 1);
  param_3[2] = fVar2;
  fVar1 = *param_3;
  uVar6 = (undefined2)((uint)fVar2 >> 0x10);
  iVar5 = (uint)CONCAT21(uVar6,(fVar1 == fVar3) << 6 | (NAN(fVar1) || NAN(fVar3)) << 2 | 2U |
                               fVar1 < fVar3) << 8;
  if ((NAN(fVar1) || NAN(fVar3)) != (fVar1 == fVar3)) {
    fVar1 = param_3[1];
    iVar5 = (uint)CONCAT21(uVar6,(fVar1 == fVar3) << 6 | (NAN(fVar1) || NAN(fVar3)) << 2 | 2U |
                                 fVar1 < fVar3) << 8;
    if ((NAN(fVar1) || NAN(fVar3)) != (fVar1 == fVar3)) {
      fVar1 = param_3[2];
      iVar5 = (uint)CONCAT21(uVar6,(fVar1 == fVar3) << 6 | (NAN(fVar1) || NAN(fVar3)) << 2 | 2U |
                                   fVar1 < fVar3) << 8;
      if ((NAN(fVar1) || NAN(fVar3)) != (fVar1 == fVar3)) {
        return iVar5;
      }
    }
  }
  return CONCAT31((int3)((uint)iVar5 >> 8),1);
}



/* FUNCTION 29814 ; VA 0x00c93ff0 ; FUN_00c93ff0 */

undefined4 FUN_00c93ff0(undefined8 *param_1,float *param_2,undefined8 *param_3)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined8 *puVar3;
  double dVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  undefined8 uStack_24;
  float fStack_1c;
  ulonglong uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810218;
  pvStack_10 = ExceptionList;
  fVar7 = *(float *)((int)param_1 + 0xc);
  uStack_18 = (ulonglong)(uint)fVar7;
  fStack_1c = *(float *)(param_1 + 1);
  fVar5 = *param_2 * fVar7 + param_2[1] * *(float *)(param_1 + 2) +
          param_2[2] * *(float *)((int)param_1 + 0x14);
  uVar1 = *param_1;
  fVar8 = DAT_018c45d0;
  if (DAT_018c45d0 <= fStack_1c) {
    fVar8 = fStack_1c;
  }
  fVar9 = DAT_018c45c4;
  if (fVar8 <= DAT_018c45c4) {
    fVar9 = fVar8;
  }
  uStack_24._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
  fVar8 = DAT_018c45d0;
  if (DAT_018c45d0 <= uStack_24._4_4_) {
    fVar8 = uStack_24._4_4_;
  }
  uStack_24._0_4_ = (float)uVar1;
  fVar6 = DAT_018c45d0;
  if (DAT_018c45d0 <= (float)uStack_24) {
    fVar6 = (float)uStack_24;
  }
  fVar10 = DAT_018c45c4;
  if (fVar6 <= DAT_018c45c4) {
    fVar10 = fVar6;
  }
  fVar6 = DAT_018c45c4;
  if (fVar8 <= DAT_018c45c4) {
    fVar6 = fVar8;
  }
  if (fVar10 * *param_2 + fVar6 * param_2[1] + fVar9 * param_2[2] < param_2[3]) {
    if (DAT_018ce2f0 < fVar5) goto LAB_00c940f5;
  }
  else if (fVar5 < 0.0) {
LAB_00c940f5:
    dVar4 = (double)(fVar7 * fVar7 + *(float *)(param_1 + 2) * *(float *)(param_1 + 2) +
                    *(float *)((int)param_1 + 0x14) * *(float *)((int)param_1 + 0x14));
    ExceptionList = &pvStack_10;
    uStack_24 = uVar1;
    FUN_017267a0();
    fVar7 = DAT_018ce2f8 / (float)dVar4;
    fVar8 = (float)uStack_18 * fVar7;
    uStack_18 = CONCAT44((int)(uStack_18 >> 0x20),fVar8);
    fVar5 = *(float *)((int)param_1 + 0x14) * fVar7;
    dVar4 = (double)(*(float *)(param_1 + 2) * fVar7 * *(float *)(param_1 + 2) * fVar7 +
                     fVar8 * fVar8 + fVar5 * fVar5);
    FUN_017267a0();
    fStack_1c = fVar5 * (DAT_018ce2f8 / (float)dVar4);
    uStack_8 = 0;
    puVar3 = (undefined8 *)FUN_01168ec0(&uStack_24,param_2);
    *param_3 = *puVar3;
    uVar2 = *(undefined4 *)(puVar3 + 1);
    *(undefined4 *)(param_3 + 1) = uVar2;
    ExceptionList = pvStack_10;
    return CONCAT31((int3)((uint)uVar2 >> 8),1);
  }
  *param_3 = CONCAT44(DAT_018e0028,DAT_018e0028);
  *(undefined4 *)(param_3 + 1) = 0x7f800000;
  return 0x7f800000;
}



/* FUNCTION 29815 ; VA 0x00c94220 ; FUN_00c94220 */

undefined FUN_00c94220(float *param_1)

{
  float fVar1;
  int iVar2;
  float *pfVar3;
  int iVar4;
  int aiStack_1c [6];
  
  iVar4 = 0;
  aiStack_1c[3] = 0;
  aiStack_1c[4] = 0;
  aiStack_1c[5] = 0;
  aiStack_1c[0] = 0;
  aiStack_1c[1] = 0;
  aiStack_1c[2] = 0;
  do {
    iVar2 = 0;
    pfVar3 = param_1;
    do {
      fVar1 = *pfVar3;
      if (((NAN(fVar1) || NAN(DAT_018ce2f8)) == (fVar1 == DAT_018ce2f8)) &&
         ((NAN(fVar1) || NAN(DAT_018f7864)) == (fVar1 == DAT_018f7864))) {
        if ((NAN(fVar1) == (fVar1 == 0.0)) &&
           ((NAN(fVar1) || NAN(DAT_018f9988)) == (fVar1 == DAT_018f9988))) {
          return 0;
        }
      }
      else {
        aiStack_1c[iVar4 + 3] = aiStack_1c[iVar4 + 3] + 1;
        aiStack_1c[iVar2] = aiStack_1c[iVar2] + 1;
      }
      iVar2 = iVar2 + 1;
      pfVar3 = pfVar3 + 1;
    } while (iVar2 < 3);
    iVar4 = iVar4 + 1;
    param_1 = param_1 + 3;
  } while (iVar4 < 3);
  if ((((aiStack_1c[3] == 1) && (aiStack_1c[4] == 1)) && (aiStack_1c[5] == 1)) &&
     (((aiStack_1c[0] == 1 && (aiStack_1c[1] == 1)) && (aiStack_1c[2] == 1)))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 29816 ; VA 0x00c942f0 ; FUN_00c942f0 */

uint FUN_00c942f0(uint param_1)

{
  uint uVar1;
  
  uVar1 = param_1 & 0x7fffffff;
  if (uVar1 < 0x800000) {
    uVar1 = -(uint)(uVar1 != 0) & 0xfffffffe;
    return CONCAT31((int3)(uVar1 >> 8),uVar1 == 0xfffffffe);
  }
  if (uVar1 < 0x7f800000) {
    return 0xffffff00;
  }
  return (uint)(((param_1 & 0x7fffff) != 0) == 0xfffffffd);
}



/* FUNCTION 29817 ; VA 0x00c94350 ; FUN_00c94350 */

undefined4 FUN_00c94350(uint param_1)

{
  return CONCAT31((int3)((param_1 & 0x7fffffff) >> 8),0x7f800000 < (param_1 & 0x7fffffff));
}



/* FUNCTION 29818 ; VA 0x00c94370 ; FUN_00c94370 */

undefined4 FUN_00c94370(uint param_1)

{
  return CONCAT31((int3)((param_1 & 0x7f800000) >> 8),(param_1 & 0x7f800000) == 0x7f800000);
}



/* FUNCTION 29819 ; VA 0x00c94390 ; FUN_00c94390 */

int FUN_00c94390(uint *param_1)

{
  uint uVar1;
  uint3 uVar2;
  int iVar3;
  uint *puVar4;
  int iVar5;
  
  iVar5 = 0;
  do {
    iVar3 = 0;
    puVar4 = param_1;
    do {
      uVar1 = *puVar4 & 0x7fffffff;
      uVar2 = (uint3)(uVar1 >> 8);
      if (uVar1 < 0x800000) {
        if (uVar1 != 0) {
LAB_00c943c0:
          return CONCAT31(uVar2,1);
        }
      }
      else if (0x7f7fffff < uVar1) goto LAB_00c943c0;
      iVar3 = iVar3 + 1;
      puVar4 = puVar4 + 1;
    } while (iVar3 < 3);
    iVar5 = iVar5 + 1;
    param_1 = param_1 + 3;
    if (2 < iVar5) {
      return (uint)uVar2 << 8;
    }
  } while( true );
}



/* FUNCTION 29820 ; VA 0x00c943f0 ; FUN_00c943f0 */

int FUN_00c943f0(uint *param_1)

{
  uint uVar1;
  uint3 uVar2;
  
  uVar1 = *param_1 & 0x7fffffff;
  if (uVar1 < 0x800000) {
    if (uVar1 != 0) goto LAB_00c94412;
  }
  else if (0x7f7fffff < uVar1) goto LAB_00c94412;
  uVar1 = param_1[1] & 0x7fffffff;
  if (uVar1 < 0x800000) {
    if (uVar1 != 0) goto LAB_00c94412;
  }
  else if (0x7f7fffff < uVar1) goto LAB_00c94412;
  uVar1 = param_1[2] & 0x7fffffff;
  uVar2 = (uint3)(uVar1 >> 8);
  if (uVar1 < 0x800000) {
    if (uVar1 == 0) {
      return (uint)uVar2 << 8;
    }
  }
  else if (uVar1 < 0x7f800000) {
    return (uint)uVar2 << 8;
  }
LAB_00c94412:
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 29821 ; VA 0x00c94470 ; FUN_00c94470 */

uint FUN_00c94470(uint *param_1)

{
  uint uVar1;
  
  uVar1 = *param_1 & 0x7f800000;
  if (uVar1 != 0x7f800000) {
    uVar1 = param_1[1] & 0x7f800000;
    if (uVar1 != 0x7f800000) {
      uVar1 = param_1[2] & 0x7f800000;
      if (uVar1 != 0x7f800000) {
        return uVar1;
      }
    }
  }
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 29822 ; VA 0x00c944d0 ; FUN_00c944d0 */

undefined4
FUN_00c944d0(float *param_1,float *param_2,float *param_3,float *param_4,float *param_5,
            float param_6)

{
  float fVar1;
  float fVar2;
  float fVar3;
  double dVar4;
  double dVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  
  param_6 = param_6 - DAT_018ce2f8;
  fVar7 = *param_2 - *param_1;
  fVar11 = param_2[2] - param_1[2];
  fVar1 = param_2[1] - param_1[1];
  dVar4 = (double)(fVar1 * fVar1 + fVar7 * fVar7 + fVar11 * fVar11);
  FUN_017267a0();
  fVar2 = DAT_018ce2f8 / (float)dVar4;
  fVar7 = fVar7 * fVar2;
  fVar8 = *param_4 - *param_3;
  fVar12 = param_4[2] - param_3[2];
  fVar1 = fVar1 * fVar2;
  fVar11 = fVar11 * fVar2;
  fVar2 = param_4[1] - param_3[1];
  dVar5 = (double)(fVar2 * fVar2 + fVar8 * fVar8 + fVar12 * fVar12);
  FUN_017267a0();
  fVar3 = DAT_018ce2f8 / (float)dVar5;
  fVar2 = fVar2 * fVar3;
  fVar8 = fVar8 * fVar3;
  fVar12 = fVar12 * fVar3;
  fVar3 = fVar2 * fVar1 + fVar8 * fVar7 + fVar12 * fVar11;
  dVar10 = (double)(float)(double)CONCAT44((uint)((ulonglong)(double)fVar3 >> 0x20) &
                                           DAT_018c0da0._4_4_,
                                           SUB84((double)fVar3,0) & (uint)DAT_018c0da0) -
           DAT_018c0d60;
  if ((double)param_6 <=
      (double)CONCAT44((uint)((ulonglong)dVar10 >> 0x20) & DAT_018c0da0._4_4_,
                       SUB84(dVar10,0) & (uint)DAT_018c0da0)) {
    fVar13 = (param_1[1] - param_3[1]) * fVar1 + (*param_1 - *param_3) * fVar7 +
             (param_1[2] - param_3[2]) * fVar11;
    fVar14 = (*param_1 - *param_3) * fVar8 + (param_1[1] - param_3[1]) * fVar2 +
             (param_1[2] - param_3[2]) * fVar12;
    fVar6 = fVar3 * fVar13;
    fVar9 = DAT_018ce2f8 - fVar3 * fVar3;
    fVar15 = (fVar14 - fVar6) / fVar9;
    fVar8 = fVar8 * fVar15;
    fVar13 = (fVar3 * fVar14 - fVar6 * fVar3) / fVar9 - fVar13;
    fVar2 = fVar2 * fVar15;
    fVar12 = fVar12 * fVar15;
    fVar11 = fVar11 * fVar13;
    fVar7 = fVar7 * fVar13;
    fVar1 = fVar1 * fVar13;
    if (((float)((uint)param_6 ^ DAT_018c4ea0) <= fVar13) &&
       ((float)((uint)param_6 ^ DAT_018c4ea0) <= fVar15)) {
      dVar10 = (double)(fVar1 * fVar1 + fVar7 * fVar7 + fVar11 * fVar11);
      FUN_017267a0();
      if ((float)dVar10 <= (float)dVar4 + param_6) {
        dVar4 = (double)(fVar2 * fVar2 + fVar8 * fVar8 + fVar12 * fVar12);
        FUN_017267a0();
        if ((float)dVar4 <= (float)dVar5 + param_6) {
          fVar3 = (*param_1 + fVar7) - (*param_3 + fVar8);
          fVar2 = (param_1[1] + fVar1) - (param_3[1] + fVar2);
          fVar1 = (param_1[2] + fVar11) - (param_3[2] + fVar12);
          dVar4 = (double)(fVar2 * fVar2 + fVar3 * fVar3 + fVar1 * fVar1);
          FUN_017267a0();
          *param_5 = (float)dVar4;
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 29823 ; VA 0x00c94890 ; FUN_00c94890 */

undefined * FUN_00c94890(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181023c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01f24) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f01f24);
    if (DAT_01f01f24 == -1) {
      uStack_8 = 0;
      FUN_01160a40(0x3f800000,0,0,0,0,&DAT_bf800000,0,0x3f800000,0);
      FUN_016f37bf(&DAT_01f01f24);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f01f00;
}



/* FUNCTION 29824 ; VA 0x00c94960 ; FUN_00c94960 */

undefined * FUN_00c94960(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181025c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01f4c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f01f4c);
    if (DAT_01f01f4c == -1) {
      uStack_8 = 0;
      FUN_01160a40(0,0,0x3f800000,0,0x3f800000,0,&DAT_bf800000,0,0);
      FUN_016f37bf(&DAT_01f01f4c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f01f28;
}



/* FUNCTION 29825 ; VA 0x00c94a30 ; FUN_00c94a30 */

undefined * FUN_00c94a30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181027c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01f74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f01f74);
    if (DAT_01f01f74 == -1) {
      uStack_8 = 0;
      FUN_01160a40(0,0x3f800000,0,&DAT_bf800000,0,0,0,0,0x3f800000);
      FUN_016f37bf(&DAT_01f01f74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f01f50;
}



/* FUNCTION 29826 ; VA 0x00c94b00 ; FUN_00c94b00 */

undefined4 FUN_00c94b00(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined auStack_4c [36];
  undefined auStack_28 [36];
  
  FUN_01160c20(auStack_28,param_2);
  uVar1 = FUN_011630b0(auStack_4c);
  FUN_01160c20(param_1,uVar1);
  return param_1;
}



/* FUNCTION 29827 ; VA 0x00c94b40 ; FUN_00c94b40 */

undefined FUN_00c94b40(void)

{
  char cVar1;
  
  cVar1 = FUN_01162520();
  if (cVar1 == '\0') {
    FUN_01162820();
    return 1;
  }
  return 0;
}



/* FUNCTION 29828 ; VA 0x00c94b60 ; FUN_00c94b60 */

undefined4 * FUN_00c94b60(undefined4 *param_1,int *param_2,int *param_3)

{
  float *pfVar1;
  longlong lVar2;
  double *pdVar3;
  double *pdVar4;
  double *pdVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  undefined auStack_50 [8];
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  float fStack_2c;
  float fStack_28;
  int iStack_24;
  double *pdStack_20;
  int iStack_1c;
  double *pdStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018102a9;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  lVar2 = (ulonglong)(uint)(param_2[1] - *param_2 >> 3) * 0x10;
  ExceptionList = &pvStack_10;
  pdVar3 = (double *)FUN_01674e20(-(uint)((int)((ulonglong)lVar2 >> 0x20) != 0) | (uint)lVar2);
  uVar6 = 0;
  iStack_1c = param_2[1] - *param_2 >> 3;
  pdVar5 = pdVar3;
  if (iStack_1c != 0) {
    do {
      *pdVar5 = (double)*(float *)(*param_2 + uVar6 * 8);
      iVar8 = uVar6 * 8;
      uVar6 = uVar6 + 1;
      pdVar5[1] = (double)*(float *)(*param_2 + 4 + iVar8);
      pdVar5 = pdVar5 + 2;
    } while (uVar6 < (uint)(param_2[1] - *param_2 >> 3));
  }
  piStack_3c = &iStack_1c;
  uStack_44 = 1;
  uStack_40 = 0;
  lVar2 = (ulonglong)(uint)(param_3[1] - *param_3 >> 3) * 0x10;
  pdStack_18 = pdVar3;
  pdVar4 = (double *)FUN_01674e20(-(uint)((int)((ulonglong)lVar2 >> 0x20) != 0) | (uint)lVar2);
  uVar6 = 0;
  iStack_24 = param_3[1] - *param_3 >> 3;
  pdVar5 = pdVar4;
  if (iStack_24 != 0) {
    do {
      *pdVar5 = (double)*(float *)(*param_3 + uVar6 * 8);
      iVar8 = uVar6 * 8;
      uVar6 = uVar6 + 1;
      pdVar5[1] = (double)*(float *)(*param_3 + 4 + iVar8);
      pdVar5 = pdVar5 + 2;
    } while (uVar6 < (uint)(param_3[1] - *param_3 >> 3));
  }
  piStack_30 = &iStack_24;
  uStack_38 = 1;
  uStack_34 = 0;
  pdStack_20 = pdVar4;
  FUN_0127f190(1,&uStack_44,&uStack_38,auStack_50);
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if ((piStack_48 != (int *)0x0) && (iVar8 = 0, 0 < *piStack_48)) {
    iVar7 = 0;
    do {
      pfVar1 = (float *)param_1[1];
      fStack_2c = (float)*(double *)(piStack_48[1] + iVar7);
      fStack_28 = (float)*(double *)(piStack_48[1] + 8 + iVar7);
      if ((float *)param_1[2] == pfVar1) {
        FUN_007ef0d0(pfVar1,&fStack_2c);
      }
      else {
        *pfVar1 = fStack_2c;
        pfVar1[1] = fStack_28;
        param_1[1] = param_1[1] + 8;
      }
      iVar8 = iVar8 + 1;
      iVar7 = iVar7 + 0x10;
    } while (iVar8 < *piStack_48);
  }
  FUN_0127f120(auStack_50);
  FUN_01674ea0(pdVar3);
  FUN_01674ea0(pdVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29829 ; VA 0x00c94d60 ; FUN_00c94d60 */

float10 FUN_00c94d60(undefined *param_1)

{
  bool bVar1;
  
  bVar1 = (float)param_1 < DAT_018ce2f0;
  param_1 = (undefined *)0x3f800000;
  if (bVar1) {
    param_1 = &DAT_bf800000;
  }
  return (float10)(float)param_1;
}



/* FUNCTION 29830 ; VA 0x00c94d90 ; FUN_00c94d90 */

void FUN_00c94d90(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_58 [36];
  undefined auStack_34 [36];
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_10 = 0;
  uStack_c = 0x3f800000;
  uStack_8 = 0;
  FUN_01161370(auStack_34,&uStack_10,param_2);
  puVar4 = (undefined4 *)FUN_01160c20(auStack_58,param_1);
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_1[4] = puVar4[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  param_1[8] = puVar4[8];
  return;
}



/* FUNCTION 29831 ; VA 0x00c94df0 ; FUN_00c94df0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00c94df0(undefined4 param_1,undefined4 param_2,float param_3)

{
  double dVar1;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  float fStack_10;
  undefined4 uStack_c;
  float fStack_8;
  
  uStack_18 = DAT_01d71e7c;
  uStack_38 = _DAT_01d71e5c;
  uStack_34 = uRam01d71e60;
  uStack_30 = uRam01d71e64;
  uStack_2c = _DAT_01d71e68;
  uStack_28 = _DAT_01d71e6c;
  uStack_24 = uRam01d71e70;
  uStack_20 = _DAT_01d71e74;
  uStack_1c = uRam01d71e78;
  dVar1 = (double)param_3;
  FUN_01728390();
  fStack_8 = (float)dVar1;
  dVar1 = (double)param_3;
  FUN_017279f0();
  uStack_c = 0;
  fStack_10 = fStack_8;
  fStack_14 = (float)dVar1;
  FUN_01162b00(0,&fStack_14);
  fStack_14 = (float)((uint)fStack_8 ^ DAT_018c4ea0);
  uStack_c = 0;
  fStack_10 = (float)dVar1;
  FUN_01162b00(1,&fStack_14);
  FUN_01160c20(param_1,&uStack_38);
  return param_1;
}



/* FUNCTION 29832 ; VA 0x00c94eb0 ; FUN_00c94eb0 */

void FUN_00c94eb0(undefined8 *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  double dVar4;
  
  fVar1 = *param_2;
  dVar4 = (double)(fVar1 * fVar1 + param_2[1] * param_2[1] + param_2[2] * param_2[2]);
  FUN_017267a0();
  if (DAT_01973584 < (float)dVar4) {
    fVar3 = DAT_018ce2f8 / (float)dVar4;
    fVar2 = param_2[2];
    *param_1 = CONCAT44(param_2[1] * fVar3,fVar1 * fVar3);
    *(float *)(param_1 + 1) = fVar2 * fVar3;
    return;
  }
  *(undefined4 *)param_1 = 0x3f800000;
  *(undefined4 *)((int)param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  return;
}



/* FUNCTION 29833 ; VA 0x00c94f60 ; FUN_00c94f60 */

void FUN_00c94f60(int param_1,float param_2,float param_3)

{
  float fVar1;
  float fVar2;
  double dVar3;
  double dVar4;
  float fVar5;
  float fVar6;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  
  dVar3 = (double)param_3;
  FUN_01728390();
  fVar1 = (float)dVar3;
  dVar3 = (double)(DAT_018ce2f8 - fVar1 * fVar1);
  FUN_017267a0();
  dVar4 = (double)param_2;
  FUN_01728390();
  fVar2 = (float)((uint)((float)dVar4 * (float)dVar3) ^ DAT_018c4ea0);
  dVar4 = (double)param_2;
  FUN_017279f0();
  fVar6 = (float)((uint)((float)dVar4 * (float)dVar3) ^ DAT_018c4ea0);
  dVar3 = (double)(fVar2 * fVar2 + fVar1 * fVar1 + fVar6 * fVar6);
  FUN_017267a0();
  fVar5 = DAT_018ce2f8 / (float)dVar3;
  fStack_14 = fVar5 * fVar2 + *(float *)(param_1 + 0x24);
  fStack_10 = fVar5 * fVar1 + *(float *)(param_1 + 0x28);
  fStack_c = fVar5 * fVar6 + *(float *)(param_1 + 0x2c);
  FUN_01163c40(&fStack_14);
  return;
}



/* FUNCTION 29834 ; VA 0x00c95080 ; FUN_00c95080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c95080(undefined4 *param_1)

{
  double dVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  float *pfVar7;
  float fVar8;
  int iVar9;
  int iVar10;
  float fVar11;
  float afStack_98 [9];
  undefined auStack_74 [12];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  int iStack_14;
  int iStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar10 = -1;
  iStack_14 = -1;
  fStack_c = 0.0;
  fStack_8 = 0.0;
  do {
    FUN_011612d0(&fStack_44,fStack_8);
    iVar9 = 0;
    iStack_10 = (int)fStack_8 * 3;
    do {
      pfVar7 = (float *)FUN_011612d0(auStack_74,iVar9);
      fVar11 = pfVar7[1] * fStack_40 + *pfVar7 * fStack_44 + pfVar7[2] * fStack_3c;
      afStack_98[iStack_10 + iVar9] = fVar11;
      fVar8 = fStack_8;
      iVar6 = iVar9;
      if ((float)(double)CONCAT44((uint)((ulonglong)(double)fVar11 >> 0x20) & DAT_018c0da0._4_4_,
                                  SUB84((double)fVar11,0) & (uint)DAT_018c0da0) <=
          (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_c >> 0x20) & DAT_018c0da0._4_4_,
                                  SUB84((double)fStack_c,0) & (uint)DAT_018c0da0)) {
        fVar8 = (float)iStack_14;
        fVar11 = fStack_c;
        iVar6 = iVar10;
      }
      iVar10 = iVar6;
      fStack_c = fVar11;
      iVar9 = iVar9 + 1;
      iStack_14 = (int)fVar8;
    } while (iVar9 < 3);
    fStack_8 = (float)((int)fStack_8 + 1);
  } while ((int)fStack_8 < 3);
  if (fVar8 != -NAN) {
    FUN_011612d0(&fStack_20,iVar10);
    fStack_8 = 0.0;
    if (fStack_c < 0.0) {
      fStack_20 = fStack_20 * DAT_018f7864;
      fStack_1c = fStack_1c * DAT_018f7864;
      fStack_18 = fStack_18 * DAT_018f7864;
    }
    pfVar7 = afStack_98 + 1;
    fStack_c = -NAN;
    iVar9 = 0;
    iStack_10 = -1;
    do {
      if (iVar9 != iStack_14) {
        if ((iVar10 != 0) &&
           (dVar1 = (double)pfVar7[-1],
           (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_8 >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84((double)fStack_8,0) & (uint)DAT_018c0da0) <
           (float)(double)CONCAT44((uint)((ulonglong)dVar1 >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84(dVar1,0) & (uint)DAT_018c0da0))) {
          iStack_10 = 0;
          fStack_c = (float)iVar9;
          fStack_8 = pfVar7[-1];
        }
        if ((iVar10 != 1) &&
           (dVar1 = (double)*pfVar7,
           (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_8 >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84((double)fStack_8,0) & (uint)DAT_018c0da0) <
           (float)(double)CONCAT44((uint)((ulonglong)dVar1 >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84(dVar1,0) & (uint)DAT_018c0da0))) {
          iStack_10 = 1;
          fStack_c = (float)iVar9;
          fStack_8 = *pfVar7;
        }
        if ((iVar10 != 2) &&
           (dVar1 = (double)pfVar7[1],
           (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_8 >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84((double)fStack_8,0) & (uint)DAT_018c0da0) <
           (float)(double)CONCAT44((uint)((ulonglong)dVar1 >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84(dVar1,0) & (uint)DAT_018c0da0))) {
          iStack_10 = 2;
          fStack_c = (float)iVar9;
          fStack_8 = pfVar7[1];
        }
      }
      iVar9 = iVar9 + 1;
      pfVar7 = pfVar7 + 3;
    } while (iVar9 < 3);
    if (fStack_c != -NAN) {
      FUN_011612d0(&fStack_2c,iStack_10);
      if (fStack_8 < 0.0) {
        fStack_2c = fStack_2c * DAT_018f7864;
        fStack_28 = fStack_28 * DAT_018f7864;
        fStack_24 = fStack_24 * DAT_018f7864;
      }
      iVar10 = (3 - iStack_10) - iVar10;
      fStack_8 = (float)((3 - (int)fStack_c) - iStack_14);
      FUN_011612d0(&fStack_38,iVar10);
      fVar8 = fStack_8;
      if (afStack_98[(int)fStack_8 * 3 + iVar10] <= 0.0 &&
          afStack_98[(int)fStack_8 * 3 + iVar10] != 0.0) {
        fStack_38 = fStack_38 * DAT_018f7864;
        fStack_34 = fStack_34 * DAT_018f7864;
        fStack_30 = fStack_30 * DAT_018f7864;
      }
      FUN_01162b00(iStack_14,&fStack_20);
      FUN_01162b00(fStack_c,&fStack_2c);
      FUN_01162b00(fVar8,&fStack_38);
      *param_1 = uStack_68;
      param_1[1] = uStack_64;
      param_1[2] = uStack_60;
      param_1[3] = uStack_5c;
      param_1[4] = uStack_58;
      param_1[5] = uStack_54;
      param_1[6] = uStack_50;
      param_1[7] = uStack_4c;
      param_1[8] = uStack_48;
      return;
    }
  }
  uVar5 = DAT_01d71e7c;
  uVar4 = _DAT_01d71e68;
  uVar3 = uRam01d71e64;
  uVar2 = uRam01d71e60;
  *param_1 = _DAT_01d71e5c;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  uVar4 = uRam01d71e78;
  uVar3 = _DAT_01d71e74;
  uVar2 = uRam01d71e70;
  param_1[4] = _DAT_01d71e6c;
  param_1[5] = uVar2;
  param_1[6] = uVar3;
  param_1[7] = uVar4;
  param_1[8] = uVar5;
  return;
}



/* FUNCTION 29835 ; VA 0x00c953b0 ; FUN_00c953b0 */

undefined4 * FUN_00c953b0(undefined4 *param_1,int param_2,float *param_3)

{
  float fVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  undefined auStack_3c [44];
  float fStack_10;
  ulonglong uStack_c;
  
  fVar8 = *(float *)(param_2 + 0x2c) / param_3[2];
  fVar1 = param_3[1];
  fVar9 = *(float *)(param_2 + 0x24) / *param_3;
  fVar7 = *(float *)(param_2 + 0x28) / fVar1;
  if (fVar8 < 0.0) {
    fVar8 = fVar8 - DAT_018ce2f4;
  }
  else {
    fVar8 = fVar8 + DAT_018ce2f4;
  }
  if (fVar7 < 0.0) {
    fVar7 = fVar7 - DAT_018ce2f4;
  }
  else {
    fVar7 = fVar7 + DAT_018ce2f4;
  }
  if (fVar9 < 0.0) {
    fVar9 = fVar9 - DAT_018ce2f4;
  }
  else {
    fVar9 = fVar9 + DAT_018ce2f4;
  }
  fStack_10 = (float)(int)fVar8 * param_3[2];
  uStack_c = (ulonglong)(uint)((float)(int)fVar9 * *param_3);
  puVar6 = (undefined4 *)FUN_00c95080(auStack_3c,param_2);
  uVar2 = puVar6[1];
  uVar3 = puVar6[2];
  uVar4 = puVar6[3];
  *param_1 = *puVar6;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  uVar3 = puVar6[5];
  uVar4 = puVar6[6];
  uVar5 = puVar6[7];
  uVar2 = puVar6[8];
  param_1[4] = puVar6[4];
  param_1[5] = uVar3;
  param_1[6] = uVar4;
  param_1[7] = uVar5;
  param_1[8] = uVar2;
  *(ulonglong *)(param_1 + 9) = CONCAT44((float)(int)fVar7 * fVar1,(int)uStack_c);
  param_1[0xb] = fStack_10;
  return param_1;
}



/* FUNCTION 29836 ; VA 0x00c954a0 ; FUN_00c954a0 */

undefined4 * FUN_00c954a0(undefined4 *param_1,int param_2,float param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  undefined auStack_3c [44];
  float fStack_10;
  ulonglong uStack_c;
  
  fVar6 = *(float *)(param_2 + 0x2c) / param_3;
  fVar8 = *(float *)(param_2 + 0x24) / param_3;
  fVar7 = *(float *)(param_2 + 0x28) / param_3;
  if (fVar6 < 0.0) {
    fVar6 = fVar6 - DAT_018ce2f4;
  }
  else {
    fVar6 = fVar6 + DAT_018ce2f4;
  }
  if (fVar7 < 0.0) {
    fVar7 = fVar7 - DAT_018ce2f4;
  }
  else {
    fVar7 = fVar7 + DAT_018ce2f4;
  }
  if (fVar8 < 0.0) {
    fVar8 = fVar8 - DAT_018ce2f4;
  }
  else {
    fVar8 = fVar8 + DAT_018ce2f4;
  }
  fStack_10 = (float)(int)fVar6 * param_3;
  uStack_c = (ulonglong)(uint)((float)(int)fVar8 * param_3);
  puVar5 = (undefined4 *)FUN_00c95080(auStack_3c,param_2);
  uVar1 = puVar5[1];
  uVar2 = puVar5[2];
  uVar3 = puVar5[3];
  *param_1 = *puVar5;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar2 = puVar5[5];
  uVar3 = puVar5[6];
  uVar4 = puVar5[7];
  uVar1 = puVar5[8];
  param_1[4] = puVar5[4];
  param_1[5] = uVar2;
  param_1[6] = uVar3;
  param_1[7] = uVar4;
  param_1[8] = uVar1;
  *(ulonglong *)(param_1 + 9) = CONCAT44((float)(int)fVar7 * param_3,(int)uStack_c);
  param_1[0xb] = fStack_10;
  return param_1;
}



/* FUNCTION 29837 ; VA 0x00c95580 ; FUN_00c95580 */

float * FUN_00c95580(float *param_1,undefined8 *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  *(undefined8 *)param_1 = *param_2;
  param_1[2] = *(float *)(param_2 + 1);
  fVar1 = param_1[1];
  fVar2 = param_1[2];
  fVar3 = fVar1;
  if (fVar2 < fVar1) {
    param_1[1] = fVar2;
    param_1[2] = fVar1;
    fVar3 = fVar2;
    fVar2 = fVar1;
  }
  fVar1 = *param_1;
  if (fVar3 < fVar1) {
    *param_1 = fVar3;
    param_1[1] = fVar1;
    fVar3 = fVar1;
  }
  if (fVar2 < fVar3) {
    param_1[2] = fVar3;
    param_1[1] = fVar2;
  }
  return param_1;
}



/* FUNCTION 29838 ; VA 0x00c955f0 ; FUN_00c955f0 */

void FUN_00c955f0(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[4];
  param_1[2] = param_2[8];
  return;
}



/* FUNCTION 29839 ; VA 0x00c95610 ; FUN_00c95610 */

void FUN_00c95610(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  fVar1 = param_3[2];
  fVar5 = param_2[2] / fVar1;
  fVar2 = *param_3;
  fVar3 = *param_2 / fVar2;
  fVar4 = param_2[1] / param_3[1];
  if (fVar5 < 0.0) {
    fVar5 = fVar5 - DAT_018ce2f4;
  }
  else {
    fVar5 = fVar5 + DAT_018ce2f4;
  }
  if (fVar4 < 0.0) {
    fVar4 = fVar4 - DAT_018ce2f4;
  }
  else {
    fVar4 = fVar4 + DAT_018ce2f4;
  }
  if (fVar3 < 0.0) {
    fVar3 = fVar3 - DAT_018ce2f4;
  }
  else {
    fVar3 = fVar3 + DAT_018ce2f4;
  }
  param_1[1] = (float)(int)fVar4 * param_3[1];
  param_1[2] = (float)(int)fVar5 * fVar1;
  *param_1 = (float)(int)fVar3 * fVar2;
  return;
}



/* FUNCTION 29840 ; VA 0x00c956c0 ; FUN_00c956c0 */

void FUN_00c956c0(float *param_1,float *param_2,float param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar2 = param_2[2] / param_3;
  fVar1 = *param_2 / param_3;
  fVar3 = param_2[1] / param_3;
  if (fVar2 < 0.0) {
    fVar2 = fVar2 - DAT_018ce2f4;
  }
  else {
    fVar2 = fVar2 + DAT_018ce2f4;
  }
  if (fVar3 < 0.0) {
    fVar3 = fVar3 - DAT_018ce2f4;
  }
  else {
    fVar3 = fVar3 + DAT_018ce2f4;
  }
  if (fVar1 < 0.0) {
    fVar1 = fVar1 - DAT_018ce2f4;
  }
  else {
    fVar1 = fVar1 + DAT_018ce2f4;
  }
  param_1[1] = (float)(int)fVar3 * param_3;
  param_1[2] = (float)(int)fVar2 * param_3;
  *param_1 = (float)(int)fVar1 * param_3;
  return;
}



/* FUNCTION 29841 ; VA 0x00c95760 ; FUN_00c95760 */

void FUN_00c95760(float *param_1,float *param_2)

{
  uint uVar1;
  uint uVar2;
  
  uVar1 = (uint)DAT_018c0da0;
  uVar2 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  *param_1 = (float)(double)CONCAT44((uint)((ulonglong)(double)*param_2 >> 0x20) & uVar2,
                                     SUB84((double)*param_2,0) & uVar1);
  param_1[1] = (float)(double)CONCAT44((uint)((ulonglong)(double)param_2[1] >> 0x20) & uVar2,
                                       SUB84((double)param_2[1],0) & uVar1);
  param_1[2] = (float)(double)CONCAT44((uint)((ulonglong)(double)param_2[2] >> 0x20) & uVar2,
                                       SUB84((double)param_2[2],0) & uVar1);
  return;
}



/* FUNCTION 29842 ; VA 0x00c957b0 ; FUN_00c957b0 */

void FUN_00c957b0(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  fVar1 = *param_2;
  fVar2 = param_2[1];
  fVar3 = param_2[2];
  fVar4 = param_3[4];
  *param_1 = param_3[3] * fVar2 + fVar1 * *param_3 + param_3[6] * fVar3;
  fVar5 = param_3[5];
  param_1[1] = param_3[1] * fVar1 + fVar4 * fVar2 + param_3[7] * fVar3;
  param_1[2] = param_3[2] * fVar1 + fVar5 * fVar2 + param_3[8] * fVar3;
  return;
}



/* FUNCTION 29843 ; VA 0x00c95850 ; FUN_00c95850 */

void FUN_00c95850(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  
  if (param_1 != param_2) {
    puVar6 = param_1 + 0xb;
    do {
      uVar2 = *puVar6;
      if (0xf < uVar2) {
        uVar3 = puVar6[-5];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-1] = 0;
      *puVar6 = 0xf;
      *(undefined *)(puVar6 + -5) = 0;
      puVar1 = puVar6 + 1;
      puVar6 = puVar6 + 0xc;
    } while (puVar1 != param_2);
  }
  return;
}



/* FUNCTION 29844 ; VA 0x00c958c0 ; FUN_00c958c0 */

int __thiscall FUN_00c958c0(uint *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int iVar10;
  uint uVar11;
  
  uVar3 = *param_1;
  iVar10 = (int)((int)param_2 - uVar3) >> 2;
  iVar1 = (int)(param_1[1] - uVar3) >> 2;
  if (iVar1 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = iVar1 + 1;
  uVar7 = (int)(param_1[2] - uVar3) >> 2;
  uVar3 = uVar2;
  if ((uVar7 <= 0x3fffffff - (uVar7 >> 1)) && (uVar3 = (uVar7 >> 1) + uVar7, uVar3 < uVar2)) {
    uVar3 = uVar2;
  }
  puVar4 = (undefined4 *)FUN_00577ed0(uVar3);
  uVar7 = 0;
  puVar5 = puVar4 + iVar10;
  *puVar5 = *param_3;
  puVar6 = (undefined4 *)param_1[1];
  puVar8 = (undefined4 *)*param_1;
  if (param_2 == puVar6) {
    uVar11 = (uint)((int)puVar6 + (3 - (int)puVar8)) >> 2;
    if (puVar6 < puVar8) {
      uVar11 = 0;
    }
    puVar6 = puVar4;
    if (uVar11 != 0) {
      do {
        uVar7 = uVar7 + 1;
        *puVar6 = *puVar8;
        puVar8 = puVar8 + 1;
        puVar6 = puVar6 + 1;
      } while (uVar7 != uVar11);
    }
  }
  else {
    uVar11 = (uint)((int)param_2 + (3 - (int)puVar8)) >> 2;
    if (param_2 < puVar8) {
      uVar11 = 0;
    }
    puVar9 = puVar4;
    if (uVar11 != 0) {
      do {
        uVar7 = uVar7 + 1;
        *puVar9 = *puVar8;
        puVar8 = puVar8 + 1;
        puVar9 = puVar9 + 1;
      } while (uVar7 != uVar11);
      puVar6 = (undefined4 *)param_1[1];
    }
    uVar7 = 0;
    uVar11 = (uint)((int)puVar6 + (3 - (int)param_2)) >> 2;
    if (puVar6 < param_2) {
      uVar11 = 0;
    }
    if (uVar11 != 0) {
      puVar8 = puVar5 + 1;
      do {
        uVar7 = uVar7 + 1;
        *puVar8 = *(undefined4 *)(((int)param_2 - (int)(puVar5 + 1)) + (int)puVar8);
        puVar8 = puVar8 + 1;
      } while (uVar7 != uVar11);
    }
  }
  FUN_00601e00(puVar4,uVar2,uVar3);
  return *param_1 + iVar10 * 4;
}



/* FUNCTION 29845 ; VA 0x00c95a00 ; FUN_00c95a00 */

void __thiscall FUN_00c95a00(int *param_1,uint param_2)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  uint uVar11;
  undefined4 *puVar12;
  undefined *puVar13;
  undefined *puVar14;
  undefined *puVar15;
  
  uVar11 = (param_1[1] - *param_1) / 0x30;
  uVar9 = (param_1[2] - *param_1) / 0x30;
  if (param_2 <= uVar9) {
    if (param_2 <= uVar11) {
      if (param_2 != uVar11) {
        iVar7 = param_2 * 0x30 + *param_1;
        FUN_00c95850(iVar7,param_1[1],param_1);
        param_1[1] = iVar7;
      }
      return;
    }
    iVar7 = FUN_00c98770(param_1[1],param_2 - uVar11);
    param_1[1] = iVar7;
    return;
  }
  if (0x5555555 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = param_2;
  if ((uVar9 <= 0x5555555 - (uVar9 >> 1)) && (uVar5 = (uVar9 >> 1) + uVar9, uVar5 < param_2)) {
    uVar5 = param_2;
  }
  uVar9 = uVar5 * 0x30;
  if (uVar5 < 0x5555556) {
    uVar5 = uVar9;
    if (0xfff < uVar9) goto LAB_00c95a92;
    if (uVar9 == 0) {
      puVar13 = (undefined *)0x0;
    }
    else {
      puVar13 = (undefined *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_00c95a92:
    uVar6 = uVar5 + 0x23;
    if (uVar6 <= uVar5) {
      uVar6 = 0xffffffff;
    }
    iVar7 = FUN_01674e20(uVar6);
    if (iVar7 == 0) goto LAB_00c95c2f;
    puVar13 = (undefined *)(iVar7 + 0x23U & 0xffffffe0);
    *(int *)(puVar13 + -4) = iVar7;
  }
  FUN_00c98770(puVar13 + uVar11 * 0x30,param_2 - uVar11);
  puVar1 = (undefined *)param_1[1];
  puVar14 = (undefined *)*param_1;
  puVar15 = puVar13;
  if (puVar14 != puVar1) {
    puVar10 = (undefined4 *)(puVar14 + 0x2c);
    puVar12 = (undefined4 *)(puVar13 + 0x2c);
    do {
      *puVar15 = *puVar14;
      puVar14 = puVar14 + 0x30;
      *(undefined *)((int)puVar12 + -0x2b) = *(undefined *)((int)puVar10 + -0x2b);
      puVar15 = puVar15 + 0x30;
      *(undefined4 *)((int)puVar12 + -0x2a) = *(undefined4 *)((int)puVar10 + -0x2a);
      uVar2 = puVar10[-8];
      uVar3 = puVar10[-7];
      uVar4 = puVar10[-6];
      puVar12[-9] = puVar10[-9];
      puVar12[-8] = uVar2;
      puVar12[-7] = uVar3;
      puVar12[-6] = uVar4;
      puVar12[-1] = 0;
      *puVar12 = 0;
      uVar2 = puVar10[-4];
      uVar3 = puVar10[-3];
      uVar4 = puVar10[-2];
      puVar12[-5] = puVar10[-5];
      puVar12[-4] = uVar2;
      puVar12[-3] = uVar3;
      puVar12[-2] = uVar4;
      *(undefined8 *)(puVar12 + -1) = *(undefined8 *)(puVar10 + -1);
      puVar10[-1] = 0;
      *puVar10 = 0xf;
      *(undefined *)(puVar10 + -5) = 0;
      puVar10 = puVar10 + 0xc;
      puVar12 = puVar12 + 0xc;
    } while (puVar14 != puVar1);
  }
  FUN_00c95850(puVar15,puVar15,param_1);
  if (*param_1 != 0) {
    FUN_00c95850(*param_1,param_1[1],param_1);
    iVar7 = *param_1;
    uVar11 = ((param_1[2] - *param_1) / 0x30) * 0x30;
    iVar8 = iVar7;
    if (0xfff < uVar11) {
      iVar8 = *(int *)(iVar7 + -4);
      uVar11 = uVar11 + 0x23;
      if (0x1f < (iVar7 - iVar8) - 4U) {
LAB_00c95c2f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar11);
  }
  *param_1 = (int)puVar13;
  param_1[1] = (int)(puVar13 + param_2 * 0x30);
  param_1[2] = (int)(puVar13 + uVar9);
  return;
}



/* FUNCTION 29846 ; VA 0x00c95c40 ; FUN_00c95c40 */

void __thiscall FUN_00c95c40(uint *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uStack_c;
  
  puVar4 = (undefined4 *)param_1[1];
  uVar2 = *param_1;
  uVar6 = (int)((int)puVar4 - uVar2) >> 2;
  uStack_c = (int)(param_1[2] - uVar2) >> 2;
  if (param_2 <= uStack_c) {
    if (param_2 <= uVar6) {
      if (param_2 != uVar6) {
        param_1[1] = uVar2 + param_2 * 4;
      }
      return;
    }
    iVar3 = param_2 - uVar6;
    puVar1 = puVar4;
    if (iVar3 != 0) {
      puVar1 = puVar4 + iVar3;
      for (; iVar3 != 0; iVar3 = iVar3 + -1) {
        *puVar4 = 0xc2;
        puVar4 = puVar4 + 1;
      }
    }
    param_1[1] = (uint)puVar1;
    return;
  }
  if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x3fffffff - (uStack_c >> 1) < uStack_c) {
    uStack_c = param_2;
  }
  else {
    uStack_c = (uStack_c >> 1) + uStack_c;
    if (uStack_c < param_2) {
      uStack_c = param_2;
    }
  }
  puVar1 = (undefined4 *)FUN_00577ed0(uStack_c);
  iVar3 = param_2 - uVar6;
  puVar4 = puVar1 + uVar6;
  if (iVar3 != 0) {
    for (; iVar3 != 0; iVar3 = iVar3 + -1) {
      *puVar4 = 0xc2;
      puVar4 = puVar4 + 1;
    }
  }
  uVar6 = 0;
  puVar4 = (undefined4 *)*param_1;
  uVar2 = (uint)((int)param_1[1] + (3 - (int)puVar4)) >> 2;
  if ((undefined4 *)param_1[1] < puVar4) {
    uVar2 = 0;
  }
  puVar5 = puVar1;
  if (uVar2 != 0) {
    do {
      uVar6 = uVar6 + 1;
      *puVar5 = *puVar4;
      puVar4 = puVar4 + 1;
      puVar5 = puVar5 + 1;
    } while (uVar6 != uVar2);
  }
  FUN_00601e00(puVar1,param_2,uStack_c);
  return;
}



/* FUNCTION 29847 ; VA 0x00c95d40 ; FUN_00c95d40 */

int * __thiscall FUN_00c95d40(int *param_1,uint *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar5 = (int)(param_2[1] - *param_2) >> 2;
  if (uVar5 != 0) {
    if (0x3fffffff < uVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_00577ed0(uVar5);
    *param_1 = iVar2;
    param_1[1] = iVar2;
    uVar6 = 0;
    param_1[2] = *param_1 + uVar5 * 4;
    puVar4 = (undefined4 *)*param_2;
    puVar3 = (undefined4 *)*param_1;
    uVar5 = (uint)((int)param_2[1] + (3 - (int)puVar4)) >> 2;
    if ((undefined4 *)param_2[1] < puVar4) {
      uVar5 = 0;
    }
    if (uVar5 != 0) {
      do {
        uVar1 = *puVar4;
        puVar4 = puVar4 + 1;
        *puVar3 = uVar1;
        uVar6 = uVar6 + 1;
        puVar3 = puVar3 + 1;
      } while (uVar6 != uVar5);
    }
    param_1[1] = (int)puVar3;
  }
  return param_1;
}



/* FUNCTION 29848 ; VA 0x00c95dd0 ; FUN_00c95dd0 */

uint * __thiscall FUN_00c95dd0(uint *param_1,uint param_2)

{
  int iVar1;
  
  iVar1 = FUN_00c9a030();
  if ((param_2 < (uint)((*(int *)(iVar1 + 0x28) - *(int *)(iVar1 + 0x24)) / 0x30)) &&
     (*(char *)(*(int *)(iVar1 + 0x24) + param_2 * 0x30) != '\0')) {
    *param_1 = param_2;
    return param_1;
  }
  *param_1 = 0xc2;
  return param_1;
}



/* FUNCTION 29849 ; VA 0x00c95e20 ; FUN_00c95e20 */

undefined4 * __fastcall FUN_00c95e20(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_018102ff;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  uStack_8 = 3;
  uStack_7 = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  uVar1 = FUN_00601dc0();
  param_1[0xc] = uVar1;
  uStack_8 = 4;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  uVar1 = FUN_00601dc0();
  param_1[0xe] = uVar1;
  _uStack_8 = CONCAT31(uStack_7,5);
  uVar2 = 0;
  FUN_005542c0("White",5);
  FUN_00c98f00(1,0xf2,0xf3,0xf3,uVar2);
  uVar2 = 0;
  FUN_005542c0(&DAT_019735a4,4);
  FUN_00c98f00(2,0xa1,0xa5,0xa2,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light yellow",0xc);
  FUN_00c98f00(3,0xf9,0xe9,0x99,uVar2);
  uVar2 = 0;
  FUN_005542c0("Brick yellow",0xc);
  FUN_00c98f00(5,0xd7,0xc5,0x9a,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light green (Mint)",0x12);
  FUN_00c98f00(6,0xc2,0xda,0xb8,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light reddish violet",0x14);
  FUN_00c98f00(9,0xe8,0xba,200,uVar2);
  uVar2 = 0;
  FUN_005542c0("Pastel Blue",0xb);
  FUN_00c98f00(0xb,0x80,0xbb,0xdb,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light orange brown",0x12);
  FUN_00c98f00(0xc,0xcb,0x84,0x42,uVar2);
  uVar2 = 0;
  FUN_005542c0("Nougat",6);
  FUN_00c98f00(0x12,0xcc,0x8e,0x69,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright red",10);
  FUN_00c98f00(0x15,0xc4,0x28,0x1c,uVar2);
  uVar2 = 0;
  FUN_005542c0("Med. reddish violet",0x13);
  FUN_00c98f00(0x16,0xc4,0x70,0xa0,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright blue",0xb);
  FUN_00c98f00(0x17,0xd,0x69,0xac,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright yellow",0xd);
  FUN_00c98f00(0x18,0xf5,0xcd,0x30,uVar2);
  uVar2 = 0;
  FUN_005542c0("Earth orange",0xc);
  FUN_00c98f00(0x19,0x62,0x47,0x32,uVar2);
  uVar2 = 0;
  FUN_005542c0(&DAT_0197366c,5);
  FUN_00c98f00(0x1a,0x1b,0x2a,0x35,uVar2);
  uVar2 = 0;
  FUN_005542c0("Dark grey",9);
  FUN_00c98f00(0x1b,0x6d,0x6e,0x6c,uVar2);
  uVar2 = 0;
  FUN_005542c0("Dark green",10);
  FUN_00c98f00(0x1c,0x28,0x7f,0x47,uVar2);
  uVar2 = 0;
  FUN_005542c0("Medium green",0xc);
  FUN_00c98f00(0x1d,0xa1,0xc4,0x8c,uVar2);
  uVar2 = 0;
  FUN_005542c0("Lig. Yellowich orange",0x15);
  FUN_00c98f00(0x24,0xf3,0xcf,0x9b,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright green",0xc);
  FUN_00c98f00(0x25,0x4b,0x97,0x4b,uVar2);
  uVar2 = 0;
  FUN_005542c0("Dark orange",0xb);
  FUN_00c98f00(0x26,0xa0,0x5f,0x35,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light bluish violet",0x13);
  FUN_00c98f00(0x27,0xc1,0xca,0xde,uVar2);
  uVar2 = 0;
  FUN_005542c0("Transparent",0xb);
  FUN_00c98f00(0x28,0xec,0xec,0xec,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Red",7);
  FUN_00c98f00(0x29,0xcd,0x54,0x4b,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Lg blue",0xb);
  FUN_00c98f00(0x2a,0xc1,0xdf,0xf0,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Blue",8);
  FUN_00c98f00(0x2b,0x7b,0xb6,0xe8,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Yellow",10);
  FUN_00c98f00(0x2c,0xf7,0xf1,0x8d,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light blue",10);
  FUN_00c98f00(0x2d,0xb4,0xd2,0xe4,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Flu. Reddish orange",0x17);
  FUN_00c98f00(0x2f,0xd9,0x85,0x6c,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Green",9);
  FUN_00c98f00(0x30,0x84,0xb6,0x8d,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Flu. Green",0xe);
  FUN_00c98f00(0x31,0xf8,0xf1,0x84,uVar2);
  uVar2 = 0;
  FUN_005542c0("Phosph. White",0xd);
  FUN_00c98f00(0x32,0xec,0xe8,0xde,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light red",9);
  FUN_00c98f00(100,0xee,0xc4,0xb6,uVar2);
  uVar2 = 0;
  FUN_005542c0("Medium red",10);
  FUN_00c98f00(0x65,0xda,0x86,0x7a,uVar2);
  uVar2 = 0;
  FUN_005542c0("Medium blue",0xb);
  FUN_00c98f00(0x66,0x6e,0x99,0xca,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light grey",10);
  FUN_00c98f00(0x67,199,0xc1,0xb7,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright violet",0xd);
  FUN_00c98f00(0x68,0x6b,0x32,0x7c,uVar2);
  uVar2 = 0;
  FUN_005542c0("Br. yellowish orange",0x14);
  FUN_00c98f00(0x69,0xe2,0x9b,0x40,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright orange",0xd);
  FUN_00c98f00(0x6a,0xda,0x85,0x41,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright bluish green",0x13);
  FUN_00c98f00(0x6b,0,0x8f,0x9c,uVar2);
  uVar2 = 0;
  FUN_005542c0("Earth yellow",0xc);
  FUN_00c98f00(0x6c,0x68,0x5c,0x43,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright bluish violet",0x14);
  FUN_00c98f00(0x6e,0x43,0x54,0x93,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Brown",9);
  FUN_00c98f00(0x6f,0xbf,0xb7,0xb1,uVar2);
  uVar2 = 0;
  FUN_005542c0("Medium bluish violet",0x14);
  FUN_00c98f00(0x70,0x68,0x74,0xac,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Medi. reddish violet",0x18);
  FUN_00c98f00(0x71,0xe5,0xad,200,uVar2);
  uVar2 = 0;
  FUN_005542c0("Med. yellowish green",0x14);
  FUN_00c98f00(0x73,199,0xd2,0x3c,uVar2);
  uVar2 = 0;
  FUN_005542c0("Med. bluish green",0x11);
  FUN_00c98f00(0x74,0x55,0xa5,0xaf,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light bluish green",0x12);
  FUN_00c98f00(0x76,0xb7,0xd7,0xd5,uVar2);
  uVar2 = 0;
  FUN_005542c0("Br. yellowish green",0x13);
  FUN_00c98f00(0x77,0xa4,0xbd,0x47,uVar2);
  uVar2 = 0;
  FUN_005542c0("Lig. yellowish green",0x14);
  FUN_00c98f00(0x78,0xd9,0xe4,0xa7,uVar2);
  uVar2 = 0;
  FUN_005542c0("Med. yellowish orange",0x15);
  FUN_00c98f00(0x79,0xe7,0xac,0x58,uVar2);
  uVar2 = 0;
  FUN_005542c0("Br. reddish orange",0x12);
  FUN_00c98f00(0x7b,0xd3,0x6f,0x4c,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright reddish violet",0x15);
  FUN_00c98f00(0x7c,0x92,0x39,0x78,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light orange",0xc);
  FUN_00c98f00(0x7d,0xea,0xb8,0x92,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Bright bluish violet",0x18);
  FUN_00c98f00(0x7e,0xa5,0xa5,0xcb,uVar2);
  uVar2 = 0;
  FUN_005542c0(&DAT_0194d300,4);
  FUN_00c98f00(0x7f,0xdc,0xbc,0x81,uVar2);
  uVar2 = 0;
  FUN_005542c0("Dark nougat",0xb);
  FUN_00c98f00(0x80,0xae,0x7a,0x59,uVar2);
  uVar2 = 0;
  FUN_005542c0("Silver",6);
  FUN_00c98f00(0x83,0x9c,0xa3,0xa8,uVar2);
  uVar2 = 0;
  FUN_005542c0("Neon orange",0xb);
  FUN_00c98f00(0x85,0xd5,0x73,0x3d,uVar2);
  uVar2 = 0;
  FUN_005542c0("Neon green",10);
  FUN_00c98f00(0x86,0xd8,0xdd,0x56,uVar2);
  uVar2 = 0;
  FUN_005542c0("Sand blue",9);
  FUN_00c98f00(0x87,0x74,0x86,0x9d,uVar2);
  uVar2 = 0;
  FUN_005542c0("Sand violet",0xb);
  FUN_00c98f00(0x88,0x87,0x7c,0x90,uVar2);
  uVar2 = 0;
  FUN_005542c0("Medium orange",0xd);
  FUN_00c98f00(0x89,0xe0,0x98,100,uVar2);
  uVar2 = 0;
  FUN_005542c0("Sand yellow",0xb);
  FUN_00c98f00(0x8a,0x95,0x8a,0x73,uVar2);
  uVar2 = 0;
  FUN_005542c0("Earth blue",10);
  FUN_00c98f00(0x8c,0x20,0x3a,0x56,uVar2);
  uVar2 = 0;
  FUN_005542c0("Earth green",0xb);
  FUN_00c98f00(0x8d,0x27,0x46,0x2d,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Flu. Blue",0xd);
  FUN_00c98f00(0x8f,0xcf,0xe2,0xf7,uVar2);
  uVar2 = 0;
  FUN_005542c0("Sand blue metallic",0x12);
  FUN_00c98f00(0x91,0x79,0x88,0xa1,uVar2);
  uVar2 = 0;
  FUN_005542c0("Sand violet metallic",0x14);
  FUN_00c98f00(0x92,0x95,0x8e,0xa3,uVar2);
  uVar2 = 0;
  FUN_005542c0("Sand yellow metallic",0x14);
  FUN_00c98f00(0x93,0x93,0x87,0x67,uVar2);
  uVar2 = 0;
  FUN_005542c0("Dark grey metallic",0x12);
  FUN_00c98f00(0x94,0x57,0x58,0x57,uVar2);
  uVar2 = 0;
  FUN_005542c0("Black metallic",0xe);
  FUN_00c98f00(0x95,0x16,0x1d,0x32,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light grey metallic",0x13);
  FUN_00c98f00(0x96,0xab,0xad,0xac,uVar2);
  uVar2 = 0;
  FUN_005542c0("Sand green",10);
  FUN_00c98f00(0x97,0x78,0x90,0x82,uVar2);
  uVar2 = 0;
  FUN_005542c0("Sand red",8);
  FUN_00c98f00(0x99,0x95,0x79,0x77,uVar2);
  uVar2 = 0;
  FUN_005542c0("Dark red",8);
  FUN_00c98f00(0x9a,0x7b,0x2e,0x2f,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Flu. Yellow",0xf);
  FUN_00c98f00(0x9d,0xff,0xf6,0x7b,uVar2);
  uVar2 = 0;
  FUN_005542c0("Tr. Flu. Red",0xc);
  FUN_00c98f00(0x9e,0xe1,0xa4,0xc2,uVar2);
  uVar2 = 0;
  FUN_005542c0("Gun metallic",0xc);
  FUN_00c98f00(0xa8,0x75,0x6c,0x62,uVar2);
  uVar2 = 0;
  FUN_005542c0("Red flip/flop",0xd);
  FUN_00c98f00(0xb0,0x97,0x69,0x5b,uVar2);
  uVar2 = 0;
  FUN_005542c0("Yellow flip/flop",0x10);
  FUN_00c98f00(0xb2,0xb4,0x84,0x55,uVar2);
  uVar2 = 0;
  FUN_005542c0("Silver flip/flop",0x10);
  FUN_00c98f00(0xb3,0x89,0x87,0x88,uVar2);
  uVar2 = 0;
  FUN_005542c0("Curry",5);
  FUN_00c98f00(0xb4,0xd7,0xa9,0x4b,uVar2);
  uVar2 = 0;
  FUN_005542c0("Fire Yellow",0xb);
  FUN_00c98f00(0xbe,0xf9,0xd6,0x2e,uVar2);
  uVar2 = 0;
  FUN_005542c0("Flame yellowish orange",0x16);
  FUN_00c98f00(0xbf,0xe8,0xab,0x2d,uVar2);
  uVar2 = 0;
  FUN_005542c0("Reddish brown",0xd);
  FUN_00c98f00(0xc0,0x69,0x40,0x28,uVar2);
  uVar2 = 0;
  FUN_005542c0("Flame reddish orange",0x14);
  FUN_00c98f00(0xc1,0xcf,0x60,0x24,uVar2);
  uVar2 = 0;
  FUN_005542c0("Medium stone grey",0x11);
  FUN_00c98f00(0xc2,0xa3,0xa2,0xa5,uVar2);
  uVar2 = 0;
  FUN_005542c0("Royal blue",10);
  FUN_00c98f00(0xc3,0x46,0x67,0xa4,uVar2);
  uVar2 = 0;
  FUN_005542c0("Dark Royal blue",0xf);
  FUN_00c98f00(0xc4,0x23,0x47,0x8b,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright reddish lilac",0x14);
  FUN_00c98f00(0xc6,0x8e,0x42,0x85,uVar2);
  uVar2 = 0;
  FUN_005542c0("Dark stone grey",0xf);
  FUN_00c98f00(199,99,0x5f,0x62,uVar2);
  uVar2 = 0;
  FUN_005542c0("Lemon metalic",0xd);
  FUN_00c98f00(200,0x82,0x8a,0x5d,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light stone grey",0x10);
  FUN_00c98f00(0xd0,0xe5,0xe4,0xdf,uVar2);
  uVar2 = 0;
  FUN_005542c0("Dark Curry",10);
  FUN_00c98f00(0xd1,0xb0,0x8e,0x44,uVar2);
  uVar2 = 0;
  FUN_005542c0("Faded green",0xb);
  FUN_00c98f00(0xd2,0x70,0x95,0x78,uVar2);
  uVar2 = 0;
  FUN_005542c0("Turquoise",9);
  FUN_00c98f00(0xd3,0x79,0xb5,0xb5,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light Royal blue",0x10);
  FUN_00c98f00(0xd4,0x9f,0xc3,0xe9,uVar2);
  uVar2 = 0;
  FUN_005542c0("Medium Royal blue",0x11);
  FUN_00c98f00(0xd5,0x6c,0x81,0xb7,uVar2);
  uVar2 = 0;
  FUN_005542c0(&DAT_018fa4fc,4);
  FUN_00c98f00(0xd8,0x90,0x4c,0x2a,uVar2);
  uVar2 = 0;
  FUN_005542c0("Brown",5);
  FUN_00c98f00(0xd9,0x7c,0x5c,0x46,uVar2);
  uVar2 = 0;
  FUN_005542c0("Reddish lilac",0xd);
  FUN_00c98f00(0xda,0x96,0x70,0x9f,uVar2);
  uVar2 = 0;
  FUN_005542c0("Lilac",5);
  FUN_00c98f00(0xdb,0x6b,0x62,0x9b,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light lilac",0xb);
  FUN_00c98f00(0xdc,0xa7,0xa9,0xce,uVar2);
  uVar2 = 0;
  FUN_005542c0("Bright purple",0xd);
  FUN_00c98f00(0xdd,0xcd,0x62,0x98,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light purple",0xc);
  FUN_00c98f00(0xde,0xe4,0xad,200,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light pink",10);
  FUN_00c98f00(0xdf,0xdc,0x90,0x95,uVar2);
  uVar2 = 0;
  FUN_005542c0("Light brick yellow",0x12);
  FUN_00c98f00(0xe0,0xf0,0xd5,0xa0,uVar2);
  uVar2 = 0;
  FUN_005542c0("Warm yellowish orange",0x15);
  FUN_00c98f00(0xe1,0xeb,0xb8,0x7f,uVar2);
  uVar2 = 0;
  FUN_00551260("Cool yellow");
  FUN_00c98f00(0xe2,0xfd,0xea,0x8d,uVar2);
  FUN_0054eff0("Dove blue");
  FUN_00c98f00(0xe8,0x7d,0xbb,0xdd,uVar2);
  FUN_0054eff0("Medium lilac");
  FUN_00c98f00(0x10c,0x34,0x2b,0x75,uVar2);
  FUN_0054eff0("Slime green");
  FUN_00c98f00(0x12d,0x50,0x6d,0x54,uVar2);
  FUN_0054eff0("Smoky grey");
  FUN_00c98f00(0x12e,0x5b,0x5d,0x69,uVar2);
  FUN_0054eff0("Dark blue");
  FUN_00c98f00(0x12f,0,0x10,0xb0,uVar2);
  FUN_0054eff0("Parsley green");
  FUN_00c98f00(0x130,0x2c,0x65,0x1d,uVar2);
  FUN_0054eff0("Steel blue");
  FUN_00c98f00(0x131,0x52,0x7c,0xae,uVar2);
  FUN_0054eff0("Storm blue");
  FUN_00c98f00(0x132,0x33,0x58,0x82,uVar2);
  FUN_0054eff0("Lapis");
  FUN_00c98f00(0x133,0x10,0x2a,0xdc,uVar2);
  FUN_0054eff0("Dark indigo");
  FUN_00c98f00(0x134,0x3d,0x15,0x85,uVar2);
  FUN_0054eff0("Sea green");
  FUN_00c98f00(0x135,0x34,0x8e,0x40,uVar2);
  FUN_0054eff0("Shamrock");
  FUN_00c98f00(0x136,0x5b,0x9a,0x4c,uVar2);
  FUN_0054eff0("Fossil");
  FUN_00c98f00(0x137,0x9f,0xa1,0xac,uVar2);
  FUN_0054eff0("Mulberry");
  FUN_00c98f00(0x138,0x59,0x22,0x59,uVar2);
  FUN_0054eff0("Forest green");
  FUN_00c98f00(0x139,0x1f,0x80,0x1d,uVar2);
  FUN_0054eff0("Cadet blue");
  FUN_00c98f00(0x13a,0x9f,0xad,0xc0,uVar2);
  FUN_0054eff0("Electric blue");
  FUN_00c98f00(0x13b,9,0x89,0xcf,uVar2);
  FUN_0054eff0("Eggplant");
  FUN_00c98f00(0x13c,0x7b,0,0x7b,uVar2);
  FUN_0054eff0(&DAT_01973d48);
  FUN_00c98f00(0x13d,0x7c,0x9c,0x6b,uVar2);
  FUN_0054eff0("Artichoke");
  FUN_00c98f00(0x13e,0x8a,0xab,0x85,uVar2);
  FUN_0054eff0("Sage green");
  FUN_00c98f00(0x13f,0xb9,0xc4,0xb1,uVar2);
  FUN_0054eff0("Ghost grey");
  FUN_00c98f00(0x140,0xca,0xcb,0xd1,uVar2);
  FUN_0054eff0("Lilac");
  FUN_00c98f00(0x141,0xa7,0x5e,0x9b,uVar2);
  FUN_0054eff0(&DAT_01973d74);
  FUN_00c98f00(0x142,0x7b,0x2f,0x7b,uVar2);
  FUN_0054eff0("Olivine");
  FUN_00c98f00(0x143,0x94,0xbe,0x81,uVar2);
  FUN_0054eff0("Laurel green");
  FUN_00c98f00(0x144,0xa8,0xbd,0x99,uVar2);
  FUN_0054eff0("Quill grey");
  FUN_00c98f00(0x145,0xdf,0xdf,0xde,uVar2);
  FUN_0054eff0("Crimson");
  FUN_00c98f00(0x147,0x97,0,0,uVar2);
  FUN_0054eff0(&DAT_01973da8);
  FUN_00c98f00(0x148,0xb1,0xe5,0xa6,uVar2);
  FUN_0054eff0("Baby blue");
  FUN_00c98f00(0x149,0x98,0xc2,0xdb,uVar2);
  FUN_0054eff0("Carnation pink");
  FUN_00c98f00(0x14a,0xff,0x98,0xdc,uVar2);
  FUN_0054eff0("Persimmon");
  FUN_00c98f00(0x14b,0xff,0x59,0x59,uVar2);
  FUN_0054eff0("Maroon");
  FUN_00c98f00(0x14c,0x75,0,0,uVar2);
  FUN_0054eff0(&DAT_0194d300);
  FUN_00c98f00(0x14d,0xef,0xb8,0x38,uVar2);
  FUN_0054eff0("Daisy orange");
  FUN_00c98f00(0x14e,0xf8,0xd9,0x6d,uVar2);
  FUN_0054eff0("Pearl");
  FUN_00c98f00(0x14f,0xe7,0xe7,0xec,uVar2);
  FUN_0054eff0(&DAT_01973df8);
  FUN_00c98f00(0x150,199,0xd4,0xe4,uVar2);
  FUN_0054eff0("Salmon");
  FUN_00c98f00(0x151,0xff,0x94,0x94,uVar2);
  FUN_0054eff0("Terra Cotta");
  FUN_00c98f00(0x152,0xbe,0x68,0x62,uVar2);
  FUN_0054eff0("Cocoa");
  FUN_00c98f00(0x153,0x56,0x24,0x24,uVar2);
  FUN_0054eff0("Wheat");
  FUN_00c98f00(0x154,0xf1,0xe7,199,uVar2);
  FUN_0054eff0("Buttermilk");
  FUN_00c98f00(0x155,0xfe,0xf3,0xbb,uVar2);
  FUN_0054eff0("Mauve");
  FUN_00c98f00(0x156,0xe0,0xb2,0xd0,uVar2);
  FUN_0054eff0("Sunrise");
  FUN_00c98f00(0x157,0xd4,0x90,0xbd,uVar2);
  FUN_0054eff0("Tawny");
  FUN_00c98f00(0x158,0x96,0x55,0x55,uVar2);
  FUN_0054eff0(&DAT_018fa4fc);
  FUN_00c98f00(0x159,0x8f,0x4c,0x2a,uVar2);
  FUN_0054eff0("Cashmere");
  FUN_00c98f00(0x15a,0xd3,0xbe,0x96,uVar2);
  FUN_0054eff0("Khaki");
  FUN_00c98f00(0x15b,0xe2,0xdc,0xbc,uVar2);
  FUN_0054eff0("Lily white");
  FUN_00c98f00(0x15c,0xed,0xea,0xea,uVar2);
  FUN_0054eff0("Seashell");
  FUN_00c98f00(0x15d,0xe9,0xda,0xda,uVar2);
  FUN_0054eff0("Burgundy");
  FUN_00c98f00(0x15e,0x88,0x3e,0x3e,uVar2);
  FUN_0054eff0(&DAT_01973e7c);
  FUN_00c98f00(0x15f,0xbc,0x9b,0x5d,uVar2);
  FUN_0054eff0("Burlap");
  FUN_00c98f00(0x160,199,0xac,0x78,uVar2);
  FUN_0054eff0("Beige");
  FUN_00c98f00(0x161,0xca,0xbf,0xa3,uVar2);
  FUN_0054eff0("Oyster");
  FUN_00c98f00(0x162,0xbb,0xb3,0xb2,uVar2);
  FUN_0054eff0("Pine Cone");
  FUN_00c98f00(0x163,0x6c,0x58,0x4b,uVar2);
  FUN_0054eff0("Fawn brown");
  FUN_00c98f00(0x164,0xa0,0x84,0x4f,uVar2);
  FUN_0054eff0("Hurricane grey");
  FUN_00c98f00(0x165,0x95,0x89,0x88,uVar2);
  FUN_0054eff0("Cloudy grey");
  FUN_00c98f00(0x166,0xab,0xa8,0x9e,uVar2);
  FUN_0054eff0("Linen");
  FUN_00c98f00(0x167,0xaf,0x94,0x83,uVar2);
  FUN_0054eff0("Copper");
  FUN_00c98f00(0x168,0x96,0x67,0x66,uVar2);
  FUN_0054eff0("Dirt brown");
  FUN_00c98f00(0x169,0x56,0x42,0x36,uVar2);
  FUN_0054eff0("Bronze");
  FUN_00c98f00(0x16a,0x7e,0x68,0x3f,uVar2);
  FUN_0054eff0("Flint");
  FUN_00c98f00(0x16b,0x69,0x66,0x5c,uVar2);
  FUN_0054eff0("Dark taupe");
  FUN_00c98f00(0x16c,0x5a,0x4c,0x42,uVar2);
  FUN_0054eff0("Burnt Sienna");
  FUN_00c98f00(0x16d,0x6a,0x39,9,uVar2);
  FUN_0054eff0("Institutional white");
  FUN_00c98f00(0x3e9,0xf8,0xf8,0xf8,uVar2);
  FUN_0054eff0("Mid gray");
  FUN_00c98f00(0x3ea,0xcd,0xcd,0xcd,uVar2);
  FUN_0054eff0("Really black");
  FUN_00c98f00(0x3eb,0x11,0x11,0x11,uVar2);
  FUN_0054eff0("Really red");
  FUN_00c98f00(0x3ec,0xff,0,0,uVar2);
  FUN_0054eff0("Deep orange");
  FUN_00c98f00(0x3ed,0xff,0xb0,0,uVar2);
  FUN_0054eff0("Alder");
  FUN_00c98f00(0x3ee,0xb4,0x80,0xff,uVar2);
  FUN_0054eff0("Dusty Rose");
  FUN_00c98f00(0x3ef,0xa3,0x4b,0x4b,uVar2);
  FUN_0054eff0("Olive");
  FUN_00c98f00(0x3f0,0xc1,0xbe,0x42,uVar2);
  FUN_0054eff0("New Yeller");
  FUN_00c98f00(0x3f1,0xff,0xff,0,uVar2);
  FUN_0054eff0("Really blue");
  FUN_00c98f00(0x3f2,0,0,0xff,uVar2);
  FUN_0054eff0("Navy blue");
  FUN_00c98f00(0x3f3,0,0x20,0x60,uVar2);
  FUN_0054eff0("Deep blue");
  FUN_00c98f00(0x3f4,0x21,0x54,0xb9,uVar2);
  FUN_0054eff0(&DAT_01973fac);
  FUN_00c98f00(0x3f5,4,0xaf,0xec,uVar2);
  FUN_0054eff0("CGA brown");
  FUN_00c98f00(0x3f6,0xaa,0x55,0,uVar2);
  FUN_0054eff0("Magenta");
  FUN_00c98f00(0x3f7,0xaa,0,0xaa,uVar2);
  FUN_0054eff0(&DAT_01973fc8);
  FUN_00c98f00(0x3f8,0xff,0x66,0xcc,uVar2);
  FUN_0054eff0("Deep orange");
  FUN_00c98f00(0x3f9,0xff,0xaf,0,uVar2);
  FUN_0054eff0(&DAT_01973fd0);
  FUN_00c98f00(0x3fa,0x12,0xee,0xd4,uVar2);
  FUN_0054eff0("Toothpaste");
  FUN_00c98f00(0x3fb,0,0xff,0xff,uVar2);
  FUN_0054eff0("Lime green");
  FUN_00c98f00(0x3fc,0,0xff,0,uVar2);
  FUN_0054eff0(&DAT_01973ff0);
  FUN_00c98f00(0x3fd,0x3a,0x7d,0x15,uVar2);
  FUN_0054eff0("Grime");
  FUN_00c98f00(0x3fe,0x7f,0x8e,100,uVar2);
  FUN_0054eff0("Lavender");
  FUN_00c98f00(0x3ff,0x8c,0x5b,0x9f,uVar2);
  FUN_0054eff0("Pastel light blue");
  FUN_00c98f00(0x400,0xaf,0xdd,0xff,uVar2);
  FUN_0054eff0("Pastel orange");
  FUN_00c98f00(0x401,0xff,0xc9,0xc9,uVar2);
  FUN_0054eff0("Pastel violet");
  FUN_00c98f00(0x402,0xb1,0xa7,0xff,uVar2);
  FUN_0054eff0("Pastel blue-green");
  FUN_00c98f00(0x403,0x9f,0xf3,0xe9,uVar2);
  FUN_0054eff0("Pastel green");
  FUN_00c98f00(0x404,0xcc,0xff,0xcc,uVar2);
  FUN_0054eff0("Pastel yellow");
  FUN_00c98f00(0x405,0xff,0xff,0xcc,uVar2);
  FUN_0054eff0("Pastel brown");
  FUN_00c98f00(0x406,0xff,0xcc,0x99,uVar2);
  FUN_0054eff0("Royal purple");
  FUN_00c98f00(0x407,0x62,0x25,0xd1,uVar2);
  FUN_0054eff0("Hot pink");
  FUN_00c98f00(0x408,0xff,0,0xbf,uVar2);
  FUN_00c9a0c0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29850 ; VA 0x00c985d0 ; FUN_00c985d0 */

void __fastcall FUN_00c985d0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00c95850(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x30) * 0x30;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 29851 ; VA 0x00c98650 ; FUN_00c98650 */

void __fastcall FUN_00c98650(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  FUN_00601ea0();
  FUN_01674ea0(param_1[0xe],0x18);
  FUN_00601ea0();
  FUN_01674ea0(param_1[0xc],0x18);
  FUN_00c985d0();
  iVar1 = param_1[6];
  if (iVar1 != 0) {
    uVar3 = param_1[8] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00c98763;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0;
  }
  iVar1 = param_1[3];
  if (iVar1 != 0) {
    uVar3 = param_1[5] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00c98763;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00c98763:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 29852 ; VA 0x00c98770 ; FUN_00c98770 */

undefined * __thiscall FUN_00c98770(undefined4 *param_1,undefined *param_2,int param_3)

{
  undefined4 uVar1;
  undefined *puVar2;
  
  uVar1 = *param_1;
  if (param_3 != 0) {
    puVar2 = param_2 + 4;
    do {
      *param_2 = 0;
      *(undefined4 *)(puVar2 + -3) = 1;
      param_2 = param_2 + 0x30;
      puVar2[1] = 0;
      *(undefined4 *)(puVar2 + 4) = 0;
      *(undefined4 *)(puVar2 + 8) = 0;
      *(undefined4 *)(puVar2 + 0xc) = 0;
      *(undefined4 *)(puVar2 + 0x10) = 0x3f800000;
      *(undefined4 *)(puVar2 + 0x24) = 0;
      *(undefined4 *)(puVar2 + 0x28) = 0xf;
      puVar2[0x14] = 0;
      param_3 = param_3 + -1;
      puVar2 = puVar2 + 0x30;
    } while (param_3 != 0);
  }
  FUN_00c95850(param_2,param_2,uVar1);
  return param_2;
}



/* FUNCTION 29853 ; VA 0x00c987e0 ; FUN_00c987e0 */

void FUN_00c987e0(uint *param_1,float param_2,float param_3,float param_4)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  char *pcVar4;
  float fVar5;
  uint uVar6;
  uint uVar7;
  float fStack_c;
  uint uStack_8;
  
  uStack_8 = 0xc2;
  fStack_c = DAT_01900c50;
  iVar2 = FUN_00c9a030();
  uVar3 = 0;
  pcVar4 = *(char **)(iVar2 + 0x24);
  uVar1 = (*(int *)(iVar2 + 0x28) - (int)pcVar4) / 0x30;
  if (uVar1 == 0) {
    *param_1 = 0xc2;
    return;
  }
  do {
    if (*pcVar4 != '\0') {
      uVar6 = (uint)DAT_018c0da0;
      uVar7 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
      fVar5 = (float)(double)CONCAT44((uint)((ulonglong)(double)(*(float *)(pcVar4 + 0xc) - param_3)
                                            >> 0x20) & uVar7,
                                      SUB84((double)(*(float *)(pcVar4 + 0xc) - param_3),0) & uVar6)
              + (float)(double)CONCAT44((uint)((ulonglong)(double)(*(float *)(pcVar4 + 8) - param_2)
                                              >> 0x20) & uVar7,
                                        SUB84((double)(*(float *)(pcVar4 + 8) - param_2),0) & uVar6)
              + (float)(double)CONCAT44((uint)((ulonglong)
                                               (double)(*(float *)(pcVar4 + 0x10) - param_4) >> 0x20
                                              ) & uVar7,
                                        SUB84((double)(*(float *)(pcVar4 + 0x10) - param_4),0) &
                                        uVar6);
      if ((fVar5 < fStack_c) && (uStack_8 = uVar3, fStack_c = fVar5, NAN(fVar5) != (fVar5 == 0.0)))
      break;
    }
    uVar3 = uVar3 + 1;
    pcVar4 = pcVar4 + 0x30;
  } while (uVar3 < uVar1);
  *param_1 = uStack_8;
  return;
}



/* FUNCTION 29854 ; VA 0x00c98900 ; FUN_00c98900 */

void FUN_00c98900(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  char *pcVar10;
  uint uStack_10;
  int iStack_c;
  
  uVar9 = 0xc2;
  uStack_10 = 0xc2;
  iStack_c = 10000;
  iVar2 = FUN_00c9a030();
  uVar5 = 0;
  pcVar10 = *(char **)(iVar2 + 0x24);
  uVar1 = (*(int *)(iVar2 + 0x28) - (int)pcVar10) / 0x30;
  if (uVar1 == 0) {
    *param_1 = 0xc2;
    return;
  }
  do {
    if (*pcVar10 != '\0') {
      uVar9 = *(uint *)(pcVar10 + 2);
      uVar3 = (uVar9 >> 0x10 & 0xff) - (param_2 >> 0x10 & 0xff);
      uVar6 = (int)uVar3 >> 0x1f;
      uVar4 = (uVar9 >> 8 & 0xff) - (param_2 >> 8 & 0xff);
      uVar7 = (int)uVar4 >> 0x1f;
      uVar9 = (uVar9 & 0xff) - (param_2 & 0xff);
      uVar8 = (int)uVar9 >> 0x1f;
      iVar2 = ((uVar3 ^ uVar6) - uVar6) + ((uVar4 ^ uVar7) - uVar7) + ((uVar9 ^ uVar8) - uVar8);
      uVar9 = uStack_10;
      if ((iVar2 < iStack_c) && (uVar9 = uVar5, uStack_10 = uVar5, iStack_c = iVar2, iVar2 == 0))
      break;
    }
    uVar5 = uVar5 + 1;
    pcVar10 = pcVar10 + 0x30;
  } while (uVar5 < uVar1);
  *param_1 = uVar9;
  return;
}



/* FUNCTION 29855 ; VA 0x00c989d0 ; FUN_00c989d0 */

void FUN_00c989d0(uint *param_1,float param_2,float param_3,float param_4)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  char *pcVar4;
  float fVar5;
  uint uVar6;
  uint uVar7;
  float fStack_c;
  uint uStack_8;
  
  uStack_8 = 0xc2;
  fStack_c = DAT_01900c50;
  iVar2 = FUN_00c9a030();
  uVar3 = 0;
  pcVar4 = *(char **)(iVar2 + 0x24);
  uVar1 = (*(int *)(iVar2 + 0x28) - (int)pcVar4) / 0x30;
  if (uVar1 == 0) {
    *param_1 = 0xc2;
    return;
  }
  do {
    if (*pcVar4 != '\0') {
      uVar6 = (uint)DAT_018c0da0;
      uVar7 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
      fVar5 = (float)(double)CONCAT44((uint)((ulonglong)(double)(*(float *)(pcVar4 + 0xc) - param_3)
                                            >> 0x20) & uVar7,
                                      SUB84((double)(*(float *)(pcVar4 + 0xc) - param_3),0) & uVar6)
              + (float)(double)CONCAT44((uint)((ulonglong)(double)(*(float *)(pcVar4 + 8) - param_2)
                                              >> 0x20) & uVar7,
                                        SUB84((double)(*(float *)(pcVar4 + 8) - param_2),0) & uVar6)
              + (float)(double)CONCAT44((uint)((ulonglong)
                                               (double)(*(float *)(pcVar4 + 0x10) - param_4) >> 0x20
                                              ) & uVar7,
                                        SUB84((double)(*(float *)(pcVar4 + 0x10) - param_4),0) &
                                        uVar6);
      if ((fVar5 < fStack_c) && (uStack_8 = uVar3, fStack_c = fVar5, NAN(fVar5) != (fVar5 == 0.0)))
      break;
    }
    uVar3 = uVar3 + 1;
    pcVar4 = pcVar4 + 0x30;
  } while (uVar3 < uVar1);
  *param_1 = uStack_8;
  return;
}



/* FUNCTION 29856 ; VA 0x00c98ad0 ; FUN_00c98ad0 */

void __thiscall FUN_00c98ad0(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00c9a030();
  puVar1 = (undefined4 *)(*(int *)(iVar4 + 0x24) + 8 + *param_1 * 0x30);
  uVar2 = puVar1[1];
  uVar3 = puVar1[2];
  *param_2 = *puVar1;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  return;
}



/* FUNCTION 29857 ; VA 0x00c98b10 ; FUN_00c98b10 */

void __thiscall FUN_00c98b10(int *param_1,undefined *param_2)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = FUN_00c9a030();
  uVar1 = *(undefined4 *)(*(int *)(iVar2 + 0x24) + 2 + *param_1 * 0x30);
  *param_2 = (char)uVar1;
  param_2[1] = (char)((uint)uVar1 >> 8);
  param_2[2] = (char)((uint)uVar1 >> 0x10);
  return;
}



/* FUNCTION 29858 ; VA 0x00c98b50 ; FUN_00c98b50 */

void __thiscall FUN_00c98b50(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  
  iVar5 = FUN_00c9a030();
  puVar1 = (undefined4 *)(*(int *)(iVar5 + 0x24) + 8 + *param_1 * 0x30);
  uVar2 = puVar1[1];
  uVar3 = puVar1[2];
  uVar4 = puVar1[3];
  *param_2 = *puVar1;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  return;
}



/* FUNCTION 29859 ; VA 0x00c98b80 ; FUN_00c98b80 */

int FUN_00c98b80(void)

{
  int iVar1;
  
  iVar1 = FUN_00c9a030();
  return iVar1 + 0xc;
}



/* FUNCTION 29860 ; VA 0x00c98b90 ; FUN_00c98b90 */

void __fastcall FUN_00c98b90(int *param_1)

{
  float *pfVar1;
  float *pfVar2;
  uint uVar3;
  uint *puVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint *puVar9;
  uint *puVar10;
  float fVar11;
  float fVar12;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  uint uStack_30;
  int *piStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint *puStack_20;
  uint uStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810320;
  pvStack_10 = ExceptionList;
  piStack_2c = param_1 + 0xc;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  FUN_00601ea0();
  FUN_00601ea0();
  puVar9 = (uint *)*param_1;
  puVar10 = (uint *)param_1[1];
  if (puVar9 != puVar10) {
    piVar5 = piStack_14 + 3;
    puStack_20 = puVar10;
    do {
      uStack_28 = *puVar9;
      uStack_1c = uStack_28;
      FUN_00c95d40(piVar5);
      uStack_8 = 0;
      uStack_18 = 0;
      pfVar1 = (float *)(piStack_14[9] + 8 + uStack_1c * 0x30);
      uVar6 = 0;
      uStack_24 = iStack_40 - iStack_44 >> 2;
      fVar12 = DAT_01900c50;
      uVar8 = uStack_18;
      if (uStack_24 != 0) {
        while (uVar3 = *(uint *)(iStack_44 + uVar6 * 4), uVar8 = uVar6, uVar3 != uStack_1c) {
          pfVar2 = (float *)(piStack_14[9] + 8 + uVar3 * 0x30);
          fVar11 = (float)(double)CONCAT44((uint)((ulonglong)(double)(*pfVar1 - *pfVar2) >> 0x20) &
                                           DAT_018c0da0._4_4_,
                                           SUB84((double)(*pfVar1 - *pfVar2),0) & (uint)DAT_018c0da0
                                          ) +
                   (float)(double)CONCAT44((uint)((ulonglong)(double)(pfVar1[1] - pfVar2[1]) >> 0x20
                                                 ) & DAT_018c0da0._4_4_,
                                           SUB84((double)(pfVar1[1] - pfVar2[1]),0) &
                                           (uint)DAT_018c0da0) +
                   (float)(double)CONCAT44((uint)((ulonglong)(double)(pfVar1[2] - pfVar2[2]) >> 0x20
                                                 ) & DAT_018c0da0._4_4_,
                                           SUB84((double)(pfVar1[2] - pfVar2[2]),0) &
                                           (uint)DAT_018c0da0);
          puVar10 = puStack_20;
          if (((fVar11 < fVar12) &&
              (fVar12 = fVar11, uStack_18 = uVar6, NAN(fVar11) != (fVar11 == 0.0))) ||
             (uVar6 = uVar6 + 1, uVar8 = uStack_18, uStack_24 <= uVar6)) break;
        }
      }
      uStack_18 = uVar8;
      puVar4 = (uint *)FUN_0070a8f0(&uStack_28);
      uStack_8 = 0xffffffff;
      *puVar4 = uStack_18;
      if (iStack_44 != 0) {
        uVar8 = (iStack_3c - iStack_44 >> 2) * 4;
        iVar7 = iStack_44;
        if (0xfff < uVar8) {
          iVar7 = *(int *)(iStack_44 + -4);
          uVar8 = uVar8 + 0x23;
          if (0x1f < (iStack_44 - iVar7) - 4U) goto LAB_00c98ef7;
        }
        FUN_01674ea0(iVar7,uVar8);
        iStack_44 = 0;
        iStack_40 = 0;
        iStack_3c = 0;
      }
      uStack_1c = *puVar9;
      FUN_00c95d40(piStack_14 + 6);
      uStack_30 = uStack_1c;
      uStack_8 = 1;
      uStack_18 = 0;
      pfVar1 = (float *)(piStack_14[9] + 8 + uStack_1c * 0x30);
      uVar6 = 0;
      uStack_28 = iStack_4c - iStack_50 >> 2;
      fVar12 = DAT_01900c50;
      uVar8 = uStack_18;
      if (uStack_28 != 0) {
        while (uVar3 = *(uint *)(iStack_50 + uVar6 * 4), uVar8 = uVar6, uVar3 != uStack_1c) {
          pfVar2 = (float *)(piStack_14[9] + 8 + uVar3 * 0x30);
          fVar11 = (float)(double)CONCAT44((uint)((ulonglong)(double)(*pfVar1 - *pfVar2) >> 0x20) &
                                           DAT_018c0da0._4_4_,
                                           SUB84((double)(*pfVar1 - *pfVar2),0) & (uint)DAT_018c0da0
                                          ) +
                   (float)(double)CONCAT44((uint)((ulonglong)(double)(pfVar1[1] - pfVar2[1]) >> 0x20
                                                 ) & DAT_018c0da0._4_4_,
                                           SUB84((double)(pfVar1[1] - pfVar2[1]),0) &
                                           (uint)DAT_018c0da0) +
                   (float)(double)CONCAT44((uint)((ulonglong)(double)(pfVar1[2] - pfVar2[2]) >> 0x20
                                                 ) & DAT_018c0da0._4_4_,
                                           SUB84((double)(pfVar1[2] - pfVar2[2]),0) &
                                           (uint)DAT_018c0da0);
          puVar10 = puStack_20;
          if (((fVar11 < fVar12) &&
              (fVar12 = fVar11, uStack_18 = uVar6, NAN(fVar11) != (fVar11 == 0.0))) ||
             (uVar6 = uVar6 + 1, uVar8 = uStack_18, uStack_28 <= uVar6)) break;
        }
      }
      uStack_18 = uVar8;
      puVar4 = (uint *)FUN_0070a8f0(&uStack_30);
      uStack_8 = 0xffffffff;
      *puVar4 = uStack_18;
      if (iStack_50 != 0) {
        uVar8 = iStack_48 - iStack_50 & 0xfffffffc;
        iVar7 = iStack_50;
        if (0xfff < uVar8) {
          iVar7 = *(int *)(iStack_50 + -4);
          uVar8 = uVar8 + 0x23;
          if (0x1f < (iStack_50 - iVar7) - 4U) {
LAB_00c98ef7:
            uStack_8 = 0xffffffff;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar7,uVar8);
        iStack_50 = 0;
        iStack_4c = 0;
        iStack_48 = 0;
      }
      puVar9 = puVar9 + 1;
    } while (puVar9 != puVar10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29861 ; VA 0x00c98f00 ; FUN_00c98f00 */

void __thiscall
FUN_00c98f00(int param_1,uint param_2,undefined4 param_3,undefined param_4,undefined param_5,
            undefined4 *param_6)

{
  uint *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  undefined *puVar6;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = param_2;
  puStack_c = &LAB_017c8538;
  pvStack_10 = ExceptionList;
  puVar1 = *(uint **)(param_1 + 4);
  uStack_8 = 0;
  if (*(uint **)(param_1 + 8) == puVar1) {
    ExceptionList = &pvStack_10;
    FUN_00c958c0(puVar1,&param_2);
  }
  else {
    ExceptionList = &pvStack_10;
    *puVar1 = param_2;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
  }
  piVar5 = (int *)(param_1 + 0x24);
  iVar4 = *piVar5;
  if ((uint)((*(int *)(param_1 + 0x28) - iVar4) / 0x30) <= uVar3) {
    FUN_00c95a00(uVar3 + 1,piVar5);
    iVar4 = *piVar5;
  }
  puVar6 = (undefined *)(uVar3 * 0x30 + iVar4);
  param_3 = CONCAT13(0xff,CONCAT12(param_5,CONCAT11(param_4,(char)param_3)));
  *(undefined4 *)(puVar6 + 2) = param_3;
  *puVar6 = 1;
  puVar2 = (undefined4 *)FUN_011667e0(puVar6 + 2);
  *(undefined4 *)(puVar6 + 8) = *puVar2;
  *(undefined4 *)(puVar6 + 0xc) = puVar2[1];
  *(undefined4 *)(puVar6 + 0x10) = puVar2[2];
  *(undefined4 *)(puVar6 + 0x14) = puVar2[3];
  if ((undefined4 **)(puVar6 + 0x18) != &param_6) {
    puVar2 = &param_6;
    if (0xf < in_stack_00000028) {
      puVar2 = param_6;
    }
    FUN_005542c0(puVar2,in_stack_00000024);
  }
  if (0xf < in_stack_00000028) {
    uVar3 = in_stack_00000028 + 1;
    puVar2 = param_6;
    if (0xfff < uVar3) {
      puVar2 = (undefined4 *)param_6[-1];
      uVar3 = in_stack_00000028 + 0x24;
      if ((undefined *)0x1f < (undefined *)((int)param_6 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29862 ; VA 0x00c99030 ; FUN_00c99030 */

void __thiscall FUN_00c99030(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = param_2;
  piVar1 = *(int **)(param_1 + 0x10);
  if (*(int **)(param_1 + 0x14) != piVar1) {
    *piVar1 = param_2;
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    *(undefined *)(*(int *)(param_1 + 0x24) + 1 + param_2 * 0x30) = 0;
    return;
  }
  FUN_00c958c0(piVar1,&param_2);
  *(undefined *)(*(int *)(param_1 + 0x24) + 1 + iVar2 * 0x30) = 0;
  return;
}



/* FUNCTION 29863 ; VA 0x00c99080 ; FUN_00c99080 */

int __fastcall FUN_00c99080(int *param_1)

{
  int iVar1;
  
  iVar1 = FUN_00c9a030();
  return *(int *)(iVar1 + 0x24) + 0x18 + *param_1 * 0x30;
}



/* FUNCTION 29864 ; VA 0x00c990a0 ; FUN_00c990a0 */

void FUN_00c990a0(uint *param_1,byte *param_2)

{
  uint uVar1;
  uint uVar2;
  byte *pbVar3;
  byte bVar4;
  int iVar5;
  byte *pbVar6;
  uint uVar7;
  byte *pbVar8;
  uint uVar9;
  char *pcVar10;
  byte *pbVar11;
  bool bVar12;
  uint uStack_14;
  byte bStack_5;
  
  iVar5 = FUN_00c9a030();
  bStack_5 = 1;
  uStack_14 = 0xffffffff;
  uVar9 = 0;
  pcVar10 = *(char **)(iVar5 + 0x24);
  uVar1 = (*(int *)(iVar5 + 0x28) - (int)pcVar10) / 0x30;
  if (uVar1 != 0) {
    bVar4 = 1;
    pbVar11 = (byte *)(pcVar10 + 0x18);
    do {
      if (bVar4 == 0) break;
      if (*pcVar10 != '\0') {
        pbVar8 = param_2;
        do {
          bVar4 = *pbVar8;
          pbVar8 = pbVar8 + 1;
        } while (bVar4 != 0);
        uVar7 = *(uint *)(pbVar11 + 0x10);
        pbVar6 = pbVar11;
        if (0xf < *(uint *)(pbVar11 + 0x14)) {
          pbVar6 = *(byte **)pbVar11;
        }
        bVar4 = bStack_5;
        pbVar3 = param_2;
        if (uVar7 == (int)pbVar8 - (int)(param_2 + 1)) {
          while (uVar2 = uVar7 - 4, 3 < uVar7) {
            if (*(int *)pbVar6 != *(int *)pbVar3) goto LAB_00c99138;
            pbVar6 = pbVar6 + 4;
            pbVar3 = pbVar3 + 4;
            uVar7 = uVar2;
          }
          if (uVar2 == 0xfffffffc) {
LAB_00c9916c:
            uVar7 = 0;
          }
          else {
LAB_00c99138:
            bVar12 = *pbVar6 < *pbVar3;
            if ((*pbVar6 == *pbVar3) &&
               ((uVar2 == 0xfffffffd ||
                ((bVar12 = pbVar6[1] < pbVar3[1], pbVar6[1] == pbVar3[1] &&
                 ((uVar2 == 0xfffffffe ||
                  ((bVar12 = pbVar6[2] < pbVar3[2], pbVar6[2] == pbVar3[2] &&
                   ((uVar2 == 0xffffffff || (bVar12 = pbVar6[3] < pbVar3[3], pbVar6[3] == pbVar3[3])
                    ))))))))))) goto LAB_00c9916c;
            uVar7 = -(uint)bVar12 | 1;
          }
          if (uVar7 == 0) {
            bStack_5 = pbVar11[-0x17];
            bVar4 = bStack_5;
            uStack_14 = uVar9;
          }
        }
      }
      uVar9 = uVar9 + 1;
      pcVar10 = pcVar10 + 0x30;
      pbVar11 = pbVar11 + 0x30;
    } while (uVar9 < uVar1);
    if (uStack_14 != 0xffffffff) {
      *param_1 = uStack_14;
      return;
    }
  }
  *param_1 = 0xc2;
  return;
}



/* FUNCTION 29865 ; VA 0x00c991c0 ; FUN_00c991c0 */

void __thiscall FUN_00c991c0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
    return;
  }
  FUN_00c958c0(puVar1,param_2);
  return;
}



/* FUNCTION 29866 ; VA 0x00c991f0 ; FUN_00c991f0 */

void FUN_00c991f0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_00c9a030();
  iVar1 = FUN_011607a0(0,(*(int *)(iVar1 + 0x10) - *(int *)(iVar1 + 0xc) >> 2) + -1);
  iVar2 = FUN_00c9a030();
  *param_1 = *(undefined4 *)(*(int *)(iVar2 + 0xc) + iVar1 * 4);
  return;
}



/* FUNCTION 29867 ; VA 0x00c99230 ; FUN_00c99230 */

void __thiscall FUN_00c99230(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  
  uVar5 = param_2;
  piVar1 = (int *)(param_1 + 0x18);
  iVar2 = *piVar1;
  if (param_2 != *(int *)(param_1 + 0x1c) - iVar2 >> 2) {
    *(int *)(param_1 + 0x1c) = iVar2;
    param_2 = 0x8d;
    if (*(int *)(param_1 + 0x20) == iVar2) {
      FUN_00c958c0(*(undefined4 **)(param_1 + 0x1c),&param_2);
    }
    else {
      **(undefined4 **)(param_1 + 0x1c) = 0x8d;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x12d;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x12d;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x6b;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x6b;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x12e;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x12e;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x1a;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x1a;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3f4;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3f4;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x12f;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x12f;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3f3;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3f3;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x130;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x130;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x1c;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x1c;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3fa;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3fa;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x87;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x87;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x131;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x131;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x132;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x132;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x133;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x133;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x134;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x134;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3fd;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3fd;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x135;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x135;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x136;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x136;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3fb;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3fb;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x137;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x137;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x66;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x66;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x17;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x17;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3f2;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3f2;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x138;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x138;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x139;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x139;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x25;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x25;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3fe;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3fe;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3fc;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3fc;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x403;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x403;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x13a;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x13a;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x13b;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x13b;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3ff;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3ff;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x407;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x407;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x13c;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x13c;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x97;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x97;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x13d;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x13d;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x13e;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x13e;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x13f;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x13f;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x140;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x140;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x400;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x400;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3f5;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3f5;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3ee;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3ee;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x141;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x141;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x142;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x142;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x68;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x68;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3f0;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3f0;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x77;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x77;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x143;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x143;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x144;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x144;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x145;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x145;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0xb;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0xb;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x402;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x402;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3f8;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3f8;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x408;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x408;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x3f7;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x3f7;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x1c);
    param_2 = 0x147;
    if (*(undefined4 **)(param_1 + 0x20) == puVar3) {
      FUN_00c958c0(puVar3,&param_2);
    }
    else {
      *puVar3 = 0x147;
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 4;
    }
    param_2 = 0x3f9;
    FUN_00c991c0(&param_2);
    param_2 = 0x3f1;
    FUN_00c991c0(&param_2);
    param_2 = 0x1d;
    FUN_00c991c0(&param_2);
    param_2 = 0x148;
    FUN_00c991c0(&param_2);
    param_2 = 0x404;
    FUN_00c991c0(&param_2);
    param_2 = 0xd0;
    FUN_00c991c0(&param_2);
    param_2 = 0x2d;
    FUN_00c991c0(&param_2);
    param_2 = 0x149;
    FUN_00c991c0(&param_2);
    param_2 = 0x14a;
    FUN_00c991c0(&param_2);
    param_2 = 0x14b;
    FUN_00c991c0(&param_2);
    param_2 = 0x3ec;
    FUN_00c991c0(&param_2);
    param_2 = 0x15;
    FUN_00c991c0(&param_2);
    param_2 = 0x14c;
    FUN_00c991c0(&param_2);
    param_2 = 0x14d;
    FUN_00c991c0(&param_2);
    param_2 = 0x18;
    FUN_00c991c0(&param_2);
    param_2 = 0x14e;
    FUN_00c991c0(&param_2);
    param_2 = 0xe2;
    FUN_00c991c0(&param_2);
    param_2 = 0x405;
    FUN_00c991c0(&param_2);
    param_2 = 0x14f;
    FUN_00c991c0(&param_2);
    param_2 = 0x150;
    FUN_00c991c0(&param_2);
    param_2 = 0x401;
    FUN_00c991c0(&param_2);
    param_2 = 0x151;
    FUN_00c991c0(&param_2);
    param_2 = 0x152;
    FUN_00c991c0(&param_2);
    param_2 = 0x3ef;
    FUN_00c991c0(&param_2);
    param_2 = 0x153;
    FUN_00c991c0(&param_2);
    param_2 = 0x85;
    FUN_00c991c0(&param_2);
    param_2 = 0x6a;
    FUN_00c991c0(&param_2);
    param_2 = 0x28;
    FUN_00c991c0(&param_2);
    param_2 = 0x155;
    FUN_00c991c0(&param_2);
    param_2 = 0x3e9;
    FUN_00c991c0(&param_2);
    param_2 = 1;
    FUN_00c991c0(&param_2);
    param_2 = 9;
    FUN_00c991c0(&param_2);
    param_2 = 0x156;
    FUN_00c991c0(&param_2);
    param_2 = 0x157;
    FUN_00c991c0(&param_2);
    param_2 = 0x158;
    FUN_00c991c0(&param_2);
    param_2 = 0x159;
    FUN_00c991c0(&param_2);
    param_2 = 0x3f6;
    FUN_00c991c0(&param_2);
    param_2 = 0x69;
    FUN_00c991c0(&param_2);
    param_2 = 0x15a;
    FUN_00c991c0(&param_2);
    param_2 = 0x15b;
    FUN_00c991c0(&param_2);
    param_2 = 0x15c;
    FUN_00c991c0(&param_2);
    param_2 = 0x15d;
    FUN_00c991c0(&param_2);
    param_2 = 0x406;
    FUN_00c991c0(&param_2);
    param_2 = 0x7d;
    FUN_00c991c0(&param_2);
    param_2 = 0x65;
    FUN_00c991c0(&param_2);
    param_2 = 0x15e;
    FUN_00c991c0(&param_2);
    param_2 = 0xc0;
    FUN_00c991c0(&param_2);
    param_2 = 0x15f;
    FUN_00c991c0(&param_2);
    param_2 = 0x160;
    FUN_00c991c0(&param_2);
    param_2 = 0x161;
    FUN_00c991c0(&param_2);
    param_2 = 0x162;
    FUN_00c991c0(&param_2);
    param_2 = 0x3ea;
    FUN_00c991c0(&param_2);
    param_2 = 5;
    FUN_00c991c0(&param_2);
    param_2 = 0x12;
    FUN_00c991c0(&param_2);
    param_2 = 0xd9;
    FUN_00c991c0(&param_2);
    param_2 = 0x163;
    FUN_00c991c0(&param_2);
    param_2 = 0x164;
    FUN_00c991c0(&param_2);
    param_2 = 0x99;
    FUN_00c991c0(&param_2);
    param_2 = 0x165;
    FUN_00c991c0(&param_2);
    param_2 = 0x166;
    FUN_00c991c0(&param_2);
    param_2 = 0x167;
    FUN_00c991c0(&param_2);
    param_2 = 0x168;
    FUN_00c991c0(&param_2);
    param_2 = 0x26;
    FUN_00c991c0(&param_2);
    param_2 = 0x169;
    FUN_00c991c0(&param_2);
    param_2 = 0x16a;
    FUN_00c991c0(&param_2);
    param_2 = 199;
    FUN_00c991c0(&param_2);
    param_2 = 0xc2;
    FUN_00c991c0(&param_2);
    param_2 = 0x16b;
    FUN_00c991c0(&param_2);
    param_2 = 0x16c;
    FUN_00c991c0(&param_2);
    param_2 = 0x16d;
    FUN_00c991c0(&param_2);
    param_2 = 0x3eb;
    FUN_00c991c0(&param_2);
    uVar4 = *(int *)(param_1 + 0x1c) - *piVar1 >> 2;
    if (uVar4 < uVar5) {
      uVar5 = uVar4;
    }
    FUN_00c95c40(uVar5,piVar1);
    FUN_00c98b90();
  }
  return;
}



/* FUNCTION 29868 ; VA 0x00c9a030 ; FUN_00c9a030 */

undefined * FUN_00c9a030(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181033c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f02058) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f02058);
    if (DAT_01f02058 == -1) {
      uStack_8 = 0;
      FUN_00c95e20();
      FUN_016f3654(&LAB_01897ba0);
      FUN_016f37bf(&DAT_01f02058);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f02018;
}



/* FUNCTION 29869 ; VA 0x00c9a0c0 ; FUN_00c9a0c0 */

void __fastcall FUN_00c9a0c0(int param_1)

{
  undefined4 *puVar1;
  undefined4 uStack_8;
  
  puVar1 = *(undefined4 **)(param_1 + 0xc);
  if ((*(int *)(param_1 + 0x10) - (int)puVar1 & 0xfffffffcU) != 0x200) {
    *(undefined4 **)(param_1 + 0x10) = puVar1;
    uStack_8 = 0x8d;
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x8d;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x12d;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x1a71) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x12d;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x6b;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x3871) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x6b;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x1a;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x1411) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x1a;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x3f4;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x4e1) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x3f4;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x12f;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0xbdc1) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x12f;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x3f3;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x38d1) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x3f3;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x130;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0xbd91) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x130;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x1c;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x3901) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x1c;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x3fa;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x541) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x3fa;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x12e;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0xbee1) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x12e;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x131;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x38a1) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x131;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x132;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x3931) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x132;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x133;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x3961) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x133;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    uStack_8 = 0x134;
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x3991) = 0;
    puVar1 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar1) {
      FUN_00c958c0(puVar1,&uStack_8);
    }
    else {
      *puVar1 = 0x134;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
    *(undefined *)(*(int *)(param_1 + 0x24) + 0x39c1) = 0;
    FUN_00c99030(0x3fd);
    FUN_00c99030(0x135);
    FUN_00c99030(0x136);
    FUN_00c99030(0x3fb);
    FUN_00c99030(0x87);
    FUN_00c99030(0x66);
    FUN_00c99030(0x17);
    FUN_00c99030(0x3f2);
    FUN_00c99030(0x138);
    FUN_00c99030(0x139);
    FUN_00c99030(0x25);
    FUN_00c99030(0x3fe);
    FUN_00c99030(0x3fc);
    FUN_00c99030(0x403);
    FUN_00c99030(0x137);
    FUN_00c99030(0x13b);
    FUN_00c99030(0x3ff);
    FUN_00c99030(0x407);
    FUN_00c99030(0x13c);
    FUN_00c99030(0x97);
    FUN_00c99030(0x13d);
    FUN_00c99030(0x13e);
    FUN_00c99030(0x13f);
    FUN_00c99030(0x400);
    FUN_00c99030(0x13a);
    FUN_00c99030(0x3f5);
    FUN_00c99030(0x3ee);
    FUN_00c99030(0x141);
    FUN_00c99030(0x142);
    FUN_00c99030(0x68);
    FUN_00c99030(0x3f0);
    FUN_00c99030(0x77);
    FUN_00c99030(0x143);
    FUN_00c99030(0x144);
    FUN_00c99030(0x145);
    FUN_00c99030(0x140);
    FUN_00c99030(0xb);
    FUN_00c99030(0x402);
    FUN_00c99030(0x3f8);
    FUN_00c99030(0x408);
    FUN_00c99030(0x3f7);
    FUN_00c99030(0x147);
    FUN_00c99030(0x3ed);
    FUN_00c99030(0x3f1);
    FUN_00c99030(0x1d);
    FUN_00c99030(0x148);
    FUN_00c99030(0x404);
    FUN_00c99030(0xd0);
    FUN_00c99030(0x2d);
    FUN_00c99030(0x149);
    FUN_00c99030(0x14a);
    FUN_00c99030(0x14b);
    FUN_00c99030(0x3ec);
    FUN_00c99030(0x15);
    FUN_00c99030(0x14c);
    FUN_00c99030(0x14d);
    FUN_00c99030(0x18);
    FUN_00c99030(0x14e);
    FUN_00c99030(0xe2);
    FUN_00c99030(0x405);
    FUN_00c99030(0x14f);
    FUN_00c99030(0x150);
    FUN_00c99030(0x156);
    FUN_00c99030(0x157);
    FUN_00c99030(0x152);
    FUN_00c99030(0x3ef);
    FUN_00c99030(0x153);
    FUN_00c99030(0x85);
    FUN_00c99030(0x6a);
    FUN_00c99030(0x154);
    FUN_00c99030(0x155);
    FUN_00c99030(0x3e9);
    FUN_00c99030(1);
    FUN_00c99030(9);
    FUN_00c99030(0x401);
    FUN_00c99030(0x151);
    FUN_00c99030(0x158);
    FUN_00c99030(0x159);
    FUN_00c99030(0x3f6);
    FUN_00c99030(0x69);
    FUN_00c99030(0x15a);
    FUN_00c99030(0x15b);
    FUN_00c99030(0x15c);
    FUN_00c99030(0x15d);
    FUN_00c99030(0x406);
    FUN_00c99030(0x7d);
    FUN_00c99030(0x65);
    FUN_00c99030(0x15e);
    FUN_00c99030(0xc0);
    FUN_00c99030(0x15f);
    FUN_00c99030(0x160);
    FUN_00c99030(0x161);
    FUN_00c99030(0x162);
    FUN_00c99030(0x3ea);
    FUN_00c99030(5);
    FUN_00c99030(0x12);
    FUN_00c99030(0xd9);
    FUN_00c99030(0x163);
    FUN_00c99030(0x164);
    FUN_00c99030(0x99);
    FUN_00c99030(0x165);
    FUN_00c99030(0x166);
    FUN_00c99030(0x167);
    FUN_00c99030(0x168);
    FUN_00c99030(0x26);
    FUN_00c99030(0x169);
    FUN_00c99030(0x16a);
    FUN_00c99030(199);
    FUN_00c99030(0xc2);
    FUN_00c99030(0x16b);
    FUN_00c99030(0x16c);
    FUN_00c99030(0x16d);
    FUN_00c99030(0x3eb);
    FUN_00c99230(*(int *)(param_1 + 0x10) - *(int *)(param_1 + 0xc) >> 2);
  }
  return;
}



/* FUNCTION 29870 ; VA 0x00c9a900 ; FUN_00c9a900 */

void __thiscall FUN_00c9a900(int *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810360;
  pvStack_10 = ExceptionList;
  iStack_14 = *param_1;
  uVar1 = *param_2;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01ef3710);
  uStack_8 = 0;
  iVar3 = FUN_00b06640(uVar1);
  iVar4 = FUN_00c155c0();
  if (*(char *)(iVar4 + 0xa8) != '\0') {
    FUN_00ca0e10();
  }
  FUN_0060dcd0(&uStack_20,iVar3);
  piVar6 = piStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  FUN_0089be10(uStack_20,piStack_1c);
  piVar5 = (int *)(iStack_14 + 0x60);
  if (*(int **)(iVar3 + 0xa0) != piVar5) {
    piVar6 = (int *)(iVar3 + 0x9c);
    if (*(int *)(iVar3 + 0xa0) != 0) {
      if (*(int *)(iVar3 + 0xa4) != 0) {
        **(int **)(iVar3 + 0xa4) = *piVar6;
      }
      if (*piVar6 != 0) {
        *(undefined4 *)(*piVar6 + 0xa4) = *(undefined4 *)(iVar3 + 0xa4);
      }
      **(int **)(iVar3 + 0xa0) = **(int **)(iVar3 + 0xa0) + -1;
      *piVar6 = 0;
      *(undefined4 *)(iVar3 + 0xa4) = 0;
      *(undefined4 *)(iVar3 + 0xa0) = 0;
    }
    iVar4 = *(int *)(iStack_14 + 100);
    if (iVar4 != 0) {
      *piVar6 = iVar4;
      *(int **)(iVar4 + 0xa4) = piVar6;
    }
    *(int *)(iStack_14 + 100) = iVar3;
    *(int **)(iVar3 + 0xa4) = (int *)(iStack_14 + 100);
    *(int **)(iVar3 + 0xa0) = piVar5;
    *piVar5 = *piVar5 + 1;
    piVar6 = piStack_1c;
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar3 = piVar6[1] + -1;
    piVar6[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar5 = piVar6 + 2;
      iVar3 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  uStack_8 = 2;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29871 ; VA 0x00c9aa70 ; FUN_00c9aa70 */

undefined * FUN_00c9aa70(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181037c;
  pvStack_10 = ExceptionList;
  if (DAT_01f02064 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f02270) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f02270);
      if (DAT_01f02270 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"PhysicsService",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01897db0);
        FUN_016f37bf(&DAT_01f02270);
      }
    }
    DAT_01f02064 = &DAT_01f02068;
  }
  ExceptionList = pvStack_10;
  return DAT_01f02064;
}



/* FUNCTION 29872 ; VA 0x00c9ab50 ; FUN_00c9ab50 */

void FUN_00c9ab50(void)

{
  int iVar1;
  
  if (DAT_01f02274 == 0) {
    iVar1 = FUN_00c9aa70();
    DAT_01f02274 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29873 ; VA 0x00c9ab70 ; FUN_00c9ab70 */

int FUN_00c9ab70(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  
  iVar1 = FUN_005cb2b0(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = 0;
  *(undefined4 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 8) = *param_3;
  *(undefined4 *)(iVar1 + 0xc) = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  *(undefined4 *)(iVar1 + 0x10) = 0;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(undefined4 *)(iVar1 + 0x10) = param_3[2];
  *(undefined4 *)(iVar1 + 0x14) = param_3[3];
  param_3[2] = 0;
  param_3[3] = 0;
  *(undefined4 *)(iVar1 + 0x18) = param_3[4];
  *(undefined4 *)(iVar1 + 0x1c) = param_3[5];
  return iVar1;
}



/* FUNCTION 29874 ; VA 0x00c9abf0 ; FUN_00c9abf0 */

undefined4 * __thiscall
FUN_00c9abf0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018103db;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00c9aa70();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::PhysicsService,int___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088c8c0();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29875 ; VA 0x00c9ad70 ; FUN_00c9ad70 */

void __fastcall FUN_00c9ad70(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x30);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 29876 ; VA 0x00c9adf0 ; FUN_00c9adf0 */

void __fastcall FUN_00c9adf0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::PhysicsService::vftable;
  param_1[0x16] = RBX::PhysicsService::vftable;
  FUN_016790b0();
  FUN_016790b0();
  iVar2 = param_1[0x48];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  iVar2 = param_1[0x47];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  uVar3 = param_1[0x45];
  if (0xf < uVar3) {
    iVar2 = param_1[0x40];
    uVar5 = uVar3 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar3 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x44] = 0;
  param_1[0x45] = 0xf;
  *(undefined *)(param_1 + 0x40) = 0;
  iVar2 = param_1[0x3e];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  iVar2 = param_1[0x3d];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  iVar2 = param_1[0x3c];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar2 = param_1[0x38];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  FUN_0056b650();
  FUN_008ee200();
  FUN_0056b650();
  FUN_008ee200();
  FUN_008ea430();
  FUN_008ea430();
  iVar2 = param_1[0x19];
  while (iVar2 != 0) {
    iVar4 = *(int *)(iVar2 + 0x9c);
    FUN_00908080(iVar2);
    iVar2 = iVar4;
  }
  FUN_00f45160();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29877 ; VA 0x00c9aff0 ; FUN_00c9aff0 */

undefined4 * __thiscall FUN_00c9aff0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  
  if (param_1 != param_2) {
    FUN_008ee200();
    *param_1 = *param_2;
    param_1[1] = param_2[1];
    param_1[2] = param_2[2];
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
  }
  param_1[3] = param_2[3];
  uVar2 = param_2[4];
  uVar3 = param_2[5];
  param_2[4] = 0;
  param_2[5] = 0;
  param_1[4] = uVar2;
  piVar4 = (int *)param_1[5];
  param_1[5] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  param_2[6] = 0;
  param_2[7] = 0;
  param_1[6] = uVar2;
  piVar4 = (int *)param_1[7];
  param_1[7] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 29878 ; VA 0x00c9b0c0 ; FUN_00c9b0c0 */

undefined4 * __thiscall FUN_00c9b0c0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  iVar3 = param_2[1];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_2[1];
  }
  *param_1 = *param_2;
  piVar2 = (int *)param_1[1];
  param_1[1] = iVar3;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = param_2[3];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_2[3];
  }
  param_1[2] = param_2[2];
  piVar2 = (int *)param_1[3];
  param_1[3] = iVar3;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 29879 ; VA 0x00c9b160 ; FUN_00c9b160 */

int __thiscall FUN_00c9b160(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),1);
  }
  FUN_005c4ac0();
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 29880 ; VA 0x00c9b1b0 ; FUN_00c9b1b0 */

undefined4 __thiscall FUN_00c9b1b0(undefined4 param_1,byte param_2)

{
  FUN_00c9ad70();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 29881 ; VA 0x00c9b1e0 ; FUN_00c9b1e0 */

bool __thiscall FUN_00c9b1e0(undefined4 param_1)

{
  int iVar1;
  char cVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int in_stack_0000001c;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9420;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008f7870(param_1);
  if (iVar4 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid DataModel.");
  }
  iVar4 = FUN_005c3ac0(param_1);
  if (iVar4 != 0) {
    cVar2 = FUN_00bbc0d0(&stack0x00000004);
    iVar4 = in_stack_0000001c;
    if (cVar2 == '\0') {
      FUN_016756b0(auStack_1c,"Collision group does not exist.");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    if (in_stack_0000001c != 0) {
      iVar1 = *(int *)(in_stack_0000001c + 0xc);
      iVar5 = FUN_00aff8c0();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        iVar4 = FUN_00a9d140(iVar4);
        if (iVar4 != 0) {
          FUN_005507b0();
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return false;
        }
        cVar2 = FUN_00bbdba0(&stack0x00000004);
        cVar3 = FUN_00b06fa0();
        FUN_005507b0();
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return cVar3 == cVar2;
      }
    }
    FUN_016756b0(auStack_1c,"Parameter 2 must be BasePart in CollisionGroupContainsPart.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Invalid Workspace.");
}



/* FUNCTION 29882 ; VA 0x00c9b340 ; FUN_00c9b340 */

void __thiscall FUN_00c9b340(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  undefined4 in_stack_00000034;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9440;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid DataModel.");
  }
  iVar2 = FUN_005c3ac0(param_1);
  if (iVar2 != 0) {
    cVar1 = FUN_008ff0a0();
    if (cVar1 == '\0') {
      cVar1 = FUN_008b0260(param_1);
      if (cVar1 != '\0') {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("This API can only be used on the server!");
      }
    }
    cVar1 = FUN_00bbc0d0(&stack0x00000004);
    if (cVar1 != '\0') {
      cVar1 = FUN_00bbc0d0(&stack0x0000001c);
      if (cVar1 != '\0') {
        cVar1 = FUN_00bbc160(&stack0x00000004,&stack0x0000001c,in_stack_00000034);
        if (cVar1 != '\0') {
          FUN_008b8160();
        }
        FUN_005507b0();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
    }
    FUN_016756b0(auStack_1c,"Both collision groups must be valid.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Invalid Workspace.");
}



/* FUNCTION 29883 ; VA 0x00c9b450 ; FUN_00c9b450 */

undefined __fastcall FUN_00c9b450(undefined4 param_1)

{
  char cVar1;
  undefined uVar2;
  int iVar3;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9440;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008f7870(param_1);
  if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid DataModel.");
  }
  iVar3 = FUN_005c3ac0(param_1);
  if (iVar3 != 0) {
    cVar1 = FUN_00bbc0d0(&stack0x00000004);
    if (cVar1 != '\0') {
      cVar1 = FUN_00bbc0d0(&stack0x0000001c);
      if (cVar1 != '\0') {
        uVar2 = FUN_00bbc330(&stack0x00000004,&stack0x0000001c);
        FUN_005507b0();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return uVar2;
      }
    }
    FUN_016756b0(auStack_1c,"Both collision groups must be valid.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Invalid Workspace.");
}



/* FUNCTION 29884 ; VA 0x00c9b530 ; FUN_00c9b530 */

int __fastcall FUN_00c9b530(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c9e8b0(&stack0x00000004);
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid DataModel.");
  }
  iVar2 = FUN_005c3ac0(param_1);
  if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid Workspace.");
  }
  cVar1 = FUN_008ff0a0();
  if (cVar1 == '\0') {
    cVar1 = FUN_008b0260(param_1);
    if (cVar1 != '\0') {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("This API can only be used on the server!");
    }
  }
  if (DAT_01d66528 == '\0') {
    uVar3 = *(uint *)(*(int *)(iVar2 + 0x1b4) + 0x21c);
  }
  else {
    uVar3 = *(uint *)(*(int *)(iVar2 + 0x1b4) + 0x5c4);
  }
  if (uVar3 < 0x20) {
    cVar1 = FUN_00bbc550(&stack0x00000004);
    if (cVar1 != -1) {
      FUN_008b8160();
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return (int)cVar1;
    }
    FUN_016756b0(auStack_1c,"Could not create collision group, one with that name already exists.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  FUN_016756b0(auStack_1c,"Cannot create more than 32 collision groups.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 29885 ; VA 0x00c9b660 ; FUN_00c9b660 */

void __thiscall FUN_00c9b660(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  undefined4 *puStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x48);
  if (puVar2 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_28c = FUN_0088daf0();
    puStack_288 = (undefined4 *)0x0;
    auStack_284[0] = *puVar2;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8bf8)
       && (FUN_016f3809(&DAT_01ea8bf8), DAT_01ea8bf8 == -1)) {
      DAT_01ea8bec = FUN_005c6640;
      DAT_01ea8bf0 = FUN_005c6640;
      DAT_01ea8bf4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8bf8);
    }
    puStack_288 = &DAT_01ea8bec;
    puVar5 = &uStack_28c;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xb, puStack_288 != (undefined4 *)0x0)) {
    (*(code *)puStack_288[2])(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29886 ; VA 0x00c9b9e0 ; FUN_00c9b9e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00c9b9e0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6655;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    puStack_e8 = (undefined *)0x0;
    puStack_18 = &uStack_ec;
    uStack_14 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_006874f0(iVar1);
    uStack_14 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 2;
    if (puStack_e8 != (undefined *)0x0) {
      (**(code **)(puStack_e8 + 8))(&uStack_e4);
    }
  }
  if ((uStack_14 & 1) != 0) {
    uStack_14 = uStack_14 & 0xfffffffe;
    uStack_8 = 3;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    uStack_14 = uStack_14 | 8;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
  }
  else {
    uStack_ec = FUN_00b00260();
    puStack_e8 = (undefined *)0x0;
    uStack_e4 = *puVar4;
    uStack_e0 = puVar4[1];
    uStack_dc = puVar4[2];
    uStack_d8 = puVar4[3];
    uStack_d4 = puVar4[4];
    uStack_d0 = puVar4[5];
    uStack_cc = puVar4[6];
    uStack_c8 = puVar4[7];
    uStack_c4 = puVar4[8];
    uStack_c0 = puVar4[9];
    uStack_bc = puVar4[10];
    uStack_b8 = puVar4[0xb];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3d8)
       && (FUN_016f3809(&DAT_01ead3d8), DAT_01ead3d8 == -1)) {
      _DAT_01ead3cc = FUN_00619ef0;
      _DAT_01ead3d0 = FUN_00619ef0;
      DAT_01ead3d4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3d8);
    }
    puStack_e8 = &DAT_01ead3cc;
    uStack_14 = uStack_14 | 4;
    puVar4 = &uStack_ec;
    uStack_8 = 4;
  }
  uVar2 = FUN_00b00260();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 8) != 0) {
    uStack_14 = uStack_14 & 0xfffffff7;
    uStack_8 = 6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uStack_14 & 4) != 0) {
    uStack_14 = uStack_14 & 0xfffffffb;
    uStack_8 = 7;
    if (puStack_e8 != (undefined *)0x0) {
      (**(code **)(puStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    uStack_14 = uStack_14 | 0x20;
    param_2 = &uStack_1bc;
    uStack_8 = 9;
  }
  else {
    param_2 = (undefined4 *)FUN_006ea440(*(int *)(param_1 + 0x48));
    uStack_14 = uStack_14 | 0x10;
    uStack_8 = 8;
  }
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uStack_14 & 0x20) != 0) {
    uStack_14 = uStack_14 & 0xffffffdf;
    uStack_8 = 10;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uStack_14 & 0x10) != 0) {
    uStack_14 = uStack_14 & 0xffffffef;
    uStack_8 = 0xb;
    if (puStack_e8 != (undefined *)0x0) {
      (**(code **)(puStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    uStack_14 = uStack_14 | 0x80;
    puVar4 = &uStack_28c;
    uStack_8 = 0xd;
  }
  else {
    puVar4 = (undefined4 *)FUN_006ea440(*(int *)(param_1 + 0x4c));
    uStack_14 = uStack_14 | 0x40;
    uStack_8 = 0xc;
  }
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uStack_14 < '\0') {
    uStack_14 = uStack_14 & 0xffffff7f;
    uStack_8 = 0xe;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uStack_14 & 0x40) != 0) && (uStack_8 = 0xf, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29887 ; VA 0x00c9be10 ; FUN_00c9be10 */

void __thiscall FUN_00c9be10(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_006874f0(iVar1);
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar5 = &uStack_28c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(auStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29888 ; VA 0x00c9c010 ; FUN_00c9c010 */

void __thiscall FUN_00c9c010(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088cb40();
    iStack_1b8 = 0;
    FUN_0054ef60(iVar1);
    iStack_1b8 = FUN_005c9d30();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29889 ; VA 0x00c9c240 ; FUN_00c9c240 */

void __thiscall FUN_00c9c240(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8320;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_006874f0(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29890 ; VA 0x00c9c440 ; FUN_00c9c440 */

void FUN_00c9c440(void)

{
  FUN_00c9a900(&stack0x00000008);
  return;
}



/* FUNCTION 29891 ; VA 0x00c9c460 ; FUN_00c9c460 */

void FUN_00c9c460(undefined4 param_1,undefined4 param_2)

{
  FUN_00c9e160(param_2);
  return;
}



/* FUNCTION 29892 ; VA 0x00c9c480 ; FUN_00c9c480 */

int FUN_00c9c480(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar2 = *(int *)(param_1 + 0x18);
  uStack_8 = 1;
  iVar3 = FUN_00971ce0(iVar2,1);
  if ((char)iVar3 != '\0') {
    iVar3 = FUN_0097fff0(iVar2);
    *(int *)(iVar2 + 0xe8) = iVar3;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29893 ; VA 0x00c9c540 ; FUN_00c9c540 */

int FUN_00c9c540(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_00b06640(param_2);
  FUN_00908080(uVar4);
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_18,uVar4);
  uStack_8 = 0;
  uVar4 = *puVar5;
  uVar3 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  iVar6 = FUN_0089be10(uVar4,uVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 29894 ; VA 0x00c9c600 ; FUN_00c9c600 */

void FUN_00c9c600(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  
  iVar1 = *(int *)(param_1 + 0x18);
  cVar2 = FUN_00971ce0(iVar1,1);
  if ((cVar2 != '\0') && ((param_2 == 0 || (param_2 == 1)))) {
    uVar3 = FUN_0097fff0(iVar1);
    *(undefined4 *)(iVar1 + 0xe8) = uVar3;
  }
  return;
}



/* FUNCTION 29895 ; VA 0x00c9c640 ; FUN_00c9c640 */

undefined4 FUN_00c9c640(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  int iStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  undefined4 uStack_78;
  int iStack_74;
  int iStack_70;
  undefined4 uStack_6c;
  int aiStack_60 [5];
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined *puStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_01810688;
  pvStack_1c = ExceptionList;
  uStack_6c = param_2;
  iStack_70 = 0xc9c67c;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300();
  iStack_70 = (int)pcStack_28 + 0x48;
  iVar2 = iVar2 - param_3;
  uStack_78 = 3;
  iStack_7c = param_3;
  uStack_80 = param_2;
  iStack_84 = 0xc9c696;
  iStack_74 = iVar2;
  uVar1 = FUN_009d1aa0();
  puStack_2c = (undefined *)CONCAT31(puStack_2c._1_3_,uVar1);
  iStack_84 = (int)pcStack_28 + 0x44;
  uStack_30 = FUN_009d09d0(aiStack_60,param_2,param_3,2,iVar2);
  uStack_14 = 0;
  uVar3 = FUN_009d09d0(auStack_48,param_2,param_3,1,iVar2,(int)pcStack_28 + 0x40);
  uStack_6c = puStack_2c;
  puStack_2c = (undefined *)&iStack_84;
  uStack_14._0_1_ = 1;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  FUN_0054ef60(uStack_30);
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar3);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  (*pcStack_28)();
  if (0xf < uStack_34) {
    uVar4 = uStack_34 + 1;
    uVar5 = auStack_48[0];
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(auStack_48[0] - 4);
      uVar4 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (0xf < uStack_4c) {
    uVar5 = uStack_4c + 1;
    iVar2 = aiStack_60[0];
    if (0xfff < uVar5) {
      iVar2 = *(int *)(aiStack_60[0] + -4);
      uVar5 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar5);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 29896 ; VA 0x00c9c7b0 ; FUN_00c9c7b0 */

undefined4 FUN_00c9c7b0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  float10 fVar6;
  float10 fVar7;
  undefined4 uStack_12c;
  int iStack_128;
  undefined auStack_124 [200];
  undefined auStack_5c [12];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  float fStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018106b3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01256300(param_2);
  iVar4 = iVar4 - param_3;
  fVar6 = (float10)FUN_009d0730(param_2,param_3,4,iVar4,iStack_14 + 0x4c);
  fVar7 = (float10)FUN_009d0730(param_2,param_3,3,iVar4,iStack_14 + 0x48);
  fStack_18 = (float)fVar7;
  if (iVar4 < 2) {
LAB_00c9c8f5:
    puVar5 = *(undefined4 **)(iStack_14 + 0x44);
    if (puVar5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_5c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_5c,&DAT_01c17198);
    }
  }
  else {
    FUN_0060efa0();
    puVar5 = (undefined4 *)FUN_01257810(param_2,param_3 + 2,DAT_01ede6d4);
    if (puVar5 == (undefined4 *)0x0) {
      if (1 < iVar4) {
        uStack_12c = FUN_00888530();
        iStack_128 = 0;
        uStack_8 = 0;
        cVar3 = FUN_009d1bf0(param_2,param_3 + 2,&uStack_12c,1);
        if (cVar3 != '\0') {
          puVar5 = (undefined4 *)FUN_0088ab30();
          uStack_50 = *puVar5;
          uStack_4c = puVar5[1];
          uStack_48 = puVar5[2];
          uStack_44 = puVar5[3];
          uStack_40 = puVar5[4];
          uStack_3c = puVar5[5];
          uStack_38 = puVar5[6];
          uStack_34 = puVar5[7];
          uStack_30 = puVar5[8];
          uStack_2c = puVar5[9];
          uStack_28 = puVar5[10];
          uStack_24 = puVar5[0xb];
          uStack_8 = 1;
          if (iStack_128 != 0) {
            (**(code **)(iStack_128 + 8))(auStack_124);
          }
          uStack_8 = 0xffffffff;
          goto LAB_00c9c91a;
        }
        uStack_8 = 2;
        if (iStack_128 != 0) {
          (**(code **)(iStack_128 + 8))(auStack_124);
        }
        uStack_8 = 0xffffffff;
      }
      goto LAB_00c9c8f5;
    }
  }
  uStack_50 = *puVar5;
  uStack_4c = puVar5[1];
  uStack_48 = puVar5[2];
  uStack_44 = puVar5[3];
  uStack_40 = puVar5[4];
  uStack_3c = puVar5[5];
  uStack_38 = puVar5[6];
  uStack_34 = puVar5[7];
  uStack_30 = puVar5[8];
  uStack_2c = puVar5[9];
  uStack_28 = puVar5[10];
  uStack_24 = puVar5[0xb];
LAB_00c9c91a:
  puVar5 = (undefined4 *)FUN_009d1340(auStack_20,param_2,param_3,1,iVar4,iStack_14 + 0x40);
  uStack_8 = 3;
  pcVar2 = *(code **)(iStack_14 + 0x38);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(*puVar5,puVar5[1],&uStack_50,fStack_18,(float)fVar6);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 29897 ; VA 0x00c9c9f0 ; FUN_00c9c9f0 */

undefined4 FUN_00c9c9f0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uStack_80;
  int iStack_7c;
  undefined4 uStack_78;
  int iStack_74;
  int iStack_70;
  undefined4 uStack_6c;
  int aiStack_60 [5];
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined *puStack_30;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017c86a8;
  pvStack_1c = ExceptionList;
  uStack_6c = param_2;
  iStack_70 = 0xc9ca2c;
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_01256300();
  iStack_70 = (int)pcStack_28 + 0x44;
  uStack_78 = 2;
  iStack_7c = param_3;
  uStack_80 = param_2;
  iStack_74 = iVar1 - param_3;
  uStack_2c = FUN_009d09d0(aiStack_60);
  uStack_14 = 0;
  uVar2 = FUN_009d09d0(auStack_48,param_2,param_3,1,iVar1 - param_3,(int)pcStack_28 + 0x40);
  puStack_30 = (undefined *)&uStack_80;
  uStack_14._0_1_ = 1;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  FUN_0054ef60(uStack_2c);
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar2);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  uVar2 = (*pcStack_28)();
  uVar2 = FUN_009d5ac0(param_2,uVar2);
  if (0xf < uStack_34) {
    uVar3 = uStack_34 + 1;
    uVar4 = auStack_48[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_48[0] - 4);
      uVar3 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (0xf < uStack_4c) {
    uVar4 = uStack_4c + 1;
    iVar1 = aiStack_60[0];
    if (0xfff < uVar4) {
      iVar1 = *(int *)(aiStack_60[0] + -4);
      uVar4 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar4);
  }
  ExceptionList = pvStack_1c;
  return uVar2;
}



/* FUNCTION 29898 ; VA 0x00c9cb50 ; FUN_00c9cb50 */

undefined4 FUN_00c9cb50(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  int iStack_68;
  int iStack_64;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined *puStack_34;
  code *pcStack_30;
  int *piStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_018106d8;
  pvStack_1c = ExceptionList;
  iStack_64 = param_2;
  iStack_68 = 0xc9cb8c;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300();
  iStack_68 = iStack_24 + 0x44;
  piStack_28 = (int *)FUN_009d1340(auStack_3c,param_2,param_3,2,iVar2 - param_3);
  uStack_14 = 0;
  uVar3 = FUN_009d09d0(auStack_54,param_2,param_3,1,iVar2 - param_3,iStack_24 + 0x40);
  puStack_34 = (undefined *)&iStack_68;
  pcStack_30 = *(code **)(iStack_24 + 0x38);
  iStack_24 = *(int *)(iStack_24 + 0x3c) + param_1;
  if (piStack_28[1] != 0) {
    LOCK();
    piVar1 = (int *)(piStack_28[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_68 = *piStack_28;
  iStack_64 = piStack_28[1];
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar3);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  uVar3 = (*pcStack_30)();
  pcStack_30 = (code *)FUN_009d5ac0(param_2,uVar3);
  if (0xf < uStack_40) {
    uVar5 = uStack_40 + 1;
    uVar4 = auStack_54[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_54[0] - 4);
      uVar5 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[1] + -1;
    piStack_38[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar1 = piStack_38 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return pcStack_30;
}



/* FUNCTION 29899 ; VA 0x00c9ccc0 ; FUN_00c9ccc0 */

int __thiscall FUN_00c9ccc0(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid DataModel.");
  }
  iVar2 = FUN_005c3ac0(param_1);
  if (iVar2 != 0) {
    cVar1 = FUN_00bbc0d0(&param_2);
    if (cVar1 == '\0') {
      FUN_016756b0(auStack_1c,"Collision group not found.");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    cVar1 = FUN_00bbdba0(&param_2);
    if (0xf < in_stack_00000018) {
      uVar3 = in_stack_00000018 + 1;
      iVar2 = param_2;
      if (0xfff < uVar3) {
        iVar2 = *(int *)(param_2 + -4);
        uVar3 = in_stack_00000018 + 0x24;
        if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return (int)cVar1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Invalid Workspace.");
}



/* FUNCTION 29900 ; VA 0x00c9cda0 ; FUN_00c9cda0 */

undefined4 __thiscall FUN_00c9cda0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined auStack_10 [12];
  
  if ((param_3 < 0) || (0x1f < param_3)) {
    FUN_016756b0(auStack_10,"The Collision group Id must be between 0 and %d",0x20);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  iVar1 = FUN_008f7870(param_1);
  if (iVar1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid DataModel.");
  }
  iVar1 = FUN_005c3ac0(param_1);
  if (iVar1 != 0) {
    FUN_00bbda40(param_2,param_3);
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Invalid Workspace.");
}



/* FUNCTION 29901 ; VA 0x00c9ce20 ; FUN_00c9ce20 */

void __thiscall FUN_00c9ce20(undefined4 *param_1,int *param_2)

{
  undefined4 ***pppuVar1;
  undefined4 ***pppuVar2;
  undefined uVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined4 *****pppppuVar9;
  undefined4 ***pppuVar10;
  uint uVar11;
  uint uVar12;
  undefined4 ****ppppuVar13;
  undefined4 *puVar14;
  uint *puVar15;
  undefined4 uStack_154;
  undefined4 *puStack_150;
  int *piStack_14c;
  int *piStack_148;
  int *piStack_84;
  int *piStack_80;
  int *piStack_7c;
  int *piStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  undefined4 *puStack_6c;
  int iStack_68;
  uint auStack_64 [4];
  int iStack_54;
  uint uStack_50;
  undefined4 ****ppppuStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  undefined4 ***pppuStack_3c;
  undefined4 ***pppuStack_38;
  undefined4 uStack_34;
  undefined4 ***pppuStack_30;
  undefined4 uStack_2c;
  undefined4 ***pppuStack_28;
  undefined4 ***pppuStack_24;
  undefined4 *puStack_20;
  undefined4 ****ppppuStack_1c;
  undefined4 ***pppuStack_18;
  undefined4 ****ppppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181076e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_74 = (undefined4 *)FUN_01674e20(0x18);
  if (puStack_74 == (undefined4 *)0x0) {
    puStack_74 = (undefined4 *)0x0;
  }
  else {
    puStack_74[1] = 1;
    puStack_74[2] = 1;
    *puStack_74 = std::
                  _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                  ::vftable;
    puStack_74[3] = 0;
    puStack_74[4] = 0;
    puStack_74[5] = 0;
  }
  puVar14 = puStack_74 + 3;
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  puStack_70 = puVar14;
  if (param_1 != (undefined4 *)0x0) {
    puStack_20 = (undefined4 *)param_1[0xd];
    puStack_6c = puStack_74;
    puVar4 = param_1;
    if ((puStack_20 != (undefined4 *)0x0) && (puVar4 = puStack_20, puStack_20[0xd] != 0)) {
      puVar4 = (undefined4 *)FUN_005c8ac0();
    }
    puStack_20 = puVar4;
    if (((puStack_20 != (undefined4 *)0x0) &&
        (iVar6 = puStack_20[3], iVar5 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da))) && (iStack_68 = FUN_00562f00(), iStack_68 != 0)) {
      if (DAT_01d66528 == '\0') {
        iVar6 = *(int *)(iStack_68 + 0x1b4);
        uVar3 = (undefined)uStack_8;
        if (*(int *)(iVar6 + 0x21c) == 0) {
          puVar14 = (undefined4 *)0x0;
        }
        else {
          puVar14 = *(undefined4 **)(*(int *)(iVar6 + 0x228) + *(int *)(iVar6 + 0x218) * 4);
        }
        while (uStack_8._0_1_ = uVar3, puVar14 != (undefined4 *)0x0) {
          piVar8 = puVar14 + 2;
          pppuStack_28 = (undefined4 ***)puVar14[6];
          if (0xf < (uint)puVar14[7]) {
            piVar8 = (int *)*piVar8;
          }
          if (&DAT_0000000f < pppuStack_28) {
            pppuStack_24 = (undefined4 ***)((uint)pppuStack_28 | 0xf);
            if ((undefined4 ****)0x7fffffff < pppuStack_24) {
              pppuStack_24 = (undefined4 ****)0x7fffffff;
            }
            ppppuStack_4c = (undefined4 ****)FUN_00554060((undefined *)((int)pppuStack_24 + 1));
            ppppuStack_1c = ppppuStack_4c;
            FUN_0170c6f0(ppppuStack_4c,piVar8,(undefined *)((int)pppuStack_28 + 1));
            pppuStack_18 = pppuStack_24;
          }
          else {
            ppppuStack_4c = (undefined4 ****)*piVar8;
            iStack_48 = piVar8[1];
            iStack_44 = piVar8[2];
            iStack_40 = piVar8[3];
            pppuStack_18 = (undefined4 ***)&DAT_0000000f;
            ppppuStack_1c = ppppuStack_4c;
          }
          ppppuStack_14 = (undefined4 ****)(int)*(char *)(puVar14 + 8);
          uStack_8 = CONCAT31(uStack_8._1_3_,9);
          pppuStack_3c = pppuStack_28;
          pppuStack_38 = pppuStack_18;
          pppuStack_24 = pppuStack_18;
          piVar8 = (int *)FUN_01674e20(0x24);
          pppuStack_30 = (undefined4 ***)piVar8;
          if (piVar8 == (int *)0x0) {
            piVar8 = (int *)0x0;
          }
          else {
            piVar8[1] = 1;
            piVar8[2] = 1;
            *piVar8 = (int)std::
                           _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                           ::vftable;
            *(undefined *)(piVar8 + 3) = 0;
            iVar6 = FUN_00588320(0xb);
            piVar8[4] = iVar6;
            piVar8[5] = 0;
            piVar8[6] = 0x3f800000;
            piVar8[7] = 0;
            piVar8[8] = 0;
          }
          piStack_84 = piVar8 + 3;
          uStack_8._0_1_ = 10;
          iStack_54 = 0;
          uStack_50 = 0xf;
          auStack_64[0] = auStack_64[0] & 0xffffff00;
          piStack_80 = piVar8;
          FUN_005542c0(&DAT_018c387c,4);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
          iVar6 = FUN_005c4c00(auStack_64);
          puStack_20 = (undefined4 *)(iVar6 + 0x18);
          uVar7 = FUN_0088cb40();
          *puStack_20 = uVar7;
          pppuStack_30 = (undefined4 ***)FUN_005c9d30();
          ppppuVar13 = (undefined4 ****)puStack_20[1];
          if (ppppuVar13 == (undefined4 ****)pppuStack_30) {
            if ((undefined4 *****)(puStack_20 + 2) != &ppppuStack_4c) {
              pppppuVar9 = &ppppuStack_4c;
              if (&DAT_0000000f < pppuStack_18) {
                pppppuVar9 = (undefined4 *****)ppppuStack_1c;
              }
              FUN_005542c0(pppppuVar9,pppuStack_28);
              goto LAB_00c9d41e;
            }
          }
          else {
            if (ppppuVar13 != (undefined4 ****)0x0) {
              pppuStack_18 = (undefined4 ***)(puStack_20 + 2);
              (*(code *)ppppuVar13[2])(puStack_20 + 2);
              puStack_20[1] = 0;
            }
            FUN_0054ef60(&ppppuStack_4c);
            puStack_20[1] = pppuStack_30;
LAB_00c9d41e:
            pppuStack_24 = pppuStack_38;
            ppppuStack_1c = ppppuStack_4c;
          }
          uStack_8._0_1_ = 10;
          if (0xf < uStack_50) {
            uVar12 = uStack_50 + 1;
            uVar11 = auStack_64[0];
            if (0xfff < uVar12) {
              uVar11 = *(uint *)(auStack_64[0] - 4);
              uVar12 = uStack_50 + 0x24;
              uVar3 = (undefined)uStack_8;
              if (0x1f < (auStack_64[0] - uVar11) - 4) {
LAB_00c9d725:
                uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar11,uVar12);
          }
          iStack_54 = 0;
          uStack_50 = 0xf;
          auStack_64[0] = auStack_64[0] & 0xffffff00;
          FUN_005542c0(&DAT_018c1fd8,2);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
          iVar6 = FUN_005c4c00(auStack_64);
          pppuStack_28 = (undefined4 ***)(iVar6 + 0x18);
          pppuVar10 = (undefined4 ***)FUN_0088c8c0();
          *pppuStack_28 = pppuVar10;
          pppuStack_30 = (undefined4 ***)FUN_005c9cc0();
          ppppuVar13 = (undefined4 ****)pppuStack_28[1];
          if (ppppuVar13 == (undefined4 ****)pppuStack_30) {
            pppuStack_28[2] = ppppuStack_14;
          }
          else {
            if (ppppuVar13 != (undefined4 ****)0x0) {
              (*(code *)ppppuVar13[2])(pppuStack_28 + 2);
            }
            pppuStack_28[2] = ppppuStack_14;
            pppuStack_28[1] = pppuStack_30;
          }
          uStack_8._0_1_ = 10;
          if (0xf < uStack_50) {
            uVar12 = uStack_50 + 1;
            uVar11 = auStack_64[0];
            if (0xfff < uVar12) {
              uVar11 = *(uint *)(auStack_64[0] - 4);
              uVar12 = uStack_50 + 0x24;
              uVar3 = (undefined)uStack_8;
              if (0x1f < (auStack_64[0] - uVar11) - 4) goto LAB_00c9d725;
            }
            FUN_01674ea0(uVar11,uVar12);
          }
          pppuStack_18 = (undefined4 ***)FUN_00bbd8a0(ppppuStack_14);
          iStack_54 = 0;
          uStack_50 = 0xf;
          auStack_64[0] = auStack_64[0] & 0xffffff00;
          FUN_005542c0(&DAT_0195e5bc,4);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
          iVar6 = FUN_005c4c00(auStack_64);
          ppppuStack_14 = (undefined4 ****)(iVar6 + 0x18);
          ppppuVar13 = (undefined4 ****)FUN_0088c8c0();
          *ppppuStack_14 = ppppuVar13;
          pppuStack_30 = (undefined4 ***)FUN_005c9cc0();
          ppppuVar13 = (undefined4 ****)ppppuStack_14[1];
          if (ppppuVar13 == (undefined4 ****)pppuStack_30) {
            ppppuStack_14[2] = pppuStack_18;
          }
          else {
            if (ppppuVar13 != (undefined4 ****)0x0) {
              (*(code *)ppppuVar13[2])(ppppuStack_14 + 2);
            }
            ppppuStack_14[2] = pppuStack_18;
            ppppuStack_14[1] = pppuStack_30;
          }
          uStack_8._0_1_ = 10;
          if (0xf < uStack_50) {
            uVar12 = uStack_50 + 1;
            uVar11 = auStack_64[0];
            if (0xfff < uVar12) {
              uVar11 = *(uint *)(auStack_64[0] - 4);
              uVar12 = uStack_50 + 0x24;
              uVar3 = (undefined)uStack_8;
              if (0x1f < (auStack_64[0] - uVar11) - 4) goto LAB_00c9d725;
            }
            FUN_01674ea0(uVar11,uVar12);
          }
          if (piVar8 != (int *)0x0) {
            LOCK();
            piVar8[1] = piVar8[1] + 1;
            UNLOCK();
          }
          piStack_7c = piVar8 + 3;
          uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
          piStack_78 = piVar8;
          uStack_154 = FUN_008881d0();
          piStack_14c = piVar8 + 3;
          puStack_150 = (undefined4 *)0x0;
          piStack_7c = (int *)0x0;
          piStack_78 = (int *)0x0;
          piStack_148 = piVar8;
          if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
               DAT_01ea8a9c) && (FUN_016f3809(&DAT_01ea8a9c), DAT_01ea8a9c == -1)) {
            DAT_01ea8a90 = FUN_0057bbb0;
            DAT_01ea8a94 = FUN_005880a0;
            DAT_01ea8a98 = FUN_0057d5e0;
            FUN_016f37bf(&DAT_01ea8a9c);
          }
          puStack_150 = &DAT_01ea8a90;
          uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
          if (puStack_70[2] == puStack_70[1]) {
            FUN_005ca4f0(puStack_70[1],&uStack_154);
          }
          else {
            FUN_005caaf0(puStack_70);
            puStack_70[1] = puStack_70[1] + 0xd0;
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
          if (puStack_150 != (undefined4 *)0x0) {
            (*(code *)puStack_150[2])(&piStack_14c);
          }
          puVar14 = (undefined4 *)*puVar14;
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar6 = piVar8[1] + -1;
            piVar8[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piVar8)();
              LOCK();
              iVar6 = piVar8[2] + -1;
              piVar8[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          uStack_8._0_1_ = 0;
          uVar3 = (undefined)uStack_8;
          uStack_8._0_1_ = 0;
          if (&DAT_0000000f < pppuStack_24) {
            ppppuVar13 = (undefined4 ****)((int)pppuStack_24 + 1);
            pppppuVar9 = (undefined4 *****)ppppuStack_1c;
            if ((undefined4 ****)0xfff < ppppuVar13) {
              pppppuVar9 = (undefined4 *****)ppppuStack_1c[-1];
              ppppuVar13 = (undefined4 ****)(pppuStack_24 + 9);
              uVar3 = (undefined)uStack_8;
              if (0x1f < (uint)((int)ppppuStack_1c + (-4 - (int)pppppuVar9))) goto LAB_00c9d725;
            }
            FUN_01674ea0(pppppuVar9,ppppuVar13);
            uVar3 = (undefined)uStack_8;
          }
        }
      }
      else {
        ppppuStack_1c = (undefined4 *****)0x0;
        do {
          ppppuStack_14 = ppppuStack_1c;
          FUN_00bbda40(auStack_64,ppppuStack_1c);
          uStack_8._0_1_ = 1;
          if (iStack_54 == 0) {
            uStack_8._0_1_ = 0;
            uVar3 = (undefined)uStack_8;
            uStack_8._0_1_ = 0;
            if (0xf < uStack_50) {
              uVar12 = uStack_50 + 1;
              uVar11 = auStack_64[0];
              if (0xfff < uVar12) {
                uVar11 = *(uint *)(auStack_64[0] - 4);
                uVar12 = uStack_50 + 0x24;
                if (0x1f < (auStack_64[0] - uVar11) - 4) goto LAB_00c9d725;
              }
              FUN_01674ea0(uVar11,uVar12);
              uVar3 = (undefined)uStack_8;
            }
          }
          else {
            FUN_00888650(&uStack_34);
            uStack_8._0_1_ = 2;
            pppuStack_3c = (undefined4 ****)0x0;
            pppuStack_38 = (undefined4 ***)&DAT_0000000f;
            ppppuStack_4c = (undefined4 ****)((uint)ppppuStack_4c & 0xffffff00);
            FUN_005542c0(&DAT_018c387c,4);
            puVar15 = auStack_64;
            uStack_8._0_1_ = 3;
            FUN_005c4c00(&ppppuStack_4c);
            FUN_005c16d0(puVar15);
            uStack_8._0_1_ = 2;
            if (&DAT_0000000f < pppuStack_38) {
              ppppuVar13 = (undefined4 ****)((int)pppuStack_38 + 1);
              pppppuVar9 = (undefined4 *****)ppppuStack_4c;
              if ((undefined4 ****)0xfff < ppppuVar13) {
                pppppuVar9 = (undefined4 *****)ppppuStack_4c[-1];
                ppppuVar13 = (undefined4 ****)(pppuStack_38 + 9);
                uVar3 = (undefined)uStack_8;
                if (0x1f < (uint)((int)ppppuStack_4c + (-4 - (int)pppppuVar9))) goto LAB_00c9d725;
              }
              FUN_01674ea0(pppppuVar9,ppppuVar13);
            }
            pppuStack_3c = (undefined4 ****)0x0;
            pppuStack_38 = (undefined4 ***)&DAT_0000000f;
            ppppuStack_4c = (undefined4 ****)((uint)ppppuStack_4c & 0xffffff00);
            FUN_005542c0(&DAT_018c1fd8,2);
            uStack_8 = CONCAT31(uStack_8._1_3_,4);
            iVar6 = FUN_005c4c00(&ppppuStack_4c);
            uVar7 = FUN_0088c8c0();
            *(undefined4 *)(iVar6 + 0x18) = uVar7;
            pppuStack_18 = (undefined4 ***)FUN_005c9cc0();
            ppppuVar13 = *(undefined4 *****)(iVar6 + 0x1c);
            if (ppppuVar13 == (undefined4 ****)pppuStack_18) {
              *(undefined4 *****)(iVar6 + 0x20) = ppppuStack_1c;
            }
            else {
              if (ppppuVar13 != (undefined4 ****)0x0) {
                (*(code *)ppppuVar13[2])(iVar6 + 0x20);
              }
              *(undefined4 *****)(iVar6 + 0x20) = ppppuStack_1c;
              *(undefined4 ****)(iVar6 + 0x1c) = pppuStack_18;
            }
            uStack_8._0_1_ = 2;
            if (&DAT_0000000f < pppuStack_38) {
              ppppuVar13 = (undefined4 ****)((int)pppuStack_38 + 1);
              pppppuVar9 = (undefined4 *****)ppppuStack_4c;
              if ((undefined4 ****)0xfff < ppppuVar13) {
                pppppuVar9 = (undefined4 *****)ppppuStack_4c[-1];
                ppppuVar13 = (undefined4 ****)(pppuStack_38 + 9);
                uVar3 = (undefined)uStack_8;
                if (0x1f < (uint)((int)ppppuStack_4c + (-4 - (int)pppppuVar9))) goto LAB_00c9d725;
              }
              FUN_01674ea0(pppppuVar9,ppppuVar13);
            }
            ppppuStack_14 = (undefined4 ****)FUN_00bbd8a0(ppppuStack_14);
            pppuStack_3c = (undefined4 ****)0x0;
            pppuStack_38 = (undefined4 ***)&DAT_0000000f;
            ppppuStack_4c = (undefined4 ****)((uint)ppppuStack_4c & 0xffffff00);
            FUN_005542c0(&DAT_0195e5bc,4);
            uStack_8 = CONCAT31(uStack_8._1_3_,5);
            iVar6 = FUN_005c4c00(&ppppuStack_4c);
            uVar7 = FUN_0088c8c0();
            *(undefined4 *)(iVar6 + 0x18) = uVar7;
            pppuStack_18 = (undefined4 ***)FUN_005c9cc0();
            ppppuVar13 = *(undefined4 *****)(iVar6 + 0x1c);
            if (ppppuVar13 == (undefined4 ****)pppuStack_18) {
              *(undefined4 *****)(iVar6 + 0x20) = ppppuStack_14;
            }
            else {
              if (ppppuVar13 != (undefined4 ****)0x0) {
                (*(code *)ppppuVar13[2])(iVar6 + 0x20);
              }
              *(undefined4 *****)(iVar6 + 0x20) = ppppuStack_14;
              *(undefined4 ****)(iVar6 + 0x1c) = pppuStack_18;
            }
            uStack_8._0_1_ = 2;
            if (&DAT_0000000f < pppuStack_38) {
              ppppuVar13 = (undefined4 ****)((int)pppuStack_38 + 1);
              pppppuVar9 = (undefined4 *****)ppppuStack_4c;
              if ((undefined4 ****)0xfff < ppppuVar13) {
                pppppuVar9 = (undefined4 *****)ppppuStack_4c[-1];
                ppppuVar13 = (undefined4 ****)(pppuStack_38 + 9);
                uVar3 = (undefined)uStack_8;
                if (0x1f < (uint)((int)ppppuStack_4c + (-4 - (int)pppppuVar9))) goto LAB_00c9d725;
              }
              FUN_01674ea0(pppppuVar9,ppppuVar13);
            }
            pppuVar10 = pppuStack_30;
            if ((undefined4 ****)pppuStack_30 != (undefined4 ****)0x0) {
              LOCK();
              pppuStack_30[1] = (undefined4 ***)((int)pppuStack_30[1] + 1);
              UNLOCK();
            }
            uStack_2c = uStack_34;
            pppuStack_28 = pppuStack_30;
            uStack_8._0_1_ = 6;
            FUN_005c15a0(&uStack_2c);
            uStack_8 = CONCAT31(uStack_8._1_3_,7);
            if (puVar14[2] == puVar14[1]) {
              FUN_005ca4f0(puVar14[1],&uStack_154);
            }
            else {
              FUN_005caaf0(puVar14);
              puVar14[1] = puVar14[1] + 0xd0;
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,8);
            if (puStack_150 != (undefined4 *)0x0) {
              (*(code *)puStack_150[2])(&piStack_14c);
            }
            pppuVar2 = pppuStack_28;
            if ((undefined4 ****)pppuStack_28 != (undefined4 ****)0x0) {
              LOCK();
              pppuVar1 = (undefined4 ***)((int)pppuStack_28[1] + -1);
              pppuStack_28[1] = pppuVar1;
              UNLOCK();
              if (pppuVar1 == (undefined4 ***)0x0) {
                (*(code *)**pppuStack_28)();
                LOCK();
                ppppuVar13 = (undefined4 ****)(pppuVar2 + 2);
                pppuVar1 = (undefined4 ***)((int)*ppppuVar13 + -1);
                *ppppuVar13 = pppuVar1;
                UNLOCK();
                if (pppuVar1 == (undefined4 ***)0x0) {
                  (*(code *)(*pppuVar2)[1])();
                }
              }
            }
            if ((undefined4 ****)pppuVar10 != (undefined4 ****)0x0) {
              LOCK();
              pppuVar2 = (undefined4 ***)((int)pppuVar10[1] + -1);
              pppuVar10[1] = pppuVar2;
              UNLOCK();
              if (pppuVar2 == (undefined4 ***)0x0) {
                (*(code *)**pppuVar10)();
                LOCK();
                pppuVar2 = (undefined4 ***)((int)pppuVar10[2] + -1);
                pppuVar10[2] = pppuVar2;
                UNLOCK();
                if (pppuVar2 == (undefined4 ***)0x0) {
                  (*(code *)(*pppuVar10)[1])();
                }
              }
            }
            uStack_8._0_1_ = 0;
            puVar14 = puStack_70;
            uVar3 = (undefined)uStack_8;
            if (0xf < uStack_50) {
              uVar12 = uStack_50 + 1;
              uVar11 = auStack_64[0];
              if (0xfff < uVar12) {
                uVar11 = *(uint *)(auStack_64[0] - 4);
                uVar12 = uStack_50 + 0x24;
                if (0x1f < (auStack_64[0] - uVar11) - 4) goto LAB_00c9d725;
              }
              FUN_01674ea0(uVar11,uVar12);
              puVar14 = puStack_70;
              uVar3 = (undefined)uStack_8;
            }
          }
          uStack_8._0_1_ = uVar3;
          ppppuStack_1c = (undefined4 ****)((int)ppppuStack_1c + 1);
        } while ((int)ppppuStack_1c < 0x20);
      }
    }
  }
  *param_2 = (int)puStack_70;
  param_2[1] = (int)puStack_74;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29902 ; VA 0x00c9d780 ; FUN_00c9d780 */

uint __thiscall FUN_00c9d780(int param_1,undefined4 param_2)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint *puVar5;
  int iVar6;
  uint uVar7;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810788;
  pvStack_10 = ExceptionList;
  uVar7 = 0;
  piVar3 = *(int **)(param_1 + 0x98);
  iVar6 = *(int *)(param_1 + 0x9c) - (int)piVar3;
  uVar2 = iVar6 * 0x2aaaaaab;
  uStack_14 = iVar6 / 0x18;
  ExceptionList = &pvStack_10;
  if (uStack_14 != 0) {
    do {
      ExceptionList = &pvStack_10;
      if ((*piVar3 != *(int *)(param_1 + 0xa8)) ||
         (uVar2 = piVar3[2], ExceptionList = &pvStack_10, uVar2 != *(uint *)(param_1 + 0xb0)))
      break;
      uVar7 = uVar7 + 1;
      piVar3 = piVar3 + 6;
      ExceptionList = &pvStack_10;
    } while (uVar7 < uStack_14);
  }
  do {
    if (uVar7 == uStack_14) {
      ExceptionList = pvStack_10;
      return uVar2;
    }
    iStack_18 = uVar7 * 0x18;
    puVar4 = (undefined4 *)(iStack_18 + *(int *)(param_1 + 0x98));
    iStack_30 = puVar4[1];
    if (iStack_30 != 0) {
      LOCK();
      *(int *)(iStack_30 + 4) = *(int *)(iStack_30 + 4) + 1;
      UNLOCK();
      iStack_30 = puVar4[1];
    }
    uStack_34 = *puVar4;
    iStack_28 = puVar4[3];
    if (iStack_28 != 0) {
      LOCK();
      *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
      UNLOCK();
      iStack_28 = puVar4[3];
    }
    uStack_2c = puVar4[2];
    uStack_24 = puVar4[4];
    uStack_20 = puVar4[5];
    uStack_8 = 0;
    FUN_00c9e9a0(&uStack_34,param_2);
    uStack_8 = 0xffffffff;
    FUN_0056b650();
    uStack_1c = (*(int *)(param_1 + 0x9c) - *(int *)(param_1 + 0x98)) / 0x18;
    puVar5 = (uint *)(iStack_18 + *(int *)(param_1 + 0x98));
    do {
      uVar7 = uVar7 + 1;
      uVar2 = uStack_1c;
      if ((uStack_1c <= uVar7) || (uVar2 = puVar5[6], uVar2 != *(uint *)(param_1 + 0xa8))) break;
      puVar1 = puVar5 + 8;
      uVar2 = uStack_1c;
      puVar5 = puVar5 + 6;
    } while (*puVar1 == *(uint *)(param_1 + 0xb0));
  } while( true );
}



/* FUNCTION 29903 ; VA 0x00c9d8d0 ; FUN_00c9d8d0 */

int FUN_00c9d8d0(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00a9bfa0(param_1);
  if (iVar3 != 0) {
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    iVar3 = FUN_00a9d410(param_1,param_2,param_3,param_4,param_5,0);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29904 ; VA 0x00c9d990 ; FUN_00c9d990 */

uint * __thiscall FUN_00c9d990(int *param_1,uint *param_2)

{
  uint *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  
  iVar2 = *param_1;
  uVar4 = (param_1[1] - iVar2) / 0x18 - 1;
  iVar5 = (*param_2 >> 3) + *param_2;
  uVar3 = iVar5 + 0x9e3779b9;
  uVar3 = (uVar3 >> 2) + (param_2[2] >> 3) + param_2[2] + iVar5 * 0x40 + 0x2c15e7f9 ^ uVar3;
  uVar6 = 0;
  while( true ) {
    uVar3 = uVar3 & uVar4;
    uVar7 = *(uint *)(iVar2 + uVar3 * 0x18);
    puVar1 = (uint *)(iVar2 + uVar3 * 0x18);
    if ((uVar7 == param_1[4]) && (uVar7 = *puVar1, puVar1[2] == param_1[6])) {
      FUN_00c9b0c0(param_2);
      param_1[3] = param_1[3] + 1;
      return puVar1;
    }
    if ((uVar7 == *param_2) && (puVar1[2] == param_2[2])) break;
    uVar3 = uVar3 + 1 + uVar6;
    uVar6 = uVar6 + 1;
    if (uVar4 < uVar6) {
      return (uint *)0x0;
    }
  }
  return puVar1;
}



/* FUNCTION 29905 ; VA 0x00c9da60 ; FUN_00c9da60 */

void __fastcall FUN_00c9da60(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  
  if (((*(int *)(param_1 + 0x4c) == 0) && (*(int *)(param_1 + 0x70) != 0)) ||
     (*(int *)(param_1 + 0x90) <= *(int *)(param_1 + 0x8c))) {
    iVar1 = *(int *)(param_1 + 0x44);
    iVar2 = *(int *)(param_1 + 0x40);
    if (iVar2 != iVar1) {
      do {
        FUN_0056b650();
        iVar2 = iVar2 + 0x18;
      } while (iVar2 != iVar1);
      iVar2 = *(int *)(param_1 + 0x40);
    }
    *(int *)(param_1 + 0x44) = iVar2;
    *(undefined4 *)(param_1 + 0x4c) = 0;
    uStack_2c = *(undefined4 *)(param_1 + 0x40);
    uStack_28 = *(undefined4 *)(param_1 + 0x44);
    uStack_24 = *(undefined4 *)(param_1 + 0x48);
    *(undefined4 *)(param_1 + 0x40) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
    *(undefined4 *)(param_1 + 0x48) = 0;
    uStack_20 = *(undefined4 *)(param_1 + 0x4c);
    uStack_1c = *(undefined4 *)(param_1 + 0x50);
    uStack_18 = *(undefined4 *)(param_1 + 0x54);
    *(undefined4 *)(param_1 + 0x50) = 0;
    *(undefined4 *)(param_1 + 0x54) = 0;
    uStack_14 = *(undefined4 *)(param_1 + 0x58);
    uStack_10 = *(undefined4 *)(param_1 + 0x5c);
    *(undefined4 *)(param_1 + 0x58) = 0;
    *(undefined4 *)(param_1 + 0x5c) = 0;
    FUN_00c9aff0(param_1 + 100);
    FUN_00c9aff0(&uStack_2c);
    FUN_0056b650();
    FUN_008ee200();
    *(int *)(param_1 + 0x94) = *(int *)(param_1 + 0x94) + 1;
    *(undefined4 *)(param_1 + 0x8c) = 0;
  }
  return;
}



/* FUNCTION 29906 ; VA 0x00c9db60 ; FUN_00c9db60 */

void __thiscall FUN_00c9db60(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01810866;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  FUN_01679490();
  FUN_01679490();
  if (DAT_01d68ac4 != '\0') {
    FUN_01679490();
  }
  FUN_01679490();
  iVar4 = (int)param_3;
  FUN_008a4210(param_2,param_3);
  FUN_00f45260(param_2,iVar4);
  if (iVar4 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar4 = FUN_00562f00();
  if (iVar4 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  iStack_8 = 0;
  uVar5 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 1;
  puVar6 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    *puVar6 = 0;
    puVar6[1] = 1;
    puVar6[2] = FUN_00c9c460;
    puVar6[3] = _guard_check_icall;
    puVar6[4] = 0;
    puVar6[5] = iVar4 + 0x338;
    puVar6[6] = param_1;
  }
  FUN_016797d0(puVar6);
  if (puVar6 != (undefined4 *)0x0) {
    LOCK();
    puVar6[1] = puVar6[1] + 1;
    UNLOCK();
  }
  iStack_8._0_1_ = 2;
  param_3 = puVar6;
  FUN_01675290(uVar5);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  cVar3 = FUN_01679300(&param_3);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(&param_3);
  }
  iStack_8 = 0xffffffff;
  if (param_3 != (undefined4 *)0x0) {
    piVar1 = param_3 + 1;
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(param_3);
    }
  }
  if (param_1 == 0) {
LAB_00c9dd41:
    iVar4 = 0;
  }
  else {
    iVar4 = *(int *)(param_1 + 0x34);
    iVar7 = param_1;
    if ((iVar4 != 0) && (iVar7 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
      iVar7 = FUN_005c8ac0();
    }
    if ((iVar7 == 0) ||
       (iVar4 = *(int *)(iVar7 + 0xc), iVar7 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar7 + 0x1da) <
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) goto LAB_00c9dd41;
    iVar4 = FUN_0055e560();
  }
  if (DAT_01d68ac4 == '\0') {
    param_3 = (undefined4 *)(iVar4 + 0x50);
    iStack_8 = 9;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 10;
    puVar6 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = 0;
      puVar6[1] = 1;
      puVar6[2] = FUN_00c9c600;
      puVar6[3] = _guard_check_icall;
      puVar6[4] = 0;
      puVar6[5] = param_3;
      puVar6[6] = param_1;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    iStack_8 = CONCAT31(iStack_8._1_3_,0xb);
    FUN_01675290(uVar5);
    iVar4 = *(int *)(param_1 + 0xf0);
    *(undefined4 **)(param_1 + 0xf0) = puVar6;
    iStack_8 = 0xffffffff;
    if (iVar4 == 0) goto LAB_00c9dfb6;
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar7 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
  }
  else {
    param_3 = (undefined4 *)(iVar4 + 0x2a4);
    iStack_8 = 3;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 4;
    puVar6 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = 0;
      puVar6[1] = 1;
      puVar6[2] = FUN_00c9c480;
      puVar6[3] = _guard_check_icall;
      puVar6[4] = 0;
      puVar6[5] = param_3;
      puVar6[6] = param_1;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    iStack_8 = CONCAT31(iStack_8._1_3_,5);
    FUN_01675290(uVar5);
    iVar7 = *(int *)(param_1 + 0xf4);
    *(undefined4 **)(param_1 + 0xf4) = puVar6;
    if (iVar7 != 0) {
      piVar1 = (int *)(iVar7 + 4);
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(iVar7);
      }
    }
    param_3 = (undefined4 *)(iVar4 + 0x2a8);
    iStack_8 = 6;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 7;
    puVar6 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = 0;
      puVar6[1] = 1;
      puVar6[2] = FUN_00c9c480;
      puVar6[3] = _guard_check_icall;
      puVar6[4] = 0;
      puVar6[5] = param_3;
      puVar6[6] = param_1;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    iStack_8 = CONCAT31(iStack_8._1_3_,8);
    FUN_01675290(uVar5);
    iVar4 = *(int *)(param_1 + 0xf8);
    *(undefined4 **)(param_1 + 0xf8) = puVar6;
    iStack_8 = 0xffffffff;
    if (iVar4 == 0) goto LAB_00c9dfb6;
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar7 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
  }
  iStack_8 = 0xffffffff;
  if (iVar7 == 1) {
    iStack_8 = 0xffffffff;
    FUN_01674ea0(iVar4);
  }
LAB_00c9dfb6:
  iVar4 = FUN_00bbddb0();
  if (iVar4 != 0) {
    param_3 = (undefined4 *)(iVar4 + 0x3c);
    iStack_8 = 0xc;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 0xd;
    puVar6 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = 0;
      puVar6[1] = 1;
      puVar6[2] = FUN_00c9c440;
      puVar6[3] = _guard_check_icall;
      puVar6[4] = 0;
      puVar6[5] = param_3;
      puVar6[6] = param_1;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    iStack_8 = CONCAT31(iStack_8._1_3_,0xe);
    FUN_01675290(uVar5);
    iVar7 = *(int *)(param_1 + 0x11c);
    *(undefined4 **)(param_1 + 0x11c) = puVar6;
    if (iVar7 != 0) {
      piVar1 = (int *)(iVar7 + 4);
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(iVar7);
      }
    }
    param_3 = (undefined4 *)(iVar4 + 0x40);
    iStack_8 = 0xf;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 0x10;
    puVar6 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = 0;
      puVar6[1] = 1;
      puVar6[2] = FUN_00c9c540;
      puVar6[3] = _guard_check_icall;
      puVar6[4] = 0;
      puVar6[5] = param_3;
      puVar6[6] = param_1;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    iStack_8 = CONCAT31(iStack_8._1_3_,0x11);
    FUN_01675290(uVar5);
    iVar4 = *(int *)(param_1 + 0x120);
    *(undefined4 **)(param_1 + 0x120) = puVar6;
    if (iVar4 != 0) {
      piVar1 = (int *)(iVar4 + 4);
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(iVar4);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29907 ; VA 0x00c9e160 ; FUN_00c9e160 */

void __thiscall FUN_00c9e160(int param_1,uint *param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810878;
  pvStack_10 = ExceptionList;
  uStack_28 = param_2[1];
  ExceptionList = &pvStack_10;
  if (uStack_28 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(uStack_28 + 4) = *(int *)(uStack_28 + 4) + 1;
    UNLOCK();
    uStack_28 = param_2[1];
  }
  uStack_2c = *param_2;
  uStack_20 = param_2[3];
  if (uStack_20 != 0) {
    LOCK();
    *(int *)(uStack_20 + 4) = *(int *)(uStack_20 + 4) + 1;
    UNLOCK();
    uStack_20 = param_2[3];
  }
  uStack_24 = param_2[2];
  uStack_8 = 0;
  if ((*(int *)(param_1 + 0xbc) != *(int *)(param_1 + 0xc0)) &&
     ((uStack_2c != *(uint *)(param_1 + 0xcc) || (uStack_24 != *(uint *)(param_1 + 0xd4))))) {
    uStack_14 = (*(int *)(param_1 + 0xc0) - *(int *)(param_1 + 0xbc)) / 0x18 - 1;
    iVar4 = (uStack_2c >> 3) + uStack_2c;
    uVar3 = iVar4 + 0x9e3779b9;
    uVar3 = (uStack_24 >> 3) + 0x2c15e7f9 + param_2[2] + iVar4 * 0x40 + (uVar3 >> 2) ^ uVar3;
    uVar5 = 0;
    do {
      puVar1 = (uint *)(*(int *)(param_1 + 0xbc) + (uVar3 & uStack_14) * 0x18);
      if ((*puVar1 == uStack_2c) && (puVar1[2] == uStack_24)) goto LAB_00c9e256;
      if ((*puVar1 == *(uint *)(param_1 + 0xcc)) && (puVar1[2] == *(uint *)(param_1 + 0xd4))) break;
      uVar3 = (uVar3 & uStack_14) + 1 + uVar5;
      uVar5 = uVar5 + 1;
    } while (uVar5 <= uStack_14);
  }
  puVar1 = (uint *)0x0;
LAB_00c9e256:
  piVar2 = (int *)(-(uint)(puVar1 != (uint *)0x0) & (uint)(puVar1 + 4));
  uStack_1c = uStack_24;
  uStack_18 = uStack_2c;
  if (piVar2 == (int *)0x0) {
    uVar3 = param_2[4];
    uVar5 = param_2[5];
    if ((uint)(((*(int *)(param_1 + 0xc0) - *(int *)(param_1 + 0xbc)) / 0x18) * 3) >> 2 <=
        *(uint *)(param_1 + 200)) {
      FUN_00c9e380();
    }
    iVar4 = FUN_00c9d990(&uStack_2c);
    *(uint *)(iVar4 + 0x10) = -(uint)(uVar3 != 0) & 3;
    *(uint *)(iVar4 + 0x14) = uVar5;
  }
  else if (*piVar2 < 3 == (param_2[4] == 1)) {
    switch(*piVar2) {
    case 0:
    case 2:
      *piVar2 = 4;
      break;
    case 1:
      *piVar2 = 5;
      break;
    case 3:
    case 5:
      *piVar2 = 1;
      break;
    case 4:
      *piVar2 = 2;
    }
  }
  FUN_0056b650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29908 ; VA 0x00c9e320 ; FUN_00c9e320 */

void __fastcall FUN_00c9e320(int param_1)

{
  LOCK();
  *(int *)(param_1 + 0xe4) = *(int *)(param_1 + 0xe4) + 1;
  UNLOCK();
  return;
}



/* FUNCTION 29909 ; VA 0x00c9e330 ; FUN_00c9e330 */

void __thiscall FUN_00c9e330(int *param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  
  iVar1 = *param_1;
  puVar2 = *(undefined4 **)(iVar1 + 4);
  uVar3 = FUN_00c9ab70(iVar1,puVar2,param_2);
  if (param_1[1] != 0x7fffffe) {
    param_1[1] = param_1[1] + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 29910 ; VA 0x00c9e380 ; FUN_00c9e380 */

void __fastcall FUN_00c9e380(int *param_1)

{
  uint *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint *puVar9;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  uint uStack_24;
  uint uStack_1c;
  int *piStack_10;
  uint uStack_c;
  int iStack_8;
  
  if (*param_1 == param_1[1]) {
    iVar4 = 0x10;
  }
  else {
    iVar4 = ((param_1[1] - *param_1) / 0x18) * 2;
  }
  piStack_10 = param_1;
  FUN_008e6f20(param_1 + 4,iVar4);
  iVar4 = *param_1;
  uStack_c = 0;
  iVar2 = param_1[1] - iVar4 >> 0x1f;
  if ((param_1[1] - iVar4) / 0x18 + iVar2 != iVar2) {
    iStack_8 = 0;
    do {
      puVar1 = (uint *)(iVar4 + iStack_8);
      if ((*(int *)(iVar4 + iStack_8) != param_1[4]) || (puVar1[2] != param_1[6])) {
        iVar4 = (*puVar1 >> 3) + *puVar1;
        uVar7 = (iStack_30 - iStack_34) / 0x18 - 1;
        uVar6 = iVar4 + 0x9e3779b9;
        uVar6 = (puVar1[2] >> 3) + (uVar6 >> 2) + 0x2c15e7f9 + puVar1[2] + iVar4 * 0x40 ^ uVar6;
        uVar8 = 0;
        do {
          uVar6 = uVar6 & uVar7;
          puVar9 = (uint *)(iStack_34 + uVar6 * 0x18);
          uVar5 = *puVar9;
          if ((uVar5 == uStack_24) && (uVar5 = *puVar9, puVar9[2] == uStack_1c)) {
            FUN_00c9b0c0(puVar1);
            iStack_28 = iStack_28 + 1;
            goto LAB_00c9e486;
          }
          if ((uVar5 == *puVar1) && (puVar9[2] == puVar1[2])) goto LAB_00c9e486;
          uVar6 = uVar6 + 1 + uVar8;
          uVar8 = uVar8 + 1;
        } while (uVar8 <= uVar7);
        puVar9 = (uint *)0x0;
LAB_00c9e486:
        FUN_00c9b0c0(puVar1);
        puVar9[4] = puVar1[4];
        puVar9[5] = puVar1[5];
        iVar4 = *piStack_10;
        param_1 = piStack_10;
      }
      iStack_8 = iStack_8 + 0x18;
      uStack_c = uStack_c + 1;
    } while (uStack_c < (uint)((param_1[1] - iVar4) / 0x18));
  }
  if (param_1 != &iStack_34) {
    *param_1 = iStack_34;
    iVar2 = param_1[1];
    param_1[1] = iStack_30;
    iVar3 = param_1[2];
    param_1[2] = iStack_2c;
    iStack_34 = iVar4;
    iStack_30 = iVar2;
    iStack_2c = iVar3;
  }
  FUN_0056b650();
  FUN_008ee200();
  return;
}



/* FUNCTION 29911 ; VA 0x00c9e520 ; FUN_00c9e520 */

void __thiscall FUN_00c9e520(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c9e8b0(&param_2);
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid DataModel.");
  }
  iVar2 = FUN_005c3ac0(param_1);
  if (iVar2 != 0) {
    cVar1 = FUN_008ff0a0();
    if (cVar1 == '\0') {
      cVar1 = FUN_008b0260(param_1);
      if (cVar1 != '\0') {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("This API can only be used on the server!");
      }
    }
    cVar1 = FUN_00bc0280(&param_2);
    if (cVar1 != '\0') {
      FUN_008b8160();
    }
    if (0xf < in_stack_00000018) {
      uVar3 = in_stack_00000018 + 1;
      iVar2 = param_2;
      if (0xfff < uVar3) {
        iVar2 = *(int *)(param_2 + -4);
        uVar3 = in_stack_00000018 + 0x24;
        if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Invalid Workspace.");
}



/* FUNCTION 29912 ; VA 0x00c9e610 ; FUN_00c9e610 */

void __thiscall FUN_00c9e610(undefined4 param_1,uint param_2)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int in_stack_0000001c;
  uint in_stack_00000030;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9440;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00c9e8b0(&param_2);
  FUN_00c9e8b0(&stack0x0000001c);
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid DataModel.");
  }
  iVar2 = FUN_005c3ac0(param_1);
  if (iVar2 != 0) {
    cVar1 = FUN_008ff0a0();
    if (cVar1 == '\0') {
      cVar1 = FUN_008b0260(param_1);
      if (cVar1 != '\0') {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("This API can only be used on the server!");
      }
    }
    cVar1 = FUN_00bc09c0(&param_2,&stack0x0000001c);
    if (cVar1 != '\0') {
      FUN_008b8160();
    }
    if (0xf < in_stack_00000018) {
      uVar3 = in_stack_00000018 + 1;
      uVar4 = param_2;
      if (0xfff < uVar3) {
        uVar4 = *(uint *)(param_2 - 4);
        uVar3 = in_stack_00000018 + 0x24;
        if (0x1f < (param_2 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar3);
    }
    in_stack_00000014 = 0;
    in_stack_00000018 = 0xf;
    param_2 = param_2 & 0xffffff00;
    if (0xf < in_stack_00000030) {
      uVar4 = in_stack_00000030 + 1;
      iVar2 = in_stack_0000001c;
      if (0xfff < uVar4) {
        iVar2 = *(int *)(in_stack_0000001c + -4);
        uVar4 = in_stack_00000030 + 0x24;
        if (0x1f < (in_stack_0000001c - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar4);
    }
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Invalid Workspace.");
}



/* FUNCTION 29913 ; VA 0x00c9e760 ; FUN_00c9e760 */

void __thiscall FUN_00c9e760(undefined4 param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4300;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid DataModel.");
  }
  iVar2 = FUN_005c3ac0(param_1);
  if (iVar2 != 0) {
    cVar1 = FUN_00bbc0d0(&stack0x0000000c);
    if (cVar1 == '\0') {
      FUN_016756b0(auStack_1c,"Collision group does not exist.");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    if (param_2 != 0) {
      iVar2 = *(int *)(param_2 + 0xc);
      iVar3 = FUN_00aff8c0();
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        iVar2 = FUN_00a9d140(param_2);
        if (iVar2 == 0) {
          cVar1 = FUN_00bbdba0(&stack0x0000000c);
          FUN_00b0d5d0((int)cVar1);
          FUN_00550b30();
          FUN_005507b0();
          ExceptionList = pvStack_10;
          return;
        }
        FUN_016756b0(auStack_1c,
                     "PhysicsService::SetPartCollisionGroup() : Passed in Instance parameter has a WorldModel ancestor"
                    );
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_1c,&DAT_01c17198);
      }
    }
    FUN_016756b0(auStack_1c,"Parameter 1 must be BasePart in SetPartCollisionGroup.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Invalid Workspace.");
}



/* FUNCTION 29914 ; VA 0x00c9e8b0 ; FUN_00c9e8b0 */

void FUN_00c9e8b0(undefined4 *param_1)

{
  uint uVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined auStack_10 [12];
  
  uVar1 = param_1[5];
  iVar4 = param_1[4];
  puVar3 = param_1;
  if (0xf < uVar1) {
    puVar3 = (undefined4 *)*param_1;
  }
  cVar2 = FUN_0055c360(puVar3,iVar4,&DAT_018bc9b8,0);
  if (cVar2 != '\0') {
    FUN_016756b0(auStack_10,"Collision group requires a valid name.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  puVar3 = param_1;
  if (0xf < uVar1) {
    puVar3 = (undefined4 *)*param_1;
  }
  cVar2 = FUN_0055c360(puVar3,iVar4,"Default",7);
  if (cVar2 != '\0') {
    FUN_016756b0(auStack_10,"Can not use/change the Default collision group.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  if (iVar4 != 0) {
    iVar4 = FUN_0170db20(param_1,0x5c,iVar4);
    if ((iVar4 != 0) && (iVar4 - (int)param_1 != -1)) goto LAB_00c9e97a;
  }
  iVar4 = FUN_00591310(0x5e,0);
  if (iVar4 == -1) {
    return;
  }
LAB_00c9e97a:
  FUN_016756b0(auStack_10,"Collision group name must not contain a \'\' or a \'^\'.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 29915 ; VA 0x00c9e9a0 ; FUN_00c9e9a0 */

void __thiscall FUN_00c9e9a0(undefined4 *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018108f0;
  pvStack_10 = ExceptionList;
  switch(*param_1) {
  case 0:
    ExceptionList = &pvStack_10;
    uVar2 = FUN_00703f50(param_2,param_2 + 8,0,param_1[1]);
    uStack_8 = 0;
    break;
  case 1:
    ExceptionList = &pvStack_10;
    uVar2 = FUN_00703f50(param_2,param_2 + 8,1,param_1[1]);
    uStack_8 = 4;
    FUN_00c9e330(uVar2);
    FUN_0056b650();
    uVar2 = FUN_00703f50(param_2,param_2 + 8,0,param_1[1]);
    uStack_8 = 5;
    break;
  case 2:
    iVar1 = param_2 + 8;
    ExceptionList = &pvStack_10;
    uVar2 = FUN_00703f50(param_2,iVar1,0,param_1[1]);
    uStack_8 = 6;
    FUN_00c9e330(uVar2);
    FUN_0056b650();
    uVar2 = FUN_00703f50(param_2,iVar1,1,param_1[1]);
    uStack_8 = 7;
    FUN_00c9e330(uVar2);
    FUN_0056b650();
    uVar2 = FUN_00703f50(param_2,iVar1,0,param_1[1]);
    uStack_8 = 8;
    break;
  case 3:
    ExceptionList = &pvStack_10;
    uVar2 = FUN_00703f50(param_2,param_2 + 8,1,param_1[1]);
    uStack_8 = 1;
    break;
  case 4:
    ExceptionList = &pvStack_10;
    uVar2 = FUN_00703f50(param_2,param_2 + 8,0,param_1[1]);
    uStack_8 = 2;
    FUN_00c9e330(uVar2);
    FUN_0056b650();
    uVar2 = FUN_00703f50(param_2,param_2 + 8,1,param_1[1]);
    uStack_8 = 3;
    break;
  case 5:
    iVar1 = param_2 + 8;
    ExceptionList = &pvStack_10;
    uVar2 = FUN_00703f50(param_2,iVar1,1,param_1[1]);
    uStack_8 = 9;
    FUN_00c9e330(uVar2);
    FUN_0056b650();
    uVar2 = FUN_00703f50(param_2,iVar1,0,param_1[1]);
    uStack_8 = 10;
    FUN_00c9e330(uVar2);
    FUN_0056b650();
    uVar2 = FUN_00703f50(param_2,iVar1,1,param_1[1]);
    uStack_8 = 0xb;
    break;
  default:
    goto switchD_00c9e9ce_caseD_6;
  }
  FUN_00c9e330(uVar2);
  FUN_0056b650();
switchD_00c9e9ce_caseD_6:
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29916 ; VA 0x00c9ebe0 ; FUN_00c9ebe0 */

undefined8 * __thiscall FUN_00c9ebe0(float *param_1,undefined8 *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  
  *(undefined4 *)param_2 = 0x7f7fffff;
  *(undefined4 *)((int)param_2 + 4) = 0x7f7fffff;
  *(undefined4 *)(param_2 + 1) = 0x7f7fffff;
  *(undefined4 *)((int)param_2 + 0xc) = 0xff7fffff;
  *(undefined4 *)(param_2 + 2) = 0xff7fffff;
  *(undefined4 *)((int)param_2 + 0x14) = 0xff7fffff;
  fVar1 = *param_3;
  if (*param_3 <= *param_1) {
    fVar1 = *param_1;
  }
  fVar2 = param_3[2];
  if (param_3[2] <= param_1[2]) {
    fVar2 = param_1[2];
  }
  fVar4 = param_3[3];
  if (fVar1 <= param_3[3]) {
    fVar4 = fVar1;
  }
  fVar1 = param_3[1];
  if (param_3[1] <= param_1[1]) {
    fVar1 = param_1[1];
  }
  fVar3 = param_3[4];
  if (fVar1 <= param_3[4]) {
    fVar3 = fVar1;
  }
  fVar1 = param_3[5];
  if (fVar2 <= param_3[5]) {
    fVar1 = fVar2;
  }
  *param_2 = CONCAT44(fVar3,fVar4);
  *(float *)(param_2 + 1) = fVar1;
  fVar1 = *param_3;
  if (*param_3 <= param_1[3]) {
    fVar1 = param_1[3];
  }
  fVar2 = param_3[2];
  if (param_3[2] <= param_1[5]) {
    fVar2 = param_1[5];
  }
  fVar4 = param_3[3];
  if (fVar1 <= param_3[3]) {
    fVar4 = fVar1;
  }
  fVar1 = param_3[1];
  if (param_3[1] <= param_1[4]) {
    fVar1 = param_1[4];
  }
  fVar3 = param_3[4];
  if (fVar1 <= param_3[4]) {
    fVar3 = fVar1;
  }
  fVar1 = param_3[5];
  if (fVar2 <= param_3[5]) {
    fVar1 = fVar2;
  }
  *(ulonglong *)((int)param_2 + 0xc) = CONCAT44(fVar3,fVar4);
  *(float *)((int)param_2 + 0x14) = fVar1;
  return param_2;
}



/* FUNCTION 29917 ; VA 0x00c9ecc0 ; FUN_00c9ecc0 */

undefined __thiscall FUN_00c9ecc0(float *param_1,float *param_2)

{
  undefined uVar1;
  float fVar2;
  float fVar3;
  double dVar4;
  double dVar5;
  float fVar6;
  uint uVar7;
  uint uVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  
  dVar4 = (double)(param_2[1] - param_1[4]);
  uVar7 = (uint)DAT_018c0da0;
  uVar8 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fVar9 = (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar8,SUB84(dVar4,0) & uVar7);
  dVar4 = (double)(param_2[2] - param_1[5]);
  fVar11 = (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar8,SUB84(dVar4,0) & uVar7);
  dVar4 = (double)(*param_2 - *param_1);
  fVar10 = (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar8,SUB84(dVar4,0) & uVar7);
  dVar4 = (double)(param_2[1] - param_1[1]);
  fVar6 = (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar8,SUB84(dVar4,0) & uVar7);
  dVar4 = (double)(param_2[2] - param_1[2]);
  dVar5 = (double)(*param_2 - param_1[3]);
  fVar2 = (float)(double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & uVar8,SUB84(dVar5,0) & uVar7);
  fVar3 = fVar2;
  if (fVar9 < fVar2) {
    fVar3 = fVar9;
  }
  uVar1 = fVar9 < fVar2;
  if (fVar11 < fVar3) {
    uVar1 = 2;
    fVar3 = fVar11;
  }
  if (fVar10 < fVar3) {
    uVar1 = 3;
    fVar3 = fVar10;
  }
  if (fVar6 < fVar3) {
    uVar1 = 4;
    fVar3 = fVar6;
  }
  if ((float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar8,SUB84(dVar4,0) & uVar7) <
      fVar3) {
    uVar1 = 5;
  }
  return uVar1;
}



/* FUNCTION 29918 ; VA 0x00c9ed90 ; FUN_00c9ed90 */

float10 __thiscall FUN_00c9ed90(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  fVar3 = (param_1[3] - *param_1) * DAT_018ce2f4;
  fVar2 = *param_2 - (*param_1 + param_1[3]) * DAT_018ce2f4;
  fVar4 = (param_1[4] - param_1[1]) * DAT_018ce2f4;
  fVar5 = (param_1[5] - param_1[2]) * DAT_018ce2f4;
  fVar1 = param_2[1] - (param_1[1] + param_1[4]) * DAT_018ce2f4;
  fVar6 = param_2[2] - (param_1[2] + param_1[5]) * DAT_018ce2f4;
  param_2 = (float *)0x0;
  if (fVar2 < (float)((uint)fVar3 ^ DAT_018c4ea0)) {
    param_2 = (float *)((fVar3 + fVar2) * (fVar3 + fVar2) + 0.0);
  }
  if (fVar3 < fVar2) {
    param_2 = (float *)((float)param_2 + (fVar2 - fVar3) * (fVar2 - fVar3));
  }
  if (fVar1 < (float)((uint)fVar4 ^ DAT_018c4ea0)) {
    param_2 = (float *)((float)param_2 + (fVar4 + fVar1) * (fVar4 + fVar1));
  }
  if (fVar4 < fVar1) {
    param_2 = (float *)((float)param_2 + (fVar1 - fVar4) * (fVar1 - fVar4));
  }
  if (fVar6 < (float)((uint)fVar5 ^ DAT_018c4ea0)) {
    param_2 = (float *)((float)param_2 + (fVar5 + fVar6) * (fVar5 + fVar6));
  }
  if (fVar5 < fVar6) {
    param_2 = (float *)((fVar6 - fVar5) * (fVar6 - fVar5) + (float)param_2);
  }
  return (float10)(float)param_2;
}



/* FUNCTION 29919 ; VA 0x00c9eef0 ; FUN_00c9eef0 */

/* WARNING: Removing unreachable block (ram,0x00c9ef49) */

undefined8 * __thiscall FUN_00c9eef0(int param_1,undefined8 *param_2,float *param_3,float *param_4)

{
  uint uVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fStack_8 = DAT_018e0028;
  uVar1 = 0;
  fStack_14 = DAT_0193ce08;
  fStack_10 = DAT_0193ce08;
  fStack_c = DAT_0193ce08;
  fVar6 = DAT_018e0028;
  fVar7 = DAT_018e0028;
  do {
    fVar2 = *(float *)(param_1 + (short)(uVar1 >> 2) * 0xc);
    fVar3 = *(float *)(param_1 + 4 + (short)((ushort)(uVar1 >> 1) & 1) * 0xc);
    fVar5 = *(float *)(param_1 + 8 + (uVar1 & 1) * 0xc);
    fVar8 = (fVar3 * param_3[1] + fVar2 * *param_3 + param_3[2] * fVar5 + param_3[9]) - param_4[9];
    fVar4 = (fVar3 * param_3[4] + fVar2 * param_3[3] + param_3[5] * fVar5 + param_3[10]) -
            param_4[10];
    fVar5 = (fVar3 * param_3[7] + fVar2 * param_3[6] + param_3[8] * fVar5 + param_3[0xb]) -
            param_4[0xb];
    fVar3 = fVar8 * *param_4 + fVar4 * param_4[3] + fVar5 * param_4[6];
    fVar2 = fVar8 * param_4[1] + fVar4 * param_4[4] + fVar5 * param_4[7];
    fVar5 = fVar8 * param_4[2] + fVar4 * param_4[5] + fVar5 * param_4[8];
    if (fVar5 <= fStack_8) {
      fStack_8 = fVar5;
    }
    if (fVar2 <= fVar7) {
      fVar7 = fVar2;
    }
    if (fVar3 <= fVar6) {
      fVar6 = fVar3;
    }
    if (fStack_c <= fVar5) {
      fStack_c = fVar5;
    }
    if (fStack_10 <= fVar2) {
      fStack_10 = fVar2;
    }
    if (fStack_14 <= fVar3) {
      fStack_14 = fVar3;
    }
    uVar1 = uVar1 + 1;
  } while ((int)uVar1 < 8);
  *(undefined4 *)(param_2 + 2) = 0xff7fffff;
  *(undefined4 *)((int)param_2 + 0x14) = 0xff7fffff;
  param_3 = (float *)fStack_c;
  if (fStack_8 < fStack_c) {
    param_3 = (float *)fStack_8;
  }
  fVar2 = fStack_10;
  if (fVar7 < fStack_10) {
    fVar2 = fVar7;
  }
  fVar3 = fStack_14;
  if (fVar6 < fStack_14) {
    fVar3 = fVar6;
  }
  *param_2 = CONCAT44(fVar2,fVar3);
  *(float **)(param_2 + 1) = param_3;
  if (fStack_8 <= fStack_c) {
    fStack_8 = fStack_c;
  }
  if (fVar7 <= fStack_10) {
    fVar7 = fStack_10;
  }
  if (fVar6 <= fStack_14) {
    fVar6 = fStack_14;
  }
  *(ulonglong *)((int)param_2 + 0xc) = CONCAT44(fVar7,fVar6);
  *(float *)((int)param_2 + 0x14) = fStack_8;
  return param_2;
}



/* FUNCTION 29920 ; VA 0x00c9f130 ; FUN_00c9f130 */

float * __thiscall FUN_00c9f130(float *param_1,float *param_2,int param_3)

{
  float fVar1;
  int iVar2;
  
  fVar1 = DAT_018ce2f4;
  *param_2 = (param_1[3] + *param_1) * DAT_018ce2f4;
  iVar2 = param_3 % 3;
  param_2[1] = (param_1[4] + param_1[1]) * fVar1;
  param_2[2] = (param_1[5] + param_1[2]) * fVar1;
  if (param_3 < 3) {
    param_2[iVar2] = param_1[iVar2 + 3];
    return param_2;
  }
  param_2[iVar2] = param_1[iVar2];
  return param_2;
}



/* FUNCTION 29921 ; VA 0x00c9f1c0 ; FUN_00c9f1c0 */

undefined4 * __thiscall FUN_00c9f1c0(int param_1,undefined4 *param_2,uint param_3)

{
  uint uVar1;
  
  *param_2 = *(undefined4 *)
              (param_1 + (short)((int)(param_3 + ((int)param_3 >> 0x1f & 3U)) >> 2) * 0xc);
  uVar1 = (int)param_3 / 2 & 0x80000001;
  if ((int)uVar1 < 0) {
    uVar1 = (uVar1 - 1 | 0xfffffffe) + 1;
  }
  param_2[1] = *(undefined4 *)(param_1 + 4 + (short)uVar1 * 0xc);
  param_3 = param_3 & 0x80000001;
  if ((int)param_3 < 0) {
    param_3 = (param_3 - 1 | 0xfffffffe) + 1;
  }
  param_2[2] = *(undefined4 *)(param_1 + 8 + (short)param_3 * 0xc);
  return param_2;
}



/* FUNCTION 29922 ; VA 0x00c9f230 ; FUN_00c9f230 */

undefined2 * FUN_00c9f230(undefined2 *param_1,uint param_2)

{
  uint uVar1;
  
  *param_1 = (short)((int)(param_2 + ((int)param_2 >> 0x1f & 3U)) >> 2);
  uVar1 = (int)param_2 / 2 & 0x80000001;
  if ((int)uVar1 < 0) {
    uVar1 = (uVar1 - 1 | 0xfffffffe) + 1;
  }
  param_1[1] = (short)uVar1;
  param_2 = param_2 & 0x80000001;
  if ((int)param_2 < 0) {
    param_2 = (param_2 - 1 | 0xfffffffe) + 1;
  }
  param_1[2] = (short)param_2;
  return param_1;
}



/* FUNCTION 29923 ; VA 0x00c9f280 ; FUN_00c9f280 */

void FUN_00c9f280(undefined4 param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4,
                 undefined8 *param_5)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined auStack_10 [12];
  
  switch(param_1) {
  case 0:
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,4);
    *param_2 = *puVar1;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,6);
    *param_3 = *puVar1;
    *(undefined4 *)(param_3 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,7);
    uVar2 = 5;
    break;
  case 1:
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,2);
    *param_2 = *puVar1;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,3);
    *param_3 = *puVar1;
    *(undefined4 *)(param_3 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,7);
    uVar2 = 6;
    break;
  case 2:
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,1);
    *param_2 = *puVar1;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,5);
    *param_3 = *puVar1;
    *(undefined4 *)(param_3 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,7);
    uVar2 = 3;
    break;
  case 3:
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,0);
    *param_2 = *puVar1;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,1);
    *param_3 = *puVar1;
    *(undefined4 *)(param_3 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,3);
    uVar2 = 2;
    break;
  case 4:
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,0);
    *param_2 = *puVar1;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,4);
    *param_3 = *puVar1;
    *(undefined4 *)(param_3 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,5);
    uVar2 = 1;
    break;
  case 5:
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,0);
    *param_2 = *puVar1;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,2);
    *param_3 = *puVar1;
    *(undefined4 *)(param_3 + 1) = *(undefined4 *)(puVar1 + 1);
    puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,6);
    uVar2 = 4;
    break;
  default:
    goto switchD_00c9f295_caseD_6;
  }
  *param_4 = *puVar1;
  *(undefined4 *)(param_4 + 1) = *(undefined4 *)(puVar1 + 1);
  puVar1 = (undefined8 *)FUN_00c9f1c0(auStack_10,uVar2);
  *param_5 = *puVar1;
  *(undefined4 *)(param_5 + 1) = *(undefined4 *)(puVar1 + 1);
switchD_00c9f295_caseD_6:
  return;
}



/* FUNCTION 29924 ; VA 0x00c9f4c0 ; FUN_00c9f4c0 */

undefined4 __thiscall FUN_00c9f4c0(float *param_1,float *param_2,float param_3)

{
  float fStack_c;
  float fStack_8;
  
  if ((((*param_1 - param_3 < param_2[3] || *param_1 - param_3 == param_2[3]) &&
       (param_1[1] - param_3 < param_2[4] || param_1[1] - param_3 == param_2[4])) &&
      (param_1[2] - param_3 < param_2[5] || param_1[2] - param_3 == param_2[5])) &&
     (((fStack_c = (float)*(undefined8 *)(param_1 + 4), param_2[1] <= fStack_c + param_3 &&
       (*param_2 <= param_1[3] + param_3)) &&
      (fStack_8 = (float)((ulonglong)*(undefined8 *)(param_1 + 4) >> 0x20),
      param_2[2] <= fStack_8 + param_3)))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 29925 ; VA 0x00c9f550 ; FUN_00c9f550 */

undefined8 * __thiscall FUN_00c9f550(float *param_1,undefined8 *param_2,float *param_3)

{
  double dVar1;
  double dVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  uint uVar6;
  uint uVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  
  fVar9 = *param_1;
  if (fVar9 <= param_1[3]) {
    fVar4 = param_1[1];
    if (fVar4 <= param_1[4]) {
      fVar5 = param_1[2];
      if (fVar5 <= param_1[5]) {
        fVar3 = (param_1[5] + fVar5) * DAT_018ce2f4;
        fVar10 = (param_1[4] + fVar4) * DAT_018ce2f4;
        fVar8 = (param_1[3] + fVar9) * DAT_018ce2f4;
        fVar11 = param_3[1] * fVar10 + *param_3 * fVar8 + param_3[2] * fVar3 + param_3[9];
        fVar12 = param_3[4] * fVar10 + param_3[3] * fVar8 + param_3[5] * fVar3 + param_3[10];
        fVar4 = (param_1[4] - fVar4) * DAT_018ce2f4;
        fVar3 = param_3[7] * fVar10 + param_3[6] * fVar8 + param_3[8] * fVar3 + param_3[0xb];
        fVar5 = (param_1[5] - fVar5) * DAT_018ce2f4;
        fVar9 = (param_1[3] - fVar9) * DAT_018ce2f4;
        dVar1 = (double)param_3[1];
        uVar6 = (uint)DAT_018c0da0;
        uVar7 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
        fVar10 = (float)(double)CONCAT44((uint)((ulonglong)dVar1 >> 0x20) & uVar7,
                                         SUB84(dVar1,0) & uVar6) * fVar4 +
                 (float)(double)CONCAT44((uint)((ulonglong)(double)*param_3 >> 0x20) & uVar7,
                                         SUB84((double)*param_3,0) & uVar6) * fVar9 +
                 (float)(double)CONCAT44((uint)((ulonglong)(double)param_3[2] >> 0x20) & uVar7,
                                         SUB84((double)param_3[2],0) & uVar6) * fVar5;
        dVar1 = (double)param_3[4];
        dVar2 = (double)param_3[3];
        fVar8 = (float)(double)CONCAT44((uint)((ulonglong)dVar1 >> 0x20) & uVar7,
                                        SUB84(dVar1,0) & uVar6) * fVar4 +
                (float)(double)CONCAT44((uint)((ulonglong)dVar2 >> 0x20) & uVar7,
                                        SUB84(dVar2,0) & uVar6) * fVar9 +
                (float)(double)CONCAT44((uint)((ulonglong)(double)param_3[5] >> 0x20) & uVar7,
                                        SUB84((double)param_3[5],0) & uVar6) * fVar5;
        dVar1 = (double)param_3[7];
        dVar2 = (double)param_3[8];
        fVar9 = (float)(double)CONCAT44((uint)((ulonglong)dVar1 >> 0x20) & uVar7,
                                        SUB84(dVar1,0) & uVar6) * fVar4 +
                (float)(double)CONCAT44((uint)((ulonglong)(double)param_3[6] >> 0x20) & uVar7,
                                        SUB84((double)param_3[6],0) & uVar6) * fVar9 +
                (float)(double)CONCAT44((uint)((ulonglong)dVar2 >> 0x20) & uVar7,
                                        SUB84(dVar2,0) & uVar6) * fVar5;
        *(ulonglong *)((int)param_2 + 0xc) = CONCAT44(fVar8 + fVar12,fVar10 + fVar11);
        *(float *)((int)param_2 + 0x14) = fVar9 + fVar3;
        *param_2 = CONCAT44(fVar12 - fVar8,fVar11 - fVar10);
        *(float *)(param_2 + 1) = fVar3 - fVar9;
        return param_2;
      }
    }
  }
  *(undefined4 *)param_2 = 0x7f7fffff;
  *(undefined4 *)((int)param_2 + 4) = 0x7f7fffff;
  *(undefined4 *)(param_2 + 1) = 0x7f7fffff;
  *(undefined4 *)((int)param_2 + 0xc) = 0xff7fffff;
  *(undefined4 *)(param_2 + 2) = 0xff7fffff;
  *(undefined4 *)((int)param_2 + 0x14) = 0xff7fffff;
  return param_2;
}



/* FUNCTION 29926 ; VA 0x00c9f800 ; FUN_00c9f800 */

void FUN_00c9f800(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,code *param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  iVar4 = (int)param_3 - (int)param_1 >> 2;
  if (iVar4 < 0x29) {
    cVar3 = (*param_4)(*param_2,*param_1);
    if (cVar3 != '\0') {
      uVar2 = *param_2;
      *param_2 = *param_1;
      *param_1 = uVar2;
    }
    cVar3 = (*param_4)(*param_3,*param_2);
    if (cVar3 != '\0') {
      uVar2 = *param_3;
      *param_3 = *param_2;
      *param_2 = uVar2;
      cVar3 = (*param_4)(uVar2,*param_1);
      if (cVar3 != '\0') {
        uVar2 = *param_2;
        *param_2 = *param_1;
        *param_1 = uVar2;
      }
    }
  }
  else {
    iVar4 = iVar4 + 1 >> 3;
    puVar1 = param_1 + iVar4;
    cVar3 = (*param_4)(param_1[iVar4]);
    if (cVar3 != '\0') {
      uVar2 = *puVar1;
      *puVar1 = *param_1;
      *param_1 = uVar2;
    }
    cVar3 = (*param_4)(param_1[iVar4 * 2],*puVar1);
    if (cVar3 != '\0') {
      uVar2 = param_1[iVar4 * 2];
      param_1[iVar4 * 2] = *puVar1;
      *puVar1 = uVar2;
      cVar3 = (*param_4)(uVar2,*param_1);
      if (cVar3 != '\0') {
        uVar2 = *puVar1;
        *puVar1 = *param_1;
        *param_1 = uVar2;
      }
    }
    puVar5 = param_2 + -iVar4;
    cVar3 = (*param_4)(*param_2,*puVar5);
    if (cVar3 != '\0') {
      uVar2 = *param_2;
      *param_2 = *puVar5;
      *puVar5 = uVar2;
    }
    cVar3 = (*param_4)(param_2[iVar4],*param_2);
    if (cVar3 != '\0') {
      uVar2 = param_2[iVar4];
      param_2[iVar4] = *param_2;
      *param_2 = uVar2;
      cVar3 = (*param_4)(uVar2,*puVar5);
      if (cVar3 != '\0') {
        uVar2 = *param_2;
        *param_2 = *puVar5;
        *puVar5 = uVar2;
      }
    }
    puVar5 = param_3 + iVar4 * -2;
    puVar6 = param_3 + -iVar4;
    cVar3 = (*param_4)(*puVar6,*puVar5);
    if (cVar3 != '\0') {
      uVar2 = *puVar6;
      *puVar6 = *puVar5;
      *puVar5 = uVar2;
    }
    cVar3 = (*param_4)(*param_3,*puVar6);
    if (cVar3 != '\0') {
      uVar2 = *param_3;
      *param_3 = *puVar6;
      *puVar6 = uVar2;
      cVar3 = (*param_4)(uVar2,*puVar5);
      if (cVar3 != '\0') {
        uVar2 = *puVar6;
        *puVar6 = *puVar5;
        *puVar5 = uVar2;
      }
    }
    cVar3 = (*param_4)(*param_2,*puVar1);
    if (cVar3 != '\0') {
      uVar2 = *param_2;
      *param_2 = *puVar1;
      *puVar1 = uVar2;
    }
    cVar3 = (*param_4)(*puVar6,*param_2);
    if (cVar3 != '\0') {
      uVar2 = *puVar6;
      *puVar6 = *param_2;
      *param_2 = uVar2;
      cVar3 = (*param_4)(uVar2,*puVar1);
      if (cVar3 != '\0') {
        uVar2 = *param_2;
        *param_2 = *puVar1;
        *puVar1 = uVar2;
        return;
      }
    }
  }
  return;
}



/* FUNCTION 29927 ; VA 0x00c9f9d0 ; FUN_00c9f9d0 */

void FUN_00c9f9d0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,code *param_4)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puStack_10;
  undefined4 *puStack_c;
  undefined4 *puStack_8;
  
  puVar4 = param_2 + ((int)param_3 - (int)param_2 >> 3);
  FUN_00c9f800(param_2,puVar4,param_3 + -1,param_4);
  puVar3 = puVar4;
  while (((param_2 < puVar3 && (cVar2 = (*param_4)(puVar3[-1],*puVar3), cVar2 == '\0')) &&
         (cVar2 = (*param_4)(*puVar3,puVar3[-1]), cVar2 == '\0'))) {
    puVar3 = puVar3 + -1;
  }
  do {
    puVar4 = puVar4 + 1;
    puVar5 = puVar4;
    puStack_10 = puVar4;
    puStack_8 = puVar4;
    puStack_c = puVar3;
    puVar8 = puVar3;
    if ((param_3 <= puVar4) || (cVar2 = (*param_4)(*puVar4,*puVar3), cVar2 != '\0')) break;
    cVar2 = (*param_4)(*puVar3,*puVar4);
  } while (cVar2 == '\0');
joined_r0x00c9fa72:
  do {
    puVar6 = puStack_c;
    if (param_3 <= puVar5) {
joined_r0x00c9fab5:
      while (puVar7 = puVar5, param_2 < puVar3) {
        puVar6 = puVar6 + -1;
        cVar2 = (*param_4)(*puVar6,*puVar8);
        puVar4 = puStack_8;
        if (cVar2 == '\0') {
          cVar2 = (*param_4)(*puVar8,*puVar6);
          puVar3 = puStack_c;
          puVar7 = puStack_10;
          if (cVar2 != '\0') break;
          puVar8 = puVar8 + -1;
          if (puVar8 != puVar6) {
            uVar1 = *puVar8;
            *puVar8 = *puVar6;
            *puVar6 = uVar1;
          }
        }
        puStack_c = puStack_c + -1;
        puVar5 = puStack_10;
        puVar3 = puStack_c;
      }
      if (puVar3 == param_2) {
        if (puVar7 == param_3) {
          *param_1 = puVar8;
          param_1[1] = puVar4;
          return;
        }
        if (puVar4 != puVar7) {
          uVar1 = *puVar8;
          *puVar8 = *puVar4;
          *puVar4 = uVar1;
        }
        puVar4 = puVar4 + 1;
        uVar1 = *puVar8;
        *puVar8 = *puVar7;
        *puVar7 = uVar1;
        puVar5 = puVar7 + 1;
        puStack_10 = puVar7 + 1;
        puStack_8 = puVar4;
        puVar8 = puVar8 + 1;
      }
      else {
        puVar3 = puVar3 + -1;
        puStack_c = puVar3;
        if (puVar7 == param_3) {
          puVar8 = puVar8 + -1;
          if (puVar3 != puVar8) {
            uVar1 = *puVar3;
            *puVar3 = *puVar8;
            *puVar8 = uVar1;
          }
          puVar5 = puVar4 + -1;
          puVar4 = puVar4 + -1;
          uVar1 = *puVar8;
          *puVar8 = *puVar5;
          *puVar4 = uVar1;
          puVar5 = puVar7;
          puStack_8 = puVar4;
        }
        else {
          uVar1 = *puVar7;
          *puVar7 = *puVar3;
          *puVar3 = uVar1;
          puVar5 = puVar7 + 1;
          puStack_10 = puVar7 + 1;
        }
      }
      goto joined_r0x00c9fa72;
    }
    cVar2 = (*param_4)(*puVar8,*puVar5);
    puVar3 = puStack_c;
    if (cVar2 == '\0') {
      cVar2 = (*param_4)(*puVar5,*puVar8);
      puStack_8 = puVar4;
      puStack_10 = puVar5;
      if (cVar2 != '\0') goto joined_r0x00c9fab5;
      if (puVar4 != puVar5) {
        uVar1 = *puVar4;
        *puVar4 = *puVar5;
        *puVar5 = uVar1;
      }
      puVar4 = puVar4 + 1;
    }
    puVar5 = puVar5 + 1;
    puStack_10 = puVar5;
    puStack_8 = puVar4;
  } while( true );
}



/* FUNCTION 29928 ; VA 0x00c9fb90 ; FUN_00c9fb90 */

void FUN_00c9fb90(int param_1,int param_2,uint param_3,undefined4 *param_4,code *param_5)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = (int)(param_3 - 1) >> 1;
  iVar4 = param_2;
  iVar3 = param_2;
  if (param_2 < iVar2) {
    do {
      iVar3 = iVar4 * 2 + 2;
      cVar1 = (*param_5)(*(undefined4 *)(param_1 + iVar3 * 4),
                         *(undefined4 *)(param_1 + 4 + iVar4 * 8));
      if (cVar1 != '\0') {
        iVar3 = iVar4 * 2 + 1;
      }
      *(undefined4 *)(param_1 + iVar4 * 4) = *(undefined4 *)(param_1 + iVar3 * 4);
      iVar4 = iVar3;
    } while (iVar3 < iVar2);
  }
  if ((iVar3 == iVar2) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar3 * 4) = *(undefined4 *)(param_1 + -4 + param_3 * 4);
    iVar3 = param_3 - 1;
  }
  while (param_2 < iVar3) {
    iVar4 = iVar3 + -1 >> 1;
    cVar1 = (*param_5)(*(undefined4 *)(param_1 + iVar4 * 4),*param_4);
    if (cVar1 == '\0') break;
    *(undefined4 *)(param_1 + iVar3 * 4) = *(undefined4 *)(param_1 + iVar4 * 4);
    iVar3 = iVar4;
  }
  *(undefined4 *)(param_1 + iVar3 * 4) = *param_4;
  return;
}



/* FUNCTION 29929 ; VA 0x00c9fc40 ; FUN_00c9fc40 */

void FUN_00c9fc40(undefined4 *param_1,undefined4 *param_2,int param_3,code *param_4)

{
  undefined4 uVar1;
  code *pcVar2;
  undefined4 *puVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  undefined4 *puStack_10;
  undefined4 *puStack_c;
  undefined4 *puStack_8;
  
  iVar5 = (int)param_2 - (int)param_1;
  puVar8 = param_1;
  puVar9 = param_2;
  puVar7 = puStack_c;
  do {
    iVar5 = iVar5 >> 2;
    if (iVar5 < 0x21) {
LAB_00c9fcd5:
      if (((1 < iVar5) && (puVar8 != puVar9)) && (puVar7 = puVar8 + 1, puVar7 != puVar9)) {
        do {
          uVar1 = *puVar7;
          puStack_10 = puVar7;
          puStack_c = (undefined4 *)uVar1;
          puStack_8 = puVar7;
          cVar4 = (*param_4)(uVar1,*puVar8);
          pcVar2 = param_4;
          if (cVar4 == '\0') {
            cVar4 = (*param_4)(puStack_c,puVar7[-1]);
            puVar3 = puStack_c;
            puVar10 = puVar7 + -1;
            puVar7 = puStack_10;
            puVar9 = puStack_8;
            while (puStack_8 = puVar10, cVar4 != '\0') {
              puVar10 = puStack_8 + -1;
              *puVar9 = *puStack_8;
              puStack_10 = puVar7;
              cVar4 = (*pcVar2)(puVar3,*puVar10);
              puVar8 = param_1;
              puVar7 = puStack_10;
              puVar9 = puStack_8;
            }
            *puVar9 = puStack_c;
          }
          else {
            FUN_0170cc70((int)puVar7 + (4 - ((int)puVar7 - (int)puVar8)),puVar8,
                         (int)puVar7 - (int)puVar8);
            *puVar8 = uVar1;
          }
          puVar7 = puVar7 + 1;
        } while (puVar7 != param_2);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar5) {
        param_2 = (undefined4 *)((int)puVar9 - (int)puVar8);
        uVar6 = (int)param_2 >> 2;
        puStack_c = (undefined4 *)((int)param_2 >> 3);
        if (0 < (int)puStack_c) {
          puStack_14 = (undefined4 *)(uVar6 - 1);
          puStack_8 = (undefined4 *)((int)puStack_14 >> 1);
          do {
            puStack_10 = (undefined4 *)puVar8[(int)puStack_c + -1];
            puVar7 = (undefined4 *)((int)puStack_c + -1);
            puVar9 = puVar7;
            puStack_c = puVar7;
            if ((int)puVar7 < (int)puStack_8) {
              do {
                puVar9 = (undefined4 *)((int)puVar7 * 2 + 2);
                cVar4 = (*param_4)(puVar8[(int)puVar9],puVar8[(int)puVar7 * 2 + 1]);
                if (cVar4 != '\0') {
                  puVar9 = (undefined4 *)((int)puVar7 * 2 + 1);
                }
                puVar8[(int)puVar7] = puVar8[(int)puVar9];
                puVar7 = puVar9;
              } while ((int)puVar9 < (int)puStack_8);
            }
            if ((puVar9 == puStack_8) && ((uVar6 & 1) == 0)) {
              puVar8[(int)puVar9] = puVar8[uVar6 - 1];
              puVar9 = puStack_14;
            }
            if ((int)puStack_c < (int)puVar9) {
              do {
                puVar7 = (undefined4 *)((int)puVar9 + -1 >> 1);
                cVar4 = (*param_4)(puVar8[(int)puVar7],puStack_10);
                if (cVar4 == '\0') break;
                puVar8[(int)puVar9] = puVar8[(int)puVar7];
                puVar9 = puVar7;
              } while ((int)puStack_c < (int)puVar7);
            }
            puVar8[(int)puVar9] = puStack_10;
            puVar7 = puStack_c;
          } while (0 < (int)puStack_c);
        }
        puStack_c = puVar7;
        iVar5 = (int)param_2;
        if ((int)uVar6 < 2) {
          return;
        }
        do {
          if (1 < (int)uVar6) {
            param_2 = *(undefined4 **)((int)puVar8 + iVar5 + -4);
            *(undefined4 *)((int)puVar8 + iVar5 + -4) = *puVar8;
            FUN_00c9fb90(puVar8,0,iVar5 + -4 >> 2,&param_2,param_4);
          }
          iVar5 = iVar5 + -4;
          uVar6 = iVar5 >> 2;
        } while (1 < (int)uVar6);
        return;
      }
      goto LAB_00c9fcd5;
    }
    puStack_c = puVar7;
    FUN_00c9f9d0(&puStack_18,puVar8,puVar9,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)puStack_18 - (int)puVar8 & 0xfffffffcU) <
        (int)((int)puVar9 - (int)puStack_14 & 0xfffffffcU)) {
      FUN_00c9fc40(puVar8,puStack_18,param_3,param_4);
      param_1 = puStack_14;
      puVar8 = puStack_14;
    }
    else {
      FUN_00c9fc40(puStack_14,puVar9,param_3,param_4);
      param_2 = puStack_18;
      puVar9 = puStack_18;
    }
    iVar5 = (int)puVar9 - (int)puVar8;
    puVar7 = puStack_c;
  } while( true );
}



/* FUNCTION 29930 ; VA 0x00c9fea0 ; FUN_00c9fea0 */

void FUN_00c9fea0(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (param_3 != 0) {
    if ((param_3 != 1) || (*(int *)(param_2 + 0x1b0) == 0)) goto LAB_00c9fedd;
    iVar2 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))();
    if (iVar2 == 10) goto LAB_00c9fedd;
  }
  FUN_00ca1ae0(param_2,0);
LAB_00c9fedd:
  iVar2 = 0;
  if (0 < *(int *)(param_2 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_2 + 0x10) + iVar2 * 4);
      uVar3 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      if (((uVar3 == 0) || (*(int *)(uVar3 + 0x20) == 0)) ||
         (iVar1 = *(int *)(*(int *)(uVar3 + 0x20) + 0x18), (iVar1 - 8U & -(uint)(iVar1 != 0)) == 0))
      {
        FUN_00c9fea0(param_1,uVar3,param_3);
      }
      iVar2 = iVar2 + 1;
    } while (iVar2 < *(int *)(param_2 + 0x14));
  }
  return;
}



/* FUNCTION 29931 ; VA 0x00c9ff30 ; FUN_00c9ff30 */

void FUN_00c9ff30(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  iVar3 = param_3;
  if (((param_3 == 0) ||
      (((param_3 == 1 && (*(int *)(param_2 + 0x1b0) != 0)) &&
       (iVar4 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))(), iVar4 != 10)))) &&
     ((*(int *)(param_2 + 0x1b0) != 0 &&
      (iVar4 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))(), iVar4 != 10)))) {
    param_3 = FUN_00c16450();
    piVar1 = *(int **)(param_1 + 4);
    if (*(int **)(param_1 + 8) == piVar1) {
      FUN_006030d0(piVar1,&param_3);
    }
    else {
      *piVar1 = param_3;
      *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
    }
  }
  iVar4 = 0;
  if (0 < *(int *)(param_2 + 0x14)) {
    do {
      iVar2 = *(int *)(*(int *)(param_2 + 0x10) + iVar4 * 4);
      uVar5 = -(uint)(iVar2 != 0) & iVar2 - 8U;
      if (((uVar5 == 0) || (*(int *)(uVar5 + 0x20) == 0)) ||
         (iVar2 = *(int *)(*(int *)(uVar5 + 0x20) + 0x18), (iVar2 - 8U & -(uint)(iVar2 != 0)) == 0))
      {
        FUN_00c9ff30(param_1,uVar5,iVar3);
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < *(int *)(param_2 + 0x14));
  }
  return;
}



/* FUNCTION 29932 ; VA 0x00ca0000 ; FUN_00ca0000 */

void FUN_00ca0000(undefined4 param_1,undefined4 param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (param_4 != 0) {
    if ((param_4 != 1) || (*(int *)(param_3 + 0x1b0) == 0)) goto LAB_00ca003b;
    iVar2 = (**(code **)(**(int **)(param_3 + 0x1ac) + 8))();
    if (iVar2 == 10) goto LAB_00ca003b;
  }
  FUN_00ca06b0(param_3);
LAB_00ca003b:
  iVar2 = 0;
  if (0 < *(int *)(param_3 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_3 + 0x10) + iVar2 * 4);
      uVar3 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      if (((uVar3 == 0) || (*(int *)(uVar3 + 0x20) == 0)) ||
         (iVar1 = *(int *)(*(int *)(uVar3 + 0x20) + 0x18), (iVar1 - 8U & -(uint)(iVar1 != 0)) == 0))
      {
        FUN_00ca0000(param_1,param_2,uVar3,param_4);
      }
      iVar2 = iVar2 + 1;
    } while (iVar2 < *(int *)(param_3 + 0x14));
  }
  return;
}



/* FUNCTION 29933 ; VA 0x00ca0090 ; FUN_00ca0090 */

void FUN_00ca0090(char *param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  
  if (param_3 != 0) {
    if ((param_3 != 1) || (*(int *)(param_2 + 0x1b0) == 0)) goto LAB_00ca00ed;
    iVar2 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))();
    if (iVar2 == 10) goto LAB_00ca00ed;
  }
  if (((*param_1 == '\0') && (*(char *)(param_2 + 0x226) == '\0')) &&
     ((*(char *)(param_2 + 0x222) != '\0' || (*(char *)(param_2 + 0x225) != '\0')))) {
    cVar3 = '\0';
  }
  else {
    cVar3 = '\x01';
  }
  *param_1 = cVar3;
LAB_00ca00ed:
  iVar2 = 0;
  if (0 < *(int *)(param_2 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_2 + 0x10) + iVar2 * 4);
      uVar4 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      if (((uVar4 == 0) || (*(int *)(uVar4 + 0x20) == 0)) ||
         (iVar1 = *(int *)(*(int *)(uVar4 + 0x20) + 0x18), (iVar1 - 8U & -(uint)(iVar1 != 0)) == 0))
      {
        FUN_00ca0090(param_1,uVar4,param_3);
      }
      iVar2 = iVar2 + 1;
    } while (iVar2 < *(int *)(param_2 + 0x14));
  }
  return;
}



/* FUNCTION 29934 ; VA 0x00ca0140 ; FUN_00ca0140 */

void FUN_00ca0140(float *param_1,float *param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  float fVar4;
  double dVar5;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  
  if ((param_4 == 0) ||
     (((param_4 == 1 && (*(int *)(param_3 + 0x1b0) != 0)) &&
      (iVar2 = (**(code **)(**(int **)(param_3 + 0x1ac) + 8))(), iVar2 != 10)))) {
    uVar3 = -(uint)(param_3 != 0) & param_3 + 0x50U;
    FUN_00fa07b0();
    fStack_1c = *(float *)(uVar3 + 0xdc) - param_1[1];
    fStack_18 = *(float *)(uVar3 + 0xe0) - param_1[2];
    fStack_20 = *(float *)(uVar3 + 0xd8) - *param_1;
    FUN_00c95760(&fStack_14,&fStack_20);
    iVar2 = *(int *)(param_3 + 0x1ac);
    fStack_10 = *(float *)(iVar2 + 8) * DAT_018ce2f4 + fStack_10;
    fStack_14 = *(float *)(iVar2 + 4) * DAT_018ce2f4 + fStack_14;
    fStack_c = *(float *)(iVar2 + 0xc) * DAT_018ce2f4 + fStack_c;
    dVar5 = (double)(fStack_10 * fStack_10 + fStack_14 * fStack_14 + fStack_c * fStack_c);
    FUN_017267a0();
    fVar4 = (float)dVar5;
    if ((float)dVar5 <= *param_2) {
      fVar4 = *param_2;
    }
    *param_2 = fVar4;
  }
  iVar2 = 0;
  if (0 < *(int *)(param_3 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_3 + 0x10) + iVar2 * 4);
      uVar3 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      if (((uVar3 == 0) || (*(int *)(uVar3 + 0x20) == 0)) ||
         (iVar1 = *(int *)(*(int *)(uVar3 + 0x20) + 0x18), (iVar1 - 8U & -(uint)(iVar1 != 0)) == 0))
      {
        FUN_00ca0140(param_1,param_2,uVar3,param_4);
      }
      iVar2 = iVar2 + 1;
    } while (iVar2 < *(int *)(param_3 + 0x14));
  }
  return;
}



/* FUNCTION 29935 ; VA 0x00ca02b0 ; FUN_00ca02b0 */

void FUN_00ca02b0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar5 = param_3;
  iVar3 = param_2;
  if ((param_3 == 0) ||
     (((param_3 == 1 && (*(int *)(param_2 + 0x1b0) != 0)) &&
      (iVar4 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))(), iVar4 != 10)))) {
    iVar4 = FUN_00c15a50();
    iVar5 = param_3;
    while (param_3 = iVar5, iVar4 != 0) {
      iVar5 = *(int *)(iVar4 + 0x2c);
      if (iVar3 == iVar5) {
        iVar5 = *(int *)(iVar4 + 0x30);
      }
      param_2 = iVar4;
      if ((iVar5 != 0) && (iVar5 = FUN_00c155c0(), iVar5 != param_1)) {
        piVar1 = *(int **)(param_1 + 0x8c);
        if (*(int **)(param_1 + 0x90) == piVar1) {
          FUN_0063d9b0(piVar1,&param_2);
          iVar4 = param_2;
        }
        else {
          *piVar1 = iVar4;
          *(int *)(param_1 + 0x8c) = *(int *)(param_1 + 0x8c) + 4;
        }
      }
      iVar4 = FUN_00c16250(iVar4);
      iVar5 = param_3;
    }
    param_2 = 0;
  }
  iVar4 = 0;
  if (0 < *(int *)(iVar3 + 0x14)) {
    do {
      iVar2 = *(int *)(*(int *)(iVar3 + 0x10) + iVar4 * 4);
      uVar6 = -(uint)(iVar2 != 0) & iVar2 - 8U;
      if (((uVar6 == 0) || (*(int *)(uVar6 + 0x20) == 0)) ||
         (iVar2 = *(int *)(*(int *)(uVar6 + 0x20) + 0x18), (iVar2 - 8U & -(uint)(iVar2 != 0)) == 0))
      {
        FUN_00ca02b0(param_1,uVar6,iVar5);
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < *(int *)(iVar3 + 0x14));
  }
  return;
}



/* FUNCTION 29936 ; VA 0x00ca03a0 ; FUN_00ca03a0 */

undefined4 * __fastcall FUN_00ca03a0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0181092c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::IPipelined::vftable;
  param_1[1] = 0;
  uStack_8 = 0;
  FUN_01078820();
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  *param_1 = RBX::Assembly::vftable;
  param_1[2] = RBX::Assembly::vftable;
  param_1[0xd] = 0x1010000;
  *(undefined2 *)(param_1 + 0xe) = 0x100;
  *(undefined *)((int)param_1 + 0x3a) = 0;
  param_1[0xf] = 0xc;
  param_1[0x10] = 0;
  param_1[0x11] = 0xffffffff;
  param_1[0x12] = 0xffffffff;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0xffffffff;
  param_1[0x1c] = 0xffffffff;
  param_1[0x1d] = 0xffffffff;
  *(undefined *)(param_1 + 0x1e) = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x25] = 0;
  *(undefined2 *)(param_1 + 0x28) = 0;
  *(undefined *)(param_1 + 0x2a) = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29937 ; VA 0x00ca04f0 ; FUN_00ca04f0 */

void __fastcall FUN_00ca04f0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[0x19];
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Assembly::vftable;
  param_1[2] = RBX::Assembly::vftable;
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 0x7c);
    if (iVar2 != 0) {
      uVar4 = (*(int *)(iVar1 + 0x84) - iVar2 >> 2) * 4;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00ca06aa;
      }
      FUN_01674ea0(iVar3,uVar4);
      *(undefined4 *)(iVar1 + 0x7c) = 0;
      *(undefined4 *)(iVar1 + 0x80) = 0;
      *(undefined4 *)(iVar1 + 0x84) = 0;
    }
    FUN_01674ea0(iVar1,0x88);
  }
  if ((int *)param_1[0x18] != (int *)0x0) {
    (**(code **)(*(int *)param_1[0x18] + 8))(1);
  }
  if ((int *)param_1[0x17] != (int *)0x0) {
    (**(code **)(*(int *)param_1[0x17] + 0xc))(1);
  }
  uStack_8 = 0;
  FUN_01674ea0(param_1[0x25]);
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  iVar1 = param_1[0x22];
  if (iVar1 != 0) {
    uVar4 = param_1[0x24] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00ca06aa;
    }
    FUN_01674ea0(iVar2,uVar4);
    param_1[0x22] = 0;
    param_1[0x23] = 0;
    param_1[0x24] = 0;
  }
  iVar1 = param_1[0x1f];
  if (iVar1 != 0) {
    uVar4 = param_1[0x21] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00ca06aa:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
    param_1[0x1f] = 0;
    param_1[0x20] = 0;
    param_1[0x21] = 0;
  }
  FUN_01078870();
  *param_1 = RBX::IPipelined::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29938 ; VA 0x00ca06b0 ; FUN_00ca06b0 */

void __fastcall FUN_00ca06b0(int *param_1)

{
  float fVar1;
  int iVar2;
  char cVar3;
  float *pfVar4;
  undefined4 *puVar5;
  float fVar6;
  float fVar7;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  undefined4 *puStack_8;
  
  pfVar4 = (float *)FUN_00c15960();
  iVar2 = *param_1;
  fVar7 = *(float *)(iVar2 + 0xc);
  if (pfVar4[2] <= *(float *)(iVar2 + 0xc)) {
    fVar7 = pfVar4[2];
  }
  fVar6 = *(float *)(iVar2 + 8);
  if (pfVar4[1] <= *(float *)(iVar2 + 8)) {
    fVar6 = pfVar4[1];
  }
  fVar1 = *(float *)(iVar2 + 4);
  if (*pfVar4 <= *(float *)(iVar2 + 4)) {
    fVar1 = *pfVar4;
  }
  *(ulonglong *)(iVar2 + 4) = CONCAT44(fVar6,fVar1);
  *(float *)(iVar2 + 0xc) = fVar7;
  fVar7 = *(float *)(iVar2 + 0x18);
  if (*(float *)(iVar2 + 0x18) <= pfVar4[5]) {
    fVar7 = pfVar4[5];
  }
  fVar6 = *(float *)(iVar2 + 0x14);
  if (*(float *)(iVar2 + 0x14) <= pfVar4[4]) {
    fVar6 = pfVar4[4];
  }
  fVar1 = *(float *)(iVar2 + 0x10);
  if (*(float *)(iVar2 + 0x10) <= pfVar4[3]) {
    fVar1 = pfVar4[3];
  }
  *(ulonglong *)(iVar2 + 0x10) = CONCAT44(fVar6,fVar1);
  _fStack_10 = CONCAT44(fVar7,fStack_10);
  *(float *)(iVar2 + 0x18) = fVar7;
  iVar2 = *(int *)param_1[1];
  if (*(char *)(iVar2 + 0x34) != '\0') {
    puVar5 = *(undefined4 **)(iVar2 + 0x60);
    if (puVar5 == (undefined4 *)0x0) {
      puStack_8 = (undefined4 *)FUN_01674e20(0x14);
      if (puStack_8 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        puStack_8[1] = 0xffffffff;
        puStack_8[2] = 0;
        puStack_8[3] = 0;
        *puStack_8 = RBX::AssemblyMidPhaseBinding::vftable;
        puStack_8[4] = iVar2;
        puVar5 = puStack_8;
      }
      *(undefined4 **)(iVar2 + 0x60) = puVar5;
    }
    cVar3 = (**(code **)*puVar5)();
    if (cVar3 != '\0') {
      fVar7 = (float)DAT_01d68adc / DAT_018ce320;
      fStack_20 = *pfVar4 - fVar7;
      fStack_1c = pfVar4[1] - fVar7;
      fStack_18 = pfVar4[2] - fVar7;
      fStack_14 = fVar7 + pfVar4[3];
      fStack_10 = (float)*(undefined8 *)(pfVar4 + 4);
      fStack_c = (float)((ulonglong)*(undefined8 *)(pfVar4 + 4) >> 0x20);
      _fStack_10 = CONCAT44(fVar7 + fStack_c,fVar7 + fStack_10);
      FUN_00c16450();
      cVar3 = FUN_01090e50(&fStack_20);
      if (cVar3 == '\0') {
        *(undefined *)(*param_1 + 1) = 1;
      }
    }
  }
  return;
}



/* FUNCTION 29939 ; VA 0x00ca0847 ; FUN_00ca0847 */

void FUN_00ca0847(void)

{
  FUN_00ca0850();
  return;
}



/* FUNCTION 29940 ; VA 0x00ca0850 ; FUN_00ca0850 */

undefined4 __thiscall FUN_00ca0850(undefined4 param_1,byte param_2)

{
  FUN_00ca04f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xac);
  }
  return param_1;
}



/* FUNCTION 29941 ; VA 0x00ca0880 ; FUN_00ca0880 */

undefined4 * __thiscall FUN_00ca0880(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Collision::BroadPhaseColliderBinding::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 29942 ; VA 0x00ca08b0 ; FUN_00ca08b0 */

undefined4 * __thiscall FUN_00ca08b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Collision::MidPhaseCollectionBinding::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 29943 ; VA 0x00ca08e0 ; FUN_00ca08e0 */

undefined4 * __thiscall FUN_00ca08e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Collision::BroadPhaseColliderBinding::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 29944 ; VA 0x00ca0910 ; FUN_00ca0910 */

undefined4 * __thiscall FUN_00ca0910(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Collision::MidPhaseCollectionBinding::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 29945 ; VA 0x00ca0940 ; FUN_00ca0940 */

void __thiscall FUN_00ca0940(int param_1,int param_2)

{
  int *piVar1;
  
  if (*(int *)(param_2 + 0x3c) == -1) {
    *(int *)(param_2 + 0x3c) = *(int *)(param_1 + 0x80) - *(int *)(param_1 + 0x7c) >> 2;
    piVar1 = *(int **)(param_1 + 0x80);
    if (*(int **)(param_1 + 0x84) != piVar1) {
      *piVar1 = param_2;
      *(int *)(param_1 + 0x80) = *(int *)(param_1 + 0x80) + 4;
      return;
    }
    FUN_0063d9b0(piVar1,&param_2);
  }
  return;
}



/* FUNCTION 29946 ; VA 0x00ca0980 ; FUN_00ca0980 */

undefined4 FUN_00ca0980(int *param_1)

{
  undefined4 uVar1;
  
  if (*(char *)(param_1 + 8) != '\0') {
switchD_00ca0999_caseD_c:
    return 1;
  }
  uVar1 = (**(code **)(*param_1 + 0x10))();
  switch(uVar1) {
  case 0xc:
  case 0xd:
  case 0xf:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x14:
  case 0x15:
  case 0x16:
    goto switchD_00ca0999_caseD_c;
  default:
    return 0;
  }
}



/* FUNCTION 29947 ; VA 0x00ca09e0 ; FUN_00ca09e0 */

undefined FUN_00ca09e0(uint *param_1)

{
  undefined uVar1;
  int iVar2;
  undefined uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar3 = 0;
  uVar5 = 0;
  uVar4 = (param_1[1] - *param_1) + 3 >> 2;
  if (param_1[1] < *param_1) {
    uVar4 = 0;
  }
  uVar1 = 0;
  if (uVar4 != 0) {
    do {
      uVar3 = uVar1;
      iVar2 = FUN_00c155c0();
      if (0 < *(int *)(iVar2 + 0x50)) {
        uVar3 = 1;
        *(undefined4 *)(iVar2 + 0x50) = 0;
      }
      uVar5 = uVar5 + 1;
      uVar1 = uVar3;
    } while (uVar5 != uVar4);
  }
  return uVar3;
}



/* FUNCTION 29948 ; VA 0x00ca0a40 ; FUN_00ca0a40 */

bool FUN_00ca0a40(float *param_1,float *param_2,int param_3)

{
  float *pfVar1;
  float10 extraout_ST0;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  undefined auStack_c4 [68];
  float fStack_80;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  
  fVar2 = *(float *)(param_3 + 0x24);
  fVar3 = *(float *)(param_3 + 0x28);
  fVar4 = *(float *)(param_3 + 0x2c);
  fStack_14 = param_1[1] * fVar3 + fVar2 * *param_1 + param_1[2] * fVar4 + param_1[9];
  fStack_18 = param_1[3] * fVar2 + param_1[4] * fVar3 + param_1[5] * fVar4 + param_1[10];
  fStack_1c = param_1[6] * fVar2 + param_1[7] * fVar3 + param_1[8] * fVar4 + param_1[0xb];
  pfVar1 = (float *)FUN_01160c20(auStack_c4,param_3);
  fStack_80 = pfVar1[8];
  fStack_2c = param_2[3] - fStack_14;
  fVar4 = param_2[2] - fStack_1c;
  fStack_28 = param_2[1] - fStack_18;
  fVar3 = *param_2 - fStack_14;
  fVar2 = param_2[5] - fStack_1c;
  fStack_60 = pfVar1[1];
  fStack_3c = pfVar1[3];
  fStack_30 = (float)DAT_01d68ae4 / DAT_018ce320;
  fStack_14 = param_2[4] - fStack_18;
  fStack_58 = pfVar1[1];
  fStack_24 = (fStack_3c * fStack_28 + fVar3 * *pfVar1 + fVar4 * pfVar1[6]) - *param_2;
  fStack_70 = pfVar1[5];
  fStack_20 = (pfVar1[4] * fStack_28 + fVar3 * fStack_60 + pfVar1[7] * fVar4) - param_2[1];
  fVar3 = (fStack_70 * fStack_28 + fVar3 * pfVar1[2] + fStack_80 * fVar4) - param_2[2];
  fStack_4c = pfVar1[5];
  fStack_48 = pfVar1[6];
  fStack_44 = pfVar1[7];
  fStack_40 = (fStack_3c * fStack_14 + *pfVar1 * fStack_2c + pfVar1[6] * fVar2) - param_2[3];
  fStack_50 = pfVar1[4] * fStack_14 + fStack_60 * fStack_2c + pfVar1[7] * fVar2;
  fVar5 = (fStack_70 * fStack_14 + pfVar1[2] * fStack_2c + fStack_80 * fVar2) - param_2[5];
  fStack_6c = fStack_70;
  fStack_68 = fStack_70;
  fStack_64 = fStack_70;
  fStack_5c = fStack_60;
  fStack_54 = fStack_58;
  fStack_38 = fStack_3c;
  fStack_34 = fStack_3c;
  fStack_1c = fVar4;
  fStack_18 = fVar2;
  FUN_01729cd8((fStack_50 - param_2[4]) * (fStack_50 - param_2[4]) + fStack_40 * fStack_40 +
               fVar5 * fVar5,fStack_20 * fStack_20 + fStack_24 * fStack_24 + fVar3 * fVar3);
  return fStack_30 * fStack_30 < (float)extraout_ST0;
}



/* FUNCTION 29949 ; VA 0x00ca0d40 ; FUN_00ca0d40 */

undefined __fastcall FUN_00ca0d40(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  char cVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined auStack_40 [48];
  int iStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  piVar2 = *(int **)(param_1 + 0x5c);
  iStack_10 = FUN_00ca1600();
  iVar1 = *(int *)((-(uint)(iVar1 != 0) & iVar1 - 8U) + 0x1a8);
  uStack_c = FUN_00c157b0();
  uVar8 = (**(code **)(*piVar2 + 4))();
  iVar6 = iStack_10;
  if (*(char *)(iStack_10 + 1) == '\0') {
    cVar7 = FUN_00ca0a40(iStack_10 + 0x4c,uVar8,uStack_c);
    if (cVar7 == '\0') {
      return 0;
    }
  }
  uStack_5 = 1;
  if ((DAT_01d67c98 != '\0') && (iVar1 != 0)) {
    if (*(char *)(iVar6 + 1) == '\0') {
      *(int *)(iVar1 + 0x48) = *(int *)(iVar1 + 0x48) + 1;
    }
    else {
      *(int *)(iVar1 + 0x44) = *(int *)(iVar1 + 0x44) + 1;
    }
  }
  puVar9 = (undefined4 *)FUN_0071fcc0(auStack_40);
  uVar8 = puVar9[1];
  uVar3 = puVar9[2];
  uVar4 = puVar9[3];
  *(undefined4 *)(iVar6 + 0x4c) = *puVar9;
  *(undefined4 *)(iVar6 + 0x50) = uVar8;
  *(undefined4 *)(iVar6 + 0x54) = uVar3;
  *(undefined4 *)(iVar6 + 0x58) = uVar4;
  uVar8 = puVar9[5];
  uVar3 = puVar9[6];
  uVar4 = puVar9[7];
  *(undefined4 *)(iVar6 + 0x5c) = puVar9[4];
  *(undefined4 *)(iVar6 + 0x60) = uVar8;
  *(undefined4 *)(iVar6 + 100) = uVar3;
  *(undefined4 *)(iVar6 + 0x68) = uVar4;
  uVar8 = puVar9[8];
  uVar3 = puVar9[9];
  uVar4 = puVar9[10];
  uVar5 = puVar9[0xb];
  *(undefined *)(iVar6 + 1) = 0;
  *(undefined4 *)(iVar6 + 0x6c) = uVar8;
  *(undefined4 *)(iVar6 + 0x70) = uVar3;
  *(undefined4 *)(iVar6 + 0x74) = uVar4;
  *(undefined4 *)(iVar6 + 0x78) = uVar5;
  return uStack_5;
}



/* FUNCTION 29950 ; VA 0x00ca0df0 ; FUN_00ca0df0 */

void FUN_00ca0df0(void)

{
  FUN_00cdfbc0();
  return;
}



/* FUNCTION 29951 ; VA 0x00ca0e10 ; FUN_00ca0e10 */

void __fastcall FUN_00ca0e10(int param_1)

{
  int iVar1;
  undefined auStack_14 [12];
  undefined4 uStack_8;
  
  FUN_00f9fa40(auStack_14);
  uStack_8 = 0;
  iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  FUN_00ca0140(auStack_14,&uStack_8,-(uint)(iVar1 != 0) & iVar1 - 8U,0);
  *(undefined4 *)(param_1 + 0xa4) = uStack_8;
  *(undefined *)(param_1 + 0xa8) = 0;
  return;
}



/* FUNCTION 29952 ; VA 0x00ca0e80 ; FUN_00ca0e80 */

undefined4 FUN_00ca0e80(void)

{
  char cVar1;
  
  cVar1 = FUN_00c15650();
  if ((cVar1 != '\0') && (cVar1 = FUN_00c15650(), cVar1 != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 29953 ; VA 0x00ca0f00 ; FUN_00ca0f00 */

void __fastcall FUN_00ca0f00(uint param_1)

{
  int iVar1;
  undefined4 uStack_8;
  
  uStack_8 = param_1 & 0xffffff;
  iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  FUN_00ca0090((int)&uStack_8 + 3,-(uint)(iVar1 != 0) & iVar1 - 8U,0);
  *(undefined *)(param_1 + 0x37) = uStack_8._3_1_;
  return;
}



/* FUNCTION 29954 ; VA 0x00ca0f40 ; FUN_00ca0f40 */

bool __fastcall FUN_00ca0f40(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  iVar1 = FUN_00ca3ed0(-(uint)(iVar1 != 0) & iVar1 - 8U,0);
  return iVar1 != 0;
}



/* FUNCTION 29955 ; VA 0x00ca0f60 ; FUN_00ca0f60 */

bool FUN_00ca0f60(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00ca3ed0(param_1,0);
  return iVar1 != 0;
}



/* FUNCTION 29956 ; VA 0x00ca0f80 ; FUN_00ca0f80 */

void __fastcall FUN_00ca0f80(undefined4 param_1)

{
  undefined4 uVar1;
  
  FUN_00ca1600();
  uVar1 = FUN_00c157b0();
  FUN_00ca2290(uVar1,param_1);
  return;
}



/* FUNCTION 29957 ; VA 0x00ca0fb0 ; FUN_00ca0fb0 */

void FUN_00ca0fb0(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  bool bVar4;
  char cVar5;
  undefined4 uVar6;
  int *piVar7;
  
  if (*(char *)(param_1 + 0x36) != '\0') {
    *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(param_1 + 0x88);
    iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
    FUN_00ca02b0(param_1,-(uint)(iVar1 != 0) & iVar1 - 8U,0);
    *(undefined *)(param_1 + 0x36) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x8c);
  piVar7 = *(int **)(param_1 + 0x88);
  while( true ) {
    if (piVar7 == piVar2) {
      return;
    }
    piVar3 = (int *)*piVar7;
    if (*(char *)(piVar3 + 8) != '\0') break;
    uVar6 = (**(code **)(*piVar3 + 0x10))();
    switch(uVar6) {
    case 0xc:
    case 0xd:
    case 0xf:
    case 0x10:
    case 0x11:
    case 0x12:
    case 0x14:
    case 0x15:
    case 0x16:
      goto switchD_00ca101e_caseD_c;
    default:
switchD_00ca101e_caseD_e:
      piVar7 = piVar7 + 1;
    }
  }
switchD_00ca101e_caseD_c:
  iVar1 = piVar3[0xc];
  if ((*(char *)(piVar3[0xb] + 0x223) == '\0') && (cVar5 = FUN_00c14800(), cVar5 == '\0')) {
    bVar4 = false;
  }
  else {
    bVar4 = true;
  }
  if ((*(char *)(iVar1 + 0x223) != '\0') || (cVar5 = FUN_00c14800(), cVar5 != '\0')) {
    cVar5 = '\x01';
  }
  if ((bVar4) || (cVar5 != '\0')) {
    *(int *)(param_2 + 0x50) = *(int *)(param_2 + 0x50) + 1;
  }
  goto switchD_00ca101e_caseD_e;
}



/* FUNCTION 29958 ; VA 0x00ca1090 ; FUN_00ca1090 */

void FUN_00ca1090(void)

{
  undefined4 *puVar1;
  int iVar2;
  undefined auStack_70 [48];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  FUN_00c157b0();
  puVar1 = (undefined4 *)FUN_0071fcc0(auStack_70);
  uStack_20 = *puVar1;
  uStack_1c = puVar1[1];
  uStack_18 = puVar1[2];
  uStack_14 = puVar1[3];
  uStack_30 = puVar1[4];
  uStack_2c = puVar1[5];
  uStack_28 = puVar1[6];
  uStack_24 = puVar1[7];
  uStack_40 = puVar1[8];
  uStack_3c = puVar1[9];
  uStack_38 = puVar1[10];
  uStack_34 = puVar1[0xb];
  iVar2 = FUN_00ca1600();
  *(undefined4 *)(iVar2 + 0x4c) = uStack_20;
  *(undefined4 *)(iVar2 + 0x50) = uStack_1c;
  *(undefined4 *)(iVar2 + 0x54) = uStack_18;
  *(undefined4 *)(iVar2 + 0x58) = uStack_14;
  *(undefined4 *)(iVar2 + 0x5c) = uStack_30;
  *(undefined4 *)(iVar2 + 0x60) = uStack_2c;
  *(undefined4 *)(iVar2 + 100) = uStack_28;
  *(undefined4 *)(iVar2 + 0x68) = uStack_24;
  *(undefined4 *)(iVar2 + 0x6c) = uStack_40;
  *(undefined4 *)(iVar2 + 0x70) = uStack_3c;
  *(undefined4 *)(iVar2 + 0x74) = uStack_38;
  *(undefined4 *)(iVar2 + 0x78) = uStack_34;
  return;
}



/* FUNCTION 29959 ; VA 0x00ca1110 ; FUN_00ca1110 */

void __thiscall FUN_00ca1110(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  
  puVar5 = (undefined4 *)FUN_00c157b0();
  uVar2 = puVar5[1];
  uVar3 = puVar5[2];
  uVar4 = puVar5[3];
  *param_2 = *puVar5;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  uVar2 = puVar5[5];
  uVar3 = puVar5[6];
  uVar4 = puVar5[7];
  param_2[4] = puVar5[4];
  param_2[5] = uVar2;
  param_2[6] = uVar3;
  param_2[7] = uVar4;
  uVar2 = puVar5[9];
  uVar3 = puVar5[10];
  uVar4 = puVar5[0xb];
  param_2[8] = puVar5[8];
  param_2[9] = uVar2;
  param_2[10] = uVar3;
  param_2[0xb] = uVar4;
  iVar1 = *(int *)(*(int *)(*(int *)(param_1 + 0x10) + 0x24) + 0x1c);
  FUN_00c9ff30(param_3,-(uint)(iVar1 != 0) & iVar1 - 8U,0);
  return;
}



/* FUNCTION 29960 ; VA 0x00ca1170 ; FUN_00ca1170 */

void __thiscall FUN_00ca1170(int param_1,undefined4 *param_2,undefined4 param_3,undefined *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_70 [48];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  iVar4 = *(int *)(*(int *)(*(int *)(param_1 + 8) + 0x24) + 0x1c);
  iVar4 = FUN_00ca3ed0(-(uint)(iVar4 != 0) & iVar4 - 8U,0);
  *(bool *)param_3 = iVar4 != 0;
  iVar4 = FUN_00ca1600();
  FUN_00ca1260(*(undefined4 *)(param_1 + 8));
  uVar1 = *(undefined4 *)(iVar4 + 8);
  uVar2 = *(undefined4 *)(iVar4 + 0xc);
  uVar3 = *(undefined4 *)(iVar4 + 0x10);
  *param_2 = *(undefined4 *)(iVar4 + 4);
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(iVar4 + 0x14);
  FUN_00c157b0();
  puVar5 = (undefined4 *)FUN_0071fcc0(auStack_70);
  uStack_20 = *puVar5;
  uStack_1c = puVar5[1];
  uStack_18 = puVar5[2];
  uStack_14 = puVar5[3];
  uStack_30 = puVar5[4];
  uStack_2c = puVar5[5];
  uStack_28 = puVar5[6];
  uStack_24 = puVar5[7];
  uStack_40 = puVar5[8];
  uStack_3c = puVar5[9];
  uStack_38 = puVar5[10];
  uStack_34 = puVar5[0xb];
  iVar4 = FUN_00ca1600();
  *(undefined4 *)(iVar4 + 0x4c) = uStack_20;
  *(undefined4 *)(iVar4 + 0x50) = uStack_1c;
  *(undefined4 *)(iVar4 + 0x54) = uStack_18;
  *(undefined4 *)(iVar4 + 0x58) = uStack_14;
  *(undefined4 *)(iVar4 + 0x5c) = uStack_30;
  *(undefined4 *)(iVar4 + 0x60) = uStack_2c;
  *(undefined4 *)(iVar4 + 100) = uStack_28;
  *(undefined4 *)(iVar4 + 0x68) = uStack_24;
  *(undefined4 *)(iVar4 + 0x6c) = uStack_40;
  *(undefined4 *)(iVar4 + 0x70) = uStack_3c;
  *(undefined4 *)(iVar4 + 0x74) = uStack_38;
  *(undefined4 *)(iVar4 + 0x78) = uStack_34;
  if ((DAT_01d69068 != '\0') && (DAT_01d69098 != '\0')) {
    *param_4 = *(undefined *)(*(int *)(param_1 + 8) + 0x37);
  }
  return;
}



/* FUNCTION 29961 ; VA 0x00ca1260 ; FUN_00ca1260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00ca1260(char *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  
  uVar5 = _UNK_018c4ebc;
  uVar4 = _UNK_018c4eb8;
  uVar3 = _UNK_018c4eb4;
  uVar2 = DAT_018c45d0;
  if (*param_1 != '\0') {
    *(undefined4 *)(param_1 + 4) = _DAT_018c4eb0;
    *(undefined4 *)(param_1 + 8) = uVar3;
    *(undefined4 *)(param_1 + 0xc) = uVar4;
    *(undefined4 *)(param_1 + 0x10) = uVar5;
    *(ulonglong *)(param_1 + 0x14) = CONCAT44(uVar2,uVar2);
    puVar6 = (undefined4 *)FUN_00c157b0();
    uVar2 = puVar6[1];
    uVar3 = puVar6[2];
    uVar4 = puVar6[3];
    *(undefined4 *)(param_1 + 0x1c) = *puVar6;
    *(undefined4 *)(param_1 + 0x20) = uVar2;
    *(undefined4 *)(param_1 + 0x24) = uVar3;
    *(undefined4 *)(param_1 + 0x28) = uVar4;
    uVar2 = puVar6[5];
    uVar3 = puVar6[6];
    uVar4 = puVar6[7];
    *(undefined4 *)(param_1 + 0x2c) = puVar6[4];
    *(undefined4 *)(param_1 + 0x30) = uVar2;
    *(undefined4 *)(param_1 + 0x34) = uVar3;
    *(undefined4 *)(param_1 + 0x38) = uVar4;
    uVar2 = puVar6[9];
    uVar3 = puVar6[10];
    uVar4 = puVar6[0xb];
    *(undefined4 *)(param_1 + 0x3c) = puVar6[8];
    *(undefined4 *)(param_1 + 0x40) = uVar2;
    *(undefined4 *)(param_1 + 0x44) = uVar3;
    *(undefined4 *)(param_1 + 0x48) = uVar4;
    iVar1 = *(int *)(*(int *)(param_2 + 0x24) + 0x1c);
    FUN_00ca0000(param_1,&param_2,-(uint)(iVar1 != 0) & iVar1 - 8U,1);
    *param_1 = '\0';
  }
  return;
}



/* FUNCTION 29962 ; VA 0x00ca12e0 ; FUN_00ca12e0 */

undefined4 __fastcall FUN_00ca12e0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x24);
}



/* FUNCTION 29963 ; VA 0x00ca12f0 ; FUN_00ca12f0 */

float * __thiscall FUN_00ca12f0(int param_1,float *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  float fVar4;
  float fVar5;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  undefined auStack_24 [8];
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  int iStack_c;
  float fStack_8;
  
  iStack_c = param_1;
  if (*(char *)(param_1 + 0xa8) != '\0') {
    FUN_00f9fa40(auStack_24);
    fStack_8 = 0.0;
    iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
    FUN_00ca0140(auStack_24,&fStack_8,-(uint)(iVar1 != 0) & iVar1 - 8U,0);
    *(float *)(param_1 + 0xa4) = fStack_8;
    *(undefined *)(param_1 + 0xa8) = 0;
  }
  fStack_8 = *(float *)(param_1 + 0xa4);
  FUN_00f9fa40(&fStack_18);
  fStack_1c = fStack_10 - fStack_8;
  *(ulonglong *)(param_2 + 3) = CONCAT44(fStack_8 + fStack_14,fStack_8 + fStack_18);
  *(ulonglong *)param_2 = CONCAT44(fStack_14 - fStack_8,fStack_18 - fStack_8);
  param_2[2] = fStack_1c;
  param_2[5] = fStack_8 + fStack_10;
  iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  fStack_10 = fStack_8 + fStack_10;
  iVar1 = FUN_00ca3ed0(-(uint)(iVar1 != 0) & iVar1 - 8U,0);
  iVar3 = 0;
  if (0 < *(int *)(param_1 + 0x14)) {
    do {
      iVar2 = *(int *)(*(int *)(param_1 + 0x10) + iVar3 * 4);
      iVar2 = *(int *)(*(int *)((-(uint)(iVar2 != 0) & iVar2 - 8U) + 0x24) + 0x1c);
      iVar2 = FUN_00ca3ed0(-(uint)(iVar2 != 0) & iVar2 - 8U,0);
      if ((iVar1 != 0) == (iVar2 != 0)) {
        FUN_00ca12f0(&fStack_3c);
        fStack_1c = param_2[2];
        if (fStack_34 <= param_2[2]) {
          fStack_1c = fStack_34;
        }
        fVar5 = param_2[1];
        if (fStack_38 <= param_2[1]) {
          fVar5 = fStack_38;
        }
        fVar4 = *param_2;
        if (fStack_3c <= *param_2) {
          fVar4 = fStack_3c;
        }
        *(ulonglong *)param_2 = CONCAT44(fVar5,fVar4);
        param_2[2] = fStack_1c;
        fStack_10 = param_2[5];
        if (param_2[5] <= fStack_28) {
          fStack_10 = fStack_28;
        }
        fVar5 = param_2[4];
        if (param_2[4] <= fStack_2c) {
          fVar5 = fStack_2c;
        }
        fVar4 = param_2[3];
        if (param_2[3] <= fStack_30) {
          fVar4 = fStack_30;
        }
        *(ulonglong *)(param_2 + 3) = CONCAT44(fVar5,fVar4);
        param_2[5] = fStack_10;
      }
      iVar3 = iVar3 + 1;
      param_1 = iStack_c;
    } while (iVar3 < *(int *)(iStack_c + 0x14));
  }
  return param_2;
}



/* FUNCTION 29964 ; VA 0x00ca1510 ; FUN_00ca1510 */

int __fastcall FUN_00ca1510(int param_1)

{
  int iVar1;
  
  if (*(char *)(param_1 + 0x36) != '\0') {
    *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(param_1 + 0x88);
    iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
    FUN_00ca02b0(param_1,-(uint)(iVar1 != 0) & iVar1 - 8U,0);
    *(undefined *)(param_1 + 0x36) = 0;
  }
  return param_1 + 0x88;
}



/* FUNCTION 29965 ; VA 0x00ca1550 ; FUN_00ca1550 */

uint __fastcall FUN_00ca1550(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  return -(uint)(iVar1 != 0) & iVar1 - 8U;
}



/* FUNCTION 29966 ; VA 0x00ca1560 ; FUN_00ca1560 */

void FUN_00ca1560(void)

{
  FUN_00c157d0();
  return;
}



/* FUNCTION 29967 ; VA 0x00ca1580 ; FUN_00ca1580 */

undefined4 __fastcall FUN_00ca1580(int param_1)

{
  undefined4 uVar1;
  
  if (*(int **)(param_1 + 4) != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00ca1589. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(int **)(param_1 + 4) + 4))();
    return uVar1;
  }
  return 0;
}



/* FUNCTION 29968 ; VA 0x00ca1590 ; FUN_00ca1590 */

void __fastcall FUN_00ca1590(int param_1)

{
  undefined4 *puVar1;
  
  if (*(int *)(param_1 + 0x5c) == 0) {
    puVar1 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar1 != (undefined4 *)0x0) {
      puVar1[2] = param_1;
      puVar1[1] = 0;
      *puVar1 = RBX::AssemblyBroadPhaseBinding::vftable;
      *(undefined4 **)(param_1 + 0x5c) = puVar1;
      return;
    }
    *(undefined4 *)(param_1 + 0x5c) = 0;
  }
  return;
}



/* FUNCTION 29969 ; VA 0x00ca15e0 ; FUN_00ca15e0 */

void FUN_00ca15e0(void)

{
  FUN_00c15650();
  return;
}



/* FUNCTION 29970 ; VA 0x00ca1600 ; FUN_00ca1600 */

void __fastcall FUN_00ca1600(int param_1)

{
  undefined2 *puVar1;
  
  if (*(int *)(param_1 + 100) == 0) {
    puVar1 = (undefined2 *)FUN_01674e20(0x88);
    if (puVar1 != (undefined2 *)0x0) {
      *puVar1 = 0x101;
      *(undefined4 *)(puVar1 + 2) = 0x7f7fffff;
      *(undefined4 *)(puVar1 + 4) = 0x7f7fffff;
      *(undefined4 *)(puVar1 + 6) = 0x7f7fffff;
      *(undefined4 *)(puVar1 + 8) = 0xff7fffff;
      *(undefined4 *)(puVar1 + 10) = 0xff7fffff;
      *(undefined4 *)(puVar1 + 0xc) = 0xff7fffff;
      *(undefined4 *)(puVar1 + 0xe) = 0x3f800000;
      *(undefined4 *)(puVar1 + 0x10) = 0;
      *(undefined4 *)(puVar1 + 0x12) = 0;
      *(undefined4 *)(puVar1 + 0x14) = 0;
      *(undefined4 *)(puVar1 + 0x16) = 0x3f800000;
      *(undefined4 *)(puVar1 + 0x18) = 0;
      *(undefined4 *)(puVar1 + 0x1a) = 0;
      *(undefined4 *)(puVar1 + 0x1c) = 0;
      *(undefined4 *)(puVar1 + 0x1e) = 0x3f800000;
      *(undefined4 *)(puVar1 + 0x20) = 0;
      *(undefined4 *)(puVar1 + 0x22) = 0;
      *(undefined4 *)(puVar1 + 0x24) = 0;
      *(undefined4 *)(puVar1 + 0x26) = 0x3f800000;
      *(undefined4 *)(puVar1 + 0x28) = 0;
      *(undefined4 *)(puVar1 + 0x2a) = 0;
      *(undefined4 *)(puVar1 + 0x2c) = 0;
      *(undefined4 *)(puVar1 + 0x2e) = 0x3f800000;
      *(undefined4 *)(puVar1 + 0x30) = 0;
      *(undefined4 *)(puVar1 + 0x32) = 0;
      *(undefined4 *)(puVar1 + 0x34) = 0;
      *(undefined4 *)(puVar1 + 0x36) = 0x3f800000;
      *(undefined4 *)(puVar1 + 0x38) = 0;
      *(undefined4 *)(puVar1 + 0x3a) = 0;
      *(undefined4 *)(puVar1 + 0x3c) = 0;
      *(undefined4 *)(puVar1 + 0x3e) = 0;
      *(undefined4 *)(puVar1 + 0x40) = 0;
      *(undefined4 *)(puVar1 + 0x42) = 0;
      *(undefined2 **)(param_1 + 100) = puVar1;
      return;
    }
    *(undefined4 *)(param_1 + 100) = 0;
  }
  return;
}



/* FUNCTION 29971 ; VA 0x00ca1730 ; FUN_00ca1730 */

uint FUN_00ca1730(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x28) != 0) {
    iVar1 = *(int *)(*(int *)(param_1 + 0x28) + 0x20);
    return -(uint)(iVar1 != 0) & iVar1 - 8U;
  }
  return 0;
}



/* FUNCTION 29972 ; VA 0x00ca1750 ; FUN_00ca1750 */

bool __fastcall FUN_00ca1750(int param_1)

{
  return *(int *)(param_1 + 0xc) != 0;
}



/* FUNCTION 29973 ; VA 0x00ca1760 ; FUN_00ca1760 */

void __fastcall FUN_00ca1760(int param_1)

{
  undefined4 *puVar1;
  
  if (*(int *)(param_1 + 0x60) == 0) {
    puVar1 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar1 != (undefined4 *)0x0) {
      puVar1[1] = 0xffffffff;
      puVar1[2] = 0;
      puVar1[4] = param_1;
      puVar1[3] = 0;
      *puVar1 = RBX::AssemblyMidPhaseBinding::vftable;
      *(undefined4 **)(param_1 + 0x60) = puVar1;
      return;
    }
    *(undefined4 *)(param_1 + 0x60) = 0;
  }
  return;
}



/* FUNCTION 29974 ; VA 0x00ca17b0 ; FUN_00ca17b0 */

void FUN_00ca17b0(int *param_1)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined *puVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  float10 fVar11;
  float fVar12;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int iStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar4 = param_1;
  puStack_c = &LAB_01810948;
  pvStack_10 = ExceptionList;
  iStack_18 = 0;
  uStack_14 = 0;
  iStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ff4d30(&iStack_1c,1);
  iVar10 = iStack_1c + iStack_18 * 4;
  FUN_00c9fc40(iStack_1c,iVar10,iVar10 - iStack_1c >> 2,FUN_00ca1ac0);
  iVar10 = param_1[1];
  iVar6 = iVar10;
  if (iVar10 == iStack_18) goto LAB_00ca191f;
  iVar6 = param_1[2];
  param_1[1] = iStack_18;
  iVar8 = iVar10;
  if (iVar6 < iStack_18) {
    if (iVar6 == 0) {
      param_1[2] = iStack_18;
    }
    else if (iStack_18 < 10) {
      param_1[2] = 10;
    }
    else {
      fVar12 = DAT_018df57c;
      if ((iVar6 * 0x1c < 0x61a81) && (fVar12 = DAT_018df580, 64000 < iVar6 * 0x1c)) {
        fVar12 = DAT_018daf58;
      }
      iVar6 = ((int)((float)iVar6 * fVar12) - iVar6) + iStack_18;
      if (iVar6 < 10) {
        iVar6 = 10;
      }
      param_1[2] = iVar6;
    }
LAB_00ca18c4:
    FUN_006dda40(iVar8);
  }
  else if ((iStack_18 <= iVar6 / 3) && (10 < iStack_18)) {
    iVar8 = iStack_18;
    if (iVar10 <= iStack_18) {
      iVar8 = iVar10;
    }
    goto LAB_00ca18c4;
  }
  iVar6 = param_1[1];
  if (iVar10 < iVar6) {
    iVar8 = iVar10 * 0x1c;
    do {
      iVar10 = iVar10 + 1;
      puVar5 = (undefined4 *)(*param_1 + iVar8);
      iVar8 = iVar8 + 0x1c;
      *puVar5 = 0;
      puVar5[1] = 0;
      puVar5[2] = 0;
      puVar5[3] = 0;
      puVar5[4] = 0;
      puVar5[5] = 0;
      puVar5[6] = 0;
      iVar6 = param_1[1];
    } while (iVar10 < iVar6);
  }
LAB_00ca191f:
  iVar10 = 0;
  if (0 < iVar6) {
    param_1 = (int *)0x0;
    do {
      iVar6 = (**(code **)(**(int **)(iStack_1c + iVar10 * 4) + 0x10))();
      if (iVar6 == 5) {
        uVar9 = 0;
        fVar12 = *(float *)(*(int *)(iStack_1c + iVar10 * 4) + 0xb4);
        if (fVar12 < 0.0) {
          fVar12 = (float)((uint)fVar12 ^ DAT_018c4ea0);
          puVar7 = &DAT_bf800000;
          uVar3 = DAT_018f9988;
        }
        else {
          puVar7 = (undefined *)0x3f800000;
          uVar3 = 0;
        }
        puVar5 = (undefined4 *)(*piVar4 + (int)param_1);
        *puVar5 = uVar3;
        puVar5[1] = uVar3;
        puVar5[2] = puVar7;
        puVar5[3] = fVar12;
        *(undefined8 *)(puVar5 + 4) = 0;
      }
      else {
        iVar6 = *(int *)(iStack_1c + iVar10 * 4);
        uVar1 = *(undefined8 *)(iVar6 + 0xdc);
        uVar3 = *(undefined4 *)(iVar6 + 0xe4);
        uVar2 = *(undefined8 *)(iVar6 + 0xd0);
        uVar9 = *(undefined4 *)(iVar6 + 0xd8);
        fVar11 = (float10)FUN_01165610(0x358637bd);
        puVar5 = (undefined4 *)(*piVar4 + (int)param_1);
        uStack_5c = (undefined4)uVar1;
        uStack_58 = (undefined4)((ulonglong)uVar1 >> 0x20);
        *puVar5 = uStack_5c;
        puVar5[1] = uStack_58;
        puVar5[2] = uVar3;
        puVar5[3] = (float)fVar11;
        *(undefined8 *)(puVar5 + 4) = uVar2;
      }
      param_1 = (int *)((int)param_1 + 0x1c);
      iVar10 = iVar10 + 1;
      puVar5[6] = uVar9;
    } while (iVar10 < piVar4[1]);
  }
  uStack_8 = 1;
  FUN_01674ea0(iStack_1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29975 ; VA 0x00ca1a60 ; FUN_00ca1a60 */

uint FUN_00ca1a60(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x28) + 0x20);
  return -(uint)(iVar1 != 0) & iVar1 - 8U;
}



/* FUNCTION 29976 ; VA 0x00ca1a80 ; FUN_00ca1a80 */

uint FUN_00ca1a80(uint param_1)

{
  int iVar1;
  
  if ((param_1 != 0) && (*(int *)(param_1 + 0x20) != 0)) {
    iVar1 = *(int *)(*(int *)(param_1 + 0x20) + 0x18);
    return (uint)((iVar1 - 8U & -(uint)(iVar1 != 0)) != 0);
  }
  return param_1 & 0xffffff00;
}



/* FUNCTION 29977 ; VA 0x00ca1ab0 ; FUN_00ca1ab0 */

undefined4 __fastcall FUN_00ca1ab0(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x10) >> 8),
                  *(undefined *)(*(int *)(param_1 + 0x10) + 0xa1));
}



/* FUNCTION 29978 ; VA 0x00ca1ac0 ; FUN_00ca1ac0 */

void FUN_00ca1ac0(int param_1,int param_2)

{
  (**(code **)(*(int *)(-(uint)(param_2 != 0) & param_2 + 8U) + 4))(param_1 + 8);
  return;
}



/* FUNCTION 29979 ; VA 0x00ca1ae0 ; FUN_00ca1ae0 */

void FUN_00ca1ae0(int param_1,char param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  
  FUN_00c3e3a0();
  iVar3 = *(int *)(param_1 + 0x1a8);
  iVar1 = FUN_00c16390();
  if (param_2 == '\0') {
    iVar3 = 0;
    if (0 < iVar1) {
      do {
        uVar2 = FUN_00c15720(iVar3);
        FUN_00ce9040(uVar2,0);
        iVar3 = iVar3 + 1;
        iVar1 = FUN_00c16390();
      } while (iVar3 < iVar1);
    }
  }
  else {
    iVar4 = 0;
    if (0 < iVar1) {
      do {
        FUN_00c15720(iVar4);
        FUN_00ff5760(*(undefined4 *)(iVar3 + 0x6f0));
        iVar4 = iVar4 + 1;
        iVar1 = FUN_00c16390();
      } while (iVar4 < iVar1);
      return;
    }
  }
  return;
}



/* FUNCTION 29980 ; VA 0x00ca1b70 ; FUN_00ca1b70 */

void __fastcall FUN_00ca1b70(uint param_1)

{
  int iVar1;
  undefined4 uStack_8;
  
  if (DAT_01d67ba4 != '\0') {
    FUN_00ca1bb0();
  }
  uStack_8 = param_1 & 0xffffff00;
  iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  FUN_00c9fea0(uStack_8,-(uint)(iVar1 != 0) & iVar1 - 8U,0);
  return;
}



/* FUNCTION 29981 ; VA 0x00ca1bb0 ; FUN_00ca1bb0 */

void __fastcall FUN_00ca1bb0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  iVar2 = FUN_00ca3ed0(-(uint)(iVar3 != 0) & iVar3 - 8U,0);
  iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  iVar3 = iVar1 + -8;
  if (iVar2 == 0) {
    if (iVar1 == 0) {
      iVar3 = 0;
    }
    iVar3 = FUN_00c1a100(iVar3);
  }
  else if (iVar1 == 0) {
    iVar3 = 0;
  }
  if ((iVar3 != 0) && (*(int *)(iVar3 + 0x1a8) != 0)) {
    FUN_005e6780(iVar3);
  }
  return;
}



/* FUNCTION 29982 ; VA 0x00ca1c10 ; FUN_00ca1c10 */

void __fastcall FUN_00ca1c10(int param_1)

{
  *(undefined *)(param_1 + 0xa0) = 1;
  return;
}



/* FUNCTION 29983 ; VA 0x00ca1c20 ; FUN_00ca1c20 */

int __fastcall FUN_00ca1c20(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_00c155c0();
  iVar2 = FUN_00c155c0();
  if (iVar1 == param_1) {
    iVar1 = iVar2;
  }
  return iVar1;
}



/* FUNCTION 29984 ; VA 0x00ca1c50 ; FUN_00ca1c50 */

undefined FUN_00ca1c50(void)

{
  char cVar1;
  
  cVar1 = FUN_01091880();
  if ((cVar1 == '\0') && (cVar1 = FUN_00f9e380((float)DAT_01d68ad4 * DAT_018f784c), cVar1 == '\0'))
  {
    return 0;
  }
  return 1;
}



/* FUNCTION 29985 ; VA 0x00ca1cb0 ; FUN_00ca1cb0 */

void FUN_00ca1cb0(undefined4 param_1)

{
  FUN_00ca1cd0(param_1,param_1);
  return;
}



/* FUNCTION 29986 ; VA 0x00ca1cd0 ; FUN_00ca1cd0 */

void FUN_00ca1cd0(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  bool bVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  
  if (*(char *)(param_2 + 0x36) != '\0') {
    *(undefined4 *)(param_2 + 0x8c) = *(undefined4 *)(param_2 + 0x88);
    iVar7 = *(int *)(*(int *)(param_2 + 0x24) + 0x1c);
    FUN_00ca02b0(param_2,-(uint)(iVar7 != 0) & iVar7 - 8U,0);
    *(undefined *)(param_2 + 0x36) = 0;
  }
  piVar1 = *(int **)(param_2 + 0x8c);
  piVar8 = *(int **)(param_2 + 0x88);
  while( true ) {
    if (piVar8 == piVar1) {
      iVar7 = 0;
      if (0 < *(int *)(param_2 + 0x14)) {
        do {
          iVar3 = *(int *)(*(int *)(param_2 + 0x10) + iVar7 * 4);
          FUN_00ca1cd0(param_1,-(uint)(iVar3 != 0) & iVar3 - 8U);
          iVar7 = iVar7 + 1;
        } while (iVar7 < *(int *)(param_2 + 0x14));
      }
      return;
    }
    piVar2 = (int *)*piVar8;
    if (*(char *)(piVar2 + 8) != '\0') break;
    uVar6 = (**(code **)(*piVar2 + 0x10))();
    switch(uVar6) {
    case 0xc:
    case 0xd:
    case 0xf:
    case 0x10:
    case 0x11:
    case 0x12:
    case 0x14:
    case 0x15:
    case 0x16:
      goto switchD_00ca1d3e_caseD_c;
    default:
switchD_00ca1d3e_caseD_e:
      piVar8 = piVar8 + 1;
    }
  }
switchD_00ca1d3e_caseD_c:
  iVar7 = piVar2[0xc];
  if ((*(char *)(piVar2[0xb] + 0x223) == '\0') && (cVar5 = FUN_00c14800(), cVar5 == '\0')) {
    bVar4 = false;
  }
  else {
    bVar4 = true;
  }
  if ((*(char *)(iVar7 + 0x223) != '\0') || (cVar5 = FUN_00c14800(), cVar5 != '\0')) {
    cVar5 = '\x01';
  }
  if ((bVar4) || (cVar5 != '\0')) {
    *(int *)(param_1 + 0x50) = *(int *)(param_1 + 0x50) + 1;
  }
  goto switchD_00ca1d3e_caseD_e;
}



/* FUNCTION 29987 ; VA 0x00ca1de0 ; FUN_00ca1de0 */

void __thiscall FUN_00ca1de0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_2 + 0x3c);
  if (iVar1 != -1) {
    iVar2 = *(int *)(param_1 + 0x7c);
    if (iVar2 != *(int *)(param_1 + 0x80)) {
      iVar3 = *(int *)(iVar2 + -4 + (*(int *)(param_1 + 0x80) - iVar2 >> 2) * 4);
      *(int *)(iVar2 + iVar1 * 4) = iVar3;
      *(int *)(iVar3 + 0x3c) = iVar1;
      *(int *)(param_1 + 0x80) = *(int *)(param_1 + 0x80) + -4;
      *(undefined4 *)(param_2 + 0x3c) = 0xffffffff;
    }
  }
  return;
}



/* FUNCTION 29988 ; VA 0x00ca1e20 ; FUN_00ca1e20 */

void __thiscall FUN_00ca1e20(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181096f;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x40);
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x40) = param_2;
  if (iVar1 == 0) {
    if (param_2 != 0) {
      iVar1 = FUN_01674e20(0x20);
      uStack_8 = 0;
      if (iVar1 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_010916c0(param_1);
      }
      *(undefined4 *)(param_1 + 0x58) = uVar2;
    }
    ExceptionList = pvStack_10;
    return;
  }
  if (param_2 != 0) {
    FUN_01091770(param_1);
    ExceptionList = pvStack_10;
    return;
  }
  iVar1 = *(int *)(param_1 + 0x58);
  if (iVar1 != 0) {
    FUN_01091760();
    FUN_01674ea0(iVar1,0x20);
  }
  *(undefined4 *)(param_1 + 0x58) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29989 ; VA 0x00ca1ee0 ; FUN_00ca1ee0 */

void FUN_00ca1ee0(int param_1)

{
  *(undefined4 *)(param_1 + 0x50) = 0;
  return;
}



/* FUNCTION 29990 ; VA 0x00ca1ef0 ; FUN_00ca1ef0 */

undefined4 __fastcall FUN_00ca1ef0(undefined4 param_1)

{
  char cVar1;
  
  cVar1 = FUN_010918b0(param_1);
  if ((cVar1 != '\0') && (cVar1 = FUN_00f9e380((float)DAT_01d68acc * DAT_018f784c), cVar1 == '\0'))
  {
    return 1;
  }
  return 0;
}



/* FUNCTION 29991 ; VA 0x00ca1f50 ; FUN_00ca1f50 */

void __fastcall FUN_00ca1f50(int param_1)

{
  if (*(int **)(param_1 + 4) != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00ca1f5d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(param_1 + 4) + 8))();
    return;
  }
  return;
}



/* FUNCTION 29992 ; VA 0x00ca1f70 ; FUN_00ca1f70 */

void __thiscall FUN_00ca1f70(int param_1,undefined param_2)

{
  int iVar1;
  int *piVar2;
  
  *(undefined *)(param_1 + 0xa1) = param_2;
  iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  piVar2 = (int *)(iVar1 + 0x68);
  if (iVar1 == 0) {
    piVar2 = (int *)0x70;
  }
  *(undefined *)(*piVar2 + 0x40) = param_2;
  return;
}



/* FUNCTION 29993 ; VA 0x00ca1fa0 ; FUN_00ca1fa0 */

void __thiscall FUN_00ca1fa0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  float *pfVar6;
  int iVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fStack_1c;
  float fStack_18;
  int iStack_c;
  
  iVar7 = *(int *)(param_1 + 0x98);
  if (iVar7 != 0) {
    *(undefined4 *)(param_1 + 0x98) = 0;
    if (*(int *)(param_1 + 0x9c) < 0) {
      if (*(int *)(param_1 + 0x9c) == 0) {
        uVar5 = 0;
      }
      else {
        uVar5 = 10;
      }
      *(undefined4 *)(param_1 + 0x9c) = uVar5;
      FUN_0078c480(iVar7);
    }
  }
  FUN_00ff4d30();
  FUN_00c9fc40(*(int *)(param_1 + 0x94),*(int *)(param_1 + 0x94) + *(int *)(param_1 + 0x98) * 4,
               *(int *)(param_1 + 0x98),FUN_00ca1ac0);
  bVar2 = false;
  if ((*(int *)(param_1 + 0x98) == param_2[1]) && (iVar7 = 0, 0 < *(int *)(param_1 + 0x98))) {
    iStack_c = 0;
    do {
      iVar4 = (**(code **)(**(int **)(*(int *)(param_1 + 0x94) + iVar7 * 4) + 0x10))();
      iVar1 = *(int *)(*(int *)(param_1 + 0x94) + iVar7 * 4);
      pfVar6 = (float *)(*param_2 + iStack_c);
      fVar8 = pfVar6[3];
      if (iVar4 == 5) {
        fVar8 = fVar8 * pfVar6[2];
        if ((bVar2) ||
           (bVar2 = false,
           (NAN(fVar8) || NAN(*(float *)(iVar1 + 0xb4))) == (fVar8 == *(float *)(iVar1 + 0xb4)))) {
          bVar2 = true;
        }
        FUN_01064c60(fVar8);
      }
      else {
        fVar10 = *pfVar6 * fVar8;
        fVar9 = pfVar6[1] * fVar8;
        fVar8 = pfVar6[2] * fVar8;
        if (bVar2) {
LAB_00ca20e3:
          bVar2 = true;
        }
        else {
          fStack_1c = (float)*(undefined8 *)(iVar1 + 0xdc);
          if ((((NAN(fVar10) || NAN(fStack_1c)) == (fVar10 == fStack_1c)) ||
              (fStack_18 = (float)((ulonglong)*(undefined8 *)(iVar1 + 0xdc) >> 0x20),
              (NAN(fVar9) || NAN(fStack_18)) == (fVar9 == fStack_18))) ||
             (bVar2 = false,
             (NAN(fVar8) || NAN(*(float *)(iVar1 + 0xe4))) == (fVar8 == *(float *)(iVar1 + 0xe4))))
          goto LAB_00ca20e3;
        }
        FUN_01063b20(*(undefined8 *)(pfVar6 + 4),pfVar6[6],CONCAT44(fVar9,fVar10),fVar8);
      }
      iVar7 = iVar7 + 1;
      iStack_c = iStack_c + 0x1c;
    } while (iVar7 < *(int *)(param_1 + 0x98));
    if (bVar2) {
      iVar7 = FUN_00c157b0();
      if ((((NAN(*(float *)(param_3 + 0x24)) || NAN(*(float *)(iVar7 + 0x24))) !=
            (*(float *)(param_3 + 0x24) == *(float *)(iVar7 + 0x24))) &&
          ((NAN(*(float *)(param_3 + 0x28)) || NAN(*(float *)(iVar7 + 0x28))) !=
           (*(float *)(param_3 + 0x28) == *(float *)(iVar7 + 0x28)))) &&
         ((NAN(*(float *)(param_3 + 0x2c)) || NAN(*(float *)(iVar7 + 0x2c))) !=
          (*(float *)(param_3 + 0x2c) == *(float *)(iVar7 + 0x2c)))) {
        cVar3 = FUN_01160ab0(iVar7);
        if (((((cVar3 != '\0') &&
              ((NAN(*(float *)(param_3 + 0x30)) || NAN(*(float *)(iVar7 + 0x30))) !=
               (*(float *)(param_3 + 0x30) == *(float *)(iVar7 + 0x30)))) &&
             ((NAN(*(float *)(param_3 + 0x34)) || NAN(*(float *)(iVar7 + 0x34))) !=
              (*(float *)(param_3 + 0x34) == *(float *)(iVar7 + 0x34)))) &&
            (((NAN(*(float *)(param_3 + 0x38)) || NAN(*(float *)(iVar7 + 0x38))) !=
              (*(float *)(param_3 + 0x38) == *(float *)(iVar7 + 0x38)) &&
             ((NAN(*(float *)(param_3 + 0x3c)) || NAN(*(float *)(iVar7 + 0x3c))) !=
              (*(float *)(param_3 + 0x3c) == *(float *)(iVar7 + 0x3c)))))) &&
           (((NAN(*(float *)(param_3 + 0x40)) || NAN(*(float *)(iVar7 + 0x40))) !=
             (*(float *)(param_3 + 0x40) == *(float *)(iVar7 + 0x40)) &&
            ((NAN(*(float *)(param_3 + 0x44)) || NAN(*(float *)(iVar7 + 0x44))) !=
             (*(float *)(param_3 + 0x44) == *(float *)(iVar7 + 0x44)))))) {
          if (DAT_01d67ba4 != '\0') {
            FUN_00ca1bb0();
          }
          param_2 = (int *)((uint)param_2 & 0xffffff00);
          iVar7 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
          FUN_00c9fea0(param_2,-(uint)(iVar7 != 0) & iVar7 - 8U,0);
        }
      }
    }
  }
  return;
}



/* FUNCTION 29994 ; VA 0x00ca2240 ; FUN_00ca2240 */

void __fastcall FUN_00ca2240(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_00c157d0();
  if (iVar1 == 1) {
    *(undefined *)(param_1 + 0xa0) = 0;
  }
  else if ((iVar1 == 2) || (iVar1 == 4)) {
    *(undefined *)(param_1 + 0xa0) = 1;
    return;
  }
  return;
}



/* FUNCTION 29995 ; VA 0x00ca2280 ; FUN_00ca2280 */

undefined4 __fastcall FUN_00ca2280(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x10) >> 8),
                  *(undefined *)(*(int *)(param_1 + 0x10) + 0xa0));
}



/* FUNCTION 29996 ; VA 0x00ca2290 ; FUN_00ca2290 */

void FUN_00ca2290(float *param_1,int param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined auStack_e4 [48];
  undefined auStack_b4 [36];
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  float fStack_58;
  undefined auStack_54 [12];
  float fStack_48;
  float fStack_44;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  ulonglong uStack_30;
  undefined8 uStack_28;
  undefined8 uStack_1c;
  float fStack_14;
  float fStack_8;
  
  FUN_00ca1260(param_2);
  FUN_0071fcc0(auStack_b4);
  fVar1 = param_1[4];
  uStack_30 = (ulonglong)
              (uint)(param_1[1] * fStack_8c + *param_1 * fStack_90 + param_1[2] * fStack_88 +
                    param_1[9]);
  fVar2 = param_1[3];
  fVar3 = param_1[5];
  fVar4 = param_1[10];
  fStack_8 = param_1[6] * fStack_90 + param_1[7] * fStack_8c + param_1[8] * fStack_88 + param_1[0xb]
  ;
  puVar5 = (undefined4 *)FUN_01160c20(auStack_54,auStack_b4);
  uStack_84 = *puVar5;
  uStack_80 = puVar5[1];
  uStack_7c = puVar5[2];
  uStack_78 = puVar5[3];
  uStack_74 = puVar5[4];
  uStack_70 = puVar5[5];
  uStack_6c = puVar5[6];
  uStack_68 = puVar5[7];
  uStack_64 = puVar5[8];
  fStack_58 = fStack_8;
  uStack_60 = CONCAT44(fVar2 * fStack_90 + fVar1 * fStack_8c + fVar3 * fStack_88 + fVar4,
                       (int)uStack_30);
  FUN_00c9f550(&uStack_28,&uStack_84);
  if ((DAT_01d69148 != '\0') && (*(char *)(param_2 + 0xa0) != '\0')) {
    FUN_00fa0810();
    uVar6 = FUN_0071f260(auStack_e4,auStack_b4);
    FUN_00c9f550(&fStack_48,uVar6);
    fVar1 = uStack_28._4_4_;
    if (fStack_44 <= uStack_28._4_4_) {
      fVar1 = fStack_44;
    }
    if (fStack_48 <= (float)uStack_28) {
      uStack_28._0_4_ = fStack_48;
    }
    uStack_28 = CONCAT44(fVar1,(float)uStack_28);
    if (fStack_14 <= fStack_34) {
      fStack_14 = fStack_34;
    }
    fVar1 = uStack_1c._4_4_;
    if (uStack_1c._4_4_ <= fStack_38) {
      fVar1 = fStack_38;
    }
    if ((float)uStack_1c <= fStack_3c) {
      uStack_1c._0_4_ = fStack_3c;
    }
    uStack_1c = CONCAT44(fVar1,(float)uStack_1c);
    fStack_8 = fStack_14;
  }
  (**(code **)(**(int **)(param_2 + 0x5c) + 8))(&uStack_28);
  return;
}



/* FUNCTION 29997 ; VA 0x00ca24b0 ; FUN_00ca24b0 */

void FUN_00ca24b0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_00c157b0();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_1[4] = puVar4[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_1[8] = puVar4[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  return;
}



/* FUNCTION 29998 ; VA 0x00ca24f0 ; FUN_00ca24f0 */

void __thiscall FUN_00ca24f0(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined auStack_c [4];
  undefined4 uStack_8;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
  puVar3 = (undefined4 *)FUN_016830f0(auStack_c);
  FUN_00c185b0(0,*puVar3,puVar3[1]);
  uStack_8 = *(undefined4 *)((-(uint)(iVar1 != 0) & iVar1 - 8U) + 0x1a8);
  if ((param_2 == -1) || (cVar2 = FUN_00cdfbc0(param_1,param_2), cVar2 != '\0')) {
    FUN_00c19c40(param_2,uStack_8);
  }
  if (*(int *)(param_1 + 0x58) != 0) {
    FUN_01091af0();
  }
  return;
}



/* FUNCTION 29999 ; VA 0x00ca2570 ; FUN_00ca2570 */

void __thiscall FUN_00ca2570(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  
  if (param_2 != 0) {
    if (*(char *)(param_1 + 0x36) != '\0') {
      *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(param_1 + 0x88);
      iVar2 = *(int *)(*(int *)(param_1 + 0x24) + 0x1c);
      FUN_00ca02b0(param_1,-(uint)(iVar2 != 0) & iVar2 - 8U,0);
      *(undefined *)(param_1 + 0x36) = 0;
    }
    piVar5 = *(int **)(param_1 + 0x88);
    uVar4 = 0;
    uVar3 = (uint)((int)*(int **)(param_1 + 0x8c) + (3 - (int)piVar5)) >> 2;
    if (*(int **)(param_1 + 0x8c) < piVar5) {
      uVar3 = 0;
    }
    if (uVar3 != 0) {
      do {
        piVar1 = (int *)*piVar5;
        iVar2 = (**(code **)(*piVar1 + 0x10))();
        if (iVar2 - 7U < 0x13) {
          FUN_00bc1c10(piVar1[0xb],0);
          FUN_00bc1c10(piVar1[0xc],0);
        }
        uVar4 = uVar4 + 1;
        piVar5 = piVar5 + 1;
      } while (uVar4 != uVar3);
    }
  }
  return;
}


