/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 23500 ; VA 0x00b1c0c0 ; FUN_00b1c0c0 */

undefined4 __thiscall FUN_00b1c0c0(undefined4 param_1,byte param_2)

{
  FUN_00b19590();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 23501 ; VA 0x00b1c0f0 ; FUN_00b1c0f0 */

undefined4 __thiscall FUN_00b1c0f0(undefined4 param_1,byte param_2)

{
  FUN_00b19600();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 23502 ; VA 0x00b1c120 ; FUN_00b1c120 */

int __thiscall FUN_00b1c120(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),1);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 23503 ; VA 0x00b1c180 ; FUN_00b1c180 */

undefined4 __thiscall FUN_00b1c180(undefined4 param_1,byte param_2)

{
  FUN_00b19680();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 23504 ; VA 0x00b1c1b0 ; FUN_00b1c1b0 */

int __thiscall FUN_00b1c1b0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 23505 ; VA 0x00b1c200 ; FUN_00b1c200 */

undefined4 __thiscall FUN_00b1c200(undefined4 param_1,byte param_2)

{
  FUN_00b196e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 23506 ; VA 0x00b1c230 ; FUN_00b1c230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b1c230(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::AssetService::AssetType>::vftable;
  _DAT_01f16398 = _DAT_01f16398 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 23507 ; VA 0x00b1c260 ; FUN_00b1c260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b1c260(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::MarketplaceService::CurrencyType>::vftable;
  _DAT_01eee3e0 = _DAT_01eee3e0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 23508 ; VA 0x00b1c290 ; FUN_00b1c290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b1c290(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::MarketplaceService::InfoType>::vftable;
  _DAT_01eee3e8 = _DAT_01eee3e8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 23509 ; VA 0x00b1c2c0 ; FUN_00b1c2c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b1c2c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::MarketplaceService::ProductPurchaseDecision>::
             vftable;
  _DAT_01eee3f0 = _DAT_01eee3f0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 23510 ; VA 0x00b1c2f0 ; FUN_00b1c2f0 */

undefined4 __thiscall FUN_00b1c2f0(undefined4 param_1,byte param_2)

{
  FUN_00b19e90();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x218);
  }
  return param_1;
}



/* FUNCTION 23511 ; VA 0x00b1c330 ; FUN_00b1c330 */

/* WARNING: Removing unreachable block (ram,0x00b1c3e6) */
/* WARNING: Removing unreachable block (ram,0x00b1c430) */
/* WARNING: Removing unreachable block (ram,0x00b1c43c) */
/* WARNING: Removing unreachable block (ram,0x00b1c44a) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b1c330(undefined4 param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint in_stack_000000d4;
  undefined4 in_stack_000000f0;
  uint in_stack_000000f4;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = _DAT_00000000;
  puStack_c = &LAB_017efb05;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01674e20(0xc);
  uStack_8._0_1_ = 3;
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    FUN_00569550(1,&uStack_11);
  }
  uStack_8._0_1_ = 2;
  FUN_0055ba30(iVar2,in_stack_000000f0);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uVar3 = FUN_00b319a0();
  *_DAT_00000000 = uVar3;
  iVar4 = FUN_00b31ba0();
  iVar2 = puVar1[1];
  if (iVar2 == iVar4) {
    puVar1[2] = 1;
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(puVar1 + 2);
    }
    puVar1[2] = 1;
    puVar1[1] = iVar4;
  }
  uStack_8._0_1_ = 5;
  if (in_stack_000000d4 == 0) {
    uVar3 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar3);
  }
  (**(code **)((in_stack_000000d4 & 0xfffffffe) + 4))(&stack0x000000dc,0,0);
  uStack_8._0_1_ = 7;
  if (param_2 != 0) {
    (**(code **)(param_2 + 8))(&stack0x0000000c);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (in_stack_000000d4 != 0) {
    if (((in_stack_000000d4 & 1) == 0) &&
       (*(code **)(in_stack_000000d4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_000000d4 & 0xfffffffe))(&stack0x000000dc,&stack0x000000dc,2);
    }
    in_stack_000000d4 = 0;
  }
  uStack_8 = 9;
  if (((in_stack_000000f4 != 0) && ((in_stack_000000f4 & 1) == 0)) &&
     (*(code **)(in_stack_000000f4 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_000000f4 & 0xfffffffe))(&stack0x000000fc,&stack0x000000fc,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23512 ; VA 0x00b1c4f0 ; FUN_00b1c4f0 */

void FUN_00b1c4f0(int param_1)

{
  *(uint *)(param_1 + 0x14) = *(uint *)(param_1 + 0x14) | 0x4000;
  return;
}



/* FUNCTION 23513 ; VA 0x00b1c500 ; FUN_00b1c500 */

undefined4 * FUN_00b1c500(undefined4 *param_1,int *param_2)

{
  code *pcVar1;
  bool bVar2;
  int iVar3;
  undefined uVar4;
  char cVar5;
  char cVar6;
  int iVar7;
  int *piVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int *piVar11;
  int iVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  int iVar18;
  undefined4 auStack_90 [2];
  int iStack_88;
  int *piStack_84;
  int *piStack_80;
  int *piStack_7c;
  uint uStack_78;
  undefined4 uStack_74;
  uint uStack_70;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  uint uStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  int iStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017efbec;
  pvStack_10 = ExceptionList;
  uStack_70 = 0;
  uStack_2c = 0;
  iVar18 = *param_2;
  ExceptionList = &pvStack_10;
  iVar7 = FUN_008881d0();
  if (iVar18 != iVar7) {
LAB_00b1d179:
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar8 = param_2 + 2;
  if (param_2[1] == 0) {
    piVar8 = (int *)0x0;
  }
  piStack_80 = (int *)piVar8[1];
  if (piStack_80 != (int *)0x0) {
    LOCK();
    piStack_80[1] = piStack_80[1] + 1;
    UNLOCK();
    piStack_80 = (int *)piVar8[1];
  }
  iVar18 = *piVar8;
  uStack_8 = 0;
  piVar8 = (int *)FUN_01674e20(0x18);
  piStack_84 = piVar8;
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)0x0;
  }
  else {
    *(undefined *)piVar8 = 0;
    iVar7 = FUN_00588320(0xb);
    piVar8[1] = iVar7;
    piVar8[2] = 0;
    piVar8[3] = 0x3f800000;
    piVar8[4] = 0;
    piVar8[5] = 0;
  }
  uStack_50 = 0;
  piStack_4c = (int *)0x0;
  FUN_005c1af0(piVar8,iVar18);
  uStack_8._0_1_ = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("playerId",8);
  uStack_8._0_1_ = 2;
  puVar9 = (undefined4 *)FUN_0091d440(auStack_28);
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("PlayerId",8);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puVar10 = (undefined4 *)FUN_005c4eb0(auStack_48);
  piVar8 = puVar9 + 1;
  piVar11 = puVar10 + 1;
  *puVar10 = *puVar9;
  if (piVar8 != piVar11) {
    if (*piVar11 != 0) {
      (**(code **)(*piVar11 + 8))(puVar10 + 2);
      *piVar11 = 0;
    }
    if ((undefined4 *)*piVar8 != (undefined4 *)0x0) {
      (**(code **)*piVar8)(puVar9 + 2,puVar10 + 2);
      *piVar11 = *piVar8;
    }
  }
  uStack_8._0_1_ = 2;
  if (0xf < uStack_34) {
    uVar16 = uStack_34 + 1;
    uVar15 = auStack_48[0];
    if (0xfff < uVar16) {
      uVar15 = *(uint *)(auStack_48[0] - 4);
      uVar16 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar15) - 4) {
LAB_00b1d183:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar16);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_14) {
    uVar16 = uStack_14 + 1;
    uVar15 = auStack_28[0];
    if (0xfff < uVar16) {
      uVar15 = *(uint *)(auStack_28[0] - 4);
      uVar16 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar16);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("placeId",7);
  uStack_8._0_1_ = 4;
  puVar9 = (undefined4 *)FUN_0091d440(auStack_28);
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("PlaceIdWherePurchased",0x15);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puVar10 = (undefined4 *)FUN_005c4eb0(auStack_48);
  piVar8 = puVar9 + 1;
  piVar11 = puVar10 + 1;
  *puVar10 = *puVar9;
  if (piVar8 != piVar11) {
    if (*piVar11 != 0) {
      (**(code **)(*piVar11 + 8))(puVar10 + 2);
      *piVar11 = 0;
    }
    if ((undefined4 *)*piVar8 != (undefined4 *)0x0) {
      (**(code **)*piVar8)(puVar9 + 2,puVar10 + 2);
      *piVar11 = *piVar8;
    }
  }
  uStack_8._0_1_ = 4;
  if (0xf < uStack_34) {
    uVar16 = uStack_34 + 1;
    uVar15 = auStack_48[0];
    if (0xfff < uVar16) {
      uVar15 = *(uint *)(auStack_48[0] - 4);
      uVar16 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar16);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_14) {
    uVar16 = uStack_14 + 1;
    uVar15 = auStack_28[0];
    if (0xfff < uVar16) {
      uVar15 = *(uint *)(auStack_28[0] - 4);
      uVar16 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar16);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("receipt",7);
  uStack_8._0_1_ = 6;
  puVar9 = (undefined4 *)FUN_0091d440(auStack_28);
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("PurchaseId",10);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  puVar10 = (undefined4 *)FUN_005c4eb0(auStack_48);
  piVar8 = puVar9 + 1;
  piVar11 = puVar10 + 1;
  *puVar10 = *puVar9;
  if (piVar8 != piVar11) {
    if (*piVar11 != 0) {
      (**(code **)(*piVar11 + 8))(puVar10 + 2);
      *piVar11 = 0;
    }
    if ((undefined4 *)*piVar8 != (undefined4 *)0x0) {
      (**(code **)*piVar8)(puVar9 + 2,puVar10 + 2);
      *piVar11 = *piVar8;
    }
  }
  uStack_8._0_1_ = 6;
  if (0xf < uStack_34) {
    uVar16 = uStack_34 + 1;
    uVar15 = auStack_48[0];
    if (0xfff < uVar16) {
      uVar15 = *(uint *)(auStack_48[0] - 4);
      uVar16 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar16);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_14) {
    uVar16 = uStack_14 + 1;
    uVar15 = auStack_28[0];
    if (0xfff < uVar16) {
      uVar15 = *(uint *)(auStack_28[0] - 4);
      uVar16 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar16);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("actionArgs",10);
  uStack_8._0_1_ = 8;
  piVar8 = (int *)FUN_0091d440(auStack_28);
  iVar18 = *piVar8;
  iVar7 = FUN_008882f0();
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_14) {
    uVar16 = uStack_14 + 1;
    uVar15 = auStack_28[0];
    if (0xfff < uVar16) {
      uVar15 = *(uint *)(auStack_28[0] - 4);
      uVar16 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar16);
  }
  if (iVar18 == iVar7) {
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    FUN_005542c0("actionArgs",10);
    uStack_8._0_1_ = 9;
    piVar8 = (int *)FUN_0091d440(auStack_48);
    iVar18 = *piVar8;
    iVar7 = FUN_008882f0();
    if (iVar18 != iVar7) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar11 = piVar8 + 2;
    if (piVar8[1] == 0) {
      piVar11 = (int *)0x0;
    }
    piVar8 = (int *)piVar11[1];
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = (int *)piVar11[1];
    }
    piVar11 = (int *)*piVar11;
    uStack_8._0_1_ = 0xb;
    piStack_84 = piVar11;
    piStack_7c = piVar8;
    if (0xf < uStack_34) {
      uVar16 = uStack_34 + 1;
      uVar15 = auStack_48[0];
      if (0xfff < uVar16) {
        uVar15 = *(uint *)(auStack_48[0] - 4);
        uVar16 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar16);
    }
    uStack_38 = 0;
    iVar18 = piVar11[1] - *piVar11 >> 0x1f;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    uStack_54 = 0;
    if ((piVar11[1] - *piVar11) / 0xd0 + iVar18 != iVar18) {
      iStack_30 = 0;
      do {
        iVar18 = iStack_30;
        if ((uint)((piVar11[1] - *piVar11) / 0xd0) <= uStack_54) {
LAB_00b1d1b5:
          FUN_00577c40();
          pcVar1 = (code *)swi(3);
          puVar9 = (undefined4 *)(*pcVar1)();
          return puVar9;
        }
        iVar7 = *(int *)(iStack_30 + *piVar11);
        iVar12 = FUN_008881d0();
        iVar3 = iStack_30;
        if (iVar7 == iVar12) {
          iVar18 = *piVar11;
          if ((uint)((piVar11[1] - iVar18) / 0xd0) <= uStack_54) goto LAB_00b1d1b5;
          iVar7 = *(int *)(iStack_30 + iVar18);
          iVar12 = FUN_008881d0();
          if (iVar7 != iVar12) goto LAB_00b1d179;
          puVar9 = (undefined4 *)(iVar3 + 8 + iVar18);
          if (*(int *)(iVar3 + 4 + iVar18) == 0) {
            puVar9 = (undefined4 *)0x0;
          }
          piVar8 = (int *)puVar9[1];
          if (piVar8 != (int *)0x0) {
            LOCK();
            piVar8[1] = piVar8[1] + 1;
            UNLOCK();
            piVar8 = (int *)puVar9[1];
          }
          uStack_74 = *puVar9;
          uStack_8._0_1_ = 0xc;
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          FUN_005542c0(&DAT_0191c24c,5);
          uStack_8._0_1_ = 0xd;
          FUN_0091d440(auStack_28);
          uVar13 = FUN_00563690(auStack_6c);
          uStack_8._0_1_ = 0xe;
          cVar5 = FUN_009ee890(uVar13,auStack_90);
          uStack_8._0_1_ = 0xd;
          if (0xf < uStack_58) {
            uVar16 = uStack_58 + 1;
            uVar15 = auStack_6c[0];
            if (0xfff < uVar16) {
              uVar15 = *(uint *)(auStack_6c[0] - 4);
              uVar16 = uStack_58 + 0x24;
              if (0x1f < (auStack_6c[0] - uVar15) - 4) goto LAB_00b1d183;
            }
            FUN_01674ea0(uVar15,uVar16);
          }
          uStack_5c = 0;
          uStack_58 = 0xf;
          auStack_6c[0] = auStack_6c[0] & 0xffffff00;
          uStack_8._0_1_ = 0xc;
          if (0xf < uStack_14) {
            uVar16 = uStack_14 + 1;
            uVar15 = auStack_28[0];
            if (0xfff < uVar16) {
              uVar15 = *(uint *)(auStack_28[0] - 4);
              uVar16 = uStack_14 + 0x24;
              if (0x1f < (auStack_28[0] - uVar15) - 4) goto LAB_00b1d183;
            }
            FUN_01674ea0(uVar15,uVar16);
          }
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          FUN_005542c0(&DAT_0191c248,3);
          uVar15 = uStack_2c;
          uStack_70 = uStack_2c | 1;
          uStack_8._0_1_ = 0xf;
          FUN_0091d440(auStack_28);
          puVar10 = (undefined4 *)FUN_00563690(auStack_6c);
          puVar9 = puVar10 + 4;
          if (0xf < (uint)puVar10[5]) {
            puVar10 = (undefined4 *)*puVar10;
          }
          cVar6 = FUN_0055c360(puVar10,*puVar9,"productId",9);
          if ((cVar6 == '\0') || (cVar5 == '\0')) {
            bVar2 = false;
          }
          else {
            bVar2 = true;
          }
          if (0xf < uStack_58) {
            uVar17 = uStack_58 + 1;
            uVar16 = auStack_6c[0];
            if (0xfff < uVar17) {
              uVar16 = *(uint *)(auStack_6c[0] - 4);
              uVar17 = uStack_58 + 0x24;
              if (0x1f < (auStack_6c[0] - uVar16) - 4) goto LAB_00b1d183;
            }
            FUN_01674ea0(uVar16,uVar17);
          }
          uStack_2c = uVar15 & 0xfffffffc;
          uStack_5c = 0;
          uStack_58 = 0xf;
          auStack_6c[0] = auStack_6c[0] & 0xffffff00;
          uStack_8._0_1_ = 0xc;
          uStack_8._1_3_ = 0;
          if (0xf < uStack_14) {
            uVar17 = uStack_14 + 1;
            uVar16 = auStack_28[0];
            if (0xfff < uVar17) {
              uVar16 = *(uint *)(auStack_28[0] - 4);
              uVar17 = uStack_14 + 0x24;
              if (0x1f < (auStack_28[0] - uVar16) - 4) goto LAB_00b1d183;
            }
            FUN_01674ea0(uVar16,uVar17);
          }
          if (bVar2) {
            uStack_18 = 0;
            uStack_14 = 0xf;
            auStack_28[0] = auStack_28[0] & 0xffffff00;
            FUN_005542c0("ProductId",9);
            puVar9 = auStack_90;
            uStack_8._0_1_ = 0x10;
            FUN_005c4eb0(auStack_28);
            FUN_00632bc0(puVar9);
            uStack_8._0_1_ = 0xc;
            if (0xf < uStack_14) {
              uVar17 = uStack_14 + 1;
              uVar16 = auStack_28[0];
              if (0xfff < uVar17) {
                uVar16 = *(uint *)(auStack_28[0] - 4);
                uVar17 = uStack_14 + 0x24;
                if (0x1f < (auStack_28[0] - uVar16) - 4) goto LAB_00b1d183;
              }
              FUN_01674ea0(uVar16,uVar17);
            }
          }
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          FUN_005542c0(&DAT_0191c248,3);
          uStack_70 = uStack_2c | 4;
          uStack_8._0_1_ = 0x11;
          FUN_0091d440(auStack_28);
          puVar10 = (undefined4 *)FUN_00563690(auStack_6c);
          puVar9 = puVar10 + 4;
          if (0xf < (uint)puVar10[5]) {
            puVar10 = (undefined4 *)*puVar10;
          }
          cVar6 = FUN_0055c360(puVar10,*puVar9,"currencyTypeId",0xe);
          if ((cVar6 == '\0') || (cVar5 == '\0')) {
            bVar2 = false;
          }
          else {
            bVar2 = true;
          }
          if (0xf < uStack_58) {
            uVar17 = uStack_58 + 1;
            uVar16 = auStack_6c[0];
            if (0xfff < uVar17) {
              uVar16 = *(uint *)(auStack_6c[0] - 4);
              uVar17 = uStack_58 + 0x24;
              if (0x1f < (auStack_6c[0] - uVar16) - 4) goto LAB_00b1d183;
            }
            FUN_01674ea0(uVar16,uVar17);
          }
          uVar15 = uVar15 & 0xfffffff0;
          uStack_5c = 0;
          uStack_58 = 0xf;
          auStack_6c[0] = auStack_6c[0] & 0xffffff00;
          uStack_8._0_1_ = 0xc;
          uStack_8._1_3_ = 0;
          uStack_78 = uVar15;
          if (0xf < uStack_14) {
            uVar17 = uStack_14 + 1;
            uVar16 = auStack_28[0];
            if (0xfff < uVar17) {
              uVar16 = *(uint *)(auStack_28[0] - 4);
              uVar17 = uStack_14 + 0x24;
              if (0x1f < (auStack_28[0] - uVar16) - 4) goto LAB_00b1d183;
            }
            FUN_01674ea0(uVar16,uVar17);
          }
          uVar13 = auStack_90[0];
          uStack_2c = uVar15;
          if (bVar2) {
            uStack_18 = 0;
            uStack_14 = 0xf;
            auStack_28[0] = auStack_28[0] & 0xffffff00;
            FUN_005542c0("CurrencyType",0xc);
            uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
            puVar9 = (undefined4 *)FUN_005c4eb0(auStack_28);
            uVar14 = FUN_00b31840();
            *puVar9 = uVar14;
            iStack_88 = FUN_00b31ac0();
            iVar18 = puVar9[1];
            if (iVar18 == iStack_88) {
              puVar9[2] = uVar13;
            }
            else {
              if (iVar18 != 0) {
                (**(code **)(iVar18 + 8))(puVar9 + 2);
              }
              puVar9[2] = uVar13;
              puVar9[1] = iStack_88;
            }
            uStack_8._0_1_ = 0xc;
            uVar15 = uStack_78;
            if (0xf < uStack_14) {
              uVar16 = uStack_14 + 1;
              uVar15 = auStack_28[0];
              if (0xfff < uVar16) {
                uVar15 = *(uint *)(auStack_28[0] - 4);
                uVar16 = uStack_14 + 0x24;
                if (0x1f < (auStack_28[0] - uVar15) - 4) goto LAB_00b1d183;
              }
              FUN_01674ea0(uVar15,uVar16);
              uVar15 = uStack_78;
            }
          }
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          FUN_005542c0(&DAT_0191c248,3);
          uStack_70 = uVar15 | 0x10;
          uStack_8._0_1_ = 0x13;
          FUN_0091d440(auStack_28);
          puVar10 = (undefined4 *)FUN_00563690(auStack_6c);
          puVar9 = puVar10 + 4;
          if (0xf < (uint)puVar10[5]) {
            puVar10 = (undefined4 *)*puVar10;
          }
          cVar6 = FUN_0055c360(puVar10,*puVar9,"unitPrice",9);
          if ((cVar6 == '\0') || (cVar5 == '\0')) {
            bVar2 = false;
          }
          else {
            bVar2 = true;
          }
          if (0xf < uStack_58) {
            uVar16 = uStack_58 + 1;
            uVar15 = auStack_6c[0];
            if (0xfff < uVar16) {
              uVar15 = *(uint *)(auStack_6c[0] - 4);
              uVar16 = uStack_58 + 0x24;
              if (0x1f < (auStack_6c[0] - uVar15) - 4) goto LAB_00b1d183;
            }
            FUN_01674ea0(uVar15,uVar16);
          }
          uStack_2c = uStack_2c & 0xffffffcf;
          uStack_5c = 0;
          uStack_58 = 0xf;
          auStack_6c[0] = auStack_6c[0] & 0xffffff00;
          uStack_8._0_1_ = 0xc;
          uStack_8._1_3_ = 0;
          if (0xf < uStack_14) {
            uVar16 = uStack_14 + 1;
            uVar15 = auStack_28[0];
            if (0xfff < uVar16) {
              uVar15 = *(uint *)(auStack_28[0] - 4);
              uVar16 = uStack_14 + 0x24;
              if (0x1f < (auStack_28[0] - uVar15) - 4) goto LAB_00b1d183;
            }
            FUN_01674ea0(uVar15,uVar16);
          }
          if (bVar2) {
            uStack_5c = 0;
            uStack_58 = 0xf;
            auStack_6c[0] = auStack_6c[0] & 0xffffff00;
            FUN_005542c0("CurrencySpent",0xd);
            puVar9 = auStack_90;
            uStack_8._0_1_ = 0x14;
            FUN_005c4eb0(auStack_6c);
            FUN_00632bc0(puVar9);
            FUN_005507b0();
          }
          uStack_8._0_1_ = 0xb;
          iVar18 = iStack_30;
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar7 = piVar8[1] + -1;
            piVar8[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piVar8)();
              LOCK();
              iVar7 = piVar8[2] + -1;
              piVar8[2] = iVar7;
              UNLOCK();
              iVar18 = iStack_30;
              if (iVar7 == 0) {
                (**(code **)(*piVar8 + 4))();
                iVar18 = iStack_30;
              }
            }
          }
        }
        iStack_30 = iVar18 + 0xd0;
        uStack_54 = uStack_54 + 1;
        piVar11 = piStack_84;
        piVar8 = piStack_7c;
      } while (uStack_54 < (uint)((piStack_84[1] - *piStack_84) / 0xd0));
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar18 = piVar8[1] + -1;
      piVar8[1] = iVar18;
      UNLOCK();
      if (iVar18 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar18 = piVar8[2] + -1;
        piVar8[2] = iVar18;
        UNLOCK();
        if (iVar18 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  piVar8 = piStack_4c;
  *param_1 = 0;
  param_1[1] = 0;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    piStack_4c[1] = piStack_4c[1] + 1;
    UNLOCK();
  }
  *param_1 = uStack_50;
  param_1[1] = piStack_4c;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar18 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar18;
    UNLOCK();
    if (iVar18 == 0) {
      (**(code **)*piStack_4c)();
      LOCK();
      piVar11 = piVar8 + 2;
      iVar18 = *piVar11 + -1;
      *piVar11 = iVar18;
      UNLOCK();
      if (iVar18 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  piVar8 = piStack_80;
  if (piStack_80 != (int *)0x0) {
    LOCK();
    iVar18 = piStack_80[1] + -1;
    piStack_80[1] = iVar18;
    UNLOCK();
    if (iVar18 == 0) {
      (**(code **)*piStack_80)();
      LOCK();
      piVar11 = piVar8 + 2;
      iVar18 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar18 == 1) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23514 ; VA 0x00b1d1c0 ; FUN_00b1d1c0 */

void FUN_00b1d1c0(undefined4 param_1,code *param_2,undefined4 param_3,uint *param_4,uint *param_5)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017efc10;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eee1b9);
  auStack_6c[0] = 0;
  uVar1 = *param_5;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_5 + 2;
      uStack_7c = 0xb1d237;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_5[2];
      uStack_60 = param_5[3];
      uStack_5c = param_5[4];
      uStack_58 = param_5[5];
      uStack_54 = *(undefined8 *)(param_5 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_4;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_4 + 2);
    }
    else {
      uStack_a8 = param_4[2];
      uStack_a4 = param_4[3];
      uStack_a0 = param_4[4];
      uStack_9c = param_4[5];
      uStack_98 = *(undefined8 *)(param_4 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_008bd490();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0xb1d319;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_90 = 0xb1d333;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23515 ; VA 0x00b1d350 ; FUN_00b1d350 */

void FUN_00b1d350(undefined4 param_1,code *param_2,undefined4 param_3,uint *param_4,uint *param_5)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017efc30;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eee1b9);
  auStack_6c[0] = 0;
  uVar1 = *param_5;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_5 + 2;
      uStack_7c = 0xb1d3c7;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_5[2];
      uStack_60 = param_5[3];
      uStack_5c = param_5[4];
      uStack_58 = param_5[5];
      uStack_54 = *(undefined8 *)(param_5 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_4;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_4 + 2);
    }
    else {
      uStack_a8 = param_4[2];
      uStack_a4 = param_4[3];
      uStack_a0 = param_4[4];
      uStack_9c = param_4[5];
      uStack_98 = *(undefined8 *)(param_4 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_00960570();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0xb1d4a9;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_90 = 0xb1d4c3;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23516 ; VA 0x00b1d4e0 ; FUN_00b1d4e0 */

void FUN_00b1d4e0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  undefined8 uStack_a4;
  undefined4 uStack_9c;
  undefined auStack_98 [24];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_5c;
  uint *puStack_58;
  uint *puStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined8 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017efc48;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eee1b9);
  uVar2 = *param_5;
  uVar3 = param_5[1];
  uStack_4c = 0;
  uVar4 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    uStack_4c = uVar4;
    if ((uVar4 & 1) == 0) {
      puStack_54 = &uStack_44;
      uStack_50 = 0;
      puStack_58 = param_7 + 2;
      uStack_5c = 0xb1d568;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_44 = param_7[2];
      uStack_40 = param_7[3];
      uStack_3c = param_7[4];
      uStack_38 = param_7[5];
      uStack_34 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_70 = 0;
  uStack_9c = param_1;
  uVar4 = *param_6;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_6 + 2,&uStack_b4,0);
    }
    else {
      uStack_b4 = param_6[2];
      uStack_b0 = param_6[3];
      uStack_ac = param_6[4];
      uStack_a8 = param_6[5];
      uStack_a4 = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0(auStack_98,FUN_008e61f0);
  uStack_9c = 0xb1d5dc;
  FUN_008dc4b0();
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_7c = *param_4;
  uStack_78 = param_4[1];
  uStack_8 = 0xffffffff;
  uStack_80 = 0xb1d619;
  uStack_74 = uVar2;
  uStack_70 = uVar3;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23517 ; VA 0x00b1d630 ; FUN_00b1d630 */

void FUN_00b1d630(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  undefined8 uStack_a4;
  undefined4 uStack_9c;
  undefined auStack_98 [28];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_5c;
  uint *puStack_58;
  uint *puStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined8 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017efc48;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eee1b9);
  uVar1 = *param_5;
  uVar2 = *param_4;
  uVar3 = param_4[1];
  uStack_4c = 0;
  uVar4 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    uStack_4c = uVar4;
    if ((uVar4 & 1) == 0) {
      puStack_54 = &uStack_44;
      uStack_50 = 0;
      puStack_58 = param_7 + 2;
      uStack_5c = 0xb1d6c0;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_44 = param_7[2];
      uStack_40 = param_7[3];
      uStack_3c = param_7[4];
      uStack_38 = param_7[5];
      uStack_34 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_70 = 0;
  uStack_9c = param_1;
  uVar4 = *param_6;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_6 + 2,&uStack_b4,0);
    }
    else {
      uStack_b4 = param_6[2];
      uStack_b0 = param_6[3];
      uStack_ac = param_6[4];
      uStack_a8 = param_6[5];
      uStack_a4 = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0(auStack_98,FUN_009e25f0);
  uStack_9c = 0xb1d734;
  FUN_009604b0();
  uStack_8 = 0xffffffff;
  uStack_7c = 0xb1d74a;
  uStack_78 = uVar2;
  uStack_74 = uVar3;
  uStack_70 = uVar1;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23518 ; VA 0x00b1d760 ; FUN_00b1d760 */

void FUN_00b1d760(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uStack_b8;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined auStack_9c [24];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_60;
  uint *puStack_5c;
  uint *puStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  undefined8 uStack_38;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0738;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eee1b9);
  uVar1 = *param_5;
  uVar2 = param_5[1];
  uVar3 = *param_4;
  uVar4 = param_4[1];
  uStack_50 = 0;
  uVar5 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    uStack_50 = uVar5;
    if ((uVar5 & 1) == 0) {
      puStack_58 = &uStack_48;
      uStack_54 = 0;
      puStack_5c = param_7 + 2;
      uStack_60 = 0xb1d7f6;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))();
    }
    else {
      uStack_48 = param_7[2];
      uStack_44 = param_7[3];
      uStack_40 = param_7[4];
      uStack_3c = param_7[5];
      uStack_38 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_74 = 0;
  uStack_a0 = param_1;
  uVar5 = *param_6;
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(param_6 + 2,&uStack_b8,0);
    }
    else {
      uStack_b8 = param_6[2];
      uStack_b4 = param_6[3];
      uStack_b0 = param_6[4];
      uStack_ac = param_6[5];
      uStack_a8 = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0(auStack_9c,FUN_008e61f0);
  uStack_a0 = 0xb1d86a;
  FUN_008dc4b0();
  uStack_8 = 0xffffffff;
  uStack_84 = 0xb1d883;
  uStack_80 = uVar3;
  uStack_7c = uVar4;
  uStack_78 = uVar1;
  uStack_74 = uVar2;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23519 ; VA 0x00b1d8a0 ; FUN_00b1d8a0 */

void FUN_00b1d8a0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,undefined4 *param_6,undefined4 param_7,undefined *param_8,
                 uint *param_9,uint *param_10)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  undefined8 uStack_a4;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_70;
  undefined4 uStack_5c;
  uint *puStack_58;
  uint *puStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined8 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017efc70;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eee1b9);
  uVar1 = *param_8;
  uVar2 = *param_6;
  uVar3 = *param_5;
  uVar4 = param_5[1];
  uVar5 = *param_4;
  uStack_4c = 0;
  uVar6 = *param_10;
  ExceptionList = &pvStack_10;
  if (uVar6 != 0) {
    uStack_4c = uVar6;
    if ((uVar6 & 1) == 0) {
      puStack_54 = &uStack_44;
      uStack_50 = 0;
      puStack_58 = param_10 + 2;
      uStack_5c = 0xb1d942;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar6 & 0xfffffffe))();
    }
    else {
      uStack_44 = param_10[2];
      uStack_40 = param_10[3];
      uStack_3c = param_10[4];
      uStack_38 = param_10[5];
      uStack_34 = *(undefined8 *)(param_10 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_70 = 0;
  uStack_9c = param_1;
  uVar6 = *param_9;
  if (uVar6 != 0) {
    if ((uVar6 & 1) == 0) {
      (**(code **)(uVar6 & 0xfffffffe))(param_9 + 2,&uStack_b4,0);
    }
    else {
      uStack_b4 = param_9[2];
      uStack_b0 = param_9[3];
      uStack_ac = param_9[4];
      uStack_a8 = param_9[5];
      uStack_a4 = *(undefined8 *)(param_9 + 6);
    }
  }
  FUN_008bfbf0(&uStack_98,FUN_009e25f0);
  uStack_9c = 0xb1d9b9;
  FUN_009604b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_8c = param_7;
  uStack_90 = 0xb1d9cd;
  uStack_70 = CONCAT31((int3)((uint)param_8 >> 8),uVar1);
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_9c = 0xb1d9e6;
  uStack_98 = uVar5;
  uStack_94 = uVar3;
  uStack_90 = uVar4;
  uStack_8c = uVar2;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23520 ; VA 0x00b1da00 ; FUN_00b1da00 */

void FUN_00b1da00(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
                 undefined8 param_18)

{
  int iVar1;
  uint *puVar2;
  int *piVar3;
  uint auStack_138 [2];
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 *puStack_124;
  ulonglong uStack_120;
  uint auStack_118 [2];
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 *puStack_104;
  undefined8 uStack_100;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017efcbb;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_100 = 0x1800b1da2e;
  ExceptionList = &pvStack_10;
  piStack_18 = (int *)FUN_01674e20();
  if (piStack_18 == (int *)0x0) {
    piVar3 = (int *)0x0;
  }
  else {
    piStack_18[1] = 1;
    piStack_18[2] = 1;
    *piStack_18 = (int)std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    piStack_18[3] = 0;
    piStack_18[4] = 0;
    piStack_18[5] = 0;
    piVar3 = piStack_18;
  }
  uStack_8._0_1_ = 4;
  uStack_100 = CONCAT44(0xb1da79,(undefined4)uStack_100);
  piStack_20 = piVar3 + 3;
  piStack_1c = piVar3;
  uStack_f0 = FUN_008881d0();
  iStack_ec = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_3;
  piStack_e4 = param_4;
  uStack_100 = CONCAT44(0xb1dabf,(undefined4)uStack_100);
  iStack_ec = FUN_0058c000();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (piVar3[5] == piVar3[4]) {
    uStack_100 = CONCAT44(&uStack_f0,piVar3[4]);
    puStack_104 = (undefined4 *)0xb1daf0;
    FUN_005ca4f0();
  }
  else {
    uStack_100 = CONCAT44(&uStack_f0,0xb1dadf);
    FUN_005caf00();
    piVar3[4] = piVar3[4] + 0xd0;
  }
  uStack_8._0_1_ = 6;
  if (iStack_ec != 0) {
    uStack_100 = CONCAT44(&uStack_e8,0xb1db0a);
    (**(code **)(iStack_ec + 8))();
  }
  piStack_18 = (int *)auStack_118;
  puStack_14 = (undefined *)auStack_118;
  uStack_8._0_1_ = 4;
  auStack_118[0] = 0;
  puVar2 = auStack_118;
  if (param_12 != 0) {
    auStack_118[0] = param_12;
    if ((param_12 & 1) == 0) {
      uStack_120 = ZEXT48(&uStack_110);
      puStack_124 = &param_14;
      uStack_128 = 0xb1db55;
      (**(code **)(param_12 & 0xfffffffe))();
      puVar2 = (uint *)piStack_18;
    }
    else {
      uStack_110 = param_14;
      uStack_10c = param_15;
      uStack_108 = param_16;
      puStack_104 = (undefined4 *)param_17;
      uStack_100 = param_18;
      puVar2 = auStack_118;
    }
  }
  piStack_18 = (int *)puVar2;
  puStack_14 = (undefined *)auStack_138;
  uStack_8._0_1_ = 7;
  auStack_138[0] = 0;
  puVar2 = auStack_138;
  if (param_5 != 0) {
    auStack_138[0] = param_5;
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_130,0);
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_130 = param_7;
      uStack_12c = param_8;
      uStack_128 = param_9;
      puStack_124 = param_10;
      uStack_120 = param_11;
      puVar2 = auStack_138;
    }
  }
  puStack_14 = (undefined *)puVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00f50180(param_1,param_2,piVar3 + 3,piVar3);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = piVar3[1] + -1;
    piVar3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_100 = CONCAT44(0xb1dc09,(undefined4)uStack_100);
      (**(code **)*piVar3)();
      LOCK();
      iVar1 = piVar3[2] + -1;
      piVar3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_100 = CONCAT44(0xb1dc19,(undefined4)uStack_100);
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = param_2[1] + -1;
    param_2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_100 = CONCAT44(0xb1dc2f,(undefined4)uStack_100);
      (**(code **)*param_2)();
      LOCK();
      iVar1 = param_2[2] + -1;
      param_2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_100 = CONCAT44(0xb1dc3f,(undefined4)uStack_100);
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_100 = CONCAT44(0xb1dc55,(undefined4)uStack_100);
      (**(code **)*param_4)();
      LOCK();
      piVar3 = param_4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        uStack_100 = CONCAT44(0xb1dc64,(undefined4)uStack_100);
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_104 = &param_7;
    uStack_100 = CONCAT44(2,puStack_104);
    uStack_108 = 0xb1dc85;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 9;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_104 = &param_14;
    uStack_100 = CONCAT44(2,puStack_104);
    uStack_108 = 0xb1dcb3;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23521 ; VA 0x00b1dcd0 ; FUN_00b1dcd0 */

void FUN_00b1dcd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 *param_10,ulonglong param_11,uint param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined8 param_18)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  uint *puVar4;
  undefined4 *puVar5;
  uint auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  ulonglong uStack_50;
  uint auStack_48 [2];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017efcf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_30 = CONCAT44(auStack_20,0xb1dcfd);
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_00b264d0();
  puStack_14 = (undefined *)auStack_48;
  puStack_18 = (undefined *)auStack_48;
  uStack_8._0_1_ = 2;
  pcVar2 = *(code **)(*(int *)*puVar5 + 4);
  auStack_48[0] = 0;
  puVar4 = auStack_48;
  if (param_12 != 0) {
    auStack_48[0] = param_12;
    if ((param_12 & 1) == 0) {
      uStack_50 = ZEXT48(&uStack_40);
      puStack_54 = &param_14;
      uStack_58 = 0xb1dd4c;
      (**(code **)(param_12 & 0xfffffffe))();
      puVar4 = (uint *)puStack_14;
    }
    else {
      uStack_40 = param_14;
      uStack_3c = param_15;
      uStack_38 = param_16;
      uStack_34 = param_17;
      uStack_30 = param_18;
      puVar4 = auStack_48;
    }
  }
  puStack_14 = (undefined *)puVar4;
  puStack_18 = (undefined *)auStack_68;
  uStack_8._0_1_ = 3;
  auStack_68[0] = 0;
  puVar4 = auStack_68;
  if (param_5 != 0) {
    auStack_68[0] = param_5;
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_60,0);
      puVar4 = (uint *)puStack_18;
    }
    else {
      uStack_60 = param_7;
      uStack_5c = param_8;
      uStack_58 = param_9;
      puStack_54 = param_10;
      uStack_50 = param_11;
      puVar4 = auStack_68;
    }
  }
  puStack_18 = (undefined *)puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  (*pcVar2)(param_1,param_2,param_3,param_4);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_5 & 0xfffffffe))(&param_7,&param_7,2);
  }
  uStack_8 = 5;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_12 & 0xfffffffe))(&param_14,&param_14,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23522 ; VA 0x00b1de40 ; FUN_00b1de40 */

/* WARNING: Removing unreachable block (ram,0x00b1debf) */
/* WARNING: Removing unreachable block (ram,0x00b1dedb) */
/* WARNING: Removing unreachable block (ram,0x00b1dec7) */
/* WARNING: Removing unreachable block (ram,0x00b1df76) */
/* WARNING: Removing unreachable block (ram,0x00b1df7a) */
/* WARNING: Removing unreachable block (ram,0x00b1df83) */

void __thiscall FUN_00b1de40(int param_1,int param_2)

{
  code *pcVar1;
  uint uVar2;
  uint *puVar3;
  uint auStack_54 [2];
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017efd18;
  pvStack_10 = ExceptionList;
  puVar3 = (uint *)(*(int *)(param_1 + 0x38) + param_2);
  uStack_14 = *(undefined4 *)(param_1 + 0x44);
  pcVar1 = *(code **)(param_1 + 0x40);
  uStack_8 = 0;
  uVar2 = *puVar3;
  auStack_54[0] = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    auStack_54[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 2,&uStack_4c,0);
    }
    else {
      uStack_4c = puVar3[2];
      uStack_48 = puVar3[3];
      uStack_44 = puVar3[4];
      uStack_40 = puVar3[5];
      uStack_3c = *(undefined8 *)(puVar3 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_34 = 0;
  uStack_8._0_1_ = 2;
  FUN_00b31c10(puVar3);
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 1;
  if (pcVar1 != (code *)0x0) {
    (*pcVar1)(auStack_54);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((auStack_54[0] != 0) && ((auStack_54[0] & 1) == 0)) &&
     (*(code **)(auStack_54[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_54[0] & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23523 ; VA 0x00b1dfa0 ; FUN_00b1dfa0 */

undefined4 * __thiscall
FUN_00b1dfa0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017efd61;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b218c0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23524 ; VA 0x00b1e150 ; FUN_00b1e150 */

undefined4 * __thiscall
FUN_00b1e150(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017efda1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_006ef180;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23525 ; VA 0x00b1e300 ; FUN_00b1e300 */

undefined4 * __thiscall
FUN_00b1e300(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017efde1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b21a10;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23526 ; VA 0x00b1e4b0 ; FUN_00b1e4b0 */

undefined4 * __thiscall
FUN_00b1e4b0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017efe21;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b21c70;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23527 ; VA 0x00b1e660 ; FUN_00b1e660 */

undefined4 * __thiscall
FUN_00b1e660(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017efe61;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b21e20;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23528 ; VA 0x00b1e810 ; FUN_00b1e810 */

undefined4 * __thiscall
FUN_00b1e810(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017efea1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b22000;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23529 ; VA 0x00b1e9c0 ; FUN_00b1e9c0 */

undefined4 * __thiscall
FUN_00b1e9c0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017efee1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b22180;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23530 ; VA 0x00b1eb70 ; FUN_00b1eb70 */

undefined4 * __thiscall
FUN_00b1eb70(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eff21;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b22300;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23531 ; VA 0x00b1ed20 ; FUN_00b1ed20 */

undefined4 * __thiscall
FUN_00b1ed20(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eff61;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b224b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23532 ; VA 0x00b1eed0 ; FUN_00b1eed0 */

undefined4 * __thiscall
FUN_00b1eed0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017effa1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b22690;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23533 ; VA 0x00b1f080 ; FUN_00b1f080 */

undefined4 * __thiscall
FUN_00b1f080(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017effe1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b22800;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23534 ; VA 0x00b1f220 ; FUN_00b1f220 */

undefined4 * __thiscall
FUN_00b1f220(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0021;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009b0180;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23535 ; VA 0x00b1f3d0 ; FUN_00b1f3d0 */

void __fastcall FUN_00b1f3d0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x30);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    *(undefined8 *)(puVar1 + 10) = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00b14f20(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 23536 ; VA 0x00b1f430 ; FUN_00b1f430 */

void __fastcall FUN_00b1f430(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x30);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    *(undefined8 *)(puVar1 + 10) = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00b14fa0(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 23537 ; VA 0x00b1f490 ; FUN_00b1f490 */

void FUN_00b1f490(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00b317b0();
    *param_2 = uVar3;
    iVar4 = FUN_00b31a50();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 23538 ; VA 0x00b1f4f0 ; FUN_00b1f4f0 */

void FUN_00b1f4f0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b31840();
    *param_2 = uVar3;
    iVar4 = FUN_00b31ac0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 23539 ; VA 0x00b1f550 ; FUN_00b1f550 */

void FUN_00b1f550(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b318f0();
    *param_2 = uVar3;
    iVar4 = FUN_00b31b30();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 23540 ; VA 0x00b1f5b0 ; FUN_00b1f5b0 */

void FUN_00b1f5b0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b319a0();
    *param_2 = uVar3;
    iVar4 = FUN_00b31ba0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 23541 ; VA 0x00b1f610 ; FUN_00b1f610 */

void FUN_00b1f610(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b317b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23542 ; VA 0x00b1f650 ; FUN_00b1f650 */

void FUN_00b1f650(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b31840();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23543 ; VA 0x00b1f690 ; FUN_00b1f690 */

void FUN_00b1f690(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b318f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23544 ; VA 0x00b1f6d0 ; FUN_00b1f6d0 */

void FUN_00b1f6d0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b319a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23545 ; VA 0x00b1f710 ; FUN_00b1f710 */

undefined4 * FUN_00b1f710(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00671f90(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 23546 ; VA 0x00b1f780 ; FUN_00b1f780 */

void __thiscall FUN_00b1f780(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088c8c0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar5;
    iStack_1b8 = FUN_005c9cc0();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23547 ; VA 0x00b1f9a0 ; FUN_00b1f9a0 */

void __thiscall FUN_00b1f9a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar4;
    uStack_e0 = puVar4[1];
    iStack_e8 = FUN_005c9e80();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_28c = FUN_0088da50();
    iStack_288 = 0;
    uStack_284 = *puVar4;
    uStack_280 = puVar4[1];
    iStack_288 = FUN_005c9e80();
    puVar4 = &uStack_28c;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(&uStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23548 ; VA 0x00b1fcc0 ; FUN_00b1fcc0 */

void __thiscall FUN_00b1fcc0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar6 = *(undefined4 **)(param_1 + 0x40);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uStack_8 = 1;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = FUN_0088cb40();
    iStack_1b8 = 0;
    FUN_0054ef60(iVar2);
    iStack_1b8 = FUN_005c9d30();
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23549 ; VA 0x00b1ff10 ; FUN_00b1ff10 */

void __thiscall FUN_00b1ff10(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uStack_8 = 1;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = thunk_FUN_00b317b0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar5;
    iStack_1b8 = FUN_00b31a50();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = thunk_FUN_00b317b0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23550 ; VA 0x00b20160 ; FUN_00b20160 */

void __thiscall FUN_00b20160(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uStack_8 = 1;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088da50();
    iStack_1b8 = 0;
    uStack_1b4 = *puVar5;
    uStack_1b0 = puVar5[1];
    iStack_1b8 = FUN_005c9e80();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(&uStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23551 ; VA 0x00b203b0 ; FUN_00b203b0 */

void __thiscall FUN_00b203b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uStack_8 = 1;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar6 = 1;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_005c9e80();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088da50();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x48);
  if (puVar2 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_28c = FUN_0088daf0();
    iStack_288 = 0;
    auStack_284[0] = *puVar2;
    iStack_288 = FUN_005c9ef0();
    puVar5 = &uStack_28c;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23552 ; VA 0x00b206f0 ; FUN_00b206f0 */

void __thiscall
FUN_00b206f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int *piVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uStack_8 = 1;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar6 = 1;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_005c9e80();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088da50();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x48);
  if (puVar2 == (undefined *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = FUN_0088daf0();
    iStack_e8 = 0;
    uStack_e4 = CONCAT31(uStack_e4._1_3_,*puVar2);
    iStack_e8 = FUN_005c9ef0();
    puVar5 = &uStack_ec;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    uStack_28c = FUN_00b31840();
    iStack_288 = 0;
    auStack_284[0] = *puVar5;
    iStack_288 = FUN_00b31ac0();
    puVar5 = &uStack_28c;
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_00b31840();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23553 ; VA 0x00b20b20 ; FUN_00b20b20 */

void __thiscall FUN_00b20b20(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar4;
    uStack_e0 = puVar4[1];
    iStack_e8 = FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar4;
    uStack_e0 = puVar4[1];
    iStack_e8 = FUN_005c9e80();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar1 = *(undefined **)(param_1 + 0x48);
  if (puVar1 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_28c = FUN_0088daf0();
    iStack_288 = 0;
    auStack_284[0] = *puVar1;
    iStack_288 = FUN_005c9ef0();
    puVar4 = &uStack_28c;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23554 ; VA 0x00b20e40 ; FUN_00b20e40 */

void __thiscall
FUN_00b20e40(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf757;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_008881d0();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_00b318f0();
    iStack_e8 = 0;
    uStack_e4 = *puVar5;
    iStack_e8 = FUN_00b31b30();
    puStack_18 = &uStack_ec;
    uVar6 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar6;
  uVar3 = FUN_00b318f0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_005c9e80();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088da50();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    uStack_e4 = *puVar5;
    iStack_e8 = FUN_005c9cc0();
    puVar5 = &uStack_ec;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088c8c0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x4c);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar5 = &uStack_ec;
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x40) != 0) {
    uVar6 = uVar6 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x50);
  if (puVar2 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 0x11;
    uVar6 = uVar6 | 0x200;
  }
  else {
    uStack_28c = FUN_0088daf0();
    iStack_288 = 0;
    auStack_284[0] = *puVar2;
    iStack_288 = FUN_005c9ef0();
    puVar5 = &uStack_28c;
    uStack_8 = 0x10;
    uVar6 = uVar6 | 0x100;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x200) != 0) {
    uVar6 = uVar6 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x100) != 0) && (uStack_8 = 0x13, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23555 ; VA 0x00b21350 ; FUN_00b21350 */

void __thiscall FUN_00b21350(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_008881d0();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar3 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar4;
    uStack_e0 = puVar4[1];
    iStack_e8 = FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar3 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar3;
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar3;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar3 & 1) != 0) {
    uVar3 = uVar3 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 5;
    uVar3 = uVar3 | 8;
  }
  else {
    uStack_1bc = FUN_00b318f0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar4;
    iStack_1b8 = FUN_00b31b30();
    puVar4 = &uStack_1bc;
    uStack_8 = 4;
    uVar3 = uVar3 | 4;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_00b318f0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar4);
  if ((uVar3 & 8) != 0) {
    uVar3 = uVar3 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar3;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar3 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23556 ; VA 0x00b21580 ; FUN_00b21580 */

void __thiscall FUN_00b21580(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uStack_8 = 1;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088da50();
    iStack_1b8 = 0;
    uStack_1b4 = *puVar5;
    uStack_1b0 = puVar5[1];
    iStack_1b8 = FUN_005c9e80();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(&uStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23557 ; VA 0x00b217d0 ; FUN_00b217d0 */

int __thiscall FUN_00b217d0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_00b14fa0(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x30);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 23558 ; VA 0x00b21830 ; FUN_00b21830 */

int __thiscall FUN_00b21830(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_01674ea0(puVar1,0x20);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
    iVar2 = iVar2 + 1;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 23559 ; VA 0x00b21870 ; FUN_00b21870 */

int __thiscall FUN_00b21870(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_006f8c50();
    FUN_01674ea0(puVar1,0x28);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 23560 ; VA 0x00b218c0 ; FUN_00b218c0 */

int FUN_00b218c0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0061;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_f0 = FUN_0088cbe0();
  uStack_ec = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_2;
  piStack_e4 = param_3;
  uStack_ec = FUN_00630900();
  uStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 3;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 4;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23561 ; VA 0x00b21a10 ; FUN_00b21a10 */

int FUN_00b21a10(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  int in_stack_00000028;
  uint in_stack_0000003c;
  undefined in_stack_00000040;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  int *piStack_354;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f00d2;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 3;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_360 = FUN_0088cdc0();
  uStack_35c = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_358 = param_2;
  piStack_354 = param_3;
  uStack_35c = FUN_006309e0();
  uStack_8._0_1_ = 4;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  FUN_0054ef60(&param_4);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&stack0x00000028);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 6;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000040;
  uStack_ec = FUN_005c9ef0();
  uStack_8._0_1_ = 7;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_360,&uStack_20,pcVar3);
  uStack_8._0_1_ = 8;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 9;
  FUN_00577b20();
  uStack_8._0_1_ = 3;
  FUN_016f32d1(&uStack_360,0xd0,4,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar6 = in_stack_00000024 + 1;
    uVar7 = param_4;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(param_4 - 4);
      uVar6 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(uVar7,uVar6);
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (0xf < in_stack_0000003c) {
    uVar7 = in_stack_0000003c + 1;
    iVar5 = in_stack_00000028;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(in_stack_00000028 + -4);
      uVar7 = in_stack_0000003c + 0x24;
      if (0x1f < (in_stack_00000028 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23562 ; VA 0x00b21c70 ; FUN_00b21c70 */

int FUN_00b21c70(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_00000024;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0124;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&param_4);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 5;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar6 = in_stack_00000024 + 1;
    iVar5 = param_4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_4 + -4);
      uVar6 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23563 ; VA 0x00b21e20 ; FUN_00b21e20 */

int FUN_00b21e20(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_00000024;
  undefined in_stack_00000028;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  int *piStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e485f;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_290 = FUN_0088cdc0();
  uStack_28c = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_288 = param_2;
  piStack_284 = param_3;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&param_4);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000028;
  uStack_ec = FUN_005c9ef0();
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 6;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar6 = in_stack_00000024 + 1;
    iVar5 = param_4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_4 + -4);
      uVar6 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23564 ; VA 0x00b22000 ; FUN_00b22000 */

int FUN_00b22000(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3c7c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_f0 = thunk_FUN_00b317b0();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_00b31a50();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 4;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23565 ; VA 0x00b22180 ; FUN_00b22180 */

int FUN_00b22180(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3c7c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088da50();
  uStack_e8 = param_4;
  uStack_ec = 0;
  uStack_e4 = param_5;
  uStack_ec = FUN_005c9e80();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 4;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23566 ; VA 0x00b22300 ; FUN_00b22300 */

int FUN_00b22300(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
                undefined param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  int *piStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0177;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_290 = FUN_0088cdc0();
  uStack_28c = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_288 = param_2;
  piStack_284 = param_3;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_1c0 = FUN_0088da50();
  uStack_1b8 = param_4;
  uStack_1bc = 0;
  uStack_1b4 = param_5;
  uStack_1bc = FUN_005c9e80();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_6;
  uStack_ec = FUN_005c9ef0();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 5;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23567 ; VA 0x00b224b0 ; FUN_00b224b0 */

int FUN_00b224b0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
                undefined param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  int *piStack_354;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f01e2;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_360 = FUN_0088cdc0();
  uStack_35c = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_358 = param_2;
  piStack_354 = param_3;
  uStack_35c = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_290 = FUN_0088da50();
  uStack_288 = param_4;
  uStack_28c = 0;
  uStack_284 = param_5;
  uStack_28c = FUN_005c9e80();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088daf0();
  uStack_1bc = 0;
  uStack_1b8 = param_6;
  uStack_1bc = FUN_005c9ef0();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_00b31840();
  uStack_ec = 0;
  uStack_e8 = param_7;
  uStack_ec = FUN_00b31ac0();
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_360,&uStack_20,pcVar3);
  uStack_8._0_1_ = 6;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_360,0xd0,4,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23568 ; VA 0x00b22690 ; FUN_00b22690 */

void FUN_00b22690(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined param_6)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e104f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_290 = FUN_0088da50();
  uStack_288 = param_2;
  uStack_28c = 0;
  uStack_284 = param_3;
  uStack_28c = FUN_005c9e80();
  iStack_8._0_1_ = 1;
  uStack_1c0 = FUN_0088da50();
  uStack_1b8 = param_4;
  uStack_1bc = 0;
  uStack_1b4 = param_5;
  uStack_1bc = FUN_005c9e80();
  iStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_6;
  uStack_ec = FUN_005c9ef0();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,piVar1);
  iStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 5;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  iStack_8 = 6;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23569 ; VA 0x00b22800 ; FUN_00b22800 */

void FUN_00b22800(int param_1,undefined4 param_2,undefined4 param_3,undefined param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_0088da50();
  uStack_1b8 = param_2;
  uStack_1bc = 0;
  uStack_1b4 = param_3;
  uStack_1bc = FUN_005c9e80();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_005c9ef0();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23570 ; VA 0x00b22930 ; FUN_00b22930 */

int FUN_00b22930(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  pcVar3 = *(code **)(param_1 + 0x18);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_2,param_3,param_4,param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23571 ; VA 0x00b22a00 ; FUN_00b22a00 */

int FUN_00b22a00(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef008;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00b1b120(uVar3,param_2,param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23572 ; VA 0x00b22aa0 ; FUN_00b22aa0 */

int FUN_00b22aa0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined *)(param_1 + 0x24);
  uVar4 = *(undefined4 *)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar5 = FUN_00b1b120(uVar4,uVar3,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23573 ; VA 0x00b22b40 ; FUN_00b22b40 */

void FUN_00b22b40(int param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *(undefined4 *)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  FUN_00b1b4b0(uVar1);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23574 ; VA 0x00b22bd0 ; FUN_00b22bd0 */

undefined4 __thiscall FUN_00b22bd0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar7 = param_2[1];
  uVar5 = uVar7;
  if (((int)uVar7 < 1) && ((int)uVar7 < 0)) {
    uVar5 = ~uVar7;
  }
  uVar5 = (uVar5 >> 2) + uVar5 * 0x40 + *param_2 ^ uVar5;
  uVar6 = uVar5 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    for (piVar2 = (int *)*piVar1;
        (piVar2 != (int *)0x0 && ((uint)piVar2[1] % *(uint *)(param_1 + 4) == uVar6));
        piVar2 = (int *)*piVar2) {
      if ((piVar2[1] == uVar5) && ((*param_2 == piVar2[2] && (uVar7 == piVar2[3])))) {
        uVar3 = FUN_0057d5a0(piVar1,*piVar2);
        if (*piVar1 != 0) {
          uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
          if (uVar6 == uVar7) {
            return uVar3;
          }
          *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar1;
        }
        puVar4 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
        if ((int *)*puVar4 == piVar1) {
          *puVar4 = 0;
        }
        return uVar3;
      }
      piVar1 = piVar2;
    }
  }
  return 0;
}



/* FUNCTION 23575 ; VA 0x00b22cc0 ; FUN_00b22cc0 */

void __thiscall FUN_00b22cc0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  code *pcVar3;
  char cVar4;
  uint uVar5;
  undefined *puVar6;
  undefined4 uVar7;
  int *piVar8;
  int iVar9;
  int *piVar10;
  undefined uVar11;
  uint in_stack_0000002c;
  undefined4 uStack_1f8;
  int iStack_1f4;
  undefined auStack_1f0 [200];
  undefined4 uStack_128;
  int iStack_124;
  undefined auStack_120 [200];
  int aiStack_58 [5];
  uint uStack_44;
  undefined uStack_40;
  undefined auStack_34 [4];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined auStack_24 [4];
  undefined8 uStack_20;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar10 = param_3;
  puStack_c = &LAB_017f023c;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar5 = (**(code **)*param_3)();
  if (uVar5 < 5) {
LAB_00b22d86:
    if (*(undefined **)(param_1 + 0x50) != (undefined *)0x0) {
      uVar11 = **(undefined **)(param_1 + 0x50);
      goto LAB_00b22d93;
    }
    uVar7 = 5;
LAB_00b230bc:
    FUN_016756b0(auStack_34,"Argument %d missing or nil",uVar7);
    puVar6 = auStack_34;
    goto LAB_00b230fb;
  }
  uStack_128 = FUN_00888530();
  iStack_124 = 0;
  uStack_8._0_1_ = 2;
  cVar4 = (**(code **)(*piVar10 + 4))(5,&uStack_128);
  if (cVar4 == '\0') {
    uStack_8._0_1_ = 4;
    if (iStack_124 != 0) {
      (**(code **)(iStack_124 + 8))(auStack_120);
    }
    uStack_8._0_1_ = 1;
    goto LAB_00b22d86;
  }
  puVar6 = (undefined *)FUN_0088bcc0();
  param_3 = (int *)CONCAT13(*puVar6,param_3._0_3_);
  uStack_8._0_1_ = 3;
  uVar11 = *puVar6;
  if (iStack_124 != 0) {
    (**(code **)(iStack_124 + 8))(auStack_120);
    uVar11 = param_3._3_1_;
  }
  uStack_8._0_1_ = 1;
LAB_00b22d93:
  param_3 = (int *)CONCAT13(uVar11,param_3._0_3_);
  uVar5 = (**(code **)*piVar10)();
  if (uVar5 < 4) {
LAB_00b22e50:
    if (*(int *)(param_1 + 0x4c) == 0) {
      uVar7 = 4;
      goto LAB_00b230bc;
    }
    FUN_0054ef60(*(int *)(param_1 + 0x4c));
  }
  else {
    uStack_30 = 0;
    uStack_2c = 0xf;
    uStack_40 = 0;
    uStack_8._0_1_ = 5;
    uStack_128 = FUN_00888530();
    iStack_124 = 0;
    uStack_8._0_1_ = 6;
    cVar4 = (**(code **)(*piVar10 + 4))(4,&uStack_128);
    if (cVar4 == '\0') {
      uStack_8._0_1_ = 8;
      if (iStack_124 != 0) {
        (**(code **)(iStack_124 + 8))(auStack_120);
      }
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      goto LAB_00b22e50;
    }
    uVar7 = FUN_008898b0();
    FUN_0054ef60(uVar7);
    uStack_8._0_1_ = 7;
    if (iStack_124 != 0) {
      (**(code **)(iStack_124 + 8))(auStack_120);
    }
    FUN_005507b0();
  }
  uStack_8._0_1_ = 9;
  uVar5 = (**(code **)*piVar10)();
  if (uVar5 < 3) {
LAB_00b22eff:
    if (*(int **)(param_1 + 0x48) != (int *)0x0) {
      iStack_28 = **(int **)(param_1 + 0x48);
      goto LAB_00b22f0c;
    }
    uVar7 = 3;
  }
  else {
    uStack_1f8 = FUN_00888530();
    iStack_1f4 = 0;
    uStack_8._0_1_ = 10;
    cVar4 = (**(code **)(*piVar10 + 4))(3,&uStack_1f8);
    if (cVar4 == '\0') {
      uStack_8._0_1_ = 0xc;
      if (iStack_1f4 != 0) {
        (**(code **)(iStack_1f4 + 8))(auStack_1f0);
      }
      uStack_8._0_1_ = 9;
      goto LAB_00b22eff;
    }
    piVar8 = (int *)FUN_00889220();
    iStack_18 = *piVar8;
    uStack_8._0_1_ = 0xb;
    if (iStack_1f4 != 0) {
      (**(code **)(iStack_1f4 + 8))(auStack_1f0);
    }
    uStack_8._0_1_ = 9;
    iStack_28 = iStack_18;
LAB_00b22f0c:
    uStack_20 = FUN_009b3df0(piVar10,param_1 + 0x44);
    iVar9 = (**(code **)*piVar10)();
    if (iVar9 != 0) {
      pcVar3 = *(code **)(*piVar10 + 0x38);
      uVar7 = FUN_00b318f0();
      cVar4 = (*pcVar3)(1,uVar7,&iStack_18);
      iVar9 = iStack_18;
      if (cVar4 != '\0') goto LAB_00b22fea;
      uStack_1f8 = FUN_00888530();
      iStack_1f4 = 0;
      uStack_8._0_1_ = 0xd;
      cVar4 = (**(code **)(*piVar10 + 4))(1,&uStack_1f8);
      if (cVar4 != '\0') {
        piVar10 = (int *)FUN_00b14cc0();
        iVar9 = *piVar10;
        uStack_8._0_1_ = 0xe;
        if (iStack_1f4 != 0) {
          (**(code **)(iStack_1f4 + 8))(auStack_1f0);
        }
        uStack_8._0_1_ = 9;
        goto LAB_00b22fea;
      }
      uStack_8._0_1_ = 0xf;
      if (iStack_1f4 != 0) {
        (**(code **)(iStack_1f4 + 8))(auStack_1f0);
      }
      uStack_8._0_1_ = 9;
      param_1 = iStack_14;
    }
    if (*(int **)(param_1 + 0x40) != (int *)0x0) {
      iStack_14 = param_1;
      iVar9 = **(int **)(param_1 + 0x40);
LAB_00b22fea:
      puVar1 = (undefined4 *)(iStack_14 + 0x3c);
      puVar2 = (undefined4 *)(iStack_14 + 0x38);
      iStack_14 = iVar9;
      FUN_00b1d8a0(param_2,*puVar2,*puVar1,&iStack_14,&uStack_20,&iStack_28,aiStack_58,
                   (int)&param_3 + 3,&param_4,&stack0x0000002c);
      uStack_8._0_1_ = 1;
      uVar11 = (undefined)uStack_8;
      uStack_8._0_1_ = 1;
      if (0xf < uStack_44) {
        uVar5 = uStack_44 + 1;
        iVar9 = aiStack_58[0];
        if (0xfff < uVar5) {
          iVar9 = *(int *)(aiStack_58[0] + -4);
          uVar5 = uStack_44 + 0x24;
          if (0x1f < (aiStack_58[0] - iVar9) - 4U) {
            uStack_8._0_1_ = uVar11;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar9,uVar5);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
      if (param_4 != 0) {
        if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
        }
        param_4 = 0;
      }
      uStack_8 = 0x11;
      if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
         (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
      }
      ExceptionList = pvStack_10;
      return;
    }
    uVar7 = 1;
  }
  FUN_016756b0(auStack_24,"Argument %d missing or nil",uVar7);
  puVar6 = auStack_24;
LAB_00b230fb:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(puVar6,&DAT_01c17198);
}



/* FUNCTION 23576 ; VA 0x00b23110 ; FUN_00b23110 */

void FUN_00b23110(undefined4 param_1,int *param_2,uint param_3)

{
  undefined4 *puVar1;
  code *pcVar2;
  int *piVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined8 uVar8;
  uint in_stack_0000002c;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  int *piStack_20;
  undefined auStack_1c [4];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_2;
  puStack_c = &LAB_017f026b;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar5 = (**(code **)*param_2)();
  if (1 < uVar5) {
    pcVar2 = *(code **)(*piVar3 + 0x38);
    uVar6 = FUN_00b318f0();
    cVar4 = (*pcVar2)(2,uVar6,&param_2);
    piStack_20 = param_2;
    if (cVar4 != '\0') goto LAB_00b231ff;
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    uStack_8._0_1_ = 2;
    cVar4 = (**(code **)(*piVar3 + 4))(2,&uStack_f0);
    if (cVar4 != '\0') {
      puVar7 = (undefined4 *)FUN_00b14cc0();
      piStack_20 = (int *)*puVar7;
      uStack_8._0_1_ = 3;
      if (iStack_ec != 0) {
        (**(code **)(iStack_ec + 8))(auStack_e8);
      }
      uStack_8._0_1_ = 1;
      goto LAB_00b231ff;
    }
    uStack_8._0_1_ = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
    uStack_8._0_1_ = 1;
  }
  if (*(undefined4 **)(uStack_18._4_4_ + 0x44) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  piStack_20 = (int *)**(undefined4 **)(uStack_18._4_4_ + 0x44);
LAB_00b231ff:
  uVar8 = FUN_009269c0(piVar3,uStack_18._4_4_ + 0x40);
  puVar7 = (undefined4 *)(uStack_18._4_4_ + 0x3c);
  puVar1 = (undefined4 *)(uStack_18._4_4_ + 0x38);
  uStack_18 = uVar8;
  FUN_00b1d630(param_1,*puVar1,*puVar7,&uStack_18,&piStack_20,&param_3,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23577 ; VA 0x00b232c0 ; FUN_00b232c0 */

void __thiscall FUN_00b232c0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00b1d350(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&param_4,
               &stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23578 ; VA 0x00b23360 ; FUN_00b23360 */

void __thiscall FUN_00b23360(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00b1d1c0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&param_4,
               &stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23579 ; VA 0x00b23400 ; FUN_00b23400 */

void __thiscall FUN_00b23400(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint in_stack_0000002c;
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [200];
  undefined8 uStack_2c;
  undefined auStack_24 [4];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f02ab;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_2c = FUN_009b3df0(param_3,param_1 + 0x44);
  iVar3 = (**(code **)*param_3)();
  if (iVar3 != 0) {
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8._0_1_ = 2;
    uStack_fc = FUN_00888530();
    iStack_f8 = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*param_3 + 4))(1,&uStack_fc);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_0088a3d0();
      piVar5 = (int *)puVar4[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)puVar4[1];
      }
      uStack_18 = *puVar4;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      piStack_14 = piVar5;
      if (iStack_f8 != 0) {
        (**(code **)(iStack_f8 + 8))(auStack_f4);
      }
      FUN_00550b30();
      goto LAB_00b23523;
    }
    uStack_8._0_1_ = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00550b30();
  }
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_24,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  piVar5 = (int *)puVar4[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)puVar4[1];
  }
  uStack_18 = *puVar4;
  piStack_14 = piVar5;
LAB_00b23523:
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00b1d4e0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &uStack_2c,&param_4,&stack0x0000002c);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23580 ; VA 0x00b23600 ; FUN_00b23600 */

void __thiscall FUN_00b23600(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_20;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009b3df0(param_3,param_1 + 0x44);
  uStack_20 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00b1d760(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_20,
               &uStack_18,&param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23581 ; VA 0x00b236d0 ; FUN_00b236d0 */

code * __thiscall FUN_00b236d0(int param_1,undefined4 param_2,uint param_3,int *param_4)

{
  undefined uVar1;
  int *piVar2;
  code *pcVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  code *pcStack_50;
  undefined auStack_48 [36];
  int iStack_24;
  uint uStack_20;
  int *piStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f02e0;
  pvStack_10 = ExceptionList;
  iVar6 = param_1 + 0x5d + (uint)*(byte *)(param_1 + 0x5c);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pcVar3 = (code *)FUN_00606ea0(&uStack_18,(param_3 >> 3) + param_3,&param_3,
                                -(uint)(iVar6 != 0) & iVar6 + 1U);
  if ((uStack_18 != 0) && (pcVar3 = (code *)FUN_00b1a530(&param_3), *(int *)(pcVar3 + 8) != 0)) {
    iVar6 = FUN_00b1a530(&param_3);
    FUN_0054f510(iVar6 + 8);
    uStack_8._0_1_ = 1;
    if (*(int *)(param_1 + 100) != 0) {
      piStack_1c = (int *)((param_3 >> 3) + param_3);
      uStack_18 = (uint)piStack_1c % *(uint *)(param_1 + 0x60);
      iStack_24 = uStack_18 * 4;
      piStack_14 = *(int **)(iStack_24 + *(int *)(param_1 + 0x70));
      if ((piStack_14 != (int *)0x0) &&
         (piVar2 = (int *)*piStack_14, (int *)*piStack_14 != (int *)0x0)) {
        while (piVar7 = piVar2, piVar2 = piStack_14,
              (uint)piVar7[1] % *(uint *)(param_1 + 0x60) == uStack_18) {
          if (((int *)piVar7[1] == piStack_1c) && (param_3 == piVar7[2])) {
            FUN_00b217d0(piStack_14,*piVar7);
            if (*piVar2 != 0) {
              uVar8 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 0x60);
              if (uStack_18 == uVar8) break;
              *(int **)(*(int *)(param_1 + 0x70) + uVar8 * 4) = piVar2;
            }
            puVar4 = (undefined4 *)(*(int *)(param_1 + 0x70) + iStack_24);
            if ((int *)*puVar4 == piVar2) {
              *puVar4 = 0;
            }
            break;
          }
          piVar2 = (int *)*piVar7;
          piStack_14 = piVar7;
          if ((int *)*piVar7 == (int *)0x0) break;
        }
      }
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    piStack_1c = param_4;
    uStack_8._0_1_ = 2;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (pcStack_50 == (code *)0x0) {
      uStack_20 = param_3;
      uStack_8._0_1_ = uVar1;
      uVar5 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar5);
    }
    uStack_20 = 0;
    piStack_1c = (int *)0x0;
    (**(code **)(((uint)pcStack_50 & 0xfffffffe) + 4))(auStack_48,param_2,param_3,param_4);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    pcVar3 = pcStack_50;
    if (((pcStack_50 != (code *)0x0) && (((uint)pcStack_50 & 1) == 0)) &&
       (pcVar3 = *(code **)((uint)pcStack_50 & 0xfffffffe), pcVar3 != (code *)0x0)) {
      pcVar3 = (code *)(*pcVar3)(auStack_48,auStack_48,2);
    }
  }
  piVar2 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar7 = param_4 + 1;
    iVar6 = *piVar7;
    pcVar3 = (code *)*piVar7;
    *piVar7 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      pcVar3 = (code *)(**(code **)*param_4)();
      LOCK();
      piVar7 = piVar2 + 2;
      iVar6 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        pcVar3 = (code *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar3;
}



/* FUNCTION 23582 ; VA 0x00b238d0 ; FUN_00b238d0 */

undefined4 FUN_00b238d0(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  FUN_009d05b0(param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x44);
  uVar3 = FUN_009d09d0(aiStack_2c,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
  uStack_8 = 0;
  pcVar1 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar3);
  (*pcVar1)();
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 23583 ; VA 0x00b239a0 ; FUN_00b239a0 */

undefined4 FUN_00b239a0(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_38 [5];
  uint uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799148;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  uStack_18 = FUN_009d1940(param_2,param_3,3,iVar2,iStack_14 + 0x48);
  uStack_20 = FUN_009d1940(param_2,param_3,2,iVar2,iStack_14 + 0x44);
  uVar3 = FUN_009d09d0(aiStack_38,param_2,param_3,1,iVar2,iStack_14 + 0x40);
  uStack_8 = 0;
  pcVar1 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar3);
  (*pcVar1)();
  if (0xf < uStack_24) {
    uVar4 = uStack_24 + 1;
    iVar2 = aiStack_38[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_38[0] + -4);
      uVar4 = uStack_24 + 0x24;
      if (0x1f < (aiStack_38[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 23584 ; VA 0x00b23aa0 ; FUN_00b23aa0 */

undefined4 FUN_00b23aa0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  int aiStack_34 [5];
  uint uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbe30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  uVar4 = FUN_009d09d0(aiStack_34,param_2,param_3,2,iVar3 - param_3,iStack_14 + 0x44);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_009d1340(auStack_1c,param_2,param_3,1,iVar3 - param_3,iStack_14 + 0x40)
  ;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  pcVar2 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar4);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(*puVar5,puVar5[1]);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    iVar3 = aiStack_34[0];
    if (0xfff < uVar6) {
      iVar3 = *(int *)(aiStack_34[0] + -4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar6);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 23585 ; VA 0x00b23bd0 ; FUN_00b23bd0 */

undefined4 FUN_00b23bd0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  code *pcVar5;
  undefined4 uStack_118;
  int iStack_114;
  undefined auStack_110 [204];
  undefined auStack_44 [12];
  undefined auStack_38 [4];
  int *piStack_34;
  code *apcStack_30 [3];
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017f030f;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_2);
  iVar3 = iVar3 - param_3;
  if (1 < iVar3) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee594)
       && (FUN_016f3809(&DAT_01eee594), DAT_01eee594 == -1)) {
      uStack_14 = 0;
      FUN_00ddcf50();
      FUN_016f3654(&LAB_0188d9d0);
      uStack_14 = 0xffffffff;
      FUN_016f37bf(&DAT_01eee594);
    }
    cVar2 = FUN_009d1e20(&DAT_01eee530,param_2,param_3 + 2,apcStack_30);
    pcVar5 = apcStack_30[0];
    if (cVar2 != '\0') goto LAB_00b23d16;
  }
  if (1 < iVar3) {
    uStack_118 = FUN_00888530();
    iStack_114 = 0;
    uStack_14 = 1;
    cVar2 = FUN_009d1bf0(param_2,param_3 + 2,&uStack_118,1);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_00ddc8b0();
      pcVar5 = (code *)*puVar4;
      uStack_14 = 2;
      if (iStack_114 != 0) {
        (**(code **)(iStack_114 + 8))(auStack_110);
      }
      uStack_14 = 0xffffffff;
      goto LAB_00b23d16;
    }
    uStack_14 = 3;
    if (iStack_114 != 0) {
      (**(code **)(iStack_114 + 8))(auStack_110);
    }
    uStack_14 = 0xffffffff;
  }
  if (*(undefined4 **)(iStack_24 + 0x44) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_44,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_44,&DAT_01c17198);
  }
  pcVar5 = (code *)**(undefined4 **)(iStack_24 + 0x44);
LAB_00b23d16:
  puVar4 = (undefined4 *)FUN_009d1340(auStack_38,param_2,param_3,1,iVar3,iStack_24 + 0x40);
  uStack_14 = 4;
  apcStack_30[0] = *(code **)(iStack_24 + 0x38);
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*apcStack_30[0])(*puVar4,puVar4[1],pcVar5);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_34[1] + -1;
    piStack_34[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 23586 ; VA 0x00b23e20 ; FUN_00b23e20 */

undefined4 FUN_00b23e20(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined8 uVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc228;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  uVar5 = FUN_009d1940(param_2,param_3,2,iVar3 - param_3,iStack_14 + 0x44);
  uStack_18 = (undefined4)uVar5;
  puVar4 = (undefined4 *)FUN_009d1340(auStack_20,param_2,param_3,1,iVar3 - param_3,iStack_14 + 0x40)
  ;
  uStack_8 = 0;
  pcVar2 = *(code **)(iStack_14 + 0x38);
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(*puVar4,puVar4[1],uStack_18,(int)((ulonglong)uVar5 >> 0x20));
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 23587 ; VA 0x00b23f10 ; FUN_00b23f10 */

undefined4 FUN_00b23f10(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined8 uVar5;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e6ac8;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_2);
  iVar3 = iVar3 - param_3;
  uVar2 = FUN_009d1aa0(param_2,param_3,3,iVar3,(int)pcStack_28 + 0x48);
  uStack_2c = CONCAT31(uStack_2c._1_3_,uVar2);
  uVar5 = FUN_009d1940(param_2,param_3,2,iVar3,(int)pcStack_28 + 0x44);
  uStack_30 = (undefined4)uVar5;
  puVar4 = (undefined4 *)FUN_009d1340(auStack_38,param_2,param_3,1,iVar3,(int)pcStack_28 + 0x40);
  uStack_14 = 0;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcStack_28)(*puVar4,puVar4[1],uStack_30,(int)((ulonglong)uVar5 >> 0x20),uStack_2c);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_34[1] + -1;
    piStack_34[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 23588 ; VA 0x00b24030 ; FUN_00b24030 */

undefined4 FUN_00b24030(int param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  char cVar2;
  undefined uVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined8 uVar7;
  undefined4 uStack_120;
  int iStack_11c;
  undefined auStack_118 [204];
  undefined auStack_4c [12];
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  int iStack_30;
  int iStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017f0333;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar4 = FUN_01256300(param_2);
  iVar4 = iVar4 - param_3;
  puStack_34 = (undefined4 *)iVar4;
  if (3 < iVar4) {
    uVar5 = FUN_00b31840();
    cVar2 = FUN_009d1e20(uVar5,param_2,param_3 + 4,&iStack_30);
    iStack_2c = iStack_30;
    if (cVar2 != '\0') goto LAB_00b24164;
    if (3 < iVar4) {
      uStack_120 = FUN_00888530();
      iStack_11c = 0;
      uStack_14 = 0;
      cVar2 = FUN_009d1bf0(param_2,param_3 + 4,&uStack_120,1);
      if (cVar2 != '\0') {
        piVar6 = (int *)FUN_00b14bf0();
        iStack_2c = *piVar6;
        uStack_14 = 1;
        if (iStack_11c != 0) {
          (**(code **)(iStack_11c + 8))(auStack_118);
        }
        uStack_14 = 0xffffffff;
        goto LAB_00b24164;
      }
      uStack_14 = 2;
      if (iStack_11c != 0) {
        (**(code **)(iStack_11c + 8))(auStack_118);
      }
      uStack_14 = 0xffffffff;
    }
  }
  if (*(int **)((int)pcStack_28 + 0x4c) == (int *)0x0) {
    FUN_016756b0(auStack_4c,"Argument %d missing or nil",4);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_4c,&DAT_01c17198);
  }
  iStack_2c = **(int **)((int)pcStack_28 + 0x4c);
LAB_00b24164:
  uVar3 = FUN_009d1aa0(param_2,param_3,3,iVar4,(int)pcStack_28 + 0x48);
  uStack_38 = CONCAT31(uStack_38._1_3_,uVar3);
  uVar7 = FUN_009d1940(param_2,param_3,2,iVar4,(int)pcStack_28 + 0x44);
  puStack_34 = (undefined4 *)
               FUN_009d1340(auStack_40,param_2,param_3,1,puStack_34,(int)pcStack_28 + 0x40);
  uStack_14 = 3;
  pcVar1 = *(code **)((int)pcStack_28 + 0x38);
  iStack_30 = *(int *)((int)pcStack_28 + 0x3c) + param_1;
  if (puStack_34[1] != 0) {
    LOCK();
    piVar6 = (int *)(puStack_34[1] + 4);
    *piVar6 = *piVar6 + 1;
    UNLOCK();
  }
  pcStack_28 = pcVar1;
  (*pcVar1)(*puStack_34,puStack_34[1],uVar7,uStack_38,iStack_2c);
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar6 = piStack_3c + 2;
      iVar4 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 23589 ; VA 0x00b24270 ; FUN_00b24270 */

undefined4 __thiscall FUN_00b24270(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  int iVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  
  iVar2 = FUN_01256300(param_3);
  iVar2 = iVar2 - param_4;
  uVar1 = FUN_009d1aa0(param_3,param_4,3,iVar2,param_1 + 0x48);
  uVar3 = FUN_009d1940(param_3,param_4,2,iVar2,param_1 + 0x44);
  uVar4 = FUN_009d1940(param_3,param_4,1,iVar2,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))(uVar4,uVar3,uVar1);
  return 0;
}



/* FUNCTION 23590 ; VA 0x00b24300 ; FUN_00b24300 */

int __thiscall FUN_00b24300(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_9c [8];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  int iStack_88;
  undefined *puStack_84;
  code *pcStack_80;
  undefined auStack_7c [8];
  uint uStack_74;
  undefined auStack_70 [12];
  undefined4 uStack_64;
  undefined auStack_60 [20];
  undefined4 uStack_4c;
  int iStack_48;
  undefined *puStack_44;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined *puStack_28;
  code *pcStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f0350;
  pvStack_10 = ExceptionList;
  puStack_44 = (undefined *)0x1;
  uStack_4c = 0xb2432b;
  ExceptionList = &pvStack_10;
  iStack_48 = param_1;
  iStack_14 = param_1;
  iVar2 = FUN_00971ce0();
  if ((char)iVar2 != '\0') {
    if (param_1 != 0) {
      iVar2 = *(int *)(param_1 + 0x34);
      iVar3 = param_1;
      if ((iVar2 != 0) && (iVar3 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
        puStack_44 = (undefined *)0xb2434d;
        iVar3 = FUN_005c8ac0();
      }
      if (iVar3 != 0) {
        iVar2 = *(int *)(iVar3 + 0xc);
        puStack_44 = (undefined *)0xb2435f;
        iVar3 = FUN_008a8c30();
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
            (uint)*(ushort *)(iVar3 + 0x1da)) {
          puStack_44 = (undefined *)0xb24381;
          FUN_00916350();
        }
      }
    }
    puStack_44 = (undefined *)0x2;
    iStack_48 = 0xb2438e;
    iVar2 = FUN_00e56510();
    if ((char)iVar2 != '\0') {
      iStack_48 = 0xb2439c;
      puStack_44 = (undefined *)param_1;
      iVar2 = FUN_008f7870();
      piVar1 = *(int **)(iVar2 + 0x43c);
      iStack_1c = *piVar1 - (int)piVar1;
      iStack_18 = piVar1[1] - (int)piVar1;
      puStack_44 = auStack_34;
      iStack_48 = 0xb243bf;
      puVar4 = (undefined4 *)FUN_00b264d0();
      piStack_20 = (int *)*puVar4;
      puStack_28 = auStack_60;
      uVar5 = CONCAT31((int3)((uint)param_1 >> 8),DAT_01eee1b9);
      uStack_64 = 0;
      iStack_8 = 0;
      pcStack_24 = *(code **)(*piStack_20 + 0x10);
      uStack_74 = (uint)DAT_01eee1b9;
      puStack_84 = auStack_7c;
      pcStack_80 = (code *)iStack_14;
      iStack_88 = 0xb243fa;
      FUN_0060e0c0();
      pcStack_80 = FUN_00b27850;
      iStack_88 = 0xb24408;
      puStack_84 = auStack_70;
      FUN_00b13e80();
      uStack_74 = 0xb24412;
      FUN_00b112b0();
      iStack_8._0_1_ = 1;
      puStack_84 = (undefined *)0x0;
      uStack_94 = uVar5;
      FUN_0060e0c0(auStack_9c,iStack_14);
      FUN_00b13e80(&uStack_90,FUN_00b278f0);
      uStack_94 = 0xb24449;
      FUN_00b112b0();
      puStack_84 = (undefined *)iStack_18;
      iStack_88 = iStack_1c;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      uStack_8c = param_3;
      uStack_90 = param_2;
      uStack_94 = 0xb2445f;
      iVar2 = (*pcStack_24)();
      if (piStack_30 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_30 + 1;
        iVar3 = *piVar1;
        iVar2 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          uStack_94 = 0xb24478;
          iVar2 = (**(code **)*piStack_30)();
          LOCK();
          piVar1 = piStack_30 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            uStack_94 = 0xb24487;
            iVar2 = (**(code **)(*piStack_30 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 23591 ; VA 0x00b244a0 ; FUN_00b244a0 */

undefined4 __thiscall FUN_00b244a0(byte *param_1,undefined4 param_2,int *param_3)

{
  uint uVar1;
  
  uVar1 = param_3[1];
  if (((int)uVar1 < 1) && ((int)uVar1 < 0)) {
    uVar1 = ~uVar1;
  }
  FUN_00606ff0(param_2,(uVar1 >> 2) + uVar1 * 0x40 + *param_3 ^ uVar1,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  return param_2;
}



/* FUNCTION 23592 ; VA 0x00b24500 ; FUN_00b24500 */

/* WARNING: Removing unreachable block (ram,0x00b24659) */
/* WARNING: Removing unreachable block (ram,0x00b24665) */
/* WARNING: Removing unreachable block (ram,0x00b24673) */

undefined4 FUN_00b24500(int *param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  int iStack_104;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f0399;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uStack_3c = 0;
  uStack_14 = param_2;
  uStack_2c = param_2;
  iStack_20 = param_3;
  iStack_28 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00b25370(param_1,param_2,param_3);
  uStack_1c = uStack_14;
  iStack_18 = param_3;
  uStack_2c = 0;
  iStack_28 = 0;
  uStack_8 = 2;
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_110 = FUN_008881d0();
  uStack_108 = uStack_14;
  uStack_10c = 0;
  iStack_104 = iStack_20;
  uStack_1c = 0;
  iStack_18 = 0;
  uStack_10c = FUN_0058c000();
  uStack_8 = 3;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  FUN_00687980(&uStack_110,&uStack_40,param_1);
  uStack_8 = 4;
  (*pcVar1)(uStack_24,&uStack_38,&uStack_40);
  uStack_8 = 5;
  FUN_00577b20();
  _uStack_8 = CONCAT31(uStack_7,2);
  uVar2 = FUN_016f32d1(&uStack_110,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 23593 ; VA 0x00b24690 ; FUN_00b24690 */

/* WARNING: Removing unreachable block (ram,0x00b24763) */
/* WARNING: Removing unreachable block (ram,0x00b2473a) */
/* WARNING: Removing unreachable block (ram,0x00b24746) */
/* WARNING: Removing unreachable block (ram,0x00b24754) */
/* WARNING: Removing unreachable block (ram,0x00b24771) */
/* WARNING: Removing unreachable block (ram,0x00b2479d) */
/* WARNING: Removing unreachable block (ram,0x00b24781) */

undefined4
FUN_00b24690(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5030;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b247b0(param_1,param_2,param_3,param_4,param_5,param_6,param_7,
                       CONCAT44(param_9,param_8),&uStack_1c);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23594 ; VA 0x00b247b0 ; FUN_00b247b0 */

/* WARNING: Removing unreachable block (ram,0x00b2496c) */
/* WARNING: Removing unreachable block (ram,0x00b24978) */
/* WARNING: Removing unreachable block (ram,0x00b24986) */

undefined4
FUN_00b247b0(int *param_1,undefined4 param_2,int param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,uint param_9,
            undefined4 param_10)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_fffffde4;
  undefined4 in_stack_fffffde8;
  undefined4 in_stack_fffffdec;
  undefined4 in_stack_fffffdf0;
  undefined4 in_stack_fffffdf4;
  undefined4 in_stack_fffffdf8;
  undefined4 uStack_1fc;
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  int iStack_1f0;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  uint uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined8 uStack_114;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f03fc;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_4);
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00b25590(param_1,param_2,param_3,in_stack_fffffde4,in_stack_fffffde8,in_stack_fffffdec,
               in_stack_fffffdf0,in_stack_fffffdf4,in_stack_fffffdf8);
  uStack_4c = param_4;
  uStack_5c = param_4;
  uStack_58 = param_5;
  uStack_54 = param_6;
  uStack_50 = param_7;
  param_4 = param_4 & 0xffffff00;
  uStack_48 = param_5;
  uStack_44 = param_6;
  uStack_40 = param_7;
  uStack_20 = param_2;
  uStack_3c = CONCAT44(param_9,param_8);
  param_8 = 0;
  param_9 = 0xf;
  iStack_1c = param_3;
  uStack_8._0_1_ = 3;
  pcStack_14 = *(code **)(*param_1 + 8);
  uStack_34 = uStack_3c;
  uStack_1fc = FUN_0088cdc0();
  uStack_1f8 = 0;
  uStack_1f4 = param_2;
  iStack_1f0 = param_3;
  uStack_20 = 0;
  iStack_1c = 0;
  uStack_1f8 = FUN_006309e0();
  uStack_8._0_1_ = 4;
  uStack_12c = FUN_0088cb40();
  uStack_128 = 0;
  uStack_124 = uStack_5c;
  uStack_120 = uStack_58;
  uStack_11c = uStack_54;
  uStack_118 = uStack_50;
  uStack_114 = uStack_34;
  uStack_3c = 0xf00000000;
  uStack_4c = uStack_4c & 0xffffff00;
  uStack_128 = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687980(&uStack_1fc,&uStack_5c,param_1);
  uStack_8._0_1_ = 6;
  (*pcStack_14)(uStack_18,&uStack_2c,param_10);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar1 = FUN_016f32d1(&uStack_1fc,0xd0,2,FUN_0056e5b0);
  if (0xf < param_9) {
    uVar3 = param_9 + 1;
    uVar2 = param_4;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(param_4 - 4);
      uVar3 = param_9 + 0x24;
      if (0x1f < (param_4 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar1 = FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23595 ; VA 0x00b249e0 ; FUN_00b249e0 */

/* WARNING: Removing unreachable block (ram,0x00b24b69) */
/* WARNING: Removing unreachable block (ram,0x00b24b75) */
/* WARNING: Removing unreachable block (ram,0x00b24b83) */

undefined4 FUN_00b249e0(int *param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  int iStack_1d4;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f0454;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uStack_3c = 0;
  uStack_14 = param_2;
  uStack_2c = param_2;
  iStack_20 = param_3;
  iStack_28 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00b25690(param_1,param_2,param_3,param_4);
  uStack_1c = uStack_14;
  iStack_18 = param_3;
  uStack_2c = 0;
  iStack_28 = 0;
  uStack_8 = 2;
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_1e0 = FUN_0088cdc0();
  uStack_1d8 = uStack_14;
  uStack_1dc = 0;
  iStack_1d4 = iStack_20;
  uStack_1c = 0;
  iStack_18 = 0;
  uStack_1dc = FUN_006309e0();
  uStack_8 = 3;
  uStack_110 = thunk_FUN_00b317b0();
  uStack_10c = 0;
  uStack_108 = param_4;
  uStack_10c = FUN_00b31a50();
  uStack_8 = 4;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  FUN_00687980(&uStack_1e0,&uStack_40,param_4);
  uStack_8 = 5;
  (*pcVar1)(uStack_24,&uStack_38,&uStack_40);
  uStack_8 = 6;
  FUN_00577b20();
  _uStack_8 = CONCAT31(uStack_7,2);
  uVar2 = FUN_016f32d1(&uStack_1e0,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 23596 ; VA 0x00b24ba0 ; FUN_00b24ba0 */

/* WARNING: Removing unreachable block (ram,0x00b24d35) */
/* WARNING: Removing unreachable block (ram,0x00b24d41) */
/* WARNING: Removing unreachable block (ram,0x00b24d4f) */

undefined4
FUN_00b24ba0(int *param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  int iStack_1d4;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f0454;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uStack_3c = 0;
  uStack_14 = param_2;
  uStack_2c = param_2;
  iStack_20 = param_3;
  iStack_28 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00b25730(param_1,param_2,param_3,param_4,param_5);
  uStack_1c = uStack_14;
  iStack_18 = param_3;
  uStack_2c = 0;
  iStack_28 = 0;
  uStack_8 = 2;
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_1e0 = FUN_0088cdc0();
  uStack_1d8 = uStack_14;
  uStack_1dc = 0;
  iStack_1d4 = iStack_20;
  uStack_1c = 0;
  iStack_18 = 0;
  uStack_1dc = FUN_006309e0();
  uStack_8 = 3;
  uStack_110 = FUN_0088da50();
  uStack_108 = param_4;
  uStack_10c = 0;
  uStack_104 = param_5;
  uStack_10c = FUN_005c9e80();
  uStack_8 = 4;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  FUN_00687980(&uStack_1e0,&uStack_40,param_1);
  uStack_8 = 5;
  (*pcVar1)(uStack_24,&uStack_38,&uStack_40);
  uStack_8 = 6;
  FUN_00577b20();
  _uStack_8 = CONCAT31(uStack_7,2);
  uVar2 = FUN_016f32d1(&uStack_1e0,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 23597 ; VA 0x00b24d70 ; FUN_00b24d70 */

/* WARNING: Removing unreachable block (ram,0x00b24ded) */
/* WARNING: Removing unreachable block (ram,0x00b24df9) */
/* WARNING: Removing unreachable block (ram,0x00b24e07) */

undefined4
FUN_00b24d70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b24e20(param_1,param_2,param_3,param_4,param_5,param_6,&uStack_18);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23598 ; VA 0x00b24e20 ; FUN_00b24e20 */

/* WARNING: Removing unreachable block (ram,0x00b24fbf) */
/* WARNING: Removing unreachable block (ram,0x00b24fcb) */
/* WARNING: Removing unreachable block (ram,0x00b24fd9) */

undefined4
FUN_00b24e20(int *param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  int iStack_290;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined uStack_f4;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f04a7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00b257d0(param_1,param_2,param_3,param_4,param_5,param_6);
  uStack_20 = param_2;
  iStack_1c = param_3;
  uStack_8._0_1_ = 1;
  pcStack_14 = *(code **)(*param_1 + 8);
  uStack_29c = FUN_0088cdc0();
  uStack_298 = 0;
  uStack_294 = param_2;
  iStack_290 = param_3;
  uStack_20 = 0;
  iStack_1c = 0;
  uStack_298 = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_1cc = FUN_0088da50();
  uStack_1c4 = param_4;
  uStack_1c8 = 0;
  uStack_1c0 = param_5;
  uStack_1c8 = FUN_005c9e80();
  uStack_8._0_1_ = 3;
  uStack_fc = FUN_0088daf0();
  uStack_f8 = 0;
  uStack_f4 = (undefined)param_6;
  uStack_f8 = FUN_005c9ef0();
  uStack_8._0_1_ = 4;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687980(&uStack_29c,&uStack_2c,param_1);
  uStack_8._0_1_ = 5;
  (*pcStack_14)(uStack_18,&uStack_2c,param_7);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar1 = FUN_016f32d1(&uStack_29c,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23599 ; VA 0x00b25000 ; FUN_00b25000 */

/* WARNING: Removing unreachable block (ram,0x00b25080) */
/* WARNING: Removing unreachable block (ram,0x00b2508c) */
/* WARNING: Removing unreachable block (ram,0x00b2509a) */

undefined4
FUN_00b25000(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b250c0(param_1,param_2,param_3,param_4,param_5,param_6,param_7,&uStack_18);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23600 ; VA 0x00b250c0 ; FUN_00b250c0 */

/* WARNING: Removing unreachable block (ram,0x00b2528f) */
/* WARNING: Removing unreachable block (ram,0x00b2529b) */
/* WARNING: Removing unreachable block (ram,0x00b252a9) */

undefined4
FUN_00b250c0(int *param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uStack_36c;
  undefined4 uStack_368;
  undefined4 uStack_364;
  int iStack_360;
  undefined4 uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined uStack_1c4;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0512;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00b25870(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  uStack_20 = param_2;
  iStack_1c = param_3;
  uStack_8._0_1_ = 1;
  pcStack_14 = *(code **)(*param_1 + 8);
  uStack_36c = FUN_0088cdc0();
  uStack_368 = 0;
  uStack_364 = param_2;
  iStack_360 = param_3;
  uStack_20 = 0;
  iStack_1c = 0;
  uStack_368 = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_29c = FUN_0088da50();
  uStack_294 = param_4;
  uStack_298 = 0;
  uStack_290 = param_5;
  uStack_298 = FUN_005c9e80();
  uStack_8._0_1_ = 3;
  uStack_1cc = FUN_0088daf0();
  uStack_1c8 = 0;
  uStack_1c4 = (undefined)param_6;
  uStack_1c8 = FUN_005c9ef0();
  uStack_8._0_1_ = 4;
  uStack_fc = FUN_00b31840();
  uStack_f8 = 0;
  uStack_f4 = param_7;
  uStack_f8 = FUN_00b31ac0();
  uStack_8._0_1_ = 5;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687980(&uStack_36c,&uStack_2c,param_1);
  uStack_8._0_1_ = 6;
  (*pcStack_14)(uStack_18,&uStack_2c,param_8);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar1 = FUN_016f32d1(&uStack_36c,0xd0,4,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23601 ; VA 0x00b252d0 ; FUN_00b252d0 */

/* WARNING: Removing unreachable block (ram,0x00b2532e) */
/* WARNING: Removing unreachable block (ram,0x00b2533a) */
/* WARNING: Removing unreachable block (ram,0x00b25348) */

undefined4 FUN_00b252d0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b1b780(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23602 ; VA 0x00b25370 ; FUN_00b25370 */

/* WARNING: Removing unreachable block (ram,0x00b253ce) */
/* WARNING: Removing unreachable block (ram,0x00b253da) */
/* WARNING: Removing unreachable block (ram,0x00b253e8) */

undefined4 FUN_00b25370(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1328;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_006ecbd0(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23603 ; VA 0x00b25410 ; FUN_00b25410 */

/* WARNING: Removing unreachable block (ram,0x00b25548) */
/* WARNING: Removing unreachable block (ram,0x00b25506) */
/* WARNING: Removing unreachable block (ram,0x00b254dd) */
/* WARNING: Removing unreachable block (ram,0x00b254e9) */
/* WARNING: Removing unreachable block (ram,0x00b254f7) */
/* WARNING: Removing unreachable block (ram,0x00b25514) */
/* WARNING: Removing unreachable block (ram,0x00b25582) */
/* WARNING: Removing unreachable block (ram,0x00b25524) */
/* WARNING: Removing unreachable block (ram,0x00b25556) */
/* WARNING: Removing unreachable block (ram,0x00b25587) */
/* WARNING: Removing unreachable block (ram,0x00b25566) */

undefined4
FUN_00b25410(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0538;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b1b880(param_2,param_3,param_4,param_5,param_6,param_7,CONCAT44(param_9,param_8),
                       param_10,param_11,param_12,param_13,CONCAT44(param_15,param_14),param_16);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23604 ; VA 0x00b25590 ; FUN_00b25590 */

/* WARNING: Removing unreachable block (ram,0x00b2564d) */
/* WARNING: Removing unreachable block (ram,0x00b25624) */
/* WARNING: Removing unreachable block (ram,0x00b25630) */
/* WARNING: Removing unreachable block (ram,0x00b2563e) */
/* WARNING: Removing unreachable block (ram,0x00b2565b) */
/* WARNING: Removing unreachable block (ram,0x00b25687) */
/* WARNING: Removing unreachable block (ram,0x00b2566b) */

undefined4
FUN_00b25590(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5030;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b1ba80(param_2,param_3,param_4,param_5,param_6,param_7,CONCAT44(param_9,param_8));
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23605 ; VA 0x00b25690 ; FUN_00b25690 */

/* WARNING: Removing unreachable block (ram,0x00b256f1) */
/* WARNING: Removing unreachable block (ram,0x00b256fd) */
/* WARNING: Removing unreachable block (ram,0x00b2570b) */

undefined4 FUN_00b25690(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0089bf10(param_2,param_3,param_4);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23606 ; VA 0x00b25730 ; FUN_00b25730 */

/* WARNING: Removing unreachable block (ram,0x00b25794) */
/* WARNING: Removing unreachable block (ram,0x00b257a0) */
/* WARNING: Removing unreachable block (ram,0x00b257ae) */

undefined4
FUN_00b25730(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b1bc10(param_2,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23607 ; VA 0x00b257d0 ; FUN_00b257d0 */

/* WARNING: Removing unreachable block (ram,0x00b25837) */
/* WARNING: Removing unreachable block (ram,0x00b25843) */
/* WARNING: Removing unreachable block (ram,0x00b25851) */

undefined4
FUN_00b257d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b1bd10(param_2,param_3,param_4,param_5,param_6);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23608 ; VA 0x00b25870 ; FUN_00b25870 */

/* WARNING: Removing unreachable block (ram,0x00b258da) */
/* WARNING: Removing unreachable block (ram,0x00b258e6) */
/* WARNING: Removing unreachable block (ram,0x00b258f4) */

undefined4
FUN_00b25870(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b1be10(param_2,param_3,param_4,param_5,param_6,param_7);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23609 ; VA 0x00b25910 ; FUN_00b25910 */

/* WARNING: Removing unreachable block (ram,0x00b25971) */
/* WARNING: Removing unreachable block (ram,0x00b2597d) */
/* WARNING: Removing unreachable block (ram,0x00b2598b) */

undefined4 FUN_00b25910(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef008;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009a5dd0(param_2,param_3,param_4);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23610 ; VA 0x00b259b0 ; FUN_00b259b0 */

void FUN_00b259b0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  param_2 = (int *)*param_2;
  iVar2 = *param_2;
  iVar3 = FUN_0088cbe0();
  if (iVar2 == iVar3) {
    piVar4 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00b252d0(param_1,*piVar4,piVar4[1]);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23611 ; VA 0x00b25a10 ; FUN_00b25a10 */

void FUN_00b25a10(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  param_2 = (int *)*param_2;
  iVar2 = *param_2;
  iVar3 = FUN_008881d0();
  if (iVar2 == iVar3) {
    piVar4 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00b25370(param_1,*piVar4,piVar4[1]);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23612 ; VA 0x00b25a70 ; FUN_00b25a70 */

void FUN_00b25a70(undefined4 param_1,undefined4 param_2)

{
  FUN_00b15680(param_1,param_2,param_2);
  return;
}



/* FUNCTION 23613 ; VA 0x00b25a90 ; FUN_00b25a90 */

void FUN_00b25a90(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e50a8;
  pvStack_10 = ExceptionList;
  iVar2 = *param_2;
  iVar4 = *(int *)(iVar2 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088cb40();
  if (iVar4 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar4 = iVar2 + 0xd8;
  if (*(int *)(iVar2 + 0xd4) == 0) {
    iVar4 = 0;
  }
  FUN_0054ef60(iVar4);
  param_2 = (int *)*param_2;
  uStack_8 = 0;
  iVar2 = *param_2;
  iVar4 = FUN_0088cdc0();
  if (iVar2 == iVar4) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    if (piVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8 = 0xffffffff;
    FUN_00b25590(param_1,*piVar5,piVar5[1]);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23614 ; VA 0x00b25b60 ; FUN_00b25b60 */

void FUN_00b25b60(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e50a8;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(*param_2 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088daf0();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar2 = *param_2;
  iVar3 = *(int *)(iVar2 + 0xd0);
  iVar4 = FUN_0088cb40();
  if (iVar3 == iVar4) {
    iVar3 = iVar2 + 0xd8;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      iVar3 = 0;
    }
    FUN_0054ef60(iVar3);
    param_2 = (int *)*param_2;
    uStack_8 = 0;
    iVar2 = *param_2;
    iVar3 = FUN_0088cdc0();
    if (iVar2 == iVar3) {
      piVar5 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar5 = (int *)0x0;
      }
      if (piVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar5[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_8 = 0xffffffff;
      FUN_00a87dd0(param_1,*piVar5,piVar5[1]);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 23615 ; VA 0x00b25c70 ; FUN_00b25c70 */

void FUN_00b25c70(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  
  iVar2 = *param_2;
  iVar5 = *(int *)(iVar2 + 0xd0);
  iVar3 = thunk_FUN_00b317b0();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar2 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar2 = *param_2;
    uVar7 = *puVar4;
    iVar5 = FUN_0088cdc0(uVar7);
    if (iVar2 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      if (piVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00b25690(param_1,*piVar6,piVar6[1],uVar7);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23616 ; VA 0x00b25d00 ; FUN_00b25d00 */

void FUN_00b25d00(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  
  iVar2 = *param_2;
  iVar5 = *(int *)(iVar2 + 0xd0);
  iVar3 = FUN_0088da50();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar2 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar2 = *param_2;
    uVar8 = puVar4[1];
    uVar7 = *puVar4;
    iVar5 = FUN_0088cdc0(uVar7,uVar8);
    if (iVar2 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      if (piVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00b25730(param_1,*piVar6,piVar6[1],uVar7,uVar8);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23617 ; VA 0x00b25d90 ; FUN_00b25d90 */

void FUN_00b25d90(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined *puVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  
  iVar2 = *param_2;
  iVar7 = *(int *)(iVar2 + 0x1a0);
  iVar3 = FUN_0088daf0();
  if (iVar7 == iVar3) {
    puVar4 = (undefined *)(iVar2 + 0x1a8);
    iVar7 = *param_2;
    if (*(int *)(iVar2 + 0x1a4) == 0) {
      puVar4 = (undefined *)0x0;
    }
    iVar2 = *(int *)(iVar7 + 0xd0);
    uVar5 = CONCAT31((int3)((uint)puVar4 >> 8),*puVar4);
    iVar3 = FUN_0088da50();
    if (iVar2 == iVar3) {
      puVar6 = (undefined4 *)(iVar7 + 0xd8);
      param_2 = (int *)*param_2;
      if (*(int *)(iVar7 + 0xd4) == 0) {
        puVar6 = (undefined4 *)0x0;
      }
      iVar2 = *param_2;
      uVar10 = puVar6[1];
      uVar9 = *puVar6;
      iVar7 = FUN_0088cdc0(uVar9,uVar10,uVar5);
      if (iVar2 == iVar7) {
        piVar8 = param_2 + 2;
        if (param_2[1] == 0) {
          piVar8 = (int *)0x0;
        }
        if (piVar8[1] != 0) {
          LOCK();
          piVar1 = (int *)(piVar8[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_00b257d0(param_1,*piVar8,piVar8[1],uVar9,uVar10,uVar5);
        return;
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23618 ; VA 0x00b25e50 ; FUN_00b25e50 */

void FUN_00b25e50(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined *puVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  
  iVar2 = *param_2;
  iVar7 = *(int *)(iVar2 + 0x270);
  iVar3 = FUN_00b31840();
  if (iVar7 == iVar3) {
    puVar4 = (undefined4 *)(iVar2 + 0x278);
    iVar7 = *param_2;
    if (*(int *)(iVar2 + 0x274) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar2 = *(int *)(iVar7 + 0x1a0);
    uVar11 = *puVar4;
    iVar3 = FUN_0088daf0();
    if (iVar2 == iVar3) {
      puVar5 = (undefined *)(iVar7 + 0x1a8);
      iVar2 = *param_2;
      if (*(int *)(iVar7 + 0x1a4) == 0) {
        puVar5 = (undefined *)0x0;
      }
      iVar7 = *(int *)(iVar2 + 0xd0);
      uVar6 = CONCAT31((int3)((uint)puVar5 >> 8),*puVar5);
      iVar3 = FUN_0088da50();
      if (iVar7 == iVar3) {
        puVar4 = (undefined4 *)(iVar2 + 0xd8);
        param_2 = (int *)*param_2;
        if (*(int *)(iVar2 + 0xd4) == 0) {
          puVar4 = (undefined4 *)0x0;
        }
        uVar10 = puVar4[1];
        iVar2 = *param_2;
        uVar9 = *puVar4;
        iVar7 = FUN_0088cdc0(uVar9,uVar10,uVar6,uVar11);
        if (iVar2 == iVar7) {
          piVar8 = param_2 + 2;
          if (param_2[1] == 0) {
            piVar8 = (int *)0x0;
          }
          if (piVar8[1] != 0) {
            LOCK();
            piVar1 = (int *)(piVar8[1] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          FUN_00b25870(param_1,*piVar8,piVar8[1],uVar9,uVar10,uVar6,uVar11);
          return;
        }
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23619 ; VA 0x00b25f40 ; FUN_00b25f40 */

void FUN_00b25f40(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined *puVar7;
  undefined4 *puVar8;
  int iVar9;
  int *piVar10;
  
  piVar3 = param_2;
  iVar2 = *param_2;
  iVar9 = *(int *)(iVar2 + 0x1a0);
  iVar6 = FUN_0088daf0();
  if (iVar9 == iVar6) {
    puVar7 = (undefined *)(iVar2 + 0x1a8);
    iVar9 = *param_2;
    if (*(int *)(iVar2 + 0x1a4) == 0) {
      puVar7 = (undefined *)0x0;
    }
    iVar2 = *(int *)(iVar9 + 0xd0);
    uVar1 = *puVar7;
    param_2 = (int *)CONCAT13(uVar1,param_2._0_3_);
    iVar6 = FUN_0088da50();
    if (iVar2 == iVar6) {
      puVar8 = (undefined4 *)(iVar9 + 0xd8);
      piVar3 = (int *)*piVar3;
      if (*(int *)(iVar9 + 0xd4) == 0) {
        puVar8 = (undefined4 *)0x0;
      }
      iVar2 = *piVar3;
      uVar4 = *puVar8;
      uVar5 = puVar8[1];
      iVar9 = FUN_0088da50();
      if (iVar2 == iVar9) {
        piVar10 = piVar3 + 2;
        if (piVar3[1] == 0) {
          piVar10 = (int *)0x0;
        }
        param_2 = (int *)CONCAT31(param_2._1_3_,uVar1);
        FUN_00b1bf20(*piVar10,piVar10[1],uVar4,uVar5,param_2);
        return;
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23620 ; VA 0x00b26000 ; FUN_00b26000 */

void FUN_00b26000(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puVar5;
  int iVar6;
  int *piVar7;
  
  iVar2 = *param_2;
  iVar6 = *(int *)(iVar2 + 0xd0);
  iVar4 = FUN_0088daf0();
  if (iVar6 == iVar4) {
    puVar5 = (undefined *)(iVar2 + 0xd8);
    piVar3 = (int *)*param_2;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar5 = (undefined *)0x0;
    }
    iVar2 = *piVar3;
    uVar1 = *puVar5;
    param_2 = (int *)CONCAT13(uVar1,param_2._0_3_);
    iVar6 = FUN_0088da50();
    if (iVar2 == iVar6) {
      piVar7 = piVar3 + 2;
      if (piVar3[1] == 0) {
        piVar7 = (int *)0x0;
      }
      param_2 = (int *)CONCAT31(param_2._1_3_,uVar1);
      FUN_00a51eb0(*piVar7,piVar7[1],param_2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23621 ; VA 0x00b26080 ; FUN_00b26080 */

void FUN_00b26080(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  
  piVar2 = (int *)*param_2;
  iVar3 = *piVar2;
  iVar4 = FUN_0088daf0();
  if (iVar3 == iVar4) {
    piVar5 = piVar2 + 2;
    iVar3 = *param_2;
    if (piVar2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar4 = *(int *)(iVar3 + 0xd0);
    uVar1 = *(undefined *)piVar5;
    iVar6 = FUN_0088cdc0();
    if (iVar4 == iVar6) {
      puVar7 = (undefined4 *)(iVar3 + 0xd8);
      if (*(int *)(iVar3 + 0xd4) == 0) {
        puVar7 = (undefined4 *)0x0;
      }
      if (puVar7[1] != 0) {
        LOCK();
        piVar2 = (int *)(puVar7[1] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      FUN_00b25910(param_1,CONCAT31((int3)((uint)piVar5 >> 8),uVar1),*puVar7,puVar7[1]);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23622 ; VA 0x00b26110 ; FUN_00b26110 */

void FUN_00b26110(uint param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined8 param_7,int **param_8,undefined4 param_9,
                 int *param_10,undefined4 param_11,int **param_12,int param_13,undefined8 param_14)

{
  int **ppiVar1;
  int ***pppiVar2;
  uint *puVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined **ppuVar9;
  int *piVar10;
  uint auStack_1bc [2];
  int iStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined8 uStack_1a4;
  int *piStack_19c;
  int *piStack_198;
  undefined4 auStack_194 [3];
  undefined4 uStack_188;
  undefined *puStack_184;
  undefined4 *puStack_180;
  int **ppiStack_17c;
  char *pcStack_178;
  int **ppiStack_174;
  undefined *puStack_170;
  int *piStack_16c;
  undefined4 uStack_168;
  int **ppiStack_164;
  int iStack_160;
  undefined8 uStack_15c;
  undefined auStack_14c [40];
  undefined auStack_124 [40];
  undefined auStack_fc [40];
  undefined auStack_d4 [40];
  undefined auStack_ac [40];
  undefined auStack_84 [40];
  undefined auStack_5c [4];
  int *piStack_58;
  undefined auStack_54 [4];
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  undefined *puStack_44;
  undefined *puStack_40;
  int *apiStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  code *pcStack_24;
  undefined *puStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f05d6;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_15c._0_4_ = 0xb2613f;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_008f7870();
  piVar10 = *(int **)(iVar6 + 0x43c);
  uStack_15c = CONCAT44(uStack_15c._4_4_,piVar10[1] - (int)piVar10);
  iStack_160 = *piVar10 - (int)piVar10;
  ppiStack_164 = apiStack_3c;
  uStack_168 = 0xb26159;
  FUN_00fbf1e0();
  uStack_8._0_1_ = 2;
  piStack_1c = (int *)0x2;
  piStack_16c = (int *)0xb2616a;
  piStack_16c = (int *)FUN_008f7870();
  puStack_170 = auStack_5c;
  ppiStack_174 = (int **)0xb26174;
  puStack_180 = (undefined4 *)FUN_005e5de0();
  ppiStack_174 = &piStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  pcStack_178 = "DeveloperProducts";
  ppiStack_17c = apiStack_3c;
  puStack_184 = auStack_54;
  uStack_188 = 0xb2618f;
  puVar7 = (undefined4 *)FUN_00b14d90();
  piStack_4c = (int *)*puVar7;
  piVar10 = (int *)puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  piStack_18 = piStack_50;
  piStack_48 = piVar10;
  piStack_1c = piStack_4c;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_50[1] + -1;
    piStack_50[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      uStack_15c = CONCAT44(0xb261c7,(undefined4)uStack_15c);
      (**(code **)*piStack_50)();
      LOCK();
      iVar6 = piStack_18[2] + -1;
      piStack_18[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_15c = CONCAT44(0xb261d8,(undefined4)uStack_15c);
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_58[2] + -1;
    piStack_58[2] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      uStack_15c = CONCAT44(0xb261f1,(undefined4)uStack_15c);
      (**(code **)(*piStack_58 + 4))();
    }
  }
  puStack_40 = (undefined *)&ppiStack_174;
  piStack_18 = (int *)&ppiStack_174;
  pcStack_24 = *(code **)(*piStack_1c + 0xa4);
  ppiStack_174 = (int **)0x0;
  pppiVar2 = &ppiStack_174;
  if (param_8 != (int **)0x0) {
    ppiStack_174 = param_8;
    if (((uint)param_8 & 1) == 0) {
      ppiStack_17c = &piStack_16c;
      pcStack_178 = (char *)0x0;
      puStack_180 = &param_10;
      puStack_184 = (undefined *)0xb26243;
      (**(code **)((uint)param_8 & 0xfffffffe))();
      pppiVar2 = (int ***)puStack_40;
    }
    else {
      piStack_16c = param_10;
      uStack_168 = param_11;
      ppiStack_164 = param_12;
      iStack_160 = param_13;
      uStack_15c = param_14;
      pppiVar2 = &ppiStack_174;
    }
  }
  puStack_40 = (undefined *)pppiVar2;
  piStack_18 = auStack_194;
  puStack_44 = (undefined *)&piStack_19c;
  if (piVar10 != (int *)0x0) {
    LOCK();
    piVar10[1] = piVar10[1] + 1;
    UNLOCK();
  }
  puStack_20 = (undefined *)auStack_1bc;
  uStack_8._0_1_ = 7;
  auStack_1bc[0] = 0;
  piStack_19c = piStack_1c;
  piStack_198 = piVar10;
  ppiVar1 = &piStack_19c;
  puVar3 = auStack_1bc;
  piVar4 = auStack_194;
  if (param_1 != 0) {
    auStack_1bc[0] = param_1;
    if ((param_1 & 1) == 0) {
      (**(code **)(param_1 & 0xfffffffe))(&param_3,&iStack_1b4,0);
      ppiVar1 = (int **)puStack_44;
      puVar3 = (uint *)puStack_20;
      piVar4 = piStack_18;
    }
    else {
      iStack_1b4 = param_3;
      uStack_1b0 = param_4;
      uStack_1ac = param_5;
      uStack_1a8 = param_6;
      uStack_1a4 = param_7;
      ppiVar1 = &piStack_19c;
      puVar3 = auStack_1bc;
      piVar4 = auStack_194;
    }
  }
  piStack_18 = piVar4;
  puStack_20 = (undefined *)puVar3;
  puStack_44 = (undefined *)ppiVar1;
  uStack_8._0_1_ = 6;
  FUN_009649e0(auStack_14c);
  piStack_198 = (int *)auStack_14c;
  uStack_8._0_1_ = 8;
  piStack_19c = (int *)0xb262e2;
  FUN_008c1490();
  uStack_8._0_1_ = 9;
  *piStack_18 = 0;
  piStack_198 = (int *)auStack_124;
  piStack_19c = (int *)0xb26301;
  FUN_008c1490();
  piStack_198 = (int *)auStack_fc;
  uStack_8._0_1_ = 10;
  piStack_19c = (int *)0xb26317;
  FUN_008c1490();
  piStack_198 = (int *)auStack_d4;
  uStack_8._0_1_ = 0xb;
  piStack_19c = (int *)0xb2632a;
  FUN_008c1490();
  piStack_198 = (int *)auStack_84;
  uStack_8._0_1_ = 0xc;
  piStack_19c = (int *)0xb26337;
  cVar5 = FUN_00585a40();
  if (cVar5 == '\0') {
    piStack_198 = (int *)auStack_84;
    piStack_19c = (int *)0xb2634d;
    FUN_008c1490();
    piStack_198 = (int *)0x28;
    uStack_8._0_1_ = 0xd;
    piStack_19c = (int *)0xb26358;
    puStack_20 = (undefined *)FUN_01674e20();
    uStack_8._0_1_ = 0xe;
    if (puStack_20 == (undefined *)0x0) {
      uVar8 = 0;
    }
    else {
      piStack_198 = (int *)auStack_ac;
      piStack_19c = (int *)0xb26374;
      uVar8 = FUN_008c1490();
    }
    piStack_18[2] = uVar8;
    piStack_198 = (int *)0xb2638b;
    FUN_008c3670();
    piStack_198 = (int *)0xb26393;
    FUN_008c3670();
    cStack_11 = '\x01';
  }
  else {
    piStack_198 = (int *)0xb263a1;
    FUN_008c3670();
    cStack_11 = '\0';
  }
  piStack_198 = (int *)0xb263b0;
  FUN_008c3670();
  ppuVar9 = &PTR_FUN_01936c28;
  if (cStack_11 == '\0') {
    ppuVar9 = (undefined **)0x0;
  }
  *piStack_18 = (int)ppuVar9;
  piStack_198 = (int *)0xb263cd;
  FUN_008c3670();
  piStack_198 = (int *)0xb263d8;
  FUN_008c3670();
  uStack_8._0_1_ = 6;
  piStack_198 = (int *)0xb263e7;
  FUN_008c3670();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  piStack_198 = (int *)0xb263f1;
  (*pcStack_24)();
  if (piVar10 != (int *)0x0) {
    LOCK();
    iVar6 = piVar10[1] + -1;
    piVar10[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      piStack_198 = (int *)0xb26404;
      (**(code **)*piVar10)();
      LOCK();
      piVar4 = piVar10 + 2;
      iVar6 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        piStack_198 = (int *)0xb26413;
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_28) {
    piStack_198 = (int *)(uStack_28 + 1);
    piVar10 = apiStack_3c[0];
    if (0xfff < piStack_198) {
      piVar10 = (int *)apiStack_3c[0][-1];
      piStack_198 = (int *)(uStack_28 + 0x24);
      if (0x1f < (uint)((int)apiStack_3c[0] + (-4 - (int)piVar10))) {
                    /* WARNING: Subroutine does not return */
        piStack_198 = (int *)&UNK_00b264c6;
        FUN_017167a3();
      }
    }
    uStack_1a4 = CONCAT44(0xb26448,(undefined4)uStack_1a4);
    piStack_19c = piVar10;
    FUN_01674ea0();
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  apiStack_3c[0] = (int *)((uint)apiStack_3c[0] & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    piStack_19c = &param_3;
    piStack_198 = (int *)0x2;
    uStack_1a4 = CONCAT44(piStack_19c,0xb2647e);
    (**(code **)(param_1 & 0xfffffffe))();
  }
  uStack_8 = 0x10;
  if (((param_8 != (int **)0x0) && (((uint)param_8 & 1) == 0)) &&
     (*(code **)((uint)param_8 & 0xfffffffe) != (code *)0x0)) {
    piStack_19c = (int *)&param_10;
    piStack_198 = (int *)0x2;
    uStack_1a4 = CONCAT44(piStack_19c,0xb264ac);
    (**(code **)((uint)param_8 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23623 ; VA 0x00b264d0 ; FUN_00b264d0 */

void __thiscall FUN_00b264d0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f05ef;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0xc0) == 0) {
    uStack_30 = 0xb26503;
    ExceptionList = &pvStack_10;
    puStack_2c = (undefined4 *)param_1;
    uVar3 = FUN_00965f10();
    uStack_30 = 0x44;
    iVar4 = FUN_01674e20();
    uStack_8 = 0;
    if (iVar4 == 0) {
      uStack_30 = 0;
    }
    else {
      FUN_0060dcd0(&uStack_30,uVar3);
      uStack_30 = FUN_00ff7c10();
    }
    puStack_2c = param_2;
    uStack_8 = 0xffffffff;
    FUN_00b123b0();
    *(undefined4 *)(param_1 + 0xc0) = 0;
    piVar2 = *(int **)(param_1 + 0xc4);
    *(undefined4 *)(param_1 + 0xc4) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puStack_2c = (undefined4 *)0xb26588;
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          puStack_2c = (undefined4 *)0xb26597;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  iVar4 = *(int *)(param_1 + 0xc4);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = *(int *)(param_1 + 0xc4);
  }
  *param_2 = *(undefined4 *)(param_1 + 0xc0);
  param_2[1] = iVar4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23624 ; VA 0x00b265e0 ; FUN_00b265e0 */

void __thiscall
FUN_00b265e0(undefined4 ****param_1,undefined4 ****param_2,undefined4 ****param_3,
            undefined4 ****param_4,uint param_5)

{
  undefined uVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 ***pppuVar4;
  int iVar5;
  undefined4 ****ppppuVar6;
  double *pdVar7;
  undefined4 ***pppuVar8;
  undefined **ppuVar9;
  undefined4 ****ppppuVar10;
  byte *pbVar11;
  undefined4 ***pppuVar12;
  undefined4 ***in_stack_00000030;
  undefined4 ***pppuStack_3fc;
  undefined4 *puStack_3f8;
  undefined4 *puStack_3f4;
  undefined auStack_3f0 [20];
  undefined4 uStack_3dc;
  undefined4 ***pppuStack_3d8;
  undefined4 *puStack_3d4;
  undefined auStack_3d0 [16];
  undefined4 uStack_3c0;
  undefined4 ***pppuStack_3bc;
  undefined4 ***pppuStack_3b8;
  undefined4 **appuStack_3b4 [2];
  undefined4 **ppuStack_3ac;
  undefined4 uStack_39c;
  undefined4 ***pppuStack_398;
  undefined4 ***pppuStack_394;
  undefined4 ***pppuStack_390;
  undefined4 ***pppuStack_38c;
  undefined4 ***pppuStack_388;
  undefined4 ***pppuStack_384;
  undefined4 ***pppuStack_380;
  undefined4 ***pppuStack_37c;
  undefined4 ***pppuStack_378;
  undefined4 *puStack_36c;
  undefined4 *puStack_368;
  undefined auStack_364 [24];
  undefined4 *puStack_34c;
  undefined4 *puStack_348;
  undefined auStack_344 [72];
  undefined4 *puStack_2fc;
  undefined4 *puStack_2f8;
  undefined auStack_2f4 [24];
  undefined4 *puStack_2dc;
  undefined4 *puStack_2d8;
  undefined auStack_2d4 [72];
  undefined4 *puStack_28c;
  undefined4 *puStack_288;
  undefined auStack_284 [24];
  undefined4 *puStack_26c;
  undefined4 *puStack_268;
  undefined auStack_264 [72];
  undefined4 *puStack_21c;
  undefined4 *puStack_218;
  undefined auStack_214 [24];
  undefined4 *puStack_1fc;
  undefined4 *puStack_1f8;
  undefined auStack_1f4 [72];
  undefined4 *puStack_1ac;
  undefined4 *puStack_1a8;
  undefined auStack_1a4 [24];
  undefined4 *puStack_18c;
  undefined4 *puStack_188;
  undefined auStack_184 [72];
  undefined4 *puStack_13c;
  undefined4 *puStack_138;
  undefined auStack_134 [24];
  undefined4 *puStack_11c;
  undefined4 *puStack_118;
  undefined auStack_114 [72];
  undefined uStack_cc;
  int iStack_bc;
  undefined4 uStack_b8;
  undefined4 ***apppuStack_b4 [4];
  undefined4 uStack_a4;
  uint uStack_a0;
  undefined4 **appuStack_9c [4];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 **ppuStack_84;
  undefined4 **ppuStack_80;
  undefined4 **ppuStack_7c;
  undefined4 **ppuStack_78;
  undefined *puStack_74;
  undefined4 ***apppuStack_70 [4];
  int iStack_60;
  uint uStack_5c;
  undefined4 ***apppuStack_58 [4];
  int iStack_48;
  uint uStack_44;
  undefined4 ***apppuStack_40 [4];
  int iStack_30;
  uint uStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined4 *puStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined4 ***pppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  ppppuVar10 = param_3;
  puStack_c = &LAB_017f0761;
  pvStack_10 = ExceptionList;
  pppuStack_380 = apppuStack_70;
  pppuStack_378 = param_3;
  pppuStack_37c = param_2;
  uStack_8 = 1;
  pppuStack_384 = (undefined4 ***)0xb2661c;
  ExceptionList = &pvStack_10;
  pppuStack_14 = param_1;
  FUN_00fbec90();
  pppuStack_384 = ppppuVar10;
  pppuStack_388 = param_2;
  pppuStack_38c = apppuStack_58;
  uStack_8._0_1_ = 2;
  pppuStack_390 = (undefined4 ***)0xb2662d;
  FUN_00fbf0d0();
  pppuStack_390 = ppppuVar10;
  pppuStack_394 = param_2;
  pppuStack_398 = apppuStack_40;
  uStack_8._0_1_ = 3;
  uStack_39c = 0xb2663e;
  FUN_00fbf510();
  ppppuVar10 = param_4;
  uStack_8._0_1_ = 4;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (param_4 == (undefined4 ****)0x3) {
    pppuStack_378 = param_3;
    pppuStack_37c = param_2;
    pppuStack_380 = apppuStack_b4;
    pppuStack_384 = (undefined4 ***)0xb26664;
    FUN_00fbf620();
    uStack_8._0_1_ = 5;
    pppuStack_388 = (undefined4 ****)0xb2666e;
    pppuStack_384 = param_1;
    iStack_18 = FUN_0064e700();
    if (iStack_18 == 0) {
      pppuStack_390 = (undefined4 ***)0x2a;
      pppuStack_37c = (undefined4 ****)0x0;
      pppuStack_378 = (undefined4 ***)0xf;
      pppuStack_394 = (undefined4 ***)0x1950afc;
      pppuStack_38c = (undefined4 ***)((uint)pppuStack_38c & 0xffffff00);
      pppuStack_398 = (undefined4 ****)0xb26928;
      FUN_005542c0();
      pppuStack_390 = (undefined4 ****)0xb26930;
      FUN_005e65e0();
    }
    else {
      puStack_3f4 = &stack0x00000030;
      puStack_28 = (undefined *)&pppuStack_394;
      param_3 = &pppuStack_394;
      param_4 = (undefined4 ****)CONCAT31(param_4._1_3_,DAT_01eee1b9);
      puStack_20 = (undefined4 *)CONCAT31(puStack_20._1_3_,DAT_01eee1b9);
      pppuStack_398 = (undefined4 ****)0x0;
      puStack_1c = auStack_3f0;
      puStack_3f8 = (undefined4 *)0xb266a9;
      FUN_0054f510();
      uStack_8._0_1_ = 6;
      pppuStack_3fc = pppuStack_14;
      uVar3 = FUN_008f7870();
      FUN_005e5de0(&puStack_3f8,uVar3);
      pppuVar4 = pppuStack_14;
      uStack_8._0_1_ = 5;
      pppuStack_3fc = param_4;
      FUN_00b14990(auStack_3d0,FUN_00b2b530,0,pppuStack_14);
      puStack_3d4 = (undefined4 *)0xb266e7;
      FUN_00b11730();
      param_3 = (undefined4 ****)appuStack_3b4;
      uStack_8._0_1_ = 7;
      pppuStack_3d8 = &stack0x00000030;
      param_4 = (undefined4 ****)&puStack_3d4;
      uStack_3dc = 0xb26704;
      FUN_0054f510();
      uStack_8._0_1_ = 8;
      puStack_3f8 = &param_5;
      pppuStack_3fc = (undefined4 ***)0xb26716;
      FUN_0054f510();
      puStack_3f8 = puStack_20;
      uStack_8._0_1_ = 7;
      pppuStack_3fc = pppuVar4;
      FUN_00b14840(&puStack_34c,FUN_00b2ba90,0);
      puStack_26c = puStack_34c;
      puStack_268 = puStack_348;
      pppuStack_3b8 = (undefined4 ***)auStack_344;
      uStack_8._0_1_ = 9;
      pppuStack_3bc = (undefined4 ***)0xb26762;
      FUN_00b16560();
      puStack_1fc = puStack_26c;
      puStack_1f8 = puStack_268;
      pppuStack_3b8 = (undefined4 ***)auStack_264;
      uStack_8._0_1_ = 10;
      appuStack_3b4[0] = (undefined4 ***)0x0;
      pppuStack_3bc = (undefined4 ***)0xb26796;
      FUN_00b16560();
      puStack_18c = puStack_1fc;
      puStack_188 = puStack_1f8;
      pppuStack_3b8 = (undefined4 ***)auStack_1f4;
      uStack_8._0_1_ = 0xb;
      pppuStack_3bc = (undefined4 ***)0xb267c4;
      FUN_00b16560();
      puStack_2dc = puStack_18c;
      puStack_2d8 = puStack_188;
      pppuStack_3b8 = (undefined4 ***)auStack_184;
      uStack_8._0_1_ = 0xc;
      pppuStack_3bc = (undefined4 ***)0xb267f2;
      FUN_00b16560();
      pppuStack_3b8 = (undefined4 ***)&puStack_2dc;
      uStack_8._0_1_ = 0xd;
      pppuStack_3bc = (undefined4 ***)0xb26802;
      cVar2 = FUN_00585a40();
      if (cVar2 == '\0') {
        puStack_11c = puStack_2dc;
        puStack_118 = puStack_2d8;
        pppuStack_3b8 = (undefined4 ***)auStack_2d4;
        pppuStack_3bc = (undefined4 ***)0xb26837;
        FUN_00b16560();
        pppuStack_3b8 = (undefined4 ***)0x50;
        uStack_8._0_1_ = 0xe;
        pppuStack_3bc = (undefined4 ***)0xb26842;
        pppuVar4 = (undefined4 ***)FUN_01674e20();
        uStack_8._0_1_ = 0xf;
        if (pppuVar4 == (undefined4 ***)0x0) {
          ppuStack_3ac = (undefined4 ***)0x0;
          param_4 = (undefined4 ****)pppuVar4;
        }
        else {
          pppuStack_3b8 = (undefined4 ***)auStack_114;
          *pppuVar4 = (undefined4 **)puStack_11c;
          pppuVar4[1] = (undefined4 **)puStack_118;
          pppuStack_3bc = (undefined4 ***)0xb26872;
          param_4 = (undefined4 ****)pppuVar4;
          FUN_00b16560();
          ppuStack_3ac = pppuVar4;
        }
        pppuStack_3b8 = (undefined4 ***)0xb26884;
        FUN_0096ca80();
        pppuStack_3b8 = (undefined4 ***)0xb2688f;
        FUN_0096ca80();
        param_4 = (undefined4 ****)CONCAT13(1,param_4._0_3_);
      }
      else {
        pppuStack_3b8 = (undefined4 ***)0xb268a0;
        FUN_0096ca80();
        param_4 = (undefined4 ****)((uint)param_4 & 0xffffff);
      }
      pppuStack_3b8 = (undefined4 ***)0xb268af;
      FUN_0096ca80();
      appuStack_3b4[0] = (undefined4 **)&PTR_FUN_01951b78;
      if (param_4._3_1_ == '\0') {
        appuStack_3b4[0] = (undefined4 ***)0x0;
      }
      pppuStack_3b8 = (undefined4 ***)0xb268c9;
      FUN_0096ca80();
      pppuStack_3b8 = (undefined4 ***)0xb268d4;
      FUN_0096ca80();
      pppuStack_3b8 = (undefined4 ***)0xb268df;
      FUN_0096ca80();
      pppuStack_3b8 = (undefined4 ****)0x2;
      pppuStack_3bc = (undefined4 ****)0x0;
      uStack_8._0_1_ = 0x10;
      pppuStack_3d8 = apppuStack_b4;
      uStack_3dc = 0xb268f8;
      FUN_0054ef60();
      uStack_8._0_1_ = 5;
      pppuStack_3d8 = (undefined4 ***)0xb26904;
      FUN_00bcb620();
    }
    uStack_8._0_1_ = 4;
    if (0xf < uStack_a0) {
      pppuStack_378 = (undefined4 ***)(uStack_a0 + 1);
      ppppuVar10 = (undefined4 ****)apppuStack_b4[0];
      if (0xfff < pppuStack_378) {
        ppppuVar10 = (undefined4 ****)apppuStack_b4[0][-1];
        pppuStack_378 = (undefined4 ***)(uStack_a0 + 0x24);
        if ((undefined *)0x1f < (undefined *)((int)apppuStack_b4[0] + (-4 - (int)ppppuVar10))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_378 = (undefined4 ***)0xb27249;
          FUN_017167a3();
        }
      }
      pppuStack_380 = (undefined4 ****)0xb2696f;
      pppuStack_37c = ppppuVar10;
      FUN_01674ea0();
    }
  }
  else if (param_4 == (undefined4 ****)0x0) {
    if (iStack_60 == 0) {
      pppuStack_390 = (undefined4 ***)0x3b;
      pppuStack_37c = param_4;
      pppuStack_378 = (undefined4 ***)0xf;
      pppuStack_394 = (undefined4 ***)0x1950b28;
      pppuStack_38c = (undefined4 ***)((uint)pppuStack_38c._1_3_ << 8);
      pppuStack_398 = (undefined4 ****)0xb269a2;
      uStack_8._0_1_ = uVar1;
      FUN_005542c0();
      pppuStack_390 = (undefined4 ****)0xb269aa;
      FUN_005e65e0();
    }
    else {
LAB_00b26a5b:
      if (((int)param_3 < 1) && (((int)param_3 < 0 || (param_2 == (undefined4 ****)0x0)))) {
        pppuStack_390 = (undefined4 ***)0x66;
        pppuStack_37c = (undefined4 ****)0x0;
        pppuStack_378 = (undefined4 ***)0xf;
        pppuStack_394 = (undefined4 ***)0x1950c40;
        pppuStack_38c = (undefined4 ***)((uint)pppuStack_38c._1_3_ << 8);
        pppuStack_398 = (undefined4 ****)0xb26a8c;
        uStack_8._0_1_ = uVar1;
        FUN_005542c0();
        pppuStack_390 = (undefined4 ****)0xb26a94;
        FUN_005e65e0();
      }
      else if (param_4 == (undefined4 ****)&DAT_00000004) {
        if (param_1 != (undefined4 ****)0x0) {
          ppppuVar10 = (undefined4 ****)param_1[0xd];
          if ((ppppuVar10 != (undefined4 ****)0x0) &&
             (param_1 = ppppuVar10, uStack_8._0_1_ = uVar1, ppppuVar10[0xd] != (undefined4 ***)0x0))
          {
            pppuStack_378 = (undefined4 ***)0xb26abd;
            param_1 = (undefined4 ****)FUN_005c8ac0();
          }
          uVar1 = (undefined)uStack_8;
          if (param_1 != (undefined4 ****)0x0) {
            pppuVar4 = param_1[3];
            pppuStack_378 = (undefined4 ***)0xb26acf;
            iVar5 = FUN_008a8c30();
            uVar1 = (undefined)uStack_8;
            if ((uint)*(ushort *)(pppuVar4 + 0x76) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
                (uint)*(ushort *)(iVar5 + 0x1da)) {
              pppuStack_378 = (undefined4 ***)0xb26af1;
              iVar5 = FUN_008e1480();
              uVar1 = (undefined)uStack_8;
              if (iVar5 != 0) {
                param_4 = &pppuStack_394;
                pppuStack_398 = &stack0x00000030;
                uStack_39c = 0xb26b08;
                FUN_0054f510();
                uStack_8._0_1_ = 0x11;
                pppuStack_3b8 = (undefined4 ***)&param_5;
                pppuStack_3bc = (undefined4 ***)0xb26b1a;
                FUN_0054f510();
                pppuStack_3b8 = param_3;
                uStack_8._0_1_ = 4;
                pppuStack_3bc = param_2;
                uStack_3c0 = 0xb26b2b;
                FUN_00de5740();
                goto LAB_00b26df7;
              }
            }
          }
        }
        uStack_8._0_1_ = uVar1;
        pppuStack_390 = (undefined4 ***)0x41;
        pppuStack_37c = (undefined4 ****)0x0;
        pppuStack_378 = (undefined4 ***)0xf;
        pppuStack_394 = (undefined4 ***)0x1950ca8;
        pppuStack_38c = (undefined4 ***)((uint)pppuStack_38c & 0xffffff00);
        pppuStack_398 = (undefined4 ****)0xb26b52;
        FUN_005542c0();
        pppuStack_390 = (undefined4 ****)0xb26b5a;
        FUN_005e65e0();
      }
      else {
        pppuStack_378 = (undefined4 ***)0x0;
        pppuStack_37c = (undefined4 ***)&DAT_018bc9b8;
        iStack_bc = 0;
        uStack_b8 = 0xf;
        uStack_cc = 0;
        pppuStack_380 = (undefined4 ****)0xb26b8c;
        uStack_8._0_1_ = uVar1;
        FUN_005542c0();
        uStack_8._0_1_ = 0x12;
        if (param_1 != (undefined4 ****)0x0) {
          param_4 = (undefined4 ****)param_1[0xd];
          ppppuVar6 = param_1;
          if ((param_4 != (undefined4 ****)0x0) &&
             (ppppuVar6 = param_4, param_4[0xd] != (undefined4 ***)0x0)) {
            pppuStack_378 = (undefined4 ***)0xb26bae;
            ppppuVar6 = (undefined4 ****)FUN_005c8ac0();
          }
          param_4 = ppppuVar6;
          if (param_4 != (undefined4 ****)0x0) {
            pppuVar4 = param_4[3];
            pppuStack_378 = (undefined4 ***)0xb26bc4;
            iVar5 = FUN_008a8c30();
            param_1 = (undefined4 ****)pppuStack_14;
            if ((uint)*(ushort *)(pppuVar4 + 0x76) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
                (uint)*(ushort *)(iVar5 + 0x1da)) {
              pppuStack_378 = (undefined4 ***)0xb26be7;
              iVar5 = FUN_005c2760();
              param_1 = (undefined4 ****)pppuStack_14;
              if (iVar5 != 0) {
                pppuStack_378 = apppuStack_b4;
                pppuStack_37c = (undefined4 ***)0xb26bf9;
                pppuStack_378 = (undefined4 ***)FUN_008cc950();
                uStack_8._0_1_ = 0x13;
                pppuStack_37c = (undefined4 ***)0xb26c09;
                FUN_00551230();
                uStack_8._0_1_ = 0x12;
                pppuStack_378 = (undefined4 ***)0xb26c18;
                FUN_005507b0();
                param_1 = (undefined4 ****)pppuStack_14;
              }
            }
          }
        }
        if (ppppuVar10 == (undefined4 ****)0x0) {
          pppuStack_37c = apppuStack_70;
          pppuStack_378 = (undefined4 ***)iStack_60;
          if (0xf < uStack_5c) {
            pppuStack_37c = apppuStack_70[0];
          }
LAB_00b26c57:
          pppuStack_380 = (undefined4 ****)0xb26c63;
          FUN_00554150();
        }
        else {
          if (ppppuVar10 == (undefined4 ****)0x1) {
            pppuStack_37c = apppuStack_58;
            pppuStack_378 = (undefined4 ***)iStack_48;
            if (0xf < uStack_44) {
              pppuStack_37c = apppuStack_58[0];
            }
            goto LAB_00b26c57;
          }
          if (ppppuVar10 == (undefined4 ****)0x2) {
            pppuStack_378 = (undefined4 ***)iStack_30;
            pppuStack_37c = apppuStack_40;
            if (0xf < uStack_2c) {
              pppuStack_37c = apppuStack_40[0];
            }
            goto LAB_00b26c57;
          }
        }
        if (iStack_bc != 0) {
          pppuStack_37c = (undefined4 ****)0xb26ca1;
          pppuStack_378 = param_1;
          puStack_20 = (undefined4 *)FUN_0064e700();
          if (puStack_20 != (undefined4 *)0x0) {
            pppuStack_378 = (undefined4 ***)0x0;
            pppuStack_37c = (undefined4 ***)&DAT_018bc9b8;
            uStack_a4 = 0;
            uStack_a0 = 0xf;
            apppuStack_b4[0] = (undefined4 ***)((uint)apppuStack_b4[0] & 0xffffff00);
            pppuStack_380 = (undefined4 ***)0xb26cdc;
            FUN_005542c0();
            uStack_8c = 0;
            uStack_88 = 0xf;
            appuStack_9c[0]._0_1_ = 0;
            uStack_8._0_1_ = 0x15;
            if (ppppuVar10 == (undefined4 ****)0x0) {
              pppuStack_378 = apppuStack_70;
LAB_00b26d16:
              pppuStack_37c = (undefined4 ***)0xb26d22;
              FUN_00551230();
            }
            else {
              if (ppppuVar10 == (undefined4 ****)0x1) {
                pppuStack_378 = apppuStack_58;
                goto LAB_00b26d16;
              }
              if (ppppuVar10 == (undefined4 ****)0x2) {
                pppuStack_378 = apppuStack_40;
                goto LAB_00b26d16;
              }
            }
            pppuStack_378 = appuStack_9c;
            pbVar11 = (byte *)((int)(param_1 + 0x2a) + *(byte *)(param_1 + 0x2a) + 1);
            pppuStack_380 = (undefined4 ***)0xb26d3b;
            pppuStack_37c = (undefined4 ***)pbVar11;
            pppuStack_380 = (undefined4 ***)FUN_0055c740();
            pppuStack_37c = appuStack_9c;
            pppuStack_378 = (undefined4 ***)(-(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1));
            pppuStack_384 = &param_4;
            pppuStack_388 = (undefined4 ****)0xb26d5b;
            FUN_00562fc0();
            if (param_4 != (undefined4 ****)0x0) {
              ppuStack_84 = param_4[8];
              ppuStack_80 = param_4[9];
              ppuStack_78 = param_4[0xb];
              if ((undefined4 ***)ppuStack_78 != (undefined4 ***)0x0) {
                LOCK();
                ((undefined4 ***)ppuStack_78)[1] =
                     (undefined4 **)((int)((undefined4 ***)ppuStack_78)[1] + 1);
                UNLOCK();
                ppuStack_78 = param_4[0xb];
              }
              ppuStack_7c = param_4[10];
              pppuStack_378 = &param_2;
              uStack_8._0_1_ = 0x16;
              pppuStack_37c = (undefined4 ****)0xb26d96;
              pdVar7 = (double *)FUN_01682800();
              if (*pdVar7 - (double)CONCAT44(ppuStack_80,ppuStack_84) < (double)DAT_01d66e00) {
                pppuStack_380 = &ppuStack_7c;
                pppuStack_384 = (undefined4 ****)0xb26dc6;
                FUN_00557fc0();
                pppuStack_380 = (undefined4 ****)0xb26dce;
                FUN_0096e3d0();
                pppuStack_378 = (undefined4 ***)0xb26dd6;
                FUN_0056bac0();
                pppuStack_378 = (undefined4 ***)0xb26de1;
                FUN_005507b0();
                pppuStack_378 = (undefined4 ***)0xb26dec;
                FUN_005507b0();
                goto LAB_00b26dec;
              }
              uStack_8._0_1_ = 0x15;
              pppuStack_378 = (undefined4 ***)0xb26ee6;
              FUN_0056bac0();
            }
            puStack_24 = (undefined *)&pppuStack_394;
            param_3 = &pppuStack_394;
            param_4 = (undefined4 ****)CONCAT31(param_4._1_3_,DAT_01eee1b9);
            pppuStack_398 = (undefined4 ****)0x0;
            iStack_18 = CONCAT31(iStack_18._1_3_,DAT_01eee1b9);
            puStack_3f4 = &stack0x00000030;
            puStack_1c = auStack_3f0;
            puStack_3f8 = (undefined4 *)0xb26f12;
            FUN_0054f510();
            uStack_8._0_1_ = 0x17;
            pppuStack_3fc = pppuStack_14;
            uVar3 = FUN_008f7870();
            FUN_005e5de0(&puStack_3f8,uVar3);
            uStack_8._0_1_ = 0x15;
            pppuStack_3fc = param_4;
            FUN_00b14990(auStack_3d0,FUN_00b2b530,0,pppuStack_14);
            puStack_3d4 = (undefined4 *)0xb26f4f;
            FUN_00b11730();
            param_3 = (undefined4 ****)appuStack_3b4;
            param_4 = (undefined4 ****)appuStack_3b4;
            uStack_8._0_1_ = 0x18;
            pppuStack_3d8 = &stack0x00000030;
            puStack_1c = (undefined *)&puStack_3d4;
            uStack_3dc = 0xb26f6d;
            FUN_0054f510();
            puStack_28 = (undefined *)&puStack_3f4;
            uStack_8._0_1_ = 0x19;
            puStack_3f8 = &param_5;
            pppuStack_3fc = (undefined4 ****)0xb26f82;
            FUN_0054f510();
            pppuVar4 = pppuStack_14;
            uStack_8._0_1_ = 0x1a;
            puStack_74 = (undefined *)&pppuStack_3fc;
            uVar3 = FUN_008f7870(pppuStack_14);
            FUN_005e5de0(&pppuStack_3fc,uVar3);
            uStack_8._0_1_ = 0x1b;
            FUN_0054ef60(appuStack_9c);
            uStack_8._0_1_ = 0x18;
            FUN_00b14640(&puStack_2fc,FUN_00b2b680,0,pppuVar4);
            puStack_13c = puStack_2fc;
            puStack_138 = puStack_2f8;
            pppuStack_3b8 = (undefined4 ***)auStack_2f4;
            uStack_8._0_1_ = 0x1c;
            pppuStack_3bc = (undefined4 ***)0xb27002;
            FUN_00b16c00();
            pppuVar4 = param_4;
            puStack_1ac = puStack_13c;
            puStack_1a8 = puStack_138;
            pppuStack_3b8 = (undefined4 ***)auStack_134;
            uStack_8._0_1_ = 0x1d;
            *param_4 = (undefined4 ***)0x0;
            pppuStack_3bc = (undefined4 ***)0xb27039;
            FUN_00b16c00();
            puStack_21c = puStack_1ac;
            puStack_218 = puStack_1a8;
            pppuStack_3b8 = (undefined4 ***)auStack_1a4;
            uStack_8._0_1_ = 0x1e;
            pppuStack_3bc = (undefined4 ***)0xb27067;
            FUN_00b16c00();
            puStack_36c = puStack_21c;
            puStack_368 = puStack_218;
            pppuStack_3b8 = (undefined4 ***)auStack_214;
            uStack_8._0_1_ = 0x1f;
            pppuStack_3bc = (undefined4 ***)0xb27095;
            FUN_00b16c00();
            pppuStack_3b8 = (undefined4 ***)&puStack_36c;
            uStack_8._0_1_ = 0x20;
            pppuStack_3bc = (undefined4 ***)0xb270a5;
            cVar2 = FUN_00585a40();
            if (cVar2 == '\0') {
              puStack_28c = puStack_36c;
              puStack_288 = puStack_368;
              pppuStack_3b8 = (undefined4 ***)auStack_364;
              pppuStack_3bc = (undefined4 ***)0xb270da;
              FUN_00b16c00();
              pppuStack_3b8 = (undefined4 ***)0x70;
              uStack_8._0_1_ = 0x21;
              pppuStack_3bc = (undefined4 ***)0xb270e5;
              pppuVar8 = (undefined4 ***)FUN_01674e20();
              uStack_8._0_1_ = 0x22;
              if (pppuVar8 == (undefined4 ***)0x0) {
                pppuVar12 = (undefined4 ***)0x0;
                param_4 = (undefined4 ****)pppuVar8;
              }
              else {
                pppuStack_3b8 = (undefined4 ***)auStack_284;
                *pppuVar8 = (undefined4 **)puStack_28c;
                pppuVar8[1] = (undefined4 **)puStack_288;
                pppuStack_3bc = (undefined4 ***)0xb27115;
                param_4 = (undefined4 ****)pppuVar8;
                FUN_00b16c00();
                pppuVar12 = pppuVar8;
              }
              pppuVar4[2] = pppuVar12;
              pppuStack_3b8 = (undefined4 ***)0xb27127;
              FUN_00b19b60();
              pppuStack_3b8 = (undefined4 ***)0xb27132;
              FUN_00b19b60();
              param_4 = (undefined4 ****)CONCAT13(1,param_4._0_3_);
            }
            else {
              pppuStack_3b8 = (undefined4 ***)0xb27143;
              FUN_00b19b60();
              param_4 = (undefined4 ****)((uint)param_4 & 0xffffff);
            }
            pppuStack_3b8 = (undefined4 ***)0xb27152;
            FUN_00b19b60();
            ppuVar9 = &PTR_FUN_01951b88;
            if (param_4._3_1_ == '\0') {
              ppuVar9 = (undefined **)0x0;
            }
            *pppuVar4 = (undefined4 **)ppuVar9;
            pppuStack_3b8 = (undefined4 ***)0xb2716c;
            FUN_00b19b60();
            pppuStack_3b8 = (undefined4 ***)0xb27177;
            FUN_00b19b60();
            pppuStack_3b8 = (undefined4 ***)0xb27182;
            FUN_00b19b60();
            pppuStack_3b8 = (undefined4 ****)0x2;
            pppuStack_3bc = (undefined4 ****)0x0;
            uStack_8._0_1_ = 0x23;
            pppuStack_3d8 = appuStack_9c;
            uStack_3dc = 0xb2719b;
            FUN_0054ef60();
            uStack_8._0_1_ = 0x15;
            pppuStack_3d8 = (undefined4 ***)0xb271a7;
            FUN_00bcb3b0();
            pppuStack_378 = (undefined4 ***)0xb271b2;
            FUN_005507b0();
            pppuStack_378 = (undefined4 ***)0xb271bd;
            FUN_005507b0();
          }
          pppuStack_378 = (undefined4 ***)0xb271c8;
          FUN_005507b0();
          pppuStack_378 = (undefined4 ***)0xb271d0;
          FUN_005507b0();
          pppuStack_378 = (undefined4 ***)0xb271d8;
          FUN_005507b0();
          pppuStack_378 = (undefined4 ***)0xb271e0;
          FUN_005507b0();
          goto LAB_00b271e0;
        }
        pppuStack_390 = (undefined4 ***)0x46;
        pppuStack_37c = (undefined4 ****)0x0;
        pppuStack_378 = (undefined4 ***)0xf;
        pppuStack_394 = (undefined4 ***)0x1950cf0;
        pppuStack_38c = (undefined4 ***)((uint)pppuStack_38c & 0xffffff00);
        pppuStack_398 = (undefined4 ****)0xb26c8e;
        FUN_005542c0();
        pppuStack_390 = (undefined4 ****)0xb26c96;
        FUN_005e65e0();
LAB_00b26dec:
        pppuStack_378 = (undefined4 ***)0xb26df7;
        FUN_005507b0();
      }
    }
  }
  else if (param_4 == (undefined4 ****)0x1) {
    if (iStack_48 != 0) goto LAB_00b26a5b;
    pppuStack_390 = (undefined4 ***)0x3e;
    pppuStack_37c = (undefined4 ****)0x0;
    pppuStack_378 = (undefined4 ***)0xf;
    pppuStack_394 = (undefined4 ***)0x1950b64;
    pppuStack_38c = (undefined4 ***)((uint)pppuStack_38c._1_3_ << 8);
    pppuStack_398 = (undefined4 ****)0xb269e0;
    uStack_8._0_1_ = uVar1;
    FUN_005542c0();
    pppuStack_390 = (undefined4 ****)0xb269e8;
    FUN_005e65e0();
  }
  else if (param_4 == (undefined4 ****)&DAT_00000005) {
    pppuStack_390 = (undefined4 ***)0x4a;
    pppuStack_37c = (undefined4 ****)0x0;
    pppuStack_378 = (undefined4 ***)0xf;
    pppuStack_394 = (undefined4 ***)0x1950ba8;
    pppuStack_38c = (undefined4 ***)((uint)pppuStack_38c._1_3_ << 8);
    pppuStack_398 = (undefined4 ****)0xb26a14;
    uStack_8._0_1_ = uVar1;
    FUN_005542c0();
    pppuStack_390 = (undefined4 ****)0xb26a1c;
    FUN_005e65e0();
  }
  else {
    if ((param_4 != (undefined4 ****)0x2) || (iStack_30 != 0)) goto LAB_00b26a5b;
    pppuStack_390 = (undefined4 ***)0x43;
    pppuStack_37c = (undefined4 ****)0x0;
    pppuStack_378 = (undefined4 ***)0xf;
    pppuStack_394 = (undefined4 ***)0x1950bf8;
    pppuStack_38c = (undefined4 ***)((uint)pppuStack_38c._1_3_ << 8);
    pppuStack_398 = (undefined4 ****)0xb26a4e;
    uStack_8._0_1_ = uVar1;
    FUN_005542c0();
    pppuStack_390 = (undefined4 ****)0xb26a56;
    FUN_005e65e0();
  }
LAB_00b26df7:
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_2c) {
    pppuStack_378 = (undefined4 ***)(uStack_2c + 1);
    ppppuVar10 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < pppuStack_378) {
      ppppuVar10 = (undefined4 ****)apppuStack_40[0][-1];
      pppuStack_378 = (undefined4 ***)(uStack_2c + 0x24);
      if ((undefined *)0x1f < (undefined *)((int)apppuStack_40[0] + (-4 - (int)ppppuVar10))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_378 = (undefined4 ***)0xb2724e;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    pppuStack_380 = (undefined4 ****)0xb26e2c;
    pppuStack_37c = ppppuVar10;
    FUN_01674ea0();
  }
  iStack_30 = 0;
  uStack_2c = 0xf;
  apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_44) {
    pppuStack_378 = (undefined4 ***)(uStack_44 + 1);
    ppppuVar10 = (undefined4 ****)apppuStack_58[0];
    if (0xfff < pppuStack_378) {
      ppppuVar10 = (undefined4 ****)apppuStack_58[0][-1];
      pppuStack_378 = (undefined4 ***)(uStack_44 + 0x24);
      if ((undefined *)0x1f < (undefined *)((int)apppuStack_58[0] + (-4 - (int)ppppuVar10))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_378 = (undefined4 ***)0xb27253;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    pppuStack_380 = (undefined4 ****)0xb26e76;
    pppuStack_37c = ppppuVar10;
    FUN_01674ea0();
  }
  iStack_48 = 0;
  uStack_44 = 0xf;
  apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
  uStack_8._0_1_ = 1;
  if (0xf < uStack_5c) {
    pppuStack_378 = (undefined4 ***)(uStack_5c + 1);
    ppppuVar10 = (undefined4 ****)apppuStack_70[0];
    if (0xfff < pppuStack_378) {
      ppppuVar10 = (undefined4 ****)apppuStack_70[0][-1];
      pppuStack_378 = (undefined4 ***)(uStack_5c + 0x24);
      if ((undefined *)0x1f < (undefined *)((int)apppuStack_70[0] + (-4 - (int)ppppuVar10))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_378 = (undefined4 ***)&UNK_00b27258;
        FUN_017167a3();
      }
    }
    pppuStack_380 = (undefined4 ***)0xb26ec0;
    pppuStack_37c = ppppuVar10;
    FUN_01674ea0();
  }
  iStack_60 = 0;
  uStack_5c = 0xf;
  apppuStack_70[0] = (undefined4 ***)((uint)apppuStack_70[0] & 0xffffff00);
LAB_00b271e0:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x24);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      pppuStack_380 = (undefined4 ***)&stack0x00000018;
      pppuStack_378 = (undefined4 ***)0x2;
      pppuStack_384 = (undefined4 ***)0xb27201;
      pppuStack_37c = pppuStack_380;
      (**(code **)(param_5 & 0xfffffffe))();
    }
    param_5 = 0;
  }
  uStack_8 = 0x25;
  if (((in_stack_00000030 != (undefined4 ***)0x0) && (((uint)in_stack_00000030 & 1) == 0)) &&
     (*(code **)((uint)in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
    pppuStack_380 = (undefined4 ***)&stack0x00000038;
    pppuStack_378 = (undefined4 ***)0x2;
    pppuStack_384 = (undefined4 ***)0xb2722f;
    pppuStack_37c = pppuStack_380;
    (**(code **)((uint)in_stack_00000030 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23625 ; VA 0x00b27260 ; FUN_00b27260 */

int __thiscall FUN_00b27260(undefined4 param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined *apuStack_84 [2];
  code *pcStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  code *pcStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined *puStack_24;
  code *pcStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0788;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_6c = CONCAT44(auStack_2c,0xb2728f);
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_00b264d0();
  piStack_1c = (int *)*puVar4;
  uStack_8._0_1_ = 1;
  pcStack_20 = *(code **)(*piStack_1c + 0xc);
  uStack_6c = CONCAT44(param_1,0xb272a6);
  iVar5 = FUN_008f7870();
  puStack_24 = (undefined *)apuStack_84;
  piVar2 = *(int **)(iVar5 + 0x43c);
  iStack_18 = *piVar2 - (int)piVar2;
  iStack_14 = piVar2[1] - (int)piVar2;
  uStack_34 = CONCAT44(in_stack_00000020,in_stack_0000001c);
  pcStack_44 = FUN_00b24300;
  uStack_40 = 0;
  uStack_3c = param_1;
  cVar3 = FUN_00585a40(&pcStack_44);
  if (cVar3 == '\0') {
    pcStack_7c = pcStack_44;
    uStack_78 = uStack_40;
    uStack_74 = uStack_3c;
    uStack_70 = uStack_38;
    uStack_6c = uStack_34;
    apuStack_84[0] = &DAT_01951b99;
  }
  else {
    apuStack_84[0] = (undefined *)0x0;
  }
  uStack_8._0_1_ = 2;
  FUN_0054ef60(&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar5 = (*pcStack_20)(param_1);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_28 + 1;
    iVar1 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar5 = (**(code **)*piStack_28)();
      LOCK();
      piVar2 = piStack_28 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar5 = (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    iVar5 = param_2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_2 + -4);
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23626 ; VA 0x00b273d0 ; FUN_00b273d0 */

int FUN_00b273d0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 uVar6;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f07b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_01eee1b4);
  uStack_8._0_1_ = 1;
  uStack_14 = uVar4;
  FUN_00562c90(&iStack_1c,&param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_1c != 0) {
    uVar6 = FUN_00928340();
    FUN_00b24300(uVar6);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar5 = piStack_18[2] + -1;
      piStack_18[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar5 = FUN_01675290(uVar4);
  piVar3 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23627 ; VA 0x00b274b0 ; FUN_00b274b0 */

void __thiscall
FUN_00b274b0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 *param_7,ulonglong param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15)

{
  int *piVar1;
  code *pcVar2;
  uint *puVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 *puVar7;
  int iVar8;
  uint auStack_70 [2];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 *puStack_5c;
  ulonglong uStack_58;
  uint auStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  undefined8 uStack_38;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f07f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if (param_1 == 0) goto LAB_00b276ba;
  iVar8 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (iVar8 == 0) {
LAB_00b274f4:
    iVar8 = param_1;
  }
  else {
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar8 + 0x34) != 0) {
      uStack_38 = CONCAT44(0xb274f4,(undefined4)uStack_38);
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
      goto LAB_00b274f4;
    }
  }
  if (iVar8 != 0) {
    iVar8 = *(int *)(iVar8 + 0xc);
    uStack_38 = CONCAT44(0xb27506,(undefined4)uStack_38);
    iVar4 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      uStack_38 = 0x63410001ead600;
      puStack_3c = (undefined4 *)0xb27534;
      FUN_005789c0();
      uStack_38 = CONCAT44(0xb2753c,(undefined4)uStack_38);
      uVar5 = FUN_00635450();
      uStack_38 = CONCAT44(uVar5,0xb27544);
      piStack_14 = (int *)FUN_008aa140();
      if (*piStack_14 == 0) {
        uStack_38 = CONCAT44(0xb27558,(undefined4)uStack_38);
        uVar5 = FUN_00b7a190();
        uStack_38 = CONCAT44(uVar5,auStack_20);
        puStack_3c = (undefined4 *)0xb27564;
        piVar6 = (int *)FUN_008a9ba0();
        iVar8 = *piVar6;
        iVar4 = piVar6[1];
        *piVar6 = 0;
        piVar6[1] = 0;
        *piStack_14 = iVar8;
        piVar6 = (int *)piStack_14[1];
        piStack_14[1] = iVar4;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar8 = piVar6[1] + -1;
          piVar6[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            uStack_38 = CONCAT44(0xb27594,(undefined4)uStack_38);
            (**(code **)*piVar6)();
            LOCK();
            iVar8 = piVar6[2] + -1;
            piVar6[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              uStack_38 = CONCAT44(0xb275a4,(undefined4)uStack_38);
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        piVar6 = piStack_1c;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar8 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            uStack_38 = CONCAT44(0xb275bd,(undefined4)uStack_38);
            (**(code **)*piStack_1c)();
            LOCK();
            piVar1 = piVar6 + 2;
            iVar8 = *piVar1 + -1;
            *piVar1 = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              uStack_38 = CONCAT44(0xb275cd,(undefined4)uStack_38);
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        if (*piStack_14 == 0) goto LAB_00b276ba;
      }
      uStack_38 = CONCAT44(auStack_28,0xb275e5);
      puVar7 = (undefined4 *)FUN_00b264d0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      pcVar2 = *(code **)(*(int *)*puVar7 + 0x24);
      uStack_38 = CONCAT44(0xb275f5,(undefined4)uStack_38);
      iStack_18 = FUN_00b83190();
      piStack_14 = (int *)auStack_50;
      piStack_1c = (int *)auStack_50;
      auStack_50[0] = 0;
      puVar3 = auStack_50;
      if (param_9 != 0) {
        auStack_50[0] = param_9;
        if ((param_9 & 1) == 0) {
          uStack_58 = ZEXT48(&uStack_48);
          puStack_5c = &param_11;
          uStack_60 = 0xb2763c;
          (**(code **)(param_9 & 0xfffffffe))();
          puVar3 = (uint *)piStack_14;
        }
        else {
          uStack_48 = param_11;
          uStack_44 = param_12;
          uStack_40 = param_13;
          puStack_3c = (undefined4 *)param_14;
          uStack_38 = param_15;
          puVar3 = auStack_50;
        }
      }
      piStack_14 = (int *)puVar3;
      piStack_1c = (int *)auStack_70;
      uStack_8._0_1_ = 3;
      auStack_70[0] = 0;
      puVar3 = auStack_70;
      if (param_2 != 0) {
        auStack_70[0] = param_2;
        if ((param_2 & 1) == 0) {
          (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_68,0);
          puVar3 = (uint *)piStack_1c;
        }
        else {
          uStack_68 = param_4;
          uStack_64 = param_5;
          uStack_60 = param_6;
          puStack_5c = param_7;
          uStack_58 = param_8;
          puVar3 = auStack_70;
        }
      }
      piStack_1c = (int *)puVar3;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      (*pcVar2)(iStack_18);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_24[1] + -1;
        piStack_24[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          uStack_38 = CONCAT44(0xb276ab,(undefined4)uStack_38);
          (**(code **)*piStack_24)();
          LOCK();
          piVar6 = piStack_24 + 2;
          iVar8 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar8 == 1) {
            uStack_38 = CONCAT44(0xb276ba,(undefined4)uStack_38);
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
    }
  }
LAB_00b276ba:
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_3c = &param_4;
    uStack_38 = CONCAT44(2,puStack_3c);
    uStack_40 = 0xb276db;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_3c = &param_11;
    uStack_38 = CONCAT44(2,puStack_3c);
    uStack_40 = 0xb27709;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23628 ; VA 0x00b27720 ; FUN_00b27720 */

void FUN_00b27720(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  uint in_stack_00000028;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0828;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (iStack_1c != 0) {
    if (in_stack_00000024 != (int *)0x0) {
      LOCK();
      in_stack_00000024[1] = in_stack_00000024[1] + 1;
      UNLOCK();
    }
    FUN_0096e3d0(in_stack_00000020,in_stack_00000024);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[2] + -1;
    param_2[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = in_stack_00000024 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*in_stack_00000024 + 4))();
      }
    }
  }
  uStack_8 = 5;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&stack0x00000030,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23629 ; VA 0x00b27850 ; FUN_00b27850 */

int FUN_00b27850(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0850;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puVar3 = &param_3;
  if (0xf < in_stack_00000020) {
    puVar3 = param_3;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0086f2f0(3,"Error fetching MarketplaceService receipts: %s",puVar3);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    puVar3 = param_3;
    if (0xfff < uVar5) {
      puVar3 = (undefined4 *)param_3[-1];
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(puVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23630 ; VA 0x00b278f0 ; FUN_00b278f0 */

void * FUN_00b278f0(undefined4 param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  code *pcVar3;
  undefined *puVar4;
  void *pvVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int in_stack_0000001c;
  uint in_stack_00000020;
  int *piStack_158;
  undefined4 uStack_154;
  undefined auStack_150 [20];
  undefined4 uStack_13c;
  undefined4 *puStack_138;
  int *piStack_134;
  int *piStack_130;
  int iStack_120;
  void *pvStack_11c;
  int aiStack_118 [50];
  int *piStack_50;
  int *piStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined4 uStack_24;
  undefined *puStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f088b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_7 = 0;
  pvVar5 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_0000001c != 0) {
    piStack_130 = &iStack_34;
    piStack_134 = (int *)0xb27931;
    ExceptionList = &pvStack_10;
    pvVar5 = (void *)FUN_00587490();
    uStack_8 = 2;
    if (iStack_34 != 0) {
      piStack_130 = (int *)0xb27944;
      iStack_120 = FUN_00888530();
      pvStack_11c = (void *)0x0;
      piStack_130 = (int *)0x0;
      piStack_134 = &iStack_120;
      uStack_8 = 3;
      puStack_138 = &param_3;
      uStack_13c = 0xb2796a;
      FUN_0098ef90();
      iVar7 = iStack_120;
      piStack_130 = (int *)0xb27978;
      iVar6 = FUN_008882f0();
      iVar8 = iStack_120;
      if (iVar7 == iVar6) {
        piStack_130 = (int *)0xb2798b;
        iVar7 = FUN_008882f0();
        if (iVar8 != iVar7) {
          piStack_130 = (int *)0x18c072c;
                    /* WARNING: Subroutine does not return */
          piStack_134 = (int *)0xb27c3d;
          FUN_016757c0();
        }
        piStack_50 = aiStack_118;
        if (pvStack_11c == (void *)0x0) {
          piStack_50 = (int *)0x0;
        }
        piStack_4c = (int *)piStack_50[1];
        piStack_1c = piStack_4c;
        if (piStack_4c != (int *)0x0) {
          LOCK();
          piStack_4c[1] = piStack_4c[1] + 1;
          UNLOCK();
          piStack_4c = (int *)piStack_50[1];
          piStack_1c = piStack_4c;
        }
        piStack_50 = (int *)*piStack_50;
        uStack_8 = 4;
        iVar7 = piStack_50[1] - *piStack_50 >> 0x1f;
        uStack_14 = 0;
        piStack_2c = piStack_50;
        piStack_1c = piStack_4c;
        if ((piStack_50[1] - *piStack_50) / 0xd0 + iVar7 != iVar7) {
          iStack_18 = 0;
          do {
            piVar2 = piStack_2c;
            puVar4 = puStack_20;
            if ((uint)((piStack_2c[1] - *piStack_2c) / 0xd0) <= uStack_14) {
LAB_00b27c42:
              puStack_20 = puVar4;
              piStack_130 = (int *)0xb27c47;
              FUN_00577c40();
              pcVar3 = (code *)swi(3);
              pvVar5 = (void *)(*pcVar3)();
              return pvVar5;
            }
            iVar7 = *(int *)(iStack_18 + *piStack_2c);
            piStack_130 = (int *)0xb27a1f;
            iVar8 = FUN_008881d0();
            if (iVar7 == iVar8) {
              piStack_130 = (int *)iStack_34;
              piStack_134 = (int *)0xb27a2f;
              uStack_24 = FUN_008f7870();
              iVar7 = *piVar2;
              piStack_130 = (int *)0x1;
              puStack_20 = auStack_150;
              puVar4 = auStack_150;
              if ((uint)((piVar2[1] - iVar7) / 0xd0) <= uStack_14) goto LAB_00b27c42;
              FUN_00b1c500(&piStack_158,iStack_18 + iVar7);
              if (param_2 != (int *)0x0) {
                LOCK();
                param_2[2] = param_2[2] + 1;
                UNLOCK();
              }
              FUN_00b140a0(&uStack_48,FUN_00b2d6c0,param_1,param_2);
              uStack_154 = 0;
              if (piStack_40 != (int *)0x0) {
                LOCK();
                piStack_40[2] = piStack_40[2] + 1;
                UNLOCK();
              }
              if (piStack_38 != (int *)0x0) {
                LOCK();
                piStack_38[1] = piStack_38[1] + 1;
                UNLOCK();
              }
              piStack_158 = piStack_38;
              FUN_00b11340(uStack_48,uStack_44,piStack_40,uStack_3c);
              piVar2 = piStack_38;
              if (piStack_38 != (int *)0x0) {
                LOCK();
                iVar7 = piStack_38[1] + -1;
                piStack_38[1] = iVar7;
                UNLOCK();
                if (iVar7 == 0) {
                  uStack_154 = 0xb27b19;
                  (**(code **)*piStack_38)();
                  LOCK();
                  piVar1 = piVar2 + 2;
                  iVar7 = *piVar1 + -1;
                  *piVar1 = iVar7;
                  UNLOCK();
                  if (iVar7 == 0) {
                    uStack_154 = 0xb27b29;
                    (**(code **)(*piVar2 + 4))();
                  }
                }
              }
              if (piStack_40 != (int *)0x0) {
                LOCK();
                iVar7 = piStack_40[2] + -1;
                piStack_40[2] = iVar7;
                UNLOCK();
                if (iVar7 == 0) {
                  uStack_154 = 0xb27b3e;
                  (**(code **)(*piStack_40 + 4))();
                }
              }
              uStack_154 = 0xb27b46;
              FUN_0090ca30();
            }
            iStack_18 = iStack_18 + 0xd0;
            uStack_14 = uStack_14 + 1;
          } while (uStack_14 < (uint)((piStack_2c[1] - *piStack_2c) / 0xd0));
        }
        piVar2 = piStack_1c;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar7 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            piStack_130 = (int *)0xb27b8b;
            (**(code **)*piStack_1c)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar7 = *piVar1 + -1;
            *piVar1 = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              piStack_130 = (int *)0xb27b9b;
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
      }
      uStack_8 = 5;
      pvVar5 = pvStack_11c;
      if (pvStack_11c != (void *)0x0) {
        piStack_130 = aiStack_118;
        piStack_134 = (int *)0xb27bb5;
        pvVar5 = (void *)(**(code **)((int)pvStack_11c + 8))();
      }
    }
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_30 + 1;
      iVar7 = *piVar2;
      pvVar5 = (void *)*piVar2;
      *piVar2 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        piStack_130 = (int *)0xb27bce;
        (**(code **)*piStack_30)();
        LOCK();
        piVar2 = piStack_30 + 2;
        iVar7 = *piVar2;
        pvVar5 = (void *)*piVar2;
        *piVar2 = iVar7 + -1;
        UNLOCK();
        if (iVar7 + -1 == 0) {
          piStack_130 = (int *)0xb27bde;
          pvVar5 = (void *)(**(code **)(*piStack_30 + 4))();
        }
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 2;
    iVar7 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar7 == 1) {
      piStack_130 = (int *)0xb27bf2;
      pvVar5 = (void *)(**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    piStack_130 = (int *)(in_stack_00000020 + 1);
    iVar7 = param_3;
    if (0xfff < piStack_130) {
      iVar7 = *(int *)(param_3 + -4);
      piStack_130 = (int *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_3 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_130 = (int *)0xb27c42;
        FUN_017167a3();
      }
    }
    puStack_138 = (undefined4 *)0xb27c1f;
    piStack_134 = (int *)iVar7;
    pvVar5 = (void *)FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 23631 ; VA 0x00b27c50 ; FUN_00b27c50 */

void FUN_00b27c50(void)

{
  FUN_00b1ad50();
  return;
}



/* FUNCTION 23632 ; VA 0x00b27c60 ; FUN_00b27c60 */

void FUN_00b27c60(undefined4 *param_1)

{
  (*(code *)*param_1)(param_1[4],param_1[5]);
  return;
}



/* FUNCTION 23633 ; VA 0x00b27c80 ; FUN_00b27c80 */

int FUN_00b27c80(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f08b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_24);
  uStack_8 = 0;
  if (iStack_24 == 0) {
    iVar5 = 0;
    piVar2 = piStack_20;
  }
  else {
    uStack_14 = *(undefined4 *)(param_1 + 8);
    iVar3 = *(int *)(param_1 + 0x10);
    uVar4 = *(undefined4 *)(param_1 + 0xc);
    iVar5 = FUN_008f7870(iStack_24);
    piVar2 = piStack_20;
    if (iVar5 != 0) {
      FUN_0055e560();
      iVar5 = FUN_0097fc00(&iStack_1c,uStack_14,uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if ((iStack_1c != 0) && (*(int *)(iStack_1c + 0x450) != iVar3)) {
        FUN_00933eb0(iVar3);
        if (piStack_18 != (int *)0x0) {
          LOCK();
          piStack_18[1] = piStack_18[1] + 1;
          UNLOCK();
        }
        iVar5 = FUN_0098cf30(iStack_1c,piStack_18);
      }
      piVar2 = piStack_20;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_18 + 1;
        iVar3 = *piVar1;
        iVar5 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar2 = piStack_18 + 2;
          iVar3 = *piVar2;
          iVar5 = *piVar2;
          *piVar2 = iVar3 + -1;
          UNLOCK();
          piVar2 = piStack_20;
          if (iVar3 + -1 == 0) {
            iVar5 = (**(code **)(*piStack_18 + 4))();
            piVar2 = piStack_20;
          }
        }
      }
    }
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23634 ; VA 0x00b27db0 ; FUN_00b27db0 */

void FUN_00b27db0(undefined4 *param_1,undefined4 param_2)

{
  code *pcVar1;
  
  pcVar1 = (code *)*param_1;
  FUN_006d07c0(param_1 + 1);
  (*pcVar1)(param_2);
  return;
}



/* FUNCTION 23635 ; VA 0x00b27de0 ; FUN_00b27de0 */

int FUN_00b27de0(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d0460;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  pcVar4 = (code *)*puVar3;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  FUN_0054ef60(puVar3 + 3);
  if (puVar3[2] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar5 = (*pcVar4)(puVar3[1],puVar3[2]);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23636 ; VA 0x00b27ec0 ; FUN_00b27ec0 */

void FUN_00b27ec0(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  FUN_006d07c0(puVar2 + 3);
  if (puVar2[2] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar3)(puVar2[1],puVar2[2]);
  return;
}



/* FUNCTION 23637 ; VA 0x00b27f20 ; FUN_00b27f20 */

void FUN_00b27f20(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f08d0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  iStack_8._0_1_ = 1;
  FUN_006d07c0(puVar2 + 3);
  if (puVar2[2] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  (*pcVar3)(puVar2[1],puVar2[2]);
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23638 ; VA 0x00b28000 ; FUN_00b28000 */

void FUN_00b28000(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c4740;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  iStack_8._0_1_ = 1;
  FUN_0054ef60(puVar2 + 3);
  if (puVar2[2] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  (*pcVar3)(puVar2[1],puVar2[2]);
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23639 ; VA 0x00b280d0 ; FUN_00b280d0 */

void FUN_00b280d0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pcVar2 = (code *)*param_1;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(param_1[1],param_1[2]);
  if (0xf < in_stack_0000001c) {
    uVar4 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_2 + -4);
      uVar4 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23640 ; VA 0x00b28180 ; FUN_00b28180 */

void FUN_00b28180(undefined4 *param_1)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  pcVar2 = (code *)*param_1;
  if (param_1[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[4] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = param_1[3];
  uVar4 = param_1[4];
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(param_1[1],param_1[2],uVar3,uVar4);
  return;
}



/* FUNCTION 23641 ; VA 0x00b281f0 ; FUN_00b281f0 */

int FUN_00b281f0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1328;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *param_1;
  param_1 = &param_2;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00b11ce0(param_1,uVar3,&param_1,0);
  piVar4 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23642 ; VA 0x00b28270 ; FUN_00b28270 */

void FUN_00b28270(int *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  
  puVar2 = (undefined4 *)*param_1;
  uVar3 = puVar2[10];
  pcVar4 = (code *)*puVar2;
  uVar5 = puVar2[9];
  uVar6 = puVar2[8];
  if (puVar2[7] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[7] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar7 = puVar2[6];
  uVar8 = puVar2[7];
  if (puVar2[5] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[5] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar9 = puVar2[4];
  uVar10 = puVar2[5];
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar4)(puVar2[2],puVar2[3],uVar9,uVar10,uVar7,uVar8,uVar6,uVar5,uVar3,param_2);
  return;
}



/* FUNCTION 23643 ; VA 0x00b28310 ; FUN_00b28310 */

void FUN_00b28310(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  uint uVar11;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  uVar4 = puVar2[8];
  uVar5 = puVar2[9];
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  if (puVar2[7] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[7] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar6 = puVar2[6];
  uVar7 = puVar2[7];
  if (puVar2[5] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[5] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar8 = puVar2[4];
  uVar9 = puVar2[5];
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar3)(puVar2[2],puVar2[3],uVar8,uVar9,uVar6,uVar7,uVar4,uVar5);
  if (0xf < in_stack_0000001c) {
    uVar11 = in_stack_0000001c + 1;
    iVar10 = param_2;
    if (0xfff < uVar11) {
      iVar10 = *(int *)(param_2 + -4);
      uVar11 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar10,uVar11);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23644 ; VA 0x00b28420 ; FUN_00b28420 */

void FUN_00b28420(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f08f8;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar2 = *param_1;
  uVar1 = *(undefined4 *)(iVar2 + 8);
  uStack_40 = 0;
  uVar3 = *(uint *)(iVar2 + 0x30);
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_40 = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      iStack_4c = iVar2 + 0x38;
      uStack_50 = 0xb28490;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_38 = *(undefined4 *)(iVar2 + 0x38);
      uStack_34 = *(undefined4 *)(iVar2 + 0x3c);
      uStack_30 = *(undefined4 *)(iVar2 + 0x40);
      uStack_2c = *(undefined4 *)(iVar2 + 0x44);
      uStack_28 = *(undefined8 *)(iVar2 + 0x48);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  uVar3 = *(uint *)(iVar2 + 0x10);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(iVar2 + 0x18,&uStack_58,0);
    }
    else {
      uStack_58 = *(undefined4 *)(iVar2 + 0x18);
      uStack_54 = *(undefined4 *)(iVar2 + 0x1c);
      uStack_50 = *(undefined4 *)(iVar2 + 0x20);
      iStack_4c = *(int *)(iVar2 + 0x24);
      uStack_48 = *(ulonglong *)(iVar2 + 0x28);
    }
  }
  iStack_8._0_1_ = 2;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00b1b1c0(uVar1);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
        uStack_28 = CONCAT44(&UNK_00b28541,(undefined4)uStack_28);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_28 = CONCAT44(uVar3,iVar2);
    uStack_2c = 0xb28529;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23645 ; VA 0x00b28550 ; FUN_00b28550 */

void FUN_00b28550(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f0928;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar2 = *param_1;
  uVar3 = *(undefined4 *)(iVar2 + 8);
  uVar4 = *(uint *)(iVar2 + 0x18);
  ExceptionList = &pvStack_10;
  if ((uVar4 != 0) && (ExceptionList = &pvStack_10, (uVar4 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar4 & 0xfffffffe))(iVar2 + 0x20);
  }
  if (*(int *)(iVar2 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x10) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8._0_1_ = 2;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00b1b350(uVar3);
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23646 ; VA 0x00b28660 ; FUN_00b28660 */

void FUN_00b28660(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *(undefined4 *)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  FUN_00b1b4b0(uVar1);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23647 ; VA 0x00b28700 ; FUN_00b28700 */

void FUN_00b28700(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *param_1;
  param_1 = &param_2;
  ExceptionList = &pvStack_10;
  FUN_00b11f10(param_1,uVar1,&param_1,0);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23648 ; VA 0x00b28780 ; FUN_00b28780 */

void FUN_00b28780(undefined4 *param_1)

{
  undefined *puStack_c;
  undefined *puStack_8;
  
  puStack_c = &stack0x00000008;
  puStack_8 = &stack0x0000000c;
  FUN_00b11bc0(param_1,*param_1,&puStack_c,0);
  return;
}



/* FUNCTION 23649 ; VA 0x00b287b0 ; FUN_00b287b0 */

void FUN_00b287b0(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint in_stack_00000030;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0958;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)&param_2;
  uStack_8 = 2;
  puStack_18 = &param_4;
  puStack_14 = &stack0x00000030;
  ExceptionList = &pvStack_10;
  FUN_00b11a90(param_1,param_1,&puStack_1c,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000018,&stack0x00000018,2);
    }
    param_4 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_00000030 != 0) && ((in_stack_00000030 & 1) == 0)) &&
     (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000030 & 0xfffffffe))(&stack0x00000038,&stack0x00000038,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23650 ; VA 0x00b28890 ; FUN_00b28890 */

void FUN_00b28890(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint in_stack_00000030;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0958;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)&param_2;
  uStack_8 = 2;
  puStack_18 = &param_4;
  puStack_14 = &stack0x00000030;
  ExceptionList = &pvStack_10;
  FUN_00b11de0(param_1,param_1,&puStack_1c,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000018,&stack0x00000018,2);
    }
    param_4 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_00000030 != 0) && ((in_stack_00000030 & 1) == 0)) &&
     (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000030 & 0xfffffffe))(&stack0x00000038,&stack0x00000038,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23651 ; VA 0x00b28970 ; FUN_00b28970 */

void FUN_00b28970(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,uint param_5
                 ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 *param_10,ulonglong param_11,char *param_12,undefined4 param_13,
                 uint param_14,undefined4 param_15,undefined4 param_16,TypeDescriptor *param_17,
                 undefined8 param_18)

{
  int iVar1;
  uint *puVar2;
  char **ppcVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined8 uVar6;
  uint auStack_80 [2];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 *puStack_6c;
  undefined8 uStack_68;
  char *pcStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  TypeDescriptor *pTStack_4c;
  undefined8 uStack_48;
  undefined auStack_38 [4];
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  code *pcStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f09a0;
  pvStack_10 = ExceptionList;
  uStack_48 = 0x1d98770;
  pTStack_4c = &RBX::Instance::RTTI_Type_Descriptor;
  uStack_50 = 0;
  uStack_54 = param_1;
  uStack_8 = 3;
  uStack_58 = 0xb289ad;
  ExceptionList = &pvStack_10;
  iStack_14 = FUN_0170d75d();
  if (iStack_14 == 0) {
    piVar5 = (int *)0x0;
    iStack_14 = 0;
  }
  else {
    piVar5 = param_2;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
  }
  uStack_8._0_1_ = 4;
  iStack_30 = iStack_14;
  piStack_2c = piVar5;
  if (iStack_14 == 0) {
    uStack_5c = 0x59;
    uStack_48 = 0xf00000000;
    pcStack_60 = 
    "MarketplaceService:IsPlayerSubscribed() was called with an instance that is not a Player.";
    uStack_58 = uStack_58 & 0xffffff00;
    uStack_68 = CONCAT44(0xb289fc,(undefined4)uStack_68);
    FUN_005542c0();
    uStack_5c = 0xb28a04;
    FUN_005e65e0();
  }
  else {
    uStack_48 = CONCAT44(auStack_38,0xb28a15);
    puVar4 = (undefined4 *)FUN_00b264d0();
    piStack_1c = (int *)*puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pcStack_20 = *(code **)(*piStack_1c + 0x30);
    uStack_48 = CONCAT44(0xb28a2e,(undefined4)uStack_48);
    uVar6 = FUN_00928340();
    uStack_18 = (undefined4)((ulonglong)uVar6 >> 0x20);
    iStack_14 = (int)uVar6;
    puStack_24 = (undefined *)&pcStack_60;
    puStack_28 = (undefined *)&pcStack_60;
    pcStack_60 = (char *)0x0;
    ppcVar3 = &pcStack_60;
    if (param_12 != (char *)0x0) {
      pcStack_60 = param_12;
      if (((uint)param_12 & 1) == 0) {
        uStack_68 = ZEXT48(&uStack_58);
        puStack_6c = &param_14;
        uStack_70 = 0xb28a78;
        (**(code **)((uint)param_12 & 0xfffffffe))();
        uVar6 = CONCAT44(uStack_18,iStack_14);
        ppcVar3 = (char **)puStack_24;
      }
      else {
        uStack_58 = param_14;
        uStack_54 = param_15;
        uStack_50 = param_16;
        pTStack_4c = param_17;
        uStack_48 = param_18;
        ppcVar3 = &pcStack_60;
      }
    }
    puStack_24 = (undefined *)ppcVar3;
    uStack_18 = (undefined4)((ulonglong)uVar6 >> 0x20);
    iStack_14 = (int)uVar6;
    puStack_28 = (undefined *)auStack_80;
    uStack_8._0_1_ = 6;
    auStack_80[0] = 0;
    puVar2 = auStack_80;
    if (param_5 != 0) {
      auStack_80[0] = param_5;
      if ((param_5 & 1) == 0) {
        (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_78,0);
        uVar6 = CONCAT44(uStack_18,iStack_14);
        puVar2 = (uint *)puStack_28;
      }
      else {
        uStack_78 = param_7;
        uStack_74 = param_8;
        uStack_70 = param_9;
        puStack_6c = param_10;
        uStack_68 = param_11;
        puVar2 = auStack_80;
      }
    }
    puStack_28 = (undefined *)puVar2;
    uStack_18 = (undefined4)((ulonglong)uVar6 >> 0x20);
    iStack_14 = (int)uVar6;
    uStack_8._0_1_ = 5;
    (*pcStack_20)(uVar6,param_3,param_4);
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_34[1] + -1;
      piStack_34[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_48 = CONCAT44(0xb28af0,(undefined4)uStack_48);
        (**(code **)*piStack_34)();
        LOCK();
        iVar1 = piStack_34[2] + -1;
        piStack_34[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          uStack_48 = CONCAT44(0xb28b01,(undefined4)uStack_48);
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar1 = piVar5[1] + -1;
    piVar5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_48 = CONCAT44(0xb28b14,(undefined4)uStack_48);
      (**(code **)*piVar5)();
      LOCK();
      iVar1 = piVar5[2] + -1;
      piVar5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_48 = CONCAT44(0xb28b24,(undefined4)uStack_48);
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = param_2[1] + -1;
    param_2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_48 = CONCAT44(0xb28b3a,(undefined4)uStack_48);
      (**(code **)*param_2)();
      LOCK();
      piVar5 = param_2 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        uStack_48 = CONCAT44(0xb28b49,(undefined4)uStack_48);
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    pTStack_4c = (TypeDescriptor *)&param_7;
    uStack_48 = CONCAT44(2,pTStack_4c);
    uStack_50 = 0xb28b6a;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 8;
  if (((param_12 != (char *)0x0) && (((uint)param_12 & 1) == 0)) &&
     (*(code **)((uint)param_12 & 0xfffffffe) != (code *)0x0)) {
    pTStack_4c = (TypeDescriptor *)&param_14;
    uStack_48 = CONCAT44(2,pTStack_4c);
    uStack_50 = 0xb28b98;
    (**(code **)((uint)param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23652 ; VA 0x00b28bb0 ; FUN_00b28bb0 */

int FUN_00b28bb0(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint in_stack_00000038;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f09d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (iStack_18 != 0) {
    FUN_00591e70(iStack_18 + 0xf8);
    FUN_00b22bd0(&param_7);
    FUN_005923a0();
    puVar4 = &param_9;
    if (0xf < in_stack_00000038) {
      puVar4 = param_9;
    }
    iVar3 = FUN_0086f2f0(3,"Error fetching player membership: %s",puVar4);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_6 + 4))();
    }
  }
  if (0xf < in_stack_00000038) {
    uVar5 = in_stack_00000038 + 1;
    puVar4 = param_9;
    if (0xfff < uVar5) {
      puVar4 = (undefined4 *)param_9[-1];
      uVar5 = in_stack_00000038 + 0x24;
      if (0x1f < (uint)((int)param_9 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(puVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23653 ; VA 0x00b28ce0 ; FUN_00b28ce0 */

int FUN_00b28ce0(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,int param_5,
                int *param_6,undefined4 param_7,undefined *param_8,int param_9,undefined *param_10)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint in_stack_fffffecc;
  undefined *puStack_11c;
  undefined *puStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined *puStack_108;
  int aiStack_104 [2];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined8 uStack_f4;
  undefined auStack_e0 [24];
  undefined auStack_c8 [24];
  undefined auStack_b0 [24];
  undefined auStack_98 [16];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined auStack_80 [16];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined auStack_68 [4];
  int *piStack_64;
  undefined auStack_58 [4];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined *puStack_24;
  int iStack_20;
  undefined *puStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0a8c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_f4 = (double)CONCAT44(&iStack_40,0xb28d14);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490();
  uStack_8._0_1_ = 3;
  if (iStack_40 != 0) {
    uStack_f4 = (double)CONCAT44(&iStack_38,0xb28d32);
    iVar3 = FUN_00587490();
    uStack_8._0_1_ = 4;
    if (iStack_38 != 0) {
      uStack_f4 = (double)CONCAT44(iStack_40 + 0xf8,0xb28d50);
      FUN_00591e70();
      iStack_20 = iStack_40 + 0x108;
      uStack_8._0_1_ = 5;
      uStack_f4 = (double)CONCAT44(&param_7,0xb28d68);
      iVar3 = FUN_00b1ab60();
      puStack_1c = *(undefined **)(iVar3 + 8);
      if ((puStack_1c == param_10) && (param_9 < DAT_01d66e50)) {
        iStack_18 = 0;
        piStack_14 = (int *)0x0;
        if (param_6 != (int *)0x0) {
          piVar1 = param_6 + 1;
          iVar3 = param_6[1];
          while (iVar3 != 0) {
            LOCK();
            iVar4 = *piVar1;
            if (iVar3 == iVar4) {
              *piVar1 = iVar3 + 1;
              iVar4 = iVar3;
            }
            UNLOCK();
            if (iVar4 == iVar3) {
              iStack_18 = param_5;
              piStack_14 = param_6;
              break;
            }
            iVar3 = *piVar1;
          }
        }
        uStack_8._0_1_ = 6;
        if (iStack_18 != 0) {
          uStack_f4 = (double)DAT_01d66e58;
          puStack_118 = (undefined *)0x0;
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[2] = param_2[2] + 1;
            UNLOCK();
          }
          if (param_4 != (int *)0x0) {
            LOCK();
            param_4[2] = param_4[2] + 1;
            UNLOCK();
          }
          if (param_6 != (int *)0x0) {
            LOCK();
            param_6[2] = param_6[2] + 1;
            UNLOCK();
          }
          puStack_11c = puStack_1c;
          FUN_00b10900(param_7,param_8,param_9,param_1,param_2,param_3,param_4,param_5,param_6);
          puStack_118 = (undefined *)0xb28e78;
          FUN_009eef30();
        }
        uStack_f4 = (double)CONCAT44(0xb28e80,(undefined *)uStack_f4);
        FUN_00550b30();
        uStack_f4 = (double)CONCAT44(0xb28e88,(undefined *)uStack_f4);
        iVar3 = FUN_005923a0();
      }
      else {
        if (puStack_1c != &DAT_00000004) {
          auStack_58[0] = 0;
          uStack_f4._4_4_ = 0xb;
          uStack_f4._0_4_ = (undefined *)0xb28eb5;
          uStack_54 = FUN_00588320();
          uStack_50 = 0;
          uStack_4c = 0x3f800000;
          uStack_48 = 0;
          uStack_44 = 0;
          uStack_28 = *(undefined4 *)(iStack_38 + 0x440);
          puStack_24 = *(undefined **)(iStack_38 + 0x444);
          uStack_f4 = (double)CONCAT44(uStack_f4._4_4_,&uStack_28);
          puStack_f8 = auStack_b0;
          uStack_8._0_1_ = 7;
          uStack_fc = 0xb28efa;
          uVar5 = FUN_0063fc10();
          uStack_f4 = 1.27450479006442e-313;
          uStack_8._0_1_ = 8;
          uStack_70 = 0;
          uStack_6c = 0xf;
          auStack_80[0] = 0;
          puStack_f8 = (undefined *)0xb28f24;
          FUN_005542c0();
          uStack_f4._0_4_ = auStack_80;
          uStack_8._0_1_ = 9;
          puStack_f8 = (undefined *)0xb28f35;
          uStack_f4._4_4_ = uVar5;
          FUN_005d15d0();
          uStack_f4 = (double)CONCAT44(uStack_f4._4_4_,0xb28f3d);
          FUN_005511f0();
          uStack_f4 = (double)CONCAT44(0xb28f45,(undefined *)uStack_f4);
          FUN_005507b0();
          uStack_8._0_1_ = 7;
          uStack_f4 = (double)CONCAT44(0xb28f54,(undefined *)uStack_f4);
          FUN_005507b0();
          uStack_f4 = (double)CONCAT44(&param_7,auStack_c8);
          puStack_f8 = (undefined *)0xb28f64;
          uVar5 = FUN_0063fc10();
          uStack_f4 = 6.37883424173009e-314;
          uStack_8._0_1_ = 10;
          uStack_88 = 0;
          uStack_84 = 0xf;
          auStack_98[0] = 0;
          puStack_f8 = (undefined *)0xb28f97;
          FUN_005542c0();
          uStack_f4._0_4_ = auStack_98;
          uStack_8._0_1_ = 0xb;
          puStack_f8 = (undefined *)0xb28fab;
          uStack_f4._4_4_ = uVar5;
          FUN_005d15d0();
          uStack_f4 = (double)CONCAT44(uStack_f4._4_4_,0xb28fb3);
          FUN_005511f0();
          uStack_f4 = (double)CONCAT44(0xb28fbe,(undefined *)uStack_f4);
          FUN_005507b0();
          uStack_8._0_1_ = 7;
          uStack_f4 = (double)CONCAT44(0xb28fcd,(undefined *)uStack_f4);
          FUN_005507b0();
          puStack_24 = (undefined *)aiStack_104;
          puStack_108 = auStack_58;
          if (param_10 == &DAT_00000004) {
            uStack_10c = 0xb28feb;
            puStack_24 = (undefined *)aiStack_104;
            puStack_1c = (undefined *)aiStack_104;
            FUN_0060e660();
            puStack_24 = (undefined *)&puStack_11c;
            uStack_8._0_1_ = 0xc;
            uStack_10c = 0;
            puStack_108 = (undefined *)0xf;
            puStack_11c = (undefined *)((uint)puStack_11c & 0xffffff00);
            FUN_005542c0("PremiumUpsellCompletedVerified",0x1e);
            uStack_8._0_1_ = 0xd;
            in_stack_fffffecc = in_stack_fffffecc & 0xffffff00;
            FUN_005542c0("InGamePrompt",0xc);
            uStack_8._0_1_ = 7;
            FUN_0087a3e0(iStack_40,in_stack_fffffecc);
            FUN_014c9d60(&iStack_30,0);
            puStack_f8 = auStack_e0;
            uStack_f4 = (double)CONCAT44(param_8,param_7);
            uStack_8._0_1_ = 0xe;
            uStack_fc = 0xb2906b;
            puVar6 = (undefined4 *)FUN_00f56310();
            puVar2 = puVar6 + 4;
            uStack_8._0_1_ = 0xf;
            if (0xf < (uint)puVar6[5]) {
              puVar6 = (undefined4 *)*puVar6;
            }
            uStack_f4 = (double)CONCAT44(*puVar2,puVar6);
            puStack_f8 = (undefined *)0xb2908b;
            FUN_014cbbc0();
            uStack_8._0_1_ = 0xe;
            uStack_f4 = (double)CONCAT44(0xb2909a,(undefined *)uStack_f4);
            FUN_005507b0();
            *(undefined4 *)(iStack_30 + 0xb0) = 0;
            uStack_f4 = 1.28152525854628e-316;
            puStack_f8 = (undefined *)0xb290c1;
            FUN_014cb7a0();
            uStack_f4 = (double)CONCAT44(0xb290c9,(undefined *)uStack_f4);
            FUN_014cba60();
            uStack_f4 = (double)CONCAT44(auStack_68,0xb290d5);
            FUN_014cb340();
            uStack_8._0_1_ = 0x10;
            if (piStack_64 != (int *)0x0) {
              LOCK();
              iVar3 = piStack_64[1] + -1;
              piStack_64[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                uStack_f4 = (double)CONCAT44(0xb290f0,(undefined *)uStack_f4);
                (**(code **)(*piStack_64 + 4))();
                LOCK();
                iVar3 = piStack_64[2] + -1;
                piStack_64[2] = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  uStack_f4 = (double)CONCAT44(0xb29100,(undefined *)uStack_f4);
                  (**(code **)(*piStack_64 + 8))();
                }
              }
            }
            if (piStack_2c != (int *)0x0) {
              LOCK();
              iVar3 = piStack_2c[1] + -1;
              piStack_2c[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                uStack_f4 = (double)CONCAT44(0xb2911a,(undefined *)uStack_f4);
                (**(code **)*piStack_2c)();
                LOCK();
                iVar3 = piStack_2c[2] + -1;
                piStack_2c[2] = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  uStack_f4 = (double)CONCAT44(0xb2912a,(undefined *)uStack_f4);
                  (**(code **)(*piStack_2c + 4))();
                }
              }
            }
          }
          else {
            uStack_10c = 0xb29135;
            piStack_14 = aiStack_104;
            FUN_0060e660();
            puStack_24 = (undefined *)&puStack_11c;
            uStack_8._0_1_ = 0x11;
            uStack_10c = 0;
            puStack_108 = (undefined *)0xf;
            puStack_11c = (undefined *)((uint)puStack_11c & 0xffffff00);
            FUN_005542c0("PremiumUpsellCompletedNotVerified",0x21);
            uStack_8._0_1_ = 0x12;
            in_stack_fffffecc = in_stack_fffffecc & 0xffffff00;
            FUN_005542c0("InGamePrompt",0xc);
            uStack_8._0_1_ = 7;
            FUN_0087a3e0(iStack_40,in_stack_fffffecc);
          }
          uStack_f4 = (double)CONCAT44(0xb29199,(undefined *)uStack_f4);
          FUN_0056cfd0();
        }
        uStack_f4 = (double)CONCAT44(&param_7,0xb291a5);
        FUN_00b22bd0();
        uStack_8._0_1_ = 4;
        uStack_f4 = (double)CONCAT44(0xb291b1,(undefined *)uStack_f4);
        FUN_005923a0();
        uStack_f4 = (double)CONCAT44(1,(undefined *)uStack_f4);
        if (param_2 != (int *)0x0) {
          LOCK();
          param_2[2] = param_2[2] + 1;
          UNLOCK();
          LOCK();
          param_2[2] = param_2[2] + 1;
          UNLOCK();
        }
        uStack_110 = 0;
        piVar1 = param_2 + 2;
        if (param_2 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        puStack_11c = param_8;
        puStack_118 = param_10;
        FUN_00b12530(param_1,param_2,param_7);
        if (param_2 != (int *)0x0) {
          LOCK();
          iVar3 = *piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            uStack_114 = 0xb29222;
            (**(code **)(*param_2 + 4))();
          }
          LOCK();
          iVar3 = *piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            uStack_114 = 0xb29231;
            (**(code **)(*param_2 + 4))();
          }
        }
        uStack_114 = 0xb29239;
        iVar3 = FUN_0090ca30();
      }
    }
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_34 + 1;
      iVar4 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        uStack_f4 = (double)CONCAT44(0xb2924f,(undefined *)uStack_f4);
        (**(code **)*piStack_34)();
        LOCK();
        piVar1 = piStack_34 + 2;
        iVar4 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          uStack_f4 = (double)CONCAT44(0xb2925f,(undefined *)uStack_f4);
          iVar3 = (**(code **)(*piStack_34 + 4))();
        }
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_3c + 1;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      uStack_f4 = (double)CONCAT44(0xb29275,(undefined *)uStack_f4);
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar4 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        uStack_f4 = (double)CONCAT44(0xb29285,(undefined *)uStack_f4);
        iVar3 = (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      uStack_f4 = (double)CONCAT44(0xb2929a,(undefined *)uStack_f4);
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      uStack_f4 = (double)CONCAT44(0xb292af,(undefined *)uStack_f4);
      iVar3 = (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      uStack_f4 = (double)CONCAT44(0xb292c3,(undefined *)uStack_f4);
      iVar3 = (**(code **)(*param_6 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23654 ; VA 0x00b292e0 ; FUN_00b292e0 */

uint FUN_00b292e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b12040();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 23655 ; VA 0x00b29300 ; FUN_00b29300 */

uint FUN_00b29300(void)

{
  int iVar1;
  
  iVar1 = FUN_00b12040();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 23656 ; VA 0x00b29320 ; FUN_00b29320 */

/* WARNING: Removing unreachable block (ram,0x00b29388) */

undefined4 FUN_00b29320(int *param_1,int *param_2,undefined4 *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  char *pcVar8;
  char *pcVar9;
  longlong lVar10;
  undefined auStack_34 [24];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0ac0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if ((param_1 == (int *)0x0) ||
     (iVar2 = param_1[3], ExceptionList = &pvStack_10, iVar6 = FUN_00913630(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    FUN_01675640(auStack_34,"MarketplaceService:%s",param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00554150(" player should be of type Player, but is of type ",0x31);
    if (param_1 == (int *)0x0) {
      pcVar8 = "nil";
    }
    else {
      pcVar8 = (char *)(**(code **)(*param_1 + 0x10))();
      if (0xf < *(uint *)(pcVar8 + 0x14)) {
        pcVar8 = *(char **)pcVar8;
      }
    }
    pcVar9 = pcVar8;
    do {
      cVar5 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar5 != '\0');
    FUN_00554150(pcVar8,(int)pcVar9 - (int)(pcVar8 + 1));
    if (param_4 == 0) {
      FUN_005500e0(auStack_34);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    FUN_0054ef60(auStack_34);
    FUN_005e65e0();
    FUN_005507b0();
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar2 = param_2[1] + -1;
      param_2[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_2)();
        LOCK();
        piVar1 = param_2 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    uStack_8 = 4;
    if (((param_4 != 0) && ((param_4 & 1) == 0)) &&
       (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000018,&stack0x00000018,2);
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  lVar10 = FUN_00928340();
  if (lVar10 < 1) {
    uVar3 = param_3[5];
    uVar4 = param_3[4];
    puVar7 = param_3;
    if (0xf < uVar3) {
      puVar7 = (undefined4 *)*param_3;
    }
    cVar5 = FUN_0055c360(puVar7,uVar4,"PromptPurchase()",0x10);
    if (cVar5 == '\0') {
      puVar7 = param_3;
      if (0xf < uVar3) {
        puVar7 = (undefined4 *)*param_3;
      }
      cVar5 = FUN_0055c360(puVar7,uVar4,"PromptProductPurchase()",0x17);
      if (cVar5 == '\0') {
        puVar7 = param_3;
        if (0xf < uVar3) {
          puVar7 = (undefined4 *)*param_3;
        }
        cVar5 = FUN_0055c360(puVar7,uVar4,"PromptGamePassPurchase()",0x18);
        if (cVar5 == '\0') {
          if (0xf < uVar3) {
            param_3 = (undefined4 *)*param_3;
          }
          FUN_01675640(auStack_34,"MarketplaceService:%s",param_3);
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          FUN_00554150(" was called on a guest, please use this call only on players with an account."
                       ,0x4d);
          FUN_0086ed30(2,auStack_34,6);
          FUN_005507b0();
          FUN_00550b30();
          FUN_00550990();
          ExceptionList = pvStack_10;
          return 0;
        }
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&stack0x00000018,&stack0x00000018,2);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 23657 ; VA 0x00b295d0 ; FUN_00b295d0 */

undefined __thiscall FUN_00b295d0(int *param_1,uint param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_00000044;
  uint in_stack_00000048;
  uint in_stack_0000004c;
  int *in_stack_00000050;
  uint in_stack_00000054;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000060;
  code *in_stack_00000064;
  undefined4 in_stack_00000068;
  ulonglong in_stack_0000006c;
  undefined4 uVar10;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  int *piStack_140;
  uint auStack_7c [2];
  undefined auStack_74 [24];
  undefined auStack_5c [4];
  uint auStack_58 [2];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  code *pcStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined *puStack_38;
  uint uStack_34;
  undefined4 *puStack_30;
  int iStack_2c;
  undefined auStack_28 [4];
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0b7b;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  uStack_34 = in_stack_0000004c;
  ExceptionList = &pvStack_10;
  if (in_stack_0000004c != 0) {
    iVar6 = *(int *)(in_stack_0000004c + 0xc);
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00913630();
    if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      iVar6 = FUN_0064e810(param_1);
      if ((iVar6 != 0) && (*(int *)(uStack_34 + 0x34) == iVar6)) {
        cVar4 = FUN_00973950(param_1,1);
        if (cVar4 == '\0') {
          iVar5 = (int)param_1 + *(byte *)(param_1 + 0x17) + 0x5d;
          FUN_00606ea0(&puStack_20,(in_stack_0000004c >> 3) + in_stack_0000004c,&stack0x0000004c,
                       -(uint)(iVar5 != 0) & iVar5 + 1U);
          if (puStack_20 == (undefined4 *)0x0) {
            cVar4 = FUN_016793f0();
            piVar7 = piStack_18;
            if (cVar4 == '\0') {
              iStack_2c = iVar6 + 0x2a8;
              piStack_18 = (int *)((uint)piStack_18 & 0xffffff00);
              pcStack_48 = FUN_00b236d0;
              uStack_44 = 0;
              uStack_40 = CONCAT44(piVar7,param_1) & 0xffffff00ffffffff;
              uStack_8._0_1_ = 5;
              piVar7 = (int *)FUN_01675290(DAT_02110da8);
              uStack_8._0_1_ = 6;
              piStack_18 = piVar7;
              puStack_30 = (undefined4 *)FUN_01674e20(0x28);
              if (puStack_30 == (undefined4 *)0x0) {
                puStack_30 = (undefined4 *)0x0;
              }
              else {
                *puStack_30 = 0;
                puStack_30[1] = 1;
                puStack_30[2] = FUN_00b22aa0;
                puStack_30[3] = _guard_check_icall;
                puStack_30[4] = 0;
                puStack_30[5] = iStack_2c;
                puStack_30[6] = pcStack_48;
                puStack_30[7] = uStack_44;
                puStack_30[8] = (undefined4)uStack_40;
                puStack_30[9] = uStack_40._4_4_;
              }
              FUN_016797d0(puStack_30);
              puStack_20 = puStack_30;
              if (puStack_30 != (undefined4 *)0x0) {
                LOCK();
                puStack_30[1] = puStack_30[1] + 1;
                UNLOCK();
              }
              uStack_24 = 1;
              uStack_8._0_1_ = 7;
              FUN_01675290(piVar7);
              uStack_8._0_1_ = 5;
              FUN_00614020(&puStack_20);
              uStack_8._0_1_ = 4;
              FUN_0056e750();
            }
            iVar6 = FUN_00b1a530(&stack0x0000004c);
            auStack_58[0] = 0;
            if (in_stack_00000054 != 0) {
              auStack_58[0] = in_stack_00000054;
              if ((in_stack_00000054 & 1) == 0) {
                (**(code **)(in_stack_00000054 & 0xfffffffe))(&stack0x0000005c,&uStack_50,0);
              }
              else {
                uStack_50 = in_stack_0000005c;
                uStack_4c = in_stack_00000060;
                pcStack_48 = in_stack_00000064;
                uStack_44 = in_stack_00000068;
                uStack_40 = in_stack_0000006c;
              }
            }
            if ((uint *)(iVar6 + 8) != auStack_58) {
              auStack_7c[0] = 0;
              uStack_8._0_1_ = 9;
              FUN_005880d0(auStack_58);
              FUN_005880d0((uint *)(iVar6 + 8));
              FUN_005880d0(auStack_7c);
              uStack_8._0_1_ = 10;
              if (((auStack_7c[0] != 0) && ((auStack_7c[0] & 1) == 0)) &&
                 (*(code **)(auStack_7c[0] & 0xfffffffe) != (code *)0x0)) {
                (**(code **)(auStack_7c[0] & 0xfffffffe))(auStack_74,auStack_74,2);
              }
            }
            uStack_8._0_1_ = 0xb;
            if (((auStack_58[0] != 0) && ((auStack_58[0] & 1) == 0)) &&
               (*(code **)(auStack_58[0] & 0xfffffffe) != (code *)0x0)) {
              (**(code **)(auStack_58[0] & 0xfffffffe))(&uStack_50,&uStack_50,2);
            }
            uStack_8._0_1_ = 4;
            FUN_00927d30(auStack_5c);
            piStack_18 = (int *)FUN_01674e20(0xc);
            if (piStack_18 == (int *)0x0) {
              piVar7 = (int *)0x0;
            }
            else {
              *piStack_18 = 0;
              piStack_18[1] = 0;
              piStack_18[2] = 0;
              piVar7 = piStack_18;
            }
            FUN_00557ff0(piVar7);
            uStack_8._0_1_ = 0xc;
            FUN_005c13e0(&param_2);
            uStack_8._0_1_ = 0xd;
            FUN_005cd7a0(&uStack_14c);
            uStack_8._0_1_ = 0xc;
            FUN_0056e5b0();
            FUN_005c13e0(&stack0x0000001c);
            uStack_8._0_1_ = 0xe;
            FUN_005cd7a0(&uStack_14c);
            uStack_8._0_1_ = 0xc;
            FUN_0056e5b0();
            FUN_005c13e0(&stack0x00000034);
            uStack_8._0_1_ = 0xf;
            FUN_005cd7a0(&uStack_14c);
            uStack_8._0_1_ = 0xc;
            FUN_0056e5b0();
            uVar10 = 1;
            piVar7 = param_1;
            cVar4 = FUN_0098c5a0(param_1,1);
            if (cVar4 == '\0') {
              FUN_00557fc0(auStack_28);
              FUN_00b252d0(param_1,piVar7,uVar10);
            }
            else {
              puStack_38 = auStack_5c;
              uStack_34 = 0;
              FUN_00557fc0(auStack_28);
              uStack_8._0_1_ = 0x10;
              pcVar2 = *(code **)(*param_1 + 8);
              uStack_14c = FUN_0088cbe0();
              uStack_144 = uStack_1c;
              uStack_148 = 0;
              piStack_140 = piStack_18;
              uStack_1c = 0;
              piStack_18 = (int *)0x0;
              uStack_148 = FUN_00630900();
              uStack_8._0_1_ = 0x11;
              uStack_44 = 0;
              uStack_40 = 0;
              FUN_00687980(&uStack_14c,auStack_7c,in_stack_00000050);
              uStack_8._0_1_ = 0x12;
              (*pcVar2)(&DAT_0212b208,&uStack_44,&puStack_38);
              uStack_8._0_1_ = 0x13;
              FUN_00577b20();
              uStack_8._0_1_ = 0x10;
              FUN_016f32d1(&uStack_14c,0xd0,1,FUN_0056e5b0);
              piVar7 = piStack_18;
              if (piStack_18 != (int *)0x0) {
                LOCK();
                iVar6 = piStack_18[1] + -1;
                piStack_18[1] = iVar6;
                UNLOCK();
                if (iVar6 == 0) {
                  (**(code **)*piStack_18)();
                  LOCK();
                  piVar1 = piVar7 + 2;
                  iVar6 = *piVar1 + -1;
                  *piVar1 = iVar6;
                  UNLOCK();
                  if (iVar6 == 0) {
                    (**(code **)(*piVar7 + 4))();
                    FUN_00550b30();
                    uStack_11 = 1;
                    goto LAB_00b29a5e;
                  }
                }
              }
            }
            FUN_00550b30();
            uStack_11 = 1;
            goto LAB_00b29a5e;
          }
        }
      }
    }
  }
  uStack_11 = 0;
LAB_00b29a5e:
  uStack_8._0_1_ = 3;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < in_stack_00000018) {
    uVar9 = in_stack_00000018 + 1;
    uVar8 = param_2;
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(param_2 - 4);
      uVar9 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8._0_1_ = 2;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000030) {
    uVar9 = in_stack_00000030 + 1;
    uVar8 = in_stack_0000001c;
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(in_stack_0000001c - 4);
      uVar9 = in_stack_00000030 + 0x24;
      if (0x1f < (in_stack_0000001c - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < in_stack_00000048) {
    uVar9 = in_stack_00000048 + 1;
    uVar8 = in_stack_00000034;
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(in_stack_00000034 - 4);
      uVar9 = in_stack_00000048 + 0x24;
      if (0x1f < (in_stack_00000034 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  piVar7 = in_stack_00000050;
  in_stack_00000044 = 0;
  in_stack_00000048 = 0xf;
  in_stack_00000034 = in_stack_00000034 & 0xffffff00;
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    iVar6 = in_stack_00000050[1] + -1;
    in_stack_00000050[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*in_stack_00000050)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  uStack_8 = 0x14;
  if (((in_stack_00000054 != 0) && ((in_stack_00000054 & 1) == 0)) &&
     (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000054 & 0xfffffffe))(&stack0x0000005c,&stack0x0000005c,2);
  }
  ExceptionList = pvStack_10;
  return uStack_11;
}



/* FUNCTION 23658 ; VA 0x00b29bb0 ; FUN_00b29bb0 */

void FUN_00b29bb0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b317b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23659 ; VA 0x00b29bf0 ; FUN_00b29bf0 */

void FUN_00b29bf0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b31840();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23660 ; VA 0x00b29c30 ; FUN_00b29c30 */

void FUN_00b29c30(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b318f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23661 ; VA 0x00b29c70 ; FUN_00b29c70 */

void FUN_00b29c70(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b319a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23662 ; VA 0x00b29cb0 ; FUN_00b29cb0 */

int * FUN_00b29cb0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b29d6d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b29cee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1ddd82c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_28082e19ebc314128252b077ece8ca88>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 23663 ; VA 0x00b29d90 ; FUN_00b29d90 */

void FUN_00b29d90(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      iVar3 = FUN_01674e20(0x28);
      if (iVar3 != 0) {
        iVar4 = FUN_00b157d0(iVar4);
        *param_2 = iVar4;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        piVar2 = *(int **)(iVar4 + 0x20);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        piVar2 = *(int **)(iVar4 + 0x18);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        piVar2 = *(int **)(iVar4 + 0x10);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_01674ea0(iVar4,0x28);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1ddd864);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&<lambda_6e049b8240578d4f22b444e7154a222e>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 23664 ; VA 0x00b29ea0 ; FUN_00b29ea0 */

void FUN_00b29ea0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      ExceptionList = &pvStack_10;
      *param_2 = *param_1;
      FUN_006d07c0(param_1 + 1);
      param_2[4] = param_1[4];
      *(undefined *)(param_2 + 5) = *(undefined *)(param_1 + 5);
      if (param_3 != 1) {
        ExceptionList = pvStack_10;
        return;
      }
      uStack_8 = 0;
      FUN_00577b20();
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 2) {
      uStack_8 = 1;
      ExceptionList = &pvStack_10;
      FUN_00577b20();
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1ddfa9c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_RBX::DataModel*,class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>,class_RBX::SystemAddress,bool),class_boost::_bi::list4<struct_boost::arg<1>,class_boost::_bi::value<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>,class_boost::_bi::value<class_RBX::SystemAddress>,class_boost::_bi::value<bool>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23665 ; VA 0x00b29fa0 ; FUN_00b29fa0 */

int * FUN_00b29fa0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b2a082. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b29ff6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1de009c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>)>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list4<class_boost::_bi::value<class_std::shared_ptr<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>)>_>_>,struct_boost::arg<1>,struct_boost::arg<2>,struct_boost::arg<3>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 23666 ; VA 0x00b2a0a0 ; FUN_00b2a0a0 */

void FUN_00b2a0a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796bdf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x2c);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00b16210(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_006511a0();
        FUN_01674ea0(iVar2,0x2c);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dde594);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::MarketplaceService>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,int,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_boost::_bi::list5<class_boost::_bi::value<class_std::shared_ptr<class_RBX::MarketplaceService>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<int>,class_boost::_bi::value<int>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23667 ; VA 0x00b2a1f0 ; FUN_00b2a1f0 */

void FUN_00b2a1f0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x20);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_00b162a0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        FUN_00577b20();
        piVar1 = *(int **)(iVar3 + 8);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1ddfddc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>,class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>,class_RBX::SystemAddress,bool,bool),class_boost::_bi::list5<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>,class_boost::_bi::value<class_RBX::SystemAddress>,class_boost::_bi::value<bool>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23668 ; VA 0x00b2a360 ; FUN_00b2a360 */

void FUN_00b2a360(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x20);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_00b162a0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        FUN_00577b20();
        piVar1 = *(int **)(iVar3 + 8);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1ddfbfc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>,class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>,class_RBX::SystemAddress,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list5<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>,class_boost::_bi::value<class_RBX::SystemAddress>,class_boost::_bi::value<bool>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23669 ; VA 0x00b2a4d0 ; FUN_00b2a4d0 */

void FUN_00b2a4d0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e522f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x60);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        FUN_00b17130(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x30);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x38,iVar4 + 0x38,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x30) = 0;
        }
        FUN_00a7c840();
        FUN_01674ea0(iVar4,0x60);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dddbd4);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::MarketplaceService>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>*,class_std::exception*,class_boost::function<void___cdecl(bool)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,__int64,__int64),class_boost::_bi::list7<class_boost::_bi::value<class_std::shared_ptr<class_RBX::MarketplaceService>_>,struct_boost::arg<1>,struct_boost::arg<2>,class_boost::_bi::value<class_boost::function<void___cdecl(bool)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::value<__int64>,class_boost::_bi::value<__int64>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23670 ; VA 0x00b2a660 ; FUN_00b2a660 */

void FUN_00b2a660(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4a6f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x24);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00b16330(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar2,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dde454);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::MarketplaceService>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list3<class_boost::_bi::value<class_std::weak_ptr<class_RBX::MarketplaceService>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23671 ; VA 0x00b2a7b0 ; FUN_00b2a7b0 */

int * FUN_00b2a7b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b2a862. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b2a7ee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1ddeb1c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::MarketplaceService>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list2<class_boost::_bi::value<class_std::weak_ptr<class_RBX::MarketplaceService>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 23672 ; VA 0x00b2a880 ; FUN_00b2a880 */

int * FUN_00b2a880(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      piVar3 = (int *)FUN_00ae36d0(param_1);
      if (param_3 == 1) {
        piVar2 = *(int **)(param_1 + 0x10);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 1;
          iVar4 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar4 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar4 + -1;
            UNLOCK();
            if (iVar4 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = *(int **)(param_1 + 8);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00b2a925. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar2 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_00ae3c40(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar3 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dde71c);
      iVar4 = 0;
      if (piVar3 == (int *)0x0) {
        iVar4 = param_1;
      }
      *param_2 = iVar4;
      return piVar3;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::MarketplaceService>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_boost::_bi::list2<class_boost::_bi::value<class_std::weak_ptr<class_RBX::MarketplaceService>_>,class_boost::_bi::value<class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 23673 ; VA 0x00b2a940 ; FUN_00b2a940 */

void FUN_00b2a940(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x48);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_00b16ef0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00b19bf0();
        FUN_01674ea0(iVar3,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1ddddfc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::MarketplaceService>,class_std::shared_ptr<class_RBX::Instance>,__int64,bool,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<cha...traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23674 ; VA 0x00b2aa90 ; FUN_00b2aa90 */

void FUN_00b2aa90(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      puVar5 = (undefined4 *)FUN_01674e20(0x30);
      if (puVar5 != (undefined4 *)0x0) {
        *puVar5 = *puVar2;
        FUN_00b17f60(puVar2 + 2);
        puVar5[10] = puVar2[10];
        *param_2 = (int)puVar5;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        piVar3 = *(int **)(iVar6 + 0x1c);
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        piVar3 = *(int **)(iVar6 + 0x14);
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        piVar3 = *(int **)(iVar6 + 0xc);
        if (piVar3 != (int *)0x0) {
          LOCK();
          piVar1 = piVar3 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        FUN_01674ea0(iVar6,0x30);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1ddda44);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::MarketplaceService>,class_std::weak_ptr<class_RBX::DataModel>,class_std::weak_ptr<class_RBX::TimerService>,__int64,int,enum_RBX::MembershipType),class_boost::_bi::list6<class_boost::_bi::value<class_std::weak_ptr<class_RBX::MarketplaceService>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::TimerService>_>,class_boost::_bi::value<__int64>,class_boost::_bi::value<int>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 23675 ; VA 0x00b2abb0 ; FUN_00b2abb0 */

void FUN_00b2abb0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      puVar5 = (undefined4 *)FUN_01674e20(0x28);
      if (puVar5 != (undefined4 *)0x0) {
        *puVar5 = *puVar2;
        FUN_00b17f60(puVar2 + 2);
        *param_2 = (int)puVar5;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        piVar3 = *(int **)(iVar6 + 0x1c);
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        piVar3 = *(int **)(iVar6 + 0x14);
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        piVar3 = *(int **)(iVar6 + 0xc);
        if (piVar3 != (int *)0x0) {
          LOCK();
          piVar1 = piVar3 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        FUN_01674ea0(iVar6,0x28);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1ddd89c);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::MarketplaceService>,class_std::weak_ptr<class_RBX::DataModel>,class_std::weak_ptr<class_RBX::TimerService>,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list5<class_boost::_bi::value<class_std::weak_ptr<class_RBX::MarketplaceService>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::TimerService>_>,class_boost::_bi::value<__int64>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 23676 ; VA 0x00b2acd0 ; FUN_00b2acd0 */

void FUN_00b2acd0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1ddff7c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_RBX::Reflection::Variant,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list3<struct_boost::arg<1>,struct_boost::arg<2>,struct_boost::arg<3>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 23677 ; VA 0x00b2ad40 ; FUN_00b2ad40 */

void FUN_00b2ad40(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1ddec14);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::MarketplaceService,__int64>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::MarketplaceService*>,class_boost::_bi::value<__int64>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 23678 ; VA 0x00b2adb0 ; FUN_00b2adb0 */

void FUN_00b2adb0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00b16560(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096ca80();
        FUN_01674ea0(iVar3,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1ddf56c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::MarketplaceService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::MarketplaceService*>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23679 ; VA 0x00b2af10 ; FUN_00b2af10 */

void FUN_00b2af10(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcd9f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar5 = (undefined4 *)FUN_01674e20(0x38);
      uStack_8 = 0;
      if (puVar5 != (undefined4 *)0x0) {
        *puVar5 = *puVar1;
        puVar5[1] = puVar1[1];
        FUN_00b16760(puVar1 + 2);
        *param_2 = (int)puVar5;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        uVar2 = *(uint *)(iVar6 + 0x18);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar6 + 0x20,iVar6 + 0x20,2);
            }
          }
          *(undefined4 *)(iVar6 + 0x18) = 0;
        }
        piVar3 = *(int **)(iVar6 + 0x10);
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        FUN_01674ea0(iVar6,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1ddf37c);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::MarketplaceService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::weak_ptr<class_RBX::DataModel>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::MarketplaceService*>,struct_boost::arg<1>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23680 ; VA 0x00b2b0a0 ; FUN_00b2b0a0 */

void FUN_00b2b0a0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      puVar5 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar5 != (undefined4 *)0x0) {
        uVar2 = puVar1[1];
        uVar3 = puVar1[2];
        uVar4 = puVar1[3];
        *puVar5 = *puVar1;
        puVar5[1] = uVar2;
        puVar5[2] = uVar3;
        puVar5[3] = uVar4;
        uVar2 = puVar1[5];
        uVar3 = puVar1[6];
        uVar4 = puVar1[7];
        puVar5[4] = puVar1[4];
        puVar5[5] = uVar2;
        puVar5[6] = uVar3;
        puVar5[7] = uVar4;
        *param_2 = (int)puVar5;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      FUN_01674ea0(*param_2,0x20);
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1ddecbc);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::MarketplaceService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::MarketplaceService*>,struct_boost::arg<1>,class_boost::_bi::value<__int64>,class_boost::_bi::value<__int64>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 23681 ; VA 0x00b2b160 ; FUN_00b2b160 */

void FUN_00b2b160(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffef;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x70);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00b16c00(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00b19b60();
        FUN_01674ea0(iVar3,0x70);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1ddedb4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf5<void,class_RBX::MarketplaceService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::weak_ptr<class_RBX::DataModel>,class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class...decl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23682 ; VA 0x00b2b2c0 ; FUN_00b2b2c0 */

int FUN_00b2b2c0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined *puStack_f8;
  int iStack_f4;
  undefined *puStack_f0;
  code *pcStack_ec;
  undefined auStack_e8 [8];
  undefined8 uStack_e0;
  undefined4 uStack_d8;
  undefined *puStack_d4;
  code *pcStack_d0;
  undefined *puStack_cc;
  int iStack_c8;
  undefined *puStack_c4;
  code *pcStack_c0;
  undefined auStack_bc [8];
  undefined8 uStack_b4;
  uint uStack_ac;
  int iStack_a8;
  undefined4 uStack_a4;
  int iStack_a0;
  undefined4 uStack_80;
  undefined auStack_7c [12];
  undefined4 uStack_70;
  int **ppiStack_6c;
  uint uStack_68;
  undefined8 *puStack_64;
  code *pcStack_60;
  undefined auStack_50 [8];
  undefined8 uStack_48;
  undefined *puStack_3c;
  undefined4 uStack_38;
  undefined *puStack_34;
  undefined *puStack_30;
  undefined *puStack_2c;
  code *pcStack_28;
  int *piStack_24;
  int iStack_20;
  code *pcStack_1c;
  int iStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f0bd0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  puStack_64 = (undefined8 *)0xb2b2f0;
  ExceptionList = &pvStack_10;
  iStack_18 = FUN_008f7870();
  iVar3 = iStack_18;
  uStack_48 = CONCAT44(uStack_48._4_4_,(int)uStack_48);
  uStack_e0 = CONCAT44(uStack_e0._4_4_,(undefined4)uStack_e0);
  uStack_b4 = CONCAT44(uStack_b4._4_4_,(undefined4)uStack_b4);
  if (((iStack_18 != 0) &&
      (uStack_48 = CONCAT44(uStack_48._4_4_,(int)uStack_48),
      uStack_e0 = CONCAT44(uStack_e0._4_4_,(undefined4)uStack_e0),
      uStack_b4 = CONCAT44(uStack_b4._4_4_,(undefined4)uStack_b4), *(int *)(iStack_18 + 0x4a0) == 2)
      ) && (iVar3 = *(int *)(param_1 + 0x450), iStack_20 = iVar3,
           uStack_48 = CONCAT44(uStack_48._4_4_,(int)uStack_48),
           uStack_e0 = CONCAT44(uStack_e0._4_4_,(undefined4)uStack_e0),
           uStack_b4 = CONCAT44(uStack_b4._4_4_,(undefined4)uStack_b4), iVar3 != 4)) {
    pcStack_60 = (code *)0xb2b328;
    lVar6 = FUN_00928340();
    iVar3 = (int)lVar6;
    pcStack_60 = pcStack_14 + 0xf8;
    puStack_64 = (undefined8 *)0xb2b344;
    uStack_48 = lVar6;
    FUN_00591e70();
    pcStack_1c = pcStack_14 + 0x108;
    uStack_8 = 1;
    pcStack_60 = (code *)(-(uint)(pcStack_14 + (byte)*pcStack_1c + 0x109 != (code *)0x0) &
                         (uint)(pcStack_14 + (byte)*pcStack_1c + 0x109 + 1));
    if ((lVar6 < 0x100000000) && (lVar6 < 0)) {
      lVar6 = CONCAT44(-1 - uStack_48._4_4_,-1 - iVar3);
    }
    uStack_68 = (uint)((ulonglong)lVar6 >> 0x20);
    uStack_38 = (undefined4)lVar6;
    puStack_64 = &uStack_48;
    uStack_68 = (uStack_68 >> 2) + uStack_68 * 0x40 + iVar3 ^ uStack_68;
    ppiStack_6c = &piStack_24;
    uStack_70 = 0xb2b3a4;
    FUN_00606ff0();
    if (piStack_24 == (int *)0x0) {
      pcStack_60 = (code *)&uStack_48;
      puStack_64 = (undefined8 *)0xb2b3c2;
      iVar3 = FUN_00b1ab60();
      uStack_8 = 0;
      *(int *)(iVar3 + 8) = iStack_20;
      pcStack_60 = (code *)0xb2b3d4;
      FUN_005923a0();
      pcStack_60 = (code *)0xb2b3df;
      pcStack_1c = (code *)FUN_005cf2a0();
      pcStack_60 = (code *)auStack_50;
      puStack_64 = (undefined8 *)0xb2b3ee;
      puVar4 = (undefined4 *)FUN_00b264d0();
      piStack_24 = (int *)*puVar4;
      puStack_2c = auStack_7c;
      uVar5 = CONCAT31(0xffffff,DAT_01eee1b9);
      uStack_80 = 0;
      uStack_8 = 2;
      pcStack_28 = *(code **)(*piStack_24 + 0x28);
      uStack_ac = (uint)DAT_01eee1b9;
      puStack_30 = auStack_bc;
      puStack_c4 = auStack_bc;
      pcStack_c0 = pcStack_1c;
      iStack_c8 = 0xb2b42f;
      uStack_b4 = uStack_48;
      FUN_0060e0c0();
      iStack_c8 = iStack_18;
      uStack_8 = 3;
      pcStack_d0 = (code *)0xb2b441;
      puStack_cc = (undefined *)&puStack_c4;
      puStack_34 = (undefined *)&puStack_c4;
      FUN_005e5de0();
      uStack_8 = 4;
      pcStack_d0 = pcStack_14;
      uStack_d8 = 0xb2b450;
      puStack_d4 = (undefined *)&puStack_cc;
      FUN_0060e0c0();
      uStack_8 = 2;
      pcStack_d0 = FUN_00b28bb0;
      uStack_d8 = 0xb2b462;
      puStack_d4 = (undefined *)&iStack_a8;
      FUN_00b14500();
      uStack_ac = 0xb2b46c;
      FUN_00b115d0();
      iVar3 = (int)uStack_48;
      uStack_8 = 5;
      iStack_a0 = 0;
      uStack_d8 = 1;
      puStack_3c = auStack_e8;
      puStack_f0 = auStack_e8;
      pcStack_ec = pcStack_1c;
      iStack_f4 = 0xb2b497;
      puStack_d4 = (undefined *)uVar5;
      uStack_e0 = uStack_48;
      FUN_0060e0c0();
      iStack_f4 = iStack_18;
      uStack_8 = 6;
      puStack_f8 = (undefined *)&puStack_f0;
      puStack_34 = (undefined *)&puStack_f0;
      FUN_005e5de0();
      uStack_8 = 7;
      FUN_0060e0c0(&puStack_f8,pcStack_14);
      uStack_8 = 5;
      FUN_00b14350(&pcStack_d0,FUN_00b28ce0);
      puStack_d4 = (undefined *)0xb2b4d4;
      FUN_00b11460();
      iStack_a0 = iStack_20;
      uStack_a4 = uStack_48._4_4_;
      uStack_8 = 2;
      iStack_a8 = iVar3;
      uStack_ac = 0xb2b4e5;
      (*pcStack_28)();
      pcStack_60 = (code *)0xb2b4ed;
      iVar3 = FUN_00550b30();
    }
    else {
      pcStack_60 = (code *)0xb2b3b2;
      iVar3 = FUN_005923a0();
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pcStack_60 = (code *)0xb2b506;
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pcStack_60 = (code *)0xb2b515;
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23683 ; VA 0x00b2b530 ; FUN_00b2b530 */

void FUN_00b2b530(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int in_stack_00000014;
  uint in_stack_00000018;
  int *in_stack_00000020;
  uint in_stack_00000024;
  undefined auStack_3c [8];
  undefined4 uStack_34;
  undefined *puStack_30;
  undefined4 *puStack_2c;
  int *piStack_28;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0c00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_28 = &iStack_1c;
  puStack_2c = (undefined4 *)0xb2b560;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (iStack_1c != 0) {
    if (in_stack_00000014 == 0) {
      puStack_2c = (undefined4 *)0x0;
      piStack_28 = (int *)&DAT_0000000f;
      auStack_3c[0] = 0;
      FUN_005542c0("MarketplaceService:getProductInfo() failed but with no known error",0x42);
    }
    else {
      puVar3 = &param_1;
      if (0xf < in_stack_00000018) {
        puVar3 = param_1;
      }
      FUN_01675640(auStack_3c,"MarketplaceService:getProductInfo() failed because %s",puVar3);
    }
    FUN_005e65e0();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_28 = (int *)0xb2b5d4;
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_28 = (int *)0xb2b5e4;
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < in_stack_00000018) {
    piStack_28 = (int *)(in_stack_00000018 + 1);
    puVar3 = param_1;
    if (0xfff < piStack_28) {
      puVar3 = (undefined4 *)param_1[-1];
      piStack_28 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        piStack_28 = (int *)&UNK_00b2b67c;
        FUN_017167a3();
      }
    }
    puStack_30 = (undefined *)0xb2b615;
    puStack_2c = puVar3;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      piStack_28 = (int *)0xb2b63e;
      (**(code **)(*in_stack_00000020 + 4))();
    }
  }
  uStack_8 = 4;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &stack0x0000002c;
    piStack_28 = (int *)0x2;
    uStack_34 = 0xb2b662;
    puStack_2c = (undefined4 *)puStack_30;
    (**(code **)(in_stack_00000024 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23684 ; VA 0x00b2b680 ; FUN_00b2b680 */

void FUN_00b2b680(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  undefined8 *puVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 *in_stack_0000001c;
  int in_stack_0000002c;
  uint in_stack_00000030;
  int *in_stack_00000038;
  uint in_stack_0000003c;
  uint in_stack_0000005c;
  undefined4 *puStack_108;
  undefined4 *puStack_104;
  undefined4 uStack_100;
  undefined ***pppuStack_fc;
  undefined4 *puStack_f8;
  int *piStack_f4;
  undefined **appuStack_e8 [3];
  int iStack_dc;
  undefined **appuStack_d8 [16];
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined **ppuStack_80;
  int iStack_38;
  int *piStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  int iStack_24;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0c8a;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  piStack_f4 = &iStack_38;
  puStack_f8 = (undefined4 *)0xb2b6bc;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 5;
  if (iStack_38 != 0) {
    if (in_stack_0000002c == 0) {
      FUN_01675640(&puStack_108,
                   "MarketplaceService:getProductInfo() failed because rawProductInfo was empty");
      FUN_005e65e0();
    }
    else {
      uStack_18 = 0;
      piStack_14 = (int *)0x0;
      appuStack_e8[0] = &PTR_018bf148;
      appuStack_d8[0] = (undefined **)&DAT_018bf150;
      ppuStack_80 = std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
      piStack_f4 = (int *)0x0;
      puStack_f8 = (undefined4 *)0x0;
      pppuStack_fc = appuStack_d8 + 2;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      uStack_1c = 1;
      uStack_100 = 0xb2b73d;
      FUN_0054edc0();
      *(undefined ***)((int)appuStack_d8 + (int)appuStack_d8[0][1]) =
           std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
      *(undefined **)((int)&iStack_dc + (int)appuStack_d8[0][1]) = appuStack_d8[0][1] + -8;
      *(undefined ***)((int)appuStack_e8 + (int)appuStack_e8[0][1]) =
           std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
      *(undefined **)(appuStack_e8[0][1] + (int)&stack0xffffff14) = appuStack_e8[0][1] + -0x20;
      uStack_8 = 0xb;
      *(undefined ***)((int)appuStack_e8 + (int)appuStack_e8[0][1]) =
           std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
           vftable;
      *(undefined **)(appuStack_e8[0][1] + (int)&stack0xffffff14) = appuStack_e8[0][1] + -0x68;
      piStack_f4 = (int *)0xb2b7c4;
      FUN_0054ee60();
      appuStack_d8[2] =
           std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
           vftable;
      uStack_98 = 0;
      uStack_94 = 0;
      piStack_f4 = (int *)in_stack_0000002c;
      puStack_f8 = &stack0x0000001c;
      if (0xf < in_stack_00000030) {
        puStack_f8 = in_stack_0000001c;
      }
      pppuStack_fc = appuStack_d8;
      uStack_8._0_1_ = 0xc;
      uStack_100 = 0xb2b801;
      FUN_0055b3b0();
      uStack_100 = 0;
      puStack_104 = &uStack_18;
      puStack_108 = &stack0x0000001c;
      cVar4 = FUN_0098f070();
      if (cVar4 == '\0') {
        puStack_f8 = (undefined4 *)0x0;
        piStack_f4 = (int *)0xf;
        puStack_108 = (undefined4 *)((uint)puStack_108 & 0xffffff00);
        FUN_005542c0("MarketplaceService::getProductInfo() an error occured while parsing web response"
                     ,0x50);
        FUN_005e65e0();
      }
      else {
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        puStack_f8 = (undefined4 *)uStack_18;
        piStack_f4 = piStack_14;
        pppuStack_fc = (undefined ***)0xb2b84b;
        FUN_0096e3d0();
        uStack_28 = 0;
        uStack_30 = 0;
        iStack_24 = 0;
        piStack_f4 = (int *)auStack_20;
        uStack_8._0_1_ = 0xd;
        puStack_f8 = (undefined4 *)0xb2b86e;
        puVar5 = (undefined8 *)FUN_01682800();
        uStack_30 = *puVar5;
        piStack_f4 = &uStack_18;
        puStack_f8 = (undefined4 *)0xb2b888;
        FUN_0056ecd0();
        piStack_f4 = (int *)&param_1;
        puStack_f8 = (undefined4 *)0xb2b897;
        iVar6 = FUN_00b1a310();
        *(undefined4 *)(iVar6 + 0x18) = (undefined4)uStack_30;
        *(undefined4 *)(iVar6 + 0x1c) = uStack_30._4_4_;
        if (iStack_24 != 0) {
          LOCK();
          *(int *)(iStack_24 + 4) = *(int *)(iStack_24 + 4) + 1;
          UNLOCK();
        }
        *(undefined4 *)(iVar6 + 0x20) = uStack_28;
        piVar2 = *(int **)(iVar6 + 0x24);
        *(int *)(iVar6 + 0x24) = iStack_24;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar6 = piVar2[1] + -1;
          piVar2[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            piStack_f4 = (int *)0xb2b8cf;
            (**(code **)*piVar2)();
            LOCK();
            iVar6 = piVar2[2] + -1;
            piVar2[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              piStack_f4 = (int *)0xb2b8df;
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piStack_f4 = (int *)0xb2b8e7;
        FUN_0056bac0();
      }
      piStack_f4 = (int *)0xb2b91e;
      FUN_005705c0();
      piVar2 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_14[1] + -1;
        piStack_14[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          piStack_f4 = (int *)0xb2b934;
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            piStack_f4 = (int *)0xb2b944;
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_34[1] + -1;
    piStack_34[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      piStack_f4 = (int *)0xb2b95a;
      (**(code **)*piStack_34)();
      LOCK();
      iVar6 = piStack_34[2] + -1;
      piStack_34[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        piStack_f4 = (int *)0xb2b96a;
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 3;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < in_stack_00000018) {
    piStack_f4 = (int *)(in_stack_00000018 + 1);
    puVar7 = param_1;
    if (0xfff < piStack_f4) {
      puVar7 = (undefined4 *)param_1[-1];
      piStack_f4 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        piStack_f4 = (int *)0xb2ba7b;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    pppuStack_fc = (undefined ***)0xb2b99f;
    puStack_f8 = puVar7;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000030) {
    piStack_f4 = (int *)(in_stack_00000030 + 1);
    puVar7 = in_stack_0000001c;
    if (0xfff < piStack_f4) {
      puVar7 = (undefined4 *)in_stack_0000001c[-1];
      piStack_f4 = (int *)(in_stack_00000030 + 0x24);
      if (0x1f < (uint)((int)in_stack_0000001c + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        piStack_f4 = (int *)&UNK_00b2ba80;
        FUN_017167a3();
      }
    }
    pppuStack_fc = (undefined ***)0xb2b9e9;
    puStack_f8 = puVar7;
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = (undefined4 *)((uint)in_stack_0000001c & 0xffffff00);
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    piVar2 = in_stack_00000038 + 2;
    iVar6 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      piStack_f4 = (int *)0xb2ba12;
      (**(code **)(*in_stack_00000038 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (in_stack_0000003c != 0) {
    if (((in_stack_0000003c & 1) == 0) &&
       (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
      pppuStack_fc = (undefined ***)&stack0x00000044;
      piStack_f4 = (int *)0x2;
      uStack_100 = 0xb2ba33;
      puStack_f8 = pppuStack_fc;
      (**(code **)(in_stack_0000003c & 0xfffffffe))();
    }
    in_stack_0000003c = 0;
  }
  uStack_8 = 0xf;
  if (((in_stack_0000005c != 0) && ((in_stack_0000005c & 1) == 0)) &&
     (*(code **)(in_stack_0000005c & 0xfffffffe) != (code *)0x0)) {
    pppuStack_fc = (undefined ***)&stack0x00000064;
    piStack_f4 = (int *)0x2;
    uStack_100 = 0xb2ba61;
    puStack_f8 = pppuStack_fc;
    (**(code **)(in_stack_0000005c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23685 ; VA 0x00b2ba90 ; FUN_00b2ba90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b2ba90(void)

{
  int iVar1;
  int iVar2;
  void *pvVar3;
  char cVar4;
  undefined *puVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined4 ***pppuVar9;
  byte *pbVar10;
  uint uVar11;
  int in_stack_00000014;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_0000003c;
  undefined uVar12;
  undefined4 in_stack_ffffff8c;
  undefined4 in_stack_ffffff90;
  undefined4 in_stack_ffffff94;
  undefined4 uVar13;
  undefined *puVar14;
  undefined4 uVar15;
  uint *puVar16;
  undefined4 uVar17;
  undefined4 **appuStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  uint uStack_3c;
  undefined *puStack_38;
  undefined2 uStack_34;
  int aiStack_30 [2];
  byte *pbStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [4];
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0d50;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (in_stack_00000014 == 0) {
    uVar13 = 0;
    uVar15 = 0xf;
    uVar12 = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("MarketplaceService:GetProductInfo() failed because the response was empty.",0x4a);
    FUN_005e65e0(uVar12,in_stack_ffffff8c,in_stack_ffffff90,in_stack_ffffff94,uVar13,uVar15);
  }
  else {
    pbStack_28 = (byte *)0x0;
    uStack_24 = 0;
    uStack_8 = 3;
    puVar5 = &stack0x00000004;
    uVar13 = 0xb2bb0b;
    ExceptionList = &pvStack_10;
    cVar4 = FUN_0098f070(puVar5,&pbStack_28,0);
    if (cVar4 == '\0') {
      uVar15 = 0;
      uVar17 = 0xf;
      uVar12 = 0;
      FUN_005542c0("MarketplaceService:GetProductInfo() failed because it could not parse the response."
                   ,0x53);
      FUN_005e65e0(uVar12,in_stack_ffffff8c,uVar13,puVar5,uVar15,uVar17);
    }
    else {
      puVar5 = (undefined *)FUN_01674e20(0x18);
      puStack_18 = puVar5;
      if (puVar5 == (undefined *)0x0) {
        puVar5 = (undefined *)0x0;
      }
      else {
        *puVar5 = 0;
        uVar13 = FUN_00588320(0xb);
        *(undefined4 *)(puVar5 + 4) = uVar13;
        *(undefined4 *)(puVar5 + 8) = 0;
        *(undefined4 *)(puVar5 + 0xc) = 0x3f800000;
        *(undefined4 *)(puVar5 + 0x10) = 0;
        *(undefined4 *)(puVar5 + 0x14) = 0;
      }
      aiStack_30[0] = 0;
      aiStack_30[1] = 0;
      FUN_005c1af0(puVar5,in_stack_00000018);
      pbVar10 = pbStack_28;
      uStack_8._0_1_ = 4;
      uStack_44 = 0;
      uStack_40 = 0xf;
      appuStack_54[0] = (undefined4 **)((uint)appuStack_54[0] & 0xffffff00);
      FUN_005542c0(&DAT_018c387c,4);
      pbVar10 = pbVar10 + *pbVar10 + 1;
      uVar13 = FUN_0055c740(pbVar10,appuStack_54);
      FUN_00562fc0(&puStack_18,uVar13,appuStack_54,
                   -(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
      FUN_005507b0();
      puVar5 = puStack_18;
      iVar2 = aiStack_30[0];
      if (puStack_18 != (undefined *)0x0) {
        iVar1 = *(int *)(puStack_18 + 0x20);
        iVar6 = FUN_0088cb40();
        if (iVar1 == iVar6) {
          puStack_38 = (undefined *)0x0;
          uStack_34 = 0;
          uStack_3c = -(uint)(iVar2 != -3) & iVar2 + 4U;
          uStack_8._0_1_ = 5;
          FUN_005c6580();
          puVar14 = puStack_38;
          puStack_18 = puStack_38 + 8;
          *(undefined4 *)(puStack_38 + 0x18) = 0;
          *(undefined4 *)(puStack_38 + 0x1c) = 0xf;
          *puStack_18 = 0;
          FUN_005542c0(&DAT_018d8974,4);
          *(undefined4 *)(puVar14 + 0x20) = *(undefined4 *)(puVar5 + 0x20);
          *(undefined4 *)(puVar14 + 0x24) = 0;
          puVar7 = *(undefined4 **)(puVar5 + 0x24);
          uStack_8._0_1_ = 6;
          if (puVar7 != (undefined4 *)0x0) {
            (*(code *)*puVar7)(puVar5 + 0x28,puVar14 + 0x28);
            puVar7 = *(undefined4 **)(puVar5 + 0x24);
          }
          *(undefined4 **)(puVar14 + 0x24) = puVar7;
          uStack_8._0_1_ = 5;
          uStack_34 = CONCAT11(1,(undefined)uStack_34);
          FUN_0094df20(auStack_20,&uStack_3c);
          puVar5 = puStack_38;
          uStack_8._0_1_ = 7;
          if (puStack_38 != (undefined *)0x0) {
            if (uStack_34._1_1_ != '\0') {
              FUN_00560ab0(uStack_3c,puStack_38 + 8);
            }
            FUN_01674ea0(puVar5,0xf0);
          }
          uStack_8._0_1_ = 4;
        }
      }
      pbVar10 = pbStack_28;
      uStack_44 = 0;
      uStack_40 = 0xf;
      appuStack_54[0] = (undefined4 **)((uint)appuStack_54[0] & 0xffffff00);
      FUN_005542c0("description",0xb);
      pbVar10 = pbVar10 + *pbVar10 + 1;
      uVar13 = FUN_0055c740(pbVar10,appuStack_54);
      FUN_00562fc0(&puStack_18,uVar13,appuStack_54,
                   -(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
      FUN_005507b0();
      puVar5 = puStack_18;
      if (puStack_18 != (undefined *)0x0) {
        iVar1 = *(int *)(puStack_18 + 0x20);
        iVar6 = FUN_0088cb40();
        if (iVar1 == iVar6) {
          puStack_38 = (undefined *)0x0;
          uStack_34 = 0;
          uStack_3c = -(uint)(iVar2 != -3) & iVar2 + 4U;
          uStack_8._0_1_ = 8;
          FUN_005c6580();
          puVar14 = puStack_38;
          puStack_18 = puStack_38 + 8;
          *(undefined4 *)(puStack_38 + 0x18) = 0;
          *(undefined4 *)(puStack_38 + 0x1c) = 0xf;
          *puStack_18 = 0;
          FUN_005542c0("Description",0xb);
          *(undefined4 *)(puVar14 + 0x20) = *(undefined4 *)(puVar5 + 0x20);
          *(undefined4 *)(puVar14 + 0x24) = 0;
          puVar7 = *(undefined4 **)(puVar5 + 0x24);
          uStack_8._0_1_ = 9;
          if (puVar7 != (undefined4 *)0x0) {
            (*(code *)*puVar7)(puVar5 + 0x28,puVar14 + 0x28);
            puVar7 = *(undefined4 **)(puVar5 + 0x24);
          }
          *(undefined4 **)(puVar14 + 0x24) = puVar7;
          uStack_8._0_1_ = 8;
          uStack_34 = CONCAT11(1,(undefined)uStack_34);
          FUN_0094df20(auStack_20,&uStack_3c);
          puVar5 = puStack_38;
          uStack_8._0_1_ = 10;
          if (puStack_38 != (undefined *)0x0) {
            if (uStack_34._1_1_ != '\0') {
              FUN_00560ab0(uStack_3c,puStack_38 + 8);
            }
            FUN_01674ea0(puVar5,0xf0);
          }
          uStack_8._0_1_ = 4;
        }
      }
      pbVar10 = pbStack_28;
      uStack_44 = 0;
      uStack_40 = 0xf;
      appuStack_54[0] = (undefined4 **)((uint)appuStack_54[0] & 0xffffff00);
      FUN_005542c0("priceInRobux",0xc);
      pbVar10 = pbVar10 + *pbVar10 + 1;
      uVar13 = FUN_0055c740(pbVar10,appuStack_54);
      FUN_00562fc0(&puStack_18,uVar13,appuStack_54,
                   -(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
      FUN_005507b0();
      puVar5 = puStack_18;
      if ((puStack_18 != (undefined *)0x0) &&
         (*(char *)(*(int *)(puStack_18 + 0x20) + 0x21) != '\0')) {
        puStack_38 = (undefined *)0x0;
        uStack_34 = 0;
        uStack_3c = -(uint)(iVar2 != -3) & iVar2 + 4U;
        uStack_8._0_1_ = 0xb;
        FUN_005c6580();
        puVar14 = puStack_38;
        puStack_18 = puStack_38 + 8;
        *(undefined4 *)(puStack_38 + 0x18) = 0;
        *(undefined4 *)(puStack_38 + 0x1c) = 0xf;
        *puStack_18 = 0;
        FUN_005542c0("PriceInRobux",0xc);
        *(undefined4 *)(puVar14 + 0x20) = *(undefined4 *)(puVar5 + 0x20);
        *(undefined4 *)(puVar14 + 0x24) = 0;
        puVar7 = *(undefined4 **)(puVar5 + 0x24);
        uStack_8._0_1_ = 0xc;
        if (puVar7 != (undefined4 *)0x0) {
          (*(code *)*puVar7)(puVar5 + 0x28,puVar14 + 0x28);
          puVar7 = *(undefined4 **)(puVar5 + 0x24);
        }
        *(undefined4 **)(puVar14 + 0x24) = puVar7;
        uStack_8._0_1_ = 0xb;
        uStack_34 = CONCAT11(1,(undefined)uStack_34);
        FUN_0094df20(auStack_20,&uStack_3c);
        puVar5 = puStack_38;
        uStack_8._0_1_ = 0xd;
        if (puStack_38 != (undefined *)0x0) {
          if (uStack_34._1_1_ != '\0') {
            FUN_00560ab0(uStack_3c,puStack_38 + 8);
          }
          FUN_01674ea0(puVar5,0xf0);
        }
        uStack_8._0_1_ = 4;
      }
      pbVar10 = pbStack_28;
      uStack_44 = 0;
      uStack_40 = 0xf;
      appuStack_54[0] = (undefined4 **)((uint)appuStack_54[0] & 0xffffff00);
      FUN_005542c0("created",7);
      pbVar10 = pbVar10 + *pbVar10 + 1;
      uVar13 = FUN_0055c740(pbVar10,appuStack_54);
      FUN_00562fc0(&puStack_18,uVar13,appuStack_54,
                   -(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
      FUN_005507b0();
      if (puStack_18 != (undefined *)0x0) {
        iVar1 = *(int *)(puStack_18 + 0x20);
        puVar5 = puStack_18 + 0x20;
        iVar6 = FUN_0088cb40();
        if (iVar1 == iVar6) {
          FUN_00b15030(auStack_20,"Created",puVar5);
        }
      }
      pbVar10 = pbStack_28;
      uStack_44 = 0;
      uStack_40 = 0xf;
      appuStack_54[0] = (undefined4 **)((uint)appuStack_54[0] & 0xffffff00);
      FUN_005542c0("updated",7);
      pbVar10 = pbVar10 + *pbVar10 + 1;
      uVar13 = FUN_0055c740(pbVar10,appuStack_54);
      FUN_00562fc0(&puStack_18,uVar13,appuStack_54,
                   -(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
      FUN_005507b0();
      if (puStack_18 != (undefined *)0x0) {
        iVar1 = *(int *)(puStack_18 + 0x20);
        puVar5 = puStack_18 + 0x20;
        iVar6 = FUN_0088cb40();
        if (iVar1 == iVar6) {
          FUN_00b15030(auStack_20,"Updated",puVar5);
        }
      }
      pbVar10 = pbStack_28;
      uStack_44 = 0;
      uStack_40 = 0xf;
      appuStack_54[0] = (undefined4 **)((uint)appuStack_54[0] & 0xffffff00);
      FUN_005542c0("imageAssetId",0xc);
      pbVar10 = pbVar10 + *pbVar10 + 1;
      uVar13 = FUN_0055c740(pbVar10,appuStack_54);
      FUN_00562fc0(&puStack_18,uVar13,appuStack_54,
                   -(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
      FUN_005507b0();
      puVar5 = puStack_18;
      if ((puStack_18 != (undefined *)0x0) &&
         (*(char *)(*(int *)(puStack_18 + 0x20) + 0x21) != '\0')) {
        puStack_38 = (undefined *)0x0;
        uStack_34 = 0;
        uStack_3c = -(uint)(iVar2 != -3) & iVar2 + 4U;
        uStack_8._0_1_ = 0xe;
        FUN_005c6580();
        puVar14 = puStack_38;
        puStack_18 = puStack_38 + 8;
        *(undefined4 *)(puStack_38 + 0x18) = 0;
        *(undefined4 *)(puStack_38 + 0x1c) = 0xf;
        *puStack_18 = 0;
        FUN_005542c0("IconImageAssetId",0x10);
        *(undefined4 *)(puVar14 + 0x20) = *(undefined4 *)(puVar5 + 0x20);
        *(undefined4 *)(puVar14 + 0x24) = 0;
        puVar7 = *(undefined4 **)(puVar5 + 0x24);
        uStack_8._0_1_ = 0xf;
        if (puVar7 != (undefined4 *)0x0) {
          (*(code *)*puVar7)(puVar5 + 0x28,puVar14 + 0x28);
          puVar7 = *(undefined4 **)(puVar5 + 0x24);
        }
        *(undefined4 **)(puVar14 + 0x24) = puVar7;
        uStack_8._0_1_ = 0xe;
        uStack_34 = CONCAT11(1,(undefined)uStack_34);
        FUN_0094df20(auStack_20,&uStack_3c);
        puVar5 = puStack_38;
        uStack_8._0_1_ = 0x10;
        if (puStack_38 != (undefined *)0x0) {
          if (uStack_34._1_1_ != '\0') {
            FUN_00560ab0(uStack_3c,puStack_38 + 8);
          }
          FUN_01674ea0(puVar5,0xf0);
        }
        uStack_8._0_1_ = 4;
      }
      uStack_44 = 0;
      uStack_40 = 0xf;
      appuStack_54[0] = (undefined4 **)((uint)appuStack_54[0] & 0xffffff00);
      FUN_005542c0("status",6);
      piVar8 = (int *)FUN_00580040(&puStack_18,appuStack_54);
      iVar1 = *piVar8;
      FUN_005507b0();
      if (iVar1 != 0) {
        iVar1 = *(int *)(iVar1 + 0x20);
        iVar6 = FUN_0088cb40();
        if (iVar1 == iVar6) {
          uVar13 = FUN_0055d610();
          FUN_0054ef60(uVar13);
          pppuVar9 = appuStack_54;
          if (0xf < uStack_40) {
            pppuVar9 = (undefined4 ***)appuStack_54[0];
          }
          uStack_11 = FUN_0055c360(pppuVar9,uStack_44,&DAT_01951118,4);
          puStack_38 = (undefined *)0x0;
          uStack_34 = 0;
          uVar11 = -(uint)(iVar2 != -3) & iVar2 + 4U;
          uStack_8._0_1_ = 0x12;
          uStack_3c = uVar11;
          FUN_005c6580();
          puVar5 = puStack_38;
          puStack_18 = (undefined *)((int)puStack_38 + 8);
          *(undefined4 *)((int)puStack_38 + 0x18) = 0;
          *(undefined4 *)((int)puStack_38 + 0x1c) = 0xf;
          *puStack_18 = 0;
          FUN_005542c0("IsForSale",9);
          uStack_8._0_1_ = 0x13;
          uVar13 = FUN_0088daf0();
          *(undefined4 *)((int)puVar5 + 0x20) = uVar13;
          *(undefined4 *)((int)puVar5 + 0x24) = 0;
          *(undefined *)((int)puVar5 + 0x28) = uStack_11;
          uVar13 = FUN_005c9ef0();
          *(undefined4 *)((int)puVar5 + 0x24) = uVar13;
          uStack_8._0_1_ = 0x12;
          uStack_34._1_1_ = '\x01';
          FUN_0094df20(auStack_20,&uStack_3c);
          puVar5 = puStack_38;
          uStack_8._0_1_ = 0x14;
          if (puStack_38 != (undefined *)0x0) {
            if (uStack_34._1_1_ != '\0') {
              FUN_00560ab0(uStack_3c,(int)puStack_38 + 8);
            }
            FUN_01674ea0(puVar5,0xf0);
          }
          puStack_38 = (undefined *)0x0;
          uStack_34 = 0;
          uStack_8._0_1_ = 0x15;
          uStack_3c = uVar11;
          FUN_005c6580();
          puVar5 = puStack_38;
          puStack_18 = puStack_38 + 8;
          *(undefined4 *)(puStack_38 + 0x18) = 0;
          *(undefined4 *)(puStack_38 + 0x1c) = 0xf;
          *puStack_18 = 0;
          FUN_005542c0("Active",6);
          uStack_8._0_1_ = 0x16;
          uVar13 = FUN_0088daf0();
          *(undefined4 *)(puVar5 + 0x20) = uVar13;
          *(undefined4 *)(puVar5 + 0x24) = 0;
          puVar5[0x28] = uStack_11;
          uVar13 = FUN_005c9ef0();
          *(undefined4 *)(puVar5 + 0x24) = uVar13;
          uStack_8._0_1_ = 0x15;
          uStack_34 = CONCAT11(1,(undefined)uStack_34);
          FUN_0094df20(auStack_20,&uStack_3c);
          puVar5 = puStack_38;
          uStack_8._0_1_ = 0x17;
          if (puStack_38 != (undefined *)0x0) {
            if (uStack_34._1_1_ != '\0') {
              FUN_00560ab0(uStack_3c,puStack_38 + 8);
            }
            FUN_01674ea0(puVar5,0xf0);
          }
          uStack_8._0_1_ = 4;
          FUN_005507b0();
        }
      }
      uStack_44 = 0;
      uStack_40 = 0xf;
      appuStack_54[0] = (undefined4 **)((uint)appuStack_54[0] & 0xffffff00);
      FUN_005542c0(&DAT_018c1fd8,2);
      piVar8 = (int *)FUN_00580040(&puStack_18,appuStack_54);
      iVar1 = *piVar8;
      FUN_005507b0();
      if ((iVar1 != 0) && (*(char *)(*(int *)(iVar1 + 0x20) + 0x21) != '\0')) {
        puStack_38 = (undefined *)0x0;
        uStack_34 = 0;
        uStack_3c = -(uint)(iVar2 != -3) & iVar2 + 4U;
        uStack_8._0_1_ = 0x18;
        FUN_005c6580();
        puStack_1c = puStack_38 + 8;
        *(undefined4 *)(puStack_38 + 0x18) = 0;
        *(undefined4 *)(puStack_38 + 0x1c) = 0xf;
        *puStack_1c = 0;
        FUN_005542c0("ProductId",9);
        uStack_8._0_1_ = 0x19;
        FUN_0056a440(iVar1 + 0x20);
        uStack_8._0_1_ = 0x18;
        uStack_34 = CONCAT11(1,(undefined)uStack_34);
        FUN_0094df20(auStack_20,&uStack_3c);
        puVar5 = puStack_38;
        uStack_8._0_1_ = 0x1a;
        if (puStack_38 != (undefined *)0x0) {
          if (uStack_34._1_1_ != '\0') {
            FUN_00560ab0(uStack_3c,puStack_38 + 8);
          }
          FUN_0054db70(puVar5,0xf0);
        }
        uStack_8._0_1_ = 4;
      }
      puStack_18 = (undefined *)0x0;
      FUN_00b15140(auStack_20,"Subscribers",&puStack_18);
      puStack_18 = (undefined *)0x0;
      FUN_00b15140(auStack_20,"AssetTypeId",&puStack_18);
      puStack_38 = (undefined *)0x0;
      uStack_34 = 0;
      uStack_3c = -(uint)(iVar2 != -3) & iVar2 + 4U;
      uStack_8._0_1_ = 0x1b;
      FUN_005c6580();
      puVar5 = puStack_38;
      puStack_1c = puStack_38 + 8;
      *(undefined4 *)(puStack_38 + 0x18) = 0;
      *(undefined4 *)(puStack_38 + 0x1c) = 0xf;
      *puStack_1c = 0;
      FUN_005542c0("MinimumMembershipLevel",0x16);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1c);
      uVar13 = thunk_FUN_005f32d0();
      iVar2 = _tls_index;
      *(undefined4 *)(puVar5 + 0x20) = uVar13;
      pvVar3 = ThreadLocalStoragePointer;
      *(undefined4 *)(puVar5 + 0x24) = 0;
      *(undefined4 *)(puVar5 + 0x28) = 4;
      if (*(int *)(*(int *)((int)pvVar3 + iVar2 * 4) + 0x34) < DAT_01eaac8c) {
        FUN_016f3809(&DAT_01eaac8c);
        if (DAT_01eaac8c == -1) {
          _DAT_01eaac80 = FUN_005c65e0;
          _DAT_01eaac84 = FUN_005c65e0;
          _DAT_01eaac88 = _guard_check_icall;
          FUN_016f37bf(&DAT_01eaac8c);
        }
      }
      puVar16 = &uStack_3c;
      *(undefined **)(puVar5 + 0x24) = &DAT_01eaac80;
      puVar5 = auStack_20;
      uStack_8._0_1_ = 0x1b;
      uStack_34 = CONCAT11(1,(undefined)uStack_34);
      FUN_0094df20(puVar5,puVar16);
      puVar14 = puStack_38;
      uStack_8._0_1_ = 0x1d;
      if (puStack_38 != (undefined *)0x0) {
        if (uStack_34._1_1_ != '\0') {
          FUN_00560ab0(uStack_3c,puStack_38 + 8);
        }
        puVar16 = (uint *)0xf0;
        FUN_0054db70(puVar14,0xf0);
        puVar5 = puVar14;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_00557fc0(aiStack_30);
      FUN_0096e3d0(puVar5,puVar16);
      FUN_00550b30();
    }
    FUN_00550b30();
  }
  FUN_005507b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 0x1f;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&stack0x00000044,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23686 ; VA 0x00b2c680 ; FUN_00b2c680 */

void __thiscall FUN_00b2c680(int param_1,int param_2,undefined4 *param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uStack_4c;
  code *pcStack_44;
  undefined4 *puStack_40;
  code *pcStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined4 uStack_30;
  code *pcStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f0d99;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  iStack_1c = param_1 + 0x78;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_01679490();
  FUN_01679490();
  iStack_20 = param_1 + 0x80;
  FUN_01679490();
  iVar4 = (int)param_3;
  FUN_008a4210(param_2,param_3);
  if (iVar4 != 0) {
    cVar2 = FUN_00971ce0(iVar4,1);
    if (cVar2 != '\0') {
      *(undefined *)(param_1 + 0x74) = 0;
      pcStack_2c = FUN_00b1c330;
      cVar2 = FUN_00585a40(&pcStack_2c);
      if (cVar2 == '\0') {
        pcStack_44 = pcStack_2c;
        puStack_40 = puStack_28;
        uStack_4c = 0x1951c05;
      }
      else {
        uStack_4c = 0;
      }
      uStack_8 = 0;
      FUN_00b31c10(param_1 + 0x1b0);
      uStack_8 = 1;
      if (((uStack_4c != 0) && ((uStack_4c & 1) == 0)) &&
         (*(code **)(uStack_4c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_4c & 0xfffffffe))(&pcStack_44,&pcStack_44,2);
      }
      iVar4 = *(int *)(param_1 + 0x34);
      uStack_8 = 0xffffffff;
      if ((iVar4 != 0) && (param_1 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
        param_1 = FUN_005c8ac0();
      }
      if ((param_1 != 0) &&
         (iVar4 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        FUN_0055e560();
      }
      FUN_008a40f0();
      param_2 = FUN_008a4100();
      param_2 = param_2 + 8;
      pcStack_3c = FUN_00b273d0;
      uStack_38 = 0;
      iStack_34 = iStack_14;
      uStack_8 = 2;
      iVar4 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 3;
      iStack_24 = iVar4;
      puStack_28 = (undefined4 *)FUN_01674e20(0x28);
      if (puStack_28 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puStack_28 = 0;
        puStack_28[1] = 1;
        puStack_28[2] = FUN_00923570;
        puStack_28[3] = _guard_check_icall;
        puStack_28[4] = 0;
        puStack_28[5] = param_2;
        puStack_28[6] = pcStack_3c;
        puStack_28[7] = uStack_38;
        puStack_28[8] = iStack_34;
        puStack_28[9] = uStack_30;
        puVar5 = puStack_28;
      }
      FUN_016797d0(puVar5);
      if (puVar5 != (undefined4 *)0x0) {
        LOCK();
        puVar5[1] = puVar5[1] + 1;
        UNLOCK();
      }
      uStack_18 = 1;
      uStack_8._0_1_ = 4;
      param_3 = puVar5;
      FUN_01675290(iVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      cVar2 = FUN_01679300(&param_3);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_3);
      }
      uStack_8 = 0xffffffff;
      if (param_3 != (undefined4 *)0x0) {
        piVar1 = param_3 + 1;
        LOCK();
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          FUN_01674ea0(param_3);
        }
      }
      param_1 = iStack_14;
      pcStack_3c = FUN_00b27260;
      uStack_38 = 0;
      iStack_34 = iStack_14;
      param_3 = (undefined4 *)FUN_00b14b10(&param_2,&pcStack_3c);
      uStack_8 = 5;
      cVar2 = FUN_01679300(param_3);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_3);
      }
      uStack_8 = 0xffffffff;
      if (param_2 != 0) {
        piVar1 = (int *)(param_2 + 4);
        LOCK();
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
    pcStack_3c = FUN_00b32ff0;
    uStack_38 = 0;
    iStack_34 = param_1;
    param_3 = (undefined4 *)FUN_00b14b10(&iStack_24,&pcStack_3c);
    uStack_8 = 6;
    cVar2 = FUN_01679300(param_3);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(param_3);
    }
    if (iStack_24 != 0) {
      piVar1 = (int *)(iStack_24 + 4);
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        FUN_01674ea0(iStack_24);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23687 ; VA 0x00b2c9d0 ; FUN_00b2c9d0 */

void __thiscall
FUN_00b2c9d0(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,uint param_6)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  uint *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  char cVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined **ppuVar11;
  int iVar12;
  uint uVar13;
  uint uVar14;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  int in_stack_00000044;
  undefined8 in_stack_00000048;
  uint in_stack_00000050;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined8 in_stack_00000068;
  undefined4 uStack_294;
  undefined8 uStack_290;
  int *piStack_288;
  undefined4 uStack_284;
  undefined4 *puStack_280;
  undefined4 *puStack_27c;
  undefined4 uStack_278;
  uint auStack_274 [2];
  undefined4 uStack_26c;
  undefined4 uStack_268;
  undefined4 uStack_264;
  int iStack_260;
  undefined8 uStack_25c;
  undefined4 auStack_254 [4];
  undefined4 uStack_244;
  undefined4 *puStack_240;
  undefined4 *puStack_23c;
  undefined4 uStack_238;
  uint auStack_234 [2];
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 *puStack_220;
  undefined8 uStack_21c;
  undefined4 auStack_20c [2];
  undefined auStack_204 [64];
  undefined4 uStack_1c4;
  undefined auStack_1bc [64];
  undefined4 uStack_17c;
  undefined auStack_174 [64];
  undefined4 uStack_134;
  undefined auStack_12c [64];
  undefined4 uStack_ec;
  undefined auStack_e4 [64];
  undefined4 auStack_a4 [2];
  undefined auStack_9c [64];
  undefined auStack_5c [4];
  int *piStack_58;
  undefined *puStack_54;
  undefined *puStack_50;
  undefined *puStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  code *pcStack_40;
  int *piStack_3c;
  undefined8 uStack_38;
  int iStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0e49;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_21c = CONCAT44(param_1,0xb2ca02);
  ExceptionList = &pvStack_10;
  uStack_20 = param_1;
  iVar8 = FUN_0097bfc0();
  if (iVar8 != 0) {
    iVar1 = *(int *)(iVar8 + 0xc);
    uStack_21c = CONCAT44(0xb2ca17,(undefined4)uStack_21c);
    iVar9 = thunk_FUN_00897b90();
    iVar12 = 0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
        (uint)*(ushort *)(iVar9 + 0x1da)) {
      iVar12 = iVar8;
    }
    uStack_21c = CONCAT44(iVar12,&uStack_48);
    puStack_220 = (undefined4 *)0xb2ca3f;
    FUN_0060dcd0();
    uVar3 = uStack_20;
    uStack_8._0_1_ = 3;
    uStack_24 = CONCAT31(uStack_24._1_3_,param_2 == 3);
    uStack_21c = CONCAT44(auStack_5c,0xb2ca5c);
    puVar10 = (undefined4 *)FUN_00b264d0();
    piStack_3c = (int *)*puVar10;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    pcStack_40 = *(code **)(*piStack_3c + 0x1c);
    uStack_28 = CONCAT31(uStack_28._1_3_,DAT_01eee1b9);
    uStack_21c = CONCAT44(uVar3,0xb2ca7b);
    iVar8 = FUN_008f7870();
    piVar2 = *(int **)(iVar8 + 0x43c);
    iStack_30 = *piVar2 - (int)piVar2;
    iStack_2c = piVar2[1] - (int)piVar2;
    uStack_21c = CONCAT44(0xb2ca9a,(undefined4)uStack_21c);
    uStack_38 = FUN_00928340();
    puStack_4c = (undefined *)auStack_234;
    puStack_1c = auStack_234;
    auStack_234[0] = 0;
    puVar4 = auStack_234;
    if (in_stack_00000050 != 0) {
      auStack_234[0] = in_stack_00000050;
      if ((in_stack_00000050 & 1) == 0) {
        puStack_23c = &uStack_22c;
        uStack_238 = 0;
        puStack_240 = &stack0x00000058;
        uStack_244 = 0xb2cae4;
        (**(code **)(in_stack_00000050 & 0xfffffffe))();
        puVar4 = (uint *)puStack_4c;
      }
      else {
        uStack_22c = in_stack_00000058;
        uStack_228 = in_stack_0000005c;
        uStack_224 = in_stack_00000060;
        puStack_220 = (undefined4 *)in_stack_00000064;
        uStack_21c = in_stack_00000068;
        puVar4 = auStack_234;
      }
    }
    puStack_4c = (undefined *)puVar4;
    puStack_50 = (undefined *)auStack_254;
    puStack_1c = auStack_254;
    puVar10 = auStack_254;
    uStack_8._0_1_ = 5;
    puStack_54 = (undefined *)auStack_274;
    puStack_18 = auStack_274;
    auStack_274[0] = 0;
    puVar4 = auStack_274;
    puVar5 = auStack_254;
    puVar6 = auStack_254;
    if (in_stack_00000030 != 0) {
      auStack_274[0] = in_stack_00000030;
      if ((in_stack_00000030 & 1) == 0) {
        puStack_27c = &uStack_26c;
        uStack_278 = 0;
        puStack_280 = &stack0x00000038;
        uStack_284 = 0xb2cb3a;
        (**(code **)(in_stack_00000030 & 0xfffffffe))();
        puVar4 = (uint *)puStack_54;
        puVar5 = (undefined4 *)puStack_50;
        puVar6 = puStack_1c;
      }
      else {
        uStack_26c = in_stack_00000038;
        uStack_268 = in_stack_0000003c;
        uStack_264 = in_stack_00000040;
        iStack_260 = in_stack_00000044;
        uStack_25c = in_stack_00000048;
        puVar4 = auStack_274;
        puVar5 = auStack_254;
        puVar6 = auStack_254;
      }
    }
    puStack_1c = puVar6;
    puStack_50 = (undefined *)puVar5;
    puStack_54 = (undefined *)puVar4;
    uStack_278 = uStack_28;
    puStack_27c = (undefined4 *)uStack_24;
    puStack_280 = (undefined4 *)param_4;
    uStack_284 = param_3;
    puStack_18 = (undefined4 *)((int)&uStack_290 + 4);
    if (piStack_44 != (int *)0x0) {
      LOCK();
      piStack_44[1] = piStack_44[1] + 1;
      UNLOCK();
    }
    uStack_290._4_4_ = uStack_48;
    piStack_288 = piStack_44;
    uStack_8._0_1_ = 7;
    FUN_0060e0c0(&uStack_294,uStack_20);
    uStack_8._0_1_ = 5;
    FUN_00b141e0(auStack_20c,FUN_00b27720);
    uStack_1c4 = auStack_20c[0];
    uStack_8._0_1_ = 8;
    uStack_25c = CONCAT44(auStack_204,0xb2cbc0);
    FUN_00b16ef0();
    uStack_17c = uStack_1c4;
    uStack_8._0_1_ = 9;
    auStack_254[0] = 0;
    uStack_25c = CONCAT44(auStack_1bc,0xb2cbe8);
    FUN_00b16ef0();
    uStack_134 = uStack_17c;
    uStack_8._0_1_ = 10;
    uStack_25c = CONCAT44(auStack_174,0xb2cc0a);
    FUN_00b16ef0();
    auStack_a4[0] = uStack_134;
    uStack_8._0_1_ = 0xb;
    uStack_25c = CONCAT44(auStack_12c,0xb2cc2c);
    FUN_00b16ef0();
    uStack_8._0_1_ = 0xc;
    uStack_25c = CONCAT44(auStack_a4,0xb2cc3c);
    cVar7 = FUN_00585a40();
    if (cVar7 == '\0') {
      uStack_ec = auStack_a4[0];
      uStack_25c = CONCAT44(auStack_9c,0xb2cc61);
      FUN_00b16ef0();
      uStack_8._0_1_ = 0xd;
      uStack_25c = 0x4800b2cc6c;
      puVar10 = (undefined4 *)FUN_01674e20();
      uStack_8._0_1_ = 0xe;
      puStack_18 = puVar10;
      if (puVar10 == (undefined4 *)0x0) {
        puVar10 = (undefined4 *)0x0;
      }
      else {
        *puVar10 = uStack_ec;
        uStack_25c = CONCAT44(auStack_e4,0xb2cc93);
        FUN_00b16ef0();
      }
      puStack_1c[2] = puVar10;
      uStack_25c = CONCAT44(0xb2cca8,(undefined4)uStack_25c);
      FUN_00b19bf0();
      uStack_25c = CONCAT44(0xb2ccb3,(undefined4)uStack_25c);
      FUN_00b19bf0();
      cStack_11 = '\x01';
      puVar10 = puStack_1c;
    }
    else {
      uStack_25c = CONCAT44(0xb2ccc7,(undefined4)uStack_25c);
      FUN_00b19bf0();
      cStack_11 = '\0';
    }
    uStack_25c = CONCAT44(0xb2ccd6,(undefined4)uStack_25c);
    FUN_00b19bf0();
    ppuVar11 = &PTR_FUN_01951bc0;
    if (cStack_11 == '\0') {
      ppuVar11 = (undefined **)0x0;
    }
    *puVar10 = ppuVar11;
    uStack_25c = CONCAT44(0xb2ccf0,(undefined4)uStack_25c);
    FUN_00b19bf0();
    uStack_25c = CONCAT44(0xb2ccfb,(undefined4)uStack_25c);
    FUN_00b19bf0();
    uStack_25c = CONCAT44(0xb2cd06,(undefined4)uStack_25c);
    FUN_00b19bf0();
    puStack_27c = &param_6;
    uStack_8._0_1_ = 0xf;
    uStack_25c = CONCAT44(in_stack_0000002c,iStack_2c);
    iStack_260 = iStack_30;
    puStack_280 = (undefined4 *)0xb2cd21;
    FUN_0054ef60();
    puStack_27c = (undefined4 *)param_5;
    puStack_280 = (undefined4 *)param_4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uStack_284 = param_3;
    piStack_288 = (int *)param_2;
    uStack_294 = 0xb2cd3d;
    uStack_290 = uStack_38;
    (*pcStack_40)();
    if (piStack_58 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_58[1] + -1;
      piStack_58[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        uStack_21c = CONCAT44(0xb2cd54,(undefined4)uStack_21c);
        (**(code **)*piStack_58)();
        LOCK();
        iVar8 = piStack_58[2] + -1;
        piStack_58[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          uStack_21c = CONCAT44(0xb2cd67,(undefined4)uStack_21c);
          (**(code **)(*piStack_58 + 4))();
        }
      }
    }
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_44[1] + -1;
      piStack_44[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        uStack_21c = CONCAT44(0xb2cd7b,(undefined4)uStack_21c);
        (**(code **)*piStack_44)();
        LOCK();
        piVar2 = piStack_44 + 2;
        iVar8 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          uStack_21c = CONCAT44(0xb2cd8d,(undefined4)uStack_21c);
          (**(code **)(*piStack_44 + 4))();
        }
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000028) {
    uVar14 = in_stack_00000028 + 1;
    uVar13 = param_6;
    if (0xfff < uVar14) {
      uVar13 = *(uint *)(param_6 - 4);
      uVar14 = in_stack_00000028 + 0x24;
      if (0x1f < (param_6 - uVar13) - 4) {
        uStack_21c = CONCAT44(&UNK_00b2ce40,(undefined4)uStack_21c);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_21c = CONCAT44(uVar14,uVar13);
    puStack_220 = (undefined4 *)0xb2cdc2;
    FUN_01674ea0();
  }
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_6 = param_6 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  if (in_stack_00000030 != 0) {
    if (((in_stack_00000030 & 1) == 0) &&
       (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
      puStack_220 = &stack0x00000038;
      uStack_21c = CONCAT44(2,puStack_220);
      uStack_224 = 0xb2cdf8;
      (**(code **)(in_stack_00000030 & 0xfffffffe))();
    }
    in_stack_00000030 = 0;
  }
  uStack_8 = 0x11;
  if (((in_stack_00000050 != 0) && ((in_stack_00000050 & 1) == 0)) &&
     (*(code **)(in_stack_00000050 & 0xfffffffe) != (code *)0x0)) {
    puStack_220 = &stack0x00000058;
    uStack_21c = CONCAT44(2,puStack_220);
    uStack_224 = 0xb2ce26;
    (**(code **)(in_stack_00000050 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23688 ; VA 0x00b2ce50 ; FUN_00b2ce50 */

undefined FUN_00b2ce50(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined8 uVar7;
  undefined auStack_1c [4];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0e70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00913630();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      puVar6 = (undefined4 *)FUN_00b264d0(auStack_18);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      pcVar3 = *(code **)(*(int *)*puVar6 + 0x20);
      uVar7 = FUN_00928340();
      uVar4 = (*pcVar3)(uVar7);
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_14[1] + -1;
        piStack_14[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          iVar2 = piStack_14[2] + -1;
          piStack_14[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar2 = param_2[1] + -1;
        param_2[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*param_2)();
          LOCK();
          piVar1 = param_2 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return uVar4;
    }
  }
  FUN_016756b0(auStack_1c,"MarketplaceService:PlayerCanMakePurchases() argument is not a player");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 23689 ; VA 0x00b2cf60 ; FUN_00b2cf60 */

void FUN_00b2cf60(int param_1,int *param_2,int param_3,int param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined8 uVar5;
  uint in_stack_00000034;
  char *pcStack_60;
  undefined4 uStack_5c;
  undefined uStack_58;
  undefined4 uStack_50;
  undefined *puStack_4c;
  char *pcStack_48;
  undefined4 uStack_44;
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0ea8;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  if ((param_4 < 1) && ((param_4 < 0 || (param_3 == 0)))) {
    uStack_5c = 0x6e;
    pcStack_48 = (char *)0x0;
    uStack_44 = 0xf;
    pcStack_60 = 
    "MarketplaceService:PlayerOwnsAsset() second argument is not a valid assetId (supplied assetId was less than 0)"
    ;
    uStack_58 = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_5c = 0xb2cfc2;
    FUN_005e65e0();
  }
  else {
    uStack_44 = 0x11;
    pcStack_48 = "PlayerOwnsAsset()";
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = 0;
    puStack_4c = (undefined *)0xb2cfe8;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_8._0_1_ = 3;
    FUN_0054f510(&stack0x00000034);
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    cVar3 = FUN_00b29320(param_1,param_2,auStack_34);
    uStack_8._0_1_ = 2;
    uStack_44 = 0xb2d03b;
    FUN_005507b0();
    if (cVar3 == '\0') {
      uStack_44 = 0;
      pcStack_48 = (char *)0xb2d049;
      FUN_008927d0();
    }
    else if (param_1 != 0) {
      iVar2 = *(int *)(param_1 + 0xc);
      uStack_44 = 0xb2d05a;
      iVar4 = FUN_00913630();
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        uStack_44 = 0xb2d07c;
        uVar5 = FUN_00928340();
        puStack_18 = (undefined *)&pcStack_60;
        FUN_0054f510(&stack0x00000034);
        uStack_8._0_1_ = 4;
        FUN_0054f510(&param_5);
        uStack_8._0_1_ = 2;
        FUN_00b1dcd0(uVar5,param_3,param_4);
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_44 = 0xb2d0d0;
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_44 = 0xb2d0df;
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      puStack_4c = &stack0x0000001c;
      uStack_44 = 2;
      uStack_50 = 0xb2d100;
      pcStack_48 = puStack_4c;
      (**(code **)(param_5 & 0xfffffffe))();
    }
    param_5 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) &&
     (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
    puStack_4c = &stack0x0000003c;
    uStack_44 = 2;
    uStack_50 = 0xb2d12e;
    pcStack_48 = puStack_4c;
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23690 ; VA 0x00b2d150 ; FUN_00b2d150 */

void FUN_00b2d150(undefined4 param_1,int *param_2,int param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 *param_8)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  uint in_stack_00000034;
  undefined auStack_b8 [24];
  undefined4 uStack_a0;
  undefined4 uStack_88;
  uint *puStack_84;
  char *pcStack_80;
  int *piStack_7c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0ef0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (0 < (int)DAT_01d66e30) {
    piStack_7c = (int *)0x0;
    pcStack_80 = (char *)0x0;
    puStack_84 = (uint *)0xffffffff;
    uStack_88 = 0xb2d18f;
    ExceptionList = &pvStack_10;
    FUN_0151f6f0();
    uStack_8._0_1_ = 3;
    piStack_7c = (int *)&param_8;
    if (0xf < in_stack_00000034) {
      piStack_7c = param_8;
    }
    pcStack_80 = "msg";
    puStack_84 = (uint *)0xb2d1ac;
    FUN_0151f850();
    uVar6 = DAT_01d66e30;
    piStack_7c = (int *)0x19;
    pcStack_80 = "purchaseVerificationError";
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    puStack_84 = (uint *)0xb2d1d3;
    FUN_005542c0();
    piStack_7c = (int *)0x0;
    pcStack_80 = (char *)uVar6;
    puStack_84 = auStack_38;
    uStack_8._0_1_ = 4;
    uStack_88 = 0xb2d1e6;
    FUN_01520d20();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (0xf < uStack_24) {
      piStack_7c = (int *)(uStack_24 + 1);
      uVar6 = auStack_38[0];
      if (0xfff < piStack_7c) {
        uVar6 = *(uint *)(auStack_38[0] - 4);
        piStack_7c = (int *)(uStack_24 + 0x24);
        if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          piStack_7c = (int *)0xb2d360;
          FUN_017167a3();
        }
      }
      puStack_84 = (uint *)0xb2d21b;
      pcStack_80 = (char *)uVar6;
      FUN_01674ea0();
    }
    piStack_7c = (int *)0xb2d226;
    FUN_0151f7f0();
  }
  piStack_7c = &iStack_20;
  pcStack_80 = (char *)0xb2d232;
  FUN_00587490();
  iVar3 = param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (iStack_20 != 0) {
    piStack_7c = (int *)0xb2d248;
    uVar4 = FUN_0088daf0();
    *(undefined4 *)(iVar3 + 0x1a0) = uVar4;
    piStack_7c = (int *)0xb2d253;
    iVar5 = FUN_005c9ef0();
    iVar2 = *(int *)(iVar3 + 0x1a4);
    if (iVar2 == iVar5) {
      *(undefined *)(iVar3 + 0x1a8) = 0;
    }
    else {
      if (iVar2 != 0) {
        piStack_7c = (int *)(iVar3 + 0x1a8);
        pcStack_80 = (char *)0xb2d278;
        (**(code **)(iVar2 + 8))();
      }
      *(undefined *)(iVar3 + 0x1a8) = 0;
      *(int *)(iVar3 + 0x1a4) = iVar5;
    }
    piStack_7c = (int *)0x1;
    uStack_14 = CONCAT31(uStack_14._1_3_,DAT_01eee1b9);
    uStack_a0 = 0;
    FUN_006d07c0(&param_3);
    FUN_00b137b0(auStack_b8,FUN_00b2d590,uStack_14);
    FUN_00b10a50();
    uStack_a0 = 0xb2d2d2;
    FUN_0090ca30();
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      piStack_7c = (int *)0xb2d2eb;
      (**(code **)*piStack_1c)();
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_7c = (int *)0xb2d2fb;
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      piStack_7c = (int *)0xb2d30f;
      (**(code **)(*param_2 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  piStack_7c = (int *)0xb2d31b;
  FUN_00577b20();
  if (0xf < in_stack_00000034) {
    piStack_7c = (int *)(in_stack_00000034 + 1);
    puVar7 = param_8;
    if (0xfff < piStack_7c) {
      puVar7 = (undefined4 *)param_8[-1];
      piStack_7c = (int *)(in_stack_00000034 + 0x24);
      if (0x1f < (uint)((int)param_8 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        piStack_7c = (int *)&UNK_00b2d365;
        FUN_017167a3();
      }
    }
    puStack_84 = (uint *)0xb2d348;
    pcStack_80 = (char *)puVar7;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23691 ; VA 0x00b2d370 ; FUN_00b2d370 */

void FUN_00b2d370(undefined4 param_1,int *param_2,int param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,uint param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  undefined auStack_bc [8];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  int *piStack_ac;
  undefined4 uStack_a4;
  undefined4 uStack_9c;
  undefined *puStack_98;
  undefined auStack_94 [8];
  undefined4 uStack_8c;
  undefined *puStack_88;
  char *pcStack_84;
  int *piStack_80;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_3;
  puStack_c = &LAB_017f0f30;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  iVar2 = *(int *)(param_3 + 0x1a0);
  piStack_80 = (int *)0xb2d3a3;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0088daf0();
  if (iVar2 == iVar4) {
    pcVar5 = (char *)(iVar3 + 0x1a8);
    if (*(int *)(iVar3 + 0x1a4) == 0) {
      pcVar5 = (char *)0x0;
    }
    uStack_14 = CONCAT31(uStack_14._1_3_,*pcVar5);
    if (*pcVar5 == (char)param_8) {
      piStack_80 = &iStack_20;
      pcStack_84 = (char *)0xb2d3d9;
      FUN_00587490();
      uStack_8._0_1_ = 2;
      if (iStack_20 != 0) {
        piStack_80 = (int *)0x1;
        uStack_14 = CONCAT31(uStack_14._1_3_,DAT_01eee1b9);
        uStack_a4 = 0;
        FUN_006d07c0(&param_3);
        FUN_00b137b0(auStack_bc,FUN_00b2d590,uStack_14);
        FUN_00b10a50();
        uStack_a4 = 0xb2d42d;
        FUN_0090ca30();
      }
      uStack_8._0_1_ = 1;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar2 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_80 = (int *)0xb2d447;
          (**(code **)*piStack_1c)();
          LOCK();
          iVar2 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            piStack_80 = (int *)0xb2d457;
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      piStack_80 = (int *)((param_7 & 0xff) * 2);
      pcStack_84 = (char *)0xb2d465;
      FUN_00b30af0();
    }
    else {
      puStack_18 = auStack_94;
      puStack_98 = &DAT_01d66efc;
      uStack_9c = 0xb2d47f;
      FUN_0054ef60();
      puStack_98 = (undefined *)param_7;
      piStack_ac = &param_3;
      uStack_8._0_1_ = 3;
      uStack_9c = param_6;
      uStack_b0 = 0xb2d497;
      FUN_006d07c0();
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      uStack_b0 = param_1;
      piStack_ac = param_2;
      uStack_8._0_1_ = 1;
      uStack_b4 = 0xb2d4c8;
      FUN_00b2d150();
      if (0 < DAT_01d66e28) {
        piStack_80 = (int *)0x0;
        pcStack_84 = (char *)0x0;
        puStack_88 = (undefined *)0xffffffff;
        uStack_8c = 0xb2d4e2;
        FUN_0151f6f0();
        piStack_80 = (int *)uStack_14;
        uStack_8._0_1_ = 4;
        pcStack_84 = "isPurchase";
        puStack_88 = (undefined *)0xb2d4f6;
        FUN_0151fcf0();
        piStack_80 = (int *)param_8;
        pcStack_84 = "isOwner";
        puStack_88 = (undefined *)0xb2d506;
        FUN_0151fcf0();
        iVar2 = DAT_01d66e28;
        piStack_80 = (int *)0x1c;
        pcStack_84 = "purchaseVerificationMismatch";
        uStack_28 = 0;
        uStack_24 = 0xf;
        auStack_38[0] = 0;
        puStack_88 = (undefined *)0xb2d52d;
        FUN_005542c0();
        piStack_80 = (int *)0x0;
        pcStack_84 = (char *)iVar2;
        puStack_88 = auStack_38;
        uStack_8._0_1_ = 5;
        uStack_8c = 0xb2d540;
        FUN_01520d20();
        piStack_80 = (int *)0xb2d548;
        FUN_005507b0();
        piStack_80 = (int *)0xb2d550;
        FUN_0151f7f0();
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_80 = (int *)0xb2d564;
        (**(code **)(*param_2 + 4))();
      }
    }
    uStack_8 = 6;
    piStack_80 = (int *)0xb2d573;
    FUN_00577b20();
    ExceptionList = pvStack_10;
    return;
  }
  piStack_80 = (int *)0x18c072c;
                    /* WARNING: Subroutine does not return */
  pcStack_84 = &UNK_00b2d58e;
  FUN_016757c0();
}



/* FUNCTION 23692 ; VA 0x00b2d590 ; FUN_00b2d590 */

void FUN_00b2d590(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  char in_stack_00000018;
  undefined *puVar6;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0f48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eadd74,&LAB_00670c50);
  uVar2 = FUN_00675b30();
  piVar3 = (int *)FUN_008aa140(uVar2);
  if (*piVar3 == 0) {
    if (DAT_01eee3dc == 0) {
      iVar4 = FUN_00b12040();
      DAT_01eee3dc = *(int *)(iVar4 + 4);
    }
    piVar5 = (int *)FUN_008a9ba0(auStack_18,DAT_01eee3dc);
    iVar4 = *piVar5;
    iVar1 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar3 = iVar4;
    piVar5 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = piVar5[1] + -1;
      piVar5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar4 = piVar5[2] + -1;
        piVar5[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_14[1] + -1;
      piStack_14[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar5 = piStack_14 + 2;
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  if (*piVar3 != 0) {
    if (in_stack_00000018 == '\0') {
      puVar6 = &DAT_0212b100;
    }
    else {
      puVar6 = &DAT_0212b318;
    }
    FUN_009cba80(puVar6,&stack0x00000008,&stack0x00000014);
  }
  uStack_8 = 1;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23693 ; VA 0x00b2d6c0 ; FUN_00b2d6c0 */

int FUN_00b2d6c0(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_178 [252];
  undefined uStack_7c;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0ff1;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffe74;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00587490(&iStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_38 != 0) {
    uStack_6c = 0;
    uStack_68 = 0xf;
    uStack_7c = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (*(int *)(iStack_38 + 0x1b0) != 0) {
      iStack_20 = 0xffffffff;
      uStack_24 = 0xffffffff;
      uStack_8._0_1_ = 5;
      uStack_40 = 0;
      uStack_3c = 0xf;
      auStack_50[0] = 0;
      FUN_005542c0("CurrencyType",0xc);
      uStack_8._0_1_ = 6;
      piVar3 = (int *)FUN_0091d440(auStack_50);
      iStack_18 = *piVar3;
      iVar2 = FUN_00b31840();
      if (iStack_18 == iVar2) {
        iStack_18 = *piVar3;
        iVar2 = FUN_00b31840();
        if (iStack_18 != iVar2) {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Variant cast failed");
        }
        piVar4 = piVar3 + 2;
        if (piVar3[1] == 0) {
          piVar4 = (int *)0x0;
        }
        iVar2 = *piVar4;
        iStack_30 = iVar2;
      }
      else {
        if ((undefined4 *)piVar3[1] != (undefined4 *)0x0) {
          (**(code **)piVar3[1])(piVar3 + 2,auStack_178);
        }
        iVar1 = piVar3[1];
        uStack_8._0_1_ = 7;
        piVar3 = (int *)FUN_00b14bf0();
        iVar2 = *piVar3;
        uStack_8._0_1_ = 8;
        iStack_30 = iVar2;
        if (iVar1 != 0) {
          (**(code **)(iVar1 + 8))(auStack_178);
        }
      }
      uStack_8._0_1_ = 5;
      iStack_20 = iVar2;
      FUN_005507b0();
      uStack_40 = 0;
      uStack_3c = 0xf;
      auStack_50[0] = 0;
      FUN_005542c0("CurrencySpent",0xd);
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      piVar3 = (int *)FUN_0091d440(auStack_50);
      iStack_18 = *piVar3;
      iVar2 = FUN_0088c8c0();
      if (iStack_18 != iVar2) {
        if ((undefined4 *)piVar3[1] != (undefined4 *)0x0) {
          (**(code **)piVar3[1])(piVar3 + 2,auStack_178);
        }
        iVar2 = piVar3[1];
        uStack_8._0_1_ = 10;
        puVar5 = (undefined4 *)FUN_00889220();
        iStack_20 = *puVar5;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
        if (iVar2 != 0) {
          (**(code **)(iVar2 + 8))(auStack_178);
        }
        FUN_005507b0();
        iVar2 = FUN_00b2d90c();
        return iVar2;
      }
      iStack_18 = *piVar3;
      iVar2 = FUN_0088c8c0();
      if (iStack_18 != iVar2) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar4 = piVar3 + 2;
      if (piVar3[1] == 0) {
        piVar4 = (int *)0x0;
      }
      iStack_20 = *piVar4;
      FUN_005507b0();
      iVar2 = FUN_00b2d90c();
      return iVar2;
    }
    iVar2 = FUN_005507b0();
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_34 + 1;
    iVar1 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar3 = piStack_34 + 2;
      iVar1 = *piVar3;
      iVar2 = *piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar2 = (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 2;
    iVar1 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar2 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar3 = param_4 + 1;
    iVar1 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar2 = (**(code **)*param_4)();
      LOCK();
      piVar3 = param_4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar2 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 23694 ; VA 0x00b2d8f7 ; Catch@00b2d8f7 */

undefined * Catch_00b2d8f7(void)

{
  return &DAT_00b2d8fd;
}



/* FUNCTION 23695 ; VA 0x00b2d90c ; FUN_00b2d90c */

int FUN_00b2d90c(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  byte bVar4;
  uint *puVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  int unaff_EBP;
  int iVar11;
  int unaff_EDI;
  int *piStack_68;
  undefined4 uStack_64;
  uint uStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  undefined auStack_40 [28];
  undefined4 uStack_24;
  undefined auStack_20 [12];
  undefined4 uStack_14;
  int iStack_10;
  int iStack_c;
  char *pcStack_8;
  uint uStack_4;
  
  uStack_4 = 10;
  pcStack_8 = "PurchaseId";
  *(undefined4 *)(unaff_EBP + -4) = 4;
  *(undefined4 *)(unaff_EBP + -0x3c) = 0;
  *(undefined4 *)(unaff_EBP + -0x38) = 0xf;
  *(undefined *)(unaff_EBP + -0x4c) = 0;
  iStack_c = 0xb2d937;
  FUN_005542c0();
  uStack_4 = unaff_EBP + -0x4c;
  *(undefined *)(unaff_EBP + -4) = 0xd;
  pcStack_8 = (char *)0xb2d946;
  FUN_0091d440();
  uStack_4 = unaff_EBP + -0x90;
  pcStack_8 = (char *)0xb2d954;
  puVar10 = (undefined4 *)FUN_00563690();
  if ((undefined4 *)(unaff_EBP + -0x78) != puVar10) {
    uStack_4 = 0xb2d964;
    FUN_005507b0();
    uVar7 = puVar10[1];
    uVar8 = puVar10[2];
    uVar9 = puVar10[3];
    *(undefined4 *)(unaff_EBP + -0x78) = *puVar10;
    *(undefined4 *)(unaff_EBP + -0x74) = uVar7;
    *(undefined4 *)(unaff_EBP + -0x70) = uVar8;
    *(undefined4 *)(unaff_EBP + -0x6c) = uVar9;
    *(undefined8 *)(unaff_EBP + -0x68) = *(undefined8 *)(puVar10 + 4);
    puVar10[4] = 0;
    puVar10[5] = 0xf;
    *(undefined *)puVar10 = 0;
  }
  uStack_4 = 0xb2d991;
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 4;
  uStack_4 = 0xb2d99d;
  FUN_005507b0();
  uStack_4 = 0xe;
  pcStack_8 = "RRReceiptTotal";
  *(undefined4 *)(unaff_EBP + -0x3c) = 0;
  *(undefined4 *)(unaff_EBP + -0x38) = 0xf;
  *(undefined *)(unaff_EBP + -0x4c) = 0;
  iStack_c = 0xb2d9be;
  FUN_005542c0();
  uStack_4 = 0;
  iStack_c = unaff_EBP + -0x4c;
  *(undefined *)(unaff_EBP + -4) = 0xe;
  pcStack_8 = (char *)0x1;
  iStack_10 = 0xb2d9cf;
  FUN_008783f0();
  *(undefined *)(unaff_EBP + -4) = 4;
  uStack_4 = 0xb2d9de;
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -0x24) = 0;
  *(int *)(unaff_EBP + -0x28) = unaff_EDI + 0x88;
  uStack_4 = 0xb2d9f3;
  FUN_00587410();
  bVar4 = *(byte *)(unaff_EDI + 0x90);
  uStack_4 = unaff_EBP + -0x78;
  *(undefined *)(unaff_EBP + -4) = 0xf;
  iVar11 = bVar4 + 0x91 + unaff_EDI;
  iStack_c = 0xb2da10;
  pcStack_8 = (char *)iVar11;
  iStack_c = FUN_0055c740();
  uStack_4 = -(uint)(iVar11 != 0) & iVar11 + 1U;
  pcStack_8 = (char *)(unaff_EBP + -0x78);
  iStack_10 = unaff_EBP + -0x20;
  uStack_14 = 0xb2da31;
  FUN_00562fc0();
  if (*(int *)(unaff_EBP + -0x20) != 0) {
    *(undefined *)(unaff_EBP + -4) = 0x10;
    if (*(char *)(unaff_EBP + -0x24) != '\0') {
      puVar5 = *(uint **)(unaff_EBP + -0x28);
      LOCK();
      uVar2 = *puVar5;
      *puVar5 = *puVar5 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puVar5;
        *puVar5 = *puVar5 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uStack_4 = 0xb2da6b;
          uStack_4 = FUN_00554e40();
          pcStack_8 = (char *)0xb2da72;
          SetEvent();
        }
      }
    }
    uStack_4 = 0xd;
    pcStack_8 = "RRReceiptFail";
    *(undefined *)(unaff_EBP + -4) = 4;
    *(undefined4 *)(unaff_EBP + -0x3c) = 0;
    *(undefined4 *)(unaff_EBP + -0x38) = 0xf;
    *(undefined *)(unaff_EBP + -0x4c) = 0;
    iStack_c = 0xb2da97;
    FUN_005542c0();
    uStack_4 = 0;
    iStack_c = unaff_EBP + -0x4c;
    *(undefined *)(unaff_EBP + -4) = 0x12;
    pcStack_8 = (char *)0x1;
    iStack_10 = 0xb2daa8;
    FUN_008783f0();
    *(undefined *)(unaff_EBP + -4) = 4;
    uStack_4 = 0xb2dab7;
    FUN_005507b0();
    uStack_4 = unaff_EBP + -0x78;
    if (0xf < *(uint *)(unaff_EBP + -100)) {
      uStack_4 = *(int *)(unaff_EBP + -0x78);
    }
    pcStack_8 = "ReceiptId %s already being processed.";
    iStack_c = 3;
    iStack_10 = 0xb2dacf;
    FUN_0086f2f0();
    uStack_4 = 0xb2dada;
    FUN_005507b0();
    uStack_4 = 0xb2dae2;
    FUN_00550b30();
    piVar6 = *(int **)(unaff_EBP + 0xc);
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar11 = piVar6[2] + -1;
      piVar6[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        uStack_4 = 0xb2daf8;
        (**(code **)(*piVar6 + 4))();
      }
    }
    uStack_4 = 0xb2db00;
    iVar11 = FUN_00550b30();
    ExceptionList = *(void **)(unaff_EBP + -0xc);
    return iVar11;
  }
  pcStack_8 = (char *)(unaff_EBP + -0x78);
  iStack_c = unaff_EBP + -0xac;
  iStack_10 = 0xb2db28;
  uStack_4 = (uint)pcStack_8;
  FUN_00676530();
  *(undefined *)(unaff_EBP + -4) = 0x11;
  if (*(char *)(unaff_EBP + -0x24) != '\0') {
    puVar5 = *(uint **)(unaff_EBP + -0x28);
    LOCK();
    uVar2 = *puVar5;
    *puVar5 = *puVar5 + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puVar5;
      *puVar5 = *puVar5 | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        uStack_4 = 0xb2db58;
        uStack_4 = FUN_00554e40();
        pcStack_8 = (char *)0xb2db5f;
        SetEvent();
      }
    }
  }
  *(undefined *)(unaff_EBP + -4) = 4;
  *(undefined **)(unaff_EBP + -0x24) = auStack_20;
  *(int *)(unaff_EBP + -0xa8) = unaff_EDI + 0x1b0;
  bVar4 = DAT_01eee1b9;
  uStack_24 = 0;
  *(byte *)(unaff_EBP + -0x18) = DAT_01eee1b9;
  *(undefined4 **)(unaff_EBP + -0x20) = &uStack_48;
  uStack_4c = (uint)bVar4;
  piStack_68 = (int *)(unaff_EBP + -0x78);
  FUN_0054ef60();
  if (*(int *)(unaff_EBP + 0xc) != 0) {
    LOCK();
    piVar6 = (int *)(*(int *)(unaff_EBP + 0xc) + 8);
    *piVar6 = *piVar6 + 1;
    UNLOCK();
  }
  piStack_68 = *(int **)(unaff_EBP + 0xc);
  FUN_00b13f20(*(undefined4 *)(unaff_EBP + -0x20),FUN_00b2ed60);
  uStack_4c = 0xb2dbd8;
  FUN_00b111c0();
  *(undefined *)(unaff_EBP + -4) = 0x13;
  *(undefined **)(unaff_EBP + -0x14) = auStack_40;
  piStack_68 = (int *)(unaff_EBP + -0x78);
  iStack_44 = *(undefined4 *)(unaff_EBP + -0x18);
  uStack_48 = *(undefined4 *)(unaff_EBP + -0x1c);
  uStack_4c = *(undefined4 *)(unaff_EBP + -0x2c);
  FUN_0054ef60();
  piVar6 = *(int **)(unaff_EBP + -0x30);
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
  }
  piStack_68 = piVar6;
  FUN_00b139a0(unaff_EBP + -0x60,FUN_00b2de10);
  iVar11 = *(int *)(unaff_EBP + -0x58);
  *(undefined4 *)(unaff_EBP + -0xa4) = *(undefined4 *)(unaff_EBP + -0x60);
  *(int *)(unaff_EBP + -0x18) = unaff_EBP + -0xa0;
  *(undefined4 *)(unaff_EBP + -0xa0) = 0;
  *(undefined4 *)(unaff_EBP + -0x9c) = 0;
  if (iVar11 != 0) {
    LOCK();
    *(int *)(iVar11 + 4) = *(int *)(iVar11 + 4) + 1;
    UNLOCK();
    iVar11 = *(int *)(unaff_EBP + -0x58);
  }
  *(undefined4 *)(unaff_EBP + -0xa0) = *(undefined4 *)(unaff_EBP + -0x5c);
  *(int *)(unaff_EBP + -0x9c) = iVar11;
  iStack_44 = unaff_EBP + -0x54;
  *(undefined *)(unaff_EBP + -4) = 0x15;
  uStack_48 = 0xb2dc82;
  FUN_0054ef60();
  *(undefined4 *)(unaff_EBP + -0x80) = *(undefined4 *)(unaff_EBP + -0x3c);
  *(undefined4 *)(unaff_EBP + -0x7c) = *(undefined4 *)(unaff_EBP + -0x38);
  *(undefined **)(unaff_EBP + -0x18) = &stack0xffffff94;
  *(int ***)(unaff_EBP + -0x18) = &piStack_68;
  **(undefined4 **)(unaff_EBP + -0x14) = 0;
  if (*(int *)(unaff_EBP + -0x9c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(unaff_EBP + -0x9c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piStack_68 = *(int **)(unaff_EBP + -0xa0);
  uStack_64 = *(undefined4 *)(unaff_EBP + -0x9c);
  *(undefined *)(unaff_EBP + -4) = 0x17;
  FUN_0054ef60(unaff_EBP + -0x98);
  uStack_48 = *(undefined4 *)(unaff_EBP + -0x80);
  iStack_44 = *(undefined4 *)(unaff_EBP + -0x7c);
  *(undefined *)(unaff_EBP + -4) = 0x16;
  FUN_00b12800();
  iStack_44 = 0xb2dd0f;
  FUN_006511a0();
  *(undefined *)(unaff_EBP + -4) = 0x13;
  iStack_44 = 0xb2dd1b;
  FUN_006511a0();
  if (*(int *)(unaff_EBP + 0x14) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(unaff_EBP + 0x14) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_48 = *(undefined4 *)(unaff_EBP + 0x10);
  iStack_44 = *(undefined4 *)(unaff_EBP + 0x14);
  *(undefined *)(unaff_EBP + -4) = 4;
  uStack_4c = 0xb2dd52;
  FUN_00b1afd0();
  uStack_4 = 0xb2dd5a;
  iVar11 = FUN_005507b0();
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar1 = piVar6 + 1;
    iVar3 = *piVar1;
    iVar11 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      uStack_4 = 0xb2dd94;
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1;
      iVar11 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        uStack_4 = 0xb2dda4;
        iVar11 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = *(int **)(unaff_EBP + 0xc);
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar1 = piVar6 + 2;
    iVar3 = *piVar1;
    iVar11 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      uStack_4 = 0xb2ddb9;
      iVar11 = (**(code **)(*piVar6 + 4))();
    }
  }
  piVar6 = *(int **)(unaff_EBP + 0x14);
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar1 = piVar6 + 1;
    iVar3 = *piVar1;
    iVar11 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      uStack_4 = 0xb2ddcf;
      iVar11 = (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uStack_4 = 0xb2ddde;
        iVar11 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return iVar11;
}



/* FUNCTION 23696 ; VA 0x00b2dd5c ; Catch@00b2dd5c */

undefined4 Catch_00b2dd5c(void)

{
  int unaff_EBP;
  
  FUN_00b305b0(unaff_EBP + -0x78);
  return 0xb2dd6e;
}



/* FUNCTION 23697 ; VA 0x00b2de10 ; FUN_00b2de10 */

int FUN_00b2de10(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  int *in_stack_00000030;
  int *piStack_a8;
  int iStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  uint uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined auStack_80 [28];
  undefined4 uStack_64;
  undefined auStack_60 [20];
  undefined4 uStack_4c;
  int *piStack_48;
  undefined4 *puStack_44;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined *puStack_28;
  undefined *puStack_24;
  code *pcStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1030;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc0;
  iVar7 = 0;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  puVar4 = &stack0xffffffc0;
  if ((in_stack_0000002c[1] - *in_stack_0000002c) / 0xd0 == 1) {
    puStack_44 = (undefined4 *)0xb2de65;
    ExceptionList = &pvStack_10;
    iVar7 = FUN_00b15320();
    puVar4 = puStack_14;
  }
  puStack_14 = puVar4;
  uStack_8 = 2;
  if (iVar7 == 1) {
    puStack_44 = (undefined4 *)auStack_34;
    piStack_48 = (int *)0xb2de83;
    puVar5 = (undefined4 *)FUN_00b264d0();
    piStack_1c = (int *)*puVar5;
    puStack_24 = auStack_60;
    uStack_64 = 0;
    uStack_8._0_1_ = 5;
    pcStack_20 = *(code **)(*piStack_1c + 0x14);
    uStack_8c = (uint)DAT_01eee1b9;
    piStack_a8 = (int *)&param_3;
    uStack_18 = CONCAT31((int3)((uint)param_1 >> 8),*(undefined *)(param_1 + 0x74));
    FUN_0054ef60();
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[2] = param_2[2] + 1;
      UNLOCK();
    }
    piStack_a8 = param_2;
    FUN_00b13f20(&uStack_88,FUN_00b2ed60,param_1);
    uStack_8c = 0xb2df01;
    FUN_00b111c0();
    puStack_28 = auStack_80;
    uStack_8._0_1_ = 6;
    uStack_84 = 0;
    FUN_0054ef60(&param_3);
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[2] = param_2[2] + 1;
      UNLOCK();
    }
    FUN_00b13f20(&piStack_a8,FUN_00b2ee70,param_1,param_2);
    FUN_00b111c0();
    uStack_84 = in_stack_00000028;
    piStack_a8 = (int *)&param_3;
    if (0xf < in_stack_00000020) {
      piStack_a8 = param_3;
    }
    uStack_88 = in_stack_00000024;
    uStack_8._0_1_ = 7;
    uStack_90 = 0;
    uStack_8c = 0xf;
    uStack_a0 = 0;
    piVar6 = piStack_a8;
    do {
      cVar3 = *(char *)piVar6;
      piVar6 = (int *)((int)piVar6 + 1);
    } while (cVar3 != '\0');
    iStack_a4 = (int)piVar6 - (int)((int)piStack_a8 + 1);
    FUN_005542c0();
    iStack_a4 = uStack_18;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    piStack_a8 = (int *)0xb2dfad;
    iVar7 = (*pcStack_20)();
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piVar6 = piStack_30 + 1;
      iVar2 = *piVar6;
      iVar7 = *piVar6;
      *piVar6 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_44 = (undefined4 *)0xb2dfc6;
        (**(code **)*piStack_30)();
        LOCK();
        piVar6 = piStack_30 + 2;
        iVar2 = *piVar6;
        iVar7 = *piVar6;
        *piVar6 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          puStack_44 = (undefined4 *)0xb2dfd6;
          iVar7 = (**(code **)(*piStack_30 + 4))();
        }
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      piVar6 = param_2 + 1;
      iVar2 = *piVar6;
      iVar7 = *piVar6;
      *piVar6 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_44 = (undefined4 *)0xb2dfec;
        (**(code **)*param_2)();
        LOCK();
        piVar6 = param_2 + 2;
        iVar2 = *piVar6;
        iVar7 = *piVar6;
        *piVar6 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          puStack_44 = (undefined4 *)0xb2dffc;
          iVar7 = (**(code **)(*param_2 + 4))();
        }
      }
    }
    if (in_stack_00000020 < 0x10) goto LAB_00b2e0ae;
    puStack_44 = (undefined4 *)(in_stack_00000020 + 1);
    piVar6 = param_3;
    if (0xfff < puStack_44) {
      piVar6 = (int *)param_3[-1];
      puStack_44 = (undefined4 *)(in_stack_00000020 + 0x24);
      if ((char *)0x1f < (char *)((int)param_3 + (-4 - (int)piVar6))) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)0xb2e0fb;
        FUN_017167a3();
      }
    }
  }
  else {
    puStack_44 = &param_3;
    piStack_48 = (int *)0xb2e055;
    iVar7 = FUN_00b305b0();
    if (param_2 != (int *)0x0) {
      LOCK();
      piVar6 = param_2 + 1;
      iVar2 = *piVar6;
      iVar7 = *piVar6;
      *piVar6 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_44 = (undefined4 *)0xb2e06e;
        (**(code **)*param_2)();
        LOCK();
        piVar6 = param_2 + 2;
        iVar2 = *piVar6;
        iVar7 = *piVar6;
        *piVar6 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          puStack_44 = (undefined4 *)0xb2e07e;
          iVar7 = (**(code **)(*param_2 + 4))();
        }
      }
    }
    if (in_stack_00000020 < 0x10) goto LAB_00b2e0ae;
    puStack_44 = (undefined4 *)(in_stack_00000020 + 1);
    piVar6 = param_3;
    if (0xfff < puStack_44) {
      piVar6 = (int *)param_3[-1];
      puStack_44 = (undefined4 *)(in_stack_00000020 + 0x24);
      if ((char *)0x1f < (char *)((int)param_3 + (-4 - (int)piVar6))) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)&UNK_00b2e100;
        FUN_017167a3();
      }
    }
  }
  uStack_4c = 0xb2e0ab;
  piStack_48 = piVar6;
  iVar7 = FUN_01674ea0();
LAB_00b2e0ae:
  piVar6 = in_stack_00000030;
  param_3 = (int *)((uint)param_3 & 0xffffff00);
  in_stack_00000020 = 0xf;
  in_stack_0000001c = 0;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000030 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_44 = (undefined4 *)0xb2e0d6;
      iVar7 = (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_44 = (undefined4 *)0xb2e0e5;
        iVar7 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 23698 ; VA 0x00b2e030 ; Catch@00b2e030 */

undefined * Catch_00b2e030(void)

{
  int unaff_EBP;
  
  FUN_00b305b0(unaff_EBP + 0x10);
  return &DAT_00b2e042;
}



/* FUNCTION 23699 ; VA 0x00b2e110 ; FUN_00b2e110 */

void __fastcall FUN_00b2e110(int param_1)

{
  char cVar1;
  undefined auStack_10 [12];
  
  cVar1 = FUN_00971ce0(param_1,1);
  if (cVar1 != '\0') {
    *(undefined *)(param_1 + 0x74) = 1;
    return;
  }
  FUN_00b1a2e0(0);
  FUN_016756b0(auStack_10,"Can only register ProcessReceipt callback on server");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 23700 ; VA 0x00b2e160 ; FUN_00b2e160 */

void __thiscall FUN_00b2e160(int param_1,int *param_2,undefined **param_3,uint *param_4)

{
  uint uVar1;
  undefined *puVar2;
  undefined *puVar3;
  undefined **ppuVar4;
  void **ppvVar5;
  char cVar6;
  int iVar7;
  char *pcVar8;
  uint *puVar9;
  undefined4 *puVar10;
  int iVar11;
  int *piVar12;
  int iVar13;
  undefined **ppuVar14;
  undefined *puVar15;
  undefined **ppuVar16;
  bool bVar17;
  undefined8 uVar18;
  undefined4 uStack_b8;
  undefined **ppuStack_b4;
  undefined4 uStack_ac;
  undefined8 *puStack_a8;
  uint uStack_a4;
  undefined *puStack_a0;
  undefined *puStack_9c;
  undefined *puStack_98;
  uint auStack_94 [2];
  int *piStack_8c;
  undefined4 uStack_88;
  undefined **ppuStack_84;
  undefined4 uStack_78;
  uint uStack_74;
  undefined *puStack_70;
  uint uStack_6c;
  undefined4 uStack_68;
  int *piStack_64;
  int *piStack_60;
  undefined **ppuStack_5c;
  uint *puStack_58;
  int aiStack_44 [2];
  int aiStack_3c [2];
  undefined8 uStack_34;
  undefined *puStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  uint uStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  ppuVar16 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f10a8;
  pvStack_10 = ExceptionList;
  iStack_14 = param_1;
  if (param_2 == (int *)&DAT_0212b100) {
    if (((int)param_3[1] - (int)*param_3) / 0xd0 != 3) {
      return;
    }
    iVar11 = *(int *)*param_3;
    puStack_58 = (uint *)0xb2e1bc;
    ExceptionList = &pvStack_10;
    iVar7 = FUN_0088cdc0();
    if (iVar11 != iVar7) {
      ExceptionList = pvStack_10;
      return;
    }
    iVar11 = *(int *)(*param_3 + 0xd0);
    puStack_58 = (uint *)0xb2e1d4;
    iVar7 = FUN_0088da50();
    if (iVar11 != iVar7) {
      ExceptionList = pvStack_10;
      return;
    }
    iVar11 = *(int *)(*param_3 + 0x1a0);
    puStack_58 = (uint *)0xb2e1ec;
    iVar7 = FUN_0088daf0();
    if (iVar11 != iVar7) {
      ExceptionList = pvStack_10;
      return;
    }
    puStack_58 = param_4;
    piStack_64 = (int *)0xb2e206;
    piStack_64 = (int *)FUN_00605c00();
    uStack_68 = 0xb2e20e;
    FUN_00557fc0();
    piStack_64 = (int *)&uStack_34;
    uStack_68 = 0xb2e217;
    FUN_00c5f480();
    ppuVar16 = param_3;
    uStack_8 = 0;
    if ((int)uStack_34 != 0) {
      puStack_58 = (uint *)0xb2e23b;
      pcVar8 = (char *)FUN_00605c60();
      if (*pcVar8 == '\0') {
        puStack_58 = param_4;
        ppuStack_5c = ppuVar16;
        piStack_60 = param_2;
        piStack_64 = (int *)0xb2e24e;
        FUN_009cba80();
        puStack_58 = (uint *)0xb2e256;
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)iStack_14;
      ppuStack_5c = (undefined **)0xb2e270;
      ppuStack_5c = (undefined **)FUN_008f7870();
      piStack_60 = aiStack_3c;
      piStack_64 = (int *)0xb2e27a;
      FUN_005e5de0();
      uStack_8._0_1_ = 1;
      puStack_58 = (uint *)0xb2e289;
      cVar6 = FUN_0091eb80();
      if (cVar6 == '\0') {
        uVar1 = *param_4;
        puStack_70 = &DAT_01d66ee4;
        uStack_74 = 0xb2e2a4;
        param_4 = &uStack_6c;
        FUN_0054ef60();
        puStack_70 = (undefined *)0x0;
        uStack_8._0_1_ = 2;
        ppuStack_84 = param_3;
        uStack_88 = 0xb2e2b8;
        uStack_74 = uVar1;
        FUN_006d07c0();
        piStack_8c = aiStack_3c;
        auStack_94[1] = 0xb2e2c6;
        FUN_005587b0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        piStack_8c = (int *)0xb2e2cf;
        FUN_00b2d150();
      }
      else {
        puStack_58 = (uint *)0xb2e2e4;
        puVar9 = (uint *)FUN_0055d6a0();
        puStack_2c = (undefined *)&uStack_74;
        puStack_18 = (undefined *)*puVar9;
        puStack_1c = (undefined *)puVar9[1];
        uStack_78 = 0;
        uStack_a4 = *param_4;
        puStack_9c = (undefined *)(uint)DAT_01eee1b9;
        puStack_a0 = (undefined *)0x0;
        ppuStack_b4 = param_3;
        uStack_b8 = 0xb2e320;
        param_4 = &uStack_74;
        FUN_006d07c0();
        FUN_005587b0(aiStack_3c);
        FUN_00b13b60(&puStack_98,FUN_00b2d150);
        puStack_9c = (undefined *)0xb2e344;
        FUN_00b10ea0();
        param_4 = auStack_94;
        uStack_8._0_1_ = 4;
        puStack_98 = (undefined *)0x0;
        FUN_006d07c0(param_3);
        FUN_005587b0(aiStack_3c);
        FUN_00b13b60(&uStack_b8,FUN_00b2d370);
        FUN_00b10ce0();
        puStack_98 = puStack_1c;
        puStack_a8 = &uStack_34;
        puStack_9c = puStack_18;
        uStack_ac = 0xb2e3a0;
        FUN_00557fc0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        puStack_a8 = (undefined8 *)0xb2e3ac;
        FUN_00b2cf60();
      }
      puStack_58 = (uint *)0xb2e3b4;
      FUN_0056c200();
    }
    puStack_58 = (uint *)0xb2e3bc;
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return;
  }
  if (param_2 == (int *)&DAT_0212b318) {
    if (((int)param_3[1] - (int)*param_3) / 0xd0 != 3) {
      return;
    }
    iVar11 = *(int *)*param_3;
    puStack_58 = (uint *)0xb2e405;
    ExceptionList = &pvStack_10;
    iVar7 = FUN_0088cdc0();
    if (iVar11 != iVar7) {
      ExceptionList = pvStack_10;
      return;
    }
    iVar11 = *(int *)(*param_3 + 0xd0);
    puStack_58 = (uint *)0xb2e41d;
    iVar7 = FUN_0088da50();
    if (iVar11 != iVar7) {
      ExceptionList = pvStack_10;
      return;
    }
    iVar11 = *(int *)(*param_3 + 0x1a0);
    puStack_58 = (uint *)0xb2e435;
    iVar7 = FUN_0088daf0();
    if (iVar11 != iVar7) {
      ExceptionList = pvStack_10;
      return;
    }
    puStack_58 = param_4;
    piStack_64 = (int *)0xb2e44f;
    piStack_64 = (int *)FUN_00605c00();
    uStack_68 = 0xb2e457;
    FUN_00557fc0();
    piStack_64 = aiStack_3c;
    uStack_68 = 0xb2e460;
    FUN_00c5f480();
    ppuVar16 = param_3;
    uStack_8 = 5;
    if (aiStack_3c[0] != 0) {
      puStack_58 = (uint *)0xb2e484;
      pcVar8 = (char *)FUN_00605c60();
      iVar11 = iStack_14;
      if (*pcVar8 == '\0') {
        puStack_58 = param_4;
        ppuStack_5c = ppuVar16;
        piStack_60 = param_2;
        piStack_64 = (int *)0xb2e497;
        FUN_009cba80();
        puStack_58 = (uint *)0xb2e49f;
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)iStack_14;
      ppuStack_5c = (undefined **)0xb2e4ba;
      ppuStack_5c = (undefined **)FUN_008f7870();
      piStack_60 = aiStack_44;
      piStack_64 = (int *)0xb2e4c4;
      FUN_005e5de0();
      uStack_8._0_1_ = 6;
      puStack_58 = (uint *)0xb2e4d3;
      cVar6 = FUN_0091eb80();
      if (cVar6 == '\0') {
        uVar1 = *param_4;
        puStack_70 = &DAT_01d66ee4;
        uStack_74 = 0xb2e4ee;
        param_4 = &uStack_6c;
        FUN_0054ef60();
        puStack_70 = (undefined *)0x1;
        uStack_8._0_1_ = 7;
        ppuStack_84 = param_3;
        uStack_88 = 0xb2e502;
        uStack_74 = uVar1;
        FUN_006d07c0();
        piStack_8c = aiStack_44;
        auStack_94[1] = 0xb2e510;
        FUN_005587b0();
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        piStack_8c = (int *)0xb2e519;
        FUN_00b2d150();
      }
      else {
        puStack_58 = (uint *)0xb2e531;
        puVar9 = (uint *)FUN_0055d6a0();
        puVar15 = (undefined *)*puVar9;
        puVar2 = (undefined *)puVar9[1];
        puStack_58 = (uint *)(iVar11 + 200);
        ppuStack_5c = (undefined **)0xb2e54b;
        puStack_1c = puVar15;
        FUN_00591e70();
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        puStack_58 = (uint *)0xb2e557;
        uStack_34 = FUN_00928340();
        puStack_58 = (uint *)&uStack_34;
        ppuStack_5c = &puStack_18;
        piStack_60 = (int *)0xb2e570;
        FUN_00b244a0();
        puVar3 = puStack_18;
        if ((puStack_18 != (undefined *)0x0) &&
           (puStack_28 = puStack_18 + 0x10, *(int *)(puStack_18 + 0x18) != 0)) {
          puStack_24 = puVar2;
          if (((int)puVar2 < 1) && ((int)puVar2 < 0)) {
            puStack_24 = (undefined *)~(uint)puVar2;
          }
          uStack_20 = *(uint *)(puStack_18 + 0x14);
          puStack_24 = (undefined *)
                       ((uint)(puVar15 + ((uint)puStack_24 >> 2) + (int)puStack_24 * 0x40) ^
                       (uint)puStack_24);
          puVar15 = (undefined *)((uint)puStack_24 % uStack_20);
          puStack_2c = (undefined *)((int)puVar15 * 4);
          ppuVar16 = *(undefined ***)(puStack_2c + *(int *)(puStack_18 + 0x24));
          puStack_18 = puVar15;
          if ((ppuVar16 != (undefined **)0x0) &&
             (ppuVar4 = (undefined **)*ppuVar16, (undefined **)*ppuVar16 != (undefined **)0x0)) {
            while (ppuVar14 = ppuVar4, (undefined *)((uint)ppuVar14[1] % uStack_20) == puVar15) {
              if (((ppuVar14[1] == puStack_24) && (puStack_1c == ppuVar14[2])) &&
                 (puVar2 == ppuVar14[3])) {
                puStack_58 = (uint *)*ppuVar14;
                piStack_60 = (int *)0xb2e61d;
                ppuStack_5c = ppuVar16;
                FUN_00b21830();
                if (*ppuVar16 != (undefined *)0x0) {
                  puVar15 = (undefined *)(*(uint *)(*ppuVar16 + 4) % *(uint *)(puVar3 + 0x14));
                  if (puStack_18 == puVar15) break;
                  *(undefined ***)(*(int *)(puVar3 + 0x24) + (int)puVar15 * 4) = ppuVar16;
                }
                if (*(undefined ***)(puStack_2c + *(int *)(puVar3 + 0x24)) == ppuVar16) {
                  *(undefined4 *)(puStack_2c + *(int *)(puVar3 + 0x24)) = 0;
                }
                break;
              }
              ppuVar4 = (undefined **)*ppuVar14;
              ppuVar16 = ppuVar14;
              if ((undefined **)*ppuVar14 == (undefined **)0x0) break;
            }
          }
        }
        puStack_2c = (undefined *)CONCAT31(puStack_2c._1_3_,DAT_01eee1b9);
        uVar1 = *param_4;
        puStack_28 = (undefined *)CONCAT31(puStack_28._1_3_,DAT_01eee1b9);
        puStack_58 = (uint *)0xb2e65e;
        uVar18 = FUN_00928340();
        puStack_24 = (undefined *)((ulonglong)uVar18 >> 0x20);
        uStack_20 = (uint)uVar18;
        puStack_18 = (undefined *)&uStack_74;
        param_4 = &uStack_74;
        uStack_78 = 0;
        puStack_9c = puStack_2c;
        puStack_a0 = (undefined *)0x1;
        ppuStack_b4 = param_3;
        uStack_b8 = 0xb2e687;
        uStack_a4 = uVar1;
        FUN_006d07c0();
        FUN_005587b0(aiStack_44);
        FUN_00b13b60(&puStack_98,FUN_00b2d150);
        puStack_9c = (undefined *)0xb2e6ab;
        FUN_00b10ea0();
        param_4 = auStack_94;
        uStack_8._0_1_ = 9;
        puStack_98 = (undefined *)0x0;
        FUN_006d07c0(param_3);
        FUN_005587b0(aiStack_44);
        FUN_00b13b60(&uStack_b8,FUN_00b2d370);
        FUN_00b10ce0();
        puStack_9c = puStack_1c;
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        puStack_a0 = puStack_24;
        uStack_a4 = uStack_20;
        puStack_a8 = (undefined8 *)0xb2e70b;
        puStack_98 = puVar2;
        FUN_00b31da0();
        puStack_58 = (uint *)0xb2e713;
        FUN_005923a0();
      }
      puStack_58 = (uint *)0xb2e71b;
      FUN_0056c200();
    }
    puStack_58 = (uint *)0xb2e723;
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return;
  }
  if (param_2 == (int *)&DAT_0212b140) {
    if ((undefined *)0xcf < param_3[1] + (-0x270 - (int)*param_3)) {
      return;
    }
    iVar11 = *(int *)*param_3;
    puStack_58 = (uint *)0xb2e75e;
    ExceptionList = &pvStack_10;
    iVar7 = FUN_0088da50();
    if (iVar11 != iVar7) {
      ExceptionList = pvStack_10;
      return;
    }
    iVar11 = *(int *)(*param_3 + 0xd0);
    puStack_58 = (uint *)0xb2e776;
    iVar7 = FUN_0088da50();
    if (iVar11 != iVar7) {
      ExceptionList = pvStack_10;
      return;
    }
    iVar11 = *(int *)(*param_3 + 0x1a0);
    puStack_58 = (uint *)0xb2e78e;
    iVar7 = FUN_0088daf0();
    if (iVar11 != iVar7) {
      ExceptionList = pvStack_10;
      return;
    }
    puStack_58 = (uint *)0xb2e7a0;
    puVar10 = (undefined4 *)FUN_0055d6a0();
    puStack_58 = (uint *)iStack_14;
    ppuStack_5c = (undefined **)param_4;
    piStack_60 = (int *)puVar10[1];
    piStack_64 = (int *)*puVar10;
    uStack_68 = 0xb2e7b1;
    iVar11 = FUN_00c5f5d0();
LAB_00b2ed2e:
    bVar17 = iVar11 == 0;
LAB_00b2ed30:
    ppvVar5 = (void **)ExceptionList;
    if (bVar17) {
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    if (param_2 == (int *)&DAT_0212b1c8) {
      if (((int)param_3[1] - (int)*param_3) / 0xd0 != 3) {
        return;
      }
      iVar11 = *(int *)*param_3;
      puStack_58 = (uint *)0xb2e7f0;
      ExceptionList = &pvStack_10;
      iVar7 = FUN_0088cdc0();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      iVar11 = *(int *)(*param_3 + 0xd0);
      puStack_58 = (uint *)0xb2e808;
      iVar7 = FUN_0088da50();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      iVar11 = *(int *)(*param_3 + 0x1a0);
      puStack_58 = (uint *)0xb2e820;
      iVar7 = FUN_0088daf0();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = param_4;
      piStack_64 = (int *)0xb2e83a;
      piStack_64 = (int *)FUN_00605c00();
      uStack_68 = 0xb2e842;
      FUN_00557fc0();
      piStack_64 = aiStack_44;
      uStack_68 = 0xb2e84b;
      FUN_00c5f480();
      uStack_8 = 10;
      if (aiStack_44[0] != 0) {
        puStack_58 = (uint *)0x4;
        ppuStack_5c = (undefined **)0xb2e862;
        FUN_00b30af0();
        puStack_58 = param_4;
        ppuStack_5c = param_3;
        piStack_60 = param_2;
        piStack_64 = (int *)0xb2e874;
        FUN_009cba80();
      }
      puStack_58 = (uint *)0xb2e87c;
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return;
    }
    if (param_2 == (int *)&DAT_0212ab38) {
      if ((undefined *)0xcf < param_3[1] + (-0x270 - (int)*param_3)) {
        return;
      }
      iVar11 = *(int *)*param_3;
      puStack_58 = (uint *)0xb2e8bb;
      ExceptionList = &pvStack_10;
      iVar7 = FUN_0088cb40();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      iVar11 = *(int *)(*param_3 + 0xd0);
      puStack_58 = (uint *)0xb2e8d3;
      iVar7 = FUN_0088da50();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      iVar11 = *(int *)(*param_3 + 0x1a0);
      puStack_58 = (uint *)0xb2e8eb;
      iVar7 = FUN_0088da50();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)0xb2e8fd;
      iVar11 = FUN_0055d610();
      if ((DAT_01eee150 < *(uint *)(iVar11 + 0x10)) && (0 < (int)DAT_01eee150)) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)0xb2e91d;
      puVar10 = (undefined4 *)FUN_0055d6a0();
      puStack_58 = (uint *)iStack_14;
      ppuStack_5c = (undefined **)param_4;
      piStack_60 = (int *)puVar10[1];
      piStack_64 = (int *)*puVar10;
      uStack_68 = 0xb2e92e;
      iVar11 = FUN_00c5f5d0();
      if (iVar11 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)0xb2e940;
      cVar6 = FUN_0091eb80();
      bVar17 = cVar6 == '\0';
      goto LAB_00b2ed30;
    }
    if (param_2 == (int *)&DAT_0212b248) {
      if ((undefined *)0xcf < param_3[1] + (-0x1a0 - (int)*param_3)) {
        return;
      }
      iVar11 = *(int *)*param_3;
      puStack_58 = (uint *)0xb2e970;
      ExceptionList = &pvStack_10;
      iVar7 = FUN_0088daf0();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      iVar11 = *(int *)(*param_3 + 0xd0);
      puStack_58 = (uint *)0xb2e988;
      iVar7 = FUN_0088cdc0();
      ppuVar16 = param_3;
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)0xb2e9a0;
      puVar10 = (undefined4 *)FUN_00605c00();
      puStack_58 = param_4;
      ppuStack_5c = (undefined **)*puVar10;
      piStack_60 = (int *)0xb2e9aa;
      iVar11 = FUN_00c5f570();
      if (iVar11 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = param_4;
      ppuStack_5c = ppuVar16;
      goto LAB_00b2ed3a;
    }
    if (param_2 == (int *)&DAT_0212af50) {
      if ((undefined *)0xcf < param_3[1] + (-0x340 - (int)*param_3)) {
        return;
      }
      iVar11 = *(int *)*param_3;
      puStack_58 = (uint *)0xb2e9ee;
      ExceptionList = &pvStack_10;
      iVar7 = FUN_0088cdc0();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      iVar11 = *(int *)(*param_3 + 0x270);
      puStack_58 = (uint *)0xb2ea06;
      iVar7 = FUN_0088daf0();
      ppuVar16 = param_3;
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)0xb2ea18;
      puVar10 = (undefined4 *)FUN_00605c00();
      puStack_58 = param_4;
      ppuStack_5c = (undefined **)*puVar10;
      piStack_60 = (int *)0xb2ea22;
      param_3 = (undefined **)FUN_00c5f570();
joined_r0x00b2eac3:
      if (param_3 == (undefined **)0x0) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)0xb2ea3d;
      pcVar8 = (char *)FUN_00605c60();
      if (*pcVar8 != '\0') {
        puStack_58 = (uint *)0xb2ea4a;
        cVar6 = FUN_0091eb80();
        if (cVar6 == '\0') {
          ExceptionList = pvStack_10;
          return;
        }
      }
      puStack_58 = param_4;
      ppuStack_5c = ppuVar16;
      goto LAB_00b2ed3a;
    }
    if (param_2 == (int *)&DAT_0212ae80) {
      if ((undefined *)0xcf < param_3[1] + (-0x270 - (int)*param_3)) {
        return;
      }
      iVar11 = *(int *)*param_3;
      puStack_58 = (uint *)0xb2ea87;
      ExceptionList = &pvStack_10;
      iVar7 = FUN_0088cdc0();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      iVar11 = *(int *)(*param_3 + 0x1a0);
      puStack_58 = (uint *)0xb2ea9f;
      iVar7 = FUN_0088daf0();
      ppuVar16 = param_3;
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)0xb2eab1;
      puVar10 = (undefined4 *)FUN_00605c00();
      puStack_58 = param_4;
      ppuStack_5c = (undefined **)*puVar10;
      piStack_60 = (int *)0xb2eabb;
      param_3 = (undefined **)FUN_00c5f570();
      goto joined_r0x00b2eac3;
    }
    if (param_2 == (int *)&DAT_0212a9a8) {
      if (((int)param_3[1] - (int)*param_3) / 0xd0 != 2) {
        return;
      }
      iVar11 = *(int *)*param_3;
      puStack_58 = (uint *)0xb2eb0d;
      ExceptionList = &pvStack_10;
      iVar7 = FUN_0088cdc0();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      iVar11 = *(int *)(*ppuVar16 + 0xd0);
      puStack_58 = (uint *)0xb2eb22;
      iVar7 = thunk_FUN_00b317b0();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)0xb2eb31;
      puStack_58 = (uint *)FUN_00605c00();
      ppuStack_5c = (undefined **)0xb2eb3a;
      FUN_00557fc0();
      puStack_58 = (uint *)aiStack_3c;
      uStack_8 = 0xb;
      ppuStack_5c = (undefined **)aiStack_44;
      piStack_60 = (int *)0xb2eb4e;
      FUN_00562c90();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      if (aiStack_44[0] != 0) {
        puStack_58 = (uint *)&param_3;
        ppuStack_5c = (undefined **)0xb2eb65;
        FUN_00927d30();
        puStack_58 = param_4;
        ppuStack_5c = (undefined **)0xb2eb70;
        cVar6 = FUN_005e0cd0();
        if (cVar6 == '\0') {
          puStack_58 = (uint *)0xb2eb7b;
          piVar12 = (int *)FUN_00b14ae0();
          iVar11 = *piVar12;
          puStack_58 = (uint *)aiStack_44;
          ppuStack_5c = (undefined **)0xb2eb89;
          FUN_00557fc0();
          if (iVar11 == 0x3d) {
            *(undefined *)((int)uStack_34 + 0x314) = 0;
          }
          if (uStack_34._4_4_ != (int *)0x0) {
            LOCK();
            iVar11 = uStack_34._4_4_[1] + -1;
            uStack_34._4_4_[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              puStack_58 = (uint *)0xb2ebb1;
              (**(code **)*uStack_34._4_4_)();
              LOCK();
              piVar12 = uStack_34._4_4_ + 2;
              iVar11 = *piVar12;
              *piVar12 = *piVar12 + -1;
              UNLOCK();
              if (iVar11 == 1) {
                puStack_58 = (uint *)0xb2ebc0;
                (**(code **)(*uStack_34._4_4_ + 4))();
              }
            }
          }
        }
      }
      puStack_58 = (uint *)0xb2ebc8;
      FUN_00550b30();
      puStack_58 = (uint *)0xb2ebd0;
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return;
    }
    if (param_2 == (int *)&DAT_0212b5b8) {
      return;
    }
    if (param_2 == (int *)&DAT_0212b638) {
      ppuStack_5c = (undefined **)param_4;
      piStack_60 = aiStack_44;
      piStack_64 = (int *)0xb2ec03;
      ExceptionList = &pvStack_10;
      puStack_58 = (uint *)param_1;
      FUN_0097c020();
      uStack_8 = 0xf;
      if (aiStack_44[0] != 0) {
        piStack_60 = aiStack_44;
        piStack_64 = (int *)0xb2ec21;
        FUN_00557fc0();
        piStack_60 = (int *)0xb2ec28;
        FUN_00b2b2c0();
      }
      puStack_58 = (uint *)0xb2ec30;
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return;
    }
    if (((param_2 == (int *)&DAT_0212a9e8) || (param_2 == (int *)&DAT_0212aa28)) ||
       (param_2 == (int *)&DAT_0212aa68)) {
      iVar11 = *(int *)*param_3;
      puStack_58 = (uint *)0xb2ecc9;
      ExceptionList = &pvStack_10;
      iVar7 = FUN_0088cdc0();
      if (iVar11 != iVar7) {
        ExceptionList = pvStack_10;
        return;
      }
      iVar11 = *(int *)(*param_3 + 0xd0);
      puStack_58 = (uint *)0xb2ecdd;
      iVar13 = FUN_0088da50();
      iVar7 = iStack_14;
      if (iVar11 != iVar13) {
        ExceptionList = pvStack_10;
        return;
      }
      puStack_58 = (uint *)iStack_14;
      ppuStack_5c = (undefined **)0xb2ecea;
      iVar11 = FUN_0064e810();
      ppvVar5 = (void **)ExceptionList;
      if (iVar11 != 0) {
        puStack_58 = (uint *)0x1;
        ppuStack_5c = (undefined **)iVar7;
        piStack_60 = (int *)0xb2ecfc;
        cVar6 = FUN_0097c970();
        if (cVar6 == '\0') {
          puStack_58 = (uint *)0xb2ed21;
          puVar10 = (undefined4 *)FUN_00605c00();
          puStack_58 = param_4;
          ppuStack_5c = (undefined **)*puVar10;
          piStack_60 = (int *)0xb2ed2b;
          iVar11 = FUN_00c5f570();
          goto LAB_00b2ed2e;
        }
        puStack_58 = (uint *)0xb2ed0d;
        piVar12 = (int *)FUN_00605c00();
        ppvVar5 = (void **)ExceptionList;
        if (*piVar12 != *(int *)(iVar11 + 0xf4)) {
          ExceptionList = pvStack_10;
          return;
        }
      }
    }
    else {
      ppvVar5 = &pvStack_10;
      if ((DAT_01d63cb0 != '\0') && (ppvVar5 = &pvStack_10, param_2 == (int *)&DAT_0212b538)) {
        if (((int)param_3[1] - (int)*param_3) / 0xd0 != 2) {
          return;
        }
        iVar11 = *(int *)*param_3;
        puStack_58 = (uint *)0xb2ec9e;
        ExceptionList = &pvStack_10;
        iVar7 = FUN_0088cdc0();
        if (iVar11 != iVar7) {
          ExceptionList = pvStack_10;
          return;
        }
        puStack_58 = (uint *)0xb2ecab;
        FUN_0088da50();
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  ExceptionList = ppvVar5;
  puStack_58 = param_4;
  ppuStack_5c = param_3;
LAB_00b2ed3a:
  piStack_60 = param_2;
  piStack_64 = (int *)0xb2ed40;
  param_4 = puStack_58;
  FUN_009cba80();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23701 ; VA 0x00b2ed60 ; FUN_00b2ed60 */

int FUN_00b2ed60(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f10e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (iStack_18 != 0) {
    iVar3 = FUN_00b305b0(&param_3);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar4 = in_stack_00000020 + 1;
    uVar5 = param_3;
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(param_3 - 4);
      uVar4 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(uVar5,uVar4);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (0xf < in_stack_00000038) {
    uVar5 = in_stack_00000038 + 1;
    iVar3 = in_stack_00000024;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(in_stack_00000024 + -4);
      uVar5 = in_stack_00000038 + 0x24;
      if (0x1f < (in_stack_00000024 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23702 ; VA 0x00b2ee70 ; FUN_00b2ee70 */

void FUN_00b2ee70(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f10e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (DAT_01d66ed4 == '\0') {
    ExceptionList = &pvStack_10;
    FUN_00587490(&iStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_18 != 0) {
      FUN_00b305b0(&param_3);
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar2 = piStack_14[2] + -1;
        piStack_14[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    uVar4 = param_3;
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(param_3 - 4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (0xf < in_stack_00000038) {
    uVar4 = in_stack_00000038 + 1;
    iVar2 = in_stack_00000024;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(in_stack_00000024 + -4);
      uVar4 = in_stack_00000038 + 0x24;
      if (0x1f < (in_stack_00000024 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23703 ; VA 0x00b2ef90 ; FUN_00b2ef90 */

uint __thiscall FUN_00b2ef90(undefined4 param_1,int param_2,int *param_3,int param_4,int param_5)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  char cVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_ffffff94;
  undefined4 in_stack_ffffff98;
  undefined4 in_stack_ffffff9c;
  undefined4 in_stack_ffffffa0;
  undefined4 uVar9;
  char *pcVar10;
  int iVar11;
  undefined4 uVar12;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  uint auStack_30 [3];
  undefined auStack_24 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f1100;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d66edc == '\0') {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_01255560();
    uStack_48 = *puVar5;
    uStack_44 = puVar5[1];
    uStack_40 = puVar5[2];
    uStack_3c = puVar5[3];
    uStack_38 = *(undefined8 *)(puVar5 + 4);
    cVar4 = FUN_01255580(&uStack_48,5);
    if (cVar4 == '\0') {
      FUN_016756b0(auStack_24,"PromptBundlePurchase is not yet enabled");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_24,&DAT_01c17198);
    }
  }
  uVar12 = 0x16;
  pcVar10 = "PromptBundlePurchase()";
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uVar9 = 0xb2f00c;
  FUN_005542c0("PromptBundlePurchase()",0x16);
  iStack_8._0_1_ = 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  cVar4 = FUN_00b29320(param_2,param_3,auStack_30,0,in_stack_ffffff94,in_stack_ffffff98,
                       in_stack_ffffff9c,in_stack_ffffffa0,uVar9,pcVar10,uVar12);
  bStack_11 = cVar4 == '\0';
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_1c) {
    uVar8 = uStack_1c + 1;
    uVar7 = auStack_30[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_30[0] - 4);
      uVar8 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uVar7 = (uint)bStack_11;
  if (bStack_11 == 0) {
    iVar6 = FUN_0064e810(param_1);
    if (iVar6 != 0) {
      cVar4 = FUN_0097c970(param_1,1);
      iVar11 = param_4;
      if ((cVar4 != '\0') && (param_2 != *(int *)(iVar6 + 0xf4))) {
        FUN_0086f2f0(2,
                     "MarketplaceService:PromptBundlePurchase: called from a local script, but not called on a local player. Local scripts can only prompt the local player."
                    );
        uVar7 = FUN_00550b30();
        ExceptionList = pvStack_10;
        return uVar7;
      }
      if ((param_5 < 1) && ((param_5 < 0 || (param_4 == 0)))) {
        FUN_016756b0(auStack_24,
                     "MarketplaceService:PromptBundlePurchase: second argument is not a valid bundleId (supplied bundleId was less than 0)"
                    );
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_24,&DAT_01c17198);
      }
      iVar6 = FUN_008f7870(param_1);
      if (iVar6 != 0) {
        iVar6 = FUN_00916350();
        if (iVar6 != 0) {
          cVar4 = FUN_00e56510(2);
          if (cVar4 == '\0') {
            FUN_016756b0(auStack_24,
                         "Studio API access is not enabled. Enable it by going to the Game Settings page."
                        );
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_24,&DAT_01c17198);
          }
        }
      }
      uVar9 = 0;
      pcVar10 = "PurchaseBundlePrompted";
      FUN_0087c450(&DAT_018c5f98,"PurchasingEvents","PurchaseBundlePrompted",0,0,0);
      iVar6 = param_5;
      FUN_00557fc0(&param_2);
      FUN_00b24ba0(param_1,pcVar10,uVar9,iVar11,iVar6);
      uVar7 = FUN_00550b30();
      ExceptionList = pvStack_10;
      return uVar7;
    }
    uVar7 = FUN_0086f2f0(2,
                         "MarketplaceService:PromptBundlePurchase: unable to get the Players service."
                        );
  }
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar8 = *puVar1;
    uVar7 = *puVar1;
    *puVar1 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      uVar7 = (**(code **)*param_3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar6 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        uVar7 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 23704 ; VA 0x00b2f230 ; FUN_00b2f230 */

int __thiscall FUN_00b2f230(undefined4 param_1,int param_2,int *param_3,int param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_2c [3];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f1120;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PromptGamePassPurchase()",0x18);
  iStack_8._0_1_ = 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00b29320(param_2,param_3,auStack_2c,0);
  cVar3 = (char)iVar4;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    uVar5 = auStack_2c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_2c[0] - 4);
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar5,uVar6);
  }
  if (cVar3 != '\0') {
    iVar4 = FUN_0064e810(param_1);
    if (iVar4 != 0) {
      cVar3 = FUN_0097c970(param_1,1);
      if ((cVar3 != '\0') && (param_2 != *(int *)(iVar4 + 0xf4))) {
        FUN_0086f2f0(2,
                     "MarketplaceService:PromptGamePassPurchase was called from a local script, but was not called on the local player. Local scripts can only call this function on the local player."
                    );
        iVar4 = FUN_00550b30();
        ExceptionList = pvStack_10;
        return iVar4;
      }
    }
    if ((param_5 < 1) && ((param_5 < 0 || (param_4 == 0)))) {
      FUN_016756b0(auStack_20,
                   "MarketplaceService::PromptGamePassPurchase() was called with an invalid game pass id (supplied game pass id was less than zero)"
                  );
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
    iVar4 = FUN_008f7870(param_1);
    if (iVar4 != 0) {
      iVar4 = FUN_00916350();
      if (iVar4 != 0) {
        cVar3 = FUN_00e56510(2);
        if (cVar3 == '\0') {
          FUN_016756b0(auStack_20,
                       "Studio API access is not enabled. Enable it by going to the Game Settings page."
                      );
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_20,&DAT_01c17198);
        }
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar4 = FUN_00b24ba0(param_1,param_2,param_3,param_4,param_5);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23705 ; VA 0x00b2f450 ; FUN_00b2f450 */

int __thiscall FUN_00b2f450(undefined4 param_1,int param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_ffffffac;
  uint auStack_2c [3];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1148;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PromptNativePurchase()",0x16);
  uStack_8._0_1_ = 2;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00b29320(param_2,param_3,auStack_2c,0,in_stack_ffffffac);
  cVar3 = (char)iVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar6 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar6,uVar5);
  }
  if (cVar3 != '\0') {
    iVar4 = FUN_0064e810(param_1);
    if (((iVar4 == 0) || (cVar3 = FUN_0097c970(param_1,1), cVar3 == '\0')) ||
       (param_2 == *(int *)(iVar4 + 0xf4))) {
      if (in_stack_0000001c == 0) {
        FUN_016756b0(auStack_20,"MarketplaceService:PromptNativePurchase() productId is empty");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_20,&DAT_01c17198);
      }
      FUN_0054ef60(&param_4);
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      FUN_00b24690(param_1,param_2,param_3);
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar4 = param_3[1] + -1;
        param_3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*param_3)();
          LOCK();
          piVar1 = param_3 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*param_3 + 4))();
          }
        }
      }
    }
    else {
      FUN_0086f2f0(2,
                   "MarketplaceService:PromptNativePurchase called from a local script, but not called on a local player. Local scripts can only prompt the local player."
                  );
      FUN_00550b30();
    }
    iVar4 = FUN_005507b0();
    ExceptionList = pvStack_10;
    return iVar4;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (in_stack_00000020 < 0x10) {
    ExceptionList = pvStack_10;
    return iVar4;
  }
  uVar6 = in_stack_00000020 + 1;
  iVar4 = param_4;
  if (0xfff < uVar6) {
    iVar4 = *(int *)(param_4 + -4);
    uVar6 = in_stack_00000020 + 0x24;
    if (0x1f < (param_4 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  iVar4 = FUN_01674ea0(iVar4,uVar6);
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23706 ; VA 0x00b2f690 ; FUN_00b2f690 */

int __thiscall FUN_00b2f690(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  int *piStack_104;
  int iStack_40;
  int *piStack_3c;
  undefined *puStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1199;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  FUN_00562c90(&iStack_40,&param_2);
  uStack_8._0_1_ = 1;
  if (iStack_40 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("First argument to PromptPremiumPurchase must be a Player");
  }
  uVar6 = 0xb2f6e1;
  iVar5 = FUN_008f7870(param_1);
  if (iVar5 != 0) {
    if (*(int *)(iVar5 + 0x4a0) == 2) {
      FUN_00927d30(auStack_1c);
      uStack_108 = param_2;
      puStack_38 = auStack_1c;
      uStack_34 = 0;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      piStack_14 = param_3;
      uStack_24 = param_2;
      piStack_20 = param_3;
      uStack_8._0_1_ = 2;
      pcVar4 = *(code **)(*param_1 + 8);
      uStack_110 = FUN_0088cdc0();
      uStack_10c = 0;
      piStack_104 = piStack_14;
      uStack_24 = 0;
      piStack_20 = (int *)0x0;
      uStack_10c = FUN_006309e0();
      uStack_8._0_1_ = 3;
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_28 = 0;
      FUN_00687980(&uStack_110,&iStack_40,param_3);
      uStack_8._0_1_ = 4;
      (*pcVar4)(&DAT_0212b578,&uStack_30,&puStack_38);
      uStack_8._0_1_ = 5;
      FUN_00577b20();
      uStack_8._0_1_ = 2;
      iVar5 = FUN_016f32d1(&uStack_110,0xd0,1,FUN_0056e5b0);
    }
    else {
      uVar7 = 0xb2f7eb;
      iVar5 = FUN_0055e560();
      if (*(int *)(iVar5 + 0xf4) != iStack_40) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Can only call PromptPremiumPurchase from LocalScript on the local player");
      }
      FUN_00557fc0(&param_2);
      iVar5 = FUN_00925d30(param_1,uVar6,uVar7);
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_3c + 1;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        piVar1 = piStack_3c + 2;
        iVar3 = *piVar1;
        iVar5 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar5 = (**(code **)(*piStack_3c + 4))();
        }
      }
    }
    piVar1 = param_3;
    if (param_3 != (int *)0x0) {
      LOCK();
      piVar2 = param_3 + 1;
      iVar3 = *piVar2;
      iVar5 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)*param_3)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          iVar5 = (**(code **)(*piVar1 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar5;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("MarketplaceService must be in DataModel when calling PromptPremiumPurchase");
}



/* FUNCTION 23707 ; VA 0x00b2f890 ; FUN_00b2f890 */

int __thiscall
FUN_00b2f890(undefined4 param_1,int param_2,int *param_3,int param_4,int param_5,undefined4 param_6,
            undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_stack_ffffffac;
  undefined4 in_stack_ffffffb0;
  undefined4 in_stack_ffffffb4;
  undefined4 in_stack_ffffffb8;
  undefined4 uVar7;
  char *pcVar8;
  undefined4 uVar9;
  uint auStack_2c [3];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f1120;
  pvStack_10 = ExceptionList;
  uVar9 = 0x17;
  pcVar8 = "PromptProductPurchase()";
  iStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uVar7 = 0xb2f8d8;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PromptProductPurchase()",0x17);
  iStack_8._0_1_ = 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00b29320(param_2,param_3,auStack_2c,0,in_stack_ffffffac,in_stack_ffffffb0,
                       in_stack_ffffffb4,in_stack_ffffffb8,uVar7,pcVar8,uVar9);
  cVar3 = (char)iVar4;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    uVar5 = auStack_2c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_2c[0] - 4);
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar5,uVar6);
  }
  if (cVar3 != '\0') {
    iVar4 = FUN_0064e810(param_1);
    if (iVar4 != 0) {
      cVar3 = FUN_0097c970(param_1,1);
      if ((cVar3 != '\0') && (param_2 != *(int *)(iVar4 + 0xf4))) {
        FUN_0086f2f0(2,
                     "MarketplaceService:PromptProductPurchase called from a local script, but not called on a local player. Local scripts can only prompt the local player."
                    );
        iVar4 = FUN_00550b30();
        ExceptionList = pvStack_10;
        return iVar4;
      }
    }
    if ((param_5 < 1) && ((param_5 < 0 || (param_4 == 0)))) {
      FUN_016756b0(auStack_20,
                   "MarketplaceService:PromptPurchase() second argument is not a valid productId (supplied productId was less than 0)"
                  );
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
    iVar4 = FUN_008f7870(param_1);
    if (iVar4 != 0) {
      iVar4 = FUN_00916350();
      if (iVar4 != 0) {
        cVar3 = FUN_00e56510(2);
        if (cVar3 == '\0') {
          FUN_016756b0(auStack_20,
                       "Studio API access is not enabled. Enable it by going to the Game Settings page."
                      );
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_20,&DAT_01c17198);
        }
      }
    }
    FUN_0087c450(&DAT_018c5f98,"PurchasingEvents","ProductPurchasePrompted",0,0,0);
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar4 = FUN_00b25000(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23708 ; VA 0x00b2fad0 ; FUN_00b2fad0 */

int __thiscall
FUN_00b2fad0(undefined4 param_1,int param_2,int *param_3,int param_4,int param_5,undefined4 param_6,
            undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_stack_ffffffac;
  undefined4 in_stack_ffffffb0;
  undefined4 in_stack_ffffffb4;
  undefined4 in_stack_ffffffb8;
  undefined4 uVar7;
  char *pcVar8;
  undefined4 uVar9;
  uint auStack_2c [3];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f1120;
  pvStack_10 = ExceptionList;
  uVar9 = 0x10;
  pcVar8 = "PromptPurchase()";
  iStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uVar7 = 0xb2fb18;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PromptPurchase()",0x10);
  iStack_8._0_1_ = 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00b29320(param_2,param_3,auStack_2c,0,in_stack_ffffffac,in_stack_ffffffb0,
                       in_stack_ffffffb4,in_stack_ffffffb8,uVar7,pcVar8,uVar9);
  cVar3 = (char)iVar4;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    uVar5 = auStack_2c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_2c[0] - 4);
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar5,uVar6);
  }
  if (cVar3 != '\0') {
    iVar4 = FUN_0064e810(param_1);
    if (iVar4 != 0) {
      cVar3 = FUN_0097c970(param_1,1);
      if ((cVar3 != '\0') && (param_2 != *(int *)(iVar4 + 0xf4))) {
        FUN_0086f2f0(2,
                     "MarketplaceService:PromptPurchase called from a local script, but not called on a local player. Local scripts can only prompt the local player."
                    );
        iVar4 = FUN_00550b30();
        ExceptionList = pvStack_10;
        return iVar4;
      }
    }
    if ((param_5 < 1) && ((param_5 < 0 || (param_4 == 0)))) {
      FUN_016756b0(auStack_20,
                   "MarketplaceService:PromptPurchase() second argument is not a valid assetId (supplied assetId was less than 0)"
                  );
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
    iVar4 = FUN_008f7870(param_1);
    if (iVar4 != 0) {
      iVar4 = FUN_00916350();
      if (iVar4 != 0) {
        cVar3 = FUN_00e56510(2);
        if (cVar3 == '\0') {
          FUN_016756b0(auStack_20,
                       "Studio API access is not enabled. Enable it by going to the Game Settings page."
                      );
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_20,&DAT_01c17198);
        }
      }
    }
    FUN_0087c450(&DAT_018c5f98,"PurchasingEvents","PurchasePrompted",0,0,0);
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar4 = FUN_00b25000(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23709 ; VA 0x00b2fd10 ; FUN_00b2fd10 */

void FUN_00b2fd10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00a51eb0(param_1,param_2,param_3);
  return;
}



/* FUNCTION 23710 ; VA 0x00b2fd30 ; FUN_00b2fd30 */

int __thiscall FUN_00b2fd30(undefined4 param_1,int param_2,int *param_3,int param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_2c [3];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f1120;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PromptSubscriptionCancellation()",0x20);
  iStack_8._0_1_ = 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00b29320(param_2,param_3,auStack_2c,0);
  cVar3 = (char)iVar4;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    uVar5 = auStack_2c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_2c[0] - 4);
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar5,uVar6);
  }
  if (cVar3 != '\0') {
    iVar4 = FUN_0064e810(param_1);
    if (iVar4 != 0) {
      cVar3 = FUN_0097c970(param_1,1);
      if ((cVar3 != '\0') && (param_2 != *(int *)(iVar4 + 0xf4))) {
        FUN_0086f2f0(2,
                     "MarketplaceService:PromptSubscriptionCancellation was called from a local script, but was not called on the local player. Local scripts can only call this function on the local player."
                    );
        iVar4 = FUN_00550b30();
        ExceptionList = pvStack_10;
        return iVar4;
      }
    }
    if ((param_5 < 1) && ((param_5 < 0 || (param_4 == 0)))) {
      FUN_016756b0(auStack_20,
                   "MarketplaceService::PromptSubscriptionCancellation() was called with an invalid subscription id (supplied subscription id was less than zero)"
                  );
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
    iVar4 = FUN_008f7870(param_1);
    if (iVar4 != 0) {
      iVar4 = FUN_00916350();
      if (iVar4 != 0) {
        cVar3 = FUN_00e56510(2);
        if (cVar3 == '\0') {
          FUN_016756b0(auStack_20,
                       "Studio API access is not enabled. Enable it by going to the Game Settings page."
                      );
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_20,&DAT_01c17198);
        }
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar4 = FUN_00b24ba0(param_1,param_2,param_3,param_4,param_5);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23711 ; VA 0x00b2ff50 ; FUN_00b2ff50 */

int __thiscall FUN_00b2ff50(undefined4 param_1,int param_2,int *param_3,int param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_2c [3];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f1120;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PromptSubscriptionPurchase()",0x1c);
  iStack_8._0_1_ = 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00b29320(param_2,param_3,auStack_2c,0);
  cVar3 = (char)iVar4;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    uVar5 = auStack_2c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_2c[0] - 4);
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar5,uVar6);
  }
  if (cVar3 != '\0') {
    iVar4 = FUN_0064e810(param_1);
    if (iVar4 != 0) {
      cVar3 = FUN_0097c970(param_1,1);
      if ((cVar3 != '\0') && (param_2 != *(int *)(iVar4 + 0xf4))) {
        FUN_0086f2f0(2,
                     "MarketplaceService:PromptSubscriptionPurchase was called from a local script, but was not called on the local player. Local scripts can only call this function on the local player."
                    );
        iVar4 = FUN_00550b30();
        ExceptionList = pvStack_10;
        return iVar4;
      }
    }
    if ((param_5 < 1) && ((param_5 < 0 || (param_4 == 0)))) {
      FUN_016756b0(auStack_20,
                   "MarketplaceService::PromptSubscriptionPurchase() was called with an invalid subscription id (supplied subscription id was less than zero)"
                  );
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
    iVar4 = FUN_008f7870(param_1);
    if (iVar4 != 0) {
      iVar4 = FUN_00916350();
      if (iVar4 != 0) {
        cVar3 = FUN_00e56510(2);
        if (cVar3 == '\0') {
          FUN_016756b0(auStack_20,
                       "Studio API access is not enabled. Enable it by going to the Game Settings page."
                      );
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_20,&DAT_01c17198);
        }
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar4 = FUN_00b24ba0(param_1,param_2,param_3,param_4,param_5);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23712 ; VA 0x00b30170 ; FUN_00b30170 */

int __thiscall FUN_00b30170(undefined4 param_1,int param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_ffffffac;
  uint auStack_2c [3];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1148;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PromptThirdPartyPurchase()",0x1a);
  uStack_8._0_1_ = 2;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00b29320(param_2,param_3,auStack_2c,0,in_stack_ffffffac);
  cVar3 = (char)iVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar6 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar6,uVar5);
  }
  if (cVar3 != '\0') {
    iVar4 = FUN_0064e810(param_1);
    if (((iVar4 == 0) || (cVar3 = FUN_0097c970(param_1,1), cVar3 == '\0')) ||
       (param_2 == *(int *)(iVar4 + 0xf4))) {
      if (in_stack_0000001c == 0) {
        FUN_016756b0(auStack_20,"MarketplaceService:PromptThirdPartyPurchase() productId is empty");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_20,&DAT_01c17198);
      }
      FUN_0054ef60(&param_4);
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      FUN_00b24690(param_1,param_2,param_3);
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar4 = param_3[1] + -1;
        param_3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*param_3)();
          LOCK();
          piVar1 = param_3 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*param_3 + 4))();
          }
        }
      }
    }
    else {
      FUN_0086f2f0(2,
                   "MarketplaceService:PromptThirdPartyPurchase called from a local script, but not called on a local player. Local scripts can only prompt the local player."
                  );
      FUN_00550b30();
    }
    iVar4 = FUN_005507b0();
    ExceptionList = pvStack_10;
    return iVar4;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (in_stack_00000020 < 0x10) {
    ExceptionList = pvStack_10;
    return iVar4;
  }
  uVar6 = in_stack_00000020 + 1;
  iVar4 = param_4;
  if (0xfff < uVar6) {
    iVar4 = *(int *)(param_4 + -4);
    uVar6 = in_stack_00000020 + 0x24;
    if (0x1f < (param_4 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  iVar4 = FUN_01674ea0(iVar4,uVar6);
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23713 ; VA 0x00b303b0 ; FUN_00b303b0 */

int FUN_00b303b0(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  longlong lVar8;
  int iStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f11d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_38);
  uStack_8._0_1_ = 2;
  if (iStack_38 != 0) {
    iVar3 = FUN_00562c90(&iStack_40,&param_3);
    uStack_8._0_1_ = 3;
    if (iStack_40 != 0) {
      FUN_00591e70(iStack_38 + 200);
      uStack_8._0_1_ = 4;
      lVar8 = FUN_00928340();
      uStack_24 = (uint)((ulonglong)lVar8 >> 0x20);
      iStack_20 = (int)lVar8;
      iStack_28 = iStack_38 + 0xd8;
      if (*(int *)(iStack_38 + 0xe0) != 0) {
        uStack_1c = uStack_24;
        if ((lVar8 < 0x100000000) && (lVar8 < 0)) {
          uStack_1c = -uStack_24 - 1;
        }
        uStack_18 = *(uint *)(iStack_38 + 0xdc);
        uStack_1c = (uStack_1c >> 2) + uStack_1c * 0x40 + iStack_20 ^ uStack_1c;
        uStack_14 = uStack_1c % uStack_18;
        iStack_2c = uStack_14 * 4;
        piVar7 = *(int **)(iStack_2c + *(int *)(iStack_38 + 0xec));
        if ((piVar7 != (int *)0x0) && (piVar2 = (int *)*piVar7, (int *)*piVar7 != (int *)0x0)) {
          while (piVar5 = piVar2, (uint)piVar5[1] % uStack_18 == uStack_14) {
            if (((piVar5[1] == uStack_1c) && (iStack_20 == piVar5[2])) && (uStack_24 == piVar5[3]))
            {
              FUN_00b21870(piVar7,*piVar5);
              if (*piVar7 != 0) {
                uVar6 = *(uint *)(*piVar7 + 4) % *(uint *)(iStack_38 + 0xdc);
                lVar8 = CONCAT44(uStack_24,iStack_20);
                if (uStack_14 == uVar6) break;
                *(int **)(*(int *)(iStack_38 + 0xec) + uVar6 * 4) = piVar7;
              }
              puVar4 = (undefined4 *)(*(int *)(iStack_38 + 0xec) + iStack_2c);
              lVar8 = CONCAT44(uStack_24,iStack_20);
              if ((int *)*puVar4 == piVar7) {
                *puVar4 = 0;
                lVar8 = CONCAT44(uStack_24,iStack_20);
              }
              break;
            }
            piVar2 = (int *)*piVar5;
            piVar7 = piVar5;
            if ((int *)*piVar5 == (int *)0x0) break;
          }
        }
      }
      uStack_24 = (uint)((ulonglong)lVar8 >> 0x20);
      iStack_20 = (int)lVar8;
      iVar3 = FUN_005923a0();
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      piVar7 = piStack_3c + 1;
      iVar1 = *piVar7;
      iVar3 = *piVar7;
      *piVar7 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        piVar7 = piStack_3c + 2;
        iVar1 = *piVar7;
        iVar3 = *piVar7;
        *piVar7 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_3c + 4))();
        }
      }
    }
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    piVar7 = piStack_34 + 1;
    iVar1 = *piVar7;
    iVar3 = *piVar7;
    *piVar7 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar7 = piStack_34 + 2;
      iVar1 = *piVar7;
      iVar3 = *piVar7;
      *piVar7 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar7 = param_2 + 2;
    iVar1 = *piVar7;
    iVar3 = *piVar7;
    *piVar7 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  piVar7 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar2 = param_4 + 1;
    iVar1 = *piVar2;
    iVar3 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*param_4)();
      LOCK();
      piVar2 = piVar7 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23714 ; VA 0x00b305b0 ; FUN_00b305b0 */

/* WARNING: Removing unreachable block (ram,0x00b306d3) */
/* WARNING: Removing unreachable block (ram,0x00b306e6) */
/* WARNING: Removing unreachable block (ram,0x00b306ed) */
/* WARNING: Removing unreachable block (ram,0x00b306f4) */

undefined4 * __thiscall FUN_00b305b0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_00587410();
  if (*(int *)(param_1 + 0x98) != 0) {
    uVar2 = FUN_0055c740((byte *)(param_1 + 0x90) + *(byte *)(param_1 + 0x90) + 1,param_2);
    uVar4 = uVar2 % *(uint *)(param_1 + 0x94);
    puVar1 = *(undefined4 **)(param_1 + 0xa4);
    piVar7 = (int *)puVar1[uVar4];
    if ((piVar7 != (int *)0x0) && (piVar3 = (int *)*piVar7, (int *)*piVar7 != (int *)0x0)) {
      while( true ) {
        piVar6 = piVar3;
        uVar5 = piVar6[1];
        puVar1 = (undefined4 *)(uVar5 / *(uint *)(param_1 + 0x94));
        if (uVar5 % *(uint *)(param_1 + 0x94) != uVar4) break;
        if (uVar5 == uVar2) {
          piVar3 = piVar6 + 2;
          if (0xf < (uint)piVar6[7]) {
            piVar3 = (int *)*piVar3;
          }
          puVar1 = param_2;
          if (0xf < (uint)param_2[5]) {
            puVar1 = (undefined4 *)*param_2;
          }
          puVar1 = (undefined4 *)FUN_0055c360(puVar1,param_2[4],piVar3,piVar6[6]);
          if ((char)puVar1 != '\0') {
            FUN_0061adc0(piVar7,*piVar6);
            if (*piVar7 != 0) {
              uVar2 = *(uint *)(*piVar7 + 4);
              uVar5 = uVar2 % *(uint *)(param_1 + 0x94);
              if (uVar4 == uVar5) {
                ExceptionList = pvStack_10;
                return (undefined4 *)(uVar2 / *(uint *)(param_1 + 0x94));
              }
              *(int **)(*(int *)(param_1 + 0xa4) + uVar5 * 4) = piVar7;
            }
            puVar1 = (undefined4 *)(*(int *)(param_1 + 0xa4) + uVar4 * 4);
            if ((int *)*puVar1 != piVar7) {
              ExceptionList = pvStack_10;
              return puVar1;
            }
            *puVar1 = 0;
            ExceptionList = pvStack_10;
            return puVar1;
          }
        }
        piVar3 = (int *)*piVar6;
        piVar7 = piVar6;
        if ((int *)*piVar6 == (int *)0x0) {
          ExceptionList = pvStack_10;
          return puVar1;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 23715 ; VA 0x00b30710 ; FUN_00b30710 */

void __thiscall FUN_00b30710(undefined4 param_1,int *param_2)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d9648;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_2 + 8))(param_1,&uStack_24,&uStack_18);
  uStack_8 = 1;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23716 ; VA 0x00b30790 ; FUN_00b30790 */

void __thiscall FUN_00b30790(undefined4 param_1,undefined4 ***param_2)

{
  undefined *puVar1;
  int iVar2;
  undefined4 ****ppppuVar3;
  undefined4 ***pppuVar4;
  undefined4 ****ppppuVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined *in_stack_0000001c;
  undefined uVar6;
  undefined auStack_cc [16];
  undefined4 uStack_bc;
  undefined *puStack_b8;
  undefined auStack_b4 [4];
  undefined4 uStack_b0;
  int iStack_ac;
  int iStack_a8;
  undefined4 ***pppuStack_a4;
  undefined4 ***pppuStack_a0;
  undefined auStack_8f [21];
  undefined auStack_7a [2];
  undefined *puStack_78;
  undefined *puStack_74;
  int iStack_70;
  undefined *puStack_6c;
  undefined uStack_68;
  undefined4 uStack_64;
  undefined auStack_60 [4];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 ***pppuStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1239;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_48 = param_1;
  if (DAT_01d66e9c != '\0') {
    pppuStack_a0 = (undefined4 ***)0xb;
    auStack_60[0] = 0;
    pppuStack_a4 = (undefined4 ***)0xb307d9;
    ExceptionList = &pvStack_10;
    uStack_5c = FUN_00588320();
    uStack_58 = 0;
    uStack_54 = 0x3f800000;
    uStack_50 = 0;
    uStack_4c = 0;
    pppuStack_a0 = (undefined4 ***)0x7;
    pppuStack_a4 = (undefined4 ***)0x1938ca4;
    uStack_8._0_1_ = 1;
    uStack_34 = 0;
    uStack_30 = 0xf;
    apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
    iStack_a8 = 0xb30820;
    FUN_005542c0();
    pppuStack_a0 = apppuStack_44;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    pppuStack_a4 = (undefined4 ***)0xb30830;
    iVar2 = FUN_005d15d0();
    if ((undefined4 ****)(iVar2 + 0x18) != &param_2) {
      pppuStack_a0 = (undefined4 ***)in_stack_00000014;
      pppuStack_a4 = &param_2;
      if (0xf < in_stack_00000018) {
        pppuStack_a4 = param_2;
      }
      iStack_a8 = 0xb3084b;
      FUN_005542c0();
    }
    uStack_8._0_1_ = 1;
    if (0xf < uStack_30) {
      pppuStack_a0 = (undefined4 ***)(uStack_30 + 1);
      pppuVar4 = apppuStack_44[0];
      if (0xfff < pppuStack_a0) {
        pppuVar4 = (undefined4 ***)apppuStack_44[0][-1];
        pppuStack_a0 = (undefined4 ***)(uStack_30 + 0x24);
        if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)pppuVar4))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_a0 = (undefined4 ***)0xb30ada;
          FUN_017167a3();
        }
      }
      iStack_a8 = 0xb30880;
      pppuStack_a4 = pppuVar4;
      FUN_01674ea0();
    }
    puVar1 = in_stack_0000001c;
    puStack_78 = auStack_8f;
    puStack_74 = auStack_7a;
    uStack_8._0_1_ = 3;
    iStack_1c = 0;
    iStack_70 = ((uint)in_stack_0000001c ^ (int)in_stack_0000001c >> 0x1f) -
                ((int)in_stack_0000001c >> 0x1f);
    uStack_18 = 0xf;
    puStack_6c = auStack_7a;
    pppuStack_2c = (undefined4 ***)((uint)pppuStack_2c & 0xffffff00);
    puStack_14 = (undefined *)0x1;
    uStack_68 = 0x30;
    uStack_64 = 0x30;
    pppuStack_a0 = (undefined4 ***)0xb308d5;
    in_stack_0000001c = (undefined *)FUN_0063a3c0();
    if ((int)puVar1 < 0) {
      in_stack_0000001c = in_stack_0000001c + -1;
      *in_stack_0000001c = 0x2d;
    }
    ppppuVar3 = &pppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar3 = (undefined4 ****)pppuStack_2c;
    }
    puStack_74 = auStack_7a;
    ppppuVar5 = &pppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar5 = (undefined4 ****)pppuStack_2c;
    }
    iStack_a8 = (int)ppppuVar3 + (iStack_1c - (int)ppppuVar5);
    ppppuVar3 = &pppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar3 = (undefined4 ****)pppuStack_2c;
    }
    iStack_ac = (int)ppppuVar5 - (int)ppppuVar3;
    pppuStack_a0 = (undefined4 ***)(auStack_7a + -(int)in_stack_0000001c);
    uStack_b0 = 0xb3092a;
    pppuStack_a4 = (undefined4 ***)in_stack_0000001c;
    puStack_78 = in_stack_0000001c;
    FUN_00591430();
    pppuStack_a0 = (undefined4 ***)0xb;
    pppuStack_a4 = (undefined4 ***)0x1951940;
    uStack_34 = 0;
    uStack_30 = 0xf;
    apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
    iStack_a8 = 0xb3094b;
    FUN_005542c0();
    pppuStack_a0 = apppuStack_44;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    pppuStack_a4 = (undefined4 ****)0xb3095b;
    iVar2 = FUN_005d15d0();
    if ((undefined4 ****)(iVar2 + 0x18) != &pppuStack_2c) {
      pppuStack_a0 = (undefined4 ****)0xb3096c;
      FUN_005507b0();
      *(undefined4 ****)(iVar2 + 0x18) = pppuStack_2c;
      *(undefined4 *)(iVar2 + 0x1c) = uStack_28;
      *(undefined4 *)(iVar2 + 0x20) = uStack_24;
      *(undefined4 *)(iVar2 + 0x24) = uStack_20;
      *(ulonglong *)(iVar2 + 0x28) = CONCAT44(uStack_18,iStack_1c);
      iStack_1c = 0;
      uStack_18 = 0xf;
      pppuStack_2c = (undefined4 ***)((uint)pppuStack_2c & 0xffffff00);
    }
    uStack_8._0_1_ = 3;
    if (0xf < uStack_30) {
      pppuStack_a0 = (undefined4 ***)(uStack_30 + 1);
      ppppuVar3 = (undefined4 ****)apppuStack_44[0];
      if ((undefined4 ****)0xfff < pppuStack_a0) {
        ppppuVar3 = (undefined4 ****)apppuStack_44[0][-1];
        pppuStack_a0 = (undefined4 ***)(uStack_30 + 0x24);
        if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_a0 = (undefined4 ***)0xb30adf;
          FUN_017167a3();
        }
      }
      iStack_a8 = 0xb309ca;
      pppuStack_a4 = ppppuVar3;
      FUN_01674ea0();
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
    uStack_8._0_1_ = 1;
    uVar6 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_18) {
      pppuStack_a0 = (undefined4 ***)(uStack_18 + 1);
      ppppuVar3 = (undefined4 ****)pppuStack_2c;
      if ((undefined4 ****)0xfff < pppuStack_a0) {
        ppppuVar3 = (undefined4 ****)pppuStack_2c[-1];
        pppuStack_a0 = (undefined4 ***)(uStack_18 + 0x24);
        if (0x1f < (uint)((int)pppuStack_2c + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_a0 = (undefined4 ***)0xb30ae4;
          uStack_8._0_1_ = uVar6;
          FUN_017167a3();
        }
      }
      iStack_a8 = 0xb30a16;
      pppuStack_a4 = ppppuVar3;
      FUN_01674ea0();
    }
    in_stack_0000001c = auStack_b4;
    puStack_14 = auStack_b4;
    puStack_b8 = auStack_60;
    uStack_bc = 0xb30a2d;
    FUN_0060e660();
    puStack_14 = auStack_cc;
    uStack_8._0_1_ = 5;
    uStack_bc = 0;
    puStack_b8 = (undefined *)0xf;
    auStack_cc[0] = 0;
    FUN_005542c0("AssetPurchase",0xd);
    uStack_8._0_1_ = 6;
    uVar6 = 0;
    FUN_005542c0("prompted",8);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_0087a3e0(uStack_48,uVar6);
    pppuStack_a0 = (undefined4 ***)0xb30a93;
    FUN_0056cfd0();
  }
  if (0xf < in_stack_00000018) {
    pppuStack_a0 = (undefined4 ***)(in_stack_00000018 + 1);
    pppuVar4 = param_2;
    if (0xfff < pppuStack_a0) {
      pppuVar4 = (undefined4 ***)param_2[-1];
      pppuStack_a0 = (undefined4 ***)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)pppuVar4))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_a0 = (undefined4 ***)&UNK_00b30ae9;
        FUN_017167a3();
      }
    }
    iStack_a8 = 0xb30ac0;
    pppuStack_a4 = pppuVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23717 ; VA 0x00b30af0 ; FUN_00b30af0 */

void FUN_00b30af0(int param_1)

{
  char cVar1;
  char *pcVar2;
  uint uVar3;
  uint uVar4;
  char *pcVar5;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a810;
  pvStack_10 = ExceptionList;
  if (param_1 == 4) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("MpsRateLimit-Success-Bundle",0x1b);
    uStack_8 = 0;
    FUN_008783f0(auStack_28,1,0);
    if (uStack_14 < 0x10) {
      ExceptionList = pvStack_10;
      return;
    }
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    uStack_30 = 0;
    uStack_2c = 0xf;
    pcVar5 = "MpsRateLimit-Success-GamePasss";
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    if (param_1 != 2) {
      pcVar5 = "MpsRateLimit-Success-Asset";
    }
    pcVar2 = pcVar5;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
    ExceptionList = &pvStack_10;
    FUN_005542c0(pcVar5,(int)pcVar2 - (int)(pcVar5 + 1));
    uStack_8 = 1;
    FUN_008783f0(auStack_40,1,0);
    if (uStack_2c < 0x10) {
      ExceptionList = pvStack_10;
      return;
    }
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  FUN_01674ea0(uVar3,uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23718 ; VA 0x00b30c20 ; FUN_00b30c20 */

void __fastcall FUN_00b30c20(undefined4 param_1)

{
  char cVar1;
  undefined uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1260;
  pvStack_10 = ExceptionList;
  if (DAT_01d66e94 != '\0') {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_0097c970();
    if (cVar1 != '\0') {
      FUN_00588320();
      uStack_8 = 0;
      FUN_005542c0("RobuxUpsellStarted",0x12);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uVar2 = 0;
      FUN_005542c0("prompted",8);
      uStack_8 = 0xffffffff;
      FUN_0087a3e0(param_1,uVar2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23719 ; VA 0x00b30d10 ; FUN_00b30d10 */

int __thiscall FUN_00b30d10(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined uVar4;
  undefined uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined auStack_20 [8];
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar5 = DAT_01eee1ba;
  uVar4 = DAT_01eee1b9;
  uVar3 = DAT_01eee1b8;
  puStack_c = &LAB_017f1280;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uVar6 = FUN_00b138b0(auStack_20,FUN_00b1da00,param_3,param_4,uVar4,uVar3,uVar5);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar7 = FUN_00b154e0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x40),
                       *(undefined4 *)(param_1 + 0x44),uVar6);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 23720 ; VA 0x00b30e00 ; FUN_00b30e00 */

int __thiscall FUN_00b30e00(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00b249e0(param_1,param_2,param_3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23721 ; VA 0x00b30ea0 ; FUN_00b30ea0 */

/* WARNING: Removing unreachable block (ram,0x00b30f3c) */
/* WARNING: Removing unreachable block (ram,0x00b30f4a) */
/* WARNING: Removing unreachable block (ram,0x00b30fa5) */
/* WARNING: Removing unreachable block (ram,0x00b30f5a) */

void __thiscall FUN_00b30ea0(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f12a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00a5b570(param_1,uStack_30,uStack_2c,uStack_28,uStack_24,CONCAT44(uStack_1c,uStack_20),
               in_stack_0000001c,in_stack_00000020,in_stack_00000024,in_stack_00000028,&uStack_18);
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23722 ; VA 0x00b30fc0 ; FUN_00b30fc0 */

int __thiscall
FUN_00b30fc0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00b24d70(param_1,param_2,param_3,param_4,param_5,param_6);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23723 ; VA 0x00b31060 ; FUN_00b31060 */

int __thiscall
FUN_00b31060(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00b24d70(param_1,param_2,param_3,param_4,param_5,param_6);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23724 ; VA 0x00b31100 ; FUN_00b31100 */

void __thiscall FUN_00b31100(int *param_1,char param_2)

{
  int iVar1;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9648;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008f7870(param_1);
  if (iVar1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("MarketplaceService must be in DataModel when calling PromptPremiumPurchase");
  }
  if (*(int *)(iVar1 + 0x4a0) == 1) {
    uStack_18 = 0;
    uStack_14 = 0;
    FUN_006eccd0();
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = 0;
    (**(code **)(*param_1 + 8))(&DAT_0212b5f8,&uStack_24,&uStack_18);
    uStack_8 = 1;
    FUN_00577b20();
    uStack_8 = 0xffffffff;
    if (param_2 != '\0') {
      FUN_00b30710(param_1);
    }
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Can only signal that the premium prompt is finished from client");
}



/* FUNCTION 23725 ; VA 0x00b311e0 ; FUN_00b311e0 */

void FUN_00b311e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  code *pcVar1;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f12e7;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b1bf20(param_1,param_2,param_3,param_4,param_5);
  pcVar1 = *(code **)(*piStack_14 + 8);
  uStack_298 = FUN_0088da50();
  uStack_294 = 0;
  uStack_290 = param_1;
  uStack_28c = param_2;
  uStack_294 = FUN_005c9e80();
  uStack_8 = 0;
  uStack_1c8 = FUN_0088da50();
  uStack_1c0 = param_3;
  uStack_1c4 = 0;
  uStack_1bc = param_4;
  uStack_1c4 = FUN_005c9e80();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_f8 = FUN_0088daf0();
  uStack_f4 = 0;
  uStack_f0 = (undefined)param_5;
  uStack_f4 = FUN_005c9ef0();
  uStack_8 = 2;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_298,&uStack_28,param_5);
  uStack_8._0_1_ = 3;
  (*pcVar1)(&DAT_0212b140,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_298,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23726 ; VA 0x00b31350 ; FUN_00b31350 */

int __thiscall
FUN_00b31350(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined8 uVar8;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f1318;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  if ((char)param_6 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_00562c90(&iStack_1c,&param_2);
    iStack_8._0_1_ = 1;
    if (iStack_1c != 0) {
      puVar6 = (undefined4 *)FUN_00b264d0(auStack_24);
      iStack_8._0_1_ = 2;
      pcVar3 = *(code **)(*(int *)*puVar6 + 8);
      uVar8 = FUN_00928340();
      (*pcVar3)(uVar8,param_4,param_5);
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar7 = piStack_20[1] + -1;
        piStack_20[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar7 = piStack_20[2] + -1;
          piStack_20[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_18[1] + -1;
      piStack_18[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar7 = piStack_18[2] + -1;
        piStack_18[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  uVar5 = uStack_14;
  FUN_0087c450(&DAT_018c5f98,"PurchasingEvents","PromptPurchaseFinished",0,0,0);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar7 = FUN_00b24d70(uVar5,param_2,param_3,param_4,param_5,param_6);
  piVar4 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 23727 ; VA 0x00b314b0 ; FUN_00b314b0 */

int __thiscall
FUN_00b314b0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00b24d70(param_1,param_2,param_3,param_4,param_5,param_6);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23728 ; VA 0x00b31550 ; FUN_00b31550 */

int __thiscall
FUN_00b31550(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00b24d70(param_1,param_2,param_3,param_4,param_5,param_6);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23729 ; VA 0x00b315f0 ; FUN_00b315f0 */

/* WARNING: Type propagation algorithm not settling */

int __thiscall FUN_00b315f0(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  int *piStack_1e0;
  int *piStack_1dc;
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined uStack_1c8;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int aiStack_24 [3];
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1364;
  pvStack_10 = ExceptionList;
  piStack_1dc = (int *)0x1;
  ExceptionList = &pvStack_10;
  piStack_1e0 = param_1;
  iVar6 = FUN_0098c5a0();
  if ((char)iVar6 == '\0') {
    piStack_1e0 = (int *)0xb3162b;
    piStack_1dc = param_1;
    uVar7 = FUN_0097bfc0();
    piStack_1e0 = (int *)0x1;
    cVar5 = FUN_00973950(param_1);
    if (cVar5 == '\0') {
      FUN_0060dcd0(&piStack_1e0,uVar7);
      iVar6 = FUN_00b25910(param_1,param_2);
    }
    else {
      piStack_1e0 = aiStack_24 + 3;
      uStack_2c = 0;
      uStack_28 = 0;
      piStack_1dc = (int *)uVar7;
      FUN_0060dcd0();
      iStack_8 = 0;
      pcVar3 = *(code **)(*param_1 + 8);
      piStack_1dc = (int *)0xb3166c;
      uStack_1d0 = FUN_0088daf0();
      uStack_1cc = 0;
      uStack_1c8 = (undefined)param_2;
      piStack_1dc = (int *)0xb3168a;
      uStack_1cc = FUN_005c9ef0();
      iStack_8._0_1_ = 1;
      piStack_1dc = (int *)0xb31699;
      uStack_100 = FUN_0088cdc0();
      iStack_f8 = iStack_18;
      uStack_fc = 0;
      uStack_f4 = piStack_14;
      iStack_18 = 0;
      piStack_14 = (int *)0x0;
      piStack_1dc = (int *)0xb316ce;
      uStack_fc = FUN_006309e0();
      piStack_1dc = (int *)param_2;
      piStack_1e0 = &iStack_30;
      iStack_8._0_1_ = 2;
      aiStack_24[0] = 0;
      aiStack_24[1] = 0;
      aiStack_24[2] = 0;
      FUN_00687980(&uStack_1d0);
      piStack_1dc = &uStack_2c;
      iStack_8._0_1_ = 3;
      piStack_1e0 = aiStack_24;
      (*pcVar3)(&DAT_0212b248);
      iStack_8._0_1_ = 4;
      FUN_00577b20();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      iVar6 = FUN_016f32d1(&uStack_1d0,0xd0,2,FUN_0056e5b0);
      piVar4 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_14 + 1;
        iVar2 = *piVar1;
        iVar6 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar6 = (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            iVar6 = (**(code **)(*piVar4 + 4))();
            ExceptionList = pvStack_10;
            return iVar6;
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 23730 ; VA 0x00b3177a ; FUN_00b3177a */

void FUN_00b3177a(void)

{
  int unaff_EBP;
  undefined4 unaff_EDI;
  undefined auStack_8 [8];
  
  FUN_0060dcd0(auStack_8);
  FUN_00b25910(unaff_EDI,*(undefined4 *)(unaff_EBP + 8));
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 23731 ; VA 0x00b317b0 ; FUN_00b317b0 */

undefined * FUN_00b317b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f137c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee594) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee594);
    if (DAT_01eee594 == -1) {
      uStack_8 = 0;
      FUN_00ddcf50();
      FUN_016f3654(&LAB_0188d9d0);
      FUN_016f37bf(&DAT_01eee594);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee530;
}



/* FUNCTION 23732 ; VA 0x00b31840 ; FUN_00b31840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b31840(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f13a6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee52c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee52c);
    if (DAT_01eee52c == -1) {
      uStack_8 = 0;
      FUN_009ca470("CurrencyType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eee4c8 = RBX::Reflection::EnumDesc<enum_RBX::MarketplaceService::CurrencyType>::vftable
      ;
      FUN_009caf20(&DAT_01d66f14,3);
      FUN_016f3654(&LAB_0188d9f0);
      FUN_016f37bf(&DAT_01eee52c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee4c8;
}



/* FUNCTION 23733 ; VA 0x00b318f0 ; FUN_00b318f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b318f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f13c6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee4c4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee4c4);
    if (DAT_01eee4c4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("InfoType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eee460 = RBX::Reflection::EnumDesc<enum_RBX::MarketplaceService::InfoType>::vftable;
      FUN_009caf20(&DAT_01d66f2c,5);
      FUN_016f3654(&LAB_0188da10);
      FUN_016f37bf(&DAT_01eee4c4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee460;
}



/* FUNCTION 23734 ; VA 0x00b319a0 ; FUN_00b319a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b319a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f13e6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee45c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee45c);
    if (DAT_01eee45c == -1) {
      uStack_8 = 0;
      FUN_009ca470("ProductPurchaseDecision");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eee3f8 =
           RBX::Reflection::EnumDesc<enum_RBX::MarketplaceService::ProductPurchaseDecision>::vftable
      ;
      FUN_009caf20(&DAT_01d66f54,2);
      FUN_016f3654(&LAB_0188da30);
      FUN_016f37bf(&DAT_01eee45c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee3f8;
}



/* FUNCTION 23735 ; VA 0x00b31a50 ; FUN_00b31a50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b31a50(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee5a4) {
    FUN_016f3809(&DAT_01eee5a4);
    if (DAT_01eee5a4 == -1) {
      _DAT_01eee598 = FUN_005c65e0;
      _DAT_01eee59c = FUN_005c65e0;
      _DAT_01eee5a0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eee5a4);
    }
  }
  return &DAT_01eee598;
}



/* FUNCTION 23736 ; VA 0x00b31ac0 ; FUN_00b31ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b31ac0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee5d4) {
    FUN_016f3809(&DAT_01eee5d4);
    if (DAT_01eee5d4 == -1) {
      _DAT_01eee5c8 = FUN_005c65e0;
      _DAT_01eee5cc = FUN_005c65e0;
      _DAT_01eee5d0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eee5d4);
    }
  }
  return &DAT_01eee5c8;
}



/* FUNCTION 23737 ; VA 0x00b31b30 ; FUN_00b31b30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b31b30(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee5c4) {
    FUN_016f3809(&DAT_01eee5c4);
    if (DAT_01eee5c4 == -1) {
      _DAT_01eee5b8 = FUN_005c65e0;
      _DAT_01eee5bc = FUN_005c65e0;
      _DAT_01eee5c0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eee5c4);
    }
  }
  return &DAT_01eee5b8;
}



/* FUNCTION 23738 ; VA 0x00b31ba0 ; FUN_00b31ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b31ba0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee5b4) {
    FUN_016f3809(&DAT_01eee5b4);
    if (DAT_01eee5b4 == -1) {
      _DAT_01eee5a8 = FUN_005c65e0;
      _DAT_01eee5ac = FUN_005c65e0;
      _DAT_01eee5b0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eee5b4);
    }
  }
  return &DAT_01eee5a8;
}



/* FUNCTION 23739 ; VA 0x00b31c10 ; FUN_00b31c10 */

void __thiscall FUN_00b31c10(int param_1,int param_2)

{
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f13f8;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    auStack_30[0] = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005880d0(param_1);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_30);
    uStack_8 = 1;
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23740 ; VA 0x00b31ca0 ; FUN_00b31ca0 */

int FUN_00b31ca0(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined8 uVar7;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1428;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00562c90(&iStack_18,&param_1);
  uStack_8._0_1_ = 1;
  if (iStack_18 != 0) {
    puVar6 = (undefined4 *)FUN_00b264d0(auStack_20);
    uStack_8._0_1_ = 2;
    pcVar4 = *(code **)(*(int *)*puVar6 + 0x34);
    uVar7 = FUN_00928340();
    iVar5 = (*pcVar4)(uVar7,param_3,param_4);
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar3 = *piVar1;
        iVar5 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar5 = (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piVar1 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23741 ; VA 0x00b31da0 ; FUN_00b31da0 */

void __thiscall
FUN_00b31da0(int param_1,int param_2,undefined *param_3,int param_4,undefined *param_5,uint param_6)

{
  int *piVar1;
  longlong lVar2;
  undefined *puVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int *piVar8;
  byte *pbVar9;
  longlong lVar10;
  uint in_stack_00000034;
  undefined auStack_1cc [8];
  undefined4 uStack_1c4;
  undefined4 *puStack_1c0;
  undefined auStack_1bc [24];
  undefined4 uStack_1a4;
  undefined4 *puStack_1a0;
  undefined auStack_19c [32];
  int iStack_17c;
  undefined *puStack_178;
  int iStack_174;
  undefined *puStack_170;
  undefined auStack_16c [96];
  undefined4 uStack_10c;
  undefined4 uStack_108;
  char *pcStack_104;
  undefined4 uStack_100;
  uint uStack_fc;
  undefined *puStack_f8;
  byte **ppbStack_f4;
  undefined *puStack_f0;
  int *piStack_ec;
  byte **ppbStack_e8;
  int iStack_c0;
  uint uStack_ac;
  int iStack_8c;
  uint uStack_78;
  undefined auStack_70 [24];
  undefined4 uStack_58;
  code *pcStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  double dStack_40;
  int iStack_38;
  byte *pbStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  byte *pbStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f14ac;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  piStack_ec = (int *)0xb31dda;
  ExceptionList = &pvStack_10;
  ppbStack_e8 = (byte **)param_1;
  iStack_38 = param_1;
  iVar5 = FUN_0097ee20();
  puVar3 = param_3;
  lVar2 = CONCAT44(param_3,param_2);
  if (iVar5 == 1) {
    piStack_ec = (int *)0xb31dee;
    ppbStack_e8 = (byte **)param_1;
    iVar5 = FUN_0064e810();
    if ((iVar5 != 0) && (*(int *)(iVar5 + 0xf4) != 0)) {
      ppbStack_e8 = (byte **)0xb31e04;
      lVar10 = FUN_00928340();
      if (lVar10 == lVar2) goto LAB_00b31e3b;
    }
    uStack_100 = 0x3f;
    piStack_ec = (int *)0x0;
    ppbStack_e8 = (byte **)0xf;
    pcStack_104 = "MarketPlace:UserOwnsGamePassAsync() can only query local player";
    uStack_fc = uStack_fc & 0xffffff00;
    uStack_108 = 0xb31e2e;
    FUN_005542c0();
    uStack_100 = 0xb31e36;
    FUN_005e65e0();
    goto LAB_00b322c7;
  }
LAB_00b31e3b:
  if (((int)puVar3 < 1) && ((int)puVar3 < 0)) {
    if (param_6 == 0) {
      ppbStack_e8 = (byte **)0xb32334;
      ppbStack_e8 = (byte **)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      piStack_ec = (int *)0xb3233e;
      FUN_0054e5e0();
    }
    piStack_ec = (int *)&stack0x0000001c;
    ppbStack_e8 = (byte **)0x0;
    puStack_f0 = (undefined *)0xb31e5e;
    (**(code **)((param_6 & 0xfffffffe) + 4))();
    goto LAB_00b322c7;
  }
  ppbStack_e8 = (byte **)&dStack_40;
  piStack_ec = (int *)0xb31e6f;
  FUN_01682800();
  ppbStack_e8 = (byte **)(param_1 + 200);
  piStack_ec = (int *)0xb31e81;
  FUN_00591e70();
  uStack_8._0_1_ = 3;
  iVar5 = param_1 + 0xd9 + (uint)*(byte *)(param_1 + 0xd8);
  ppbStack_e8 = (byte **)(-(uint)(iVar5 != 0) & iVar5 + 1U);
  piStack_ec = &param_2;
  puStack_f0 = (undefined *)(((uint)puVar3 >> 2) + (int)puVar3 * 0x40 + param_2 ^ (uint)puVar3);
  ppbStack_f4 = &pbStack_14;
  puStack_f8 = (undefined *)0xb31ec0;
  FUN_00606ff0();
  if (pbStack_14 == (byte *)0x0) {
LAB_00b31f69:
    if (*(double *)(param_1 + 0xf0) <= dStack_40) {
      iStack_24 = param_1 + 0x84;
      ppbStack_e8 = (byte **)0xb31fb6;
      cVar4 = FUN_016793f0();
      if (cVar4 == '\0') {
        piStack_ec = (int *)0xb31fc4;
        ppbStack_e8 = (byte **)param_1;
        iVar5 = FUN_0064e810();
        if (iVar5 != 0) {
          pbStack_18 = (byte *)(iVar5 + 0x2a8);
          uStack_1c = CONCAT31(uStack_1c._1_3_,DAT_01eee1b9);
          piStack_ec = &iStack_2c;
          puStack_f0 = (undefined *)0xb31fea;
          ppbStack_e8 = (byte **)param_1;
          FUN_0060e0c0();
          ppbStack_e8 = (byte **)uStack_1c;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            piStack_28[2] = piStack_28[2] + 1;
            UNLOCK();
          }
          puStack_f0 = (undefined *)iStack_2c;
          piStack_ec = piStack_28;
          ppbStack_f4 = (byte **)0xb32020;
          puVar6 = (undefined4 *)FUN_00b163b0();
          pcStack_54 = FUN_00b303b0;
          piVar8 = (int *)puVar6[1];
          if (piVar8 != (int *)0x0) {
            LOCK();
            piVar8[2] = piVar8[2] + 1;
            UNLOCK();
            piVar8 = (int *)puVar6[1];
          }
          uStack_50 = *puVar6;
          piStack_4c = piVar8;
          uStack_1c = uStack_50;
          if (pbStack_30 != (byte *)0x0) {
            LOCK();
            iVar5 = *(int *)(pbStack_30 + 8) + -1;
            *(int *)(pbStack_30 + 8) = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              ppbStack_e8 = (byte **)0xb32055;
              (**(code **)(*(int *)pbStack_30 + 4))();
            }
          }
          if (piStack_28 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_28[2] + -1;
            piStack_28[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              ppbStack_e8 = (byte **)0xb3206a;
              (**(code **)(*piStack_28 + 4))();
            }
          }
          ppbStack_e8 = (byte **)DAT_02110da8;
          uStack_8._0_1_ = 5;
          piStack_ec = (int *)0xb32079;
          uVar7 = FUN_01675290();
          piStack_ec = (int *)0x24;
          uStack_8._0_1_ = 6;
          puStack_f0 = (undefined *)0xb32089;
          uStack_58 = uVar7;
          pbStack_30 = (byte *)FUN_01674e20();
          if (pbStack_30 == (byte *)0x0) {
            pbVar9 = (byte *)0x0;
          }
          else {
            pbStack_30[0] = 0;
            pbStack_30[1] = 0;
            pbStack_30[2] = 0;
            pbStack_30[3] = 0;
            pbStack_30[4] = 1;
            pbStack_30[5] = 0;
            pbStack_30[6] = 0;
            pbStack_30[7] = 0;
            *(code **)(pbStack_30 + 8) = FUN_00ae4280;
            *(code **)(pbStack_30 + 0xc) = FUN_0057e090;
            pbStack_30[0x10] = 0;
            pbStack_30[0x11] = 0;
            pbStack_30[0x12] = 0;
            pbStack_30[0x13] = 0;
            *(byte **)(pbStack_30 + 0x14) = pbStack_18;
            *(code **)(pbStack_30 + 0x18) = FUN_00b303b0;
            pbStack_30[0x1c] = 0;
            pbStack_30[0x1d] = 0;
            pbStack_30[0x1e] = 0;
            pbStack_30[0x1f] = 0;
            pbStack_30[0x20] = 0;
            pbStack_30[0x21] = 0;
            pbStack_30[0x22] = 0;
            pbStack_30[0x23] = 0;
            if (piVar8 != (int *)0x0) {
              LOCK();
              piVar8[2] = piVar8[2] + 1;
              UNLOCK();
            }
            *(undefined4 *)(pbStack_30 + 0x1c) = uStack_1c;
            *(int **)(pbStack_30 + 0x20) = piVar8;
            pbVar9 = pbStack_30;
          }
          piStack_ec = (int *)0xb320ed;
          ppbStack_e8 = (byte **)pbVar9;
          FUN_016797d0();
          if (pbVar9 != (byte *)0x0) {
            LOCK();
            *(int *)(pbVar9 + 4) = *(int *)(pbVar9 + 4) + 1;
            UNLOCK();
          }
          uStack_20 = 1;
          uStack_8._0_1_ = 7;
          piStack_ec = (int *)0xb32111;
          ppbStack_e8 = (byte **)uVar7;
          pbStack_14 = pbVar9;
          FUN_01675290();
          ppbStack_e8 = &pbStack_14;
          uStack_8._0_1_ = 5;
          piStack_ec = (int *)0xb32124;
          FUN_00614020();
          ppbStack_e8 = (byte **)0xb3212c;
          FUN_0056e750();
          uStack_8._0_1_ = 3;
          if (piVar8 != (int *)0x0) {
            LOCK();
            piVar1 = piVar8 + 2;
            iVar5 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar5 == 1) {
              ppbStack_e8 = (byte **)0xb32146;
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
      }
      puVar3 = param_3;
      ppbStack_e8 = (byte **)param_5;
      puStack_f8 = auStack_70;
      piStack_ec = (int *)param_4;
      puStack_f0 = param_3;
      ppbStack_f4 = (byte **)param_2;
      uStack_fc = 0xb3215c;
      FUN_00f56580();
      ppbStack_e8 = (byte **)0x0;
      piStack_ec = (int *)0x5;
      puStack_f0 = auStack_70;
      uStack_8._0_1_ = 8;
      ppbStack_f4 = (byte **)0xb32176;
      FUN_014cc090();
      ppbStack_e8 = (byte **)0x0;
      iStack_24 = CONCAT31(iStack_24._1_3_,DAT_01eee1b8);
      uStack_20 = CONCAT31(uStack_20._1_3_,DAT_01eee1b9);
      puStack_1a0 = &stack0x00000034;
      uStack_8._0_1_ = 9;
      uStack_10c = 0;
      puStack_170 = param_5;
      iStack_174 = param_4;
      puStack_178 = puVar3;
      iStack_17c = param_2;
      param_5 = auStack_19c;
      uStack_1a4 = 0xb321b3;
      FUN_0054f510();
      param_3 = auStack_1bc;
      uStack_8._0_1_ = 10;
      puStack_1c0 = &param_6;
      uStack_1c4 = 0xb321c8;
      FUN_0054f510();
      puStack_1c0 = (undefined4 *)iStack_24;
      uStack_8._0_1_ = 0xb;
      uStack_1c4 = uStack_20;
      FUN_0060dcd0(auStack_1cc,iStack_38);
      uStack_8._0_1_ = 9;
      FUN_00b13c90(auStack_16c,&LAB_00b32350);
      puStack_170 = (undefined *)0xb321fc;
      FUN_00b11060();
      uStack_10c = 0xb32207;
      FUN_014ccc70();
      uStack_8._0_1_ = 8;
      if (0xf < uStack_78) {
        ppbStack_e8 = (byte **)(uStack_78 + 1);
        iVar5 = iStack_8c;
        if (0xfff < ppbStack_e8) {
          iVar5 = *(int *)(iStack_8c + -4);
          ppbStack_e8 = (byte **)(uStack_78 + 0x24);
          if (0x1f < (iStack_8c - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
            ppbStack_e8 = (byte **)0xb32343;
            FUN_017167a3();
          }
        }
        puStack_f0 = (undefined *)0xb3223f;
        piStack_ec = (int *)iVar5;
        FUN_01674ea0();
      }
      ppbStack_e8 = (byte **)0xb32262;
      FUN_0056cfd0();
      if (0xf < uStack_ac) {
        ppbStack_e8 = (byte **)(uStack_ac + 1);
        iVar5 = iStack_c0;
        if (0xfff < ppbStack_e8) {
          iVar5 = *(int *)(iStack_c0 + -4);
          ppbStack_e8 = (byte **)(uStack_ac + 0x24);
          if (0x1f < (iStack_c0 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
            ppbStack_e8 = (byte **)&UNK_00b32348;
            FUN_017167a3();
          }
        }
        puStack_f0 = (undefined *)0xb32299;
        piStack_ec = (int *)iVar5;
        FUN_01674ea0();
      }
      ppbStack_e8 = (byte **)0xb322bf;
      FUN_005507b0();
    }
    else {
      uStack_100 = 0xf;
      piStack_ec = (int *)0x0;
      ppbStack_e8 = (byte **)0xf;
      pcStack_104 = "TooManyRequests";
      uStack_fc = uStack_fc & 0xffffff00;
      uStack_108 = 0xb31f99;
      FUN_005542c0();
      uStack_100 = 0xb31fa1;
      FUN_005e65e0();
    }
  }
  else {
    ppbStack_e8 = (byte **)(-(uint)(pbStack_14 + pbStack_14[0x10] + 0x11 != (byte *)0x0) &
                           (uint)(pbStack_14 + pbStack_14[0x10] + 0x11 + 1));
    iStack_2c = param_4;
    puStack_f0 = param_5;
    if (((int)param_5 < 1) && ((int)param_5 < 0)) {
      iStack_2c = -1 - param_4;
      puStack_f0 = (undefined *)(-(int)param_5 - 1);
    }
    piStack_ec = &param_4;
    puStack_f0 = (undefined *)
                 (((uint)puStack_f0 >> 2) + (int)puStack_f0 * 0x40 + param_4 ^ (uint)puStack_f0);
    ppbStack_f4 = &pbStack_18;
    puStack_f8 = (undefined *)0xb31f29;
    pbStack_14 = pbStack_14 + 0x10;
    FUN_00606ff0();
    if (pbStack_18 == (byte *)0x0) goto LAB_00b31f69;
    if (pbStack_18[0x18] == 0) {
      if (*(double *)(pbStack_18 + 0x10) <= dStack_40) goto LAB_00b31f69;
      ppbStack_e8 = (byte **)0x0;
      piStack_ec = (int *)0xb31f5f;
      FUN_008927d0();
    }
    else {
      ppbStack_e8 = (byte **)0x1;
      piStack_ec = (int *)0xb31f40;
      FUN_008927d0();
    }
  }
  ppbStack_e8 = (byte **)0xb322c7;
  FUN_005923a0();
LAB_00b322c7:
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (param_6 != 0) {
    if (((param_6 & 1) == 0) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0)) {
      puStack_f0 = &stack0x0000001c;
      ppbStack_e8 = (byte **)0x2;
      ppbStack_f4 = (byte **)0xb322e8;
      piStack_ec = (int *)puStack_f0;
      (**(code **)(param_6 & 0xfffffffe))();
    }
    param_6 = 0;
  }
  uStack_8 = 0xd;
  if (((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) &&
     (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
    puStack_f0 = &stack0x0000003c;
    ppbStack_e8 = (byte **)0x2;
    ppbStack_f4 = (byte **)0xb32316;
    piStack_ec = (int *)puStack_f0;
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23742 ; VA 0x00b32980 ; FUN_00b32980 */

int __thiscall FUN_00b32980(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int in_stack_00000020;
  undefined *puVar10;
  undefined8 *puVar11;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  int *piStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1568;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  iVar4 = FUN_008f7870(param_1);
  if (iVar4 != 0) {
    piVar5 = *(int **)(iVar4 + 0x43c);
    uStack_24 = CONCAT44(piVar5[1] - (int)piVar5,*piVar5 - (int)piVar5);
  }
  piVar5 = (int *)FUN_01674e20(0x24);
  if (piVar5 == (int *)0x0) {
    piVar5 = (int *)0x0;
  }
  else {
    piVar5[1] = 1;
    piVar5[2] = 1;
    *piVar5 = (int)std::
                   _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                   ::vftable;
    *(undefined *)(piVar5 + 3) = 0;
    piStack_18 = piVar5;
    iVar4 = FUN_00588320(0xb);
    piVar5[4] = iVar4;
    piVar5[5] = 0;
    piVar5[6] = 0x3f800000;
    piVar5[7] = 0;
    piVar5[8] = 0;
  }
  piStack_1c = piVar5 + 3;
  uStack_8._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  piStack_18 = piVar5;
  FUN_005542c0("playerId",8);
  puVar10 = &stack0x0000001c;
  uStack_8._0_1_ = 2;
  FUN_005c4eb0(auStack_3c);
  FUN_00632bc0(puVar10);
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    uVar9 = auStack_3c[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_3c[0] - 4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0("placeId",7);
  puVar11 = &uStack_24;
  uStack_8._0_1_ = 3;
  FUN_005c4eb0(auStack_3c);
  FUN_00632bc0(puVar11);
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    uVar9 = auStack_3c[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_3c[0] - 4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0("isValid",7);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puVar6 = (undefined4 *)FUN_005c4eb0(auStack_3c);
  uVar7 = FUN_0088daf0();
  *puVar6 = uVar7;
  in_stack_00000020 = FUN_005c9ef0();
  iVar4 = puVar6[1];
  if (iVar4 == in_stack_00000020) {
    *(undefined *)(puVar6 + 2) = 0;
  }
  else {
    if (iVar4 != 0) {
      (**(code **)(iVar4 + 8))(puVar6 + 2);
    }
    *(undefined *)(puVar6 + 2) = 0;
    puVar6[1] = in_stack_00000020;
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    uVar9 = auStack_3c[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_3c[0] - 4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0("productId",9);
  puVar10 = &stack0x00000024;
  uStack_8._0_1_ = 5;
  FUN_005c4eb0(auStack_3c);
  FUN_00632bc0(puVar10);
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    uVar9 = auStack_3c[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_3c[0] - 4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0("errorReason",0xb);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  puVar6 = (undefined4 *)FUN_005c4eb0(auStack_3c);
  uVar7 = FUN_0088cb40();
  *puVar6 = uVar7;
  in_stack_00000020 = FUN_005c9d30();
  iVar4 = puVar6[1];
  if (iVar4 == in_stack_00000020) {
    if ((undefined4 **)(puVar6 + 2) != &param_2) {
      puVar6 = &param_2;
      if (0xf < in_stack_00000018) {
        puVar6 = param_2;
      }
      FUN_005542c0(puVar6,in_stack_00000014);
    }
  }
  else {
    if (iVar4 != 0) {
      (**(code **)(iVar4 + 8))(puVar6 + 2);
      puVar6[1] = 0;
    }
    FUN_0054ef60(&param_2);
    puVar6[1] = in_stack_00000020;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    uVar9 = auStack_3c[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_3c[0] - 4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  piVar1 = piVar5 + 1;
  if (piVar5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_00b24500(uStack_14,piVar5 + 3,piVar5);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar9 = in_stack_00000018 + 1;
    puVar6 = param_2;
    if (0xfff < uVar9) {
      puVar6 = (undefined4 *)param_2[-1];
      uVar9 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(puVar6,uVar9);
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23743 ; VA 0x00b32db0 ; FUN_00b32db0 */

int __thiscall FUN_00b32db0(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined uVar8;
  undefined **appuStack_cc [3];
  int iStack_c0;
  undefined **appuStack_bc [16];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined **ppuStack_64;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f15ca;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  appuStack_cc[0] = &PTR_018bf148;
  appuStack_bc[0] = (undefined **)&DAT_018bf150;
  ppuStack_64 = std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
  uStack_8 = 2;
  uStack_1c = 1;
  ExceptionList = &pvStack_10;
  FUN_0054edc0(appuStack_bc + 2,0,0);
  *(undefined ***)((int)appuStack_bc + (int)appuStack_bc[0][1]) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&iStack_c0 + (int)appuStack_bc[0][1]) = appuStack_bc[0][1] + -8;
  *(undefined ***)((int)appuStack_cc + (int)appuStack_cc[0][1]) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(appuStack_cc[0][1] + (int)&stack0xffffff30) = appuStack_cc[0][1] + -0x20;
  uStack_8 = 6;
  *(undefined ***)((int)appuStack_cc + (int)appuStack_cc[0][1]) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_cc[0][1] + (int)&stack0xffffff30) = appuStack_cc[0][1] + -0x68;
  FUN_0054ee60();
  appuStack_bc[2] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_7c = 0;
  uStack_78 = 0;
  puVar5 = &param_2;
  if (0xf < in_stack_00000018) {
    puVar5 = param_2;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_0055b3b0(appuStack_bc,puVar5,in_stack_00000014);
  cVar4 = FUN_0098f070(&param_2,&uStack_18,0);
  if (cVar4 == '\0') {
    uVar8 = 0;
    FUN_005542c0("VerifyResponse Failed",0x15);
    FUN_00b32980(uVar8);
  }
  else {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    FUN_00b24500(param_1,uStack_18,piStack_14);
  }
  iVar6 = FUN_005705c0();
  piVar3 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar7 = in_stack_00000018 + 1;
    puVar5 = param_2;
    if (0xfff < uVar7) {
      puVar5 = (undefined4 *)param_2[-1];
      uVar7 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(puVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 23744 ; VA 0x00b32ff0 ; FUN_00b32ff0 */

int FUN_00b32ff0(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined *puVar4;
  undefined *puVar5;
  int iVar6;
  undefined4 *puVar7;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined *in_stack_00000028;
  undefined4 auStack_b0 [3];
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined *puStack_98;
  undefined4 uStack_94;
  undefined auStack_90 [20];
  undefined4 uStack_7c;
  int iStack_78;
  undefined *puStack_74;
  undefined4 uStack_44;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined8 uStack_28;
  int *piStack_20;
  undefined *puStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1600;
  pvStack_10 = ExceptionList;
  puStack_74 = (undefined *)0x0;
  uStack_8 = 0;
  uStack_7c = 0xb33021;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_00971ce0();
  if ((char)iVar6 != '\0') {
    uStack_28 = 0;
    iStack_78 = 0xb3303a;
    iVar6 = FUN_008f7870();
    if (iVar6 == 0) {
      iStack_14 = (int)uStack_28._4_4_;
      iStack_18 = (int)uStack_28;
    }
    else {
      piVar2 = *(int **)(iVar6 + 0x43c);
      iStack_18 = *piVar2 - (int)piVar2;
      iStack_14 = piVar2[1] - (int)piVar2;
    }
    puStack_74 = auStack_30;
    iStack_78 = 0xb3306f;
    puVar7 = (undefined4 *)FUN_00b264d0();
    puVar4 = in_stack_00000028;
    uVar3 = in_stack_00000024;
    piStack_20 = (int *)*puVar7;
    uStack_94 = 0;
    uStack_28 = CONCAT44(*(undefined4 *)(*piStack_20 + 0x18),(int)uStack_28);
    uStack_8._0_1_ = 1;
    auStack_b0[0] = 0;
    uStack_a4 = in_stack_0000001c;
    uStack_a0 = in_stack_00000020;
    uStack_9c = in_stack_00000024;
    puStack_98 = in_stack_00000028;
    in_stack_00000028 = auStack_90;
    FUN_00b118b0(FUN_00b32980);
    puVar5 = puStack_1c;
    puStack_1c = (undefined *)auStack_b0;
    uStack_8._0_1_ = 2;
    FUN_00b118b0(FUN_00b32db0,0,puVar5,uStack_44,in_stack_0000001c,in_stack_00000020,uVar3,puVar4,0)
    ;
    uStack_8._0_1_ = 3;
    FUN_0054ef60(&param_1);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar6 = (*uStack_28._4_4_)();
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piVar2 = piStack_2c + 1;
      iVar1 = *piVar2;
      iVar6 = *piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        puStack_74 = (undefined *)0xb33180;
        iVar6 = (**(code **)*piStack_2c)();
        LOCK();
        piVar2 = piStack_2c + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          puStack_74 = (undefined *)0xb3318f;
          iVar6 = (**(code **)(*piStack_2c + 4))();
        }
      }
    }
  }
  if (0xf < in_stack_00000018) {
    puStack_74 = (undefined *)(in_stack_00000018 + 1);
    iVar6 = param_1;
    if (0xfff < puStack_74) {
      iVar6 = *(int *)(param_1 + -4);
      puStack_74 = (undefined *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_74 = &UNK_00b331d6;
        FUN_017167a3();
      }
    }
    uStack_7c = 0xb331bc;
    iStack_78 = iVar6;
    iVar6 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 23745 ; VA 0x00b331e0 ; FUN_00b331e0 */

int * __fastcall FUN_00b331e0(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined auStack_14 [8];
  int iStack_c;
  int iStack_8;
  
  iVar3 = *param_1;
  iVar1 = FUN_00b33310();
  if (iVar3 == iVar1) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar1 = FUN_0088cb40();
  if (iVar3 == iVar1) {
    iVar3 = *param_1;
    iVar1 = FUN_0088cb40();
    if (iVar3 != iVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar6 = param_1 + 2;
    piVar2 = piVar6;
    if (param_1[1] == 0) {
      piVar2 = (int *)0x0;
    }
    if (piVar2[4] != 0) {
      piVar2 = (int *)FUN_00b33440(auStack_14,piVar2);
      iStack_8 = *piVar2;
      iStack_c = piVar2[1];
      iVar1 = FUN_00630eb0();
      iVar3 = param_1[1];
      if (iVar3 == iVar1) {
        *piVar6 = iStack_8;
        param_1[3] = iStack_c;
      }
      else {
        if (iVar3 != 0) {
          (**(code **)(iVar3 + 8))(piVar6);
        }
        param_1[2] = iStack_8;
        param_1[3] = iStack_c;
        param_1[1] = iVar1;
      }
      iVar3 = FUN_00b33310();
      *param_1 = iVar3;
      iVar1 = FUN_00b33310();
      if (iVar3 == iVar1) {
        if (param_1[1] == 0) {
          piVar6 = (int *)0x0;
        }
        return piVar6;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
  }
  thunk_FUN_00b33310();
  uVar4 = FUN_005543f0();
  uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
}



/* FUNCTION 23746 ; VA 0x00b33310 ; FUN_00b33310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b33310(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f161c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee5fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee5fc);
    if (DAT_01eee5fc == -1) {
      uStack_8 = 0;
      FUN_00888860("NumberRange",0x2b,0,0,0);
      _DAT_01eee5d8 = RBX::Reflection::TType<class_RBX::NumberRange>::vftable;
      FUN_016f3654(&LAB_0188dab0);
      FUN_016f37bf(&DAT_01eee5fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee5d8;
}



/* FUNCTION 23747 ; VA 0x00b333b0 ; FUN_00b333b0 */

float * __thiscall FUN_00b333b0(float *param_1,float param_2,float param_3)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 < param_2) {
    *param_1 = param_3;
    param_1[1] = param_2;
  }
  return param_1;
}



/* FUNCTION 23748 ; VA 0x00b333e0 ; FUN_00b333e0 */

undefined4 FUN_00b333e0(undefined4 param_1,undefined4 param_2)

{
  FUN_00b33640(param_1,param_2);
  return param_1;
}



/* FUNCTION 23749 ; VA 0x00b33400 ; FUN_00b33400 */

uint FUN_00b33400(uint param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined auStack_c [8];
  
  if (*(int *)(param_1 + 0x10) == 0) {
    return param_1 & 0xffffff00;
  }
  puVar2 = (undefined4 *)FUN_00b33440(auStack_c,param_1);
  *param_2 = *puVar2;
  uVar1 = puVar2[1];
  param_2[1] = uVar1;
  return CONCAT31((int3)((uint)uVar1 >> 8),1);
}


