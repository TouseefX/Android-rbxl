/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 1250 ; VA 0x004d2910 ; FUN_004d2910 */

void FUN_004d2910(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00bc5930(FUN_00bcbae0,0,s_GetAsync_021251d0,s_apiUrlPath_02132188,s_priority_02121eec,
               s_httpRequestType_0211cf5c,0,0,5,uStack_10,0);
  FUN_016f3654(&LAB_01891f80);
  return;
}



/* FUNCTION 1251 ; VA 0x004d2980 ; FUN_004d2980 */

void FUN_004d2980(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00bc5830(FUN_00bd14f0,0,s_PostAsyncFullUrl_021321ac,s_apiUrl_02132194,&DAT_0211cf8c,
               s_priority_02121eec,s_content_type_021251e8,s_httpRequestType_0211cf5c,0,0,0,5,
               uStack_10,0);
  FUN_016f3654(&LAB_01891fd0);
  return;
}



/* FUNCTION 1252 ; VA 0x004d2a10 ; FUN_004d2a10 */

void FUN_004d2a10(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00bc5830(FUN_00bd19e0,0,s_PostAsync_021251f8,s_apiUrlPath_02132188,&DAT_0211cf8c,
               s_priority_02121eec,s_content_type_021251e8,s_httpRequestType_0211cf5c,0,0,0,5,
               uStack_10,0);
  FUN_016f3654(&LAB_01892030);
  return;
}



/* FUNCTION 1253 ; VA 0x004d2aa0 ; FUN_004d2aa0 */

void FUN_004d2aa0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00bc5a00(FUN_00bd1f20,0,s_RequestLimitedAsync_021321c0,s_requestOptions_02125204,
               s_priority_02121eec,s_content_type_021251e8,s_httpRequestType_0211cf5c,0,0,0,0,
               uStack_10,0);
  FUN_016f3654(&LAB_01892090);
  return;
}



/* FUNCTION 1254 ; VA 0x004d2b20 ; FUN_004d2b20 */

void FUN_004d2b20(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00bc5a00(FUN_00bd20b0,0,s_RequestAsync_02125214,s_requestOptions_02125204,s_priority_02121eec,
               s_content_type_021251e8,s_httpRequestType_0211cf5c,0,0,0,5,uStack_10,0);
  FUN_016f3654(&LAB_018920a0);
  return;
}



/* FUNCTION 1255 ; VA 0x004d2bb0 ; FUN_004d2bb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d2bb0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017febdc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00bc46d0();
  FUN_009cb790(uVar2,s_GetDocumentationUrl_021321e0,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02132140 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HttpRbxApiService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02132178 = FUN_00bcbd50;
  _DAT_0213217c = 0;
  DAT_02132180 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02132164 = FUN_0088cb40();
  iVar1 = DAT_02132180;
  if (DAT_02132180 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_partialUrl_021321d4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018920b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1256 ; VA 0x004d2e10 ; FUN_004d2e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d2e10(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800126;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00bd37d0();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_Active_0212c204,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_021322a4 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02132270 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::HopperBin>::vftable;
    puVar5[1] = &DAT_02132270;
    puVar5[2] = 0xf4;
    puVar5[4] = FUN_00553510;
    puVar5[5] = 0;
  }
  if (DAT_021322a4 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021322a4;
    DAT_021322a4 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_021322a4;
  }
  DAT_021322a4 = puVar5;
  cVar2 = (*(code *)DAT_02132270[3])();
  if (cVar2 != '\0') {
    _DAT_02132294 = _DAT_02132294 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02132270[2])();
  if (cVar2 != '\0') {
    _DAT_02132294 = _DAT_02132294 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018921b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1257 ; VA 0x004d2f40 ; FUN_004d2f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d2f40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800144;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00bd5640();
  uVar3 = FUN_00bd37d0();
  FUN_009ca670(uVar3,uVar2,s_BinType_02132454,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02132230 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::HopperBin,enum_RBX::HopperBin::BinType>::vftable;
  _DAT_02132264 = uVar2;
  DAT_02132268 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02132268 == (undefined4 *)0x0) {
    DAT_02132268 = (undefined4 *)0x0;
  }
  else {
    *DAT_02132268 =
         RBX::Reflection::PropDescriptor<class_RBX::HopperBin,enum_RBX::HopperBin::BinType>::
         GetSetImpl<enum_RBX::HopperBin::BinType_(__thiscall_RBX::HopperBin::*)(void)const_,void_(__thiscall_RBX::HopperBin::*)(enum_RBX::HopperBin::BinType)>
         ::vftable;
    DAT_02132268[2] = &LAB_0074b660;
    DAT_02132268[3] = 0;
    DAT_02132268[4] = FUN_00bd5200;
    DAT_02132268[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213226c = FUN_00bd5640();
  cVar1 = (*(code *)DAT_02132230[3])();
  if (cVar1 != '\0') {
    _DAT_02132254 = _DAT_02132254 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02132230[2])();
  if (cVar1 != '\0') {
    _DAT_02132254 = _DAT_02132254 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018921d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1258 ; VA 0x004d3060 ; FUN_004d3060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d3060(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd37d0(uVar2,0);
  FUN_009cb970(uVar1,s_Deselected_02132484,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02132354 = 0x114;
  _DAT_02132320 =
       RBX::Reflection::
       EventDesc<class_RBX::HopperBin,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::HopperBin::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02132348 = 0;
  _DAT_0213234c = 0;
  _DAT_02132350 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_02132320 =
       RBX::Reflection::
       EventDesc<class_RBX::HopperBin,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::HopperBin::*>
       ::vftable;
  FUN_016f3654(&LAB_018921f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1259 ; VA 0x004d3150 ; FUN_004d3150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d3150(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd37d0(uVar2,0);
  FUN_009cb970(uVar1,s_ReplicatedSelected_02132470,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02132314 = 0x104;
  _DAT_021322e0 =
       RBX::Reflection::
       EventDesc<class_RBX::HopperBin,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::HopperBin::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02132308 = 0;
  _DAT_0213230c = 0;
  _DAT_02132310 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_021322e0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::HopperBin,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::HopperBin::*>
       ::vftable;
  _DAT_02132318 = 0;
  _DAT_0213231c = 0;
  FUN_016f3654(&LAB_01892200);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1260 ; VA 0x004d3260 ; FUN_004d3260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d3260(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01800173;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd37d0();
  FUN_009cb970(uVar1,s_Selected_02132464,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021322dc = 0x10c;
  iStack_8 = 0;
  _DAT_021322a8 =
       RBX::Reflection::
       EventDesc<class_RBX::HopperBin,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::HopperBin::*>
       ::vftable;
  FUN_0086e3d0(s_mouse_0213245c);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021322d0 = uStack_1c;
  _DAT_021322d4 = uStack_18;
  _DAT_021322d8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021322a8 =
       RBX::Reflection::
       EventDesc<class_RBX::HopperBin,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::HopperBin::*>
       ::vftable;
  FUN_016f3654(&LAB_01892210);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1261 ; VA 0x004d33b0 ; FUN_004d33b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d33b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180019c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00bd36f0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::BackpackItem,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_const_(__thiscall_RBX::BackpackItem::*)(void)const_,void_(__thiscall_RBX::BackpackItem::*)(class_RBX::TextureId_const&)>
              ::vftable;
    puVar3[2] = FUN_00bd4830;
    puVar3[3] = 0;
    puVar3[4] = FUN_00bd55a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_TextureId_02132448,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_021321f8 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213222c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213221c = _DAT_0213221c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021321f8[2])();
    if (cVar1 != '\0') {
      _DAT_0213221c = _DAT_0213221c & 0xfffffff3;
    }
  }
  DAT_021321f8 = RBX::Reflection::PropDescriptor<class_RBX::BackpackItem,class_RBX::TextureId>::
                 vftable;
  FUN_016f3654(&LAB_01892220);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1262 ; VA 0x004d3580 ; FUN_004d3580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d3580(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018001ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd37d0(uVar2,0);
  FUN_009cb790(uVar1,s_Disable_021324a0,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132398 = RBX::Reflection::BoundFuncDesc<class_RBX::HopperBin,void___cdecl(void),0>::vftable
  ;
  _DAT_021323d0 = FUN_00bd46c0;
  _DAT_021323d4 = 0;
  _DAT_021323bc = FUN_00888530();
  FUN_016f3654(&LAB_01892280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1263 ; VA 0x004d3620 ; FUN_004d3620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d3620(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018001da;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd37d0(uVar2,0);
  FUN_009cb790(uVar1,s_ToggleSelect_02132490,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132358 = RBX::Reflection::BoundFuncDesc<class_RBX::HopperBin,void___cdecl(void),0>::vftable
  ;
  _DAT_02132390 = &LAB_00a3d6e0;
  _DAT_02132394 = 0;
  _DAT_0213237c = FUN_00888530();
  FUN_016f3654(&LAB_01892290);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1264 ; VA 0x004d3830 ; FUN_004d3830 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d3830(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018009a3;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00();
  FUN_009cb970(uVar1,s_OnHttpResultApproved_021329e4,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0213286c = 0x90;
  iStack_8 = 0;
  _DAT_02132838 =
       RBX::Reflection::
       EventDesc<class_RBX::LogService,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::LogService::*>
       ::vftable;
  FUN_0086e3d0(s_isApproved_021329d8);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02132860 = uStack_1c;
  _DAT_02132864 = uStack_18;
  _DAT_02132868 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_02132838 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::LogService,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::LogService::*>
       ::vftable;
  _DAT_02132870 = 0;
  _DAT_02132874 = 1;
  FUN_016f3654(&LAB_01892410);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1265 ; VA 0x004d3990 ; FUN_004d3990 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d3990(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018009de;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00();
  FUN_009cb970(uVar1,s_MessageOut_021328f8,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0213267c = 0x58;
  iStack_8 = 0;
  _DAT_02132648 =
       RBX::Reflection::
       EventDesc<class_RBX::LogService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType)>_RBX::LogService::*>
       ::vftable;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_messageType_0212182c);
  thunk_FUN_0086f380();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02132670 = uStack_1c;
  _DAT_02132674 = uStack_18;
  _DAT_02132678 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02132648 =
       RBX::Reflection::
       EventDesc<class_RBX::LogService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType)>_RBX::LogService::*>
       ::vftable;
  FUN_016f3654(&LAB_01892420);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1266 ; VA 0x004d3bf0 ; FUN_004d3bf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d3bf0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01800a13;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00();
  FUN_009cb970(uVar1,s_ServerHttpResultOut_02132984,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021327ac = 0x80;
  iStack_8 = 0;
  _DAT_02132778 =
       RBX::Reflection::
       EventDesc<class_RBX::LogService,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::LogService::*>
       ::vftable;
  FUN_0086e3d0(s_httpResult_02132968);
  FUN_008881d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021327a0 = uStack_1c;
  _DAT_021327a4 = uStack_18;
  _DAT_021327a8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_02132778 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::LogService,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::LogService::*>
       ::vftable;
  _DAT_021327b0 = 0;
  _DAT_021327b4 = 1;
  FUN_016f3654(&LAB_01892460);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1267 ; VA 0x004d3d50 ; FUN_004d3d50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d3d50(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01800a59;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00();
  FUN_009cb970(uVar1,s_ServerMessageOut_02132904,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021326b4 = 0x68;
  iStack_8 = 0;
  _DAT_02132680 =
       RBX::Reflection::
       EventDesc<class_RBX::LogService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType,int),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType,int)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType,int)>_RBX::LogService::*>
       ::vftable;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_messageType_0212182c);
  thunk_FUN_0086f380();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_timestamp_02119240);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_021326a8 = uStack_1c;
  _DAT_021326ac = uStack_18;
  _DAT_021326b0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_02132680 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::LogService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType,int),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType,int)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::MessageType,int)>_RBX::LogService::*>
       ::vftable;
  _DAT_021326b8 = 0;
  _DAT_021326bc = 1;
  FUN_016f3654(&LAB_01892470);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1268 ; VA 0x004d3f00 ; FUN_004d3f00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d3f00(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01800a93;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00();
  FUN_009cb970(uVar1,s_HttpResultOut_02132974,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02132774 = 0x5c;
  iStack_8 = 0;
  _DAT_02132740 =
       RBX::Reflection::
       EventDesc<class_RBX::LogService,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::LogService::*>
       ::vftable;
  FUN_0086e3d0(s_httpResult_02132968);
  FUN_008881d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02132768 = uStack_1c;
  _DAT_0213276c = uStack_18;
  _DAT_02132770 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02132740 =
       RBX::Reflection::
       EventDesc<class_RBX::LogService,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::LogService::*>
       ::vftable;
  FUN_016f3654(&LAB_01892480);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1269 ; VA 0x004d4050 ; FUN_004d4050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d4050(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01800ace;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00();
  FUN_009cb970(uVar1,s_RequestScriptExecutionSignal_02132948,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02132734 = 0x70;
  iStack_8 = 0;
  _DAT_02132700 =
       RBX::Reflection::
       EventDesc<class_RBX::LogService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::LogService::*>
       ::vftable;
  FUN_0086e3d0(s_requestingPlayer_02132918);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_source_02119484);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02132728 = uStack_1c;
  _DAT_0213272c = uStack_18;
  _DAT_02132730 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_02132700 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::LogService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::LogService::*>
       ::vftable;
  _DAT_02132738 = 0;
  _DAT_0213273c = 0;
  FUN_016f3654(&LAB_01892490);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1270 ; VA 0x004d41e0 ; FUN_004d41e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d41e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800aea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00(uVar2,0);
  FUN_009cb790(uVar1,s_GetHttpResultHistory_021328c8,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021325c8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LogService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02132600 = FUN_00bdb970;
  _DAT_02132604 = 0;
  _DAT_021325ec = FUN_008882f0();
  FUN_016f3654(&LAB_018924a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1271 ; VA 0x004d4280 ; FUN_004d4280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d4280(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800b0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00(uVar2,0);
  FUN_009cb790(uVar1,s_GetLogHistory_02132878,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021324c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LogService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021324f8 = FUN_00bdbb80;
  _DAT_021324fc = 0;
  _DAT_021324e4 = FUN_008882f0();
  FUN_016f3654(&LAB_018924b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1272 ; VA 0x004d4320 ; FUN_004d4320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d4320(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800b2a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00(uVar2,0);
  FUN_009cb790(uVar1,s_RequestHttpResultApproved_0213289c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132540 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LogService,void___cdecl(void),0>::vftable;
  _DAT_02132578 = FUN_00bdeb20;
  _DAT_0213257c = 0;
  _DAT_02132564 = FUN_00888530();
  FUN_016f3654(&LAB_018924c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1273 ; VA 0x004d43c0 ; FUN_004d43c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d43c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800b4a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00(uVar2,0);
  FUN_009cb790(uVar1,s_RequestServerHttpResult_021328e0,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132608 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LogService,void___cdecl(void),0>::vftable;
  _DAT_02132640 = FUN_00bdeba0;
  _DAT_02132644 = 0;
  _DAT_0213262c = FUN_00888530();
  FUN_016f3654(&LAB_018924d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1274 ; VA 0x004d4460 ; FUN_004d4460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d4460(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800b6a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bd5c00(uVar2,0);
  FUN_009cb790(uVar1,s_RequestServerOutput_02132888,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132500 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LogService,void___cdecl(void),0>::vftable;
  _DAT_02132538 = FUN_00bdec00;
  _DAT_0213253c = 0;
  _DAT_02132524 = FUN_00888530();
  FUN_016f3654(&LAB_018924e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1275 ; VA 0x004d4500 ; FUN_004d4500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d4500(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800bcc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00bd5c00();
  FUN_009cb790(uVar2,s_ExecuteScript_021328b8,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02132580 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LogService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_021325b8 = FUN_00bdaa70;
  _DAT_021325bc = 0;
  DAT_021325c0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021325a4 = FUN_00888530();
  iVar1 = DAT_021325c0;
  if (DAT_021325c0 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_source_02119484);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018924f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1276 ; VA 0x004d46b0 ; FUN_004d46b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d46b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800bfe;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("apikey=",7);
  uStack_8 = 0;
  _DAT_01d67f00 = 0;
  _DAT_01d67f04 = 0xf;
  DAT_01d67ef0 = 0;
  FUN_005542c0("accesskey=",10);
  uStack_8._0_1_ = 1;
  _DAT_01d67f18 = 0;
  _DAT_01d67f1c = 0xf;
  DAT_01d67f08 = 0;
  FUN_005542c0("rbxcdn.com/",0xb);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  _DAT_01d67f30 = 0;
  _DAT_01d67f34 = 0xf;
  DAT_01d67f20 = 0;
  FUN_005542c0("ticket=",7);
  FUN_016f3654(&LAB_01892510);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1277 ; VA 0x004d47a0 ; FUN_004d47a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d47a0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01801523;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_2c = CONCAT31(uStack_2c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bdf550();
  FUN_009cb970(uVar1,s_VideoAdClosed_02132a8c,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02132a74 = 0x58;
  iStack_8 = 0;
  _DAT_02132a40 =
       RBX::Reflection::
       EventDesc<class_RBX::AdService,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::AdService::*>
       ::vftable;
  FUN_0086e3d0(s_adShown_02132a84);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02132a68 = uStack_1c;
  _DAT_02132a6c = uStack_18;
  _DAT_02132a70 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02132a40 =
       RBX::Reflection::
       EventDesc<class_RBX::AdService,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::AdService::*>
       ::vftable;
  FUN_016f3654(&LAB_01892590);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1278 ; VA 0x004d48f0 ; FUN_004d48f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d48f0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180153a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bdf550(uVar2,0);
  FUN_009cb790(uVar1,s_ShowVideoAd_02132a78,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132a00 = RBX::Reflection::BoundFuncDesc<class_RBX::AdService,void___cdecl(void),0>::vftable
  ;
  _DAT_02132a38 = &LAB_00bdf820;
  _DAT_02132a3c = 0;
  _DAT_02132a24 = FUN_00888530();
  FUN_016f3654(&LAB_018925a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1279 ; VA 0x004d49d0 ; FUN_004d49d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d49d0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("TeamChildOrderProperty",0x16);
  _DAT_01ef6d54 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1280 ; VA 0x004d4a30 ; FUN_004d4a30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d4a30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018015da;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bdf840(uVar2,0);
  FUN_009cb790(uVar1,s_GetTeams_02132b30,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132ae0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Teams,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02132b18 = FUN_00bdffa0;
  _DAT_02132b1c = 0;
  _DAT_02132b04 = FUN_0088cc80();
  FUN_016f3654(&LAB_01892610);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1281 ; VA 0x004d4ad0 ; FUN_004d4ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d4ad0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018015fa;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bdf840(uVar2,0);
  FUN_009cb790(uVar1,s_RebalanceTeams_02132b20,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132aa0 = RBX::Reflection::BoundFuncDesc<class_RBX::Teams,void___cdecl(void),0>::vftable;
  _DAT_02132ad8 = _guard_check_icall;
  _DAT_02132adc = 0;
  _DAT_02132ac4 = FUN_00888530();
  FUN_016f3654(&LAB_01892680);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1282 ; VA 0x004d4c80 ; FUN_004d4c80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d4c80(void)

{
  undefined4 uVar1;
  undefined auStack_390 [864];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01801d04;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00be0bd0();
  FUN_009cb970(uVar1,s_PointsAwarded_02132d14,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02132c8c = 0x94;
  iStack_8 = 0;
  _DAT_02132c58 =
       RBX::Reflection::
       EventDesc<class_RBX::PointsService,void___cdecl(__int64,int,int,int),class_rbx::remote_signal<void___cdecl(__int64,int,int,int)>,class_rbx::remote_signal<void___cdecl(__int64,int,int,int)>_RBX::PointsService::*>
       ::vftable;
  FUN_0086e3d0(s_userId_0211fb64);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_pointsAwarded_02132d04);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_userBalanceInGame_02132cf0);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(s_userTotalBalance_02132cdc);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_390,&uStack_30,uStack_20);
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  _DAT_02132c80 = uStack_1c;
  _DAT_02132c84 = uStack_18;
  _DAT_02132c88 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_390,0xd8,4,FUN_00688b10);
  _DAT_02132c58 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::PointsService,void___cdecl(__int64,int,int,int),class_rbx::remote_signal<void___cdecl(__int64,int,int,int)>,class_rbx::remote_signal<void___cdecl(__int64,int,int,int)>_RBX::PointsService::*>
       ::vftable;
  _DAT_02132c90 = 1;
  _DAT_02132c94 = 1;
  FUN_016f3654(&LAB_018926f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1283 ; VA 0x004d4e50 ; FUN_004d4e50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d4e50(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801d2e;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00be0bd0(uVar2,0);
  FUN_009cb820(uVar1,s_AwardPoints_02132cd0,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02132c10 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::PointsService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(__int64,int),2>
       ::vftable;
  _DAT_02132c48 = FUN_00be4080;
  _DAT_02132c4c = 0;
  DAT_02132c50 = 0;
  DAT_02132c54 = 0;
  uStack_8 = 2;
  FUN_00be4b00();
  FUN_016f3654(&LAB_01892700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1284 ; VA 0x004d4f10 ; FUN_004d4f10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d4f10(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801d4a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00be0bd0(uVar2,0);
  FUN_009cb790(uVar1,s_GetAwardablePoints_02132cbc,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132bd0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PointsService,int___cdecl(void),0>::vftable;
  _DAT_02132c08 = FUN_00555290;
  _DAT_02132c0c = 0;
  _DAT_02132bf4 = FUN_0088c8c0();
  FUN_016f3654(&LAB_01892740);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1285 ; VA 0x004d4fb0 ; FUN_004d4fb0 */

void FUN_004d4fb0(void)

{
  FUN_00be1ed0(FUN_00be5310,0,s_GetPointBalance_02132c98,s_userId_0211fb64,0,1,0);
  FUN_016f3654(&LAB_01892750);
  return;
}



/* FUNCTION 1286 ; VA 0x004d5010 ; FUN_004d5010 */

void FUN_004d5010(void)

{
  FUN_00be1ed0(FUN_00be53c0,0,s_GetGamePointBalance_02132ca8,s_userId_0211fb64,0,1,0);
  FUN_016f3654(&LAB_01892770);
  return;
}



/* FUNCTION 1287 ; VA 0x004d50e0 ; FUN_004d50e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d50e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018022ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00be79a0(uVar2,0);
  FUN_009cb790(uVar1,s_IsFinishedReplicating_02132f00,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132da0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ReplicatedFirst,bool___cdecl(void),0>::vftable;
  _DAT_02132dd8 = &LAB_009f5e70;
  _DAT_02132ddc = 0;
  _DAT_02132dc4 = FUN_0088daf0();
  FUN_016f3654(&LAB_01892820);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1288 ; VA 0x004d5180 ; FUN_004d5180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5180(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018022ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00be79a0(uVar2,0);
  FUN_009cb790(uVar1,s_IsDefaultLoadingGuiRemoved_02132f38,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132e18 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ReplicatedFirst,bool___cdecl(void),0>::vftable;
  _DAT_02132e50 = &LAB_00855c90;
  _DAT_02132e54 = 0;
  _DAT_02132e3c = FUN_0088daf0();
  FUN_016f3654(&LAB_01892830);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1289 ; VA 0x004d5220 ; FUN_004d5220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5220(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180230a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00be79a0(uVar2,0);
  FUN_009cb790(uVar1,s_RemoveDefaultLoadingScreen_02132ed0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132d28 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ReplicatedFirst,void___cdecl(void),0>::vftable;
  _DAT_02132d60 = &LAB_00be7f30;
  _DAT_02132d64 = 0;
  _DAT_02132d4c = FUN_00888530();
  FUN_016f3654(&LAB_01892840);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1290 ; VA 0x004d52c0 ; FUN_004d52c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d52c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180232a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00be79a0(uVar2,0);
  FUN_009cb790(uVar1,s_SetDefaultLoadingGuiRemoved_02132f54,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02132e58 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ReplicatedFirst,void___cdecl(void),0>::vftable;
  _DAT_02132e90 = FUN_00be8470;
  _DAT_02132e94 = 0;
  _DAT_02132e7c = FUN_00888530();
  FUN_016f3654(&LAB_01892850);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1291 ; VA 0x004d5370 ; FUN_004d5370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5370(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018024aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00be8480(uVar2,0);
  FUN_009cb790(uVar1,s_ClearJoinAfterMoveJoints_02133164,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021330a0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::JointsService,void___cdecl(void),0>::vftable;
  _DAT_021330d8 = FUN_00be8b10;
  _DAT_021330dc = 0;
  _DAT_021330c4 = FUN_00888530();
  FUN_016f3654(&LAB_018928c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1292 ; VA 0x004d5410 ; FUN_004d5410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5410(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018024ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00be8480(uVar2,0);
  FUN_009cb790(uVar1,s_CreateJoinAfterMoveJoints_02133148,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02133060 =
       RBX::Reflection::BoundFuncDesc<class_RBX::JointsService,void___cdecl(void),0>::vftable;
  _DAT_02133098 = &LAB_00be8b30;
  _DAT_0213309c = 0;
  _DAT_02133084 = FUN_00888530();
  FUN_016f3654(&LAB_018928d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1293 ; VA 0x004d54b0 ; FUN_004d54b0 */

void FUN_004d54b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00be8580(FUN_00be94b0,0,s_SetJoinAfterMoveInstance_021330f0,s_joinInstance_021330e0,0,
               uStack_10,0);
  FUN_016f3654(&LAB_018928e0);
  return;
}



/* FUNCTION 1294 ; VA 0x004d5510 ; FUN_004d5510 */

void FUN_004d5510(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00be8580(FUN_00be9580,0,s_SetJoinAfterMoveTarget_02133118,s_joinTarget_0213310c,0,uStack_10,0)
  ;
  FUN_016f3654(&LAB_01892930);
  return;
}



/* FUNCTION 1295 ; VA 0x004d5570 ; FUN_004d5570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5570(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018024ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00be8480(uVar2,0);
  FUN_009cb790(uVar1,s_ShowPermissibleJoints_02133130,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02133020 =
       RBX::Reflection::BoundFuncDesc<class_RBX::JointsService,void___cdecl(void),0>::vftable;
  _DAT_02133058 = &LAB_00be9650;
  _DAT_0213305c = 0;
  _DAT_02133044 = FUN_00888530();
  FUN_016f3654(&LAB_01892980);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1296 ; VA 0x004d5800 ; FUN_004d5800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5800(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01803149;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bea180();
  FUN_009cb970(uVar1,s_RemoteFriendEventSignal_02133280,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021331b4 = 0x58;
  iStack_8 = 0;
  _DAT_02133180 =
       RBX::Reflection::
       EventDesc<class_RBX::FriendService,void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendEventType),class_rbx::remote_signal<void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendEventType)>,class_rbx::remote_signal<void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendEventType)>_RBX::FriendService::*>
       ::vftable;
  FUN_0086e3d0(s_userId_0211fb64);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_userId_0211fb64);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_event_02133278);
  FUN_00bfa7a0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_021331a8 = uStack_1c;
  _DAT_021331ac = uStack_18;
  _DAT_021331b0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_02133180 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::FriendService,void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendEventType),class_rbx::remote_signal<void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendEventType)>,class_rbx::remote_signal<void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendEventType)>_RBX::FriendService::*>
       ::vftable;
  _DAT_021331b8 = 1;
  _DAT_021331bc = 0;
  FUN_016f3654(&LAB_01892a00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1297 ; VA 0x004d59b0 ; FUN_004d59b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d59b0(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01803199;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bea180();
  FUN_009cb970(uVar1,s_RemoteFriendStatusSignal_02133298,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021331f4 = 0x60;
  iStack_8 = 0;
  _DAT_021331c0 =
       RBX::Reflection::
       EventDesc<class_RBX::FriendService,void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendStatus),class_rbx::remote_signal<void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendStatus)>,class_rbx::remote_signal<void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendStatus)>_RBX::FriendService::*>
       ::vftable;
  FUN_0086e3d0(s_userId_0211fb64);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_userId_0211fb64);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_status_02123f34);
  FUN_00935e70();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_021331e8 = uStack_1c;
  _DAT_021331ec = uStack_18;
  _DAT_021331f0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_021331c0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::FriendService,void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendStatus),class_rbx::remote_signal<void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendStatus)>,class_rbx::remote_signal<void___cdecl(__int64,__int64,enum_RBX::FriendService_FriendStatus)>_RBX::FriendService::*>
       ::vftable;
  _DAT_021331f8 = 0;
  _DAT_021331fc = 0;
  FUN_016f3654(&LAB_01892a10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1298 ; VA 0x004d5b60 ; FUN_004d5b60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5b60(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018031d3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bea180();
  FUN_009cb970(uVar1,s_FriendsUpdated_021332d4,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02133274 = 0x68;
  iStack_8 = 0;
  _DAT_02133240 =
       RBX::Reflection::
       EventDesc<class_RBX::FriendService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_RBX::FriendService::*>
       ::vftable;
  FUN_0086e3d0(s_friendData_021332c8);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02133268 = uStack_1c;
  _DAT_0213326c = uStack_18;
  _DAT_02133270 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02133240 =
       RBX::Reflection::
       EventDesc<class_RBX::FriendService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_RBX::FriendService::*>
       ::vftable;
  FUN_016f3654(&LAB_01892a20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1299 ; VA 0x004d5cb0 ; FUN_004d5cb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5cb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018031ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bea180(uVar2,0);
  FUN_009cb820(uVar1,s_GetPlatformFriends_021332b4,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02133200 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::FriendService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02133238 = FUN_00bf2630;
  _DAT_0213323c = 0;
  _DAT_02133224 = FUN_008882f0();
  FUN_016f3654(&LAB_01892a30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1300 ; VA 0x004d5de0 ; FUN_004d5de0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5de0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180431a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bfb120(uVar2,0);
  FUN_009cb790(uVar1,s_GetIsThirdPartyAssetAllowed_02133464,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02133378 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PermissionsService,bool___cdecl(void),0>::vftable;
  _DAT_021333b0 = FUN_007cfe50;
  _DAT_021333b4 = 0;
  _DAT_0213339c = FUN_0088daf0();
  FUN_016f3654(&LAB_01892ac0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1301 ; VA 0x004d5e80 ; FUN_004d5e80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5e80(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180433a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bfb120(uVar2,0);
  FUN_009cb790(uVar1,s_GetIsThirdPartyPurchaseAllowed_02133480,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021333b8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PermissionsService,bool___cdecl(void),0>::vftable;
  _DAT_021333f0 = FUN_00838a70;
  _DAT_021333f4 = 0;
  _DAT_021333dc = FUN_0088daf0();
  FUN_016f3654(&LAB_01892ad0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1302 ; VA 0x004d5f20 ; FUN_004d5f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5f20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180435a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bfb120(uVar2,0);
  FUN_009cb790(uVar1,s_GetIsThirdPartyTeleportAllowed_021334a0,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021333f8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PermissionsService,bool___cdecl(void),0>::vftable;
  _DAT_02133430 = FUN_00bfe4e0;
  _DAT_02133434 = 0;
  _DAT_0213341c = FUN_0088daf0();
  FUN_016f3654(&LAB_01892ae0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1303 ; VA 0x004d5fc0 ; FUN_004d5fc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5fc0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018043bc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bfb120();
  FUN_009cb790(uVar1,s_GetPermissions_02133438,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021332e8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PermissionsService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_02133320 = FUN_00bfe4f0;
  _DAT_02133324 = 0;
  DAT_02133328 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213330c = FUN_008882f0();
  if (DAT_02133328 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02133328);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_assetId_0211bf40);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_01892af0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1304 ; VA 0x004d6140 ; FUN_004d6140 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d6140(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018043ee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bfb120(uVar2,0);
  FUN_009cb790(uVar1,s_SetPermissions_02133454,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02133330 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PermissionsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),2>
       ::vftable;
  _DAT_02133368 = FUN_00bfe510;
  _DAT_0213336c = 0;
  _DAT_02133370 = 0;
  DAT_02133374 = 0;
  uStack_8 = 2;
  FUN_00bfd780();
  FUN_016f3654(&LAB_01892b10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1305 ; VA 0x004d6430 ; FUN_004d6430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d6430(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804dba;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c00240();
  FUN_0089a380(uVar3,s_Description_02133d48,&DAT_021197d4,0);
  uStack_8 = 0;
  DAT_021334c0 = RBX::Reflection::
                 BoundProp<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,1>
                 ::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::
              BoundProp<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,1>
              ::BoundPropGetSet<class_RBX::FunctionalTest>::vftable;
    puVar4[1] = &DAT_021334c0;
    puVar4[2] = 0x60;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_021334f4 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021334f4;
    DAT_021334f4 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_021334f4;
  }
  DAT_021334f4 = puVar4;
  cVar2 = (*(code *)DAT_021334c0[3])();
  if (cVar2 != '\0') {
    _DAT_021334e4 = _DAT_021334e4 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021334c0[2])();
  if (cVar2 != '\0') {
    _DAT_021334e4 = _DAT_021334e4 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1306 ; VA 0x004d6550 ; FUN_004d6550 */

void FUN_004d6550(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00c01110(FUN_00c04df0,0,s_Error_021205c8,s_message_02119b14);
  FUN_016f3654();
  return;
}



/* FUNCTION 1307 ; VA 0x004d65f0 ; FUN_004d65f0 */

void FUN_004d65f0(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00c01110(FUN_00c04df0,0,s_Failed_02133de4,s_message_02119b14);
  FUN_016f3654();
  return;
}



/* FUNCTION 1308 ; VA 0x004d66e0 ; FUN_004d66e0 */

void FUN_004d66e0(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00c01110(FUN_00c07010,0,&DAT_02133dd4,s_message_02119b14);
  FUN_016f3654();
  return;
}



/* FUNCTION 1309 ; VA 0x004d6780 ; FUN_004d6780 */

void FUN_004d6780(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00c01110(FUN_00c07010,0,s_Passed_02133ddc,s_message_02119b14);
  FUN_016f3654();
  return;
}



/* FUNCTION 1310 ; VA 0x004d6870 ; FUN_004d6870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d6870(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804dda;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c00240();
  FUN_00684770(uVar3,s_Timeout_02133d54,s_Settings_02119294,0);
  uStack_8 = 0;
  DAT_021334f8 = RBX::Reflection::BoundProp<double,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<double,1>::BoundPropGetSet<class_RBX::FunctionalTest>::
              vftable;
    puVar4[1] = &DAT_021334f8;
    puVar4[2] = 0x78;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_0213352c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0213352c;
    DAT_0213352c = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_0213352c;
  }
  DAT_0213352c = puVar4;
  cVar2 = (*(code *)DAT_021334f8[3])();
  if (cVar2 != '\0') {
    _DAT_0213351c = _DAT_0213351c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021334f8[2])();
  if (cVar2 != '\0') {
    _DAT_0213351c = _DAT_0213351c & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1311 ; VA 0x004d6990 ; FUN_004d6990 */

void FUN_004d6990(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00c01110(FUN_00c08d00,0,&DAT_02133dcc,s_message_02119b14);
  FUN_016f3654();
  return;
}



/* FUNCTION 1312 ; VA 0x004d6a30 ; FUN_004d6a30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d6a30(void)

{
  undefined4 uVar1;
  undefined auStack_390 [864];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01804e34;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c00340();
  FUN_009cb970(uVar1,s_ServerCollectConditionalResult_02133eec,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02133d3c = 0x1c8;
  iStack_8 = 0;
  _DAT_02133d08 =
       RBX::Reflection::
       EventDesc<class_RBX::TestService,void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int),class_rbx::remote_signal<void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int)>,class_rbx::remote_signal<void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int)>_RBX::TestService::*>
       ::vftable;
  FUN_0086e3d0(s_condition_02133eac);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(&DAT_02126680);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_script_021205b4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(&DAT_02133e90);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_390,&uStack_30,uStack_20);
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  _DAT_02133d30 = uStack_1c;
  _DAT_02133d34 = uStack_18;
  _DAT_02133d38 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_390,0xd8,4,FUN_00688b10);
  _DAT_02133d08 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::TestService,void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int),class_rbx::remote_signal<void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int)>,class_rbx::remote_signal<void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int)>_RBX::TestService::*>
       ::vftable;
  _DAT_02133d40 = 0;
  _DAT_02133d44 = 1;
  FUN_016f3654(&LAB_01892e40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1313 ; VA 0x004d6c00 ; FUN_004d6c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d6c00(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01804e79;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c00340();
  FUN_009cb970(uVar1,s_ServerCollectResult_02133ed8,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02133cfc = 0x1c0;
  iStack_8 = 0;
  _DAT_02133cc8 =
       RBX::Reflection::
       EventDesc<class_RBX::TestService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int)>_RBX::TestService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_02126680);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_script_021205b4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(&DAT_02133e90);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02133cf0 = uStack_1c;
  _DAT_02133cf4 = uStack_18;
  _DAT_02133cf8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_02133cc8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::TestService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>,int)>_RBX::TestService::*>
       ::vftable;
  _DAT_02133d00 = 0;
  _DAT_02133d04 = 1;
  FUN_016f3654(&LAB_01892e50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1314 ; VA 0x004d6db0 ; FUN_004d6db0 */

void FUN_004d6db0(void)

{
  uint uStack_14;
  
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00c01410(FUN_00c02a50,0,s_Check_02133eb8,s_condition_02133eac,s_description_0212171c,
               s_source_02119484,&DAT_02133e90,0,0,0,0,uStack_14,0);
  FUN_016f3654(&LAB_01892e60);
  return;
}



/* FUNCTION 1315 ; VA 0x004d6e30 ; FUN_004d6e30 */

void FUN_004d6e30(void)

{
  uint uStack_14;
  
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00c012f0(FUN_00c02cc0,0,s_Checkpoint_02133ea0,&DAT_02126680,s_source_02119484,&DAT_02133e90,0,
               0,0,0,uStack_14,0);
  FUN_016f3654(&LAB_01892e70);
  return;
}



/* FUNCTION 1316 ; VA 0x004d6eb0 ; FUN_004d6eb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d6eb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804e9a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c00340(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02133ed0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02133c88 =
       RBX::Reflection::BoundFuncDesc<class_RBX::TestService,void___cdecl(void),0>::vftable;
  _DAT_02133cc0 = FUN_00c04d30;
  _DAT_02133cc4 = 0;
  _DAT_02133cac = FUN_00888530();
  FUN_016f3654(&LAB_01892e80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1317 ; VA 0x004d6f50 ; FUN_004d6f50 */

void FUN_004d6f50(void)

{
  uint uStack_14;
  
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00c012f0(FUN_00c04ed0,0,s_Error_021205c8,s_description_0212171c,s_source_02119484,
               &DAT_02133e90,0,0,0,0,uStack_14,0);
  FUN_016f3654(&LAB_01892e90);
  return;
}



/* FUNCTION 1318 ; VA 0x004d6fd0 ; FUN_004d6fd0 */

void FUN_004d6fd0(void)

{
  uint uStack_14;
  
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00c012f0(FUN_00c05310,0,&DAT_02133ec8,s_description_0212171c,s_source_02119484,&DAT_02133e90,0
               ,0,0,0,uStack_14,0);
  FUN_016f3654(&LAB_01892ea0);
  return;
}



/* FUNCTION 1319 ; VA 0x004d7050 ; FUN_004d7050 */

void FUN_004d7050(void)

{
  uint uStack_14;
  
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00c012f0(FUN_00c063f0,0,s_Message_02133e98,&DAT_02126680,s_source_02119484,&DAT_02133e90,0,0,0
               ,0,uStack_14,0);
  FUN_016f3654(&LAB_01892eb0);
  return;
}



/* FUNCTION 1320 ; VA 0x004d70d0 ; FUN_004d70d0 */

void FUN_004d70d0(void)

{
  uint uStack_14;
  
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00c01410(FUN_00c07940,0,s_Require_02133ec0,s_condition_02133eac,s_description_0212171c,
               s_source_02119484,&DAT_02133e90,0,0,0,0,uStack_14,0);
  FUN_016f3654(&LAB_01892ec0);
  return;
}



/* FUNCTION 1321 ; VA 0x004d7150 ; FUN_004d7150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d7150(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804eba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c00340(uVar2,0);
  FUN_009cb820(uVar1,&DAT_02121eb4,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02133a18 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::TestService,void___cdecl(void),0>::vftable;
  _DAT_02133a50 = FUN_00c07b30;
  _DAT_02133a54 = 0;
  _DAT_02133a3c = FUN_00888530();
  FUN_016f3654(&LAB_01892ed0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1322 ; VA 0x004d71f0 ; FUN_004d71f0 */

void FUN_004d71f0(void)

{
  uint uStack_14;
  
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_00c01410(FUN_00c08de0,0,&DAT_02133dcc,s_condition_02133eac,s_description_0212171c,
               s_source_02119484,&DAT_02133e90,0,0,0,0,uStack_14,0);
  FUN_016f3654(&LAB_01892ee0);
  return;
}



/* FUNCTION 1323 ; VA 0x004d72c0 ; FUN_004d72c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d72c0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804eda;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c00340();
  FUN_0089a380(uVar3,s_Description_02133d48,&DAT_021197d4,0);
  uStack_8 = 0;
  DAT_02133778 = RBX::Reflection::
                 BoundProp<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,1>
                 ::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::
              BoundProp<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,1>
              ::BoundPropGetSet<class_RBX::TestService>::vftable;
    puVar4[1] = &DAT_02133778;
    puVar4[2] = 0xc4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_021337ac != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021337ac;
    DAT_021337ac = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_021337ac;
  }
  DAT_021337ac = puVar4;
  cVar2 = (*(code *)DAT_02133778[3])();
  if (cVar2 != '\0') {
    _DAT_0213379c = _DAT_0213379c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02133778[2])();
  if (cVar2 != '\0') {
    _DAT_0213379c = _DAT_0213379c & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1324 ; VA 0x004d7570 ; FUN_004d7570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d7570(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804efa;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c00340();
  FUN_005c44c0(uVar3,s_NumberOfPlayers_02133e28,s_Settings_02119294,0);
  uStack_8 = 0;
  DAT_021338c8 = RBX::Reflection::BoundProp<int,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<int,1>::BoundPropGetSet<class_RBX::TestService>::vftable;
    puVar4[1] = &DAT_021338c8;
    puVar4[2] = 0xec;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_021338fc != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021338fc;
    DAT_021338fc = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_021338fc;
  }
  DAT_021338fc = puVar4;
  cVar2 = (*(code *)DAT_021338c8[3])();
  if (cVar2 != '\0') {
    _DAT_021338ec = _DAT_021338ec & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021338c8[2])();
  if (cVar2 != '\0') {
    _DAT_021338ec = _DAT_021338ec & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1325 ; VA 0x004d7900 ; FUN_004d7900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d7900(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("PolicyServiceHttpResponse",0x19);
  uStack_8 = 0xffffffff;
  _DAT_01ef88a4 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1326 ; VA 0x004d79f0 ; FUN_004d79f0 */

void FUN_004d79f0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00c09c70(FUN_00c0b490,0,s_GetPolicyInfoForPlayerAsync_02133fd8,s_player_0211f800,0,uStack_10,0
              );
  FUN_016f3654(&LAB_018932f0);
  return;
}



/* FUNCTION 1327 ; VA 0x004d7af0 ; FUN_004d7af0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d7af0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805d76;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c0ecd0();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_Enabled_0212c1fc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213419c = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02134168 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::ProximityPromptService>
              ::vftable;
    puVar5[1] = &DAT_02134168;
    puVar5[2] = 0x70;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_0213419c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0213419c;
    DAT_0213419c = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_0213419c;
  }
  DAT_0213419c = puVar5;
  cVar2 = (*(code *)DAT_02134168[3])();
  if (cVar2 != '\0') {
    _DAT_0213418c = _DAT_0213418c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02134168[2])();
  if (cVar2 != '\0') {
    _DAT_0213418c = _DAT_0213418c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01893400);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1328 ; VA 0x004d7c20 ; FUN_004d7c20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d7c20(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805da6;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c0ecd0();
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar3,uVar4,s_MaxPromptsVisible_02134270,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_021341d4 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_021341a0 = RBX::Reflection::BoundProp<int,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<int,1>::BoundPropGetSet<class_RBX::ProximityPromptService>
              ::vftable;
    puVar5[1] = &DAT_021341a0;
    puVar5[2] = 0x74;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_021341d4 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021341d4;
    DAT_021341d4 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_021341d4;
  }
  DAT_021341d4 = puVar5;
  cVar2 = (*(code *)DAT_021341a0[3])();
  if (cVar2 != '\0') {
    _DAT_021341c4 = _DAT_021341c4 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021341a0[2])();
  if (cVar2 != '\0') {
    _DAT_021341c4 = _DAT_021341c4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01893420);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1329 ; VA 0x004d7d90 ; FUN_004d7d90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d7d90(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("ProximityPrompts",0x10);
  _DAT_01ef8b54 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1330 ; VA 0x004d7e50 ; FUN_004d7e50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d7e50(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01805dd3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c0ecd0();
  FUN_009cb970(uVar1,s_PromptHidden_021341f8,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02134084 = 0x7c;
  iStack_8 = 0;
  _DAT_02134050 =
       RBX::Reflection::
       EventDesc<class_RBX::ProximityPromptService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ProximityPromptService::*>
       ::vftable;
  FUN_0086e3d0(s_prompt_021341e4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02134078 = uStack_1c;
  _DAT_0213407c = uStack_18;
  _DAT_02134080 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02134050 =
       RBX::Reflection::
       EventDesc<class_RBX::ProximityPromptService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ProximityPromptService::*>
       ::vftable;
  FUN_016f3654(&LAB_01893460);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1331 ; VA 0x004d7fa0 ; FUN_004d7fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d7fa0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01805e0e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c0ecd0();
  FUN_009cb970(uVar1,s_PromptShown_021341ec,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0213404c = 0x78;
  iStack_8 = 0;
  _DAT_02134018 =
       RBX::Reflection::
       EventDesc<class_RBX::ProximityPromptService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::ProximityPromptInputType),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::ProximityPromptInputType)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::ProximityPromptInputType)>_RBX::ProximityPromptService::*>
       ::vftable;
  FUN_0086e3d0(s_prompt_021341e4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_inputType_021341d8);
  FUN_00c12520();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02134040 = uStack_1c;
  _DAT_02134044 = uStack_18;
  _DAT_02134048 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02134018 =
       RBX::Reflection::
       EventDesc<class_RBX::ProximityPromptService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::ProximityPromptInputType),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::ProximityPromptInputType)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::ProximityPromptInputType)>_RBX::ProximityPromptService::*>
       ::vftable;
  FUN_016f3654(&LAB_01893470);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1332 ; VA 0x004d81d0 ; FUN_004d81d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d81d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806ba4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c28850();
  uVar3 = FUN_00c1b320();
  FUN_009ca670(uVar3,uVar2,"AmbientReverb",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01ef9178 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Soundscape::SoundService,enum_RBX::Soundscape::ReverbType>
                 ::vftable;
  _DAT_01ef91ac = uVar2;
  DAT_01ef91b0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01ef91b0 == (undefined4 *)0x0) {
    DAT_01ef91b0 = (undefined4 *)0x0;
  }
  else {
    *DAT_01ef91b0 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Soundscape::SoundService,enum_RBX::Soundscape::ReverbType>::
         GetSetImpl<enum_RBX::Soundscape::ReverbType_(__thiscall_RBX::Soundscape::SoundService::*)(void)const_,void_(__thiscall_RBX::Soundscape::SoundService::*)(enum_RBX::Soundscape::ReverbType_const&)>
         ::vftable;
    DAT_01ef91b0[2] = &LAB_0061ebe0;
    DAT_01ef91b0[3] = 0;
    DAT_01ef91b0[4] = FUN_00c28330;
    DAT_01ef91b0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01ef91b4 = FUN_00c28850();
  cVar1 = (*(code *)DAT_01ef9178[3])();
  if (cVar1 != '\0') {
    _DAT_01ef919c = _DAT_01ef919c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01ef9178[2])();
  if (cVar1 != '\0') {
    _DAT_01ef919c = _DAT_01ef919c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01893620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1333 ; VA 0x004d82f0 ; FUN_004d82f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d82f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806bcc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c1b320();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Soundscape::SoundService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Soundscape::SoundService::*)(void)const_,void_(__thiscall_RBX::Soundscape::SoundService::*)(bool)>
              ::vftable;
    puVar3[2] = FUN_00c23510;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c286a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,"RespectFilteringEnabled",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,0);
  DAT_01ef9418 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01ef944c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01ef943c = _DAT_01ef943c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01ef9418[2])();
    if (cVar1 != '\0') {
      _DAT_01ef943c = _DAT_01ef943c & 0xfffffff3;
    }
  }
  DAT_01ef9418 = RBX::Reflection::PropDescriptor<class_RBX::Soundscape::SoundService,bool>::vftable;
  FUN_016f3654(&LAB_01893640);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1334 ; VA 0x004d8d60 ; FUN_004d8d60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d8d60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806bea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c1b320(uVar2,0);
  FUN_009cb790(uVar1,"BeginRecording",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01ef9288 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Soundscape::SoundService,bool___cdecl(void),0>::
       vftable;
  _DAT_01ef92c0 = FUN_00585a40;
  _DAT_01ef92c4 = 0;
  _DAT_01ef92ac = FUN_0088daf0();
  FUN_016f3654(&LAB_01893780);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1335 ; VA 0x004d8e00 ; FUN_004d8e00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d8e00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806c0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c1b320(uVar2,0);
  FUN_009cb820(uVar1,"EndRecording",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01ef92c8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Soundscape::SoundService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_01ef9300 = FUN_00c20c00;
  _DAT_01ef9304 = 0;
  _DAT_01ef92ec = FUN_008881d0();
  FUN_016f3654(&LAB_01893790);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1336 ; VA 0x004d8ea0 ; FUN_004d8ea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d8ea0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806c2a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c1b320(uVar2,0);
  FUN_009cb790(uVar1,"GetListener",0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01ef9248 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Soundscape::SoundService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(void),0>
       ::vftable;
  _DAT_01ef9280 = FUN_00c22d60;
  _DAT_01ef9284 = 0;
  _DAT_01ef926c = FUN_0088cbe0();
  FUN_016f3654(&LAB_018937a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1337 ; VA 0x004d8f40 ; FUN_004d8f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d8f40(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806c4a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c1b320(uVar2,0);
  FUN_009cb820(uVar1,"GetRecordingDevices",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01ef9308 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Soundscape::SoundService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_01ef9340 = FUN_00c23320;
  _DAT_01ef9344 = 0;
  _DAT_01ef932c = FUN_008881d0();
  FUN_016f3654(&LAB_018937b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1338 ; VA 0x004d8fe0 ; FUN_004d8fe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d8fe0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806c6a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c1b320(uVar2,0);
  FUN_009cb790(uVar1,"GetSoundMemoryData",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01ef9390 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Soundscape::SoundService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_01ef93c8 = FUN_00c235e0;
  _DAT_01ef93cc = 0;
  _DAT_01ef93b4 = FUN_008881d0();
  FUN_016f3654(&LAB_018937c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1339 ; VA 0x004d9080 ; FUN_004d9080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d9080(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806ccc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c1b320();
  FUN_009cb790(uVar2,"PlayLocalSound",0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_01ef93d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Soundscape::SoundService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_01ef9408 = FUN_00c27340;
  _DAT_01ef940c = 0;
  DAT_01ef9410 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_01ef93f4 = FUN_00888530();
  puVar4 = DAT_01ef9410;
  if (DAT_01ef9410 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0("sound");
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_018937d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1340 ; VA 0x004d9250 ; FUN_004d9250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d9250(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806d2c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c1b320();
  FUN_009cb790(uVar1,"PlayStockSound",5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_01ef91b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Soundscape::SoundService,void___cdecl(enum_RBX::SoundType),1>::
       vftable;
  _DAT_01ef91f0 = &LAB_00c274a0;
  _DAT_01ef91f4 = 0;
  DAT_01ef91f8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_01ef91dc = FUN_00888530();
  puVar3 = DAT_01ef91f8;
  if (DAT_01ef91f8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00896fb0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00897490();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00896fb0();
  uVar2 = FUN_0086e3d0("sound");
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01893820);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1341 ; VA 0x004d93f0 ; FUN_004d93f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d93f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806d5e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c1b320(uVar2,0);
  FUN_009cb790(uVar1,"SetListener",0,CONCAT44(uVar3,uVar2),0);
  _DAT_01ef9200 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Soundscape::SoundService,void___cdecl(enum_RBX::Soundscape::ListenerType,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),2>
       ::vftable;
  _DAT_01ef9238 = FUN_00c283b0;
  _DAT_01ef923c = 0;
  _DAT_01ef9240 = 0;
  _DAT_01ef9244 = 0;
  uStack_8 = 2;
  FUN_00c20730();
  FUN_016f3654(&LAB_01893840);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1342 ; VA 0x004d94b0 ; FUN_004d94b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d94b0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806dbc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c1b320();
  FUN_009cb790(uVar1,"SetRecordingDevice",5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_01ef9348 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Soundscape::SoundService,bool___cdecl(int),1>::
       vftable;
  _DAT_01ef9380 = FUN_005c92d0;
  _DAT_01ef9384 = 0;
  DAT_01ef9388 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_01ef936c = FUN_0088daf0();
  puVar3 = DAT_01ef9388;
  if (DAT_01ef9388 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c8c0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005c9cc0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0("deviceIndex");
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01893850);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1343 ; VA 0x004d96f0 ; FUN_004d96f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d96f0(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01807aee;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c2a7d0();
  FUN_009cb970(uVar1,s_GameInvitePromptClosed_02134454,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021343d4 = 0x60;
  iStack_8 = 0;
  _DAT_021343a0 =
       RBX::Reflection::
       EventDesc<class_RBX::SocialService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_RBX::SocialService::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_recipientIds_021343f4);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_021343c8 = uStack_1c;
  _DAT_021343cc = uStack_18;
  _DAT_021343d0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_021343a0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::SocialService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_RBX::SocialService::*>
       ::vftable;
  _DAT_021343d8 = 0;
  _DAT_021343dc = 1;
  FUN_016f3654(&LAB_01893940);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1344 ; VA 0x004d9880 ; FUN_004d9880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d9880(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01807b23;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c2a7d0();
  FUN_009cb970(uVar1,s_PromptInviteRequested_0213443c,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02134394 = 0x58;
  iStack_8 = 0;
  _DAT_02134360 =
       RBX::Reflection::
       EventDesc<class_RBX::SocialService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::SocialService::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02134388 = uStack_1c;
  _DAT_0213438c = uStack_18;
  _DAT_02134390 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_02134360 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::SocialService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::SocialService::*>
       ::vftable;
  _DAT_02134398 = 0;
  _DAT_0213439c = 1;
  FUN_016f3654(&LAB_01893950);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1345 ; VA 0x004d99e0 ; FUN_004d99e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d99e0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807b7c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c2a7d0();
  FUN_009cb820(uVar2,s_CanSendGameInviteAsync_02134424,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02134318 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::SocialService,bool___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_02134350 = FUN_00c2b290;
  _DAT_02134354 = 0;
  DAT_02134358 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213433c = FUN_0088daf0();
  puVar4 = DAT_02134358;
  if (DAT_02134358 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_player_0211f800);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01893960);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1346 ; VA 0x004d9bb0 ; FUN_004d9bb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d9bb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807bae;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c2a7d0(uVar2,0);
  FUN_009cb790(uVar1,s_InvokeGameInvitePromptClosed_02134404,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021342d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SocialService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),2>
       ::vftable;
  _DAT_02134308 = FUN_00c2c8b0;
  _DAT_0213430c = 0;
  _DAT_02134310 = 0;
  _DAT_02134314 = 0;
  uStack_8 = 2;
  FUN_00c2bb50();
  FUN_016f3654(&LAB_018939b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1347 ; VA 0x004d9c70 ; FUN_004d9c70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d9c70(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807c0c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c2a7d0();
  FUN_009cb790(uVar2,s_PromptGameInvite_021343e0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02134288 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SocialService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_021342c0 = FUN_00c2d1a0;
  _DAT_021342c4 = 0;
  DAT_021342c8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021342ac = FUN_00888530();
  puVar4 = DAT_021342c8;
  if (DAT_021342c8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_player_0211f800);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_018939c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1348 ; VA 0x004d9f40 ; FUN_004d9f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d9f40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807f6c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c2d600();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::StudioData,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::StudioData::*)(void)const_,void_(__thiscall_RBX::StudioData::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
              ::vftable;
    puVar3[2] = FUN_009f5e50;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c2d9d0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_CommitInflightGuid_02134650,&DAT_021197d4,uStack_24,0,0,0xc,6,6,0);
  DAT_0213454c = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02134580 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02134570 = _DAT_02134570 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213454c[2])();
    if (cVar1 != '\0') {
      _DAT_02134570 = _DAT_02134570 & 0xfffffff3;
    }
  }
  DAT_0213454c = RBX::Reflection::
                 PropDescriptor<class_RBX::StudioData,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_01893b10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1349 ; VA 0x004da070 ; FUN_004da070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004da070(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807f9c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c2d600();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::StudioData,int>::
              GetSetImpl<int_(__thiscall_RBX::StudioData::*)(void)const_,void_(__thiscall_RBX::StudioData::*)(int)>
              ::vftable;
    puVar3[2] = FUN_00855cc0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c2da90;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_CommitInflightPlaceVersion_0213467c,&DAT_021197d4,uStack_24,0,0,0xc,6,6
               ,0);
  DAT_021345bc = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021345f0 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021345e0 = _DAT_021345e0 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021345bc[2])();
    if (cVar1 != '\0') {
      _DAT_021345e0 = _DAT_021345e0 & 0xfffffff3;
    }
  }
  DAT_021345bc = RBX::Reflection::PropDescriptor<class_RBX::StudioData,int>::vftable;
  FUN_016f3654(&LAB_01893b30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1350 ; VA 0x004da290 ; FUN_004da290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004da290(void)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  char *pcVar4;
  undefined *puVar5;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018080ad;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  pcVar4 = PTR_DAT_01d685dc;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(PTR_DAT_01d685dc,(int)pcVar4 - (int)(PTR_DAT_01d685dc + 1));
  uStack_18 = 2;
  uStack_8 = 0;
  DAT_01efa06c = 0;
  _DAT_01efa070 = 0;
  DAT_01efa06c = FUN_00575af0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar5 = auStack_30;
  do {
    uVar2 = DAT_01efa06c;
    iVar3 = FUN_00b35190(puVar5);
    FUN_0055a7d0(auStack_14,uVar2,iVar3 + 0x10,iVar3);
    puVar5 = puVar5 + 0x1c;
  } while (puVar5 != auStack_14);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_30,0x1c,1,FUN_005507b0);
  FUN_016f3654(FUN_01893c10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1351 ; VA 0x004da3a0 ; FUN_004da3a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004da3a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018080fc;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c2dc10(uVar2,0);
  FUN_009cb790(uVar1,s_AppendTempAssetId_021347f0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021346d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UnvalidatedAssetService,void___cdecl(__int64,__int64,class_G3D::Vector3,class_G3D::Vector3,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),5>
       ::vftable;
  _DAT_02134708 = FUN_00c2f2b0;
  _DAT_0213470c = 0;
  _DAT_02134710 = 0;
  _DAT_02134714 = 0;
  _DAT_02134718 = 0;
  _DAT_0213471c = 0;
  _DAT_02134720 = 0;
  uStack_8 = 5;
  FUN_00c2f6c0(s_userId_0211fb64,&DAT_021347ec,s_lookAt_021347e4,s_camPos_021347dc,s_usage_021347d4)
  ;
  FUN_016f3654(&LAB_01893c90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1352 ; VA 0x004da490 ; FUN_004da490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004da490(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808142;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c2dc10(uVar2,0);
  FUN_009cb790(uVar1,s_AppendVantagePoint_02134820,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02134778 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UnvalidatedAssetService,bool___cdecl(__int64,__int64,class_G3D::Vector3,class_G3D::Vector3),4>
       ::vftable;
  _DAT_021347b0 = FUN_00c2f530;
  _DAT_021347b4 = 0;
  DAT_021347b8 = 0;
  DAT_021347bc = 0;
  DAT_021347c0 = 0;
  DAT_021347c4 = 0;
  uStack_8 = 4;
  FUN_00c2fe00(s_userId_0211fb64,&DAT_021347ec,s_lookAt_021347e4,s_camPos_021347dc);
  FUN_016f3654(&LAB_01893ca0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1353 ; VA 0x004da570 ; FUN_004da570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004da570(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808178;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c2dc10(uVar2,0);
  FUN_009cb790(uVar1,s_UpgradeTempAssetId_0213480c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02134728 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UnvalidatedAssetService,bool___cdecl(__int64,__int64,__int64),3>::
       vftable;
  _DAT_02134760 = FUN_00c314c0;
  _DAT_02134764 = 0;
  DAT_02134768 = 0;
  DAT_0213476c = 0;
  DAT_02134770 = 0;
  uStack_8 = 3;
  FUN_00c2fb50(s_userId_0211fb64,s_tempId_02134804,s_assetId_0211bf40);
  FUN_016f3654(&LAB_01893d00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1354 ; VA 0x004da640 ; FUN_004da640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004da640(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018081ac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c2dc10();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::UnvalidatedAssetService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::UnvalidatedAssetService::*)(void)const_,void_(__thiscall_RBX::UnvalidatedAssetService::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
              ::vftable;
    puVar3[2] = FUN_00c313f0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c31450;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_CachedData_021347c8,&DAT_021197d4,uStack_24,0,0,0xe,6,6,0);
  DAT_02134698 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021346cc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021346bc = _DAT_021346bc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02134698[2])();
    if (cVar1 != '\0') {
      _DAT_021346bc = _DAT_021346bc & 0xfffffff3;
    }
  }
  DAT_02134698 = RBX::Reflection::
                 PropDescriptor<class_RBX::UnvalidatedAssetService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_01893d50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1355 ; VA 0x004da770 ; FUN_004da770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004da770(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018087ac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c31b40();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::VideoFrame,class_RBX::VideoId>::
              GetSetImpl<class_RBX::VideoId_(__thiscall_RBX::VideoFrame::*)(void)const_,void_(__thiscall_RBX::VideoFrame::*)(class_RBX::VideoId)>
              ::vftable;
    puVar3[2] = FUN_00c34990;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c364f0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_Video_02120368,s_Video_02120368,uStack_24,0,0,0x1f,0,0,0);
  DAT_02134838 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::VideoId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213486c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213485c = _DAT_0213485c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02134838[2])();
    if (cVar1 != '\0') {
      _DAT_0213485c = _DAT_0213485c & 0xfffffff3;
    }
  }
  DAT_02134838 = RBX::Reflection::PropDescriptor<class_RBX::VideoFrame,class_RBX::VideoId>::vftable;
  FUN_016f3654(&LAB_01893dd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1356 ; VA 0x004da950 ; FUN_004da950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004da950(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018087e3;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c31b40();
  FUN_009cb970(uVar1,s_PlayingUpdatedFromServer_02129078,6,CONCAT44(uStack_2c,uStack_30),0);
  DAT_02134c34 = 0x35c;
  iStack_8 = 0;
  _DAT_02134c00 =
       RBX::Reflection::
       EventDesc<class_RBX::VideoFrame,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::VideoFrame::*>
       ::vftable;
  FUN_0086e3d0(s_value_0211ab70);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02134c28 = uStack_1c;
  _DAT_02134c2c = uStack_18;
  _DAT_02134c30 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_02134c00 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::VideoFrame,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::VideoFrame::*>
       ::vftable;
  _DAT_02134c38 = 0;
  _DAT_02134c3c = 0;
  FUN_016f3654(&LAB_01893e50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1357 ; VA 0x004daab0 ; FUN_004daab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004daab0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01808813;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c31b40();
  FUN_009cb970(uVar1,s_TimePositionUpdatedFromServer_02129058,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02134c74 = 0x364;
  iStack_8 = 0;
  _DAT_02134c40 =
       RBX::Reflection::
       EventDesc<class_RBX::VideoFrame,void___cdecl(double),class_rbx::remote_signal<void___cdecl(double)>,class_rbx::remote_signal<void___cdecl(double)>_RBX::VideoFrame::*>
       ::vftable;
  FUN_0086e3d0(s_value_0211ab70);
  FUN_0088ca00();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02134c68 = uStack_1c;
  _DAT_02134c6c = uStack_18;
  _DAT_02134c70 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_02134c40 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::VideoFrame,void___cdecl(double),class_rbx::remote_signal<void___cdecl(double)>,class_rbx::remote_signal<void___cdecl(double)>_RBX::VideoFrame::*>
       ::vftable;
  _DAT_02134c78 = 0;
  _DAT_02134c7c = 0;
  FUN_016f3654(&LAB_01893e60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1358 ; VA 0x004dae40 ; FUN_004dae40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dae40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180883c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c31b40();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::VideoFrame,class_G3D::Vector2>::
              GetImpl<class_G3D::Vector2_(__thiscall_RBX::VideoFrame::*)(void)const_>::vftable;
    puVar3[2] = FUN_00c347e0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_Resolution_02134c80,s_Video_02120368,uStack_24,0,0,0x15,0,0,0);
  DAT_021348a8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021348dc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021348cc = _DAT_021348cc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021348a8[2])();
    if (cVar1 != '\0') {
      _DAT_021348cc = _DAT_021348cc & 0xfffffff3;
    }
  }
  DAT_021348a8 = RBX::Reflection::PropDescriptor<class_RBX::VideoFrame,class_G3D::Vector2>::vftable;
  FUN_016f3654(&LAB_01893ef0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1359 ; VA 0x004db250 ; FUN_004db250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004db250(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180886c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c31b40();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::VideoFrame,float>::
              GetSetImpl<float_(__thiscall_RBX::VideoFrame::*)(void)const_,void_(__thiscall_RBX::VideoFrame::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00c349c0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c36760;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_Volume_02128ea0,s_Video_02120368,uStack_24,0,0,0x1f,0,0,0);
  DAT_02134a30 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02134a64 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02134a54 = _DAT_02134a54 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02134a30[2])();
    if (cVar1 != '\0') {
      _DAT_02134a54 = _DAT_02134a54 & 0xfffffff3;
    }
  }
  DAT_02134a30 = RBX::Reflection::PropDescriptor<class_RBX::VideoFrame,float>::vftable;
  FUN_016f3654(&LAB_01893f90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1360 ; VA 0x004db430 ; FUN_004db430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004db430(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180888a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c31b40(uVar2,0);
  FUN_009cb790(uVar1,s_Pause_02121eb8,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02134aa8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::VideoFrame,void___cdecl(void),0>::vftable;
  _DAT_02134ae0 = &LAB_00c35a10;
  _DAT_02134ae4 = 0;
  _DAT_02134acc = FUN_00888530();
  FUN_016f3654(&LAB_01894050);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1361 ; VA 0x004db500 ; FUN_004db500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004db500(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018088aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c31b40(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02128f90,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02134a68 =
       RBX::Reflection::BoundFuncDesc<class_RBX::VideoFrame,void___cdecl(void),0>::vftable;
  _DAT_02134aa0 = &LAB_00c35a20;
  _DAT_02134aa4 = 0;
  _DAT_02134a8c = FUN_00888530();
  FUN_016f3654(&LAB_01894070);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1362 ; VA 0x004db610 ; FUN_004db610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004db610(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01808dec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c37c00();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Message,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&_(__thiscall_RBX::Message::*)(void)const_,void_(__thiscall_RBX::Message::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)>
              ::vftable;
    puVar3[2] = &LAB_00c38460;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c38a80;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,&DAT_02134cf8,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_02134cc0 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02134cf4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02134ce4 = _DAT_02134ce4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02134cc0[2])();
    if (cVar1 != '\0') {
      _DAT_02134ce4 = _DAT_02134ce4 & 0xfffffff3;
    }
  }
  DAT_02134cc0 = RBX::Reflection::
                 PropDescriptor<class_RBX::Message,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_01894090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1363 ; VA 0x004dbc10 ; FUN_004dbc10 */

void FUN_004dbc10(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_02134d74,0x10);
  FUN_00c38cb0(s_part1_021351b8,&DAT_021197d4,FUN_00c3c020,0,FUN_00c3d770,0,*puVar1,puVar1[1],
               puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_01894210);
  return;
}



/* FUNCTION 1364 ; VA 0x004dbc70 ; FUN_004dbc70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dbc70(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180943c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c396b0();
  FUN_009cb790(uVar1,s_SetDesiredAngle_02135218,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02135058 = RBX::Reflection::BoundFuncDesc<class_RBX::Motor,void___cdecl(float),1>::vftable;
  _DAT_02135090 = &LAB_00c3b2e6;
  _DAT_02135094 = 0;
  DAT_02135098 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213507c = FUN_00888530();
  puVar3 = DAT_02135098;
  if (DAT_02135098 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c960();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00630820();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(s_value_0211ab70);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01894230);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1365 ; VA 0x004dc670 ; FUN_004dc670 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dc670(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018096fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c3ebd0();
  FUN_009cb790(uVar2,s_SetTextFromInput_02135e6c,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02135b88 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::TextBox,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02135bc0 = FUN_00fac790;
  _DAT_02135bc4 = 0;
  DAT_02135bc8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02135bac = FUN_00888530();
  iVar1 = DAT_02135bc8;
  if (DAT_02135bc8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_02126680);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01894800);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1366 ; VA 0x004dc8e0 ; FUN_004dc8e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dc8e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809724;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00896cc0();
  uVar3 = FUN_00c3ebd0();
  FUN_009ca670(uVar3,uVar2,&DAT_02135d78,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021357b0 = RBX::Reflection::EnumPropDescriptor<class_RBX::TextBox,enum_RBX::Text::Font>::
                 vftable;
  _DAT_021357e4 = uVar2;
  DAT_021357e8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021357e8 == (undefined4 *)0x0) {
    DAT_021357e8 = (undefined4 *)0x0;
  }
  else {
    *DAT_021357e8 =
         RBX::Reflection::PropDescriptor<class_RBX::TextBox,enum_RBX::Text::Font>::
         GetSetImpl<enum_RBX::Text::Font_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(enum_RBX::Text::Font)>
         ::vftable;
    DAT_021357e8[2] = &LAB_00c41fe0;
    DAT_021357e8[3] = 0;
    DAT_021357e8[4] = FUN_00fab4f0;
    DAT_021357e8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021357ec = FUN_00896cc0();
  cVar1 = (*(code *)DAT_021357b0[3])();
  if (cVar1 != '\0') {
    _DAT_021357d4 = _DAT_021357d4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021357b0[2])();
  if (cVar1 != '\0') {
    _DAT_021357d4 = _DAT_021357d4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01894840);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1367 ; VA 0x004dce80 ; FUN_004dce80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dce80(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809764;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c45750();
  uVar3 = FUN_00c3ebd0();
  FUN_009ca670(uVar3,uVar2,s_ReturnKeyType_02135d30,&DAT_021197d4,uStack_24,0,0,0x15,5,5,1);
  uStack_8 = 0;
  DAT_02135688 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::TextBox,enum_RBX::TextBox::ReturnKeyType>::vftable;
  _DAT_021356bc = uVar2;
  DAT_021356c0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021356c0 == (undefined4 *)0x0) {
    DAT_021356c0 = (undefined4 *)0x0;
  }
  else {
    *DAT_021356c0 =
         RBX::Reflection::PropDescriptor<class_RBX::TextBox,enum_RBX::TextBox::ReturnKeyType>::
         GetSetImpl<enum_RBX::TextBox::ReturnKeyType_(__thiscall_RBX::TextBox::*)(void)const_,void_(__thiscall_RBX::TextBox::*)(enum_RBX::TextBox::ReturnKeyType)>
         ::vftable;
    DAT_021356c0[2] = &LAB_00c420a0;
    DAT_021356c0[3] = 0;
    DAT_021356c0[4] = FUN_00c45240;
    DAT_021356c0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021356c4 = FUN_00c45750();
  cVar1 = (*(code *)DAT_02135688[3])();
  if (cVar1 != '\0') {
    _DAT_021356ac = _DAT_021356ac & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02135688[2])();
  if (cVar1 != '\0') {
    _DAT_021356ac = _DAT_021356ac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01894920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1368 ; VA 0x004dd120 ; FUN_004dd120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dd120(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180978c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c3ebd0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TextBox,class_G3D::Vector2>::
              GetImpl<class_G3D::Vector2_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(void)const_>
              ::vftable;
    puVar3[2] = FUN_00fa7a50;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_TextBounds_02135e18,&DAT_02134cf8,uStack_24,0,0,0x15,0,0,0);
  DAT_02135a70 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02135aa4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02135a94 = _DAT_02135a94 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02135a70[2])();
    if (cVar1 != '\0') {
      _DAT_02135a94 = _DAT_02135a94 & 0xfffffff3;
    }
  }
  DAT_02135a70 = RBX::Reflection::PropDescriptor<class_RBX::TextBox,class_G3D::Vector2>::vftable;
  FUN_016f3654(&LAB_01894980);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1369 ; VA 0x004dd300 ; FUN_004dd300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dd300(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018097bc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c3ebd0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TextBox,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(class_RBX::BrickColor)>
              ::vftable;
    puVar3[2] = FUN_00c42100;
    puVar3[3] = 0;
    puVar3[4] = FUN_00fac5e0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,s_TextColor_02135d80,&DAT_02134cf8,uStack_24,0,0,0x14,0,0,0);
  DAT_021357f0 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02135824 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02135814 = _DAT_02135814 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021357f0[2])();
    if (cVar1 != '\0') {
      _DAT_02135814 = _DAT_02135814 & 0xfffffff3;
    }
  }
  DAT_021357f0 = RBX::Reflection::PropDescriptor<class_RBX::TextBox,class_RBX::BrickColor>::vftable;
  FUN_016f3654(&LAB_018949c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1370 ; VA 0x004dd4e0 ; FUN_004dd4e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dd4e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018097e4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c45800();
  uVar3 = FUN_00c3ebd0();
  FUN_009ca670(uVar3,uVar2,s_TextInputType_02135d20,&DAT_021197d4,uStack_24,0,0,0x15,5,5,1);
  uStack_8 = 0;
  DAT_02135648 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::TextBox,enum_RBX::TextBox::TextInputType>::vftable;
  _DAT_0213567c = uVar2;
  DAT_02135680 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02135680 == (undefined4 *)0x0) {
    DAT_02135680 = (undefined4 *)0x0;
  }
  else {
    *DAT_02135680 =
         RBX::Reflection::PropDescriptor<class_RBX::TextBox,enum_RBX::TextBox::TextInputType>::
         GetSetImpl<enum_RBX::TextBox::TextInputType_(__thiscall_RBX::TextBox::*)(void)const_,void_(__thiscall_RBX::TextBox::*)(enum_RBX::TextBox::TextInputType)>
         ::vftable;
    DAT_02135680[2] = &LAB_00c42140;
    DAT_02135680[3] = 0;
    DAT_02135680[4] = FUN_00c45330;
    DAT_02135680[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02135684 = FUN_00c45800();
  cVar1 = (*(code *)DAT_02135648[3])();
  if (cVar1 != '\0') {
    _DAT_0213566c = _DAT_0213566c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02135648[2])();
  if (cVar1 != '\0') {
    _DAT_0213566c = _DAT_0213566c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01894a00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1371 ; VA 0x004dd880 ; FUN_004dd880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dd880(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809804;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c458b0();
  uVar3 = FUN_00c3ebd0();
  FUN_009ca670(uVar3,uVar2,s_TextTruncate_02135e08,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02135a30 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::TextBox,enum_RBX::TextService::TextTruncate>::vftable
  ;
  _DAT_02135a64 = uVar2;
  DAT_02135a68 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02135a68 == (undefined4 *)0x0) {
    DAT_02135a68 = (undefined4 *)0x0;
  }
  else {
    *DAT_02135a68 =
         RBX::Reflection::PropDescriptor<class_RBX::TextBox,enum_RBX::TextService::TextTruncate>::
         GetSetImpl<enum_RBX::TextService::TextTruncate_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(enum_RBX::TextService::TextTruncate)>
         ::vftable;
    DAT_02135a68[2] = &LAB_00c421a0;
    DAT_02135a68[3] = 0;
    DAT_02135a68[4] = FUN_00fad860;
    DAT_02135a68[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02135a6c = FUN_00c458b0();
  cVar1 = (*(code *)DAT_02135a30[3])();
  if (cVar1 != '\0') {
    _DAT_02135a54 = _DAT_02135a54 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02135a30[2])();
  if (cVar1 != '\0') {
    _DAT_02135a54 = _DAT_02135a54 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01894aa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1372 ; VA 0x004dda60 ; FUN_004dda60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dda60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809824;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c45940();
  uVar3 = FUN_00c3ebd0();
  FUN_009ca670(uVar3,uVar2,s_TextXAlignment_02135de8,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021359b0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::TextBox,enum_RBX::TextService::XAlignment>::vftable;
  _DAT_021359e4 = uVar2;
  DAT_021359e8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021359e8 == (undefined4 *)0x0) {
    DAT_021359e8 = (undefined4 *)0x0;
  }
  else {
    *DAT_021359e8 =
         RBX::Reflection::PropDescriptor<class_RBX::TextBox,enum_RBX::TextService::XAlignment>::
         GetSetImpl<enum_RBX::TextService::XAlignment_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(enum_RBX::TextService::XAlignment)>
         ::vftable;
    DAT_021359e8[2] = &LAB_00c42460;
    DAT_021359e8[3] = 0;
    DAT_021359e8[4] = FUN_00fadbc0;
    DAT_021359e8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021359ec = FUN_00c45940();
  cVar1 = (*(code *)DAT_021359b0[3])();
  if (cVar1 != '\0') {
    _DAT_021359d4 = _DAT_021359d4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021359b0[2])();
  if (cVar1 != '\0') {
    _DAT_021359d4 = _DAT_021359d4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01894ae0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1373 ; VA 0x004ddb80 ; FUN_004ddb80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ddb80(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809844;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c459d0();
  uVar3 = FUN_00c3ebd0();
  FUN_009ca670(uVar3,uVar2,s_TextYAlignment_02135df8,&DAT_02134cf8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021359f0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::TextBox,enum_RBX::TextService::YAlignment>::vftable;
  _DAT_02135a24 = uVar2;
  DAT_02135a28 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02135a28 == (undefined4 *)0x0) {
    DAT_02135a28 = (undefined4 *)0x0;
  }
  else {
    *DAT_02135a28 =
         RBX::Reflection::PropDescriptor<class_RBX::TextBox,enum_RBX::TextService::YAlignment>::
         GetSetImpl<enum_RBX::TextService::YAlignment_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(enum_RBX::TextService::YAlignment)>
         ::vftable;
    DAT_02135a28[2] = &LAB_00c42470;
    DAT_02135a28[3] = 0;
    DAT_02135a28[4] = FUN_00fadc50;
    DAT_02135a28[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02135a2c = FUN_00c459d0();
  cVar1 = (*(code *)DAT_021359f0[3])();
  if (cVar1 != '\0') {
    _DAT_02135a14 = _DAT_02135a14 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021359f0[2])();
  if (cVar1 != '\0') {
    _DAT_02135a14 = _DAT_02135a14 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01894b00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1374 ; VA 0x004ddee0 ; FUN_004ddee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ddee0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180987e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c3ebd0();
  FUN_009cb970(uVar1,s_FocusLost_02135c5c,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02135414 = 0x634;
  iStack_8 = 0;
  _DAT_021353e0 =
       RBX::Reflection::
       EventDesc<class_RBX::TextBox,void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>_RBX::TextBox::*>
       ::vftable;
  FUN_0086e3d0(s_enterPressed_02135c4c);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_inputThatCausedFocusLoss_02135c30);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02135408 = uStack_1c;
  _DAT_0213540c = uStack_18;
  _DAT_02135410 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_021353e0 =
       RBX::Reflection::
       EventDesc<class_RBX::TextBox,void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>)>_RBX::TextBox::*>
       ::vftable;
  FUN_016f3654(&LAB_01894b50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1375 ; VA 0x004de070 ; FUN_004de070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004de070(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180989a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c3ebd0(uVar2,0);
  FUN_009cb790(uVar1,s_CaptureFocus_02135bf0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021352d8 = RBX::Reflection::BoundFuncDesc<class_RBX::TextBox,void___cdecl(void),0>::vftable;
  _DAT_02135310 = FUN_00c40390;
  _DAT_02135314 = 0;
  _DAT_021352fc = FUN_00888530();
  FUN_016f3654(&LAB_01894b70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1376 ; VA 0x004de110 ; FUN_004de110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004de110(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018098ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c3ebd0(uVar2,0);
  FUN_009cb790(uVar1,s_IsFocused_02135c10,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02135360 = RBX::Reflection::BoundFuncDesc<class_RBX::TextBox,bool___cdecl(void),0>::vftable;
  _DAT_02135398 = &LAB_00c41fd0;
  _DAT_0213539c = 0;
  _DAT_02135384 = FUN_0088daf0();
  FUN_016f3654(&LAB_01894b80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1377 ; VA 0x004de1b0 ; FUN_004de1b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004de1b0(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180991c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c3ebd0();
  FUN_009cb790(uVar2,s_ReleaseFocus_02135c00,0,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_02135318 = RBX::Reflection::BoundFuncDesc<class_RBX::TextBox,void___cdecl(bool),1>::vftable;
  _DAT_02135350 = FUN_00c44ae0;
  _DAT_02135354 = 0;
  DAT_02135358 = (undefined *)FUN_01674e20(1);
  if (DAT_02135358 == (undefined *)0x0) {
    DAT_02135358 = (undefined *)0x0;
  }
  else {
    *DAT_02135358 = 0;
  }
  uStack_8._0_1_ = 1;
  _DAT_0213533c = FUN_00888530();
  puVar1 = DAT_02135358;
  if (DAT_02135358 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar1;
    iStack_ec = FUN_005c9ef0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_submitted_02125708);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01894b90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1378 ; VA 0x004de360 ; FUN_004de360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004de360(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180993a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c3ebd0(uVar2,0);
  FUN_009cb790(uVar1,s_ResetKeyboardMode_02135c1c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021353a0 = RBX::Reflection::BoundFuncDesc<class_RBX::TextBox,void___cdecl(void),0>::vftable;
  _DAT_021353d8 = FUN_00c44ba0;
  _DAT_021353dc = 0;
  _DAT_021353c4 = FUN_00888530();
  FUN_016f3654(&LAB_01894bb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1379 ; VA 0x004de920 ; FUN_004de920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004de920(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809f3a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c46280();
  FUN_00684820(uVar3,s_Enabled_0212c1fc,s_State_0211d030,0);
  uStack_8 = 0;
  DAT_02136078 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::Tool>::vftable;
    puVar4[1] = &DAT_02136078;
    puVar4[2] = 0x148;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_021360ac != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021360ac;
    DAT_021360ac = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_021360ac;
  }
  DAT_021360ac = puVar4;
  cVar2 = (*(code *)DAT_02136078[3])();
  if (cVar2 != '\0') {
    _DAT_0213609c = _DAT_0213609c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02136078[2])();
  if (cVar2 != '\0') {
    _DAT_0213609c = _DAT_0213609c & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1380 ; VA 0x004deb10 ; FUN_004deb10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004deb10(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01809f73;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c46280();
  FUN_009cb970(uVar1,s_Equipped_02136290,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021360e4 = 0x1a4;
  iStack_8 = 0;
  _DAT_021360b0 =
       RBX::Reflection::
       EventDesc<class_RBX::Tool,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_RBX::Tool::special_equipped_signal,class_RBX::Tool::special_equipped_signal_RBX::Tool::*>
       ::vftable;
  FUN_0086e3d0(s_mouse_0213245c);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021360d8 = uStack_1c;
  _DAT_021360dc = uStack_18;
  _DAT_021360e0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021360b0 =
       RBX::Reflection::
       EventDesc<class_RBX::Tool,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_RBX::Tool::special_equipped_signal,class_RBX::Tool::special_equipped_signal_RBX::Tool::*>
       ::vftable;
  FUN_016f3654(&LAB_01894e20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1381 ; VA 0x004dec60 ; FUN_004dec60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dec60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c46280(uVar2,0);
  FUN_009cb970(uVar1,s_Unequipped_0213629c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213611c = 0x1bc;
  _DAT_021360e8 =
       RBX::Reflection::
       EventDesc<class_RBX::Tool,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Tool::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02136110 = 0;
  _DAT_02136114 = 0;
  _DAT_02136118 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_021360e8 =
       RBX::Reflection::
       EventDesc<class_RBX::Tool,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Tool::*>
       ::vftable;
  FUN_016f3654(&LAB_01894e30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1382 ; VA 0x004ded50 ; FUN_004ded50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ded50(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809f8a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c46280(uVar2,0);
  FUN_009cb790(uVar1,s_Activate_021362c0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021361a0 = RBX::Reflection::BoundFuncDesc<class_RBX::Tool,void___cdecl(void),0>::vftable;
  _DAT_021361d8 = FUN_00c488e0;
  _DAT_021361dc = 0;
  _DAT_021361c4 = FUN_00888530();
  FUN_016f3654(&LAB_01894e40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1383 ; VA 0x004dedf0 ; FUN_004dedf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dedf0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809faa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c46280(uVar2,0);
  FUN_009cb790(uVar1,s_Deactivate_021362cc,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021361e0 = RBX::Reflection::BoundFuncDesc<class_RBX::Tool,void___cdecl(void),0>::vftable;
  _DAT_02136218 = FUN_00c48930;
  _DAT_0213621c = 0;
  _DAT_02136204 = FUN_00888530();
  FUN_016f3654(&LAB_01894e50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1384 ; VA 0x004def60 ; FUN_004def60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004def60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809fdc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c46280();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Tool,class_G3D::CoordinateFrame>::
              GetSetImpl<class_G3D::CoordinateFrame_const&_(__thiscall_RBX::Tool::*)(void)const_,void_(__thiscall_RBX::Tool::*)(class_G3D::CoordinateFrame_const&)>
              ::vftable;
    puVar3[2] = &LAB_00c484b0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c49aa0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,&DAT_02136220,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_02135e80 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02135eb4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02135ea4 = _DAT_02135ea4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02135e80[2])();
    if (cVar1 != '\0') {
      _DAT_02135ea4 = _DAT_02135ea4 & 0xfffffff3;
    }
  }
  DAT_02135e80 = RBX::Reflection::PropDescriptor<class_RBX::Tool,class_G3D::CoordinateFrame>::
                 vftable;
  FUN_016f3654(&LAB_01894e80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1385 ; VA 0x004df1d0 ; FUN_004df1d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004df1d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a00c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c46280();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Tool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::Tool::*)(void)const_,void_(__thiscall_RBX::Tool::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
              ::vftable;
    puVar3[2] = FUN_00c486e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c4a520;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_ToolTip_02136250,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_02135f98 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02135fcc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02135fbc = _DAT_02135fbc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02135f98[2])();
    if (cVar1 != '\0') {
      _DAT_02135fbc = _DAT_02135fbc & 0xfffffff3;
    }
  }
  DAT_02135f98 = RBX::Reflection::
                 PropDescriptor<class_RBX::Tool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_01894f20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1386 ; VA 0x004df5c0 ; FUN_004df5c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004df5c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a5aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770(uVar2,0);
  FUN_009cb790(uVar1,s_ClearComputerCameraMovementModes_021367d0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021364b8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PlayerScripts,void___cdecl(void),0>::vftable;
  _DAT_021364f0 = FUN_00c4e940;
  _DAT_021364f4 = 0;
  _DAT_021364dc = FUN_00888530();
  FUN_016f3654(&LAB_01895080);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1387 ; VA 0x004df660 ; FUN_004df660 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004df660(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a5ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770(uVar2,0);
  FUN_009cb790(uVar1,s_ClearComputerMovementModes_0213673c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021363a8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PlayerScripts,void___cdecl(void),0>::vftable;
  _DAT_021363e0 = FUN_00c4e960;
  _DAT_021363e4 = 0;
  _DAT_021363cc = FUN_00888530();
  FUN_016f3654(&LAB_01895090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1388 ; VA 0x004df700 ; FUN_004df700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004df700(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a5ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770(uVar2,0);
  FUN_009cb790(uVar1,s_ClearTouchCameraMovementModes_0213678c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02136430 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PlayerScripts,void___cdecl(void),0>::vftable;
  _DAT_02136468 = FUN_00c4e980;
  _DAT_0213646c = 0;
  _DAT_02136454 = FUN_00888530();
  FUN_016f3654(&LAB_018950a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1389 ; VA 0x004df7a0 ; FUN_004df7a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004df7a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a60a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770(uVar2,0);
  FUN_009cb790(uVar1,s_ClearTouchMovementModes_02136704,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02136320 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PlayerScripts,void___cdecl(void),0>::vftable;
  _DAT_02136358 = FUN_00c4e9a0;
  _DAT_0213635c = 0;
  _DAT_02136344 = FUN_00888530();
  FUN_016f3654(&LAB_018950b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1390 ; VA 0x004df840 ; FUN_004df840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004df840(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a62a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770(uVar2,0);
  FUN_009cb790(uVar1,s_GetRegisteredComputerCameraMovem_021368e8,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02136698 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PlayerScripts,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021366d0 = FUN_00c501b0;
  _DAT_021366d4 = 0;
  _DAT_021366bc = FUN_008882f0();
  FUN_016f3654(&LAB_018950c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1391 ; VA 0x004df8e0 ; FUN_004df8e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004df8e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a64a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770(uVar2,0);
  FUN_009cb790(uVar1,s_GetRegisteredComputerMovementMod_02136850,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021365a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PlayerScripts,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021365e0 = FUN_00c50300;
  _DAT_021365e4 = 0;
  _DAT_021365cc = FUN_008882f0();
  FUN_016f3654(&LAB_018950d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1392 ; VA 0x004df980 ; FUN_004df980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004df980(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a66a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770(uVar2,0);
  FUN_009cb790(uVar1,s_GetRegisteredTouchCameraMovement_021368c0,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02136658 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PlayerScripts,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02136690 = FUN_00c50450;
  _DAT_02136694 = 0;
  _DAT_0213667c = FUN_008882f0();
  FUN_016f3654(&LAB_018950e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1393 ; VA 0x004dfa20 ; FUN_004dfa20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dfa20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a68a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770(uVar2,0);
  FUN_009cb790(uVar1,s_GetRegisteredTouchMovementModes_02136830,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02136568 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PlayerScripts,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021365a0 = FUN_00c505a0;
  _DAT_021365a4 = 0;
  _DAT_0213658c = FUN_008882f0();
  FUN_016f3654(&LAB_018950f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1394 ; VA 0x004dfac0 ; FUN_004dfac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dfac0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a6ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770();
  FUN_009cb790(uVar1,s_RegisterComputerCameraMovementMo_021367ac,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02136470 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PlayerScripts,void___cdecl(enum_RBX::GameBasicSettings::ComputerCameraMovementMode),1>
       ::vftable;
  _DAT_021364a8 = FUN_00c51180;
  _DAT_021364ac = 0;
  DAT_021364b0 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02136494 = FUN_00888530();
  puVar3 = DAT_021364b0;
  if (DAT_021364b0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00c51450();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00c51690();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00c51450();
  uVar2 = FUN_0086e3d0(s_cameraMovementMode_02136758);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01895100);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1395 ; VA 0x004dfc60 ; FUN_004dfc60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dfc60(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a74c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770();
  FUN_009cb790(uVar1,s_RegisterComputerMovementMode_0213671c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02136360 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PlayerScripts,void___cdecl(enum_RBX::GameBasicSettings::ComputerMovementMode),1>
       ::vftable;
  _DAT_02136398 = FUN_00c511e0;
  _DAT_0213639c = 0;
  DAT_021363a0 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02136384 = FUN_00888530();
  puVar3 = DAT_021363a0;
  if (DAT_021363a0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00c514e0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00c51700();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00c514e0();
  uVar2 = FUN_0086e3d0(s_movementMode_021366d8);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01895120);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1396 ; VA 0x004dfe00 ; FUN_004dfe00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dfe00(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a7ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770();
  FUN_009cb790(uVar1,s_RegisterTouchCameraMovementMode_0213676c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021363e8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PlayerScripts,void___cdecl(enum_RBX::GameBasicSettings::TouchCameraMovementMode),1>
       ::vftable;
  _DAT_02136420 = FUN_00c51230;
  _DAT_02136424 = 0;
  DAT_02136428 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213640c = FUN_00888530();
  puVar3 = DAT_02136428;
  if (DAT_02136428 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00c51570();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00c51770();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00c51570();
  uVar2 = FUN_0086e3d0(s_cameraMovementMode_02136758);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01895140);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1397 ; VA 0x004dffa0 ; FUN_004dffa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004dffa0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180a80c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c4b770();
  FUN_009cb790(uVar1,s_RegisterTouchMovementMode_021366e8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021362d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PlayerScripts,void___cdecl(enum_RBX::GameBasicSettings::TouchMovementMode),1>
       ::vftable;
  _DAT_02136310 = FUN_00c51290;
  _DAT_02136314 = 0;
  DAT_02136318 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021362fc = FUN_00888530();
  puVar3 = DAT_02136318;
  if (DAT_02136318 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00c51600();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00c517e0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00c51600();
  uVar2 = FUN_0086e3d0(s_movementMode_021366d8);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01895160);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1398 ; VA 0x004e03c0 ; FUN_004e03c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e03c0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b196;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c51e00();
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar3,uVar4,s_UIOffset_0213704c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02136e24 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02136df0 = RBX::Reflection::BoundProp<class_G3D::Vector2,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<class_G3D::Vector2,1>::
              BoundPropGetSet<class_RBX::ProximityPrompt>::vftable;
    puVar5[1] = &DAT_02136df0;
    puVar5[2] = 0x90;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_02136e24 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02136e24;
    DAT_02136e24 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_02136e24;
  }
  DAT_02136e24 = puVar5;
  cVar2 = (*(code *)DAT_02136df0[3])();
  if (cVar2 != '\0') {
    _DAT_02136e14 = _DAT_02136e14 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02136df0[2])();
  if (cVar2 != '\0') {
    _DAT_02136e14 = _DAT_02136e14 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01895420);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1399 ; VA 0x004e04f0 ; FUN_004e04f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e04f0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b1c0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd8bc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd8bc,uVar3,0,0,0x1f);
    if (DAT_01efd8bc == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01efd898 = RBX::Reflection::RefType<class_RBX::LocalizationTable*>::vftable;
      FUN_016f3654(&LAB_018956a0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efd8bc);
    }
  }
  uVar2 = FUN_00c51e00();
  FUN_009ca670(uVar2,&DAT_01efd898,s_RootLocalizationTable_02137088,s_Localization_021263c8,uVar3,
               uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_02136ee0 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::ProximityPrompt,class_RBX::LocalizationTable>::vftable
  ;
  _DAT_02136f14 =
       RBX::Reflection::RefPropDescriptor<class_RBX::ProximityPrompt,class_RBX::LocalizationTable>::
       vftable;
  DAT_02136f18 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02136f18 == (undefined4 *)0x0) {
    DAT_02136f18 = (undefined4 *)0x0;
  }
  else {
    *DAT_02136f18 =
         RBX::Reflection::PropDescriptor<class_RBX::ProximityPrompt,class_RBX::LocalizationTable*>::
         GetSetImpl<class_RBX::LocalizationTable*_(__thiscall_RBX::ProximityPrompt::*)(void)const_,void_(__thiscall_RBX::ProximityPrompt::*)(class_RBX::LocalizationTable*)>
         ::vftable;
    DAT_02136f18[2] = FUN_00c53db0;
    DAT_02136f18[3] = 0;
    DAT_02136f18[4] = FUN_00c54dc0;
    DAT_02136f18[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_02136ee0[3])();
  if (cVar1 != '\0') {
    _DAT_02136f04 = _DAT_02136f04 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02136ee0[2])();
  if (cVar1 != '\0') {
    _DAT_02136f04 = _DAT_02136f04 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01895440);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1400 ; VA 0x004e0800 ; FUN_004e0800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e0800(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c51e00(uVar2,0);
  FUN_009cb970(uVar1,s_PromptHidden_021341f8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021369f4 = 0xbc;
  _DAT_021369c0 =
       RBX::Reflection::
       EventDesc<class_RBX::ProximityPrompt,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::ProximityPrompt::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_021369e8 = 0;
  _DAT_021369ec = 0;
  _DAT_021369f0 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_021369c0 =
       RBX::Reflection::
       EventDesc<class_RBX::ProximityPrompt,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::ProximityPrompt::*>
       ::vftable;
  FUN_016f3654(&LAB_018954e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1401 ; VA 0x004e08f0 ; FUN_004e08f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e08f0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b1f3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c51e00();
  FUN_009cb970(uVar1,s_PromptShown_021341ec,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021369bc = 0xb8;
  iStack_8 = 0;
  _DAT_02136988 =
       RBX::Reflection::
       EventDesc<class_RBX::ProximityPrompt,void___cdecl(enum_RBX::ProximityPromptInputType),class_rbx::signal<void___cdecl(enum_RBX::ProximityPromptInputType)>,class_rbx::signal<void___cdecl(enum_RBX::ProximityPromptInputType)>_RBX::ProximityPrompt::*>
       ::vftable;
  FUN_0086e3d0(s_inputType_021341d8);
  thunk_FUN_00c12520();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021369b0 = uStack_1c;
  _DAT_021369b4 = uStack_18;
  _DAT_021369b8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02136988 =
       RBX::Reflection::
       EventDesc<class_RBX::ProximityPrompt,void___cdecl(enum_RBX::ProximityPromptInputType),class_rbx::signal<void___cdecl(enum_RBX::ProximityPromptInputType)>,class_rbx::signal<void___cdecl(enum_RBX::ProximityPromptInputType)>_RBX::ProximityPrompt::*>
       ::vftable;
  FUN_016f3654(&LAB_018954f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1402 ; VA 0x004e0be0 ; FUN_004e0be0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e0be0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b20a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c51e00(uVar2,0);
  FUN_009cb790(uVar1,s_InputHoldBegin_02137058,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02136e28 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ProximityPrompt,void___cdecl(void),0>::vftable;
  _DAT_02136e60 = FUN_00c541e0;
  _DAT_02136e64 = 0;
  _DAT_02136e4c = FUN_00888530();
  FUN_016f3654(&LAB_01895560);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1403 ; VA 0x004e0c80 ; FUN_004e0c80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e0c80(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b22a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c51e00(uVar2,0);
  FUN_009cb790(uVar1,s_InputHoldEnd_02137068,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02136e68 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ProximityPrompt,void___cdecl(void),0>::vftable;
  _DAT_02136ea0 = FUN_00c54260;
  _DAT_02136ea4 = 0;
  _DAT_02136e8c = FUN_00888530();
  FUN_016f3654(&LAB_01895570);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1404 ; VA 0x004e0d20 ; FUN_004e0d20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e0d20(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b254;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c550f0();
  uVar3 = FUN_00c51e00();
  FUN_009ca670(uVar3,uVar2,s_Exclusivity_02136fdc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02136c28 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::ProximityPrompt,enum_RBX::ProximityPrompt::ProximityPromptExclusivity>
                 ::vftable;
  _DAT_02136c5c = uVar2;
  DAT_02136c60 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02136c60 == (undefined4 *)0x0) {
    DAT_02136c60 = (undefined4 *)0x0;
  }
  else {
    *DAT_02136c60 =
         RBX::Reflection::
         PropDescriptor<class_RBX::ProximityPrompt,enum_RBX::ProximityPrompt::ProximityPromptExclusivity>
         ::
         GetSetImpl<enum_RBX::ProximityPrompt::ProximityPromptExclusivity_(__thiscall_RBX::ProximityPrompt::*)(void)const_,void_(__thiscall_RBX::ProximityPrompt::*)(enum_RBX::ProximityPrompt::ProximityPromptExclusivity)>
         ::vftable;
    DAT_02136c60[2] = FUN_00926d50;
    DAT_02136c60[3] = 0;
    DAT_02136c60[4] = FUN_00c54d30;
    DAT_02136c60[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02136c64 = FUN_00c550f0();
  cVar1 = (*(code *)DAT_02136c28[3])();
  if (cVar1 != '\0') {
    _DAT_02136c4c = _DAT_02136c4c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02136c28[2])();
  if (cVar1 != '\0') {
    _DAT_02136c4c = _DAT_02136c4c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018955c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1405 ; VA 0x004e0f40 ; FUN_004e0f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e0f40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b274;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c551a0();
  uVar3 = FUN_00c51e00();
  FUN_009ca670(uVar3,uVar2,s_Style_02136fd4,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02136be8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::ProximityPrompt,enum_RBX::ProximityPrompt::ProximityPromptStyle>
                 ::vftable;
  _DAT_02136c1c = uVar2;
  DAT_02136c20 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02136c20 == (undefined4 *)0x0) {
    DAT_02136c20 = (undefined4 *)0x0;
  }
  else {
    *DAT_02136c20 =
         RBX::Reflection::
         PropDescriptor<class_RBX::ProximityPrompt,enum_RBX::ProximityPrompt::ProximityPromptStyle>
         ::
         GetSetImpl<enum_RBX::ProximityPrompt::ProximityPromptStyle_(__thiscall_RBX::ProximityPrompt::*)(void)const_,void_(__thiscall_RBX::ProximityPrompt::*)(enum_RBX::ProximityPrompt::ProximityPromptStyle)>
         ::vftable;
    DAT_02136c20[2] = FUN_00c54090;
    DAT_02136c20[3] = 0;
    DAT_02136c20[4] = FUN_00c54f70;
    DAT_02136c20[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02136c24 = FUN_00c551a0();
  cVar1 = (*(code *)DAT_02136be8[3])();
  if (cVar1 != '\0') {
    _DAT_02136c0c = _DAT_02136c0c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02136be8[2])();
  if (cVar1 != '\0') {
    _DAT_02136c0c = _DAT_02136c0c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01895620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1406 ; VA 0x004e1060 ; FUN_004e1060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1060(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b676;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c55950();
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar3,uVar4,s_MaxActivationDistance_02136fe8,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0213722c = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_021371f8 = RBX::Reflection::BoundProp<float,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::ClickDetector>::
              vftable;
    puVar5[1] = &DAT_021371f8;
    puVar5[2] = 0x70;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_0213722c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0213722c;
    DAT_0213722c = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_0213722c;
  }
  DAT_0213722c = puVar5;
  cVar2 = (*(code *)DAT_021371f8[3])();
  if (cVar2 != '\0') {
    _DAT_0213721c = _DAT_0213721c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021371f8[2])();
  if (cVar2 != '\0') {
    _DAT_0213721c = _DAT_0213721c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018956b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1407 ; VA 0x004e1190 ; FUN_004e1190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1190(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b69c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c55950();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ClickDetector,class_RBX::TextureId>::
              GetSetImpl<class_RBX::TextureId_(__thiscall_RBX::ClickDetector::*)(void)const_,void_(__thiscall_RBX::ClickDetector::*)(class_RBX::TextureId)>
              ::vftable;
    puVar3[2] = FUN_00c56a20;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c57760;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,s_CursorIcon_02137304,s_Image_021372fc,uStack_24,0,0,0x1f,0,0,0);
  DAT_02137230 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02137264 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02137254 = _DAT_02137254 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02137230[2])();
    if (cVar1 != '\0') {
      _DAT_02137254 = _DAT_02137254 & 0xfffffff3;
    }
  }
  DAT_02137230 = RBX::Reflection::PropDescriptor<class_RBX::ClickDetector,class_RBX::TextureId>::
                 vftable;
  FUN_016f3654(&LAB_018956d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1408 ; VA 0x004e1310 ; FUN_004e1310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1310(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00c55c00(0x98,s_mouseClick_02137288,s_playerWhoClicked_02137268,0,
               CONCAT44(&DAT_021370a0,uStack_10),0);
  _DAT_021370d8 =
       RBX::Reflection::
       EventDesc<class_RBX::ClickDetector,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ClickDetector::*>
       ::vftable;
  FUN_016f3654(&LAB_01895750);
  return;
}



/* FUNCTION 1409 ; VA 0x004e1370 ; FUN_004e1370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1370(void)

{
  undefined4 extraout_var;
  
  FUN_00c55c00(0x98,s_MouseClick_0213727c,s_playerWhoClicked_02137268,0,0,0,0);
  _DAT_021370a0 =
       RBX::Reflection::
       EventDesc<class_RBX::ClickDetector,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ClickDetector::*>
       ::vftable;
  FUN_016f3654(&LAB_01895760,extraout_var);
  return;
}



/* FUNCTION 1410 ; VA 0x004e13c0 ; FUN_004e13c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e13c0(void)

{
  undefined4 extraout_var;
  
  FUN_00c55c00(0xa0,s_MouseHoverEnter_021372b8,s_playerWhoHovered_021372a4,0,0,0,0);
  _DAT_02137148 =
       RBX::Reflection::
       EventDesc<class_RBX::ClickDetector,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ClickDetector::*>
       ::vftable;
  FUN_016f3654(&LAB_01895770,extraout_var);
  return;
}



/* FUNCTION 1411 ; VA 0x004e1410 ; FUN_004e1410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1410(void)

{
  undefined4 extraout_var;
  
  FUN_00c55c00(0xa4,s_MouseHoverLeave_021372c8,s_playerWhoHovered_021372a4,0,0,0,0);
  _DAT_02137180 =
       RBX::Reflection::
       EventDesc<class_RBX::ClickDetector,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ClickDetector::*>
       ::vftable;
  FUN_016f3654(&LAB_01895780,extraout_var);
  return;
}



/* FUNCTION 1412 ; VA 0x004e1460 ; FUN_004e1460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1460(void)

{
  undefined4 extraout_var;
  
  FUN_00c55c00(0x9c,s_RightMouseClick_02137294,s_playerWhoClicked_02137268,0,0,0,0);
  _DAT_02137110 =
       RBX::Reflection::
       EventDesc<class_RBX::ClickDetector,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ClickDetector::*>
       ::vftable;
  FUN_016f3654(&LAB_01895790,extraout_var);
  return;
}



/* FUNCTION 1413 ; VA 0x004e14b0 ; FUN_004e14b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e14b0(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b6de;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c55950();
  FUN_009cb970(uVar1,s_MouseActionReplicated_021372e4,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_021371ec = 0xa8;
  iStack_8 = 0;
  _DAT_021371b8 =
       RBX::Reflection::
       EventDesc<class_RBX::ClickDetector,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int)>_RBX::ClickDetector::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_actionType_021372d8);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_021371e0 = uStack_1c;
  _DAT_021371e4 = uStack_18;
  _DAT_021371e8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_021371b8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::ClickDetector,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int)>_RBX::ClickDetector::*>
       ::vftable;
  _DAT_021371f0 = 1;
  _DAT_021371f4 = 0;
  FUN_016f3654(&LAB_018957a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1414 ; VA 0x004e1680 ; FUN_004e1680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1680(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180bfda;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c58700();
  FUN_00f50070(uVar1,s_OnClientInvoke_021376c8,uStack_1c,0,0);
  uStack_8 = 0;
  _DAT_021373e8 =
       RBX::Reflection::
       BoundAsyncCallbackDesc<class_RBX::RemoteFunction,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),1>
       ::vftable;
  _DAT_02137420 = 0x78;
  _DAT_02137428 = FUN_00c61780;
  _DAT_0213742c = 0;
  _DAT_0213740c = FUN_0088cbe0();
  uVar1 = FUN_0088cbe0();
  uVar2 = FUN_0086e3d0(s_arguments_0212bd00);
  FUN_00888aa0(uVar2,uVar1);
  FUN_016f3654(&LAB_01895810);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1415 ; VA 0x004e1750 ; FUN_004e1750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1750(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180bffa;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c58700();
  FUN_00f50070(uVar1,s_OnServerInvoke_021376b8,uStack_1c,0,0);
  uStack_8 = 0;
  _DAT_021373a0 =
       RBX::Reflection::
       BoundAsyncCallbackDesc<class_RBX::RemoteFunction,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),2>
       ::vftable;
  _DAT_021373d8 = 0x58;
  _DAT_021373e0 = FUN_00c61d90;
  _DAT_021373e4 = 0;
  _DAT_021373c4 = FUN_0088cbe0();
  uVar1 = FUN_0088cdc0();
  uVar2 = FUN_0086e3d0(s_player_0211f800);
  FUN_00888aa0(uVar2,uVar1);
  uVar1 = FUN_0088cbe0();
  uVar2 = FUN_0086e3d0(s_arguments_0212bd00);
  FUN_00888aa0(uVar2,uVar1);
  FUN_016f3654(&LAB_01895820);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1416 ; VA 0x004e1840 ; FUN_004e1840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1840(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180c033;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c58600();
  FUN_009cb970(uVar1,s_OnClientEvent_0213776c,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02137688 = FUN_00c5f3e0;
  _DAT_0213768c = 0;
  iStack_8 = 0;
  _DAT_02137650 =
       RBX::Reflection::
       EventDesc<class_RBX::RemoteEvent,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>*_(__thiscall_RBX::RemoteEvent::*)(bool)>
       ::vftable;
  FUN_0086e3d0(s_arguments_0212bd00);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02137678 = uStack_1c;
  _DAT_0213767c = uStack_18;
  _DAT_02137680 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_02137650 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::RemoteEvent,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>*_(__thiscall_RBX::RemoteEvent::*)(bool)>
       ::vftable;
  _DAT_02137690 = 0;
  _DAT_02137694 = 1;
  FUN_016f3654(&LAB_01895830);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1417 ; VA 0x004e19b0 ; FUN_004e19b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e19b0(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180c06e;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c58600();
  FUN_009cb970(uVar1,s_OnServerEvent_0213775c,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02137640 = FUN_00c5f430;
  _DAT_02137644 = 0;
  iStack_8 = 0;
  _DAT_02137608 =
       RBX::Reflection::
       EventDesc<class_RBX::RemoteEvent,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>*_(__thiscall_RBX::RemoteEvent::*)(bool)>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_arguments_0212bd00);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02137630 = uStack_1c;
  _DAT_02137634 = uStack_18;
  _DAT_02137638 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_02137608 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::RemoteEvent,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>*_(__thiscall_RBX::RemoteEvent::*)(bool)>
       ::vftable;
  _DAT_02137648 = 0;
  _DAT_0213764c = 1;
  FUN_016f3654(&LAB_01895840);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1418 ; VA 0x004e1b90 ; FUN_004e1b90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1b90(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180c0ae;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c58700();
  FUN_009cb970(uVar1,s_RemoteOnInvokeError_02137720,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02137524 = 0xb0;
  iStack_8 = 0;
  _DAT_021374f0 =
       RBX::Reflection::
       EventDesc<class_RBX::RemoteFunction,void___cdecl(int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::RemoteFunction::*>
       ::vftable;
  FUN_0086e3d0(&DAT_021347ec);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_arguments_0212bd00);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02137518 = uStack_1c;
  _DAT_0213751c = uStack_18;
  _DAT_02137520 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_021374f0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::RemoteFunction,void___cdecl(int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::RemoteFunction::*>
       ::vftable;
  _DAT_02137528 = 0;
  _DAT_0213752c = 0;
  FUN_016f3654(&LAB_01895860);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1419 ; VA 0x004e1d20 ; FUN_004e1d20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1d20(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180c0f9;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c58700();
  FUN_009cb970(uVar1,s_RemoteOnInvokeServer_021376d8,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02137464 = 0x98;
  iStack_8 = 0;
  _DAT_02137430 =
       RBX::Reflection::
       EventDesc<class_RBX::RemoteFunction,void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_RBX::RemoteFunction::*>
       ::vftable;
  FUN_0086e3d0(&DAT_021347ec);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_arguments_0212bd00);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02137458 = uStack_1c;
  _DAT_0213745c = uStack_18;
  _DAT_02137460 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_02137430 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::RemoteFunction,void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_RBX::RemoteFunction::*>
       ::vftable;
  _DAT_02137468 = 0;
  _DAT_0213746c = 0;
  FUN_016f3654(&LAB_01895870);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1420 ; VA 0x004e1f20 ; FUN_004e1f20 */

void FUN_004e1f20(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00c5ad00(FUN_00c5eb70,0,s_FireAllClients_0213774c,s_arguments_0212bd00,0,uStack_10,0);
  FUN_016f3654(&LAB_01895890);
  return;
}



/* FUNCTION 1421 ; VA 0x004e1f80 ; FUN_004e1f80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e1f80(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180c12e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c58600(uVar2,0);
  FUN_009cb790(uVar1,s_FireClient_02137740,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02137578 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::RemoteEvent,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),2>
       ::vftable;
  _DAT_021375b0 = FUN_00c5eca0;
  _DAT_021375b4 = 0;
  _DAT_021375b8 = 0;
  _DAT_021375bc = 0;
  uStack_8 = 2;
  FUN_00c5d810();
  FUN_016f3654(&LAB_018958e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1422 ; VA 0x004e2040 ; FUN_004e2040 */

void FUN_004e2040(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00c5ad00(FUN_00c5f100,0,s_FireServer_02137734,s_arguments_0212bd00,0,uStack_10,0);
  FUN_016f3654(&LAB_018958f0);
  return;
}



/* FUNCTION 1423 ; VA 0x004e20a0 ; FUN_004e20a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e20a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180c15e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c58700(uVar2,0);
  FUN_009cb820(uVar1,s_InvokeClient_021376a8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02137358 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::RemoteFunction,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),2>
       ::vftable;
  _DAT_02137390 = FUN_00c5fc40;
  _DAT_02137394 = 0;
  _DAT_02137398 = 0;
  _DAT_0213739c = 0;
  uStack_8 = 2;
  FUN_00c5da80();
  FUN_016f3654(&LAB_01895940);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1424 ; VA 0x004e2160 ; FUN_004e2160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e2160(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180c1bc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c58700();
  FUN_009cb820(uVar2,s_InvokeServer_02137698,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02137310 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::RemoteFunction,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),1>
       ::vftable;
  _DAT_02137348 = FUN_00c5fee0;
  _DAT_0213734c = 0;
  DAT_02137350 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02137334 = FUN_0088cbe0();
  puVar4 = DAT_02137350;
  if (DAT_02137350 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cbe0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_00630900();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cbe0();
  uVar3 = FUN_0086e3d0(s_arguments_0212bd00);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01895950);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1425 ; VA 0x004e2680 ; FUN_004e2680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e2680(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cdf3;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c63380();
  FUN_009cb970(uVar1,s_RemoteCreateSeatWeld_02137b60,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02137a28 = 0x250;
  _DAT_02137a2c = 0;
  iStack_8 = 0;
  _DAT_021379f0 =
       RBX::Reflection::
       EventDesc<class_RBX::VehicleSeat,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::VehicleSeat::*>
       ::vftable;
  FUN_0086e3d0(s_humanoid_02137b54);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02137a18 = uStack_1c;
  _DAT_02137a1c = uStack_18;
  _DAT_02137a20 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_021379f0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::VehicleSeat,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::VehicleSeat::*>
       ::vftable;
  _DAT_02137a30 = 0;
  _DAT_02137a34 = 0;
  FUN_016f3654(&LAB_01895ae0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1426 ; VA 0x004e27f0 ; FUN_004e27f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e27f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c63380(uVar2,0);
  FUN_009cb970(uVar1,s_RemoteDestroySeatWeld_02137b78,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02137a70 = 600;
  DAT_02137a74 = 0;
  _DAT_02137a38 =
       RBX::Reflection::
       EventDesc<class_RBX::VehicleSeat,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::VehicleSeat::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02137a60 = 0;
  _DAT_02137a64 = 0;
  _DAT_02137a68 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_02137a38 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::VehicleSeat,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::VehicleSeat::*>
       ::vftable;
  _DAT_02137a78 = 0;
  _DAT_02137a7c = 0;
  FUN_016f3654(&LAB_01895af0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1427 ; VA 0x004e2900 ; FUN_004e2900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e2900(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ce4c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00c67360;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c63380();
  FUN_009cb790(uVar2,&DAT_02123cd0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02137ab8 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_02137a80 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::VehicleSeat,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_02137ac0 = 0;
  DAT_02137ac4 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02137aa4 = FUN_00888530();
  puVar4 = DAT_02137ac4;
  if (DAT_02137ac4 == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088cdc0();
    iStack_f8 = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_f4 = *puVar4;
    uStack_f0 = puVar4[1];
    iStack_f8 = FUN_006309e0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_humanoid_02137b54);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_01895b00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1428 ; VA 0x004e2f70 ; FUN_004e2f70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e2f70(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffd0;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ce80;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffd0 & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x13;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efe1c4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efe1c4,uVar3,0,0,0x13);
    if (DAT_01efe1c4 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01efe1a0 = RBX::Reflection::RefType<class_RBX::Humanoid*>::vftable;
      FUN_016f3654(&LAB_01895c90);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efe1c4);
    }
  }
  uVar2 = FUN_00c63380();
  FUN_009ca670(uVar2,&DAT_01efe1a0,s_Occupant_02137ad4,s_Control_0211ffd0,uVar3,uVar4,uVar5,uVar6,0,
               0,0);
  uStack_8 = 1;
  DAT_021377b8 = RBX::Reflection::RefPropDescriptor<class_RBX::VehicleSeat,class_RBX::Humanoid>::
                 vftable;
  _DAT_021377ec =
       RBX::Reflection::RefPropDescriptor<class_RBX::VehicleSeat,class_RBX::Humanoid>::vftable;
  DAT_021377f0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021377f0 == (undefined4 *)0x0) {
    DAT_021377f0 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_021377f0 + 2) = 0xc65980;
    *DAT_021377f0 =
         RBX::Reflection::PropDescriptor<class_RBX::VehicleSeat,class_RBX::Humanoid*>::
         GetImpl<class_RBX::Humanoid*_(__thiscall_RBX::SeatImpl<class_RBX::PartInstance>::*)(void)const_>
         ::vftable;
    DAT_021377f0[4] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_021377b8[3])();
  if (cVar1 != '\0') {
    _DAT_021377dc = _DAT_021377dc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021377b8[2])();
  if (cVar1 != '\0') {
    _DAT_021377dc = _DAT_021377dc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01895c10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1429 ; VA 0x004e3120 ; FUN_004e3120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e3120(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d0b3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c67ac0();
  FUN_009cb970(uVar1,s_AxisChanged_02137c48,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02137c34 = 0x90;
  iStack_8 = 0;
  _DAT_02137c00 =
       RBX::Reflection::
       EventDesc<class_RBX::SkateboardController,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::SkateboardController::*>
       ::vftable;
  FUN_0086e3d0(&DAT_02137c40);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02137c28 = uStack_1c;
  _DAT_02137c2c = uStack_18;
  _DAT_02137c30 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02137c00 =
       RBX::Reflection::
       EventDesc<class_RBX::SkateboardController,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::SkateboardController::*>
       ::vftable;
  FUN_016f3654(&LAB_01895ca0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1430 ; VA 0x004e3350 ; FUN_004e3350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e3350(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d22c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c68a10();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ScreenGui,int>::
              GetSetImpl<int_(__thiscall_RBX::ScreenGui::*)(void)const_,void_(__thiscall_RBX::ScreenGui::*)(int)>
              ::vftable;
    puVar3[2] = FUN_00c699d0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c6a620;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_DisplayOrder_02137cfc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02137c54 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02137c88 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02137c78 = _DAT_02137c78 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02137c54[2])();
    if (cVar1 != '\0') {
      _DAT_02137c78 = _DAT_02137c78 & 0xfffffff3;
    }
  }
  DAT_02137c54 = RBX::Reflection::PropDescriptor<class_RBX::ScreenGui,int>::vftable;
  FUN_016f3654(&LAB_01895d50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1431 ; VA 0x004e3780 ; FUN_004e3780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e3780(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d45e;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c6ac40();
  FUN_009cb970(uVar1,s_MouseDrag_02138034,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02137e5c = 0xac;
  iStack_8 = 0;
  _DAT_02137e28 =
       RBX::Reflection::
       EventDesc<class_RBX::Handles,void___cdecl(enum_RBX::NormalId,float),class_rbx::remote_signal<void___cdecl(enum_RBX::NormalId,float)>,class_rbx::remote_signal<void___cdecl(enum_RBX::NormalId,float)>_RBX::Handles::*>
       ::vftable;
  FUN_0086e3d0(&DAT_02138008);
  thunk_FUN_00890320();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_distance_02138028);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02137e50 = uStack_1c;
  _DAT_02137e54 = uStack_18;
  _DAT_02137e58 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_02137e28 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Handles,void___cdecl(enum_RBX::NormalId,float),class_rbx::remote_signal<void___cdecl(enum_RBX::NormalId,float)>,class_rbx::remote_signal<void___cdecl(enum_RBX::NormalId,float)>_RBX::Handles::*>
       ::vftable;
  _DAT_02137e60 = 0;
  _DAT_02137e64 = 1;
  FUN_016f3654(&LAB_01895f30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1432 ; VA 0x004e39b0 ; FUN_004e39b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e39b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d48c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c6ac40();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Handles,class_RBX::Faces>::
              GetSetImpl<class_RBX::Faces_(__thiscall_RBX::Handles::*)(void)const_,void_(__thiscall_RBX::Handles::*)(class_RBX::Faces)>
              ::vftable;
    puVar3[2] = FUN_00c6c280;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c6c8b0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d230();
  FUN_009ca670(uVar2,uVar4,s_Faces_02138000,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02137d70 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Faces>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02137da4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02137d94 = _DAT_02137d94 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02137d70[2])();
    if (cVar1 != '\0') {
      _DAT_02137d94 = _DAT_02137d94 & 0xfffffff3;
    }
  }
  DAT_02137d70 = RBX::Reflection::PropDescriptor<class_RBX::Handles,class_RBX::Faces>::vftable;
  FUN_016f3654(&LAB_01895f80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1433 ; VA 0x004e3ae0 ; FUN_004e3ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e3ae0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d4b4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c6cea0();
  uVar3 = FUN_00c6ac40();
  FUN_009ca670(uVar3,uVar2,s_Style_02136fd4,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02137d30 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Handles,enum_RBX::Handles::VisualStyle>::vftable;
  _DAT_02137d64 = uVar2;
  DAT_02137d68 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02137d68 == (undefined4 *)0x0) {
    DAT_02137d68 = (undefined4 *)0x0;
  }
  else {
    *DAT_02137d68 =
         RBX::Reflection::PropDescriptor<class_RBX::Handles,enum_RBX::Handles::VisualStyle>::
         GetSetImpl<enum_RBX::Handles::VisualStyle_(__thiscall_RBX::Handles::*)(void)const_,void_(__thiscall_RBX::Handles::*)(enum_RBX::Handles::VisualStyle)>
         ::vftable;
    DAT_02137d68[2] = &LAB_00c6c350;
    DAT_02137d68[3] = 0;
    DAT_02137d68[4] = FUN_00c6cc40;
    DAT_02137d68[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02137d6c = FUN_00c6cea0();
  cVar1 = (*(code *)DAT_02137d30[3])();
  if (cVar1 != '\0') {
    _DAT_02137d54 = _DAT_02137d54 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02137d30[2])();
  if (cVar1 != '\0') {
    _DAT_02137d54 = _DAT_02137d54 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01895fa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1434 ; VA 0x004e3c00 ; FUN_004e3c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e3c00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180dcd4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c7d060();
  uVar3 = FUN_00c6de80();
  FUN_009ca670(uVar3,uVar2,s_AutomaticSize_02139244,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021383a0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GuiObject,enum_RBX::GuiObject::AutomaticSize>::
                 vftable;
  _DAT_021383d4 = uVar2;
  DAT_021383d8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021383d8 == (undefined4 *)0x0) {
    DAT_021383d8 = (undefined4 *)0x0;
  }
  else {
    *DAT_021383d8 =
         RBX::Reflection::PropDescriptor<class_RBX::GuiObject,enum_RBX::GuiObject::AutomaticSize>::
         GetSetImpl<enum_RBX::GuiObject::AutomaticSize_(__thiscall_RBX::GuiObject::*)(void)const_,void_(__thiscall_RBX::GuiObject::*)(enum_RBX::GuiObject::AutomaticSize)>
         ::vftable;
    DAT_021383d8[2] = &LAB_00c76e00;
    DAT_021383d8[3] = 0;
    DAT_021383d8[4] = FUN_00c7bb60;
    DAT_021383d8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021383dc = FUN_00c7d060();
  cVar1 = (*(code *)DAT_021383a0[3])();
  if (cVar1 != '\0') {
    _DAT_021383c4 = _DAT_021383c4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021383a0[2])();
  if (cVar1 != '\0') {
    _DAT_021383c4 = _DAT_021383c4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01896020);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1435 ; VA 0x004e3f40 ; FUN_004e3f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e3f40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180dcf4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c7d110();
  uVar3 = FUN_00c6de80();
  FUN_009ca670(uVar3,uVar2,s_BorderMode_02139264,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02138420 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GuiObject,enum_RBX::GuiObject::BorderMode>::vftable;
  _DAT_02138454 = uVar2;
  DAT_02138458 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02138458 == (undefined4 *)0x0) {
    DAT_02138458 = (undefined4 *)0x0;
  }
  else {
    *DAT_02138458 =
         RBX::Reflection::PropDescriptor<class_RBX::GuiObject,enum_RBX::GuiObject::BorderMode>::
         GetSetImpl<enum_RBX::GuiObject::BorderMode_(__thiscall_RBX::GuiObject::*)(void)const_,void_(__thiscall_RBX::GuiObject::*)(enum_RBX::GuiObject::BorderMode)>
         ::vftable;
    DAT_02138458[2] = &LAB_00c76e90;
    DAT_02138458[3] = 0;
    DAT_02138458[4] = FUN_00c7be80;
    DAT_02138458[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213845c = FUN_00c7d110();
  cVar1 = (*(code *)DAT_02138420[3])();
  if (cVar1 != '\0') {
    _DAT_02138444 = _DAT_02138444 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02138420[2])();
  if (cVar1 != '\0') {
    _DAT_02138444 = _DAT_02138444 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018960e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1436 ; VA 0x004e4ca0 ; FUN_004e4ca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e4ca0(void)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined auStack_118 [216];
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180dd23;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_009cba60(auStack_40,1,0);
  uStack_30 = *puVar1;
  uStack_2c = puVar1[1];
  uStack_28 = puVar1[2];
  uStack_24 = puVar1[3];
  uVar2 = FUN_00c6de80();
  FUN_009cb970(uVar2,s_DragBegin_0213935c,0,uStack_30,uStack_2c,uStack_28);
  _DAT_0213887c = 0x29c;
  iStack_8 = 0;
  _DAT_02138848 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiObject,void___cdecl(class_RBX::UDim2),class_rbx::remote_signal<void___cdecl(class_RBX::UDim2)>,class_rbx::remote_signal<void___cdecl(class_RBX::UDim2)>_RBX::GuiObject::*>
       ::vftable;
  uVar2 = FUN_0086e3d0(s_initialPosition_0213934c);
  uVar3 = FUN_0088d5f0();
  FUN_00888740(uVar2,uVar3);
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_118,auStack_40,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02138870 = uStack_1c;
  _DAT_02138874 = uStack_18;
  _DAT_02138878 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_118,0xd8,1,FUN_00688b10);
  _DAT_02138848 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::GuiObject,void___cdecl(class_RBX::UDim2),class_rbx::remote_signal<void___cdecl(class_RBX::UDim2)>,class_rbx::remote_signal<void___cdecl(class_RBX::UDim2)>_RBX::GuiObject::*>
       ::vftable;
  _DAT_02138880 = 0;
  _DAT_02138884 = uStack_24;
  FUN_016f3654(&LAB_01896420);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1437 ; VA 0x004e4e10 ; FUN_004e4e10 */

void FUN_004e4e10(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cba60(auStack_14,1,0);
  FUN_00c6f230(0x294,s_DragStopped_02139340,&DAT_0212a0b0,&DAT_0212a0ac,0,*puVar1,puVar1[1],
               puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_01896430);
  return;
}



/* FUNCTION 1438 ; VA 0x004e4e70 ; FUN_004e4e70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e4e70(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180dd5e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c6dcc0();
  FUN_009cb970(uVar1,s_Activated_021362a8,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02138dd8 = 0x378;
  iStack_8 = 0;
  _DAT_02138da4 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiButton,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int)>_RBX::GuiButton::*>
       ::vftable;
  FUN_0086e3d0(s_inputObject_0213947c);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_clickCount_02139470);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02138dcc = uStack_1c;
  _DAT_02138dd0 = uStack_18;
  _DAT_02138dd4 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02138da4 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiButton,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,int)>_RBX::GuiButton::*>
       ::vftable;
  FUN_016f3654(&LAB_01896440);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1439 ; VA 0x004e5080 ; FUN_004e5080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e5080(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180dd9e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c6de80();
  FUN_009cb970(uVar1,s_TouchLongPress_0212ea60,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02138964 = 0x1c0;
  iStack_8 = 0;
  _DAT_02138930 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiObject,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState)>_RBX::GuiObject::*>
       ::vftable;
  FUN_0086e3d0(s_touchPositions_0212e9f8);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_state_02123f08);
  thunk_FUN_00d82070();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02138958 = uStack_1c;
  _DAT_0213895c = uStack_18;
  _DAT_02138960 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02138930 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiObject,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState)>_RBX::GuiObject::*>
       ::vftable;
  FUN_016f3654(&LAB_01896470);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1440 ; VA 0x004e5290 ; FUN_004e5290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e5290(void)

{
  undefined4 uVar1;
  undefined auStack_38c [864];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ddf4;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c6de80();
  FUN_009cb970(uVar1,s_TouchPan_0212ea9c,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021389d4 = 0x1c8;
  iStack_8 = 0;
  _DAT_021389a0 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiObject,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState)>_RBX::GuiObject::*>
       ::vftable;
  FUN_0086e3d0(s_touchPositions_0212e9f8);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_totalTranslation_0212ea88);
  FUN_0088d730();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_velocity_0212ea14);
  FUN_0088d730();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(s_state_02123f08);
  thunk_FUN_00d82070();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_38c,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  _DAT_021389c8 = uStack_1c;
  _DAT_021389cc = uStack_18;
  _DAT_021389d0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_38c,0xd8,4,FUN_00688b10);
  _DAT_021389a0 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiObject,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState)>_RBX::GuiObject::*>
       ::vftable;
  FUN_016f3654(&LAB_018964a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1441 ; VA 0x004e54d0 ; FUN_004e54d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e54d0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180de2e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c6de80();
  FUN_009cb970(uVar1,s_TouchSwipe_0212ea54,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0213892c = 0x1bc;
  iStack_8 = 0;
  _DAT_021388f8 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiObject,void___cdecl(enum_RBX::GuiSwipeDirection,int),class_rbx::signal<void___cdecl(enum_RBX::GuiSwipeDirection,int)>,class_rbx::signal<void___cdecl(enum_RBX::GuiSwipeDirection,int)>_RBX::GuiObject::*>
       ::vftable;
  FUN_0086e3d0(s_swipeDirection_0212ea44);
  thunk_FUN_00b84860();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_numberOfTouches_0212ea34);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02138920 = uStack_1c;
  _DAT_02138924 = uStack_18;
  _DAT_02138928 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_021388f8 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiObject,void___cdecl(enum_RBX::GuiSwipeDirection,int),class_rbx::signal<void___cdecl(enum_RBX::GuiSwipeDirection,int)>,class_rbx::signal<void___cdecl(enum_RBX::GuiSwipeDirection,int)>_RBX::GuiObject::*>
       ::vftable;
  FUN_016f3654(&LAB_018964d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1442 ; VA 0x004e5640 ; FUN_004e5640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e5640(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180de63;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c6de80();
  FUN_009cb970(uVar1,s_TouchTap_0212ea08,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021388bc = 0x1b4;
  iStack_8 = 0;
  _DAT_02138888 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiObject,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_RBX::GuiObject::*>
       ::vftable;
  FUN_0086e3d0(s_touchPositions_0212e9f8);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021388b0 = uStack_1c;
  _DAT_021388b4 = uStack_18;
  _DAT_021388b8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02138888 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiObject,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_RBX::GuiObject::*>
       ::vftable;
  FUN_016f3654(&LAB_018964e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1443 ; VA 0x004e5ab0 ; FUN_004e5ab0 */

void FUN_004e5ab0(void)

{
  undefined auStack_84 [32];
  undefined uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined *puStack_48;
  undefined **ppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180de78;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_3c = 0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  ppuStack_40 = RBX::Lua::WeakFunctionRef::vftable;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_50 = (ulonglong)uStack_20;
  uStack_8 = 0;
  uStack_54 = 0;
  puStack_14 = auStack_84;
  puStack_48 = (undefined *)0x0;
  ExceptionList = &pvStack_10;
  FUN_00d88580(&ppuStack_40);
  uStack_64 = 0;
  uStack_60 = 0x3f800000;
  uStack_5c = 3;
  uStack_58 = 1;
  FUN_00c6ead0(FUN_00c7d7a0,0,s_TweenPosition_021391f8,s_endPosition_021391cc,
               s_easingDirection_021391bc,s_easingStyle_021391b0,&DAT_0211fe58,s_override_021391a4,
               s_callback_02139198);
  puStack_48 = (undefined *)0x4e5b80;
  FUN_00d88a30();
  puStack_48 = &LAB_018965b0;
  uStack_50 = CONCAT44(0x4e5b8a,(undefined4)uStack_50);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1444 ; VA 0x004e5ba0 ; FUN_004e5ba0 */

void FUN_004e5ba0(void)

{
  undefined auStack_84 [32];
  undefined uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined *puStack_48;
  undefined **ppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180de78;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_3c = 0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  ppuStack_40 = RBX::Lua::WeakFunctionRef::vftable;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_50 = (ulonglong)uStack_20;
  uStack_8 = 0;
  uStack_54 = 0;
  puStack_14 = auStack_84;
  puStack_48 = (undefined *)0x0;
  ExceptionList = &pvStack_10;
  FUN_00d88580(&ppuStack_40);
  uStack_64 = 0;
  uStack_60 = 0x3f800000;
  uStack_5c = 3;
  uStack_58 = 1;
  FUN_00c6ead0(FUN_00c7db70,0,s_TweenSize_02139208,s_endSize_021391d8,s_easingDirection_021391bc,
               s_easingStyle_021391b0,&DAT_0211fe58,s_override_021391a4,s_callback_02139198);
  puStack_48 = (undefined *)0x4e5c70;
  FUN_00d88a30();
  puStack_48 = &LAB_018965c0;
  uStack_50 = CONCAT44(0x4e5c7a,(undefined4)uStack_50);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1445 ; VA 0x004e5c90 ; FUN_004e5c90 */

void FUN_004e5c90(void)

{
  undefined auStack_84 [32];
  undefined uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined *puStack_48;
  undefined **ppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180de78;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_3c = 0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  ppuStack_40 = RBX::Lua::WeakFunctionRef::vftable;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_50 = (ulonglong)uStack_20;
  uStack_8 = 0;
  uStack_54 = 0;
  puStack_14 = auStack_84;
  puStack_48 = (undefined *)0x0;
  ExceptionList = &pvStack_10;
  FUN_00d88580(&ppuStack_40);
  uStack_64 = 0;
  uStack_60 = 0x3f800000;
  uStack_5c = 3;
  uStack_58 = 1;
  FUN_00c6e980(FUN_00c7dc70,0,s_TweenSizeAndPosition_021391e0,s_endSize_021391d8,
               s_endPosition_021391cc,s_easingDirection_021391bc,s_easingStyle_021391b0,
               &DAT_0211fe58,s_override_021391a4,s_callback_02139198);
  puStack_48 = (undefined *)0x4e5d65;
  FUN_00d88a30();
  puStack_48 = &LAB_018965d0;
  uStack_50 = CONCAT44(0x4e5d6f,(undefined4)uStack_50);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1446 ; VA 0x004e5d90 ; FUN_004e5d90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e5d90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180deac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c6de80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_G3D::Vector2>::
              GetSetImpl<class_G3D::Vector2_(__thiscall_RBX::GuiBase2d::*)(void)const_,void_(__thiscall_RBX::GuiObject::*)(class_G3D::Vector2)>
              ::vftable;
    puVar3[2] = FUN_00c76dd0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c7bab0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_AnchorPoint_02139238,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02138330 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02138364 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02138354 = _DAT_02138354 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02138330[2])();
    if (cVar1 != '\0') {
      _DAT_02138354 = _DAT_02138354 & 0xfffffff3;
    }
  }
  DAT_02138330 = RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_G3D::Vector2>::vftable;
  FUN_016f3654(&LAB_018966c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1447 ; VA 0x004e6040 ; FUN_004e6040 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e6040(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ded4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c7d2c0();
  uVar3 = FUN_00c6dcc0();
  FUN_009ca670(uVar3,uVar2,s_Style_02136fd4,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02139158 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GuiButton,enum_RBX::GuiButton::Style>::vftable;
  _DAT_0213918c = uVar2;
  DAT_02139190 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02139190 == (undefined4 *)0x0) {
    DAT_02139190 = (undefined4 *)0x0;
  }
  else {
    *DAT_02139190 =
         RBX::Reflection::PropDescriptor<class_RBX::GuiButton,enum_RBX::GuiButton::Style>::
         GetSetImpl<enum_RBX::GuiButton::Style_(__thiscall_RBX::GuiButton::*)(void)const_,void_(__thiscall_RBX::GuiButton::*)(enum_RBX::GuiButton::Style)>
         ::vftable;
    DAT_02139190[2] = FUN_00c777d0;
    DAT_02139190[3] = 0;
    DAT_02139190[4] = FUN_00c7c970;
    DAT_02139190[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02139194 = FUN_00c7d2c0();
  cVar1 = (*(code *)DAT_02139158[3])();
  if (cVar1 != '\0') {
    _DAT_0213917c = _DAT_0213917c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02139158[2])();
  if (cVar1 != '\0') {
    _DAT_0213917c = _DAT_0213917c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01896720);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1448 ; VA 0x004e6470 ; FUN_004e6470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e6470(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180def4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c7d230();
  uVar3 = FUN_00c6de80();
  FUN_009ca670(uVar3,uVar2,s_SizeConstraint_02139254,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021383e0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::GuiObject,enum_RBX::GuiObject::SizeConstraint>::
                 vftable;
  _DAT_02138414 = uVar2;
  DAT_02138418 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02138418 == (undefined4 *)0x0) {
    DAT_02138418 = (undefined4 *)0x0;
  }
  else {
    *DAT_02138418 =
         RBX::Reflection::PropDescriptor<class_RBX::GuiObject,enum_RBX::GuiObject::SizeConstraint>::
         GetSetImpl<enum_RBX::GuiObject::SizeConstraint_(__thiscall_RBX::GuiObject::*)(void)const_,void_(__thiscall_RBX::GuiObject::*)(enum_RBX::GuiObject::SizeConstraint)>
         ::vftable;
    DAT_02138418[2] = &LAB_008b3a00;
    DAT_02138418[3] = 0;
    DAT_02138418[4] = FUN_00c7c940;
    DAT_02138418[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213841c = FUN_00c7d230();
  cVar1 = (*(code *)DAT_021383e0[3])();
  if (cVar1 != '\0') {
    _DAT_02138404 = _DAT_02138404 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021383e0[2])();
  if (cVar1 != '\0') {
    _DAT_02138404 = _DAT_02138404 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018967e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1449 ; VA 0x004e6840 ; FUN_004e6840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e6840(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ec29;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c7e1e0();
  FUN_009cb970(uVar1,s_MouseDrag_02138034,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02139664 = 0xac;
  iStack_8 = 0;
  _DAT_02139630 =
       RBX::Reflection::
       EventDesc<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis,float,float),class_rbx::remote_signal<void___cdecl(enum_G3D::Vector3::Axis,float,float)>,class_rbx::remote_signal<void___cdecl(enum_G3D::Vector3::Axis,float,float)>_RBX::ArcHandles::*>
       ::vftable;
  FUN_0086e3d0(&DAT_02137c40);
  thunk_FUN_00896ba0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_relativeAngle_02139814);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_deltaRadius_02139808);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02139658 = uStack_1c;
  _DAT_0213965c = uStack_18;
  _DAT_02139660 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_02139630 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::ArcHandles,void___cdecl(enum_G3D::Vector3::Axis,float,float),class_rbx::remote_signal<void___cdecl(enum_G3D::Vector3::Axis,float,float)>,class_rbx::remote_signal<void___cdecl(enum_G3D::Vector3::Axis,float,float)>_RBX::ArcHandles::*>
       ::vftable;
  _DAT_02139668 = 0;
  _DAT_0213966c = 1;
  FUN_016f3654(&LAB_01896d30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1450 ; VA 0x004e6a90 ; FUN_004e6a90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e6a90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ec5c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c7e1e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ArcHandles,class_RBX::Axes>::
              GetSetImpl<class_RBX::Axes_(__thiscall_RBX::ArcHandles::*)(void)const_,void_(__thiscall_RBX::ArcHandles::*)(class_RBX::Axes)>
              ::vftable;
    puVar3[2] = FUN_00c7f600;
    puVar3[3] = 0;
    puVar3[4] = FUN_00c7fc30;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088ce60();
  FUN_009ca670(uVar2,uVar4,&DAT_02137c38,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02139578 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Axes>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021395ac = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213959c = _DAT_0213959c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02139578[2])();
    if (cVar1 != '\0') {
      _DAT_0213959c = _DAT_0213959c & 0xfffffff3;
    }
  }
  DAT_02139578 = RBX::Reflection::PropDescriptor<class_RBX::ArcHandles,class_RBX::Axes>::vftable;
  FUN_016f3654(&LAB_01896d60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1451 ; VA 0x004e6bc0 ; FUN_004e6bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e6bc0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f20a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c809f0(uVar2,0);
  FUN_009cb790(uVar1,s_Abort_02139c74,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02139b50 = RBX::Reflection::BoundFuncDesc<class_RBX::Rocket,void___cdecl(void),0>::vftable;
  _DAT_02139b88 = FUN_00c828b0;
  _DAT_02139b8c = 0;
  _DAT_02139b74 = FUN_00888530();
  FUN_016f3654(&LAB_01896de0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1452 ; VA 0x004e6c60 ; FUN_004e6c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e6c60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f22a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c809f0(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02139c64,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02139ad0 = RBX::Reflection::BoundFuncDesc<class_RBX::Rocket,void___cdecl(void),0>::vftable;
  _DAT_02139b08 = FUN_00c84df0;
  _DAT_02139b0c = 0;
  _DAT_02139af4 = FUN_00888530();
  FUN_016f3654(&LAB_01896df0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1453 ; VA 0x004e6d00 ; FUN_004e6d00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e6d00(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f266;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c809f0();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,s_Active_0212c204,s_Internal_02139c58,uStack_24,0,0,2,0,0,0);
  DAT_02139ac8 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02139a94 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::Rocket>::vftable;
    puVar5[1] = &DAT_02139a94;
    puVar5[2] = 0x158;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_02139ac8 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02139ac8;
    DAT_02139ac8 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_02139ac8;
  }
  DAT_02139ac8 = puVar5;
  cVar2 = (*(code *)DAT_02139a94[3])();
  if (cVar2 != '\0') {
    _DAT_02139ab8 = _DAT_02139ab8 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02139a94[2])();
  if (cVar2 != '\0') {
    _DAT_02139ab8 = _DAT_02139ab8 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01896e00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1454 ; VA 0x004e70a0 ; FUN_004e70a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e70a0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f27a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c809f0();
  FUN_00918e80(uVar3,s_MaxTorque_02139c3c,&DAT_02139c24,0);
  uStack_8 = 0;
  DAT_02139a24 = RBX::Reflection::BoundProp<class_G3D::Vector3,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<class_G3D::Vector3,1>::BoundPropGetSet<class_RBX::Rocket>::
              vftable;
    puVar4[1] = &DAT_02139a24;
    puVar4[2] = 400;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_02139a58 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02139a58;
    DAT_02139a58 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_02139a58;
  }
  DAT_02139a58 = puVar4;
  cVar2 = (*(code *)DAT_02139a24[3])();
  if (cVar2 != '\0') {
    _DAT_02139a48 = _DAT_02139a48 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02139a24[2])();
  if (cVar2 != '\0') {
    _DAT_02139a48 = _DAT_02139a48 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1455 ; VA 0x004e71c0 ; FUN_004e71c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e71c0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f2b0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee410c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee410c,uVar3,0,0,0x1f);
    if (DAT_01ee410c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee40e8 = RBX::Reflection::RefType<class_RBX::PartInstance*>::vftable;
      FUN_016f3654(&LAB_01887330);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee410c);
    }
  }
  uVar2 = FUN_00c809f0();
  FUN_009ca670(uVar2,&DAT_01ee40e8,s_Target_02139bd8,s_Goals_02139bd0,uVar3,uVar4,uVar5,uVar6,0,0,0)
  ;
  uStack_8 = 1;
  DAT_02139828 = RBX::Reflection::RefPropDescriptor<class_RBX::Rocket,class_RBX::PartInstance>::
                 vftable;
  _DAT_0213985c =
       RBX::Reflection::RefPropDescriptor<class_RBX::Rocket,class_RBX::PartInstance>::vftable;
  DAT_02139860 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02139860 == (undefined4 *)0x0) {
    DAT_02139860 = (undefined4 *)0x0;
  }
  else {
    *DAT_02139860 =
         RBX::Reflection::PropDescriptor<class_RBX::Rocket,class_RBX::PartInstance*>::
         GetSetImpl<class_RBX::PartInstance*_(__thiscall_RBX::Rocket::*)(void)const_,void_(__thiscall_RBX::Rocket::*)(class_RBX::PartInstance*)>
         ::vftable;
    DAT_02139860[2] = &LAB_00c85270;
    DAT_02139860[3] = 0;
    DAT_02139860[4] = FUN_00c86b10;
    DAT_02139860[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_02139828[3])();
  if (cVar1 != '\0') {
    _DAT_0213984c = _DAT_0213984c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02139828[2])();
  if (cVar1 != '\0') {
    _DAT_0213984c = _DAT_0213984c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01896ee0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1456 ; VA 0x004e76a0 ; FUN_004e76a0 */

void FUN_004e76a0(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_01eff7e8,0x15);
  FUN_00c7ffa0("cframe","Goals",FUN_00c84fc0,0,FUN_00c864f0,0,*puVar1,puVar1[1],puVar1[2],puVar1[3],
               0);
  FUN_016f3654(&LAB_01896fe0);
  return;
}



/* FUNCTION 1457 ; VA 0x004e7920 ; FUN_004e7920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e7920(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f2ca;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c80310();
  FUN_006846c0(uVar3,&DAT_019711f0,"Goals",0);
  uStack_8 = 0;
  DAT_01effc00 = RBX::Reflection::BoundProp<float,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::BodyAngularVelocity>::
              vftable;
    puVar4[1] = &DAT_01effc00;
    puVar4[2] = 0x14c;
    puVar4[4] = FUN_00c857a0;
    puVar4[5] = 0;
  }
  if (DAT_01effc34 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_01effc34;
    DAT_01effc34 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_01effc34;
  }
  DAT_01effc34 = puVar4;
  cVar2 = (*(code *)DAT_01effc00[3])();
  if (cVar2 != '\0') {
    _DAT_01effc24 = _DAT_01effc24 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_01effc00[2])();
  if (cVar2 != '\0') {
    _DAT_01effc24 = _DAT_01effc24 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1458 ; VA 0x004e7ae0 ; FUN_004e7ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e7ae0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f2ea;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c808f0();
  FUN_006846c0(uVar3,&DAT_019711f0,"Goals",0);
  uStack_8 = 0;
  DAT_01effa68 = RBX::Reflection::BoundProp<float,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::BodyVelocity>::vftable
    ;
    puVar4[1] = &DAT_01effa68;
    puVar4[2] = 0x14c;
    puVar4[4] = FUN_00c857a0;
    puVar4[5] = 0;
  }
  if (DAT_01effa9c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_01effa9c;
    DAT_01effa9c = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_01effa9c;
  }
  DAT_01effa9c = puVar4;
  cVar2 = (*(code *)DAT_01effa68[3])();
  if (cVar2 != '\0') {
    _DAT_01effa8c = _DAT_01effa8c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_01effa68[2])();
  if (cVar2 != '\0') {
    _DAT_01effa8c = _DAT_01effa8c & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1459 ; VA 0x004e8500 ; FUN_004e8500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e8500(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f30a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c809f0();
  FUN_00918e80(uVar3,s_TargetOffset_02139be0,s_Goals_02139bd0,0);
  uStack_8 = 0;
  DAT_02139864 = RBX::Reflection::BoundProp<class_G3D::Vector3,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<class_G3D::Vector3,1>::BoundPropGetSet<class_RBX::Rocket>::
              vftable;
    puVar4[1] = &DAT_02139864;
    puVar4[2] = 0x164;
    puVar4[4] = &LAB_00c85790;
    puVar4[5] = 0;
  }
  if (DAT_02139898 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02139898;
    DAT_02139898 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_02139898;
  }
  DAT_02139898 = puVar4;
  cVar2 = (*(code *)DAT_02139864[3])();
  if (cVar2 != '\0') {
    _DAT_02139888 = _DAT_02139888 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02139864[2])();
  if (cVar2 != '\0') {
    _DAT_02139888 = _DAT_02139888 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1460 ; VA 0x004e8620 ; FUN_004e8620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e8620(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f32a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c809f0();
  FUN_006846c0(uVar3,s_TargetRadius_02139bf0,s_Goals_02139bd0,0);
  uStack_8 = 0;
  DAT_0213989c = RBX::Reflection::BoundProp<float,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::Rocket>::vftable;
    puVar4[1] = &DAT_0213989c;
    puVar4[2] = 0x170;
    puVar4[4] = &LAB_00c85790;
    puVar4[5] = 0;
  }
  if (DAT_021398d0 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021398d0;
    DAT_021398d0 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_021398d0;
  }
  DAT_021398d0 = puVar4;
  cVar2 = (*(code *)DAT_0213989c[3])();
  if (cVar2 != '\0') {
    _DAT_021398c0 = _DAT_021398c0 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0213989c[2])();
  if (cVar2 != '\0') {
    _DAT_021398c0 = _DAT_021398c0 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1461 ; VA 0x004e8940 ; FUN_004e8940 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e8940(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c806f0(uVar2,0);
  FUN_009cb970(uVar1,"ReachedTarget",0,CONCAT44(uVar3,uVar2),0);
  _DAT_01effa5c = 0x18c;
  _DAT_01effa28 =
       RBX::Reflection::
       EventDesc<class_RBX::BodyPosition,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::BodyPosition::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_01effa50 = 0;
  _DAT_01effa54 = 0;
  _DAT_01effa58 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_01effa28 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::BodyPosition,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::BodyPosition::*>
       ::vftable;
  _DAT_01effa60 = 1;
  _DAT_01effa64 = 1;
  FUN_016f3654(&LAB_01897300);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1462 ; VA 0x004e8a50 ; FUN_004e8a50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e8a50(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c809f0(uVar2,0);
  FUN_009cb970(uVar1,s_ReachedTarget_02139c7c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02139bc4 = 0x1a0;
  _DAT_02139b90 =
       RBX::Reflection::
       EventDesc<class_RBX::Rocket,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Rocket::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02139bb8 = 0;
  _DAT_02139bbc = 0;
  _DAT_02139bc0 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_02139b90 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Rocket,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Rocket::*>
       ::vftable;
  _DAT_02139bc8 = 1;
  _DAT_02139bcc = 1;
  FUN_016f3654(&LAB_01897310);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1463 ; VA 0x004e8b60 ; FUN_004e8b60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e8b60(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f34a;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02139ad0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c809f0(uVar2,&DAT_02139ad0);
  FUN_009cb790(uVar1,&DAT_02139c6c,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02139b10 = RBX::Reflection::BoundFuncDesc<class_RBX::Rocket,void___cdecl(void),0>::vftable;
  _DAT_02139b48 = FUN_00c84df0;
  _DAT_02139b4c = 0;
  _DAT_02139b34 = FUN_00888530();
  FUN_016f3654(&LAB_01897320);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1464 ; VA 0x004e8c00 ; FUN_004e8c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e8c00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f36a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c806f0(uVar2,0);
  FUN_009cb790(uVar1,"GetLastForce",0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01eff9a8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::BodyPosition,class_G3D::Vector3___cdecl(void),0>::
       vftable;
  _DAT_01eff9e0 = FUN_00c85190;
  _DAT_01eff9e4 = 0;
  _DAT_01eff9cc = FUN_0088d870();
  FUN_016f3654(&LAB_01897330);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1465 ; VA 0x004e8d60 ; FUN_004e8d60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e8d60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f3aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c808f0(uVar2,0);
  FUN_009cb790(uVar1,"GetLastForce",0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01effbc0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::BodyVelocity,class_G3D::Vector3___cdecl(void),0>::
       vftable;
  _DAT_01effbf8 = FUN_00c851b0;
  _DAT_01effbfc = 0;
  _DAT_01effbe4 = FUN_0088d870();
  FUN_016f3654(&LAB_01897350);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1466 ; VA 0x004e8e00 ; FUN_004e8e00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e8e00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f3ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c808f0(uVar2,0);
  FUN_009cb790(uVar1,"lastForce",0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01effb80 =
       RBX::Reflection::BoundFuncDesc<class_RBX::BodyVelocity,class_G3D::Vector3___cdecl(void),0>::
       vftable;
  _DAT_01effbb8 = FUN_00c851b0;
  _DAT_01effbbc = 0;
  _DAT_01effba4 = FUN_0088d870();
  FUN_016f3654(&LAB_01897360);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1467 ; VA 0x004e8ef0 ; FUN_004e8ef0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e8ef0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f633;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c86e90();
  FUN_009cb970(uVar1,s_RemoteCreateSeatWeld_02137b60,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02139d40 = 0x120;
  _DAT_02139d44 = 0;
  iStack_8 = 0;
  _DAT_02139d08 =
       RBX::Reflection::
       EventDesc<class_RBX::Seat,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Seat::*>
       ::vftable;
  FUN_0086e3d0(s_humanoid_02137b54);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02139d30 = uStack_1c;
  _DAT_02139d34 = uStack_18;
  _DAT_02139d38 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_02139d08 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Seat,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Seat::*>
       ::vftable;
  _DAT_02139d48 = 0;
  _DAT_02139d4c = 0;
  FUN_016f3654(&LAB_01897620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1468 ; VA 0x004e9060 ; FUN_004e9060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e9060(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c86e90(uVar2,0);
  FUN_009cb970(uVar1,s_RemoteDestroySeatWeld_02137b78,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02139d88 = 0x128;
  DAT_02139d8c = 0;
  _DAT_02139d50 =
       RBX::Reflection::
       EventDesc<class_RBX::Seat,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Seat::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02139d78 = 0;
  _DAT_02139d7c = 0;
  _DAT_02139d80 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_02139d50 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Seat,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Seat::*>
       ::vftable;
  _DAT_02139d90 = 0;
  _DAT_02139d94 = 0;
  FUN_016f3654(&LAB_01897630);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1469 ; VA 0x004e9170 ; FUN_004e9170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e9170(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f68c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00c88c10;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c86e90();
  FUN_009cb790(uVar2,&DAT_02123cd0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02139dd0 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_02139d98 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Seat,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>::
       vftable;
  _DAT_02139dd8 = 0;
  DAT_02139ddc = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02139dbc = FUN_00888530();
  puVar4 = DAT_02139ddc;
  if (DAT_02139ddc == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088cdc0();
    iStack_f8 = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_f4 = *puVar4;
    uStack_f0 = puVar4[1];
    iStack_f8 = FUN_006309e0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_humanoid_02137b54);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_01897640);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1470 ; VA 0x004e9350 ; FUN_004e9350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e9350(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f6bc;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c86e90();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xc484b0;
    *(undefined8 *)(puVar3 + 6) = 0xc64295;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Seat,bool>::
              GetSetImpl<bool_const&_(__thiscall_RBX::SeatImpl<class_RBX::BasicPartInstance>::*)(void)const_,void_(__thiscall_RBX::Seat::*)(bool_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_Disabled_02137ac8,s_Control_0211ffd0,uStack_3c,0,0,0x1f,0,0,0);
  DAT_02139c90 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02139cc4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02139cb4 = _DAT_02139cb4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02139c90[2])();
    if (cVar1 != '\0') {
      _DAT_02139cb4 = _DAT_02139cb4 & 0xfffffff3;
    }
  }
  DAT_02139c90 = RBX::Reflection::PropDescriptor<class_RBX::Seat,bool>::vftable;
  FUN_016f3654(&LAB_01897690);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1471 ; VA 0x004e94a0 ; FUN_004e94a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e94a0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffd0;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f6f0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffd0 & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x13;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efe1c4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efe1c4,uVar3,0,0,0x13);
    if (DAT_01efe1c4 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01efe1a0 = RBX::Reflection::RefType<class_RBX::Humanoid*>::vftable;
      FUN_016f3654(&LAB_01895c90);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efe1c4);
    }
  }
  uVar2 = FUN_00c86e90();
  FUN_009ca670(uVar2,&DAT_01efe1a0,s_Occupant_02137ad4,s_Control_0211ffd0,uVar3,uVar4,uVar5,uVar6,0,
               0,0);
  uStack_8 = 1;
  DAT_02139cc8 = RBX::Reflection::RefPropDescriptor<class_RBX::Seat,class_RBX::Humanoid>::vftable;
  _DAT_02139cfc = RBX::Reflection::RefPropDescriptor<class_RBX::Seat,class_RBX::Humanoid>::vftable;
  DAT_02139d00 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02139d00 == (undefined4 *)0x0) {
    DAT_02139d00 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_02139d00 + 2) = 0xc65980;
    *DAT_02139d00 =
         RBX::Reflection::PropDescriptor<class_RBX::Seat,class_RBX::Humanoid*>::
         GetImpl<class_RBX::Humanoid*_(__thiscall_RBX::SeatImpl<class_RBX::BasicPartInstance>::*)(void)const_>
         ::vftable;
    DAT_02139d00[4] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_02139cc8[3])();
  if (cVar1 != '\0') {
    _DAT_02139cec = _DAT_02139cec & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02139cc8[2])();
  if (cVar1 != '\0') {
    _DAT_02139cec = _DAT_02139cec & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018976b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1472 ; VA 0x004e9670 ; FUN_004e9670 */

void FUN_004e9670(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00c89300(0x254,0,s_equipped_0213a1b8,s_humanoid_02137b54,s_skateboardController_0213a1a0,0,
               CONCAT44(&DAT_02139f08,uStack_10),0);
  FUN_016f3654(&LAB_01897730);
  return;
}



/* FUNCTION 1473 ; VA 0x004e96d0 ; FUN_004e96d0 */

void FUN_004e96d0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00c89460(600,0,s_unequipped_0213a1c4,s_humanoid_02137b54,0,CONCAT44(&DAT_02139f88,uStack_10),0
              );
  FUN_016f3654(&LAB_01897740);
  return;
}



/* FUNCTION 1474 ; VA 0x004e9730 ; FUN_004e9730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e9730(void)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined8 uStack_f4;
  undefined4 uStack_ec;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f9ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00c8a210;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c88fe0();
  FUN_009cb790(uVar2,s_ApplySpecificImpulse_0213a200,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213a0b8 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_0213a080 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SkateboardPlatform,void___cdecl(class_G3D::Vector3),1>::vftable;
  _DAT_0213a0c0 = 0;
  DAT_0213a0c4 = (undefined8 *)0x0;
  uStack_8 = 1;
  _DAT_0213a0a4 = FUN_00888530();
  puVar1 = DAT_0213a0c4;
  if (DAT_0213a0c4 == (undefined8 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088d870();
    puStack_f8 = (undefined *)0x0;
    uStack_f4 = *puVar1;
    uStack_ec = *(undefined4 *)(puVar1 + 1);
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead408) {
      FUN_016f3809(&DAT_01ead408);
      if (DAT_01ead408 == -1) {
        _DAT_01ead3fc = FUN_005c6600;
        _DAT_01ead400 = FUN_005c6600;
        DAT_01ead404 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead408);
      }
    }
    puStack_f8 = &DAT_01ead3fc;
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(s_impulseWorld_0213a1f0);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_f8 != (undefined *)0x0) {
      (**(code **)(puStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_01897750);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1475 ; VA 0x004e9960 ; FUN_004e9960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e9960(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180f9ee;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c88fe0();
  FUN_009cb970(uVar1,s_MoveStateChanged_0213a18c,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02139f00 = 0x250;
  _DAT_02139f04 = 0;
  iStack_8 = 0;
  _DAT_02139ec8 =
       RBX::Reflection::
       EventDesc<class_RBX::SkateboardPlatform,void___cdecl(enum_RBX::SkateboardPlatform::MoveState,enum_RBX::SkateboardPlatform::MoveState),class_rbx::signal<void___cdecl(enum_RBX::SkateboardPlatform::MoveState,enum_RBX::SkateboardPlatform::MoveState)>,class_rbx::signal<void___cdecl(enum_RBX::SkateboardPlatform::MoveState,enum_RBX::SkateboardPlatform::MoveState)>_RBX::SkateboardPlatform::*>
       ::vftable;
  FUN_0086e3d0(s_newState_0213a180);
  FUN_00c8d570();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_oldState_0213a174);
  FUN_00c8d570();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02139ef0 = uStack_1c;
  _DAT_02139ef4 = uStack_18;
  _DAT_02139ef8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02139ec8 =
       RBX::Reflection::
       EventDesc<class_RBX::SkateboardPlatform,void___cdecl(enum_RBX::SkateboardPlatform::MoveState,enum_RBX::SkateboardPlatform::MoveState),class_rbx::signal<void___cdecl(enum_RBX::SkateboardPlatform::MoveState,enum_RBX::SkateboardPlatform::MoveState)>,class_rbx::signal<void___cdecl(enum_RBX::SkateboardPlatform::MoveState,enum_RBX::SkateboardPlatform::MoveState)>_RBX::SkateboardPlatform::*>
       ::vftable;
  FUN_016f3654(&LAB_01897770);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1476 ; VA 0x004e9ae0 ; FUN_004e9ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e9ae0(void)

{
  undefined4 extraout_var;
  
  FUN_00c89300(0x254,0,s_Equipped_02136290,s_humanoid_02137b54,s_skateboardController_0213a1a0,0,0,0
               ,0);
  _DAT_02139f08 =
       RBX::Reflection::
       EventDesc<class_RBX::SkateboardPlatform,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::SkateboardPlatform::*>
       ::vftable;
  FUN_016f3654(&LAB_01897780,extraout_var);
  return;
}



/* FUNCTION 1477 ; VA 0x004e9b40 ; FUN_004e9b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e9b40(void)

{
  undefined4 extraout_var;
  
  FUN_00c89460(600,0,s_Unequipped_0213629c,s_humanoid_02137b54,0,0,0,0);
  _DAT_02139f88 =
       RBX::Reflection::
       EventDesc<class_RBX::SkateboardPlatform,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::SkateboardPlatform::*>
       ::vftable;
  FUN_016f3654(&LAB_01897790,extraout_var);
  return;
}



/* FUNCTION 1478 ; VA 0x004e9ba0 ; FUN_004e9ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e9ba0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fa23;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c88fe0();
  FUN_009cb970(uVar1,s_RemoteCreateMotor6D_0213a218,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0213a100 = 0x25c;
  _DAT_0213a104 = 0;
  iStack_8 = 0;
  _DAT_0213a0c8 =
       RBX::Reflection::
       EventDesc<class_RBX::SkateboardPlatform,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::SkateboardPlatform::*>
       ::vftable;
  FUN_0086e3d0(s_humanoid_02137b54);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0213a0f0 = uStack_1c;
  _DAT_0213a0f4 = uStack_18;
  _DAT_0213a0f8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_0213a0c8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::SkateboardPlatform,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::SkateboardPlatform::*>
       ::vftable;
  _DAT_0213a108 = 0;
  _DAT_0213a10c = 0;
  FUN_016f3654(&LAB_018977a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1479 ; VA 0x004e9d10 ; FUN_004e9d10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e9d10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c88fe0(uVar2,0);
  FUN_009cb970(uVar1,s_RemoteDestroyMotor6D_0213a22c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213a148 = 0x264;
  DAT_0213a14c = 0;
  _DAT_0213a110 =
       RBX::Reflection::
       EventDesc<class_RBX::SkateboardPlatform,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::SkateboardPlatform::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_0213a138 = 0;
  _DAT_0213a13c = 0;
  _DAT_0213a140 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_0213a110 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::SkateboardPlatform,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::SkateboardPlatform::*>
       ::vftable;
  _DAT_0213a150 = 0;
  _DAT_0213a154 = 0;
  FUN_016f3654(&LAB_018977b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1480 ; VA 0x004e9e20 ; FUN_004e9e20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004e9e20(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fa44;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c8d570();
  uVar3 = FUN_00c88fe0();
  FUN_009ca670(uVar3,uVar2,s_MoveState_0213a168,s_Control_0211ffd0,uStack_3c,0,0,2,0,0,1);
  uStack_8 = 0;
  DAT_02139e88 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::SkateboardPlatform,enum_RBX::SkateboardPlatform::MoveState>
                 ::vftable;
  _DAT_02139ebc = uVar2;
  DAT_02139ec0 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_02139ec0 == (undefined4 *)0x0) {
    DAT_02139ec0 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_02139ec0 + 2) = 0xc8c010;
    *(undefined8 *)(DAT_02139ec0 + 6) = 0xc8d360;
    *DAT_02139ec0 =
         RBX::Reflection::
         PropDescriptor<class_RBX::SkateboardPlatform,enum_RBX::SkateboardPlatform::MoveState>::
         GetSetImpl<enum_RBX::SkateboardPlatform::MoveState_(__thiscall_RBX::SkateboardPlatform::*)(void)const_,void_(__thiscall_RBX::SkateboardPlatform::*)(enum_RBX::SkateboardPlatform::MoveState_const&)>
         ::vftable;
    DAT_02139ec0[4] = 0;
    DAT_02139ec0[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02139ec4 = FUN_00c8d570();
  cVar1 = (*(code *)DAT_02139e88[3])();
  if (cVar1 != '\0') {
    _DAT_02139eac = _DAT_02139eac & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02139e88[2])();
  if (cVar1 != '\0') {
    _DAT_02139eac = _DAT_02139eac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018977e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1481 ; VA 0x004ea0c0 ; FUN_004ea0c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ea0c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fa6c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c88fe0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x9b7390;
    *(undefined8 *)(puVar3 + 6) = 0xc8d4a0;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::SkateboardPlatform,bool>::
              GetSetImpl<bool_(__thiscall_RBX::SkateboardPlatform::*)(void)const_,void_(__thiscall_RBX::SkateboardPlatform::*)(bool)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_StickyWheels_0213a158,s_Control_0211ffd0,uStack_3c,0,0,0x1f,0,0,0);
  DAT_02139e50 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02139e84 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02139e74 = _DAT_02139e74 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02139e50[2])();
    if (cVar1 != '\0') {
      _DAT_02139e74 = _DAT_02139e74 & 0xfffffff3;
    }
  }
  DAT_02139e50 = RBX::Reflection::PropDescriptor<class_RBX::SkateboardPlatform,bool>::vftable;
  FUN_016f3654(&LAB_01897840);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1482 ; VA 0x004ea210 ; FUN_004ea210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ea210(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffd0;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180faa0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffd0 & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f01444) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f01444,uVar3,0,0,0x15);
    if (DAT_01f01444 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01f01420 = RBX::Reflection::RefType<class_RBX::SkateboardController*>::vftable;
      FUN_016f3654(&LAB_01897900);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01f01444);
    }
  }
  uVar2 = FUN_00c88fe0();
  FUN_009ca670(uVar2,&DAT_01f01420,s_Controller_0213a1d0,s_Control_0211ffd0,uVar3,uVar4,uVar5,uVar6,
               0,0,0);
  uStack_8 = 1;
  DAT_0213a008 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::SkateboardPlatform,class_RBX::SkateboardController>::
                 vftable;
  _DAT_0213a03c =
       RBX::Reflection::
       RefPropDescriptor<class_RBX::SkateboardPlatform,class_RBX::SkateboardController>::vftable;
  DAT_0213a040 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213a040 == (undefined4 *)0x0) {
    DAT_0213a040 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_0213a040 + 2) = 0xc8bf70;
    *DAT_0213a040 =
         RBX::Reflection::
         PropDescriptor<class_RBX::SkateboardPlatform,class_RBX::SkateboardController*>::
         GetImpl<class_RBX::SkateboardController*_(__thiscall_RBX::SkateboardPlatform::*)(void)const_>
         ::vftable;
    DAT_0213a040[4] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0213a008[3])();
  if (cVar1 != '\0') {
    _DAT_0213a02c = _DAT_0213a02c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213a008[2])();
  if (cVar1 != '\0') {
    _DAT_0213a02c = _DAT_0213a02c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01897860);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1483 ; VA 0x004ea3b0 ; FUN_004ea3b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ea3b0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffd0;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fad0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffd0 & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efe1c4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efe1c4,uVar3,0,0,0x15);
    if (DAT_01efe1c4 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01efe1a0 = RBX::Reflection::RefType<class_RBX::Humanoid*>::vftable;
      FUN_016f3654(&LAB_01895c90);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efe1c4);
    }
  }
  uVar2 = FUN_00c88fe0();
  FUN_009ca670(uVar2,&DAT_01efe1a0,s_ControllingHumanoid_0213a1dc,s_Control_0211ffd0,uVar3,uVar4,
               uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_0213a044 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::SkateboardPlatform,class_RBX::Humanoid>::vftable;
  _DAT_0213a078 =
       RBX::Reflection::RefPropDescriptor<class_RBX::SkateboardPlatform,class_RBX::Humanoid>::
       vftable;
  DAT_0213a07c = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0213a07c == (undefined4 *)0x0) {
    DAT_0213a07c = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_0213a07c + 2) = 0xc8bf80;
    *DAT_0213a07c =
         RBX::Reflection::PropDescriptor<class_RBX::SkateboardPlatform,class_RBX::Humanoid*>::
         GetImpl<class_RBX::Humanoid*_(__thiscall_RBX::SkateboardPlatform::*)(void)const_>::vftable;
    DAT_0213a07c[4] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0213a044[3])();
  if (cVar1 != '\0') {
    _DAT_0213a068 = _DAT_0213a068 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0213a044[2])();
  if (cVar1 != '\0') {
    _DAT_0213a068 = _DAT_0213a068 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01897880);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1484 ; VA 0x004ea560 ; FUN_004ea560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ea560(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180fc43;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c8d8e0();
  FUN_009cb970(uVar1,s_RemoteCreateMotor6D_0213a218,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0213a280 = 0x110;
  _DAT_0213a284 = 0;
  iStack_8 = 0;
  _DAT_0213a248 =
       RBX::Reflection::
       EventDesc<class_RBX::Platform,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Platform::*>
       ::vftable;
  FUN_0086e3d0(s_humanoid_02137b54);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0213a270 = uStack_1c;
  _DAT_0213a274 = uStack_18;
  _DAT_0213a278 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_0213a248 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Platform,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Platform::*>
       ::vftable;
  _DAT_0213a288 = 0;
  _DAT_0213a28c = 0;
  FUN_016f3654(&LAB_01897910);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1485 ; VA 0x004ea6d0 ; FUN_004ea6d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ea6d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c8d8e0(uVar2,0);
  FUN_009cb970(uVar1,s_RemoteDestroyMotor6D_0213a22c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213a2c8 = 0x118;
  _DAT_0213a2cc = 0;
  _DAT_0213a290 =
       RBX::Reflection::
       EventDesc<class_RBX::Platform,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Platform::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_0213a2b8 = 0;
  _DAT_0213a2bc = 0;
  _DAT_0213a2c0 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_0213a290 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Platform,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Platform::*>
       ::vftable;
  _DAT_0213a2d0 = 0;
  _DAT_0213a2d4 = 0;
  FUN_016f3654(&LAB_01897920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1486 ; VA 0x004ea8f0 ; FUN_004ea8f0 */

void FUN_004ea8f0(void)

{
  FUN_00c8dad0(s_AttachmentForward_0213a4d8,s_Appearance_02119800,0xffffff9000c8fed0,0,
               0xffffff9000c90e70,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_01897960);
  return;
}



/* FUNCTION 1487 ; VA 0x004ea980 ; FUN_004ea980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ea980(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ff8c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c8dce0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xffffff9000763950;
    *(undefined8 *)(puVar3 + 6) = 0xffffff9000c91040;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Accoutrement,class_G3D::CoordinateFrame>::
              GetSetImpl<class_G3D::CoordinateFrame_const&_(__thiscall_RBX::Accoutrement::*)(void)const_,void_(__thiscall_RBX::Accoutrement::*)(class_G3D::CoordinateFrame_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,s_AttachmentPoint_0213a4b8,s_Appearance_02119800,uStack_3c,0,0,0x1f,0,0,0
              );
  DAT_0213a2d8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213a30c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213a2fc = _DAT_0213a2fc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213a2d8[2])();
    if (cVar1 != '\0') {
      _DAT_0213a2fc = _DAT_0213a2fc & 0xfffffff3;
    }
  }
  DAT_0213a2d8 = RBX::Reflection::PropDescriptor<class_RBX::Accoutrement,class_G3D::CoordinateFrame>
                 ::vftable;
  FUN_016f3654(&LAB_01897980);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1488 ; VA 0x004eaad0 ; FUN_004eaad0 */

void FUN_004eaad0(void)

{
  FUN_00c8dad0(s_AttachmentPos_0213a4c8,s_Appearance_02119800,0xffffff9000c22d40,0,
               0xffffff9000c910c0,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_018979a0);
  return;
}



/* FUNCTION 1489 ; VA 0x004eab60 ; FUN_004eab60 */

void FUN_004eab60(void)

{
  FUN_00c8dad0(s_AttachmentRight_0213a4fc,s_Appearance_02119800,0xffffff9000c8ff20,0,
               0xffffff9000c91170,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_018979c0);
  return;
}



/* FUNCTION 1490 ; VA 0x004eabf0 ; FUN_004eabf0 */

void FUN_004eabf0(void)

{
  FUN_00c8dad0(s_AttachmentUp_0213a4ec,s_Appearance_02119800,0xffffff9000c8ff40,0,0xffffff9000c91320
               ,0,0,0,0,0x15,0);
  FUN_016f3654(&LAB_018979e0);
  return;
}



/* FUNCTION 1491 ; VA 0x004eac80 ; FUN_004eac80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eac80(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ffbc;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c8dce0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xffffff9000c11840;
    *(undefined8 *)(puVar3 + 6) = 0xffffff9000c914d0;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Accoutrement,int>::
              GetSetImpl<int_(__thiscall_RBX::Accoutrement::*)(void)const_,void_(__thiscall_RBX::Accoutrement::*)(int)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_BackendAccoutrementState_0213a50c,s_Appearance_02119800,uStack_3c,0,0,2
               ,0,0,0);
  DAT_0213a3f0 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0213a424 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213a414 = _DAT_0213a414 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0213a3f0[2])();
    if (cVar1 != '\0') {
      _DAT_0213a414 = _DAT_0213a414 & 0xfffffff3;
    }
  }
  DAT_0213a3f0 = RBX::Reflection::PropDescriptor<class_RBX::Accoutrement,int>::vftable;
  FUN_016f3654(&LAB_01897a00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1492 ; VA 0x004eae30 ; FUN_004eae30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eae30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810422;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c9aa70(uVar2,0);
  FUN_009cb790(uVar1,s_LocalIkSolve_0213aa60,3,CONCAT44(uVar3,uVar2),0);
  _DAT_0213a8d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PhysicsService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::CoordinateFrame_const&,float,float),4>
       ::vftable;
  _DAT_0213a908 = FUN_00c9d8d0;
  _DAT_0213a90c = 0;
  _DAT_0213a910 = 0;
  _DAT_0213a914 = 0;
  _DAT_0213a918 = 0;
  _DAT_0213a91c = 0;
  uStack_8 = 4;
  FUN_00c9b9e0(&DAT_02123e0c,s_target_02127abc,s_translateStiffness_02127aa8,
               s_rotateStiffness_02127a98);
  FUN_016f3654(&LAB_01897bb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1493 ; VA 0x004eaf10 ; FUN_004eaf10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eaf10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810462;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c9aa70(uVar2,0);
  FUN_009cb790(uVar1,s_IkSolve_0213aa58,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0213a880 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PhysicsService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::CoordinateFrame_const&,float,float),4>
       ::vftable;
  _DAT_0213a8b8 = FUN_00c9d8d0;
  _DAT_0213a8bc = 0;
  _DAT_0213a8c0 = 0;
  _DAT_0213a8c4 = 0;
  _DAT_0213a8c8 = 0;
  _DAT_0213a8cc = 0;
  uStack_8 = 4;
  FUN_00c9b9e0(&DAT_02123e0c,s_target_02127abc,s_translateStiffness_02127aa8,
               s_rotateStiffness_02127a98);
  FUN_016f3654(&LAB_01897bc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1494 ; VA 0x004eaff0 ; FUN_004eaff0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eaff0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181048e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c9aa70(uVar2,0);
  FUN_009cb790(uVar1,s_CollisionGroupContainsPart_0213a98c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213a690 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PhysicsService,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_0213a6c8 = FUN_00c9b1e0;
  _DAT_0213a6cc = 0;
  _DAT_0213a6d0 = 0;
  DAT_0213a6d4 = 0;
  uStack_8 = 2;
  FUN_00c9c240();
  FUN_016f3654(&LAB_01897bd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1495 ; VA 0x004eb0b0 ; FUN_004eb0b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eb0b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018104c8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c9aa70(uVar2,0);
  FUN_009cb790(uVar1,s_CollisionGroupSetCollidable_0213a9c4,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213a6d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PhysicsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),3>
       ::vftable;
  _DAT_0213a710 = FUN_00c9b340;
  _DAT_0213a714 = 0;
  _DAT_0213a718 = 0;
  _DAT_0213a71c = 0;
  DAT_0213a720 = 0;
  uStack_8 = 3;
  FUN_00c9b660(s_name1_0213a9bc,s_name2_0213a9b4,s_collidable_0213a9a8);
  FUN_016f3654(&LAB_01897c30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1496 ; VA 0x004eb180 ; FUN_004eb180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eb180(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018104fe;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c9aa70(uVar2,0);
  FUN_009cb790(uVar1,s_CollisionGroupsAreCollidable_0213a9e0,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0213a728 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PhysicsService,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0213a760 = FUN_00c9b450;
  _DAT_0213a764 = 0;
  _DAT_0213a768 = 0;
  _DAT_0213a76c = 0;
  uStack_8 = 2;
  FUN_00c9c010();
  FUN_016f3654(&LAB_01897c70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1497 ; VA 0x004eb240 ; FUN_004eb240 */

void FUN_004eb240(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00c9abf0(FUN_00c9b530,0,s_CreateCollisionGroup_0213a920,&DAT_0211a93c,0,uStack_10,0);
  FUN_016f3654(&LAB_01897c90);
  return;
}



/* FUNCTION 1498 ; VA 0x004eb2a0 ; FUN_004eb2a0 */

void FUN_004eb2a0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00c9abf0(FUN_00c9ccc0,0,s_GetCollisionGroupId_0213aa00,&DAT_0211a93c,0,uStack_10,0);
  FUN_016f3654(&LAB_01897cb0);
  return;
}



/* FUNCTION 1499 ; VA 0x004eb300 ; FUN_004eb300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eb300(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181055c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c9aa70();
  FUN_009cb790(uVar1,s_GetCollisionGroupName_0213aa14,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0213a7b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PhysicsService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(int),1>
       ::vftable;
  _DAT_0213a7f0 = FUN_00c9cda0;
  _DAT_0213a7f4 = 0;
  DAT_0213a7f8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213a7dc = FUN_0088cb40();
  puVar3 = DAT_0213a7f8;
  if (DAT_0213a7f8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c8c0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005c9cc0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01897cd0);
  ExceptionList = pvStack_10;
  return;
}


