/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 21000 ; VA 0x00a62220 ; FUN_00a62220 */

int * __thiscall FUN_00a62220(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  uint *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1a26;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x81) != '\0') {
    piVar1 = *(int **)(param_1 + 0x78);
    if ((piVar1 != *(int **)(param_1 + 0x6c)) && (piVar1 != (int *)**(int **)(param_1 + 0x6c))) {
      iVar2 = piVar1[2];
      puVar4 = (uint *)(iVar2 + 0x28);
      ExceptionList = &pvStack_10;
      if (auStack_38 != puVar4) {
        if (0xf < *(uint *)(iVar2 + 0x3c)) {
          puVar4 = (uint *)*puVar4;
        }
        ExceptionList = &pvStack_10;
        FUN_005542c0(puVar4,*(undefined4 *)(iVar2 + 0x38));
      }
      puVar5 = (undefined4 *)FUN_01674e20(0x18);
      uStack_8._0_1_ = 1;
      puStack_18 = puVar5;
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        puVar5[1] = 1;
        puVar5[2] = 1;
        *puVar5 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
        FUN_00569550(2,&uStack_11);
      }
      piVar1 = puVar5 + 3;
      puVar3 = (undefined4 *)*piVar1;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      piStack_20 = piVar1;
      puStack_1c = puVar5;
      uVar6 = FUN_0088daf0();
      *puVar3 = uVar6;
      puStack_18 = (undefined4 *)FUN_005c9ef0();
      iVar2 = puVar3[1];
      if ((undefined4 *)iVar2 == puStack_18) {
        *(undefined *)(puVar3 + 2) = 1;
      }
      else {
        if (iVar2 != 0) {
          (**(code **)(iVar2 + 8))(puVar3 + 2);
          puVar3[1] = 0;
        }
        *(undefined *)(puVar3 + 2) = 1;
        puVar3[1] = puStack_18;
      }
      FUN_005c16d0(auStack_38);
      *param_2 = (int)piVar1;
      param_2[1] = (int)puVar5;
      if (0xf < uStack_24) {
        uVar8 = uStack_24 + 1;
        uVar7 = auStack_38[0];
        if (0xfff < uVar8) {
          uVar7 = *(uint *)(auStack_38[0] - 4);
          uVar8 = uStack_24 + 0x24;
          if (0x1f < (auStack_38[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar8);
      }
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 3;
  puStack_18 = puVar5;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    puVar5[1] = 1;
    puVar5[2] = 1;
    *puVar5 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    FUN_00569550(1,&uStack_11);
  }
  piVar1 = puVar5 + 3;
  puVar3 = (undefined4 *)*piVar1;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  piStack_20 = piVar1;
  puStack_1c = puVar5;
  uVar6 = FUN_0088daf0();
  *puVar3 = uVar6;
  puStack_18 = (undefined4 *)FUN_005c9ef0();
  iVar2 = puVar3[1];
  if ((undefined4 *)iVar2 == puStack_18) {
    *(undefined *)(puVar3 + 2) = 0;
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(puVar3 + 2);
      puVar3[1] = 0;
    }
    *(undefined *)(puVar3 + 2) = 0;
    puVar3[1] = puStack_18;
  }
  param_2[1] = (int)puVar5;
  *param_2 = (int)piVar1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21001 ; VA 0x00a62440 ; FUN_00a62440 */

void __fastcall FUN_00a62440(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  
  if (*(int *)(param_1 + 0x68) != 0) {
    FUN_00a60f10(1);
    iVar4 = FUN_01674e20(0x40);
    if (iVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_00a5fcf0(param_1);
    }
    *(undefined4 *)(param_1 + 0x68) = uVar5;
  }
  puVar1 = *(undefined4 **)(param_1 + 0x6c);
  for (puVar2 = (undefined4 *)*puVar1; puVar2 != puVar1; puVar2 = (undefined4 *)*puVar2) {
    FUN_00a5f110(puVar2[2]);
  }
  piVar6 = *(int **)(param_1 + 0x6c);
  piVar7 = (int *)*piVar6;
  *piVar6 = (int)piVar6;
  *(int *)(*(int *)(param_1 + 0x6c) + 4) = *(int *)(param_1 + 0x6c);
  *(undefined4 *)(param_1 + 0x70) = 0;
  piVar6 = *(int **)(param_1 + 0x6c);
  if (piVar7 != piVar6) {
    do {
      piVar3 = (int *)*piVar7;
      FUN_01674ea0(piVar7,0xc);
      piVar6 = *(int **)(param_1 + 0x6c);
      piVar7 = piVar3;
    } while (piVar3 != piVar6);
  }
  *(int **)(param_1 + 0x74) = piVar6;
  *(undefined4 *)(param_1 + 0x78) = **(undefined4 **)(param_1 + 0x6c);
  *(undefined4 *)(param_1 + 0x84) = 0;
  FUN_006eccd0();
  return;
}



/* FUNCTION 21002 ; VA 0x00a624ed ; FUN_00a624ed */

void FUN_00a624ed(void)

{
  FUN_00a62500();
  return;
}



/* FUNCTION 21003 ; VA 0x00a62500 ; FUN_00a62500 */

int __fastcall FUN_00a62500(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1a6b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_01944058;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::bad_optional_access::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 21004 ; VA 0x00a62620 ; FUN_00a62620 */

void __fastcall FUN_00a62620(int param_1)

{
  int *piVar1;
  int *piVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1aa0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x84) = 0;
  piVar9 = (int *)**(int **)(param_1 + 0x6c);
  if (piVar9 != *(int **)(param_1 + 0x6c)) {
    do {
      iVar4 = piVar9[2];
      iVar7 = 0;
      if (*(int *)(iVar4 + 8) == 0) {
        puVar8 = (undefined4 *)0x0;
      }
      else {
        puVar8 = *(undefined4 **)(*(int *)(iVar4 + 0x14) + *(int *)(iVar4 + 4) * 4);
      }
      for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
        if (*(char *)(puVar8 + 0x12) == '\0') {
          puVar8[0x13] = 0;
          *(undefined *)(puVar8 + 0x12) = 1;
          piVar1 = (int *)puVar8[9];
          piVar2 = (int *)*piVar1;
          while (piVar2 != piVar1) {
            iVar4 = (**(code **)(*(int *)piVar2[4] + 0x28))(puVar8[4]);
            if (*(char *)(puVar8 + 0x12) == '\0') goto LAB_00a6275a;
            puVar8[0x13] = puVar8[0x13] + iVar4;
            FUN_00551320();
            piVar1 = (int *)puVar8[9];
          }
        }
        if (*(char *)(puVar8 + 0x14) == '\0') {
          puVar8[0x15] = 0;
          *(undefined *)(puVar8 + 0x14) = 1;
          if (puVar8[0xd] == 0) {
            puVar5 = (undefined4 *)0x0;
          }
          else {
            puVar5 = *(undefined4 **)(puVar8[0x10] + puVar8[0xc] * 4);
          }
          for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
            if (*(char *)(puVar8 + 0x14) == '\0') goto LAB_00a6276f;
            puVar8[0x15] = puVar8[0x15] + puVar5[9];
          }
        }
        if (*(char *)(puVar8 + 0x12) == '\0') {
          uVar6 = FUN_00a5fdc0();
          uStack_8 = 2;
          FUN_00a5f7a0(uVar6);
LAB_00a6275a:
          uVar6 = FUN_00a5fdc0();
          uStack_8 = 0;
          FUN_00a5f7a0(uVar6);
LAB_00a6276f:
          uVar6 = FUN_00a5fdc0();
          uStack_8 = 1;
          FUN_00a5f7a0(uVar6);
LAB_00a62784:
          uVar6 = FUN_00a5fdc0();
          uStack_8 = 3;
          FUN_00a5f7a0(uVar6);
          pcVar3 = (code *)swi(3);
          (*pcVar3)();
          return;
        }
        if (*(char *)(puVar8 + 0x14) == '\0') goto LAB_00a62784;
        iVar7 = iVar7 + puVar8[0x13] + puVar8[0x15];
      }
      *(int *)(param_1 + 0x84) = *(int *)(param_1 + 0x84) + iVar7;
      piVar9 = (int *)*piVar9;
    } while (piVar9 != (int *)*(int *)(param_1 + 0x6c));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21005 ; VA 0x00a627a0 ; FUN_00a627a0 */

void __fastcall FUN_00a627a0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x2c);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    puVar1[10] = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00a5f130(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 21006 ; VA 0x00a62800 ; FUN_00a62800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00a62800(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00a65740();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ee7dbc) {
      FUN_016f3809(&DAT_01ee7dbc);
      if (DAT_01ee7dbc == -1) {
        _DAT_01ee7db0 = FUN_005c65e0;
        _DAT_01ee7db4 = FUN_005c65e0;
        _DAT_01ee7db8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ee7dbc);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01ee7db0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01ee7db0;
  }
  return;
}



/* FUNCTION 21007 ; VA 0x00a628c0 ; FUN_00a628c0 */

void FUN_00a628c0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a65740();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21008 ; VA 0x00a62900 ; FUN_00a62900 */

undefined4 * FUN_00a62900(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_005f49c0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 21009 ; VA 0x00a62970 ; FUN_00a62970 */

undefined4 * FUN_00a62970(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined *puVar5;
  code *pcStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1ac9;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a5efa0(param_1);
  uStack_18 = *param_1;
  uStack_8 = 0;
  uStack_14 = 1;
  pcStack_30 = FUN_00a63240;
  uStack_2c = 0;
  uStack_28 = param_2;
  cVar4 = FUN_00585a40(&pcStack_30);
  if (cVar4 == '\0') {
    puVar5 = &DAT_01944075;
  }
  else {
    puVar5 = (undefined *)0x0;
  }
  FUN_008ac5b0(auStack_20,"Data Size",puVar5);
  piVar3 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_18 = *param_1;
  pcStack_30 = FUN_0074a340;
  uStack_2c = 0;
  uStack_28 = param_2;
  cVar4 = FUN_00585a40(&pcStack_30);
  if (cVar4 == '\0') {
    puVar5 = &DAT_01944075;
  }
  else {
    puVar5 = (undefined *)0x0;
  }
  FUN_008ac5b0(auStack_20,"Stack Size",puVar5);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21010 ; VA 0x00a62ae0 ; FUN_00a62ae0 */

void __fastcall FUN_00a62ae0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[10];
        if (0xf < uVar6) {
          iVar2 = puVar7[5];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a62b9d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[9] = 0;
        puVar7[10] = 0xf;
        *(undefined *)(puVar7 + 5) = 0;
        FUN_01674ea0(puVar7,0x2c);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00a62b9d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 21011 ; VA 0x00a62bb0 ; FUN_00a62bb0 */

int __thiscall FUN_00a62bb0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_00a60220();
    FUN_01674ea0(puVar1,0x58);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 21012 ; VA 0x00a62c00 ; FUN_00a62c00 */

int __fastcall FUN_00a62c00(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  if (DAT_01d66188 == '\0') {
    FUN_00a62440();
  }
  if (*(int *)(param_1 + 0x68) != 0) {
    FUN_00a60f10(1);
    *(undefined4 *)(param_1 + 0x68) = 0;
  }
  FUN_01679490();
  FUN_01679490();
  iVar4 = FUN_01679490();
  if (*(int *)(param_1 + 0x60) != 0) {
    iVar4 = FUN_00a6f530(param_1 + 0x58);
    *(undefined4 *)(param_1 + 0x60) = 0;
    piVar3 = *(int **)(param_1 + 100);
    *(undefined4 *)(param_1 + 100) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a62c93. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          iVar4 = (**(code **)(*piVar3 + 4))();
          return iVar4;
        }
      }
    }
  }
  return iVar4;
}



/* FUNCTION 21013 ; VA 0x00a62ca0 ; FUN_00a62ca0 */

int FUN_00a62ca0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00a60ca0(uVar3,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21014 ; VA 0x00a62d30 ; FUN_00a62d30 */

int FUN_00a62d30(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  pcVar3 = *(code **)(param_1 + 0x18);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_2,param_3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21015 ; VA 0x00a62e00 ; FUN_00a62e00 */

undefined4 __thiscall FUN_00a62e00(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1ae8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(param_1 + 0x38))(auStack_18);
  uStack_8 = 0;
  uVar2 = FUN_009d5730(param_3,uVar2);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar1 = piStack_14[2] + -1;
      piStack_14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 21016 ; VA 0x00a62e80 ; FUN_00a62e80 */

byte * __thiscall FUN_00a62e80(byte *param_1,uint param_2)

{
  byte *pbStack_8;
  
  pbStack_8 = param_1;
  FUN_00606ea0(&pbStack_8,(param_2 >> 3) + param_2,&param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (pbStack_8 == (byte *)0x0) {
    return pbStack_8;
  }
  return pbStack_8 + 0xc;
}



/* FUNCTION 21017 ; VA 0x00a62ed0 ; FUN_00a62ed0 */

int __thiscall FUN_00a62ed0(byte *param_1,uint *param_2)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  undefined **ppuVar4;
  undefined **ppuVar5;
  int *piVar6;
  undefined4 uStack_68;
  uint uStack_64;
  int *piStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined *puStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined uStack_2c;
  undefined uStack_24;
  uint uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1b20;
  pvStack_10 = ExceptionList;
  param_2 = (uint *)*param_2;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&iStack_14,((uint)param_2 >> 3) + (int)param_2,&param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_14 != 0) {
    ExceptionList = pvStack_10;
    return iStack_14 + 0xc;
  }
  param_2 = (uint *)*puVar3;
  iStack_14 = FUN_00a60a40(&param_2);
  piVar6 = (int *)puVar3[1];
  iStack_14 = iStack_14 + 4;
  uStack_68 = *(undefined4 *)(param_1 + 0x24);
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = (int *)puVar3[1];
  }
  uStack_64 = *puVar3;
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
  }
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_54 = 0;
  uStack_8 = 2;
  uStack_50 = 0;
  uStack_4c = 0;
  piStack_60 = piVar6;
  uStack_1c = uStack_64;
  piStack_18 = piVar6;
  uStack_50 = FUN_00a60fb0();
  uStack_48 = 0;
  param_2 = (uint *)0xb;
  ppuVar4 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar5 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar5 = ppuVar4;
  }
  puStack_44 = *ppuVar5;
  uStack_40 = 0;
  uStack_3c = 0x3f800000;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_24 = 0;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = piVar6[1] + -1;
    piVar6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  iVar2 = iStack_14;
  uStack_8 = 3;
  FUN_00a60300(&uStack_68);
  FUN_00a60220();
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 1;
  *(undefined4 *)(iVar2 + 0x38) = *(undefined4 *)(param_1 + 0x18);
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 21018 ; VA 0x00a63090 ; FUN_00a63090 */

int * __thiscall FUN_00a63090(int param_1,int *param_2)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1b49;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  uVar1 = *(uint *)(param_1 + 8);
  piVar2 = (int *)0x0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (uVar1 != 0) {
    if (0x3fffffff < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(uVar1);
    piVar2 = (int *)param_2[1];
    if (*(int *)(param_1 + 8) != 0) {
      puVar3 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      goto joined_r0x00a63111;
    }
  }
  puVar3 = (undefined4 *)0x0;
joined_r0x00a63111:
  for (; puVar3 != (undefined4 *)0x0; puVar3 = (undefined4 *)*puVar3) {
    puStack_18 = puVar3 + 3;
    if ((int *)param_2[2] == piVar2) {
      FUN_0063d9b0(piVar2,&puStack_18);
    }
    else {
      *piVar2 = (int)puStack_18;
      param_2[1] = param_2[1] + 4;
    }
    piVar2 = (int *)param_2[1];
  }
  FUN_00a5eca0(*param_2,piVar2,(int)piVar2 - *param_2 >> 2,param_2);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21019 ; VA 0x00a63170 ; FUN_00a63170 */

undefined4 * FUN_00a63170(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00b73ae0();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      puVar4 = &DAT_01ef0a50;
      goto LAB_00a631f6;
    }
    if (param_1 != 0) {
      iVar2 = *(int *)(param_1 + 0xc);
      iVar3 = FUN_009ec190();
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        puVar4 = &DAT_01ee5728;
        goto LAB_00a631f6;
      }
    }
  }
  puVar4 = (undefined4 *)0x0;
LAB_00a631f6:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 21020 ; VA 0x00a63240 ; FUN_00a63240 */

undefined4 __fastcall FUN_00a63240(int param_1)

{
  return *(undefined4 *)(param_1 + 0x84);
}



/* FUNCTION 21021 ; VA 0x00a63250 ; FUN_00a63250 */

undefined4 FUN_00a63250(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00a5f190(param_1,param_2,param_3);
  return param_1;
}



/* FUNCTION 21022 ; VA 0x00a63270 ; FUN_00a63270 */

uint __thiscall FUN_00a63270(int param_1,int *param_2)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  int *piVar3;
  
  do {
    if ((DAT_01d66190 != '\0') && (*(char *)((int)param_2 + 0x21) == '\0')) {
LAB_00a632e6:
      return in_EAX & 0xffffff00;
    }
    iVar1 = param_2[3];
    iVar2 = FUN_00c391f0();
    in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
    piVar3 = (int *)0x0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX) {
      piVar3 = param_2;
    }
    if (piVar3 != (int *)0x0) break;
    in_EAX = (**(code **)(*param_2 + 0x24))();
    if (((char)in_EAX != '\0') || (param_2 = (int *)param_2[0xd], param_2 == (int *)0x0))
    goto LAB_00a632e6;
    in_EAX = *(int *)(param_1 + 0x5c) + 0xc;
  } while (param_2 != (int *)(-(uint)(*(int *)(param_1 + 0x5c) != 0) & in_EAX));
  return CONCAT31((int3)(in_EAX >> 8),1);
}



/* FUNCTION 21023 ; VA 0x00a632f0 ; FUN_00a632f0 */

uint FUN_00a632f0(void)

{
  int iVar1;
  
  iVar1 = FUN_00a5e070();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 21024 ; VA 0x00a63310 ; FUN_00a63310 */

uint FUN_00a63310(void)

{
  int iVar1;
  
  iVar1 = FUN_00a5e070();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 21025 ; VA 0x00a63330 ; FUN_00a63330 */

void FUN_00a63330(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a65740();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21026 ; VA 0x00a63370 ; FUN_00a63370 */

void FUN_00a63370(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dccf14);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<int,class_boost::_mfi::cmf0<int,class_RBX::ChangeHistoryService>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::ChangeHistoryService*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 21027 ; VA 0x00a633e0 ; FUN_00a633e0 */

void __fastcall FUN_00a633e0(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01ee7b14);
  uStack_8 = 0;
  piVar1 = *(int **)**(undefined4 **)(param_1 + 0x6c);
  FUN_00a612b0(piVar1[2]);
  if (*(int **)(param_1 + 0x78) == piVar1) {
    *(int *)(param_1 + 0x78) = (*(int **)(param_1 + 0x78))[1];
  }
  if (*(int **)(param_1 + 0x7c) == piVar1) {
    *(undefined4 *)(param_1 + 0x7c) = *(undefined4 *)(param_1 + 0x6c);
  }
  if (*(int **)(param_1 + 0x74) == piVar1) {
    *(int *)(param_1 + 0x74) = **(int **)(param_1 + 0x74);
  }
  if (piVar1[2] != 0) {
    FUN_00a60f10(1);
  }
  *(int *)piVar1[1] = *piVar1;
  *(int *)(*piVar1 + 4) = piVar1[1];
  *(int *)(param_1 + 0x70) = *(int *)(param_1 + 0x70) + -1;
  FUN_01674ea0(piVar1,0xc);
  FUN_00a62620();
  uStack_8 = 1;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21028 ; VA 0x00a634b0 ; FUN_00a634b0 */

void * __thiscall FUN_00a634b0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  void **ppvVar5;
  void *pvVar6;
  undefined4 uVar7;
  int *piVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1b78;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar6 = ExceptionList;
  ppvVar5 = &pvStack_10;
  iStack_18 = param_1;
  if (((*(char *)(param_1 + 0x80) == '\0') && (ppvVar5 = &pvStack_10, *(int *)(param_1 + 0x68) != 0)
      ) && (ExceptionList = &pvStack_10, pvVar6 = (void *)FUN_00a63270(param_2),
           ppvVar5 = (void **)ExceptionList, (char)pvVar6 != '\0')) {
    uVar7 = FUN_01675290(DAT_01ee7b14);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piVar8 = (int *)FUN_01255560();
    if (*piVar8 == 9) {
      iStack_14 = FUN_00a62ed0(&param_2);
    }
    else {
      iStack_14 = FUN_00a62ed0(&param_2);
    }
    iVar9 = *(int *)(iStack_14 + 4);
    puVar2 = *(undefined4 **)(*(int *)(iVar9 + 0xc) + 0x1c);
    puVar10 = *(undefined4 **)(*(int *)(iVar9 + 0xc) + 0x18);
    piStack_1c = (int *)((uint)((int)puVar2 + (3 - (int)puVar10)) >> 2);
    if (puVar2 < puVar10) {
      piStack_1c = (int *)0x0;
    }
    if (piStack_1c != (int *)0x0) {
      piVar8 = (int *)0x0;
      do {
        FUN_00a61bc0(*puVar10);
        puVar10 = puVar10 + 1;
        piVar8 = (int *)((int)piVar8 + 1);
      } while (piVar8 != piStack_1c);
      iVar9 = *(int *)(iStack_14 + 4);
    }
    iVar4 = iStack_14;
    puVar10 = (undefined4 *)FUN_0060dcd0(&iStack_20,*(undefined4 *)(iVar9 + 0x34));
    uVar11 = *puVar10;
    uVar3 = puVar10[1];
    *puVar10 = 0;
    puVar10[1] = 0;
    *(undefined4 *)(iVar4 + 0x10) = uVar11;
    piVar8 = *(int **)(iVar4 + 0x14);
    *(undefined4 *)(iVar4 + 0x14) = uVar3;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar9 = piVar8[1] + -1;
      piVar8[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar9 = piVar8[2] + -1;
        piVar8[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    piVar8 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar8 + 2;
        iVar9 = *piVar1 + -1;
        *piVar1 = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    piVar8 = (int *)FUN_01255560();
    uVar11 = 1;
    if (*piVar8 == 9) {
      uVar11 = 4;
    }
    *(undefined4 *)(iVar4 + 0xc) = uVar11;
    if (*(char *)(iVar4 + 0x3c) != '\0') {
      *(undefined *)(iVar4 + 0x3c) = 0;
    }
    FUN_00a5f430(&iStack_20,&param_2);
    iVar9 = iStack_18;
    uStack_8._0_1_ = 2;
    if ((iStack_20 != 0) && (*(int *)(iStack_18 + 0x60) == 0)) {
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      *(int *)(iStack_18 + 0x60) = iStack_20;
      piVar8 = *(int **)(iStack_18 + 100);
      *(int **)(iStack_18 + 100) = piStack_1c;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar4 = piVar8[1] + -1;
        piVar8[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar4 = piVar8[2] + -1;
          piVar8[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      uVar11 = *(undefined4 *)(*(int *)(iVar9 + 0x60) + 0x134);
      FUN_00a6e300(iStack_18 + 0x58);
      FUN_00a61500(uVar11);
    }
    FUN_00550b30();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    pvVar6 = (void *)FUN_01675290(uVar7);
    ppvVar5 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar5;
  piVar8 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar9 = *piVar1;
    pvVar6 = (void *)*piVar1;
    *piVar1 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      pvVar6 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar9 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        pvVar6 = (void *)(**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 21029 ; VA 0x00a63710 ; FUN_00a63710 */

undefined4 * __thiscall FUN_00a63710(int param_1,int param_2,int *param_3,undefined4 *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void **ppvVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  int iVar10;
  undefined4 *puVar11;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1ba0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar6 = (undefined4 *)ExceptionList;
  ppvVar5 = &pvStack_10;
  if (((*(char *)(param_1 + 0x80) == '\0') && (ppvVar5 = &pvStack_10, *(int *)(param_1 + 0x68) != 0)
      ) && (ExceptionList = &pvStack_10, puVar6 = (undefined4 *)FUN_00a63270(param_2),
           ppvVar5 = (void **)ExceptionList, (char)puVar6 != '\0')) {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    puVar6 = (undefined4 *)FUN_00a63170(param_2,param_3);
    iVar2 = param_2;
    ppvVar5 = (void **)ExceptionList;
    if (puVar6 != param_4) {
      iVar3 = *(int *)(param_2 + 0xc);
      iVar7 = FUN_00d1e830();
      puVar11 = param_4;
      puVar6 = (undefined4 *)(uint)*(ushort *)(iVar7 + 0x1da);
      iVar10 = 0;
      if ((undefined4 *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8)) <=
          puVar6) {
        iVar10 = iVar2;
      }
      ppvVar5 = (void **)ExceptionList;
      if ((((iVar10 == 0) || (param_4 == (undefined4 *)&DAT_0211a3a0)) || (param_4 == &DAT_0211a3d8)
          ) && (param_4 != &DAT_01eeee08)) {
        uStack_18 = FUN_01675290(DAT_01ee7b14);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        piVar8 = (int *)FUN_01255560();
        if (*piVar8 == 9) {
          piVar8 = *(int **)(param_1 + 0x6c);
          piVar4 = (int *)*piVar8;
          do {
            if (piVar8 == piVar4) goto LAB_00a6385f;
            piVar8 = (int *)piVar8[1];
            iStack_14 = FUN_00a62e80(param_2);
          } while ((iStack_14 == 0) ||
                  (piVar1 = (int *)(iStack_14 + 0x18),
                  piVar9 = (int *)FUN_00601f20(auStack_1c,&param_4), puVar11 = param_4,
                  *piVar9 == *piVar1));
        }
        else {
          FUN_00a62ed0(&param_2);
        }
        FUN_00a646b0(puVar11);
LAB_00a6385f:
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        puVar6 = (undefined4 *)FUN_01675290(uStack_18);
        ppvVar5 = (void **)ExceptionList;
      }
    }
  }
  ExceptionList = ppvVar5;
  piVar8 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar4 = param_3 + 1;
    iVar2 = *piVar4;
    puVar6 = (undefined4 *)*piVar4;
    *piVar4 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar6 = (undefined4 *)(**(code **)*param_3)();
      LOCK();
      piVar4 = piVar8 + 2;
      iVar2 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar6 = (undefined4 *)(**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 21030 ; VA 0x00a638b0 ; FUN_00a638b0 */

void * __thiscall FUN_00a638b0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  void **ppvVar3;
  void *pvVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 *puVar7;
  int iVar8;
  int *piVar9;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1bc8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ppvVar3 = &pvStack_10;
  iStack_14 = param_1;
  if (((*(char *)(param_1 + 0x80) == '\0') && (ppvVar3 = &pvStack_10, *(int *)(param_1 + 0x68) != 0)
      ) && (ExceptionList = &pvStack_10, pvVar4 = (void *)FUN_00a63270(param_2),
           ppvVar3 = (void **)ExceptionList, (char)pvVar4 != '\0')) {
    uVar5 = FUN_01675290(DAT_01ee7b14);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piVar6 = (int *)FUN_01255560();
    if (*piVar6 == 9) {
      piVar6 = (int *)**(int **)(param_1 + 0x6c);
      if (piVar6 != *(int **)(param_1 + 0x6c)) {
        do {
          FUN_00a648b0(param_2);
          iVar8 = piVar6[2];
          if (*(int *)(iVar8 + 8) == 0) {
            puVar7 = (undefined4 *)0x0;
          }
          else {
            puVar7 = *(undefined4 **)(*(int *)(iVar8 + 0x14) + *(int *)(iVar8 + 4) * 4);
          }
          for (; puVar7 != (undefined4 *)0x0; puVar7 = (undefined4 *)*puVar7) {
            if (puVar7[6] != 0) {
              piVar9 = (int *)*piVar6;
              goto LAB_00a639af;
            }
          }
          if (piVar6 == *(int **)(param_1 + 0x78)) {
            *(int *)(param_1 + 0x78) = (*(int **)(param_1 + 0x78))[1];
          }
          if (piVar6 == *(int **)(param_1 + 0x74)) {
            *(int *)(param_1 + 0x74) = **(int **)(param_1 + 0x74);
          }
          piVar9 = (int *)*piVar6;
          *(int **)piVar6[1] = piVar9;
          *(int *)(*piVar6 + 4) = piVar6[1];
          *(int *)(iStack_14 + 0x70) = *(int *)(iStack_14 + 0x70) + -1;
          FUN_01674ea0(piVar6,0xc);
          param_1 = iStack_14;
LAB_00a639af:
          piVar6 = piVar9;
        } while (piVar9 != *(int **)(param_1 + 0x6c));
      }
    }
    else {
      FUN_00557fc0(&param_2);
      iStack_18 = FUN_00a63170();
      if (iStack_18 == 0) {
        iVar8 = FUN_00a62ed0(&param_2);
        *(undefined4 *)(iVar8 + 0x10) = 0;
        piVar6 = *(int **)(iVar8 + 0x14);
        *(undefined4 *)(iVar8 + 0x14) = 0;
        iStack_18 = iVar8;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar1 = piVar6[1] + -1;
          piVar6[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar1 = piVar6[2] + -1;
            piVar6[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        iVar1 = *(int *)(iVar8 + 0x18);
        uStack_8._0_1_ = 2;
        FUN_00a61060(*(undefined4 *)(iVar1 + 4));
        iVar2 = iStack_18;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        *(int *)(*(int *)(iVar8 + 0x18) + 4) = iVar1;
        **(int **)(iVar8 + 0x18) = iVar1;
        *(int *)(*(int *)(iVar8 + 0x18) + 8) = iVar1;
        *(undefined4 *)(iVar8 + 0x1c) = 0;
        *(undefined4 *)(iStack_18 + 0x40) = 0;
        if (*(char *)(iStack_18 + 0x3c) == '\0') {
          *(undefined *)(iStack_18 + 0x3c) = 1;
        }
        if ((*(int *)(iStack_18 + 0xc) == 1) || (piVar6 = (int *)FUN_01255560(), *piVar6 == 9)) {
          *(undefined4 *)(iVar2 + 0xc) = 0;
          param_1 = iStack_14;
        }
        else {
          *(undefined4 *)(iVar2 + 0xc) = 3;
          param_1 = iStack_14;
        }
      }
      else {
        iVar8 = FUN_00a62ed0(&param_2);
        FUN_00a646b0(iStack_18);
        FUN_00a646b0(&DAT_01eebf14);
        FUN_0058a2b0();
        *(undefined4 *)(iVar8 + 0xc) = 3;
      }
    }
    FUN_00a5f430(&iStack_1c,&param_2);
    uStack_8._0_1_ = 3;
    if (iStack_1c != 0) {
      FUN_00a6f530(param_1 + 0x58);
      FUN_0058a2b0();
    }
    FUN_00550b30();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    pvVar4 = (void *)FUN_01675290(uVar5);
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  piVar6 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar9 = param_3 + 1;
    iVar8 = *piVar9;
    pvVar4 = (void *)*piVar9;
    *piVar9 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar9 = piVar6 + 2;
      iVar8 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        pvVar4 = (void *)(**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 21031 ; VA 0x00a63b40 ; FUN_00a63b40 */

void __thiscall FUN_00a63b40(int param_1,int param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_1c [4];
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1be8;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x81) == '\0') {
    return;
  }
  if (param_3 != 0) {
    if (param_3 == 1) {
      if (param_2 != 0) {
        return;
      }
      *(undefined4 *)(param_1 + 0x7c) = *(undefined4 *)(param_1 + 0x78);
      return;
    }
    if (param_3 != 2) {
      return;
    }
  }
  if (((DAT_01ee7b0c != 1) || (*(int *)(param_1 + 0x88) == 0)) ||
     (ExceptionList = &pvStack_10, *(int *)(*(int *)(param_1 + 0x88) + 0x68) != 1)) {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)
             FUN_0060dcd0(auStack_1c,*(undefined4 *)(*(int *)(param_1 + 0x5c) + 0x1b8));
    uStack_8 = 0;
    uVar2 = *puVar5;
    uVar3 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    FUN_00a64960(uVar2,uVar3);
    uStack_8 = 0xffffffff;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  FUN_00a65420(&DAT_0194400c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21032 ; VA 0x00a63c60 ; FUN_00a63c60 */

void __thiscall FUN_00a63c60(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1c21;
  pvStack_10 = ExceptionList;
  piStack_1c = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_1 + 0x88) = 0;
    piStack_18 = *(int **)(param_1 + 0x8c);
    *(undefined4 *)(param_1 + 0x8c) = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    FUN_01679490();
    FUN_00a62c00();
    if (DAT_01d66188 != '\0') {
      FUN_00a62440();
    }
    *(undefined4 *)(param_1 + 0x5c) = 0;
    if (*(int *)(param_1 + 0x90) != 0) {
      FUN_008a65e0(0,0);
      *(undefined4 *)(param_1 + 0x90) = 0;
      piStack_18 = *(int **)(param_1 + 0x94);
      *(undefined4 *)(param_1 + 0x94) = 0;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_18[1] + -1;
        piStack_18[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  FUN_008a4210(param_2,param_3);
  if (param_3 != 0) {
    *(int *)(param_1 + 0x5c) = param_3 + -0xc;
    uVar5 = FUN_005f5170();
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_28,uVar5);
    uVar5 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x88) = uVar5;
    param_2 = *(int **)(param_1 + 0x8c);
    *(undefined4 *)(param_1 + 0x8c) = uVar2;
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar3 = param_2[1] + -1;
      param_2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_2)();
        LOCK();
        iVar3 = param_2[2] + -1;
        param_2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    param_2 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar3 = param_2[2] + -1;
        param_2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    iStack_14 = *(int *)(param_1 + 0x88) + 0xd8;
    iStack_8 = 0;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 1;
    piStack_24 = (int *)uVar5;
    piStack_18 = (int *)FUN_01674e20(0x28);
    if (piStack_18 == (undefined4 *)0x0) {
      piStack_18 = (undefined4 *)0x0;
    }
    else {
      *piStack_18 = 0;
      piStack_18[1] = 1;
      piStack_18[2] = (int)FUN_00819150;
      piStack_18[3] = (int)_guard_check_icall;
      piStack_18[4] = 0;
      piStack_18[5] = iStack_14;
      piStack_18[6] = (int)FUN_00a63b40;
      piStack_18[7] = 0;
      piStack_18[8] = param_1;
      piStack_18[9] = uStack_2c;
    }
    FUN_016797d0(piStack_18);
    param_2 = piStack_18;
    if (piStack_18 != (undefined4 *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    piStack_1c = (int *)0x1;
    iStack_8._0_1_ = 2;
    FUN_01675290(uVar5);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    cVar4 = FUN_01679300(&param_2);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_2);
    }
    iStack_8 = 0xffffffff;
    if (param_2 != (undefined4 *)0x0) {
      piVar1 = param_2 + 1;
      LOCK();
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(param_2);
      }
    }
    param_3 = FUN_006fb410();
    if (param_3 != 0) {
      puVar6 = (undefined4 *)FUN_00a62970(auStack_20,param_1);
      uVar5 = *puVar6;
      uVar2 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      *(undefined4 *)(param_1 + 0x90) = uVar5;
      param_2 = *(int **)(param_1 + 0x94);
      *(undefined4 *)(param_1 + 0x94) = uVar2;
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar3 = param_2[1] + -1;
        param_2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*param_2)();
          LOCK();
          iVar3 = param_2[2] + -1;
          param_2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      param_2 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar1 = param_2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      FUN_008a65e0(param_3,0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21033 ; VA 0x00a63fb0 ; FUN_00a63fb0 */

void __thiscall FUN_00a63fb0(int param_1,int *param_2,uint param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  byte *pbVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined auStack_a8 [20];
  int *piStack_94;
  undefined8 uStack_8c;
  undefined8 uStack_80;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  undefined8 uStack_68;
  int iStack_60;
  undefined8 uStack_5c;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  undefined4 uStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  uint uStack_34;
  undefined8 *puStack_30;
  undefined8 uStack_2c;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1c64;
  pvStack_10 = ExceptionList;
  uVar6 = 0;
  uStack_34 = 0;
  uStack_14 = 0;
  if ((((param_3 == 0) && (*(char *)(param_1 + 0x28) == '\0')) && (*(int *)(param_1 + 0x10) != 0))
     && (*(int *)(param_1 + 8) != 0)) {
    ExceptionList = &pvStack_10;
    iStack_18 = param_1;
    uVar2 = FUN_01675290(DAT_01ee7b14);
    iStack_8 = 0;
    uStack_44 = uVar2;
    piVar3 = (int *)FUN_01255560();
    if (*piVar3 == 9) {
      FUN_00a70da0(&uStack_68,3);
      puStack_30 = &uStack_68;
      uStack_2c = uStack_68;
      iStack_24 = iStack_60;
      uStack_8c = uStack_5c;
      iStack_40 = iStack_54;
      param_2 = piStack_1c;
      do {
        if ((int)uStack_2c == (int)uStack_8c) {
          if ((uStack_2c._4_4_ == uStack_8c._4_4_) && (uVar2 = uStack_44, iStack_24 == iStack_40))
          goto LAB_00a642ae;
        }
        puVar7 = *(undefined4 **)(iStack_18 + 0x14);
        puVar8 = (undefined4 *)*puVar7;
        while (puVar7 != puVar8) {
          puVar7 = (undefined4 *)puVar7[1];
          if (puVar7 == puVar8) {
            param_2 = *(int **)(iStack_18 + 0xc);
            if (param_2 != (int *)0x0) {
              LOCK();
              param_2[1] = param_2[1] + 1;
              UNLOCK();
              param_2 = *(int **)(iStack_18 + 0xc);
            }
            uStack_20 = *(undefined4 *)(iStack_18 + 8);
            uStack_34 = uVar6 | 1;
            iStack_8 = CONCAT31(iStack_8._1_3_,1);
            piStack_1c = param_2;
            uStack_14 = uStack_34;
            iVar4 = FUN_00a62ed0(&uStack_20);
          }
          else {
            param_3 = *(uint *)(iStack_18 + 8);
            pbVar5 = (byte *)puVar7[2] + *(byte *)puVar7[2] + 1;
            FUN_00606ea0(&iStack_38,(param_3 >> 3) + param_3,&param_3,
                         -(uint)(pbVar5 != (byte *)0x0) & (uint)(pbVar5 + 1));
            if (iStack_38 == 0) {
              iVar4 = 0;
            }
            else {
              iVar4 = iStack_38 + 0xc;
            }
          }
          iStack_8 = 0;
          if (((uStack_14 & 1) != 0) && (uStack_14 = uStack_14 & 0xfffffffe, param_2 != (int *)0x0))
          {
            LOCK();
            iVar9 = param_2[1] + -1;
            param_2[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*param_2)();
              LOCK();
              iVar9 = param_2[2] + -1;
              param_2[2] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)(*param_2 + 4))();
              }
            }
          }
          if (iVar4 != 0) {
            if (puVar7 != puVar8) {
              iVar9 = *(byte *)(iVar4 + 0x20) + 0x21 + iVar4;
              uVar2 = FUN_00a6ce70(&uStack_2c);
              FUN_006e16e0(&iStack_3c,uVar2,&uStack_2c,-(uint)(iVar9 != 0) & iVar9 + 1U);
              if (iStack_3c == 0) goto LAB_00a6418d;
            }
            iStack_78 = iStack_24 * 8;
            iStack_6c = iStack_78 + 8;
            iStack_4c = uStack_2c._4_4_ * 8;
            iStack_50 = (int)uStack_2c * 8;
            iStack_74 = iStack_50 + 8;
            uStack_80 = CONCAT44(iStack_4c,iStack_50);
            iStack_70 = iStack_4c + 8;
            FUN_00a71760(auStack_a8,&uStack_80,0,1);
            iStack_8._0_1_ = 2;
            iVar9 = FUN_00a60880(&uStack_2c);
            FUN_00a71f60(iVar9 + 0xc);
            piVar3 = piStack_94;
            if (*(char *)(iVar4 + 0x44) != '\0') {
              *(undefined *)(iVar4 + 0x44) = 0;
            }
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            uVar6 = uStack_14;
            if (piStack_94 != (int *)0x0) {
              LOCK();
              iVar4 = piStack_94[1] + -1;
              piStack_94[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piStack_94)();
                LOCK();
                piVar1 = piVar3 + 2;
                iVar4 = *piVar1 + -1;
                *piVar1 = iVar4;
                UNLOCK();
                uVar6 = uStack_14;
                if (iVar4 == 0) {
                  (**(code **)(*piVar3 + 4))();
                  uVar6 = uStack_14;
                }
              }
            }
            break;
          }
LAB_00a6418d:
          uVar6 = uStack_14;
          puVar8 = (undefined4 *)**(undefined4 **)(iStack_18 + 0x14);
        }
        FUN_00a6e100();
      } while( true );
    }
    piVar3 = (int *)(iStack_18 + 8);
    FUN_00557fc0(piVar3);
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    FUN_00a62ed0(&uStack_20);
    FUN_00a61710(*(undefined4 *)(*piVar3 + 0x134),param_2,0);
    FUN_00550b30();
LAB_00a642ae:
    iStack_8 = 4;
    FUN_01675290(uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21034 ; VA 0x00a642e0 ; FUN_00a642e0 */

int * __fastcall FUN_00a642e0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_58 [20];
  int *piStack_44;
  undefined8 uStack_40;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined auStack_1c [4];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1c78;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)(*(int *)(param_1 + 0xc) + -1);
  switch(piVar3) {
  case (int *)0x0:
  case (int *)0x3:
    ExceptionList = &pvStack_10;
    FUN_00a5f680(auStack_18,**(undefined4 **)(param_1 + 0x18),*(undefined4 **)(param_1 + 0x18),
                 FUN_00a61be0,param_1);
    piStack_14 = &DAT_0211a3d8;
    puVar4 = (undefined4 *)FUN_00601f20(auStack_1c,&piStack_14);
    piVar3 = (int *)*puVar4;
    if (piVar3 == *(int **)(param_1 + 0x18)) {
      piVar3 = (int *)FUN_008a65e0(*(undefined4 *)(param_1 + 0x10),0);
    }
    break;
  case (int *)0x1:
    ExceptionList = &pvStack_10;
    piVar3 = (int *)FUN_00a5f680(auStack_18,**(undefined4 **)(param_1 + 0x18),
                                 *(undefined4 **)(param_1 + 0x18),FUN_00a61be0,param_1);
    if (*(int *)(param_1 + 0x28) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      piVar3 = *(int **)(param_1 + 0x34);
      puVar4 = (undefined4 *)piVar3[*(int *)(param_1 + 0x24)];
    }
    for (; puVar4 != (undefined4 *)0x0; puVar4 = (undefined4 *)*puVar4) {
      iStack_24 = puVar4[3] * 8;
      iStack_30 = iStack_24 + 8;
      iStack_38 = puVar4[4] * 8;
      iStack_28 = puVar4[2] * 8;
      iStack_34 = iStack_28 + 8;
      uStack_40 = CONCAT44(iStack_24,iStack_28);
      iStack_2c = iStack_38 + 8;
      FUN_00a6dba0(8);
      piVar3 = puVar4 + 5;
      uStack_8 = 0;
      if (0xf < (uint)puVar4[10]) {
        piVar3 = (int *)*piVar3;
      }
      FUN_00a6f140(piVar3,puVar4[9]);
      FUN_00a72960(&uStack_40,auStack_58,0);
      uStack_8 = 0xffffffff;
      piStack_14 = piStack_44;
      piVar3 = piStack_44;
      if (piStack_44 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_44[1] + -1;
        piStack_44[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_44)();
          LOCK();
          piVar1 = piStack_14 + 2;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            piVar3 = (int *)(**(code **)(*piStack_14 + 4))();
          }
        }
      }
    }
    break;
  case (int *)0x2:
    ExceptionList = &pvStack_10;
    piVar3 = (int *)FUN_008a65e0(0,0);
    ExceptionList = pvStack_10;
    return piVar3;
  default:
    goto switchD_00a6430c_caseD_4;
  }
  if (*(char *)(param_1 + 0x3c) != '\0') {
    *(undefined *)(param_1 + 0x3c) = 0;
  }
switchD_00a6430c_caseD_4:
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 21035 ; VA 0x00a64490 ; FUN_00a64490 */

void FUN_00a64490(void)

{
  int iVar1;
  uint uVar2;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1c98;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc8;
  ExceptionList = &pvStack_10;
  FUN_00a63090(&iStack_2c);
  uVar2 = 0;
  while( true ) {
    uStack_8 = 0;
    uStack_18 = uVar2;
    if ((uint)(iStack_28 - iStack_2c >> 2) <= uVar2) break;
    uStack_8 = 1;
    FUN_00a642e0();
    uVar2 = uVar2 + 1;
  }
  FUN_00a650d0(1);
  if (iStack_2c != 0) {
    uVar2 = iStack_24 - iStack_2c & 0xfffffffc;
    iVar1 = iStack_2c;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(iStack_2c + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iStack_2c - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21036 ; VA 0x00a644ea ; Catch@00a644ea */

undefined * Catch_00a644ea(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))(6);
  FUN_0086edd0(2,uVar1);
  return &DAT_00a64505;
}



/* FUNCTION 21037 ; VA 0x00a64570 ; FUN_00a64570 */

void __fastcall FUN_00a64570(int param_1)

{
  undefined4 uVar1;
  undefined *puVar2;
  char *pcVar3;
  undefined auStack_38 [12];
  undefined auStack_2c [12];
  undefined auStack_20 [4];
  undefined *puStack_1c;
  undefined uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1cc0;
  pvStack_10 = ExceptionList;
  puVar2 = (undefined *)(param_1 + 0x80);
  if (*(char *)(param_1 + 0x80) == '\0') {
    if (*(char *)(param_1 + 0x81) != '\0') {
      if (*(int *)(param_1 + 0x74) != *(int *)(param_1 + 0x6c)) {
        uStack_18 = 0;
        ExceptionList = &pvStack_10;
        *puVar2 = 1;
        uStack_8 = 0;
        puStack_1c = puVar2;
        if (*(int *)(param_1 + 0x68) != 0) {
          FUN_00a657f0();
          if (*(int *)(param_1 + 0x68) != 0) {
            FUN_00a60f10(1);
          }
          iStack_14 = FUN_01674e20(0x40);
          if (iStack_14 == 0) {
            uVar1 = 0;
          }
          else {
            uVar1 = FUN_00a5fcf0(param_1);
          }
          *(undefined4 *)(param_1 + 0x68) = uVar1;
        }
        FUN_00a64490();
        FUN_0054ef60(*(int *)(*(int *)(param_1 + 0x74) + 8) + 0x28);
        *(undefined4 **)(param_1 + 0x78) = *(undefined4 **)(param_1 + 0x74);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        *(undefined4 *)(param_1 + 0x74) = **(undefined4 **)(param_1 + 0x74);
        FUN_006eccd0();
        FUN_0054ef60(auStack_38);
        FUN_006ecaa0();
        FUN_005507b0();
        if (puVar2 != (undefined *)0x0) {
          *puVar2 = 0;
        }
        ExceptionList = pvStack_10;
        return;
      }
      ExceptionList = &pvStack_10;
      FUN_00550130("Attempt to play beyond change history");
      puVar2 = auStack_2c;
      goto LAB_00a646a6;
    }
    pcVar3 = "ChangeHistoryService is disabled";
  }
  else {
    pcVar3 = "ChangeHistoryService is currently playing";
  }
  ExceptionList = &pvStack_10;
  FUN_00550130(pcVar3);
  puVar2 = auStack_20;
LAB_00a646a6:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(puVar2,&DAT_01c17198);
}



/* FUNCTION 21038 ; VA 0x00a646b0 ; FUN_00a646b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a646b0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  void *pvVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_00a61850(param_2);
  puVar7 = *(undefined4 **)(param_1 + 0xc);
  if ((puVar7 == (undefined4 *)0x1) || (puVar7 == (undefined4 *)&DAT_00000004)) {
    if (param_2 == &DAT_0211a3d8) {
      puVar7 = (undefined4 *)FUN_0060dcd0(auStack_c,*(undefined4 *)(*(int *)(param_1 + 4) + 0x34));
      uVar6 = *puVar7;
      uVar4 = puVar7[1];
      *puVar7 = 0;
      puVar7[1] = 0;
      *(undefined4 *)(param_1 + 0x10) = uVar6;
      piVar1 = *(int **)(param_1 + 0x14);
      *(undefined4 *)(param_1 + 0x14) = uVar4;
      if (piVar1 != (int *)0x0) {
        LOCK();
        piVar2 = piVar1 + 1;
        iVar3 = *piVar2;
        puVar7 = (undefined4 *)*piVar2;
        *piVar2 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          piVar2 = piVar1 + 2;
          iVar3 = *piVar2;
          puVar7 = (undefined4 *)*piVar2;
          *piVar2 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            puVar7 = (undefined4 *)(**(code **)(*piVar1 + 4))();
          }
        }
      }
      if (piStack_8 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_8 + 1;
        iVar3 = *piVar1;
        puVar7 = (undefined4 *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          puVar7 = (undefined4 *)(**(code **)*piStack_8)();
          LOCK();
          piVar1 = piStack_8 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            puVar7 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
          }
        }
      }
    }
  }
  else {
    *(undefined4 *)(param_1 + 0xc) = 2;
    uVar6 = FUN_0060dcd0(auStack_c,*(undefined4 *)(*(int *)(param_1 + 4) + 0x34));
    puVar7 = (undefined4 *)FUN_005587e0(uVar6);
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_8 + 1;
      iVar3 = *piVar1;
      puVar7 = (undefined4 *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        puVar7 = (undefined4 *)(**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          puVar7 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
        }
      }
    }
    if (param_2 == &DAT_0211a3d8) {
      puVar8 = (undefined4 *)FUN_00a60800(&param_2);
      uVar6 = FUN_0088cdc0();
      pvVar5 = ThreadLocalStoragePointer;
      iVar3 = _tls_index;
      *puVar8 = uVar6;
      if (*(int *)(*(int *)((int)pvVar5 + iVar3 * 4) + 0x34) < DAT_01ead288) {
        FUN_016f3809(&DAT_01ead288);
        if (DAT_01ead288 == -1) {
          DAT_01ead27c = FUN_0057bbb0;
          _DAT_01ead280 = FUN_005880a0;
          DAT_01ead284 = FUN_0057d5e0;
          FUN_016f37bf(&DAT_01ead288);
        }
      }
      puVar7 = (undefined4 *)puVar8[1];
      if ((code **)puVar7 == &DAT_01ead27c) {
        puVar7 = (undefined4 *)FUN_0056ecd0(param_1 + 0x10);
      }
      else {
        if (puVar7 != (undefined4 *)0x0) {
          (*(code *)puVar7[2])(puVar8 + 2);
          puVar8[1] = 0;
        }
        puVar8[2] = 0;
        puVar8[3] = 0;
        if (*(int *)(param_1 + 0x14) != 0) {
          LOCK();
          piVar1 = (int *)(*(int *)(param_1 + 0x14) + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        puVar8[2] = *(undefined4 *)(param_1 + 0x10);
        puVar7 = *(undefined4 **)(param_1 + 0x14);
        puVar8[3] = puVar7;
        puVar8[1] = &DAT_01ead27c;
      }
    }
  }
  if (*(char *)(param_1 + 0x3c) != '\0') {
    *(undefined *)(param_1 + 0x3c) = 0;
  }
  return puVar7;
}



/* FUNCTION 21039 ; VA 0x00a648b0 ; FUN_00a648b0 */

void __thiscall FUN_00a648b0(int param_1,uint param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  if (*(int *)(param_1 + 8) != 0) {
    uVar2 = (param_2 >> 3) + param_2;
    uVar5 = uVar2 % *(uint *)(param_1 + 4);
    piVar6 = *(int **)(uVar5 * 4 + *(int *)(param_1 + 0x14));
    if ((piVar6 != (int *)0x0) && (piVar1 = (int *)*piVar6, (int *)*piVar6 != (int *)0x0)) {
      while (piVar4 = piVar1, (uint)piVar4[1] % *(uint *)(param_1 + 4) == uVar5) {
        if ((piVar4[1] == uVar2) && (param_2 == piVar4[2])) {
          FUN_00a62bb0(piVar6,*piVar4);
          if (*piVar6 != 0) {
            uVar2 = *(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4);
            if (uVar5 == uVar2) {
              return;
            }
            *(int **)(*(int *)(param_1 + 0x14) + uVar2 * 4) = piVar6;
          }
          puVar3 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
          if ((int *)*puVar3 != piVar6) {
            return;
          }
          *puVar3 = 0;
          return;
        }
        piVar1 = (int *)*piVar4;
        piVar6 = piVar4;
        if ((int *)*piVar4 == (int *)0x0) {
          return;
        }
      }
    }
  }
  return;
}



/* FUNCTION 21040 ; VA 0x00a64960 ; FUN_00a64960 */

int * __thiscall FUN_00a64960(int param_1,int *param_2,int *param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  float *pfVar7;
  int *piVar8;
  int *piVar9;
  byte *pbVar10;
  int iVar11;
  undefined4 *puVar12;
  float *pfVar13;
  int iStack_30;
  int *piStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int *piStack_18;
  char cStack_13;
  char cStack_12;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1ce0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_18 = param_2;
  piStack_2c = param_2;
  piVar3 = param_2;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if (param_2 != (int *)0x0) {
    iVar11 = param_2[3];
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00aff8c0();
    piStack_18 = param_2;
    piVar3 = (int *)(uint)*(ushort *)(iVar2 + 0x1da);
    if ((int *)((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) <= piVar3) {
      cStack_12 = '\0';
      cStack_13 = '\0';
      bStack_11 = 0;
      iVar11 = *(int *)(iStack_1c + 0x78);
      do {
        pbVar10 = *(byte **)(iVar11 + 8) + **(byte **)(iVar11 + 8) + 1;
        piStack_24 = piStack_18;
        FUN_00606ea0(&iStack_30,((uint)piStack_18 >> 3) + (int)piStack_18,&piStack_24,
                     -(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
        if ((iStack_30 != 0) && (piStack_24 = (int *)(iStack_30 + 0xc), piStack_24 != (int *)0x0)) {
          if (cStack_12 == '\0') {
            puVar12 = *(undefined4 **)(iStack_30 + 0x24);
            puVar5 = (undefined4 *)puVar12[1];
            puStack_20 = puVar12;
            if (*(char *)((int)puVar12[1] + 0xd) == '\0') {
              do {
                if ((uint)puVar5[4] < 0x212a430) {
                  puVar6 = (undefined4 *)puVar5[2];
                }
                else {
                  puVar6 = (undefined4 *)*puVar5;
                  puStack_20 = puVar5;
                }
                puVar5 = puVar6;
              } while (*(char *)((int)puVar6 + 0xd) == '\0');
              if ((puStack_20 == puVar12) || (&DAT_0212a430 < (undefined4 *)puStack_20[4]))
              goto LAB_00a64a68;
            }
            else {
LAB_00a64a68:
              puStack_20 = puVar12;
            }
            if (puStack_20 != puVar12) {
              iVar2 = puStack_20[5];
              iVar4 = FUN_00b00260();
              if (iVar2 != iVar4) goto LAB_00a64da9;
              puVar12 = puStack_20 + 7;
              if (puStack_20[6] == 0) {
                puVar12 = (undefined4 *)0x0;
              }
              iVar2 = FUN_00b077e0();
              if (((((NAN((float)puVar12[9]) || NAN(*(float *)(iVar2 + 0x24))) ==
                     ((float)puVar12[9] == *(float *)(iVar2 + 0x24))) ||
                   ((NAN((float)puVar12[10]) || NAN(*(float *)(iVar2 + 0x28))) ==
                    ((float)puVar12[10] == *(float *)(iVar2 + 0x28)))) ||
                  ((NAN((float)puVar12[0xb]) || NAN(*(float *)(iVar2 + 0x2c))) ==
                   ((float)puVar12[0xb] == *(float *)(iVar2 + 0x2c)))) ||
                 (cVar1 = FUN_01160ab0(iVar2), cVar1 == '\0')) {
                FUN_00a62ed0(&param_2);
                FUN_00a646b0(&DAT_0212a430);
              }
              cStack_12 = '\x01';
              piStack_18 = param_2;
            }
          }
          if (cStack_13 == '\0') {
            puVar12 = (undefined4 *)piStack_24[6];
            puVar5 = (undefined4 *)puVar12[1];
            puStack_20 = puVar12;
            if (*(char *)((int)puVar12[1] + 0xd) == '\0') {
              do {
                if ((uint)puVar5[4] < 0x212a580) {
                  puVar6 = (undefined4 *)puVar5[2];
                }
                else {
                  puVar6 = (undefined4 *)*puVar5;
                  puStack_20 = puVar5;
                }
                puVar5 = puVar6;
              } while (*(char *)((int)puVar6 + 0xd) == '\0');
              if ((puStack_20 == puVar12) || (&DAT_0212a580 < (undefined *)puStack_20[4]))
              goto LAB_00a64b48;
            }
            else {
LAB_00a64b48:
              puStack_20 = puVar12;
            }
            if (puStack_20 != puVar12) {
              iVar2 = puStack_20[5];
              iVar4 = FUN_0088d870();
              if (iVar2 != iVar4) goto LAB_00a64da9;
              pfVar13 = (float *)(puStack_20 + 7);
              if (puStack_20[6] == 0) {
                pfVar13 = (float *)0x0;
              }
              pfVar7 = (float *)FUN_00b07b60();
              if ((((NAN(*pfVar13) || NAN(*pfVar7)) == (*pfVar13 == *pfVar7)) ||
                  ((NAN(pfVar13[1]) || NAN(pfVar7[1])) == (pfVar13[1] == pfVar7[1]))) ||
                 ((NAN(pfVar13[2]) || NAN(pfVar7[2])) == (pfVar13[2] == pfVar7[2]))) {
                FUN_00a62ed0(&param_2);
                FUN_00a646b0(&DAT_0212a580);
              }
              cStack_13 = '\x01';
              piStack_18 = param_2;
            }
          }
          piVar3 = (int *)(uint)bStack_11;
          if (bStack_11 == 0) {
            piVar3 = (int *)piStack_24[6];
            piVar8 = (int *)piVar3[1];
            piStack_24 = piVar3;
            if (*(char *)(piVar3[1] + 0xd) == '\0') {
              do {
                if ((uint)piVar8[4] < 0x212a5b8) {
                  piVar9 = (int *)piVar8[2];
                }
                else {
                  piVar9 = (int *)*piVar8;
                  piStack_24 = piVar8;
                }
                piVar8 = piVar9;
              } while (*(char *)((int)piVar9 + 0xd) == '\0');
              if ((piStack_24 == piVar3) || (&DAT_0212a5b8 < (undefined *)piStack_24[4]))
              goto LAB_00a64c0d;
            }
            else {
LAB_00a64c0d:
              piStack_24 = piVar3;
            }
            if (piStack_24 == piVar3) {
              piVar3 = (int *)0x0;
            }
            else {
              iVar2 = piStack_24[5];
              iVar4 = FUN_0088d870();
              if (iVar2 != iVar4) {
LAB_00a64da9:
                    /* WARNING: Subroutine does not return */
                FUN_016757c0("Variant cast failed");
              }
              pfVar13 = (float *)(piStack_24 + 7);
              if (piStack_24[6] == 0) {
                pfVar13 = (float *)0x0;
              }
              pfVar7 = (float *)FUN_00b08660();
              if ((((NAN(*pfVar13) || NAN(*pfVar7)) == (*pfVar13 == *pfVar7)) ||
                  ((NAN(pfVar13[1]) || NAN(pfVar7[1])) == (pfVar13[1] == pfVar7[1]))) ||
                 ((NAN(pfVar13[2]) || NAN(pfVar7[2])) == (pfVar13[2] == pfVar7[2]))) {
                FUN_00a62ed0(&param_2);
                FUN_00a646b0(&DAT_0212a5b8);
              }
              piVar3 = (int *)0x1;
              bStack_11 = 1;
              piStack_18 = param_2;
            }
          }
          if (((cStack_12 != '\0') && (cStack_13 != '\0')) && ((char)piVar3 != '\0')) break;
        }
        piVar3 = *(int **)(iStack_1c + 0x6c);
        if (iVar11 == *piVar3) break;
        iVar11 = *(int *)(iVar11 + 4);
      } while( true );
    }
  }
  puVar12 = (undefined4 *)piStack_18[0xb];
  if (puVar12 != (undefined4 *)0x0) {
    piStack_2c = (int *)piStack_18[0xc];
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[1] = piStack_2c[1] + 1;
      UNLOCK();
      piStack_2c = (int *)piStack_18[0xc];
      puVar12 = (undefined4 *)piStack_18[0xb];
    }
    puVar5 = (undefined4 *)puVar12[1];
    puVar6 = (undefined4 *)*puVar12;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piStack_24 = piStack_2c;
    puStack_28 = puVar12;
    piVar3 = piStack_18;
    for (; puVar6 != puVar5; puVar6 = puVar6 + 2) {
      if (puVar6[1] != 0) {
        LOCK();
        piVar3 = (int *)(puVar6[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      piVar3 = (int *)FUN_00a60ca0(iStack_1c,*puVar6,puVar6[1]);
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piVar8 = piStack_2c + 1;
      iVar11 = *piVar8;
      piVar3 = (int *)*piVar8;
      *piVar8 = iVar11 + -1;
      UNLOCK();
      if (iVar11 + -1 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar8 = piStack_2c + 2;
        iVar11 = *piVar8;
        piVar3 = (int *)*piVar8;
        *piVar8 = iVar11 + -1;
        UNLOCK();
        if (iVar11 + -1 == 0) {
          piVar3 = (int *)(**(code **)(*piStack_2c + 4))();
        }
      }
    }
  }
  piVar8 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar9 = param_3 + 1;
    iVar11 = *piVar9;
    piVar3 = (int *)*piVar9;
    *piVar9 = iVar11 + -1;
    UNLOCK();
    if (iVar11 + -1 == 0) {
      piVar3 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar9 = piVar8 + 2;
      iVar11 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar11 == 1) {
        piVar3 = (int *)(**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 21041 ; VA 0x00a64dc0 ; FUN_00a64dc0 */

void FUN_00a64dc0(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar1 = &param_1;
  if (0xf < in_stack_00000018) {
    puVar1 = param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_00a64e40(puVar1);
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    puVar1 = param_1;
    if (0xfff < uVar2) {
      puVar1 = (undefined4 *)param_1[-1];
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21042 ; VA 0x00a64e40 ; FUN_00a64e40 */

void __thiscall FUN_00a64e40(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    iVar2 = param_1;
    if ((iVar1 != 0) && (iVar2 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      iVar2 = FUN_005c8ac0();
    }
    if ((iVar2 != 0) &&
       (iVar1 = *(int *)(iVar2 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_0055e000();
    }
  }
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    iVar2 = param_1;
    if ((iVar1 != 0) && (iVar2 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      iVar2 = FUN_005c8ac0();
    }
    if ((iVar2 != 0) &&
       (iVar1 = *(int *)(iVar2 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_0055e310();
    }
  }
  FUN_00d16030();
  FUN_00d16030();
  if (((*(int *)(param_1 + 0x88) == 0) || (*(int *)(*(int *)(param_1 + 0x88) + 0x68) != 1)) ||
     (DAT_01ee7b0c != 0)) {
    FUN_00a65420(param_2);
  }
  return;
}



/* FUNCTION 21043 ; VA 0x00a64f30 ; FUN_00a64f30 */

int * FUN_00a64f30(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_2 != (int *)0x0) {
    piVar4 = (int *)param_2[0xd];
    piVar6 = param_2;
    if ((piVar4 != (int *)0x0) && (piVar6 = piVar4, piVar4[0xd] != 0)) {
      param_2 = (int *)FUN_005c8ac0();
      piVar6 = param_2;
    }
    if (piVar6 != (int *)0x0) {
      iVar5 = piVar6[3];
      iVar2 = FUN_008a8c30();
      param_2 = (int *)(uint)*(ushort *)(iVar2 + 0x1da);
      if ((int *)((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) <= param_2) {
        FUN_005789c0(&DAT_01eaad54,&LAB_005f4440);
        uVar3 = FUN_005f5590();
        piVar4 = (int *)FUN_008aa140(uVar3);
        param_2 = piVar4;
        if (*piVar4 == 0) {
          if (DAT_01ee7d3c == 0) {
            iVar5 = FUN_00a5e070();
            DAT_01ee7d3c = *(int *)(iVar5 + 4);
          }
          param_2 = (int *)FUN_008a9ba0(auStack_c,DAT_01ee7d3c);
          iVar5 = *param_2;
          iVar2 = param_2[1];
          *param_2 = 0;
          param_2[1] = 0;
          *piVar4 = iVar5;
          piVar6 = (int *)piVar4[1];
          piVar4[1] = iVar2;
          if (piVar6 != (int *)0x0) {
            LOCK();
            piVar1 = piVar6 + 1;
            iVar5 = *piVar1;
            param_2 = (int *)*piVar1;
            *piVar1 = iVar5 + -1;
            UNLOCK();
            if (iVar5 + -1 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              piVar1 = piVar6 + 2;
              iVar5 = *piVar1;
              param_2 = (int *)*piVar1;
              *piVar1 = iVar5 + -1;
              UNLOCK();
              if (iVar5 + -1 == 0) {
                param_2 = (int *)(**(code **)(*piVar6 + 4))();
              }
            }
          }
          if (piStack_8 != (int *)0x0) {
            LOCK();
            piVar6 = piStack_8 + 1;
            iVar5 = *piVar6;
            param_2 = (int *)*piVar6;
            *piVar6 = iVar5 + -1;
            UNLOCK();
            if (iVar5 + -1 == 0) {
              param_2 = (int *)(**(code **)*piStack_8)();
              LOCK();
              piVar6 = piStack_8 + 2;
              iVar5 = *piVar6;
              *piVar6 = *piVar6 + -1;
              UNLOCK();
              if (iVar5 == 1) {
                param_2 = (int *)(**(code **)(*piStack_8 + 4))();
              }
            }
          }
        }
        if (*piVar4 != 0) {
          param_2 = (int *)FUN_00a64e40(param_1);
        }
      }
    }
  }
  return param_2;
}



/* FUNCTION 21044 ; VA 0x00a65050 ; FUN_00a65050 */

void __fastcall FUN_00a65050(int param_1)

{
  uint uVar1;
  
  if (*(char *)(param_1 + 0x81) == '\0') {
    return;
  }
  FUN_00a65420(&DAT_01943f60);
  uVar1 = *(uint *)(param_1 + 0x70);
  while (1 < uVar1) {
    FUN_00a633e0();
    uVar1 = *(uint *)(param_1 + 0x70);
  }
  FUN_006eccd0();
  return;
}



/* FUNCTION 21045 ; VA 0x00a6508b ; FUN_00a6508b */

void FUN_00a6508b(void)

{
  FUN_00a650a0();
  return;
}



/* FUNCTION 21046 ; VA 0x00a650a0 ; FUN_00a650a0 */

void __fastcall FUN_00a650a0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00a5fa10(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c848bc);
}



/* FUNCTION 21047 ; VA 0x00a650d0 ; FUN_00a650d0 */

uint __thiscall FUN_00a650d0(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  uint *puVar6;
  uint *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  int *piVar10;
  int *piVar11;
  undefined auStack_30 [4];
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  uint uStack_1c;
  int iStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7090;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x24);
  if (uVar3 != 0) {
    uVar1 = *(uint *)(uVar3 + 0x34);
    uVar8 = uVar3;
    ExceptionList = &pvStack_10;
    iStack_18 = param_1;
    if ((uVar1 != 0) && (uVar8 = uVar1, ExceptionList = &pvStack_10, *(int *)(uVar1 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      uVar3 = FUN_005c8ac0();
      uVar8 = uVar3;
    }
    if (uVar8 != 0) {
      iVar2 = *(int *)(uVar8 + 0xc);
      iVar4 = FUN_008a8c30();
      uVar3 = (uint)*(ushort *)(iVar4 + 0x1da);
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <= uVar3) {
        FUN_005789c0(&DAT_01ea8ad8,&LAB_0055d5d0);
        uVar5 = FUN_00560f40();
        puVar6 = (uint *)FUN_008aa140(uVar5);
        puStack_14 = puVar6;
        if (*puVar6 == 0) {
          uVar5 = FUN_008aa950();
          puVar7 = (uint *)FUN_008a9ba0(&piStack_28,uVar5);
          puVar6 = puStack_14;
          uVar3 = *puVar7;
          uVar1 = puVar7[1];
          *puVar7 = 0;
          puVar7[1] = 0;
          *puStack_14 = uVar3;
          piVar10 = (int *)puStack_14[1];
          puStack_14[1] = uVar1;
          if (piVar10 != (int *)0x0) {
            LOCK();
            iVar2 = piVar10[1] + -1;
            piVar10[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piVar10)();
              LOCK();
              iVar2 = piVar10[2] + -1;
              piVar10[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar10 + 4))();
              }
            }
          }
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_24[1] + -1;
            piStack_24[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_24)();
              LOCK();
              iVar2 = piStack_24[2] + -1;
              piStack_24[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_24 + 4))();
              }
            }
          }
        }
        uVar3 = *puVar6;
        if ((uVar3 != 0) && (uVar3 = FUN_005c33c0(uVar3), uVar3 != 0)) {
          uStack_1c = uVar3;
          puStack_14 = (uint *)FUN_01674e20(0x18);
          if (puStack_14 == (uint *)0x0) {
            puStack_14 = (uint *)0x0;
          }
          else {
            ((int *)puStack_14)[1] = 1;
            ((int *)puStack_14)[2] = 1;
            *puStack_14 = (uint)std::
                                _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                                ::vftable;
            ((int *)puStack_14)[3] = 0;
            ((int *)puStack_14)[4] = 0;
            ((int *)puStack_14)[5] = 0;
          }
          piStack_28 = (int *)(puStack_14 + 3);
          iStack_8 = 0;
          piStack_24 = (int *)puStack_14;
          puVar6 = puStack_14;
          if (*(int *)(iStack_18 + 8) == 0) {
            puVar9 = (undefined4 *)0x0;
          }
          else {
            puVar9 = *(undefined4 **)(*(int *)(iStack_18 + 0x14) + *(int *)(iStack_18 + 4) * 4);
          }
          for (; puStack_14 = puVar6, puVar9 != (undefined4 *)0x0; puVar9 = (undefined4 *)*puVar9) {
            if ((((puVar9[4] != 0) &&
                 (iVar2 = *(int *)(puVar9[4] + 0xc), iVar4 = FUN_00aff8c0(),
                 (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
                 (uint)*(ushort *)(iVar4 + 0x1da))) ||
                ((puVar9[4] != 0 &&
                 (iVar2 = *(int *)(puVar9[4] + 0xc), iVar4 = FUN_00b63e30(),
                 (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
                 (uint)*(ushort *)(iVar4 + 0x1da))))) && (puVar9[6] == (param_2 ^ 1) * 2 + 1)) {
              uVar5 = FUN_0060dcd0(auStack_30,puVar9[4]);
              iStack_8._0_1_ = 1;
              FUN_00a5f190(auStack_20,*piStack_28,uVar5);
              piVar10 = piStack_2c;
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              if (piStack_2c != (int *)0x0) {
                LOCK();
                iVar2 = piStack_2c[1] + -1;
                piStack_2c[1] = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)*piStack_2c)();
                  LOCK();
                  piVar11 = piVar10 + 2;
                  iVar2 = *piVar11 + -1;
                  *piVar11 = iVar2;
                  UNLOCK();
                  if (iVar2 == 0) {
                    (**(code **)(*piVar10 + 4))();
                  }
                }
              }
            }
            puVar6 = puStack_14;
          }
          if (*piStack_28 == piStack_28[1]) {
            if (*(int *)(iStack_18 + 0x20) != 0) {
              LOCK();
              piVar10 = (int *)(*(int *)(iStack_18 + 0x20) + 4);
              *piVar10 = *piVar10 + 1;
              UNLOCK();
            }
            piVar10 = *(int **)(iStack_18 + 0x1c);
            piVar11 = *(int **)(iStack_18 + 0x20);
          }
          else {
            piVar10 = piStack_28;
            piVar11 = (int *)puVar6;
            if (puVar6 != (uint *)0x0) {
              LOCK();
              ((int *)puVar6)[1] = ((int *)puVar6)[1] + 1;
              UNLOCK();
            }
          }
          uVar3 = FUN_009e0d10(piVar10,piVar11);
          if (puVar6 != (uint *)0x0) {
            LOCK();
            puVar7 = (uint *)((int *)puVar6 + 1);
            uVar1 = *puVar7;
            uVar3 = *puVar7;
            *puVar7 = uVar1 - 1;
            UNLOCK();
            if (uVar1 - 1 == 0) {
              uVar3 = (**(code **)*puVar6)();
              LOCK();
              piVar10 = (int *)puVar6 + 2;
              iVar2 = *piVar10;
              *piVar10 = *piVar10 + -1;
              UNLOCK();
              if (iVar2 == 1) {
                uVar3 = (**(code **)(*puVar6 + 4))();
              }
            }
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 21048 ; VA 0x00a653e0 ; FUN_00a653e0 */

void __thiscall FUN_00a653e0(int param_1,char param_2)

{
  if ((param_2 != *(char *)(param_1 + 0x81)) && (*(char *)(param_1 + 0x80) == '\0')) {
    *(char *)(param_1 + 0x81) = param_2;
    if (param_2 != '\0') {
      FUN_00a61d50();
      return;
    }
    FUN_00a62c00();
  }
  return;
}



/* FUNCTION 21049 ; VA 0x00a65420 ; FUN_00a65420 */

void __thiscall FUN_00a65420(undefined4 *param_1,char *param_2)

{
  int *piVar1;
  uint uVar2;
  bool bVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  char cVar8;
  char *pcVar9;
  int *piVar10;
  undefined4 *puVar11;
  undefined *puVar12;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1cf8;
  pvStack_10 = ExceptionList;
  piStack_24 = (int *)0x0;
  cVar8 = *(char *)((int)param_1 + 0x81);
  if (cVar8 != '\0') {
    ExceptionList = &pvStack_10;
    puStack_20 = param_1;
    if (((DAT_01ee7b0c == 1) && (ExceptionList = &pvStack_10, *(int *)((int)param_1 + 0x88) != 0))
       && (ExceptionList = &pvStack_10, *(int *)(*(int *)((int)param_1 + 0x88) + 0x68) == 1)) {
      uVar5 = *(undefined4 *)(*(int *)((int)param_1 + 0x5c) + 0x1b8);
      puVar12 = auStack_18;
      ExceptionList = &pvStack_10;
      uVar4 = FUN_0060dcd0(puVar12,uVar5);
      uStack_8 = 0;
      FUN_00557f90(uVar4);
      FUN_00a64960(puVar12,uVar5);
      uStack_8 = 0xffffffff;
      FUN_00550b30();
      cVar8 = *(char *)((int)param_1 + 0x81);
    }
    if (cVar8 != '\0') {
      piVar10 = *(int **)((int)param_1 + 0x6c);
      puStack_1c = (undefined4 *)((int)param_1 + 0x6c);
      piVar6 = *(int **)((int)param_1 + 0x74);
      if (piVar6 != piVar10) {
        do {
          if (*(int **)((int)param_1 + 0x7c) == piVar6) {
            *(int **)((int)param_1 + 0x7c) = piVar10;
            break;
          }
          piVar6 = (int *)*piVar6;
        } while (piVar6 != piVar10);
        piVar10 = (int *)*puStack_1c;
        piVar6 = *(int **)((int)param_1 + 0x74);
        piStack_14 = piVar10;
        if (piVar6 != piVar10) {
          do {
            FUN_00a5f110(piVar6[2]);
            piVar6 = (int *)*piVar6;
          } while (piVar6 != piVar10);
          piVar10 = *(int **)((int)param_1 + 0x6c);
          piVar6 = *(int **)((int)param_1 + 0x74);
        }
        puVar11 = (undefined4 *)((int)param_1 + 0x6c);
        piStack_14 = piVar10;
        if (piVar6 == (int *)*piVar10) {
          FUN_0087de00();
        }
        else {
          while (piVar6 != piVar10) {
            piVar1 = (int *)*piVar6;
            *(int **)piVar6[1] = piVar1;
            *(int *)(*piVar6 + 4) = piVar6[1];
            puVar11[1] = puVar11[1] + -1;
            FUN_01674ea0(piVar6,0xc);
            puVar11 = puStack_1c;
            piVar6 = piVar1;
            param_1 = puStack_20;
          }
        }
        *(undefined4 *)((int)param_1 + 0x74) = *(undefined4 *)((int)param_1 + 0x6c);
        *(undefined4 *)((int)param_1 + 0x78) = *(undefined4 *)(*(int *)((int)param_1 + 0x6c) + 4);
        FUN_00a62620();
      }
      uVar2 = *(uint *)((int)param_1 + 0x70);
      while ((3 < uVar2 && ((0xfa < uVar2 || (0xfa00000 < *(int *)((int)param_1 + 0x84)))))) {
        FUN_00a633e0();
        uVar2 = *(uint *)((int)param_1 + 0x70);
      }
    }
    iVar7 = *(int *)((int)param_1 + 0x68);
    if (iVar7 != 0) {
      if (*(int *)(iVar7 + 8) == 0) {
        piVar10 = (int *)0x0;
      }
      else {
        piVar10 = *(int **)(*(int *)(iVar7 + 0x14) + *(int *)(iVar7 + 4) * 4);
      }
      if (piVar10 != (int *)0x0) {
LAB_00a655b3:
        if (piVar10[6] == 0) goto code_r0x00a655b9;
        pcVar9 = param_2;
        do {
          cVar8 = *pcVar9;
          pcVar9 = pcVar9 + 1;
        } while (cVar8 != '\0');
        FUN_005542c0(param_2,(int)pcVar9 - (int)(param_2 + 1));
        iVar7 = *(int *)((int)param_1 + 0x6c);
        puStack_20 = *(undefined4 **)(iVar7 + 4);
        uVar5 = FUN_00602bf0(iVar7,puStack_20,(int *)((int)param_1 + 0x68));
        if (*(int *)((int)param_1 + 0x70) == 0x15555554) {
                    /* WARNING: Subroutine does not return */
          FUN_016ddcd9("list<T> too long");
        }
        *(int *)((int)param_1 + 0x70) = *(int *)((int)param_1 + 0x70) + 1;
        *(undefined4 *)(iVar7 + 4) = uVar5;
        *puStack_20 = uVar5;
        FUN_00a62620();
        *(undefined4 *)((int)param_1 + 0x74) = *(undefined4 *)((int)param_1 + 0x6c);
        *(undefined4 *)((int)param_1 + 0x78) = *(undefined4 *)(*(int *)((int)param_1 + 0x6c) + 4);
        puStack_20 = (undefined4 *)FUN_005c33c0(param_1);
        piVar10 = piStack_24;
        if (puStack_20 == (undefined4 *)0x0) {
LAB_00a65662:
          bVar3 = false;
        }
        else {
          piVar6 = (int *)FUN_0085e880(&uStack_28);
          piVar10 = (int *)0x1;
          if (*piVar6 == 0) goto LAB_00a65662;
          bVar3 = true;
        }
        if (((uint)piVar10 & 1) != 0) {
          FUN_00550b30();
        }
        if (bVar3) {
          iVar7 = *(int *)((int)param_1 + 0x68);
          FUN_0085e880(&uStack_28);
          if (piStack_24 != (int *)0x0) {
            LOCK();
            piStack_24[1] = piStack_24[1] + 1;
            UNLOCK();
          }
          *(undefined4 *)(iVar7 + 0x1c) = uStack_28;
          piVar10 = *(int **)(iVar7 + 0x20);
          *(int **)(iVar7 + 0x20) = piStack_24;
          if (piVar10 != (int *)0x0) {
            LOCK();
            iVar7 = piVar10[1] + -1;
            piVar10[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piVar10)();
              LOCK();
              iVar7 = piVar10[2] + -1;
              piVar10[2] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)(*piVar10 + 4))();
              }
            }
          }
          piVar10 = piStack_24;
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar7 = piStack_24[1] + -1;
            piStack_24[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piStack_24)();
              LOCK();
              piVar6 = piVar10 + 2;
              iVar7 = *piVar6;
              *piVar6 = *piVar6 + -1;
              UNLOCK();
              if (iVar7 == 1) {
                (**(code **)(*piVar10 + 4))();
              }
            }
          }
        }
        iVar7 = FUN_01674e20(0x40);
        if (iVar7 == 0) {
          uVar5 = 0;
        }
        else {
          uVar5 = FUN_00a5fcf0(param_1);
        }
        *(undefined4 *)((int)param_1 + 0x68) = uVar5;
      }
    }
LAB_00a6570e:
    FUN_006eccd0();
  }
  ExceptionList = pvStack_10;
  return;
code_r0x00a655b9:
  piVar10 = (int *)*piVar10;
  if (piVar10 == (int *)0x0) goto LAB_00a6570e;
  goto LAB_00a655b3;
}



/* FUNCTION 21050 ; VA 0x00a65740 ; FUN_00a65740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a65740(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1d26;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee7dac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee7dac);
    if (DAT_01ee7dac == -1) {
      uStack_8 = 0;
      FUN_009ca470("RuntimeUndoBehavior");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee7d48 =
           RBX::Reflection::EnumDesc<enum_RBX::ChangeHistoryService::RuntimeUndoBehavior>::vftable;
      FUN_009caf20(&DAT_01d66198,3);
      FUN_016f3654(&LAB_0188a2f0);
      FUN_016f37bf(&DAT_01ee7dac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee7d48;
}



/* FUNCTION 21051 ; VA 0x00a657f0 ; FUN_00a657f0 */

void FUN_00a657f0(void)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  int iStack_108;
  undefined auStack_104 [200];
  undefined auStack_3c [20];
  int iStack_28;
  int iStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1d43;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffee4;
  ExceptionList = &pvStack_10;
  FUN_00a63090(&iStack_28);
  iStack_18 = iStack_24 - iStack_28 >> 2;
  while (iStack_18 != 0) {
    uStack_8 = 1;
    iVar5 = *(int *)(iStack_28 + -4 + iStack_18 * 4);
    iVar2 = *(int *)(iVar5 + 0xc);
    if (iVar2 == 1) {
      if (*(int *)(iVar5 + 8) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(iVar5 + 8) + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      iVar2 = FUN_00a63170(*(undefined4 *)(iVar5 + 4),*(undefined4 *)(iVar5 + 8));
      if (iVar2 != 0) {
        FUN_00a646b0(iVar2);
      }
      FUN_008a65e0(0,0);
    }
    else if (iVar2 == 2) {
      FUN_00a5f680(auStack_3c,**(undefined4 **)(iVar5 + 0x18),*(undefined4 **)(iVar5 + 0x18),
                   FUN_00a65ed0,iVar5);
      if (*(int *)(iVar5 + 0x28) == 0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        puVar6 = *(undefined4 **)(*(int *)(iVar5 + 0x34) + *(int *)(iVar5 + 0x24) * 4);
      }
      for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
        FUN_00a66040(puVar6 + 2);
      }
    }
    else if (iVar2 == 3) {
      FUN_00a65aa0();
    }
    if (*(char *)(iVar5 + 0x3c) != '\0') {
      *(undefined *)(iVar5 + 0x3c) = 0;
    }
    if (*(char *)(iVar5 + 0x44) == '\0') {
      iStack_18 = iStack_18 + -1;
    }
    else {
      *(undefined *)(iVar5 + 0x44) = 0;
      iStack_18 = iStack_18 + -1;
    }
  }
  uVar8 = 0;
  iStack_18 = 0;
  do {
    uStack_8 = 0;
    uStack_1c = uVar8;
    if ((uint)(iStack_24 - iStack_28 >> 2) <= uVar8) {
      FUN_00a650d0(0);
      if (iStack_28 != 0) {
        uVar8 = iStack_20 - iStack_28 & 0xfffffffc;
        iVar5 = iStack_28;
        if (0xfff < uVar8) {
          iVar5 = *(int *)(iStack_28 + -4);
          uVar8 = uVar8 + 0x23;
          if (0x1f < (iStack_28 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar5,uVar8);
      }
      ExceptionList = pvStack_10;
      return;
    }
    uStack_8._0_1_ = 3;
    uStack_8._1_3_ = 0;
    iVar5 = *(int *)(iStack_28 + uVar8 * 4);
    puVar6 = *(undefined4 **)(iVar5 + 0x18);
    puVar3 = (undefined4 *)puVar6[1];
    puVar7 = puVar6;
    if (*(char *)((int)puVar6[1] + 0xd) == '\0') {
      do {
        if ((uint)puVar3[4] < 0x212a430) {
          puVar4 = (undefined4 *)puVar3[2];
        }
        else {
          puVar4 = (undefined4 *)*puVar3;
          puVar7 = puVar3;
        }
        puVar3 = puVar4;
      } while (*(char *)((int)puVar4 + 0xd) == '\0');
      if ((puVar7 == puVar6) || (&DAT_0212a430 < (undefined4 *)puVar7[4])) goto LAB_00a65987;
    }
    else {
LAB_00a65987:
      puVar7 = puVar6;
    }
    iStack_18 = iVar5;
    if (puVar7 != puVar6) {
      uStack_110 = puVar7[4];
      uStack_10c = puVar7[5];
      iStack_108 = 0;
      if ((undefined4 *)puVar7[6] != (undefined4 *)0x0) {
        (**(code **)puVar7[6])(puVar7 + 7,auStack_104);
      }
      iVar5 = iStack_18;
      iStack_108 = puVar7[6];
      uStack_8._0_1_ = 4;
      FUN_00a65ed0(&uStack_110);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (iStack_108 != 0) {
        (**(code **)(iStack_108 + 8))(auStack_104);
      }
    }
    if (*(char *)(iVar5 + 0x3c) != '\0') {
      *(undefined *)(iVar5 + 0x3c) = 0;
    }
    uVar8 = uVar8 + 1;
  } while( true );
}



/* FUNCTION 21052 ; VA 0x00a6590b ; Catch@00a6590b */

undefined * Catch_00a6590b(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x2c) + 4))(6);
  FUN_0086edd0(2,uVar1);
  return &DAT_00a65928;
}



/* FUNCTION 21053 ; VA 0x00a65a03 ; Catch@00a65a03 */

undefined * Catch_00a65a03(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x30) + 4))(6);
  FUN_0086edd0(2,uVar1);
  return &DAT_00a65a20;
}



/* FUNCTION 21054 ; VA 0x00a65aa0 ; FUN_00a65aa0 */

void __fastcall FUN_00a65aa0(int *param_1)

{
  uint *puVar1;
  uint *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  byte *pbVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uStack_10c;
  uint uStack_108;
  undefined4 *puStack_104;
  undefined auStack_100 [200];
  int *piStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1d63;
  pvStack_10 = ExceptionList;
  piStack_28 = (int *)0x0;
  iStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  iStack_18 = 0;
  ExceptionList = &pvStack_10;
  piStack_38 = param_1;
  piStack_28 = (int *)FUN_01674e20(8);
  *piStack_28 = 0;
  piStack_28[1] = 0;
  *piStack_28 = (int)&piStack_28;
  puStack_14 = (uint *)param_1[1];
  iVar6 = *(int *)(*param_1 + 0x78);
  iStack_8 = 0;
  pbVar5 = *(byte **)(iVar6 + 8) + **(byte **)(iVar6 + 8) + 1;
  FUN_00606ea0(&iStack_2c,((uint)puStack_14 >> 3) + (int)puStack_14,&puStack_14,
               -(uint)(pbVar5 != (byte *)0x0) & (uint)(pbVar5 + 1));
  iVar7 = iStack_18;
  if (iStack_2c != 0) {
    iStack_2c = iStack_2c + 0xc;
  }
  do {
    do {
      if (iVar6 == **(int **)(*piStack_38 + 0x6c)) {
LAB_00a65c5c:
        if (iVar7 != 0) {
          do {
            FUN_00a642e0();
            iStack_18 = iStack_18 + -1;
          } while (iStack_18 != 0);
          uStack_1c = 0;
          iStack_18 = 0;
        }
        if (iStack_2c != 0) {
          puVar1 = *(uint **)(iStack_2c + 0x18);
          puVar2 = (uint *)*puVar1;
          while (puStack_14 = puVar2, puVar2 != puVar1) {
            uStack_10c = puVar2[4];
            uStack_108 = puVar2[5];
            puVar4 = (undefined4 *)puVar2[6];
            puStack_104 = (undefined4 *)0x0;
            if (puVar4 != (undefined4 *)0x0) {
              (*(code *)*puVar4)(puVar2 + 7,auStack_100);
              puVar4 = (undefined4 *)puVar2[6];
            }
            iStack_8._0_1_ = 1;
            puStack_104 = puVar4;
            FUN_00a61be0(&uStack_10c);
            iStack_8._0_1_ = 2;
            if (puStack_104 != (undefined4 *)0x0) {
              (*(code *)puStack_104[2])(auStack_100);
            }
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_00551320();
            puVar2 = puStack_14;
          }
        }
        FUN_00611300();
        ExceptionList = pvStack_10;
        return;
      }
      iVar6 = *(int *)(iVar6 + 4);
      puStack_14 = (uint *)piStack_38[1];
      pbVar5 = *(byte **)(iVar6 + 8) + **(byte **)(iVar6 + 8) + 1;
      iStack_30 = ((uint)puStack_14 >> 3) + (int)puStack_14;
      FUN_00606ea0(&iStack_34,iStack_30,&puStack_14,
                   -(uint)(pbVar5 != (byte *)0x0) & (uint)(pbVar5 + 1));
    } while ((iStack_34 == 0) || (iStack_30 = iStack_34 + 0xc, iStack_30 == 0));
    if ((*(int *)(iStack_34 + 0x18) == 1) || (*(int *)(iStack_34 + 0x18) == 4)) {
      FUN_00a642e0();
      iVar7 = iStack_18;
      goto LAB_00a65c5c;
    }
    if (((iVar7 + uStack_1c & 3) == 0) && (uStack_20 <= iVar7 + 4U >> 2)) {
      FUN_006a2af0(1);
      iVar7 = iStack_18;
    }
    uStack_1c = uStack_1c & uStack_20 * 4 - 1;
    uVar8 = iVar7 + uStack_1c;
    puStack_14 = (uint *)((uStack_20 - 1 & uVar8 >> 2) * 4);
    if (*(int *)(iStack_24 + (int)puStack_14) == 0) {
      uVar3 = FUN_01674e20(0x10);
      *(undefined4 *)(iStack_24 + (int)puStack_14) = uVar3;
    }
    *(int *)(*(int *)(iStack_24 + (int)puStack_14) + (uVar8 & 3) * 4) = iStack_30;
    iStack_18 = iStack_18 + 1;
    iVar7 = iStack_18;
  } while( true );
}



/* FUNCTION 21055 ; VA 0x00a65d80 ; FUN_00a65d80 */

void __fastcall FUN_00a65d80(int param_1)

{
  undefined4 uVar1;
  undefined *puVar2;
  char *pcVar3;
  undefined auStack_38 [12];
  undefined auStack_2c [12];
  undefined auStack_20 [4];
  undefined *puStack_1c;
  undefined uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1cc0;
  pvStack_10 = ExceptionList;
  puVar2 = (undefined *)(param_1 + 0x80);
  if (*(char *)(param_1 + 0x80) == '\0') {
    if (*(char *)(param_1 + 0x81) != '\0') {
      if (*(int *)(param_1 + 0x78) != **(int **)(param_1 + 0x6c)) {
        uStack_18 = 0;
        ExceptionList = &pvStack_10;
        *puVar2 = 1;
        uStack_8 = 0;
        puStack_1c = puVar2;
        if (*(int *)(param_1 + 0x68) != 0) {
          FUN_00a612b0(*(int *)(param_1 + 0x68));
          if (*(int *)(param_1 + 0x68) != 0) {
            FUN_00a60f10(1);
          }
          iStack_14 = FUN_01674e20(0x40);
          if (iStack_14 == 0) {
            uVar1 = 0;
          }
          else {
            uVar1 = FUN_00a5fcf0(param_1);
          }
          *(undefined4 *)(param_1 + 0x68) = uVar1;
        }
        FUN_00a657f0();
        FUN_0054ef60(*(int *)(*(int *)(param_1 + 0x78) + 8) + 0x28);
        *(int *)(param_1 + 0x74) = *(int *)(param_1 + 0x78);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        *(undefined4 *)(param_1 + 0x78) = *(undefined4 *)(*(int *)(param_1 + 0x78) + 4);
        FUN_006eccd0();
        FUN_0054ef60(auStack_38);
        FUN_006ecaa0();
        FUN_005507b0();
        if (puVar2 != (undefined *)0x0) {
          *puVar2 = 0;
        }
        ExceptionList = pvStack_10;
        return;
      }
      ExceptionList = &pvStack_10;
      FUN_00550130("Attempt to unplay before the change history");
      puVar2 = auStack_2c;
      goto LAB_00a65ec0;
    }
    pcVar3 = "ChangeHistoryService is disabled";
  }
  else {
    pcVar3 = "ChangeHistoryService is currently playing";
  }
  ExceptionList = &pvStack_10;
  FUN_00550130(pcVar3);
  puVar2 = auStack_20;
LAB_00a65ec0:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(puVar2,&DAT_01c17198);
}



/* FUNCTION 21056 ; VA 0x00a65ed0 ; FUN_00a65ed0 */

void __thiscall FUN_00a65ed0(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  byte *pbVar6;
  int iVar7;
  int iVar8;
  undefined auStack_f4 [8];
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1d7b;
  pvStack_10 = ExceptionList;
  param_2 = (undefined4 *)*param_2;
  iStack_1c = *param_1;
  iVar8 = *(int *)(iStack_1c + 0x78);
  if (iVar8 == **(int **)(iStack_1c + 0x6c)) {
    return;
  }
  uStack_20 = param_1[1];
  iVar7 = (uStack_20 >> 3) + uStack_20;
  ExceptionList = &pvStack_10;
  uStack_14 = uStack_20;
  do {
    iVar8 = *(int *)(iVar8 + 4);
    pbVar6 = *(byte **)(iVar8 + 8) + **(byte **)(iVar8 + 8) + 1;
    FUN_00606ea0(&iStack_18,iVar7,&uStack_14,-(uint)(pbVar6 != (byte *)0x0) & (uint)(pbVar6 + 1));
    if ((iStack_18 != 0) && (iStack_18 != -0xc)) {
      puVar1 = *(undefined4 **)(iStack_18 + 0x24);
      puVar3 = puVar1;
      puVar5 = (undefined4 *)puVar1[1];
      if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
        do {
          puVar4 = puVar5;
          if ((undefined4 *)puVar4[4] < param_2) {
            puVar5 = (undefined4 *)puVar4[2];
            puVar4 = puVar3;
          }
          else {
            puVar5 = (undefined4 *)*puVar4;
          }
          puVar3 = puVar4;
        } while (*(char *)((int)puVar5 + 0xd) == '\0');
        if ((puVar4 == puVar1) || (param_2 < (undefined4 *)puVar4[4])) goto LAB_00a65f7d;
      }
      else {
LAB_00a65f7d:
        puVar4 = puVar1;
      }
      if (puVar4 != puVar1) {
        FUN_00a5e010(puVar4 + 4);
        uStack_8 = 0;
        FUN_00a61be0(auStack_f4);
        uStack_8 = 1;
        if (iStack_ec == 0) {
          ExceptionList = pvStack_10;
          return;
        }
        (**(code **)(iStack_ec + 8))(auStack_e8);
        ExceptionList = pvStack_10;
        return;
      }
      if ((param_2 == &DAT_0211a3d8) &&
         (((iVar2 = *(int *)(iStack_18 + 0x18), iVar2 == 1 || (iVar2 == 2)) || (iVar2 == 4)))) {
        FUN_008a65e0(*(undefined4 *)(iStack_18 + 0x1c),0);
        ExceptionList = pvStack_10;
        return;
      }
    }
    if (iVar8 == **(int **)(iStack_1c + 0x6c)) {
      ExceptionList = pvStack_10;
      return;
    }
  } while( true );
}



/* FUNCTION 21057 ; VA 0x00a66040 ; FUN_00a66040 */

int __thiscall FUN_00a66040(int *param_1,int *param_2)

{
  int *piVar1;
  void **ppvVar2;
  undefined4 uVar3;
  int iVar4;
  byte *pbVar5;
  int iVar6;
  int *piStack_3c;
  undefined8 uStack_38;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1d98;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(*param_1 + 0x78);
  ExceptionList = &pvStack_10;
  ppvVar2 = &pvStack_10;
  piStack_14 = param_1;
  if (iVar4 != **(int **)(*param_1 + 0x6c)) {
    do {
      iVar4 = *(int *)(iVar4 + 4);
      uStack_18 = piStack_14[1];
      pbVar5 = *(byte **)(iVar4 + 8) + **(byte **)(iVar4 + 8) + 1;
      FUN_00606ea0(&iStack_1c,(uStack_18 >> 3) + uStack_18,&uStack_18,
                   -(uint)(pbVar5 != (byte *)0x0) & (uint)(pbVar5 + 1));
      if ((iStack_1c != 0) && (iStack_1c != -0xc)) {
        iVar6 = iStack_1c + 0x2d + (uint)*(byte *)(iStack_1c + 0x2c);
        uVar3 = FUN_00a6ce70(param_2);
        FUN_006e16e0(&iStack_20,uVar3,param_2,-(uint)(iVar6 != 0) & iVar6 + 1U);
        if (iStack_20 != 0) {
          iVar4 = FUN_00a61c70(param_2,iStack_20 + 0x14);
          ExceptionList = pvStack_10;
          return iVar4;
        }
      }
      ppvVar2 = (void **)ExceptionList;
    } while (iVar4 != **(int **)(*piStack_14 + 0x6c));
  }
  ExceptionList = ppvVar2;
  uVar3 = FUN_00a6dba0(8);
  uStack_8 = 0;
  iStack_2c = *param_2 * 8 + 8;
  uStack_38 = CONCAT44(param_2[1] * 8,*param_2 * 8);
  iStack_28 = param_2[1] * 8 + 8;
  iStack_30 = param_2[2] * 8;
  iStack_24 = iStack_30 + 8;
  iVar4 = FUN_00a72960(&uStack_38,uVar3,0);
  if (piStack_3c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_3c + 1;
    iVar6 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar4 = (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar4 = (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21058 ; VA 0x00a661d0 ; FUN_00a661d0 */

int __thiscall FUN_00a661d0(int param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  code *pcVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1dc0;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_4;
  piVar8 = (int *)puVar3[1];
  ExceptionList = &pvStack_10;
  if (piVar8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)puVar3[1];
  }
  piVar9 = *(int **)(param_1 + 8);
  uVar4 = *puVar3;
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
    piVar9 = *(int **)(param_1 + 8);
  }
  uVar5 = *(undefined4 *)(param_1 + 4);
  uStack_8 = 1;
  pcVar6 = (code *)*param_3;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
  }
  iVar7 = (*pcVar6)(uVar5,piVar9,uVar4,piVar8);
  if (piVar9 != (int *)0x0) {
    piVar1 = piVar9 + 1;
    LOCK();
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar9 = piVar8 + 1;
    iVar2 = *piVar9;
    iVar7 = *piVar9;
    *piVar9 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*piVar8)();
      LOCK();
      piVar9 = piVar8 + 2;
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 21059 ; VA 0x00a662e0 ; FUN_00a662e0 */

int __thiscall FUN_00a662e0(int param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  code *pcVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1de0;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_4;
  piVar8 = (int *)puVar3[1];
  ExceptionList = &pvStack_10;
  if (piVar8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)puVar3[1];
  }
  piVar9 = *(int **)(param_1 + 8);
  uVar4 = *puVar3;
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
    piVar9 = *(int **)(param_1 + 8);
  }
  uVar5 = *(undefined4 *)(param_1 + 4);
  uStack_8 = 1;
  pcVar6 = (code *)*param_3;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
  }
  iVar7 = (*pcVar6)(uVar5,piVar9,uVar4,piVar8);
  if (piVar9 != (int *)0x0) {
    piVar1 = piVar9 + 1;
    LOCK();
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar9 = piVar8 + 1;
    iVar2 = *piVar9;
    iVar7 = *piVar9;
    *piVar9 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*piVar8)();
      LOCK();
      piVar9 = piVar8 + 2;
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 21060 ; VA 0x00a663f0 ; FUN_00a663f0 */

undefined4 *
FUN_00a663f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  piVar1 = param_5 + 1;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21061 ; VA 0x00a66510 ; FUN_00a66510 */

undefined4 *
FUN_00a66510(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piVar1 = param_5 + 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a66b10(param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = uStack_18;
  param_1[2] = 0;
  param_1[3] = 0;
  if (piStack_10 != (int *)0x0) {
    LOCK();
    piStack_10[1] = piStack_10[1] + 1;
    UNLOCK();
  }
  param_1[2] = uStack_14;
  param_1[3] = piStack_10;
  param_1[4] = param_7;
  if (piStack_10 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_10[1] + -1;
    piStack_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_10)();
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21062 ; VA 0x00a66650 ; FUN_00a66650 */

undefined4 *
FUN_00a66650(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piVar1 = param_5 + 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a66b10(param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = uStack_14;
  param_1[2] = 0;
  param_1[3] = 0;
  if (piStack_c != (int *)0x0) {
    LOCK();
    piStack_c[1] = piStack_c[1] + 1;
    UNLOCK();
  }
  param_1[2] = uStack_10;
  param_1[3] = piStack_c;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21063 ; VA 0x00a66790 ; FUN_00a66790 */

undefined4 *
FUN_00a66790(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,int *param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  undefined auStack_1c [20];
  int *piStack_8;
  
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  piStack_8 = param_5 + 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piStack_8 = *piStack_8 + 1;
    UNLOCK();
  }
  FUN_00a66b80(param_3,param_4,param_5,param_6,param_7,param_8);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piStack_8;
    *piStack_8 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      iVar2 = param_7[2] + -1;
      param_7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  *param_1 = param_2;
  FUN_00a66ab0(auStack_1c);
  FUN_00a678e0();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21064 ; VA 0x00a668d0 ; FUN_00a668d0 */

void FUN_00a668d0(undefined4 param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_2 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_2 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a66928. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 21065 ; VA 0x00a66930 ; FUN_00a66930 */

void * __thiscall FUN_00a66930(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvVar5;
  int *piVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar7 = *(undefined4 **)(param_1 + 0x2c);
  pvVar5 = ExceptionList;
  if (puVar7 != (undefined4 *)0x0) {
    piVar6 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(param_1 + 0x30);
      puVar7 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar7[1];
    puVar7 = (undefined4 *)*puVar7;
    uStack_8 = 0;
    pvVar5 = pvStack_10;
    for (; puVar7 != puVar3; puVar7 = puVar7 + 2) {
      uVar4 = *(undefined4 *)(param_2 + 4);
      if (puVar7[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar7[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00a67ff0(uVar4,*puVar7,puVar7[1]);
      pvVar5 = (void *)FUN_00a66930(param_2);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar2 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 21066 ; VA 0x00a66a10 ; FUN_00a66a10 */

undefined4 __thiscall
FUN_00a66a10(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  FUN_00a66b10(param_2,param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21067 ; VA 0x00a66ab0 ; FUN_00a66ab0 */

undefined4 * __thiscall FUN_00a66ab0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  return param_1;
}



/* FUNCTION 21068 ; VA 0x00a66b10 ; FUN_00a66b10 */

undefined4 * __thiscall
FUN_00a66b10(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  param_1[1] = param_3;
  param_1[2] = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 21069 ; VA 0x00a66b80 ; FUN_00a66b80 */

int __thiscall
FUN_00a66b80(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  FUN_00a66b10(param_2,param_3,param_4);
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0xc) = param_5;
  *(int **)(param_1 + 0x10) = param_6;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21070 ; VA 0x00a66ca0 ; FUN_00a66ca0 */

undefined4 * __thiscall FUN_00a66ca0(undefined4 *param_1,int param_2,int *param_3,int param_4)

{
  int *piVar1;
  undefined uVar2;
  undefined uVar3;
  char cVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  undefined auStack_80 [4];
  undefined auStack_7c [4];
  undefined *puStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  undefined auStack_68 [4];
  int *piStack_64;
  int iStack_60;
  int *piStack_5c;
  int iStack_54;
  int *piStack_50;
  undefined4 *puStack_4c;
  undefined4 *puStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e1f01;
  pvStack_10 = ExceptionList;
  puStack_20 = param_1;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  piStack_40 = param_1 + 1;
  param_1[2] = 0;
  piStack_44 = param_1 + 2;
  param_1[3] = 0;
  puStack_48 = param_1 + 3;
  puStack_4c = param_1 + 4;
  param_1[4] = 0;
  uStack_8 = 5;
  uStack_7 = 0;
  if (param_2 == 0) {
    piStack_50 = (int *)0x0;
    piVar5 = &iStack_54;
    uVar9 = 2;
    iStack_60 = 0;
  }
  else {
    piVar5 = (int *)FUN_0060dcd0(auStack_68,*(undefined4 *)(param_2 + 0x34));
    uVar9 = 1;
    iStack_60 = *piVar5;
  }
  piVar1 = (int *)piVar5[1];
  piStack_30 = piVar1;
  iStack_18 = iStack_60;
  uStack_14 = uVar9;
  *piVar5 = 0;
  piVar5[1] = 0;
  _uStack_8 = CONCAT31(uStack_7,6);
  piStack_5c = piVar1;
  if (((uVar9 & 2) != 0) &&
     (uVar9 = uVar9 & 0xfffffffd, uStack_14 = uVar9, piStack_50 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_50[1] + -1;
    piStack_50[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      iVar7 = piStack_50[2] + -1;
      piStack_50[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
  }
  if ((uVar9 & 1) != 0) {
    uVar9 = uVar9 & 0xfffffffe;
    piStack_2c = piStack_64;
    uStack_14 = uVar9;
    if (piStack_64 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_64[1] + -1;
      piStack_64[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_64)();
        LOCK();
        iVar7 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
  }
  uStack_1c = uVar9;
  if (((iStack_18 == 0) || (param_2 == 0)) || (param_4 == 0)) {
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar7 = piVar1[1] + -1;
      piVar1[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar7 = piVar1[2] + -1;
        piVar1[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  else {
    piStack_2c = (int *)(iStack_18 + 0x48);
    iStack_28 = CONCAT31(iStack_28._1_3_,DAT_01ee7dc4);
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piVar5 = (int *)FUN_00a66a10(param_4,param_2,param_3,iStack_28);
    puStack_78 = &LAB_00a6815b;
    iStack_74 = *piVar5;
    iStack_6c = piVar5[2];
    if (iStack_6c != 0) {
      LOCK();
      *(int *)(iStack_6c + 4) = *(int *)(iStack_6c + 4) + 1;
      UNLOCK();
      iStack_6c = piVar5[2];
    }
    iStack_70 = piVar5[1];
    piStack_34 = piStack_50;
    piStack_3c = (int *)iStack_70;
    piStack_38 = (int *)iStack_74;
    iStack_28 = iStack_6c;
    if (piStack_50 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_50[1] + -1;
      piStack_50[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_50)();
        LOCK();
        iVar7 = piStack_34[2] + -1;
        piStack_34[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar7 = param_3[1] + -1;
      param_3[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar7 = param_3[2] + -1;
        param_3[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    uStack_8 = 8;
    uVar6 = FUN_01675290(DAT_02110da8);
    uStack_8 = 9;
    piStack_34 = (int *)uVar6;
    piStack_50 = (int *)FUN_01674e20(0x28);
    if (piStack_50 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      *piStack_50 = 0;
      piStack_50[1] = 1;
      piStack_50[2] = (int)FUN_00a68c10;
      piStack_50[3] = (int)FUN_0057e0b0;
      piStack_50[4] = 0;
      piStack_50[5] = (int)piStack_2c;
      piStack_50[6] = (int)&LAB_00a6815b;
      piStack_50[7] = (int)piStack_38;
      piStack_50[8] = 0;
      piStack_50[9] = 0;
      if (iStack_28 != 0) {
        LOCK();
        *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
        UNLOCK();
      }
      piStack_50[8] = (int)piStack_3c;
      piStack_50[9] = iStack_28;
      piVar5 = piStack_50;
    }
    FUN_016797d0(piVar5);
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    uStack_14 = uVar9 | 4;
    uStack_8 = 10;
    piStack_24 = piVar5;
    FUN_01675290(uVar6);
    _uStack_8 = CONCAT31(uStack_7,8);
    cVar4 = FUN_01679300(&piStack_24);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_24);
    }
    uStack_14 = uStack_1c;
    if (piStack_24 != (int *)0x0) {
      piVar5 = piStack_24 + 1;
      LOCK();
      iVar7 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(piStack_24);
      }
    }
    uStack_8 = 6;
    FUN_0056bac0();
    FUN_008a40f0();
    iVar7 = FUN_008a4100();
    uVar3 = DAT_01ee7dc5;
    uVar2 = DAT_01ee7dc4;
    piStack_2c = (int *)(iVar7 + 0x1c);
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piStack_3c = (int *)FUN_00a66650(&puStack_78,&LAB_00a68160,param_4,param_2,param_3,uVar2,uVar3);
    uStack_8 = 0xc;
    uVar6 = FUN_01675290(DAT_02110da8);
    uStack_8 = 0xd;
    piStack_50 = (int *)uVar6;
    piStack_38 = (int *)FUN_01674e20(0x28);
    if (piStack_38 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      *piStack_38 = 0;
      piStack_38[1] = 1;
      piStack_38[2] = (int)FUN_00a68cc0;
      piStack_38[3] = (int)FUN_0057e0b0;
      piStack_38[4] = 0;
      piStack_38[5] = (int)piStack_2c;
      piStack_38[6] = *piStack_3c;
      piStack_38[7] = piStack_3c[1];
      piStack_38[8] = 0;
      piStack_38[9] = 0;
      if (piStack_3c[3] != 0) {
        LOCK();
        piVar5 = (int *)(piStack_3c[3] + 4);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
      piStack_38[8] = piStack_3c[2];
      piStack_38[9] = piStack_3c[3];
      piVar5 = piStack_38;
    }
    FUN_016797d0(piVar5);
    uVar9 = uStack_1c;
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_1c | 8;
    uStack_8 = 0xe;
    piStack_24 = piVar5;
    FUN_01675290(uVar6);
    _uStack_8 = CONCAT31(uStack_7,0xc);
    cVar4 = FUN_01679300(&piStack_24);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_24);
    }
    uStack_14 = uVar9;
    if (piStack_24 != (int *)0x0) {
      piVar5 = piStack_24 + 1;
      LOCK();
      iVar7 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(piStack_24);
      }
    }
    FUN_0056bac0();
    uVar2 = DAT_01ee7dc4;
    piStack_2c = (int *)(iStack_18 + 0x4c);
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piStack_30[1] = piStack_30[1] + 1;
      UNLOCK();
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piStack_40 = (int *)FUN_00a66790(auStack_80,&LAB_00a68160,param_4,param_2,param_3,iStack_18,
                                     piStack_30,uVar2);
    uStack_8 = 0x10;
    uVar6 = FUN_01675290(DAT_02110da8);
    _uStack_8 = CONCAT31(uStack_7,0x11);
    piStack_50 = (int *)uVar6;
    piVar5 = (int *)FUN_01674e20(0x30);
    piStack_3c = piVar5;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      *piVar5 = 0;
      piVar5[1] = 1;
      piVar5[2] = (int)FUN_00a68e40;
      piVar5[3] = (int)FUN_00a68eb0;
      piVar5[4] = 0;
      piVar5[5] = (int)piStack_2c;
      piVar5[6] = *piStack_40;
      FUN_00a66ab0(piStack_40 + 1);
    }
    FUN_016797d0(piVar5);
    uVar9 = uStack_1c;
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_1c | 0x10;
    uStack_8 = 0x12;
    piStack_24 = piVar5;
    FUN_01675290(uVar6);
    _uStack_8 = CONCAT31(uStack_7,0x10);
    cVar4 = FUN_01679300(&piStack_24);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_24);
    }
    uStack_14 = uVar9;
    if (piStack_24 != (int *)0x0) {
      piVar5 = piStack_24 + 1;
      LOCK();
      iVar7 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(piStack_24);
      }
    }
    uStack_8 = 6;
    FUN_00a678e0();
    FUN_008a40f0();
    iVar7 = FUN_008a4100();
    uVar2 = DAT_01ee7dc4;
    piStack_2c = (int *)(iVar7 + 0x14);
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piStack_44 = (int *)FUN_00a66510(auStack_7c,&LAB_00a68160,param_4,param_2,param_3,uVar2,0);
    uStack_8 = 0x14;
    uVar6 = FUN_01675290(DAT_02110da8);
    uStack_8 = 0x15;
    piStack_50 = (int *)uVar6;
    piStack_40 = (int *)FUN_01674e20(0x2c);
    if (piStack_40 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      *piStack_40 = 0;
      piStack_40[1] = 1;
      piStack_40[2] = (int)FUN_00a68d80;
      piStack_40[3] = (int)FUN_0057e0b0;
      piStack_40[4] = 0;
      piStack_40[5] = (int)piStack_2c;
      piStack_40[6] = *piStack_44;
      piStack_40[7] = piStack_44[1];
      piStack_40[8] = 0;
      piStack_40[9] = 0;
      if (piStack_44[3] != 0) {
        LOCK();
        piVar5 = (int *)(piStack_44[3] + 4);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
      piStack_40[8] = piStack_44[2];
      piStack_40[9] = piStack_44[3];
      piStack_40[10] = piStack_44[4];
      piVar5 = piStack_40;
    }
    FUN_016797d0(piVar5);
    uVar9 = uStack_1c;
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_1c | 0x20;
    uStack_8 = 0x16;
    piStack_24 = piVar5;
    FUN_01675290(uVar6);
    _uStack_8 = CONCAT31(uStack_7,0x14);
    cVar4 = FUN_01679300(&piStack_24);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_24);
    }
    uStack_14 = uVar9;
    if (piStack_24 != (int *)0x0) {
      piVar5 = piStack_24 + 1;
      LOCK();
      iVar7 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(piStack_24);
      }
    }
    uStack_8 = 6;
    FUN_0056bac0();
    iVar7 = iStack_18;
    FUN_008a40f0();
    iVar8 = FUN_008a4100();
    uVar2 = DAT_01ee7dc4;
    piStack_2c = (int *)(iVar8 + 0xc);
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piStack_30[1] = piStack_30[1] + 1;
      UNLOCK();
    }
    piVar5 = (int *)FUN_00a663f0(&puStack_78,&LAB_0089c009,param_4,iVar7,piStack_30,uVar2);
    uStack_8 = 0x18;
    uVar6 = FUN_01675290(DAT_02110da8);
    uStack_8 = 0x19;
    piStack_50 = (int *)FUN_01674e20(0x28);
    if (piStack_50 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      *piStack_50 = 0;
      piStack_50[1] = 1;
      piStack_50[2] = (int)FUN_00a68ae0;
      piStack_50[3] = (int)FUN_0057e0b0;
      piStack_50[4] = 0;
      piStack_50[5] = (int)piStack_2c;
      piStack_50[6] = *piVar5;
      piStack_50[7] = piVar5[1];
      piStack_50[8] = 0;
      piStack_50[9] = 0;
      if (piVar5[3] != 0) {
        LOCK();
        piVar1 = (int *)(piVar5[3] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      piStack_50[8] = piVar5[2];
      piStack_50[9] = piVar5[3];
      piVar5 = piStack_50;
    }
    FUN_016797d0(piVar5);
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_1c | 0x40;
    uStack_8 = 0x1a;
    piStack_24 = piVar5;
    FUN_01675290(uVar6);
    _uStack_8 = CONCAT31(uStack_7,0x18);
    cVar4 = FUN_01679300(&piStack_24);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_24);
    }
    if (piStack_24 != (int *)0x0) {
      piVar5 = piStack_24 + 1;
      LOCK();
      iVar7 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(piStack_24);
      }
    }
    FUN_0056bac0();
    FUN_00550b30();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar7 = param_3[1] + -1;
    param_3[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar5 = param_3 + 2;
      iVar7 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puStack_20;
}



/* FUNCTION 21071 ; VA 0x00a675e0 ; FUN_00a675e0 */

undefined4 * __thiscall FUN_00a675e0(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  int iStack_2c;
  int *piStack_28;
  undefined4 *puStack_24;
  code *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1f7b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::PackageManager::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = *param_2;
  param_1[2] = param_2[1];
  uStack_8 = 0;
  puStack_18 = param_1;
  if ((-(uint)(*param_2 != 0) & *param_2 + 0xcU) == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_005f4f20();
  }
  puVar4 = (undefined4 *)FUN_0060dcd0(&iStack_2c,uVar3);
  piVar1 = piStack_28;
  param_1[3] = 0;
  param_1[4] = 0;
  if (puVar4[1] != 0) {
    LOCK();
    piVar2 = (int *)(puVar4[1] + 8);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  param_1[3] = *puVar4;
  param_1[4] = puVar4[1];
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_28[1] + -1;
    piStack_28[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar5 = *piVar2 + -1;
      *piVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  *(undefined *)(param_1 + 5) = 0;
  uVar3 = FUN_00588320(0xb);
  param_1[6] = uVar3;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  param_1[9] = 0;
  param_1[10] = 0;
  *(undefined *)(param_1 + 0xb) = 0;
  uVar3 = FUN_00588320(0xb);
  param_1[0xc] = uVar3;
  param_1[0xd] = 0;
  param_1[0xe] = 0x3f800000;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  FUN_016dee4c(param_1 + 0x11,2);
  *(undefined *)(param_1 + 0x1d) = 0;
  uVar3 = FUN_00588320(0xb);
  param_1[0x1e] = uVar3;
  param_1[0x1f] = 0;
  param_1[0x20] = 0x3f800000;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  FUN_00a68ec0(&iStack_2c);
  uStack_8._0_1_ = 6;
  if (iStack_2c == 0) {
    if (piStack_28 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    LOCK();
    iVar5 = piStack_28[1] + -1;
    piStack_28[1] = iVar5;
    UNLOCK();
    if (iVar5 != 0) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)*piStack_28)();
    LOCK();
    piVar1 = piStack_28 + 2;
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 != 1) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    iVar5 = *piStack_28;
  }
  else {
    pcStack_20 = FUN_00a69480;
    puStack_1c = param_1;
    FUN_00a66930(&pcStack_20);
    iVar5 = FUN_008a4100();
    uStack_8._0_1_ = 7;
    uVar3 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 8;
    puStack_1c = (undefined4 *)uVar3;
    puStack_24 = (undefined4 *)FUN_01674e20(0x20);
    if (puStack_24 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puStack_24 = 0;
      puStack_24[1] = 1;
      puStack_24[2] = FUN_00a68a50;
      puStack_24[3] = _guard_check_icall;
      puStack_24[4] = 0;
      puStack_24[5] = iVar5 + 0x10;
      puStack_24[6] = FUN_00a69480;
      puStack_24[7] = param_1;
      puVar4 = puStack_24;
    }
    FUN_016797d0(puVar4);
    if (puVar4 != (undefined4 *)0x0) {
      LOCK();
      puVar4[1] = puVar4[1] + 1;
      UNLOCK();
    }
    uStack_14 = 1;
    uStack_8._0_1_ = 9;
    puStack_24 = puVar4;
    FUN_01675290(uVar3);
    if (puVar4 != (undefined4 *)0x0) {
      piVar1 = puVar4 + 1;
      LOCK();
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        FUN_01674ea0(puVar4);
      }
    }
    if (piStack_28 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    LOCK();
    iVar5 = piStack_28[1] + -1;
    piStack_28[1] = iVar5;
    UNLOCK();
    if (iVar5 != 0) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)*piStack_28)();
    LOCK();
    piVar1 = piStack_28 + 2;
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 != 1) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    iVar5 = *piStack_28;
  }
  (**(code **)(iVar5 + 4))();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21072 ; VA 0x00a678a0 ; FUN_00a678a0 */

void FUN_00a678a0(void)

{
  FUN_00a678e0();
  return;
}



/* FUNCTION 21073 ; VA 0x00a678b0 ; FUN_00a678b0 */

void __fastcall FUN_00a678b0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00a668d0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x18);
  }
  return;
}



/* FUNCTION 21074 ; VA 0x00a678e0 ; FUN_00a678e0 */

void __fastcall FUN_00a678e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a67933. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 21075 ; VA 0x00a67940 ; FUN_00a67940 */

void __fastcall FUN_00a67940(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00a668d0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x18);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 21076 ; VA 0x00a679f0 ; thunk_FUN_00a67940 */

void __fastcall thunk_FUN_00a67940(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00a668d0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x18);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 21077 ; VA 0x00a67a00 ; FUN_00a67a00 */

void __fastcall FUN_00a67a00(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a950;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar3 = param_1[4];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[3];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = param_1[2];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar3 = param_1[1];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar3 = *param_1;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21078 ; VA 0x00a67b20 ; FUN_00a67b20 */

int __fastcall FUN_00a67b20(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_008ae410();
  FUN_016dedfb(param_1 + 0x44);
  FUN_009a3ad0();
  iVar4 = FUN_00a67940();
  piVar3 = *(int **)(param_1 + 0x10);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = *(int **)(param_1 + 8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a67b73. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 21079 ; VA 0x00a67b80 ; FUN_00a67b80 */

uint * __thiscall FUN_00a67b80(byte *param_1,uint *param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  uint *puVar10;
  undefined4 *puVar11;
  uint *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1fa0;
  pvStack_10 = ExceptionList;
  uStack_14 = *param_2;
  uVar9 = (uStack_14 >> 3) + uStack_14;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&puStack_18,uVar9,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (puStack_18 == (uint *)0x0) {
    if (param_2[1] == 0) {
      puVar10 = (uint *)0x0;
    }
    else {
      LOCK();
      piVar5 = (int *)(param_2[1] + 4);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
      uStack_14 = *param_2;
      puVar10 = (uint *)param_2[1];
    }
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    puStack_18 = puVar10;
    piVar5 = (int *)FUN_01674e20(0x18);
    puVar1 = puVar10 + 1;
    *piVar5 = 0;
    puStack_18 = (uint *)(piVar5 + 2);
    piVar5[1] = 0;
    *puStack_18 = 0;
    piVar5[3] = 0;
    piVar5[4] = 0;
    piVar5[5] = 0;
    piVar5[3] = 0;
    if (puVar10 != (uint *)0x0) {
      LOCK();
      *puVar1 = *puVar1 + 1;
      UNLOCK();
    }
    *puStack_18 = uStack_14;
    piVar5[3] = (int)puVar10;
    piVar5[4] = 0;
    piVar5[5] = 0;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (puVar10 != (uint *)0x0) {
      LOCK();
      uVar6 = *puVar1;
      *puVar1 = uVar6 - 1;
      UNLOCK();
      if (uVar6 - 1 == 0) {
        (**(code **)*puVar10)();
        LOCK();
        uVar6 = puVar10[2] - 1;
        puVar10[2] = uVar6;
        UNLOCK();
        if (uVar6 == 0) {
          (**(code **)(*puVar10 + 4))();
        }
      }
    }
    uVar3 = *(uint *)(param_1 + 8);
    uVar6 = uVar3 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar6 = FUN_005d6bb0(uVar6);
      if (uVar6 <= *(uint *)(param_1 + 4)) {
        uVar6 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar6);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar6) {
      uVar7 = uVar3 >> 1;
      if (uVar3 + (uVar3 >> 1) <= uVar6) {
        uVar7 = 1;
      }
      uVar6 = FUN_005d6bb0(uVar7 + uVar3);
      puVar10 = (uint *)(param_1 + 4);
      if (uVar6 != *puVar10) {
        FUN_005d2b00(uVar6);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar10 * 4);
        puVar4 = (undefined4 *)*puVar11;
        while (puVar4 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *puVar10) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *puVar10) * 4) == 0) {
            *piVar2 = (int)puVar11;
            puVar11 = puVar4;
          }
          else {
            *puVar11 = *puVar4;
            *puVar4 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar4;
          }
          puVar4 = (undefined4 *)*puVar11;
        }
      }
    }
    piVar5[1] = uVar9;
    uVar6 = *(uint *)(param_1 + 4);
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uVar9 % uVar6) * 4);
    if ((int *)*piVar2 == (int *)0x0) {
      piVar8 = (int *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
      if (*piVar8 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % uVar6) * 4) = piVar5;
      }
      *piVar2 = (int)piVar8;
      *piVar5 = *piVar8;
    }
    else {
      *piVar5 = *(int *)*piVar2;
      piVar8 = (int *)*piVar2;
    }
    *piVar8 = (int)piVar5;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return puStack_18;
  }
  ExceptionList = pvStack_10;
  return puStack_18 + 2;
}



/* FUNCTION 21080 ; VA 0x00a67dc0 ; FUN_00a67dc0 */

uint * __thiscall FUN_00a67dc0(byte *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  uint *puVar10;
  undefined4 *puVar11;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1fc0;
  pvStack_10 = ExceptionList;
  uVar5 = *param_2;
  uVar9 = (uVar5 >> 3) + uVar5;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&puStack_14,uVar9,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (puStack_14 == (uint *)0x0) {
    if (param_2[1] == 0) {
      puVar10 = (uint *)0x0;
    }
    else {
      LOCK();
      piVar4 = (int *)(param_2[1] + 4);
      *piVar4 = *piVar4 + 1;
      UNLOCK();
      uVar5 = *param_2;
      puVar10 = (uint *)param_2[1];
    }
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    puStack_14 = puVar10;
    piVar4 = (int *)FUN_01674e20(0x14);
    puVar1 = puVar10 + 1;
    puStack_14 = (uint *)(piVar4 + 2);
    *piVar4 = 0;
    piVar4[1] = 0;
    piVar4[3] = 0;
    piVar4[4] = 0;
    *puStack_14 = 0;
    piVar4[3] = 0;
    if (puVar10 != (uint *)0x0) {
      LOCK();
      *puVar1 = *puVar1 + 1;
      UNLOCK();
    }
    *puStack_14 = uVar5;
    piVar4[3] = (int)puVar10;
    piVar4[4] = 0;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (puVar10 != (uint *)0x0) {
      LOCK();
      uVar5 = *puVar1;
      *puVar1 = uVar5 - 1;
      UNLOCK();
      if (uVar5 - 1 == 0) {
        (**(code **)*puVar10)();
        LOCK();
        uVar5 = puVar10[2] - 1;
        puVar10[2] = uVar5;
        UNLOCK();
        if (uVar5 == 0) {
          (**(code **)(*puVar10 + 4))();
        }
      }
    }
    uVar2 = *(uint *)(param_1 + 8);
    uVar5 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005c6680(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      uVar7 = uVar2 >> 1;
      if (uVar2 + (uVar2 >> 1) <= uVar5) {
        uVar7 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar7 + uVar2);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005c6680(iVar6);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar11;
        while (puVar3 != (undefined4 *)0x0) {
          piVar8 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar8 = (int)puVar11;
            puVar11 = puVar3;
          }
          else {
            *puVar11 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar8;
            *(undefined4 **)*piVar8 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar11;
        }
      }
    }
    piVar4[1] = uVar9;
    uVar9 = uVar9 % *(uint *)(param_1 + 4);
    piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (piVar8 == (int *)0x0) {
      piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar8 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar11 = piVar8;
      *piVar4 = *piVar8;
    }
    else {
      *piVar4 = *piVar8;
      piVar8 = (int *)*puVar11;
    }
    *piVar8 = (int)piVar4;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return puStack_14;
  }
  ExceptionList = pvStack_10;
  return puStack_14 + 2;
}



/* FUNCTION 21081 ; VA 0x00a67ff0 ; FUN_00a67ff0 */

int __thiscall FUN_00a67ff0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  pcVar3 = (code *)*param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21082 ; VA 0x00a68080 ; FUN_00a68080 */

int __thiscall
FUN_00a68080(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1fe0;
  pvStack_10 = ExceptionList;
  pcVar3 = (code *)*param_1;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_3,param_4,param_5,param_6,param_7);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21083 ; VA 0x00a68170 ; FUN_00a68170 */

int __thiscall FUN_00a68170(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  FUN_008ae410();
  FUN_016dedfb(param_1 + 0x44);
  FUN_009a3ad0();
  FUN_00a67940();
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x8c);
  }
  return param_1;
}



/* FUNCTION 21084 ; VA 0x00a681f0 ; FUN_00a681f0 */

void FUN_00a681f0(void)

{
  FUN_00a67a00();
  return;
}



/* FUNCTION 21085 ; VA 0x00a68200 ; FUN_00a68200 */

int __thiscall FUN_00a68200(int *param_1,uint *param_2)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  undefined auStack_38 [4];
  int *piStack_34;
  byte *pbStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2019;
  pvStack_10 = ExceptionList;
  pbStack_30 = (byte *)(param_1 + 0xb);
  uStack_2c = 0;
  uVar7 = *param_2;
  iVar6 = (int)param_1 + *pbStack_30 + 0x2d;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  iVar6 = FUN_00606ea0(&iStack_18,(uVar7 >> 3) + uVar7,param_2,-(uint)(iVar6 != 0) & iVar6 + 1U);
  if (iStack_18 == 0) {
    piVar5 = (int *)param_2[1];
    iStack_18 = uVar7 + 0x4c;
    piStack_20 = (int *)CONCAT31(piStack_20._1_3_,DAT_01ee7dc4);
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      uVar7 = *param_2;
      piVar5 = (int *)param_2[1];
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    piVar3 = (int *)FUN_00a66a10(piStack_1c,uVar7,piVar5,piStack_20);
    iStack_24 = *piVar3;
    piVar8 = (int *)piVar3[2];
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = (int *)piVar3[2];
    }
    iStack_28 = piVar3[1];
    piStack_20 = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_34[1] + -1;
      piStack_34[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        iVar6 = piStack_20[2] + -1;
        piStack_20[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[1] + -1;
      piVar5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar6 = piVar5[2] + -1;
        piVar5[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    uStack_8 = 1;
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 2;
    piStack_20 = (int *)uVar4;
    piStack_34 = (int *)FUN_01674e20(0x28);
    if (piStack_34 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      *piStack_34 = 0;
      piStack_34[1] = 1;
      piStack_34[2] = (int)FUN_00a68b60;
      piStack_34[3] = (int)FUN_0057e0b0;
      piStack_34[4] = 0;
      piStack_34[5] = iStack_18;
      piStack_34[6] = (int)&LAB_00a68165;
      piStack_34[7] = iStack_24;
      piStack_34[8] = 0;
      piStack_34[9] = 0;
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
      }
      piStack_34[8] = iStack_28;
      piStack_34[9] = (int)piVar8;
      piVar5 = piStack_34;
    }
    FUN_016797d0(piVar5);
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    uStack_2c = 1;
    uStack_8._0_1_ = 3;
    piStack_14 = piVar5;
    FUN_01675290(uVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00a67dc0(param_2);
    cVar2 = FUN_01679300(&piStack_14);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_14);
    }
    if (piStack_14 != (int *)0x0) {
      piVar5 = piStack_14 + 1;
      LOCK();
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        FUN_01674ea0(piStack_14);
      }
    }
    uStack_8 = 0xffffffff;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar6 = piVar8[1] + -1;
      piVar8[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar6 = piVar8[2] + -1;
        piVar8[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    iVar6 = (**(code **)(*piStack_1c + 8))(auStack_38,param_2);
    piVar5 = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piVar8 = piStack_34 + 1;
      iVar1 = *piVar8;
      iVar6 = *piVar8;
      *piVar8 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar6 = (**(code **)*piStack_34)();
        LOCK();
        piVar8 = piVar5 + 2;
        iVar1 = *piVar8;
        *piVar8 = *piVar8 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          iVar6 = (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 21086 ; VA 0x00a684b0 ; FUN_00a684b0 */

int * FUN_00a684b0(int *param_1,int *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  longlong lVar5;
  longlong lVar6;
  int **ppiVar7;
  undefined auStack_38 [16];
  int iStack_28;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e204f;
  pvStack_10 = ExceptionList;
  if (*param_2 == 0) {
    *param_1 = 0;
    param_1[1] = 0;
    return param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_00eb3da0(auStack_38);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  lVar5 = FUN_00a15700(auStack_38);
  lVar6 = FUN_00eb3de0();
  uVar2 = uStack_14;
  if (((lVar5 == 0) || (iStack_28 == 0)) || (lVar6 == 0)) {
    *param_1 = 0;
    param_1[1] = 0;
  }
  else {
    piVar4 = (int *)0x0;
    piStack_20 = (int *)0x0;
    piStack_1c = (int *)0x0;
    uStack_8._0_1_ = 1;
    piVar3 = (int *)FUN_00995490(&param_2,piVar1);
    if (*piVar3 == 0) {
      piVar4 = (int *)FUN_01674e20(0x20);
      uStack_8._0_1_ = 2;
      param_2 = piVar4;
      if (piVar4 == (int *)0x0) {
        piVar4 = (int *)0x0;
      }
      else {
        piVar4[1] = 1;
        piVar4[2] = 1;
        *piVar4 = (int)std::_Ref_count_obj<class_RBX::PackageManager::PackageLinkListener>::vftable;
        if (piVar1[1] != 0) {
          LOCK();
          piVar3 = (int *)(piVar1[1] + 4);
          *piVar3 = *piVar3 + 1;
          UNLOCK();
        }
        FUN_00a66ca0(*piVar1,piVar1[1],uVar2);
      }
      piStack_20 = piVar4 + 3;
      uStack_8._0_1_ = 1;
      uStack_18 = 0;
      uStack_14 = 0;
      piStack_1c = piVar4;
      FUN_00550b30();
      ppiVar7 = &piStack_20;
      FUN_00a67b80(piVar1);
      FUN_0056ecd0(ppiVar7);
    }
    piVar1 = piStack_20;
    piStack_20 = (int *)0x0;
    piStack_1c = (int *)0x0;
    *param_1 = (int)piVar1;
    param_1[1] = (int)piVar4;
    FUN_00550b30();
  }
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21087 ; VA 0x00a68650 ; FUN_00a68650 */

undefined4 * FUN_00a68650(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  int iStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2091;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00fbebe0(&puStack_34,*param_2,param_2[1]);
  puVar5 = puStack_30;
  uStack_8 = 1;
  puVar3 = puStack_30;
  for (puVar8 = puStack_34; puVar8 != puVar5; puVar8 = puVar8 + 2) {
    piStack_1c = (int *)puVar8[1];
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
      piStack_1c = (int *)puVar8[1];
    }
    uStack_20 = *puVar8;
    uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
    uStack_8._0_1_ = 2;
    puStack_30 = puVar3;
    puVar6 = (undefined4 *)(**(code **)(*piStack_18 + 0xc))(auStack_28,&uStack_20);
    puVar3 = (undefined4 *)param_1[1];
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if ((undefined4 *)param_1[2] == puVar3) {
      FUN_0077c2a0(puVar3,puVar6);
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      *puVar3 = *puVar6;
      puVar3[1] = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      param_1[1] = param_1[1] + 8;
    }
    piVar1 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar4 = *piVar2 + -1;
        *piVar2 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piVar1 = piStack_1c;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar4 = *piVar2 + -1;
        *piVar2 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    puVar3 = puStack_30;
  }
  puVar8 = puStack_34;
  if (puStack_34 != (undefined4 *)0x0) {
    for (; puVar8 != puVar3; puVar8 = puVar8 + 2) {
      piVar1 = (int *)puVar8[1];
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar4 = piVar1[1] + -1;
        piVar1[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar4 = piVar1[2] + -1;
          piVar1[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
    }
    uVar7 = iStack_2c - (int)puStack_34 & 0xfffffff8;
    puVar8 = puStack_34;
    if (0xfff < uVar7) {
      puVar8 = (undefined4 *)puStack_34[-1];
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uint)((int)puStack_34 + (-4 - (int)puVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar8,uVar7);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21088 ; VA 0x00a68860 ; FUN_00a68860 */

void __thiscall FUN_00a68860(int param_1,undefined4 *param_2,uint *param_3)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e20a8;
  pvStack_10 = ExceptionList;
  uVar2 = *param_3;
  if (uVar2 == 0) {
    *param_2 = 0;
    param_2[1] = 0;
    return;
  }
  uStack_8 = 0;
  iVar4 = param_1 + 0x15 + (uint)*(byte *)(param_1 + 0x14);
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&piStack_14,(uVar2 >> 3) + uVar2,param_3,-(uint)(iVar4 != 0) & iVar4 + 1U);
  if (piStack_14 != (int *)0x0) {
    FUN_0056ecd0(piStack_14 + 4);
    piVar8 = (int *)*piStack_14;
    piVar5 = (int *)((uint)piStack_14[1] % *(uint *)(param_1 + 0x18));
    piVar1 = *(int **)(*(int *)(param_1 + 0x28) + (int)piVar5 * 4);
    for (piVar7 = (int *)*piVar1; piVar7 != piStack_14; piVar7 = (int *)*piVar7) {
      piVar1 = piVar7;
    }
    piStack_14 = piVar5;
    do {
      *piVar1 = *piVar7;
      FUN_00a668d0(-(uint)(param_1 != -0x17) & param_1 + 0x18U,piVar7 + 2);
      FUN_01674ea0(piVar7,0x18);
      *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + -1;
      piVar5 = piStack_14;
      if (*piVar1 == 0) {
LAB_00a6896a:
        if (*(int **)(*(int *)(param_1 + 0x28) + (int)piStack_14 * 4) == piVar1) {
          *(undefined4 *)(*(int *)(param_1 + 0x28) + (int)piStack_14 * 4) = 0;
        }
      }
      else {
        piVar5 = (int *)(*(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 0x18));
        if (piStack_14 != piVar5) {
          *(int **)(*(int *)(param_1 + 0x28) + (int)piVar5 * 4) = piVar1;
          goto LAB_00a6896a;
        }
      }
      piVar7 = (int *)*piVar1;
      piStack_14 = piVar5;
    } while (piVar7 != piVar8);
  }
  if (*(int *)(param_1 + 0x34) != 0) {
    uVar2 = (*param_3 >> 3) + *param_3;
    uVar6 = uVar2 % *(uint *)(param_1 + 0x30);
    piStack_14 = (int *)(uVar6 * 4);
    piVar8 = *(int **)((int)piStack_14 + *(int *)(param_1 + 0x40));
    if ((piVar8 != (int *)0x0) && (piVar1 = (int *)*piVar8, (int *)*piVar8 != (int *)0x0)) {
      while (piVar7 = piVar1, (uint)piVar7[1] % *(uint *)(param_1 + 0x30) == uVar6) {
        if ((piVar7[1] == uVar2) && (*param_3 == piVar7[2])) {
          FUN_009af930(piVar8,*piVar7);
          if (*piVar8 != 0) {
            uVar2 = *(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 0x30);
            if (uVar6 == uVar2) break;
            *(int **)(*(int *)(param_1 + 0x40) + uVar2 * 4) = piVar8;
          }
          puVar3 = (undefined4 *)(*(int *)(param_1 + 0x40) + (int)piStack_14);
          if ((int *)*puVar3 == piVar8) {
            *puVar3 = 0;
          }
          break;
        }
        piVar1 = (int *)*piVar7;
        piVar8 = piVar7;
        if ((int *)*piVar7 == (int *)0x0) break;
      }
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21089 ; VA 0x00a68a50 ; FUN_00a68a50 */

int FUN_00a68a50(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_1 + 0x1c);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00a67ff0(uVar3,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21090 ; VA 0x00a68ae0 ; FUN_00a68ae0 */

int FUN_00a68ae0(undefined *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  iVar4 = (int)param_1 + 0x18;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  param_1 = (undefined *)&param_2;
  iVar4 = FUN_00a661d0(&param_2,iVar4,&param_1,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21091 ; VA 0x00a68b60 ; FUN_00a68b60 */

int FUN_00a68b60(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcVar4;
  int iVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e20c8;
  pvStack_10 = ExceptionList;
  piVar6 = *(int **)(param_1 + 0x24);
  ExceptionList = &pvStack_10;
  if (piVar6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = *(int **)(param_1 + 0x24);
  }
  uVar3 = *(undefined4 *)(param_1 + 0x20);
  pcVar4 = *(code **)(param_1 + 0x18);
  piVar1 = piVar6 + 1;
  uStack_8 = 0;
  if (piVar6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar5 = (*pcVar4)(uVar3,piVar6,param_2);
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 21092 ; VA 0x00a68c10 ; FUN_00a68c10 */

int FUN_00a68c10(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4ed0;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)&param_2;
  puStack_14 = (undefined *)&param_4;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00a662e0(param_1,param_1 + 0x18,&puStack_18,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21093 ; VA 0x00a68cc0 ; FUN_00a68cc0 */

int FUN_00a68cc0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_1 + 0x1c);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (*(int *)(param_1 + 0x24) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x24) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_00a68080(uVar3,*(undefined4 *)(param_1 + 0x20),*(undefined4 *)(param_1 + 0x24),param_2
                       ,param_3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21094 ; VA 0x00a68d80 ; FUN_00a68d80 */

int FUN_00a68d80(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_1 + 0x28);
  uVar4 = *(undefined4 *)(param_1 + 0x1c);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (*(int *)(param_1 + 0x24) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x24) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar5 = FUN_00a68080(uVar4,*(undefined4 *)(param_1 + 0x20),*(undefined4 *)(param_1 + 0x24),param_2
                       ,param_3,uVar3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 21095 ; VA 0x00a68e40 ; FUN_00a68e40 */

void FUN_00a68e40(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar2 = *(undefined4 *)(param_1 + 0x1c);
  if (*(int *)(param_1 + 0x2c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x2c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *(undefined4 *)(param_1 + 0x28);
  uVar4 = *(undefined4 *)(param_1 + 0x2c);
  if (*(int *)(param_1 + 0x24) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x24) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a68080(uVar2,*(undefined4 *)(param_1 + 0x20),*(undefined4 *)(param_1 + 0x24),uVar3,uVar4,
               param_2);
  return;
}



/* FUNCTION 21096 ; VA 0x00a68eb0 ; FUN_00a68eb0 */

void FUN_00a68eb0(void)

{
  FUN_00a678e0();
  return;
}



/* FUNCTION 21097 ; VA 0x00a68ec0 ; FUN_00a68ec0 */

undefined4 * __thiscall FUN_00a68ec0(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  *param_2 = 0;
  param_2[1] = 0;
  iVar1 = *(int *)(param_1 + 8);
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 4);
    piVar3 = (int *)(iVar1 + 4);
    if (iVar2 != 0) {
      while( true ) {
        LOCK();
        iVar1 = *piVar3;
        if (iVar2 == iVar1) {
          *piVar3 = iVar2 + 1;
          iVar1 = iVar2;
        }
        UNLOCK();
        if (iVar1 == iVar2) break;
        iVar2 = *piVar3;
        if (iVar2 == 0) {
          return param_2;
        }
      }
      *param_2 = *(undefined4 *)(param_1 + 4);
      param_2[1] = *(undefined4 *)(param_1 + 8);
    }
  }
  return param_2;
}



/* FUNCTION 21098 ; VA 0x00a68f20 ; FUN_00a68f20 */

int FUN_00a68f20(int param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_38 [12];
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2119;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00a68ec0(&iStack_2c);
  uStack_8._0_1_ = 2;
  if (iStack_2c != 0) {
    uStack_8._0_1_ = 3;
    if (param_1 == 0) {
      iVar3 = 0;
    }
    else {
      iVar3 = param_1;
      if (*(int *)(param_1 + 0x34) != 0) {
        iVar3 = FUN_005c8ac0();
      }
    }
    FUN_0060dcd0(&iStack_24,iVar3);
    iVar3 = iStack_2c + 0xc;
    uStack_14 = 1;
    if (iStack_24 != iVar3) {
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      iStack_1c = param_1;
      piStack_18 = param_2;
      uStack_8._0_1_ = 4;
      FUN_00a68650(auStack_38,&iStack_1c);
      iVar3 = FUN_00577ac0();
      if (param_2 != (int *)0x0) {
        LOCK();
        piVar1 = param_2 + 1;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*param_2)();
          LOCK();
          piVar1 = param_2 + 2;
          iVar2 = *piVar1;
          iVar3 = *piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            iVar3 = (**(code **)(*param_2 + 4))();
          }
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_20 + 4))();
        }
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 21099 ; VA 0x00a690a0 ; FUN_00a690a0 */

void FUN_00a690a0(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return;
}



/* FUNCTION 21100 ; VA 0x00a69100 ; FUN_00a69100 */

void * FUN_00a69100(void *param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  undefined auStack_24 [12];
  void *pvStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2140;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar3 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (((param_3 == &DAT_0211a3d8) &&
      (pvVar3 = param_1, ExceptionList = &pvStack_10, param_1 != (void *)0x0)) &&
     (ExceptionList = &pvStack_10, *(int *)((int)param_1 + 0x34) == 0)) {
    ExceptionList = &pvStack_10;
    if (param_2 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    pvStack_18 = param_1;
    piStack_14 = param_2;
    uStack_8 = 1;
    FUN_00a68650(auStack_24,&pvStack_18);
    FUN_00577ac0();
    pvVar3 = (void *)FUN_00550b30();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 21101 ; VA 0x00a691b0 ; FUN_00a691b0 */

void FUN_00a691b0(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return;
}



/* FUNCTION 21102 ; VA 0x00a69210 ; FUN_00a69210 */

undefined __thiscall FUN_00a69210(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined uVar6;
  uint uVar7;
  longlong lVar8;
  int aiStack_38 [5];
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2168;
  pvStack_10 = ExceptionList;
  if (*param_2 == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00eb3da0(aiStack_38);
  uStack_8 = 0;
  lVar8 = FUN_00a15700(uVar3);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    iVar5 = aiStack_38[0];
    if (0xfff < uVar7) {
      iVar5 = *(int *)(aiStack_38[0] + -4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (aiStack_38[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
  }
  FUN_00a68ec0(&uStack_20);
  iVar5 = *(int *)(param_1 + 0x10);
  iStack_18 = 0;
  piStack_14 = (int *)0x0;
  if (iVar5 != 0) {
    piVar1 = (int *)(iVar5 + 4);
    iVar5 = *(int *)(iVar5 + 4);
    while (iVar5 != 0) {
      LOCK();
      iVar4 = *piVar1;
      if (iVar5 == iVar4) {
        *piVar1 = iVar5 + 1;
        iVar4 = iVar5;
      }
      UNLOCK();
      if (iVar4 == iVar5) {
        iStack_18 = *(int *)(param_1 + 0xc);
        piStack_14 = *(int **)(param_1 + 0x10);
        break;
      }
      iVar5 = *piVar1;
    }
  }
  piVar1 = piStack_14;
  uStack_8 = 3;
  if (uStack_20 != 0) {
    piVar2 = *(int **)(uStack_20 + 0x43c);
    if (((*piVar2 - (int)piVar2 != 0 || piVar2[1] - (int)piVar2 != 0) && (lVar8 != 0)) &&
       (iStack_18 != 0)) {
      FUN_00a305c0(*piVar2 - (int)piVar2,piVar2[1] - (int)piVar2,lVar8);
      uVar6 = 1;
      goto LAB_00a69335;
    }
  }
  uVar6 = 0;
LAB_00a69335:
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar5 = piVar1[1] + -1;
    piVar1[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar5 = piVar1[2] + -1;
      piVar1[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 21103 ; VA 0x00a693a0 ; FUN_00a693a0 */

int __thiscall FUN_00a693a0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2188;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)0x0;
  iVar3 = 0;
  iVar2 = *(int *)(param_1 + 0x10);
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    piVar4 = (int *)(iVar2 + 4);
    iVar3 = *(int *)(iVar2 + 4);
    ExceptionList = &pvStack_10;
    while (iVar3 != 0) {
      LOCK();
      iVar2 = *piVar4;
      if (iVar3 == iVar2) {
        *piVar4 = iVar3 + 1;
        iVar2 = iVar3;
      }
      UNLOCK();
      if (iVar2 == iVar3) {
        iVar3 = *(int *)(param_1 + 0xc);
        piVar4 = *(int **)(param_1 + 0x10);
        goto LAB_00a693f9;
      }
      iVar3 = *piVar4;
    }
    iVar3 = 0;
    piVar4 = (int *)0x0;
  }
LAB_00a693f9:
  uStack_8 = 1;
  if (iVar3 != 0) {
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iVar2 = FUN_00a31d50(*param_2,param_2[1]);
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar3 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar2 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar2 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 21104 ; VA 0x00a69480 ; FUN_00a69480 */

int * __thiscall FUN_00a69480(int *param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e21b0;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if (param_2 != 0) {
    iVar3 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar6 = FUN_00eb3a50();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      puVar8 = &uStack_2c;
      piStack_28 = param_3;
      bVar5 = true;
      bVar4 = false;
      goto LAB_00a69508;
    }
  }
  piStack_20 = (int *)0x0;
  puVar8 = &uStack_24;
  bVar5 = false;
  bVar4 = true;
  param_2 = 0;
LAB_00a69508:
  piStack_18 = (int *)puVar8[1];
  *puVar8 = 0;
  iStack_1c = param_2;
  puVar8[1] = 0;
  piVar2 = piStack_20;
  piVar7 = piStack_18;
  if (bVar4) {
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar3 = *piVar1;
      piVar7 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        piVar7 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar7 = (int *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  piVar2 = piStack_28;
  if ((bVar5) && (piStack_28 != (int *)0x0)) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar3 = *piVar1;
    piVar7 = (int *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      piVar7 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar7 = (int *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_1c != 0) {
    piVar7 = (int *)(**(code **)(*piStack_14 + 0x24))(&iStack_1c);
  }
  piVar2 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar3 = *piVar1;
    piVar7 = (int *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      piVar7 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar7 = (int *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    piVar7 = (int *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piVar7 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piVar7 = (int *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar7;
}



/* FUNCTION 21105 ; VA 0x00a695f0 ; FUN_00a695f0 */

int * __thiscall
FUN_00a695f0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e21c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00a699b0();
  FUN_00a6ab70(uVar3,param_2,param_3,0,param_7,param_8,param_9,param_10,param_11);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<class_RBX::TextureId,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<class_RBX::TextureId,1>::
              BoundPropGetSet<class_RBX::Clothing>::vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = param_5;
    puVar4[5] = param_6;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21106 ; VA 0x00a696c0 ; FUN_00a696c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a696c0(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee9124) {
    FUN_016f3809(&DAT_01ee9124);
    if (DAT_01ee9124 == -1) {
      _DAT_01ee9118 = FUN_005c65f0;
      _DAT_01ee911c = FUN_005c93a0;
      _DAT_01ee9120 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ee9124);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01ee9118) {
    if (param_1 + 1 != param_2) {
      FUN_005507b0();
      uVar2 = param_2[1];
      uVar3 = param_2[2];
      uVar4 = param_2[3];
      param_1[1] = *param_2;
      param_1[2] = uVar2;
      param_1[3] = uVar3;
      param_1[4] = uVar4;
      *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 4);
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
    }
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[5] = 0;
  param_1[6] = 0;
  uVar2 = param_2[1];
  uVar3 = param_2[2];
  uVar4 = param_2[3];
  param_1[1] = *param_2;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  param_1[4] = uVar4;
  *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  *param_1 = &DAT_01ee9118;
  return param_1;
}



/* FUNCTION 21107 ; VA 0x00a697d0 ; FUN_00a697d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a697d0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2200;
  pvStack_10 = ExceptionList;
  if (DAT_01ee824c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee8460) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee8460);
      if (DAT_01ee8460 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00a698d0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BodyColors",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ee8458 = RBX::Creator<class_RBX::BodyColors>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee8250,&DAT_01ee8458);
        FUN_016f3654(FUN_0188a610);
        FUN_016f37bf(&DAT_01ee8460);
      }
    }
    DAT_01ee824c = &DAT_01ee8250;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee824c;
}



/* FUNCTION 21108 ; VA 0x00a698d0 ; FUN_00a698d0 */

undefined * FUN_00a698d0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e221c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee8f00 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee9110) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee9110);
      if (DAT_01ee9110 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"CharacterAppearance",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0188a670);
        FUN_016f37bf(&DAT_01ee9110);
      }
    }
    DAT_01ee8f00 = &DAT_01ee8f08;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee8f00;
}



/* FUNCTION 21109 ; VA 0x00a699b0 ; FUN_00a699b0 */

undefined * FUN_00a699b0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e223c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee8ac8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee8cd8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee8cd8);
      if (DAT_01ee8cd8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00a698d0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Clothing",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0188a680);
        FUN_016f37bf(&DAT_01ee8cd8);
      }
    }
    DAT_01ee8ac8 = &DAT_01ee8ad0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee8ac8;
}



/* FUNCTION 21110 ; VA 0x00a69a90 ; FUN_00a69a90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a69a90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2270;
  pvStack_10 = ExceptionList;
  if (DAT_01ee88a8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee8ac0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee8ac0);
      if (DAT_01ee8ac0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00a699b0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Pants",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ee8ab8 = RBX::Creator<class_RBX::Pants>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee88b0,&DAT_01ee8ab8);
        FUN_016f3654(FUN_0188a690);
        FUN_016f37bf(&DAT_01ee8ac0);
      }
    }
    DAT_01ee88a8 = &DAT_01ee88b0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee88a8;
}



/* FUNCTION 21111 ; VA 0x00a69b90 ; FUN_00a69b90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a69b90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e22a0;
  pvStack_10 = ExceptionList;
  if (DAT_01ee8688 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee88a0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee88a0);
      if (DAT_01ee88a0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00a699b0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Shirt",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ee8898 = RBX::Creator<class_RBX::Shirt>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee8690,&DAT_01ee8898);
        FUN_016f3654(FUN_0188a6f0);
        FUN_016f37bf(&DAT_01ee88a0);
      }
    }
    DAT_01ee8688 = &DAT_01ee8690;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee8688;
}



/* FUNCTION 21112 ; VA 0x00a69c90 ; FUN_00a69c90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a69c90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e22d0;
  pvStack_10 = ExceptionList;
  if (DAT_01ee8468 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee8680) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee8680);
      if (DAT_01ee8680 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00a698d0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ShirtGraphic",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ee8678 = RBX::Creator<class_RBX::ShirtGraphic>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee8470,&DAT_01ee8678);
        FUN_016f3654(FUN_0188a750);
        FUN_016f37bf(&DAT_01ee8680);
      }
    }
    DAT_01ee8468 = &DAT_01ee8470;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee8468;
}



/* FUNCTION 21113 ; VA 0x00a69d90 ; FUN_00a69d90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a69d90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2300;
  pvStack_10 = ExceptionList;
  if (DAT_01ee8ce0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee8ef8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee8ef8);
      if (DAT_01ee8ef8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00a698d0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_01944c84,0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ee8ef0 = RBX::Creator<class_RBX::Skin>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee8ce8,&DAT_01ee8ef0);
        FUN_016f3654(FUN_0188a7b0);
        FUN_016f37bf(&DAT_01ee8ef8);
      }
    }
    DAT_01ee8ce0 = &DAT_01ee8ce8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee8ce0;
}



/* FUNCTION 21114 ; VA 0x00a69e90 ; FUN_00a69e90 */

int __thiscall FUN_00a69e90(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2310;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::BodyColors*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21115 ; VA 0x00a69f62 ; Catch_All@00a69f62 */

void Catch_All_00a69f62(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21116 ; VA 0x00a69f80 ; FUN_00a69f80 */

int __thiscall FUN_00a69f80(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2320;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Pants*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21117 ; VA 0x00a6a052 ; Catch_All@00a6a052 */

void Catch_All_00a6a052(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21118 ; VA 0x00a6a070 ; FUN_00a6a070 */

int __thiscall FUN_00a6a070(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2330;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Shirt*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21119 ; VA 0x00a6a142 ; Catch_All@00a6a142 */

void Catch_All_00a6a142(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21120 ; VA 0x00a6a160 ; FUN_00a6a160 */

int __thiscall FUN_00a6a160(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2340;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ShirtGraphic*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21121 ; VA 0x00a6a232 ; Catch_All@00a6a232 */

void Catch_All_00a6a232(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21122 ; VA 0x00a6a250 ; FUN_00a6a250 */

int __thiscall FUN_00a6a250(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2350;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Skin*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21123 ; VA 0x00a6a322 ; Catch_All@00a6a322 */

void Catch_All_00a6a322(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21124 ; VA 0x00a6a340 ; FUN_00a6a340 */

undefined4 * FUN_00a6a340(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e23b3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a697d0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  uStack_1c = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(0xb8);
  uStack_8._0_1_ = 2;
  puStack_14 = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x58);
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::CharacterAppearance,class_RBX::Instance>::vftable;
    uVar4 = FUN_00a698d0();
    puVar3[3] = uVar4;
    puVar3[0x15] = RBX::IModelModifier::vftable;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::DescribedCreatable<class_RBX::BodyColors,class_RBX::LegacyCharacterAppearance>::
              vftable;
    puVar3[0x15] = RBX::
                   DescribedCreatable<class_RBX::BodyColors,class_RBX::LegacyCharacterAppearance>::
                   vftable;
    uVar4 = FUN_00a697d0();
    puVar3[3] = uVar4;
    *puVar3 = RBX::BodyColors::vftable;
    puVar3[0x15] = RBX::BodyColors::vftable;
    puVar3[0x16] = 0xe2;
    puVar3[0x17] = 0xe2;
    puVar3[0x18] = 0xe2;
    puVar3[0x19] = 0x1c;
    puVar3[0x1a] = 0x17;
    uStack_8._0_1_ = 5;
    puVar3[0x1b] = 0x17;
    FUN_00c98ad0(puVar3 + 0x1c);
    FUN_00c98ad0(puVar3 + 0x1f);
    FUN_00c98ad0(puVar3 + 0x22);
    FUN_00c98ad0(puVar3 + 0x25);
    FUN_00c98ad0(puVar3 + 0x28);
    FUN_00c98ad0(puVar3 + 0x2b);
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("Body Colors",0xb);
    uStack_8._0_1_ = 6;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 5;
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      uVar5 = auStack_34[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_34[0] - 4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a69e90(puVar3,uStack_1c);
  uStack_18 = 1;
  uStack_8 = 10;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21125 ; VA 0x00a6a550 ; FUN_00a6a550 */

undefined4 * FUN_00a6a550(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e23fb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a69a90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x94);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00a6ac20();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::Pants,class_RBX::Clothing>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::Pants,class_RBX::Clothing>::vftable;
    uVar4 = FUN_00a69a90();
    puVar3[3] = uVar4;
    *puVar3 = RBX::Pants::vftable;
    puVar3[0x15] = RBX::Pants::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a69f80(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21126 ; VA 0x00a6a640 ; FUN_00a6a640 */

undefined4 * FUN_00a6a640(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e244b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a69b90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x94);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00a6ac20();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::Shirt,class_RBX::Clothing>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::Shirt,class_RBX::Clothing>::vftable;
    uVar4 = FUN_00a69b90();
    puVar3[3] = uVar4;
    *puVar3 = RBX::Shirt::vftable;
    puVar3[0x15] = RBX::Shirt::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a6a070(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21127 ; VA 0x00a6a730 ; FUN_00a6a730 */

undefined4 * FUN_00a6a730(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined8 *puVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e24bb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a69c90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  uStack_18 = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(0x7c);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x58);
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::CharacterAppearance,class_RBX::Instance>::vftable;
    uVar4 = FUN_00a698d0();
    puVar3[3] = uVar4;
    puVar3[0x15] = RBX::IModelModifier::vftable;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::DescribedCreatable<class_RBX::ShirtGraphic,class_RBX::LegacyCharacterAppearance>
              ::vftable;
    puVar3[0x15] = RBX::
                   DescribedCreatable<class_RBX::ShirtGraphic,class_RBX::LegacyCharacterAppearance>
                   ::vftable;
    uVar4 = FUN_00a69c90();
    puVar3[3] = uVar4;
    *puVar3 = RBX::ShirtGraphic::vftable;
    puVar3[0x15] = RBX::ShirtGraphic::vftable;
    puVar3[0x1a] = 0;
    puVar3[0x1b] = 0xf;
    *(undefined *)(puVar3 + 0x16) = 0;
    uStack_8._0_1_ = 6;
    puVar5 = (undefined8 *)FUN_0115ee70();
    uStack_24 = 0;
    *(undefined8 *)(puVar3 + 0x1c) = *puVar5;
    puVar3[0x1e] = *(undefined4 *)(puVar5 + 1);
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("Shirt Graphic",0xd);
    uStack_8._0_1_ = 7;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 6;
    if (0xf < uStack_20) {
      uVar7 = uStack_20 + 1;
      uVar6 = auStack_34[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_34[0] - 4);
        uVar7 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a6a160(puVar3,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 0xb;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21128 ; VA 0x00a6a8e0 ; FUN_00a6a8e0 */

undefined4 * FUN_00a6a8e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2520;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a69d90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  uStack_18 = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(0x5c);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x58);
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::CharacterAppearance,class_RBX::Instance>::vftable;
    uVar4 = FUN_00a698d0();
    puVar3[3] = uVar4;
    puVar3[0x15] = RBX::IModelModifier::vftable;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::DescribedCreatable<class_RBX::Skin,class_RBX::LegacyCharacterAppearance>::vftable
    ;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::Skin,class_RBX::LegacyCharacterAppearance>::
                   vftable;
    uVar4 = FUN_00a69d90();
    puVar3[3] = uVar4;
    *puVar3 = RBX::Skin::vftable;
    puVar3[0x15] = RBX::Skin::vftable;
    uStack_8._0_1_ = 5;
    puVar3[0x16] = 0xe2;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0(&DAT_01944c84,4);
    uStack_8._0_1_ = 6;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 5;
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      uVar5 = auStack_34[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_34[0] - 4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a6a250(puVar3,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 10;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21129 ; VA 0x00a6aa70 ; FUN_00a6aa70 */

undefined4 __thiscall FUN_00a6aa70(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = thunk_FUN_0088d190();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    uVar5 = FUN_00d00030();
    FUN_0054ef60(uVar5);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = thunk_FUN_0088d190();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21130 ; VA 0x00a6ab70 ; FUN_00a6ab70 */

/* WARNING: Removing unreachable block (ram,0x00a6ac03) */

int * __thiscall
FUN_00a6ab70(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e254b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = thunk_FUN_0088d190();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21131 ; VA 0x00a6ac20 ; FUN_00a6ac20 */

undefined4 * __fastcall FUN_00a6ac20(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2596;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0170d1f0(param_1,0,0x58);
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::CharacterAppearance,class_RBX::Instance>::vftable;
  uVar1 = FUN_00a698d0();
  param_1[3] = uVar1;
  param_1[0x15] = RBX::IModelModifier::vftable;
  uStack_8 = 1;
  *param_1 = RBX::Described<class_RBX::Clothing,class_RBX::CharacterAppearance>::vftable;
  param_1[0x15] = RBX::Described<class_RBX::Clothing,class_RBX::CharacterAppearance>::vftable;
  uVar1 = FUN_00a699b0();
  param_1[3] = uVar1;
  *param_1 = RBX::Clothing::vftable;
  param_1[0x15] = RBX::Clothing::vftable;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0xf;
  *(undefined *)(param_1 + 0x16) = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined8 *)FUN_0115ee70();
  uStack_1c = 0;
  *(undefined8 *)(param_1 + 0x22) = *puVar2;
  param_1[0x24] = *(undefined4 *)(puVar2 + 1);
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("Clothing",8);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    uVar3 = auStack_2c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_2c[0] - 4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21132 ; VA 0x00a6ad60 ; FUN_00a6ad60 */

void __fastcall FUN_00a6ad60(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::BodyColors>::vftable;
  uVar1 = FUN_00a697d0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21133 ; VA 0x00a6ada0 ; FUN_00a6ada0 */

void __fastcall FUN_00a6ada0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Pants>::vftable;
  uVar1 = FUN_00a69a90(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21134 ; VA 0x00a6ade0 ; FUN_00a6ade0 */

void __fastcall FUN_00a6ade0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Shirt>::vftable;
  uVar1 = FUN_00a69b90(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21135 ; VA 0x00a6ae20 ; FUN_00a6ae20 */

void __fastcall FUN_00a6ae20(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ShirtGraphic>::vftable;
  uVar1 = FUN_00a69c90(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21136 ; VA 0x00a6ae60 ; FUN_00a6ae60 */

void __fastcall FUN_00a6ae60(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Skin>::vftable;
  uVar1 = FUN_00a69d90(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21137 ; VA 0x00a6aea0 ; FUN_00a6aea0 */

void __fastcall FUN_00a6aea0(int param_1)

{
  *(undefined ***)(param_1 + 0x54) = RBX::IModelModifier::vftable;
  FUN_0089b230();
  return;
}



/* FUNCTION 21138 ; VA 0x00a6aeb0 ; FUN_00a6aeb0 */

void __fastcall FUN_00a6aeb0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x84);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x70);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a6af4f;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0xf;
  *(undefined *)(param_1 + 0x70) = 0;
  uVar1 = *(uint *)(param_1 + 0x6c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x58);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00a6af4f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0xf;
  *(undefined *)(param_1 + 0x58) = 0;
  *(undefined ***)(param_1 + 0x54) = RBX::IModelModifier::vftable;
  FUN_0089b230();
  return;
}



/* FUNCTION 21139 ; VA 0x00a6af55 ; FUN_00a6af55 */

void FUN_00a6af55(void)

{
  FUN_00a6afb0();
  return;
}



/* FUNCTION 21140 ; VA 0x00a6af5d ; FUN_00a6af5d */

void FUN_00a6af5d(void)

{
  FUN_00a6afe0();
  return;
}



/* FUNCTION 21141 ; VA 0x00a6af65 ; FUN_00a6af65 */

void FUN_00a6af65(void)

{
  FUN_00a6b010();
  return;
}



/* FUNCTION 21142 ; VA 0x00a6af6d ; FUN_00a6af6d */

void FUN_00a6af6d(void)

{
  FUN_00a6b070();
  return;
}



/* FUNCTION 21143 ; VA 0x00a6af75 ; FUN_00a6af75 */

void FUN_00a6af75(void)

{
  FUN_00a6b0f0();
  return;
}



/* FUNCTION 21144 ; VA 0x00a6af80 ; FUN_00a6af80 */

undefined4 * __thiscall FUN_00a6af80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 21145 ; VA 0x00a6afb0 ; FUN_00a6afb0 */

int __thiscall FUN_00a6afb0(int param_1,byte param_2)

{
  *(undefined ***)(param_1 + 0x54) = RBX::IModelModifier::vftable;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 21146 ; VA 0x00a6afe0 ; FUN_00a6afe0 */

undefined4 __thiscall FUN_00a6afe0(undefined4 param_1,byte param_2)

{
  FUN_00a6aeb0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x94);
  }
  return param_1;
}



/* FUNCTION 21147 ; VA 0x00a6b010 ; FUN_00a6b010 */

int __thiscall FUN_00a6b010(int param_1,byte param_2)

{
  *(undefined ***)(param_1 + 0x54) = RBX::IModelModifier::vftable;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb8);
  }
  return param_1;
}



/* FUNCTION 21148 ; VA 0x00a6b040 ; FUN_00a6b040 */

undefined4 * __thiscall FUN_00a6b040(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TextureId>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 21149 ; VA 0x00a6b070 ; FUN_00a6b070 */

int __thiscall FUN_00a6b070(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x6c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x58);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0xf;
  *(undefined *)(param_1 + 0x58) = 0;
  *(undefined ***)(param_1 + 0x54) = RBX::IModelModifier::vftable;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x7c);
  }
  return param_1;
}



/* FUNCTION 21150 ; VA 0x00a6b0f0 ; FUN_00a6b0f0 */

int __thiscall FUN_00a6b0f0(int param_1,byte param_2)

{
  *(undefined ***)(param_1 + 0x54) = RBX::IModelModifier::vftable;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 21151 ; VA 0x00a6b120 ; FUN_00a6b120 */

void __fastcall FUN_00a6b120(int *param_1)

{
  int iVar1;
  
  iVar1 = FUN_009ba880(param_1[0xd]);
  if (iVar1 != 0) {
    (**(code **)(*param_1 + 0xa8))(iVar1);
  }
  return;
}



/* FUNCTION 21152 ; VA 0x00a6b140 ; FUN_00a6b140 */

void __fastcall FUN_00a6b140(int *param_1)

{
  char cVar1;
  int iVar2;
  
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 != '\0') {
    iVar2 = FUN_009ba880(param_1[0xd]);
    if (iVar2 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar2);
    }
  }
  return;
}



/* FUNCTION 21153 ; VA 0x00a6b170 ; FUN_00a6b170 */

void __thiscall FUN_00a6b170(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  undefined **ppuVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  undefined *puStack_28;
  undefined auStack_24 [12];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2688;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (iVar4 != 0) {
    iVar5 = *(int *)(iVar4 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00b63e30();
    iVar3 = 0;
    if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar3 = iVar4;
    }
    if (iVar3 != 0) {
      piVar1 = *(int **)(iVar3 + 0x130);
      for (piVar7 = *(int **)(iVar3 + 300); piVar7 != piVar1; piVar7 = piVar7 + 1) {
        iStack_18 = *piVar7;
        if ((iStack_18 != 0) &&
           (iVar4 = *(int *)(iStack_18 + 0xc), iVar3 = FUN_00a69d90(), iVar5 = iStack_18,
           (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
           (uint)*(ushort *)(iVar3 + 0x1da))) goto LAB_00a6b20d;
      }
      iVar5 = 0;
LAB_00a6b20d:
      param_1 = iStack_14;
      if (iVar5 != 0) {
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  if (*(int *)(param_2 + 0x228) == 0) {
    iVar4 = FUN_009b4d50();
    if (iVar4 != 0) {
      FUN_00b0d620(param_1 + 0x70);
    }
    iVar4 = FUN_009b4e80();
    if (iVar4 != 0) {
      FUN_00b0d620(param_1 + 0xa0);
    }
    iVar4 = FUN_009b6d40();
    if (iVar4 != 0) {
      FUN_00b0d620(param_1 + 0xac);
    }
    iVar4 = FUN_009b77e0();
    if (iVar4 != 0) {
      FUN_00b0d620(param_1 + 0x94);
    }
    iVar4 = FUN_009b4e60();
    if (iVar4 != 0) {
      FUN_00b0d620(param_1 + 0x7c);
    }
    iVar4 = FUN_009b6d20();
    if (iVar4 != 0) {
      FUN_00b0d620(param_1 + 0x88);
    }
  }
  else if (*(int *)(param_1 + 0x34) != 0) {
    ppuVar8 = (undefined **)&DAT_01d661c0;
    do {
      FUN_0054ef60(ppuVar8);
      puStack_28 = ppuVar8[6];
      uStack_8 = 0;
      iVar4 = FUN_008a1240(aiStack_40);
      if ((iVar4 != 0) &&
         (iVar4 = *(int *)(iVar4 + 0xc), iVar5 = FUN_00aff8c0(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        (**(code **)(**(int **)(puStack_28 + 0x34) + 0xc))(auStack_24,iStack_14);
        FUN_00b0d620(auStack_24);
      }
      uStack_8 = 0xffffffff;
      if (0xf < uStack_2c) {
        uVar6 = uStack_2c + 1;
        iVar4 = aiStack_40[0];
        if (0xfff < uVar6) {
          iVar4 = *(int *)(aiStack_40[0] + -4);
          uVar6 = uStack_2c + 0x24;
          if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar6);
      }
      ppuVar8 = ppuVar8 + 7;
    } while (ppuVar8 != &PTR_s_FixRegionToExtents_01d66364);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21154 ; VA 0x00a6b3b0 ; FUN_00a6b3b0 */

void FUN_00a6b3b0(void)

{
  int iVar1;
  
  iVar1 = FUN_009b4e80();
  if (iVar1 != 0) {
    FUN_00b065a0();
  }
  iVar1 = FUN_009b6d40();
  if (iVar1 != 0) {
    FUN_00b065a0();
  }
  iVar1 = FUN_009b77e0();
  if (iVar1 != 0) {
    FUN_00b065a0();
  }
  iVar1 = FUN_009b4e60();
  if (iVar1 != 0) {
    FUN_00b065a0();
  }
  iVar1 = FUN_009b6d20();
  if (iVar1 != 0) {
    FUN_00b065a0();
  }
  return;
}



/* FUNCTION 21155 ; VA 0x00a6b420 ; FUN_00a6b420 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00a6b420(int param_1)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int iVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined8 *puVar8;
  int *piVar9;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  undefined4 auStack_54 [3];
  undefined8 uStack_48;
  float fStack_40;
  undefined4 auStack_3c [3];
  undefined8 uStack_30;
  float fStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e26c1;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = FUN_009b77e0();
  if (iStack_14 != 0) {
    if ((*(int *)(param_1 + 0x228) == 0) &&
       (puVar7 = *(undefined4 **)(iStack_14 + 0x2c), puVar7 != (undefined4 *)0x0)) {
      piVar1 = (int *)puVar7[1];
      for (piVar9 = (int *)*puVar7; piVar9 != piVar1; piVar9 = piVar9 + 2) {
        iStack_20 = *piVar9;
        if (iStack_20 != 0) {
          iStack_1c = *(int *)(iStack_20 + 0xc);
          iVar6 = FUN_00cffc50();
          iVar4 = iStack_20;
          if ((uint)*(ushort *)(iStack_1c + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
              (uint)*(ushort *)(iVar6 + 0x1da)) {
            if (iStack_20 != 0) {
              if (*(int *)(iStack_18 + 0x34) == *(int *)(param_1 + 0x34)) {
                FUN_0054ef60();
                puVar7 = auStack_3c;
                bVar3 = false;
                bVar2 = true;
              }
              else {
                if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                     DAT_01ee7de0) && (FUN_016f3809(), DAT_01ee7de0 == -1)) {
                  _DAT_01ee7dd8 = 0;
                  DAT_01ee7ddc = 0xf;
                  DAT_01ee7dc8._0_1_ = 0;
                  FUN_016f3654();
                  FUN_016f37bf();
                }
                FUN_0054ef60();
                puVar7 = auStack_54;
                bVar3 = true;
                bVar2 = false;
              }
              uStack_6c = *puVar7;
              uStack_68 = puVar7[1];
              uStack_64 = puVar7[2];
              uStack_60 = puVar7[3];
              uStack_5c = *(undefined8 *)(puVar7 + 4);
              puVar7[4] = 0;
              puVar7[5] = 0xf;
              *(undefined *)puVar7 = 0;
              uStack_8 = 1;
              if (bVar3) {
                FUN_005507b0();
              }
              uStack_8 = CONCAT31(uStack_8._1_3_,2);
              if (bVar2) {
                FUN_005507b0();
              }
              cVar5 = FUN_00684460();
              if (cVar5 != '\0') {
                FUN_0054ef60(&uStack_6c);
                FUN_00d00d70();
                FUN_00b065a0();
              }
              if (*(int *)(iStack_18 + 0x34) == *(int *)(param_1 + 0x34)) {
                puVar8 = (undefined8 *)(iStack_18 + 0x70);
              }
              else {
                puVar8 = (undefined8 *)FUN_0115ee70();
              }
              uStack_48 = *puVar8;
              fStack_28 = *(float *)(iVar4 + 0xa4);
              fStack_40 = *(float *)(puVar8 + 1);
              uStack_30 = *(undefined8 *)(iVar4 + 0x9c);
              if ((NAN((float)uStack_30) || NAN((float)uStack_48)) !=
                  ((float)uStack_30 == (float)uStack_48)) {
                uStack_30._4_4_ = (float)((ulonglong)uStack_30 >> 0x20);
                uStack_48._4_4_ = (float)((ulonglong)uStack_48 >> 0x20);
                if (((NAN(uStack_30._4_4_) || NAN(uStack_48._4_4_)) !=
                     (uStack_30._4_4_ == uStack_48._4_4_)) &&
                   ((NAN(fStack_28) || NAN(fStack_40)) != (fStack_28 == fStack_40)))
                goto LAB_00a6b634;
              }
              FUN_00d00aa0();
              FUN_00b065a0();
LAB_00a6b634:
              FUN_005507b0();
              ExceptionList = pvStack_10;
              return;
            }
            break;
          }
        }
      }
    }
    FUN_00b065a0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21156 ; VA 0x00a6b6a0 ; FUN_00a6b6a0 */

void __fastcall FUN_00a6b6a0(int param_1)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_009b4d50();
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x14c))(*(undefined4 *)(param_1 + 0x58));
  }
  piVar1 = (int *)FUN_009b4e80();
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x14c))(*(undefined4 *)(param_1 + 0x58));
  }
  piVar1 = (int *)FUN_009b6d40();
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x14c))(*(undefined4 *)(param_1 + 0x58));
  }
  piVar1 = (int *)FUN_009b77e0();
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x14c))(*(undefined4 *)(param_1 + 0x58));
  }
  piVar1 = (int *)FUN_009b4e60();
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x14c))(*(undefined4 *)(param_1 + 0x58));
  }
  piVar1 = (int *)FUN_009b6d20();
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x14c))(*(undefined4 *)(param_1 + 0x58));
  }
  return;
}



/* FUNCTION 21157 ; VA 0x00a6b740 ; FUN_00a6b740 */

void __thiscall FUN_00a6b740(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e26d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21158 ; VA 0x00a6b7d0 ; FUN_00a6b7d0 */

undefined4 * FUN_00a6b7d0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a6a340(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 21159 ; VA 0x00a6b840 ; FUN_00a6b840 */

undefined4 * FUN_00a6b840(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a6a550(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 21160 ; VA 0x00a6b8b0 ; FUN_00a6b8b0 */

undefined4 * FUN_00a6b8b0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a6a640(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 21161 ; VA 0x00a6b920 ; FUN_00a6b920 */

undefined4 * FUN_00a6b920(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a6a730(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 21162 ; VA 0x00a6b990 ; FUN_00a6b990 */

undefined4 * FUN_00a6b990(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a6a8e0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 21163 ; VA 0x00a6ba00 ; FUN_00a6ba00 */

undefined4 *
FUN_00a6ba00(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2709;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a6a340(param_1);
  uVar1 = *param_1;
  uStack_8 = 0;
  (**(code **)(*DAT_01ee8128 + 0x10))(uVar1,param_2);
  (**(code **)(*DAT_01ee8160 + 0x10))(uVar1,param_3);
  (**(code **)(*DAT_01ee8198 + 0x10))(uVar1,param_4);
  (**(code **)(*DAT_01ee8208 + 0x10))(uVar1,param_6);
  (**(code **)(*DAT_01ee8240 + 0x10))(uVar1,param_7);
  (**(code **)(*DAT_01ee81d0 + 0x10))(uVar1,param_5);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21164 ; VA 0x00a6bac0 ; FUN_00a6bac0 */

void __fastcall FUN_00a6bac0(int *param_1)

{
  int iVar1;
  
  iVar1 = FUN_009ba880(param_1[0xd]);
  if (iVar1 != 0) {
    (**(code **)(*param_1 + 0xa8))(iVar1);
  }
  return;
}



/* FUNCTION 21165 ; VA 0x00a6baf0 ; FUN_00a6baf0 */

void __thiscall FUN_00a6baf0(int param_1,int param_2,int param_3)

{
  FUN_009cbaa0(param_2 + *(int *)(param_1 + 8),param_3 + *(int *)(param_1 + 8));
  return;
}



/* FUNCTION 21166 ; VA 0x00a6bb10 ; FUN_00a6bb10 */

undefined __fastcall FUN_00a6bb10(int param_1)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2730;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_1 + 8))(auStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar1 = FUN_009cbaa0(uVar3,uVar2);
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar6 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar6 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar6) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar6 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 21167 ; VA 0x00a6bc00 ; FUN_00a6bc00 */

void FUN_00a6bc00(void)

{
  int iVar1;
  
  if (DAT_01ee9114 == 0) {
    iVar1 = FUN_00a698d0();
    DAT_01ee9114 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 21168 ; VA 0x00a6bc20 ; FUN_00a6bc20 */

void FUN_00a6bc20(void)

{
  int iVar1;
  
  if (DAT_01ee8cdc == 0) {
    iVar1 = FUN_00a699b0();
    DAT_01ee8cdc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 21169 ; VA 0x00a6bc40 ; FUN_00a6bc40 */

void FUN_00a6bc40(void)

{
  int iVar1;
  
  if (DAT_01ee8464 == 0) {
    iVar1 = FUN_00a697d0();
    DAT_01ee8464 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 21170 ; VA 0x00a6bc60 ; FUN_00a6bc60 */

void FUN_00a6bc60(void)

{
  int iVar1;
  
  if (DAT_01ee8ac4 == 0) {
    iVar1 = FUN_00a69a90();
    DAT_01ee8ac4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 21171 ; VA 0x00a6bc80 ; FUN_00a6bc80 */

void FUN_00a6bc80(void)

{
  int iVar1;
  
  if (DAT_01ee88a4 == 0) {
    iVar1 = FUN_00a69b90();
    DAT_01ee88a4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 21172 ; VA 0x00a6bca0 ; FUN_00a6bca0 */

void FUN_00a6bca0(void)

{
  int iVar1;
  
  if (DAT_01ee8684 == 0) {
    iVar1 = FUN_00a69c90();
    DAT_01ee8684 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 21173 ; VA 0x00a6bcc0 ; FUN_00a6bcc0 */

void FUN_00a6bcc0(void)

{
  int iVar1;
  
  if (DAT_01ee8efc == 0) {
    iVar1 = FUN_00a69d90();
    DAT_01ee8efc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 21174 ; VA 0x00a6bce0 ; FUN_00a6bce0 */

void __thiscall FUN_00a6bce0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x90);
  *param_2 = *(undefined8 *)(param_1 + 0x88);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 21175 ; VA 0x00a6bd00 ; FUN_00a6bd00 */

void __thiscall FUN_00a6bd00(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x78);
  *param_2 = *(undefined8 *)(param_1 + 0x70);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 21176 ; VA 0x00a6bd20 ; FUN_00a6bd20 */

void __thiscall FUN_00a6bd20(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x58);
  return;
}



/* FUNCTION 21177 ; VA 0x00a6bd30 ; FUN_00a6bd30 */

void __thiscall FUN_00a6bd30(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x84);
  *param_2 = *(undefined8 *)(param_1 + 0x7c);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 21178 ; VA 0x00a6bd50 ; FUN_00a6bd50 */

void __thiscall FUN_00a6bd50(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x5c);
  return;
}



/* FUNCTION 21179 ; VA 0x00a6bd60 ; FUN_00a6bd60 */

void __thiscall FUN_00a6bd60(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0xa8);
  *param_2 = *(undefined8 *)(param_1 + 0xa0);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 21180 ; VA 0x00a6bd80 ; FUN_00a6bd80 */

void __thiscall FUN_00a6bd80(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x68);
  return;
}



/* FUNCTION 21181 ; VA 0x00a6bd90 ; FUN_00a6bd90 */

void __thiscall FUN_00a6bd90(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x60);
  return;
}



/* FUNCTION 21182 ; VA 0x00a6bda0 ; FUN_00a6bda0 */

void __thiscall FUN_00a6bda0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0xb4);
  *param_2 = *(undefined8 *)(param_1 + 0xac);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 21183 ; VA 0x00a6bdc0 ; FUN_00a6bdc0 */

void __thiscall FUN_00a6bdc0(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x6c);
  return;
}



/* FUNCTION 21184 ; VA 0x00a6bdd0 ; FUN_00a6bdd0 */

undefined * FUN_00a6bdd0(undefined *param_1)

{
  char *pcVar1;
  char *pcVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar1 = (char *)0x0;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(0,pcVar2);
  uStack_8 = 0;
  FUN_009cbbb0(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21185 ; VA 0x00a6be40 ; FUN_00a6be40 */

void __thiscall FUN_00a6be40(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x9c);
  *param_2 = *(undefined8 *)(param_1 + 0x94);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 21186 ; VA 0x00a6be60 ; FUN_00a6be60 */

void __thiscall FUN_00a6be60(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 100);
  return;
}



/* FUNCTION 21187 ; VA 0x00a6be70 ; FUN_00a6be70 */

void __thiscall FUN_00a6be70(int param_1,undefined4 *param_2,int param_3)

{
  *param_2 = *(undefined4 *)(param_3 + *(int *)(param_1 + 8));
  return;
}



/* FUNCTION 21188 ; VA 0x00a6be90 ; FUN_00a6be90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00a6be90(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e26d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  uVar5 = thunk_FUN_0088d190();
  iVar6 = _tls_index;
  *param_3 = uVar5;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar6 * 4) + 0x34) < DAT_01ee9124) {
    FUN_016f3809(&DAT_01ee9124);
    if (DAT_01ee9124 == -1) {
      _DAT_01ee9118 = FUN_005c65f0;
      _DAT_01ee911c = FUN_005c93a0;
      _DAT_01ee9120 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ee9124);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01ee9118) {
    if (param_3 + 2 != puVar4) {
      FUN_005507b0();
      uVar5 = puVar4[1];
      uVar2 = puVar4[2];
      uVar3 = puVar4[3];
      param_3[2] = *puVar4;
      param_3[3] = uVar5;
      param_3[4] = uVar2;
      param_3[5] = uVar3;
      *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
    }
  }
  else {
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_3 + 2);
      param_3[1] = 0;
    }
    param_3[6] = 0;
    param_3[7] = 0;
    uVar5 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    param_3[2] = *puVar4;
    param_3[3] = uVar5;
    param_3[4] = uVar2;
    param_3[5] = uVar3;
    *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    param_3[1] = &DAT_01ee9118;
  }
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    iVar6 = aiStack_28[0];
    if (0xfff < uVar7) {
      iVar6 = *(int *)(aiStack_28[0] + -4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21189 ; VA 0x00a6c010 ; FUN_00a6c010 */

uint FUN_00a6c010(void)

{
  int iVar1;
  
  iVar1 = FUN_00a697d0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 21190 ; VA 0x00a6c030 ; FUN_00a6c030 */

uint FUN_00a6c030(void)

{
  int iVar1;
  
  iVar1 = FUN_00a69a90();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 21191 ; VA 0x00a6c050 ; FUN_00a6c050 */

uint FUN_00a6c050(void)

{
  int iVar1;
  
  iVar1 = FUN_00a69b90();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 21192 ; VA 0x00a6c070 ; FUN_00a6c070 */

uint FUN_00a6c070(void)

{
  int iVar1;
  
  iVar1 = FUN_00a69c90();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 21193 ; VA 0x00a6c090 ; FUN_00a6c090 */

uint FUN_00a6c090(void)

{
  int iVar1;
  
  iVar1 = FUN_00a69d90();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 21194 ; VA 0x00a6c0b0 ; FUN_00a6c0b0 */

uint FUN_00a6c0b0(void)

{
  int iVar1;
  
  iVar1 = FUN_00a697d0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 21195 ; VA 0x00a6c0d0 ; FUN_00a6c0d0 */

uint FUN_00a6c0d0(void)

{
  int iVar1;
  
  iVar1 = FUN_00a69a90();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 21196 ; VA 0x00a6c0f0 ; FUN_00a6c0f0 */

uint FUN_00a6c0f0(void)

{
  int iVar1;
  
  iVar1 = FUN_00a69b90();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 21197 ; VA 0x00a6c110 ; FUN_00a6c110 */

uint FUN_00a6c110(void)

{
  int iVar1;
  
  iVar1 = FUN_00a69c90();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 21198 ; VA 0x00a6c130 ; FUN_00a6c130 */

uint FUN_00a6c130(void)

{
  int iVar1;
  
  iVar1 = FUN_00a69d90();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 21199 ; VA 0x00a6c150 ; FUN_00a6c150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00a6c150(undefined4 param_1)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee7de0) {
    FUN_016f3809(&DAT_01ee7de0);
    if (DAT_01ee7de0 == -1) {
      _DAT_01ee7dd8 = 0;
      DAT_01ee7ddc = 0xf;
      DAT_01ee7dc8._0_1_ = 0;
      FUN_016f3654(&LAB_0188a810);
      FUN_016f37bf(&DAT_01ee7de0);
    }
  }
  FUN_0054ef60(&DAT_01ee7dc8);
  return param_1;
}



/* FUNCTION 21200 ; VA 0x00a6c1d0 ; FUN_00a6c1d0 */

void __thiscall FUN_00a6c1d0(int *param_1,int *param_2)

{
  int iVar1;
  
  FUN_008a3ee0(param_2);
  if ((int *)*param_2 == param_1) {
    if (param_2[2] != 0) {
      iVar1 = FUN_009ba880(param_2[2]);
      if (iVar1 != 0) {
        (**(code **)(*param_1 + 0xa8))(iVar1);
      }
    }
    if (param_2[1] != 0) {
      iVar1 = FUN_009ba880(param_2[1]);
      if (iVar1 != 0) {
        (**(code **)(*param_1 + 0xa8))(iVar1);
      }
    }
  }
  return;
}



/* FUNCTION 21201 ; VA 0x00a6c230 ; FUN_00a6c230 */

void __thiscall
FUN_00a6c230(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  (**(code **)(*DAT_01ee8128 + 0x10))(param_1,param_2);
  (**(code **)(*DAT_01ee8160 + 0x10))(param_1,param_3);
  (**(code **)(*DAT_01ee8198 + 0x10))(param_1,param_4);
  (**(code **)(*DAT_01ee8208 + 0x10))(param_1,param_6);
  (**(code **)(*DAT_01ee8240 + 0x10))(param_1,param_7);
  (**(code **)(*DAT_01ee81d0 + 0x10))(param_1,param_5);
  return;
}



/* FUNCTION 21202 ; VA 0x00a6c2a0 ; FUN_00a6c2a0 */

void __thiscall FUN_00a6c2a0(int *param_1,float param_2,float param_3,float param_4)

{
  int iVar1;
  
  if ((((NAN(param_2) || NAN((float)param_1[0x22])) == (param_2 == (float)param_1[0x22])) ||
      ((NAN(param_3) || NAN((float)param_1[0x23])) == (param_3 == (float)param_1[0x23]))) ||
     ((NAN(param_4) || NAN((float)param_1[0x24])) == (param_4 == (float)param_1[0x24]))) {
    param_1[0x22] = (int)param_2;
    param_1[0x23] = (int)param_3;
    param_1[0x24] = (int)param_4;
    FUN_008a4940(&DAT_01ee7ec4);
    iVar1 = FUN_009ba880(param_1[0xd]);
    if (iVar1 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar1);
    }
  }
  return;
}



/* FUNCTION 21203 ; VA 0x00a6c320 ; FUN_00a6c320 */

void __thiscall FUN_00a6c320(int *param_1,float param_2,float param_3,float param_4)

{
  int iVar1;
  
  if ((((NAN(param_2) || NAN((float)param_1[0x1c])) == (param_2 == (float)param_1[0x1c])) ||
      ((NAN(param_3) || NAN((float)param_1[0x1d])) == (param_3 == (float)param_1[0x1d]))) ||
     ((NAN(param_4) || NAN((float)param_1[0x1e])) == (param_4 == (float)param_1[0x1e]))) {
    param_1[0x1c] = (int)param_2;
    param_1[0x1d] = (int)param_3;
    param_1[0x1e] = (int)param_4;
    FUN_008a4940(&DAT_01ee7e1c);
    iVar1 = FUN_009ba880(param_1[0xd]);
    if (iVar1 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar1);
    }
  }
  return;
}



/* FUNCTION 21204 ; VA 0x00a6c390 ; FUN_00a6c390 */

void __thiscall FUN_00a6c390(int *param_1,float param_2,float param_3,float param_4)

{
  int *piVar1;
  int iVar2;
  undefined auStack_8 [4];
  
  piVar1 = (int *)FUN_00c987e0(auStack_8,CONCAT44(param_3,param_2),param_4);
  if ((((NAN(param_2) || NAN((float)param_1[0x1c])) == (param_2 == (float)param_1[0x1c])) ||
      ((NAN(param_3) || NAN((float)param_1[0x1d])) == (param_3 == (float)param_1[0x1d]))) ||
     ((NAN(param_4) || NAN((float)param_1[0x1e])) == (param_4 == (float)param_1[0x1e]))) {
    if (*piVar1 != param_1[0x16]) {
      param_1[0x16] = *piVar1;
      FUN_008a4940(&DAT_01ee7fa4);
    }
    param_1[0x1c] = (int)param_2;
    param_1[0x1d] = (int)param_3;
    param_1[0x1e] = (int)param_4;
    FUN_008a4940(&DAT_01ee80f4);
    iVar2 = FUN_009ba880(param_1[0xd]);
    if (iVar2 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar2);
    }
  }
  return;
}



/* FUNCTION 21205 ; VA 0x00a6c460 ; FUN_00a6c460 */

void __thiscall FUN_00a6c460(int *param_1,int param_2)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  int iVar3;
  undefined auStack_1c [12];
  undefined8 uStack_10;
  float fStack_8;
  
  puVar2 = (undefined8 *)FUN_00c98ad0(auStack_1c);
  uVar1 = *puVar2;
  fStack_8 = *(float *)(puVar2 + 1);
  uStack_10._0_4_ = (float)uVar1;
  if ((((NAN((float)uStack_10) || NAN((float)param_1[0x1c])) ==
        ((float)uStack_10 == (float)param_1[0x1c])) ||
      (uStack_10._4_4_ = (float)((ulonglong)uVar1 >> 0x20),
      (NAN(uStack_10._4_4_) || NAN((float)param_1[0x1d])) ==
      (uStack_10._4_4_ == (float)param_1[0x1d]))) ||
     ((NAN(fStack_8) || NAN((float)param_1[0x1e])) == (fStack_8 == (float)param_1[0x1e]))) {
    uStack_10 = uVar1;
    if (param_2 != param_1[0x16]) {
      param_1[0x16] = param_2;
      FUN_008a4940(&DAT_01ee7fa4);
    }
    param_1[0x1c] = (int)(float)uStack_10;
    param_1[0x1d] = (int)uStack_10._4_4_;
    param_1[0x1e] = (int)fStack_8;
    FUN_008a4940(&DAT_01ee80f4);
    iVar3 = FUN_009ba880(param_1[0xd]);
    if (iVar3 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar3);
    }
  }
  return;
}



/* FUNCTION 21206 ; VA 0x00a6c520 ; FUN_00a6c520 */

void __thiscall FUN_00a6c520(int *param_1,float param_2,float param_3,float param_4)

{
  int *piVar1;
  int iVar2;
  undefined auStack_8 [4];
  
  piVar1 = (int *)FUN_00c987e0(auStack_8,CONCAT44(param_3,param_2),param_4);
  if ((((NAN(param_2) || NAN((float)param_1[0x1f])) == (param_2 == (float)param_1[0x1f])) ||
      ((NAN(param_3) || NAN((float)param_1[0x20])) == (param_3 == (float)param_1[0x20]))) ||
     ((NAN(param_4) || NAN((float)param_1[0x21])) == (param_4 == (float)param_1[0x21]))) {
    if (*piVar1 != param_1[0x17]) {
      param_1[0x17] = *piVar1;
      FUN_008a4940(&DAT_01ee7fdc);
    }
    param_1[0x1f] = (int)param_2;
    param_1[0x20] = (int)param_3;
    param_1[0x21] = (int)param_4;
    FUN_008a4940(&DAT_01ee812c);
    iVar2 = FUN_009ba880(param_1[0xd]);
    if (iVar2 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar2);
    }
  }
  return;
}



/* FUNCTION 21207 ; VA 0x00a6c600 ; FUN_00a6c600 */

void __thiscall FUN_00a6c600(int *param_1,int param_2)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  int iVar3;
  undefined auStack_1c [12];
  undefined8 uStack_10;
  float fStack_8;
  
  puVar2 = (undefined8 *)FUN_00c98ad0(auStack_1c);
  uVar1 = *puVar2;
  fStack_8 = *(float *)(puVar2 + 1);
  uStack_10._0_4_ = (float)uVar1;
  if ((((NAN((float)uStack_10) || NAN((float)param_1[0x1f])) ==
        ((float)uStack_10 == (float)param_1[0x1f])) ||
      (uStack_10._4_4_ = (float)((ulonglong)uVar1 >> 0x20),
      (NAN(uStack_10._4_4_) || NAN((float)param_1[0x20])) ==
      (uStack_10._4_4_ == (float)param_1[0x20]))) ||
     ((NAN(fStack_8) || NAN((float)param_1[0x21])) == (fStack_8 == (float)param_1[0x21]))) {
    uStack_10 = uVar1;
    if (param_2 != param_1[0x17]) {
      param_1[0x17] = param_2;
      FUN_008a4940(&DAT_01ee7fdc);
    }
    param_1[0x1f] = (int)(float)uStack_10;
    param_1[0x20] = (int)uStack_10._4_4_;
    param_1[0x21] = (int)fStack_8;
    FUN_008a4940(&DAT_01ee812c);
    iVar3 = FUN_009ba880(param_1[0xd]);
    if (iVar3 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar3);
    }
  }
  return;
}



/* FUNCTION 21208 ; VA 0x00a6c6d0 ; FUN_00a6c6d0 */

void FUN_00a6c6d0(undefined8 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  uVar2 = (undefined4)((ulonglong)param_1 >> 0x20);
  puVar1 = (undefined4 *)FUN_00c987e0(auStack_8,(int)param_1,uVar2,param_2);
  FUN_00a6c760((int)param_1,uVar2,param_2,*puVar1);
  return;
}



/* FUNCTION 21209 ; VA 0x00a6c720 ; FUN_00a6c720 */

void FUN_00a6c720(undefined4 param_1)

{
  undefined8 *puVar1;
  undefined auStack_10 [12];
  
  puVar1 = (undefined8 *)FUN_00c98ad0(auStack_10);
  FUN_00a6c760(*puVar1,*(undefined4 *)(puVar1 + 1),param_1);
  return;
}



/* FUNCTION 21210 ; VA 0x00a6c760 ; FUN_00a6c760 */

void __thiscall FUN_00a6c760(int *param_1,float param_2,float param_3,float param_4,int param_5)

{
  int iVar1;
  
  if ((((NAN(param_2) || NAN((float)param_1[0x28])) == (param_2 == (float)param_1[0x28])) ||
      ((NAN(param_3) || NAN((float)param_1[0x29])) == (param_3 == (float)param_1[0x29]))) ||
     ((NAN(param_4) || NAN((float)param_1[0x2a])) == (param_4 == (float)param_1[0x2a]))) {
    if (param_5 != param_1[0x1a]) {
      param_1[0x1a] = param_5;
      FUN_008a4940(&DAT_01ee8084);
    }
    param_1[0x28] = (int)param_2;
    param_1[0x29] = (int)param_3;
    param_1[0x2a] = (int)param_4;
    FUN_008a4940(&DAT_01ee81d4);
    iVar1 = FUN_009ba880(param_1[0xd]);
    if (iVar1 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar1);
    }
  }
  return;
}



/* FUNCTION 21211 ; VA 0x00a6c810 ; FUN_00a6c810 */

void FUN_00a6c810(undefined8 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  uVar2 = (undefined4)((ulonglong)param_1 >> 0x20);
  puVar1 = (undefined4 *)FUN_00c987e0(auStack_8,(int)param_1,uVar2,param_2);
  FUN_00a6c8a0((int)param_1,uVar2,param_2,*puVar1);
  return;
}



/* FUNCTION 21212 ; VA 0x00a6c860 ; FUN_00a6c860 */

void FUN_00a6c860(undefined4 param_1)

{
  undefined8 *puVar1;
  undefined auStack_10 [12];
  
  puVar1 = (undefined8 *)FUN_00c98ad0(auStack_10);
  FUN_00a6c8a0(*puVar1,*(undefined4 *)(puVar1 + 1),param_1);
  return;
}



/* FUNCTION 21213 ; VA 0x00a6c8a0 ; FUN_00a6c8a0 */

void __thiscall FUN_00a6c8a0(int *param_1,float param_2,float param_3,float param_4,int param_5)

{
  int iVar1;
  
  if ((((NAN(param_2) || NAN((float)param_1[0x22])) == (param_2 == (float)param_1[0x22])) ||
      ((NAN(param_3) || NAN((float)param_1[0x23])) == (param_3 == (float)param_1[0x23]))) ||
     ((NAN(param_4) || NAN((float)param_1[0x24])) == (param_4 == (float)param_1[0x24]))) {
    if (param_5 != param_1[0x18]) {
      param_1[0x18] = param_5;
      FUN_008a4940(&DAT_01ee8014);
    }
    param_1[0x22] = (int)param_2;
    param_1[0x23] = (int)param_3;
    param_1[0x24] = (int)param_4;
    FUN_008a4940(&DAT_01ee8164);
    iVar1 = FUN_009ba880(param_1[0xd]);
    if (iVar1 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar1);
    }
  }
  return;
}



/* FUNCTION 21214 ; VA 0x00a6c950 ; FUN_00a6c950 */

void FUN_00a6c950(undefined8 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  uVar2 = (undefined4)((ulonglong)param_1 >> 0x20);
  puVar1 = (undefined4 *)FUN_00c987e0(auStack_8,(int)param_1,uVar2,param_2);
  FUN_00a6c9e0((int)param_1,uVar2,param_2,*puVar1);
  return;
}



/* FUNCTION 21215 ; VA 0x00a6c9a0 ; FUN_00a6c9a0 */

void FUN_00a6c9a0(undefined4 param_1)

{
  undefined8 *puVar1;
  undefined auStack_10 [12];
  
  puVar1 = (undefined8 *)FUN_00c98ad0(auStack_10);
  FUN_00a6c9e0(*puVar1,*(undefined4 *)(puVar1 + 1),param_1);
  return;
}



/* FUNCTION 21216 ; VA 0x00a6c9e0 ; FUN_00a6c9e0 */

void __thiscall FUN_00a6c9e0(int *param_1,float param_2,float param_3,float param_4,int param_5)

{
  int iVar1;
  
  if ((((NAN(param_2) || NAN((float)param_1[0x2b])) == (param_2 == (float)param_1[0x2b])) ||
      ((NAN(param_3) || NAN((float)param_1[0x2c])) == (param_3 == (float)param_1[0x2c]))) ||
     ((NAN(param_4) || NAN((float)param_1[0x2d])) == (param_4 == (float)param_1[0x2d]))) {
    if (param_5 != param_1[0x1b]) {
      param_1[0x1b] = param_5;
      FUN_008a4940(&DAT_01ee80bc);
    }
    param_1[0x2b] = (int)param_2;
    param_1[0x2c] = (int)param_3;
    param_1[0x2d] = (int)param_4;
    FUN_008a4940(&DAT_01ee820c);
    iVar1 = FUN_009ba880(param_1[0xd]);
    if (iVar1 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar1);
    }
  }
  return;
}



/* FUNCTION 21217 ; VA 0x00a6ca90 ; FUN_00a6ca90 */

void __thiscall FUN_00a6ca90(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2748;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00684460(&param_2,param_1 + 0x58);
  if (cVar1 != '\0') {
    (**(code **)(*DAT_01ee7e88 + 0x10))(param_1,&param_2);
    FUN_008a4940(&DAT_01ee7f34);
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21218 ; VA 0x00a6cb30 ; FUN_00a6cb30 */

void __thiscall FUN_00a6cb30(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2748;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00684460(&param_2,param_1 + 0x70);
  if (cVar1 != '\0') {
    (**(code **)(*DAT_01ee7ec0 + 0x10))(param_1,&param_2);
    FUN_008a4940(&DAT_01ee7efc);
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21219 ; VA 0x00a6cbd0 ; FUN_00a6cbd0 */

void FUN_00a6cbd0(undefined8 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  uVar2 = (undefined4)((ulonglong)param_1 >> 0x20);
  puVar1 = (undefined4 *)FUN_00c987e0(auStack_8,(int)param_1,uVar2,param_2);
  FUN_00a6cc60((int)param_1,uVar2,param_2,*puVar1);
  return;
}



/* FUNCTION 21220 ; VA 0x00a6cc20 ; FUN_00a6cc20 */

void FUN_00a6cc20(undefined4 param_1)

{
  undefined8 *puVar1;
  undefined auStack_10 [12];
  
  puVar1 = (undefined8 *)FUN_00c98ad0(auStack_10);
  FUN_00a6cc60(*puVar1,*(undefined4 *)(puVar1 + 1),param_1);
  return;
}



/* FUNCTION 21221 ; VA 0x00a6cc60 ; FUN_00a6cc60 */

void __thiscall FUN_00a6cc60(int *param_1,float param_2,float param_3,float param_4,int param_5)

{
  int iVar1;
  
  if ((((NAN(param_2) || NAN((float)param_1[0x25])) == (param_2 == (float)param_1[0x25])) ||
      ((NAN(param_3) || NAN((float)param_1[0x26])) == (param_3 == (float)param_1[0x26]))) ||
     ((NAN(param_4) || NAN((float)param_1[0x27])) == (param_4 == (float)param_1[0x27]))) {
    if (param_5 != param_1[0x19]) {
      param_1[0x19] = param_5;
      FUN_008a4940(&DAT_01ee804c);
    }
    param_1[0x25] = (int)param_2;
    param_1[0x26] = (int)param_3;
    param_1[0x27] = (int)param_4;
    FUN_008a4940(&DAT_01ee819c);
    iVar1 = FUN_009ba880(param_1[0xd]);
    if (iVar1 != 0) {
      (**(code **)(*param_1 + 0xa8))(iVar1);
    }
  }
  return;
}



/* FUNCTION 21222 ; VA 0x00a6cd10 ; FUN_00a6cd10 */

void __thiscall FUN_00a6cd10(int param_1,int param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  char cVar2;
  
  cVar2 = FUN_009cbaa0(*(int *)(param_1 + 8) + param_2,param_3);
  if (cVar2 == '\0') {
    if ((undefined4 *)(*(int *)(param_1 + 8) + param_2) != param_3) {
      puVar1 = param_3 + 4;
      if (0xf < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      FUN_005542c0(param_3,*puVar1);
    }
    if (*(code **)(param_1 + 0x10) != (code *)0x0) {
      (**(code **)(param_1 + 0x10))(*(undefined4 *)(param_1 + 4));
    }
    FUN_008a4940(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 21223 ; VA 0x00a6cd70 ; FUN_00a6cd70 */

void __thiscall FUN_00a6cd70(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e26d8;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a6aa70(aiStack_28);
  uStack_8 = 0;
  (*pcVar1)(param_2,uVar2);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21224 ; VA 0x00a6ce00 ; FUN_00a6ce00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a6ce00(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee9124) {
    FUN_016f3809(&DAT_01ee9124);
    if (DAT_01ee9124 == -1) {
      _DAT_01ee9118 = FUN_005c65f0;
      _DAT_01ee911c = FUN_005c93a0;
      _DAT_01ee9120 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ee9124);
    }
  }
  return &DAT_01ee9118;
}



/* FUNCTION 21225 ; VA 0x00a6ce70 ; FUN_00a6ce70 */

uint FUN_00a6ce70(int *param_1)

{
  return param_1[2] * 0x4f9ffb7 ^ param_1[1] * 0x127409f ^ *param_1 * 0x466f45d;
}



/* FUNCTION 21226 ; VA 0x00a6ce90 ; FUN_00a6ce90 */

bool __thiscall FUN_00a6ce90(uint *param_1,uint *param_2)

{
  return *param_1 < *param_2;
}



/* FUNCTION 21227 ; VA 0x00a6ceb0 ; FUN_00a6ceb0 */

void FUN_00a6ceb0(int param_1,int param_2)

{
  undefined8 *puVar1;
  int *piVar2;
  undefined8 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iStack_20;
  int iStack_1c;
  
  uVar6 = (param_2 - param_1) / 0xc;
  iVar9 = (int)uVar6 >> 1;
  if (0 < iVar9) {
    iVar10 = (int)(uVar6 - 1) >> 1;
    iVar7 = param_1 + iVar9 * 0xc;
    do {
      uVar3 = *(undefined8 *)(iVar7 + -0xc);
      iVar9 = iVar9 + -1;
      iVar4 = *(int *)(iVar7 + -4);
      iVar11 = iVar9;
      while (iVar11 < iVar10) {
        iVar5 = *(int *)(param_1 + 0x18 + iVar11 * 0x18);
        iVar8 = *(int *)(param_1 + 0xc + iVar11 * 0x18);
        if ((iVar5 < iVar8) ||
           ((iVar5 == iVar8 &&
            ((iVar5 = *(int *)(param_1 + 0x1c + iVar11 * 0x18),
             iVar8 = *(int *)(param_1 + 0x10 + iVar11 * 0x18), iVar5 < iVar8 ||
             ((iVar5 == iVar8 &&
              (*(int *)(param_1 + 0x20 + iVar11 * 0x18) < *(int *)(param_1 + 0x14 + iVar11 * 0x18)))
             )))))) {
          iVar8 = 1;
        }
        else {
          iVar8 = 2;
        }
        iVar8 = iVar11 * 2 + iVar8;
        puVar1 = (undefined8 *)(param_1 + iVar11 * 0xc);
        *puVar1 = *(undefined8 *)(param_1 + iVar8 * 0xc);
        *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_1 + iVar8 * 0xc + 8);
        iVar11 = iVar8;
      }
      if ((iVar11 == iVar10) && ((uVar6 & 1) == 0)) {
        puVar1 = (undefined8 *)(param_1 + iVar11 * 0xc);
        *puVar1 = *(undefined8 *)(param_1 + -0xc + uVar6 * 0xc);
        *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_1 + uVar6 * 0xc + -4);
        iVar11 = uVar6 - 1;
      }
      if (iVar9 < iVar11) {
        iStack_1c = (int)((ulonglong)uVar3 >> 0x20);
        do {
          iVar8 = iVar11 + -1 >> 1;
          piVar2 = (int *)(param_1 + iVar8 * 0xc);
          iStack_20 = (int)uVar3;
          if ((iStack_20 <= *piVar2) &&
             ((*piVar2 != iStack_20 ||
              ((iStack_1c <= piVar2[1] && ((piVar2[1] != iStack_1c || (iVar4 <= piVar2[2]))))))))
          break;
          puVar1 = (undefined8 *)(param_1 + iVar11 * 0xc);
          *puVar1 = *(undefined8 *)piVar2;
          *(int *)(puVar1 + 1) = piVar2[2];
          iVar11 = iVar8;
        } while (iVar9 < iVar8);
      }
      *(undefined8 *)(param_1 + iVar11 * 0xc) = uVar3;
      *(int *)(param_1 + 8 + iVar11 * 0xc) = iVar4;
      iVar7 = iVar7 + -0xc;
    } while (0 < iVar9);
  }
  return;
}



/* FUNCTION 21228 ; VA 0x00a6d010 ; FUN_00a6d010 */

void FUN_00a6d010(int *param_1,int *param_2,int *param_3)

{
  undefined8 uVar1;
  int iVar2;
  
  iVar2 = *param_2;
  if ((iVar2 < *param_1) ||
     ((iVar2 == *param_1 &&
      ((param_2[1] < param_1[1] || ((param_2[1] == param_1[1] && (param_2[2] < param_1[2])))))))) {
    iVar2 = param_2[2];
    uVar1 = *(undefined8 *)param_2;
    *(undefined8 *)param_2 = *(undefined8 *)param_1;
    param_2[2] = param_1[2];
    *(undefined8 *)param_1 = uVar1;
    param_1[2] = iVar2;
    iVar2 = *param_2;
  }
  if ((*param_3 < iVar2) ||
     ((*param_3 == iVar2 &&
      ((param_3[1] < param_2[1] || ((param_3[1] == param_2[1] && (param_3[2] < param_2[2])))))))) {
    uVar1 = *(undefined8 *)param_3;
    iVar2 = param_3[2];
    *(undefined8 *)param_3 = *(undefined8 *)param_2;
    param_3[2] = param_2[2];
    *(undefined8 *)param_2 = uVar1;
    param_2[2] = iVar2;
    if ((*param_2 < *param_1) ||
       ((*param_2 == *param_1 &&
        ((param_2[1] < param_1[1] || ((param_2[1] == param_1[1] && (iVar2 < param_1[2])))))))) {
      *(undefined8 *)param_2 = *(undefined8 *)param_1;
      param_2[2] = param_1[2];
      *(undefined8 *)param_1 = uVar1;
      param_1[2] = iVar2;
    }
  }
  return;
}



/* FUNCTION 21229 ; VA 0x00a6d0c0 ; FUN_00a6d0c0 */

void FUN_00a6d0c0(undefined4 *param_1,int *param_2,int *param_3,int *param_4)

{
  undefined8 uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  int *piVar11;
  bool bVar12;
  int *piStack_c;
  int *piStack_8;
  
  piVar4 = param_3 + -3;
  piVar10 = param_2 + (((int)param_3 - (int)param_2) / 0xc >> 1) * 3;
  iVar3 = ((int)piVar4 - (int)param_2) / 0xc;
  if (iVar3 < 0x29) {
    FUN_00a6d010(param_2,piVar10,piVar4,param_4);
  }
  else {
    iVar3 = iVar3 + 1 >> 3;
    FUN_00a6d010(param_2,param_2 + iVar3 * 3,param_2 + iVar3 * 6,param_4);
    FUN_00a6d010(piVar10 + iVar3 * -3,piVar10,piVar10 + iVar3 * 3,param_4);
    FUN_00a6d010(piVar4 + iVar3 * -6,piVar4 + iVar3 * -3,piVar4,param_4);
    FUN_00a6d010(param_2 + iVar3 * 3,piVar10,piVar4 + iVar3 * -3,param_4);
  }
  piVar4 = piVar10 + 3;
  for (; param_2 < piVar10; piVar10 = piVar10 + -3) {
    iVar3 = piVar10[-3];
    iVar5 = *piVar10;
    if ((iVar3 < iVar5) ||
       ((((iVar3 == iVar5 &&
          ((piVar10[-2] < piVar10[1] ||
           (((iVar5 == iVar3 && (piVar10[-2] == piVar10[1])) && (piVar10[-1] < piVar10[2])))))) ||
         (iVar5 < iVar3)) ||
        ((iVar5 == iVar3 &&
         ((piVar10[1] < piVar10[-2] || ((piVar10[1] == piVar10[-2] && (piVar10[2] < piVar10[-1])))))
         ))))) break;
  }
  piVar6 = piVar4;
  param_4 = piVar4;
  piStack_c = piVar4;
  piStack_8 = piVar10;
  piVar8 = piVar10;
  if (piVar4 < param_3) {
    iVar3 = *piVar10;
    while( true ) {
      iVar5 = *piVar4;
      piVar6 = piVar4;
      param_4 = piVar4;
      piStack_c = piVar4;
      if (((iVar5 < iVar3) ||
          ((iVar5 == iVar3 &&
           ((piVar4[1] < piVar10[1] || ((piVar4[1] == piVar10[1] && (piVar4[2] < piVar10[2]))))))))
         || (iVar3 < iVar5)) break;
      if (((iVar3 == iVar5) &&
          ((piVar10[1] < piVar4[1] ||
           (((iVar3 == iVar5 && (piVar10[1] == piVar4[1])) && (piVar10[2] < piVar4[2])))))) ||
         (piVar4 = piVar4 + 3, piVar6 = piVar4, param_4 = piVar4, piStack_c = piVar4,
         param_3 <= piVar4)) break;
    }
  }
joined_r0x00a6d238:
  do {
    if (param_3 <= piVar4) {
LAB_00a6d2af:
      piVar7 = piVar6;
      piVar11 = piVar10;
      if (param_2 < piVar10) {
        piVar10 = piStack_8 + -2;
        piVar6 = piVar8;
        do {
          iVar3 = piVar10[-1];
          iVar5 = *piVar6;
          piVar8 = piVar6;
          piVar4 = piStack_c;
          piVar7 = param_4;
          if (iVar5 <= iVar3) {
            if (iVar3 == iVar5) {
              if (piVar6[1] <= *piVar10) {
                iVar5 = *piVar6;
                iVar2 = iVar5 - iVar3;
                bVar12 = iVar5 == iVar3;
                if (!bVar12) goto LAB_00a6d2ed;
                if ((*piVar10 != piVar6[1]) || (piVar6[2] <= piVar10[1])) {
                  iVar5 = *piVar6;
                  goto LAB_00a6d2eb;
                }
              }
            }
            else {
LAB_00a6d2eb:
              iVar2 = iVar5 - iVar3;
              bVar12 = iVar5 == iVar3;
LAB_00a6d2ed:
              piVar11 = piStack_8;
              if ((SBORROW4(iVar5,iVar3) != iVar2 < 0) ||
                 ((bVar12 &&
                  ((piVar6[1] < *piVar10 || ((piVar6[1] == *piVar10 && (piVar6[2] < piVar10[1]))))))
                 )) break;
              piVar8 = piVar6 + -3;
              if (piVar8 != piVar10 + -1) {
                uVar1 = *(undefined8 *)piVar8;
                iVar3 = piVar6[-1];
                *(undefined8 *)piVar8 = *(undefined8 *)(piVar10 + -1);
                piVar6[-1] = piVar10[1];
                *(undefined8 *)(piVar10 + -1) = uVar1;
                piVar10[1] = iVar3;
              }
            }
          }
          piStack_8 = piStack_8 + -3;
          piVar10 = piVar10 + -3;
          piVar6 = piVar8;
          piVar11 = piStack_8;
        } while (param_2 < piStack_8);
      }
      if (piVar11 == param_2) {
        if (piVar4 == param_3) {
          *param_1 = piVar8;
          param_1[1] = piVar7;
          return;
        }
        if (piVar7 != piVar4) {
          uVar1 = *(undefined8 *)piVar8;
          iVar3 = piVar8[2];
          *(undefined8 *)piVar8 = *(undefined8 *)piVar7;
          piVar8[2] = piVar7[2];
          *(undefined8 *)piVar7 = uVar1;
          piVar7[2] = iVar3;
        }
        uVar1 = *(undefined8 *)piVar8;
        iVar3 = piVar8[2];
        *(undefined8 *)piVar8 = *(undefined8 *)piVar4;
        piVar8[2] = piVar4[2];
        *(undefined8 *)piVar4 = uVar1;
        piVar4[2] = iVar3;
        piVar4 = piVar4 + 3;
        piVar6 = piVar7 + 3;
        piVar10 = piVar11;
        param_4 = piVar7 + 3;
        piStack_c = piVar4;
        piVar8 = piVar8 + 3;
      }
      else {
        piVar10 = piVar11 + -3;
        piStack_8 = piVar10;
        if (piVar4 == param_3) {
          piVar9 = piVar8 + -3;
          if (piVar10 != piVar9) {
            uVar1 = *(undefined8 *)piVar10;
            iVar3 = piVar11[-1];
            *(undefined8 *)piVar10 = *(undefined8 *)piVar9;
            piVar11[-1] = piVar8[-1];
            *(undefined8 *)piVar9 = uVar1;
            piVar8[-1] = iVar3;
          }
          piVar6 = piVar7 + -3;
          uVar1 = *(undefined8 *)piVar9;
          iVar3 = piVar8[-1];
          *(undefined8 *)piVar9 = *(undefined8 *)(piVar7 + -3);
          piVar8[-1] = piVar7[-1];
          *(undefined8 *)piVar6 = uVar1;
          piVar7[-1] = iVar3;
          param_4 = piVar6;
          piVar8 = piVar9;
        }
        else {
          uVar1 = *(undefined8 *)piVar4;
          iVar3 = piVar4[2];
          *(undefined8 *)piVar4 = *(undefined8 *)piVar10;
          piVar4[2] = piVar11[-1];
          piVar4 = piVar4 + 3;
          *(undefined8 *)piVar10 = uVar1;
          piVar11[-1] = iVar3;
          piVar6 = piVar7;
          piStack_c = piVar4;
        }
      }
      goto joined_r0x00a6d238;
    }
    iVar3 = *piVar8;
    iVar5 = *piVar4;
    piVar10 = piStack_8;
    if ((iVar5 <= iVar3) &&
       ((iVar3 != iVar5 ||
        ((piVar4[1] <= piVar8[1] && ((piVar8[1] != piVar4[1] || (piVar4[2] <= piVar8[2])))))))) {
      param_4 = piVar6;
      piStack_c = piVar4;
      if ((iVar5 < iVar3) ||
         ((iVar5 == iVar3 &&
          ((piVar4[1] < piVar8[1] ||
           (((iVar5 == iVar3 && (piVar4[1] == piVar8[1])) && (piVar4[2] < piVar8[2]))))))))
      goto LAB_00a6d2af;
      if (piVar6 != piVar4) {
        uVar1 = *(undefined8 *)piVar6;
        iVar3 = piVar6[2];
        *(undefined8 *)piVar6 = *(undefined8 *)piVar4;
        piVar6[2] = piVar4[2];
        *(undefined8 *)piVar4 = uVar1;
        piVar4[2] = iVar3;
      }
      piVar6 = piVar6 + 3;
    }
    piVar4 = piVar4 + 3;
    param_4 = piVar6;
    piStack_c = piVar4;
  } while( true );
}



/* FUNCTION 21230 ; VA 0x00a6d430 ; FUN_00a6d430 */

void FUN_00a6d430(int param_1,int param_2,uint param_3,int *param_4)

{
  undefined8 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar3 = (int)(param_3 - 1) >> 1;
  iVar5 = param_2;
  iVar4 = param_2;
  if (param_2 < iVar3) {
    do {
      iVar4 = param_1 + iVar5 * 0x18;
      if ((*(int *)(iVar4 + 0x18) < *(int *)(iVar4 + 0xc)) ||
         ((*(int *)(iVar4 + 0x18) == *(int *)(iVar4 + 0xc) &&
          ((*(int *)(iVar4 + 0x1c) < *(int *)(iVar4 + 0x10) ||
           ((*(int *)(iVar4 + 0x1c) == *(int *)(iVar4 + 0x10) &&
            (*(int *)(iVar4 + 0x20) < *(int *)(iVar4 + 0x14))))))))) {
        iVar4 = 1;
      }
      else {
        iVar4 = 2;
      }
      iVar4 = iVar5 * 2 + iVar4;
      puVar1 = (undefined8 *)(param_1 + iVar5 * 0xc);
      *puVar1 = *(undefined8 *)(param_1 + iVar4 * 0xc);
      *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_1 + iVar4 * 0xc + 8);
      iVar5 = iVar4;
    } while (iVar4 < iVar3);
  }
  if ((iVar4 == iVar3) && ((param_3 & 1) == 0)) {
    puVar1 = (undefined8 *)(param_1 + iVar4 * 0xc);
    *puVar1 = *(undefined8 *)(param_1 + -0xc + param_3 * 0xc);
    *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_1 + param_3 * 0xc + -4);
    iVar4 = param_3 - 1;
  }
  while (param_2 < iVar4) {
    iVar5 = iVar4 + -1 >> 1;
    piVar2 = (int *)(param_1 + iVar5 * 0xc);
    if ((*param_4 <= *piVar2) &&
       ((*piVar2 != *param_4 ||
        ((param_4[1] <= piVar2[1] && ((piVar2[1] != param_4[1] || (param_4[2] <= piVar2[2]))))))))
    break;
    puVar1 = (undefined8 *)(param_1 + iVar4 * 0xc);
    *puVar1 = *(undefined8 *)piVar2;
    *(int *)(puVar1 + 1) = piVar2[2];
    iVar4 = iVar5;
  }
  puVar1 = (undefined8 *)(param_1 + iVar4 * 0xc);
  *puVar1 = *(undefined8 *)param_4;
  *(int *)(puVar1 + 1) = param_4[2];
  return;
}



/* FUNCTION 21231 ; VA 0x00a6d550 ; FUN_00a6d550 */

void __thiscall FUN_00a6d550(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  undefined2 *puVar3;
  uint uVar4;
  undefined2 *puVar5;
  uint uVar6;
  uint uVar7;
  
  puVar3 = (undefined2 *)param_1[1];
  uVar7 = *param_1;
  uVar4 = (int)((int)puVar3 - uVar7) >> 1;
  uVar6 = (int)(param_1[2] - uVar7) >> 1;
  if (param_2 <= uVar6) {
    if (uVar4 < param_2) {
      iVar2 = param_2 - uVar4;
      if (iVar2 != 0) {
        do {
          *puVar3 = 0;
          puVar3 = puVar3 + 1;
          iVar2 = iVar2 + -1;
        } while (iVar2 != 0);
        param_1[1] = (uint)puVar3;
        return;
      }
    }
    else {
      if (param_2 == uVar4) {
        return;
      }
      puVar3 = (undefined2 *)(uVar7 + param_2 * 2);
    }
    param_1[1] = (uint)puVar3;
    return;
  }
  if (0x7fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = param_2;
  if ((uVar6 <= 0x7fffffff - (uVar6 >> 1)) && (uVar7 = (uVar6 >> 1) + uVar6, uVar7 < param_2)) {
    uVar7 = param_2;
  }
  uVar6 = uVar7 * 2;
  if (uVar7 < 0x80000000) {
    uVar7 = uVar6;
    if (0xfff < uVar6) goto LAB_00a6d5bf;
    if (uVar6 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar6);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00a6d5bf:
    uVar1 = uVar7 + 0x23;
    if (uVar1 <= uVar7) {
      uVar1 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 == 0) goto LAB_00a6d6df;
    uVar7 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar2;
  }
  puVar3 = (undefined2 *)(uVar7 + uVar4 * 2);
  for (iVar2 = param_2 - uVar4; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = 0;
    puVar3 = puVar3 + 1;
  }
  uVar1 = 0;
  puVar3 = (undefined2 *)*param_1;
  uVar4 = (uint)((int)param_1[1] + (1 - (int)puVar3)) >> 1;
  if ((undefined2 *)param_1[1] < puVar3) {
    uVar4 = 0;
  }
  if (uVar4 != 0) {
    puVar5 = puVar3;
    do {
      uVar1 = uVar1 + 1;
      *(undefined2 *)((int)puVar5 + (uVar7 - (int)puVar3)) = *puVar5;
      puVar5 = puVar5 + 1;
    } while (uVar1 != uVar4);
    puVar3 = (undefined2 *)*param_1;
  }
  if (puVar3 != (undefined2 *)0x0) {
    uVar4 = param_1[2] - (int)puVar3 & 0xfffffffe;
    puVar5 = puVar3;
    if (0xfff < uVar4) {
      puVar5 = *(undefined2 **)(puVar3 + -2);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (uint)((int)puVar3 + (-4 - (int)puVar5))) {
LAB_00a6d6df:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar5,uVar4);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + param_2 * 2;
  param_1[2] = uVar6 + uVar7;
  return;
}



/* FUNCTION 21232 ; VA 0x00a6d6f0 ; FUN_00a6d6f0 */

void __thiscall FUN_00a6d6f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2760;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x14);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_resource<class_RBX::Voxel2::Cell*,void_(__cdecl*)(class_RBX::Voxel2::Cell*)>
              ::vftable;
    puVar1[3] = param_3;
    puVar1[4] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21233 ; VA 0x00a6d769 ; Catch_All@00a6d769 */

void Catch_All_00a6d769(void)

{
  int unaff_EBP;
  
  (**(code **)(unaff_EBP + 0xc))(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21234 ; VA 0x00a6d780 ; FUN_00a6d780 */

void FUN_00a6d780(int *param_1,int *param_2,int param_3,undefined4 param_4)

{
  undefined8 uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int iStack_34;
  undefined4 uStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  int *piStack_10;
  int iStack_c;
  undefined uStack_5;
  
  iVar3 = (int)param_2 - (int)param_1;
  piVar4 = param_1;
  do {
    iVar3 = iVar3 / 0xc;
    if (iVar3 < 0x21) {
LAB_00a6d84f:
      if (((1 < iVar3) && (piVar4 != param_2)) && (piStack_10 = piVar4 + 3, piStack_10 != param_2))
      {
        piStack_14 = piVar4 + 6;
        do {
          uVar1 = *(undefined8 *)piStack_10;
          iStack_c = piStack_10[2];
          iStack_34 = (int)uVar1;
          iStack_20 = (int)((ulonglong)uVar1 >> 0x20);
          if ((iStack_34 < *piVar4) ||
             ((piVar2 = piStack_10, iStack_34 == *piVar4 &&
              ((iStack_20 < piVar4[1] || ((iStack_20 == piVar4[1] && (iStack_c < piVar4[2])))))))) {
            iStack_24 = iStack_34;
            FUN_0055b6b0(&uStack_5,&piStack_18,&piStack_18);
            FUN_0170cc70((int)piStack_14 - ((int)piStack_10 - (int)piVar4),piVar4,
                         (int)piStack_10 - (int)piVar4);
            *(ulonglong *)piVar4 = CONCAT44(iStack_20,iStack_24);
            piVar4[2] = iStack_c;
          }
          else {
            while( true ) {
              piVar4 = piVar2 + -3;
              if ((*piVar4 <= iStack_34) &&
                 ((iStack_34 != *piVar4 ||
                  ((piVar2[-2] <= iStack_20 &&
                   ((iStack_20 != piVar2[-2] || (piVar2[-1] <= iStack_c)))))))) break;
              *(undefined8 *)piVar2 = *(undefined8 *)piVar4;
              piVar2[2] = piVar2[-1];
              piVar2 = piVar4;
            }
            *(undefined8 *)piVar2 = uVar1;
            piVar2[2] = iStack_c;
            piVar4 = param_1;
          }
          piStack_14 = piStack_14 + 3;
          piStack_10 = piStack_10 + 3;
        } while (piStack_10 != param_2);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar3) {
        FUN_00a6ceb0(piVar4,param_2,param_4);
        iVar3 = ((int)param_2 - (int)piVar4) / 0xc;
        if (iVar3 < 2) {
          return;
        }
        param_2 = param_2 + -3;
        if (iVar3 < 2) goto LAB_00a6d961;
        do {
          iStack_20 = param_2[2];
          uStack_28 = (undefined4)*(undefined8 *)param_2;
          iStack_24 = (int)((ulonglong)*(undefined8 *)param_2 >> 0x20);
          *(undefined8 *)param_2 = *(undefined8 *)piVar4;
          param_2[2] = piVar4[2];
          FUN_00a6d430(piVar4,0,((int)param_2 - (int)piVar4) / 0xc,&uStack_28,param_4);
LAB_00a6d961:
          param_2 = param_2 + -3;
        } while (1 < ((int)param_2 + (0xc - (int)piVar4)) / 0xc);
        return;
      }
      goto LAB_00a6d84f;
    }
    FUN_00a6d0c0(&piStack_1c,piVar4,param_2,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if (((int)piStack_1c - (int)piVar4) / 0xc < ((int)param_2 - (int)piStack_18) / 0xc) {
      FUN_00a6d780(piVar4,piStack_1c,param_3,param_4);
      param_1 = piStack_18;
      piVar4 = piStack_18;
    }
    else {
      FUN_00a6d780(piStack_18,param_2,param_3,param_4);
      param_2 = piStack_1c;
    }
    iVar3 = (int)param_2 - (int)piVar4;
  } while( true );
}



/* FUNCTION 21235 ; VA 0x00a6d9f0 ; FUN_00a6d9f0 */

/* WARNING: Removing unreachable block (ram,0x00a6da98) */
/* WARNING: Removing unreachable block (ram,0x00a6da9d) */
/* WARNING: Removing unreachable block (ram,0x00a6daf3) */
/* WARNING: Removing unreachable block (ram,0x00a6daf8) */
/* WARNING: Removing unreachable block (ram,0x00a6db5f) */
/* WARNING: Removing unreachable block (ram,0x00a6db64) */

void FUN_00a6d9f0(int *param_1)

{
  bool bVar1;
  int iVar2;
  int iStack_5c;
  char acStack_58 [72];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2778;
  bVar1 = false;
  iStack_5c = 0;
  acStack_58[0] = '\0';
  iVar2 = *param_1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  do {
    if (iVar2 == -0x3ea8cf1e) {
LAB_00a6db7a:
      if ((iStack_5c != 0) && (iStack_5c != -1)) {
        CloseHandle(iStack_5c);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar2 = *param_1;
    if (iVar2 == 0) {
      *param_1 = 0x7f0725e3;
      iVar2 = 0;
    }
    UNLOCK();
    if (iVar2 == 0) {
      if (iStack_5c == 0) {
        if (acStack_58[0] == '\0') {
          FUN_005881c0(acStack_58,param_1);
        }
        iStack_5c = OpenEventA(0x100002,0,acStack_58);
        if (iStack_5c != 0) goto LAB_00a6db02;
      }
      else {
LAB_00a6db02:
        ResetEvent(iStack_5c);
      }
      FUN_00a6e150();
      if (!bVar1) {
        LOCK();
        param_1[1] = param_1[1] + 1;
        UNLOCK();
      }
      LOCK();
      *param_1 = -0x3ea8cf1e;
      UNLOCK();
      if (iStack_5c == 0) {
        if (1 < param_1[1]) {
          if (acStack_58[0] == '\0') {
            FUN_005881c0(acStack_58,param_1);
          }
          iStack_5c = CreateEventA(0,1,0,acStack_58);
        }
        if (iStack_5c == 0) {
          ExceptionList = pvStack_10;
          return;
        }
      }
      SetEvent(iStack_5c);
      goto LAB_00a6db7a;
    }
    if (bVar1) {
LAB_00a6daa8:
      WaitForSingleObjectEx(iStack_5c,0xffffffff,0);
    }
    else {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      bVar1 = true;
      if (*param_1 == -0x3ea8cf1e) goto LAB_00a6db7a;
      if (iStack_5c != 0) goto LAB_00a6daa8;
      if (acStack_58[0] == '\0') {
        FUN_005881c0(acStack_58,param_1);
      }
      iStack_5c = CreateEventA(0,1,0,acStack_58);
    }
    iVar2 = *param_1;
  } while( true );
}



/* FUNCTION 21236 ; VA 0x00a6dba0 ; FUN_00a6dba0 */

int * __thiscall FUN_00a6dba0(int *param_1,int param_2)

{
  *param_1 = param_2;
  param_1[1] = param_2;
  param_1[2] = param_2;
  param_1[3] = param_2 * param_2;
  param_1[4] = 0;
  param_1[5] = 0;
  return param_1;
}



/* FUNCTION 21237 ; VA 0x00a6dbd0 ; FUN_00a6dbd0 */

int * __thiscall FUN_00a6dbd0(int *param_1,int param_2,int param_3,int param_4)

{
  param_1[1] = param_3;
  *param_1 = param_2;
  param_1[2] = param_4;
  param_1[3] = param_2 * param_4;
  param_1[4] = 0;
  param_1[5] = 0;
  return param_1;
}



/* FUNCTION 21238 ; VA 0x00a6dc10 ; FUN_00a6dc10 */

undefined4 * __fastcall FUN_00a6dc10(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  return param_1;
}



/* FUNCTION 21239 ; VA 0x00a6dc70 ; FUN_00a6dc70 */

undefined * __fastcall FUN_00a6dc70(undefined *param_1)

{
  undefined4 uVar1;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e27a3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = FUN_00588320(0xb);
  *(undefined4 *)(param_1 + 4) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  uStack_8 = 1;
  FUN_00a6d9f0(&DAT_01ee9128,&uStack_11);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21240 ; VA 0x00a6dd10 ; FUN_00a6dd10 */

void __fastcall FUN_00a6dd10(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    if (*(char *)(param_1 + 9) != '\0') {
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      FUN_016f32d1(iVar1 + 0x14,0x10,4,FUN_00a6de20);
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x5c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21241 ; VA 0x00a6dd70 ; FUN_00a6dd70 */

void __fastcall FUN_00a6dd70(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00a6f0c0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21242 ; VA 0x00a6de10 ; FUN_00a6de10 */

void __fastcall FUN_00a6de10(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00a6f0c0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21243 ; VA 0x00a6de20 ; FUN_00a6de20 */

void __fastcall FUN_00a6de20(undefined4 *param_1)

{
  if ((undefined4 *)*param_1 != &DAT_01ee9130) {
    FUN_01674ea0((undefined4 *)*param_1);
  }
  FUN_01674ea0(param_1[1]);
  return;
}



/* FUNCTION 21244 ; VA 0x00a6de50 ; FUN_00a6de50 */

void __fastcall FUN_00a6de50(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x1c);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x24) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
    *(undefined4 *)(param_1 + 0x24) = 0;
  }
  FUN_00a6dd70();
  return;
}



/* FUNCTION 21245 ; VA 0x00a6deb0 ; FUN_00a6deb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * __thiscall FUN_00a6deb0(byte *param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e27b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_00a6ce70(param_2);
  FUN_006e16e0(&param_2,uVar6,puVar5,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (undefined8 *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 1;
  }
  uVar1 = *puVar5;
  uVar2 = *(undefined4 *)(puVar5 + 1);
  uStack_8 = 0;
  FUN_00a6e330();
  _DAT_00000008 = uVar1;
  _DAT_00000010 = uVar2;
  FUN_016f4053(0x14,0x10,4,&LAB_00a6dc50,FUN_00a6de20);
  uRam00000054 = 0;
  uRam00000058 = 0xff;
  if (DAT_01d66380 != '\0') {
    uRam00000058 = 0;
  }
  _DAT_00000014 = &DAT_01ee9130;
  _DAT_0000001c = 0x20;
  _DAT_00000018 = 0;
  _DAT_00000020 = 0;
  uRam0000002c = 0x10;
  puRam00000024 = &DAT_01ee9130;
  uRam00000028 = 0;
  uRam00000030 = 0;
  uRam0000003c = 8;
  _DAT_00000034 = &DAT_01ee9130;
  uRam00000038 = 0;
  uRam00000040 = 0;
  uRam0000004c = 4;
  puRam00000044 = &DAT_01ee9130;
  uRam00000048 = 0;
  uRam00000050 = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar7 = uVar3 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005d6bb0(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_00a6ec40(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (undefined8 *)0x1;
    uVar9 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar7) {
      uVar9 = 1;
    }
    iVar8 = FUN_005d6bb0(uVar9 + uVar3);
    if (iVar8 != *(int *)(param_1 + 4)) {
      FUN_00a6ec40(iVar8);
      puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar11;
      while (puVar4 != (undefined4 *)0x0) {
        piVar10 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4)
        ;
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar10 = (int)puVar11;
          puVar11 = puVar4;
        }
        else {
          *puVar11 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar10;
          *(undefined4 **)*piVar10 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar11;
      }
    }
  }
  uVar7 = uVar6 % *(uint *)(param_1 + 4);
  piVar10 = *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
  puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
  _DAT_00000004 = uVar6;
  if (piVar10 == (int *)0x0) {
    piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar10 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar11 = piVar10;
    _DAT_00000000 = *piVar10;
  }
  else {
    _DAT_00000000 = *piVar10;
    piVar10 = (int *)*puVar11;
  }
  *piVar10 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (undefined8 *)&DAT_00000008;
}



/* FUNCTION 21246 ; VA 0x00a6e100 ; FUN_00a6e100 */

int * __fastcall FUN_00a6e100(int *param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = (int *)*param_1;
  param_1[1] = param_1[1] + 1;
  if (param_1[1] == piVar1[3]) {
    iVar2 = *piVar1;
    param_1[2] = param_1[2] + 1;
    param_1[1] = iVar2;
    if (param_1[2] == piVar1[4]) {
      iVar2 = piVar1[1];
      param_1[3] = param_1[3] + 1;
      param_1[2] = iVar2;
      if (param_1[3] == piVar1[5]) {
        *(undefined8 *)(param_1 + 1) = *(undefined8 *)(piVar1 + 3);
        param_1[3] = piVar1[5];
      }
    }
  }
  return param_1;
}



/* FUNCTION 21247 ; VA 0x00a6e150 ; FUN_00a6e150 */

void FUN_00a6e150(void)

{
  undefined2 *puVar1;
  int iVar2;
  byte bVar3;
  undefined4 *puVar4;
  
  bVar3 = 0;
  puVar1 = (undefined2 *)&DAT_01ee9940;
  do {
    iVar2 = 0x20;
    do {
      *puVar1 = CONCAT11((char)((int)-(uint)bVar3 >> 0x1f),bVar3);
      puVar1 = puVar1 + 1;
      iVar2 = iVar2 + -1;
    } while (iVar2 != 0);
    bVar3 = bVar3 + 1;
  } while ((int)puVar1 < 0x1eea901);
  puVar4 = &DAT_01ee9130;
  for (iVar2 = 0x200; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  return;
}



/* FUNCTION 21248 ; VA 0x00a6e1a0 ; FUN_00a6e1a0 */

void __fastcall FUN_00a6e1a0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(param_1 + 0xc))(*(undefined4 *)(param_1 + 0x10));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21249 ; VA 0x00a6e1e0 ; FUN_00a6e1e0 */

int __thiscall FUN_00a6e1e0(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_2 + 4,0x1dce318);
  if (iVar1 == 0) {
    return param_1 + 0xc;
  }
  return 0;
}


